#![recursion_limit = "256"]
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fmt::Write as _, fs, io::Read, path::{Path, PathBuf}, process::Command};

const R: &str = "/home/ubuntu/src/zopro-perf-work/negative-phi-sdk176";
const D: &str = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-negative-phi-sdk176";
fn read(p: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(p).unwrap()).unwrap() }
fn save(p: impl AsRef<Path>, v: &Value) { fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap(); }
fn hash(p: impl AsRef<Path>) -> String {
    let mut file = fs::File::open(p).unwrap(); let mut h = Sha256::new(); let mut buf = [0; 65536];
    loop { let n = file.read(&mut buf).unwrap(); if n == 0 { break; } h.update(&buf[..n]); }
    format!("{:x}", h.finalize())
}
fn walk(p: &Path, out: &mut Vec<PathBuf>) {
    for e in fs::read_dir(p).unwrap() { let e = e.unwrap();
        if e.file_type().unwrap().is_dir() { walk(&e.path(), out); }
        else if e.file_type().unwrap().is_file() { out.push(e.path()); }
    }
}
fn val(a: &Value, case: &str, arm: &str, field: &str) -> f64 {
    a["cells"][format!("{case}/{arm}")][field].as_f64().unwrap()
}
fn main() {
    assert!(!Path::new(D).exists());
    let a = read(format!("{R}/analysis.json")); let review = read(format!("{R}/review-result.json"));
    assert_eq!(review["passed"], true); assert_eq!(a["gate_passed"], false);
    assert_eq!(a["failed_checks"], review["failed_checks"]);
    assert_eq!(a["checks"].as_object().unwrap().len(), 79);
    assert_eq!(a["failed_checks"].as_array().unwrap().len(), 2);
    assert_eq!(a["canonical_proof_count"], 41104); assert_eq!(review["profile_samples"], 120193);
    let pins = read(format!("{R}/capture-pins.json")); assert_eq!(pins.as_object().unwrap().len(), 307);
    for (p, h) in pins.as_object().unwrap() { assert_eq!(hash(p), h.as_str().unwrap()); }
    let decision = json!({
        "declared_gate_passed": false, "failed_checks": a["failed_checks"],
        "fixed_implementation_closed": true, "unchanged_recapture_selected": false,
        "engineering_exception_selected": false, "production_changed": false, "adopted": false,
        "primary32_gain_established_against_both_controls": true,
        "primary32_ON_OFF": a["pairs"]["1x2-w32/ON/OFF"],
        "primary32_ON_REF": a["pairs"]["1x2-w32/ON/REF"],
        "overall_gain_against_fresh_control_established": false,
        "no_exclusions_extensions_or_threshold_changes": true,
        "canonical_proof_count": 41104,
        "next_research": "Distinct useful-work reduction in dominant MSM consumers; first inspect source and closed history against the qualified profiles. No selected replacement or new speed claim.",
        "goal_active": true, "goal_complete": false, "goal_shapes_met": 0
    });
    save(format!("{R}/decision.json"), &decision);
    let next = r#"# Continue CPU AVX research after the SDK result

Goal active and unmet: verified single-proof CPU AVX at least 10x supplied M5 CPU for all eight shapes; report CPU and Metal. Previous goal turn was no progress (timing clarification). This turn closes, reviews and publishes a completed full-SDK experiment. No production change is adopted.

Current completed root: /home/ubuntu/src/zopro-perf-work/negative-phi-sdk176.
Read protocol.md, analysis.json, review-result.json, decision.json and publication.json.
All workflows are terminal: build68688 exit0/11commands; preflight75869 exit0/52commands; capture6661 exit0/1263commands. Review74093 handle is missing after producing its passing review. No live capture, owned job or cloud resource.

The capture completed all591latency+18diagnostic SDK processes, then45offline commands and609independent Gnark checks. There are44106internally verified new requests including primes and609fresh independent exports. Together with preflight:44210requests/635exports. Canonical NEW41104 is /home/ubuntu/src/zopro-perf-work/negative-phi-sdk176/proof-sha256-after-capture.json. Prior40495preflight and40469older ledgers remain immutable. Do not replay completed qualification/capture/review/proof checks.

Fresh primary32 REF/OFF/ON medians of process means:7.832707987/7.834468543/7.818977007ms. Paired ON/OFF0.997447899 [0.995275739,0.999809828],23/31wins; ON/REF0.996718980 [0.994667945,0.999109462],26/31. This is a supported small primary gain; do not erase it or impose a gain floor. Primary16 ON/OFF1.000267467 [0.998762060,1.001923315],15/31, no established gain. Historical7.699867 is median-of-process-medians in a different campaign, not a matched regression control.

Gate FALSE2/79:2x2-w32/OFF/REF/calibration and ALL8/ON/OFF/gain. Fresh ALL8 ON/OFF1.001354993 [0.999256305,1.003515583], not established gain or regression; ON/REF0.992196547 [0.987000111,0.995939490]. The retained2x2block02 REF mean14.338358419ms versus OFF11.136398903 and ON11.037644290 contributes to favorable ON/REF aggregate. No exclusions or rescue. All other77numeric checks, all609proofs, source identities and qualified diagnostic ownership pass. Nineprofiles120193samples, unknown<=2.184%, zeroLOST;36PMUevents100%running. Fixed SDK recipe CLOSED/UNADOPTED, no extra exception or unchanged rerun.

Fresh accepted REF ALL8ms:7.832707987/11.065988613/15.913588194/24.254932903/34.007119871/40.086324129/66.467587258/65.569872290. M5 CPU37/59/109/189/284/335/528/507;Metal24/30/48/74/101/124/176/175. Targets3.7/5.9/10.9/18.9/28.4/33.5/52.8/50.7;0/8met. Merge54 REF/OFF/ON162.947719/162.013188/161.916019ms, no supplied M5 baseline. Primary32 maxRSS133.25/134.00/134.75MiB;merge54 1997.043/1991.746/1941.500MiB. Finite whole-process observations, not minimum RAM or pressure/mobile guarantees.

NEXT: distinct substantial arithmetic/algorithmic work reduction. In the fresh original REF32 cycle-IP profile, stream_g1_impl accounts20.79%, ordinary borrowedG2apply15.52%, inverseFq7.44%, G2reduce5.78%, G1balancedfeed4.72%, G1reduce4.56%. Crossbeam pin8.28% is aggregate work, not proof critical-path evidence; closed scheduler/prefault/stack/copy recipes stay closed. Inspect actual G1/G2 complete consumer and existing history before choosing a replacement. No next variant is selected yet. Aim at more useful work than the three cheap forward maps; preserve universal memory admission and finite exceptional behavior. No new proof/SKD/AWS/Aeglos result beyond this report.

Exactfield9d97 qualification reused. Source177files:172exact originals,4recoverable originals,1test child;3affine forward loops undernativeguard only. OFF/generic preserve original loops. No unadopted Euler row-capacity patch. The32worker gain does not authorize adopting a subset after failed full selection. No large persistent LUT/keyplan/workspace/input-sizedcopy/newpool/RAMcap/C/ASM rewrite. Original scalar/order/windows/resource policy remain required unless a distinct prospective study explicitly tests a necessary change.

Autoresearch loop: inspect actual source/profile and failed history; form a distinct falsifiable useful-work hypothesis; implement bounded private changes; use targeted independent oracles plus generic/resource/concurrent qualification; freeze controls/protocol/quality before clocks; run serialized xtask; after recordings verify proofs, analyze without sample changes, report every outcome, commit AND push, update exact canonical checkpoint. Never mark overall goal complete without all eight verified CPU targets. During ANY preflight/recording ONLY poll the exact confirmed live handle until terminal; timeout/truncation is not terminal. No helper/build/hash/analyze/decode/archive/push overlap recording. Rust1.98.1, noPython/questions/subagents. Raw proofs/perf/fullledger stay private; keep reports factual and polite. No token budget.
"#;
    fs::write(format!("{R}/next.md"), next).unwrap();
    fs::create_dir_all(format!("{D}/artifacts")).unwrap();
    for f in ["analysis.json", "review-result.json", "prospective-review.json", "source-audit.json", "decision.json", "design.md", "protocol.md", "next.md", "preflight-review.json", "proof-inventory.json", "profile-symbols.json"] {
        fs::copy(format!("{R}/{f}"), format!("{D}/artifacts/{f}")).unwrap();
    }
    let mut report = String::from(r#"# Short-forward G2 maps in the complete SDK

The primary 32-worker proof improves by 0.255% against the fresh control and 0.328% against the accepted reference under the declared paired analysis. The complete selection gate fails two of 79 checks: control calibration for 2x2 and all-eight gain against the fresh control. The candidate is closed without adoption or an unchanged rerun. Production is unchanged.

REF uses the frozen original-field accepted SDK with the existing fixed-placement driver. OFF and ON use coherent newly built core/prover/zolana/SDK artifacts with the same qualified short-factor field; only ON enables three affine forward-map replacements in the actual G2 entry. The scalar split, component order, projective maps, windows, grouping, solver, FFT and resource policy remain original. There is no added key table, input-sized array, retained workspace, pool or memory cap. The fixed factor occupies 64 logical constant bytes, independent of circuit size. The earlier field and query qualification are inherited, not replayed.

The actual integration passes 187 new independent Arkworks entry checks, including all 53 workers across 1/4/16/32-worker pools with requested 512 KiB stacks, a generic no-ASM/no-IFMA guard build, coherent native links and 26 SDK/Gnark preflights. All 176 accepted source originals recover from the private 177-file snapshot. Test-route counters are absent from the release consumers. The generic result is a compile check, not ARM execution.

The performance workflow completes all 1,263 commands on first execution: 591 latency processes, nine grouped PMU panels, nine cycle-IP profiles, 45 offline commands, then 609 independent Gnark checks. Capture requests total 44,106 including primes; all 609 distinct final exports pass independent verification. With preflights, the SDK stage totals 44,210 requests and 635 independent exports. The canonical private ledger advances from 40,469 before this stage through 40,495 after preflight to 41,104 after capture. Requests and prime calls are not counted as independent exports.

Each timed request includes witness preparation/solving, fresh randomized Groth16 proving, internal verification and serialization. Loading, pool creation, three prime calls and final export are excluded. The primary at 16/32 workers has 31 matched blocks of 151 requests per process; the other nine conditions have 15 blocks of 31 requests, except solo primary has 11 requests. REF/OFF/ON execute in rotating and reversing order. Worker placement, default Rayon stacks and allocator settings match. No concurrent proof-throughput result follows from these single-request measurements.

Latencies below are medians of process means, computed from all emitted per-request samples rounded to integer nanoseconds. Paired geometric ratios use corresponding blocks and 20,000 log-bootstrap resamples with the declared seed. Lower ratios are faster. Displayed medians need not divide to the paired estimate. Intervals assume exchangeable blocks and do not provide a familywise guarantee. There are no exclusions, extensions, rerolls or changed thresholds.

|Case|REF ms|OFF ms|ON ms|Paired ON/OFF [95% interval]|Wins|
|---|---:|---:|---:|---|---:|
"#);
    let cases = ["1x2-w32", "1x2-w16", "1x2-w1", "2x2-w32", "4x2-w32", "8x2-w32", "12x2-w32", "16x2-w32", "24x2-w32", "merge-24x1-w32", "merge-54x1-w32"];
    for name in cases {
        let p = &a["pairs"][format!("{name}/ON/OFF")];
        writeln!(report, "|{name}|{:.6}|{:.6}|{:.6}|{:.6} [{:.6}, {:.6}]|{}/{}|",
            val(&a, name, "REF", "median_ms"), val(&a, name, "OFF", "median_ms"), val(&a, name, "ON", "median_ms"),
            p["paired_geomean"].as_f64().unwrap(), p["bootstrap95"][0].as_f64().unwrap(), p["bootstrap95"][1].as_f64().unwrap(), p["wins"], if name == "1x2-w32" || name == "1x2-w16" {31} else {15}).unwrap();
    }
    report += r#"
Primary32 ON/OFF is 0.997448 [0.995276, 0.999810], with 23/31 wins; ON/REF is 0.996719 [0.994668, 0.999109], with 26/31 wins. Both gain and win checks pass. This is a supported small primary improvement, not a new sub-8-ms milestone. The accepted prover was already below 8 ms in earlier campaigns. The prior 7.699867 ms statistic was a median of process medians from a different campaign; it is not a matched regression control for these process means. Primary16 ON/OFF is 1.000267 [0.998762, 1.001923], with 15/31 wins, so a gain there is not established.

The failed checks are:

- `2x2-w32/OFF/REF/calibration`: ratio 0.975903 [0.942944, 0.995072], outside the declared interval-containment requirement [1/1.03, 1.03]. Block02 has REF/OFF/ON means 14.338358/11.136399/11.037644 ms. This favorable-to-ON reference observation remains included; no cause is established here.
- `ALL8/ON/OFF/gain`: equal-log ratio 1.001355 [0.999256, 1.003516]. The point estimate is 0.1355% slower, but neither gain nor regression is established. ALL8 ON/REF improves at 0.992197 [0.987000, 0.995939], with the calibration issue above retained. Shapes are resampled independently within their 31/15 blocks; unrelated shape blocks are not treated as synchronized observations.

All other 77 numeric checks pass, including all 22 nonregression and 22 RSS guards, both primary gain/win comparisons, ten of eleven calibrations and all 18 diagnostic quality checks. Source identities and proof correctness pass separately. The prospective protocol closes this fixed implementation on failure and authorizes no additional engineering exception. No candidate-only subset is promoted and no minimum gain floor is introduced.

|Case|REF peak MiB|OFF peak MiB|ON peak MiB|
|---|---:|---:|---:|
"#;
    for name in cases {
        writeln!(report, "|{name}|{:.3}|{:.3}|{:.3}|", val(&a,name,"REF","max_RSS_MiB"),val(&a,name,"OFF","max_RSS_MiB"),val(&a,name,"ON","max_RSS_MiB")).unwrap();
    }
    report += r#"
These are maximum whole-process RSS observations across each arm's latency processes, including image loading, primes and allocator state. They are not incremental scratch sizes, hard bounds, minimum RAM measurements or pressure/swap/mobile qualification. No very-large-circuit behavior is inferred.

All nine cycle profiles qualify: 120,193 samples, zero lost records, fixed 16M user-cycle periods, verified binary/PID/TID/CPU ownership and at most 2.184% unknown symbols. Absolute cycle-period coverage is not validated. All 36 PMU events have 100% reported running coverage. The single panels show ON/OFF instructions down 0.850% for primary32 and 0.696% for 2x2; user cycles down 0.406% and 0.774%. These diagnostics support lower CPU work but do not prove a wall-time critical-path saving.

The fresh original REF32 profile attributes 20.79% of samples to `stream_g1_impl`, 15.52% to ordinary borrowed G2 application, 7.44% to base-field inversion, 5.78% to G2 layer reduction, 4.72% to balanced G1 feed and 4.56% to G1 layer reduction. Crossbeam pinning accounts for 8.28% of aggregate samples; that is not evidence that its removal would save the same fraction of proof latency. The next distinct study should address larger useful-work consumers rather than repeat the three-map recipe. No replacement is selected by this report.

The reviewer independently reconstructs raw sample means, 79 gate decisions, RSS, proof freshness and source recovery. It is a separate reader run by the same agent, and shares the qualified bootstrap and diagnostic parsers with the analyzer. It is not an independent implementation of those parsers. All 307 capture pins are checked again for publication. No successful scientific command is repeated for publication.

The following comparison uses this campaign's unchanged accepted REF at 32 workers. M5 CPU and Metal are supplied reference timings, not newly measured devices. None of the eight CPU10x targets is reached. Merge54 has no supplied M5 reference.

|Shape|Accepted CPU ms|M5 CPU ms|M5 Metal ms|CPU speedup|Metal speedup|CPU10x target ms|
|---|---:|---:|---:|---:|---:|---:|
"#;
    let shapes = ["1x2","2x2","4x2","8x2","12x2","16x2","24x2","merge-24x1"];
    let names = ["1x2-w32","2x2-w32","4x2-w32","8x2-w32","12x2-w32","16x2-w32","24x2-w32","merge-24x1-w32"];
    let cpu = [37.,59.,109.,189.,284.,335.,528.,507.]; let metal = [24.,30.,48.,74.,101.,124.,176.,175.];
    let mut comp = vec![];
    for i in 0..8 { let ms = val(&a,names[i],"REF","median_ms"); assert!(ms>cpu[i]/10.);
        writeln!(report,"|{}|{:.6}|{:.0}|{:.0}|{:.3}x|{:.3}x|{:.1}|",shapes[i],ms,cpu[i],metal[i],cpu[i]/ms,metal[i]/ms,cpu[i]/10.).unwrap();
        comp.push(json!({"shape":shapes[i],"CPU_ms":ms,"M5_CPU_ms":cpu[i],"M5_Metal_ms":metal[i],"CPU_speedup":cpu[i]/ms,"Metal_speedup":metal[i]/ms,"CPU_10x_target_ms":cpu[i]/10.,"target_met":false}));
    }
    save(format!("{D}/artifacts/fresh-accepted-comparison.json"),&json!({"statistic":"median of process means", "accepted_REF_unchanged":true,"rows":comp,"goal_met":0,"goal_complete":false}));
    report += "\n[Results](artifacts/analysis.json), [review](artifacts/review-result.json), [protocol](artifacts/protocol.md), [prospective review](artifacts/prospective-review.json), [source audit](artifacts/source-audit.json), [decision](artifacts/decision.json), [proof inventory](artifacts/proof-inventory.json), [profile symbols](artifacts/profile-symbols.json), [CPU/Metal data](artifacts/fresh-accepted-comparison.json), [continuation](artifacts/next.md), [source and receipt archive](sources-receipts.tar.gz), [archive index](artifacts/archive-index.json), [checksums](SHA256SUMS). Raw proofs, private input images, binary libraries, raw perf recordings and full proof ledgers remain private. This experiment establishes no new AWS, Aeglos, ARM, mobile, huge-circuit, minimum-RAM or concurrent-throughput result.\n";
    fs::write(format!("{D}/README.md"),&report).unwrap();
    let pack = format!("{R}/publication-source"); fs::create_dir(&pack).unwrap();
    let mut files=vec![]; walk(Path::new(R),&mut files); files.sort(); let mut members=vec![]; let mut omitted=vec![];
    for p in files { let rel=p.strip_prefix(R).unwrap();
        if ["publication-source","publication-roundtrip","libs"].iter().any(|x|rel.starts_with(x)) {continue;}
        if p.file_name().unwrap().to_string_lossy().starts_with("proof-sha256-") {continue;}
        let ext=p.extension().and_then(|s|s.to_str()).unwrap_or("");
        if !["rs","md","json","log","nm","csv","toml","lock","wgsl","glsl","sha256"].contains(&ext) {continue;}
        let len=fs::metadata(&p).unwrap().len();
        if ext=="log" && len>1024*1024 {
            let exit=read(p.parent().unwrap().join("exit.json"));
            let key=if p.file_name().unwrap()=="stdout.log" {"stdout_sha256"} else {"stderr_sha256"};
            omitted.push(json!({"path":rel,"bytes":len,"sha256":exit[key],"reason":"large decoded text retained locally; metrics, ownership and receipts included"})); continue;
        }
        let bytes=fs::read(&p).unwrap(); assert!(std::str::from_utf8(&bytes).is_ok());
        let to=Path::new(&pack).join(rel);fs::create_dir_all(to.parent().unwrap()).unwrap();fs::write(&to,&bytes).unwrap();
        members.push(json!({"path":rel,"bytes":bytes.len(),"sha256":hash(to)}));
    }
    let archive=format!("{D}/sources-receipts.tar.gz"); assert!(Command::new("tar").args(["-czf",&archive,"-C",&pack,"."]).status().unwrap().success());
    let unpack=format!("{R}/publication-roundtrip");fs::create_dir(&unpack).unwrap();
    assert!(Command::new("tar").args(["-xzf",&archive,"-C",&unpack]).status().unwrap().success());
    for m in &members {assert_eq!(hash(Path::new(&unpack).join(m["path"].as_str().unwrap())),m["sha256"]);}
    save(format!("{D}/artifacts/archive-index.json"),&json!({"archive_sha256":hash(&archive),"regular_UTF8_only":true,"members":members,"omitted_large_logs":omitted,"raw_proofs_perf_binaries_images_full_ledgers_excluded":true}));
    fs::write(format!("{D}/SHA256SUMS"),"").unwrap();let mut links=0;
    for part in report.split("](").skip(1) {let link=part.split(')').next().unwrap();assert!(Path::new(D).join(link).is_file(),"{link}");links+=1;}
    let publication=json!({"passed":true,"UTF8_archive_members":members.len(),"large_local_logs":omitted.len(),"local_links_checked":links,"archive_roundtrip_and_checksums":true,"capture_pins_checked":307,"workflow_capture_commands_first_pass":1263,"SDK_processes":609,"latency_processes":591,"profile_samples":120193,"canonical_proof_count":41104,"new_capture_requests":44106,"new_capture_Gnark_exports":609,"stage_requests":44210,"stage_Gnark_exports":635,"gate_passed":false,"failed_checks_retained":2,"adopted":false,"engineering_exception":false,"goal_complete":false,"CPU_Metal_rows":8,"no_live_jobs_or_cloud":true});
    save(format!("{D}/artifacts/publication.json"),&publication);
    let mut files=vec![];walk(Path::new(D),&mut files);files.sort();let mut sums=String::new();
    for p in files {if p.file_name().unwrap()=="SHA256SUMS"{continue;}writeln!(sums,"{}  {}",hash(&p),p.strip_prefix(D).unwrap().display()).unwrap();}
    fs::write(format!("{D}/SHA256SUMS"),&sums).unwrap();
    for line in sums.lines(){let(h,p)=line.split_once("  ").unwrap();assert_eq!(hash(Path::new(D).join(p)),h);}
    save(format!("{R}/publication.json"),&publication);
    println!("PublicationPASS{}UTF8members/{}large-local-logs/{}links/checksums/roundtrip;2of79failures retained;unadopted;ledger41104",members.len(),omitted.len(),links);
}
