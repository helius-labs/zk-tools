use serde_json::Value;
use sha2::{Digest,Sha256};
use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-tree176";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/compact-tree176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn main(){
    assert!(!Path::new(R).join("candidate").exists());
    let old=fs::read_to_string(format!("{OLD}/packed_tree.rs")).unwrap();
    let head=&old[..old.find("struct Work<").unwrap()];
    let head=head.replace("//! Bounded complete unweighted tree. Native coordinates persist across levels.","//! Complete weighted group with compact native intermediate coordinates.");
    let kernel=head+&fs::read_to_string(format!("{R}/native.rs")).unwrap();
    fs::write(format!("{R}/weighted_tree.rs"),kernel).unwrap();
    let driver=fs::read_to_string(format!("{OLD}/driver.rs")).unwrap().replace("PackedTreeG1","WeightedTreeG1").replace("PackedTreeG2","WeightedTreeG2");
    fs::write(format!("{R}/driver.rs"),&driver).unwrap();
    let m:Value=serde_json::from_slice(&fs::read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json")).unwrap()).unwrap();
    assert_eq!(m["source_files_sha256"].as_object().unwrap().len(),176);
    for label in ["control","candidate"] {
        let root=format!("{R}/{label}");let source=format!("{root}/source");
        for(p,h)in m["source_files_sha256"].as_object().unwrap(){let bytes=fs::read(format!("{Z}/{p}")).unwrap();assert_eq!(format!("{:x}",Sha256::digest(&bytes)),h.as_str().unwrap());let out=format!("{source}/{p}");fs::create_dir_all(Path::new(&out).parent().unwrap()).unwrap();fs::write(out,bytes).unwrap();}
        for(p,extra)in[
            ("crates/zopro-core/src/msm.rs","\npub mod weighted_tree;\n"),
            ("crates/zopro-core/src/lib.rs","\n#[doc(hidden)] pub use msm::weighted_tree::{CallerG1 as WeightedTreeG1,CallerG2 as WeightedTreeG2};\n"),
            ("crates/zopro-bn254/src/ifma8.rs","\n#[cfg(zopro_packed_tree)] #[path=\"ifma8_tree.rs\"] mod tree;\n")
        ] {let path=format!("{source}/{p}");let mut text=fs::read_to_string(&path).unwrap();text.push_str(extra);fs::write(path,text).unwrap();}
        for(from,to)in[("weighted_tree.rs","crates/zopro-core/src/msm/weighted_tree.rs"),("ifma8_tree.rs","crates/zopro-bn254/src/ifma8_tree.rs")]{fs::copy(format!("{R}/{from}"),format!("{source}/{to}")).unwrap();}
        let path=format!("{source}/crates/zopro-core/src/simd.rs");let text=fs::read_to_string(&path).unwrap();assert_eq!(text.matches("impl FqBatch {\n").count(),1);fs::write(path,text.replacen("impl FqBatch {\n",&format!("impl FqBatch {{\n{}",fs::read_to_string(format!("{R}/simd-methods.rs")).unwrap()),1)).unwrap();
        let path=format!("{source}/scripts/ifma8.py");let text=fs::read_to_string(&path).unwrap();let marker="output = path.parent / \"ifma8.rs\"";assert_eq!(text.matches(marker).count(),1);let inserted="source += '\\n#[cfg(zopro_packed_tree)] #[path=\"ifma8_tree.rs\"] mod tree;\\n'\n";fs::write(path,text.replacen(marker,&format!("{inserted}{marker}"),1)).unwrap();
        fs::create_dir_all(format!("{root}/src")).unwrap();
        fs::write(format!("{root}/src/main.rs"),&driver).unwrap();
        fs::copy(format!("{Z}/crates/zopro-bench/examples/support/perf.rs"),format!("{root}/src/perf.rs")).unwrap();
        fs::write(format!("{root}/Cargo.toml"),format!("[package]\nname=\"zopro-weighted-tree-{label}\"\nversion=\"0.0.0\"\nedition=\"2021\"\npublish=false\n[workspace]\n[dependencies]\nzopro-core={{path=\"source/crates/zopro-core\"}}\nserde_json=\"=1.0.149\"\nsha2=\"=0.10.9\"\nrayon=\"1.10\"\nlibc=\"0.2\"\n[profile.release]\nopt-level=3\nlto=true\ncodegen-units=1\n")).unwrap();
        fs::write(format!("{R}/{label}-flags.txt"),format!("{}{}",m["rustflags"].as_str().unwrap(),if label=="candidate"{" --cfg zopro_packed_tree"}else{""})).unwrap();
    }
    println!("Verified176originals;prepared two178file weighted diagnostic snapshots;fieldhelper bytes inherited exactly");
}
