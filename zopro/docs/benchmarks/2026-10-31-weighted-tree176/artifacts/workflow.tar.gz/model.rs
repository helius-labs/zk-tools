// Integer coefficient oracle: no field/curve/native code is imported.
fn coefficients(n:usize)->(Vec<i64>,Vec<i64>){
    let mut segments=vec![(0..n).map(|i|{let mut v=vec![0i64;n];v[i]=1;v}).collect::<Vec<_>>()];
    while segments[0].len()>1 {
        let correction=segments[0].iter().step_by(2).cloned().collect::<Vec<_>>();
        let old=segments.len();let live=segments[0].len();
        for segment in &mut segments {
            assert_eq!(segment.len(),live);
            *segment=segment.chunks_exact(2).map(|p|p[0].iter().zip(&p[1]).map(|(a,b)|a+b).collect()).collect();
        }
        segments.push(correction);
        assert_eq!(segments.len(),old+1);assert!(segments.iter().all(|s|s.len()==live/2));
    }
    let total=segments[0][0].clone();let mut weighted=total.clone();
    for correction in segments[1..].iter().rev(){for(i,x)in weighted.iter_mut().enumerate(){*x=2**x-correction[0][i];}}
    (weighted,total)
}
#[test]fn every_weight_and_total_through_256(){for k in 0..=8{let n=1<<k;let(w,t)=coefficients(n);assert_eq!(w,(1..=n as i64).collect::<Vec<_>>());assert_eq!(t,vec![1;n]);}}
#[test]fn native_ranges_and_saved_tail_are_disjoint(){for n in[16usize,32,64,128,256]{let(mut live,mut s)=(n,1);while live>8{let g=live/8;let o=live/16;let old=s*g;for seg in 0..s{for j in 0..o{let src=seg*g+2*j;let dst=seg*o+j;assert!(dst<=src);assert!(src+1<old);for next in dst+1..s*o{let ns=(next/o)*g+2*(next%o);assert!(dst<ns);}}}assert!(s*o+o<=old+o);assert!(old+o<=3*n/16);live/=2;s+=1;}}}
