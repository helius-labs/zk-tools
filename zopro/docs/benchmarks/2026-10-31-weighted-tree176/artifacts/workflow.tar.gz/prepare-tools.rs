use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-tree176";
const H:&str="/home/ubuntu/src/zopro-perf-work/high-borrow176";
fn one(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1);}
fn main(){
 assert!(!Path::new(R).join("campaign.rs").exists());
 let mut s=fs::read_to_string(format!("{H}/campaign.rs")).unwrap().replace(H,R);
 s=s.replace("127 passed","128 passed").replace("--crate-name zopro_high_borrow_","--crate-name zopro_weighted_tree_");
 one(&mut s,"assert_ne!(hash(r(\"OFF-bin\")),hash(r(\"ON-bin\")))","assert_eq!(hash(r(\"OFF-bin\")),hash(r(\"ON-bin\")))");
 one(&mut s,"[(\"G2\",200),(\"G2\",352),(\"G1\",200),(\"G1\",352)]","[(\"G2\",128),(\"G2\",256),(\"G1\",128),(\"G1\",256)]");
 let start=s.find("for f in[\"setup.rs\"").unwrap();let end=start+s[start..].find("walk(&r(\"linked-code\")").unwrap();
 s.replace_range(start..end,"for entry in fs::read_dir(R).unwrap(){let entry=entry.unwrap();if entry.file_type().unwrap().is_file(){let p=entry.path();let ext=p.extension().and_then(|x|x.to_str()).unwrap_or(\"\");if [\"rs\",\"md\",\"json\",\"txt\",\"log\"].contains(&ext)||[\"control-bin\",\"OFF-bin\",\"ON-bin\",\"campaign\",\"review\",\"audit\",\"codegen\"].contains(&entry.file_name().to_str().unwrap()){files.push(p);}}}");
 one(&mut s,"filter(|c|c.3==32).collect::<Vec<_>>()","filter(|c|c.3==32&&c.2==256).collect::<Vec<_>>()");
 one(&mut s,"for c in contexts().iter().filter(|c|c.3==32)","for c in contexts().iter().filter(|c|c.3==32&&c.2==256)");
 s=s.replace("660","618").replace("600 callers","588 callers").replace("600checkedcallers","588checkedcallers").replace("callers.len(),600","callers.len(),588");
 s=s.replace("v[\"kind\"]","v[\"curve\"]").replace("v[\"priming_rounds\"],128","v[\"priming_rounds\"],8");
 one(&mut s,"assert_eq!(v[\"scratch_capacity_bytes_by_worker\"],ov[\"scratch_capacity_bytes_by_worker\"]);","if arm!=\"ON\"&&other!=\"ON\"{assert_eq!(v[\"scratch_capacity_bytes_by_worker\"],ov[\"scratch_capacity_bytes_by_worker\"]);}if arm==\"ON\"&&other!=\"ON\"{assert!(v[\"scratch_capacity_bytes_by_worker\"][0].as_u64().unwrap()<=ov[\"scratch_capacity_bytes_by_worker\"][0].as_u64().unwrap());}");
 s=s.replace("{curve}-200-w32","{curve}-128-w32").replace("{curve}-352-w32","{curve}-256-w32");
 fs::write(format!("{R}/campaign.rs"),s).unwrap();
 let mut s=fs::read_to_string(format!("{H}/review.rs")).unwrap().replace(H,R);
 let start=s.find("let m=read(format!").unwrap();let end=s.find("let pins=read(r(\"pins.json\"))").unwrap();
 s.replace_range(start..end,"let source=read(r(\"source-audit.json\"));assert_eq!(source[\"passed\"],true);assert_eq!(source[\"recovered_originals\"],352);let recovered=352;let core=fs::read_to_string(r(\"core-tests.log\")).unwrap();assert!(core.contains(\"test result: ok. 128 passed; 0 failed\"));");
 s=s.replace("660","618").replace("600","588").replace("127","128").replace("[177,178]","[178,178]").replace("\"control\":174,\"candidate\":172","\"control\":171,\"candidate\":171");
 s=s.replace("{curve}-200-w32","{curve}-128-w32").replace("{curve}-352-w32","{curve}-256-w32");
 one(&mut s,"assert_eq!(raw[\"scratch_capacity_bytes_by_worker\"],q[\"scratch_capacity_bytes_by_worker\"]);","if arm!=\"ON\"&&other!=\"ON\"{assert_eq!(raw[\"scratch_capacity_bytes_by_worker\"],q[\"scratch_capacity_bytes_by_worker\"]);}if arm==\"ON\"&&other!=\"ON\"{assert!(raw[\"scratch_capacity_bytes_by_worker\"][0].as_u64().unwrap()<=q[\"scratch_capacity_bytes_by_worker\"][0].as_u64().unwrap());}");
 s=s.replace("\"all_capacities_equal_and_zero_timed_allocations\":true","\"candidate_capacities_no_larger_and_zero_timed_allocations\":true").replace("\"original_field_files_changed\":1","\"original_field_arithmetic_changed\":false").replace("\"original_general_subtraction_body_recovered_exact\":true","\"source_audit\":source");
 fs::write(format!("{R}/review.rs"),s).unwrap();
 println!("Prepared fixed618command/588caller campaign and independent raw statistics reviewer");
}
