use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,process::Command,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-tree176";
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 fs::create_dir(format!("{R}/linked-code")).unwrap();let mut variants=BTreeMap::<String,Value>::new();
 for(arm,file)in[("frozen","control-bin"),("OFF","OFF-bin"),("ON","ON-bin")]{
  let binary=format!("{R}/{file}");let result=Command::new("nm").args(["-S","--size-sort",&binary]).output().unwrap();assert!(result.status.success());
  let mut rows=vec![];
  for line in String::from_utf8(result.stdout).unwrap().lines(){
   let f=line.split_whitespace().collect::<Vec<_>>();if f.len()!=4{continue;}
   let symbol=rustc_demangle::try_demangle(f[3]).map(|s|format!("{s:#}")).unwrap_or_else(|_|f[3].into());
   if !(symbol.contains("::msm::weighted_tree::")||symbol.contains("::msm::weighted_sum::<")||symbol.contains("::msm::reduce_layer::<")){continue;}
   let output=Command::new("objdump").args(["-d","--no-show-raw-insn",&format!("--disassemble={}",f[3]),&binary]).output().unwrap();assert!(output.status.success());
   let text=String::from_utf8(output.stdout).unwrap();let path=format!("linked-code/{arm}-{:02}.txt",rows.len());fs::write(format!("{R}/{path}"),&text).unwrap();
   let mut instructions=0;let mut ifma=0;let mut rsp=0;
   for line in text.lines(){let Some((address,tail))=line.trim().split_once(':')else{continue;};if address.is_empty()||!address.chars().all(|x|x.is_ascii_hexdigit()){continue;}let Some(op)=tail.split_whitespace().next()else{continue;};instructions+=1;if op.starts_with("vpmadd52"){ifma+=1;}if tail.contains("(%rsp)"){rsp+=1;}}
   rows.push(json!({"symbol":symbol,"bytes":u64::from_str_radix(f[1],16).unwrap(),"instruction_sites":instructions,"IFMA_sites":ifma,"RSP_operand_lines":rsp,"assembly":path,"sha256":hash(&format!("{R}/{path}"))}));
  }
  assert!(!rows.is_empty());variants.insert(arm.into(),json!({"binary_sha256":hash(&binary),"functions":rows}));
 }
 fs::write(format!("{R}/codegen.json"),serde_json::to_vec_pretty(&json!({"variants":variants,"static_sites_not_dynamic_counts_or_spills":true})).unwrap()).unwrap();println!("Linked weighted diagnostic functions mapped without fixed specialization count");
}
