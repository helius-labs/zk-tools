use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-tree176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn main(){
 let m:Value=serde_json::from_slice(&fs::read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json")).unwrap()).unwrap();let mut recovered=0;let mut unchanged=0;
 for label in["control","candidate"]{for(p,h)in m["source_files_sha256"].as_object().unwrap(){let original=fs::read(format!("{Z}/{p}")).unwrap();assert_eq!(hash(&original),h.as_str().unwrap());let file=fs::read(format!("{R}/{label}/source/{p}")).unwrap();if file==original{unchanged+=1;}
 let mut bytes=file.clone();
 match p.as_str(){
 "crates/zopro-core/src/msm.rs"=>bytes=bytes.strip_suffix(b"\npub mod weighted_tree;\n").unwrap().to_vec(),
 "crates/zopro-core/src/lib.rs"=>bytes=bytes.strip_suffix(b"\n#[doc(hidden)] pub use msm::weighted_tree::{CallerG1 as WeightedTreeG1,CallerG2 as WeightedTreeG2};\n").unwrap().to_vec(),
 "crates/zopro-bn254/src/ifma8.rs"=>bytes=bytes.strip_suffix(b"\n#[cfg(zopro_packed_tree)] #[path=\"ifma8_tree.rs\"] mod tree;\n").unwrap().to_vec(),
 "crates/zopro-core/src/simd.rs"=>{let text=String::from_utf8(bytes).unwrap();let inserted=fs::read_to_string(format!("{R}/simd-methods.rs")).unwrap();assert_eq!(text.matches(&inserted).count(),1);bytes=text.replacen(&inserted,"",1).into_bytes();},
 "scripts/ifma8.py"=>{let text=String::from_utf8(bytes).unwrap();let inserted="source += '\\n#[cfg(zopro_packed_tree)] #[path=\"ifma8_tree.rs\"] mod tree;\\n'\n";assert_eq!(text.matches(inserted).count(),1);bytes=text.replacen(inserted,"",1).into_bytes();},_=>{}
 }
 assert_eq!(bytes,original,"{label}/{p}");recovered+=1;
 }
 for(from,to)in[("weighted_tree.rs","crates/zopro-core/src/msm/weighted_tree.rs"),("ifma8_tree.rs","crates/zopro-bn254/src/ifma8_tree.rs")]{assert_eq!(fs::read(format!("{R}/{from}")).unwrap(),fs::read(format!("{R}/{label}/source/{to}")).unwrap());}
 }
 assert_eq!(recovered,352);assert_eq!(unchanged,342);
 for p in["ifma8_tree.rs","simd-methods.rs"]{assert_eq!(fs::read(format!("{R}/{p}")).unwrap(),fs::read(format!("/home/ubuntu/src/zopro-perf-work/compact-tree176/{p}")).unwrap());}
 let old=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/compact-tree176/packed_tree.rs").unwrap();let prefix=old[..old.find("struct Work<").unwrap()].replace("//! Bounded complete unweighted tree. Native coordinates persist across levels.","//! Complete weighted group with compact native intermediate coordinates.");assert_eq!(fs::read_to_string(format!("{R}/weighted_tree.rs")).unwrap(),prefix+&fs::read_to_string(format!("{R}/native.rs")).unwrap());
 let tests=fs::read_to_string(format!("{R}/core-tests.log")).unwrap();assert!(tests.contains("test result: ok. 128 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
 assert!(fs::read_to_string(format!("{R}/field-tests.log")).unwrap().contains("test result: ok. 37 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
 assert!(fs::read_to_string(format!("{R}/model-tests.log")).unwrap().contains("test result: ok. 2 passed; 0 failed"));
 assert!(!Path::new(&format!("{R}/source-audit.json")).exists());
 fs::write(format!("{R}/source-audit.json"),serde_json::to_vec_pretty(&json!({"passed":true,"recovered_originals":recovered,"unchanged_originals":unchanged,"private_source_files_each":178,"field_helper_and_SIMD_wrapper_exact_previous":true,"all_original_arithmetic_and_scheduler_bytes_recovered":true,"field_tests":37,"core_tests":128,"integer_model_tests":2,"production_changed":false})).unwrap()).unwrap();
 println!("Source audit PASS:352recovered/342unchanged;weighted native child only;37field/128core/2integer tests");
}
