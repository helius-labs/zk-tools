struct Work<C:CurveConfig> where C::Base:PackedBase {
    a:Vec<Point<C::Base>>, prefix:Vec<[FqBatch;2]>,
    original:Vec<LimbPoint<C::Base>>, scratch:Scratch<C>, fallbacks:usize,
}
impl<C:CurveConfig>Default for Work<C> where C::Base:PackedBase {
    fn default()->Self {Self{a:vec![],prefix:vec![],original:vec![],scratch:Scratch{vector_inverse:true,..Default::default()},fallbacks:0}}
}
impl<C:CurveConfig>Work<C> where C::Base:PackedBase {
    fn baseline(&mut self,input:&[Affine<C>])->(Projective<C>,Affine<C>) {
        let n=input.len(); assert!(n.is_power_of_two());
        self.original.resize(2*n-1,LimbPoint::infinity());
        for (out,&p) in self.original.iter_mut().zip(input) {*out=limbs::<C>(p);}
        let w=weighted_sum(&mut self.original,n,&mut self.scratch);
        (w,affine::<C>(self.original[0]))
    }
    fn run(&mut self,input:&[Affine<C>],on:bool)->(Projective<C>,Affine<C>) {
        #[cfg(zopro_packed_tree)] if on {
            if let Some(v)=self.native(input) {return v;}
            // Input is immutable. No packed result or large buffer overlaps
            // the fallback allocation, including after a late rejection.
            self.a=Vec::new(); self.prefix=Vec::new(); self.fallbacks+=1;
        }
        let _=on; self.baseline(input)
    }
    #[cfg(zopro_packed_tree)]
    fn native(&mut self,input:&[Affine<C>])->Option<(Projective<C>,Affine<C>)> {
        type F<C>=<C as CurveConfig>::Base;
        let n=input.len(); assert!(n.is_power_of_two()&&n<=256);
        if n<=8 || input.iter().any(|p|p.is_identity()) {return None;}
        let native_levels=n.ilog2() as usize-3;
        let tail_capacity=8*(native_levels+1)+7;
        if self.original.capacity()>tail_capacity {
            self.original=Vec::new(); self.scratch=Scratch{vector_inverse:true,..Default::default()};
        }
        self.a.clear(); self.a.reserve_exact(3*n/16);
        for group in input.chunks_exact(8) {
            let raw:[LimbPoint<C::Base>;8]=core::array::from_fn(|i|limbs::<C>(group[i]));
            self.a.push(Point{
                x:F::<C>::store_native(&F::<C>::load(core::array::from_fn(|i|&raw[i].x))),
                y:F::<C>::store_native(&F::<C>::load(core::array::from_fn(|i|&raw[i].y))),
            });
        }
        self.prefix.clear(); self.prefix.reserve_exact(n/16);
        let (mut live,mut segments)=(n,1usize);
        while live>8 {
            let old=self.a.len(); let per_segment=live/8; let per_output=live/16;
            assert_eq!(old,segments*per_segment);
            // Save the odd-weight correction before any input is overwritten.
            // Its tail starts beyond all old segments and stays untouched.
            for j in 0..per_output {
                let p=self.a[2*j]; let q=self.a[2*j+1];
                let (x,_)=F::<C>::adjacent_native(&p.x,&q.x);
                let (y,_)=F::<C>::adjacent_native(&p.y,&q.y);
                self.a.push(Point{x:F::<C>::store_native(&x),y:F::<C>::store_native(&y)});
            }
            self.prefix.clear(); let mut chains=FqBatch::one();
            for segment in 0..segments {for j in 0..per_output {
                let k=segment*per_segment+2*j;
                let (ax,bx)=F::<C>::adjacent_native(&self.a[k].x,&self.a[k+1].x);
                let norm=F::<C>::lanes_norm(&F::<C>::lanes_sub(&bx,&ax));
                if norm.tree_zero_mask()!=0 {return None;}
                self.prefix.push([chains,norm]); chains=chains.mul(&norm);
            }}
            let mut inverse=chains.inverse_nonzero();
            for record in self.prefix.iter_mut().rev() {
                let factor=record[0].mul(&inverse); inverse=inverse.mul(&record[1]); record[0]=factor;
            }
            // Outputs precede future source pairs. The saved correction tail
            // is outside this range. All inverse factors already exist.
            for segment in 0..segments {for j in 0..per_output {
                let k=segment*per_segment+2*j; let out=segment*per_output+j;
                let p=self.a[k]; let q=self.a[k+1];
                let (ax,bx)=F::<C>::adjacent_native(&p.x,&q.x);
                let (ay,by)=F::<C>::adjacent_native(&p.y,&q.y);
                let dx=F::<C>::lanes_sub(&bx,&ax);
                let slope=F::<C>::lanes_scaled_numerator(&F::<C>::lanes_sub(&by,&ay),&dx,&self.prefix[out][0]);
                let x=F::<C>::lanes_sub(&F::<C>::lanes_square(&slope),&F::<C>::lanes_add(&ax,&bx));
                let y=F::<C>::lanes_sub(&F::<C>::lanes_mul(&slope,&F::<C>::lanes_sub(&ax,&x)),&ay);
                self.a[out]=Point{x:F::<C>::store_native(&x),y:F::<C>::store_native(&y)};
            }}
            let output_end=segments*per_output;
            self.a.copy_within(old..old+per_output,output_end);
            self.a.truncate(output_end+per_output); live/=2; segments+=1;
        }
        assert_eq!(self.a.len(),segments); assert_eq!(live,8);
        self.original.clear(); self.original.reserve_exact(tail_capacity);
        for p in &self.a {
            let x=F::<C>::store(&F::<C>::load_native(&p.x));
            let y=F::<C>::store(&F::<C>::load_native(&p.y));
            self.original.extend((0..8).map(|i|LimbPoint{x:x[i],y:y[i]}));
        }
        let mut starts=[0usize;usize::BITS as usize]; let mut counts=[0usize;usize::BITS as usize];
        for j in 0..segments {starts[j]=8*j;counts[j]=8;}
        while counts[0]>1 {
            let half=counts[0]/2; let next=self.original.len();
            for i in 0..half {self.original.push(self.original[2*i]);}
            reduce_layer(&mut self.original,&starts[..segments],&mut counts[..segments],&mut self.scratch);
            starts[segments]=next;counts[segments]=half;segments+=1;
        }
        let total=affine::<C>(self.original[0]); let mut sum=total.to_projective();
        for start in starts[1..segments].iter().rev() {sum=sum.double();sum-=affine::<C>(self.original[*start]);}
        Some((sum,total))
    }
    fn capacity(&self)->usize {
        self.a.capacity()*core::mem::size_of::<Point<C::Base>>()
        +self.prefix.capacity()*core::mem::size_of::<[FqBatch;2]>()
        +self.original.capacity()*core::mem::size_of::<LimbPoint<C::Base>>()
        +self.scratch.groups.capacity()*core::mem::size_of::<Group<C::Base>>()
        +self.scratch.prefix_records.capacity()*core::mem::size_of::<[FqBatch;2]>()
        +self.scratch.pairs.capacity()*core::mem::size_of::<usize>()
    }
}

struct Inputs(u64);
impl Inputs {
    fn fr(&mut self)->Fr {
        let mut bytes=[0u8;64];
        for chunk in bytes.chunks_mut(8) {
            self.0=self.0.wrapping_add(0x9e3779b97f4a7c15);
            let mut v=self.0;v=(v^(v>>30)).wrapping_mul(0xbf58476d1ce4e5b9);
            v=(v^(v>>27)).wrapping_mul(0x94d049bb133111eb);v^=v>>31;
            chunk.copy_from_slice(&v.to_le_bytes());
        }
        Fr::from_random_bytes(&bytes)
    }
}
struct Fixture<C:CurveConfig>where C::Base:PackedBase {
    source:Vec<Affine<C>>,weights:Vec<Fr>,last:[(Projective<C>,Affine<C>);2],work:Work<C>,n:usize,
}
impl<C:CurveConfig>Fixture<C>where C::Base:PackedBase {
    fn new(n:usize,seed:u64)->Self {
        assert!(n.is_power_of_two()&&n<=256);
        let mut rng=Inputs(seed);
        let weights=(0..n+1).map(|_|rng.fr()).collect::<Vec<_>>();
        let g=Projective::<C>::generator();
        let source=Projective::<C>::batch_to_affine(&weights.iter().map(|s|g**s).collect::<Vec<_>>());
        Self{source,weights,last:[(Projective::IDENTITY,Affine::IDENTITY);2],work:Work::default(),n}
    }
    fn run(&mut self,rounds:usize,on:bool) {for i in 0..rounds {let k=i%2;self.last[k]=std::hint::black_box(self.work.run(std::hint::black_box(&self.source[k..k+self.n]),on));}}
    fn check(&self) {
        let g=Projective::<C>::generator();
        for k in 0..2 {
            let mut total=Fr::ZERO;let mut weighted=Fr::ZERO;
            for i in 0..self.n {total+=self.weights[k+i];weighted+=self.weights[k+i]*Fr::from(i as u64+1);}
            assert_eq!(self.last[k].0.to_affine(),(g*weighted).to_affine());
            assert_eq!(self.last[k].1,(g*total).to_affine());
        }
    }
}
pub struct CallerG1(Fixture<G1Config>);pub struct CallerG2(Fixture<G2Config>);
macro_rules! caller {($t:ident)=>{impl $t {
    pub fn new(n:usize,seed:u64)->Self {Self(Fixture::new(n,seed))}
    pub fn run(&mut self,n:usize,on:bool) {self.0.run(n,on)}
    pub fn check(&self) {self.0.check()}
    pub fn capacity_bytes(&self)->usize {self.0.work.capacity()}
    pub fn fallback_count(&self)->usize {self.0.work.fallbacks}
    pub fn digest(&self)->String {format!("{:?}",self.0.last.map(|(w,t)|(w.to_affine(),t)))}
}};}
caller!(CallerG1);caller!(CallerG2);

#[cfg(test)]mod weighted_tests {
    use super::*;
    fn check<C:CurveConfig>()where C::Base:PackedBase {
        let g=Projective::<C>::generator();
        let mut random=crate::testing::Seeded::new(0x7765696768746564);
        for n in [1usize,2,4,8,16,32,64,128,256] {
            let weights=(0..n).map(|_|random.fr()).collect::<Vec<_>>();
            let ordinary=Projective::<C>::batch_to_affine(&weights.iter().map(|s|g**s).collect::<Vec<_>>());
            for family in 0..5 {
                let mut values=ordinary.clone();
                if n>=4 {match family {
                    1=>values[n/2]=Affine::IDENTITY,
                    2=>values[1]=values[0],
                    3=>values[1]=-values[0],
                    4=>{for(i,s)in[3i64,5,11,-19].into_iter().enumerate(){values[i]=(g*if s<0{-Fr::from((-s)as u64)}else{Fr::from(s as u64)}).to_affine();}},
                    _=>{}
                }}
                let want_total=values.iter().fold(Projective::<C>::IDENTITY,|s,p|s+*p).to_affine();
                let want_weighted=values.iter().enumerate().fold(Projective::<C>::IDENTITY,|s,(i,p)|s+*p*Fr::from(i as u64+1)).to_affine();
                let before=values.clone(); let mut w=Work::<C>::default();
                for on in [false,true,false,true] {let (a,b)=w.run(&values,on);assert_eq!(a.to_affine(),want_weighted,"n{n} family{family}");assert_eq!(b,want_total);assert_eq!(values,before);}
            }
        }
    }
    #[test]fn weighted_g1_total_exceptions_transitions(){check::<G1Config>();}
    #[test]fn weighted_g2_total_exceptions_transitions(){check::<G2Config>();}
    #[test]fn weighted_small_stack_threaded_reuse() {
        use rayon::prelude::*;
        for workers in [1,4,16,32] {
            let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();
            pool.install(||(0..workers).into_par_iter().for_each(|i|for n in [128,256] {
                let mut a=CallerG1::new(n,i as u64+19);let mut b=CallerG2::new(n,i as u64+19);
                for on in [false,true] {for _ in 0..3 {a.run(4,on);a.check();b.run(4,on);b.check();}}
            }));
        }
    }
}
