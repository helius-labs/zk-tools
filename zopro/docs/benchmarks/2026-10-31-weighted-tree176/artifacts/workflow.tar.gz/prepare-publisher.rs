use std::fs;
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-tree176";
fn one(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1);}
fn main(){let mut s=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/high-borrow176/publish.rs").unwrap().replace("high-borrow176","weighted-tree176");
 s=s.replace("93990","145764");
 one(&mut s,"len(),12)","len(),8)");
 one(&mut s,"f[\"assembly_sha256\"]","f[\"sha256\"]");
 one(&mut s,"\"review.log\",","\"review-v2.log\",");
 one(&mut s,"\"helper-repair.md\",","\"planning-notes.md\",\"work-model.json\",");
 one(&mut s,"|Record / tail bytes per fixture, all arms|","|Original / OFF / ON retained scratch bytes per fixture|");
 one(&mut s,"row[\"scratch_capacity_bytes_first_worker\"][\"ON\"]","format!(\"{} / {} / {}\",row[\"scratch_capacity_bytes_first_worker\"][\"frozen\"],row[\"scratch_capacity_bytes_first_worker\"][\"OFF\"],row[\"scratch_capacity_bytes_first_worker\"][\"ON\"])");
 let start=s.find("table=\"|Linked function|").unwrap();let end=start+s[start..].find("let m=read(").unwrap();s.replace_range(start..end,"");
 one(&mut s,"sources.len(),355","sources.len(),356");
 let start=s.find("assert_eq!(assembly.len(),7);").unwrap();let end=start+s[start..].find("groups.insert(\"codegen\",assembly)").unwrap();s.replace_range(start..end,"assert_eq!(assembly.len(),33);");
 one(&mut s,"\"core_tests\":127","\"core_tests\":128");one(&mut s,"\"capture_commands\":660","\"capture_commands\":618");one(&mut s,"\"caller_processes\":600","\"caller_processes\":588");one(&mut s,"\"failed_checks\":12","\"failed_checks\":8");
 one(&mut s,"guarded-borrow gatefalse","weighted-tree gatefalse");
 fs::write(format!("{R}/publish.rs"),s).unwrap();println!("Prepared weighted-tree publication from exact archival workflow; no benchmark code or data changes");
}
