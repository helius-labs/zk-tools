//! Proof-local window-major Booth digits. Original bucket arithmetic is unchanged.
use super::*;
use zopro_bn254::{G1Affine,G1Config};
const WINDOWS:usize=21;
const WIDTH:usize=12;
pub(crate) struct Result {pub buckets:Vec<Vec<G1Affine>>,pub decoded:bool,pub capacity_bytes:usize}
struct Planes {digits:Vec<i16>,_charge:crate::preparation::Reservation}
fn forecast(n:usize)->Option<usize>{crate::msm_affine::grouping_cost::vector::<i16>(n.checked_mul(WINDOWS)?,false)}
impl Planes {
 fn new(words:&[[u64;4]])->Option<Self>{
  let n=words.len();if n==0{return None;}
  let total=n.checked_mul(WINDOWS)?;let charge=crate::preparation::Reservation::analysis(forecast(n))?;
  let mut digits=Vec::new();digits.try_reserve_exact(total).ok()?;digits.resize(total,0);
  if digits.capacity().checked_mul(core::mem::size_of::<i16>())?>forecast(n)?{return None;}
  digits.par_chunks_mut(n).enumerate().for_each(|(w,plane)|{for(out,scalar)in plane.iter_mut().zip(words){*out=digit(scalar,w,WIDTH);}});
  Some(Self{digits,_charge:charge})
 }
}
fn ordinary(points:&[G1Affine],words:&[[u64;4]])->Result{
 let size=batch_size(WIDTH).max(32);let buckets=(0..WINDOWS).into_par_iter().map(|w|{let mut s=Window::<G1Config>::new(1<<(WIDTH-1),size);s.feed(points,words,w,WIDTH,size);s.finish()}).collect();Result{buckets,decoded:false,capacity_bytes:0}
}
pub(crate) fn fill(points:&[G1Affine],words:&[[u64;4]],on:bool)->Result{
 assert_eq!(points.len(),words.len());
 #[cfg(zopro_digit_planes)]if on{if let Some(planes)=Planes::new(words){let size=batch_size(WIDTH).max(32);let buckets=planes.digits.par_chunks(words.len()).map(|digits|{let mut s=Window::<G1Config>::new(1<<(WIDTH-1),size);feed(&mut s,points,digits,size);s.finish()}).collect();let capacity_bytes=planes.digits.capacity()*core::mem::size_of::<i16>();return Result{buckets,decoded:true,capacity_bytes};}}
 let _=on;ordinary(points,words)
}
fn feed<'a>(state:&mut Window<'a,G1Config>,points:&'a[G1Affine],digits:&[i16],size:usize){
 for(point,&d)in points.iter().zip(digits){
  if d==0||point.is_identity(){continue;}
  let bucket=d.unsigned_abs()as usize-1;
  let encoded=bucket as u32|if d<0{1<<31}else{0};
  if state.busy(bucket){state.queue.push((encoded,point));if state.queue.len()==size-1{state.flush_queue();}continue;}
  state.add(encoded,point);if state.batch.len()==size{state.execute();state.take_from_queue();}
 }
}
#[cfg(all(test,zopro_digit_planes))]mod tests{
 use super::*;use zopro_bn254::{Field,Fr,G1Projective};
 #[test]fn layout_boundaries_and_independent_bit_digits(){
  use crate::testing::Seeded;let mut rng=Seeded::new(0x706c616e6573);let mut values=vec![Fr::ZERO,Fr::ONE,-Fr::ONE];for bit in 0..254{let x=Fr::from(2u64).pow(&[bit]);values.extend([x,x-Fr::ONE,x+Fr::ONE]);}values.extend((0..513).map(|_|rng.fr()));let words=values.iter().map(Fr::to_canonical).collect::<Vec<_>>();let plan=Planes::new(&words).unwrap();assert_eq!(plan.digits.len(),WINDOWS*words.len());for(w,plane)in plan.digits.chunks(words.len()).enumerate(){for(d,s)in plane.iter().zip(&words){let bit=|i:usize|((s[i/64]>>(i%64))&1)as i64;let low=(0..WIDTH).map(|i|bit(w*WIDTH+i)<<i).sum::<i64>();let incoming=if w==0{0}else{bit(w*WIDTH-1)};let sign=bit((w+1)*WIDTH-1);assert_eq!(*d as i64,low+incoming-(sign<<WIDTH));}}
 }
 #[test]fn complete_bucket_generator_reference_and_repeated_pools(){
  use crate::testing::Seeded;let mut rng=Seeded::new(0x6275636b6574);let n=65;let mut coefficients=Vec::new();let points=(0..n).map(|i|{let coefficient=if i%13==0{Fr::ZERO}else if i%3==0{-Fr::from(i as u64+1)}else{Fr::from(i as u64+1)};coefficients.push(coefficient);G1Affine::GENERATOR*coefficient}).collect::<Vec<_>>();let points=G1Projective::batch_to_affine(&points);let mut words=(0..n).map(|_|rng.fr().to_canonical()).collect::<Vec<_>>();words[0]=[0;4];words[1]=Fr::ONE.to_canonical();words[2]=(-Fr::ONE).to_canonical();
  let expected=(0..WINDOWS).map(|w|{let mut coefficients_by_bucket=vec![Fr::ZERO;1<<(WIDTH-1)];for(s,c)in words.iter().zip(&coefficients){let d=digit(s,w,WIDTH);if d!=0{coefficients_by_bucket[d.unsigned_abs()as usize-1]+=if d<0{-*c}else{*c};}}G1Projective::batch_to_affine(&coefficients_by_bucket.into_iter().map(|c|G1Affine::GENERATOR*c).collect::<Vec<_>>())}).collect::<Vec<_>>();
  for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();for on in[false,true,false,true]{let result=pool.install(||fill(&points,&words,on));assert_eq!(result.buckets,expected);assert_eq!(result.decoded,on);if on{assert_eq!(result.capacity_bytes,42*n);}}}
 }
 #[test]fn checked_layout_and_empty_fallback(){assert_eq!(forecast(0),Some(0));for n in[1,7,8,65,21006,36637,65536]{assert_eq!(forecast(n),Some(n*42+64));}assert_eq!(forecast(usize::MAX),None);assert!(Planes::new(&[]).is_none());let a=fill(&[],&[],true);assert!(!a.decoded);assert!(a.buckets.iter().flatten().all(|p|p.is_identity()));}
}
