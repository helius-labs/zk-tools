#[cfg(test)]mod page_frame_tests{
    use super::*;use std::collections::BTreeMap;
    fn check(words:&[[u64;4]]){let expected=words.iter().enumerate().filter(|(_,s)|**s!=[0;4]).fold(BTreeMap::<[u64;4],Vec<u32>>::new(),|mut m,(i,&s)|{m.entry(s).or_default().push(i as u32);m});for zero_aware in[false,true]{let g=scalar_groups_policy(words,zero_aware);if words.len()<256{assert!(g.is_none());continue;}let g=g.expect("repeated inputs admit original policy");assert_eq!(g.len,words.len());assert_eq!(g.values.len(),expected.len());assert_eq!(g.starts.len(),g.values.len()+1);assert_eq!(g.starts[0],0);let mut first=vec![];for &s in words{if s!=[0;4]&&!first.contains(&s){first.push(s);}}assert_eq!(g.values,first);let mut order=vec![];for(i,s)in first.iter().enumerate(){assert_eq!(g.counts[i],expected[s].len());assert_eq!(g.starts[i],order.len());order.extend_from_slice(&expected[s]);assert_eq!(g.starts[i+1],order.len());}assert_eq!(g.order,order);}}
    #[test]fn page_frame_worker_calls_preserve_groups(){
        #[cfg(all(zopro_page_safe_group_frame,target_arch="x86_64",target_feature="avx512ifma",not(no_ifma)))]{assert_eq!(std::mem::align_of::<PageAlignedFrame>(),4096);assert_eq!(std::mem::size_of::<PageAlignedFrame>(),4096);}
        let inputs=[0usize,17,255,256,1025,2049].map(|n|(0..n).map(|i|if i%3==0{[0;4]}else{let v=(i%17+1)as u64;[v,v*19,v*37,v*53]}).collect::<Vec<_>>());
        let mut visits=0;for workers in[1usize,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512<<10).build().unwrap();let rows=pool.broadcast(|_|{for words in &inputs{check(words);}1usize});assert_eq!(rows.len(),workers);visits+=rows.iter().sum::<usize>();}assert_eq!(visits,53);
        let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512<<10).build().unwrap();std::thread::scope(|s|{let handles=(0..4).map(|_|s.spawn(||pool.install(||{for words in &inputs{check(words);}}))).collect::<Vec<_>>();for h in handles{h.join().unwrap();}});
        println!("PAGE_FRAME_WORKER_VISITS={visits};CONCURRENT_CALLERS=4");
    }
}
