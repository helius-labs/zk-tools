//! Proof-local scalar grouping and its admission policy.
//!
//! Returned groups own scalar values and stable input-index lists. The
//! reservation outlives every owned buffer and all point-reduction consumers.
use super::grouping_cost;
use rayon::prelude::*;
use zopro_bn254::Fr;

pub(crate) struct ScalarGroups {
    pub(super) len: usize,
    pub(super) values: Vec<[u64; 4]>,
    pub(super) order: Vec<u32>,
    pub(super) starts: Vec<usize>,
    pub(super) counts: Vec<usize>,
    // Drop the charge after all owned buffers.
    pub(super) _reservation: crate::preparation::Reservation,
}
/// Group before converting representations, so only distinct witness
/// scalars need Montgomery reduction. The grouping is fresh per proof.
pub(crate) fn group_witness(scalars: &[Fr]) -> Option<ScalarGroups> {
    if !crate::simd::cpu_option("ZOPRO_CPU_DEDUP") {
        return None;
    }
    // SAFETY: Fr is repr(transparent) over four u64 limbs. This shared
    // view only compares/hashes the existing Montgomery representations.
    let words =
        unsafe { std::slice::from_raw_parts(scalars.as_ptr().cast::<[u64; 4]>(), scalars.len()) };
    let mut groups = scalar_groups(words)?;
    groups.values.par_iter_mut().for_each(|value| {
        *value = Fr::from_montgomery(*value).to_canonical();
    });
    Some(groups)
}

pub(crate) fn scalar_groups(scalars: &[[u64; 4]]) -> Option<ScalarGroups> {
    scalar_groups_policy(
        scalars,
        std::env::var("ZOPRO_CPU_ZERO_AWARE_GROUPS").as_deref() == Ok("1"),
    )
}

type GroupSample<'a> = std::collections::HashSet<&'a [u64; 4], ahash::RandomState>;

fn grouping_sample(scalars: &[[u64; 4]], zero_aware: bool) -> Option<(GroupSample<'_>, usize)> {
    let sample = scalars.len().min(2048);
    let stride = scalars.len().div_ceil(sample);
    let unique: GroupSample<'_> = scalars.iter().step_by(stride).take(sample).collect();
    // A strided sample of a partial domain may contain fewer than 2048
    // observations. OFF retains the original denominator for comparison.
    let observed = if zero_aware {
        scalars.len().div_ceil(stride).min(sample)
    } else {
        sample
    };
    if unique.len() * 200 > observed * 199 {
        return None;
    }
    let percent = if (32768..65536).contains(&scalars.len())
        && crate::simd::cpu_option("ZOPRO_CPU_SMALL_GROUPS")
    {
        95
    } else {
        80
    };
    if zero_aware {
        let zeros = scalars
            .iter()
            .step_by(stride)
            .take(sample)
            .filter(|s| **s == [0; 4])
            .count();
        let nonzero = observed - zeros;
        let unique_nonzero = unique.len() - usize::from(zeros != 0);
        // Scattered zeros alone do not justify a full hash map when all
        // sampled nonzero values are distinct and the zero density cannot
        // meet the existing grouping cutoff. Repeated nonzero samples and
        // dense-zero samples retain the original grouping decision.
        let decline = unique_nonzero == nonzero && nonzero * 100 > observed * percent;
        if std::env::var_os("ZOPRO_CPU_GROUP_TRACE").is_some() {
            eprintln!(
                "ZERO_AWARE_GROUP n={} sampled={} zeros={} unique_nonzero={} percent={} decline={}",
                scalars.len(),
                observed,
                zeros,
                unique_nonzero,
                percent,
                decline
            );
        }
        if decline {
            return None;
        }
    }
    Some((unique, percent))
}

fn scalar_groups_policy(scalars: &[[u64; 4]], zero_aware: bool) -> Option<ScalarGroups> {
    #[cfg(all(zopro_page_safe_group_frame,target_arch="x86_64",target_feature="avx512ifma",not(no_ifma)))]
    let mut page_frame=PageAlignedFrame{_byte:0};
    #[cfg(all(zopro_page_safe_group_frame,target_arch="x86_64",target_feature="avx512ifma",not(no_ifma)))]
    std::hint::black_box(&mut page_frame);
    if scalars.len() < 256 || scalars.len() >= u32::MAX as usize {
        return None;
    }
    let (unique, percent) = grouping_sample(scalars, zero_aware)?;
    let reservation = grouping_cost::reserve(scalars.len(), percent)?;
    // Bound the initial allocation by the sample and by the grouping
    // cutoff. Small high-diversity inputs otherwise grow and rehash the
    // entire table several times before either succeeding or declining.
    let capacity = if crate::simd::cpu_option("ZOPRO_CPU_RESERVE_GROUPS") {
        (unique.len() * 16)
            .min(scalars.len() * percent / 100)
            .min(32768)
    } else {
        0
    };
    let mut groups =
        std::collections::HashMap::with_capacity_and_hasher(capacity, ahash::RandomState::new());
    let mut values = Vec::new();
    let mut classes = vec![u32::MAX; scalars.len()];
    let mut counts: Vec<usize> = Vec::new();
    for (scalar, class) in scalars.iter().zip(&mut classes) {
        if *scalar == [0; 4] {
            continue;
        }
        let index = *groups.entry(*scalar).or_insert_with(|| {
            values.push(*scalar);
            counts.push(0);
            (values.len() - 1) as u32
        });
        *class = index;
        counts[index as usize] += 1;
    }
    drop(groups);
    if values.len() * 100 > scalars.len() * percent {
        return None;
    }
    if values.is_empty() {
        return Some(ScalarGroups {
            _reservation: reservation,
            len: scalars.len(),
            values,
            order: Vec::new(),
            starts: vec![0],
            counts,
        });
    }
    let mut starts = Vec::with_capacity(counts.len() + 1);
    starts.push(0);
    for &count in &counts {
        starts.push(starts.last().unwrap() + count);
    }
    let mut positions = starts[..counts.len()].to_vec();
    let mut order = vec![0u32; *starts.last().unwrap()];
    for (i, &class) in classes.iter().enumerate() {
        if class != u32::MAX {
            order[positions[class as usize]] = i as u32;
            positions[class as usize] += 1;
        }
    }
    drop(classes);
    drop(positions);
    Some(ScalarGroups {
        _reservation: reservation,
        len: scalars.len(),
        values,
        order,
        starts,
        counts,
    })
}

#[cfg(test)]
mod tests;

#[cfg(all(zopro_page_safe_group_frame,target_arch="x86_64",target_feature="avx512ifma",not(no_ifma)))]
#[repr(align(4096))]
struct PageAlignedFrame{_byte:u8}
#[cfg(test)]mod page_frame_tests{
    use super::*;use std::collections::BTreeMap;
    fn check(words:&[[u64;4]]){let expected=words.iter().enumerate().filter(|(_,s)|**s!=[0;4]).fold(BTreeMap::<[u64;4],Vec<u32>>::new(),|mut m,(i,&s)|{m.entry(s).or_default().push(i as u32);m});for zero_aware in[false,true]{let g=scalar_groups_policy(words,zero_aware);if words.len()<256{assert!(g.is_none());continue;}let g=g.expect("repeated inputs admit original policy");assert_eq!(g.len,words.len());assert_eq!(g.values.len(),expected.len());assert_eq!(g.starts.len(),g.values.len()+1);assert_eq!(g.starts[0],0);let mut first=vec![];for &s in words{if s!=[0;4]&&!first.contains(&s){first.push(s);}}assert_eq!(g.values,first);let mut order=vec![];for(i,s)in first.iter().enumerate(){assert_eq!(g.counts[i],expected[s].len());assert_eq!(g.starts[i],order.len());order.extend_from_slice(&expected[s]);assert_eq!(g.starts[i+1],order.len());}assert_eq!(g.order,order);}}
    #[test]fn page_frame_worker_calls_preserve_groups(){
        #[cfg(all(zopro_page_safe_group_frame,target_arch="x86_64",target_feature="avx512ifma",not(no_ifma)))]{assert_eq!(std::mem::align_of::<PageAlignedFrame>(),4096);assert_eq!(std::mem::size_of::<PageAlignedFrame>(),4096);}
        let inputs=[0usize,17,255,256,1025,2049].map(|n|(0..n).map(|i|if i%3==0{[0;4]}else{let v=(i%17+1)as u64;[v,v*19,v*37,v*53]}).collect::<Vec<_>>());
        let mut visits=0;for workers in[1usize,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512<<10).build().unwrap();let rows=pool.broadcast(|_|{for words in &inputs{check(words);}1usize});assert_eq!(rows.len(),workers);visits+=rows.iter().sum::<usize>();}assert_eq!(visits,53);
        let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512<<10).build().unwrap();std::thread::scope(|s|{let handles=(0..4).map(|_|s.spawn(||pool.install(||{for words in &inputs{check(words);}}))).collect::<Vec<_>>();for h in handles{h.join().unwrap();}});
        println!("PAGE_FRAME_WORKER_VISITS={visits};CONCURRENT_CALLERS=4");
    }
}
