use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,io::Read,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/coalesce-query176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn r(p:impl AsRef<Path>)->PathBuf{Path::new(R).join(p)}fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn pin(m:&mut BTreeMap<String,String>,p:impl AsRef<Path>){m.insert(p.as_ref().display().to_string(),hash(&p));}
fn walk(p:&Path,m:&mut BTreeMap<String,String>){for e in fs::read_dir(p).unwrap(){let p=e.unwrap().path();if p.is_dir(){walk(&p,m)}else{pin(m,p)}}}
fn main(){
 assert!(!r("build-plan.json").exists());let mut pins=BTreeMap::new();walk(&r("source"),&mut pins);assert_eq!(pins.len(),177);
 assert_eq!(hash(r("coalesce.rs")),hash(r("source/crates/zopro-core/src/msm_affine/coalesce.rs")));
 let m=read(Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
 for(p,h)in m["source_files_sha256"].as_object().unwrap(){assert_eq!(hash(Path::new(Z).join(p)),h.as_str().unwrap());pin(&mut pins,Path::new(Z).join(p));}
 for name in["coalesce.rs","classifier.rs","probe-export.rs","setup.rs","setup","bootstrap.rs","bootstrap","native.rs","native-helper","native-flags.txt","candidate-flags.txt","design.md","source-audit.json"]{pin(&mut pins,r(name));}
 pin(&mut pins,"/home/ubuntu/src/zopro-perf-work/tool-target/release/xtask");
 let mut steps=vec![];
 for label in["control","candidate"]{
  let flags=fs::read_to_string(r(if label=="control"{"native-flags.txt"}else{"candidate-flags.txt"})).unwrap();let mut env=m["environment"].clone();env["RUSTFLAGS"]=json!(flags);env["CARGO_BUILD_JOBS"]=json!("16");env["CARGO_TARGET_DIR"]=json!(r(format!("target-{label}")));env["RAYON_NUM_THREADS"]=json!("4");
  if label=="candidate"{steps.push(json!({"kind":"command","name":"candidate-core","argv":["cargo","test","--manifest-path",r("source/Cargo.toml"),"--locked","--offline","--release","-p","zopro-core","--lib","msm_affine::coalesce::tests::","--","--test-threads=1"],"environment":env,"required_tests":["msm_affine::coalesce::tests::classification_matches_original_and_sparse_spans_are_exact","msm_affine::coalesce::tests::complete_queries_match_generator_sums_and_denial","msm_affine::coalesce::tests::complete_exceptions_and_partition_tile_boundaries"],"timeout_seconds":1800}));}
  steps.push(json!({"kind":"command","name":format!("libraries-{label}"),"argv":["cargo","build","--manifest-path",r("source/Cargo.toml"),"--locked","--offline","--release","-p","zopro-bench","--lib","--message-format=json"],"environment":env,"timeout_seconds":1800}));
  steps.push(json!({"kind":"command","name":format!("freeze-{label}"),"argv":[r("native-helper"),"freeze",label],"environment":env,"timeout_seconds":600}));
 }
 save(r("build-pins.json"),&json!(pins));save(r("build-plan.json"),&json!({"version":1,"source_pins":r("build-pins.json"),"steps":steps}));println!("Prepared5native steps,3focused changed-path tests,2coherent library freezes; production unchanged");
}
