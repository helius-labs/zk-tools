use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,io::Read,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/coalesce-query176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn r(p:impl AsRef<Path>)->PathBuf{Path::new(R).join(p)}fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn pin(p:&mut BTreeMap<String,String>,x:impl AsRef<Path>){p.insert(x.as_ref().display().to_string(),hash(&x));}
fn function<'a>(s:&'a str,needle:&str)->&'a str{let a=s.find(needle).unwrap();let b=a+s[a..].find('{').unwrap();let mut n=0;for(i,c)in s.as_bytes()[b..].iter().enumerate(){if *c==b'{'{n+=1}if *c==b'}'{n-=1;if n==0{return &s[a..b+i+1]}}}panic!("body")}
fn append(file:&str,extra:&str){let p=r("source").join(file);let mut s=fs::read_to_string(&p).unwrap();s.push_str("\n// BEGIN PRIVATE COALESCE QUERY EXPERIMENT\n");s.push_str(extra);s.push('\n');fs::write(p,s).unwrap();}
fn main(){
 assert!(!r("source").exists());let manifest=Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");let m=read(&manifest);
 for(p,h)in m["source_files_sha256"].as_object().unwrap(){let from=Path::new(Z).join(p);assert_eq!(hash(&from),h.as_str().unwrap());let to=r("source").join(p);fs::create_dir_all(to.parent().unwrap()).unwrap();fs::copy(from,to).unwrap();}
 fs::copy(r("coalesce.rs"),r("source/crates/zopro-core/src/msm_affine/coalesce.rs")).unwrap();
 append("crates/zopro-core/src/msm_affine.rs","#[cfg(all(zopro_coalesce_query,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma)))]\npub(crate) mod coalesce;");
 let classifier=fs::read_to_string(r("classifier.rs")).unwrap();append("crates/zopro-core/src/msm_affine/grouping.rs",&format!("#[cfg(zopro_coalesce_query)] mod coalesced_classifier{{use super::*;\n{classifier}\n}}\n#[cfg(zopro_coalesce_query)] pub(super) use coalesced_classifier::{{Classified,classify_for_overlay}};"));
 append("crates/zopro-core/src/lib.rs",&fs::read_to_string(r("probe-export.rs")).unwrap());
 let a=r#"#[cfg(zopro_coalesce_query)]
pub(super) fn coalesce_window<'a>(bases:&'a[zopro_bn254::G1Affine],words:&[[u64;4]],overlay:&'a super::coalesce::Overlay<zopro_bn254::G1Config>,w:usize)->Vec<zopro_bn254::G1Affine>{
 let size=batch_size(12).max(32);let mut state=Window::<zopro_bn254::G1Config>::new(2048,size);
 overlay.spans(bases,words,0..bases.len(),|p,s,_|state.feed(p,s,w,12,size));state.finish()
}
"#;append("crates/zopro-core/src/msm_affine/borrowed_pending.rs",a);
 let g2=fs::read_to_string(Path::new(Z).join("crates/zopro-core/src/msm_affine/g2_borrowed.rs")).unwrap();let feed=function(&g2,"fn feed(");let begin=feed.find("        for (p, s)").unwrap();let end=feed.rfind("        self.execute();").unwrap();let loopbody=&feed[begin..end];assert!(loopbody.ends_with("        }\n"));
 let b=format!(r#"#[cfg(zopro_coalesce_query)]
impl<'a> Window<'a>{{fn coalesce_run(&mut self,bases:&'a[G2Affine],short:&[[u64;4]],high:bool,w:usize){{let bits=12;let size=batch_size(bits).max(32);
{loopbody}
}}}}
#[cfg(zopro_coalesce_query)]
pub(super) fn coalesce_phi(points:&mut[G2Affine]){{for p in points{{if !p.is_identity(){{p.x=p.x.mul_by_fp(&BETA);}}}}}}
#[cfg(zopro_coalesce_query)]
pub(super) fn coalesce_window<'a>(bases:&'a[G2Affine],words:&[[u64;4]],overlay:&'a super::coalesce::Overlay<G2Config>,range:std::ops::Range<usize>,w:usize)->Vec<G2Affine>{{
 let packed=BatchAdd::<G2Config>::default();assert!(packed.borrowed_g2_enabled());let mut state=Window::new(2048,200,packed);
 overlay.spans(bases,words,range.clone(),|p,s,_|state.coalesce_run(p,s,true,w));state.execute();state.flush_queue();
 coalesce_phi(&mut state.affine);for p in &mut state.projective{{p.x=p.x.mul_by_fp(&BETA);}}
 overlay.spans(bases,words,range,|p,s,_|state.coalesce_run(p,s,false,w));state.execute();state.flush_queue();state.finish()
}}
"#);append("crates/zopro-core/src/msm_affine/g2_borrowed.rs",&b);
 let msm=fs::read_to_string(Path::new(Z).join("crates/zopro-core/src/msm.rs")).unwrap();let body=function(&msm,"pub(super) fn reduce_indexed_buckets<");let mut mapped=body.replace("reduce_indexed_buckets<C: CurveConfig>","coalesce_indexed<C: CurveConfig, Get>");assert!(mapped.contains("coalesce_indexed"));
 assert_eq!(mapped.matches("    bases: &[Affine<C>],\n").count(),1);mapped=mapped.replace("    bases: &[Affine<C>],\n","").replace("    starts: &[usize],\n","    starts: &[usize],\n    get: Get,\n").replace("    C::Base: BatchInverse,\n","    C::Base: BatchInverse,\n    Get: Fn(u32)->Affine<C> + Sync,\n").replace("limbs::<C>(bases[i as usize])","limbs::<C>(get(i))");append("crates/zopro-core/src/msm.rs",&format!("#[cfg(zopro_coalesce_query)]\n{mapped}"));
 let mut audit=BTreeMap::new();let mut exact=0;for(p,h)in m["source_files_sha256"].as_object().unwrap(){let path=r("source").join(p);let bytes=fs::read(&path).unwrap();let current=hash(&path);if current==h.as_str().unwrap(){exact+=1;}else{let marker=b"\n// BEGIN PRIVATE COALESCE QUERY EXPERIMENT\n";let at=bytes.windows(marker.len()).position(|v|v==marker).unwrap();assert_eq!(bytes[..at],fs::read(Path::new(Z).join(p)).unwrap());}audit.insert(p.clone(),json!({"original_sha256":h,"private_sha256":current,"prefix_recovery":true}));}
 assert_eq!(exact,170);save(r("source-audit.json"),&json!({"complete":true,"originals":176,"original_files_byte_exact":exact,"append_only_parents":6,"new_children":1,"field_files_unchanged":true,"G2_feed_loop_source_exact":true,"indexed_reducer_only_getter_changed":true,"files":audit}));
 let flags=m["rustflags"].as_str().unwrap().to_owned()+" --cfg zopro_coalesce_probe";fs::write(r("native-flags.txt"),&flags).unwrap();fs::write(r("candidate-flags.txt"),flags.clone()+" --cfg zopro_coalesce_query").unwrap();
 // Reuse the checked native artifact freezer, with task-root paths only.
 let helper=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/g1-column-tiles176/native.rs").unwrap().replace("/home/ubuntu/src/zopro-perf-work/g1-column-tiles176",R);fs::write(r("native.rs"),helper).unwrap();
 println!("Prepared177files:170exact,6append-only parents,1privatechild; all field sources exact; no production edits");
}
