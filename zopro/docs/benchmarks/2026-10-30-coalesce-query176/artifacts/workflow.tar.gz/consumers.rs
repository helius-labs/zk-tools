use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,io::Read,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/coalesce-query176";
fn r(p:impl AsRef<Path>)->PathBuf{Path::new(R).join(p)}fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn pin(m:&mut BTreeMap<String,String>,p:impl AsRef<Path>){m.insert(p.as_ref().display().to_string(),hash(&p));}
fn check_pins(file:&str){for(p,h)in read(r(file)).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}}
fn setup(){
 assert_eq!(read(r("native/result.json"))["status"],"complete");check_pins("build-pins.json");assert!(!r("consumer-plan.json").exists());let mut pins: BTreeMap<String,String>=serde_json::from_value(read(r("build-pins.json"))).unwrap();let mut steps=vec![];
 for label in["control","candidate"]{let f=read(r(format!("frozen-{label}.json")));for(p,h)in f["input_pins"].as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pin(&mut pins,p);}pin(&mut pins,r(format!("frozen-{label}.json")));pin(&mut pins,r(format!("frozen-{label}-cargo.jsonl")));
  let sha=fs::read_dir(r(format!("frozen/{label}"))).unwrap().map(|e|e.unwrap().path()).filter(|p|p.file_name().unwrap().to_string_lossy().starts_with("libsha2-")&&p.extension().unwrap()=="rlib").collect::<Vec<_>>();assert_eq!(sha.len(),1);
  steps.push(json!({"kind":"link-sdk","name":label,"artifacts":r(format!("frozen-{label}-cargo.jsonl")),"driver":r("driver.rs"),"additional_sources":[r("perf_support.rs")],"rustc_flags":["--extern",format!("sha2={}",sha[0].display())],"timeout_seconds":600}));
 }
 let mut fixtures=serde_json::Map::new();
 for shape in["1x2","2x2"]{for query in["A","B"]{
  let (fixture,oracle)=if query=="A"{
   let f=Path::new("/home/ubuntu/src/zopro-perf-work/g1-columns176").join(format!("inputs/{shape}.a1q"));let old=Path::new("/home/ubuntu/src/zopro-perf-work/g1-columns176").join(format!("consumers/oracle-{shape}/stdout.log"));assert_eq!(hash(&f),read(&old)["fixture_sha256"]);pin(&mut pins,&old);
   let name=format!("oracle-{shape}-A");steps.push(json!({"kind":"command","name":name,"argv":[r("oracle-a"),f],"timeout_seconds":900}));(f,r(format!("consumers/oracle-{shape}-A/stdout.log")))
  }else{let f=Path::new("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175").join(format!("inputs/{shape}.b2q"));let o=Path::new("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175").join(format!("oracle-fixed-runs/oracle-{shape}/stdout.log"));assert_eq!(hash(&f),read(&o)["fixture_sha256"]);pin(&mut pins,&o);(f,o)};
  pin(&mut pins,&fixture);fixtures.insert(format!("{shape}-{query}"),json!({"shape":shape,"query":query,"fixture":fixture,"fixture_sha256":hash(&fixture),"oracle":oracle,"oracle_reused":query=="B"}));
 }}
 save(r("fixtures.json"),&json!(fixtures));
 for name in["driver.rs","perf_support.rs","oracle-a.rs","oracle-a","oracle-build.log","consumers.rs","consumer-helper","fixtures.json"]{pin(&mut pins,r(name));}
 for e in fs::read_dir("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/oracle-target/release/deps").unwrap(){let p=e.unwrap().path();if p.extension().is_some_and(|e|e=="rlib"||e=="so"){pin(&mut pins,p)}}
 save(r("consumer-pins.json"),&json!(pins));save(r("consumer-plan.json"),&json!({"version":1,"source_pins":r("consumer-pins.json"),"steps":steps}));println!("Prepared4consumer steps:2native complete-query links,2new complete-A oracles; existing B2 oracles reused");
}
fn finish(){
 assert_eq!(read(r("consumers/result.json"))["status"],"complete");check_pins("consumer-pins.json");let mut pins: BTreeMap<String,String>=serde_json::from_value(read(r("consumer-pins.json"))).unwrap();let mut cases=vec![];
 for(_,f)in read(r("fixtures.json")).as_object().unwrap(){let oracle=read(f["oracle"].as_str().unwrap());assert_eq!(oracle["fixture_sha256"],f["fixture_sha256"]);for k in["all_points_on_curve","all_points_in_prime_subgroup","all_scalars_canonical","independent_Arkworks_complete_MSM"]{assert_eq!(oracle[k],true)}pin(&mut pins,f["oracle"].as_str().unwrap());
  for workers in[1,16,32]{let mut c=f.clone();c["name"]=json!(format!("{}-{}-w{workers}",f["shape"].as_str().unwrap(),f["query"].as_str().unwrap()));c["workers"]=json!(workers);c["points"]=oracle["points"].clone();cases.push(c);}
 }
 let mut ids=serde_json::Map::new();for label in["control","candidate"]{let a=read(r(format!("consumers/{label}/artifacts.json")));assert_eq!(hash(a["binary"].as_str().unwrap()),a["binary_sha256"]);for(p,h)in a["input_pins"].as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pin(&mut pins,p);}pin(&mut pins,a["binary"].as_str().unwrap());pin(&mut pins,r(format!("consumers/{label}/artifacts.json")));ids.insert(label.into(),a);}
 save(r("identities.json"),&json!(ids));save(r("cases.json"),&json!(cases));save(r("capture-base-pins.json"),&json!(pins));println!("Full-query consumers/oracles closed;12cases ready,zero proofs,accepted ledger27353 unchanged");
}
fn main(){match std::env::args().nth(1).as_deref(){Some("setup")=>setup(),Some("finish")=>finish(),_=>panic!("setup/finish")}}
