// Same full classifier and admission as scalar_groups_policy, retaining
// its already-built arrays only when the exact population cutoff rejects.
pub(crate) enum Classified{
    Full(ScalarGroups),
    Rejected{values:Vec<[u64;4]>,classes:Vec<u32>,counts:Vec<usize>,charge:crate::preparation::Reservation},
}
pub(crate) fn classify_for_overlay(scalars:&[[u64;4]],zero_aware:bool)->Option<Classified>{
    if scalars.len()<256||scalars.len()>=u32::MAX as usize{return None}
    let(unique,percent)=grouping_sample(scalars,zero_aware)?;
    let reservation=grouping_cost::reserve(scalars.len(),percent)?;
    let capacity=if crate::simd::cpu_option("ZOPRO_CPU_RESERVE_GROUPS"){
        (unique.len()*16).min(scalars.len()*percent/100).min(32768)
    }else{0};
    let mut groups=std::collections::HashMap::with_capacity_and_hasher(capacity,ahash::RandomState::new());
    let mut values=Vec::new();let mut classes=vec![u32::MAX;scalars.len()];let mut counts:Vec<usize>=Vec::new();
    for(scalar,class)in scalars.iter().zip(&mut classes){
        if *scalar==[0;4]{continue}
        let index=*groups.entry(*scalar).or_insert_with(||{values.push(*scalar);counts.push(0);(values.len()-1)as u32});
        *class=index;counts[index as usize]+=1;
    }
    drop(groups);
    if values.len()*100>scalars.len()*percent{return Some(Classified::Rejected{values,classes,counts,charge:reservation})}
    if values.is_empty(){return Some(Classified::Full(ScalarGroups{_reservation:reservation,len:scalars.len(),values,order:Vec::new(),starts:vec![0],counts}))}
    let mut starts=Vec::with_capacity(counts.len()+1);starts.push(0);for &count in &counts{starts.push(starts.last().unwrap()+count)}
    let mut positions=starts[..counts.len()].to_vec();let mut order=vec![0u32;*starts.last().unwrap()];
    for(i,&class)in classes.iter().enumerate(){if class!=u32::MAX{order[positions[class as usize]]=i as u32;positions[class as usize]+=1;}}
    drop(classes);drop(positions);
    Some(Classified::Full(ScalarGroups{_reservation:reservation,len:scalars.len(),values,order,starts,counts}))
}
