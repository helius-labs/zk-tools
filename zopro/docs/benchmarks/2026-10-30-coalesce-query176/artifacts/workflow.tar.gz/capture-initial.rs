use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::{BufRead, BufReader},
    path::{Path, PathBuf},
    process::{Command, Stdio},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/coalesce-query176";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn pin(p: &mut BTreeMap<String, String>, file: impl AsRef<Path>) {
    let f = file.as_ref();
    p.insert(f.display().to_string(), hash(f));
}
fn step(name: &str, argv: Value) -> Value {
    json!({"kind":"command","name":name,"argv":argv,"timeout_seconds":600})
}
include!("sampling.rs");
include!("counter.rs");
fn loss(data: &str) {
    let mut c = Command::new("perf")
        .args(["script", "-D", "-i", data])
        .stdout(Stdio::piped())
        .spawn()
        .unwrap();
    let mut lost = vec![];
    let mut lines = 0;
    for l in BufReader::new(c.stdout.take().unwrap()).lines() {
        let l = l.unwrap();
        lines += 1;
        if l.contains("PERF_RECORD_LOST") {
            lost.push(l);
        }
    }
    assert!(c.wait().unwrap().success());
    println!(
        "{}",
        json!({"zero_lost":lost.is_empty(),"records":lost,"lines":lines})
    );
}
fn add(
    c: &Value,
    label: &str,
    block: usize,
    panel: &str,
    env: &Value,
    ids: &Value,
    jobs: &mut Vec<Value>,
    steps: &mut Vec<Value>,
) {
    let name = if panel == "latency" {
        format!("b{block}-{}-{label}", c["name"].as_str().unwrap())
    } else {
        format!("{panel}-{}-{label}", c["name"].as_str().unwrap())
    };
    let rounds = match panel {
        "preflight" => 1,
        "latency" => 20,
        _ => 200,
    };
    let workers = c["workers"].as_u64().unwrap();
    let affinity = if workers == 1 {
        "2".into()
    } else {
        format!("0-{}", workers - 1)
    };
    let mut environment = env.clone();
    environment["RAYON_NUM_THREADS"] = json!(workers.to_string());
    let mut argv = vec![];
    let mut data = Value::Null;
    if panel == "stat" || panel == "cycles" {
        environment["ZOPRO_BENCH_PERF_CTL"] = json!(r("ctl"));
        environment["ZOPRO_BENCH_PERF_ACK"] = json!(r("ack"));
        argv.extend(["sudo".to_string(), "-n".into(), "env".into()]);
        for (k, v) in environment.as_object().unwrap() {
            argv.push(format!("{k}={}", v.as_str().unwrap()));
        }
        argv.push("perf".into());
        if panel == "stat" {
            let file = r("stat").join(format!("{name}.csv"));
            data = json!(file);
            argv.extend([
                "stat".into(),
                "--no-big-num".into(),
                "-x".into(),
                ";".into(),
                "-e".into(),
                "{cycles:u,instructions:u,cache-misses:u,branch-misses:u}".into(),
                "-o".into(),
                file.display().to_string(),
            ]);
        } else {
            let file = r("perf").join(format!("{name}.data"));
            data = json!(file);
            argv.extend([
                "record".into(),
                "--no-buildid-cache".into(),
                "--sample-cpu".into(),
                "--timestamp".into(),
                "-P".into(),
                "-e".into(),
                "cycles:u".into(),
                "-c".into(),
                "16000000".into(),
                "-m".into(),
                "512".into(),
                "-o".into(),
                file.display().to_string(),
            ]);
        }
        argv.extend([
            "--delay=-1".into(),
            format!(
                "--control=fifo:{},{}",
                r("ctl").display(),
                r("ack").display()
            ),
            "--".into(),
        ]);
    }
    argv.extend([
        "taskset".into(),
        "-c".into(),
        affinity,
        ids[label]["binary"].as_str().unwrap().into(),
        c["query"].as_str().unwrap().into(),
        c["fixture"].as_str().unwrap().into(),
        c["oracle"].as_str().unwrap().into(),
        workers.to_string(),
        rounds.to_string(),
    ]);
    let mut s = step(&name, json!(argv));
    if panel == "latency" || panel == "preflight" {
        s["environment"] = environment;
    }
    steps.push(s);
    jobs.push(json!({"name":name,"case":c,"variant":label,"block":block,"panel":panel,"rounds":rounds,"data":data,"binary":ids[label]["binary"]}));
}
fn prepare() {
    assert!(!r("capture-plan.json").exists());
    assert_eq!(read(r("native/result.json"))["status"], "complete");
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(read(r("capture-base-pins.json"))).unwrap();
    for (p, h) in &pins {
        assert_eq!(hash(p), *h);
    }
    let ids = read(r("identities.json"));
    for label in ["control", "candidate"] {
        assert_eq!(hash(ids[label]["binary"].as_str().unwrap()),ids[label]["binary_sha256"]);
    }
    let mut code=BTreeMap::new();
    for label in ["control","candidate"]{
        let binary=ids[label]["binary"].as_str().unwrap();
        let out=Command::new("nm").args(["-S","--defined-only",binary]).output().unwrap();assert!(out.status.success());
        let raw=String::from_utf8(out.stdout).unwrap();
        let mut decoded=String::new();let mut selected=vec![];let mut dis=Vec::new();
        for line in raw.lines(){let f=line.split_whitespace().collect::<Vec<_>>();if f.len()!=4{continue}let name=rustc_demangle::try_demangle(f[3]).map(|n|format!("{n:#}")).unwrap_or_else(|_|f[3].into());decoded.push_str(&format!("{} {} {} {name}\n",f[0],f[1],f[2]));
            if (name.starts_with("zopro_core::msm_affine::coalesce::")||name.starts_with("zopro_core::msm_affine::grouping::coalesced_classifier::")||name.starts_with("zopro_core::coalesce_query_probe::"))&&!name.contains("{closure")&&!name.contains("::drop"){
                let d=Command::new("objdump").args(["-d","--no-show-raw-insn",&format!("--disassemble={}",f[3]),binary]).output().unwrap();assert!(d.status.success());dis.extend(d.stdout);selected.push(json!({"symbol":name,"mangled":f[3],"address":f[0],"bytes":f[1]}));
            }
        }
        if label=="candidate"{assert!(selected.iter().any(|x|x["symbol"].as_str().unwrap().contains("::prepare")))}
        fs::write(r(format!("{label}.nm")),decoded).unwrap();fs::write(r(format!("{label}.asm")),dis).unwrap();
        code.insert(label,json!({"binary_sha256":hash(binary),"selected":selected,"disassembly_sha256":hash(r(format!("{label}.asm"))),"runtime_route_checks_required":true}));
    }
    save(r("codegen.json"),&json!(code));
    let case_values=read(r("cases.json"));
    let cases=case_values.as_array().unwrap();
    assert_eq!(cases.len(),12);
    let mut env=read(r("build-plan.json"))["steps"][0]["environment"].clone();for k in ["RUSTFLAGS","CARGO_TARGET_DIR","CARGO_BUILD_JOBS"]{env.as_object_mut().unwrap().remove(k);}
    env["RAYON_NUM_THREADS"] = json!("1");
    for dir in ["stat", "perf"] {
        fs::create_dir(r(dir)).unwrap();
    }
    for name in ["ctl", "ack"] {
        assert!(Command::new("mkfifo")
            .arg(r(name))
            .status()
            .unwrap()
            .success());
    }
    let (mut jobs, mut steps) = (vec![], vec![]);
    for c in cases {
        for label in ["control", "candidate"] {
            add(c, label, 0, "preflight", &env, &ids, &mut jobs, &mut steps);
        }
    }
    for b in 0..15 {
        let mut order = (0..12).collect::<Vec<_>>();
        order.rotate_left(b % 12);
        if b % 2 == 1 {
            order.reverse();
        }
        let variants = if b % 2 == 0 {
            ["control", "candidate"]
        } else {
            ["candidate", "control"]
        };
        for i in order {
            for label in variants {
                add(
                    &cases[i], label, b, "latency", &env, &ids, &mut jobs, &mut steps,
                );
            }
        }
    }
    for panel in ["stat", "cycles"] {
      for query in ["A","B"] {
        for workers in [16, 32] {
            let c = cases
                .iter()
                .find(|c| c["shape"] == "1x2" && c["workers"] == workers && c["query"] == query)
                .unwrap();
            for label in ["control", "candidate"] {
                add(c, label, 0, panel, &env, &ids, &mut jobs, &mut steps);
            }
        }
      }
    }
    assert_eq!(jobs.len(),400);for j in jobs.iter().filter(|j|j["panel"]=="cycles"){steps.push(step(&format!("access-{}",j["name"].as_str().unwrap()),json!(["sudo","-n","chown","ubuntu:ubuntu",j["data"]])));}
    for j in jobs.iter().filter(|j| j["panel"] == "cycles") {
        let name = j["name"].as_str().unwrap();
        let file = j["data"].as_str().unwrap();
        for (kind, argv) in [
            ("events", json!(["perf", "evlist", "-v", "-i", file])),
            ("loss", json!([r("capture"), "loss", file])),
            (
                "decode",
                json!([
                    "perf",
                    "script",
                    "--ns",
                    "-i",
                    file,
                    "-F",
                    "pid,tid,cpu,time,period,ip,sym"
                ]),
            ),
            (
                "metadata",
                json!([
                    "perf",
                    "script",
                    "--header",
                    "--show-mmap-events",
                    "--show-task-events",
                    "--ns",
                    "-i",
                    file,
                    "-F",
                    "pid,tid,cpu,time,period,ip,sym"
                ]),
            ),
        ] {
            steps.push(step(&format!("{kind}-{name}"), argv));
        }
    }
    assert_eq!(steps.len(), 440);
    save(r("jobs.json"), &json!(jobs));
    save(r("cases.json"), &json!(cases));
    for n in [
        "capture.rs",
        "capture",
        "capture-design.md",
        "sampling.rs",
        "counter.rs",
        "codegen.json",
        "control.nm",
        "candidate.nm",
        "control.asm",
        "candidate.asm",
        "identities.json",
        "jobs.json",
        "cases.json",
    ] {
        pin(&mut pins, r(n));
    }
    save(r("capture-pins.json"), &json!(pins));
    save(
        r("capture-plan.json"),
        &json!({"version":1,"source_pins":r("capture-pins.json"),"steps":steps}),
    );
    println!("Frozen440steps/400processes;24preflight/360latency/16warmdiagnostics;15fixedblocks;complete weighted A/B queries;no proofs");
}
fn stats(values: &[f64]) -> Value {
    assert_eq!(values.len(), 15);
    let mut sorted = values.to_vec();
    assert!(sorted.iter().all(|&v| v > 0. && v.is_finite()));
    sorted.sort_by(f64::total_cmp);
    json!({"median":sorted[7],"lower":sorted[3],"upper":sorted[11],"wins":values.iter().filter(|&&v|v<1.).count(),"blocks":15,"values":values})
}
fn finish() {
    assert!(!r("analysis.json").exists());
    assert_eq!(read(r("runs/result.json"))["status"], "complete");
    for (p, h) in read(r("capture-pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let jobs = read(r("jobs.json"));
    let mut rows = vec![];
    let mut values = BTreeMap::<(String, String, usize), f64>::new();
    let mut cpu = BTreeMap::<(String, String, usize), f64>::new();
    let mut rss = BTreeMap::<(String, String), f64>::new();
    let mut total_passes = 0u64;
    let mut routes=BTreeMap::<String,Value>::new();
    let mut counters = BTreeMap::new();
    let mut profiles = BTreeMap::new();
    let mut symbols = BTreeMap::new();
    for j in jobs.as_array().unwrap() {
        let n = j["name"].as_str().unwrap();
        let text = fs::read_to_string(r(format!("runs/{n}/stdout.log"))).unwrap();
        let records = text
            .lines()
            .filter_map(|l| l.strip_prefix("CALLER "))
            .collect::<Vec<_>>();
        assert_eq!(records.len(), 1);
        let a: Value = serde_json::from_str(records[0]).unwrap();
        let rounds = j["rounds"].as_u64().unwrap();
        assert_eq!(a["workers"], j["case"]["workers"]);
        assert_eq!(a["input_rows"], j["case"]["points"]);
        assert_eq!(a["rounds"], rounds);
        assert_eq!(a["query"], j["case"]["query"]);
        assert_eq!(a["all_timed_outputs_checked"],true);
        assert_eq!(a["every_output_matches_independent_full_MSM"],true);
        assert_eq!(a["point_inputs_unchanged"],true);
        assert_eq!(a["normalization_inside_timer"],true);
        assert_eq!(a["B_word_reset_inside_timer"],j["case"]["query"]=="B");
        assert_eq!(a["new_proofs"], 0);
        assert_eq!(a["priming_passes"], 3);
        assert_eq!(a["postcheck_passes"], 1);
        assert_eq!(a["samples_ns"].as_array().unwrap().len(),rounds as usize);
        let rk=format!("{}-{}",j["case"]["name"].as_str().unwrap(),j["variant"].as_str().unwrap());
        if let Some(prior)=routes.insert(rk,a["metadata"].clone()){assert_eq!(prior,a["metadata"])}
        let expected=if j["variant"]=="control"{0}else if j["case"]["shape"]=="2x2"{1}else{3};
        assert_eq!(a["metadata"]["route"],expected);
        if expected==3{
            let (classes,skips)=if a["query"]=="A"{(227,583)}else{(325,849)};
            assert_eq!(a["metadata"]["classes"],classes);assert_eq!(a["metadata"]["skips"],skips);
        }
        let allowed=a["worker_rows"].as_array().unwrap().iter().map(|v|v["tid"].as_u64().unwrap()as u32).chain(std::iter::once(a["pid"].as_u64().unwrap()as u32)).collect::<BTreeSet<_>>();
        assert_eq!(allowed.len(),j["case"]["workers"].as_u64().unwrap()as usize+1);
        for wr in a["worker_rows"].as_array().unwrap(){assert_eq!(wr["cpu"].as_u64().unwrap(),if a["workers"]==1{2}else{wr["worker"].as_u64().unwrap()})}
        total_passes += rounds + 4;
        if j["panel"] == "latency" {
            let case = j["case"]["name"].as_str().unwrap();
            let label = j["variant"].as_str().unwrap();
            let b = j["block"].as_u64().unwrap() as usize;
            let ns = a["elapsed_ns"].as_f64().unwrap() / rounds as f64;
            assert_eq!(
                a["ns_per_query"].as_f64().unwrap(),
                ns
            );
            assert!(values.insert((case.into(), label.into(), b), ns).is_none());
            let c = (a["usage"]["user_cpu_ms"].as_f64().unwrap()
                + a["usage"]["system_cpu_ms"].as_f64().unwrap())
                / rounds as f64;
            cpu.insert((case.into(), label.into(), b), c);
            let peak = a["usage"]["whole_process_maxrss_kib"].as_f64().unwrap() / 1024.;
            let e = rss.entry((case.into(), label.into())).or_insert(0.);
            *e = e.max(peak);
        }
        if j["panel"] == "stat" {
            let events = fs::read_to_string(j["data"].as_str().unwrap())
                .unwrap()
                .lines()
                .filter_map(event_line)
                .collect::<BTreeMap<_, _>>();
            let mut per = BTreeMap::new();
            for k in [
                "cycles:u",
                "instructions:u",
                "cache-misses:u",
                "branch-misses:u",
            ] {
                assert!(events.contains_key(k));
                per.insert(k, events[k]["count"].as_f64().map(|v| v / rounds as f64));
            }
            counters.insert(n,json!({"events":events,"per_complete_query":per,"qualified":events.values().all(|v|v["qualified"]==true)}));
        }
        if j["panel"] == "cycles" {
            let attributes = fs::read_to_string(r(format!("runs/events-{n}/stdout.log"))).unwrap();
            for needle in ["cycles:u", "16000000", "CPU", "TIME", "PERIOD"] {
                assert!(attributes.contains(needle));
            }
            assert!(!attributes.contains("freq: 1"));
            assert_eq!(
                read(r(format!("runs/loss-{n}/stdout.log")))["zero_lost"],
                true
            );
            let metadata = fs::read_to_string(r(format!("runs/metadata-{n}/stdout.log"))).unwrap();
            assert!(metadata.contains("PERF_RECORD_FORK"));
            assert!(metadata.contains("PERF_RECORD_COMM"));
            let mut pids = BTreeSet::new();
            let mut tids = BTreeSet::new();
            let mut sym = BTreeMap::<String, (u64, u64)>::new();
            let mut samples = 0u64;
            let mut period = 0u64;
            for (p, t, cpu, weight, name) in
                fs::read_to_string(r(format!("runs/decode-{n}/stdout.log")))
                    .unwrap()
                    .lines()
                    .filter_map(sample)
            {
                assert!(cpu < j["case"]["workers"].as_u64().unwrap() as u32);
                assert!(allowed.contains(&t),"sampled unregistered TID {t}");
                assert_eq!(p,a["pid"].as_u64().unwrap()as u32);
                assert_eq!(weight, 16000000);
                pids.insert(p);
                tids.insert(t);
                samples += 1;
                period += weight;
                let v = sym.entry(name).or_default();
                v.0 += 1;
                v.1 += weight;
            }
            assert_eq!(pids.len(), 1);
            assert!(samples > 0);
            assert!(tids.len() <= j["case"]["workers"].as_u64().unwrap() as usize + 1);
            let pid = *pids.first().unwrap();
            assert!(metadata.lines().any(|l| l.contains("PERF_RECORD_MMAP")
                && l.contains(j["binary"].as_str().unwrap())
                && l.contains(&format!("{pid}/{pid}"))));
            let unknown = sym
                .iter()
                .filter(|(n, _)| n.starts_with("[unknown]"))
                .map(|(_, (_, p))| *p)
                .sum::<u64>() as f64
                / period as f64;
            let mut sorted=sym.iter().map(|(n,(s,p))|json!({"symbol":n,"samples":s,"period":p,"share":*p as f64/period as f64})).collect::<Vec<_>>();
            sorted.sort_by(|a, b| b["period"].as_u64().cmp(&a["period"].as_u64()));
            symbols.insert(n, sorted);
            profiles.insert(n,json!({"samples":samples,"sampled_period":period,"PID":pid,"sampled_TIDs":tids,"unknown_share":unknown,"zero_lost":true,"binary_MMAP_PID_matches":true,"affinity_bounds_pass":true,"period16M":true,"small_sample_context":samples<1000,"absolute_period_coverage_not_validated":true}));
        }
        rows.push(
            json!({"job":j,"receipt":a,"stdout_sha256":hash(r(format!("runs/{n}/stdout.log")))}),
        );
    }
    let mut cases = BTreeMap::new();
    let mut primary = vec![0f64; 15];
    let mut all_contexts = true;
    for c in read(r("cases.json")).as_array().unwrap() {
        let name = c["name"].as_str().unwrap();
        let get = |map: &BTreeMap<(String, String, usize), f64>, label: &str| {
            (0..15)
                .map(|b| map[&(name.into(), label.into(), b)])
                .collect::<Vec<_>>()
        };
        let off = get(&values, "control");
        let on = get(&values, "candidate");
        let ratio = on.iter().zip(&off).map(|(a, b)| a / b).collect::<Vec<_>>();
        if c["workers"] == 32 && c["shape"]=="1x2" {
            for (b, x) in ratio.iter().enumerate() {
                primary[b] += x.ln() / 2.;
            }
        }
        let pair = stats(&ratio);
        all_contexts &= pair["upper"].as_f64().unwrap() <= 1.03;
        cases.insert(name.to_string(),json!({"control_ns":stats(&off),"candidate_ns":stats(&on),"candidate_over_control":pair,"control_CPU_ms":stats(&get(&cpu,"control")),"candidate_CPU_ms":stats(&get(&cpu,"candidate")),"control_max_process_RSS_MiB":rss[&(name.into(),"control".into())],"candidate_max_process_RSS_MiB":rss[&(name.into(),"candidate".into())]}));
    }
    let primary = stats(&primary.iter().map(|v| v.exp()).collect::<Vec<_>>());
    let gate = primary["upper"].as_f64().unwrap() < 1.
        && primary["wins"].as_u64().unwrap() >= 10
        && all_contexts;
    assert_eq!(rows.len(), 400);
    assert_eq!(total_passes, 12024);
    save(r("symbols.json"), &json!(symbols));
    save(
        r("analysis.json"),
        &json!({"cases":cases,"primary_equal_log_32":primary,"all_context_upper_le_1_03":all_contexts,"caller_gate_passed":gate,"counters":counters,"profiles":profiles,"routes":routes,"workflow_steps":440,"caller_processes":400,"complete_query_passes_including_primes_and_checks":total_passes,"all_query_outputs_checked_against_independent_oracle":true,"new_proofs":0,"verified_ledger_unchanged":27353,"rows":rows}),
    );
    println!("Complete-query gate={gate};400processes/12024checkedqueries;0proofs");
}
fn main() {
    let a = std::env::args().collect::<Vec<_>>();
    match a.get(1).map(String::as_str) {
        Some("prepare") => prepare(),
        Some("finish") => finish(),
        Some("loss") => loss(&a[2]),
        _ => panic!("prepare/finish/loss"),
    }
}
