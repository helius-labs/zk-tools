#[cfg(all(zopro_coalesce_probe,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
pub mod coalesce_query_probe{
    use zopro_bn254::{G1Affine,G2Affine,G1Projective,G2Projective};
    #[derive(Clone,Copy,Debug,Default,PartialEq,Eq)]
    pub struct Metadata{pub route:u32,pub classes:usize,pub skips:usize,pub payload:usize}
    pub fn a(bases:&[G1Affine],words:&[[u64;4]])->(G1Projective,Metadata){
        #[cfg(zopro_coalesce_query)]{let(p,s)=crate::msm_affine::coalesce::a_query(bases,words,true);return(p,Metadata{route:s.route,classes:s.classes,skips:s.skips,payload:s.payload})}
        #[cfg(not(zopro_coalesce_query))]{(crate::msm_affine::msm_canonical(bases,words),Metadata::default())}
    }
    pub fn b(bases:&[G2Affine],words:&mut[[u64;4]])->(G2Projective,Metadata){
        #[cfg(zopro_coalesce_query)]{let(p,s)=crate::msm_affine::coalesce::b_query(bases,words,true);return(p,Metadata{route:s.route,classes:s.classes,skips:s.skips,payload:s.payload})}
        #[cfg(not(zopro_coalesce_query))]{(crate::msm_affine::g2_query_exclusive(bases,words),Metadata::default())}
    }
}
