
/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001a5d40 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a>:
  1a5d40:	push   %rbx
  1a5d41:	mov    %rdi,%rbx
  1a5d44:	call   bd600 <_RINvNtCsHW5vo2gROj_10zopro_core10msm_affine13msm_canonicalNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEB4_>
  1a5d49:	vxorps %xmm0,%xmm0,%xmm0
  1a5d4d:	vmovups %xmm0,0x6c(%rbx)
  1a5d52:	vmovups %xmm0,0x60(%rbx)
  1a5d57:	mov    %rbx,%rax
  1a5d5a:	pop    %rbx
  1a5d5b:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:

/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001a5d60 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b>:
  1a5d60:	push   %rbx
  1a5d61:	mov    %rdi,%rbx
  1a5d64:	call   1a2b10 <_RNvNtCsHW5vo2gROj_10zopro_core10msm_affine18g2_query_exclusive>
  1a5d69:	vxorps %xmm0,%xmm0,%xmm0
  1a5d6d:	vmovups %xmm0,0xcc(%rbx)
  1a5d75:	vmovups %xmm0,0xc0(%rbx)
  1a5d7d:	mov    %rbx,%rax
  1a5d80:	pop    %rbx
  1a5d81:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
