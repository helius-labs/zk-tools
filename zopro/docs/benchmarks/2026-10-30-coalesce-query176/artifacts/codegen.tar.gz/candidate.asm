
/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001bb470 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a>:
  1bb470:	push   %rbp
  1bb471:	push   %r15
  1bb473:	push   %r14
  1bb475:	push   %r13
  1bb477:	push   %r12
  1bb479:	push   %rbx
  1bb47a:	sub    $0xb48,%rsp
  1bb481:	mov    %rdx,0x2a0(%rsp)
  1bb489:	mov    %r8,0x340(%rsp)
  1bb491:	cmp    %r8,%rdx
  1bb494:	jne    1bbda7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x937>
  1bb49a:	mov    %rcx,%r12
  1bb49d:	mov    %rdx,%r14
  1bb4a0:	mov    %rsi,%r13
  1bb4a3:	mov    %rdi,%rbx
  1bb4a6:	lea    -0x17ce72(%rip),%rsi        # 3e63b <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5c93>
  1bb4ad:	lea    0x340(%rsp),%rdi
  1bb4b5:	mov    $0x1a,%edx
  1bb4ba:	call   *0x9aa50(%rip)        # 255f10 <_DYNAMIC+0x2d8>
  1bb4c0:	cmpl   $0x1,0x340(%rsp)
  1bb4c8:	jne    1bb4ec <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x7c>
  1bb4ca:	mov    0x348(%rsp),%rsi
  1bb4d2:	test   %rsi,%rsi
  1bb4d5:	jle    1bb531 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xc1>
  1bb4d7:	mov    0x350(%rsp),%rdi
  1bb4df:	mov    $0x1,%edx
  1bb4e4:	call   *0x9a94e(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bb4ea:	jmp    1bb531 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xc1>
  1bb4ec:	mov    0x348(%rsp),%rsi
  1bb4f4:	cmp    $0xffffffffffffffff,%rsi
  1bb4f8:	je     1bb531 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xc1>
  1bb4fa:	mov    0x350(%rsp),%rdi
  1bb502:	mov    0x358(%rsp),%rcx
  1bb50a:	mov    %r13,%r15
  1bb50d:	test   %rcx,%rcx
  1bb510:	je     1bb538 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xc8>
  1bb512:	cmp    $0x1,%rcx
  1bb516:	jne    1bb548 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xd8>
  1bb518:	movzbl (%rdi),%eax
  1bb51b:	xor    %ebp,%ebp
  1bb51d:	cmp    $0x2b,%eax
  1bb520:	je     1bb602 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x192>
  1bb526:	cmp    $0x2d,%eax
  1bb529:	je     1bb602 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x192>
  1bb52f:	jmp    1bb54b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xdb>
  1bb531:	xor    %ebp,%ebp
  1bb533:	jmp    1bb61f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1af>
  1bb538:	xor    %ebp,%ebp
  1bb53a:	test   %rsi,%rsi
  1bb53d:	jne    1bb607 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x197>
  1bb543:	jmp    1bb612 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1a2>
  1bb548:	movzbl (%rdi),%eax
  1bb54b:	xor    %r8d,%r8d
  1bb54e:	cmp    $0x2b,%al
  1bb550:	mov    %rcx,%rdx
  1bb553:	sete   %r8b
  1bb557:	mov    %r8,%rax
  1bb55a:	sub    %r8,%rdx
  1bb55d:	neg    %rax
  1bb560:	add    %rdi,%r8
  1bb563:	cmp    $0x11,%rdx
  1bb567:	jae    1bb5a9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x139>
  1bb569:	test   %rdx,%rdx
  1bb56c:	je     1bb5f5 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x185>
  1bb572:	add    %rax,%rcx
  1bb575:	xor    %r13d,%r13d
  1bb578:	xor    %eax,%eax
  1bb57a:	neg    %rcx
  1bb57d:	nopl   (%rax)
  1bb580:	movzbl (%r8,%rax,1),%edx
  1bb585:	add    $0xffffffd0,%edx
  1bb588:	cmp    $0xa,%edx
  1bb58b:	setb   %bpl
  1bb58f:	jae    1bb602 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x192>
  1bb591:	lea    0x0(%r13,%r13,4),%r9
  1bb596:	mov    %edx,%edx
  1bb598:	inc    %rax
  1bb59b:	lea    (%rdx,%r9,2),%r13
  1bb59f:	mov    %rcx,%rdx
  1bb5a2:	add    %rax,%rdx
  1bb5a5:	jne    1bb580 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x110>
  1bb5a7:	jmp    1bb602 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x192>
  1bb5a9:	add    %rax,%rcx
  1bb5ac:	mov    $0xa,%r9d
  1bb5b2:	xor    %r13d,%r13d
  1bb5b5:	xor    %r10d,%r10d
  1bb5b8:	neg    %rcx
  1bb5bb:	mov    %rcx,%rax
  1bb5be:	add    %r10,%rax
  1bb5c1:	sete   %bpl
  1bb5c5:	je     1bb602 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x192>
  1bb5c7:	mov    %r13,%rax
  1bb5ca:	mul    %r9
  1bb5cd:	jo     1bb5ee <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x17e>
  1bb5cf:	movzbl (%r8,%r10,1),%edx
  1bb5d4:	mov    %rax,%r13
  1bb5d7:	add    $0xffffffd0,%edx
  1bb5da:	add    %rdx,%r13
  1bb5dd:	setb   %al
  1bb5e0:	cmp    $0x9,%edx
  1bb5e3:	ja     1bb5ee <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x17e>
  1bb5e5:	inc    %r10
  1bb5e8:	test   %al,%al
  1bb5ea:	je     1bb5bb <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x14b>
  1bb5ec:	jmp    1bb602 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x192>
  1bb5ee:	test   %rsi,%rsi
  1bb5f1:	jne    1bb607 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x197>
  1bb5f3:	jmp    1bb612 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1a2>
  1bb5f5:	mov    $0x1,%bpl
  1bb5f8:	xor    %r13d,%r13d
  1bb5fb:	test   %rsi,%rsi
  1bb5fe:	jne    1bb607 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x197>
  1bb600:	jmp    1bb612 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1a2>
  1bb602:	test   %rsi,%rsi
  1bb605:	je     1bb612 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1a2>
  1bb607:	mov    $0x1,%edx
  1bb60c:	call   *0x9a826(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bb612:	cmp    $0xc,%r13
  1bb616:	mov    %r15,%r13
  1bb619:	sete   %al
  1bb61c:	and    %al,%bpl
  1bb61f:	lea    -0x17cfd1(%rip),%rsi        # 3e655 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5cad>
  1bb626:	lea    0x340(%rsp),%rdi
  1bb62e:	mov    $0x1a,%edx
  1bb633:	call   *0x9a8d7(%rip)        # 255f10 <_DYNAMIC+0x2d8>
  1bb639:	cmpl   $0x1,0x340(%rsp)
  1bb641:	jne    1bb66c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1fc>
  1bb643:	mov    0x348(%rsp),%rsi
  1bb64b:	test   %rsi,%rsi
  1bb64e:	jle    1bb851 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3e1>
  1bb654:	mov    0x350(%rsp),%rdi
  1bb65c:	mov    $0x1,%edx
  1bb661:	call   *0x9a7d1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bb667:	jmp    1bb851 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3e1>
  1bb66c:	mov    0x348(%rsp),%rsi
  1bb674:	cmp    $0xffffffffffffffff,%rsi
  1bb678:	je     1bb851 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3e1>
  1bb67e:	mov    0x350(%rsp),%rdi
  1bb686:	mov    0x358(%rsp),%rcx
  1bb68e:	mov    %r12,0x20(%rsp)
  1bb693:	mov    %r13,%r12
  1bb696:	test   %rcx,%rcx
  1bb699:	je     1bb6bb <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x24b>
  1bb69b:	cmp    $0x1,%rcx
  1bb69f:	jne    1bb6cc <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x25c>
  1bb6a1:	movzbl (%rdi),%eax
  1bb6a4:	xor    %r15d,%r15d
  1bb6a7:	cmp    $0x2b,%eax
  1bb6aa:	je     1bb792 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x322>
  1bb6b0:	cmp    $0x2d,%eax
  1bb6b3:	je     1bb792 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x322>
  1bb6b9:	jmp    1bb6cf <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x25f>
  1bb6bb:	xor    %r15d,%r15d
  1bb6be:	test   %rsi,%rsi
  1bb6c1:	jne    1bb797 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x327>
  1bb6c7:	jmp    1bb7a2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x332>
  1bb6cc:	movzbl (%rdi),%eax
  1bb6cf:	xor    %r8d,%r8d
  1bb6d2:	cmp    $0x2b,%al
  1bb6d4:	mov    %rcx,%rdx
  1bb6d7:	sete   %r8b
  1bb6db:	mov    %r8,%rax
  1bb6de:	sub    %r8,%rdx
  1bb6e1:	neg    %rax
  1bb6e4:	add    %rdi,%r8
  1bb6e7:	cmp    $0x11,%rdx
  1bb6eb:	jae    1bb739 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2c9>
  1bb6ed:	test   %rdx,%rdx
  1bb6f0:	je     1bb785 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x315>
  1bb6f6:	add    %rax,%rcx
  1bb6f9:	xor    %r13d,%r13d
  1bb6fc:	xor    %eax,%eax
  1bb6fe:	neg    %rcx
  1bb701:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bb710:	movzbl (%r8,%rax,1),%edx
  1bb715:	add    $0xffffffd0,%edx
  1bb718:	cmp    $0xa,%edx
  1bb71b:	setb   %r15b
  1bb71f:	jae    1bb792 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x322>
  1bb721:	lea    0x0(%r13,%r13,4),%r9
  1bb726:	mov    %edx,%edx
  1bb728:	inc    %rax
  1bb72b:	lea    (%rdx,%r9,2),%r13
  1bb72f:	mov    %rcx,%rdx
  1bb732:	add    %rax,%rdx
  1bb735:	jne    1bb710 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2a0>
  1bb737:	jmp    1bb792 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x322>
  1bb739:	add    %rax,%rcx
  1bb73c:	mov    $0xa,%r9d
  1bb742:	xor    %r13d,%r13d
  1bb745:	xor    %r10d,%r10d
  1bb748:	neg    %rcx
  1bb74b:	mov    %rcx,%rax
  1bb74e:	add    %r10,%rax
  1bb751:	sete   %r15b
  1bb755:	je     1bb792 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x322>
  1bb757:	mov    %r13,%rax
  1bb75a:	mul    %r9
  1bb75d:	jo     1bb77e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x30e>
  1bb75f:	movzbl (%r8,%r10,1),%edx
  1bb764:	mov    %rax,%r13
  1bb767:	add    $0xffffffd0,%edx
  1bb76a:	add    %rdx,%r13
  1bb76d:	setb   %al
  1bb770:	cmp    $0x9,%edx
  1bb773:	ja     1bb77e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x30e>
  1bb775:	inc    %r10
  1bb778:	test   %al,%al
  1bb77a:	je     1bb74b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2db>
  1bb77c:	jmp    1bb792 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x322>
  1bb77e:	test   %rsi,%rsi
  1bb781:	jne    1bb797 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x327>
  1bb783:	jmp    1bb7a2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x332>
  1bb785:	mov    $0x1,%r15b
  1bb788:	xor    %r13d,%r13d
  1bb78b:	test   %rsi,%rsi
  1bb78e:	jne    1bb797 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x327>
  1bb790:	jmp    1bb7a2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x332>
  1bb792:	test   %rsi,%rsi
  1bb795:	je     1bb7a2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x332>
  1bb797:	mov    $0x1,%edx
  1bb79c:	call   *0x9a696(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bb7a2:	cmp    $0x2,%r13
  1bb7a6:	mov    %r12,%r13
  1bb7a9:	mov    0x20(%rsp),%r12
  1bb7ae:	lea    -0x400(%r14),%rcx
  1bb7b5:	setb   %al
  1bb7b8:	cmp    $0xfbff,%rcx
  1bb7bf:	ja     1bb851 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3e1>
  1bb7c5:	and    %al,%r15b
  1bb7c8:	and    %r15b,%bpl
  1bb7cb:	je     1bb851 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3e1>
  1bb7d1:	call   1c2fd0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7enabled>
  1bb7d6:	test   %al,%al
  1bb7d8:	je     1bb851 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3e1>
  1bb7da:	lea    -0x17d39d(%rip),%rsi        # 3e444 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5a9c>
  1bb7e1:	lea    0x340(%rsp),%rdi
  1bb7e9:	mov    $0x12,%edx
  1bb7ee:	call   *0x9a71c(%rip)        # 255f10 <_DYNAMIC+0x2d8>
  1bb7f4:	mov    0x348(%rsp),%rsi
  1bb7fc:	mov    0x350(%rsp),%rdi
  1bb804:	cmpb   $0x0,0x340(%rsp)
  1bb80c:	je     1bb823 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3b3>
  1bb80e:	cmp    $0xfffffffffffffffe,%rsi
  1bb812:	jne    1bb8df <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x46f>
  1bb818:	test   $0x1,%dil
  1bb81c:	je     1bb851 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3e1>
  1bb81e:	jmp    1bb8f4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x484>
  1bb823:	cmpq   $0x1,0x358(%rsp)
  1bb82c:	mov    $0x1,%bpl
  1bb82f:	jne    1bb838 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3c8>
  1bb831:	cmpb   $0x30,(%rdi)
  1bb834:	setne  %bpl
  1bb838:	test   %rsi,%rsi
  1bb83b:	je     1bb848 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x3d8>
  1bb83d:	mov    $0x1,%edx
  1bb842:	call   *0x9a5f0(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bb848:	test   %bpl,%bpl
  1bb84b:	jne    1bb8f4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x484>
  1bb851:	lea    0x340(%rsp),%rdi
  1bb859:	mov    %r13,%rsi
  1bb85c:	mov    %r14,%rdx
  1bb85f:	mov    %r12,%rcx
  1bb862:	mov    %r14,%r8
  1bb865:	call   c38f0 <_RINvNtCsHW5vo2gROj_10zopro_core10msm_affine13msm_canonicalNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEB4_>
  1bb86a:	vpxor  %xmm0,%xmm0,%xmm0
  1bb86e:	vmovdqu %xmm0,0x3ac(%rsp)
  1bb877:	vmovdqa %xmm0,0x3a0(%rsp)
  1bb880:	vmovups 0x360(%rsp),%zmm1
  1bb88b:	vmovups 0x340(%rsp),%zmm0
  1bb893:	mov    0x3b8(%rsp),%eax
  1bb89a:	mov    0x3b0(%rsp),%rcx
  1bb8a2:	vmovups %zmm1,0x20(%rbx)
  1bb8ac:	vmovaps 0x3a0(%rsp),%xmm1
  1bb8b5:	vmovups %zmm0,(%rbx)
  1bb8bb:	vmovups %xmm1,0x60(%rbx)
  1bb8c0:	mov    %rcx,0x70(%rbx)
  1bb8c4:	mov    %eax,0x78(%rbx)
  1bb8c7:	mov    %rbx,%rax
  1bb8ca:	add    $0xb48,%rsp
  1bb8d1:	pop    %rbx
  1bb8d2:	pop    %r12
  1bb8d4:	pop    %r13
  1bb8d6:	pop    %r14
  1bb8d8:	pop    %r15
  1bb8da:	pop    %rbp
  1bb8db:	vzeroupper
  1bb8de:	ret
  1bb8df:	lea    -0x1(%rsi),%rax
  1bb8e3:	cmp    $0xfffffffffffffffc,%rax
  1bb8e7:	ja     1bb8f4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x484>
  1bb8e9:	mov    $0x1,%edx
  1bb8ee:	call   *0x9a544(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bb8f4:	lea    0x220(%rsp),%rdi
  1bb8fc:	mov    %r12,%rsi
  1bb8ff:	mov    %r14,%rdx
  1bb902:	call   1c4b70 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified>
  1bb907:	mov    0x220(%rsp),%rax
  1bb90f:	cmp    $0xfffffffffffffffe,%rax
  1bb913:	je     1bbc8b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x81b>
  1bb919:	cmp    $0xffffffffffffffff,%rax
  1bb91d:	jne    1bba18 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x5a8>
  1bb923:	mov    0x230(%rsp),%rcx
  1bb92b:	mov    0x240(%rsp),%rdx
  1bb933:	mov    0x228(%rsp),%rax
  1bb93b:	mov    0x238(%rsp),%rdi
  1bb943:	mov    0x268(%rsp),%rsi
  1bb94b:	mov    %r13,0x40(%rsp)
  1bb950:	mov    %r14,0x2a8(%rsp)
  1bb958:	mov    %rcx,0x1e0(%rsp)
  1bb960:	mov    0x248(%rsp),%rcx
  1bb968:	mov    %rdx,0x60(%rsp)
  1bb96d:	mov    0x250(%rsp),%rdx
  1bb975:	mov    %rax,0x38(%rsp)
  1bb97a:	mov    %rcx,0x58(%rsp)
  1bb97f:	mov    0x258(%rsp),%rcx
  1bb987:	mov    %rdx,0x340(%rsp)
  1bb98f:	mov    %rcx,0xa0(%rsp)
  1bb997:	mov    0x260(%rsp),%rcx
  1bb99f:	mov    %rcx,0x30(%rsp)
  1bb9a4:	mov    0x270(%rsp),%rcx
  1bb9ac:	mov    %rcx,0x150(%rsp)
  1bb9b4:	mov    0x278(%rsp),%rcx
  1bb9bc:	mov    %rcx,0x158(%rsp)
  1bb9c4:	cmp    %r14,%rdx
  1bb9c7:	jne    1bc104 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xc94>
  1bb9cd:	lea    0x0(,%rsi,8),%rax
  1bb9d5:	movabs $0x2000000000000000,%r15
  1bb9df:	xor    %r13d,%r13d
  1bb9e2:	xor    %ecx,%ecx
  1bb9e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bb9f0:	cmp    %rcx,%rax
  1bb9f3:	je     1bbb76 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x706>
  1bb9f9:	mov    0x30(%rsp),%rdx
  1bb9fe:	mov    (%rdx,%rcx,1),%rdx
  1bba02:	cmp    $0x1,%rdx
  1bba06:	adc    $0xffffffffffffffff,%rdx
  1bba0a:	add    $0x8,%rcx
  1bba0e:	add    %rdx,%r13
  1bba11:	jae    1bb9f0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x580>
  1bba13:	jmp    1bbbf7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x787>
  1bba18:	vmovups 0x258(%rsp),%zmm1
  1bba23:	vmovups 0x220(%rsp),%zmm0
  1bba2e:	vmovups %zmm1,0x198(%rsp)
  1bba39:	vmovups %zmm0,0x160(%rsp)
  1bba44:	lea    0x2b0(%rsp),%rdi
  1bba4c:	lea    0x160(%rsp),%rcx
  1bba54:	mov    %r13,%rsi
  1bba57:	mov    %r14,%rdx
  1bba5a:	vzeroupper
  1bba5d:	call   c3730 <_RINvNtCsHW5vo2gROj_10zopro_core10msm_affine11msm_groupedNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEB4_>
  1bba62:	vmovdqu64 0x2d0(%rsp),%zmm1
  1bba6d:	vmovdqu64 0x2b0(%rsp),%zmm0
  1bba78:	mov    0x160(%rsp),%rsi
  1bba80:	vmovdqu64 %zmm1,0x360(%rsp)
  1bba8b:	vmovdqu64 %zmm0,0x340(%rsp)
  1bba93:	vpxor  %xmm0,%xmm0,%xmm0
  1bba97:	vmovdqa %xmm0,0x3a0(%rsp)
  1bbaa0:	movq   $0x0,0x3b0(%rsp)
  1bbaac:	movl   $0x1,0x3b8(%rsp)
  1bbab7:	test   %rsi,%rsi
  1bbaba:	je     1bbad6 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x666>
  1bbabc:	mov    0x168(%rsp),%rdi
  1bbac4:	shl    $0x5,%rsi
  1bbac8:	mov    $0x8,%edx
  1bbacd:	vzeroupper
  1bbad0:	call   *0x9a362(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbad6:	mov    0x178(%rsp),%rsi
  1bbade:	test   %rsi,%rsi
  1bbae1:	je     1bbafd <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x68d>
  1bbae3:	mov    0x180(%rsp),%rdi
  1bbaeb:	shl    $0x2,%rsi
  1bbaef:	mov    $0x4,%edx
  1bbaf4:	vzeroupper
  1bbaf7:	call   *0x9a33b(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbafd:	mov    0x190(%rsp),%rsi
  1bbb05:	test   %rsi,%rsi
  1bbb08:	je     1bbb24 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x6b4>
  1bbb0a:	mov    0x198(%rsp),%rdi
  1bbb12:	shl    $0x3,%rsi
  1bbb16:	mov    $0x8,%edx
  1bbb1b:	vzeroupper
  1bbb1e:	call   *0x9a314(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbb24:	mov    0x1a8(%rsp),%rsi
  1bbb2c:	test   %rsi,%rsi
  1bbb2f:	je     1bbb4b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x6db>
  1bbb31:	mov    0x1b0(%rsp),%rdi
  1bbb39:	shl    $0x3,%rsi
  1bbb3d:	mov    $0x8,%edx
  1bbb42:	vzeroupper
  1bbb45:	call   *0x9a2ed(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbb4b:	mov    0x1c8(%rsp),%rax
  1bbb53:	mov    0x1d0(%rsp),%rcx
  1bbb5b:	mov    0x9a816(%rip),%rdx        # 256378 <_DYNAMIC+0x740>
  1bbb62:	lock sub %rax,(%rdx)
  1bbb66:	mov    0x9a813(%rip),%rdx        # 256380 <_DYNAMIC+0x748>
  1bbb6d:	lock sub %rcx,(%rdx)
  1bbb71:	jmp    1bb880 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x410>
  1bbb76:	test   %r13,%r13
  1bbb79:	je     1bbbf7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x787>
  1bbb7b:	lea    0x0(%r13,%r13,1),%rbp
  1bbb80:	mov    %rdi,0xf8(%rsp)
  1bbb88:	mov    %rsi,0x28(%rsp)
  1bbb8d:	test   %r13,%r13
  1bbb90:	js     1bbbda <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x76a>
  1bbb92:	call   *0x9a910(%rip)        # 2564a8 <_DYNAMIC+0x870>
  1bbb98:	cmp    $0x1,%rax
  1bbb9c:	movabs $0x3ffffffffffffff0,%rcx
  1bbba6:	adc    $0x0,%rax
  1bbbaa:	lea    0xf(%rcx),%rdx
  1bbbae:	cmp    %rdx,%rbp
  1bbbb1:	ja     1bbbda <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x76a>
  1bbbb3:	cmp    %rcx,%rbp
  1bbbb6:	lea    -0x1(%r15),%rdx
  1bbbba:	setb   %cl
  1bbbbd:	cmp    %rdx,%r13
  1bbbc0:	setb   %dl
  1bbbc3:	add    $0xfffffffffffffff7,%r15
  1bbbc7:	and    %cl,%dl
  1bbbc9:	cmp    %r15,%r13
  1bbbcc:	setb   %cl
  1bbbcf:	and    %dl,%cl
  1bbbd1:	cmp    $0x1,%cl
  1bbbd4:	je     1bbcd0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x860>
  1bbbda:	xor    %esi,%esi
  1bbbdc:	lea    0x340(%rsp),%rdi
  1bbbe4:	call   17a230 <_RNvMNtCsHW5vo2gROj_10zopro_core11preparationNtB2_11Reservation8analysis>
  1bbbe9:	cmpb   $0x0,0x340(%rsp)
  1bbbf1:	jne    1bbdc8 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x958>
  1bbbf7:	mov    0x9a77a(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1bbbfe:	mov    0x150(%rsp),%rcx
  1bbc06:	lock sub %rcx,(%rax)
  1bbc0a:	mov    0x9a76f(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1bbc11:	mov    0x158(%rsp),%rcx
  1bbc19:	lock sub %rcx,(%rax)
  1bbc1d:	mov    0xa0(%rsp),%rsi
  1bbc25:	test   %rsi,%rsi
  1bbc28:	je     1bbc41 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x7d1>
  1bbc2a:	shl    $0x3,%rsi
  1bbc2e:	mov    0x30(%rsp),%rdi
  1bbc33:	mov    $0x8,%edx
  1bbc38:	vzeroupper
  1bbc3b:	call   *0x9a1f7(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbc41:	mov    0x60(%rsp),%rsi
  1bbc46:	mov    0x40(%rsp),%r13
  1bbc4b:	test   %rsi,%rsi
  1bbc4e:	je     1bbc67 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x7f7>
  1bbc50:	shl    $0x2,%rsi
  1bbc54:	mov    0x58(%rsp),%rdi
  1bbc59:	mov    $0x4,%edx
  1bbc5e:	vzeroupper
  1bbc61:	call   *0x9a1d1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbc67:	mov    0x38(%rsp),%rsi
  1bbc6c:	test   %rsi,%rsi
  1bbc6f:	je     1bbc8b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x81b>
  1bbc71:	shl    $0x5,%rsi
  1bbc75:	mov    0x1e0(%rsp),%rdi
  1bbc7d:	mov    $0x8,%edx
  1bbc82:	vzeroupper
  1bbc85:	call   *0x9a1ad(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbc8b:	lea    0x340(%rsp),%rdi
  1bbc93:	mov    %r13,%rsi
  1bbc96:	mov    %r14,%rdx
  1bbc99:	mov    %r12,%rcx
  1bbc9c:	mov    %r14,%r8
  1bbc9f:	vzeroupper
  1bbca2:	call   c56b0 <_RINvNtCsHW5vo2gROj_10zopro_core10msm_affine7msm_rawNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEB4_>
  1bbca7:	vpxor  %xmm0,%xmm0,%xmm0
  1bbcab:	vmovdqa %xmm0,0x3a0(%rsp)
  1bbcb4:	movq   $0x0,0x3b0(%rsp)
  1bbcc0:	movl   $0x2,0x3b8(%rsp)
  1bbccb:	jmp    1bb880 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x410>
  1bbcd0:	cmp    $0x200,%r13
  1bbcd7:	mov    $0x200,%edi
  1bbcdc:	mov    %r13,%rcx
  1bbcdf:	cmovb  %r13,%rdi
  1bbce3:	shr    $0x3a,%rcx
  1bbce7:	jne    1bbbda <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x76a>
  1bbced:	movabs $0x3ffffffffffffff,%rcx
  1bbcf7:	cmp    %rcx,%r13
  1bbcfa:	je     1bbbda <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x76a>
  1bbd00:	movabs $0x38e38e38e38e38d,%rcx
  1bbd0a:	cmp    %rcx,%r13
  1bbd0d:	ja     1bbbda <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x76a>
  1bbd13:	mov    $0xac,%ecx
  1bbd18:	mov    %rax,%rsi
  1bbd1b:	mov    %rbp,%rax
  1bbd1e:	mul    %rcx
  1bbd21:	jo     1bbbda <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x76a>
  1bbd27:	mov    $0xf8,%edx
  1bbd2c:	mov    %rax,%rcx
  1bbd2f:	mov    %rsi,%rax
  1bbd32:	mul    %rdx
  1bbd35:	jo     1bbbda <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x76a>
  1bbd3b:	mov    %rax,%rsi
  1bbd3e:	add    %rcx,%rsi
  1bbd41:	jb     1bbbda <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x76a>
  1bbd47:	lea    0x40(,%r13,4),%rcx
  1bbd4f:	lea    0x0(%r13,%r13,2),%rax
  1bbd54:	lea    0xc8(%rcx,%rax,8),%rax
  1bbd5c:	add    %rcx,%rax
  1bbd5f:	jb     1bbd9b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x92b>
  1bbd61:	mov    %edi,%ecx
  1bbd63:	lea    0x40(,%rcx,8),%rcx
  1bbd6b:	add    %rax,%rcx
  1bbd6e:	jb     1bbd9b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x92b>
  1bbd70:	mov    %r13,%rax
  1bbd73:	shl    $0x6,%rax
  1bbd77:	add    $0x40,%rax
  1bbd7b:	add    %rcx,%rax
  1bbd7e:	jb     1bbd9b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x92b>
  1bbd80:	lea    0x0(%r13,%r13,8),%rcx
  1bbd85:	lea    0x40(,%rcx,8),%rcx
  1bbd8d:	add    %rax,%rcx
  1bbd90:	jb     1bbd9b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x92b>
  1bbd92:	add    %rcx,%rsi
  1bbd95:	jae    1bcde2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1972>
  1bbd9b:	xor    %esi,%esi
  1bbd9d:	mov    0x20(%rsp),%r12
  1bbda2:	jmp    1bbbdc <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x76c>
  1bbda7:	lea    0x97092(%rip),%r9        # 252e40 <__frame_dummy_init_array_entry+0x3b60>
  1bbdae:	lea    0x2a0(%rsp),%rsi
  1bbdb6:	lea    0x340(%rsp),%rdx
  1bbdbe:	xor    %edi,%edi
  1bbdc0:	xor    %ecx,%ecx
  1bbdc2:	call   *0x9a340(%rip)        # 256108 <_DYNAMIC+0x4d0>
  1bbdc8:	mov    0x350(%rsp),%rax
  1bbdd0:	mov    0x348(%rsp),%rbp
  1bbdd8:	cmp    $0x200,%r13
  1bbddf:	mov    $0x200,%r15d
  1bbde5:	movq   $0x0,0x1f8(%rsp)
  1bbdf1:	cmovb  %r13,%r15
  1bbdf5:	mov    %rax,0x148(%rsp)
  1bbdfd:	lea    0x340(%rsp),%rdi
  1bbe05:	mov    $0x4,%edx
  1bbe0a:	mov    $0x4,%r8d
  1bbe10:	mov    $0x8,%r9d
  1bbe16:	xor    %esi,%esi
  1bbe18:	mov    %r15,%rcx
  1bbe1b:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bbe20:	cmpl   $0x1,0x340(%rsp)
  1bbe28:	jne    1bbe4d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x9dd>
  1bbe2a:	mov    0x9a547(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1bbe31:	lock sub %rbp,(%rax)
  1bbe35:	mov    0x9a544(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1bbe3c:	mov    0x148(%rsp),%rcx
  1bbe44:	lock sub %rcx,(%rax)
  1bbe48:	jmp    1bbbf7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x787>
  1bbe4d:	mov    0x348(%rsp),%rax
  1bbe55:	mov    %r15,%r12
  1bbe58:	movq   $0x0,0x100(%rsp)
  1bbe64:	movq   $0x4,0x108(%rsp)
  1bbe70:	movq   $0x0,0x70(%rsp)
  1bbe79:	movq   $0x8,0x78(%rsp)
  1bbe82:	movq   $0x0,0x118(%rsp)
  1bbe8e:	movq   $0x8,0x120(%rsp)
  1bbe9a:	movq   $0x0,0xc8(%rsp)
  1bbea6:	movq   $0x4,0xd0(%rsp)
  1bbeb2:	movq   $0x0,0xa8(%rsp)
  1bbebe:	movq   $0x4,0xb0(%rsp)
  1bbeca:	mov    %rbp,0x130(%rsp)
  1bbed2:	movq   $0x0,0x110(%rsp)
  1bbede:	movq   $0x0,0x80(%rsp)
  1bbeea:	movq   $0x0,0x128(%rsp)
  1bbef6:	movq   $0x0,0xd8(%rsp)
  1bbf02:	movq   $0x0,0xb8(%rsp)
  1bbf0e:	mov    %rax,0x1f0(%rsp)
  1bbf16:	mov    %rax,0x48(%rsp)
  1bbf1b:	mov    %r15,0x1e8(%rsp)
  1bbf23:	lea    0x340(%rsp),%rdi
  1bbf2b:	mov    $0x8,%edx
  1bbf30:	mov    $0x1,%ecx
  1bbf35:	mov    $0x8,%r8d
  1bbf3b:	mov    $0x8,%r9d
  1bbf41:	xor    %esi,%esi
  1bbf43:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bbf48:	cmpb   $0x0,0x340(%rsp)
  1bbf50:	je     1bc05c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xbec>
  1bbf56:	mov    $0x1,%r15b
  1bbf59:	mov    0xa8(%rsp),%rsi
  1bbf61:	test   %rsi,%rsi
  1bbf64:	je     1bbf80 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xb10>
  1bbf66:	mov    0xb0(%rsp),%rdi
  1bbf6e:	shl    $0x2,%rsi
  1bbf72:	mov    $0x4,%edx
  1bbf77:	vzeroupper
  1bbf7a:	call   *0x99eb8(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbf80:	mov    0xc8(%rsp),%rsi
  1bbf88:	test   %rsi,%rsi
  1bbf8b:	je     1bbfa7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xb37>
  1bbf8d:	mov    0xd0(%rsp),%rdi
  1bbf95:	shl    $0x2,%rsi
  1bbf99:	mov    $0x4,%edx
  1bbf9e:	vzeroupper
  1bbfa1:	call   *0x99e91(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbfa7:	mov    0x118(%rsp),%rsi
  1bbfaf:	test   %rsi,%rsi
  1bbfb2:	je     1bbfce <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xb5e>
  1bbfb4:	mov    0x120(%rsp),%rdi
  1bbfbc:	shl    $0x3,%rsi
  1bbfc0:	mov    $0x8,%edx
  1bbfc5:	vzeroupper
  1bbfc8:	call   *0x99e6a(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbfce:	mov    0x70(%rsp),%rsi
  1bbfd3:	test   %rsi,%rsi
  1bbfd6:	je     1bbfef <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xb7f>
  1bbfd8:	mov    0x78(%rsp),%rdi
  1bbfdd:	shl    $0x3,%rsi
  1bbfe1:	mov    $0x8,%edx
  1bbfe6:	vzeroupper
  1bbfe9:	call   *0x99e49(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bbfef:	mov    0x100(%rsp),%rsi
  1bbff7:	test   %rsi,%rsi
  1bbffa:	je     1bc016 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xba6>
  1bbffc:	mov    0x108(%rsp),%rdi
  1bc004:	shl    $0x2,%rsi
  1bc008:	mov    $0x4,%edx
  1bc00d:	vzeroupper
  1bc010:	call   *0x99e22(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bc016:	test   %r15b,%r15b
  1bc019:	je     1bc12a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xcba>
  1bc01f:	mov    0x1e8(%rsp),%rsi
  1bc027:	mov    0x20(%rsp),%r12
  1bc02c:	mov    0x130(%rsp),%rbp
  1bc034:	test   %rsi,%rsi
  1bc037:	je     1bbe2a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x9ba>
  1bc03d:	mov    0x1f0(%rsp),%rdi
  1bc045:	shl    $0x3,%rsi
  1bc049:	mov    $0x4,%edx
  1bc04e:	vzeroupper
  1bc051:	call   *0x99de1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bc057:	jmp    1bbe2a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x9ba>
  1bc05c:	mov    0x348(%rsp),%rax
  1bc064:	mov    %rax,0x78(%rsp)
  1bc069:	movq   $0x1,0x70(%rsp)
  1bc072:	mov    0x80(%rsp),%r15
  1bc07a:	cmp    $0x1,%r15
  1bc07e:	jne    1bc096 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xc26>
  1bc080:	mov    $0x1,%al
  1bc082:	mov    %eax,0x18(%rsp)
  1bc086:	lea    0x70(%rsp),%rdi
  1bc08b:	call   *0x9a40f(%rip)        # 2564a0 <_DYNAMIC+0x868>
  1bc091:	mov    0x78(%rsp),%rax
  1bc096:	lea    0x3ff(%r14),%rcx
  1bc09d:	movq   $0x0,(%rax,%r15,8)
  1bc0a5:	inc    %r15
  1bc0a8:	shr    $0xa,%rcx
  1bc0ac:	mov    %r15,0x80(%rsp)
  1bc0b4:	mov    %rcx,0x208(%rsp)
  1bc0bc:	je     1bce43 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x19d3>
  1bc0c2:	mov    $0x400,%eax
  1bc0c7:	lea    0x95e42(%rip),%rdx        # 251f10 <__frame_dummy_init_array_entry+0x2c30>
  1bc0ce:	lea    0x95e6b(%rip),%rcx        # 251f40 <__frame_dummy_init_array_entry+0x2c60>
  1bc0d5:	movq   $0x0,0x138(%rsp)
  1bc0e1:	movq   $0x0,0x18(%rsp)
  1bc0ea:	mov    %rax,0x210(%rsp)
  1bc0f2:	mov    %rdx,0x200(%rsp)
  1bc0fa:	mov    %rcx,0x68(%rsp)
  1bc0ff:	jmp    1bc190 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xd20>
  1bc104:	lea    0x95d5d(%rip),%r9        # 251e68 <__frame_dummy_init_array_entry+0x2b88>
  1bc10b:	lea    0x340(%rsp),%rsi
  1bc113:	lea    0x2a8(%rsp),%rdx
  1bc11b:	xor    %edi,%edi
  1bc11d:	xor    %ecx,%ecx
  1bc11f:	call   *0x99fe3(%rip)        # 256108 <_DYNAMIC+0x4d0>
  1bc125:	jmp    1bde0a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x299a>
  1bc12a:	mov    0x9a247(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1bc131:	mov    0x130(%rsp),%rcx
  1bc139:	lock sub %rcx,(%rax)
  1bc13d:	mov    0x9a23c(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1bc144:	mov    0x148(%rsp),%rcx
  1bc14c:	lock sub %rcx,(%rax)
  1bc150:	mov    0x40(%rsp),%r13
  1bc155:	mov    0x20(%rsp),%r12
  1bc15a:	jmp    1bbc8b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x81b>
  1bc15f:	mov    0x208(%rsp),%rax
  1bc167:	addq   $0x400,0x18(%rsp)
  1bc170:	addq   $0x400,0x210(%rsp)
  1bc17c:	dec    %rax
  1bc17f:	mov    %rax,0x208(%rsp)
  1bc187:	test   %rax,%rax
  1bc18a:	je     1bce33 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x19c3>
  1bc190:	mov    0x210(%rsp),%rax
  1bc198:	movq   $0x0,0x1f8(%rsp)
  1bc1a4:	cmp    %rax,%r14
  1bc1a7:	cmovb  %r14,%rax
  1bc1ab:	mov    %rax,0x10(%rsp)
  1bc1b0:	mov    $0x800,%edx
  1bc1b5:	lea    0x340(%rsp),%rdi
  1bc1bd:	xor    %esi,%esi
  1bc1bf:	vzeroupper
  1bc1c2:	call   *0x99e68(%rip)        # 256030 <memset@GLIBC_2.2.5>
  1bc1c8:	mov    $0x1,%al
  1bc1ca:	mov    %eax,0x50(%rsp)
  1bc1ce:	cmp    0x18(%rsp),%r14
  1bc1d3:	jbe    1bc5b0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1140>
  1bc1d9:	mov    0x18(%rsp),%r12
  1bc1de:	mov    0x58(%rsp),%rdx
  1bc1e3:	mov    0x28(%rsp),%rdi
  1bc1e8:	mov    0x10(%rsp),%r9
  1bc1ed:	mov    $0xffffffff,%r8d
  1bc1f3:	movq   $0x0,(%rsp)
  1bc1fb:	jmp    1bc233 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xdc3>
  1bc1fd:	mov    0x30(%rsp),%rdx
  1bc202:	mov    0x8(%rsp),%rcx
  1bc207:	mov    %r12,%rax
  1bc20a:	shl    $0x20,%rax
  1bc20e:	or     %rax,%rsi
  1bc211:	mov    %rsi,(%rdx,%rcx,8)
  1bc215:	mov    0x58(%rsp),%rdx
  1bc21a:	mov    0x28(%rsp),%rdi
  1bc21f:	mov    0x10(%rsp),%r9
  1bc224:	mov    $0xffffffff,%r8d
  1bc22a:	cmp    %r9,%r12
  1bc22d:	je     1bc5cd <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x115d>
  1bc233:	mov    %r12,%rax
  1bc236:	mov    (%rdx,%rax,4),%r10d
  1bc23a:	inc    %r12
  1bc23d:	cmp    %r8,%r10
  1bc240:	je     1bc22a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xdba>
  1bc242:	cmp    %r10,%rdi
  1bc245:	jbe    1bde0c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x299c>
  1bc24b:	mov    0x30(%rsp),%rcx
  1bc250:	mov    (%rcx,%r10,8),%rcx
  1bc254:	movzwl %cx,%esi
  1bc257:	cmp    $0x2,%rsi
  1bc25b:	jb     1bc22a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xdba>
  1bc25d:	mov    0x40(%rsp),%rdi
  1bc262:	mov    %rax,%rdx
  1bc265:	shl    $0x6,%rdx
  1bc269:	mov    %r10,0x8(%rsp)
  1bc26e:	vmovdqu (%rdi,%rdx,1),%ymm0
  1bc273:	vptest %ymm0,%ymm0
  1bc278:	jne    1bc28b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xe1b>
  1bc27a:	add    0x40(%rsp),%rdx
  1bc27f:	vmovdqu 0x20(%rdx),%ymm0
  1bc284:	vptest %ymm0,%ymm0
  1bc289:	je     1bc215 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xda5>
  1bc28b:	mov    %rcx,%rdi
  1bc28e:	shr    $0x20,%rdi
  1bc292:	je     1bc1fd <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xd8d>
  1bc298:	dec    %rdi
  1bc29b:	mov    %rdi,%rdx
  1bc29e:	sub    0x18(%rsp),%rdx
  1bc2a3:	jb     1bc1fd <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xd8d>
  1bc2a9:	mov    %ecx,%esi
  1bc2ab:	shr    $0x10,%esi
  1bc2ae:	mov    %rdi,0x140(%rsp)
  1bc2b6:	cmp    $0xffff,%esi
  1bc2bc:	je     1bc215 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xda5>
  1bc2c2:	sub    0x18(%rsp),%rax
  1bc2c7:	test   %rsi,%rsi
  1bc2ca:	je     1bc31a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xeaa>
  1bc2cc:	lea    -0x1(%rsi),%rdx
  1bc2d0:	mov    %rdx,0x8(%rsp)
  1bc2d5:	cmp    (%rsp),%rdx
  1bc2d9:	jae    1bde35 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29c5>
  1bc2df:	movzwl %ax,%edx
  1bc2e2:	mov    %rdx,0x8(%rsp)
  1bc2e7:	cmp    $0x3ff,%rdx
  1bc2ee:	ja     1bde47 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29d7>
  1bc2f4:	mov    0x48(%rsp),%rdx
  1bc2f9:	mov    0x8(%rsp),%rdi
  1bc2fe:	movzwl -0x4(%rdx,%rsi,8),%ecx
  1bc303:	mov    %cx,0x340(%rsp,%rdi,2)
  1bc30b:	mov    %ax,-0x4(%rdx,%rsi,8)
  1bc310:	incw   -0x2(%rdx,%rsi,8)
  1bc315:	jmp    1bc215 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xda5>
  1bc31a:	mov    0x8(%rsp),%rsi
  1bc31f:	cmp    %rsi,0xf8(%rsp)
  1bc327:	jbe    1bde5a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29ea>
  1bc32d:	mov    0x8(%rsp),%rsi
  1bc332:	mov    0x1e0(%rsp),%rdi
  1bc33a:	mov    $0x23,%r9d
  1bc340:	shl    $0x5,%rsi
  1bc344:	vmovdqu (%rdi,%rsi,1),%ymm0
  1bc349:	xor    %esi,%esi
  1bc34b:	vmovdqu %ymm0,0x160(%rsp)
  1bc354:	mov    0x160(%rsp),%edi
  1bc35b:	mov    %edi,%r8d
  1bc35e:	add    %edi,%edi
  1bc360:	and    $0xfff,%r8d
  1bc367:	and    $0x1000,%edi
  1bc36d:	cmp    %edi,%r8d
  1bc370:	mov    $0x1,%edi
  1bc375:	mov    $0xfffffffffffffff5,%r8
  1bc37c:	setne  %sil
  1bc380:	lea    -0x18(%r9),%r15
  1bc384:	mov    %r15,%r11
  1bc387:	shr    $0x6,%r11
  1bc38b:	and    $0x3f,%r15d
  1bc38f:	shrx   %r15,0x160(%rsp,%r11,8),%r10
  1bc399:	cmp    $0x34,%r15
  1bc39d:	setb   %bpl
  1bc3a1:	cmp    $0x11,%rdi
  1bc3a5:	setae  %r15b
  1bc3a9:	or     %bpl,%r15b
  1bc3ac:	jne    1bc3c2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xf52>
  1bc3ae:	mov    %r8d,%r15d
  1bc3b1:	and    $0x3d,%r15b
  1bc3b5:	shlx   %r15,0x168(%rsp,%r11,8),%r11
  1bc3bf:	or     %r11,%r10
  1bc3c2:	mov    %r10d,%r11d
  1bc3c5:	and    $0x1fff,%r11d
  1bc3cc:	and    $0x1000,%r10d
  1bc3d3:	xor    %r15d,%r15d
  1bc3d6:	inc    %r11d
  1bc3d9:	shr    $1,%r11d
  1bc3dc:	cmp    %r10d,%r11d
  1bc3df:	setne  %r15b
  1bc3e3:	add    %r15,%rsi
  1bc3e6:	cmp    $0x1,%rsi
  1bc3ea:	ja     1bc501 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1091>
  1bc3f0:	lea    -0xc(%r9),%r15
  1bc3f4:	mov    %r15,%r11
  1bc3f7:	shr    $0x6,%r11
  1bc3fb:	and    $0x3f,%r15d
  1bc3ff:	shrx   %r15,0x160(%rsp,%r11,8),%r10
  1bc409:	cmp    $0x34,%r15
  1bc40d:	setb   %bpl
  1bc411:	cmp    $0x10,%rdi
  1bc415:	setae  %r15b
  1bc419:	or     %bpl,%r15b
  1bc41c:	jne    1bc433 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xfc3>
  1bc41e:	lea    0x34(%r8),%r15d
  1bc422:	and    $0x3d,%r15b
  1bc426:	shlx   %r15,0x168(%rsp,%r11,8),%r11
  1bc430:	or     %r11,%r10
  1bc433:	mov    %r10d,%r11d
  1bc436:	and    $0x1fff,%r11d
  1bc43d:	and    $0x1000,%r10d
  1bc444:	xor    %r15d,%r15d
  1bc447:	inc    %r11d
  1bc44a:	shr    $1,%r11d
  1bc44d:	cmp    %r10d,%r11d
  1bc450:	setne  %r15b
  1bc454:	add    %r15,%rsi
  1bc457:	cmp    $0x1,%rsi
  1bc45b:	ja     1bc501 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1091>
  1bc461:	mov    %r9d,%r15d
  1bc464:	mov    %r9,%r11
  1bc467:	shr    $0x6,%r11
  1bc46b:	and    $0x3f,%r15d
  1bc46f:	shrx   %r15,0x160(%rsp,%r11,8),%r10
  1bc479:	cmp    $0x34,%r15
  1bc47d:	setb   %bpl
  1bc481:	cmp    $0xf,%rdi
  1bc485:	setae  %r15b
  1bc489:	or     %bpl,%r15b
  1bc48c:	jne    1bc4a3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1033>
  1bc48e:	lea    0x28(%r8),%r15d
  1bc492:	and    $0x3d,%r15b
  1bc496:	shlx   %r15,0x168(%rsp,%r11,8),%r11
  1bc4a0:	or     %r11,%r10
  1bc4a3:	mov    %r10d,%r11d
  1bc4a6:	and    $0x1fff,%r11d
  1bc4ad:	and    $0x1000,%r10d
  1bc4b4:	xor    %r15d,%r15d
  1bc4b7:	inc    %r11d
  1bc4ba:	shr    $1,%r11d
  1bc4bd:	cmp    %r10d,%r11d
  1bc4c0:	setne  %r15b
  1bc4c4:	add    %r15,%rsi
  1bc4c7:	cmp    $0x1,%rsi
  1bc4cb:	ja     1bc501 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1091>
  1bc4cd:	add    $0xffffffffffffffdc,%r8
  1bc4d1:	add    $0x24,%r9
  1bc4d5:	add    $0x3,%rdi
  1bc4d9:	cmp    $0x11f,%r9
  1bc4e0:	jne    1bc380 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xf10>
  1bc4e6:	mov    0x30(%rsp),%rsi
  1bc4eb:	mov    0x8(%rsp),%rdx
  1bc4f0:	mov    $0xffff0000,%eax
  1bc4f5:	or     %rax,%rcx
  1bc4f8:	mov    %rcx,(%rsi,%rdx,8)
  1bc4fc:	jmp    1bc215 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xda5>
  1bc501:	movzwl %dx,%ecx
  1bc504:	cmp    $0x3ff,%rcx
  1bc50b:	ja     1bde70 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2a00>
  1bc511:	movzwl %ax,%r15d
  1bc515:	movw   $0xffff,0x340(%rsp,%rcx,2)
  1bc51f:	cmp    $0x3ff,%r15
  1bc526:	ja     1bde88 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2a18>
  1bc52c:	mov    (%rsp),%rax
  1bc530:	mov    %dx,0x340(%rsp,%r15,2)
  1bc539:	cmp    0x1e8(%rsp),%rax
  1bc541:	jne    1bc561 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x10f1>
  1bc543:	lea    0x1e8(%rsp),%rdi
  1bc54b:	vzeroupper
  1bc54e:	call   *0x99ef4(%rip)        # 256448 <_DYNAMIC+0x810>
  1bc554:	mov    0x1f0(%rsp),%rax
  1bc55c:	mov    %rax,0x48(%rsp)
  1bc561:	mov    0x140(%rsp),%rdx
  1bc569:	movabs $0x2000000000000,%rax
  1bc573:	mov    0x48(%rsp),%rcx
  1bc578:	shl    $0x20,%r15
  1bc57c:	add    %rax,%rdx
  1bc57f:	mov    (%rsp),%rax
  1bc583:	add    %r15,%rdx
  1bc586:	mov    %rdx,(%rcx,%rax,8)
  1bc58a:	mov    0x30(%rsp),%rcx
  1bc58f:	mov    0x8(%rsp),%rdx
  1bc594:	inc    %rax
  1bc597:	mov    %rax,0x1f8(%rsp)
  1bc59f:	mov    %rax,(%rsp)
  1bc5a3:	shl    $0x10,%rax
  1bc5a7:	or     %rax,(%rcx,%rdx,8)
  1bc5ab:	jmp    1bc215 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xda5>
  1bc5b0:	mov    0x48(%rsp),%rax
  1bc5b5:	xor    %r15d,%r15d
  1bc5b8:	movq   $0x0,(%rsp)
  1bc5c0:	mov    %rax,0x218(%rsp)
  1bc5c8:	jmp    1bc950 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x14e0>
  1bc5cd:	mov    0x1f0(%rsp),%rcx
  1bc5d5:	mov    (%rsp),%rax
  1bc5d9:	mov    %rcx,0x48(%rsp)
  1bc5de:	lea    (%rcx,%rax,8),%rcx
  1bc5e2:	mov    %rcx,0x218(%rsp)
  1bc5ea:	test   %rax,%rax
  1bc5ed:	je     1bc600 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1190>
  1bc5ef:	cmpq   $0x9,(%rsp)
  1bc5f4:	jae    1bc620 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x11b0>
  1bc5f6:	xor    %eax,%eax
  1bc5f8:	xor    %r15d,%r15d
  1bc5fb:	jmp    1bc761 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x12f1>
  1bc600:	mov    0xd8(%rsp),%rax
  1bc608:	xor    %r15d,%r15d
  1bc60b:	movq   $0x0,(%rsp)
  1bc613:	mov    %rax,0x138(%rsp)
  1bc61b:	jmp    1bc950 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x14e0>
  1bc620:	cmpq   $0x21,(%rsp)
  1bc625:	jae    1bc631 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x11c1>
  1bc627:	xor    %eax,%eax
  1bc629:	xor    %r15d,%r15d
  1bc62c:	jmp    1bc6f3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1283>
  1bc631:	mov    (%rsp),%rdx
  1bc635:	mov    $0x20,%eax
  1bc63a:	vpxor  %xmm0,%xmm0,%xmm0
  1bc63e:	vpxor  %xmm1,%xmm1,%xmm1
  1bc642:	vpxor  %xmm2,%xmm2,%xmm2
  1bc646:	vpxor  %xmm3,%xmm3,%xmm3
  1bc64a:	mov    %edx,%ecx
  1bc64c:	and    $0x1f,%ecx
  1bc64f:	cmove  %rax,%rcx
  1bc653:	mov    %rdx,%rax
  1bc656:	xor    %edx,%edx
  1bc658:	sub    %rcx,%rax
  1bc65b:	mov    0x48(%rsp),%rsi
  1bc660:	vpbroadcastq -0x1858ba(%rip),%zmm5        # 36db0 <GCC_except_table151+0x416c>
  1bc66a:	vpandq 0x6(%rsi,%rdx,8),%zmm5,%zmm4
  1bc675:	vpandq 0x46(%rsi,%rdx,8),%zmm5,%zmm7
  1bc680:	vpandq 0x86(%rsi,%rdx,8),%zmm5,%zmm6
  1bc68b:	vpandq 0xc6(%rsi,%rdx,8),%zmm5,%zmm5
  1bc696:	add    $0x20,%rdx
  1bc69a:	vpaddq %zmm4,%zmm0,%zmm0
  1bc6a0:	vpaddq %zmm7,%zmm1,%zmm1
  1bc6a6:	vpaddq %zmm6,%zmm2,%zmm2
  1bc6ac:	vpaddq %zmm5,%zmm3,%zmm3
  1bc6b2:	cmp    %rdx,%rax
  1bc6b5:	jne    1bc65b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x11eb>
  1bc6b7:	vpaddq %zmm0,%zmm1,%zmm0
  1bc6bd:	vpaddq %zmm0,%zmm2,%zmm0
  1bc6c3:	vpaddq %zmm0,%zmm3,%zmm0
  1bc6c9:	vextracti64x4 $0x1,%zmm0,%ymm1
  1bc6d0:	vpaddq %zmm1,%zmm0,%zmm0
  1bc6d6:	vextracti128 $0x1,%ymm0,%xmm1
  1bc6dc:	vpaddq %xmm1,%xmm0,%xmm0
  1bc6e0:	vpshufd $0xee,%xmm0,%xmm1
  1bc6e5:	vpaddq %xmm1,%xmm0,%xmm0
  1bc6e9:	vmovq  %xmm0,%r15
  1bc6ee:	cmp    $0x9,%ecx
  1bc6f1:	jb     1bc761 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x12f1>
  1bc6f3:	mov    (%rsp),%rsi
  1bc6f7:	mov    %rax,%rcx
  1bc6fa:	mov    $0x8,%eax
  1bc6ff:	vmovq  %r15,%xmm0
  1bc704:	mov    %esi,%edx
  1bc706:	and    $0x7,%edx
  1bc709:	cmove  %rax,%rdx
  1bc70d:	mov    %rsi,%rax
  1bc710:	sub    %rdx,%rax
  1bc713:	mov    0x48(%rsp),%rdx
  1bc718:	vpbroadcastq -0x185972(%rip),%zmm1        # 36db0 <GCC_except_table151+0x416c>
  1bc722:	vpandq 0x6(%rdx,%rcx,8),%zmm1,%zmm1
  1bc72d:	add    $0x8,%rcx
  1bc731:	vpaddq %zmm1,%zmm0,%zmm0
  1bc737:	cmp    %rcx,%rax
  1bc73a:	jne    1bc713 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x12a3>
  1bc73c:	vextracti64x4 $0x1,%zmm0,%ymm1
  1bc743:	vpaddq %zmm1,%zmm0,%zmm0
  1bc749:	vextracti128 $0x1,%ymm0,%xmm1
  1bc74f:	vpaddq %xmm1,%xmm0,%xmm0
  1bc753:	vpshufd $0xee,%xmm0,%xmm1
  1bc758:	vpaddq %xmm1,%xmm0,%xmm0
  1bc75c:	vmovq  %xmm0,%r15
  1bc761:	mov    (%rsp),%rdx
  1bc765:	mov    0x48(%rsp),%rsi
  1bc76a:	movzwl 0x6(%rsi,%rax,8),%ecx
  1bc76f:	inc    %rax
  1bc772:	add    %rcx,%r15
  1bc775:	cmp    %rax,%rdx
  1bc778:	jne    1bc76a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x12fa>
  1bc77a:	mov    0x100(%rsp),%rsi
  1bc782:	mov    0x110(%rsp),%r12
  1bc78a:	mov    %rsi,%rax
  1bc78d:	sub    %r12,%rax
  1bc790:	cmp    %rax,%r15
  1bc793:	jbe    1bc7eb <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x137b>
  1bc795:	add    %r15,%r12
  1bc798:	jb     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc79e:	mov    0x108(%rsp),%rdx
  1bc7a6:	mov    $0x4,%r8d
  1bc7ac:	mov    $0x4,%r9d
  1bc7b2:	lea    0x160(%rsp),%rdi
  1bc7ba:	mov    %r12,%rcx
  1bc7bd:	vzeroupper
  1bc7c0:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bc7c5:	cmpl   $0x1,0x160(%rsp)
  1bc7cd:	je     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc7d3:	mov    0x168(%rsp),%rax
  1bc7db:	mov    %rax,0x108(%rsp)
  1bc7e3:	mov    %r12,0x100(%rsp)
  1bc7eb:	mov    0x70(%rsp),%rsi
  1bc7f0:	mov    0x80(%rsp),%r12
  1bc7f8:	mov    %rsi,%rax
  1bc7fb:	sub    %r12,%rax
  1bc7fe:	cmp    %rax,(%rsp)
  1bc802:	jbe    1bc852 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x13e2>
  1bc804:	add    (%rsp),%r12
  1bc808:	jb     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc80e:	mov    0x78(%rsp),%rdx
  1bc813:	mov    $0x8,%r8d
  1bc819:	mov    $0x8,%r9d
  1bc81f:	lea    0x160(%rsp),%rdi
  1bc827:	mov    %r12,%rcx
  1bc82a:	vzeroupper
  1bc82d:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bc832:	cmpl   $0x1,0x160(%rsp)
  1bc83a:	je     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc840:	mov    0x168(%rsp),%rax
  1bc848:	mov    %rax,0x78(%rsp)
  1bc84d:	mov    %r12,0x70(%rsp)
  1bc852:	mov    0x118(%rsp),%rsi
  1bc85a:	mov    0x128(%rsp),%r12
  1bc862:	mov    %rsi,%rax
  1bc865:	sub    %r12,%rax
  1bc868:	cmp    %rax,(%rsp)
  1bc86c:	jbe    1bc8c5 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1455>
  1bc86e:	add    (%rsp),%r12
  1bc872:	jb     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc878:	mov    0x120(%rsp),%rdx
  1bc880:	mov    $0x8,%r8d
  1bc886:	mov    $0x8,%r9d
  1bc88c:	lea    0x160(%rsp),%rdi
  1bc894:	mov    %r12,%rcx
  1bc897:	vzeroupper
  1bc89a:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bc89f:	cmpl   $0x1,0x160(%rsp)
  1bc8a7:	je     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc8ad:	mov    0x168(%rsp),%rax
  1bc8b5:	mov    %rax,0x120(%rsp)
  1bc8bd:	mov    %r12,0x118(%rsp)
  1bc8c5:	mov    0xc8(%rsp),%rsi
  1bc8cd:	mov    0xd8(%rsp),%rcx
  1bc8d5:	mov    %rsi,%rax
  1bc8d8:	sub    %rcx,%rax
  1bc8db:	mov    %rcx,0x138(%rsp)
  1bc8e3:	cmp    %rax,(%rsp)
  1bc8e7:	jbe    1bc948 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x14d8>
  1bc8e9:	mov    0x138(%rsp),%r12
  1bc8f1:	add    (%rsp),%r12
  1bc8f5:	jb     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc8fb:	mov    0xd0(%rsp),%rdx
  1bc903:	mov    $0x4,%r8d
  1bc909:	mov    $0x4,%r9d
  1bc90f:	lea    0x160(%rsp),%rdi
  1bc917:	mov    %r12,%rcx
  1bc91a:	vzeroupper
  1bc91d:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bc922:	cmpl   $0x1,0x160(%rsp)
  1bc92a:	je     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc930:	mov    0x168(%rsp),%rax
  1bc938:	mov    %rax,0xd0(%rsp)
  1bc940:	mov    %r12,0xc8(%rsp)
  1bc948:	movl   $0x0,0x50(%rsp)
  1bc950:	mov    0xa8(%rsp),%rsi
  1bc958:	mov    0xb8(%rsp),%rcx
  1bc960:	sub    (%rsp),%r15
  1bc964:	mov    $0x0,%r12d
  1bc96a:	cmovae %r15,%r12
  1bc96e:	mov    %rsi,%rax
  1bc971:	sub    %rcx,%rax
  1bc974:	mov    %rcx,0x140(%rsp)
  1bc97c:	cmp    %rax,%r12
  1bc97f:	jbe    1bc9dc <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x156c>
  1bc981:	add    0x140(%rsp),%r12
  1bc989:	jb     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc98f:	mov    0xb0(%rsp),%rdx
  1bc997:	mov    $0x4,%r8d
  1bc99d:	mov    $0x4,%r9d
  1bc9a3:	lea    0x160(%rsp),%rdi
  1bc9ab:	mov    %r12,%rcx
  1bc9ae:	vzeroupper
  1bc9b1:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bc9b6:	cmpl   $0x1,0x160(%rsp)
  1bc9be:	je     1bbf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xae6>
  1bc9c4:	mov    0x168(%rsp),%rax
  1bc9cc:	mov    %rax,0xb0(%rsp)
  1bc9d4:	mov    %r12,0xa8(%rsp)
  1bc9dc:	cmpb   $0x0,0x50(%rsp)
  1bc9e1:	jne    1bc15f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xcef>
  1bc9e7:	mov    0x110(%rsp),%rax
  1bc9ef:	mov    0x48(%rsp),%rcx
  1bc9f4:	mov    %rax,0x8(%rsp)
  1bc9f9:	jmp    1bca3a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x15ca>
  1bc9fb:	mov    (%rsp),%rcx
  1bc9ff:	mov    0x10(%rsp),%rdx
  1bca04:	mov    0x78(%rsp),%rax
  1bca09:	mov    %r12,0x138(%rsp)
  1bca11:	mov    %rdx,(%rax,%r15,8)
  1bca15:	inc    %r15
  1bca18:	add    $0x8,%rcx
  1bca1c:	mov    %rdx,%rax
  1bca1f:	mov    %rdx,0x8(%rsp)
  1bca24:	mov    %r15,0x80(%rsp)
  1bca2c:	cmp    0x218(%rsp),%rcx
  1bca34:	je     1bc15f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xcef>
  1bca3a:	movzwl 0x4(%rcx),%r15d
  1bca3f:	mov    %rcx,(%rsp)
  1bca43:	mov    %r15w,0x160(%rsp)
  1bca4c:	movzwl 0x6(%rcx),%ecx
  1bca50:	mov    %ecx,%ebp
  1bca52:	mov    %rcx,0x298(%rsp)
  1bca5a:	test   %rcx,%rcx
  1bca5d:	je     1bcacf <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x165f>
  1bca5f:	cmp    $0xffff,%r15w
  1bca64:	je     1bcdf2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1982>
  1bca6a:	mov    %rax,%r12
  1bca6d:	cmp    0x100(%rsp),%rax
  1bca75:	jne    1bca88 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1618>
  1bca77:	lea    0x100(%rsp),%rdi
  1bca7f:	vzeroupper
  1bca82:	call   *0x999a0(%rip)        # 256428 <_DYNAMIC+0x7f0>
  1bca88:	movzwl %r15w,%edx
  1bca8c:	mov    0x108(%rsp),%rcx
  1bca94:	mov    %edx,%eax
  1bca96:	add    0x18(%rsp),%eax
  1bca9a:	mov    %eax,(%rcx,%r12,4)
  1bca9e:	mov    %r12,%rax
  1bcaa1:	inc    %rax
  1bcaa4:	mov    %rax,0x110(%rsp)
  1bcaac:	cmp    $0x3ff,%r15w
  1bcab2:	ja     1bdcbf <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x284f>
  1bcab8:	movzwl 0x340(%rsp,%rdx,2),%r15d
  1bcac1:	dec    %bp
  1bcac4:	mov    %r15w,0x160(%rsp)
  1bcacd:	jne    1bca5f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x15ef>
  1bcacf:	cmp    $0xffff,%r15w
  1bcad4:	jne    1bdc49 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x27d9>
  1bcada:	mov    0x8(%rsp),%rdi
  1bcadf:	mov    %rax,%rdx
  1bcae2:	mov    %rax,0x10(%rsp)
  1bcae7:	sub    %rdi,%rdx
  1bcaea:	jb     1bdc50 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x27e0>
  1bcaf0:	mov    0x108(%rsp),%rax
  1bcaf8:	lea    (%rax,%rdi,4),%rsi
  1bcafc:	mov    %rax,0x50(%rsp)
  1bcb01:	mov    %rdx,%rax
  1bcb04:	shr    $1,%rax
  1bcb07:	je     1bcc7d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x180d>
  1bcb0d:	cmp    $0x10,%rdx
  1bcb11:	jae    1bcb1f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x16af>
  1bcb13:	mov    0x8(%rsp),%rdi
  1bcb18:	xor    %ecx,%ecx
  1bcb1a:	jmp    1bcc46 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x17d6>
  1bcb1f:	cmp    $0x40,%rdx
  1bcb23:	jae    1bcb2c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x16bc>
  1bcb25:	xor    %ecx,%ecx
  1bcb27:	jmp    1bcbde <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x176e>
  1bcb2c:	mov    0x8(%rsp),%r8
  1bcb31:	mov    0x50(%rsp),%r10
  1bcb36:	mov    0x10(%rsp),%r9
  1bcb3b:	movabs $0x7fffffffffffffe0,%rdi
  1bcb45:	mov    %rax,%rcx
  1bcb48:	and    %rdi,%rcx
  1bcb4b:	mov    %rdx,%rdi
  1bcb4e:	shr    $0x6,%rdi
  1bcb52:	shl    $0x5,%rdi
  1bcb56:	neg    %rdi
  1bcb59:	lea    0x40(%r10,%r8,4),%r8
  1bcb5e:	lea    -0x40(%r10,%r9,4),%r9
  1bcb63:	xor    %r10d,%r10d
  1bcb66:	vpshufd $0x1b,(%r9,%r10,4),%zmm0
  1bcb6e:	vpshufd $0x1b,-0x40(%r9,%r10,4),%zmm1
  1bcb77:	vpshufd $0x1b,-0x40(%r8),%zmm2
  1bcb7f:	vshufi64x2 $0x1b,%zmm0,%zmm0,%zmm0
  1bcb86:	vshufi64x2 $0x1b,%zmm1,%zmm1,%zmm1
  1bcb8d:	vmovdqu64 %zmm0,-0x40(%r8)
  1bcb94:	vpshufd $0x1b,(%r8),%zmm0
  1bcb9b:	vmovdqu64 %zmm1,(%r8)
  1bcba1:	vshufi64x2 $0x1b,%zmm2,%zmm2,%zmm1
  1bcba8:	sub    $0xffffffffffffff80,%r8
  1bcbac:	vmovdqu64 %zmm1,(%r9,%r10,4)
  1bcbb3:	vshufi64x2 $0x1b,%zmm0,%zmm0,%zmm0
  1bcbba:	vmovdqu64 %zmm0,-0x40(%r9,%r10,4)
  1bcbc2:	add    $0xffffffffffffffe0,%r10
  1bcbc6:	cmp    %r10,%rdi
  1bcbc9:	jne    1bcb66 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x16f6>
  1bcbcb:	mov    0x8(%rsp),%rdi
  1bcbd0:	cmp    %rcx,%rax
  1bcbd3:	je     1bcc7d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x180d>
  1bcbd9:	test   $0x30,%dl
  1bcbdc:	je     1bcc46 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x17d6>
  1bcbde:	mov    0x10(%rsp),%rdi
  1bcbe3:	mov    0x50(%rsp),%r8
  1bcbe8:	mov    %rcx,%rdx
  1bcbeb:	lea    0x0(,%rdx,4),%r9
  1bcbf3:	movabs $0x7fffffffffffffe0,%rcx
  1bcbfd:	add    $0x18,%rcx
  1bcc01:	and    %rax,%rcx
  1bcc04:	lea    (%r8,%rdi,4),%rdi
  1bcc08:	sub    %r9,%rdi
  1bcc0b:	add    $0xffffffffffffffe0,%rdi
  1bcc0f:	vpshufd $0x1b,(%rdi),%ymm0
  1bcc14:	vpshufd $0x1b,(%rsi,%rdx,4),%ymm1
  1bcc1a:	vpermq $0x4e,%ymm0,%ymm0
  1bcc20:	vpermq $0x4e,%ymm1,%ymm1
  1bcc26:	vmovdqu %ymm0,(%rsi,%rdx,4)
  1bcc2b:	vmovdqu %ymm1,(%rdi)
  1bcc2f:	add    $0x8,%rdx
  1bcc33:	add    $0xffffffffffffffe0,%rdi
  1bcc37:	cmp    %rdx,%rcx
  1bcc3a:	jne    1bcc0f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x179f>
  1bcc3c:	mov    0x8(%rsp),%rdi
  1bcc41:	cmp    %rcx,%rax
  1bcc44:	je     1bcc7d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x180d>
  1bcc46:	mov    0x10(%rsp),%rdx
  1bcc4b:	mov    0x50(%rsp),%r8
  1bcc50:	lea    0x0(,%rcx,4),%r9
  1bcc58:	lea    (%r8,%rdx,4),%rdx
  1bcc5c:	sub    %r9,%rdx
  1bcc5f:	add    $0xfffffffffffffffc,%rdx
  1bcc63:	mov    (%rsi,%rcx,4),%r9d
  1bcc67:	mov    (%rdx),%r8d
  1bcc6a:	mov    %r8d,(%rsi,%rcx,4)
  1bcc6e:	mov    %r9d,(%rdx)
  1bcc71:	inc    %rcx
  1bcc74:	add    $0xfffffffffffffffc,%rdx
  1bcc78:	cmp    %rcx,%rax
  1bcc7b:	jne    1bcc63 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x17f3>
  1bcc7d:	cmp    %rdi,0x10(%rsp)
  1bcc82:	jbe    1bde1a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29aa>
  1bcc88:	mov    (%rsi),%r15d
  1bcc8b:	mov    (%rsp),%rax
  1bcc8f:	cmp    (%rax),%r15d
  1bcc92:	jne    1bdc73 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2803>
  1bcc98:	mov    0x8(%rsp),%rax
  1bcc9d:	mov    0x10(%rsp),%rdx
  1bcca2:	mov    0xa8(%rsp),%rcx
  1bccaa:	mov    0x140(%rsp),%rbp
  1bccb2:	inc    %rax
  1bccb5:	mov    %rdx,%rsi
  1bccb8:	sub    %rbp,%rcx
  1bccbb:	sub    %rax,%rsi
  1bccbe:	mov    %rsi,%r12
  1bccc1:	cmp    %rcx,%rsi
  1bccc4:	ja     1bcdb4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1944>
  1bccca:	cmp    %rax,%rdx
  1bcccd:	je     1bccff <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x188f>
  1bcccf:	mov    0x8(%rsp),%rax
  1bccd4:	mov    0x50(%rsp),%rcx
  1bccd9:	lea    0x0(,%rbp,4),%rdi
  1bcce1:	add    0xb0(%rsp),%rdi
  1bcce9:	lea    0x0(,%r12,4),%rdx
  1bccf1:	lea    0x4(%rcx,%rax,4),%rsi
  1bccf6:	vzeroupper
  1bccf9:	call   *0x99199(%rip)        # 255e98 <memcpy@GLIBC_2.14>
  1bccff:	add    %r12,%rbp
  1bcd02:	mov    0x138(%rsp),%r12
  1bcd0a:	mov    %rbp,0x140(%rsp)
  1bcd12:	mov    %rbp,0xb8(%rsp)
  1bcd1a:	cmp    0xc8(%rsp),%r12
  1bcd22:	jne    1bcd35 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x18c5>
  1bcd24:	lea    0xc8(%rsp),%rdi
  1bcd2c:	vzeroupper
  1bcd2f:	call   *0x996f3(%rip)        # 256428 <_DYNAMIC+0x7f0>
  1bcd35:	mov    0xd0(%rsp),%rax
  1bcd3d:	mov    %r15d,(%rax,%r12,4)
  1bcd41:	inc    %r12
  1bcd44:	mov    0x128(%rsp),%r15
  1bcd4c:	mov    %r12,0xd8(%rsp)
  1bcd54:	cmp    0x118(%rsp),%r15
  1bcd5c:	jne    1bcd6f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x18ff>
  1bcd5e:	lea    0x118(%rsp),%rdi
  1bcd66:	vzeroupper
  1bcd69:	call   *0x99731(%rip)        # 2564a0 <_DYNAMIC+0x868>
  1bcd6f:	mov    0x120(%rsp),%rax
  1bcd77:	mov    0x298(%rsp),%rcx
  1bcd7f:	mov    %rcx,(%rax,%r15,8)
  1bcd83:	inc    %r15
  1bcd86:	mov    %r15,0x128(%rsp)
  1bcd8e:	mov    0x80(%rsp),%r15
  1bcd96:	cmp    0x70(%rsp),%r15
  1bcd9b:	jne    1bc9fb <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x158b>
  1bcda1:	lea    0x70(%rsp),%rdi
  1bcda6:	vzeroupper
  1bcda9:	call   *0x996f1(%rip)        # 2564a0 <_DYNAMIC+0x868>
  1bcdaf:	jmp    1bc9fb <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x158b>
  1bcdb4:	mov    $0x4,%ecx
  1bcdb9:	mov    $0x4,%r8d
  1bcdbf:	lea    0xa8(%rsp),%rdi
  1bcdc7:	mov    %rbp,%rsi
  1bcdca:	mov    %r12,%rdx
  1bcdcd:	vzeroupper
  1bcdd0:	call   14ed80 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  1bcdd5:	mov    0xb8(%rsp),%rbp
  1bcddd:	jmp    1bcccf <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x185f>
  1bcde2:	lea    (%rsi,%rsi,1),%rdx
  1bcde6:	not    %rsi
  1bcde9:	shr    $0x3f,%rsi
  1bcded:	jmp    1bbd9d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x92d>
  1bcdf2:	mov    $0x1,%al
  1bcdf4:	lea    0x9512d(%rip),%rcx        # 251f28 <__frame_dummy_init_array_entry+0x2c48>
  1bcdfb:	mov    %rcx,0x200(%rsp)
  1bce03:	mov    $0x1,%cl
  1bce05:	mov    %ecx,0x18(%rsp)
  1bce09:	mov    0x200(%rsp),%r9
  1bce11:	movzbl %al,%edi
  1bce14:	lea    -0x17e65b(%rip),%rdx        # 3e7c0 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5e18>
  1bce1b:	lea    0x160(%rsp),%rsi
  1bce23:	xor    %ecx,%ecx
  1bce25:	vzeroupper
  1bce28:	call   *0x995a2(%rip)        # 2563d0 <_DYNAMIC+0x798>
  1bce2e:	jmp    1bde0a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x299a>
  1bce33:	mov    0x1e8(%rsp),%rax
  1bce3b:	mov    %rax,%r12
  1bce3e:	test   %rax,%rax
  1bce41:	je     1bce5d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x19ed>
  1bce43:	mov    %r12,%rsi
  1bce46:	shl    $0x3,%rsi
  1bce4a:	mov    0x48(%rsp),%rdi
  1bce4f:	mov    $0x4,%edx
  1bce54:	vzeroupper
  1bce57:	call   *0x98fdb(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bce5d:	cmpq   $0x0,0x38(%rsp)
  1bce63:	je     1bce84 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1a14>
  1bce65:	mov    0x38(%rsp),%rsi
  1bce6a:	shl    $0x5,%rsi
  1bce6e:	mov    0x1e0(%rsp),%rdi
  1bce76:	mov    $0x8,%edx
  1bce7b:	vzeroupper
  1bce7e:	call   *0x98fb4(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bce84:	cmpq   $0x0,0x60(%rsp)
  1bce8a:	je     1bceac <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1a3c>
  1bce8c:	mov    0x60(%rsp),%rax
  1bce91:	lea    0x0(,%rax,4),%rsi
  1bce99:	mov    0x58(%rsp),%rdi
  1bce9e:	mov    $0x4,%edx
  1bcea3:	vzeroupper
  1bcea6:	call   *0x98f8c(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bceac:	cmpq   $0x0,0xa0(%rsp)
  1bceb5:	je     1bceda <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1a6a>
  1bceb7:	mov    0xa0(%rsp),%rax
  1bcebf:	lea    0x0(,%rax,8),%rsi
  1bcec7:	mov    0x30(%rsp),%rdi
  1bcecc:	mov    $0x8,%edx
  1bced1:	vzeroupper
  1bced4:	call   *0x98f5e(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bceda:	mov    0x99497(%rip),%rcx        # 256378 <_DYNAMIC+0x740>
  1bcee1:	mov    0x150(%rsp),%rax
  1bcee9:	lock sub %rax,(%rcx)
  1bceed:	mov    0x9948c(%rip),%rcx        # 256380 <_DYNAMIC+0x748>
  1bcef4:	mov    0x158(%rsp),%rax
  1bcefc:	lock sub %rax,(%rcx)
  1bcf00:	mov    0xd8(%rsp),%rax
  1bcf08:	test   %rax,%rax
  1bcf0b:	je     1bd031 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1bc1>
  1bcf11:	mov    %rax,%r15
  1bcf14:	cmp    %r13,%rax
  1bcf17:	ja     1bdc96 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2826>
  1bcf1d:	mov    0x110(%rsp),%r8
  1bcf25:	lea    0x0(%r13,%r13,1),%rax
  1bcf2a:	cmp    %rax,%r8
  1bcf2d:	ja     1bdc96 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2826>
  1bcf33:	mov    0xb8(%rsp),%rax
  1bcf3b:	mov    %rax,0x10(%rsp)
  1bcf40:	cmp    %r13,%rax
  1bcf43:	ja     1bdc96 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2826>
  1bcf49:	vmovdqu 0x120(%rsp),%xmm0
  1bcf52:	mov    0x80(%rsp),%rax
  1bcf5a:	mov    0x108(%rsp),%rcx
  1bcf62:	mov    0x78(%rsp),%r9
  1bcf67:	movl   $0x0,0x18(%rsp)
  1bcf6f:	sub    $0x20,%rsp
  1bcf73:	vmovdqu %xmm0,0x8(%rsp)
  1bcf79:	lea    0xa8(%rsp),%rdi
  1bcf81:	mov    %rax,(%rsp)
  1bcf85:	mov    %r14,%rdx
  1bcf88:	mov    %rcx,0x28(%rsp)
  1bcf8d:	mov    0x60(%rsp),%rsi
  1bcf92:	vzeroupper
  1bcf95:	call   c9aa0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm12group_affineNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEB4_>
  1bcf9a:	add    $0x20,%rsp
  1bcf9e:	movq   $0x0,0xe0(%rsp)
  1bcfaa:	movq   $0x8,0xe8(%rsp)
  1bcfb6:	movq   $0x0,0xf0(%rsp)
  1bcfc2:	lea    0xe0(%rsp),%rdi
  1bcfca:	mov    $0x8,%ecx
  1bcfcf:	mov    $0x48,%r8d
  1bcfd5:	xor    %esi,%esi
  1bcfd7:	mov    %r15,%rdx
  1bcfda:	call   184fb0 <_RNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner17try_reserve_exactCsHW5vo2gROj_10zopro_core>
  1bcfdf:	cmp    $0xffffffffffffffff,%rax
  1bcfe3:	je     1bd04a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1bda>
  1bcfe5:	mov    0xe0(%rsp),%rax
  1bcfed:	test   %rax,%rax
  1bcff0:	je     1bd00d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1b9d>
  1bcff2:	mov    0xe8(%rsp),%rdi
  1bcffa:	shl    $0x3,%rax
  1bcffe:	lea    (%rax,%rax,8),%rsi
  1bd002:	mov    $0x8,%edx
  1bd007:	call   *0x98e2b(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bd00d:	mov    0x88(%rsp),%rsi
  1bd015:	test   %rsi,%rsi
  1bd018:	je     1bd031 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1bc1>
  1bd01a:	mov    0x90(%rsp),%rdi
  1bd022:	shl    $0x6,%rsi
  1bd026:	mov    $0x8,%edx
  1bd02b:	call   *0x98e07(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bd031:	xor    %r15d,%r15d
  1bd034:	mov    0xa8(%rsp),%rsi
  1bd03c:	test   %rsi,%rsi
  1bd03f:	jne    1bbf66 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xaf6>
  1bd045:	jmp    1bbf80 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0xb10>
  1bd04a:	mov    0xd0(%rsp),%rbp
  1bd052:	mov    0x90(%rsp),%rsi
  1bd05a:	mov    0xc8(%rsp),%rax
  1bd062:	mov    0x88(%rsp),%rcx
  1bd06a:	vpxor  %xmm0,%xmm0,%xmm0
  1bd06e:	vmovdqu %xmm0,0x380(%rsp)
  1bd077:	lea    0x0(%rbp,%r15,4),%rdi
  1bd07c:	shl    $0x2,%r15
  1bd080:	mov    %rbp,0x340(%rsp)
  1bd088:	add    $0x4,%rbp
  1bd08c:	mov    %rax,0x350(%rsp)
  1bd094:	mov    %rsi,%r12
  1bd097:	mov    %r15,0x18(%rsp)
  1bd09c:	mov    0x98(%rsp),%r15
  1bd0a4:	mov    %rdi,0x358(%rsp)
  1bd0ac:	mov    %rsi,0x360(%rsp)
  1bd0b4:	mov    %rdi,0x50(%rsp)
  1bd0b9:	mov    %rcx,0x370(%rsp)
  1bd0c1:	shl    $0x6,%r15
  1bd0c5:	lea    (%rsi,%r15,1),%rdx
  1bd0c9:	mov    %rdx,(%rsp)
  1bd0cd:	mov    %rdx,0x378(%rsp)
  1bd0d5:	jmp    1bd12c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1cbc>
  1bd0d7:	lea    0x2b4(%rsp),%rdx
  1bd0df:	lea    0x0(%r13,%r13,8),%rax
  1bd0e4:	add    $0x40,%r12
  1bd0e8:	inc    %r13
  1bd0eb:	add    $0xffffffffffffffc0,%r15
  1bd0ef:	add    $0x4,%rbp
  1bd0f3:	addq   $0xfffffffffffffffc,0x18(%rsp)
  1bd0f9:	mov    0xe8(%rsp),%rcx
  1bd101:	vmovdqu64 (%rdx),%zmm0
  1bd107:	mov    0x28(%rsp),%edx
  1bd10b:	mov    %rcx,0xf8(%rsp)
  1bd113:	vmovdqu64 %zmm0,(%rcx,%rax,8)
  1bd11a:	mov    %edx,0x40(%rcx,%rax,8)
  1bd11e:	mov    %r13,0xf0(%rsp)
  1bd126:	je     1bd1b7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1d47>
  1bd12c:	test   %r15,%r15
  1bd12f:	je     1bd19d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1d2d>
  1bd131:	vmovups (%r12),%zmm0
  1bd138:	mov    -0x4(%rbp),%eax
  1bd13b:	mov    0xf0(%rsp),%r13
  1bd143:	mov    %eax,0x28(%rsp)
  1bd147:	lea    0x164(%rsp),%rax
  1bd14f:	vmovups %zmm0,(%rax)
  1bd155:	vmovups 0x160(%rsp),%zmm0
  1bd160:	mov    0x1a0(%rsp),%eax
  1bd167:	mov    %eax,0x2f0(%rsp)
  1bd16e:	vmovups %zmm0,0x2b0(%rsp)
  1bd179:	cmp    0xe0(%rsp),%r13
  1bd181:	jne    1bd0d7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1c67>
  1bd187:	lea    0xe0(%rsp),%rdi
  1bd18f:	vzeroupper
  1bd192:	call   *0x99268(%rip)        # 256400 <_DYNAMIC+0x7c8>
  1bd198:	jmp    1bd0d7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1c67>
  1bd19d:	mov    0xe8(%rsp),%rax
  1bd1a5:	mov    0xf0(%rsp),%r13
  1bd1ad:	mov    %rax,0xf8(%rsp)
  1bd1b5:	jmp    1bd1c0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1d50>
  1bd1b7:	mov    0x50(%rsp),%rbp
  1bd1bc:	mov    %r12,(%rsp)
  1bd1c0:	mov    (%rsp),%rax
  1bd1c4:	mov    %rbp,0x348(%rsp)
  1bd1cc:	mov    %rax,0x368(%rsp)
  1bd1d4:	lea    0x340(%rsp),%rdi
  1bd1dc:	vzeroupper
  1bd1df:	call   124b70 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters3zip3ZipINtNtNtCs6i54tJFfzR_5alloc3vec9into_iter8IntoItermEIB1a_INtNtCsgHCcee0nhgM_11zopro_bn2545curve6AffineNtB26_8G1ConfigEEEECsHW5vo2gROj_10zopro_core>
  1bd1e4:	mov    0xf8(%rsp),%rdi
  1bd1ec:	mov    %r13,%rsi
  1bd1ef:	call   baa90 <_RINvMNtCsgxBkk5gSRhY_4core5sliceSINtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce11ReplacementNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigE20sort_unstable_by_keymNCINvBy_7prepareB1z_Es0_0EBC_>
  1bd1f4:	mov    0xb0(%rsp),%r15
  1bd1fc:	cmpq   $0x2,0x10(%rsp)
  1bd202:	jae    1bdcf1 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2881>
  1bd208:	mov    0xf8(%rsp),%rax
  1bd210:	mov    %rax,0x340(%rsp)
  1bd218:	mov    %r13,0x348(%rsp)
  1bd220:	movq   $0x2,0x350(%rsp)
  1bd22c:	lea    0x340(%rsp),%rdi
  1bd234:	call   15b9f0 <_RINvYINtNtNtCsgxBkk5gSRhY_4core5slice4iter7WindowsINtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce11ReplacementNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB2C_3all5checkRSBM_NCINvBP_7prepareB1Q_Es1_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBT_>
  1bd239:	test   %al,%al
  1bd23b:	jne    1bdd14 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x28a4>
  1bd241:	mov    0x10(%rsp),%rax
  1bd246:	mov    %r15,0x340(%rsp)
  1bd24e:	mov    %rax,0x348(%rsp)
  1bd256:	movq   $0x2,0x350(%rsp)
  1bd262:	lea    0x340(%rsp),%r15
  1bd26a:	mov    %r15,%rdi
  1bd26d:	call   15bae0 <_RINvYINtNtNtCsgxBkk5gSRhY_4core5slice4iter7WindowsmENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBO_3all5checkRSmNCINvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7prepareNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEs2_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB29_>
  1bd272:	test   %al,%al
  1bd274:	jne    1bdd29 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x28b9>
  1bd27a:	lea    0xe8(%rsp),%rcx
  1bd282:	mov    0xe0(%rsp),%rax
  1bd28a:	mov    0x118(%rsp),%rsi
  1bd292:	vmovups (%rcx),%xmm0
  1bd296:	mov    %rax,0x30(%rsp)
  1bd29b:	mov    0xb8(%rsp),%rax
  1bd2a3:	vmovaps %xmm0,0x340(%rsp)
  1bd2ac:	vmovups 0xa8(%rsp),%xmm0
  1bd2b5:	mov    %rax,0x330(%rsp)
  1bd2bd:	vmovaps %xmm0,0x350(%rsp)
  1bd2c6:	vmovdqu 0x340(%rsp),%xmm0
  1bd2cf:	vmovdqu 0x350(%rsp),%xmm1
  1bd2d8:	vmovdqu %xmm0,0x310(%rsp)
  1bd2e1:	vmovdqu %xmm1,0x320(%rsp)
  1bd2ea:	test   %rsi,%rsi
  1bd2ed:	je     1bd306 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1e96>
  1bd2ef:	mov    0x120(%rsp),%rdi
  1bd2f7:	shl    $0x3,%rsi
  1bd2fb:	mov    $0x8,%edx
  1bd300:	call   *0x98b32(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bd306:	mov    0x70(%rsp),%rsi
  1bd30b:	test   %rsi,%rsi
  1bd30e:	je     1bd324 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1eb4>
  1bd310:	mov    0x78(%rsp),%rdi
  1bd315:	shl    $0x3,%rsi
  1bd319:	mov    $0x8,%edx
  1bd31e:	call   *0x98b14(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bd324:	mov    0x100(%rsp),%rsi
  1bd32c:	test   %rsi,%rsi
  1bd32f:	je     1bd345 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1ed5>
  1bd331:	shl    $0x2,%rsi
  1bd335:	mov    0x8(%rsp),%rdi
  1bd33a:	mov    $0x4,%edx
  1bd33f:	call   *0x98af3(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bd345:	cmpq   $0xffffffffffffffff,0x30(%rsp)
  1bd34b:	mov    0x40(%rsp),%r13
  1bd350:	mov    0x20(%rsp),%r12
  1bd355:	je     1bbc8b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x81b>
  1bd35b:	mov    0x30(%rsp),%rax
  1bd360:	mov    0x330(%rsp),%rcx
  1bd368:	vmovdqu 0x310(%rsp),%ymm0
  1bd371:	mov    0x130(%rsp),%rdx
  1bd379:	movq   $0x0,0x88(%rsp)
  1bd385:	movq   $0x8,0x90(%rsp)
  1bd391:	mov    %r13,0x160(%rsp)
  1bd399:	mov    %r14,0x168(%rsp)
  1bd3a1:	mov    %r12,0x170(%rsp)
  1bd3a9:	movq   $0x0,0x98(%rsp)
  1bd3b5:	mov    %r14,0x178(%rsp)
  1bd3bd:	lea    0x188(%rsp),%rdi
  1bd3c5:	mov    %rax,0x220(%rsp)
  1bd3cd:	mov    %rcx,0xa0(%rsp)
  1bd3d5:	mov    %rcx,0x248(%rsp)
  1bd3dd:	mov    0x148(%rsp),%rcx
  1bd3e5:	vmovdqu %ymm0,0x228(%rsp)
  1bd3ee:	mov    %rdx,0x250(%rsp)
  1bd3f6:	mov    %rcx,0x258(%rsp)
  1bd3fe:	lea    0x220(%rsp),%rcx
  1bd406:	mov    0x230(%rsp),%rax
  1bd40e:	mov    0x238(%rsp),%rdx
  1bd416:	mov    %rcx,0x180(%rsp)
  1bd41e:	movq   $0x0,0x188(%rsp)
  1bd42a:	movq   $0x16,0x190(%rsp)
  1bd436:	mov    %rax,0x158(%rsp)
  1bd43e:	mov    %rdx,0x150(%rsp)
  1bd446:	vzeroupper
  1bd449:	call   *0x99061(%rip)        # 2564b0 <_DYNAMIC+0x878>
  1bd44f:	cmp    $0x1,%rax
  1bd453:	jne    1bd591 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2121>
  1bd459:	mov    %rdx,%rbp
  1bd45c:	mov    %rdx,0xc8(%rsp)
  1bd464:	test   %rdx,%rdx
  1bd467:	jne    1bdd66 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x28f6>
  1bd46d:	mov    $0x8,%eax
  1bd472:	movq   $0x0,0x60(%rsp)
  1bd47b:	xor    %r13d,%r13d
  1bd47e:	mov    %rax,0x38(%rsp)
  1bd483:	mov    0x40(%rsp),%rax
  1bd488:	mov    0x20(%rsp),%rdx
  1bd48d:	lea    0x220(%rsp),%rcx
  1bd495:	movq   $0x0,0xa8(%rsp)
  1bd4a1:	movq   $0x16,0xb0(%rsp)
  1bd4ad:	mov    %rax,0x340(%rsp)
  1bd4b5:	mov    %r14,0x348(%rsp)
  1bd4bd:	mov    %rdx,0x350(%rsp)
  1bd4c5:	mov    %r14,0x358(%rsp)
  1bd4cd:	mov    %rcx,0x360(%rsp)
  1bd4d5:	movq   $0x0,0x368(%rsp)
  1bd4e1:	movq   $0x16,0x370(%rsp)
  1bd4ed:	lea    0xa8(%rsp),%rdi
  1bd4f5:	call   *0x98fbd(%rip)        # 2564b8 <_DYNAMIC+0x880>
  1bd4fb:	lea    0x0(%r13,%r13,2),%rcx
  1bd500:	mov    %rax,%r14
  1bd503:	mov    %r14,0x2c8(%rsp)
  1bd50b:	mov    %r15,0x2b0(%rsp)
  1bd513:	shl    $0x5,%rcx
  1bd517:	add    0x38(%rsp),%rcx
  1bd51c:	mov    %rcx,0x2b8(%rsp)
  1bd524:	mov    %rbp,0x2c0(%rsp)
  1bd52c:	call   *0x98f76(%rip)        # 2564a8 <_DYNAMIC+0x870>
  1bd532:	xor    %ecx,%ecx
  1bd534:	cmp    $0xffffffffffffffff,%r14
  1bd538:	sete   %cl
  1bd53b:	cmp    %rax,%rcx
  1bd53e:	cmova  %rcx,%rax
  1bd542:	lea    0x2b0(%rsp),%r15
  1bd54a:	xor    %edx,%edx
  1bd54c:	lea    0xe0(%rsp),%rdi
  1bd554:	mov    $0x1,%r8d
  1bd55a:	mov    %r14,%rsi
  1bd55d:	mov    %rax,%rcx
  1bd560:	xor    %r9d,%r9d
  1bd563:	push   %r15
  1bd565:	push   $0x16
  1bd567:	call   155670 <_RINvNvNtNtCsc3XWelWpAp8_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_5range12IterProducerjEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerINtNtCsgHCcee0nhgM_11zopro_bn2545curve10ProjectiveNtB2R_8G1ConfigEENCNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7a_querys0_0EEB41_>
  1bd56c:	add    $0x10,%rsp
  1bd570:	mov    0xf0(%rsp),%rax
  1bd578:	mov    %rax,0x2b0(%rsp)
  1bd580:	cmp    %rbp,%rax
  1bd583:	jne    1bddbf <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x294f>
  1bd589:	add    %rbp,%r13
  1bd58c:	jmp    1bd7e9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2379>
  1bd591:	mov    0x40(%rsp),%rax
  1bd596:	mov    0x20(%rsp),%rdx
  1bd59b:	lea    0x220(%rsp),%rcx
  1bd5a3:	movq   $0x0,0xe0(%rsp)
  1bd5af:	movq   $0x16,0xe8(%rsp)
  1bd5bb:	mov    %rax,0x340(%rsp)
  1bd5c3:	mov    %r14,0x348(%rsp)
  1bd5cb:	mov    %rdx,0x350(%rsp)
  1bd5d3:	mov    %r14,0x358(%rsp)
  1bd5db:	mov    %rcx,0x360(%rsp)
  1bd5e3:	movq   $0x0,0x368(%rsp)
  1bd5ef:	movq   $0x16,0x370(%rsp)
  1bd5fb:	lea    0xe0(%rsp),%rdi
  1bd603:	call   *0x98eaf(%rip)        # 2564b8 <_DYNAMIC+0x880>
  1bd609:	mov    %rax,%r14
  1bd60c:	call   *0x98e96(%rip)        # 2564a8 <_DYNAMIC+0x870>
  1bd612:	xor    %ecx,%ecx
  1bd614:	cmp    $0xffffffffffffffff,%r14
  1bd618:	sete   %cl
  1bd61b:	cmp    %rax,%rcx
  1bd61e:	cmova  %rcx,%rax
  1bd622:	xor    %edx,%edx
  1bd624:	lea    0x2b0(%rsp),%rdi
  1bd62c:	mov    $0x1,%r8d
  1bd632:	mov    %r14,%rsi
  1bd635:	mov    %rax,%rcx
  1bd638:	xor    %r9d,%r9d
  1bd63b:	push   %r15
  1bd63d:	push   $0x16
  1bd63f:	call   159a50 <_RINvNvNtNtCsc3XWelWpAp8_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_5range12IterProducerjEINtNtB6_3map11MapConsumerNtNtB6_6extend15ListVecConsumerNCNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7a_querys0_0EEB2J_>
  1bd644:	add    $0x10,%rsp
  1bd648:	mov    0x2c0(%rsp),%rax
  1bd650:	test   %rax,%rax
  1bd653:	je     1bd67f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x220f>
  1bd655:	mov    0x2b0(%rsp),%rcx
  1bd65d:	test   %rcx,%rcx
  1bd660:	je     1bd67f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x220f>
  1bd662:	xor    %edx,%edx
  1bd664:	add    0x10(%rcx),%rdx
  1bd668:	dec    %rax
  1bd66b:	je     1bd676 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2206>
  1bd66d:	mov    0x18(%rcx),%rcx
  1bd671:	test   %rcx,%rcx
  1bd674:	jne    1bd664 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x21f4>
  1bd676:	test   %rdx,%rdx
  1bd679:	jne    1bdd47 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x28d7>
  1bd67f:	vmovdqu 0x2b0(%rsp),%xmm0
  1bd688:	mov    0x2c0(%rsp),%rax
  1bd690:	mov    %rax,0x350(%rsp)
  1bd698:	vmovdqa %xmm0,0x340(%rsp)
  1bd6a1:	mov    0x340(%rsp),%rdi
  1bd6a9:	test   %rdi,%rdi
  1bd6ac:	je     1bd7c7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2357>
  1bd6b2:	mov    0x350(%rsp),%r15
  1bd6ba:	mov    0x348(%rsp),%rax
  1bd6c2:	dec    %r15
  1bd6c5:	mov    %rax,0x40(%rsp)
  1bd6ca:	jmp    1bd6db <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x226b>
  1bd6cc:	dec    %r15
  1bd6cf:	mov    %r14,%rdi
  1bd6d2:	test   %r14,%r14
  1bd6d5:	je     1bd7c7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2357>
  1bd6db:	mov    0x18(%rdi),%r14
  1bd6df:	test   %r14,%r14
  1bd6e2:	je     1bd6ee <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x227e>
  1bd6e4:	movq   $0x0,0x20(%r14)
  1bd6ec:	jmp    1bd6f7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2287>
  1bd6ee:	movq   $0x0,0x40(%rsp)
  1bd6f7:	mov    0x8(%rdi),%rax
  1bd6fb:	mov    (%rdi),%r12
  1bd6fe:	mov    0x10(%rdi),%r13
  1bd702:	mov    %rax,0x20(%rsp)
  1bd707:	mov    $0x28,%esi
  1bd70c:	mov    $0x8,%edx
  1bd711:	call   *0x98721(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bd717:	cmp    $0xffffffffffffffff,%r12
  1bd71b:	je     1bd7be <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x234e>
  1bd721:	mov    0x88(%rsp),%rax
  1bd729:	mov    0x98(%rsp),%rbp
  1bd731:	sub    %rbp,%rax
  1bd734:	cmp    %rax,%r13
  1bd737:	ja     1bd796 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2326>
  1bd739:	test   %r13,%r13
  1bd73c:	je     1bd765 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x22f5>
  1bd73e:	lea    0x0(%rbp,%rbp,2),%rdi
  1bd743:	mov    %r13,%rax
  1bd746:	shl    $0x5,%rax
  1bd74a:	lea    (%rax,%rax,2),%rdx
  1bd74e:	shl    $0x5,%rdi
  1bd752:	add    0x90(%rsp),%rdi
  1bd75a:	mov    0x20(%rsp),%rsi
  1bd75f:	call   *0x98733(%rip)        # 255e98 <memcpy@GLIBC_2.14>
  1bd765:	add    %r13,%rbp
  1bd768:	mov    %rbp,0x98(%rsp)
  1bd770:	test   %r12,%r12
  1bd773:	je     1bd6cc <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x225c>
  1bd779:	shl    $0x5,%r12
  1bd77d:	lea    (%r12,%r12,2),%rsi
  1bd781:	mov    0x20(%rsp),%rdi
  1bd786:	mov    $0x8,%edx
  1bd78b:	call   *0x986a7(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bd791:	jmp    1bd6cc <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x225c>
  1bd796:	mov    $0x8,%ecx
  1bd79b:	mov    $0x60,%r8d
  1bd7a1:	lea    0x88(%rsp),%rdi
  1bd7a9:	mov    %rbp,%rsi
  1bd7ac:	mov    %r13,%rdx
  1bd7af:	call   14ed80 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  1bd7b4:	mov    0x98(%rsp),%rbp
  1bd7bc:	jmp    1bd73e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x22ce>
  1bd7be:	test   %r14,%r14
  1bd7c1:	jne    1bdc17 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x27a7>
  1bd7c7:	mov    0x88(%rsp),%rax
  1bd7cf:	mov    0x90(%rsp),%rcx
  1bd7d7:	mov    0x98(%rsp),%r13
  1bd7df:	mov    %rax,0x60(%rsp)
  1bd7e4:	mov    %rcx,0x38(%rsp)
  1bd7e9:	mov    0x30(%rsp),%rax
  1bd7ee:	vmovups -0x17f3a0(%rip),%zmm0        # 3e458 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5ab0>
  1bd7f8:	vmovups -0x17f38a(%rip),%zmm1        # 3e478 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5ad0>
  1bd802:	mov    0x150(%rsp),%rcx
  1bd80a:	lea    (%rax,%rax,8),%rax
  1bd80e:	shl    $0x3,%rax
  1bd812:	lea    (%rax,%rcx,4),%rax
  1bd816:	vmovups %zmm0,0x160(%rsp)
  1bd821:	vmovups %zmm1,0x180(%rsp)
  1bd829:	mov    %rax,0x20(%rsp)
  1bd82e:	test   %r13,%r13
  1bd831:	je     1bdb0b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x269b>
  1bd837:	mov    0x38(%rsp),%rax
  1bd83c:	shl    $0x5,%r13
  1bd840:	lea    0x340(%rsp),%r14
  1bd848:	lea    0x160(%rsp),%r15
  1bd850:	lea    0x0(%r13,%r13,2),%rbp
  1bd855:	lea    -0x60(%rax),%r12
  1bd859:	mov    %r14,%rdi
  1bd85c:	mov    %r15,%rsi
  1bd85f:	vzeroupper
  1bd862:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bd867:	vmovups 0x360(%rsp),%zmm1
  1bd872:	vmovups 0x340(%rsp),%zmm0
  1bd87a:	vmovups %zmm1,0x180(%rsp)
  1bd882:	vmovups %zmm0,0x160(%rsp)
  1bd88d:	mov    %r14,%rdi
  1bd890:	mov    %r15,%rsi
  1bd893:	vzeroupper
  1bd896:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bd89b:	vmovups 0x360(%rsp),%zmm1
  1bd8a6:	vmovups 0x340(%rsp),%zmm0
  1bd8ae:	vmovups %zmm1,0x180(%rsp)
  1bd8b6:	vmovups %zmm0,0x160(%rsp)
  1bd8c1:	mov    %r14,%rdi
  1bd8c4:	mov    %r15,%rsi
  1bd8c7:	vzeroupper
  1bd8ca:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bd8cf:	vmovups 0x360(%rsp),%zmm1
  1bd8da:	vmovups 0x340(%rsp),%zmm0
  1bd8e2:	vmovups %zmm1,0x180(%rsp)
  1bd8ea:	vmovups %zmm0,0x160(%rsp)
  1bd8f5:	mov    %r14,%rdi
  1bd8f8:	mov    %r15,%rsi
  1bd8fb:	vzeroupper
  1bd8fe:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bd903:	vmovups 0x360(%rsp),%zmm1
  1bd90e:	vmovups 0x340(%rsp),%zmm0
  1bd916:	vmovups %zmm1,0x180(%rsp)
  1bd91e:	vmovups %zmm0,0x160(%rsp)
  1bd929:	mov    %r14,%rdi
  1bd92c:	mov    %r15,%rsi
  1bd92f:	vzeroupper
  1bd932:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bd937:	vmovups 0x360(%rsp),%zmm1
  1bd942:	vmovups 0x340(%rsp),%zmm0
  1bd94a:	vmovups %zmm1,0x180(%rsp)
  1bd952:	vmovups %zmm0,0x160(%rsp)
  1bd95d:	mov    %r14,%rdi
  1bd960:	mov    %r15,%rsi
  1bd963:	vzeroupper
  1bd966:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bd96b:	vmovups 0x360(%rsp),%zmm1
  1bd976:	vmovups 0x340(%rsp),%zmm0
  1bd97e:	vmovups %zmm1,0x180(%rsp)
  1bd986:	vmovups %zmm0,0x160(%rsp)
  1bd991:	mov    %r14,%rdi
  1bd994:	mov    %r15,%rsi
  1bd997:	vzeroupper
  1bd99a:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bd99f:	vmovups 0x360(%rsp),%zmm1
  1bd9aa:	vmovups 0x340(%rsp),%zmm0
  1bd9b2:	vmovups %zmm1,0x180(%rsp)
  1bd9ba:	vmovups %zmm0,0x160(%rsp)
  1bd9c5:	mov    %r14,%rdi
  1bd9c8:	mov    %r15,%rsi
  1bd9cb:	vzeroupper
  1bd9ce:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bd9d3:	vmovups 0x360(%rsp),%zmm1
  1bd9de:	vmovups 0x340(%rsp),%zmm0
  1bd9e6:	vmovups %zmm1,0x180(%rsp)
  1bd9ee:	vmovups %zmm0,0x160(%rsp)
  1bd9f9:	mov    %r14,%rdi
  1bd9fc:	mov    %r15,%rsi
  1bd9ff:	vzeroupper
  1bda02:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bda07:	vmovups 0x360(%rsp),%zmm1
  1bda12:	vmovups 0x340(%rsp),%zmm0
  1bda1a:	vmovups %zmm1,0x180(%rsp)
  1bda22:	vmovups %zmm0,0x160(%rsp)
  1bda2d:	mov    %r14,%rdi
  1bda30:	mov    %r15,%rsi
  1bda33:	vzeroupper
  1bda36:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bda3b:	vmovups 0x360(%rsp),%zmm1
  1bda46:	vmovups 0x340(%rsp),%zmm0
  1bda4e:	vmovups %zmm1,0x180(%rsp)
  1bda56:	vmovups %zmm0,0x160(%rsp)
  1bda61:	mov    %r14,%rdi
  1bda64:	mov    %r15,%rsi
  1bda67:	vzeroupper
  1bda6a:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bda6f:	vmovups 0x360(%rsp),%zmm1
  1bda7a:	vmovups 0x340(%rsp),%zmm0
  1bda82:	vmovups %zmm1,0x180(%rsp)
  1bda8a:	vmovups %zmm0,0x160(%rsp)
  1bda95:	mov    %r14,%rdi
  1bda98:	mov    %r15,%rsi
  1bda9b:	vzeroupper
  1bda9e:	call   18e940 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1bdaa3:	vmovups 0x360(%rsp),%zmm1
  1bdaae:	vmovups 0x340(%rsp),%zmm0
  1bdab6:	lea    (%r12,%rbp,1),%rdx
  1bdaba:	vmovups %zmm1,0x180(%rsp)
  1bdac2:	vmovups %zmm0,0x160(%rsp)
  1bdacd:	mov    %r14,%rdi
  1bdad0:	mov    %r15,%rsi
  1bdad3:	vzeroupper
  1bdad6:	call   1882d0 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE14add_projectiveCsHW5vo2gROj_10zopro_core>
  1bdadb:	vmovups 0x360(%rsp),%zmm1
  1bdae6:	vmovups 0x340(%rsp),%zmm0
  1bdaee:	add    $0xffffffffffffffa0,%rbp
  1bdaf2:	vmovups %zmm1,0x180(%rsp)
  1bdafa:	vmovups %zmm0,0x160(%rsp)
  1bdb05:	jne    1bd859 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x23e9>
  1bdb0b:	vmovdqu64 0x180(%rsp),%zmm1
  1bdb13:	vmovdqu64 0x160(%rsp),%zmm0
  1bdb1e:	cmpq   $0x0,0x60(%rsp)
  1bdb24:	mov    0x158(%rsp),%rax
  1bdb2c:	mov    0xa0(%rsp),%rdx
  1bdb34:	mov    0x20(%rsp),%rcx
  1bdb39:	vmovdqu64 %zmm1,0x360(%rsp)
  1bdb44:	vmovdqu64 %zmm0,0x340(%rsp)
  1bdb4c:	mov    %rax,0x3a0(%rsp)
  1bdb54:	mov    %rdx,0x3a8(%rsp)
  1bdb5c:	mov    %rcx,0x3b0(%rsp)
  1bdb64:	movl   $0x3,0x3b8(%rsp)
  1bdb6f:	je     1bdb91 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2721>
  1bdb71:	mov    0x60(%rsp),%rax
  1bdb76:	shl    $0x5,%rax
  1bdb7a:	lea    (%rax,%rax,2),%rsi
  1bdb7e:	mov    0x38(%rsp),%rdi
  1bdb83:	mov    $0x8,%edx
  1bdb88:	vzeroupper
  1bdb8b:	call   *0x982a7(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bdb91:	mov    0x220(%rsp),%rax
  1bdb99:	test   %rax,%rax
  1bdb9c:	je     1bdbbc <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x274c>
  1bdb9e:	mov    0x228(%rsp),%rdi
  1bdba6:	shl    $0x3,%rax
  1bdbaa:	lea    (%rax,%rax,8),%rsi
  1bdbae:	mov    $0x8,%edx
  1bdbb3:	vzeroupper
  1bdbb6:	call   *0x9827c(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bdbbc:	mov    0x238(%rsp),%rsi
  1bdbc4:	test   %rsi,%rsi
  1bdbc7:	je     1bdbe3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2773>
  1bdbc9:	mov    0x240(%rsp),%rdi
  1bdbd1:	shl    $0x2,%rsi
  1bdbd5:	mov    $0x4,%edx
  1bdbda:	vzeroupper
  1bdbdd:	call   *0x98255(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bdbe3:	mov    0x250(%rsp),%rax
  1bdbeb:	mov    0x258(%rsp),%rcx
  1bdbf3:	jmp    1bbb5b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x6eb>
  1bdbf8:	mov    $0x28,%esi
  1bdbfd:	mov    $0x8,%edx
  1bdc02:	mov    %r14,%rdi
  1bdc05:	call   *0x9822d(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bdc0b:	mov    %r15,%r14
  1bdc0e:	test   %r15,%r15
  1bdc11:	je     1bd7c7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2357>
  1bdc17:	mov    0x18(%r14),%r15
  1bdc1b:	test   %r15,%r15
  1bdc1e:	je     1bdc28 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x27b8>
  1bdc20:	movq   $0x0,0x20(%r15)
  1bdc28:	mov    (%r14),%rax
  1bdc2b:	test   %rax,%rax
  1bdc2e:	je     1bdbf8 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2788>
  1bdc30:	mov    0x8(%r14),%rdi
  1bdc34:	shl    $0x5,%rax
  1bdc38:	lea    (%rax,%rax,2),%rsi
  1bdc3c:	mov    $0x8,%edx
  1bdc41:	call   *0x981f1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bdc47:	jmp    1bdbf8 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2788>
  1bdc49:	xor    %eax,%eax
  1bdc4b:	jmp    1bce03 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1993>
  1bdc50:	mov    $0x1,%al
  1bdc52:	mov    %eax,0x18(%rsp)
  1bdc56:	mov    0x10(%rsp),%rdx
  1bdc5b:	lea    0x94296(%rip),%rcx        # 251ef8 <__frame_dummy_init_array_entry+0x2c18>
  1bdc62:	mov    %rdx,%rsi
  1bdc65:	vzeroupper
  1bdc68:	call   *0x9823a(%rip)        # 255ea8 <_DYNAMIC+0x270>
  1bdc6e:	jmp    1bde0a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x299a>
  1bdc73:	mov    $0x1,%al
  1bdc75:	mov    %eax,0x18(%rsp)
  1bdc79:	mov    (%rsp),%rdx
  1bdc7d:	lea    0x9425c(%rip),%r9        # 251ee0 <__frame_dummy_init_array_entry+0x2c00>
  1bdc84:	xor    %edi,%edi
  1bdc86:	xor    %ecx,%ecx
  1bdc88:	vzeroupper
  1bdc8b:	call   *0x988df(%rip)        # 256570 <_DYNAMIC+0x938>
  1bdc91:	jmp    1bde0a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x299a>
  1bdc96:	movl   $0x0,0x18(%rsp)
  1bdc9e:	lea    -0x17f5d9(%rip),%rdi        # 3e6cc <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5d24>
  1bdca5:	lea    0x941d4(%rip),%rdx        # 251e80 <__frame_dummy_init_array_entry+0x2ba0>
  1bdcac:	mov    $0x77,%esi
  1bdcb1:	vzeroupper
  1bdcb4:	call   *0x981e6(%rip)        # 255ea0 <_DYNAMIC+0x268>
  1bdcba:	jmp    1bde0a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x299a>
  1bdcbf:	mov    $0x400,%eax
  1bdcc4:	mov    %rdx,0x8(%rsp)
  1bdcc9:	mov    %rax,0x28(%rsp)
  1bdcce:	mov    $0x1,%al
  1bdcd0:	mov    %eax,0x18(%rsp)
  1bdcd4:	mov    0x8(%rsp),%rdi
  1bdcd9:	mov    0x28(%rsp),%rsi
  1bdcde:	mov    0x68(%rsp),%rdx
  1bdce3:	vzeroupper
  1bdce6:	call   *0x9828c(%rip)        # 255f78 <_DYNAMIC+0x340>
  1bdcec:	jmp    1bde0a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x299a>
  1bdcf1:	cmpq   $0x15,0x10(%rsp)
  1bdcf7:	jae    1bdea0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2a30>
  1bdcfd:	mov    0x10(%rsp),%rsi
  1bdd02:	mov    $0x1,%edx
  1bdd07:	mov    %r15,%rdi
  1bdd0a:	call   14ce60 <_RINvNtNtNtNtCsgxBkk5gSRhY_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftmNvYmNtNtBa_3cmp10PartialOrd2ltECsHW5vo2gROj_10zopro_core>
  1bdd0f:	jmp    1bd208 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1d98>
  1bdd14:	lea    0x9417d(%rip),%rdx        # 251e98 <__frame_dummy_init_array_entry+0x2bb8>
  1bdd1b:	mov    $0x46,%esi
  1bdd20:	lea    -0x17f5e4(%rip),%rdi        # 3e743 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5d9b>
  1bdd27:	jmp    1bdd3c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x28cc>
  1bdd29:	lea    0x94180(%rip),%rdx        # 251eb0 <__frame_dummy_init_array_entry+0x2bd0>
  1bdd30:	mov    $0x37,%esi
  1bdd35:	lea    -0x17f5b3(%rip),%rdi        # 3e789 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5de1>
  1bdd3c:	call   *0x9815e(%rip)        # 255ea0 <_DYNAMIC+0x268>
  1bdd42:	jmp    1bde0a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x299a>
  1bdd47:	lea    0x88(%rsp),%rdi
  1bdd4f:	mov    $0x8,%ecx
  1bdd54:	mov    $0x60,%r8d
  1bdd5a:	xor    %esi,%esi
  1bdd5c:	call   14ed80 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  1bdd61:	jmp    1bd67f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x220f>
  1bdd66:	lea    0x88(%rsp),%rdi
  1bdd6e:	mov    $0x8,%ecx
  1bdd73:	mov    $0x60,%r8d
  1bdd79:	xor    %esi,%esi
  1bdd7b:	mov    %rbp,%rdx
  1bdd7e:	call   14ed80 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  1bdd83:	mov    0x88(%rsp),%rax
  1bdd8b:	mov    0x98(%rsp),%r13
  1bdd93:	mov    %rax,0x60(%rsp)
  1bdd98:	sub    %r13,%rax
  1bdd9b:	cmp    %rbp,%rax
  1bdd9e:	jae    1bdebb <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2a4b>
  1bdda4:	lea    -0x17f4ad(%rip),%rdi        # 3e8fe <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5f56>
  1bddab:	lea    0x94da6(%rip),%rdx        # 252b58 <__frame_dummy_init_array_entry+0x3878>
  1bddb2:	mov    $0x2f,%esi
  1bddb7:	call   *0x980e3(%rip)        # 255ea0 <_DYNAMIC+0x268>
  1bddbd:	jmp    1bde0a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x299a>
  1bddbf:	mov    0x981c2(%rip),%rcx        # 255f88 <_DYNAMIC+0x350>
  1bddc6:	lea    0xc8(%rsp),%rax
  1bddce:	mov    %rax,0x340(%rsp)
  1bddd6:	mov    %rcx,0x348(%rsp)
  1bddde:	mov    %r15,0x350(%rsp)
  1bdde6:	mov    %rcx,0x358(%rsp)
  1bddee:	lea    -0x187e96(%rip),%rdi        # 35f5f <GCC_except_table151+0x331b>
  1bddf5:	lea    0x94384(%rip),%rdx        # 252180 <__frame_dummy_init_array_entry+0x2ea0>
  1bddfc:	lea    0x340(%rsp),%rsi
  1bde04:	call   *0x980a6(%rip)        # 255eb0 <_DYNAMIC+0x278>
  1bde0a:	ud2
  1bde0c:	mov    %r10,0x8(%rsp)
  1bde11:	lea    0x94140(%rip),%rax        # 251f58 <__frame_dummy_init_array_entry+0x2c78>
  1bde18:	jmp    1bde2b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29bb>
  1bde1a:	mov    0x10(%rsp),%rax
  1bde1f:	mov    %rax,0x28(%rsp)
  1bde24:	lea    0x9409d(%rip),%rax        # 251ec8 <__frame_dummy_init_array_entry+0x2be8>
  1bde2b:	mov    %rax,0x68(%rsp)
  1bde30:	jmp    1bdcce <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x285e>
  1bde35:	mov    (%rsp),%rax
  1bde39:	mov    %rax,0x28(%rsp)
  1bde3e:	lea    0x94173(%rip),%rax        # 251fb8 <__frame_dummy_init_array_entry+0x2cd8>
  1bde45:	jmp    1bde2b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29bb>
  1bde47:	mov    $0x400,%eax
  1bde4c:	mov    %rax,0x28(%rsp)
  1bde51:	lea    0x94178(%rip),%rax        # 251fd0 <__frame_dummy_init_array_entry+0x2cf0>
  1bde58:	jmp    1bde2b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29bb>
  1bde5a:	mov    0xf8(%rsp),%rax
  1bde62:	mov    %rax,0x28(%rsp)
  1bde67:	lea    0x94102(%rip),%rax        # 251f70 <__frame_dummy_init_array_entry+0x2c90>
  1bde6e:	jmp    1bde2b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29bb>
  1bde70:	mov    $0x400,%eax
  1bde75:	mov    %rcx,0x8(%rsp)
  1bde7a:	mov    %rax,0x28(%rsp)
  1bde7f:	lea    0x94102(%rip),%rax        # 251f88 <__frame_dummy_init_array_entry+0x2ca8>
  1bde86:	jmp    1bde2b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29bb>
  1bde88:	mov    $0x400,%eax
  1bde8d:	mov    %r15,0x8(%rsp)
  1bde92:	mov    %rax,0x28(%rsp)
  1bde97:	lea    0x94102(%rip),%rax        # 251fa0 <__frame_dummy_init_array_entry+0x2cc0>
  1bde9e:	jmp    1bde2b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x29bb>
  1bdea0:	mov    0x10(%rsp),%rsi
  1bdea5:	lea    0xc7(%rsp),%rdx
  1bdead:	mov    %r15,%rdi
  1bdeb0:	call   *0x9852a(%rip)        # 2563e0 <_DYNAMIC+0x7a8>
  1bdeb6:	jmp    1bd208 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x1d98>
  1bdebb:	mov    0x90(%rsp),%rax
  1bdec3:	jmp    1bd47e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x200e>
  1bdec8:	mov    %rax,%rbx
  1bdecb:	lea    0x2b0(%rsp),%rdi
  1bded3:	call   124120 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtCs6i54tJFfzR_5alloc11collections11linked_list10LinkedListINtNtBI_3vec3VecINtNtCsgHCcee0nhgM_11zopro_bn2545curve10ProjectiveNtB1W_8G1ConfigEEEECsHW5vo2gROj_10zopro_core>
  1bded8:	jmp    1bdf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2ae6>
  1bdeda:	mov    0x40(%rsp),%rcx
  1bdedf:	mov    %r14,0x340(%rsp)
  1bdee7:	mov    %rax,%rbx
  1bdeea:	mov    %rcx,0x348(%rsp)
  1bdef2:	mov    %r15,0x350(%rsp)
  1bdefa:	test   %r12,%r12
  1bdefd:	je     1bdf17 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2aa7>
  1bdeff:	shl    $0x5,%r12
  1bdf03:	lea    (%r12,%r12,2),%rsi
  1bdf07:	mov    0x20(%rsp),%rdi
  1bdf0c:	mov    $0x8,%edx
  1bdf11:	call   *0x97f21(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bdf17:	lea    0x340(%rsp),%rdi
  1bdf1f:	call   1243a0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtCs6i54tJFfzR_5alloc11collections11linked_list8IntoIterINtNtBI_3vec3VecINtNtCsgHCcee0nhgM_11zopro_bn2545curve10ProjectiveNtB1T_8G1ConfigEEEECsHW5vo2gROj_10zopro_core>
  1bdf24:	jmp    1bdf56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2ae6>
  1bdf26:	jmp    1bdfca <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2b5a>
  1bdf2b:	add    $0x40,%r12
  1bdf2f:	mov    %rax,%rbx
  1bdf32:	mov    %rbp,0x348(%rsp)
  1bdf3a:	mov    %r12,0x368(%rsp)
  1bdf42:	lea    0x340(%rsp),%rdi
  1bdf4a:	call   124b70 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters3zip3ZipINtNtNtCs6i54tJFfzR_5alloc3vec9into_iter8IntoItermEIB1a_INtNtCsgHCcee0nhgM_11zopro_bn2545curve6AffineNtB26_8G1ConfigEEEECsHW5vo2gROj_10zopro_core>
  1bdf4f:	jmp    1bdf96 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2b26>
  1bdf51:	jmp    1bdfca <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2b5a>
  1bdf53:	mov    %rax,%rbx
  1bdf56:	mov    0x88(%rsp),%rax
  1bdf5e:	test   %rax,%rax
  1bdf61:	je     1bdf7e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2b0e>
  1bdf63:	mov    0x90(%rsp),%rdi
  1bdf6b:	shl    $0x5,%rax
  1bdf6f:	lea    (%rax,%rax,2),%rsi
  1bdf73:	mov    $0x8,%edx
  1bdf78:	call   *0x97eba(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bdf7e:	lea    0x220(%rsp),%rdi
  1bdf86:	call   124780 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7OverlayNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEEBI_>
  1bdf8b:	mov    %rbx,%rdi
  1bdf8e:	call   24e260 <_Unwind_Resume@plt>
  1bdf93:	mov    %rax,%rbx
  1bdf96:	mov    0xe0(%rsp),%rax
  1bdf9e:	test   %rax,%rax
  1bdfa1:	je     1bdfbe <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2b4e>
  1bdfa3:	mov    0xe8(%rsp),%rdi
  1bdfab:	shl    $0x3,%rax
  1bdfaf:	lea    (%rax,%rax,8),%rsi
  1bdfb3:	mov    $0x8,%edx
  1bdfb8:	call   *0x97e7a(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bdfbe:	movl   $0x0,0x18(%rsp)
  1bdfc6:	xor    %ebp,%ebp
  1bdfc8:	jmp    1bdff3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2b83>
  1bdfca:	mov    %rax,%rbx
  1bdfcd:	mov    $0x1,%al
  1bdfcf:	mov    %eax,0x18(%rsp)
  1bdfd3:	jmp    1bdff0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2b80>
  1bdfd5:	mov    %rax,%rbx
  1bdfd8:	lea    0x220(%rsp),%rdi
  1bdfe0:	call   124ef0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8grouping12ScalarGroupsEBH_>
  1bdfe5:	mov    %rbx,%rdi
  1bdfe8:	call   24e260 <_Unwind_Resume@plt>
  1bdfed:	mov    %rax,%rbx
  1bdff0:	mov    $0x1,%bpl
  1bdff3:	mov    0xa8(%rsp),%rsi
  1bdffb:	test   %rsi,%rsi
  1bdffe:	je     1be017 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2ba7>
  1be000:	mov    0xb0(%rsp),%rdi
  1be008:	shl    $0x2,%rsi
  1be00c:	mov    $0x4,%edx
  1be011:	call   *0x97e21(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be017:	test   %bpl,%bpl
  1be01a:	je     1be040 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2bd0>
  1be01c:	mov    0xc8(%rsp),%rsi
  1be024:	test   %rsi,%rsi
  1be027:	je     1be040 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2bd0>
  1be029:	mov    0xd0(%rsp),%rdi
  1be031:	shl    $0x2,%rsi
  1be035:	mov    $0x4,%edx
  1be03a:	call   *0x97df8(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be040:	mov    0x118(%rsp),%rsi
  1be048:	test   %rsi,%rsi
  1be04b:	jne    1be0c6 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2c56>
  1be04d:	mov    0x70(%rsp),%rsi
  1be052:	test   %rsi,%rsi
  1be055:	jne    1be0eb <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2c7b>
  1be05b:	mov    0x100(%rsp),%rsi
  1be063:	test   %rsi,%rsi
  1be066:	jne    1be110 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2ca0>
  1be06c:	cmpb   $0x0,0x18(%rsp)
  1be071:	je     1be132 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2cc2>
  1be077:	mov    0x1e8(%rsp),%rsi
  1be07f:	test   %rsi,%rsi
  1be082:	je     1be09b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2c2b>
  1be084:	mov    0x1f0(%rsp),%rdi
  1be08c:	shl    $0x3,%rsi
  1be090:	mov    $0x4,%edx
  1be095:	call   *0x97d9d(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be09b:	mov    0x982d6(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1be0a2:	mov    0x130(%rsp),%rcx
  1be0aa:	lock sub %rcx,(%rax)
  1be0ae:	mov    0x982cb(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1be0b5:	mov    0x148(%rsp),%rcx
  1be0bd:	lock sub %rcx,(%rax)
  1be0c1:	jmp    1be163 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2cf3>
  1be0c6:	mov    0x120(%rsp),%rdi
  1be0ce:	shl    $0x3,%rsi
  1be0d2:	mov    $0x8,%edx
  1be0d7:	call   *0x97d5b(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be0dd:	mov    0x70(%rsp),%rsi
  1be0e2:	test   %rsi,%rsi
  1be0e5:	je     1be05b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2beb>
  1be0eb:	mov    0x78(%rsp),%rdi
  1be0f0:	shl    $0x3,%rsi
  1be0f4:	mov    $0x8,%edx
  1be0f9:	call   *0x97d39(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be0ff:	mov    0x100(%rsp),%rsi
  1be107:	test   %rsi,%rsi
  1be10a:	je     1be06c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2bfc>
  1be110:	mov    0x108(%rsp),%rdi
  1be118:	shl    $0x2,%rsi
  1be11c:	mov    $0x4,%edx
  1be121:	call   *0x97d11(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be127:	cmpb   $0x0,0x18(%rsp)
  1be12c:	jne    1be077 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2c07>
  1be132:	mov    0x9823f(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1be139:	mov    0x130(%rsp),%rcx
  1be141:	lock sub %rcx,(%rax)
  1be145:	mov    0x98234(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1be14c:	mov    0x148(%rsp),%rcx
  1be154:	lock sub %rcx,(%rax)
  1be158:	mov    %rbx,%rdi
  1be15b:	call   24e260 <_Unwind_Resume@plt>
  1be160:	mov    %rax,%rbx
  1be163:	mov    0x9820e(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1be16a:	mov    0x150(%rsp),%rcx
  1be172:	lock sub %rcx,(%rax)
  1be176:	mov    0x98203(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1be17d:	mov    0x158(%rsp),%rcx
  1be185:	lock sub %rcx,(%rax)
  1be189:	cmpq   $0x0,0xa0(%rsp)
  1be192:	jne    1be1ac <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2d3c>
  1be194:	cmpq   $0x0,0x60(%rsp)
  1be19a:	jne    1be1d0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2d60>
  1be19c:	cmpq   $0x0,0x38(%rsp)
  1be1a2:	jne    1be1f1 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2d81>
  1be1a4:	mov    %rbx,%rdi
  1be1a7:	call   24e260 <_Unwind_Resume@plt>
  1be1ac:	mov    0xa0(%rsp),%rsi
  1be1b4:	shl    $0x3,%rsi
  1be1b8:	mov    0x30(%rsp),%rdi
  1be1bd:	mov    $0x8,%edx
  1be1c2:	call   *0x97c70(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be1c8:	cmpq   $0x0,0x60(%rsp)
  1be1ce:	je     1be19c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2d2c>
  1be1d0:	mov    0x60(%rsp),%rsi
  1be1d5:	shl    $0x2,%rsi
  1be1d9:	mov    0x58(%rsp),%rdi
  1be1de:	mov    $0x4,%edx
  1be1e3:	call   *0x97c4f(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be1e9:	cmpq   $0x0,0x38(%rsp)
  1be1ef:	je     1be1a4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1a+0x2d34>
  1be1f1:	mov    0x38(%rsp),%rsi
  1be1f6:	shl    $0x5,%rsi
  1be1fa:	mov    0x1e0(%rsp),%rdi
  1be202:	mov    $0x8,%edx
  1be207:	call   *0x97c2b(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be20d:	mov    %rbx,%rdi
  1be210:	call   24e260 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:

/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001be220 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b>:
  1be220:	push   %rbp
  1be221:	push   %r15
  1be223:	push   %r14
  1be225:	push   %r13
  1be227:	push   %r12
  1be229:	push   %rbx
  1be22a:	sub    $0xc08,%rsp
  1be231:	mov    %rdx,0x348(%rsp)
  1be239:	mov    %r8,0x400(%rsp)
  1be241:	cmp    %r8,%rdx
  1be244:	jne    1bea50 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x830>
  1be24a:	lea    -0x400(%rdx),%rax
  1be251:	mov    %rcx,%r12
  1be254:	mov    %rdx,%rbp
  1be257:	mov    %rdi,%rbx
  1be25a:	cmp    $0xfbff,%rax
  1be260:	ja     1be331 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x111>
  1be266:	lea    0x400(%rsp),%rdi
  1be26e:	mov    %rsi,%r13
  1be271:	call   1c8e70 <_RNvXs0_NtCsHW5vo2gROj_10zopro_core3msmINtB5_8BatchAddNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigENtNtCsgxBkk5gSRhY_4core7default7Default7defaultB7_>
  1be276:	cmpb   $0x1,0x920(%rsp)
  1be27e:	jne    1be321 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x101>
  1be284:	cmpb   $0x0,0x919(%rsp)
  1be28c:	je     1be321 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x101>
  1be292:	cmpb   $0x0,0x918(%rsp)
  1be29a:	je     1be321 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x101>
  1be2a0:	cmpb   $0x0,0x91a(%rsp)
  1be2a8:	je     1be321 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x101>
  1be2aa:	lea    -0x187a21(%rip),%rsi        # 36890 <GCC_except_table151+0x3c4c>
  1be2b1:	lea    0x1c0(%rsp),%rdi
  1be2b9:	mov    $0x10,%edx
  1be2be:	call   *0x97c4c(%rip)        # 255f10 <_DYNAMIC+0x2d8>
  1be2c4:	mov    0x1c8(%rsp),%rsi
  1be2cc:	mov    0x1d0(%rsp),%rdi
  1be2d4:	cmpb   $0x0,0x1c0(%rsp)
  1be2dc:	je     1be2f3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xd3>
  1be2de:	cmp    $0xfffffffffffffffe,%rsi
  1be2e2:	jne    1be3ce <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1ae>
  1be2e8:	test   $0x1,%dil
  1be2ec:	je     1be321 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x101>
  1be2ee:	jmp    1be3e3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1c3>
  1be2f3:	cmpq   $0x1,0x1d8(%rsp)
  1be2fc:	mov    $0x1,%r14b
  1be2ff:	jne    1be308 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xe8>
  1be301:	cmpb   $0x30,(%rdi)
  1be304:	setne  %r14b
  1be308:	test   %rsi,%rsi
  1be30b:	je     1be318 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xf8>
  1be30d:	mov    $0x1,%edx
  1be312:	call   *0x97b20(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be318:	test   %r14b,%r14b
  1be31b:	jne    1be3e3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1c3>
  1be321:	lea    0x400(%rsp),%rdi
  1be329:	call   123ae0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCsHW5vo2gROj_10zopro_core3msm8BatchAddNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEEBG_>
  1be32e:	mov    %r13,%rsi
  1be331:	lea    0x400(%rsp),%rdi
  1be339:	mov    %rbp,%rdx
  1be33c:	mov    %r12,%rcx
  1be33f:	mov    %rbp,%r8
  1be342:	call   1b8240 <_RNvNtCsHW5vo2gROj_10zopro_core10msm_affine18g2_query_exclusive>
  1be347:	vpxor  %xmm0,%xmm0,%xmm0
  1be34b:	vmovdqu %xmm0,0x4cc(%rsp)
  1be354:	vmovdqu %xmm0,0x4c0(%rsp)
  1be35d:	vmovups 0x440(%rsp),%zmm1
  1be365:	vmovups 0x400(%rsp),%zmm0
  1be36d:	vmovups 0x480(%rsp),%zmm2
  1be375:	mov    0x4d8(%rsp),%eax
  1be37c:	mov    0x4d0(%rsp),%rcx
  1be384:	vmovups %zmm1,0x40(%rbx)
  1be38b:	vmovaps 0x4c0(%rsp),%xmm1
  1be394:	vmovups %zmm2,0x80(%rbx)
  1be39b:	vmovups %zmm0,(%rbx)
  1be3a1:	vmovups %xmm1,0xc0(%rbx)
  1be3a9:	mov    %rcx,0xd0(%rbx)
  1be3b0:	mov    %eax,0xd8(%rbx)
  1be3b6:	mov    %rbx,%rax
  1be3b9:	add    $0xc08,%rsp
  1be3c0:	pop    %rbx
  1be3c1:	pop    %r12
  1be3c3:	pop    %r13
  1be3c5:	pop    %r14
  1be3c7:	pop    %r15
  1be3c9:	pop    %rbp
  1be3ca:	vzeroupper
  1be3cd:	ret
  1be3ce:	lea    -0x1(%rsi),%rax
  1be3d2:	cmp    $0xfffffffffffffffc,%rax
  1be3d6:	ja     1be3e3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1c3>
  1be3d8:	mov    $0x1,%edx
  1be3dd:	call   *0x97a55(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be3e3:	lea    0x400(%rsp),%rdi
  1be3eb:	call   123ae0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCsHW5vo2gROj_10zopro_core3msm8BatchAddNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEEBG_>
  1be3f0:	lea    0x358(%rsp),%rdi
  1be3f8:	mov    %r12,%rsi
  1be3fb:	mov    %rbp,%rdx
  1be3fe:	call   1c4b70 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified>
  1be403:	mov    0x358(%rsp),%rax
  1be40b:	cmp    $0xfffffffffffffffe,%rax
  1be40f:	je     1be767 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x547>
  1be415:	cmp    $0xffffffffffffffff,%rax
  1be419:	jne    1be518 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2f8>
  1be41f:	mov    0x370(%rsp),%rcx
  1be427:	mov    0x378(%rsp),%rdx
  1be42f:	mov    0x368(%rsp),%rax
  1be437:	mov    0x388(%rsp),%rsi
  1be43f:	mov    0x360(%rsp),%r14
  1be447:	mov    %r13,0x50(%rsp)
  1be44c:	mov    %rbp,0x350(%rsp)
  1be454:	mov    %rcx,0x190(%rsp)
  1be45c:	mov    0x380(%rsp),%rcx
  1be464:	mov    %rdx,0x80(%rsp)
  1be46c:	mov    0x3a0(%rsp),%rdx
  1be474:	mov    %rax,0x198(%rsp)
  1be47c:	mov    %rsi,0x400(%rsp)
  1be484:	mov    %rcx,0x138(%rsp)
  1be48c:	mov    0x390(%rsp),%rcx
  1be494:	mov    %rcx,0x78(%rsp)
  1be499:	mov    0x398(%rsp),%rcx
  1be4a1:	mov    %rcx,0x38(%rsp)
  1be4a6:	mov    0x3a8(%rsp),%rcx
  1be4ae:	mov    %rcx,0x178(%rsp)
  1be4b6:	mov    0x3b0(%rsp),%rcx
  1be4be:	mov    %rcx,0x180(%rsp)
  1be4c6:	cmp    %rbp,%rsi
  1be4c9:	jne    1c0020 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1e00>
  1be4cf:	lea    0x0(,%rdx,8),%rax
  1be4d7:	movabs $0x2000000000000000,%r13
  1be4e1:	mov    %rdx,0x40(%rsp)
  1be4e6:	xor    %r15d,%r15d
  1be4e9:	xor    %ecx,%ecx
  1be4eb:	nopl   0x0(%rax,%rax,1)
  1be4f0:	cmp    %rcx,%rax
  1be4f3:	je     1be64f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x42f>
  1be4f9:	mov    0x38(%rsp),%rdx
  1be4fe:	mov    (%rdx,%rcx,1),%rdx
  1be502:	cmp    $0x1,%rdx
  1be506:	adc    $0xffffffffffffffff,%rdx
  1be50a:	add    $0x8,%rcx
  1be50e:	add    %rdx,%r15
  1be511:	jae    1be4f0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2d0>
  1be513:	jmp    1be6d2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x4b2>
  1be518:	vmovups 0x358(%rsp),%zmm0
  1be523:	vmovups 0x390(%rsp),%zmm1
  1be52e:	vmovups %zmm0,0x280(%rsp)
  1be536:	vmovups %zmm1,0x2b8(%rsp)
  1be541:	mov    0x290(%rsp),%r15
  1be549:	lea    -0x400(%r15),%rax
  1be550:	cmp    $0xfc00,%rax
  1be556:	jae    1be7ac <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x58c>
  1be55c:	vmovaps 0x2d0(%rsp),%xmm0
  1be565:	mov    0x2c0(%rsp),%rax
  1be56d:	mov    0x2a0(%rsp),%rcx
  1be575:	mov    0x2a8(%rsp),%r8
  1be57d:	mov    0x2b8(%rsp),%r9
  1be585:	lea    0xb0(%rsp),%rdi
  1be58d:	vmovups %xmm0,0x8(%rsp)
  1be593:	mov    %rax,(%rsp)
  1be597:	mov    %r13,%rsi
  1be59a:	mov    %rbp,%rdx
  1be59d:	vzeroupper
  1be5a0:	call   c9c40 <_RINvNtCsHW5vo2gROj_10zopro_core3msm12group_affineNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEB4_>
  1be5a5:	mov    0xb8(%rsp),%r14
  1be5ad:	mov    0xc0(%rsp),%rdx
  1be5b5:	mov    0x288(%rsp),%rcx
  1be5bd:	lea    0x1c0(%rsp),%rdi
  1be5c5:	mov    %r14,%rsi
  1be5c8:	mov    %r15,%r8
  1be5cb:	call   1c3150 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine6g2_phi13raw_exclusive>
  1be5d0:	vmovdqu64 0x1c0(%rsp),%zmm0
  1be5d8:	vmovdqu64 0x200(%rsp),%zmm1
  1be5e0:	vmovdqu64 0x240(%rsp),%zmm2
  1be5e8:	mov    0xb0(%rsp),%rsi
  1be5f0:	vmovdqu64 %zmm0,0x400(%rsp)
  1be5f8:	vmovdqu64 %zmm2,0x480(%rsp)
  1be600:	vmovdqu64 %zmm1,0x440(%rsp)
  1be608:	vpxor  %xmm0,%xmm0,%xmm0
  1be60c:	vmovdqa %xmm0,0x4c0(%rsp)
  1be615:	movq   $0x0,0x4d0(%rsp)
  1be621:	movl   $0x1,0x4d8(%rsp)
  1be62c:	test   %rsi,%rsi
  1be62f:	je     1be81e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x5fe>
  1be635:	shl    $0x7,%rsi
  1be639:	mov    $0x8,%edx
  1be63e:	mov    %r14,%rdi
  1be641:	vzeroupper
  1be644:	call   *0x977ee(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be64a:	jmp    1be81e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x5fe>
  1be64f:	test   %r15,%r15
  1be652:	je     1be6d2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x4b2>
  1be654:	mov    %r14,0x90(%rsp)
  1be65c:	test   %r15,%r15
  1be65f:	js     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be661:	call   *0x97e41(%rip)        # 2564a8 <_DYNAMIC+0x870>
  1be667:	cmp    $0x1,%rax
  1be66b:	movabs $0x3ffffffffffffff0,%rcx
  1be675:	lea    (%r15,%r15,1),%r8
  1be679:	adc    $0x0,%rax
  1be67d:	lea    0xf(%rcx),%rdx
  1be681:	cmp    %rdx,%r8
  1be684:	ja     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be686:	cmp    %rcx,%r8
  1be689:	lea    -0x1(%r13),%rdx
  1be68d:	setb   %cl
  1be690:	cmp    %rdx,%r15
  1be693:	setb   %dl
  1be696:	add    $0xfffffffffffffff7,%r13
  1be69a:	and    %cl,%dl
  1be69c:	cmp    %r13,%r15
  1be69f:	setb   %cl
  1be6a2:	and    %dl,%cl
  1be6a4:	cmp    $0x1,%cl
  1be6a7:	je     1be8e5 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x6c5>
  1be6ad:	xor    %esi,%esi
  1be6af:	lea    0x400(%rsp),%rdi
  1be6b7:	call   17a230 <_RNvMNtCsHW5vo2gROj_10zopro_core11preparationNtB2_11Reservation8analysis>
  1be6bc:	cmpb   $0x0,0x400(%rsp)
  1be6c4:	jne    1be9b4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x794>
  1be6ca:	mov    0x90(%rsp),%r14
  1be6d2:	mov    0x97c9f(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1be6d9:	mov    0x178(%rsp),%rcx
  1be6e1:	lock sub %rcx,(%rax)
  1be6e5:	mov    0x97c94(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1be6ec:	mov    0x180(%rsp),%rcx
  1be6f4:	lock sub %rcx,(%rax)
  1be6f8:	mov    0x78(%rsp),%rsi
  1be6fd:	test   %rsi,%rsi
  1be700:	je     1be719 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x4f9>
  1be702:	mov    0x38(%rsp),%rdi
  1be707:	shl    $0x3,%rsi
  1be70b:	mov    $0x8,%edx
  1be710:	vzeroupper
  1be713:	call   *0x9771f(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be719:	mov    0x80(%rsp),%rsi
  1be721:	mov    0x50(%rsp),%r13
  1be726:	test   %rsi,%rsi
  1be729:	je     1be745 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x525>
  1be72b:	mov    0x138(%rsp),%rdi
  1be733:	shl    $0x2,%rsi
  1be737:	mov    $0x4,%edx
  1be73c:	vzeroupper
  1be73f:	call   *0x976f3(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be745:	test   %r14,%r14
  1be748:	je     1be767 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x547>
  1be74a:	mov    0x198(%rsp),%rdi
  1be752:	shl    $0x5,%r14
  1be756:	mov    $0x8,%edx
  1be75b:	mov    %r14,%rsi
  1be75e:	vzeroupper
  1be761:	call   *0x976d1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be767:	lea    0x400(%rsp),%rdi
  1be76f:	mov    %r13,%rsi
  1be772:	mov    %rbp,%rdx
  1be775:	mov    %r12,%rcx
  1be778:	mov    %rbp,%r8
  1be77b:	vzeroupper
  1be77e:	call   1c3150 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine6g2_phi13raw_exclusive>
  1be783:	vpxor  %xmm0,%xmm0,%xmm0
  1be787:	vmovdqa %xmm0,0x4c0(%rsp)
  1be790:	movq   $0x0,0x4d0(%rsp)
  1be79c:	movl   $0x2,0x4d8(%rsp)
  1be7a7:	jmp    1be35d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x13d>
  1be7ac:	lea    0x1c0(%rsp),%rdi
  1be7b4:	lea    0x280(%rsp),%rcx
  1be7bc:	mov    %r13,%rsi
  1be7bf:	mov    %rbp,%rdx
  1be7c2:	vzeroupper
  1be7c5:	call   1b80a0 <_RNvNtCsHW5vo2gROj_10zopro_core10msm_affine16g2_query_grouped>
  1be7ca:	vmovdqu64 0x1c0(%rsp),%zmm0
  1be7d2:	vmovdqu64 0x200(%rsp),%zmm1
  1be7da:	vmovdqu64 0x240(%rsp),%zmm2
  1be7e2:	vmovdqu64 %zmm0,0x400(%rsp)
  1be7ea:	vmovdqu64 %zmm2,0x480(%rsp)
  1be7f2:	vmovdqu64 %zmm1,0x440(%rsp)
  1be7fa:	vpxor  %xmm0,%xmm0,%xmm0
  1be7fe:	vmovdqa %xmm0,0x4c0(%rsp)
  1be807:	movq   $0x0,0x4d0(%rsp)
  1be813:	movl   $0x1,0x4d8(%rsp)
  1be81e:	mov    0x280(%rsp),%rsi
  1be826:	test   %rsi,%rsi
  1be829:	je     1be845 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x625>
  1be82b:	mov    0x288(%rsp),%rdi
  1be833:	shl    $0x5,%rsi
  1be837:	mov    $0x8,%edx
  1be83c:	vzeroupper
  1be83f:	call   *0x975f3(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be845:	mov    0x298(%rsp),%rsi
  1be84d:	test   %rsi,%rsi
  1be850:	je     1be86c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x64c>
  1be852:	mov    0x2a0(%rsp),%rdi
  1be85a:	shl    $0x2,%rsi
  1be85e:	mov    $0x4,%edx
  1be863:	vzeroupper
  1be866:	call   *0x975cc(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be86c:	mov    0x2b0(%rsp),%rsi
  1be874:	test   %rsi,%rsi
  1be877:	je     1be893 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x673>
  1be879:	mov    0x2b8(%rsp),%rdi
  1be881:	shl    $0x3,%rsi
  1be885:	mov    $0x8,%edx
  1be88a:	vzeroupper
  1be88d:	call   *0x975a5(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be893:	mov    0x2c8(%rsp),%rsi
  1be89b:	test   %rsi,%rsi
  1be89e:	je     1be8ba <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x69a>
  1be8a0:	mov    0x2d0(%rsp),%rdi
  1be8a8:	shl    $0x3,%rsi
  1be8ac:	mov    $0x8,%edx
  1be8b1:	vzeroupper
  1be8b4:	call   *0x9757e(%rip)        # 255e38 <_DYNAMIC+0x200>
  1be8ba:	mov    0x2e8(%rsp),%rax
  1be8c2:	mov    0x2f0(%rsp),%rcx
  1be8ca:	mov    0x97aa7(%rip),%rdx        # 256378 <_DYNAMIC+0x740>
  1be8d1:	lock sub %rax,(%rdx)
  1be8d5:	mov    0x97aa4(%rip),%rdx        # 256380 <_DYNAMIC+0x748>
  1be8dc:	lock sub %rcx,(%rdx)
  1be8e0:	jmp    1be35d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x13d>
  1be8e5:	cmp    $0x200,%r15
  1be8ec:	mov    $0x200,%edi
  1be8f1:	mov    %r15,%rcx
  1be8f4:	cmovb  %r15,%rdi
  1be8f8:	shr    $0x39,%rcx
  1be8fc:	jne    1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be902:	movabs $0x1e1e1e1e1e1e1e1,%rcx
  1be90c:	cmp    %rcx,%r15
  1be90f:	ja     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be915:	mov    $0x13c,%ecx
  1be91a:	mov    %rax,%rsi
  1be91d:	mov    %r8,%rax
  1be920:	mul    %rcx
  1be923:	jo     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be929:	mov    $0xf8,%edx
  1be92e:	mov    %rax,%rcx
  1be931:	mov    %rsi,%rax
  1be934:	mul    %rdx
  1be937:	jo     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be93d:	mov    %rax,%rsi
  1be940:	add    %rcx,%rsi
  1be943:	jb     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be949:	lea    0x40(,%r15,4),%rcx
  1be951:	lea    (%r15,%r15,2),%rax
  1be955:	lea    0xc8(%rcx,%rax,8),%rax
  1be95d:	add    %rcx,%rax
  1be960:	jb     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be966:	mov    %edi,%ecx
  1be968:	lea    0x40(,%rcx,8),%rcx
  1be970:	add    %rax,%rcx
  1be973:	jb     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be979:	mov    %r15,%rdx
  1be97c:	shl    $0x7,%rdx
  1be980:	lea    0x40(%rdx),%rax
  1be984:	add    %rcx,%rax
  1be987:	jb     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be98d:	lea    0x40(%rdx,%r15,8),%rcx
  1be992:	add    %rax,%rcx
  1be995:	jb     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be99b:	add    %rcx,%rsi
  1be99e:	jb     1be6ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48d>
  1be9a4:	lea    (%rsi,%rsi,1),%rdx
  1be9a8:	not    %rsi
  1be9ab:	shr    $0x3f,%rsi
  1be9af:	jmp    1be6af <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x48f>
  1be9b4:	mov    0x410(%rsp),%rcx
  1be9bc:	mov    0x408(%rsp),%rax
  1be9c4:	cmp    $0x200,%r15
  1be9cb:	lea    0x400(%rsp),%rdi
  1be9d3:	mov    $0x4,%edx
  1be9d8:	mov    $0x4,%r8d
  1be9de:	mov    $0x8,%r9d
  1be9e4:	movq   $0x0,0x1b0(%rsp)
  1be9f0:	mov    %rcx,0x170(%rsp)
  1be9f8:	mov    $0x200,%ecx
  1be9fd:	mov    %rax,0x168(%rsp)
  1bea05:	cmovb  %r15,%rcx
  1bea09:	xor    %esi,%esi
  1bea0b:	mov    %rcx,%r13
  1bea0e:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bea13:	cmpl   $0x1,0x400(%rsp)
  1bea1b:	mov    0x90(%rsp),%r14
  1bea23:	jne    1bea71 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x851>
  1bea25:	mov    0x9794c(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1bea2c:	mov    0x168(%rsp),%rcx
  1bea34:	lock sub %rcx,(%rax)
  1bea38:	mov    0x97941(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1bea3f:	mov    0x170(%rsp),%rcx
  1bea47:	lock sub %rcx,(%rax)
  1bea4b:	jmp    1be6d2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x4b2>
  1bea50:	lea    0x94401(%rip),%r9        # 252e58 <__frame_dummy_init_array_entry+0x3b78>
  1bea57:	lea    0x348(%rsp),%rsi
  1bea5f:	lea    0x400(%rsp),%rdx
  1bea67:	xor    %edi,%edi
  1bea69:	xor    %ecx,%ecx
  1bea6b:	call   *0x97697(%rip)        # 256108 <_DYNAMIC+0x4d0>
  1bea71:	mov    0x408(%rsp),%rax
  1bea79:	lea    0x400(%rsp),%rdi
  1bea81:	mov    $0x8,%edx
  1bea86:	mov    $0x1,%ecx
  1bea8b:	mov    $0x8,%r8d
  1bea91:	mov    $0x8,%r9d
  1bea97:	movq   $0x0,0x140(%rsp)
  1beaa3:	movq   $0x4,0x148(%rsp)
  1beaaf:	movq   $0x0,0x98(%rsp)
  1beabb:	movq   $0x8,0xa0(%rsp)
  1beac7:	movq   $0x0,0xe8(%rsp)
  1bead3:	movq   $0x8,0xf0(%rsp)
  1beadf:	movq   $0x0,0x118(%rsp)
  1beaeb:	movq   $0x4,0x120(%rsp)
  1beaf7:	movq   $0x0,0x100(%rsp)
  1beb03:	movq   $0x4,0x108(%rsp)
  1beb0f:	xor    %esi,%esi
  1beb11:	movq   $0x0,0x150(%rsp)
  1beb1d:	movq   $0x0,0xa8(%rsp)
  1beb29:	movq   $0x0,0xf8(%rsp)
  1beb35:	movq   $0x0,0x128(%rsp)
  1beb41:	movq   $0x0,0x110(%rsp)
  1beb4d:	mov    %rax,0x1a8(%rsp)
  1beb55:	mov    %rax,0x70(%rsp)
  1beb5a:	mov    %r13,0x1a0(%rsp)
  1beb62:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1beb67:	cmpb   $0x0,0x400(%rsp)
  1beb6f:	je     1bec7c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xa5c>
  1beb75:	mov    $0x1,%r15b
  1beb78:	mov    0x100(%rsp),%rsi
  1beb80:	test   %rsi,%rsi
  1beb83:	je     1beb9f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x97f>
  1beb85:	mov    0x108(%rsp),%rdi
  1beb8d:	shl    $0x2,%rsi
  1beb91:	mov    $0x4,%edx
  1beb96:	vzeroupper
  1beb99:	call   *0x97299(%rip)        # 255e38 <_DYNAMIC+0x200>
  1beb9f:	mov    0x118(%rsp),%rsi
  1beba7:	test   %rsi,%rsi
  1bebaa:	je     1bebc6 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x9a6>
  1bebac:	mov    0x120(%rsp),%rdi
  1bebb4:	shl    $0x2,%rsi
  1bebb8:	mov    $0x4,%edx
  1bebbd:	vzeroupper
  1bebc0:	call   *0x97272(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bebc6:	mov    0xe8(%rsp),%rsi
  1bebce:	test   %rsi,%rsi
  1bebd1:	je     1bebed <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x9cd>
  1bebd3:	mov    0xf0(%rsp),%rdi
  1bebdb:	shl    $0x3,%rsi
  1bebdf:	mov    $0x8,%edx
  1bebe4:	vzeroupper
  1bebe7:	call   *0x9724b(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bebed:	mov    0x98(%rsp),%rsi
  1bebf5:	test   %rsi,%rsi
  1bebf8:	je     1bec14 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x9f4>
  1bebfa:	mov    0xa0(%rsp),%rdi
  1bec02:	shl    $0x3,%rsi
  1bec06:	mov    $0x8,%edx
  1bec0b:	vzeroupper
  1bec0e:	call   *0x97224(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bec14:	mov    0x140(%rsp),%rsi
  1bec1c:	test   %rsi,%rsi
  1bec1f:	je     1bec3b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xa1b>
  1bec21:	mov    0x148(%rsp),%rdi
  1bec29:	shl    $0x2,%rsi
  1bec2d:	mov    $0x4,%edx
  1bec32:	vzeroupper
  1bec35:	call   *0x971fd(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bec3b:	test   %r15b,%r15b
  1bec3e:	je     1c004e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1e2e>
  1bec44:	mov    0x1a0(%rsp),%rsi
  1bec4c:	mov    0x90(%rsp),%r14
  1bec54:	test   %rsi,%rsi
  1bec57:	je     1bea25 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x805>
  1bec5d:	mov    0x1a8(%rsp),%rdi
  1bec65:	shl    $0x3,%rsi
  1bec69:	mov    $0x4,%edx
  1bec6e:	vzeroupper
  1bec71:	call   *0x971c1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bec77:	jmp    1bea25 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x805>
  1bec7c:	mov    0x408(%rsp),%rax
  1bec84:	mov    %rax,0xa0(%rsp)
  1bec8c:	movq   $0x1,0x98(%rsp)
  1bec98:	mov    0xa8(%rsp),%r14
  1beca0:	cmp    $0x1,%r14
  1beca4:	jne    1becc2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xaa2>
  1beca6:	mov    $0x1,%al
  1beca8:	mov    %eax,0x30(%rsp)
  1becac:	lea    0x98(%rsp),%rdi
  1becb4:	call   *0x977e6(%rip)        # 2564a0 <_DYNAMIC+0x868>
  1becba:	mov    0xa0(%rsp),%rax
  1becc2:	movq   $0x0,(%rax,%r14,8)
  1becca:	mov    %rbp,%rax
  1beccd:	shr    $1,%rax
  1becd0:	mov    %rbp,%rcx
  1becd3:	inc    %r14
  1becd6:	lea    0x93233(%rip),%rsi        # 251f10 <__frame_dummy_init_array_entry+0x2c30>
  1becdd:	lea    0x9325c(%rip),%rdx        # 251f40 <__frame_dummy_init_array_entry+0x2c60>
  1bece4:	movq   $0x0,0x68(%rsp)
  1beced:	sub    %rax,%rcx
  1becf0:	mov    %r14,0xa8(%rsp)
  1becf8:	mov    %rsi,0x2f8(%rsp)
  1bed00:	mov    %rdx,0x88(%rsp)
  1bed08:	mov    %rcx,%rax
  1bed0b:	shl    $0x7,%rax
  1bed0f:	mov    %rcx,0x300(%rsp)
  1bed17:	mov    %rax,0x330(%rsp)
  1bed1f:	lea    0x0(,%rcx,4),%rax
  1bed27:	shl    $0x20,%rcx
  1bed2b:	mov    %rcx,0x320(%rsp)
  1bed33:	xor    %ecx,%ecx
  1bed35:	mov    %rax,0x328(%rsp)
  1bed3d:	mov    $0x1,%al
  1bed3f:	mov    %eax,0x18c(%rsp)
  1bed46:	mov    0x300(%rsp),%rax
  1bed4e:	lea    0x1(%rcx),%rsi
  1bed52:	mov    %rcx,%rdx
  1bed55:	imul   %rax,%rsi
  1bed59:	cmp    %rsi,%rbp
  1bed5c:	cmovb  %rbp,%rsi
  1bed60:	imul   %rax,%rdx
  1bed64:	mov    %rsi,%rax
  1bed67:	mov    %rsi,0x340(%rsp)
  1bed6f:	mov    %rdx,0x30(%rsp)
  1bed74:	sub    %rdx,%rax
  1bed77:	mov    $0x0,%edx
  1bed7c:	cmovae %rax,%rdx
  1bed80:	add    $0x3ff,%rdx
  1bed87:	shr    $0xa,%rdx
  1bed8b:	mov    %rdx,0x318(%rsp)
  1bed93:	je     1bfde7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1bc7>
  1bed99:	mov    0x330(%rsp),%rax
  1beda1:	mov    0x328(%rsp),%rdx
  1beda9:	imul   %rcx,%rax
  1bedad:	imul   %rcx,%rdx
  1bedb1:	imul   0x320(%rsp),%rcx
  1bedba:	add    0x50(%rsp),%rax
  1bedbf:	add    0x138(%rsp),%rdx
  1bedc7:	mov    %rax,0x308(%rsp)
  1bedcf:	movabs $0x100000000,%rax
  1bedd9:	mov    %rdx,0x160(%rsp)
  1bede1:	add    %rax,%rcx
  1bede4:	mov    %rcx,0x310(%rsp)
  1bedec:	jmp    1bee41 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xc21>
  1bedee:	mov    0x318(%rsp),%rcx
  1bedf6:	movabs $0x40000000000,%rax
  1bee00:	addq   $0x20000,0x308(%rsp)
  1bee0c:	addq   $0x1000,0x160(%rsp)
  1bee18:	add    %rax,0x310(%rsp)
  1bee20:	mov    0x338(%rsp),%rax
  1bee28:	dec    %rcx
  1bee2b:	mov    %rax,0x30(%rsp)
  1bee30:	mov    %rcx,0x318(%rsp)
  1bee38:	test   %rcx,%rcx
  1bee3b:	je     1bfde7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1bc7>
  1bee41:	mov    0x30(%rsp),%r14
  1bee46:	mov    0x340(%rsp),%rax
  1bee4e:	mov    $0x800,%edx
  1bee53:	lea    0x400(%rsp),%rdi
  1bee5b:	movq   $0x0,0x1b0(%rsp)
  1bee67:	lea    0x400(%r14),%r13
  1bee6e:	cmp    %r13,%rax
  1bee71:	mov    %r13,0x338(%rsp)
  1bee79:	cmovb  %rax,%r13
  1bee7d:	xor    %esi,%esi
  1bee7f:	vzeroupper
  1bee82:	call   *0x971a8(%rip)        # 256030 <memset@GLIBC_2.2.5>
  1bee88:	mov    $0x1,%al
  1bee8a:	mov    %r13,0x58(%rsp)
  1bee8f:	mov    %eax,0xe0(%rsp)
  1bee96:	cmp    %r13,%r14
  1bee99:	jae    1bf57f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x135f>
  1bee9f:	mov    0x310(%rsp),%r9
  1beea7:	mov    0x308(%rsp),%r10
  1beeaf:	mov    0x160(%rsp),%rdi
  1beeb7:	mov    0x58(%rsp),%r8
  1beebc:	movabs $0x100000000,%rdx
  1beec6:	mov    $0xffffffff,%esi
  1beecb:	xor    %r11d,%r11d
  1beece:	movq   $0x0,0x20(%rsp)
  1beed7:	jmp    1bef07 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xce7>
  1beed9:	mov    0x38(%rsp),%rax
  1beede:	mov    0x28(%rsp),%r14
  1beee3:	add    %r9,%rcx
  1beee6:	mov    %rcx,(%rax,%r14,8)
  1beeea:	mov    0x30(%rsp),%rax
  1beeef:	sub    $0xffffffffffffff80,%r10
  1beef3:	add    %rdx,%r9
  1beef6:	lea    0x1(%rax,%r11,1),%rax
  1beefb:	inc    %r11
  1beefe:	cmp    %r8,%rax
  1bef01:	jae    1bf59d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x137d>
  1bef07:	mov    (%rdi,%r11,4),%ecx
  1bef0b:	cmp    %rsi,%rcx
  1bef0e:	je     1beeea <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xcca>
  1bef10:	mov    %rcx,0x28(%rsp)
  1bef15:	cmp    %rcx,0x40(%rsp)
  1bef1a:	jbe    1c0e9b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2c7b>
  1bef20:	mov    0x38(%rsp),%rax
  1bef25:	mov    (%rax,%rcx,8),%r13
  1bef29:	movzwl %r13w,%ecx
  1bef2d:	cmp    $0x2,%rcx
  1bef31:	jb     1beeea <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xcca>
  1bef33:	vmovdqu (%r10),%ymm0
  1bef38:	vptest %ymm0,%ymm0
  1bef3d:	jne    1bef66 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xd46>
  1bef3f:	vmovdqu 0x20(%r10),%ymm0
  1bef45:	vptest %ymm0,%ymm0
  1bef4a:	jne    1bef66 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xd46>
  1bef4c:	vmovdqu 0x40(%r10),%ymm0
  1bef52:	vptest %ymm0,%ymm0
  1bef57:	jne    1bef66 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xd46>
  1bef59:	vmovdqu 0x60(%r10),%ymm0
  1bef5f:	vptest %ymm0,%ymm0
  1bef64:	je     1beeea <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xcca>
  1bef66:	mov    %r13,%rax
  1bef69:	shr    $0x20,%rax
  1bef6d:	je     1beed9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xcb9>
  1bef73:	dec    %rax
  1bef76:	mov    %rax,%r14
  1bef79:	sub    0x30(%rsp),%r14
  1bef7e:	mov    %r14,0x68(%rsp)
  1bef83:	jb     1beed9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xcb9>
  1bef89:	shr    $0x10,%r13d
  1bef8d:	mov    %rax,0x1b8(%rsp)
  1bef95:	cmp    $0xffff,%r13d
  1bef9c:	je     1beeea <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xcca>
  1befa2:	mov    %r11,0x60(%rsp)
  1befa7:	mov    %r10,0x158(%rsp)
  1befaf:	mov    %r9,0x130(%rsp)
  1befb7:	test   %r13,%r13
  1befba:	je     1bf045 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xe25>
  1befc0:	lea    -0x1(%r13),%rcx
  1befc4:	mov    %rcx,0x28(%rsp)
  1befc9:	cmp    0x20(%rsp),%rcx
  1befce:	jae    1c0f3e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2d1e>
  1befd4:	movzwl 0x60(%rsp),%ecx
  1befd9:	mov    %rcx,0x28(%rsp)
  1befde:	cmp    $0x3ff,%rcx
  1befe5:	ja     1c0f51 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2d31>
  1befeb:	mov    0x70(%rsp),%rdx
  1beff0:	mov    0x28(%rsp),%rax
  1beff5:	mov    0x60(%rsp),%r11
  1beffa:	mov    0x160(%rsp),%rdi
  1bf002:	mov    0x58(%rsp),%r8
  1bf007:	mov    0x130(%rsp),%r9
  1bf00f:	mov    0x158(%rsp),%r10
  1bf017:	mov    $0xffffffff,%esi
  1bf01c:	movzwl -0x4(%rdx,%r13,8),%ecx
  1bf022:	mov    %cx,0x400(%rsp,%rax,2)
  1bf02a:	mov    %r11w,-0x4(%rdx,%r13,8)
  1bf030:	incw   -0x2(%rdx,%r13,8)
  1bf036:	movabs $0x100000000,%rdx
  1bf040:	jmp    1beeea <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xcca>
  1bf045:	mov    0x28(%rsp),%rax
  1bf04a:	cmp    %rax,0x190(%rsp)
  1bf052:	jbe    1c1034 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e14>
  1bf058:	mov    0x28(%rsp),%rax
  1bf05d:	mov    0x198(%rsp),%rcx
  1bf065:	shl    $0x5,%rax
  1bf069:	vmovdqu (%rcx,%rax,1),%ymm0
  1bf06e:	vmovdqu %ymm0,0x280(%rsp)
  1bf077:	lea    0x1c0(%rsp),%rdi
  1bf07f:	lea    0x280(%rsp),%rsi
  1bf087:	vzeroupper
  1bf08a:	call   1c4890 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine6g2_phi9phi_split>
  1bf08f:	mov    0x1d0(%rsp),%rdx
  1bf097:	mov    0x1c0(%rsp),%rcx
  1bf09f:	lea    (%rdx,%rdx,1),%r9d
  1bf0a3:	lea    (%rcx,%rcx,1),%edi
  1bf0a6:	mov    %edx,%r8d
  1bf0a9:	and    $0xfff,%r8d
  1bf0b0:	mov    %ecx,%eax
  1bf0b2:	and    $0xfff,%eax
  1bf0b7:	and    $0x1000,%r9d
  1bf0be:	and    $0x1000,%edi
  1bf0c4:	cmp    %r9,%r8
  1bf0c7:	setne  %sil
  1bf0cb:	cmp    %rdi,%rax
  1bf0ce:	setne  %r10b
  1bf0d2:	test   %sil,%r10b
  1bf0d5:	jne    1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf0db:	xor    %esi,%esi
  1bf0dd:	cmp    %edi,%eax
  1bf0df:	mov    %rdx,%rdi
  1bf0e2:	setne  %sil
  1bf0e6:	xor    %eax,%eax
  1bf0e8:	cmp    %r9d,%r8d
  1bf0eb:	setne  %al
  1bf0ee:	shr    $0xb,%rdi
  1bf0f2:	mov    %edi,%r8d
  1bf0f5:	and    $0x1fff,%r8d
  1bf0fc:	and    $0x1000,%edi
  1bf102:	add    %rax,%rsi
  1bf105:	xor    %eax,%eax
  1bf107:	inc    %r8d
  1bf10a:	shr    $1,%r8d
  1bf10d:	cmp    %edi,%r8d
  1bf110:	setne  %al
  1bf113:	add    %rsi,%rax
  1bf116:	cmp    $0x2,%rax
  1bf11a:	jae    1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf120:	mov    %rcx,%rsi
  1bf123:	shr    $0xb,%rsi
  1bf127:	xor    %r8d,%r8d
  1bf12a:	mov    %esi,%edi
  1bf12c:	and    $0x1fff,%edi
  1bf132:	and    $0x1000,%esi
  1bf138:	inc    %edi
  1bf13a:	shr    $1,%edi
  1bf13c:	cmp    %esi,%edi
  1bf13e:	setne  %r8b
  1bf142:	add    %r8,%rax
  1bf145:	cmp    $0x1,%rax
  1bf149:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf14f:	mov    %rdx,%rsi
  1bf152:	shr    $0x17,%rsi
  1bf156:	xor    %r8d,%r8d
  1bf159:	mov    %esi,%edi
  1bf15b:	and    $0x1fff,%edi
  1bf161:	and    $0x1000,%esi
  1bf167:	inc    %edi
  1bf169:	shr    $1,%edi
  1bf16b:	cmp    %esi,%edi
  1bf16d:	setne  %r8b
  1bf171:	add    %r8,%rax
  1bf174:	cmp    $0x1,%rax
  1bf178:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf17e:	mov    %rcx,%rsi
  1bf181:	shr    $0x17,%rsi
  1bf185:	xor    %r8d,%r8d
  1bf188:	mov    %esi,%edi
  1bf18a:	and    $0x1fff,%edi
  1bf190:	and    $0x1000,%esi
  1bf196:	inc    %edi
  1bf198:	shr    $1,%edi
  1bf19a:	cmp    %esi,%edi
  1bf19c:	setne  %r8b
  1bf1a0:	add    %r8,%rax
  1bf1a3:	cmp    $0x1,%rax
  1bf1a7:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf1ad:	mov    %rdx,%rsi
  1bf1b0:	shr    $0x23,%rsi
  1bf1b4:	xor    %r8d,%r8d
  1bf1b7:	mov    %esi,%edi
  1bf1b9:	and    $0x1fff,%edi
  1bf1bf:	and    $0x1000,%esi
  1bf1c5:	inc    %edi
  1bf1c7:	shr    $1,%edi
  1bf1c9:	cmp    %esi,%edi
  1bf1cb:	setne  %r8b
  1bf1cf:	add    %r8,%rax
  1bf1d2:	cmp    $0x1,%rax
  1bf1d6:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf1dc:	mov    %rcx,%rsi
  1bf1df:	shr    $0x23,%rsi
  1bf1e3:	xor    %r8d,%r8d
  1bf1e6:	mov    %esi,%edi
  1bf1e8:	and    $0x1fff,%edi
  1bf1ee:	and    $0x1000,%esi
  1bf1f4:	inc    %edi
  1bf1f6:	shr    $1,%edi
  1bf1f8:	cmp    %esi,%edi
  1bf1fa:	setne  %r8b
  1bf1fe:	add    %r8,%rax
  1bf201:	cmp    $0x1,%rax
  1bf205:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf20b:	mov    %rdx,%rsi
  1bf20e:	shr    $0x2f,%rsi
  1bf212:	xor    %r8d,%r8d
  1bf215:	mov    %esi,%edi
  1bf217:	and    $0x1fff,%edi
  1bf21d:	and    $0x1000,%esi
  1bf223:	inc    %edi
  1bf225:	shr    $1,%edi
  1bf227:	cmp    %esi,%edi
  1bf229:	setne  %r8b
  1bf22d:	add    %r8,%rax
  1bf230:	cmp    $0x1,%rax
  1bf234:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf23a:	mov    %rcx,%rsi
  1bf23d:	shr    $0x2f,%rsi
  1bf241:	xor    %r8d,%r8d
  1bf244:	mov    %esi,%edi
  1bf246:	and    $0x1fff,%edi
  1bf24c:	and    $0x1000,%esi
  1bf252:	inc    %edi
  1bf254:	shr    $1,%edi
  1bf256:	cmp    %esi,%edi
  1bf258:	setne  %r8b
  1bf25c:	add    %r8,%rax
  1bf25f:	cmp    $0x1,%rax
  1bf263:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf269:	mov    0x1d8(%rsp),%rsi
  1bf271:	xor    %r8d,%r8d
  1bf274:	shrd   $0x3b,%rsi,%rdx
  1bf279:	mov    %edx,%edi
  1bf27b:	and    $0x1fff,%edi
  1bf281:	and    $0x1000,%edx
  1bf287:	inc    %edi
  1bf289:	shr    $1,%edi
  1bf28b:	cmp    %edx,%edi
  1bf28d:	setne  %r8b
  1bf291:	add    %r8,%rax
  1bf294:	cmp    $0x1,%rax
  1bf298:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf29e:	mov    0x1c8(%rsp),%rdx
  1bf2a6:	xor    %r8d,%r8d
  1bf2a9:	shrd   $0x3b,%rdx,%rcx
  1bf2ae:	mov    %ecx,%edi
  1bf2b0:	and    $0x1fff,%edi
  1bf2b6:	and    $0x1000,%ecx
  1bf2bc:	inc    %edi
  1bf2be:	shr    $1,%edi
  1bf2c0:	cmp    %ecx,%edi
  1bf2c2:	setne  %r8b
  1bf2c6:	add    %r8,%rax
  1bf2c9:	cmp    $0x1,%rax
  1bf2cd:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf2d3:	mov    %rsi,%rcx
  1bf2d6:	shr    $0x7,%rcx
  1bf2da:	xor    %r8d,%r8d
  1bf2dd:	mov    %ecx,%edi
  1bf2df:	and    $0x1fff,%edi
  1bf2e5:	and    $0x1000,%ecx
  1bf2eb:	inc    %edi
  1bf2ed:	shr    $1,%edi
  1bf2ef:	cmp    %ecx,%edi
  1bf2f1:	setne  %r8b
  1bf2f5:	add    %r8,%rax
  1bf2f8:	cmp    $0x1,%rax
  1bf2fc:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf302:	mov    %rdx,%rcx
  1bf305:	shr    $0x7,%rcx
  1bf309:	xor    %r8d,%r8d
  1bf30c:	mov    %ecx,%edi
  1bf30e:	and    $0x1fff,%edi
  1bf314:	and    $0x1000,%ecx
  1bf31a:	inc    %edi
  1bf31c:	shr    $1,%edi
  1bf31e:	cmp    %ecx,%edi
  1bf320:	setne  %r8b
  1bf324:	add    %r8,%rax
  1bf327:	cmp    $0x1,%rax
  1bf32b:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf331:	mov    %rsi,%rcx
  1bf334:	shr    $0x13,%rcx
  1bf338:	xor    %r8d,%r8d
  1bf33b:	mov    %ecx,%edi
  1bf33d:	and    $0x1fff,%edi
  1bf343:	and    $0x1000,%ecx
  1bf349:	inc    %edi
  1bf34b:	shr    $1,%edi
  1bf34d:	cmp    %ecx,%edi
  1bf34f:	setne  %r8b
  1bf353:	add    %r8,%rax
  1bf356:	cmp    $0x1,%rax
  1bf35a:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf360:	mov    %rdx,%rcx
  1bf363:	shr    $0x13,%rcx
  1bf367:	xor    %r8d,%r8d
  1bf36a:	mov    %ecx,%edi
  1bf36c:	and    $0x1fff,%edi
  1bf372:	and    $0x1000,%ecx
  1bf378:	inc    %edi
  1bf37a:	shr    $1,%edi
  1bf37c:	cmp    %ecx,%edi
  1bf37e:	setne  %r8b
  1bf382:	add    %r8,%rax
  1bf385:	cmp    $0x1,%rax
  1bf389:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf38f:	mov    %rsi,%rcx
  1bf392:	shr    $0x1f,%rcx
  1bf396:	xor    %r8d,%r8d
  1bf399:	mov    %ecx,%edi
  1bf39b:	and    $0x1fff,%edi
  1bf3a1:	and    $0x1000,%ecx
  1bf3a7:	inc    %edi
  1bf3a9:	shr    $1,%edi
  1bf3ab:	cmp    %ecx,%edi
  1bf3ad:	setne  %r8b
  1bf3b1:	add    %r8,%rax
  1bf3b4:	cmp    $0x1,%rax
  1bf3b8:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf3be:	mov    %rdx,%rcx
  1bf3c1:	shr    $0x1f,%rcx
  1bf3c5:	xor    %r8d,%r8d
  1bf3c8:	mov    %ecx,%edi
  1bf3ca:	and    $0x1fff,%edi
  1bf3d0:	and    $0x1000,%ecx
  1bf3d6:	inc    %edi
  1bf3d8:	shr    $1,%edi
  1bf3da:	cmp    %ecx,%edi
  1bf3dc:	setne  %r8b
  1bf3e0:	add    %r8,%rax
  1bf3e3:	cmp    $0x1,%rax
  1bf3e7:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf3ed:	mov    %rsi,%rcx
  1bf3f0:	shr    $0x2b,%rcx
  1bf3f4:	xor    %r8d,%r8d
  1bf3f7:	mov    %ecx,%edi
  1bf3f9:	and    $0x1fff,%edi
  1bf3ff:	and    $0x1000,%ecx
  1bf405:	inc    %edi
  1bf407:	shr    $1,%edi
  1bf409:	cmp    %ecx,%edi
  1bf40b:	setne  %r8b
  1bf40f:	add    %r8,%rax
  1bf412:	cmp    $0x1,%rax
  1bf416:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf418:	mov    %rdx,%rcx
  1bf41b:	shr    $0x2b,%rcx
  1bf41f:	xor    %r8d,%r8d
  1bf422:	mov    %ecx,%edi
  1bf424:	and    $0x1fff,%edi
  1bf42a:	and    $0x1000,%ecx
  1bf430:	inc    %edi
  1bf432:	shr    $1,%edi
  1bf434:	cmp    %ecx,%edi
  1bf436:	setne  %r8b
  1bf43a:	add    %r8,%rax
  1bf43d:	cmp    $0x1,%rax
  1bf441:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf443:	movabs $0x7f80000000000000,%rcx
  1bf44d:	and    %rcx,%rsi
  1bf450:	cmp    $0x1,%rsi
  1bf454:	sbb    $0xffffffffffffffff,%rax
  1bf458:	cmp    $0x1,%rax
  1bf45c:	ja     1bf473 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1253>
  1bf45e:	and    %rcx,%rdx
  1bf461:	cmp    $0x1,%rdx
  1bf465:	sbb    $0xffffffffffffffff,%rax
  1bf469:	cmp    $0x1,%rax
  1bf46d:	jbe    1bf55e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x133e>
  1bf473:	movzwl 0x68(%rsp),%eax
  1bf478:	cmp    $0x3ff,%rax
  1bf47e:	ja     1c104d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e2d>
  1bf484:	movzwl 0x60(%rsp),%r14d
  1bf48a:	movw   $0xffff,0x400(%rsp,%rax,2)
  1bf494:	cmp    $0x3ff,%r14
  1bf49b:	ja     1c1068 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e48>
  1bf4a1:	mov    0x68(%rsp),%rax
  1bf4a6:	mov    0x20(%rsp),%rcx
  1bf4ab:	mov    %ax,0x400(%rsp,%r14,2)
  1bf4b4:	cmp    0x1a0(%rsp),%rcx
  1bf4bc:	jne    1bf4d9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x12b9>
  1bf4be:	lea    0x1a0(%rsp),%rdi
  1bf4c6:	call   *0x96f7c(%rip)        # 256448 <_DYNAMIC+0x810>
  1bf4cc:	mov    0x1a8(%rsp),%rax
  1bf4d4:	mov    %rax,0x70(%rsp)
  1bf4d9:	mov    0x1b8(%rsp),%rdx
  1bf4e1:	mov    0x70(%rsp),%rsi
  1bf4e6:	mov    0x20(%rsp),%rcx
  1bf4eb:	shl    $0x20,%r14
  1bf4ef:	movabs $0x2000000000000,%rax
  1bf4f9:	add    %rax,%r14
  1bf4fc:	add    %r14,%rdx
  1bf4ff:	mov    %rdx,(%rsi,%rcx,8)
  1bf503:	mov    0x38(%rsp),%rsi
  1bf508:	mov    0x28(%rsp),%rdx
  1bf50d:	inc    %rcx
  1bf510:	mov    %rcx,%rax
  1bf513:	shl    $0x10,%rax
  1bf517:	mov    %rcx,0x1b0(%rsp)
  1bf51f:	mov    %rcx,0x20(%rsp)
  1bf524:	or     %rax,(%rsi,%rdx,8)
  1bf528:	movabs $0x100000000,%rdx
  1bf532:	mov    0x160(%rsp),%rdi
  1bf53a:	mov    0x58(%rsp),%r8
  1bf53f:	mov    0x130(%rsp),%r9
  1bf547:	mov    0x158(%rsp),%r10
  1bf54f:	mov    0x60(%rsp),%r11
  1bf554:	mov    $0xffffffff,%esi
  1bf559:	jmp    1beeea <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xcca>
  1bf55e:	mov    0x38(%rsp),%rcx
  1bf563:	mov    0x28(%rsp),%rsi
  1bf568:	movabs $0x100000000,%rdx
  1bf572:	lea    -0x10000(%rdx),%rax
  1bf579:	or     %rax,(%rcx,%rsi,8)
  1bf57d:	jmp    1bf532 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1312>
  1bf57f:	mov    0x70(%rsp),%rax
  1bf584:	xor    %r14d,%r14d
  1bf587:	movq   $0x0,0x20(%rsp)
  1bf590:	mov    %rax,0x130(%rsp)
  1bf598:	jmp    1bf933 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1713>
  1bf59d:	mov    0x1a8(%rsp),%rax
  1bf5a5:	mov    0x20(%rsp),%rcx
  1bf5aa:	mov    %rax,0x70(%rsp)
  1bf5af:	lea    (%rax,%rcx,8),%rax
  1bf5b3:	mov    %rax,0x130(%rsp)
  1bf5bb:	test   %rcx,%rcx
  1bf5be:	je     1bf5d2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x13b2>
  1bf5c0:	cmpq   $0x9,0x20(%rsp)
  1bf5c6:	jae    1bf5f0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x13d0>
  1bf5c8:	xor    %eax,%eax
  1bf5ca:	xor    %r14d,%r14d
  1bf5cd:	jmp    1bf734 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1514>
  1bf5d2:	mov    0x128(%rsp),%rax
  1bf5da:	xor    %r14d,%r14d
  1bf5dd:	movq   $0x0,0x20(%rsp)
  1bf5e6:	mov    %rax,0x68(%rsp)
  1bf5eb:	jmp    1bf933 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1713>
  1bf5f0:	cmpq   $0x21,0x20(%rsp)
  1bf5f6:	jae    1bf602 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x13e2>
  1bf5f8:	xor    %eax,%eax
  1bf5fa:	xor    %r14d,%r14d
  1bf5fd:	jmp    1bf6c5 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x14a5>
  1bf602:	mov    0x20(%rsp),%rdx
  1bf607:	vpbroadcastq -0x188861(%rip),%zmm5        # 36db0 <GCC_except_table151+0x416c>
  1bf611:	mov    0x70(%rsp),%rsi
  1bf616:	mov    $0x20,%eax
  1bf61b:	vpxor  %xmm0,%xmm0,%xmm0
  1bf61f:	vpxor  %xmm1,%xmm1,%xmm1
  1bf623:	vpxor  %xmm2,%xmm2,%xmm2
  1bf627:	vpxor  %xmm3,%xmm3,%xmm3
  1bf62b:	mov    %edx,%ecx
  1bf62d:	and    $0x1f,%ecx
  1bf630:	cmove  %rax,%rcx
  1bf634:	mov    %rdx,%rax
  1bf637:	xor    %edx,%edx
  1bf639:	sub    %rcx,%rax
  1bf63c:	vpandq 0x46(%rsi,%rdx,8),%zmm5,%zmm6
  1bf647:	vpandq 0x6(%rsi,%rdx,8),%zmm5,%zmm4
  1bf652:	vpandq 0x86(%rsi,%rdx,8),%zmm5,%zmm7
  1bf65d:	vpaddq %zmm6,%zmm1,%zmm1
  1bf663:	vpandq 0xc6(%rsi,%rdx,8),%zmm5,%zmm6
  1bf66e:	vpaddq %zmm4,%zmm0,%zmm0
  1bf674:	vpaddq %zmm7,%zmm2,%zmm2
  1bf67a:	add    $0x20,%rdx
  1bf67e:	vpaddq %zmm6,%zmm3,%zmm3
  1bf684:	cmp    %rdx,%rax
  1bf687:	jne    1bf63c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x141c>
  1bf689:	vpaddq %zmm0,%zmm1,%zmm0
  1bf68f:	vpaddq %zmm0,%zmm2,%zmm0
  1bf695:	vpaddq %zmm0,%zmm3,%zmm0
  1bf69b:	vextracti64x4 $0x1,%zmm0,%ymm1
  1bf6a2:	vpaddq %zmm1,%zmm0,%zmm0
  1bf6a8:	vextracti128 $0x1,%ymm0,%xmm1
  1bf6ae:	vpaddq %xmm1,%xmm0,%xmm0
  1bf6b2:	vpshufd $0xee,%xmm0,%xmm1
  1bf6b7:	vpaddq %xmm1,%xmm0,%xmm0
  1bf6bb:	vmovq  %xmm0,%r14
  1bf6c0:	cmp    $0x9,%ecx
  1bf6c3:	jb     1bf734 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1514>
  1bf6c5:	mov    0x20(%rsp),%rsi
  1bf6ca:	vpbroadcastq -0x188924(%rip),%zmm2        # 36db0 <GCC_except_table151+0x416c>
  1bf6d4:	mov    %rax,%rcx
  1bf6d7:	mov    $0x8,%eax
  1bf6dc:	vmovq  %r14,%xmm0
  1bf6e1:	mov    %esi,%edx
  1bf6e3:	and    $0x7,%edx
  1bf6e6:	cmove  %rax,%rdx
  1bf6ea:	mov    %rsi,%rax
  1bf6ed:	sub    %rdx,%rax
  1bf6f0:	mov    0x70(%rsp),%rdx
  1bf6f5:	vpandq 0x6(%rdx,%rcx,8),%zmm2,%zmm1
  1bf700:	add    $0x8,%rcx
  1bf704:	vpaddq %zmm1,%zmm0,%zmm0
  1bf70a:	cmp    %rcx,%rax
  1bf70d:	jne    1bf6f5 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x14d5>
  1bf70f:	vextracti64x4 $0x1,%zmm0,%ymm1
  1bf716:	vpaddq %zmm1,%zmm0,%zmm0
  1bf71c:	vextracti128 $0x1,%ymm0,%xmm1
  1bf722:	vpaddq %xmm1,%xmm0,%xmm0
  1bf726:	vpshufd $0xee,%xmm0,%xmm1
  1bf72b:	vpaddq %xmm1,%xmm0,%xmm0
  1bf72f:	vmovq  %xmm0,%r14
  1bf734:	mov    0x70(%rsp),%rdx
  1bf739:	mov    0x20(%rsp),%rsi
  1bf73e:	movzwl 0x6(%rdx,%rax,8),%ecx
  1bf743:	inc    %rax
  1bf746:	add    %rcx,%r14
  1bf749:	cmp    %rax,%rsi
  1bf74c:	jne    1bf73e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x151e>
  1bf74e:	mov    0x140(%rsp),%rsi
  1bf756:	mov    0x150(%rsp),%r13
  1bf75e:	mov    %rsi,%rax
  1bf761:	sub    %r13,%rax
  1bf764:	cmp    %rax,%r14
  1bf767:	jbe    1bf7bf <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x159f>
  1bf769:	add    %r14,%r13
  1bf76c:	jb     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf772:	mov    0x148(%rsp),%rdx
  1bf77a:	mov    $0x4,%r8d
  1bf780:	mov    $0x4,%r9d
  1bf786:	lea    0x1c0(%rsp),%rdi
  1bf78e:	mov    %r13,%rcx
  1bf791:	vzeroupper
  1bf794:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bf799:	cmpl   $0x1,0x1c0(%rsp)
  1bf7a1:	je     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf7a7:	mov    0x1c8(%rsp),%rax
  1bf7af:	mov    %rax,0x148(%rsp)
  1bf7b7:	mov    %r13,0x140(%rsp)
  1bf7bf:	mov    0x98(%rsp),%rsi
  1bf7c7:	mov    0xa8(%rsp),%r13
  1bf7cf:	mov    %rsi,%rax
  1bf7d2:	sub    %r13,%rax
  1bf7d5:	cmp    %rax,0x20(%rsp)
  1bf7da:	jbe    1bf834 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1614>
  1bf7dc:	add    0x20(%rsp),%r13
  1bf7e1:	jb     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf7e7:	mov    0xa0(%rsp),%rdx
  1bf7ef:	mov    $0x8,%r8d
  1bf7f5:	mov    $0x8,%r9d
  1bf7fb:	lea    0x1c0(%rsp),%rdi
  1bf803:	mov    %r13,%rcx
  1bf806:	vzeroupper
  1bf809:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bf80e:	cmpl   $0x1,0x1c0(%rsp)
  1bf816:	je     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf81c:	mov    0x1c8(%rsp),%rax
  1bf824:	mov    %rax,0xa0(%rsp)
  1bf82c:	mov    %r13,0x98(%rsp)
  1bf834:	mov    0xe8(%rsp),%rsi
  1bf83c:	mov    0xf8(%rsp),%r13
  1bf844:	mov    %rsi,%rax
  1bf847:	sub    %r13,%rax
  1bf84a:	cmp    %rax,0x20(%rsp)
  1bf84f:	jbe    1bf8a9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1689>
  1bf851:	add    0x20(%rsp),%r13
  1bf856:	jb     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf85c:	mov    0xf0(%rsp),%rdx
  1bf864:	mov    $0x8,%r8d
  1bf86a:	mov    $0x8,%r9d
  1bf870:	lea    0x1c0(%rsp),%rdi
  1bf878:	mov    %r13,%rcx
  1bf87b:	vzeroupper
  1bf87e:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bf883:	cmpl   $0x1,0x1c0(%rsp)
  1bf88b:	je     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf891:	mov    0x1c8(%rsp),%rax
  1bf899:	mov    %rax,0xf0(%rsp)
  1bf8a1:	mov    %r13,0xe8(%rsp)
  1bf8a9:	mov    0x118(%rsp),%rsi
  1bf8b1:	mov    0x128(%rsp),%rdx
  1bf8b9:	mov    %rsi,%rax
  1bf8bc:	sub    %rdx,%rax
  1bf8bf:	mov    %rdx,0x68(%rsp)
  1bf8c4:	cmp    %rax,0x20(%rsp)
  1bf8c9:	jbe    1bf928 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1708>
  1bf8cb:	mov    0x68(%rsp),%r13
  1bf8d0:	add    0x20(%rsp),%r13
  1bf8d5:	jb     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf8db:	mov    0x120(%rsp),%rdx
  1bf8e3:	mov    $0x4,%r8d
  1bf8e9:	mov    $0x4,%r9d
  1bf8ef:	lea    0x1c0(%rsp),%rdi
  1bf8f7:	mov    %r13,%rcx
  1bf8fa:	vzeroupper
  1bf8fd:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bf902:	cmpl   $0x1,0x1c0(%rsp)
  1bf90a:	je     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf910:	mov    0x1c8(%rsp),%rax
  1bf918:	mov    %rax,0x120(%rsp)
  1bf920:	mov    %r13,0x118(%rsp)
  1bf928:	movl   $0x0,0xe0(%rsp)
  1bf933:	mov    0x100(%rsp),%rsi
  1bf93b:	mov    0x110(%rsp),%rdx
  1bf943:	sub    0x20(%rsp),%r14
  1bf948:	mov    $0x0,%r13d
  1bf94e:	cmovae %r14,%r13
  1bf952:	mov    %rsi,%rax
  1bf955:	sub    %rdx,%rax
  1bf958:	mov    %rdx,0x28(%rsp)
  1bf95d:	cmp    %rax,%r13
  1bf960:	jbe    1bf9ba <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x179a>
  1bf962:	add    0x28(%rsp),%r13
  1bf967:	jb     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf96d:	mov    0x108(%rsp),%rdx
  1bf975:	mov    $0x4,%r8d
  1bf97b:	mov    $0x4,%r9d
  1bf981:	lea    0x1c0(%rsp),%rdi
  1bf989:	mov    %r13,%rcx
  1bf98c:	vzeroupper
  1bf98f:	call   1b7020 <_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsHW5vo2gROj_10zopro_core>
  1bf994:	cmpl   $0x1,0x1c0(%rsp)
  1bf99c:	je     1beb75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x955>
  1bf9a2:	mov    0x1c8(%rsp),%rax
  1bf9aa:	mov    %rax,0x108(%rsp)
  1bf9b2:	mov    %r13,0x100(%rsp)
  1bf9ba:	cmpb   $0x0,0xe0(%rsp)
  1bf9c2:	jne    1bedee <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xbce>
  1bf9c8:	mov    0x150(%rsp),%r11
  1bf9d0:	mov    0x70(%rsp),%rax
  1bf9d5:	mov    %r11,0xe0(%rsp)
  1bf9dd:	jmp    1bfa22 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1802>
  1bf9df:	mov    0x60(%rsp),%rcx
  1bf9e4:	mov    0x20(%rsp),%r11
  1bf9e9:	mov    0xa0(%rsp),%rax
  1bf9f1:	mov    %r13,0x68(%rsp)
  1bf9f6:	mov    %r11,(%rax,%r14,8)
  1bf9fa:	add    $0x8,%rcx
  1bf9fe:	inc    %r14
  1bfa01:	mov    %r11,0xe0(%rsp)
  1bfa09:	mov    %r14,0xa8(%rsp)
  1bfa11:	mov    %rcx,%rax
  1bfa14:	cmp    0x130(%rsp),%rcx
  1bfa1c:	je     1bedee <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xbce>
  1bfa22:	movzwl 0x4(%rax),%r13d
  1bfa27:	mov    %rax,0x60(%rsp)
  1bfa2c:	mov    %r13w,0x1c0(%rsp)
  1bfa35:	movzwl 0x6(%rax),%eax
  1bfa39:	mov    %eax,%r14d
  1bfa3c:	mov    %rax,0x1b8(%rsp)
  1bfa44:	test   %rax,%rax
  1bfa47:	je     1bfabe <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x189e>
  1bfa49:	cmp    $0xffff,%r13w
  1bfa4e:	je     1c007e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1e5e>
  1bfa54:	mov    %r11,0x20(%rsp)
  1bfa59:	cmp    0x140(%rsp),%r11
  1bfa61:	jne    1bfa74 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1854>
  1bfa63:	lea    0x140(%rsp),%rdi
  1bfa6b:	vzeroupper
  1bfa6e:	call   *0x969b4(%rip)        # 256428 <_DYNAMIC+0x7f0>
  1bfa74:	movzwl %r13w,%edx
  1bfa78:	mov    0x148(%rsp),%rcx
  1bfa80:	mov    0x20(%rsp),%r11
  1bfa85:	mov    %edx,%eax
  1bfa87:	add    0x30(%rsp),%eax
  1bfa8b:	mov    %eax,(%rcx,%r11,4)
  1bfa8f:	inc    %r11
  1bfa92:	mov    %r11,0x150(%rsp)
  1bfa9a:	cmp    $0x3ff,%r13w
  1bfaa0:	ja     1c0e66 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2c46>
  1bfaa6:	movzwl 0x400(%rsp,%rdx,2),%r13d
  1bfaaf:	dec    %r14w
  1bfab3:	mov    %r13w,0x1c0(%rsp)
  1bfabc:	jne    1bfa49 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1829>
  1bfabe:	cmp    $0xffff,%r13w
  1bfac3:	jne    1c00bf <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1e9f>
  1bfac9:	mov    0xe0(%rsp),%r14
  1bfad1:	mov    0x60(%rsp),%rdx
  1bfad6:	mov    %r11,0x20(%rsp)
  1bfadb:	sub    %r14,%r11
  1bfade:	jb     1c00c3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1ea3>
  1bfae4:	mov    0x148(%rsp),%rax
  1bfaec:	lea    (%rax,%r14,4),%rsi
  1bfaf0:	mov    %rax,0x58(%rsp)
  1bfaf5:	mov    %r11,%rax
  1bfaf8:	shr    $1,%rax
  1bfafb:	je     1bfc5f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1a3f>
  1bfb01:	cmp    $0x10,%r11
  1bfb05:	jae    1bfb0e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x18ee>
  1bfb07:	xor    %ecx,%ecx
  1bfb09:	jmp    1bfc29 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1a09>
  1bfb0e:	cmp    $0x40,%r11
  1bfb12:	jae    1bfb1b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x18fb>
  1bfb14:	xor    %ecx,%ecx
  1bfb16:	jmp    1bfbc4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x19a4>
  1bfb1b:	mov    0x58(%rsp),%r10
  1bfb20:	mov    0x20(%rsp),%r9
  1bfb25:	movabs $0x7fffffffffffffe0,%rdi
  1bfb2f:	mov    %rax,%rcx
  1bfb32:	and    %rdi,%rcx
  1bfb35:	mov    %r11,%rdi
  1bfb38:	shr    $0x6,%rdi
  1bfb3c:	shl    $0x5,%rdi
  1bfb40:	neg    %rdi
  1bfb43:	lea    0x40(%r10,%r14,4),%r8
  1bfb48:	lea    -0x40(%r10,%r9,4),%r9
  1bfb4d:	xor    %r10d,%r10d
  1bfb50:	vpshufd $0x1b,(%r9,%r10,4),%zmm0
  1bfb58:	vpshufd $0x1b,-0x40(%r9,%r10,4),%zmm1
  1bfb61:	vpshufd $0x1b,-0x40(%r8),%zmm2
  1bfb69:	vshufi64x2 $0x1b,%zmm0,%zmm0,%zmm0
  1bfb70:	vshufi64x2 $0x1b,%zmm1,%zmm1,%zmm1
  1bfb77:	vmovdqu64 %zmm0,-0x40(%r8)
  1bfb7e:	vpshufd $0x1b,(%r8),%zmm0
  1bfb85:	vmovdqu64 %zmm1,(%r8)
  1bfb8b:	vshufi64x2 $0x1b,%zmm2,%zmm2,%zmm1
  1bfb92:	sub    $0xffffffffffffff80,%r8
  1bfb96:	vmovdqu64 %zmm1,(%r9,%r10,4)
  1bfb9d:	vshufi64x2 $0x1b,%zmm0,%zmm0,%zmm0
  1bfba4:	vmovdqu64 %zmm0,-0x40(%r9,%r10,4)
  1bfbac:	add    $0xffffffffffffffe0,%r10
  1bfbb0:	cmp    %r10,%rdi
  1bfbb3:	jne    1bfb50 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1930>
  1bfbb5:	cmp    %rcx,%rax
  1bfbb8:	je     1bfc5f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1a3f>
  1bfbbe:	test   $0x30,%r11b
  1bfbc2:	je     1bfc29 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1a09>
  1bfbc4:	mov    0x20(%rsp),%rdi
  1bfbc9:	mov    0x58(%rsp),%r8
  1bfbce:	mov    %rcx,%r9
  1bfbd1:	lea    0x0(,%r9,4),%r10
  1bfbd9:	movabs $0x7fffffffffffffe0,%rcx
  1bfbe3:	add    $0x18,%rcx
  1bfbe7:	and    %rax,%rcx
  1bfbea:	lea    (%r8,%rdi,4),%rdi
  1bfbee:	sub    %r10,%rdi
  1bfbf1:	add    $0xffffffffffffffe0,%rdi
  1bfbf5:	vpshufd $0x1b,(%rdi),%ymm0
  1bfbfa:	vpshufd $0x1b,(%rsi,%r9,4),%ymm1
  1bfc01:	vpermq $0x4e,%ymm0,%ymm0
  1bfc07:	vpermq $0x4e,%ymm1,%ymm1
  1bfc0d:	vmovdqu %ymm0,(%rsi,%r9,4)
  1bfc13:	vmovdqu %ymm1,(%rdi)
  1bfc17:	add    $0x8,%r9
  1bfc1b:	add    $0xffffffffffffffe0,%rdi
  1bfc1f:	cmp    %r9,%rcx
  1bfc22:	jne    1bfbf5 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x19d5>
  1bfc24:	cmp    %rcx,%rax
  1bfc27:	je     1bfc5f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1a3f>
  1bfc29:	mov    0x20(%rsp),%rdi
  1bfc2e:	mov    0x58(%rsp),%r8
  1bfc33:	lea    (%r8,%rdi,4),%r9
  1bfc37:	lea    0x0(,%rcx,4),%r8
  1bfc3f:	sub    %r8,%r9
  1bfc42:	add    $0xfffffffffffffffc,%r9
  1bfc46:	mov    (%rsi,%rcx,4),%edi
  1bfc49:	mov    (%r9),%r8d
  1bfc4c:	mov    %r8d,(%rsi,%rcx,4)
  1bfc50:	mov    %edi,(%r9)
  1bfc53:	inc    %rcx
  1bfc56:	add    $0xfffffffffffffffc,%r9
  1bfc5a:	cmp    %rcx,%rax
  1bfc5d:	jne    1bfc46 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1a26>
  1bfc5f:	mov    0x20(%rsp),%rcx
  1bfc64:	cmp    %r14,%rcx
  1bfc67:	jbe    1c0ecd <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2cad>
  1bfc6d:	mov    (%rsi),%eax
  1bfc6f:	cmp    (%rdx),%eax
  1bfc71:	jne    1c00e9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1ec9>
  1bfc77:	mov    0x100(%rsp),%rsi
  1bfc7f:	mov    %eax,%r13d
  1bfc82:	lea    0x1(%r14),%rax
  1bfc86:	mov    %rcx,%r9
  1bfc89:	mov    %rcx,%rdx
  1bfc8c:	sub    0x28(%rsp),%rsi
  1bfc91:	sub    %rax,%r9
  1bfc94:	cmp    %rsi,%r9
  1bfc97:	ja     1bfd9a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1b7a>
  1bfc9d:	cmp    %rax,%rdx
  1bfca0:	je     1bfcd8 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1ab8>
  1bfca2:	mov    0x58(%rsp),%rax
  1bfca7:	lea    0x0(,%r9,4),%rdx
  1bfcaf:	lea    0x4(%rax,%r14,4),%rsi
  1bfcb4:	mov    0x28(%rsp),%rax
  1bfcb9:	mov    %r9,%r14
  1bfcbc:	lea    0x0(,%rax,4),%rdi
  1bfcc4:	add    0x108(%rsp),%rdi
  1bfccc:	vzeroupper
  1bfccf:	call   *0x961c3(%rip)        # 255e98 <memcpy@GLIBC_2.14>
  1bfcd5:	mov    %r14,%r9
  1bfcd8:	mov    0x28(%rsp),%rcx
  1bfcdd:	mov    0x68(%rsp),%rax
  1bfce2:	add    %r9,%rcx
  1bfce5:	mov    %rcx,0x28(%rsp)
  1bfcea:	mov    %rcx,0x110(%rsp)
  1bfcf2:	cmp    0x118(%rsp),%rax
  1bfcfa:	jne    1bfd0d <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1aed>
  1bfcfc:	lea    0x118(%rsp),%rdi
  1bfd04:	vzeroupper
  1bfd07:	call   *0x9671b(%rip)        # 256428 <_DYNAMIC+0x7f0>
  1bfd0d:	mov    0x120(%rsp),%rax
  1bfd15:	mov    0x68(%rsp),%rcx
  1bfd1a:	mov    %r13d,(%rax,%rcx,4)
  1bfd1e:	inc    %rcx
  1bfd21:	mov    0xf8(%rsp),%r14
  1bfd29:	mov    %rcx,%r13
  1bfd2c:	mov    %rcx,0x128(%rsp)
  1bfd34:	cmp    0xe8(%rsp),%r14
  1bfd3c:	jne    1bfd4f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1b2f>
  1bfd3e:	lea    0xe8(%rsp),%rdi
  1bfd46:	vzeroupper
  1bfd49:	call   *0x96751(%rip)        # 2564a0 <_DYNAMIC+0x868>
  1bfd4f:	mov    0xf0(%rsp),%rax
  1bfd57:	mov    0x1b8(%rsp),%rcx
  1bfd5f:	mov    %rcx,(%rax,%r14,8)
  1bfd63:	inc    %r14
  1bfd66:	mov    %r14,0xf8(%rsp)
  1bfd6e:	mov    0xa8(%rsp),%r14
  1bfd76:	cmp    0x98(%rsp),%r14
  1bfd7e:	jne    1bf9df <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x17bf>
  1bfd84:	lea    0x98(%rsp),%rdi
  1bfd8c:	vzeroupper
  1bfd8f:	call   *0x9670b(%rip)        # 2564a0 <_DYNAMIC+0x868>
  1bfd95:	jmp    1bf9df <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x17bf>
  1bfd9a:	mov    0x28(%rsp),%rsi
  1bfd9f:	mov    $0x4,%ecx
  1bfda4:	mov    $0x4,%r8d
  1bfdaa:	lea    0x100(%rsp),%rdi
  1bfdb2:	mov    %r9,%rdx
  1bfdb5:	mov    %r9,0x158(%rsp)
  1bfdbd:	vzeroupper
  1bfdc0:	call   14ed80 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  1bfdc5:	mov    0x110(%rsp),%rax
  1bfdcd:	mov    0xe0(%rsp),%r14
  1bfdd5:	mov    0x158(%rsp),%r9
  1bfddd:	mov    %rax,0x28(%rsp)
  1bfde2:	jmp    1bfca2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1a82>
  1bfde7:	testb  $0x1,0x18c(%rsp)
  1bfdef:	mov    $0x1,%ecx
  1bfdf4:	movl   $0x0,0x18c(%rsp)
  1bfdff:	jne    1bed46 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0xb26>
  1bfe05:	mov    0x1a0(%rsp),%rsi
  1bfe0d:	test   %rsi,%rsi
  1bfe10:	je     1bfe29 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1c09>
  1bfe12:	mov    0x70(%rsp),%rdi
  1bfe17:	shl    $0x3,%rsi
  1bfe1b:	mov    $0x4,%edx
  1bfe20:	vzeroupper
  1bfe23:	call   *0x9600f(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bfe29:	cmpq   $0x0,0x90(%rsp)
  1bfe32:	je     1bfe56 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1c36>
  1bfe34:	mov    0x90(%rsp),%rsi
  1bfe3c:	mov    0x198(%rsp),%rdi
  1bfe44:	mov    $0x8,%edx
  1bfe49:	shl    $0x5,%rsi
  1bfe4d:	vzeroupper
  1bfe50:	call   *0x95fe2(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bfe56:	cmpq   $0x0,0x80(%rsp)
  1bfe5f:	je     1bfe87 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1c67>
  1bfe61:	mov    0x80(%rsp),%rax
  1bfe69:	mov    0x138(%rsp),%rdi
  1bfe71:	mov    $0x4,%edx
  1bfe76:	lea    0x0(,%rax,4),%rsi
  1bfe7e:	vzeroupper
  1bfe81:	call   *0x95fb1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bfe87:	cmpq   $0x0,0x78(%rsp)
  1bfe8d:	je     1bfeaf <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1c8f>
  1bfe8f:	mov    0x78(%rsp),%rax
  1bfe94:	mov    0x38(%rsp),%rdi
  1bfe99:	mov    $0x8,%edx
  1bfe9e:	lea    0x0(,%rax,8),%rsi
  1bfea6:	vzeroupper
  1bfea9:	call   *0x95f89(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bfeaf:	mov    0x964c2(%rip),%rcx        # 256378 <_DYNAMIC+0x740>
  1bfeb6:	mov    0x178(%rsp),%rax
  1bfebe:	lock sub %rax,(%rcx)
  1bfec2:	mov    0x964b7(%rip),%rcx        # 256380 <_DYNAMIC+0x748>
  1bfec9:	mov    0x180(%rsp),%rax
  1bfed1:	lock sub %rax,(%rcx)
  1bfed5:	mov    0x128(%rsp),%rax
  1bfedd:	test   %rax,%rax
  1bfee0:	je     1c0007 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1de7>
  1bfee6:	mov    %rax,%r14
  1bfee9:	cmp    %r15,%rax
  1bfeec:	ja     1c0ea4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2c84>
  1bfef2:	mov    0x150(%rsp),%r8
  1bfefa:	lea    (%r15,%r15,1),%rax
  1bfefe:	cmp    %rax,%r8
  1bff01:	ja     1c0ea4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2c84>
  1bff07:	mov    0x110(%rsp),%rax
  1bff0f:	mov    %rax,0x28(%rsp)
  1bff14:	cmp    %r15,%rax
  1bff17:	ja     1c0ea4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2c84>
  1bff1d:	vmovdqu 0xf0(%rsp),%xmm0
  1bff26:	mov    0xa8(%rsp),%rax
  1bff2e:	mov    0x148(%rsp),%rcx
  1bff36:	mov    0xa0(%rsp),%r9
  1bff3e:	movl   $0x0,0x30(%rsp)
  1bff46:	vmovdqu %xmm0,0x8(%rsp)
  1bff4c:	lea    0xc8(%rsp),%rdi
  1bff54:	mov    %rax,(%rsp)
  1bff58:	mov    %rbp,%rdx
  1bff5b:	mov    %rcx,0x68(%rsp)
  1bff60:	mov    0x50(%rsp),%rsi
  1bff65:	vzeroupper
  1bff68:	call   c9c40 <_RINvNtCsHW5vo2gROj_10zopro_core3msm12group_affineNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEB4_>
  1bff6d:	lea    0xb0(%rsp),%rdi
  1bff75:	mov    $0x8,%ecx
  1bff7a:	mov    $0x88,%r8d
  1bff80:	movq   $0x0,0xb0(%rsp)
  1bff8c:	movq   $0x8,0xb8(%rsp)
  1bff98:	movq   $0x0,0xc0(%rsp)
  1bffa4:	xor    %esi,%esi
  1bffa6:	mov    %r14,%rdx
  1bffa9:	call   184fb0 <_RNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner17try_reserve_exactCsHW5vo2gROj_10zopro_core>
  1bffae:	cmp    $0xffffffffffffffff,%rax
  1bffb2:	je     1c0108 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1ee8>
  1bffb8:	mov    0xb0(%rsp),%rax
  1bffc0:	test   %rax,%rax
  1bffc3:	je     1bffe3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1dc3>
  1bffc5:	mov    0xb8(%rsp),%rdi
  1bffcd:	mov    %rax,%rcx
  1bffd0:	shl    $0x7,%rcx
  1bffd4:	mov    $0x8,%edx
  1bffd9:	lea    (%rcx,%rax,8),%rsi
  1bffdd:	call   *0x95e55(%rip)        # 255e38 <_DYNAMIC+0x200>
  1bffe3:	mov    0xc8(%rsp),%rsi
  1bffeb:	test   %rsi,%rsi
  1bffee:	je     1c0007 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1de7>
  1bfff0:	mov    0xd0(%rsp),%rdi
  1bfff8:	shl    $0x7,%rsi
  1bfffc:	mov    $0x8,%edx
  1c0001:	call   *0x95e31(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c0007:	xor    %r15d,%r15d
  1c000a:	mov    0x100(%rsp),%rsi
  1c0012:	test   %rsi,%rsi
  1c0015:	jne    1beb85 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x965>
  1c001b:	jmp    1beb9f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x97f>
  1c0020:	lea    0x91e41(%rip),%r9        # 251e68 <__frame_dummy_init_array_entry+0x2b88>
  1c0027:	lea    0x400(%rsp),%rsi
  1c002f:	lea    0x350(%rsp),%rdx
  1c0037:	mov    %r14,0x90(%rsp)
  1c003f:	xor    %edi,%edi
  1c0041:	xor    %ecx,%ecx
  1c0043:	call   *0x960bf(%rip)        # 256108 <_DYNAMIC+0x4d0>
  1c0049:	jmp    1c1032 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e12>
  1c004e:	mov    0x96323(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1c0055:	mov    0x168(%rsp),%rcx
  1c005d:	lock sub %rcx,(%rax)
  1c0061:	mov    0x96318(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1c0068:	mov    0x170(%rsp),%rcx
  1c0070:	lock sub %rcx,(%rax)
  1c0074:	mov    0x50(%rsp),%r13
  1c0079:	jmp    1be767 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x547>
  1c007e:	mov    $0x1,%al
  1c0080:	lea    0x91ea1(%rip),%rcx        # 251f28 <__frame_dummy_init_array_entry+0x2c48>
  1c0087:	mov    %rcx,0x2f8(%rsp)
  1c008f:	mov    $0x1,%cl
  1c0091:	mov    %ecx,0x30(%rsp)
  1c0095:	mov    0x2f8(%rsp),%r9
  1c009d:	movzbl %al,%edi
  1c00a0:	lea    -0x1818e7(%rip),%rdx        # 3e7c0 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5e18>
  1c00a7:	lea    0x1c0(%rsp),%rsi
  1c00af:	xor    %ecx,%ecx
  1c00b1:	vzeroupper
  1c00b4:	call   *0x96316(%rip)        # 2563d0 <_DYNAMIC+0x798>
  1c00ba:	jmp    1c1032 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e12>
  1c00bf:	xor    %eax,%eax
  1c00c1:	jmp    1c008f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1e6f>
  1c00c3:	mov    $0x1,%al
  1c00c5:	mov    %eax,0x30(%rsp)
  1c00c9:	mov    0x20(%rsp),%rdx
  1c00ce:	lea    0x91e23(%rip),%rcx        # 251ef8 <__frame_dummy_init_array_entry+0x2c18>
  1c00d5:	mov    %r14,%rdi
  1c00d8:	mov    %rdx,%rsi
  1c00db:	vzeroupper
  1c00de:	call   *0x95dc4(%rip)        # 255ea8 <_DYNAMIC+0x270>
  1c00e4:	jmp    1c1032 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e12>
  1c00e9:	mov    $0x1,%al
  1c00eb:	mov    %eax,0x30(%rsp)
  1c00ef:	lea    0x91dea(%rip),%r9        # 251ee0 <__frame_dummy_init_array_entry+0x2c00>
  1c00f6:	xor    %edi,%edi
  1c00f8:	xor    %ecx,%ecx
  1c00fa:	vzeroupper
  1c00fd:	call   *0x9646d(%rip)        # 256570 <_DYNAMIC+0x938>
  1c0103:	jmp    1c1032 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e12>
  1c0108:	mov    0xd8(%rsp),%rsi
  1c0110:	mov    0x120(%rsp),%rdx
  1c0118:	mov    0xd0(%rsp),%rdi
  1c0120:	mov    0x118(%rsp),%rax
  1c0128:	mov    0xc8(%rsp),%rcx
  1c0130:	vpxor  %xmm0,%xmm0,%xmm0
  1c0134:	vmovdqu %xmm0,0x2c0(%rsp)
  1c013d:	lea    (%rdx,%r14,4),%r8
  1c0141:	shl    $0x2,%r14
  1c0145:	shl    $0x7,%rsi
  1c0149:	mov    %rdx,0x280(%rsp)
  1c0151:	add    $0x4,%rdx
  1c0155:	mov    %rax,0x290(%rsp)
  1c015d:	mov    %rdi,%r13
  1c0160:	mov    %r14,0x30(%rsp)
  1c0165:	mov    %rsi,%r14
  1c0168:	add    %rdi,%rsi
  1c016b:	mov    %rdx,0x40(%rsp)
  1c0170:	mov    %r8,0x298(%rsp)
  1c0178:	mov    %rdi,0x2a0(%rsp)
  1c0180:	mov    %rcx,0x2b0(%rsp)
  1c0188:	mov    %r8,0x58(%rsp)
  1c018d:	mov    %rsi,0x60(%rsp)
  1c0192:	mov    %rsi,0x2b8(%rsp)
  1c019a:	jmp    1c020b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1feb>
  1c019c:	lea    0x1c4(%rsp),%rdx
  1c01a4:	mov    %r15,%rax
  1c01a7:	shl    $0x7,%rax
  1c01ab:	sub    $0xffffffffffffff80,%r13
  1c01af:	add    $0xffffffffffffff80,%r14
  1c01b3:	addq   $0x4,0x40(%rsp)
  1c01b9:	mov    0xb8(%rsp),%rcx
  1c01c1:	vmovdqu64 (%rdx),%zmm0
  1c01c7:	vmovdqu64 0x40(%rdx),%zmm1
  1c01ce:	lea    (%rax,%r15,8),%rax
  1c01d2:	inc    %r15
  1c01d5:	addq   $0xfffffffffffffffc,0x30(%rsp)
  1c01db:	mov    0x190(%rsp),%edx
  1c01e2:	mov    %rcx,0x20(%rsp)
  1c01e7:	vmovdqu64 %zmm1,0x40(%rcx,%rax,1)
  1c01ef:	vmovdqu64 %zmm0,(%rcx,%rax,1)
  1c01f6:	mov    %edx,0x80(%rcx,%rax,1)
  1c01fd:	mov    %r15,0xc0(%rsp)
  1c0205:	je     1c02b7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2097>
  1c020b:	test   %r14,%r14
  1c020e:	je     1c02a0 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2080>
  1c0214:	mov    0x40(%rsp),%rax
  1c0219:	vmovups 0x0(%r13),%zmm0
  1c0220:	vmovups 0x40(%r13),%zmm1
  1c0227:	mov    0xc0(%rsp),%r15
  1c022f:	mov    -0x4(%rax),%eax
  1c0232:	mov    %eax,0x190(%rsp)
  1c0239:	lea    0x404(%rsp),%rax
  1c0241:	vmovups %zmm1,0x40(%rax)
  1c0248:	vmovups %zmm0,(%rax)
  1c024e:	vmovups 0x400(%rsp),%zmm0
  1c0256:	vmovups 0x440(%rsp),%zmm1
  1c025e:	mov    0x480(%rsp),%eax
  1c0265:	mov    %eax,0x240(%rsp)
  1c026c:	vmovups %zmm1,0x200(%rsp)
  1c0274:	vmovups %zmm0,0x1c0(%rsp)
  1c027c:	cmp    0xb0(%rsp),%r15
  1c0284:	jne    1c019c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1f7c>
  1c028a:	lea    0xb0(%rsp),%rdi
  1c0292:	vzeroupper
  1c0295:	call   *0x9616d(%rip)        # 256408 <_DYNAMIC+0x7d0>
  1c029b:	jmp    1c019c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x1f7c>
  1c02a0:	mov    0xb8(%rsp),%rax
  1c02a8:	mov    0xc0(%rsp),%r15
  1c02b0:	mov    %rax,0x20(%rsp)
  1c02b5:	jmp    1c02c6 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x20a6>
  1c02b7:	mov    0x58(%rsp),%rax
  1c02bc:	mov    %r13,0x60(%rsp)
  1c02c1:	mov    %rax,0x40(%rsp)
  1c02c6:	mov    0x40(%rsp),%rax
  1c02cb:	mov    0x60(%rsp),%rcx
  1c02d0:	lea    0x280(%rsp),%r14
  1c02d8:	mov    %r14,%rdi
  1c02db:	mov    %rax,0x288(%rsp)
  1c02e3:	mov    %rcx,0x2a8(%rsp)
  1c02eb:	vzeroupper
  1c02ee:	call   124bb0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters3zip3ZipINtNtNtCs6i54tJFfzR_5alloc3vec9into_iter8IntoItermEIB1a_INtNtCsgHCcee0nhgM_11zopro_bn2545curve6AffineNtB26_8G2ConfigEEEECsHW5vo2gROj_10zopro_core>
  1c02f3:	mov    0x20(%rsp),%rdi
  1c02f8:	mov    %r15,%rsi
  1c02fb:	call   baab0 <_RINvMNtCsgxBkk5gSRhY_4core5sliceSINtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce11ReplacementNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigE20sort_unstable_by_keymNCINvBy_7prepareB1z_Es0_0EBC_>
  1c0300:	mov    0x108(%rsp),%r13
  1c0308:	cmpq   $0x2,0x28(%rsp)
  1c030e:	jae    1c0ee8 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2cc8>
  1c0314:	mov    0x20(%rsp),%rax
  1c0319:	mov    %rax,0x400(%rsp)
  1c0321:	mov    %r15,0x408(%rsp)
  1c0329:	movq   $0x2,0x410(%rsp)
  1c0335:	lea    0x400(%rsp),%rdi
  1c033d:	call   15ba60 <_RINvYINtNtNtCsgxBkk5gSRhY_4core5slice4iter7WindowsINtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce11ReplacementNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvB2C_3all5checkRSBM_NCINvBP_7prepareB1Q_Es1_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEBT_>
  1c0342:	test   %al,%al
  1c0344:	jne    1c0f0b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2ceb>
  1c034a:	mov    0x28(%rsp),%rax
  1c034f:	mov    %r13,0x400(%rsp)
  1c0357:	mov    %rax,0x408(%rsp)
  1c035f:	movq   $0x2,0x410(%rsp)
  1c036b:	lea    0x400(%rsp),%rdi
  1c0373:	call   15bae0 <_RINvYINtNtNtCsgxBkk5gSRhY_4core5slice4iter7WindowsmENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBO_3all5checkRSmNCINvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7prepareNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEs2_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB29_>
  1c0378:	test   %al,%al
  1c037a:	jne    1c0f20 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2d00>
  1c0380:	lea    0xb8(%rsp),%rcx
  1c0388:	mov    0xb0(%rsp),%rax
  1c0390:	mov    0xe8(%rsp),%rsi
  1c0398:	vmovups (%rcx),%xmm0
  1c039c:	mov    %rax,0x80(%rsp)
  1c03a4:	mov    0x110(%rsp),%rax
  1c03ac:	vmovaps %xmm0,0x400(%rsp)
  1c03b5:	vmovups 0x100(%rsp),%xmm0
  1c03be:	mov    %rax,0x3f0(%rsp)
  1c03c6:	vmovaps %xmm0,0x410(%rsp)
  1c03cf:	vmovdqu 0x400(%rsp),%xmm0
  1c03d8:	vmovdqu 0x410(%rsp),%xmm1
  1c03e1:	vmovdqu %xmm0,0x3d0(%rsp)
  1c03ea:	vmovdqu %xmm1,0x3e0(%rsp)
  1c03f3:	test   %rsi,%rsi
  1c03f6:	je     1c040f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x21ef>
  1c03f8:	mov    0xf0(%rsp),%rdi
  1c0400:	shl    $0x3,%rsi
  1c0404:	mov    $0x8,%edx
  1c0409:	call   *0x95a29(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c040f:	mov    0x98(%rsp),%rsi
  1c0417:	test   %rsi,%rsi
  1c041a:	je     1c0433 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2213>
  1c041c:	mov    0xa0(%rsp),%rdi
  1c0424:	shl    $0x3,%rsi
  1c0428:	mov    $0x8,%edx
  1c042d:	call   *0x95a05(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c0433:	mov    0x140(%rsp),%rsi
  1c043b:	test   %rsi,%rsi
  1c043e:	je     1c0454 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2234>
  1c0440:	mov    0x68(%rsp),%rdi
  1c0445:	shl    $0x2,%rsi
  1c0449:	mov    $0x4,%edx
  1c044e:	call   *0x959e4(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c0454:	cmpq   $0xffffffffffffffff,0x80(%rsp)
  1c045d:	mov    0x50(%rsp),%r13
  1c0462:	je     1be767 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x547>
  1c0468:	mov    0x80(%rsp),%rax
  1c0470:	mov    0x3f0(%rsp),%rdx
  1c0478:	vmovdqu 0x3d0(%rsp),%ymm0
  1c0481:	mov    0x168(%rsp),%rcx
  1c0489:	mov    %rax,0x280(%rsp)
  1c0491:	mov    %rdx,0x180(%rsp)
  1c0499:	mov    %rdx,0x2a8(%rsp)
  1c04a1:	mov    0x170(%rsp),%rdx
  1c04a9:	vmovdqu %ymm0,0x288(%rsp)
  1c04b2:	mov    %rcx,0x2b0(%rsp)
  1c04ba:	mov    %rdx,0x2b8(%rsp)
  1c04c2:	mov    0x290(%rsp),%rax
  1c04ca:	mov    0x298(%rsp),%rcx
  1c04d2:	mov    %rax,0x178(%rsp)
  1c04da:	mov    %rcx,0x138(%rsp)
  1c04e2:	vzeroupper
  1c04e5:	call   *0x95fbd(%rip)        # 2564a8 <_DYNAMIC+0x870>
  1c04eb:	lea    0x4f(%rsp),%rcx
  1c04f0:	mov    %rbp,%rdi
  1c04f3:	xor    %esi,%esi
  1c04f5:	mov    %rax,%rdx
  1c04f8:	mov    %r12,%r8
  1c04fb:	mov    %rbp,%r9
  1c04fe:	mov    %rcx,(%rsp)
  1c0502:	mov    $0x1,%ecx
  1c0507:	call   15a610 <_RINvNvNtNtCsc3XWelWpAp8_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_5slice15IterMutProducerAyj4_EINtNtB6_8for_each15ForEachConsumerNCNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7b_query0EEB2u_>
  1c050c:	mov    0x300(%rsp),%rax
  1c0514:	mov    0x50(%rsp),%rcx
  1c0519:	lea    0xe8(%rsp),%rdx
  1c0521:	movq   $0x0,0xc8(%rsp)
  1c052d:	movq   $0x8,0xd0(%rsp)
  1c0539:	movq   $0x0,0xd8(%rsp)
  1c0545:	lea    0x1f0(%rsp),%rdi
  1c054d:	mov    %rdx,0x1c0(%rsp)
  1c0555:	mov    %rcx,0x1c8(%rsp)
  1c055d:	mov    %rbp,0x1d0(%rsp)
  1c0565:	mov    %r12,0x1d8(%rsp)
  1c056d:	mov    %rbp,0x1e0(%rsp)
  1c0575:	mov    %r14,0x1e8(%rsp)
  1c057d:	movq   $0x0,0x1f0(%rsp)
  1c0589:	mov    %rax,0xe8(%rsp)
  1c0591:	movq   $0xb,0x1f8(%rsp)
  1c059d:	call   *0x95f0d(%rip)        # 2564b0 <_DYNAMIC+0x878>
  1c05a3:	cmp    $0x1,%rax
  1c05a7:	jne    1c06f4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x24d4>
  1c05ad:	mov    %rdx,%r13
  1c05b0:	mov    %rdx,0x118(%rsp)
  1c05b8:	test   %rdx,%rdx
  1c05bb:	jne    1c0f86 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2d66>
  1c05c1:	mov    $0x8,%eax
  1c05c6:	movq   $0x0,0x78(%rsp)
  1c05cf:	xor    %r15d,%r15d
  1c05d2:	mov    %rax,0x38(%rsp)
  1c05d7:	mov    0x50(%rsp),%rcx
  1c05dc:	lea    0xe8(%rsp),%rax
  1c05e4:	movq   $0x0,0x100(%rsp)
  1c05f0:	movq   $0xb,0x108(%rsp)
  1c05fc:	mov    %rax,0x400(%rsp)
  1c0604:	mov    %rcx,0x408(%rsp)
  1c060c:	mov    %rbp,0x410(%rsp)
  1c0614:	mov    %r12,0x418(%rsp)
  1c061c:	mov    %rbp,0x420(%rsp)
  1c0624:	mov    %r14,0x428(%rsp)
  1c062c:	movq   $0x0,0x430(%rsp)
  1c0638:	movq   $0xb,0x438(%rsp)
  1c0644:	lea    0x100(%rsp),%rdi
  1c064c:	call   *0x95e66(%rip)        # 2564b8 <_DYNAMIC+0x880>
  1c0652:	lea    (%r15,%r15,2),%rdx
  1c0656:	lea    0x400(%rsp),%rcx
  1c065e:	mov    %rax,%r14
  1c0661:	mov    %r14,0x370(%rsp)
  1c0669:	mov    %rcx,0x358(%rsp)
  1c0671:	shl    $0x6,%rdx
  1c0675:	add    0x38(%rsp),%rdx
  1c067a:	mov    %rdx,0x360(%rsp)
  1c0682:	mov    %r13,0x368(%rsp)
  1c068a:	call   *0x95e18(%rip)        # 2564a8 <_DYNAMIC+0x870>
  1c0690:	xor    %ecx,%ecx
  1c0692:	cmp    $0xffffffffffffffff,%r14
  1c0696:	sete   %cl
  1c0699:	cmp    %rax,%rcx
  1c069c:	cmova  %rcx,%rax
  1c06a0:	lea    0x358(%rsp),%rcx
  1c06a8:	lea    0xb0(%rsp),%rdi
  1c06b0:	mov    $0x1,%r8d
  1c06b6:	movq   $0xb,(%rsp)
  1c06be:	mov    %r14,%rsi
  1c06c1:	xor    %edx,%edx
  1c06c3:	xor    %r9d,%r9d
  1c06c6:	mov    %rcx,0x8(%rsp)
  1c06cb:	mov    %rax,%rcx
  1c06ce:	call   156510 <_RINvNvNtNtCsc3XWelWpAp8_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_5range12IterProducerjEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerINtNtCsgHCcee0nhgM_11zopro_bn2545curve10ProjectiveNtB2R_8G2ConfigEENCNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7b_querys_0EEB41_>
  1c06d3:	mov    0xc0(%rsp),%rax
  1c06db:	mov    %rax,0x358(%rsp)
  1c06e3:	cmp    %r13,%rax
  1c06e6:	jne    1c0fdf <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2dbf>
  1c06ec:	add    %r13,%r15
  1c06ef:	jmp    1c095c <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x273c>
  1c06f4:	mov    0x50(%rsp),%rcx
  1c06f9:	lea    0xe8(%rsp),%rax
  1c0701:	movq   $0x0,0xb0(%rsp)
  1c070d:	movq   $0xb,0xb8(%rsp)
  1c0719:	mov    %rax,0x400(%rsp)
  1c0721:	mov    %rcx,0x408(%rsp)
  1c0729:	mov    %rbp,0x410(%rsp)
  1c0731:	mov    %r12,0x418(%rsp)
  1c0739:	mov    %rbp,0x420(%rsp)
  1c0741:	mov    %r14,0x428(%rsp)
  1c0749:	movq   $0x0,0x430(%rsp)
  1c0755:	movq   $0xb,0x438(%rsp)
  1c0761:	lea    0xb0(%rsp),%rdi
  1c0769:	call   *0x95d49(%rip)        # 2564b8 <_DYNAMIC+0x880>
  1c076f:	mov    %rax,%r14
  1c0772:	call   *0x95d30(%rip)        # 2564a8 <_DYNAMIC+0x870>
  1c0778:	xor    %ecx,%ecx
  1c077a:	cmp    $0xffffffffffffffff,%r14
  1c077e:	sete   %cl
  1c0781:	cmp    %rax,%rcx
  1c0784:	cmova  %rcx,%rax
  1c0788:	lea    0x400(%rsp),%rcx
  1c0790:	lea    0x358(%rsp),%rdi
  1c0798:	mov    $0x1,%r8d
  1c079e:	movq   $0xb,(%rsp)
  1c07a6:	mov    %r14,%rsi
  1c07a9:	xor    %edx,%edx
  1c07ab:	xor    %r9d,%r9d
  1c07ae:	mov    %rcx,0x8(%rsp)
  1c07b3:	mov    %rax,%rcx
  1c07b6:	call   159da0 <_RINvNvNtNtCsc3XWelWpAp8_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_5range12IterProducerjEINtNtB6_3map11MapConsumerNtNtB6_6extend15ListVecConsumerNCNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7b_querys_0EEB2J_>
  1c07bb:	mov    0x368(%rsp),%rax
  1c07c3:	test   %rax,%rax
  1c07c6:	je     1c07f2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x25d2>
  1c07c8:	mov    0x358(%rsp),%rcx
  1c07d0:	test   %rcx,%rcx
  1c07d3:	je     1c07f2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x25d2>
  1c07d5:	xor    %edx,%edx
  1c07d7:	add    0x10(%rcx),%rdx
  1c07db:	dec    %rax
  1c07de:	je     1c07e9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x25c9>
  1c07e0:	mov    0x18(%rcx),%rcx
  1c07e4:	test   %rcx,%rcx
  1c07e7:	jne    1c07d7 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x25b7>
  1c07e9:	test   %rdx,%rdx
  1c07ec:	jne    1c0f67 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2d47>
  1c07f2:	vmovdqu 0x358(%rsp),%xmm0
  1c07fb:	mov    0x368(%rsp),%rax
  1c0803:	mov    %rax,0x410(%rsp)
  1c080b:	vmovdqa %xmm0,0x400(%rsp)
  1c0814:	mov    0x400(%rsp),%rdi
  1c081c:	test   %rdi,%rdi
  1c081f:	je     1c093a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x271a>
  1c0825:	mov    0x410(%rsp),%r15
  1c082d:	mov    0x408(%rsp),%rax
  1c0835:	dec    %r15
  1c0838:	mov    %rax,0x50(%rsp)
  1c083d:	jmp    1c084e <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x262e>
  1c083f:	dec    %r15
  1c0842:	mov    %r14,%rdi
  1c0845:	test   %r14,%r14
  1c0848:	je     1c093a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x271a>
  1c084e:	mov    0x18(%rdi),%r14
  1c0852:	test   %r14,%r14
  1c0855:	je     1c0861 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2641>
  1c0857:	movq   $0x0,0x20(%r14)
  1c085f:	jmp    1c086a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x264a>
  1c0861:	movq   $0x0,0x50(%rsp)
  1c086a:	mov    0x8(%rdi),%rax
  1c086e:	mov    (%rdi),%r12
  1c0871:	mov    0x10(%rdi),%r13
  1c0875:	mov    $0x28,%esi
  1c087a:	mov    $0x8,%edx
  1c087f:	mov    %rax,0x38(%rsp)
  1c0884:	call   *0x955ae(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c088a:	cmp    $0xffffffffffffffff,%r12
  1c088e:	je     1c0931 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2711>
  1c0894:	mov    0xc8(%rsp),%rax
  1c089c:	mov    0xd8(%rsp),%rbp
  1c08a4:	sub    %rbp,%rax
  1c08a7:	cmp    %rax,%r13
  1c08aa:	ja     1c0909 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x26e9>
  1c08ac:	test   %r13,%r13
  1c08af:	je     1c08d8 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x26b8>
  1c08b1:	lea    0x0(%rbp,%rbp,2),%rdi
  1c08b6:	mov    0x38(%rsp),%rsi
  1c08bb:	mov    %r13,%rax
  1c08be:	shl    $0x6,%rax
  1c08c2:	lea    (%rax,%rax,2),%rdx
  1c08c6:	shl    $0x6,%rdi
  1c08ca:	add    0xd0(%rsp),%rdi
  1c08d2:	call   *0x955c0(%rip)        # 255e98 <memcpy@GLIBC_2.14>
  1c08d8:	add    %r13,%rbp
  1c08db:	mov    %rbp,0xd8(%rsp)
  1c08e3:	test   %r12,%r12
  1c08e6:	je     1c083f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x261f>
  1c08ec:	mov    0x38(%rsp),%rdi
  1c08f1:	shl    $0x6,%r12
  1c08f5:	mov    $0x8,%edx
  1c08fa:	lea    (%r12,%r12,2),%rsi
  1c08fe:	call   *0x95534(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c0904:	jmp    1c083f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x261f>
  1c0909:	mov    $0x8,%ecx
  1c090e:	mov    $0xc0,%r8d
  1c0914:	lea    0xc8(%rsp),%rdi
  1c091c:	mov    %rbp,%rsi
  1c091f:	mov    %r13,%rdx
  1c0922:	call   14ed80 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  1c0927:	mov    0xd8(%rsp),%rbp
  1c092f:	jmp    1c08b1 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2691>
  1c0931:	test   %r14,%r14
  1c0934:	jne    1c0e34 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2c14>
  1c093a:	mov    0xc8(%rsp),%rax
  1c0942:	mov    0xd0(%rsp),%rcx
  1c094a:	mov    0xd8(%rsp),%r15
  1c0952:	mov    %rax,0x78(%rsp)
  1c0957:	mov    %rcx,0x38(%rsp)
  1c095c:	mov    0x80(%rsp),%rcx
  1c0964:	vmovups -0x1824b6(%rip),%zmm0        # 3e4b8 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5b10>
  1c096e:	vmovups -0x182480(%rip),%zmm2        # 3e4f8 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5b50>
  1c0978:	vmovups -0x18244a(%rip),%zmm1        # 3e538 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5b90>
  1c0982:	mov    %rcx,%rax
  1c0985:	shl    $0x7,%rax
  1c0989:	lea    (%rax,%rcx,8),%rax
  1c098d:	mov    0x138(%rsp),%rcx
  1c0995:	vmovups %zmm0,0x1c0(%rsp)
  1c099d:	vmovups %zmm2,0x200(%rsp)
  1c09a5:	vmovups %zmm1,0x240(%rsp)
  1c09ad:	lea    (%rax,%rcx,4),%rax
  1c09b1:	mov    %rax,0x50(%rsp)
  1c09b6:	test   %r15,%r15
  1c09b9:	je     1c0d1b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2afb>
  1c09bf:	mov    0x38(%rsp),%rax
  1c09c4:	shl    $0x6,%r15
  1c09c8:	lea    0x400(%rsp),%r14
  1c09d0:	lea    0x1c0(%rsp),%r12
  1c09d8:	lea    (%r15,%r15,2),%rbp
  1c09dc:	lea    -0xc0(%rax),%r13
  1c09e3:	mov    %r14,%rdi
  1c09e6:	mov    %r12,%rsi
  1c09e9:	vzeroupper
  1c09ec:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c09f1:	vmovups 0x400(%rsp),%zmm0
  1c09f9:	vmovups 0x440(%rsp),%zmm1
  1c0a01:	vmovups 0x480(%rsp),%zmm2
  1c0a09:	mov    %r14,%rdi
  1c0a0c:	mov    %r12,%rsi
  1c0a0f:	vmovups %zmm2,0x240(%rsp)
  1c0a17:	vmovups %zmm1,0x200(%rsp)
  1c0a1f:	vmovups %zmm0,0x1c0(%rsp)
  1c0a27:	vzeroupper
  1c0a2a:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0a2f:	vmovups 0x400(%rsp),%zmm0
  1c0a37:	vmovups 0x440(%rsp),%zmm1
  1c0a3f:	vmovups 0x480(%rsp),%zmm2
  1c0a47:	mov    %r14,%rdi
  1c0a4a:	mov    %r12,%rsi
  1c0a4d:	vmovups %zmm2,0x240(%rsp)
  1c0a55:	vmovups %zmm1,0x200(%rsp)
  1c0a5d:	vmovups %zmm0,0x1c0(%rsp)
  1c0a65:	vzeroupper
  1c0a68:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0a6d:	vmovups 0x400(%rsp),%zmm0
  1c0a75:	vmovups 0x440(%rsp),%zmm1
  1c0a7d:	vmovups 0x480(%rsp),%zmm2
  1c0a85:	mov    %r14,%rdi
  1c0a88:	mov    %r12,%rsi
  1c0a8b:	vmovups %zmm2,0x240(%rsp)
  1c0a93:	vmovups %zmm1,0x200(%rsp)
  1c0a9b:	vmovups %zmm0,0x1c0(%rsp)
  1c0aa3:	vzeroupper
  1c0aa6:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0aab:	vmovups 0x400(%rsp),%zmm0
  1c0ab3:	vmovups 0x440(%rsp),%zmm1
  1c0abb:	vmovups 0x480(%rsp),%zmm2
  1c0ac3:	mov    %r14,%rdi
  1c0ac6:	mov    %r12,%rsi
  1c0ac9:	vmovups %zmm2,0x240(%rsp)
  1c0ad1:	vmovups %zmm1,0x200(%rsp)
  1c0ad9:	vmovups %zmm0,0x1c0(%rsp)
  1c0ae1:	vzeroupper
  1c0ae4:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0ae9:	vmovups 0x400(%rsp),%zmm0
  1c0af1:	vmovups 0x440(%rsp),%zmm1
  1c0af9:	vmovups 0x480(%rsp),%zmm2
  1c0b01:	mov    %r14,%rdi
  1c0b04:	mov    %r12,%rsi
  1c0b07:	vmovups %zmm2,0x240(%rsp)
  1c0b0f:	vmovups %zmm1,0x200(%rsp)
  1c0b17:	vmovups %zmm0,0x1c0(%rsp)
  1c0b1f:	vzeroupper
  1c0b22:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0b27:	vmovups 0x400(%rsp),%zmm0
  1c0b2f:	vmovups 0x440(%rsp),%zmm1
  1c0b37:	vmovups 0x480(%rsp),%zmm2
  1c0b3f:	mov    %r14,%rdi
  1c0b42:	mov    %r12,%rsi
  1c0b45:	vmovups %zmm2,0x240(%rsp)
  1c0b4d:	vmovups %zmm1,0x200(%rsp)
  1c0b55:	vmovups %zmm0,0x1c0(%rsp)
  1c0b5d:	vzeroupper
  1c0b60:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0b65:	vmovups 0x400(%rsp),%zmm0
  1c0b6d:	vmovups 0x440(%rsp),%zmm1
  1c0b75:	vmovups 0x480(%rsp),%zmm2
  1c0b7d:	mov    %r14,%rdi
  1c0b80:	mov    %r12,%rsi
  1c0b83:	vmovups %zmm2,0x240(%rsp)
  1c0b8b:	vmovups %zmm1,0x200(%rsp)
  1c0b93:	vmovups %zmm0,0x1c0(%rsp)
  1c0b9b:	vzeroupper
  1c0b9e:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0ba3:	vmovups 0x400(%rsp),%zmm0
  1c0bab:	vmovups 0x440(%rsp),%zmm1
  1c0bb3:	vmovups 0x480(%rsp),%zmm2
  1c0bbb:	mov    %r14,%rdi
  1c0bbe:	mov    %r12,%rsi
  1c0bc1:	vmovups %zmm2,0x240(%rsp)
  1c0bc9:	vmovups %zmm1,0x200(%rsp)
  1c0bd1:	vmovups %zmm0,0x1c0(%rsp)
  1c0bd9:	vzeroupper
  1c0bdc:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0be1:	vmovups 0x400(%rsp),%zmm0
  1c0be9:	vmovups 0x440(%rsp),%zmm1
  1c0bf1:	vmovups 0x480(%rsp),%zmm2
  1c0bf9:	mov    %r14,%rdi
  1c0bfc:	mov    %r12,%rsi
  1c0bff:	vmovups %zmm2,0x240(%rsp)
  1c0c07:	vmovups %zmm1,0x200(%rsp)
  1c0c0f:	vmovups %zmm0,0x1c0(%rsp)
  1c0c17:	vzeroupper
  1c0c1a:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0c1f:	vmovups 0x400(%rsp),%zmm0
  1c0c27:	vmovups 0x440(%rsp),%zmm1
  1c0c2f:	vmovups 0x480(%rsp),%zmm2
  1c0c37:	mov    %r14,%rdi
  1c0c3a:	mov    %r12,%rsi
  1c0c3d:	vmovups %zmm2,0x240(%rsp)
  1c0c45:	vmovups %zmm1,0x200(%rsp)
  1c0c4d:	vmovups %zmm0,0x1c0(%rsp)
  1c0c55:	vzeroupper
  1c0c58:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0c5d:	vmovups 0x400(%rsp),%zmm0
  1c0c65:	vmovups 0x440(%rsp),%zmm1
  1c0c6d:	vmovups 0x480(%rsp),%zmm2
  1c0c75:	mov    %r14,%rdi
  1c0c78:	mov    %r12,%rsi
  1c0c7b:	vmovups %zmm2,0x240(%rsp)
  1c0c83:	vmovups %zmm1,0x200(%rsp)
  1c0c8b:	vmovups %zmm0,0x1c0(%rsp)
  1c0c93:	vzeroupper
  1c0c96:	call   1ac500 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleCsHW5vo2gROj_10zopro_core>
  1c0c9b:	vmovups 0x400(%rsp),%zmm0
  1c0ca3:	vmovups 0x440(%rsp),%zmm1
  1c0cab:	vmovups 0x480(%rsp),%zmm2
  1c0cb3:	lea    0x0(%r13,%rbp,1),%rdx
  1c0cb8:	mov    %r14,%rdi
  1c0cbb:	mov    %r12,%rsi
  1c0cbe:	vmovups %zmm2,0x240(%rsp)
  1c0cc6:	vmovups %zmm1,0x200(%rsp)
  1c0cce:	vmovups %zmm0,0x1c0(%rsp)
  1c0cd6:	vzeroupper
  1c0cd9:	call   19a7a0 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE14add_projectiveCsHW5vo2gROj_10zopro_core>
  1c0cde:	vmovups 0x400(%rsp),%zmm0
  1c0ce6:	vmovups 0x440(%rsp),%zmm1
  1c0cee:	vmovups 0x480(%rsp),%zmm2
  1c0cf6:	add    $0xffffffffffffff40,%rbp
  1c0cfd:	vmovups %zmm2,0x240(%rsp)
  1c0d05:	vmovups %zmm1,0x200(%rsp)
  1c0d0d:	vmovups %zmm0,0x1c0(%rsp)
  1c0d15:	jne    1c09e3 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x27c3>
  1c0d1b:	vmovdqu64 0x1c0(%rsp),%zmm0
  1c0d23:	vmovdqu64 0x200(%rsp),%zmm1
  1c0d2b:	vmovdqu64 0x240(%rsp),%zmm2
  1c0d33:	cmpq   $0x0,0x78(%rsp)
  1c0d39:	mov    0x178(%rsp),%rax
  1c0d41:	mov    0x180(%rsp),%rdx
  1c0d49:	mov    0x50(%rsp),%rcx
  1c0d4e:	vmovdqu64 %zmm2,0x480(%rsp)
  1c0d56:	vmovdqu64 %zmm1,0x440(%rsp)
  1c0d5e:	vmovdqu64 %zmm0,0x400(%rsp)
  1c0d66:	mov    %rax,0x4c0(%rsp)
  1c0d6e:	mov    %rdx,0x4c8(%rsp)
  1c0d76:	mov    %rcx,0x4d0(%rsp)
  1c0d7e:	movl   $0x3,0x4d8(%rsp)
  1c0d89:	je     1c0dab <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2b8b>
  1c0d8b:	mov    0x78(%rsp),%rax
  1c0d90:	mov    0x38(%rsp),%rdi
  1c0d95:	mov    $0x8,%edx
  1c0d9a:	shl    $0x6,%rax
  1c0d9e:	lea    (%rax,%rax,2),%rsi
  1c0da2:	vzeroupper
  1c0da5:	call   *0x9508d(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c0dab:	mov    0x280(%rsp),%rax
  1c0db3:	test   %rax,%rax
  1c0db6:	je     1c0dd9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2bb9>
  1c0db8:	mov    0x288(%rsp),%rdi
  1c0dc0:	mov    %rax,%rcx
  1c0dc3:	shl    $0x7,%rcx
  1c0dc7:	mov    $0x8,%edx
  1c0dcc:	lea    (%rcx,%rax,8),%rsi
  1c0dd0:	vzeroupper
  1c0dd3:	call   *0x9505f(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c0dd9:	mov    0x298(%rsp),%rsi
  1c0de1:	test   %rsi,%rsi
  1c0de4:	je     1c0e00 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2be0>
  1c0de6:	mov    0x2a0(%rsp),%rdi
  1c0dee:	shl    $0x2,%rsi
  1c0df2:	mov    $0x4,%edx
  1c0df7:	vzeroupper
  1c0dfa:	call   *0x95038(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c0e00:	mov    0x2b0(%rsp),%rax
  1c0e08:	mov    0x2b8(%rsp),%rcx
  1c0e10:	jmp    1be8ca <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x6aa>
  1c0e15:	mov    $0x28,%esi
  1c0e1a:	mov    $0x8,%edx
  1c0e1f:	mov    %r14,%rdi
  1c0e22:	call   *0x95010(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c0e28:	mov    %r15,%r14
  1c0e2b:	test   %r15,%r15
  1c0e2e:	je     1c093a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x271a>
  1c0e34:	mov    0x18(%r14),%r15
  1c0e38:	test   %r15,%r15
  1c0e3b:	je     1c0e45 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2c25>
  1c0e3d:	movq   $0x0,0x20(%r15)
  1c0e45:	mov    (%r14),%rax
  1c0e48:	test   %rax,%rax
  1c0e4b:	je     1c0e15 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2bf5>
  1c0e4d:	mov    0x8(%r14),%rdi
  1c0e51:	shl    $0x6,%rax
  1c0e55:	mov    $0x8,%edx
  1c0e5a:	lea    (%rax,%rax,2),%rsi
  1c0e5e:	call   *0x94fd4(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c0e64:	jmp    1c0e15 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2bf5>
  1c0e66:	mov    $0x400,%eax
  1c0e6b:	mov    %rdx,0x28(%rsp)
  1c0e70:	mov    %rax,0x40(%rsp)
  1c0e75:	mov    $0x1,%al
  1c0e77:	mov    %eax,0x30(%rsp)
  1c0e7b:	mov    0x28(%rsp),%rdi
  1c0e80:	mov    0x40(%rsp),%rsi
  1c0e85:	mov    0x88(%rsp),%rdx
  1c0e8d:	vzeroupper
  1c0e90:	call   *0x950e2(%rip)        # 255f78 <_DYNAMIC+0x340>
  1c0e96:	jmp    1c1032 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e12>
  1c0e9b:	lea    0x910b6(%rip),%rax        # 251f58 <__frame_dummy_init_array_entry+0x2c78>
  1c0ea2:	jmp    1c0ede <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2cbe>
  1c0ea4:	movl   $0x0,0x30(%rsp)
  1c0eac:	lea    -0x1827e7(%rip),%rdi        # 3e6cc <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5d24>
  1c0eb3:	lea    0x90fc6(%rip),%rdx        # 251e80 <__frame_dummy_init_array_entry+0x2ba0>
  1c0eba:	mov    $0x77,%esi
  1c0ebf:	vzeroupper
  1c0ec2:	call   *0x94fd8(%rip)        # 255ea0 <_DYNAMIC+0x268>
  1c0ec8:	jmp    1c1032 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e12>
  1c0ecd:	lea    0x90ff4(%rip),%rax        # 251ec8 <__frame_dummy_init_array_entry+0x2be8>
  1c0ed4:	mov    %r14,0x28(%rsp)
  1c0ed9:	mov    %rcx,0x40(%rsp)
  1c0ede:	mov    %rax,0x88(%rsp)
  1c0ee6:	jmp    1c0e75 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2c55>
  1c0ee8:	cmpq   $0x15,0x28(%rsp)
  1c0eee:	jae    1c1083 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e63>
  1c0ef4:	mov    0x28(%rsp),%rsi
  1c0ef9:	mov    $0x1,%edx
  1c0efe:	mov    %r13,%rdi
  1c0f01:	call   14ce60 <_RINvNtNtNtNtCsgxBkk5gSRhY_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftmNvYmNtNtBa_3cmp10PartialOrd2ltECsHW5vo2gROj_10zopro_core>
  1c0f06:	jmp    1c0314 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x20f4>
  1c0f0b:	lea    0x90f86(%rip),%rdx        # 251e98 <__frame_dummy_init_array_entry+0x2bb8>
  1c0f12:	mov    $0x46,%esi
  1c0f17:	lea    -0x1827db(%rip),%rdi        # 3e743 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5d9b>
  1c0f1e:	jmp    1c0f33 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2d13>
  1c0f20:	lea    0x90f89(%rip),%rdx        # 251eb0 <__frame_dummy_init_array_entry+0x2bd0>
  1c0f27:	mov    $0x37,%esi
  1c0f2c:	lea    -0x1827aa(%rip),%rdi        # 3e789 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5de1>
  1c0f33:	call   *0x94f67(%rip)        # 255ea0 <_DYNAMIC+0x268>
  1c0f39:	jmp    1c1032 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e12>
  1c0f3e:	mov    0x20(%rsp),%rax
  1c0f43:	mov    %rax,0x40(%rsp)
  1c0f48:	lea    0x91069(%rip),%rax        # 251fb8 <__frame_dummy_init_array_entry+0x2cd8>
  1c0f4f:	jmp    1c0ede <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2cbe>
  1c0f51:	mov    $0x400,%eax
  1c0f56:	mov    %rax,0x40(%rsp)
  1c0f5b:	lea    0x9106e(%rip),%rax        # 251fd0 <__frame_dummy_init_array_entry+0x2cf0>
  1c0f62:	jmp    1c0ede <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2cbe>
  1c0f67:	lea    0xc8(%rsp),%rdi
  1c0f6f:	mov    $0x8,%ecx
  1c0f74:	mov    $0xc0,%r8d
  1c0f7a:	xor    %esi,%esi
  1c0f7c:	call   14ed80 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  1c0f81:	jmp    1c07f2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x25d2>
  1c0f86:	lea    0xc8(%rsp),%rdi
  1c0f8e:	mov    $0x8,%ecx
  1c0f93:	mov    $0xc0,%r8d
  1c0f99:	xor    %esi,%esi
  1c0f9b:	mov    %r13,%rdx
  1c0f9e:	call   14ed80 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  1c0fa3:	mov    0xc8(%rsp),%rax
  1c0fab:	mov    0xd8(%rsp),%r15
  1c0fb3:	mov    %rax,0x78(%rsp)
  1c0fb8:	sub    %r15,%rax
  1c0fbb:	cmp    %r13,%rax
  1c0fbe:	jae    1c109b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e7b>
  1c0fc4:	lea    -0x1826cd(%rip),%rdi        # 3e8fe <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5f56>
  1c0fcb:	lea    0x91b86(%rip),%rdx        # 252b58 <__frame_dummy_init_array_entry+0x3878>
  1c0fd2:	mov    $0x2f,%esi
  1c0fd7:	call   *0x94ec3(%rip)        # 255ea0 <_DYNAMIC+0x268>
  1c0fdd:	jmp    1c1032 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2e12>
  1c0fdf:	mov    0x94fa2(%rip),%r8        # 255f88 <_DYNAMIC+0x350>
  1c0fe6:	lea    0x118(%rsp),%rax
  1c0fee:	lea    0x358(%rsp),%rcx
  1c0ff6:	mov    %rax,0x400(%rsp)
  1c0ffe:	mov    %r8,0x408(%rsp)
  1c1006:	mov    %rcx,0x410(%rsp)
  1c100e:	mov    %r8,0x418(%rsp)
  1c1016:	lea    -0x18b0be(%rip),%rdi        # 35f5f <GCC_except_table151+0x331b>
  1c101d:	lea    0x9115c(%rip),%rdx        # 252180 <__frame_dummy_init_array_entry+0x2ea0>
  1c1024:	lea    0x400(%rsp),%rsi
  1c102c:	call   *0x94e7e(%rip)        # 255eb0 <_DYNAMIC+0x278>
  1c1032:	ud2
  1c1034:	mov    0x190(%rsp),%rax
  1c103c:	mov    %rax,0x40(%rsp)
  1c1041:	lea    0x90f28(%rip),%rax        # 251f70 <__frame_dummy_init_array_entry+0x2c90>
  1c1048:	jmp    1c0ede <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2cbe>
  1c104d:	mov    %rax,0x28(%rsp)
  1c1052:	mov    $0x400,%eax
  1c1057:	mov    %rax,0x40(%rsp)
  1c105c:	lea    0x90f25(%rip),%rax        # 251f88 <__frame_dummy_init_array_entry+0x2ca8>
  1c1063:	jmp    1c0ede <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2cbe>
  1c1068:	mov    $0x400,%eax
  1c106d:	mov    %r14,0x28(%rsp)
  1c1072:	mov    %rax,0x40(%rsp)
  1c1077:	lea    0x90f22(%rip),%rax        # 251fa0 <__frame_dummy_init_array_entry+0x2cc0>
  1c107e:	jmp    1c0ede <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2cbe>
  1c1083:	mov    0x28(%rsp),%rsi
  1c1088:	lea    0x4f(%rsp),%rdx
  1c108d:	mov    %r13,%rdi
  1c1090:	call   *0x9534a(%rip)        # 2563e0 <_DYNAMIC+0x7a8>
  1c1096:	jmp    1c0314 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x20f4>
  1c109b:	mov    0xd0(%rsp),%rax
  1c10a3:	jmp    1c05d2 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x23b2>
  1c10a8:	lea    0x358(%rsp),%rdi
  1c10b0:	mov    %rax,%rbx
  1c10b3:	call   1241d0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtCs6i54tJFfzR_5alloc11collections11linked_list10LinkedListINtNtBI_3vec3VecINtNtCsgHCcee0nhgM_11zopro_bn2545curve10ProjectiveNtB1W_8G2ConfigEEEECsHW5vo2gROj_10zopro_core>
  1c10b8:	jmp    1c1151 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2f31>
  1c10bd:	mov    0x50(%rsp),%rcx
  1c10c2:	mov    %r14,0x400(%rsp)
  1c10ca:	mov    %rax,%rbx
  1c10cd:	mov    %rcx,0x408(%rsp)
  1c10d5:	mov    %r15,0x410(%rsp)
  1c10dd:	test   %r12,%r12
  1c10e0:	je     1c10fa <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2eda>
  1c10e2:	mov    0x38(%rsp),%rdi
  1c10e7:	shl    $0x6,%r12
  1c10eb:	mov    $0x8,%edx
  1c10f0:	lea    (%r12,%r12,2),%rsi
  1c10f4:	call   *0x94d3e(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c10fa:	lea    0x400(%rsp),%rdi
  1c1102:	call   124450 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtCs6i54tJFfzR_5alloc11collections11linked_list8IntoIterINtNtBI_3vec3VecINtNtCsgHCcee0nhgM_11zopro_bn2545curve10ProjectiveNtB1T_8G2ConfigEEEECsHW5vo2gROj_10zopro_core>
  1c1107:	jmp    1c1151 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2f31>
  1c1109:	mov    %rax,%rbx
  1c110c:	lea    0x280(%rsp),%rdi
  1c1114:	call   1247e0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7OverlayNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEEBI_>
  1c1119:	mov    %rbx,%rdi
  1c111c:	call   24e260 <_Unwind_Resume@plt>
  1c1121:	mov    0x40(%rsp),%rcx
  1c1126:	lea    0x280(%rsp),%rdi
  1c112e:	sub    $0xffffffffffffff80,%r13
  1c1132:	mov    %rax,%rbx
  1c1135:	mov    %rcx,0x288(%rsp)
  1c113d:	mov    %r13,0x2a8(%rsp)
  1c1145:	call   124bb0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters3zip3ZipINtNtNtCs6i54tJFfzR_5alloc3vec9into_iter8IntoItermEIB1a_INtNtCsgHCcee0nhgM_11zopro_bn2545curve6AffineNtB26_8G2ConfigEEEECsHW5vo2gROj_10zopro_core>
  1c114a:	jmp    1c1191 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2f71>
  1c114c:	jmp    1c11ca <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2faa>
  1c114e:	mov    %rax,%rbx
  1c1151:	mov    0xc8(%rsp),%rax
  1c1159:	test   %rax,%rax
  1c115c:	je     1c1179 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2f59>
  1c115e:	mov    0xd0(%rsp),%rdi
  1c1166:	shl    $0x6,%rax
  1c116a:	mov    $0x8,%edx
  1c116f:	lea    (%rax,%rax,2),%rsi
  1c1173:	call   *0x94cbf(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c1179:	lea    0x280(%rsp),%rdi
  1c1181:	call   1247e0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce7OverlayNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEEBI_>
  1c1186:	mov    %rbx,%rdi
  1c1189:	call   24e260 <_Unwind_Resume@plt>
  1c118e:	mov    %rax,%rbx
  1c1191:	mov    0xb0(%rsp),%rax
  1c1199:	test   %rax,%rax
  1c119c:	je     1c11bc <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2f9c>
  1c119e:	mov    0xb8(%rsp),%rdi
  1c11a6:	mov    %rax,%rcx
  1c11a9:	shl    $0x7,%rcx
  1c11ad:	mov    $0x8,%edx
  1c11b2:	lea    (%rcx,%rax,8),%rsi
  1c11b6:	call   *0x94c7c(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c11bc:	movl   $0x0,0x30(%rsp)
  1c11c4:	xor    %ebp,%ebp
  1c11c6:	jmp    1c1242 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x3022>
  1c11c8:	jmp    1c11ca <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2faa>
  1c11ca:	mov    %rax,%rbx
  1c11cd:	mov    $0x1,%al
  1c11cf:	mov    %eax,0x30(%rsp)
  1c11d3:	jmp    1c123f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x301f>
  1c11d5:	mov    0xb0(%rsp),%rsi
  1c11dd:	mov    %rax,%rbx
  1c11e0:	test   %rsi,%rsi
  1c11e3:	je     1c120f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x2fef>
  1c11e5:	shl    $0x7,%rsi
  1c11e9:	mov    $0x8,%edx
  1c11ee:	mov    %r14,%rdi
  1c11f1:	call   *0x94c41(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c11f7:	lea    0x358(%rsp),%rdi
  1c11ff:	call   124ef0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8grouping12ScalarGroupsEBH_>
  1c1204:	mov    %rbx,%rdi
  1c1207:	call   24e260 <_Unwind_Resume@plt>
  1c120c:	mov    %rax,%rbx
  1c120f:	lea    0x358(%rsp),%rdi
  1c1217:	call   124ef0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine8grouping12ScalarGroupsEBH_>
  1c121c:	mov    %rbx,%rdi
  1c121f:	call   24e260 <_Unwind_Resume@plt>
  1c1224:	lea    0x400(%rsp),%rdi
  1c122c:	mov    %rax,%rbx
  1c122f:	call   123ae0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCsHW5vo2gROj_10zopro_core3msm8BatchAddNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEEBG_>
  1c1234:	mov    %rbx,%rdi
  1c1237:	call   24e260 <_Unwind_Resume@plt>
  1c123c:	mov    %rax,%rbx
  1c123f:	mov    $0x1,%bpl
  1c1242:	mov    0x100(%rsp),%rsi
  1c124a:	test   %rsi,%rsi
  1c124d:	je     1c1266 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x3046>
  1c124f:	mov    0x108(%rsp),%rdi
  1c1257:	shl    $0x2,%rsi
  1c125b:	mov    $0x4,%edx
  1c1260:	call   *0x94bd2(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c1266:	test   %bpl,%bpl
  1c1269:	je     1c128f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x306f>
  1c126b:	mov    0x118(%rsp),%rsi
  1c1273:	test   %rsi,%rsi
  1c1276:	je     1c128f <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x306f>
  1c1278:	mov    0x120(%rsp),%rdi
  1c1280:	shl    $0x2,%rsi
  1c1284:	mov    $0x4,%edx
  1c1289:	call   *0x94ba9(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c128f:	mov    0xe8(%rsp),%rsi
  1c1297:	test   %rsi,%rsi
  1c129a:	jne    1c1318 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x30f8>
  1c129c:	mov    0x98(%rsp),%rsi
  1c12a4:	test   %rsi,%rsi
  1c12a7:	jne    1c1340 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x3120>
  1c12ad:	mov    0x140(%rsp),%rsi
  1c12b5:	test   %rsi,%rsi
  1c12b8:	jne    1c1368 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x3148>
  1c12be:	cmpb   $0x0,0x30(%rsp)
  1c12c3:	je     1c138a <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x316a>
  1c12c9:	mov    0x1a0(%rsp),%rsi
  1c12d1:	test   %rsi,%rsi
  1c12d4:	je     1c12ed <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x30cd>
  1c12d6:	mov    0x1a8(%rsp),%rdi
  1c12de:	shl    $0x3,%rsi
  1c12e2:	mov    $0x4,%edx
  1c12e7:	call   *0x94b4b(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c12ed:	mov    0x95084(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1c12f4:	mov    0x168(%rsp),%rcx
  1c12fc:	lock sub %rcx,(%rax)
  1c1300:	mov    0x95079(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1c1307:	mov    0x170(%rsp),%rcx
  1c130f:	lock sub %rcx,(%rax)
  1c1313:	jmp    1c13bb <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x319b>
  1c1318:	mov    0xf0(%rsp),%rdi
  1c1320:	shl    $0x3,%rsi
  1c1324:	mov    $0x8,%edx
  1c1329:	call   *0x94b09(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c132f:	mov    0x98(%rsp),%rsi
  1c1337:	test   %rsi,%rsi
  1c133a:	je     1c12ad <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x308d>
  1c1340:	mov    0xa0(%rsp),%rdi
  1c1348:	shl    $0x3,%rsi
  1c134c:	mov    $0x8,%edx
  1c1351:	call   *0x94ae1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c1357:	mov    0x140(%rsp),%rsi
  1c135f:	test   %rsi,%rsi
  1c1362:	je     1c12be <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x309e>
  1c1368:	mov    0x148(%rsp),%rdi
  1c1370:	shl    $0x2,%rsi
  1c1374:	mov    $0x4,%edx
  1c1379:	call   *0x94ab9(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c137f:	cmpb   $0x0,0x30(%rsp)
  1c1384:	jne    1c12c9 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x30a9>
  1c138a:	mov    0x94fe7(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1c1391:	mov    0x168(%rsp),%rcx
  1c1399:	mov    %rbx,%rdi
  1c139c:	lock sub %rcx,(%rax)
  1c13a0:	mov    0x94fd9(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1c13a7:	mov    0x170(%rsp),%rcx
  1c13af:	lock sub %rcx,(%rax)
  1c13b3:	call   24e260 <_Unwind_Resume@plt>
  1c13b8:	mov    %rax,%rbx
  1c13bb:	mov    0x94fb6(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1c13c2:	mov    0x178(%rsp),%rcx
  1c13ca:	lock sub %rcx,(%rax)
  1c13ce:	mov    0x94fab(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1c13d5:	mov    0x180(%rsp),%rcx
  1c13dd:	lock sub %rcx,(%rax)
  1c13e1:	cmpq   $0x0,0x78(%rsp)
  1c13e7:	jne    1c1407 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x31e7>
  1c13e9:	cmpq   $0x0,0x80(%rsp)
  1c13f2:	jne    1c142b <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x320b>
  1c13f4:	cmpq   $0x0,0x90(%rsp)
  1c13fd:	jne    1c1455 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x3235>
  1c13ff:	mov    %rbx,%rdi
  1c1402:	call   24e260 <_Unwind_Resume@plt>
  1c1407:	mov    0x78(%rsp),%rsi
  1c140c:	mov    0x38(%rsp),%rdi
  1c1411:	mov    $0x8,%edx
  1c1416:	shl    $0x3,%rsi
  1c141a:	call   *0x94a18(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c1420:	cmpq   $0x0,0x80(%rsp)
  1c1429:	je     1c13f4 <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x31d4>
  1c142b:	mov    0x80(%rsp),%rsi
  1c1433:	mov    0x138(%rsp),%rdi
  1c143b:	mov    $0x4,%edx
  1c1440:	shl    $0x2,%rsi
  1c1444:	call   *0x949ee(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c144a:	cmpq   $0x0,0x90(%rsp)
  1c1453:	je     1c13ff <_RNvNtCsHW5vo2gROj_10zopro_core20coalesce_query_probe1b+0x31df>
  1c1455:	mov    0x90(%rsp),%rsi
  1c145d:	mov    0x198(%rsp),%rdi
  1c1465:	mov    $0x8,%edx
  1c146a:	shl    $0x5,%rsi
  1c146e:	call   *0x949c4(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c1474:	mov    %rbx,%rdi
  1c1477:	call   24e260 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:

/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001c4b70 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified>:
  1c4b70:	push   %rbp
  1c4b71:	push   %r15
  1c4b73:	push   %r14
  1c4b75:	push   %r13
  1c4b77:	push   %r12
  1c4b79:	push   %rbx
  1c4b7a:	sub    $0x158,%rsp
  1c4b81:	mov    %rdx,%r12
  1c4b84:	mov    %rsi,%r13
  1c4b87:	mov    %rdi,0x10(%rsp)
  1c4b8c:	lea    -0x1865ee(%rip),%rsi        # 3e5a5 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x5bfd>
  1c4b93:	lea    0x60(%rsp),%rdi
  1c4b98:	mov    $0xf,%edx
  1c4b9d:	call   *0x9136d(%rip)        # 255f10 <_DYNAMIC+0x2d8>
  1c4ba3:	mov    0x68(%rsp),%rsi
  1c4ba8:	mov    0x70(%rsp),%rdi
  1c4bad:	cmpb   $0x0,0x60(%rsp)
  1c4bb2:	je     1c4bc2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x52>
  1c4bb4:	cmp    $0xfffffffffffffffe,%rsi
  1c4bb8:	jne    1c4bf7 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x87>
  1c4bba:	test   $0x1,%dil
  1c4bbe:	je     1c4be6 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x76>
  1c4bc0:	jmp    1c4c0c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x9c>
  1c4bc2:	cmpq   $0x1,0x78(%rsp)
  1c4bc8:	mov    $0x1,%bl
  1c4bca:	jne    1c4bd2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x62>
  1c4bcc:	cmpb   $0x30,(%rdi)
  1c4bcf:	setne  %bl
  1c4bd2:	test   %rsi,%rsi
  1c4bd5:	je     1c4be2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x72>
  1c4bd7:	mov    $0x1,%edx
  1c4bdc:	call   *0x91256(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c4be2:	test   %bl,%bl
  1c4be4:	jne    1c4c0c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x9c>
  1c4be6:	mov    0x10(%rsp),%rax
  1c4beb:	movq   $0xfffffffffffffffe,(%rax)
  1c4bf2:	jmp    1c4d5a <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1ea>
  1c4bf7:	lea    -0x1(%rsi),%rax
  1c4bfb:	cmp    $0xfffffffffffffffc,%rax
  1c4bff:	ja     1c4c0c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x9c>
  1c4c01:	mov    $0x1,%edx
  1c4c06:	call   *0x9122c(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c4c0c:	lea    -0x1860e9(%rip),%rsi        # 3eb2a <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x6182>
  1c4c13:	lea    0x128(%rsp),%rdi
  1c4c1b:	mov    $0x1b,%edx
  1c4c20:	call   *0x912ea(%rip)        # 255f10 <_DYNAMIC+0x2d8>
  1c4c26:	mov    0x128(%rsp),%rbx
  1c4c2e:	xor    %eax,%eax
  1c4c30:	test   %rbx,%rbx
  1c4c33:	jne    1c4c4e <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xde>
  1c4c35:	cmpq   $0x1,0x140(%rsp)
  1c4c3e:	jne    1c4c4e <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xde>
  1c4c40:	mov    0x138(%rsp),%rax
  1c4c48:	cmpb   $0x31,(%rax)
  1c4c4b:	sete   %al
  1c4c4e:	movabs $0xffffffff00000001,%rcx
  1c4c58:	lea    (%r12,%rcx,1),%rdx
  1c4c5c:	or     $0x100,%rcx
  1c4c63:	cmp    %rcx,%rdx
  1c4c66:	jb     1c4d21 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1b1>
  1c4c6c:	movzbl %al,%ecx
  1c4c6f:	lea    0x60(%rsp),%rdi
  1c4c74:	mov    %r13,%rsi
  1c4c77:	mov    %r12,%rdx
  1c4c7a:	call   1c67f0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8grouping15grouping_sample>
  1c4c7f:	mov    0x60(%rsp),%rax
  1c4c84:	test   %rax,%rax
  1c4c87:	je     1c4d21 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1b1>
  1c4c8d:	mov    0x68(%rsp),%rcx
  1c4c92:	mov    0x78(%rsp),%rbx
  1c4c97:	mov    0xa0(%rsp),%rdx
  1c4c9f:	mov    %rax,0x8(%rsp)
  1c4ca4:	mov    %rcx,0xb0(%rsp)
  1c4cac:	lea    0x60(%rsp),%rdi
  1c4cb1:	mov    %r12,%rsi
  1c4cb4:	mov    %rdx,0xd8(%rsp)
  1c4cbc:	call   1c2e40 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine13grouping_cost7reserve>
  1c4cc1:	cmpl   $0x1,0x60(%rsp)
  1c4cc6:	jne    1c4d76 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x206>
  1c4ccc:	mov    0x68(%rsp),%rax
  1c4cd1:	mov    0x70(%rsp),%rcx
  1c4cd6:	mov    %rax,0x20(%rsp)
  1c4cdb:	mov    %rcx,0x28(%rsp)
  1c4ce0:	lea    -0x1861a2(%rip),%rsi        # 3eb45 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x619d>
  1c4ce7:	lea    0x60(%rsp),%rdi
  1c4cec:	mov    $0x18,%edx
  1c4cf1:	call   *0x91219(%rip)        # 255f10 <_DYNAMIC+0x2d8>
  1c4cf7:	mov    0x68(%rsp),%rsi
  1c4cfc:	mov    0x70(%rsp),%rdi
  1c4d01:	cmpb   $0x0,0x60(%rsp)
  1c4d06:	je     1c4d87 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x217>
  1c4d08:	cmp    $0xfffffffffffffffe,%rsi
  1c4d0c:	jne    1c4db3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x243>
  1c4d12:	test   $0x1,%dil
  1c4d16:	je     1c4dae <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x23e>
  1c4d1c:	jmp    1c4dc8 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x258>
  1c4d21:	mov    0x10(%rsp),%rax
  1c4d26:	movq   $0xfffffffffffffffe,(%rax)
  1c4d2d:	mov    0x130(%rsp),%rsi
  1c4d35:	cmpb   $0x0,0x128(%rsp)
  1c4d3d:	je     1c4d6f <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1ff>
  1c4d3f:	test   %rsi,%rsi
  1c4d42:	jle    1c4d5a <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1ea>
  1c4d44:	mov    0x138(%rsp),%rdi
  1c4d4c:	mov    $0x1,%edx
  1c4d51:	vzeroupper
  1c4d54:	call   *0x910de(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c4d5a:	add    $0x158,%rsp
  1c4d61:	pop    %rbx
  1c4d62:	pop    %r12
  1c4d64:	pop    %r13
  1c4d66:	pop    %r14
  1c4d68:	pop    %r15
  1c4d6a:	pop    %rbp
  1c4d6b:	vzeroupper
  1c4d6e:	ret
  1c4d6f:	test   %rsi,%rsi
  1c4d72:	jne    1c4d44 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1d4>
  1c4d74:	jmp    1c4d5a <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1ea>
  1c4d76:	mov    0x10(%rsp),%rax
  1c4d7b:	movq   $0xfffffffffffffffe,(%rax)
  1c4d82:	jmp    1c569c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xb2c>
  1c4d87:	cmpq   $0x1,0x78(%rsp)
  1c4d8d:	mov    $0x1,%bpl
  1c4d90:	jne    1c4d99 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x229>
  1c4d92:	cmpb   $0x30,(%rdi)
  1c4d95:	setne  %bpl
  1c4d99:	test   %rsi,%rsi
  1c4d9c:	je     1c4da9 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x239>
  1c4d9e:	mov    $0x1,%edx
  1c4da3:	call   *0x9108f(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c4da9:	test   %bpl,%bpl
  1c4dac:	jne    1c4dc8 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x258>
  1c4dae:	xor    %r14d,%r14d
  1c4db1:	jmp    1c4e06 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x296>
  1c4db3:	lea    -0x1(%rsi),%rax
  1c4db7:	cmp    $0xfffffffffffffffc,%rax
  1c4dbb:	ja     1c4dc8 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x258>
  1c4dbd:	mov    $0x1,%edx
  1c4dc2:	call   *0x91070(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c4dc8:	mov    0xd8(%rsp),%rdx
  1c4dd0:	movabs $0x28f5c28f5c28f5c3,%rax
  1c4dda:	shl    $0x4,%rbx
  1c4dde:	mov    $0x8000,%r14d
  1c4de4:	imul   %r12,%rdx
  1c4de8:	shr    $0x2,%rdx
  1c4dec:	mulx   %rax,%rax,%rax
  1c4df1:	shr    $0x2,%rax
  1c4df5:	cmp    %rbx,%rax
  1c4df8:	cmovae %rbx,%rax
  1c4dfc:	cmp    $0x8000,%rax
  1c4e02:	cmovb  %rax,%r14
  1c4e06:	mov    0x9176b(%rip),%rax        # 256578 <_DYNAMIC+0x940>
  1c4e0d:	mov    (%rax),%rax
  1c4e10:	test   %rax,%rax
  1c4e13:	je     1c56e1 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xb71>
  1c4e19:	mov    0x91760(%rip),%rcx        # 256580 <_DYNAMIC+0x948>
  1c4e20:	mov    (%rax),%rbx
  1c4e23:	mov    0x8(%rax),%r15
  1c4e27:	mov    (%rcx),%rbp
  1c4e2a:	test   %rbp,%rbp
  1c4e2d:	je     1c56f3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xb83>
  1c4e33:	mov    %rbx,%rdi
  1c4e36:	call   *0x18(%r15)
  1c4e3a:	lea    0x20(%rbp),%rdx
  1c4e3e:	lea    0xb8(%rsp),%rdi
  1c4e46:	mov    %rbp,%rsi
  1c4e49:	mov    %rax,%rcx
  1c4e4c:	call   *0x91736(%rip)        # 256588 <_DYNAMIC+0x950>
  1c4e52:	lea    0x38(%rsp),%rdi
  1c4e57:	mov    $0x28,%esi
  1c4e5c:	mov    $0x1,%ecx
  1c4e61:	mov    %r14,%rdx
  1c4e64:	call   c2220 <_RINvMsa_NtCsfBDUjroi3FF_9hashbrown3rawNtB6_13RawTableInner22fallible_with_capacityNtNtCs6i54tJFfzR_5alloc5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  1c4e69:	vmovups 0xb8(%rsp),%ymm0
  1c4e72:	vmovdqu 0x38(%rsp),%ymm1
  1c4e78:	movq   $0x0,0xb8(%rsp)
  1c4e84:	movq   $0x8,0xc0(%rsp)
  1c4e90:	movq   $0x0,0xc8(%rsp)
  1c4e9c:	lea    0x0(,%r12,4),%rbx
  1c4ea4:	vmovups %ymm0,0x80(%rsp)
  1c4ead:	vmovdqu %ymm1,0x60(%rsp)
  1c4eb3:	vmovdqu64 0x60(%rsp),%zmm0
  1c4ebe:	vmovdqu64 %zmm0,0xe0(%rsp)
  1c4ec9:	vzeroupper
  1c4ecc:	call   *0x911e6(%rip)        # 2560b8 <_DYNAMIC+0x480>
  1c4ed2:	mov    $0x4,%esi
  1c4ed7:	mov    %rbx,%rdi
  1c4eda:	call   *0x90f50(%rip)        # 255e30 <_DYNAMIC+0x1f8>
  1c4ee0:	test   %rax,%rax
  1c4ee3:	je     1c5762 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xbf2>
  1c4ee9:	lea    -0x4(%rbx),%rdx
  1c4eed:	mov    $0xff,%esi
  1c4ef2:	mov    %rax,%rdi
  1c4ef5:	mov    %rax,%r14
  1c4ef8:	call   *0x91132(%rip)        # 256030 <memset@GLIBC_2.2.5>
  1c4efe:	mov    $0x8,%eax
  1c4f03:	movq   $0x0,0x38(%rsp)
  1c4f0c:	movq   $0x8,0x40(%rsp)
  1c4f15:	xor    %r15d,%r15d
  1c4f18:	mov    %rbx,(%rsp)
  1c4f1c:	movl   $0xffffffff,-0x4(%r14,%rbx,1)
  1c4f25:	movq   $0x0,0x48(%rsp)
  1c4f2e:	movq   $0x0,0x18(%rsp)
  1c4f37:	mov    %r14,0x30(%rsp)
  1c4f3c:	mov    %r13,0x148(%rsp)
  1c4f44:	mov    %rax,0x58(%rsp)
  1c4f49:	jmp    1c4ff9 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x489>
  1c4f4e:	xchg   %ax,%ax
  1c4f50:	and    %rcx,%rsi
  1c4f53:	vmovdqu (%rax,%rsi,1),%xmm1
  1c4f58:	vpcmpeqb %xmm0,%xmm1,%k0
  1c4f5e:	kortestw %k0,%k0
  1c4f62:	je     1c4fa0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x430>
  1c4f64:	kmovd  %k0,%edi
  1c4f68:	tzcnt  %edi,%r8d
  1c4f6d:	add    %rsi,%r8
  1c4f70:	and    %rcx,%r8
  1c4f73:	neg    %r8
  1c4f76:	lea    (%r8,%r8,4),%r8
  1c4f7a:	vmovdqu -0x28(%rax,%r8,8),%ymm2
  1c4f81:	vpxor  0x60(%rsp),%ymm2,%ymm2
  1c4f87:	vptest %ymm2,%ymm2
  1c4f8c:	je     1c4fc0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x450>
  1c4f8e:	lea    -0x1(%rdi),%r8d
  1c4f92:	and    %di,%r8w
  1c4f96:	mov    %r8d,%edi
  1c4f99:	jne    1c4f68 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x3f8>
  1c4f9b:	nopl   0x0(%rax,%rax,1)
  1c4fa0:	vpcmpeqd %xmm2,%xmm2,%xmm2
  1c4fa4:	vpcmpeqb %xmm2,%xmm1,%k0
  1c4faa:	kortestw %k0,%k0
  1c4fae:	jne    1c50d0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x560>
  1c4fb4:	lea    0x10(%rsi,%rdx,1),%rsi
  1c4fb9:	add    $0x10,%rdx
  1c4fbd:	jmp    1c4f50 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x3e0>
  1c4fbf:	nop
  1c4fc0:	lea    (%rax,%r8,8),%rcx
  1c4fc4:	mov    -0x8(%rcx),%edi
  1c4fc7:	mov    0x48(%rsp),%rsi
  1c4fcc:	mov    0x148(%rsp),%r13
  1c4fd4:	mov    %rbx,%r12
  1c4fd7:	mov    %edi,(%r14,%r15,4)
  1c4fdb:	cmp    %rdi,%rsi
  1c4fde:	jbe    1c5731 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xbc1>
  1c4fe4:	mov    0x40(%rsp),%rax
  1c4fe9:	incq   (%rax,%rdi,8)
  1c4fed:	inc    %r15
  1c4ff0:	cmp    %r12,%r15
  1c4ff3:	je     1c5274 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x704>
  1c4ff9:	mov    %r15,%rbp
  1c4ffc:	shl    $0x5,%rbp
  1c5000:	vmovdqu 0x0(%r13,%rbp,1),%ymm0
  1c5007:	vptest %ymm0,%ymm0
  1c500c:	je     1c4fed <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x47d>
  1c500e:	add    %r13,%rbp
  1c5011:	vmovdqa 0x110(%rsp),%xmm1
  1c501a:	vpmovsxbq -0x187be3(%rip),%xmm5        # 3d440 <_RNvCs3zmp2RFaYZ5_6driver9ALLOCATOR+0x4a98>
  1c5023:	vmovdqa -0x18e54b(%rip),%xmm6        # 36ae0 <GCC_except_table151+0x3e9c>
  1c502b:	mov    0xe8(%rsp),%rcx
  1c5033:	mov    %r12,%rbx
  1c5036:	xor    %edx,%edx
  1c5038:	vmovups 0x0(%rbp),%ymm0
  1c503d:	vmovups %ymm0,0x60(%rsp)
  1c5043:	vmovdqa 0x100(%rsp),%xmm0
  1c504c:	vmovdqa 0x60(%rsp),%xmm3
  1c5052:	vmovdqa 0x70(%rsp),%xmm4
  1c5058:	mov    0x60(%rsp),%rax
  1c505d:	mov    %rax,0x150(%rsp)
  1c5065:	mov    0xe0(%rsp),%rax
  1c506d:	vpxor  %xmm0,%xmm1,%xmm2
  1c5071:	vaesdec %xmm5,%xmm0,%xmm0
  1c5076:	vpaddq -0x18e58e(%rip),%xmm0,%xmm0        # 36af0 <GCC_except_table151+0x3eac>
  1c507e:	vpshufb %xmm6,%xmm1,%xmm1
  1c5083:	vpaddq %xmm5,%xmm1,%xmm1
  1c5087:	vpshufb %xmm6,%xmm1,%xmm1
  1c508c:	vpaddq %xmm1,%xmm3,%xmm1
  1c5090:	vpshufb %xmm6,%xmm1,%xmm1
  1c5095:	vaesdec %xmm3,%xmm0,%xmm0
  1c509a:	vpaddq %xmm1,%xmm4,%xmm1
  1c509e:	vaesdec %xmm4,%xmm0,%xmm0
  1c50a3:	vaesenc %xmm0,%xmm1,%xmm0
  1c50a8:	vaesdec %xmm2,%xmm0,%xmm1
  1c50ad:	vaesdec %xmm0,%xmm1,%xmm0
  1c50b2:	vmovq  %xmm0,%r12
  1c50b7:	mov    %r12,%r13
  1c50ba:	shr    $0x39,%r13
  1c50be:	mov    %r12,%rsi
  1c50c1:	vpbroadcastb %r13d,%xmm0
  1c50c7:	jmp    1c4f50 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x3e0>
  1c50cc:	nopl   0x0(%rax)
  1c50d0:	cmpq   $0x0,0xf0(%rsp)
  1c50d9:	je     1c5237 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x6c7>
  1c50df:	mov    0x18(%rsp),%rdx
  1c50e4:	cmp    0xb8(%rsp),%rdx
  1c50ec:	jne    1c5111 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x5a1>
  1c50ee:	lea    0xb8(%rsp),%rdi
  1c50f6:	vzeroupper
  1c50f9:	call   *0x91331(%rip)        # 256430 <_DYNAMIC+0x7f8>
  1c50ff:	mov    0xc0(%rsp),%rax
  1c5107:	mov    0x18(%rsp),%rdx
  1c510c:	mov    %rax,0x58(%rsp)
  1c5111:	vmovdqu 0x0(%rbp),%ymm0
  1c5116:	mov    0x58(%rsp),%rcx
  1c511b:	mov    %rdx,%rax
  1c511e:	shl    $0x5,%rax
  1c5122:	inc    %rdx
  1c5125:	mov    %rdx,0x18(%rsp)
  1c512a:	vmovdqu %ymm0,(%rcx,%rax,1)
  1c512f:	mov    %rdx,0xc8(%rsp)
  1c5137:	mov    0x48(%rsp),%r14
  1c513c:	cmp    0x38(%rsp),%r14
  1c5141:	jne    1c5151 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x5e1>
  1c5143:	lea    0x38(%rsp),%rdi
  1c5148:	vzeroupper
  1c514b:	call   *0x9134f(%rip)        # 2564a0 <_DYNAMIC+0x868>
  1c5151:	mov    0x40(%rsp),%rax
  1c5156:	movq   $0x0,(%rax,%r14,8)
  1c515e:	inc    %r14
  1c5161:	mov    0xe8(%rsp),%rcx
  1c5169:	mov    0xe0(%rsp),%rax
  1c5171:	mov    %r14,0x48(%rsp)
  1c5176:	and    %rcx,%r12
  1c5179:	vmovdqu (%rax,%r12,1),%xmm0
  1c517f:	vpmovmskb %xmm0,%edx
  1c5183:	test   %edx,%edx
  1c5185:	je     1c520f <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x69f>
  1c518b:	mov    0x30(%rsp),%r14
  1c5190:	tzcnt  %edx,%edx
  1c5194:	add    %r12,%rdx
  1c5197:	and    %rcx,%rdx
  1c519a:	movzbl (%rax,%rdx,1),%esi
  1c519e:	test   %sil,%sil
  1c51a1:	jns    1c525f <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x6ef>
  1c51a7:	lea    -0x10(%rdx),%r8
  1c51ab:	mov    %r13b,(%rax,%rdx,1)
  1c51af:	neg    %rdx
  1c51b2:	and    $0x1,%sil
  1c51b6:	add    $0x8,%rbp
  1c51ba:	mov    0x18(%rsp),%rdi
  1c51bf:	and    %rcx,%r8
  1c51c2:	lea    (%rdx,%rdx,4),%rdx
  1c51c6:	movzbl %sil,%esi
  1c51ca:	mov    %r13b,0x10(%rax,%r8,1)
  1c51cf:	mov    0x150(%rsp),%r8
  1c51d7:	sub    %rsi,0xf0(%rsp)
  1c51df:	lea    (%rax,%rdx,8),%rcx
  1c51e3:	dec    %edi
  1c51e5:	mov    %r8,-0x28(%rax,%rdx,8)
  1c51ea:	vmovdqu 0x0(%rbp),%xmm0
  1c51ef:	vmovdqu %xmm0,-0x20(%rax,%rdx,8)
  1c51f5:	mov    0x10(%rbp),%rsi
  1c51f9:	mov    %rsi,-0x10(%rax,%rdx,8)
  1c51fe:	mov    %edi,-0x8(%rax,%rdx,8)
  1c5202:	incq   0xf8(%rsp)
  1c520a:	jmp    1c4fc4 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x454>
  1c520f:	mov    0x30(%rsp),%r14
  1c5214:	mov    $0x10,%esi
  1c5219:	add    %rsi,%r12
  1c521c:	add    $0x10,%rsi
  1c5220:	and    %rcx,%r12
  1c5223:	vmovdqu (%rax,%r12,1),%xmm0
  1c5229:	vpmovmskb %xmm0,%edx
  1c522d:	test   %edx,%edx
  1c522f:	jne    1c5190 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x620>
  1c5235:	jmp    1c5219 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x6a9>
  1c5237:	mov    $0x1,%esi
  1c523c:	lea    0xe0(%rsp),%rdi
  1c5244:	lea    0x100(%rsp),%rdx
  1c524c:	mov    $0x1,%ecx
  1c5251:	vzeroupper
  1c5254:	call   *0x9110e(%rip)        # 256368 <_DYNAMIC+0x730>
  1c525a:	jmp    1c50df <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x56f>
  1c525f:	vmovdqa (%rax),%xmm0
  1c5263:	vpmovmskb %xmm0,%edx
  1c5267:	tzcnt  %edx,%edx
  1c526b:	movzbl (%rax,%rdx,1),%esi
  1c526f:	jmp    1c51a7 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x637>
  1c5274:	mov    0xe8(%rsp),%rsi
  1c527c:	test   %rsi,%rsi
  1c527f:	je     1c52b3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x743>
  1c5281:	lea    (%rsi,%rsi,4),%rax
  1c5285:	lea    0x37(,%rax,8),%rax
  1c528d:	and    $0xfffffffffffffff0,%rax
  1c5291:	add    %rax,%rsi
  1c5294:	add    $0x11,%rsi
  1c5298:	je     1c52b3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x743>
  1c529a:	mov    0xe0(%rsp),%rdi
  1c52a2:	mov    $0x10,%edx
  1c52a7:	sub    %rax,%rdi
  1c52aa:	vzeroupper
  1c52ad:	call   *0x90b85(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c52b3:	mov    0xd8(%rsp),%rcx
  1c52bb:	mov    0x18(%rsp),%rdx
  1c52c0:	imul   $0x64,%rdx,%rax
  1c52c4:	imul   %r12,%rcx
  1c52c8:	cmp    %rcx,%rax
  1c52cb:	jbe    1c532a <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x7ba>
  1c52cd:	mov    0xc8(%rsp),%rax
  1c52d5:	mov    0x10(%rsp),%rcx
  1c52da:	vmovups 0xb8(%rsp),%xmm0
  1c52e3:	vmovdqu 0x38(%rsp),%xmm1
  1c52e9:	mov    0x28(%rsp),%rdx
  1c52ee:	mov    %rax,0x18(%rcx)
  1c52f2:	mov    0x48(%rsp),%rax
  1c52f7:	vmovups %xmm0,0x8(%rcx)
  1c52fc:	vmovdqu %xmm1,0x38(%rcx)
  1c5301:	mov    %rax,0x48(%rcx)
  1c5305:	mov    0x20(%rsp),%rax
  1c530a:	movq   $0xffffffffffffffff,(%rcx)
  1c5311:	mov    %r12,0x20(%rcx)
  1c5315:	mov    %r14,0x28(%rcx)
  1c5319:	mov    %r12,0x30(%rcx)
  1c531d:	mov    %rax,0x50(%rcx)
  1c5321:	mov    %rdx,0x58(%rcx)
  1c5325:	jmp    1c569c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xb2c>
  1c532a:	test   %rdx,%rdx
  1c532d:	je     1c5363 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x7f3>
  1c532f:	mov    0x48(%rsp),%r15
  1c5334:	movabs $0x1000000000000000,%rax
  1c533e:	dec    %rax
  1c5341:	cmp    %rax,%r15
  1c5344:	jne    1c5413 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x8a3>
  1c534a:	xor    %r14d,%r14d
  1c534d:	xor    %ebp,%ebp
  1c534f:	mov    %r14,%rdi
  1c5352:	mov    %rbx,%rsi
  1c5355:	vzeroupper
  1c5358:	call   *0x90b92(%rip)        # 255ef0 <_DYNAMIC+0x2b8>
  1c535e:	jmp    1c5780 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc10>
  1c5363:	mov    0xb8(%rsp),%rbx
  1c536b:	vzeroupper
  1c536e:	call   *0x90d44(%rip)        # 2560b8 <_DYNAMIC+0x480>
  1c5374:	mov    $0x8,%edi
  1c5379:	mov    $0x8,%esi
  1c537e:	call   *0x90aac(%rip)        # 255e30 <_DYNAMIC+0x1f8>
  1c5384:	test   %rax,%rax
  1c5387:	je     1c571f <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xbaf>
  1c538d:	vmovups 0x38(%rsp),%xmm0
  1c5393:	mov    0x10(%rsp),%rdx
  1c5398:	mov    0x48(%rsp),%rcx
  1c539d:	mov    0x58(%rsp),%rsi
  1c53a2:	movq   $0x0,(%rax)
  1c53a9:	mov    %r14,%rdi
  1c53ac:	mov    %rcx,0x58(%rdx)
  1c53b0:	mov    0x28(%rsp),%rcx
  1c53b5:	vmovups %xmm0,0x48(%rdx)
  1c53ba:	mov    %rbx,(%rdx)
  1c53bd:	mov    %rsi,0x8(%rdx)
  1c53c1:	mov    0x20(%rsp),%rsi
  1c53c6:	vxorps %xmm0,%xmm0,%xmm0
  1c53ca:	vmovups %xmm0,0x10(%rdx)
  1c53cf:	movq   $0x4,0x20(%rdx)
  1c53d7:	movq   $0x0,0x28(%rdx)
  1c53df:	movq   $0x1,0x30(%rdx)
  1c53e7:	mov    %rax,0x38(%rdx)
  1c53eb:	movq   $0x1,0x40(%rdx)
  1c53f3:	mov    %r12,0x60(%rdx)
  1c53f7:	mov    %rsi,0x68(%rdx)
  1c53fb:	mov    (%rsp),%rsi
  1c53ff:	mov    %rcx,0x70(%rdx)
  1c5403:	mov    $0x4,%edx
  1c5408:	call   *0x90a2a(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c540e:	jmp    1c569c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xb2c>
  1c5413:	inc    %r15
  1c5416:	lea    0x0(,%r15,8),%rbx
  1c541e:	vzeroupper
  1c5421:	call   *0x90c91(%rip)        # 2560b8 <_DYNAMIC+0x480>
  1c5427:	mov    $0x8,%esi
  1c542c:	mov    %rbx,%rdi
  1c542f:	mov    $0x8,%r14d
  1c5435:	call   *0x909f5(%rip)        # 255e30 <_DYNAMIC+0x1f8>
  1c543b:	test   %rax,%rax
  1c543e:	je     1c534d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x7dd>
  1c5444:	mov    %r15,0x60(%rsp)
  1c5449:	mov    0x48(%rsp),%r15
  1c544e:	mov    $0x8,%ebx
  1c5453:	mov    %rax,0x68(%rsp)
  1c5458:	movq   $0x0,(%rax)
  1c545f:	movq   $0x1,0x70(%rsp)
  1c5468:	test   %r15,%r15
  1c546b:	je     1c5534 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x9c4>
  1c5471:	mov    %r12,0x18(%rsp)
  1c5476:	mov    0x40(%rsp),%r12
  1c547b:	shl    $0x3,%r15
  1c547f:	mov    $0x1,%r14d
  1c5485:	lea    0x60(%rsp),%r13
  1c548a:	jmp    1c54a3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x933>
  1c548c:	mov    0x68(%rsp),%rax
  1c5491:	mov    %rbp,(%rax,%r14,8)
  1c5495:	inc    %r14
  1c5498:	add    $0xfffffffffffffff8,%r15
  1c549c:	mov    %r14,0x70(%rsp)
  1c54a1:	je     1c54c4 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x954>
  1c54a3:	mov    0x68(%rsp),%rax
  1c54a8:	mov    -0x8(%rax,%r14,8),%rbp
  1c54ad:	add    -0x8(%r12,%r14,8),%rbp
  1c54b2:	cmp    0x60(%rsp),%r14
  1c54b7:	jne    1c5491 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x921>
  1c54b9:	mov    %r13,%rdi
  1c54bc:	call   *0x90fde(%rip)        # 2564a0 <_DYNAMIC+0x868>
  1c54c2:	jmp    1c548c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x91c>
  1c54c4:	mov    0x48(%rsp),%rbp
  1c54c9:	cmp    %r14,%rbp
  1c54cc:	ja     1c5708 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xb98>
  1c54d2:	mov    0x18(%rsp),%r12
  1c54d7:	test   %rbp,%rbp
  1c54da:	je     1c553a <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x9ca>
  1c54dc:	mov    0x68(%rsp),%r13
  1c54e1:	lea    0x0(,%rbp,8),%r14
  1c54e9:	call   *0x90bc9(%rip)        # 2560b8 <_DYNAMIC+0x480>
  1c54ef:	mov    $0x8,%esi
  1c54f4:	mov    %r14,%rdi
  1c54f7:	call   *0x90933(%rip)        # 255e30 <_DYNAMIC+0x1f8>
  1c54fd:	test   %rax,%rax
  1c5500:	je     1c5772 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc02>
  1c5506:	mov    %rax,%rbx
  1c5509:	mov    %rax,%rdi
  1c550c:	mov    %r13,%rsi
  1c550f:	mov    %r14,%rdx
  1c5512:	call   *0x90980(%rip)        # 255e98 <memcpy@GLIBC_2.14>
  1c5518:	mov    0x70(%rsp),%r14
  1c551d:	test   %r14,%r14
  1c5520:	jne    1c553c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x9cc>
  1c5522:	lea    0x8db87(%rip),%rdi        # 2530b0 <__frame_dummy_init_array_entry+0x3dd0>
  1c5529:	call   *0x90959(%rip)        # 255e88 <_DYNAMIC+0x250>
  1c552f:	jmp    1c5780 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc10>
  1c5534:	mov    $0x1,%r14d
  1c553a:	xor    %ebp,%ebp
  1c553c:	mov    0x68(%rsp),%rax
  1c5541:	movabs $0x7ffffffffffffff1,%rcx
  1c554b:	mov    -0x8(%rax,%r14,8),%r13
  1c5550:	mov    %r13,%rax
  1c5553:	shr    $0x3e,%rax
  1c5557:	lea    0x0(,%r13,4),%r15
  1c555f:	setne  %al
  1c5562:	add    $0xb,%rcx
  1c5566:	cmp    %rcx,%r15
  1c5569:	seta   %cl
  1c556c:	or     %al,%cl
  1c556e:	je     1c5580 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xa10>
  1c5570:	xor    %edi,%edi
  1c5572:	mov    %r15,%rsi
  1c5575:	call   *0x90975(%rip)        # 255ef0 <_DYNAMIC+0x2b8>
  1c557b:	jmp    1c5780 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc10>
  1c5580:	test   %r15,%r15
  1c5583:	je     1c55ab <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xa3b>
  1c5585:	call   *0x90b2d(%rip)        # 2560b8 <_DYNAMIC+0x480>
  1c558b:	mov    $0x4,%esi
  1c5590:	mov    %r15,%rdi
  1c5593:	call   *0x908af(%rip)        # 255e48 <_DYNAMIC+0x210>
  1c5599:	mov    $0x4,%edi
  1c559e:	test   %rax,%rax
  1c55a1:	je     1c5572 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xa02>
  1c55a3:	mov    %rax,%r14
  1c55a6:	mov    %r13,%r15
  1c55a9:	jmp    1c55b4 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xa44>
  1c55ab:	mov    $0x4,%r14d
  1c55b1:	xor    %r15d,%r15d
  1c55b4:	mov    (%rsp),%r8
  1c55b8:	mov    $0xffffffff,%esi
  1c55bd:	lea    0x8db04(%rip),%rdx        # 2530c8 <__frame_dummy_init_array_entry+0x3de8>
  1c55c4:	lea    0x8db15(%rip),%rcx        # 2530e0 <__frame_dummy_init_array_entry+0x3e00>
  1c55cb:	xor    %eax,%eax
  1c55cd:	jmp    1c55d9 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xa69>
  1c55cf:	nop
  1c55d0:	inc    %rax
  1c55d3:	add    $0xfffffffffffffffc,%r8
  1c55d7:	je     1c5606 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xa96>
  1c55d9:	mov    0x30(%rsp),%rdi
  1c55de:	mov    (%rdi,%rax,4),%edi
  1c55e1:	cmp    %rsi,%rdi
  1c55e4:	je     1c55d0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xa60>
  1c55e6:	cmp    %rdi,%rbp
  1c55e9:	jbe    1c5751 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xbe1>
  1c55ef:	mov    (%rbx,%rdi,8),%r9
  1c55f3:	cmp    %r13,%r9
  1c55f6:	jae    1c5746 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xbd6>
  1c55fc:	mov    %eax,(%r14,%r9,4)
  1c5600:	incq   (%rbx,%rdi,8)
  1c5604:	jmp    1c55d0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xa60>
  1c5606:	mov    0x30(%rsp),%rdi
  1c560b:	mov    (%rsp),%rsi
  1c560f:	mov    $0x4,%edx
  1c5614:	call   *0x9081e(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c561a:	test   %rbp,%rbp
  1c561d:	je     1c5634 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xac4>
  1c561f:	shl    $0x3,%rbp
  1c5623:	mov    $0x8,%edx
  1c5628:	mov    %rbx,%rdi
  1c562b:	mov    %rbp,%rsi
  1c562e:	call   *0x90804(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c5634:	mov    0xc8(%rsp),%rax
  1c563c:	mov    0x10(%rsp),%rcx
  1c5641:	vmovups 0xb8(%rsp),%xmm0
  1c564a:	vmovdqu 0x60(%rsp),%xmm2
  1c5650:	vmovdqu 0x38(%rsp),%xmm1
  1c5656:	mov    0x28(%rsp),%rdx
  1c565b:	mov    %rax,0x10(%rcx)
  1c565f:	mov    0x70(%rsp),%rax
  1c5664:	vmovups %xmm0,(%rcx)
  1c5668:	vmovdqu %xmm2,0x30(%rcx)
  1c566d:	mov    %rax,0x40(%rcx)
  1c5671:	mov    0x48(%rsp),%rax
  1c5676:	vmovdqu %xmm1,0x48(%rcx)
  1c567b:	mov    %rax,0x58(%rcx)
  1c567f:	mov    0x20(%rsp),%rax
  1c5684:	mov    %r15,0x18(%rcx)
  1c5688:	mov    %r14,0x20(%rcx)
  1c568c:	mov    %r13,0x28(%rcx)
  1c5690:	mov    %r12,0x60(%rcx)
  1c5694:	mov    %rax,0x68(%rcx)
  1c5698:	mov    %rdx,0x70(%rcx)
  1c569c:	mov    0xb0(%rsp),%rsi
  1c56a4:	mov    0x8(%rsp),%rdi
  1c56a9:	test   %rsi,%rsi
  1c56ac:	je     1c4d2d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1bd>
  1c56b2:	lea    0x17(,%rsi,8),%rax
  1c56ba:	and    $0xfffffffffffffff0,%rax
  1c56be:	add    %rax,%rsi
  1c56c1:	add    $0x11,%rsi
  1c56c5:	je     1c4d2d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1bd>
  1c56cb:	sub    %rax,%rdi
  1c56ce:	mov    $0x10,%edx
  1c56d3:	vzeroupper
  1c56d6:	call   *0x9075c(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c56dc:	jmp    1c4d2d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x1bd>
  1c56e1:	mov    0x90e90(%rip),%rdi        # 256578 <_DYNAMIC+0x940>
  1c56e8:	call   *0x90c72(%rip)        # 256360 <_DYNAMIC+0x728>
  1c56ee:	jmp    1c4e19 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x2a9>
  1c56f3:	mov    0x90e86(%rip),%rdi        # 256580 <_DYNAMIC+0x948>
  1c56fa:	call   *0x90c58(%rip)        # 256358 <_DYNAMIC+0x720>
  1c5700:	mov    %rax,%rbp
  1c5703:	jmp    1c4e33 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0x2c3>
  1c5708:	lea    0x8d9e9(%rip),%rcx        # 2530f8 <__frame_dummy_init_array_entry+0x3e18>
  1c570f:	xor    %edi,%edi
  1c5711:	mov    %rbp,%rsi
  1c5714:	mov    %r14,%rdx
  1c5717:	call   *0x9078b(%rip)        # 255ea8 <_DYNAMIC+0x270>
  1c571d:	jmp    1c5780 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc10>
  1c571f:	mov    $0x8,%edi
  1c5724:	mov    $0x8,%esi
  1c5729:	call   *0x909b9(%rip)        # 2560e8 <_DYNAMIC+0x4b0>
  1c572f:	jmp    1c5780 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc10>
  1c5731:	mov    $0x1,%bpl
  1c5734:	lea    0x8d9d5(%rip),%rdx        # 253110 <__frame_dummy_init_array_entry+0x3e30>
  1c573b:	vzeroupper
  1c573e:	call   *0x90834(%rip)        # 255f78 <_DYNAMIC+0x340>
  1c5744:	jmp    1c5780 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc10>
  1c5746:	mov    %r15,%r12
  1c5749:	mov    %r9,%rdi
  1c574c:	mov    %rcx,%rdx
  1c574f:	jmp    1c5757 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xbe7>
  1c5751:	mov    %r15,%r12
  1c5754:	mov    %rbp,%r13
  1c5757:	mov    %r13,%rsi
  1c575a:	call   *0x90818(%rip)        # 255f78 <_DYNAMIC+0x340>
  1c5760:	jmp    1c5780 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc10>
  1c5762:	mov    $0x4,%edi
  1c5767:	mov    %rbx,%rsi
  1c576a:	call   *0x90780(%rip)        # 255ef0 <_DYNAMIC+0x2b8>
  1c5770:	jmp    1c5780 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc10>
  1c5772:	mov    $0x8,%edi
  1c5777:	mov    %r14,%rsi
  1c577a:	call   *0x90770(%rip)        # 255ef0 <_DYNAMIC+0x2b8>
  1c5780:	ud2
  1c5782:	mov    0x8(%rsp),%rbx
  1c5787:	mov    %rax,%r15
  1c578a:	jmp    1c58e7 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xd77>
  1c578f:	jmp    1c582d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xcbd>
  1c5794:	mov    0x8(%rsp),%rbx
  1c5799:	mov    %rax,%r15
  1c579c:	jmp    1c593d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xdcd>
  1c57a1:	mov    %rax,%r15
  1c57a4:	test   %r12,%r12
  1c57a7:	je     1c5839 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xcc9>
  1c57ad:	mov    %r12,%rsi
  1c57b0:	shl    $0x2,%rsi
  1c57b4:	mov    $0x4,%edx
  1c57b9:	mov    %r14,%rdi
  1c57bc:	call   *0x90676(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c57c2:	jmp    1c5839 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xcc9>
  1c57c4:	mov    %rax,%r15
  1c57c7:	jmp    1c5955 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xde5>
  1c57cc:	mov    0x8(%rsp),%rbx
  1c57d1:	mov    %rax,%r15
  1c57d4:	jmp    1c58fc <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xd8c>
  1c57d9:	mov    %rax,%r15
  1c57dc:	mov    $0x1,%bpl
  1c57df:	jmp    1c587e <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xd0e>
  1c57e4:	mov    %rax,%r15
  1c57e7:	test   %rbx,%rbx
  1c57ea:	je     1c5803 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xc93>
  1c57ec:	mov    0x58(%rsp),%rdi
  1c57f1:	shl    $0x5,%rbx
  1c57f5:	mov    $0x8,%edx
  1c57fa:	mov    %rbx,%rsi
  1c57fd:	call   *0x90635(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c5803:	mov    0x90b6e(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1c580a:	mov    0x20(%rsp),%rcx
  1c580f:	xor    %ebp,%ebp
  1c5811:	xor    %ebx,%ebx
  1c5813:	lock sub %rcx,(%rax)
  1c5817:	mov    0x90b62(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1c581e:	mov    0x28(%rsp),%rcx
  1c5823:	lock sub %rcx,(%rax)
  1c5827:	mov    (%rsp),%r14
  1c582b:	jmp    1c5884 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xd14>
  1c582d:	mov    (%rsp),%r14
  1c5831:	mov    %rax,%r15
  1c5834:	jmp    1c5857 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xce7>
  1c5836:	mov    %rax,%r15
  1c5839:	mov    (%rsp),%r14
  1c583d:	test   %rbp,%rbp
  1c5840:	je     1c5857 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xce7>
  1c5842:	shl    $0x3,%rbp
  1c5846:	mov    $0x8,%edx
  1c584b:	mov    %rbx,%rdi
  1c584e:	mov    %rbp,%rsi
  1c5851:	call   *0x905e1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c5857:	mov    0x60(%rsp),%rsi
  1c585c:	mov    $0x1,%bl
  1c585e:	test   %rsi,%rsi
  1c5861:	je     1c5877 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xd07>
  1c5863:	mov    0x68(%rsp),%rdi
  1c5868:	shl    $0x3,%rsi
  1c586c:	mov    $0x8,%edx
  1c5871:	call   *0x905c1(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c5877:	xor    %ebp,%ebp
  1c5879:	jmp    1c5884 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xd14>
  1c587b:	mov    %rax,%r15
  1c587e:	mov    (%rsp),%r14
  1c5882:	mov    $0x1,%bl
  1c5884:	mov    0x38(%rsp),%rsi
  1c5889:	test   %rsi,%rsi
  1c588c:	je     1c58a2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xd32>
  1c588e:	mov    0x40(%rsp),%rdi
  1c5893:	shl    $0x3,%rsi
  1c5897:	mov    $0x8,%edx
  1c589c:	call   *0x90596(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c58a2:	mov    0x30(%rsp),%rdi
  1c58a7:	mov    $0x4,%edx
  1c58ac:	mov    %r14,%rsi
  1c58af:	call   *0x90583(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c58b5:	test   %bl,%bl
  1c58b7:	je     1c591e <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xdae>
  1c58b9:	mov    0xb8(%rsp),%rsi
  1c58c1:	mov    0x8(%rsp),%rbx
  1c58c6:	test   %rsi,%rsi
  1c58c9:	je     1c58e2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xd72>
  1c58cb:	mov    0xc0(%rsp),%rdi
  1c58d3:	shl    $0x5,%rsi
  1c58d7:	mov    $0x8,%edx
  1c58dc:	call   *0x90556(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c58e2:	test   %bpl,%bpl
  1c58e5:	je     1c58fc <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xd8c>
  1c58e7:	mov    0xe0(%rsp),%rdi
  1c58ef:	mov    0xe8(%rsp),%rsi
  1c58f7:	call   124bf0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtNtCs9k3SxhrAWiO_3std11collections4hash3map7HashMapAyj4_mNtNtCsiVdpFFRYBgM_5ahash12random_state11RandomStateEECsHW5vo2gROj_10zopro_core>
  1c58fc:	mov    0x90a75(%rip),%rax        # 256378 <_DYNAMIC+0x740>
  1c5903:	mov    0x20(%rsp),%rcx
  1c5908:	lock sub %rcx,(%rax)
  1c590c:	mov    0x90a6d(%rip),%rax        # 256380 <_DYNAMIC+0x748>
  1c5913:	mov    0x28(%rsp),%rcx
  1c5918:	lock sub %rcx,(%rax)
  1c591c:	jmp    1c593d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xdcd>
  1c591e:	mov    0x8(%rsp),%rbx
  1c5923:	test   %bpl,%bpl
  1c5926:	je     1c593d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xdcd>
  1c5928:	mov    0xe0(%rsp),%rdi
  1c5930:	mov    0xe8(%rsp),%rsi
  1c5938:	call   124bf0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtNtCs9k3SxhrAWiO_3std11collections4hash3map7HashMapAyj4_mNtNtCsiVdpFFRYBgM_5ahash12random_state11RandomStateEECsHW5vo2gROj_10zopro_core>
  1c593d:	mov    0xb0(%rsp),%rsi
  1c5945:	mov    %rbx,%rdi
  1c5948:	call   124c20 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtNtCs9k3SxhrAWiO_3std11collections4hash3set7HashSetRAyj4_NtNtCsiVdpFFRYBgM_5ahash12random_state11RandomStateEECsHW5vo2gROj_10zopro_core>
  1c594d:	mov    0x128(%rsp),%rbx
  1c5955:	mov    0x130(%rsp),%rsi
  1c595d:	test   %rbx,%rbx
  1c5960:	jne    1c5982 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xe12>
  1c5962:	test   %rsi,%rsi
  1c5965:	je     1c5987 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xe17>
  1c5967:	mov    0x138(%rsp),%rdi
  1c596f:	mov    $0x1,%edx
  1c5974:	call   *0x904be(%rip)        # 255e38 <_DYNAMIC+0x200>
  1c597a:	mov    %r15,%rdi
  1c597d:	call   24e260 <_Unwind_Resume@plt>
  1c5982:	test   %rsi,%rsi
  1c5985:	jg     1c5967 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine8coalesce10classified+0xdf7>
  1c5987:	mov    %r15,%rdi
  1c598a:	call   24e260 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
