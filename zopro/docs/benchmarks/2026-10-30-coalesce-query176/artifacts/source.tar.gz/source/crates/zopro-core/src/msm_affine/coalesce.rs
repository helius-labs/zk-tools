//! Private complete-query experiment. Reuse rejected full classification;
//! retain only repeated sums and sparse skip/replacement positions.
use super::{digit, grouping, g2_phi};
use crate::msm::BatchInverse;
use rayon::prelude::*;
use std::ops::Range;
use zopro_bn254::{Affine,CurveConfig,Fr,G1Affine,G1Config,G1Projective,G2Affine,G2Config,G2Projective,Projective};
const TILE:usize=1024;
const TAG:u32=1<<31;
#[derive(Clone,Copy,Debug,Default,PartialEq,Eq)]
pub(crate) struct Stats{pub route:u32,pub classes:usize,pub skips:usize,pub payload:usize}
#[derive(Clone,Copy)]pub(super) struct Replacement<C:CurveConfig>{pub row:u32,pub point:Affine<C>}
pub(super) struct Overlay<C:CurveConfig>{
    pub replacements:Vec<Replacement<C>>,
    pub skips:Vec<u32>,
    _charge:crate::preparation::Reservation,
}
impl<C:CurveConfig> Overlay<C>{
    pub(super) fn spans<'a>(&'a self,bases:&'a[Affine<C>],words:&[[u64;4]],range:Range<usize>,mut visit:impl FnMut(&'a[Affine<C>],&[[u64;4]],u32)){
        let mut cursor=range.start;
        let mut r=self.replacements.partition_point(|v|(v.row as usize)<cursor);
        let mut s=self.skips.partition_point(|&v|(v as usize)<cursor);
        while cursor<range.end{
            let next_r=self.replacements.get(r).map_or(range.end,|v|(v.row as usize).min(range.end));
            let next_s=self.skips.get(s).map_or(range.end,|&v|(v as usize).min(range.end));
            let next=next_r.min(next_s);
            if cursor<next{visit(&bases[cursor..next],&words[cursor..next],cursor as u32);}
            if next==range.end{break}
            assert!(next_r!=next_s,"replacement/skip disjoint");
            if next==next_r{
                visit(std::slice::from_ref(&self.replacements[r].point),&words[next..next+1],TAG|r as u32);r+=1;
            }else{s+=1;}
            cursor=next+1;
        }
    }
    pub(super) fn point(&self,bases:&[Affine<C>],id:u32)->Affine<C>{
        if id&TAG==0{bases[id as usize]}else{self.replacements[(id&!TAG)as usize].point}
    }
    fn stats(&self)->Stats{Stats{route:3,classes:self.replacements.len(),skips:self.skips.len(),payload:self.replacements.capacity()*std::mem::size_of::<Replacement<C>>()+self.skips.capacity()*4}}
}
#[derive(Clone,Copy)]struct TileGroup{row:u32,head:u16,count:u16}
fn useful(word:[u64;4],g2:bool)->bool{
    let s=if g2{g2_phi::phi_split(word)}else{word};let mut active=0;
    for w in 0..if g2{11}else{22}{
        if g2{for high in[true,false]{let i=usize::from(high)*2;let v=digit(&[s[i],s[i+1]&0x7fffffffffffffff,0,0],w,12);active+=usize::from(v!=0);if active>=2{return true}}}
        else{active+=usize::from(digit(&s,w,12)!=0);if active>=2{return true}}
    }
    false
}
fn cost<C:CurveConfig>(duplicates:usize)->Option<usize>where C::Base:BatchInverse{
    use super::grouping_cost::vector as v;
    // Charge every new metadata/output vector and a conservative formation
    // workspace before allocation. The original classification stays charged
    // separately until its arrays have been released.
    let d=duplicates;let rows=d.checked_mul(2)?;let workers=rayon::current_num_threads().max(1);
    let fields=[v::<u32>(rows,false)?,v::<usize>(d.checked_add(1)?,false)?,v::<usize>(d,false)?,v::<u32>(d,false)?,v::<u32>(d,false)?,v::<TileGroup>(d.min(TILE/2),false)?,v::<Affine<C>>(d,false)?,v::<Replacement<C>>(d,false)?,crate::msm::workspace_grouping_linear::<C>(rows,workers)?];
    // Exact reserve can temporarily retain both old/new buffers.
    fields.into_iter().try_fold(0usize,|s,v|s.checked_add(v))?.checked_mul(2)
}
fn prepare<C:CurveConfig>(bases:&[Affine<C>],values:Vec<[u64;4]>,classes:Vec<u32>,mut metadata:Vec<usize>,original_charge:crate::preparation::Reservation,parts:usize,g2:bool,allow:bool)->Option<Overlay<C>>where C::Base:BatchInverse{
    let n=bases.len();assert!((1024..65536).contains(&n));assert_eq!(classes.len(),n);
    let duplicates=metadata.iter().try_fold(0usize,|s,&c|s.checked_add(c.saturating_sub(1)))?;
    if !allow||duplicates==0{return None}
    let charge=crate::preparation::Reservation::analysis(cost::<C>(duplicates))?;
    let mut groups=Vec::<TileGroup>::new();groups.try_reserve_exact(duplicates.min(TILE/2)).ok()?;
    let(mut order,mut starts,mut counts,mut representatives,mut skips)=(Vec::<u32>::new(),Vec::<usize>::new(),Vec::<usize>::new(),Vec::<u32>::new(),Vec::<u32>::new());
    starts.try_reserve_exact(1).ok()?;starts.push(0);
    let chunk=n.div_ceil(parts);
    for part in 0..parts{
        let first=part*chunk;let end=((part+1)*chunk).min(n);
        for start in(first..end).step_by(TILE){
            let stop=(start+TILE).min(end);groups.clear();let mut links=[0u16;TILE];
            for row in start..stop{
                let class=classes[row];if class==u32::MAX{continue}
                let meta=&mut metadata[class as usize];let original=*meta&0xffff;
                if original<2||bases[row].is_identity(){continue}
                let seen=*meta>>32;
                if seen==0||seen-1<start{*meta=((row+1)<<32)|original;continue}
                let label=(*meta>>16)&0xffff;if label==0xffff{continue}
                let local=(row-start)as u16;
                if label==0{
                    if !useful(values[class as usize],g2){*meta|=0xffff<<16;continue}
                    let representative=seen-1;let old=(representative-start)as u16;
                    links[old as usize]=u16::MAX;links[local as usize]=old;
                    groups.push(TileGroup{row:representative as u32,head:local,count:2});
                    *meta|=groups.len()<<16;
                }else{
                    let g=&mut groups[label-1];links[local as usize]=g.head;g.head=local;g.count+=1;
                }
            }
            let rows=groups.iter().map(|g|g.count as usize).sum();
            order.try_reserve_exact(rows).ok()?;starts.try_reserve_exact(groups.len()).ok()?;counts.try_reserve_exact(groups.len()).ok()?;
            representatives.try_reserve_exact(groups.len()).ok()?;skips.try_reserve_exact(rows.saturating_sub(groups.len())).ok()?;
            for g in &groups{
                let a=order.len();let mut link=g.head;
                for _ in 0..g.count{assert_ne!(link,u16::MAX);order.push((start+link as usize)as u32);link=links[link as usize];}
                assert_eq!(link,u16::MAX);order[a..].reverse();assert_eq!(order[a],g.row);
                skips.extend_from_slice(&order[a+1..]);representatives.push(g.row);counts.push(g.count as usize);starts.push(order.len());
            }
        }
    }
    drop(groups);drop(values);drop(classes);drop(metadata);drop(original_charge);
    if representatives.is_empty(){return None}
    assert!(order.len()<=2*duplicates&&representatives.len()<=duplicates&&skips.len()<=duplicates);
    let sums=crate::msm::group_affine(bases,&order,&starts,&counts);
    let mut replacements=Vec::new();replacements.try_reserve_exact(representatives.len()).ok()?;
    for (row,point) in representatives.into_iter().zip(sums){replacements.push(Replacement{row,point});}
    replacements.sort_unstable_by_key(|v|v.row);skips.sort_unstable();
    assert!(replacements.windows(2).all(|v|v[0].row<v[1].row));assert!(skips.windows(2).all(|v|v[0]<v[1]));
    Some(Overlay{replacements,skips,_charge:charge})
}
fn classified(words:&[[u64;4]])->Option<grouping::Classified>{
    if !crate::simd::cpu_option("ZOPRO_CPU_DEDUP"){return None}
    grouping::classify_for_overlay(words,std::env::var("ZOPRO_CPU_ZERO_AWARE_GROUPS").as_deref()==Ok("1"))
}
fn finish<C:CurveConfig>(sums:&[Projective<C>])->Projective<C>{let mut out=Projective::<C>::IDENTITY;for sum in sums.iter().rev(){for _ in 0..12{out=out.double()}out+=*sum;}out}
pub(crate) fn a_query(bases:&[G1Affine],words:&[[u64;4]],allow:bool)->(G1Projective,Stats){
    assert_eq!(bases.len(),words.len());
    let width=std::env::var("ZOPRO_CPU_DEFER_SIGN_WIDTH").ok().and_then(|s|s.parse::<usize>().ok()).unwrap_or(13).clamp(10,14);
    let parts=std::env::var("ZOPRO_CPU_DEFER_SIGN_PARTS").ok().and_then(|s|s.parse::<usize>().ok()).unwrap_or(2).clamp(1,2);
    if !(1024..65536).contains(&bases.len())||width!=12||parts!=1||!super::borrowed_pending::enabled()||!crate::simd::cpu_option("ZOPRO_CPU_TOP_TREE"){
        return(super::msm_canonical(bases,words),Stats::default())
    }
    let overlay=match classified(words){
        Some(grouping::Classified::Full(g))=>return(super::msm_grouped(bases,&g),Stats{route:1,..Default::default()}),
        Some(grouping::Classified::Rejected{values,classes,counts,charge})=>prepare::<G1Config>(bases,values,classes,counts,charge,1,false,allow),
        None=>None,
    };
    let Some(overlay)=overlay else{return(super::msm_raw(bases,words),Stats{route:2,..Default::default()})};
    let stats=overlay.stats();let sums:Vec<_>=(0..22).into_par_iter().map(|w|{
        let buckets=if w==21{top::<G1Config>(bases,words,&overlay,0..bases.len(),4,|s|digit(s,w,12),false)}
            else{super::borrowed_pending::coalesce_window(bases,words,&overlay,w)};
        crate::msm::weighted_affine(&buckets)
    }).collect();(finish(&sums),stats)
}
pub(crate) fn b_query(bases:&[G2Affine],words:&mut[[u64;4]],allow:bool)->(G2Projective,Stats){
    assert_eq!(bases.len(),words.len());
    if !(1024..65536).contains(&bases.len())||!crate::msm::BatchAdd::<G2Config>::default().borrowed_g2_enabled(){return(super::g2_query_exclusive(bases,words),Stats::default())}
    let overlay=match classified(words){
        Some(grouping::Classified::Full(mut g))=>{
            if !(1024..65536).contains(&g.values.len()){return(crate::msm_grouped_b2(bases,&g),Stats{route:1,..Default::default()})}
            let points=crate::msm::group_affine(bases,&g.order,&g.starts,&g.counts);
            return(g2_phi::raw_exclusive(&points,&mut g.values),Stats{route:1,..Default::default()})
        }
        Some(grouping::Classified::Rejected{values,classes,counts,charge})=>prepare::<G2Config>(bases,values,classes,counts,charge,2,true,allow),
        None=>None,
    };
    let Some(overlay)=overlay else{return(g2_phi::raw_exclusive(bases,words),Stats{route:2,..Default::default()})};
    let stats=overlay.stats();words.par_iter_mut().for_each(|v|*v=g2_phi::phi_split(*v));let words=&words[..];let chunk=bases.len().div_ceil(2);
    let sums:Vec<_>=(0..11).into_par_iter().map(|w|{
        let mut buckets:Vec<_>=(0..2).into_par_iter().map(|part|{
            let range=part*chunk..((part+1)*chunk).min(bases.len());
            if w==10{
                let mut high=top::<G2Config>(bases,words,&overlay,range.clone(),64,|s|component(s,true,w),true);
                super::g2_borrowed::coalesce_phi(&mut high);
                let low=top::<G2Config>(bases,words,&overlay,range,64,|s|component(s,false,w),true);
                super::merge_buckets(&mut high,&low);high
            }else{super::g2_borrowed::coalesce_window(bases,words,&overlay,range,w)}
        }).collect();let mut combined=buckets.swap_remove(0);for other in buckets{super::merge_buckets(&mut combined,&other)}crate::msm::weighted_affine(&combined)
    }).collect();(finish(&sums),stats)
}
pub(super) fn component(s:&[u64;4],high:bool,w:usize)->i16{let i=usize::from(high)*2;let d=digit(&[s[i],s[i+1]&0x7fffffffffffffff,0,0],w,12);if s[i+1]>>63!=0{-d}else{d}}
fn top<C:CurveConfig>(bases:&[Affine<C>],words:&[[u64;4]],overlay:&Overlay<C>,range:Range<usize>,half:usize,digit:impl Fn(&[u64;4])->i16,signed:bool)->Vec<Affine<C>>where C::Base:BatchInverse{
    let mut counts=vec![0usize;half*if signed{2}else{1}];
    let bin=|d:i16|{assert!(d.unsigned_abs()as usize<=half);assert!(signed||d>=0);d.unsigned_abs()as usize-1+if d<0{half}else{0}};
    overlay.spans(bases,words,range.clone(),|points,scalars,_|{for(p,s)in points.iter().zip(scalars){let d=digit(s);if d!=0&&!p.is_identity(){counts[bin(d)]+=1}}});
    let mut starts=Vec::with_capacity(counts.len()+1);starts.push(0);for count in counts{starts.push(starts.last().unwrap()+count)}
    if *starts.last().unwrap()==0{return vec![Affine::IDENTITY;half]}
    let mut positions=starts[..starts.len()-1].to_vec();let mut order=vec![0u32;*starts.last().unwrap()];
    overlay.spans(bases,words,range,|points,scalars,base|{for(i,(p,s))in points.iter().zip(scalars).enumerate(){let d=digit(s);if d!=0&&!p.is_identity(){let b=bin(d);order[positions[b]]=base+i as u32;positions[b]+=1}}});
    let mut buckets=crate::msm::coalesce_indexed::<C,_>(&order,&starts,|i|overlay.point(bases,i));
    if signed{let mut negative=buckets.split_off(half);for p in &mut negative{p.y=-p.y;}super::merge_buckets(&mut buckets,&negative);}
    buckets
}

#[cfg(test)]mod tests{
 use super::*;
 fn points<C:CurveConfig>(n:usize)->(Vec<Affine<C>>,Vec<Fr>){let weights=(0..n).map(|i|if i%37==0{Fr::ZERO}else if i%29==0{-Fr::from((i+1)as u64)}else{Fr::from((i+1)as u64)}).collect::<Vec<_>>();let raw=weights.iter().map(|s|Projective::<C>::generator()**s).collect::<Vec<_>>();(Projective::batch_to_affine(&raw),weights)}
 fn scalars(n:usize)->Vec<[u64;4]>{let repeated=Fr::from(981723u64).pow(&[17]);let mut x=Fr::from(91u64);(0..n).map(|i|{x=x*Fr::from(6364136223846793005u64)+Fr::ONE;match i%43{0=>Fr::ZERO,1..=3=>repeated,4=>Fr::ONE,_=>x}.to_canonical()}).collect()}
 #[test]fn classification_matches_original_and_sparse_spans_are_exact(){
  for n in[1024,1025,2049]{let words=scalars(n);let original=grouping::scalar_groups(&words);let c=classified(&words).unwrap();match c{grouping::Classified::Full(g)=>{let old=original.unwrap();assert_eq!(g.values,old.values);assert_eq!(g.order,old.order);assert_eq!(g.starts,old.starts);assert_eq!(g.counts,old.counts);},grouping::Classified::Rejected{values,classes,counts,charge}=>{assert!(original.is_none());let(p,_)=points::<G1Config>(n);let overlay=prepare::<G1Config>(&p,values,classes,counts,charge,1,false,true).unwrap();let mut weighted=G1Projective::IDENTITY;overlay.spans(&p,&words,0..n,|ps,ss,base|{for(i,(&point,&s))in ps.iter().zip(ss).enumerate(){assert_eq!(point,overlay.point(&p,base+i as u32));weighted+=point*Fr::from_canonical(s).unwrap();}});let expected=p.iter().zip(&words).fold(G1Projective::IDENTITY,|s,(p,w)|s+*p*Fr::from_canonical(*w).unwrap());assert_eq!(weighted,expected);}}}
 }
 #[test]fn complete_queries_match_generator_sums_and_denial(){
  for n in[7,1025,2049]{let words=scalars(n);let (a,wa)=points::<G1Config>(n);let(b,wb)=points::<G2Config>(n);let expected=|weights:&[Fr]|weights.iter().zip(&words).fold(Fr::ZERO,|s,(w,v)|s+*w*Fr::from_canonical(*v).unwrap());for allow in[false,true]{let (ar,astats)=a_query(&a,&words,allow);let mut bw=words.clone();let(br,bstats)=b_query(&b,&mut bw,allow);assert_eq!(ar,G1Projective::generator()*expected(&wa));assert_eq!(br,G2Projective::generator()*expected(&wb));if n>=1024&&allow{assert_eq!(astats.route,3);assert_eq!(bstats.route,3);}if !allow{assert_ne!(astats.route,3);assert_ne!(bstats.route,3);}}}
 }
 #[test]fn complete_exceptions_and_partition_tile_boundaries(){
  let n=4099;let words=scalars(n);let (mut a,mut wa)=points::<G1Config>(n);let(mut b,mut wb)=points::<G2Config>(n);
  // Repeated class rows1/2 cancel and1/3 then double through the complete reducer.
  for (i,value)in[(1,Fr::from(11u64)),(2,-Fr::from(11u64)),(3,Fr::from(11u64)),(44,Fr::ONE),(45,Fr::ONE),(46,-Fr::from(2u64))]{wa[i]=value;wb[i]=value;a[i]=(G1Projective::generator()*value).to_affine();b[i]=(G2Projective::generator()*value).to_affine();}
  let sum=|weights:&[Fr]|weights.iter().zip(&words).fold(Fr::ZERO,|s,(w,v)|s+*w*Fr::from_canonical(*v).unwrap());let ea=G1Projective::generator()*sum(&wa);let eb=G2Projective::generator()*sum(&wb);
  for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||{for _ in 0..2{assert_eq!(a_query(&a,&words,true).0,ea);assert_eq!(b_query(&b,&mut words.clone(),true).0,eb);}});}
 }
}
