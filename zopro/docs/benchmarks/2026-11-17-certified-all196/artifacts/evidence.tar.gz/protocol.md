# Exact generated-proof certificate release qualification

Retain SDK194 bcc8e0775bb5bc6c09ad86b1987ca45eebac62617340911266c84aa601fa05b1
versus accepted fusion182 c285cbc88f783abac203c66db43ea86bda8207338b9fb209df7eb5d846126202.
Reuse194's three independent ref and diag backings; no SDK rebuild or new copies.
Both arms enable fusion and indexed batching. ON alone enables
ZOPRO_BENCH_CERTIFIED_OUTPUT=1. REF is the sole adoption comparator. Prior
same-binary screen/profile retain mechanism evidence; OFF is not a new veto.

Full fresh-request warm SDK boundary: witness solving, randomness, proving,
SDK verification and serialization. Loading,3primes,cold certification and export
excluded. Keep the52–64ms primary certificate setup cost from194 visible: this
is an opt-in amortized preparation choice, not a first-proof latency improvement.
Large/unsupported inputs skip scanning and retain ordinary point validation.

Ten contexts: eight supplied shapes plusmerge54 at32workers,primary also16.
23preflights: REF/ON each context plusON preparation-denied primary16,2x2/32,
merge54/32;1timed+3primes. Review before main. Main30paired rounds/context,
17timed+3primes,600processes/12000calls/10200timed samples. Rotate contexts,
reverse oddblocks,alternate arms every3blocks,backing=block%3. All captures
precede Gnark verification per phase. Duringcapture only poll confirmed live
handle; no owned builds,analysis,hashing or reporting overlap.

Prospective primary16 paired latency upper<1 and each of3backing medians<1.
Other9latency uppers<=1.02;all10CPUuppers<=1.02;eachmaxRSS<=REF*1.05+1MiB.
33checks, no minimum gain floor. Paired process means,sorted30ratio ranks10/21
one-based,nominal95.7226%marginal median coverage under independent exchangeable
blocks,no joint guarantee. No extension,dropped backing or rescue replay.
Report all8 CPU/Metal comparisons andmerge54 separately. Backing spread remains
diagnostic only. If declared release/performance checks pass,adopt exact runtime
source with opt-in retained; cosmetic cleanup/default changes are separate artifacts.

Native134core+2prover+6cubic tests and1/4/16/32worker shared-certificate
concurrency qualification inherited from exact194 source-v2. Recheck179source
hashes and receipts. Before capture run unfiltered portable noIFMA/noASM core,
prover unit andcubic suites on the unchanged source; no qualification overlay or
native test replay. Existing field arithmetic qualification inherited by identity.
Caches add two tiny owner-bound OnceLocks and global observer counters, no point
table,key copy,new pool or proof-local buffer. Racing first callers may duplicate
cold validation;194's corrected publication never holds initialization across
Rayon cooperative work. No physical ARM/mobile/hugeproof/pressure claim.

Each enabled1x2/2x2 process must show one cold key+fixed scan,zero timed scans,
andfast-parses=rounds. Other enabled shapes: zero fast-parses/scans. REF does
not expose these counters. Retain indexed-path admission assertions,including
configured preparation denial. Denial is not physical OOM. Certificate checking
allocates no new owned point buffer and remains enabled under configured denial.

Seed57410 certified-profile195/proof-sha256-after-profile.json SHA
1b037f44a6884b6dce18236ee377834ed95df9780bce4d25c8b363626f3cdb80.
Preflight57433,main58033:623freshGnarkexports,12092SDKcalls includingprimes.
No exports from portable tests. Do not branch freshness ancestry.
Commit report/decision locally; no push authorization. No AWS resources needed.
The complete all8CPU10xgoal remains active/unmet. Prepare allowance30minutes,
capture20minutes excludingverify; reuse existing xtask/readers.
