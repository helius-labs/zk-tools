use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/cyclone-scheduler-audit176";
const REPO:&str="/home/ubuntu/src/zk-tools/zopro";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn interval<'a>(source:&'a str,first:&str,end:&str)->&'a str{assert_eq!(source.matches(first).count(),1);let start=source.find(first).unwrap();let next=start+source[start..].find(end).unwrap();assert!(next>start);&source[start..next]}
fn main(){
 assert!(!Path::new(&format!("{R}/analysis.json")).exists());
 let pins=read(format!("{R}/pins.json"));for(p,h)in pins.as_object().unwrap(){assert_eq!(hash(&fs::read(p).unwrap()),h.as_str().unwrap());}
 let upstream=fs::read_to_string(format!("{R}/multiexp_affine.go")).unwrap();let pr=read(format!("{R}/pr249.json"));let pr=&pr["pull_request"];
 assert_eq!(pr["head_sha"],"33b4576efd99457757fe103ff99a5f8429b3a368");assert_eq!(pr["merged"],false);assert_eq!(pr["state"],"closed");
 let invert=interval(&upstream,"func BatchInvert(","// batch add/dbl");assert_eq!(invert.matches(".Mul(").count(),3);assert_eq!(invert.matches(".Inverse(").count(),1);
 let add=interval(&upstream,"func BatchAdd(","type queuedItem");assert_eq!(add.matches(".Mul(").count(),2);assert_eq!(add.matches(".Square(").count(),2);assert_eq!(add.matches("BatchInvert(").count(),1);
 assert!(add.contains("if isDbl[j] {\n\t\t\td.Square(&P[j].X)"));assert!(add.contains("rr.X.Square(&lambda[j])"));
 let sched=interval(&upstream,"func newBatchScheduler(","func msmProcessChunkG1AffineBatchAffine(");
 for needle in ["queue := make([]*schedItem, 0, 4096)","BatchSize = 40","for i := 0; i < pos; i++","queue = append(queue, preBatch[j])","fetchFromInput = false","for q++; q < len(queue); q++"]{assert!(sched.contains(needle),"{needle}");}
 assert!(!sched.contains("queue = queue["));assert!(!sched.contains("queue = queue[:"));assert!(sched.contains("const")==false);assert!(upstream.contains("const BATCH_SIZE = 100;"));
 let g1=fs::read_to_string(format!("{REPO}/crates/zopro-core/src/msm.rs")).unwrap();let stream=interval(&g1,"fn stream_g1_impl<","#[derive(Clone, Copy)]\nstruct Fq2AddGroup");
 let forward=interval(stream,"    } else {\n        if s.reserve_groups", "    s.tail.clear();");assert_eq!(forward.matches("chains = chains.mul(&denominator)").count(),1);assert_eq!(forward.matches("scaled_signed_dy::<FAST,SIGNED>").count(),1);
 let reverse=&stream[stream.find("for (j, g) in s.groups.iter().enumerate().rev()").unwrap()..];assert_eq!(reverse.matches(".mul(").count(),4);
 let dy=interval(&g1,"fn scaled_signed_dy<","fn stream_g1_impl<");assert!(dy.contains("signed_difference_scaled"));
 let field=fs::read_to_string(format!("{REPO}/crates/zopro-bn254/src/ifma8.rs")).unwrap();let signed=interval(&field,"pub fn signed_difference_scaled(","impl<C: FpConfig, const MIXED: bool> Ifma8<C, MIXED> {");assert_eq!(signed.matches(".mul(").count(),1);
 let g1queue=fs::read_to_string(format!("{REPO}/crates/zopro-core/src/msm_affine/borrowed_pending.rs")).unwrap();let g2queue=fs::read_to_string(format!("{REPO}/crates/zopro-core/src/msm_affine/g2_borrowed.rs")).unwrap();
 for src in [&g1queue,&g2queue]{for s in ["self.batch.len() == size","self.queue.len() == size - 1","self.busy[","self.projective(","fn take_from_queue"]{assert!(src.contains(s));}}
 let manifest=read(format!("{REPO}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));for(path,h)in manifest["source_files_sha256"].as_object().unwrap(){assert_eq!(hash(&fs::read(format!("{REPO}/{path}")).unwrap()),h.as_str().unwrap());}
 let mut digests=BTreeMap::new();for(name,body)in [("draft_BatchInvert",invert),("draft_BatchAdd",add),("draft_scheduler",sched),("accepted_G1_stream",stream)]{digests.insert(name,hash(body.as_bytes()));}
 let out=json!({"complete":true,"upstream_PR":249,"upstream_PR_closed_unmerged":true,"upstream_ref":pr["head_sha"],"upstream_Git_blob":"417838a31072830bcdbdf4ce6b607d735127ad44","upstream_source_sha256":hash(upstream.as_bytes()),"body_sha256":digests,"pins_checked":pins.as_object().unwrap().len(),"accepted_original_source_files_checked":176,"draft_normal_batch":{"inverse_muls_per_element":3,"inverse_calls_per_nonempty_batch":1,"addition_muls_per_element":2,"addition_squares_per_element":1,"ordinary_total_M_per_element":5,"ordinary_total_S_per_element":1,"doubling_extra_S_per_element":1},"accepted_G1_full_group":{"forward_vector_products":2,"reverse_vector_products_including_square":4,"ordinary_total_vector_products":6,"shared_inverse_and_tail_costs_not_in_this_total":true},"draft_candidate_batch_sizes":[40,100],"draft_conflict_scan":"linear within each candidate batch","draft_queue":"append-only conflict pointers, no implemented bound; processed prefix retained","accepted_queue":"busy-bitset, bounded batch/queue and projective overflow","novel_arithmetic_or_dependency_reduction_selected":false,"upstream_code_executed":false,"new_prover_builds_or_tests":0,"new_SDK_requests":0,"new_proofs":0,"canonical_proof_ledger":31913,"production_changed":false,"adopted":false,"speed_or_memory_claim":false,"scope":"historical draft source only, not current Gnark CPU prover or current gnark-crypto whole implementation"});
 fs::write(format!("{R}/analysis.json"),serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("PASSsourceidentities/176acceptedhashes/normal5M+1S;no newmechanismselected");
}
