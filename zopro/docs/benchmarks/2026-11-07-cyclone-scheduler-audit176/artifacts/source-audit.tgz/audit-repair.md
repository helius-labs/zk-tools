# Source-site assertion repair

The first helper compiles, then fails its BatchAdd static multiplication-site assertion:3sites, expected2. There is one lambda multiplication in each mutually exclusive doubling/ordinary branch, plus one y-coordinate multiplication. The hand-counted normal operation total remains2M+1S in BatchAdd and5M+1S including BatchInvert.

The repaired helper distinguishes static sites from the ordinary executed branch: three sites overall, two mutually exclusive lambda sites, one ordinary lambda call and one coordinate call. It retains the unchanged arithmetic total and adds explicit interval checks. Original source/failed run remain; only the failed audit is repeated with the modified helper, with no prover build/test/model/proof replay.

The second helper compiles, then stops at its own source pin: its internal pin path still names the original manifest while the workflow uses the updated manifest. The final helper accepts the exact active pin manifest as an argument and includes the failing path in diagnostics. Both earlier source versions and failed workflows remain. This repairs diagnostic pin routing, without changing the source arithmetic count or a performance gate.
