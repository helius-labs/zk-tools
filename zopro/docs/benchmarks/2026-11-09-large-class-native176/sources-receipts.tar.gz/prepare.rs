use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/large-class-tiles176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
const P: &str = "/home/ubuntu/src/zopro-perf-work/initial-unit176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(f: &str, v: Value) {
    fs::write(format!("{R}/{f}"), serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn main() {
    assert!(!Path::new(R).join("source").exists());
    let manifest=format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json");
    let m = read(&manifest);
    let originals = m["source_files_sha256"].as_object().unwrap();
    assert_eq!(originals.len(), 176);
    let mut pins = BTreeMap::new();
    for (rel, h) in originals {
        let p = format!("{Z}/{rel}");
        assert_eq!(hash(&p), h.as_str().unwrap());
        let to = format!("{R}/source/{rel}");
        fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();
        fs::copy(&p, &to).unwrap();
        pins.insert(p, h.clone());
    }
    let rel = "crates/zopro-core/src/msm.rs";
    let path = format!("{R}/source/{rel}");
    let mut text = fs::read_to_string(&path).unwrap();
    let before = "    const GROUP: usize = 256;\n    let n = counts.len();";
    assert_eq!(text.matches(before).count(), 1);
    let guard="all(zopro_large_class_tiles,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma))";
    let after=format!("    #[cfg({guard})]\n    if crate::simd::cpu_option(\"ZOPRO_CPU_LARGE_CLASS_TILES\") {{\n        if let Some(result)=large_class_tiles::try_reduce::<C,_>(&get,order,starts,counts) {{return result;}}\n    }}\n{before}");
    text = text.replace(before, &after);
    let suffix = format!("\n#[cfg({guard})]\nmod large_class_tiles;\n");
    text.push_str(&suffix);
    fs::write(path, text).unwrap();
    let extra = ["large_class_tiles.rs", "large_class_tests.rs"];
    for f in extra {
        let to = format!("{R}/source/crates/zopro-core/src/msm/{f}");
        fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();
        fs::copy(format!("{R}/{f}"), to).unwrap();
    }
    save(
        "source-audit.json",
        json!({"manifest":manifest,"originals":originals,"parent":rel,"before":before,"after":after,"suffix":suffix,"extras":extra,"exact_originals":175,"recoverable_originals":1,"field_original1200_unchanged":true,"production_unchanged":true}),
    );
    let old = read(format!("{P}/plan.json"));
    let mut steps = vec![];
    for variant in ["OFF", "ON"] {
        fs::create_dir_all(format!("{R}/libs/{variant}")).unwrap();
        let mut s = old["steps"][0].clone();
        s["name"] = json!(format!("build-core-{variant}"));
        for v in s["argv"].as_array_mut().unwrap() {
            *v = json!(v
                .as_str()
                .unwrap()
                .replace(P, R)
                .replace(
                    "initial_unit176_OFF",
                    &format!("large_class_tiles176_{variant}")
                )
                .replace("libs/OFF", &format!("libs/{variant}")));
        }
        if variant == "ON" {
            s["argv"]
                .as_array_mut()
                .unwrap()
                .extend([json!("--cfg"), json!("zopro_large_class_tiles")]);
        }
        s["environment"]["CARGO_MANIFEST_DIR"] = json!(format!("{R}/source/crates/zopro-core"));
        steps.push(s);
    }
    let mut test = old["steps"]
        .as_array()
        .unwrap()
        .iter()
        .find(|v| v["name"] == "build-core-OFF-test")
        .unwrap()
        .clone();
    test["name"] = json!("build-native-tests");
    for v in test["argv"].as_array_mut().unwrap() {
        *v = json!(v
            .as_str()
            .unwrap()
            .replace(P, R)
            .replace("initial_unit176_OFF-test", "large_class_tiles176_test")
            .replace("core-tests-OFF-test", "native-tests"));
    }
    test["argv"]
        .as_array_mut()
        .unwrap()
        .extend([json!("--cfg"), json!("zopro_large_class_tiles")]);
    test["environment"]["CARGO_MANIFEST_DIR"] = json!(format!("{R}/source/crates/zopro-core"));
    steps.push(test);
    steps.push(json!({"kind":"command","name":"qualify-native-large-classes","argv":[format!("{R}/native-tests"),"msm::large_class_tiles::qualification::","--nocapture","--test-threads=1"],"timeout_seconds":900,"environment":{}}));
    let mut generic = read("/home/ubuntu/src/zopro-perf-work/busy-reset176/repair-plan.json")
        ["steps"]
        .as_array()
        .unwrap()
        .last()
        .unwrap()
        .clone();
    generic["name"] = json!("generic-large-class-guard");
    for v in generic["argv"].as_array_mut().unwrap() {
        *v = json!(v
            .as_str()
            .unwrap()
            .replace("/home/ubuntu/src/zopro-perf-work/busy-reset176", R)
            .replace("busy_reset176_generic", "large_class_tiles176_generic"));
    }
    generic["argv"]
        .as_array_mut()
        .unwrap()
        .extend([json!("--cfg"), json!("zopro_large_class_tiles")]);
    generic["environment"]["CARGO_MANIFEST_DIR"] = json!(format!("{R}/source/crates/zopro-core"));
    steps.push(generic);
    for (rel, _) in originals {
        let p = format!("{R}/source/{rel}");
        pins.insert(p.clone(), json!(hash(p)));
    }
    for f in extra {
        let p = format!("{R}/source/crates/zopro-core/src/msm/{f}");
        pins.insert(p.clone(), json!(hash(p)));
    }
    for f in [
        "large_class_tiles.rs",
        "large_class_tests.rs",
        "design.md",
        "prepare.rs",
        "prepare",
        "source-audit.json",
    ] {
        let p = format!("{R}/{f}");
        pins.insert(p.clone(), json!(hash(p)));
    }
    for s in &steps {
        for v in s["argv"].as_array().unwrap() {
            let a = v.as_str().unwrap();
            let p = a.split_once('=').map_or(a, |(_, p)| p);
            if Path::new(p).is_file() {
                pins.insert(p.to_owned(), json!(hash(p)));
            }
        }
    }
    save(
        "build-plan.json",
        json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"steps":steps}),
    );
    pins.insert(
        format!("{R}/build-plan.json"),
        json!(hash(format!("{R}/build-plan.json"))),
    );
    save("build-pins.json", json!(pins));
    println!("Prepared5nativecommands:OFF/ON/testbuild/3focusedtests/genericguard;176originalsbound;noSDKorlatency");
}
