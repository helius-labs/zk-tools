use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const R: &str = "/home/ubuntu/src/zopro-perf-work/large-class-tiles176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(f: &str, v: Value) {
    fs::write(format!("{R}/{f}"), serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn main() {
    assert!(!Path::new(R).join("review-result.json").exists());
    let pins = read(format!("{R}/build-pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap(), "{p}");
    }
    let a = read(format!("{R}/source-audit.json"));
    let originals = a["originals"].as_object().unwrap();
    assert_eq!(originals.len(), 176);
    for (rel, h) in originals {
        assert_eq!(hash(format!("{Z}/{rel}")), h.as_str().unwrap());
        let p = format!("{R}/source/{rel}");
        let mut b = fs::read(&p).unwrap();
        if rel == a["parent"].as_str().unwrap() {
            let mut t = String::from_utf8(b).unwrap();
            let suffix = a["suffix"].as_str().unwrap();
            assert!(t.ends_with(suffix));
            t.truncate(t.len() - suffix.len());
            let after = a["after"].as_str().unwrap();
            assert_eq!(t.matches(after).count(), 1);
            t = t.replace(after, a["before"].as_str().unwrap());
            b = t.into_bytes();
        }
        assert_eq!(format!("{:x}", Sha256::digest(b)), h.as_str().unwrap());
    }
    for f in a["extras"].as_array().unwrap() {
        let f = f.as_str().unwrap();
        assert_eq!(
            hash(format!("{R}/{f}")),
            hash(format!("{R}/source/crates/zopro-core/src/msm/{f}"))
        );
    }
    let p = read(format!("{R}/build-plan.json"));
    assert_eq!(p["steps"].as_array().unwrap().len(), 5);
    assert_eq!(
        read(format!("{R}/build-run/result.json"))["status"],
        "complete"
    );
    let mut receipts = vec![];
    let field="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/frozen/candidate/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib";
    for s in p["steps"].as_array().unwrap() {
        let name = s["name"].as_str().unwrap();
        let d = format!("{R}/build-run/{name}");
        let e = read(format!("{d}/exit.json"));
        assert_eq!(e["success"], true);
        assert_eq!(e["returncode"], 0);
        let c = read(format!("{d}/command.json"));
        let argv = s["argv"].as_array().unwrap();
        assert_eq!(
            &c["argv"].as_array().unwrap()[..4],
            &[
                json!("timeout"),
                json!("-k"),
                json!("5s"),
                json!(format!("{}s", s["timeout_seconds"]))
            ]
        );
        assert_eq!(&c["argv"].as_array().unwrap()[4..], argv);
        for (k, v) in s["environment"].as_object().unwrap() {
            if !k.starts_with("CARGO_") {
                assert_eq!(c["environment"][k], *v);
            }
        }
        for stream in ["stdout", "stderr"] {
            assert_eq!(
                hash(format!("{d}/{stream}.log")),
                e[format!("{stream}_sha256")]
            );
        }
        if name.starts_with("build-") {
            assert!(argv.iter().any(|v| v == &format!("zopro_bn254={field}")));
            assert!(argv.iter().any(|v| v == "target-cpu=native"));
            assert!(argv.iter().any(|v| v == "codegen-units=1"));
            assert!(argv.iter().any(|v| v == "zopro_dense_busy_reset"));
            assert!(!argv.iter().any(|v| v == "zopro_initial_unit"));
            assert_eq!(
                argv.iter().any(|v| v == "zopro_large_class_tiles"),
                name != "build-core-OFF"
            );
        }
        if name == "generic-large-class-guard" {
            for flag in [
                "zopro_large_class_tiles",
                "no_asm",
                "no_ifma",
                "target-cpu=x86-64",
            ] {
                assert!(argv.iter().any(|v| v == flag));
            }
        }
        receipts
            .push(json!({"name":name,"exit_sha256":hash(format!("{d}/exit.json")),"success":true}));
    }
    let test = fs::read_to_string(format!(
        "{R}/build-run/qualify-native-large-classes/stdout.log"
    ))
    .unwrap();
    for n in [
        "3 passed; 0 failed",
        "127 filtered out",
        "LARGE_CLASS_BOUNDARY_CASES=194",
        "LARGE_CLASS_WORKERS=53;concurrent_callers=4;complete_curve_cases=162",
        "LARGE_CLASS_RESOURCE_CASES=15;denial_before_getter=true;getter_panic_recovered=true",
    ] {
        assert!(test.contains(n), "{n}");
    }
    let errors = fs::read_to_string(format!(
        "{R}/build-run/qualify-native-large-classes/stderr.log"
    ))
    .unwrap();
    assert!(errors.contains("intentional getter panic"));
    let mut identities = BTreeMap::new();
    for (tag, path) in [
        ("OFF", format!("{R}/libs/OFF/libzopro_core.rlib")),
        ("ON", format!("{R}/libs/ON/libzopro_core.rlib")),
        ("generic", format!("{R}/libzopro_core-generic.rlib")),
    ] {
        let o = Command::new("nm").args(["-C", &path]).output().unwrap();
        assert!(o.status.success());
        let nm = String::from_utf8(o.stdout).unwrap();
        assert_eq!(
            nm.contains("zopro_core::msm::large_class_tiles::try_reduce"),
            tag == "ON"
        );
        assert!(!nm.contains("zopro_core::msm::large_class_tiles::qualification"));
        fs::write(format!("{R}/{tag}.nm"), &nm).unwrap();
        identities.insert(tag,json!({"path":path,"sha256":hash(&path),"nm_sha256":hash(format!("{R}/{tag}.nm")),"candidate_namespace":tag=="ON","qualification_symbols_absent":true}));
    }
    let mut schedule_cases = 0usize;
    for tile in [1024usize, 2048] {
        for n in [
            0usize,
            1,
            tile - 1,
            tile,
            tile + 1,
            2 * tile,
            2 * tile + 1,
            5 * tile + 7,
            65537,
        ] {
            let expected = n.saturating_sub(1);
            let joins = if n > tile {
                let sizes = (0..n)
                    .step_by(tile)
                    .map(|first| (n - first).min(tile))
                    .collect::<Vec<_>>();
                let joined = sizes.iter().map(|n| n - 1).sum::<usize>() + sizes.len() - 1;
                assert_eq!(sizes.iter().sum::<usize>(), n);
                joined
            } else {
                expected
            };
            assert_eq!(joins, expected);
            schedule_cases += 1;
        }
    }
    assert_eq!(schedule_cases, 18);
    let ledger = "/home/ubuntu/src/zopro-perf-work/empty-inverse-census176/proof-sha256-after.json";
    assert_eq!(read(ledger).as_array().unwrap().len(), 43083);
    save("identities.json", json!(identities));
    save("receipts.json", json!(receipts));
    let v = json!({"passed":true,"build_pins":pins.as_object().unwrap().len(),"successful_native_commands":5,"tests":3,"old_tests_filtered":127,"boundary_curve_cases":194,"threaded_curve_cases":162,"actual_workers":53,"concurrent_callers":4,"requested_worker_stack_bytes":524288,"resource_cases":15,"independent_scalar_join_topology_cases":schedule_cases,"independent_math_oracle":"Arkworks generator-weight sums from full-width coefficients","source_originals":176,"exact_originals":175,"reversible_parents":1,"new_children":2,"production_unchanged":true,"original_field1200_sha256":hash(field),"generic_guard_passed":true,"release_test_namespace_absent":true,"release_nm_invocations_outside_native_workflow":3,"native_implementation_qualified":true,"complete_MSM_or_SDK_qualified":false,"performance_measured":false,"adopted":false,"new_SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":43083,"ledger_sha256":hash(ledger),"goal_active":true,"goal_complete":false,"targets_met":0});
    save("review-result.json", v);
    println!("LARGE_CLASS_NATIVE_REVIEW_PASS376pins/5commands/3tests/194boundarycases/162threadedcases/176sourcebindings;noSDKorlatency");
}
