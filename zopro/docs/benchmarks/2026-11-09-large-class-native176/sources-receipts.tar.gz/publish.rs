use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    fmt::Write as _,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/large-class-tiles176";
const D: &str = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-large-class-native176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn walk(p: &Path, v: &mut Vec<PathBuf>) {
    for e in fs::read_dir(p).unwrap() {
        let e = e.unwrap();
        if e.file_type().unwrap().is_dir() {
            walk(&e.path(), v)
        } else if e.file_type().unwrap().is_file() {
            v.push(e.path())
        }
    }
}
fn main() {
    assert!(!Path::new(D).exists());
    let q = read(format!("{R}/review-result.json"));
    assert_eq!(q["passed"], true);
    assert_eq!(q["canonical_proofs"], 43083);
    for (p, h) in read(format!("{R}/build-pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let decision = json!({"native_correctness_qualified":true,"complete_query_qualified":false,"complete_SDK_qualified":false,"performance_measured":false,"adopted":false,"production_unchanged":true,"next":"Freeze matched complete-consumer controls/resource/profiling/reader protocol before preflight; primary negative control and actual covered larger groups","new_SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":43083,"goal_active":true,"goal_complete":false,"targets_met":0});
    save(format!("{R}/decision.json"), decision);
    fs::create_dir_all(format!("{D}/artifacts")).unwrap();
    for f in [
        "design.md",
        "next.md",
        "large_class_tiles.rs",
        "large_class_tests.rs",
        "review-result.json",
        "source-audit.json",
        "identities.json",
        "receipts.json",
        "decision.json",
    ] {
        fs::copy(format!("{R}/{f}"), format!("{D}/artifacts/{f}")).unwrap();
    }
    let mut report=String::from("# Oversized scalar-class splitting: native qualification\n\n**The private implementation passes native correctness and fallback checks. Performance is unmeasured; production is unchanged.** It splits oversized repeated-scalar classes across existing point tiles, then combines their partial roots through the original complete affine kernel. This stage does not establish a faster complete query or proof.\n\nOriginal grouping assigns up to 256 classes to a job, so one unusually large class remains serial inside that job. The retained [all-eight grouping audit](../2026-11-07-g1-large-coverage176/README.md) observed admitted A classes up to 15,072 points. Those populations do not identify the current proof's critical path. Primary A grouping declines, so this mechanism alone is not a route to the primary 3.7 ms target.\n\nOnly classes larger than the original indexed-reducer tile—2,048 points for G1 or 1,024 for G2—split into concurrent unchanged pair trees. A second pass retains 256 output classes per job, reading partial roots for split classes and original inputs for all other classes. It builds no duplicate input-order array and creates no task per singleton. It preserves both ordinary and prepared-point getters. The [Barretenberg batched-affine documentation](https://barretenberg.aztec.network/api/classbb_1_1_batched_affine_addition) also describes splitting long addition sequences among threads; this independently written implementation uses Zopro's existing tile geometry.\n\nThe native snapshot has 178 files: 175 accepted originals remain exact, one parent recovers through the recorded hook and module suffix, and two children contain the reducer and tests. Original field library1200, point formulas, grouping admission, scalar decomposition, windows, solver/key code, allocator and pool remain unchanged. The OFF and ON optimized cores use native/O3/one-CGU flags and the accepted bitmap reset. Release symbol checks find the candidate namespace only in ON and no test namespace in either. No downstream SDK is built here.\n\nBefore allocation, checked optional admission charges task descriptors, partial roots, one class-prefix array, vector overhead and the entire first-pass worker-scratch bound, conservatively on top of the old consumer forecast. First-pass scratch drops before the output pass starts. No-split, denied, overflow, disabled and generic paths retain the original reducer. This introduces no retained point table, expanded key, new pool or artificial global RAM limit. The forecast is not allocated-byte measurement, emitted stack peak, RSS or minimum RAM. Extra partial roots, inversion calls and a second parallel pass may outweigh the additional parallelism.\n\nThree new focused tests pass; 127 inherited tests are filtered, not replayed.\n\n|New checks|Coverage|\n|---|---|\n|Boundary fixtures|194 G1/G2 cases; empty, singleton, odd, tile and 256-class edges; identities, repeated/opposite points and cancellation|\n|Independent results|Arkworks generator-weight sums from full-width coefficients; ordinary/prepared access and exactly one getter read per original input|\n|Worker execution|All 53 actual workers across 1/4/16/32-worker pools requesting 512 KiB stacks|\n|Concurrent callers|Four OS callers share one eight-worker pool; worker and concurrent phases total 162 curve cases|\n|Resource and panic behavior|15 checked-cost/overflow/denial cases; denied admission invokes no getter; original fallback and intentional getter-panic recovery pass|\n|Generic guard|NoASM/noIFMA core compiles with the candidate cfg present and native module excluded|\n\nThese counts describe constructed correctness fixtures, not unique witnesses, production proofs or throughput measurements. Ordinary and prepared calls reuse each fixture. The independent group oracle does not share the native addition formulas. Complete query/proof, ARM/mobile and pressure/swap behavior remain unqualified.\n\nAll five native Rust1.98.1/xtask commands succeed first execution. A separate Rust reader checks 376 pins, exact argv and stream hashes, source recovery, test populations, release identities and 18 scalar join-topology cases. The latter show that split and final reductions preserve n−1 generic joins per nonempty class; they do not price inversions or exceptions. Three reader-invoked nm checks and setup/review/publication helpers are outside the five-command workflow. All 176 production hashes and canonical 43,083-proof ledger remain unchanged. There are zero new SDK requests, Gnark exports, latency captures, PMU panels or profiles.\n\nNext is a prospectively frozen complete-consumer comparison using the exact qualified ON core, fresh OFF and accepted REF, with relevant large-class coverage, unchanged primary controls, resources and automatic profiles. Any later adoption still needs coherent all-eight plus merge54 SDK/Gnark qualification. Native correctness alone selects no optimization.\n\nThe full CPU10× goal remains active and unmet, **0/8**. Accepted local 32-worker full-proof observations and supplied M5 references below are inherited from the latest unchanged SDK comparison. Cross-machine ratios do not establish equal hardware efficiency.\n\n|Shape|Accepted CPU ms|M5 CPU ms /speedup|M5 Metal ms /speedup|CPU10× target ms|\n|---|---:|---:|---:|---:|\n");
    let ms = [
        7.803403940,
        10.940318516,
        15.809849355,
        24.043742968,
        33.720354516,
        39.753009613,
        65.983136871,
        65.378103258,
    ];
    let cpu = [37., 59., 109., 189., 284., 335., 528., 507.];
    let metal = [24., 30., 48., 74., 101., 124., 176., 175.];
    let names = [
        "1x2",
        "2x2",
        "4x2",
        "8x2",
        "12x2",
        "16x2",
        "24x2",
        "merge-24x1",
    ];
    for i in 0..8 {
        writeln!(
            report,
            "|{}|{:.6}|{:.1} /{:.3}×|{:.1} /{:.3}×|{:.1}|",
            names[i],
            ms[i],
            cpu[i],
            cpu[i] / ms[i],
            metal[i],
            metal[i] / ms[i],
            cpu[i] / 10.
        )
        .unwrap();
    }
    report.push_str("\nAccepted primary peak RSS remains 132.50 MiB; merge54 remains 162.189200 ms without a supplied M5 reference. No new AWS/Aeglos, phone/ARM, huge-circuit, pressure/swap, minimum-RAM or concurrent-throughput evidence is added.\n\n[Design](artifacts/design.md), [native reducer](artifacts/large_class_tiles.rs), [tests](artifacts/large_class_tests.rs), [source recovery](artifacts/source-audit.json), [independent review](artifacts/review-result.json), [release identities](artifacts/identities.json), [receipts](artifacts/receipts.json), [decision](artifacts/decision.json), [continuation](artifacts/next.md), [sources and receipts](sources-receipts.tar.gz), [archive index](artifacts/archive-index.json), [checksums](SHA256SUMS). Executables/libraries, full unchanged source copies, keys/images/points/scalars/witnesses/proofs and the full ledger remain local. Private root: /home/ubuntu/src/zopro-perf-work/large-class-tiles176.\n");
    fs::write(format!("{D}/README.md"), &report).unwrap();
    let pack = PathBuf::from(format!("{R}/publication-source"));
    fs::create_dir(&pack).unwrap();
    let mut files = vec![];
    for f in [
        "large_class_tiles.rs",
        "large_class_tests.rs",
        "prepare.rs",
        "review.rs",
        "publish.rs",
        "design.md",
        "next.md",
        "source-audit.json",
        "review-result.json",
        "identities.json",
        "receipts.json",
        "decision.json",
        "build-plan.json",
        "build-pins.json",
    ] {
        files.push(PathBuf::from(format!("{R}/{f}")));
    }
    walk(Path::new(&format!("{R}/build-run")), &mut files);
    let mut members = vec![];
    for p in files {
        let rel = p.strip_prefix(R).unwrap();
        let bytes = fs::read(&p).unwrap();
        assert!(std::str::from_utf8(&bytes).is_ok());
        let to = pack.join(rel);
        fs::create_dir_all(to.parent().unwrap()).unwrap();
        fs::write(&to, &bytes).unwrap();
        members.push(json!({"path":rel,"bytes":bytes.len(),"sha256":hash(to)}));
    }
    let archive = format!("{D}/sources-receipts.tar.gz");
    assert!(Command::new("tar")
        .args(["-czf", &archive, "-C", pack.to_str().unwrap(), "."])
        .status()
        .unwrap()
        .success());
    let round = format!("{R}/publication-roundtrip");
    fs::create_dir(&round).unwrap();
    assert!(Command::new("tar")
        .args(["-xzf", &archive, "-C", &round, "."])
        .status()
        .unwrap()
        .success());
    for m in &members {
        assert_eq!(
            hash(Path::new(&round).join(m["path"].as_str().unwrap())),
            m["sha256"]
        );
    }
    save(
        format!("{D}/artifacts/archive-index.json"),
        json!({"archive_sha256":hash(&archive),"members":members,"release_nm":"retained locally,hashes inidentities.json","ledger_sha256":q["ledger_sha256"],"excluded":"unchanged full source,binaries/libraries,private key/input/point/scalar/witness/proof data,fullledger,raw nm"}),
    );
    fs::write(format!("{D}/SHA256SUMS"), "").unwrap();
    let mut links = 0;
    for s in report.split("](").skip(1) {
        let p = s.split(')').next().unwrap();
        if p.starts_with("https://") {
            continue;
        }
        assert!(Path::new(D).join(p).exists(), "{p}");
        links += 1;
    }
    let result = json!({"passed":true,"native_commands":5,"native_tests":3,"archive_members":members.len(),"archive_roundtrip":true,"local_links":links,"native_implementation_qualified":true,"performance_measured":false,"complete_SDK_qualified":false,"production_unchanged":true,"adopted":false,"canonical_proofs":43083,"new_SDK_requests":0,"new_Gnark_exports":0,"all8_CPU_Metal_rows":8,"goal_active":true,"goal_complete":false,"targets_met":0});
    save(format!("{R}/publication.json"), result.clone());
    save(format!("{D}/artifacts/publication.json"), result);
    let mut files = vec![];
    walk(Path::new(D), &mut files);
    files.sort();
    let mut sums = String::new();
    for p in files {
        if p.file_name().unwrap() == "SHA256SUMS" {
            continue;
        }
        writeln!(
            sums,
            "{}  {}",
            hash(&p),
            p.strip_prefix(D).unwrap().display()
        )
        .unwrap();
    }
    fs::write(format!("{D}/SHA256SUMS"), &sums).unwrap();
    for line in sums.lines() {
        let (h, p) = line.split_once("  ").unwrap();
        assert_eq!(hash(Path::new(D).join(p)), h);
    }
    println!("LARGE_CLASS_PUBLICATION_PASS{}members/{links}locallinks;nativecorrectnessqualified;speedunmeasured;goalactive0of8",members.len());
}
