use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::{Path,PathBuf},process::Command,fmt::Write as _};
const R:&str="/home/ubuntu/src/zopro-perf-work/initial-unit176";
const D:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-initial-unit176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn walk(p:&Path,out:&mut Vec<PathBuf>){for e in fs::read_dir(p).unwrap(){let e=e.unwrap();if e.file_type().unwrap().is_dir(){walk(&e.path(),out);}else if e.file_type().unwrap().is_file(){out.push(e.path());}}}
fn main(){
 assert!(!Path::new(D).exists());let q=read(format!("{R}/review-result.json"));let l=read(format!("{R}/link-review.json"));assert_eq!(q["passed"],true);assert_eq!(l["passed"],true);assert_eq!(l["speed_measured"],false);
 for set in["repair-pins.json","sdk-build-pins.json"]{for(p,h)in read(format!("{R}/{set}")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}}
 let ledger="/home/ubuntu/src/zopro-perf-work/unit-z-sdk176/proof-sha256-after-capture.json";assert_eq!(read(ledger).as_array().unwrap().len(),42438);
 fs::create_dir_all(format!("{D}/artifacts")).unwrap();for f in["design.md","next.md","source-audit.json","review-result.json","link-review.json","test-repair.json"]{fs::copy(format!("{R}/{f}"),format!("{D}/artifacts/{f}")).unwrap();}
 let comparison=read("/home/ubuntu/src/zopro-perf-work/unit-z-sdk176/fresh-comparison.json");let rows=comparison["rows"].as_array().unwrap();assert_eq!(rows.len(),8);
 let mut report=String::from(r#"# Initial-affine accumulator state qualification

**The private candidate passes native and generic qualification, and matching SDKs are built. Speed is unmeasured; production is unchanged.** The accepted build's latest matched 1×2 measurement remains **7.803149 ms** with32workers. The earlier [global unit-Z method](../2026-11-09-unit-z-sdk176/README.md) remains rejected.

This candidate records that an exceptional projective accumulator was initialized from a nonidentity affine point. It uses a spare bit in its existing sparse index and consumes that information on its first update or finish join. The specialized complete addition needs no dynamic Z comparison. Subsequent updates retain the accepted field method. G2's endomorphism preserves Z and therefore this initial state.

The accepted field source and original field library remain unchanged in both arms. All176 accepted original files recover exactly:173 are byte-exact and three contain reversible private edits. A private helper module is added. No Window fields, vector dimensions/capacities, table, key copy, plan, pool, allocator, forecast or memory policy changes. Bucket domains below2^31 permit tagged indices while preserving the empty sentinel; larger domains retain the original full-width representation. Synthetic boundary checks do not establish physical32-bit or ARM execution.

At most one ordinary mixed addition per eligible accumulator saves three field multiplications and two squares. This must pay for index masking, domain/flag checks, clearing stores and a new finish lookup. No proof-wide eligibility fraction or latency gain is established.

The targeted core tests exercise actual index state, identity/equal/opposite additions, queue flush, finish, endomorphism and independent Arkworks bucket results. The helper additionally matches the accepted raw Jacobian outputs and independent Arkworks results. Each Window test uses53 actual broadcast workers across1/4/16/32-worker pools with requested512KiB stacks, followed by four callers sharing an eight-worker pool.

|Arm|Tests passed|Window case executions|Helper output checks|Synthetic encoding checks|
|---|---:|---:|---:|---:|
|Native OFF|4|138|2048|60|
|Native ON|4|138|2048|60|
|Generic ON|3|69|2048|60|

Fixtures are reused across arms; execution totals are not distinct proof counts. Generic execution covers the G1 Window and both-curve helper; the native-only G2 Window is unavailable with noIFMA. Native ON per curve logs1608 tagged updates,469 tagged finish joins and4036 other recorded updates. Those are fixture observations, not proof-workload savings. All345 Window cases pass. Older unchanged field and bitmap-reset suites are not replayed.

Two native core libraries, three targeted test binaries/runs and six downstream builds complete:14 successful workflow commands. One initial test compile fails because the Arkworks G2 oracle cannot multiply-assign Fq2 by Fq; the test expression is corrected componentwise. Both completed runtime libraries are reused, with no runtime source change. The failed receipt and original test source are retained. A repair helper has a borrow-check compile fix, and the review reader is corrected to handle unchanged binary source assets without UTF-8 decoding. These manual helper attempts lack complete xtask receipts; no successful scientific work is replayed for them.

Source/receipt/link reviews bind both core/prover/zolana/SDK chains to the same original field and the unchanged fixed-placement driver, nativeO3/fatLTO/oneCGU configuration. Release binaries contain no qualification helpers. No SDK request, timed proof, PMU recording or profile is run in this qualification stage. New complete-proof correctness and performance remain to be measured before any adoption.

The following are the **previously measured accepted REF observations**, carried forward from the linked completed campaign. M5CPU and Metal are supplied historical figures from different hardware; neither is remeasured here. This candidate has no timing column because it has not been timed.

|Shape|Accepted CPU ms|M5 CPU ms / speedup|M5 Metal ms / speedup|CPU10x target ms|
|---|---:|---:|---:|---:|
"#);
 for r in rows{writeln!(report,"|{}|{:.6}|{} /{:.3}x|{} /{:.3}x|{}|",r["shape"].as_str().unwrap(),r["REF_CPU_ms"].as_f64().unwrap(),r["M5_CPU_ms"],r["REF_CPU_speedup"].as_f64().unwrap(),r["M5_Metal_ms"],r["REF_Metal_speedup"].as_f64().unwrap(),r["CPU_10x_target_ms"]).unwrap();}
 report.push_str("\nThe full all-eight goal remains active and unmet, **0/8**. Next is the frozen complete SDK comparison with all-eight shapes, merge54, primary single/16/32-worker conditions, automatic PMU/profiles and fresh Gnark verification. Canonical proof inventory remains42438; this stage adds zero exported proofs. No new AWS/Aeglos, ARM/mobile, huge-circuit, memory-pressure, swap, minimum-RAM or throughput result is claimed.\n\n[Design](artifacts/design.md), [qualification review](artifacts/review-result.json), [link review](artifacts/link-review.json), [source recovery](artifacts/source-audit.json), [test correction](artifacts/test-repair.json), [continuation](artifacts/next.md), [sources and receipts](sources-receipts.tar.gz), [archive index](artifacts/archive-index.json), [checksums](SHA256SUMS).\n");
 fs::write(format!("{D}/README.md"),&report).unwrap();
 let pack=PathBuf::from(format!("{R}/publication-source"));fs::create_dir(&pack).unwrap();let mut files=Vec::new();
 for f in["design.md","next.md","initial_unit.rs","window-tests.rs","prepare.rs","repair-tests.rs","repair-tests-before-borrow.rs","review.rs","review-before-binary-source.rs","prepare-sdk.rs","review-links.rs","publish.rs","source-audit.json","pins.json","plan.json","repair-pins.json","repair-plan.json","sdk-build-plan.json","sdk-build-pins.json","test-repair.json","review-result.json","link-review.json"]{files.push(PathBuf::from(format!("{R}/{f}")));}
 for d in["runs","repaired-runs","sdk-build-runs","before-test-type-fix"]{walk(Path::new(&format!("{R}/{d}")),&mut files);}
 for rel in["crates/zopro-core/src/msm_affine.rs","crates/zopro-core/src/msm_affine/borrowed_pending.rs","crates/zopro-core/src/msm_affine/g2_borrowed.rs","crates/zopro-core/src/msm_affine/initial_unit.rs"]{files.push(PathBuf::from(format!("{R}/source/{rel}")));}
 files.sort();let mut members=Vec::new();for p in files{let rel=p.strip_prefix(R).unwrap();let data=fs::read(&p).unwrap();assert!(std::str::from_utf8(&data).is_ok());let dest=pack.join(rel);fs::create_dir_all(dest.parent().unwrap()).unwrap();fs::write(&dest,&data).unwrap();members.push(json!({"path":rel,"bytes":data.len(),"sha256":hash(dest)}));}
 let archive=format!("{D}/sources-receipts.tar.gz");assert!(Command::new("tar").args(["-czf",&archive,"-C",pack.to_str().unwrap(),"."]).status().unwrap().success());
 let round=PathBuf::from(format!("{R}/publication-roundtrip"));fs::create_dir(&round).unwrap();assert!(Command::new("tar").args(["-xzf",&archive,"-C",round.to_str().unwrap(),"."]).status().unwrap().success());for m in&members{assert_eq!(hash(round.join(m["path"].as_str().unwrap())),m["sha256"]);}
 let index=json!({"archive_sha256":hash(&archive),"members":members,"canonical_proofs":42438,"proof_ledger_sha256":hash(ledger),"excluded":["binaries","rlibs","key/image/witness/proof bytes","full unchanged source snapshot","full historical proof ledger"],"release_symbols_local_only":[{"path":format!("{R}/OFF.nm"),"sha256":hash(format!("{R}/OFF.nm"))},{"path":format!("{R}/ON.nm"),"sha256":hash(format!("{R}/ON.nm"))}]});fs::write(format!("{D}/artifacts/archive-index.json"),serde_json::to_vec_pretty(&index).unwrap()).unwrap();
 fs::write(format!("{D}/SHA256SUMS"),"").unwrap();let mut links=0;for s in report.split("](").skip(1){let p=s.split(')').next().unwrap();assert!(Path::new(D).join(p).exists(),"{p}");links+=1;}
 let publication=json!({"passed":true,"archive_members":members.len(),"archive_roundtrip":true,"local_links":links,"successful_workflow_commands":14,"retained_failed_test_compile":1,"native_generic_tests_passed":11,"Window_case_executions":345,"coherent_native_artifacts":8,"production_unchanged":true,"speed_measured":false,"SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":42438,"all8_CPU_Metal_rows":8,"goal_targets_met":0,"goal_complete":false,"goal_active":true});for p in[format!("{R}/publication.json"),format!("{D}/artifacts/publication.json")]{fs::write(p,serde_json::to_vec_pretty(&publication).unwrap()).unwrap();}
 let mut files=Vec::new();walk(Path::new(D),&mut files);files.sort();let mut sums=String::new();for p in files{if p.file_name().unwrap()=="SHA256SUMS"{continue}writeln!(sums,"{}  {}",hash(&p),p.strip_prefix(D).unwrap().display()).unwrap();}fs::write(format!("{D}/SHA256SUMS"),&sums).unwrap();for line in sums.lines(){let(h,p)=line.split_once("  ").unwrap();assert_eq!(hash(Path::new(D).join(p)),h);}
 println!("INITIAL_UNIT_PUBLICATION_PASS{}members/{}links;productionunchanged;speedunmeasured;canonical42438",members.len(),links);
}
