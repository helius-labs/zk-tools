use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/initial-unit176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert!(!Path::new(&format!("{R}/link-review.json")).exists());let q=read(format!("{R}/review-result.json"));assert_eq!(q["passed"],true);
 for(p,h)in read(format!("{R}/sdk-build-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
 let plan=read(format!("{R}/sdk-build-plan.json"));assert_eq!(plan["steps"].as_array().unwrap().len(),6);assert_eq!(read(format!("{R}/sdk-build-runs/result.json"))["status"],"complete");
 let mut identities=json!({});
 for arm in["OFF","ON"]{
  let field=q["identities"][arm]["field"].as_str().unwrap();let core=q["identities"][arm]["core"].as_str().unwrap();assert_eq!(hash(core),q["identities"][arm]["sha256"]);assert_eq!(hash(field),q["identities"][arm]["field_sha256"]);
  for stem in["zopro_prover","zopro_zolana","sdk"]{
   let name=format!("{stem}-{arm}");let s=plan["steps"].as_array().unwrap().iter().find(|s|s["name"]==name).unwrap();let a=s["argv"].as_array().unwrap();
   let dir=format!("{R}/sdk-build-runs/{name}");let e=read(format!("{dir}/exit.json"));assert_eq!(e["success"],true);assert_eq!(e["returncode"],0);
   let c=read(format!("{dir}/command.json"));let actual=c["argv"].as_array().unwrap();assert_eq!(&actual[..3],&[json!("timeout"),json!("-k"),json!("5s")]);assert_eq!(actual[3],format!("{}s",s["timeout_seconds"]));assert_eq!(&actual[4..],a);
   for(k,v)in s["environment"].as_object().unwrap(){if !k.starts_with("CARGO_"){assert_eq!(c["environment"][k],*v);}}
   for stream in["stdout","stderr"]{assert_eq!(hash(format!("{dir}/{stream}.log")),e[format!("{stream}_sha256")]);}
   assert!(a.iter().any(|v|v==&format!("zopro_bn254={field}")));
   if stem=="zopro_zolana"{assert!(a.iter().any(|v|v==&format!("zopro_prover={R}/libs/{arm}/libzopro_prover.rlib")));}
   else{assert!(a.iter().any(|v|v==&format!("zopro_core={core}")));}
   for f in["-O","target-cpu=native","codegen-units=1"]{assert!(a.iter().any(|v|v==f));}
   if stem=="sdk"{assert!(a.iter().any(|v|v=="lto=fat"));assert!(a.iter().any(|v|v=="/home/ubuntu/src/zopro-perf-work/worker-placement-control176/driver.rs"));}
   for bad in["zopro_unit_z_mixed","zopro_unit_z_census","zopro_initial_unit"]{assert!(!a.iter().any(|v|v==bad));}
  }
  let binary=format!("{R}/sdk-{arm}");let nm=format!("{R}/{arm}.nm");let output=Command::new("nm").args(["-S","-C",&binary]).output().unwrap();assert!(output.status.success());fs::write(&nm,&output.stdout).unwrap();let symbols=String::from_utf8(output.stdout).unwrap();
  for bad in["initial_unit_qualification","busy_reset_qualification","unit_z_census","both_curves_independent_initial_add_outputs","boundary_encoding_has_no_new_range_limit"]{assert!(!symbols.contains(bad));}
  let mut libs=json!({});for stem in["zopro_core","zopro_prover","zopro_zolana"]{let p=format!("{R}/libs/{arm}/lib{stem}.rlib");libs[stem]=json!({"path":p,"sha256":hash(&p)});}
  identities[arm]=json!({"binary":binary,"sha256":hash(&binary),"field":field,"field_sha256":hash(field),"libraries":libs,"release_nm_sha256":hash(nm)});
 }
 assert_eq!(identities["OFF"]["field_sha256"],identities["ON"]["field_sha256"]);
 let out=json!({"passed":true,"coherent_native_artifacts":8,"core_builds_reused":2,"new_downstream_builds":6,"exact_original_field_reused_both_arms":true,"qualified_initial_unit_core_only":true,"release_qualification_helpers_absent":true,"original_fixed_placement_driver":true,"native_O3_fatLTO_oneCGU":true,"production_unchanged":true,"speed_measured":false,"adopted":false,"SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":42438,"goal_active":true,"goal_complete":false,"identities":identities});fs::write(format!("{R}/link-review.json"),serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("INITIAL_UNIT_SDK_LINK_PASS8artifacts;6newbuilds;unchangedfield;releasehelpersabsent;noSDKcalls");
}
