#[cfg(test)]
mod initial_unit_qualification {
    use super::*;
    use ark_ec::{AffineRepr, CurveGroup, PrimeGroup};
    use ark_ff::Zero;
    use crate::msm_affine::initial_unit as meta;
    use meta::initial_unit_qualification::{weights, __CONVERT__ as convert};
    type Config = __CONFIG__;
    type Point = zopro_bn254::Affine<Config>;
    type Proj = zopro_bn254::Projective<Config>;
    type Ark = __ARK__;
    type State<'a> = __STATE__;
    fn state<'a>(half: usize, size: usize) -> State<'a> { __NEW__ }

    #[derive(Default, Debug)]
    struct Counts { cases: usize, transitions: usize, unit_updates: usize, general_updates: usize, finish_units: usize, queued: usize, phi: usize }
    impl Counts {
        fn sum(&mut self, c: Self) {
            self.cases += c.cases; self.transitions += c.transitions; self.unit_updates += c.unit_updates;
            self.general_updates += c.general_updates; self.finish_units += c.finish_units; self.queued += c.queued; self.phi += c.phi;
        }
    }
    fn inspect(s: &State<'_>, expected: &[Ark], c: &mut Counts) {
        assert_eq!(s.projective.len(), s.projective_buckets.len());
        for (idx, &b) in s.projective_buckets.iter().enumerate() {
            let encoded = s.projective_indices[b];
            let decoded = if cfg!(zopro_initial_unit) { meta::index(encoded, s.affine.len()) } else { encoded as usize };
            assert_eq!(decoded, idx);
            let p = &s.projective[idx];
            if cfg!(zopro_initial_unit) && meta::known_unit(encoded, s.affine.len()) {
                assert_eq!(p.z, <Config as zopro_bn254::CurveConfig>::Base::ONE);
            }
            assert_eq!(p.to_affine(), convert(expected[b].into_affine()));
        }
        c.transitions += 1;
    }
    fn record(s: &mut State<'_>, b: usize, p: Point, expected: &mut [Ark], oracle: __ARK_AFFINE__, c: &mut Counts) {
        let old = s.projective_indices[b];
        if old != u32::MAX {
            if cfg!(zopro_initial_unit) && meta::known_unit(old, s.affine.len()) { c.unit_updates += 1; }
            else { c.general_updates += 1; }
        }
        s.projective(b, p); expected[b] += oracle; inspect(s, expected, c);
        if old != u32::MAX && cfg!(zopro_initial_unit) {
            assert!(!meta::known_unit(s.projective_indices[b], s.affine.len()));
        }
    }
    fn case(half: usize, points: &[Point], oracle: &[__ARK_AFFINE__]) -> Counts {
        let mut c = Counts::default(); let mut s = state(half, 32);
        let mut expected = vec![Ark::zero(); half]; let n = half.min(33);
        let shape = (s.affine.len(), s.projective_indices.len(), s.busy.len(), s.batch.capacity(), s.queue.capacity());
        for b in 0..n { record(&mut s, b, points[(b + 1) % points.len()], &mut expected, oracle[(b + 1) % points.len()], &mut c); }
        // Some accumulators remain freshly initialized until finish. Others
        // consume the tag through identity, equal, opposite and ordinary adds.
        for j in 0..(2*n + 7) {
            let b = j % n;
            if b % 4 == 1 { continue; }
            let i = match j % 5 { 0 => 0, 1 => 1, 2 => 3, _ => (j*7 + 9) % points.len() };
            record(&mut s, b, points[i], &mut expected, oracle[i], &mut c);
        }
        __PHI__
        for j in 0..(n + 5) {
            let b = j % n;
            if b % 4 == 1 { continue; }
            let i = (j*11 + 5) % points.len();
            record(&mut s, b, -points[i], &mut expected, -oracle[i], &mut c);
        }
        // Exercise the actual deferred queue flush, then finish's separate
        // affine join, including equality/cancellation on fresh accumulators.
        for j in 0..n.min(7) {
            let b = (j*3) % n; let i = (j*5 + 4) % points.len();
            s.queue.push((b as u32 | if j%2==0 {1<<31} else {0}, &points[i]));
            expected[b] += if j%2==0 {-oracle[i]}else{oracle[i]}; c.queued += 1;
        }
        s.flush_queue(); inspect(&s, &expected, &mut c);
        for b in 0..n {
            let i = (b + 1) % points.len();
            let affine = if b%3==0 {-points[i]}else{points[i]};
            s.affine[b] = affine;
            expected[b] += if b%3==0 {-oracle[i]}else{oracle[i]};
            if cfg!(zopro_initial_unit) && meta::known_unit(s.projective_indices[b], half) { c.finish_units += 1; }
        }
        assert_eq!((s.affine.len(),s.projective_indices.len(),s.busy.len(),s.batch.capacity(),s.queue.capacity()),shape);
        assert!(s.batch.is_empty() && s.queue.is_empty());
        let actual = s.finish();
        for (i, (p, want)) in actual.iter().zip(expected).enumerate() { assert_eq!(*p, convert(want.into_affine()), "finish bucket {i}/{half}"); }
        c.cases = 1; c
    }
    #[test]
    fn state_complete_windows_and_workers() {
        let g = Ark::generator();
        let oracle: Vec<_> = weights().into_iter().map(|w| (g*w).into_affine()).collect();
        let points: Vec<_> = oracle.iter().copied().map(convert).collect(); let original = points.clone();
        let mut c = Counts::default();
        for half in [1,2,31,32,33,63,64,65,2048,4096,8192,16384] { c.sum(case(half,&points,&oracle)); }
        let mut workers = 0;
        for n in [1,4,16,32] {
            let pool = rayon::ThreadPoolBuilder::new().num_threads(n).stack_size(512*1024).build().unwrap();
            let seen = std::sync::Mutex::new(std::collections::BTreeSet::new());
            for out in pool.broadcast(|ctx| {seen.lock().unwrap().insert(ctx.index());case(33,&points,&oracle)}) { c.sum(out); }
            assert_eq!(seen.into_inner().unwrap().len(), n); workers += n;
        }
        let pool = rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();
        let results = std::thread::scope(|scope| {
            let mut jobs = Vec::new();
            for _ in 0..4 { let pool = &pool; let points = &points; let oracle = &oracle; jobs.push(scope.spawn(move || pool.install(|| case(33,points,oracle)))); }
            jobs.into_iter().map(|j| j.join().unwrap()).collect::<Vec<_>>()
        });
        for out in results { c.sum(out); }
        assert_eq!(workers,53); assert_eq!(c.cases,69); assert_eq!(points,original);
        assert!(c.general_updates>0 && c.queued>0);
        if cfg!(zopro_initial_unit) {assert!(c.unit_updates>0 && c.finish_units>0);}
        println!("INITIAL_UNIT __CURVE__ ON={} WORKERS={workers} CONCURRENT_CALLERS=4 COUNTS={c:?}",cfg!(zopro_initial_unit));
    }
}
