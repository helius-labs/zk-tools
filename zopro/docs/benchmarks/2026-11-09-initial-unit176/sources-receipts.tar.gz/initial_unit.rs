//! One-use state for an accumulator initialized from a nonidentity affine point.
//! No field-level Z test, new storage, or assumption about later additions.
use zopro_bn254::{Affine, CurveConfig, Field, Projective};

const UNIT: u32 = 1 << 31;

#[inline(always)]
pub(super) fn tagged_domain(buckets: usize) -> bool {
    // Reserve MAX for the original empty sentinel, including the flagged case.
    // Larger windows retain the original, full-width index representation.
    buckets < UNIT as usize
}

#[inline(always)]
pub(super) fn initial(index: usize, buckets: usize, nonidentity: bool) -> u32 {
    let plain = index as u32;
    if tagged_domain(buckets) && nonidentity { plain | UNIT } else { plain }
}

#[inline(always)]
pub(super) fn known_unit(encoded: u32, buckets: usize) -> bool {
    tagged_domain(buckets) && encoded & UNIT != 0
}

#[inline(always)]
pub(super) fn index(encoded: u32, buckets: usize) -> usize {
    if tagged_domain(buckets) { (encoded & !UNIT) as usize } else { encoded as usize }
}

pub(super) fn add<C: CurveConfig>(left: &Projective<C>, right: &Affine<C>) -> Projective<C> {
    if right.is_identity() { return *left; }
    if left.is_identity() { return right.to_projective(); }
    debug_assert_eq!(left.z, C::Base::ONE);
    if left.x == right.x {
        return if left.y == right.y { left.double() } else { Projective::IDENTITY };
    }
    let h = right.x - left.x;
    let hh = h.square();
    let i = hh.double().double();
    let j = h * i;
    let r = (right.y - left.y).double();
    let v = left.x * i;
    let x = r.square() - j - v.double();
    let y = r * (v - x) - (left.y * j).double();
    Projective::new(x, y, h.double())
}

#[cfg(test)]
pub(super) mod initial_unit_qualification {
    use super::*;
    use ark_ec::{AffineRepr, CurveGroup, PrimeGroup};
    use ark_ff::{BigInt, PrimeField, Zero};
    use zopro_bn254::{Fq, Fq2};

    fn fq(x: ark_bn254::Fq) -> Fq { Fq::from_canonical(x.into_bigint().0).unwrap() }
    pub(crate) fn g1(p: ark_bn254::G1Affine) -> zopro_bn254::G1Affine {
        if p.is_zero() { zopro_bn254::G1Affine::IDENTITY }
        else { zopro_bn254::G1Affine::new(fq(p.x), fq(p.y)) }
    }
    pub(crate) fn g2(p: ark_bn254::G2Affine) -> zopro_bn254::G2Affine {
        if p.is_zero() { zopro_bn254::G2Affine::IDENTITY }
        else { zopro_bn254::G2Affine::new(Fq2::new(fq(p.x.c0), fq(p.x.c1)), Fq2::new(fq(p.y.c0), fq(p.y.c1))) }
    }
    pub(crate) fn weights() -> Vec<ark_bn254::Fr> {
        let mut seed = 0xb742a0d561c938efu64;
        (0..32).map(|i| match i {
            0 => ark_bn254::Fr::from(0), 1 | 2 => ark_bn254::Fr::from(1),
            3 => -ark_bn254::Fr::from(1),
            _ => loop {
                let words = core::array::from_fn(|_| {
                    seed ^= seed << 13; seed ^= seed >> 7; seed ^= seed << 17; seed
                });
                if let Some(x) = ark_bn254::Fr::from_bigint(BigInt(words)) { break x; }
            }
        }).collect()
    }
    #[test]
    fn boundary_encoding_has_no_new_range_limit() {
        let tag = UNIT as usize;
        let mut checks = 0;
        for buckets in [0, 1, 2, 4096, 16384, tag - 1, tag, tag + 1, u32::MAX as usize] {
            for idx in [0, 1, 16383, tag - 2, tag - 1, tag, u32::MAX as usize - 1] {
                if idx >= buckets { continue; }
                for unit in [false, true] {
                    let e = initial(idx, buckets, unit);
                    assert_ne!(e, u32::MAX);
                    assert_eq!(index(e, buckets), idx);
                    assert_eq!(known_unit(e, buckets), unit && buckets < tag);
                    let cleared = index(e, buckets) as u32;
                    assert!(!known_unit(cleared, buckets));
                    assert_eq!(index(cleared, buckets), idx);
                    checks += 1;
                }
            }
        }
        assert!(checks > 50);
        assert_eq!((core::mem::size_of::<u32>(), core::mem::size_of::<zopro_bn254::G1Projective>(), core::mem::size_of::<zopro_bn254::G2Projective>()), (4, 96, 192));
        println!("INITIAL_UNIT_ENCODING checks={checks};synthetic32bitbounds=true;no_large_allocation=true");
    }
    #[test]
    fn both_curves_independent_initial_add_outputs() {
        let weights = weights(); let mut checks = 0;
        macro_rules! check {
            ($ark:ty, $convert:ident) => {{
                let generator = <$ark>::generator();
                let points: Vec<_> = weights.iter().map(|w| (generator * w).into_affine()).collect();
                for a in &points { for b in &points {
                    let left = $convert(*a).to_projective(); let right = $convert(*b);
                    let old = left.add_affine(&right); let new = add(&left, &right);
                    assert_eq!((new.x, new.y, new.z), (old.x, old.y, old.z));
                    assert_eq!(new.to_affine(), $convert((a.into_group() + b).into_affine()));
                    checks += 1;
                }}
            }};
        }
        check!(ark_bn254::G1Projective, g1); check!(ark_bn254::G2Projective, g2);
        assert_eq!(checks, 2048);
        println!("INITIAL_UNIT_INDEPENDENT checks={checks};both_curves=true;identity_equal_opposite=true");
    }
}
