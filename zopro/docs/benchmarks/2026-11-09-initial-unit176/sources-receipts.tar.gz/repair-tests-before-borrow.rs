use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/initial-unit176";
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn main(){
 let old="for p in &mut expected {p.x *= beta;}";let new="for p in &mut expected {p.x.c0 *= beta; p.x.c1 *= beta;}";
 let originals=["prepare.rs","source/crates/zopro-core/src/msm_affine/g2_borrowed.rs","source-audit.json","pins.json"];
 for f in originals{let to=format!("{R}/before-test-type-fix/{f}");fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(format!("{R}/{f}"),to).unwrap();}
 for f in["prepare.rs","source/crates/zopro-core/src/msm_affine/g2_borrowed.rs"]{let p=format!("{R}/{f}");let t=fs::read_to_string(&p).unwrap();assert_eq!(t.matches(old).count(),1);fs::write(p,t.replace(old,new)).unwrap();}
 let mut audit=read(&format!("{R}/source-audit.json"));for e in audit["edits"].as_array_mut().unwrap(){if e["path"]=="crates/zopro-core/src/msm_affine/g2_borrowed.rs"{e["suffix"]=json!(e["suffix"].as_str().unwrap().replace(old,new));}}
 fs::write(format!("{R}/source-audit.json"),serde_json::to_vec_pretty(&audit).unwrap()).unwrap();
 let mut plan=read(&format!("{R}/plan.json"));let steps=plan["steps"].as_array_mut().unwrap();assert_eq!(steps.len(),8);steps.drain(0..2);plan["source_pins"]=json!(format!("{R}/repair-pins.json"));
 let mut pins=read(&format!("{R}/pins.json"));for p in pins.as_object().unwrap().keys().cloned().collect::<Vec<_>>(){pins[&p]=json!(hash(p));}
 // The old prepare binary is retained, not recompiled or executed after repair.
 for f in["repair-tests.rs"]{let p=format!("{R}/{f}");pins[&p]=json!(hash(&p));}
 fs::write(format!("{R}/repair-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();pins[format!("{R}/repair-plan.json")]=json!(hash(format!("{R}/repair-plan.json")));
 fs::write(format!("{R}/repair-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
 let r=json!({"test_only":true,"runtime_change":false,"before":old,"after":new,"retained_initial_failure":"runs/build-core-OFF-test/exit.json","reused_native_libraries":["libs/OFF/libzopro_core.rlib","libs/ON/libzopro_core.rlib"],"remaining_commands":6});fs::write(format!("{R}/test-repair.json"),serde_json::to_vec_pretty(&r).unwrap()).unwrap();println!("Test oracle expression repaired;2 native libraries reused;6remaining commands");
}
