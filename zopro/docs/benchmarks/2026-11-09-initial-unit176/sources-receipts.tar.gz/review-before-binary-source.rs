use serde_json::{json, Value}; use sha2::{Digest, Sha256}; use std::{fs, path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/initial-unit176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn receipt(root:&str,s:&Value,ok:bool){
 let d=format!("{R}/{root}/{}",s["name"].as_str().unwrap());let e=read(format!("{d}/exit.json"));assert_eq!(e["success"],ok);assert_eq!(e["returncode"],if ok{0}else{1});
 let cmd=read(format!("{d}/command.json"));let argv=cmd["argv"].as_array().unwrap();assert_eq!(&argv[..3],&[json!("timeout"),json!("-k"),json!("5s")]);assert_eq!(argv[3],format!("{}s",s["timeout_seconds"]));assert_eq!(&argv[4..],s["argv"].as_array().unwrap());
 for stream in["stdout","stderr"]{assert_eq!(hash(format!("{d}/{stream}.log")),e[format!("{stream}_sha256")]);}
}
fn main(){
 let old_pins=read(format!("{R}/pins.json"));let changed=["prepare.rs","source/crates/zopro-core/src/msm_affine/g2_borrowed.rs","source-audit.json"];
 for(p,h)in old_pins.as_object().unwrap(){let prefix=format!("{R}/");let rel=p.strip_prefix(&prefix).unwrap_or("");let current=if changed.contains(&rel){format!("{R}/before-test-type-fix/{rel}")}else{p.clone()};assert_eq!(hash(current),h.as_str().unwrap());}
 let pins=read(format!("{R}/repair-pins.json"));for(p,h)in pins.as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
 let audit=read(format!("{R}/source-audit.json"));let originals=audit["originals"].as_object().unwrap();assert_eq!(originals.len(),176);
 let mut exact=0;for(rel,h)in originals{
  assert_eq!(hash(format!("{Z}/{rel}")),h.as_str().unwrap());let path=format!("{R}/source/{rel}");let mut text=fs::read_to_string(&path).unwrap();
  if let Some(e)=audit["edits"].as_array().unwrap().iter().find(|e|e["path"]==rel.as_str()){
   let suffix=e["suffix"].as_str().unwrap();if !suffix.is_empty(){assert!(text.ends_with(suffix));text.truncate(text.len()-suffix.len());}
   for r in e["replacements"].as_array().unwrap().iter().rev(){let after=r["after"].as_str().unwrap();assert_eq!(text.matches(after).count(),1);text=text.replace(after,r["before"].as_str().unwrap());}
   assert_eq!(format!("{:x}",Sha256::digest(text.as_bytes())),h.as_str().unwrap());
  }else{assert_eq!(hash(path),h.as_str().unwrap());exact+=1;}
 }assert_eq!(exact,173);
 let old="for p in &mut expected {p.x *= beta;}";let new="for p in &mut expected {p.x.c0 *= beta; p.x.c1 *= beta;}";
 let rel="source/crates/zopro-core/src/msm_affine/g2_borrowed.rs";
 assert_eq!(fs::read_to_string(format!("{R}/before-test-type-fix/{rel}")).unwrap().replace(old,new),fs::read_to_string(format!("{R}/{rel}")).unwrap());
 // The only post-library source change is inside the appended #[cfg(test)] module.
 let g2=fs::read_to_string(format!("{R}/{rel}")).unwrap();let start=g2.find("#[cfg(test)]\nmod initial_unit_qualification").unwrap();assert!(g2[start..].contains(new));assert!(!g2[..start].contains(new));
 let initial=read(format!("{R}/plan.json"));let repaired=read(format!("{R}/repair-plan.json"));assert_eq!(initial["steps"].as_array().unwrap().len(),8);assert_eq!(repaired["steps"].as_array().unwrap().len(),6);
 for s in &initial["steps"].as_array().unwrap()[..2]{receipt("runs",s,true);}
 receipt("runs",&initial["steps"][2],false);
 assert!(fs::read_to_string(format!("{R}/runs/build-core-OFF-test/stderr.log")).unwrap().contains("error[E0277]"));
 assert_eq!(read(format!("{R}/repaired-runs/result.json"))["status"],"complete");
 for s in repaired["steps"].as_array().unwrap(){receipt("repaired-runs",s,true);}
 let native_field="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/frozen/candidate/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib";
 let generic_field="/home/ubuntu/src/zopro-perf-work/tree-policy-owner176/libzopro_bn254-generic.rlib";
 for s in initial["steps"].as_array().unwrap().iter().take(2).chain(repaired["steps"].as_array().unwrap().iter().filter(|s|s["name"].as_str().unwrap().starts_with("build-"))){
  let argv=s["argv"].as_array().unwrap();let name=s["name"].as_str().unwrap();let generic=name.contains("generic");assert!(argv.iter().any(|v|v==&format!("zopro_bn254={}",if generic{generic_field}else{native_field})));
  assert!(argv.iter().any(|v|v=="zopro_dense_busy_reset"));assert_eq!(argv.iter().any(|v|v=="zopro_initial_unit"),!name.contains("OFF"));
  if generic{for f in["target-cpu=x86-64","no_asm","no_ifma"]{assert!(argv.iter().any(|v|v==f));}}
 }
 let mut logs=json!({});for arm in["OFF-test","ON-test","generic-ON-test"]{
  let log=fs::read_to_string(format!("{R}/repaired-runs/qualify-{arm}/stdout.log")).unwrap();let tests=if arm.starts_with("generic"){3}else{4};
  assert!(log.contains(&format!("test result: ok. {tests} passed; 0 failed")));
  assert!(log.contains("INITIAL_UNIT_ENCODING checks="));assert!(log.contains("INITIAL_UNIT_INDEPENDENT checks=2048"));assert!(log.contains("INITIAL_UNIT G1"));
  assert!(log.contains("WORKERS=53 CONCURRENT_CALLERS=4"));assert!(log.contains("cases: 69"));
  if !arm.starts_with("generic"){assert!(log.contains("INITIAL_UNIT G2"));}
  logs[arm]=json!({"tests_passed":tests,"sha256":hash(format!("{R}/repaired-runs/qualify-{arm}/stdout.log")),"lines":log.lines().filter(|l|l.contains("INITIAL_UNIT")).collect::<Vec<_>>()});
 }
 let mut ids=json!({});for arm in["OFF","ON"]{let p=format!("{R}/libs/{arm}/libzopro_core.rlib");ids[arm]=json!({"core":p,"sha256":hash(&p),"field":native_field,"field_sha256":hash(native_field)});}
 let out=json!({"passed":true,"production_unchanged":true,"adopted":false,"speed_measured":false,"complete_SDK_not_yet_built":true,"exact_originals":173,"recovered_originals":176,"extra_private_module":1,"field_unchanged":true,"runtime_libraries_reused_after_test_only_fix":true,"successful_workflow_commands":8,"retained_failed_test_compile":1,"manual_helper_compile_failures":1,"manual_helper_compile_receipts_complete":false,"native_OFF_tests_passed":4,"native_ON_tests_passed":4,"generic_ON_tests_passed":3,"new_Window_cases_native_OFF":138,"new_Window_cases_native_ON":138,"new_Window_cases_generic_ON":69,"argument_population_reused_across_arms":true,"helper_Arkworks_output_executions_per_arm":2048,"broadcast_workers_per_window_test":53,"OS_callers_per_window_test":4,"requested_worker_stack_bytes":524288,"logical_Window_storage_unchanged":true,"no_physical_ARM_memory_pressure_minimumRAM_or_speed_result":true,"SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":42438,"goal_complete":false,"goal_active":true,"targets_met":0,"identities":ids,"generic_field":generic_field,"generic_field_sha256":hash(generic_field),"qualification":logs,"same_agent_not_external_audit":true});
 fs::write(format!("{R}/review-result.json"),serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("INITIAL_UNIT_QUALIFIED:8successfulcommands+1retainedfailure;11tests;345Windowcases;fieldunchanged;speedunmeasured");
}
