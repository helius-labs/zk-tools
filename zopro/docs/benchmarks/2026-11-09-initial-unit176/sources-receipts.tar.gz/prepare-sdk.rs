use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/initial-unit176";
const B:&str="/home/ubuntu/src/zopro-perf-work/busy-reset-sdk176";
const C:&str="/home/ubuntu/src/zopro-perf-work/busy-reset176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert!(!Path::new(&format!("{R}/sdk-build-plan.json")).exists());let review=read(format!("{R}/review-result.json"));assert_eq!(review["passed"],true);
 let template=read(format!("{B}/build-plan.json"));let mut steps=template["steps"].as_array().unwrap().clone();assert_eq!(steps.len(),6);
 for s in &mut steps{
  for v in s["argv"].as_array_mut().unwrap(){*v=json!(v.as_str().unwrap().replace(B,R).replace(C,R).replace("busy_reset_sdk176","initial_unit_sdk176"));}
  for v in s["environment"].as_object_mut().unwrap().values_mut(){if let Some(t)=v.as_str(){*v=json!(t.replace(B,R).replace(C,R));}}
 }
 let mut pins=BTreeMap::new();for(p,h)in read(format!("{R}/repair-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pins.insert(p.clone(),h.clone());}
 for arm in["OFF","ON"]{let p=format!("{R}/libs/{arm}/libzopro_core.rlib");assert_eq!(hash(&p),review["identities"][arm]["sha256"]);pins.insert(p.clone(),json!(hash(p)));}
 for s in &steps{for v in s["argv"].as_array().unwrap(){let t=v.as_str().unwrap();let p=t.split_once('=').map_or(t,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.to_string(),json!(hash(p)));}}}
 for f in["review-result.json","prepare-sdk.rs","prepare-sdk"]{let p=format!("{R}/{f}");pins.insert(p.clone(),json!(hash(p)));}
 let plan=json!({"version":1,"source_pins":format!("{R}/sdk-build-pins.json"),"steps":steps});fs::write(format!("{R}/sdk-build-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();pins.insert(format!("{R}/sdk-build-plan.json"),json!(hash(format!("{R}/sdk-build-plan.json"))));fs::write(format!("{R}/sdk-build-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();println!("Prepared6downstreambuilds;qualifiedOFFONcoresreused;originalfield1200;noSDKcalls");
}
