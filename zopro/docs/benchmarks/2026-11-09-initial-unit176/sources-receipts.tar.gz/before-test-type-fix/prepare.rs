use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/initial-unit176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
const B: &str = "/home/ubuntu/src/zopro-perf-work/busy-reset176";
const A: &str = "/home/ubuntu/src/zopro-perf-work/word-export176/target-candidate/release/deps";
fn read(p: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(p).unwrap()).unwrap() }
fn hash(p: impl AsRef<Path>) -> String { format!("{:x}", Sha256::digest(fs::read(p).unwrap())) }
fn save(p: &str, v: Value) { fs::write(format!("{R}/{p}"), serde_json::to_vec_pretty(&v).unwrap()).unwrap(); }
fn replace(text: &mut String, old: &str, new: &str) { assert_eq!(text.matches(old).count(), 1); *text = text.replace(old, new); }
fn main() {
    assert!(!Path::new(R).join("source").exists());
    let manifest_path = format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json");
    let manifest = read(&manifest_path); let originals = manifest["source_files_sha256"].as_object().unwrap(); assert_eq!(originals.len(), 176);
    let mut pins = BTreeMap::new();
    for (rel, h) in originals {
        let from = format!("{Z}/{rel}"); assert_eq!(hash(&from), h.as_str().unwrap());
        let to = format!("{R}/source/{rel}"); fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap(); fs::copy(&from, &to).unwrap(); pins.insert(from, h.clone());
    }
    let mut edits = Vec::new();
    let template = fs::read_to_string(format!("{R}/window-tests.rs")).unwrap();
    for (rel, old, new, config, ark, ark_affine, convert, state, ctor, curve, phi) in [
        ("crates/zopro-core/src/msm_affine/borrowed_pending.rs",
"    fn projective(&mut self, bucket: usize, point: Affine<C>) {\n        let index = self.projective_indices[bucket];\n        if index == u32::MAX {\n            self.projective_indices[bucket] = self.projective.len() as u32;\n            self.projective_buckets.push(bucket);\n            self.projective.push(point.to_projective());\n        } else {\n            self.projective[index as usize] += point;\n        }\n    }",
"    #[cfg(zopro_initial_unit)]\n    fn projective(&mut self, bucket: usize, point: Affine<C>) {\n        use super::initial_unit as state;\n        let encoded = self.projective_indices[bucket];\n        let half = self.affine.len();\n        if encoded == u32::MAX {\n            self.projective_indices[bucket] = state::initial(self.projective.len(), half, !point.is_identity());\n            self.projective_buckets.push(bucket);\n            self.projective.push(point.to_projective());\n        } else {\n            let index = state::index(encoded, half);\n            if state::known_unit(encoded, half) {\n                self.projective[index] = state::add(&self.projective[index], &point);\n                self.projective_indices[bucket] = index as u32;\n            } else {\n                self.projective[index] += point;\n            }\n        }\n    }",
"zopro_bn254::G1Config", "ark_bn254::G1Projective", "ark_bn254::G1Affine", "g1", "Window<'a, Config>", "Window::new(half,size)", "G1", ""),
        ("crates/zopro-core/src/msm_affine/g2_borrowed.rs",
"    fn projective(&mut self, b: usize, p: G2Affine) {\n        let i = self.projective_indices[b];\n        if i == u32::MAX {\n            self.projective_indices[b] = self.projective.len() as u32;\n            self.projective_buckets.push(b);\n            self.projective.push(p.to_projective());\n        } else {\n            self.projective[i as usize] += p;\n        }\n    }",
"    #[cfg(zopro_initial_unit)]\n    fn projective(&mut self, b: usize, p: G2Affine) {\n        use super::initial_unit as state;\n        let encoded = self.projective_indices[b];\n        let half = self.affine.len();\n        if encoded == u32::MAX {\n            self.projective_indices[b] = state::initial(self.projective.len(), half, !p.is_identity());\n            self.projective_buckets.push(b);\n            self.projective.push(p.to_projective());\n        } else {\n            let index = state::index(encoded, half);\n            if state::known_unit(encoded, half) {\n                self.projective[index] = state::add(&self.projective[index], &p);\n                self.projective_indices[b] = index as u32;\n            } else {\n                self.projective[index] += p;\n            }\n        }\n    }",
"zopro_bn254::G2Config", "ark_bn254::G2Projective", "ark_bn254::G2Affine", "g2", "Window<'a>", "Window::new(half,size,BatchAdd::default())", "G2",
"        for p in &mut s.projective {p.x = p.x.mul_by_fp(&BETA);}\n        for p in &mut s.affine {if !p.is_identity() {p.x = p.x.mul_by_fp(&BETA);}}\n        let beta = <ark_bn254::Fq as ark_ff::PrimeField>::from_bigint(ark_ff::BigInt(BETA.to_canonical())).unwrap();\n        for p in &mut expected {p.x *= beta;}\n        c.phi += 1; inspect(&s, &expected, &mut c);")
    ] {
        let path = format!("{R}/source/{rel}"); let mut text = fs::read_to_string(&path).unwrap();
        let replacement = format!("    #[cfg(not(zopro_initial_unit))]\n{old}\n{new}"); replace(&mut text, old, &replacement);
        let before = "            .map(|(p, &i)| *p + self.affine[i])";
        let after = "            .map(|(p, &i)| {\n                #[cfg(zopro_initial_unit)]\n                if super::initial_unit::known_unit(self.projective_indices[i], self.affine.len()) {\n                    return super::initial_unit::add(p, &self.affine[i]);\n                }\n                *p + self.affine[i]\n            })";
        replace(&mut text, before, after);
        let suffix = format!("\n{}", template.replace("__CONFIG__", config).replace("__ARK__", ark).replace("__ARK_AFFINE__", ark_affine).replace("__CONVERT__", convert).replace("__STATE__", state).replace("__NEW__", ctor).replace("__CURVE__", curve).replace("__PHI__", phi));
        text.push_str(&suffix); fs::write(&path, text).unwrap();
        edits.push(json!({"path":rel,"replacements":[{"before":old,"after":replacement},{"before":before,"after":after}],"suffix":suffix}));
    }
    let rel = "crates/zopro-core/src/msm_affine.rs"; let path = format!("{R}/source/{rel}");
    let mut text = fs::read_to_string(&path).unwrap(); let old = "mod grouping_cost;";
    let new = "mod grouping_cost;\n#[cfg(any(test, zopro_initial_unit))]\nmod initial_unit;"; replace(&mut text, old, new); fs::write(path, text).unwrap();
    edits.push(json!({"path":rel,"replacements":[{"before":old,"after":new}],"suffix":""}));
    let extra = "crates/zopro-core/src/msm_affine/initial_unit.rs";
    fs::copy(format!("{R}/initial_unit.rs"), format!("{R}/source/{extra}")).unwrap();
    save("source-audit.json", json!({"manifest":manifest_path,"manifest_sha256":hash(&manifest_path),"originals":originals,"edits":edits,"extra":extra,"exact_originals":173,"recoverable_originals":3,"total_originals":176,"field_unchanged":true,"production_changed":false,"no_new_Window_fields":true}));
    // Verify recovery immediately, before building anything.
    for (rel, expected) in originals {
        let mut bytes = fs::read(format!("{R}/source/{rel}")).unwrap();
        if let Some(edit) = edits.iter().find(|e| e["path"] == rel.as_str()) {
            let mut text = String::from_utf8(bytes).unwrap(); let suffix = edit["suffix"].as_str().unwrap();
            if !suffix.is_empty() {assert!(text.ends_with(suffix));text.truncate(text.len()-suffix.len());}
            for change in edit["replacements"].as_array().unwrap().iter().rev() {replace(&mut text, change["after"].as_str().unwrap(), change["before"].as_str().unwrap());}
            bytes = text.into_bytes();
        }
        assert_eq!(format!("{:x}",Sha256::digest(bytes)), expected.as_str().unwrap());
    }
    let parent = read(format!("{B}/plan.json")); let repair = read(format!("{B}/repair-plan.json")); let mut steps = Vec::new();
    for (arm, test, generic) in [("OFF",false,false),("ON",false,false),("OFF-test",true,false),("ON-test",true,false),("generic-ON-test",true,true)] {
        fs::create_dir_all(format!("{R}/libs/{arm}")).unwrap();
        let mut s = if generic {repair["steps"].as_array().unwrap().last().unwrap().clone()} else {parent["steps"][0].clone()};
        s["name"] = json!(format!("build-core-{arm}")); let argv = s["argv"].as_array_mut().unwrap();
        for v in argv.iter_mut() {let old = v.as_str().unwrap();*v = json!(old.replace(B,R).replace("busy_reset176_OFF",&format!("initial_unit176_{arm}")).replace("busy_reset176_generic",&format!("initial_unit176_{arm}")));}
        let out = argv.iter().position(|v| v == "-o").unwrap(); argv[out+1] = json!(if test {format!("{R}/core-tests-{arm}")}else{format!("{R}/libs/{arm}/libzopro_core.rlib")});
        if !generic {argv.extend([json!("--cfg"),json!("zopro_dense_busy_reset")]);}
        if arm.starts_with("ON") || generic {argv.extend([json!("--cfg"),json!("zopro_initial_unit")]);}
        if test {
            let pos = argv.iter().position(|v|v=="--crate-type").unwrap();argv.drain(pos..pos+2);argv.push(json!("--test"));
            argv.extend([json!("-L"),json!(format!("dependency={A}")),json!("--extern"),json!(format!("ark_bn254={A}/libark_bn254-d28868a71f06f5b5.rlib")),json!("--extern"),json!(format!("ark_ec={A}/libark_ec-59ebd5b49f9b3011.rlib")),json!("--extern"),json!(format!("ark_ff={A}/libark_ff-3a8e68dc8045d2bd.rlib"))]);
        }
        s["environment"]["CARGO_MANIFEST_DIR"] = json!(format!("{R}/source/crates/zopro-core"));
        let env=s["environment"].clone();steps.push(s);
        if test {steps.push(json!({"kind":"command","name":format!("qualify-{arm}"),"argv":[format!("{R}/core-tests-{arm}"),"initial_unit_qualification::","--nocapture","--test-threads=1"],"environment":env,"timeout_seconds":900}));}
    }
    for (rel, _) in originals {let p = format!("{R}/source/{rel}");pins.insert(p.clone(),json!(hash(p)));}
    pins.insert(format!("{R}/source/{extra}"),json!(hash(format!("{R}/source/{extra}"))));
    for f in ["design.md","initial_unit.rs","window-tests.rs","prepare.rs","prepare","source-audit.json"] {let p=format!("{R}/{f}");pins.insert(p.clone(),json!(hash(p)));}
    for s in &steps {for v in s["argv"].as_array().unwrap(){let t=v.as_str().unwrap();let p=t.split_once('=').map_or(t,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.to_owned(),json!(hash(p)));}}}
    save("plan.json",json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps}));pins.insert(format!("{R}/plan.json"),json!(hash(format!("{R}/plan.json"))));save("pins.json",json!(pins));
    println!("Prepared initial-unit state:176 originals recovered;unchanged field;5builds+3targeted test commands;no clocks/proofs");
}
