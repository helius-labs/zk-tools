use super::*;
use zopro_bn254::{G2Affine,G2Config,ifma8::LazyFq};
#[repr(C)]
#[derive(Clone,Copy)]
pub(crate) struct LazyYBucket {pub(crate) x:Fq2,pub(crate) y:[LazyFq;2]}
impl LazyYBucket {
 #[inline(always)]pub(crate)fn identity()->Self{Self::from_affine(G2Affine::IDENTITY)}
 #[inline(always)]pub(crate)fn from_affine(p:G2Affine)->Self{Self{x:p.x,y:[LazyFq::from_canonical(p.y.c0),LazyFq::from_canonical(p.y.c1)]}}
 #[inline(always)]pub(crate)fn canonical_y(self)->Fq2{Fq2::new(self.y[0].canonical(),self.y[1].canonical())}
 #[inline(always)]pub(crate)fn canonical(self)->G2Affine{G2Affine::new(self.x,self.canonical_y())}
 #[inline(always)]pub(crate)fn is_identity(self)->bool{self.x==Fq2::ZERO&&self.y[0].is_zero()&&self.y[1].is_zero()}
}

// KERNEL
