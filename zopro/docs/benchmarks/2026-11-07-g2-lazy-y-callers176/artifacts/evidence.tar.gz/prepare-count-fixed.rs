use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-lazy-y-callers176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn read(p:&str)->String{fs::read_to_string(p).unwrap()}
fn change(s:&mut String,a:&str,b:&str,count:usize,edits:&mut Vec<Value>){assert_eq!(s.matches(a).count(),count,"{a}");*s=s.replace(a,b);edits.push(json!({"old":a,"new":b,"count":count}));}
fn main(){
 assert!(!Path::new(&format!("{R}/source-audit.json")).exists());let manifest=format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");let m:Value=serde_json::from_slice(&fs::read(&manifest).unwrap()).unwrap();let sources=m["source_files_sha256"].as_object().unwrap();assert_eq!(sources.len(),176);
 // First preparation failed before any source edit: its in-memory count
 // omitted the canonical_sub in the fallback branch later removed below.
 for tree in["source","control-source"]{if Path::new(&format!("{R}/{tree}")).exists(){for(n,h)in sources{assert_eq!(hash(format!("{R}/{tree}/{n}")),h.as_str().unwrap());}}}
 let mut pins=BTreeMap::new();pins.insert(manifest.clone(),hash(&manifest));
 for(n,h)in sources{let from=format!("{Z}/{n}");assert_eq!(hash(&from),h.as_str().unwrap());pins.insert(from.clone(),hash(&from));for tree in["source","control-source"]{let to=format!("{R}/{tree}/{n}");fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(&from,to).unwrap();}}
 let original=read(&format!("{Z}/crates/zopro-core/src/msm/g2_borrowed.rs"));let start=original.find("pub(super) fn apply<").unwrap();let end=original.find("\nimpl<C: CurveConfig<Base = Fq2>> BatchAdd<C>").unwrap();let kernel_original=&original[start..end];let mut kernel=kernel_original.to_owned();let mut ke=Vec::new();
 change(&mut kernel,"pub(super) fn apply<C: CurveConfig<Base = Fq2>, const FAST: bool>(\n    buckets: &mut [Affine<C>],\n    batch: &[(u32, &Affine<C>)],","fn apply(\n    buckets: &mut [LazyYBucket],\n    batch: &[(u32, &G2Affine)],",1,&mut ke);
 change(&mut kernel,"canonical_sub::<FAST>","canonical_sub::<true>",3,&mut ke);
 change(&mut kernel,"let a = buckets[index as usize];","let a = buckets[index as usize].canonical();",1,&mut ke);
 change(&mut kernel,"buckets[(batch[k].0 & 0x7fffffff) as usize] = Affine::new(x, y);","buckets[(batch[k].0 & 0x7fffffff) as usize] = LazyYBucket::from_affine(G2Affine::new(x, y));",1,&mut ke);
 change(&mut kernel,"let a: [Affine<C>; LANES]","let a: [LazyYBucket; LANES]",1,&mut ke);
 change(&mut kernel,"let b: [&Affine<C>; LANES]","let b: [&G2Affine; LANES]",1,&mut ke);
 change(&mut kernel,"let ay = fq2_pack(a.map(|p| p.y));","let ay = core::array::from_fn(|j| FqBatch::from_lazy_y(&a.map(|p|p.y[j])));",1,&mut ke);
 let a=kernel.find("        let dy=if FAST{").unwrap();let b=a+kernel[a..].find("        let denominator=").unwrap();let old=kernel[a..b].to_owned();let new="        let by=core::array::from_fn(|j|b.map(|p|if j==0{p.y.c0}else{p.y.c1}));\n        let negative=signs::<true,G2Config>(&batch[k..k+LANES]);\n";change(&mut kernel,&old,new,1,&mut ke);
 change(&mut kernel,"let slope = Fq2::lanes_scaled_numerator(&dy, &denominator, &factor);","let slope = Fq2::lanes_scale(&FqBatch::lazy_y_numerator(&by,&ay,&denominator,negative), &factor);",1,&mut ke);
 change(&mut kernel,"let (x, y) = (fq2_unpack(x), fq2_unpack(y));","let x = fq2_unpack(x);\n        let y = y.map(FqBatch::to_lazy_y);",1,&mut ke);
 change(&mut kernel,"buckets[(batch[k + i].0 & 0x7fffffff) as usize] = Affine::new(x[i], y[i]);","buckets[(batch[k + i].0 & 0x7fffffff) as usize] = LazyYBucket{x:x[i],y:[y[0][i],y[1][i]]};",1,&mut ke);
 let mut recovered=kernel.clone();for e in ke.iter().rev(){assert_eq!(recovered.matches(e["new"].as_str().unwrap()).count(),e["count"].as_u64().unwrap()as usize);recovered=recovered.replace(e["new"].as_str().unwrap(),e["old"].as_str().unwrap());}assert_eq!(recovered,kernel_original);
 let bucket=read(&format!("{R}/bucket.rs"));let child=format!("{bucket}\n{kernel}\nimpl BatchAdd<G2Config>{{pub(crate)fn apply_lazy_y_g2(&mut self,buckets:&mut[LazyYBucket],batch:&[(u32,&G2Affine)]){{debug_assert!(self.borrowed_g2_enabled());apply(buckets,batch,&mut self.fq2);}}}}\n");fs::write(format!("{R}/source/crates/zopro-core/src/msm/lazy_y.rs"),child).unwrap();
 let original=read(&format!("{Z}/crates/zopro-core/src/msm_affine/g2_borrowed.rs"));let prefix=original.split("#[cfg(test)]").next().unwrap();let mut window=prefix.to_owned();let mut we=Vec::new();
 change(&mut window,"use crate::msm::BatchAdd;","use crate::msm::{BatchAdd,lazy_y::LazyYBucket};",1,&mut we);
 change(&mut window,"affine: Vec<G2Affine>","affine: Vec<LazyYBucket>",1,&mut we);
 change(&mut window,"affine: vec![G2Affine::IDENTITY; half]","affine: vec![LazyYBucket::identity(); half]",1,&mut we);
 change(&mut window,"*a = if neg { -*p } else { *p };","*a = LazyYBucket::from_affine(if neg { -*p } else { *p });",1,&mut we);
 change(&mut window,"if a.y == signed.y","if a.canonical_y() == signed.y",1,&mut we);
 change(&mut window,"*a = G2Affine::IDENTITY","*a = LazyYBucket::identity()",1,&mut we);
 change(&mut window,".apply_signed_borrowed_g2(",".apply_lazy_y_g2(",1,&mut we);
 change(&mut window,".map(|(p, &i)| *p + self.affine[i])",".map(|(p, &i)| *p + self.affine[i].canonical())",1,&mut we);
 change(&mut window,"self.affine[i] = p;","self.affine[i] = LazyYBucket::from_affine(p);",1,&mut we);
 change(&mut window,"        self.affine\n    }","        self.affine.into_iter().map(LazyYBucket::canonical).collect()\n    }",1,&mut we);
 let mut recovered=window.clone();for e in we.iter().rev(){assert_eq!(recovered.matches(e["new"].as_str().unwrap()).count(),e["count"].as_u64().unwrap()as usize);recovered=recovered.replace(e["new"].as_str().unwrap(),e["old"].as_str().unwrap());}assert_eq!(recovered,prefix);
 let custom=read(&format!("{R}/custom.rs"));window.push_str(&custom);fs::write(format!("{R}/source/crates/zopro-core/src/msm_affine/g2_lazy_y_window.rs"),window).unwrap();
 let field="/home/ubuntu/src/zopro-perf-work/g2-lazy-y176/lazy_y.rs";fs::copy(field,format!("{R}/source/crates/zopro-bn254/src/lazy_y.rs")).unwrap();pins.insert(field.to_owned(),hash(field));
 let exports=read(&format!("{R}/exports.rs"));let bridge=read(&format!("{R}/bridge.rs"));
 let mut suffixes=BTreeMap::new();suffixes.insert("crates/zopro-core/src/lib.rs","\n#[cfg(all(zopro_window_trial,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma)))]\npub use msm_affine::lazy_y_window_trial;\n".to_owned());suffixes.insert("crates/zopro-core/src/msm_affine.rs",format!("\n{exports}"));suffixes.insert("crates/zopro-core/src/msm_affine/g2_borrowed.rs",format!("\n{custom}"));
 for tree in["source","control-source"]{for(p,suffix)in &suffixes{let path=format!("{R}/{tree}/{p}");let original=read(&path);fs::write(path,format!("{original}{suffix}")).unwrap();}}
 let mut extra=BTreeMap::new();extra.insert("crates/zopro-bn254/src/ifma8.rs","\n#[cfg(zopro_lazy_y)]\ninclude!(\"lazy_y.rs\");\n".to_owned());extra.insert("crates/zopro-core/src/simd.rs",format!("\n{bridge}"));extra.insert("crates/zopro-core/src/msm.rs","\n#[cfg(all(zopro_lazy_y,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma)))]\npub(crate) mod lazy_y;\n".to_owned());
 for(p,suffix)in &extra{let path=format!("{R}/source/{p}");let original=read(&path);fs::write(path,format!("{original}{suffix}")).unwrap();}
 fs::copy(format!("{R}/tests.rs"),format!("{R}/source/crates/zopro-core/src/msm_affine/lazy_y_window_tests.rs")).unwrap();
 for tree in["source","control-source"]{for(n,h)in sources{let path=format!("{R}/{tree}/{n}");let mut text=read(&path);if tree=="source"{if let Some(s)=extra.get(n.as_str()){text=text.strip_suffix(s).unwrap().to_owned();}}if let Some(s)=suffixes.get(n.as_str()){text=text.strip_suffix(s).unwrap().to_owned();}assert_eq!(format!("{:x}",Sha256::digest(text.as_bytes())),h.as_str().unwrap());pins.insert(path.clone(),hash(path));}}
 let audit=json!({"accepted_sources":176,"original_recovery_both_snapshots":true,"original_control_exact":173,"candidate_original_exact":170,"shared_parent_suffixes":suffixes,"candidate_parent_suffixes":extra,"kernel_inverse_edits":ke,"window_inverse_edits":we,"qualified_field_child_exact":true,"new_bucket_bytes":128,"production_changed":false,"query_selection_changed":false,"no_new_persistent_key_copy":true});fs::write(format!("{R}/source-audit.json"),serde_json::to_vec_pretty(&audit).unwrap()).unwrap();
 let mut env=m["environment"].clone();env["CARGO_TARGET_DIR"]=format!("{R}/target").into();env["CARGO_BUILD_JOBS"]="16".into();env["RAYON_NUM_THREADS"]="4".into();env["RUSTC"]="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc".into();env["RUSTFLAGS"]=format!("{} --cfg zopro_window_trial --cfg zopro_lazy_y",m["rustflags"].as_str().unwrap()).into();
 for leaf in["source/crates/zopro-bn254/src/lazy_y.rs","source/crates/zopro-core/src/msm/lazy_y.rs","source/crates/zopro-core/src/msm_affine/g2_lazy_y_window.rs","source/crates/zopro-core/src/msm_affine/lazy_y_window_tests.rs","prepare.rs","bucket.rs","bridge.rs","custom.rs","exports.rs","tests.rs","design.md","source-audit.json"]{let p=format!("{R}/{leaf}");pins.insert(p.clone(),hash(&p));}
 fs::write(format!("{R}/environment.json"),serde_json::to_vec_pretty(&env).unwrap()).unwrap();pins.insert(format!("{R}/environment.json"),hash(format!("{R}/environment.json")));
 fs::write(format!("{R}/native-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
 let plan=json!({"version":1,"source_pins":format!("{R}/native-pins.json"),"steps":[{"kind":"command","name":"new-complete-window-tests","argv":["/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/cargo","test","--locked","--offline","--release","--manifest-path",format!("{R}/source/Cargo.toml"),"-p","zopro-core","--lib","lazy_y_window_tests::","--","--test-threads=1"],"environment":env,"timeout_seconds":1200}]});fs::write(format!("{R}/native-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();println!("Prepared new actual Window/kernel; recovered176sources in both snapshots; one targeted native qualification, no clocks");
}
