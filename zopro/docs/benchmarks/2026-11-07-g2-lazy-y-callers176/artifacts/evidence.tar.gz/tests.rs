use super::*;
use zopro_bn254::{Fq,Fq2,Fr,G2Affine,G2Projective};
const BETA:Fq=Fq::from_decimal("21888242871839275220042445260109153167277707414472061641714758635765020556616");
fn random(seed:&mut u64)->u64{*seed^=*seed<<13;*seed^=*seed>>7;*seed^=*seed<<17;*seed}
fn reference(bases:&[G2Affine],short:&[[u64;4]],w:usize,bits:usize)->Vec<G2Affine>{
 let mut buckets=vec![G2Projective::IDENTITY;1<<(bits-1)];
 for phase in[true,false]{for(p,s)in bases.iter().zip(short){let i=usize::from(phase)*2;let mut d=digit(&[s[i],s[i+1]&0x7fffffffffffffff,0,0],w,bits);if s[i+1]>>63!=0{d=-d;}if d!=0&&!p.is_identity(){let mut p=if d<0{-*p}else{*p};if phase{p.x=p.x.mul_by_fp(&BETA);}buckets[d.unsigned_abs()as usize-1]+=p;}}}
 G2Projective::batch_to_affine(&buckets)
}
fn population(n:usize,mode:usize,seed:u64)->(Vec<G2Affine>,Vec<[u64;4]>){
 let g=G2Projective::generator();let p=(g*Fr::from(1729+seed%1000)).to_affine();let mut chain=g*Fr::from(98971+seed%1000);let mut points=Vec::with_capacity(n);
 for i in 0..n{points.push(if mode==0{chain}else{match i%7{0=>G2Projective::IDENTITY,1|2=>p.to_projective(),3=>(-p).to_projective(),_=>chain}});chain+=g;}
 let bases=G2Projective::batch_to_affine(&points);let mut state=seed|1;
 let short=(0..n).map(|i|if mode==2{[if i%3==0{0}else{1},if i%5==0{1<<63}else{0},1,if i%7==0{1<<63}else{0}]}else{[random(&mut state),random(&mut state),random(&mut state),random(&mut state)]}).collect();(bases,short)
}
#[test]fn complete_windows_exceptions_tails_phi_and_input_preservation(){
 for mode in 0..3{for n in[0,1,7,8,9,31,32,33,201,513,1025]{let(bases,short)=population(n,mode,0x1749fe8d05);let original=bases.clone();let words=short.clone();for bits in[7,12]{for w in[0,1,9]{let expected=reference(&bases,&short,w,bits);for size in[8,9,31,32,33,200]{let off=lazy_y_window_trial(&bases,&short,w,bits,size,false);let on=lazy_y_window_trial(&bases,&short,w,bits,size,true);assert_eq!(off,expected,"original n={n}mode={mode}bits={bits}size={size}w={w}");assert_eq!(on,expected,"lazy n={n}mode={mode}bits={bits}size={size}w={w}");}}}assert_eq!(bases,original);assert_eq!(short,words);}}
}
#[test]fn actual_geometry_and_repeated_windows_small_stack_workers(){
 use rayon::prelude::*;
 let(bases,short)=population(15045,0,0x23c479ab);let original=bases.clone();let words=short.clone();
 let expected=reference(&bases,&short,0,12);
 for workers in[1,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||(0..workers).into_par_iter().for_each(|_|{for _ in 0..2{assert_eq!(lazy_y_window_trial(&bases,&short,0,12,0,true),expected);}}));}
 assert_eq!(bases,original);assert_eq!(short,words);
}
#[test]fn bucket_layout_and_lazy_zero_semantics(){
 use crate::msm::lazy_y::LazyYBucket;use zopro_bn254::ifma8::LazyFq;
 assert_eq!(std::mem::size_of::<LazyYBucket>(),128);assert_eq!(std::mem::align_of::<LazyYBucket>(),8);
 assert!(LazyYBucket::identity().is_identity());let p=G2Projective::generator().to_affine();let b=LazyYBucket::from_affine(p);assert!(!b.is_identity());assert_eq!(b.canonical(),p);
 assert!(LazyFq::from_canonical(Fq::ZERO).is_zero());assert!(!LazyFq::from_canonical(Fq::ONE).is_zero());assert_eq!(Fq2::ZERO,Fq2::new(Fq::ZERO,Fq::ZERO));
}
