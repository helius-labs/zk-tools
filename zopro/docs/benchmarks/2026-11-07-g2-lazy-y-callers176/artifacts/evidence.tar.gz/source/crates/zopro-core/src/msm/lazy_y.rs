use super::*;
use zopro_bn254::{G2Affine,G2Config,ifma8::LazyFq};
#[repr(C)]
#[derive(Clone,Copy)]
pub(crate) struct LazyYBucket {pub(crate) x:Fq2,pub(crate) y:[LazyFq;2]}
impl LazyYBucket {
 #[inline(always)]pub(crate)fn identity()->Self{Self::from_affine(G2Affine::IDENTITY)}
 #[inline(always)]pub(crate)fn from_affine(p:G2Affine)->Self{Self{x:p.x,y:[LazyFq::from_canonical(p.y.c0),LazyFq::from_canonical(p.y.c1)]}}
 #[inline(always)]pub(crate)fn canonical_y(self)->Fq2{Fq2::new(self.y[0].canonical(),self.y[1].canonical())}
 #[inline(always)]pub(crate)fn canonical(self)->G2Affine{G2Affine::new(self.x,self.canonical_y())}
 #[inline(always)]pub(crate)fn is_identity(self)->bool{self.x==Fq2::ZERO&&self.y[0].is_zero()&&self.y[1].is_zero()}
}

// KERNEL

fn apply(
    buckets: &mut [LazyYBucket],
    batch: &[(u32, &G2Affine)],
    s: &mut Fq2AddScratch,
) {
    let full = batch.len() / LANES * LANES;
    let mut chains = FqBatch::one();
    s.prefix_records.clear();
    s.prefix_records.reserve(full / LANES);
    for k in (0..full).step_by(LANES) {
        let ax = fq2_pack(core::array::from_fn(|i| {
            buckets[(batch[k + i].0 & 0x7fffffff) as usize].x
        }));
        let bx = fq2_pack(core::array::from_fn(|i| batch[k + i].1.x));
        let denominator = core::array::from_fn(|i| canonical_sub::<true>(&bx[i], &ax[i]));
        let norm = Fq2::lanes_norm(&denominator);
        s.prefix_records.push([chains, norm]);
        chains = chains.mul(&norm);
    }
    s.tail.clear();
    let mut inverse =
        if let Some(value) = direct_chain_inverse(&chains, full == batch.len(), s.vector_inverse) {
            value
        } else {
            let mut tail = chains.get();
            for k in full..batch.len() {
                let (encoded, b) = batch[k];
                let index = encoded & 0x7fffffff;
                let b = if encoded >> 31 != 0 { -*b } else { *b };
                let a = buckets[index as usize].canonical();
                let denominator = b.x - a.x;
                let norm = denominator.c0.square() + denominator.c1.square();
                let numerator = ((b.y - a.y) * denominator.conjugate()).mul_by_fp(&tail[k % LANES]);
                tail[k % LANES] *= norm;
                s.tail
                    .push([a.x, a.y, a.x + b.x, Fq2::new(norm, Fq::ZERO), numerator]);
            }
            let mut inverse = invert_lanes(tail, s.vector_inverse);
            for k in (full..batch.len()).rev() {
                let [ax, ay, xsum, norm, numerator] = s.tail[k - full];
                let slope = numerator.mul_by_fp(&inverse[k % LANES]);
                inverse[k % LANES] *= norm.c0;
                let x = slope.square() - xsum;
                let y = slope * (ax - x) - ay;
                buckets[(batch[k].0 & 0x7fffffff) as usize] = LazyYBucket::from_affine(G2Affine::new(x, y));
            }
            FqBatch::new(&inverse)
        };
    for j in (0..full / LANES).rev() {
        let k = j * LANES;
        let a: [LazyYBucket; LANES] =
            core::array::from_fn(|i| buckets[(batch[k + i].0 & 0x7fffffff) as usize]);
        let b: [&G2Affine; LANES] = core::array::from_fn(|i| batch[k + i].1);
        let ax = fq2_pack(a.map(|p| p.x));
        let ay = core::array::from_fn(|j| FqBatch::from_lazy_y(&a.map(|p|p.y[j])));
        let bx = fq2_pack(b.map(|p| p.x));
        let by=core::array::from_fn(|j|b.map(|p|if j==0{p.y.c0}else{p.y.c1}));
        let negative=signs::<true,G2Config>(&batch[k..k+LANES]);
        let denominator=core::array::from_fn(|i|canonical_sub::<true>(&bx[i],&ax[i]));
        let factor = s.prefix_records[j][0].mul(&inverse);
        inverse = inverse.mul(&s.prefix_records[j][1]);
        let slope = Fq2::lanes_scale(&FqBatch::lazy_y_numerator(&by,&ay,&denominator,negative), &factor);
        let x = Fq2::lanes_sub(&Fq2::lanes_square(&slope), &Fq2::lanes_add(&ax, &bx));
        let y = Fq2::lanes_sub(&Fq2::lanes_mul(&slope, &Fq2::lanes_sub(&ax, &x)), &ay);
        let x = fq2_unpack(x);
        let y = y.map(FqBatch::to_lazy_y);
        for i in 0..LANES {
            buckets[(batch[k + i].0 & 0x7fffffff) as usize] = LazyYBucket{x:x[i],y:[y[0][i],y[1][i]]};
        }
    }
}

impl BatchAdd<G2Config>{pub(crate)fn apply_lazy_y_g2(&mut self,buckets:&mut[LazyYBucket],batch:&[(u32,&G2Affine)]){debug_assert!(self.borrowed_g2_enabled());apply(buckets,batch,&mut self.fq2);}}
