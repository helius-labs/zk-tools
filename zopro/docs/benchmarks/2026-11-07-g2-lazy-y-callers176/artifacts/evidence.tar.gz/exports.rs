#[cfg(all(zopro_lazy_y,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
mod g2_lazy_y_window;
#[cfg(all(zopro_window_trial,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
#[inline(never)]
pub fn lazy_y_window_trial(bases:&[zopro_bn254::G2Affine],short:&[[u64;4]],w:usize,bits:usize,size:usize,candidate:bool)->Vec<zopro_bn254::G2Affine>{
 if candidate {
  #[cfg(zopro_lazy_y)] {return if size==0{g2_lazy_y_window::try_window(bases,short,w,bits).expect("native guard")}else{g2_lazy_y_window::trial_custom(bases,short,w,bits,size)};}
  #[cfg(not(zopro_lazy_y))] {panic!("candidate requested from original control");}
 }
 if size==0{g2_borrowed::try_window(bases,short,w,bits).expect("native guard")}else{g2_borrowed::trial_custom(bases,short,w,bits,size)}
}
#[cfg(all(test,zopro_lazy_y,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
mod lazy_y_window_tests;
