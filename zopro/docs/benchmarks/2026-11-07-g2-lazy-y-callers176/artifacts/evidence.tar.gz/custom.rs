// Diagnostic helper shared byte-for-byte by original and lazy Windows.
#[cfg(zopro_window_trial)]
pub(super) fn trial_custom(bases:&[G2Affine],short:&[[u64;4]],w:usize,bits:usize,size:usize)->Vec<G2Affine>{
 let packed=BatchAdd::default();assert!(packed.borrowed_g2_enabled());
 let mut s=Window::new(1<<(bits-1),size,packed);
 s.feed(bases,short,true,w,bits,size);
 assert!(s.batch.is_empty()&&s.queue.is_empty());
 for p in &mut s.affine{if !p.is_identity(){p.x=p.x.mul_by_fp(&BETA);}}
 for p in &mut s.projective{p.x=p.x.mul_by_fp(&BETA);}
 s.feed(bases,short,false,w,bits,size);s.finish()
}
