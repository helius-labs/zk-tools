use serde_json::json;use sha2::{Digest,Sha256};use std::{alloc::{GlobalAlloc,Layout},sync::{Arc,Mutex,atomic::{AtomicBool,AtomicUsize,Ordering::Relaxed}},time::Instant,hint::black_box};
use rayon::prelude::*;use zopro_bn254::{Fq,Fq2,G2Affine,G2Projective,Fr};
mod perf;
static AUDIT:AtomicBool=AtomicBool::new(false);static ALLOCS:AtomicUsize=AtomicUsize::new(0);static REALLOCS:AtomicUsize=AtomicUsize::new(0);static BYTES:AtomicUsize=AtomicUsize::new(0);
struct Counted;unsafe impl GlobalAlloc for Counted{
 unsafe fn alloc(&self,l:Layout)->*mut u8{if AUDIT.load(Relaxed){ALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(l.size(),Relaxed);}unsafe{zopro_core::alloc::Allocator.alloc(l)}}
 unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8{if AUDIT.load(Relaxed){ALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(l.size(),Relaxed);}unsafe{zopro_core::alloc::Allocator.alloc_zeroed(l)}}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8{if AUDIT.load(Relaxed){REALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(n,Relaxed);}unsafe{zopro_core::alloc::Allocator.realloc(p,l,n)}}
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){unsafe{zopro_core::alloc::Allocator.dealloc(p,l)}}
}#[global_allocator]static A:Counted=Counted;
fn affinity(cpu:usize){unsafe{let mut mask:libc::cpu_set_t=std::mem::zeroed();libc::CPU_ZERO(&mut mask);libc::CPU_SET(cpu,&mut mask);assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&mask),&mask),0);}}
fn rng(seed:&mut u64)->u64{*seed^=*seed<<13;*seed^=*seed>>7;*seed^=*seed<<17;*seed}
struct Fixture{bases:Arc<Vec<G2Affine>>,short:Vec<[u64;4]>,expected:Vec<G2Affine>,last:Option<Vec<G2Affine>>}
impl Fixture{
 fn new(bases:Arc<Vec<G2Affine>>,worker:usize)->Self{
  let mut seed=0x3976b8d14ce250afu64.wrapping_add(worker as u64*2);
  let short=(0..bases.len()).map(|_|core::array::from_fn(|_|rng(&mut seed))).collect::<Vec<_>>();
  const BETA:Fq=Fq::from_decimal("21888242871839275220042445260109153167277707414472061641714758635765020556616");
  let mut buckets=vec![G2Projective::IDENTITY;2048];
  for high in[true,false]{for(p,s)in bases.iter().zip(&short){let i=usize::from(high)*2;let mut d=(s[i]&4095)as i16;if d>=2048{d-=4096;}if s[i+1]>>63!=0{d=-d;}if d!=0{let mut p=if d<0{-*p}else{*p};if high{p.x=p.x.mul_by_fp(&BETA);}buckets[d.unsigned_abs()as usize-1]+=p;}}}
  let expected=G2Projective::batch_to_affine(&buckets);Self{bases,short,expected,last:None}
 }
 fn run(&mut self,rounds:usize,on:bool){assert!(self.last.is_none());for i in 0..rounds{let out=zopro_core::lazy_y_window_trial(&self.bases,&self.short,0,12,0,on);if i+1==rounds{self.last=Some(out);}else{black_box(&out);drop(out);}}}
 fn check(&self){assert_eq!(self.last.as_ref().unwrap(),&self.expected);}
 fn reset(&mut self){self.last=None;}
 fn digest(&self,h:&mut Sha256){for p in self.last.as_ref().unwrap(){for v in[p.x.c0,p.x.c1,p.y.c0,p.y.c1]{for w in v.0{h.update(w.to_le_bytes());}}}}
}
fn main(){
 let a=std::env::args().collect::<Vec<_>>();assert_eq!(a.len(),5);let n=a[1].parse::<usize>().unwrap();let workers=a[2].parse::<usize>().unwrap();let rounds=a[3].parse::<usize>().unwrap();let on=match a[4].as_str(){"OFF"=>false,"ON"=>true,_=>panic!("arm")};assert!([15044,14426].contains(&n)&&[1,16,32].contains(&workers)&&rounds>0);if on{assert!(cfg!(zopro_lazy_y));}
 let seen=Arc::new(Mutex::new(Vec::new()));let seen2=seen.clone();let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).start_handler(move|i|{let cpu=if workers==1{2}else{i};affinity(cpu);seen2.lock().unwrap().push(json!({"worker":i,"cpu":cpu,"tid":unsafe{libc::syscall(libc::SYS_gettid)}}));}).build().unwrap();pool.broadcast(|_|());let mut mapping=seen.lock().unwrap().clone();mapping.sort_by_key(|x|x["worker"].as_u64().unwrap());assert_eq!(mapping.len(),workers);
 let g=G2Projective::generator();let mut point=g*Fr::from(98761u64);let mut projective=Vec::with_capacity(n);for _ in 0..n{projective.push(point);point+=g;}let bases=Arc::new(G2Projective::batch_to_affine(&projective));drop(projective);
 let mut fixtures=(0..workers).map(|i|Fixture::new(bases.clone(),i)).collect::<Vec<_>>();
 for _ in 0..3{pool.install(||fixtures.par_iter_mut().for_each(|f|{f.reset();f.run(1,on);f.check();}));}for f in &mut fixtures{f.reset();}
 let audit=std::env::var_os("ZOPRO_WINDOW_ALLOC_AUDIT").is_some();
 let mut control=perf::Control::from_env().unwrap();if let Some(c)=control.as_mut(){c.enable().unwrap();}
 let usage0=perf::Usage::now().unwrap();AUDIT.store(audit,Relaxed);let start=Instant::now();pool.install(||fixtures.par_iter_mut().for_each(|f|f.run(black_box(rounds),on)));let elapsed=start.elapsed().as_nanos()as u64;AUDIT.store(false,Relaxed);let usage1=perf::Usage::now().unwrap();if let Some(c)=control.as_mut(){c.disable().unwrap();}
 let mut h=Sha256::new();for f in &fixtures{f.check();f.digest(&mut h);}pool.broadcast(|ctx|assert_eq!(unsafe{libc::sched_getcpu()},if workers==1{2}else{ctx.index()}as i32));
 println!("CALLER {}",json!({"kind":"G2","size":n,"workers":workers,"rounds_per_worker":rounds,"arm":a[4],"pid":std::process::id(),"worker_rows":mapping,"elapsed_ns":elapsed,"ns_per_batch_wave":elapsed as f64/rounds as f64,"allocation_audit_enabled":audit,"audited_allocations":ALLOCS.load(Relaxed),"audited_reallocations":REALLOCS.load(Relaxed),"audited_requested_bytes":BYTES.load(Relaxed),"complete_generator_oracle":true,"priming_passes":3,"priming_rounds":1,"output_sha256":format!("{:x}",h.finalize()),"usage":usage1.difference(&usage0),"new_proofs":0,"geometry":{"bits":12,"column":0,"buckets":2048,"nominal_batch":200},"scope":"fresh complete Window construction, both feeds, exceptions, tails, final normalization and rounds-1 output destructions; final equality/hash/destruction excluded"}));
}
