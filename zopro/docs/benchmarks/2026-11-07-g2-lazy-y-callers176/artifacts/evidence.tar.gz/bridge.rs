#[cfg(all(zopro_lazy_y,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
impl FqBatch {
 #[inline(always)]pub(crate)fn from_lazy_y(values:&[zopro_bn254::ifma8::LazyFq;8])->Self{Self(zopro_bn254::ifma8::LazyY8::new(values).batch())}
 #[inline(always)]pub(crate)fn to_lazy_y(self)->[zopro_bn254::ifma8::LazyFq;8]{zopro_bn254::ifma8::LazyY8::from_batch(self.0).get()}
 #[inline(always)]pub(crate)fn lazy_y_numerator(by:&[[Fq;8];2],ay:&[Self;2],dx:&[Self;2],negative:u8)->[Self;2]{zopro_bn254::ifma8::lazy_y_numerator(by,&ay.map(|v|zopro_bn254::ifma8::LazyY8::from_batch(v.0)),&dx.map(|v|v.0),negative).map(Self)}
}
