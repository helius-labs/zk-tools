use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-complex176";
const REPO: &str = "/home/ubuntu/src/zk-tools";
const DEST: &str = "zopro/docs/benchmarks/2026-11-06-joint-pair52-complex176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn write(p: impl AsRef<Path>, x: &Value) {
    fs::write(p, serde_json::to_vec_pretty(x).unwrap()).unwrap();
}
fn main() {
    let r = PathBuf::from(R);
    let d = Path::new(REPO).join(DEST);
    assert!(!r.join("review.json").exists());
    let pins = read(r.join("pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    assert_eq!(pins.as_object().unwrap().len(), 22);
    let result = read(r.join("result.json"));
    let protocol = read(r.join("protocol.json"));
    assert_eq!(result["status"], "pass");
    let mut receipts = 0;
    let mut members: Vec<String> = [
        "design.md",
        "bounds.md",
        "model.rs",
        "manage.rs",
        "finish.rs",
        "pins.json",
        "protocol.json",
        "build-pins.json",
        "build-plan.json",
        "run-plan.json",
        "result.json",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect();
    for (dir, plan) in [("build", "build-plan.json"), ("run", "run-plan.json")] {
        assert_eq!(read(r.join(dir).join("result.json"))["status"], "complete");
        assert!(!r.join(dir).join("attempt-1.json").exists());
        for step in read(r.join(plan))["steps"].as_array().unwrap() {
            let name = step["name"].as_str().unwrap();
            let path = r.join(dir).join(name);
            let exit = read(path.join("exit.json"));
            assert_eq!(exit["success"], true);
            assert_eq!(exit["returncode"], 0);
            assert_eq!(
                read(path.join("command.json"))["argv"].as_array().unwrap()[4..],
                step["argv"].as_array().unwrap()[..]
            );
            for stream in ["stdout", "stderr"] {
                assert_eq!(
                    exit[format!("{stream}_sha256")],
                    hash(path.join(format!("{stream}.log")))
                );
            }
            assert!(fs::read(path.join("stderr.log")).unwrap().is_empty());
            for file in [
                "command.json",
                "exit.json",
                "stdout.log",
                "stderr.log",
                "tests.json",
            ] {
                members.push(format!("{dir}/{name}/{file}"));
            }
            receipts += 1;
        }
        for file in [
            "result.json",
            "protocol.json",
            "source-pins.json",
            "attempt-0.json",
            "completed.json",
            "progress.json",
        ] {
            members.push(format!("{dir}/{file}"));
        }
    }
    assert_eq!(receipts, 2);
    let log = fs::read_to_string(r.join("run/joint-complex-exact-model/stdout.log")).unwrap();
    assert_eq!(
        serde_json::from_str::<Value>(log.strip_prefix("JOINT_PAIR52_COMPLEX ").unwrap().trim())
            .unwrap(),
        result
    );
    let mut negative = 0;
    let mut sub2p = 0;
    let mut total = 0;
    let mut max = [0u64; 4];
    for row in result["field_results"].as_array().unwrap() {
        let s = &row["result"];
        let tuples = 122 * 122 + 4096 + 256 + 1024;
        let calls = 2 * tuples;
        let outputs = 2 * calls;
        assert_eq!(outputs, 81040);
        assert_eq!(s["reduced_outputs"], outputs);
        assert_eq!(s["joint_complex_or_polynomial_calls"], calls);
        assert_eq!(s["exact_cancellation_rows"], outputs * 5);
        assert_eq!(s["input_ifma_proxy"], calls * 90);
        assert_eq!(s["reduction_ifma_proxy"], calls * 100);
        assert_eq!(s["input_alu_mask_proxy"], calls * 296);
        assert_eq!(s["linear_sum_difference_operations"], calls * 3);
        assert_eq!(s["two_p_input_occurrences"], 488 + 256);
        assert!(s["negative_REDC_representatives"].as_u64().unwrap() > 0);
        if row["radix"] == 260 {
            assert_eq!(s["subtract2p_corrections"], 0);
        }
        negative += s["negative_REDC_representatives"].as_u64().unwrap();
        sub2p += s["subtract2p_corrections"].as_u64().unwrap();
        total += outputs;
        for j in 0..4 {
            let x = s["max_abs_by_phase"][j].as_u64().unwrap();
            assert!((x as u128) < [32u128, 64, 1026, 1026][j] * (1u128 << 52));
            max[j] = max[j].max(x);
        }
    }
    assert_eq!(total, 324160);
    assert_eq!(protocol["total_field_outputs"], total);
    assert_eq!(result["total_exact_rows"], 1620800);
    assert_eq!(protocol["total_exact_rows"], 1620800);
    assert_eq!(result["full52_joint_calls"], 6144);
    assert_eq!(result["full52_output_polynomials"], 12288);
    let full = &result["full52_result"];
    assert_eq!(full["input_ifma_proxy"], 6144 * 90);
    assert_eq!(full["input_alu_mask_proxy"], 6144 * 296);
    assert_eq!(full["reduced_outputs"], 0);
    assert_eq!(190, 3 * 15 * 2 + 2 * 50);
    assert_eq!(296, 5 * 4 + 2 * 13 + 10 * (3 * 7 + 4));
    assert_eq!(result["proxy"]["total_ifma"], 190);
    assert_eq!(result["proxy"]["input_alu_mask"], 296);
    let manifest=read(Path::new(REPO).join("zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let mut sources = 0;
    for (name, h) in manifest["source_files_sha256"].as_object().unwrap() {
        assert_eq!(
            hash(Path::new(REPO).join("zopro").join(name)),
            h.as_str().unwrap()
        );
        sources += 1;
    }
    assert_eq!(sources, 176);
    // Analytical interval check is independent from the observed maxima.
    let b = 1u128 << 52;
    assert!(20 * b + 8 * b < 32 * b);
    assert!(32 * b + 10 * b + b + 44 < 44 * b);
    assert!(16 * 64 * b + b + 1024 < 1026 * b);
    assert!(1026 * b < 1u128 << 63);
    let review = json!({"status":"pass","pins":22,"successful_command_receipts":2,"attempts_each":1,"unchanged_production_sources":176,"field_outputs":total,"exact_rows":1620800,"full52_joint_calls":6144,"full52_output_polynomials":12288,
 "negative_representatives_corrected":negative,"unsigned_subtract2p_corrections":sub2p,"all_negative_top_branches_exercised":true,"uniform_unsigned_corrections":0,"max_observed_abs_by_phase":max,
 "source_work_reconstruction":{"input_ifma":90,"reduction_ifma":100,"total_ifma":190,"input_alu_mask":296},
 "scope":"mathematical model and receipt/range/work review only; not SIMD ISA/caller/stack/proof qualification",
 "reviewer_source_sha256":hash(r.join("finish.rs")),"reviewer_binary_sha256":hash(r.join("finish")),
 "decision":"select one fixed jointly accumulated native complex feasibility implementation and focused independent SIMD/codegen qualification; no ordinaryfield replacement or FrFFT change/adoption/performance claim","new_proofs":0});
    write(r.join("review.json"), &review);
    members.push("review.json".into());
    fs::create_dir_all(d.join("artifacts")).unwrap();
    for file in [
        "result.json",
        "protocol.json",
        "review.json",
        "pins.json",
        "bounds.md",
    ] {
        fs::copy(r.join(file), d.join("artifacts").join(file)).unwrap();
    }
    let mut hashes = BTreeMap::new();
    for file in &members {
        let bytes = fs::read(r.join(file)).unwrap();
        std::str::from_utf8(&bytes).unwrap();
        hashes.insert(file.clone(), format!("{:x}", Sha256::digest(bytes)));
    }
    write(d.join("artifacts/archive-members.json"), &json!(hashes));
    let archive = d.join("artifacts/source-and-receipts.tar.gz");
    assert!(Command::new("tar")
        .arg("-czf")
        .arg(&archive)
        .arg("-C")
        .arg(&r)
        .arg("--")
        .args(&members)
        .status()
        .unwrap()
        .success());
    let listing = Command::new("tar")
        .arg("-tzf")
        .arg(&archive)
        .output()
        .unwrap();
    assert!(listing.status.success());
    assert_eq!(
        String::from_utf8(listing.stdout)
            .unwrap()
            .lines()
            .map(str::to_owned)
            .collect::<Vec<_>>(),
        members
    );
    let extraction = r.join("archive-review");
    fs::create_dir(&extraction).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&extraction)
        .status()
        .unwrap()
        .success());
    for (file, h) in &hashes {
        assert_eq!(&hash(extraction.join(file)), h);
    }
    let report=format!("# Joint signed-pair complex arithmetic model\n\nThe fixed jointly accumulated complex-product recipe passes its exact coefficient and signed-Montgomery-reduction screen. This selects one native feasibility implementation and focused independent SIMD/code-generation qualification. **No speedup or adoption is established.** Production remains unchanged.\n\n## Arithmetic\n\nThree unreduced products share work between both output polynomials. Normal multiplication uses S=a0+a1,T=b0+b1,D=b1-b0 (normalized modulo2p), P=S*b0,Q=a1*T,U=a0*D, then(real,imag)=(REDC(P-Q),REDC(P+U)). Conjugation instead uses T=b0-b1,D=b0+b1 and(real,imag)=(REDC(P-Q),REDC(P-U)). The model matches direct complex identities modulo p and the input Montgomery radix. No invalid unreduced host field objects are constructed.\n\nEach raw product uses five diagonal and ten oriented signed limb-difference products. The diagonals mix directly into two outputs, and the P cross pieces are computed once and shared. This is a joint dataflow, not three separately materialized full convolutions. Signed real outputs, and both conjugated outputs, require arithmetic carries and a signed top until conditional addition of2p. Ordinary field multiplication and Fr/R260 FFT arithmetic are outside the proposed API change.\n\n## Model evidence\n\nThe new model checked **324,160 reduced outputs and1,620,800 exact cancellation rows** over Fq/Fr, R256/R260, normal/conjugated products, lazy endpoints, full-width random inputs and changing chains. Each field/radix has14,884boundary tuples,4,096random tuples,256endpoint-cartesian tuples and1,024chain tuples, with four outputs per tuple. Another6,144joint full52-bit polynomial calls check12,288output polynomials without assuming field bounds. The inherited public fixture is reapplied to a different arithmetic algorithm; no old model is rerun and none of these component results is a new proof.\n\nEvery joint polynomial matches independent integer products. Every cancellation state is checked for divisibility and its exact signed quotient; full REDC matches an independent extended-Euclid quotient, and canonical values match direct complex arithmetic with a modular-power radix inverse. The model exercises **{negative}negative reduced representatives** and **{sub2p}unsigned subtract2p corrections**. Each field/radix exercises negative-top correction; the larger radix needs no unsigned correction.\n\nThe general bounds and source recipe are in [bounds.md](artifacts/bounds.md). The two polynomials start below32B in coefficient magnitude, cancellation stays below64B, and final scaling/correction stays below1026B<2^63, B=2^52. Observed maxima supplement these arguments. Signed raw reductions lie in(-p,2p), while a normal unsigned imaginary reduction is below3p. Conditional2p corrections restore normalized[0,2p) outputs. These are mathematical bounds and finite checks, not native machine-code or memory qualification.\n\n## Work and native obligations\n\nThe fixed source proxy has **190 IFMAs versus300** for two retained fused products:90input plus100reduction. It adds296input vector/mask operations before three field-linear operations, reducer/carry/correction ALU, comparisons, loads, moves and spills. The 190count is not an optimized instruction count or a latency bound. A native result can lose despite fewer IFMAs.\n\nTwenty live output coefficients represent1,280logical vector bytes at eight lanes, before operands and scratch. This is not a frame, concurrent-lifetime bound, actual spill traffic, RSS peak or minimum RAM. The native implementation must retain joint accumulation, qualify actual signed corrections, and inspect final compiler code. It introduces no proposed heap/table/key-copy/plan/pool expansion.\n\nThis differs from the [closed250-IFMA Gauss caller](../2026-10-29-positive-gauss-caller175/README.md) and from three independently reduced products: the limb-product count, joint dataflow and signed correction differ. The [global ordinary signed-pair replacement](../2026-11-06-signed-pair52-screen176/README.md) remains closed with all gains/regressions retained; this is not a representation subset adoption of that build. The [Toom-5 screen](../2026-11-06-toom5-work176/README.md) also remains closed.\n\n## Execution and next stage\n\nThe normal Rust build and new model run both succeed first attempt. Separate review checks22pins, two successful receipts, all176unchanged production-source identities, row/output totals, exercised correction paths and the reconstructed source ledger. It does not rerun the model. Archive member/extraction hashes and final checksums pass.\n\nNext is one fixed native complex implementation with both normal and conjugated paths, independent raw-output/export oracles and optimized final-consumer inspection. Only credible native code selects separately frozen complete G2 callers (200/352, tails,1/16/32workers, both controls and automatic profiles), followed by all-eight plus merge54 full SDK, resource/portable and independent Gnark proof qualification before adoption. No width/layout/attribute sweep, old-kernel reroll or favorable subset is selected.\n\nAccepted production176/SDK6d83 remain unchanged: local32 1×2 **7.928660ms**, merge54 **161.883899ms**; inherited132.75MiB RSS is not a new peak or minimum. Canonical proof ledger remains30,846. The inherited [all-eight M5 CPU and Metal comparison](../2026-11-06-signed-pair52-model176/README.md#accepted-full-proof-baseline-inherited) is unchanged. The all-eight10× CPU goal remains active and unmet. No new native/profile/proof/AWS/Aeglos/large/mobile/pressure/swap/throughput result exists.\n\n[Model output](artifacts/result.json), [protocol](artifacts/protocol.json), [review](artifacts/review.json), [pins](artifacts/pins.json), [bounds](artifacts/bounds.md) and [source/receipts](artifacts/source-and-receipts.tar.gz) are preserved. The inherited public fixture remains in its parent archive; executable/library/key/witness/proof blobs are excluded.\n");
    fs::write(d.join("README.md"), report).unwrap();
    let mut sums = BTreeMap::new();
    for file in [
        "README.md",
        "artifacts/result.json",
        "artifacts/protocol.json",
        "artifacts/review.json",
        "artifacts/pins.json",
        "artifacts/bounds.md",
        "artifacts/archive-members.json",
        "artifacts/source-and-receipts.tar.gz",
    ] {
        sums.insert(file, hash(d.join(file)));
    }
    write(d.join("checksums.json"), &json!(sums));
    for (file, h) in &sums {
        assert_eq!(&hash(d.join(file)), h);
    }
    write(
        r.join("publication.json"),
        &json!({"status":"pass","files":9,"utf8_archive_members":members.len(),"roundtrip_members":hashes.len(),"archive_sha256":hash(archive)}),
    );
    println!(
        "joint model reviewed/published:22pins/324160outputs/1620800rows/{}UTF8members",
        members.len()
    );
}
