use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-complex176";
const RC: &str = "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
const XT: &str = "/home/ubuntu/src/zopro-perf-work/sdk-link-flags176/tool-target/release/xtask";
const D: &str = "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
const N: &str = "/home/ubuntu/src/zopro-perf-work/word-export176/target-candidate/release/deps";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(name: &str, v: &Value) {
    fs::write(format!("{R}/{name}"), serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn main() {
    match std::env::args().nth(1).unwrap().as_str() {
        "prepare" => {
            assert!(!Path::new(R).join("build-plan.json").exists());
            save(
                "protocol.json",
                &json!({"version":1,"algorithm":"joint three15-product limb convolutions/two signed REDCs; normal and conjugated complex products",
   "full52_joint_calls":6144,"full52_output_polynomials":12288,"full52_population":"32endpointpatterns crossed+2048inheritedfullrandom, each normal/conjugate sign",
   "fields":["Fq","Fr"],"radices":[256,260],"per_field_radix":{"boundary_tuples":14884,"random_tuples":4096,"four_component_endpoint_cartesian_tuples":256,"changing_chain_tuples":1024,"joint_calls":40520,"outputs":81040,"rows":405200},
   "total_field_outputs":324160,"total_exact_rows":1620800,"checks":["joint full polynomial exact against independent BigInt products","normal/conjugate complex residues","row divisibility and exact signed quotient","full signed Montgomery quotient independent Euclid","canonical reference independent modular-power radix inverse","signed top and add2p/unsigned subtract2p corrections","lazy closure and digit normalization","constant190IFMA/296inputALU source proxy","negative correction exercised each field/radix"],
   "model_stage_bounds_B_units":[32,64,1026,1026],"no_old_model_execution":true,"no_clock":true,"source_work_proxy_not_latency":true,
   "scope":"new mathematical coefficient/signed REDC model only, not native field/ISA/caller/SDK/proof/memory peak; ordinary field/FrFFT retained if integrated",
   "decision":"a mathematical pass can select one fixed native implementation and actual SIMD/codegen feasibility; no subset use of closed global ordinary experiment; full caller/fullproof still necessary"}),
            );
            let mut pins = BTreeMap::new();
            for p in [format!("{R}/model.rs"),format!("{R}/manage.rs"),format!("{R}/manage"),format!("{R}/design.md"),format!("{R}/bounds.md"),format!("{R}/protocol.json"),RC.into(),XT.into(),
   format!("{D}/libserde_json-cdebb9338c2784ad.rlib"),format!("{D}/libsha2-16b8f2c03bdf5faa.rlib"),format!("{N}/libnum_bigint-c7c8e458843263c8.rlib"),
   "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/inputs.json".into(),"/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/bounds.md".into(),"/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/result.json".into(),
   "/home/ubuntu/src/zk-tools/zopro/crates/zopro-bn254/src/lib.rs".into(),"/home/ubuntu/src/zk-tools/zopro/crates/zopro-bn254/src/ifma8.rs".into(),"/home/ubuntu/src/zk-tools/zopro/crates/zopro-core/src/msm.rs".into(),
   "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json".into(),
   "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-29-positive-gauss-caller175/README.md".into()]{pins.insert(p.clone(),hash(p));}
            save("build-pins.json", &json!(pins));
            let argv = vec![
                RC.to_owned(),
                "--edition=2021".into(),
                "-O".into(),
                format!("{R}/model.rs"),
                "-o".into(),
                format!("{R}/model"),
                "-L".into(),
                format!("dependency={D}"),
                "-L".into(),
                format!("dependency={N}"),
                "--extern".into(),
                format!("num_bigint={N}/libnum_bigint-c7c8e458843263c8.rlib"),
                "--extern".into(),
                format!("serde_json={D}/libserde_json-cdebb9338c2784ad.rlib"),
                "--extern".into(),
                format!("sha2={D}/libsha2-16b8f2c03bdf5faa.rlib"),
            ];
            save(
                "build-plan.json",
                &json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"environment":{},"steps":[{"kind":"command","name":"build-joint-complex-model","argv":argv,"timeout_seconds":120}]}),
            );
            println!("prepared{}pins before normal Rust model build", pins.len());
        }
        "freeze" => {
            assert_eq!(read(format!("{R}/build/result.json"))["status"], "complete");
            let mut pins = read(format!("{R}/build-pins.json"))
                .as_object()
                .unwrap()
                .clone();
            for (p, h) in &pins {
                assert_eq!(hash(p), h.as_str().unwrap());
            }
            for p in [
                format!("{R}/model"),
                format!("{R}/build-plan.json"),
                format!("{R}/build/result.json"),
            ] {
                pins.insert(p.clone(), json!(hash(p)));
            }
            save("pins.json", &json!(pins));
            save(
                "run-plan.json",
                &json!({"version":1,"source_pins":format!("{R}/pins.json"),"environment":{},"steps":[{"kind":"command","name":"joint-complex-exact-model","argv":[format!("{R}/model"),R],"timeout_seconds":600}]}),
            );
            println!(
                "frozen{}pins before first joint model execution",
                pins.len()
            );
        }
        _ => panic!("stage"),
    }
}
