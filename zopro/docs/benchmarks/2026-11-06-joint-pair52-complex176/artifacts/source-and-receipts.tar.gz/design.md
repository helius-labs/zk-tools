# Joint signed-pair complex multiplication: exact model first

This is an unimplemented mathematical/work/range question, not a native candidate or performance result. The prior global signed-pair52 replacement remains CLOSED (0e5f181bbf): preserve its R256 gains and uniform-R260 regressions, without subset integration or changing its declared gate. Base-field Toom5 is CLOSED after its explicit work screen (f6646e9ca6): no evaluation-point/width/interpolation sweep. The final48-bit full-shift idea is the already closed Oct25CIOS-pack qualification/4999 trial. Do not rerun those successful models/captures/builds.

New combined mechanism: three *unreduced* signed-pair limb convolutions feed two jointly accumulated output polynomials, followed by only two signed-capable Montgomery reductions. This combines the new fifteen-limb-product decomposition with a shared complex-product formula. It is not the old three ordinary reduced products, the old250-IFMA raw-Gauss kernel, nor a mixed-only dispatch of the previous global ordinary multiplier. Ordinary field multiplication and Fr/R260 FFT arithmetic remain the retained implementation. This is a composition of known algebra, not a novelty claim.

Actual current caller: msm.rs reverse complex operations use a[0].difference2(b[0],a[1],b[1]) and a[0].sum2(b[1],a[1],b[0]); denominator-conjugated products also use two fused products. These are two eight-lane real-field vectors for eight complex elements, not one interleaved four-complex vector. Their source proxy is2*150=300IFMAs. The proposed method returns both vectors together.

Let all raw normalized component integers a0,a1,b0,b1 be in[0,2p], with R256>4p. Linear sum/difference operands below are normalized modulo2p into[0,2p], preserving residues modulo p. They are not unreduced public host Fp objects.

Normal product:

    S = a0+a1 mod2p
    T = b0+b1 mod2p
    D = b1-b0 mod2p
    P = S*b0; Q = a1*T; U = a0*D   (raw full products)
    real = REDC(P-Q)
    imag = REDC(P+U)

Conjugated second input:

    S = a0+a1 mod2p
    T = b0-b1 mod2p
    D = b0+b1 mod2p
    P = S*b0; Q = a1*T; U = a0*D
    real = REDC(P-Q)
    imag = REDC(P-U)

The normal residues are a0*b0-a1*b1 and a0*b1+a1*b0. Conjugation gives a0*b0+a1*b1 and a1*b0-a0*b1. Every P,Q,U is nonnegative and <=4p². Signed P-Q and P-U lie in[-4p²,4p²]; exact Montgomery REDC with quotient in[0,R) lies strictly in(-p,2p). Add2p to a negative representative, otherwise retain it, producing[0,2p). P+U<=8p² has REDC<3p, so the existing subtract2p correction restores[0,2p). These arguments apply to largerR260 as well; its unsigned bound is tighter. A signed top limb after four arithmetic normalization carries must be preserved until correction. The old nonnegative-only reducer cannot be used unchanged.

For each raw product, use five diagonal products and ten oriented signed limb-difference products as in the qualified parent model. Assemble the shared diagonal convolutions directly: Dreal=DP-DQ; Dimag=DP+DU (normal) or DP-DU (conjugate). Each output's sliding diagonal convolution takes13add/sub operations. For each limb pair, compute the shared P correction once and add its two pieces into both output polynomials. Accumulate Q negatively into real and U with the required sign into imag. Negating a cross product can reverse the second difference before orientation, so no separate wide negation pass is required. Diagonal signs must also match.

Preliminary fixed source ledger, NOT yet verified: input15products*3*2IFMA=90, plus two five-row50-IFMA reductions=190 vs300. Diagonal combination costs20ALU operations; two shared diagonal convolutions26; ten cross pairs cost25each (three seven-operation difference/sign recipes plus four additions for the shared P halves): total296ALU/mask operations before three input linear operations, common reductions/normalization and final corrections. This proxy excludes loads, moves, spills, code size, scalar tails and scheduling; it is not a native instruction or latency bound. Do not compare190directly with a full-proof timing or infer a2x proof gain.

Register/lifetime obligation: two output polynomials have20vector coefficients, before live inputs and difference temporaries. A literal three-convolution materialization can create additional intermediates. The proposed joint accumulation must be modeled as actual dataflow, and later inspected in its final native consumer; no claim that all inputs/accumulators fit registers. No heap allocation, key table, duplicate proving-key/plan or new pool is proposed. Actual compiler stack and charged workspace remain unmeasured. A source array payload is not measured peak RAM.

History read this turn: Oct25shared-complex/Oct26streamed-complex-B and nonnegative-Gauss arithmetic, Oct29positive-Gauss borrowed caller (250vs300IFMA, all32worker contexts regressed8.22% and closed), Oct28reduced-Gauss; the new limb decomposition changes multiplication count, signed intermediate correction and dataflow. Do not rerun those old variants as controls or claim their isolated gains transfer. Targeted searches for nested/two-level/pairwise-Fq2/190IFMA found no matching report; this is not an exhaustive novelty proof.

FIRST UNFINISHED: implement the one joint exact coefficient model and signed REDC extension with row-by-row independent BigInt divisibility/quotient checks, both output identities, normal/conjugate modes, raw lazy endpoints and full-width/random/changing chains. Independently verify coefficient/carry bounds, negative-top correction, exact source ledger and realistic live-value obligations. Reuse public fixtures without regenerating or rerunning old arithmetic studies. A mathematical pass selects native feasibility only if full dataflow/cost looks credible; no native source/build/protocol/clock/profile exists yet. If selected, qualify actual SIMD and final G2 callers (200/352, tails,1/16/32workers, both controls/automatic profiles) before complete all-eight+54/resource/portable/Gnark proof trials. Ordinary field/FrFFT remain unchanged, but full goal scope does not shrink.

Audit exclusions: G2 already applies phi to completed bucket sums; G1bucket-Horner/borrowedK-H/point-transform variants are closed. Solver already has specialized sparse-Poseidon and native eight-lane products; do not relabel those as new optimization. HistoricalTLB/IBS observations alone do not isolate a current huge-page benefit. No new profiler capture was selected from those source/history checks.

Keep the goal active: verified CPU single-proof latency>=10x supplied M5CPU for ALL eight shapes, reporting CPU+Metal and bounded-memory/large/mobile compatibility. Accepted source176/SDK6d83,local1x2 7.928660ms,merge54 161.883899ms,inherited132.75MiBRSS(notnewpeak/minRAM),proofledger30846 unchanged. No native or proof result from this proposal. Commit AND push completed experiments, preserve negative evidence and next-agent execution mandate, continue autonomously without questions or agents.
