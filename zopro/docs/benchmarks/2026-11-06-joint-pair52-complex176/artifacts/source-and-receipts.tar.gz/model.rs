//! Joint coefficient dataflow and signed reduction model; not native SIMD.
use num_bigint::{BigInt, BigUint, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, path::Path};
const B: i128 = 1i128 << 52;
const MASK: u64 = (1u64 << 52) - 1;
type Digits = [u64; 5];
fn u(x: u64) -> BigUint {
    BigUint::from(x)
}
fn bi(x: &BigUint) -> BigInt {
    BigInt::from(x.clone())
}
fn parse(s: &str) -> BigUint {
    BigUint::parse_bytes(s.as_bytes(), 16).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn digits(x: &BigUint) -> Digits {
    let mut n = x.clone();
    std::array::from_fn(|_| {
        let v = (&n & u(MASK)).to_u64_digits().first().copied().unwrap_or(0);
        n >>= 52usize;
        v
    })
}
fn number(a: Digits) -> BigUint {
    a.iter().rev().fold(u(0), |n, &v| (n << 52usize) + u(v))
}
fn poly(a: &[i128]) -> BigInt {
    a.iter()
        .rev()
        .fold(BigInt::from(0), |n, &v| (n << 52usize) + BigInt::from(v))
}
#[derive(Default)]
struct Stats {
    input_ifma: u64,
    reduction_ifma: u64,
    input_alu: u64,
    joint: u64,
    rows: u64,
    outputs: u64,
    negative_pair_halves: u64,
    negative_raw: u64,
    subtract_two_p: u64,
    linear_ops: u64,
    endpoints: u64,
    max_abs: [i128; 4],
    digest: Sha256,
}
impl Stats {
    fn check(&mut self, x: i128, phase: usize) -> i128 {
        assert!(
            x >= i64::MIN as i128 && x <= i64::MAX as i128,
            "signed lane overflow {x}"
        );
        assert!(
            x.abs() < [32 * B, 64 * B, 1026 * B, 1026 * B][phase],
            "phase {phase} overflow {x}"
        );
        self.max_abs[phase] = self.max_abs[phase].max(x.abs());
        x
    }
    fn update(&mut self, t: &mut [i128], j: usize, x: i128, phase: usize, alu: bool) {
        t[j] = self.check(t[j] + x, phase);
        self.input_alu += alu as u64;
    }
    fn split(&mut self, a: u64, b: u64, input: bool) -> (i128, i128) {
        assert!(a <= MASK && b <= MASK);
        let p = a as u128 * b as u128;
        if input {
            self.input_ifma += 2;
        } else {
            self.reduction_ifma += 2;
        }
        ((p & MASK as u128) as i128, (p >> 52) as i128)
    }
    fn json(&self) -> Value {
        json!({"input_ifma_proxy":self.input_ifma,"reduction_ifma_proxy":self.reduction_ifma,"input_alu_mask_proxy":self.input_alu,"joint_complex_or_polynomial_calls":self.joint,
  "exact_cancellation_rows":self.rows,"reduced_outputs":self.outputs,"negative_pair_high_corrections":self.negative_pair_halves,"negative_REDC_representatives":self.negative_raw,"subtract2p_corrections":self.subtract_two_p,"linear_sum_difference_operations":self.linear_ops,"two_p_input_occurrences":self.endpoints,"max_abs_by_phase":self.max_abs,"digest":format!("{:x}",self.digest.clone().finalize())})
    }
}
fn diagonal_convolution(lo: [i128; 5], hi: [i128; 5], s: &mut Stats) -> [i128; 10] {
    let mut e = [0i128; 6];
    e[0] = lo[0];
    e[5] = hi[4];
    for j in 1..5 {
        e[j] = s.check(lo[j] + hi[j - 1], 0);
        s.input_alu += 1;
    }
    let mut t = [0i128; 10];
    t[0] = e[0];
    for j in 1..5 {
        t[j] = s.check(t[j - 1] + e[j], 0);
        s.input_alu += 1;
    }
    t[5] = s.check(t[4] + e[5], 0);
    t[5] = s.check(t[5] - e[0], 0);
    s.input_alu += 2;
    for j in 6..9 {
        t[j] = s.check(t[j - 1] - e[j - 5], 0);
        s.input_alu += 1;
    }
    t[9] = e[5];
    t
}
fn pair(a: Digits, b: Digits, j: usize, k: usize, negative: bool, s: &mut Stats) -> (i128, i128) {
    let dx = a[j] as i128 - a[k] as i128;
    let dy = if negative {
        b[j] as i128 - b[k] as i128
    } else {
        b[k] as i128 - b[j] as i128
    };
    let x = dx.abs() as u64;
    let y = if dx < 0 { -dy } else { dy };
    assert!(x <= MASK && y.abs() < B);
    s.input_alu += 7;
    let (lo, hi) = s.split(x, (y as u64) & MASK, true);
    let hi = if y < 0 {
        s.negative_pair_halves += 1;
        s.check(hi - x as i128, 0)
    } else {
        hi
    };
    assert_eq!(
        BigInt::from(lo) + (BigInt::from(hi) << 52usize),
        BigInt::from(x) * BigInt::from(y)
    );
    (lo, hi)
}
// Products P,Q,U are accumulated directly into two outputs. P is shared.
fn joint(
    p: [Digits; 2],
    q: [Digits; 2],
    v: [Digits; 2],
    conjugate: bool,
    s: &mut Stats,
) -> [[i128; 10]; 2] {
    let before = (s.input_ifma, s.input_alu);
    let mut lo = [[0i128; 5]; 2];
    let mut hi = [[0i128; 5]; 2];
    for j in 0..5 {
        let (pl, ph) = s.split(p[0][j], p[1][j], true);
        let (ql, qh) = s.split(q[0][j], q[1][j], true);
        let (vl, vh) = s.split(v[0][j], v[1][j], true);
        lo[0][j] = s.check(pl - ql, 0);
        hi[0][j] = s.check(ph - qh, 0);
        lo[1][j] = s.check(if conjugate { pl - vl } else { pl + vl }, 0);
        hi[1][j] = s.check(if conjugate { ph - vh } else { ph + vh }, 0);
        s.input_alu += 4;
    }
    let mut t = [
        diagonal_convolution(lo[0], hi[0], s),
        diagonal_convolution(lo[1], hi[1], s),
    ];
    for j in 0..5 {
        for k in j + 1..5 {
            let (l, h) = pair(p[0], p[1], j, k, false, s);
            for target in &mut t {
                s.update(target, j + k, l, 0, true);
                s.update(target, j + k + 1, h, 0, true);
            }
            let (l, h) = pair(q[0], q[1], j, k, true, s);
            s.update(&mut t[0], j + k, l, 0, false);
            s.update(&mut t[0], j + k + 1, h, 0, false);
            let (l, h) = pair(v[0], v[1], j, k, conjugate, s);
            s.update(&mut t[1], j + k, l, 0, false);
            s.update(&mut t[1], j + k + 1, h, 0, false);
        }
    }
    let pp = number(p[0]) * number(p[1]);
    let qq = number(q[0]) * number(q[1]);
    let vv = number(v[0]) * number(v[1]);
    assert_eq!(poly(&t[0]), bi(&pp) - bi(&qq));
    assert_eq!(
        poly(&t[1]),
        if conjugate {
            bi(&pp) - bi(&vv)
        } else {
            bi(&pp) + bi(&vv)
        }
    );
    assert_eq!((s.input_ifma - before.0, s.input_alu - before.1), (90, 296));
    s.joint += 1;
    t
}
fn inverse(a: &BigInt, modulus: &BigInt) -> BigInt {
    let (mut old, mut rem) = (modulus.clone(), a.clone());
    let (mut x, mut y) = (BigInt::from(0), BigInt::from(1));
    while rem != BigInt::from(0) {
        let q = &old / &rem;
        (old, rem) = (rem.clone(), old - &q * &rem);
        (x, y) = (y.clone(), x - q * &y);
    }
    assert_eq!(old, BigInt::from(1));
    ((x % modulus) + modulus) % modulus
}
struct Field {
    p: BigUint,
    two: BigUint,
    pd: Digits,
    r: BigUint,
    negative_inverse: BigInt,
    radix_inverse: BigUint,
    inv64: u64,
    bits: usize,
}
impl Field {
    fn new(p: BigUint, bits: usize) -> Self {
        let r = u(1) << bits;
        assert!(&p * u(4) < r);
        assert!(&p * u(3) < (u(1) << 256usize));
        let pd = digits(&p);
        let mut inv = 1u64;
        for _ in 0..6 {
            inv = inv.wrapping_mul(2u64.wrapping_sub(pd[0].wrapping_mul(inv)));
        }
        let inv64 = inv.wrapping_neg();
        assert_eq!(pd[0].wrapping_mul(inv64), u64::MAX);
        let negative_inverse = (bi(&r) - inverse(&bi(&p), &bi(&r))) % bi(&r);
        let radix_inverse = (&r % &p).modpow(&(&p - u(2)), &p);
        assert_eq!((&r * &radix_inverse) % &p, u(1));
        Self {
            two: &p * u(2),
            p,
            pd,
            r,
            negative_inverse,
            radix_inverse,
            inv64,
            bits,
        }
    }
    fn sum(&self, a: &BigUint, b: &BigUint) -> BigUint {
        let x = a + b;
        if x >= self.two {
            x - &self.two
        } else {
            x
        }
    }
    fn difference(&self, a: &BigUint, b: &BigUint) -> BigUint {
        if a >= b {
            a - b
        } else {
            &self.two + a - b
        }
    }
    fn normalize(&self, mut out: [i128; 5], s: &mut Stats) -> [i128; 5] {
        for j in 0..4 {
            let carry = out[j] >> 52;
            out[j] &= MASK as i128;
            out[j + 1] = s.check(out[j + 1] + carry, 3);
        }
        out
    }
    fn reduce(&self, mut t: [i128; 10], signed: bool, s: &mut Stats) -> BigUint {
        let full = poly(&t);
        let before_count = s.reduction_ifma;
        for row in 0..5 {
            let bits = if self.bits == 256 && row == 4 {
                48usize
            } else {
                52usize
            };
            let radix = BigInt::from(1) << bits;
            let before = poly(&t[row..]);
            let q = (t[row] as u64).wrapping_mul(self.inv64) & ((1u64 << bits) - 1);
            s.reduction_ifma += 1;
            let exact = &before + bi(&(u(q) * &self.p));
            assert_eq!(&exact % &radix, BigInt::from(0), "signed row divisibility");
            let numerator = s.check(t[row] + ((1i128 << bits) - 1), 1);
            let ceil = numerator >> bits;
            let shifted = q << (52 - bits);
            let hi = (shifted as u128 * self.pd[0] as u128) >> 52;
            s.reduction_ifma += 1;
            let carry = s.check(ceil + hi as i128, 1);
            for j in 1..5 {
                let (l, h) = s.split(q, self.pd[j], false);
                s.update(&mut t, row + j, l, 1, false);
                s.update(&mut t, row + j + 1, h, 1, false);
            }
            t[row] = 0;
            if bits == 48 {
                for x in &mut t[row + 1..] {
                    *x = s.check(*x * 16, 2);
                }
                s.update(&mut t, row + 1, carry, 2, false);
            } else {
                s.update(&mut t, row + 1, carry, 1, false);
            }
            assert_eq!(
                poly(&t[row + 1..]),
                exact / radix,
                "exact signed row quotient"
            );
            s.rows += 1;
        }
        assert_eq!(s.reduction_ifma - before_count, 50);
        let ri = bi(&self.r);
        let q = ((&full * &self.negative_inverse) % &ri + &ri) % &ri;
        let numerator = &full + q * bi(&self.p);
        assert_eq!(&numerator % &ri, BigInt::from(0));
        let raw = numerator / ri;
        assert_eq!(
            poly(&t[5..]),
            raw,
            "independent full signed Montgomery quotient"
        );
        if signed {
            assert!(
                raw > -bi(&self.p) && raw < bi(&self.two),
                "signed REDC range"
            );
        } else {
            assert!(
                raw.sign() != Sign::Minus && raw < bi(&(&self.p * u(3))),
                "unsigned REDC range"
            );
        }
        let out: [i128; 5] = t[5..].try_into().unwrap();
        let mut out = self.normalize(out, s);
        assert_eq!(poly(&out), raw);
        assert_eq!(
            out[4] < 0,
            raw.sign() == Sign::Minus,
            "signed top detection"
        );
        let pd = digits(&self.two);
        if signed {
            let negative = out[4] < 0;
            s.negative_raw += negative as u64;
            for j in 0..5 {
                out[j] = s.check(out[j] + if negative { pd[j] as i128 } else { 0 }, 3);
            }
            out = self.normalize(out, s);
        } else if raw >= bi(&self.two) {
            for j in 0..5 {
                out[j] = s.check(out[j] - pd[j] as i128, 3);
            }
            out = self.normalize(out, s);
            s.subtract_two_p += 1;
        }
        for x in out {
            assert!((0..B).contains(&x), "normalized corrected digit");
        }
        let lazy = poly(&out).to_biguint().unwrap();
        assert!(lazy < self.two);
        assert_eq!(
            &lazy % &self.p,
            (((&full % bi(&self.p)) + bi(&self.p)) % bi(&self.p))
                .to_biguint()
                .unwrap()
                * &self.radix_inverse
                % &self.p
        );
        let bytes = lazy.to_bytes_le();
        s.digest.update((bytes.len() as u64).to_le_bytes());
        s.digest.update(bytes);
        s.outputs += 1;
        lazy
    }
    fn test(&self, input: &[BigUint; 4], s: &mut Stats) -> [BigUint; 2] {
        let [a0, a1, b0, b1] = input;
        for a in input {
            assert!(a <= &self.two);
            s.endpoints += (a == &self.two) as u64;
        }
        let mut normal = [u(0), u(0)];
        for conjugate in [false, true] {
            let sums = self.sum(a0, a1);
            let (t, d) = if conjugate {
                (self.difference(b0, b1), self.sum(b0, b1))
            } else {
                (self.sum(b0, b1), self.difference(b1, b0))
            };
            s.linear_ops += 3;
            for x in [&sums, &t, &d] {
                assert!(x <= &self.two);
            }
            let before = (s.input_ifma, s.reduction_ifma, s.input_alu);
            let coeff = joint(
                [digits(&sums), digits(b0)],
                [digits(a1), digits(&t)],
                [digits(a0), digits(&d)],
                conjugate,
                s,
            );
            let real = self.reduce(coeff[0], true, s);
            let imag = self.reduce(coeff[1], conjugate, s);
            assert_eq!(
                (
                    s.input_ifma - before.0,
                    s.reduction_ifma - before.1,
                    s.input_alu - before.2
                ),
                (90, 100, 296)
            );
            let expected = [
                if conjugate {
                    bi(&(a0 * b0)) + bi(&(a1 * b1))
                } else {
                    bi(&(a0 * b0)) - bi(&(a1 * b1))
                },
                if conjugate {
                    bi(&(a1 * b0)) - bi(&(a0 * b1))
                } else {
                    bi(&(a0 * b1)) + bi(&(a1 * b0))
                },
            ];
            for (got, want) in [&real, &imag].into_iter().zip(expected) {
                let p = bi(&self.p);
                let canonical = ((want % &p) + &p) % &p;
                assert_eq!(
                    got % &self.p,
                    canonical.to_biguint().unwrap() * &self.radix_inverse % &self.p,
                    "direct complex semantic oracle"
                );
            }
            if !conjugate {
                normal = [real, imag];
            }
        }
        normal
    }
}
fn main() {
    let root = std::env::args().nth(1).unwrap();
    let root = Path::new(&root);
    let pins: Value = serde_json::from_slice(&fs::read(root.join("pins.json")).unwrap()).unwrap();
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let input_path = "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/inputs.json";
    let fixture: Value = serde_json::from_slice(&fs::read(input_path).unwrap()).unwrap();
    let mut full = Stats::default();
    let corners: Vec<Digits> = (0..32usize)
        .map(|mask| std::array::from_fn(|j| if mask & (1 << j) == 0 { 0 } else { MASK }))
        .collect();
    for j in 0..32 {
        for k in 0..32 {
            for conjugate in [false, true] {
                joint(
                    [corners[j], corners[k]],
                    [corners[(j + 3) % 32], corners[(k + 7) % 32]],
                    [corners[(j + 11) % 32], corners[(k + 13) % 32]],
                    conjugate,
                    &mut full,
                );
            }
        }
    }
    for row in fixture["full_random"].as_array().unwrap() {
        let [a, b, c, d]: [Digits; 4] = serde_json::from_value(row.clone()).unwrap();
        let x = std::array::from_fn(|j| a[j] ^ c[j]);
        let y = std::array::from_fn(|j| b[j] ^ d[j]);
        for conjugate in [false, true] {
            joint([a, b], [c, d], [x, y], conjugate, &mut full);
        }
    }
    assert_eq!(full.joint, 6144);
    assert_eq!(full.input_ifma, 6144 * 90);
    assert_eq!(full.input_alu, 6144 * 296);
    let mut results = Vec::new();
    let mut outputs = 0;
    for field in fixture["fields"].as_array().unwrap() {
        let p = BigUint::parse_bytes(field["p_decimal"].as_str().unwrap().as_bytes(), 10).unwrap();
        let two = &p * u(2);
        let boundary: Vec<_> = field["boundary"]
            .as_array()
            .unwrap()
            .iter()
            .map(|x| parse(x.as_str().unwrap()))
            .collect();
        assert_eq!(boundary.len(), 122);
        let mut tuples = Vec::new();
        for (j, a) in boundary.iter().enumerate() {
            for (k, b) in boundary.iter().enumerate() {
                tuples.push([
                    a.clone(),
                    b.clone(),
                    boundary[(j + 3) % 122].clone(),
                    boundary[(k + 7) % 122].clone(),
                ]);
            }
        }
        for row in field["random"].as_array().unwrap() {
            tuples.push(std::array::from_fn(|j| parse(row[j].as_str().unwrap())));
        }
        let edges = [u(0), u(1), &two - u(1), two.clone()];
        for a in &edges {
            for b in &edges {
                for c in &edges {
                    for d in &edges {
                        tuples.push([a.clone(), b.clone(), c.clone(), d.clone()]);
                    }
                }
            }
        }
        assert_eq!(tuples.len(), 19236);
        for bits in [256, 260] {
            let f = Field::new(p.clone(), bits);
            let mut s = Stats::default();
            for tuple in &tuples {
                f.test(tuple, &mut s);
            }
            let mut chain = [&p + u(1), &p - u(1)];
            for j in 0..1024 {
                let row = &field["random"][j];
                chain = f.test(
                    &[
                        chain[0].clone(),
                        chain[1].clone(),
                        parse(row[2].as_str().unwrap()),
                        parse(row[3].as_str().unwrap()),
                    ],
                    &mut s,
                );
            }
            assert_eq!(s.outputs, 81040);
            assert_eq!(s.rows, s.outputs * 5);
            assert_eq!(s.joint, 40520);
            assert_eq!(s.input_ifma, 40520 * 90);
            assert_eq!(s.reduction_ifma, 40520 * 100);
            assert_eq!(s.input_alu, 40520 * 296);
            assert!(
                s.negative_raw > 0,
                "negative representative branch was tested"
            );
            if bits == 260 {
                assert_eq!(s.subtract_two_p, 0, "uniform radix unsigned bound");
            }
            outputs += s.outputs;
            results.push(json!({"field":field["tag"],"radix":bits,"boundary_tuples":14884,"random_tuples":4096,"endpoint_tuples":256,"chain_tuples":1024,"normal_and_conjugate":true,"result":s.json()}));
        }
    }
    assert_eq!(outputs, 324160);
    let out = json!({"status":"pass","kind":"joint exact coefficient and SIGNED Montgomery reduction model, not native SIMD or proof timing","full52_joint_calls":full.joint,"full52_output_polynomials":full.joint*2,"full52_result":full.json(),"field_results":results,"total_field_outputs":outputs,"total_exact_rows":outputs*5,
  "proxy":{"input_ifma":90,"two_REDC_ifma":100,"total_ifma":190,"accepted_complex_ifma":300,"input_alu_mask":296,"excluded":"three field-linear operations, reduction/carry/correction ALU, masks/moves/loads, code size, register allocation and spills; no latency bound"},
  "fixture_sha256":hash(input_path),"decision":"select one fixed native feasibility implementation and independent SIMD/codegen qualification; no adoption/performance claim; ordinary field/FrFFT retained"});
    fs::write(
        root.join("result.json"),
        serde_json::to_vec_pretty(&out).unwrap(),
    )
    .unwrap();
    println!(
        "JOINT_PAIR52_COMPLEX {}",
        serde_json::to_string(&out).unwrap()
    );
}
