use num_bigint::BigUint;
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{fs,path::Path};
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/dot8-preredc-math176";
const MASK:u64=(1<<52)-1;
type Words=[u64;4];
fn big(a:&[u64])->BigUint{BigUint::from_bytes_le(&a.iter().flat_map(|w|w.to_le_bytes()).collect::<Vec<_>>())}
fn words(x:&BigUint)->Words{let v=x.to_u64_digits();assert!(v.len()<=4);let mut r=[0;4];r[..v.len()].copy_from_slice(&v);r}
fn radix52(a:Words)->[u64;5]{std::array::from_fn(|i|{let bit=i*52;let j=bit/64;let s=bit%64;((a[j]>>s)|if s!=0&&j+1<4{a[j+1]<<(64-s)}else{0})&MASK})}
fn full_sum(a:[Words;8],b:[Words;8])->([u64;8],u64,u64){
 let mut coefficients=[[0u64;8];10];
 for lane in 0..8{let x=radix52(a[lane]);let y=radix52(b[lane]);for i in 0..5{for j in 0..5{
  let product=x[i]as u128*y[j]as u128;
  coefficients[i+j][lane]=coefficients[i+j][lane].checked_add(product as u64&MASK).unwrap();
  coefficients[i+j+1][lane]=coefficients[i+j+1][lane].checked_add((product>>52)as u64).unwrap();
 }}}
 let mut digits=[0u64;10];let mut carry=0;let(mut raw_max,mut carried_max)=(0,0);
 for k in 0..10{let mut raw=0u64;for lane in 0..8{assert!(coefficients[k][lane]<9*(1<<52));raw=raw.checked_add(coefficients[k][lane]).unwrap();}
  assert!(raw<72*(1<<52));raw_max=raw_max.max(raw);let total=raw.checked_add(carry).unwrap();assert!(total<73*(1<<52));carried_max=carried_max.max(total);digits[k]=total&MASK;carry=total>>52;
 }
 assert_eq!(carry,0);assert!(digits[9]<(1<<43));let mut out=[0u64;8];
 for(k,digit)in digits.into_iter().enumerate(){let bit=k*52;let i=bit/64;let s=bit%64;out[i]|=digit<<s;if s!=0{let high=digit>>(64-s);if i+1<8{out[i+1]|=high}else{assert_eq!(high,0)}}}
 (out,raw_max,carried_max)
}
fn subtract(x:Words,p:Words)->(Words,bool){let mut out=[0;4];let mut borrow=false;for i in 0..4{let(v,b1)=x[i].overflowing_sub(p[i]);let(v,b2)=v.overflowing_sub(borrow as u64);out[i]=v;borrow=b1||b2;}(out,borrow)}
fn reduce(t:[u64;8],p:Words)->(Words,Words,Words,usize){
 let mut inv=1u64;for _ in 0..6{inv=inv.wrapping_mul(2u64.wrapping_sub(p[0].wrapping_mul(inv)));}assert_eq!(p[0].wrapping_mul(inv),1);let inv=inv.wrapping_neg();
 let mut w=[0u64;9];w[..8].copy_from_slice(&t);let mut quotient=[0;4];
 for i in 0..4{let q=w[i].wrapping_mul(inv);quotient[i]=q;let mut carry=0u128;
  for j in 0..4{let value=q as u128*p[j]as u128+w[i+j]as u128+carry;w[i+j]=value as u64;carry=value>>64;}
  let mut k=i+4;let mut next=carry as u64;while next!=0{assert!(k<9);let(value,overflow)=w[k].overflowing_add(next);w[k]=value;next=overflow as u64;k+=1;}assert_eq!(w[i],0);
 }
 assert_eq!(w[8],0);let unreduced:Words=w[4..8].try_into().unwrap();let mut result=unreduced;let mut corrections=0;
 for _ in 0..2{let(candidate,borrow)=subtract(result,p);if !borrow{result=candidate;corrections+=1;}}
 assert!(subtract(result,p).1);(result,quotient,unreduced,corrections)
}
struct Field{p:BigUint,pw:Words,r:BigUint,neg_inv:BigUint,r_inv:BigUint,cases:usize,corrections:[usize;3],examples:[Option<Value>;3],raw_max:u64,carry_max:u64}
impl Field{
 fn new(decimal:&str)->Self{let p=BigUint::parse_bytes(decimal.as_bytes(),10).unwrap();let r=BigUint::from(1u8)<<256;assert!(&p*4u8<r);let mut inverse=BigUint::from(1u8);for _ in 0..8{inverse=(&inverse*(&r+2u8-(&p*&inverse)%&r))%&r;}assert_eq!((&p*&inverse)%&r,BigUint::from(1u8));let neg_inv=&r-inverse;let r_inv=r.modpow(&(&p-2u8),&p);assert_eq!((&r*&r_inv)%&p,BigUint::from(1u8));Self{pw:words(&p),p,r,neg_inv,r_inv,cases:0,corrections:[0;3],examples:std::array::from_fn(|_|None),raw_max:0,carry_max:0}}
 fn check(&mut self,a:[Words;8],b:[Words;8])->Words{
  let mut expected_t=BigUint::from(0u8);for lane in 0..8{let x=big(&a[lane]);let y=big(&b[lane]);assert!(x<self.p&&y<self.p);expected_t+=x*y;}
  assert!(expected_t<&self.p*&self.p*8u8);assert!(expected_t<(&self.r*&self.r)/2u8);
  let(t,raw,carried)=full_sum(a,b);assert_eq!(big(&t),expected_t);
  let(result,q,u,n)=reduce(t,self.pw);let expected_q=(&expected_t*&self.neg_inv)%&self.r;
  assert_eq!(big(&q),expected_q);let numerator=&expected_t+&expected_q*&self.p;assert_eq!(&numerator%&self.r,BigUint::from(0u8));let expected_u=numerator/&self.r;assert!(expected_u<&self.p*3u8&&expected_u<self.r);assert_eq!(big(&u),expected_u);
  let expected_result=(&expected_t*&self.r_inv)%&self.p;assert_eq!(big(&result),expected_result);assert_eq!(big(&result),&expected_u%&self.p);
  self.cases+=1;self.corrections[n]+=1;self.raw_max=self.raw_max.max(raw);self.carry_max=self.carry_max.max(carried);
  if self.examples[n].is_none(){self.examples[n]=Some(json!({"a":a,"b":b,"T":expected_t.to_str_radix(16),"q":expected_q.to_str_radix(16),"u":expected_u.to_str_radix(16),"result":result}));}result
 }
}
fn rng(seed:&mut u64)->u64{*seed=seed.wrapping_add(0x9e3779b97f4a7c15);let mut z=*seed;z=(z^(z>>30)).wrapping_mul(0xbf58476d1ce4e5b9);z=(z^(z>>27)).wrapping_mul(0x94d049bb133111eb);z^(z>>31)}
fn random(seed:&mut u64,p:&BigUint)->Words{let x:Words=std::array::from_fn(|_|rng(seed));words(&(big(&x)%p))}
fn population(name:&str,decimal:&str)->Value{
 let mut f=Field::new(decimal);let zero=[0;4];let one=words(&BigUint::from(1u8));let max=words(&(&f.p-1u8));
 f.check([zero;8],[zero;8]);f.check([max;8],[max;8]);f.check([one;8],[max;8]);f.check(std::array::from_fn(|i|if i%2==0{max}else{zero}),[max;8]);
 for i in 0..8{let mut a=[zero;8];a[i]=max;f.check(a,[max;8]);}
 let mut boundary=vec![BigUint::from(0u8),BigUint::from(1u8),&f.p-1u8];
 for bit in [1usize,51,52,53,63,64,65,103,104,105,127,128,129,155,156,157,191,192,193,207,208,209,252,253]{let v=BigUint::from(1u8)<<bit;for x in [&v-1u8,v.clone(),&v+1u8]{if x<f.p{boundary.push(x.clone());boundary.push(&f.p-1u8-&x);}}}
 boundary.sort();boundary.dedup();let bn=boundary.len();
 for x in &boundary{for y in &boundary{f.check([words(x);8],[words(y);8]);}}
 let mut seed=0x59a395d46e2b8107;for _ in 0..8192{let a=std::array::from_fn(|_|random(&mut seed,&f.p));let b=std::array::from_fn(|_|random(&mut seed,&f.p));f.check(a,b);}
 let mut previous=max;for _ in 0..2048{let mut a=std::array::from_fn(|_|random(&mut seed,&f.p));let b=std::array::from_fn(|_|random(&mut seed,&f.p));a[0]=previous;previous=f.check(a,b);}
 assert!(f.corrections.iter().all(|&n|n>0));json!({"field":name,"prime":decimal,"cases":f.cases,"boundary_values":bn,"boundary_cross_product_cases":bn*bn,"random_vectors":8192,"dependent_vectors":2048,"correction_counts":f.corrections,"examples_by_corrections":f.examples,"max_raw_coefficient":f.raw_max,"max_normalized_input":f.carry_max,"all_bounds_and_independent_integer_references_pass":true})
}
fn main(){
 let source="/home/ubuntu/src/zk-tools/zopro/crates/zopro-bn254/src/lib.rs";let bytes=fs::read(source).unwrap();let source_text=std::str::from_utf8(&bytes).unwrap();let primes=[("Fr","21888242871839275222246405745257275088548364400416034343698204186575808495617"),("Fq","21888242871839275222246405745257275088696311157297823662689037894645226208583")];
 for(_,p)in primes{assert!(source_text.contains(p));}let results=primes.map(|(n,p)|population(n,p));let result=json!({"passed":true,"new_arithmetic_operator":false,"native_timing":false,"proofs":0,"fields":results,"canonical_input_contract":true,"source_prime_literals":{"path":source,"sha256":format!("{:x}",Sha256::digest(&bytes))},"limits":"Pure integer model, not a native operator, witness execution, benchmark or proof verification"});let out=Path::new(ROOT).join("model-result.json");assert!(!out.exists());fs::write(out,serde_json::to_vec_pretty(&result).unwrap()).unwrap();println!("PASS dot8 pre-REDC integer model: {} cases, correction counts {:?} / {:?}",results.iter().map(|r|r["cases"].as_u64().unwrap()).sum::<u64>(),results[0]["correction_counts"],results[1]["correction_counts"]);
}
