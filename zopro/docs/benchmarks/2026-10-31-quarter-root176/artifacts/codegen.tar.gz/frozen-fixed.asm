
/home/ubuntu/src/zopro-perf-work/quarter-root176/frozen-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000023dd0 <_RNvCs3zmp2RFaYZ5_6driver5fixed>:
   23dd0:	cmp    $0x1,%rsi
   23dd4:	ja     23dd7 <_RNvCs3zmp2RFaYZ5_6driver5fixed+0x7>
   23dd6:	ret
   23dd7:	push   %rbp
   23dd8:	mov    %rsp,%rbp
   23ddb:	push   %r15
   23ddd:	push   %r14
   23ddf:	push   %rbx
   23de0:	and    $0xffffffffffffffe0,%rsp
   23de4:	sub    $0x240,%rsp
   23deb:	vmovdqa64 (%rdi),%zmm2
   23df1:	vmovdqa64 0x40(%rdi),%zmm3
   23df8:	vmovdqa64 0x80(%rdi),%zmm4
   23dff:	vmovdqa64 0xc0(%rdi),%zmm5
   23e06:	vmovdqa64 0x140(%rdi),%zmm0
   23e0d:	vmovdqa64 -0x1ded7(%rip),%zmm1        # 5f40 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x460>
   23e17:	vmovdqa64 0x180(%rdi),%zmm7
   23e1e:	vmovdqa64 0x1c0(%rdi),%zmm9
   23e25:	vmovdqa64 0x200(%rdi),%zmm11
   23e2c:	vmovdqa64 0x100(%rdi),%zmm13
   23e33:	vmovdqa64 0x240(%rdi),%zmm14
   23e3a:	vmovdqa64 -0x1dec4(%rip),%zmm15        # 5f80 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x4a0>
   23e44:	movabs $0x60c89ce5c263,%rax
   23e4e:	lea    0xe0(%rsp),%rbx
   23e56:	lea    0x20(%rsp),%r14
   23e5b:	lea    0x180(%rsp),%r15
   23e63:	lea    0x40(%rsp),%rdi
   23e68:	lea    0x8(%rsp),%rsi
   23e6d:	mov    %rbx,0x8(%rsp)
   23e72:	mov    %r14,0x10(%rsp)
   23e77:	mov    %r15,0x18(%rsp)
   23e7c:	vmovdqa64 %zmm2,%zmm6
   23e82:	vmovdqa64 %zmm3,%zmm8
   23e88:	vmovdqa64 %zmm4,%zmm10
   23e8e:	vmovdqa64 %zmm5,%zmm12
   23e94:	vpermt2q %zmm0,%zmm1,%zmm6
   23e9a:	vpermt2q %zmm7,%zmm1,%zmm8
   23ea0:	vpermt2q %zmm9,%zmm1,%zmm10
   23ea6:	vpermt2q %zmm11,%zmm1,%zmm12
   23eac:	vpermi2q %zmm14,%zmm13,%zmm1
   23eb2:	vpermt2q %zmm14,%zmm15,%zmm13
   23eb8:	vpermt2q %zmm0,%zmm15,%zmm2
   23ebe:	vpermt2q %zmm7,%zmm15,%zmm3
   23ec4:	vpermt2q %zmm9,%zmm15,%zmm4
   23eca:	vpermt2q %zmm11,%zmm15,%zmm5
   23ed0:	vpsubq %zmm13,%zmm1,%zmm1
   23ed6:	vpbroadcastq -0x1e630(%rip),%zmm13        # 58b0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x30>
   23ee0:	vpsubq %zmm2,%zmm6,%zmm0
   23ee6:	vpsubq %zmm3,%zmm8,%zmm2
   23eec:	vpsubq %zmm4,%zmm10,%zmm3
   23ef2:	vpsubq %zmm5,%zmm12,%zmm4
   23ef8:	vmovaps -0x1e500(%rip),%ymm5        # 5a00 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x180>
   23f00:	vpbroadcastq -0x1e5f2(%rip),%zmm12        # 5918 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x98>
   23f0a:	vpandq %zmm13,%zmm0,%zmm7
   23f10:	vpsraq $0x34,%zmm0,%zmm0
   23f17:	vmovups %ymm5,0x40(%rsp)
   23f1d:	mov    %rax,0x60(%rsp)
   23f22:	vpaddq %zmm0,%zmm2,%zmm0
   23f28:	vpaddq 0x40(%rsp){1to8},%zmm7,%zmm8
   23f30:	vpbroadcastq 0x60(%rsp),%zmm5
   23f38:	vpandq %zmm13,%zmm0,%zmm2
   23f3e:	vpsraq $0x34,%zmm0,%zmm0
   23f45:	vpaddq 0x48(%rsp){1to8},%zmm2,%zmm9
   23f4d:	vpaddq %zmm0,%zmm3,%zmm0
   23f53:	vpandq %zmm13,%zmm0,%zmm3
   23f59:	vpsraq $0x34,%zmm0,%zmm0
   23f60:	vpaddq 0x50(%rsp){1to8},%zmm3,%zmm10
   23f68:	vpaddq %zmm0,%zmm4,%zmm0
   23f6e:	vpandq %zmm13,%zmm0,%zmm4
   23f74:	vpaddq 0x58(%rsp){1to8},%zmm4,%zmm11
   23f7c:	vpsraq $0x34,%zmm0,%zmm0
   23f83:	vpaddq %zmm0,%zmm1,%zmm0
   23f89:	vpcmpltuq %zmm12,%zmm0,%k1
   23f90:	vmovdqa64 %zmm7,%zmm8{%k1}
   23f96:	vmovdqa64 %zmm12,%zmm5{%k1}
   23f9c:	vpaddq %zmm0,%zmm5,%zmm0
   23fa2:	vmovdqa64 %zmm2,%zmm9{%k1}
   23fa8:	vpsrlq $0x34,%zmm8,%zmm2
   23faf:	vpaddq %zmm9,%zmm2,%zmm1
   23fb5:	vpandq %zmm13,%zmm8,%zmm2
   23fbb:	vmovdqa64 %zmm3,%zmm10{%k1}
   23fc1:	vpsrlq $0x34,%zmm1,%zmm3
   23fc8:	vpandq %zmm13,%zmm1,%zmm1
   23fce:	vpaddq %zmm10,%zmm3,%zmm3
   23fd4:	vinserti64x4 $0x1,%ymm1,%zmm2,%zmm6
   23fdb:	vshufi64x2 $0xee,%zmm1,%zmm2,%zmm1
   23fe2:	vmovdqa64 %zmm4,%zmm11{%k1}
   23fe8:	vpsrlq $0x34,%zmm3,%zmm4
   23fef:	vpandq %zmm13,%zmm3,%zmm3
   23ff5:	vmovdqu64 %zmm6,0xe0(%rsp)
   24000:	vpaddq %zmm11,%zmm4,%zmm4
   24006:	vmovdqu64 %zmm1,0x180(%rsp)
   2400e:	vpsrlq $0x34,%zmm4,%zmm5
   24015:	vpandq %zmm13,%zmm4,%zmm4
   2401b:	vshufi64x2 $0xee,%zmm4,%zmm3,%zmm1
   24022:	vpaddq %zmm0,%zmm5,%zmm0
   24028:	vinserti64x4 $0x1,%ymm4,%zmm3,%zmm5
   2402f:	vpandq %zmm13,%zmm0,%zmm0
   24035:	vmovdqu64 %zmm5,0x120(%rsp)
   24040:	vmovdqu64 %zmm1,0x1c0(%rsp)
   24048:	vmovaps -0x1e470(%rip),%ymm1        # 5be0 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x100>
   24050:	vmovdqa %ymm0,0x160(%rsp)
   24059:	vextracti64x4 $0x1,%zmm0,0x200(%rsp)
   24062:	vmovaps %ymm1,0x20(%rsp)
   24068:	vzeroupper
   2406b:	call   1a360 <_RINvNtCsgxBkk5gSRhY_4core5array11try_from_fnINtNtNtB4_3ops9try_trait17NeverShortCircuitNtNtNtB4_9core_arch3x867___m256iEKj5_NCINvMBJ_BG_10wrap_mut_1jNCINvMs_NtCsgHCcee0nhgM_11zopro_bn2544ifmaINtB2v_4IfmaNtB2x_8FrConfigE7shuffleKj0_Kj2_Kj4_Kj6_E0E0ECs3zmp2RFaYZ5_6driver>
   24070:	vmovaps -0x1e558(%rip),%ymm0        # 5b20 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x40>
   24078:	lea    0x40(%rsp),%rdi
   2407d:	lea    0x8(%rsp),%rsi
   24082:	mov    %rbx,0x8(%rsp)
   24087:	mov    %r14,0x10(%rsp)
   2408c:	mov    %r15,0x18(%rsp)
   24091:	vmovaps %ymm0,0x20(%rsp)
   24097:	vzeroupper
   2409a:	call   1a360 <_RINvNtCsgxBkk5gSRhY_4core5array11try_from_fnINtNtNtB4_3ops9try_trait17NeverShortCircuitNtNtNtB4_9core_arch3x867___m256iEKj5_NCINvMBJ_BG_10wrap_mut_1jNCINvMs_NtCsgHCcee0nhgM_11zopro_bn2544ifmaINtB2v_4IfmaNtB2x_8FrConfigE7shuffleKj0_Kj2_Kj4_Kj6_E0E0ECs3zmp2RFaYZ5_6driver>
   2409f:	lea    -0x1c12a(%rip),%rdi        # 7f7c <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x249c>
   240a6:	lea    0x4881b(%rip),%rdx        # 6c8c8 <__frame_dummy_init_array_entry+0x8>
   240ad:	mov    $0x47,%esi
   240b2:	call   2c7d0 <_RNvNtCsgxBkk5gSRhY_4core9panicking9panic_fmt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
