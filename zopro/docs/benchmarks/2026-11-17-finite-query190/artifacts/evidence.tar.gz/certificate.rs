#[cfg(test)] pub(crate)struct FiniteG2<'a>(&'a[zopro_bn254::G2Affine]);
#[cfg(test)]impl<'a>FiniteG2<'a>{pub(crate)fn new(points:&'a[zopro_bn254::G2Affine])->Option<Self>{points.iter().all(|p|!p.is_identity()).then_some(Self(points))}
pub(crate)fn query(&self,words:&mut[[u64;4]])->zopro_bn254::G2Projective{g2_query_exclusive_finite(self.0,words)}}
