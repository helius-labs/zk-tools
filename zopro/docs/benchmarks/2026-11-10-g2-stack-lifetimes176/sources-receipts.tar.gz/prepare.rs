use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-stack-lifetimes176";const F:&str="/home/ubuntu/src/zopro-perf-work/g2-factor-lookahead176";
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn main(){let ids=read(&format!("{F}/identities.json"));let mut pins=serde_json::Map::new();
 let mut paths=vec![format!("{R}/design.md"),format!("{R}/prepare.rs"),format!("{F}/identities.json"),format!("{F}/diagnostic-summary.json"),format!("{F}/review.json"),"/usr/bin/objdump".into()];
 for arm in["OFF","ON"]{paths.push(ids[arm]["binary"].as_str().unwrap().into());for ctx in["1x2-B-w16","1x2-B-w32","2x2-B-w32"]{let n=format!("cycles-{ctx}-{arm}");paths.push(format!("{F}/perf/{n}.data"));for prefix in["decode","metadata","events","loss"]{for file in["stdout.log","stderr.log","command.json","exit.json"]{let p=format!("{F}/runs/{prefix}-{n}/{file}");assert!(Path::new(&p).is_file(),"{p}");paths.push(p);}}}}
 let manifest=read("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json");
 // The manifest's exact schema is retained, with actual field/core source bytes
 // pinned separately below rather than guessing path prefixes.
 paths.push("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json".into());
 let _=manifest;
 for p in paths{let b=fs::read(&p).unwrap();pins.insert(p,json!(format!("{:x}",Sha256::digest(b))));}
 for arm in["OFF","ON"]{let p=ids[arm]["binary"].as_str().unwrap();assert_eq!(pins[p],ids[arm]["binary_sha256"]);}
 let pins_path=format!("{R}/decode-pins.json");fs::write(&pins_path,serde_json::to_vec_pretty(&pins).unwrap()).unwrap();let mut steps=vec![];
 for arm in["OFF","ON"]{let sym=if arm=="OFF"{"_RINvNtNtCsfxSuWeoZc8X_10zopro_core3msm11g2_borrowed5applyNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigKb1_EB6_"}else{"_RINvNtNtNtCs9hk19kp169J_10zopro_core3msm11g2_borrowed16factor_lookahead5applyNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigKb1_EB8_"};
 steps.push(json!({"name":format!("disassemble-{arm}"),"kind":"command","timeout_seconds":900,"argv":["/usr/bin/objdump","-d","-l","--no-show-raw-insn","-M","intel",format!("--disassemble={sym}"),ids[arm]["binary"]]}));}
 fs::write(format!("{R}/decode-plan.json"),serde_json::to_vec_pretty(&json!({"version":1,"source_pins":pins_path,"steps":steps})).unwrap()).unwrap();println!("{} decode pins",pins.len());
}
