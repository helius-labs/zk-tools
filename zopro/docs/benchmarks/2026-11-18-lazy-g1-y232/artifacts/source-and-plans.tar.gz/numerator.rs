/// Canonical incoming Y, typed bucket Y<2p, prefix<2p. Transient D<=3p is
/// consumed privately by full-R260 REDC; p+6p²/2^260<2p. Ordinary API bounds
/// remain unchanged. All operands retain normalized52-bit digits and3p<2^256.
#[inline(always)]
pub fn lazy_g1_scaled_numerator(by:&[crate::Fq;8],ay:&LazyY8,scale:&Ifma8<crate::FqConfig,true>,negative:u8)->Ifma8<crate::FqConfig,true>{
 unsafe{
  type B=Ifma8<crate::FqConfig,true>;
  let by=B::new(by);let p=crate::FqConfig::P;let two=crate::portable::add4(p,p).0;let three=crate::portable::add4(two,p).0;
  let two=split(two);let three=split(three);let flip=_mm512_maskz_mov_epi64(negative,B::splat(MASK));
  let mut carry=_mm512_maskz_mov_epi64(negative,B::splat(1));let mut t=[B::splat(0);5];
  for j in 0..5{let offset=_mm512_mask_blend_epi64(negative,B::splat(two[j]),B::splat(three[j]));let signed=_mm512_xor_si512(by.0[j],flip);
   let v=_mm512_add_epi64(_mm512_sub_epi64(_mm512_add_epi64(offset,signed),ay.0.0[j]),carry);t[j]=_mm512_and_si512(v,B::splat(MASK));carry=_mm512_srai_epi64::<52>(v);
  }
  // Same full-R260 row arithmetic as prefix_mul, with the wider input
  // contract proved locally above; result re-enters the ordinary<2p API.
  let a=Ifma8::<crate::FqConfig,false>(t,PhantomData);let b=Ifma8::<crate::FqConfig,false>(scale.0,PhantomData);let out=a.mul(&b);Ifma8(out.0,PhantomData)
 }
}
#[cfg(test)]
#[path="lazy_g1_tests.rs"]
mod lazy_g1_tests;
