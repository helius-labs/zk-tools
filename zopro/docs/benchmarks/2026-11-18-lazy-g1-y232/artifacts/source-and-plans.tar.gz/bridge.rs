#[cfg(all(zopro_g1_lazy_y,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
impl FqBatch {
 #[inline(always)]pub(crate)fn from_lazy_g1_y(v:&[zopro_bn254::ifma8::LazyFq;8])->Self{Self(zopro_bn254::ifma8::LazyY8::new(v).batch())}
 #[inline(always)]pub(crate)fn into_lazy_g1_y(self)->[zopro_bn254::ifma8::LazyFq;8]{zopro_bn254::ifma8::LazyY8::from_batch(self.0).get()}
 #[inline(always)]pub(crate)fn lazy_g1_dy(by:&[Fq;8],ay:&Self,scale:&Self,negative:u8)->Self{Self(zopro_bn254::ifma8::lazy_g1_scaled_numerator(by,&zopro_bn254::ifma8::LazyY8::from_batch(ay.0),&scale.0,negative))}
}
