use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::Read,
    path::{Path, PathBuf},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/lazy-g1-y232";
const SEED: &str =
    "/home/ubuntu/src/zopro-perf-work/unscaled-mixed230/proof-sha256-after-main.json";
const VERIFY: &str = "/home/ubuntu/src/zopro-perf-work/batch-local-steal/gnark/verify";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn save(p: impl AsRef<Path>, v: &Value) {
    assert!(
        !p.as_ref().exists(),
        "already exists: {}",
        p.as_ref().display()
    );
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn hash(p: impl AsRef<Path>) -> String {
    let mut f = fs::File::open(p).unwrap();
    let mut h = Sha256::new();
    let mut b = [0; 65536];
    loop {
        let n = f.read(&mut b).unwrap();
        if n == 0 {
            break;
        }
        h.update(&b[..n]);
    }
    format!("{:x}", h.finalize())
}
fn command(name: &str, argv: Vec<String>, environment: Value) -> Value {
    json!({"kind":"command","name":name,"argv":argv,"environment":environment,"timeout_seconds":1800})
}
fn receipt(folder: &str, s: &Value) {
    let base = r(format!("{folder}/{}", s["name"].as_str().unwrap()));
    let exit = read(base.join("exit.json"));
    assert_eq!(exit["success"], true);
    assert_eq!(exit["returncode"], 0);
    for stream in ["stdout", "stderr"] {
        assert_eq!(
            hash(base.join(format!("{stream}.log"))),
            exit[format!("{stream}_sha256")]
        );
    }
    let c = read(base.join("command.json"));
    assert_eq!(
        &c["argv"].as_array().unwrap()[4..],
        s["argv"].as_array().unwrap()
    );
    for (k, v) in s["environment"].as_object().into_iter().flatten() {
        // xtask records the benchmark environment allowlist. Compiler selection
        // is retained in the build plan, fingerprints and explicit link receipt.
        if !["PATH", "RUSTC", "RUSTUP_TOOLCHAIN"].contains(&k.as_str()) {
            assert_eq!(c["environment"][k], *v);
        }
    }
}
fn verify(j: &Value) -> Value {
    let c = &j["case"];
    let dir = j["proof_dir"].as_str().unwrap();
    command(
        &format!("verify-{}", j["name"].as_str().unwrap()),
        vec![
            VERIFY.into(),
            c["image"].as_str().unwrap().into(),
            c["image_sha256"].as_str().unwrap().into(),
            format!("{dir}/0.proof"),
            format!("{dir}/0.public"),
            c["public_sha256"].as_str().unwrap().into(),
        ],
        json!({}),
    )
}
fn prepare(){use std::os::unix::fs::{MetadataExt,PermissionsExt};assert_eq!(hash(SEED),"ab290bf3ef3d535745621f21aa914423ff5d578abfb30f44ed80f2f6998104f8");let mut pins=BTreeMap::<String,String>::new();for(p,h)in read(r("build-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pins.insert(p.clone(),h.as_str().unwrap().into());}let mut ids=json!({});fs::create_dir(r("bins")).unwrap();for arm in["REF","OFF","ON"]{let sdk=match arm{"REF"=>PathBuf::from("/home/ubuntu/src/zopro-perf-work/scaled-prefix-current227/build-run-v2/candidate-sdk"),"OFF"=>PathBuf::from("/home/ubuntu/src/zopro-perf-work/lazy-g1-y232/native-OFF/candidate-sdk"),_=>r("native-ON/candidate-sdk")};let expected=match arm{"REF"=>"b70a9472fa64ac6b6b41b227ca64ddfcf61c6443879c9187331eae6d5e22c153","OFF"=>"",_=>""};if !expected.is_empty(){assert_eq!(hash(&sdk),expected);}let mut copies=vec![];for i in 0..3{let p=r(format!("bins/{arm}{i}"));fs::copy(&sdk,&p).unwrap();let m=fs::metadata(&p).unwrap();let h=hash(&p);pins.insert(p.display().to_string(),h.clone());copies.push(json!({"path":p,"sha256":h,"device":m.dev(),"inode":m.ino(),"mode":m.permissions().mode()}));}ids[arm]=json!({"sha256":hash(&sdk),"copies":copies});}check_copies(&ids);save(r("runtime-consumers.json"),&ids);
let all=read("/home/ubuntu/src/zopro-perf-work/large-class-sdk176/measure-cases.json");let cases=["1x2-w16","1x2-w32","2x2-w32","merge-54x1-w32"].iter().map(|n|all.as_array().unwrap().iter().find(|c|c["name"]==*n).unwrap().clone()).collect::<Vec<_>>();for c in&cases{for k in["image","request"]{let p=c[k].as_str().unwrap();let h=hash(p);if k=="image"{assert_eq!(h,c["image_sha256"]);}pins.insert(p.into(),h);}}let base=read("/home/ubuntu/src/zopro-perf-work/store-frame-clean222/main-jobs.json")[0]["environment"].clone();
for phase in["preflight","main"]{let(mut jobs,mut steps)=(vec![],vec![]);for b in 0..if phase=="preflight"{1}else{3}{let mut order=if phase=="preflight"{vec![0]}else{vec![0,1,2,3]};let len=order.len();order.rotate_left(b%len);if b%2==1{order.reverse();}for(ci,i)in order.into_iter().enumerate(){let mut c=cases[i].clone();if phase=="preflight"{c["name"]=json!("1x2-w4");c["workers"]=json!(4);c["cpu_affinity"]=json!("0-3");}let mut arms=["REF","OFF","ON"];arms.rotate_left((b+ci)%3);if b%2==1{arms.reverse();}for arm in arms{let rounds=if phase=="preflight"{1}else if i<2{251}else if i==2{51}else{7};let name=format!("{phase}-{}-{arm}-{b}",c["name"].as_str().unwrap());let mut env=base.clone();env["RAYON_NUM_THREADS"]=json!(c["workers"].as_u64().unwrap().to_string());let pd=r(format!("proofs/{name}"));let binary=&ids[arm]["copies"][b]["path"];steps.push(command(&name,vec!["/usr/bin/taskset".into(),"-c".into(),c["cpu_affinity"].as_str().unwrap().into(),binary.as_str().unwrap().into(),c["image"].as_str().unwrap().into(),c["request"].as_str().unwrap().into(),rounds.to_string(),pd.display().to_string()],env.clone()));jobs.push(json!({"name":name,"case":c,"arm":arm,"block":b,"rounds":rounds,"proof_dir":pd,"environment":env,"binary":binary}));}}}assert_eq!(jobs.len(),if phase=="preflight"{3}else{36});steps.extend(jobs.iter().map(verify));save(r(format!("{phase}-jobs.json")),&json!(jobs));save(r(format!("{phase}-plan.json")),&json!({"version":1,"source_pins":r("runtime-pins.json"),"steps":steps}));}
for p in[PathBuf::from(SEED),PathBuf::from(VERIFY),PathBuf::from("/usr/bin/taskset")]{pins.insert(p.display().to_string(),hash(p));}for f in["protocol.md","setup.rs","finalize.rs","preparation-repair.md","adapt.rs","source-audit.json","screen.rs","screen","independent.rs","independent","runtime-consumers.json","preflight-jobs.json","main-jobs.json","preflight-plan.json","main-plan.json","native-OFF-plan.json","native-ON-plan.json","generic-plan.json","native-OFF/result.json","native-ON/result.json","generic/result.json","build-review.json"]{pins.insert(r(f).display().to_string(),hash(r(f)));}save(r("runtime-pins.json"),&json!(pins));println!("Frozen39exports/5160SDKcalls/5043timedrecords;new compact lazy G1 Y");}
fn review(phase: &str) {
    assert!(["preflight", "main"].contains(&phase));
    check_copies(&read(r("runtime-consumers.json")));
    let folder = format!("{phase}-run");
    assert_eq!(
        read(r(format!("{folder}/result.json")))["status"],
        "complete"
    );
    for (p, h) in read(r("runtime-pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    for step in read(r(format!("{phase}-plan.json")))["steps"]
        .as_array()
        .unwrap()
    {
        receipt(&folder, step);
    }
    let mut ledger: BTreeSet<String> = serde_json::from_value(read(if phase == "preflight" {
        PathBuf::from(SEED)
    } else {
        r("proof-sha256-after-preflight.json")
    }))
    .unwrap();
    assert_eq!(
        ledger.len(),
        if phase == "preflight" { 61143 } else { 61146 }
    );
    let mut rows = vec![];
    let mut samples_count = 0u64;
    for j in read(r(format!("{phase}-jobs.json"))).as_array().unwrap() {
        let name = j["name"].as_str().unwrap();
        let out = fs::read_to_string(r(format!("{folder}/{name}/stdout.log"))).unwrap();
        let samples: Vec<f64> = out
            .lines()
            .filter_map(|l| l.strip_prefix("SAMPLE "))
            .enumerate()
            .map(|(i, s)| {
                let v: Value = serde_json::from_str(s).unwrap();
                assert_eq!(v["round"], i);
                let x = v["ms"].as_f64().unwrap();
                assert!(x > 0. && x.is_finite());
                x
            })
            .collect();
        let rounds = j["rounds"].as_u64().unwrap();
        assert_eq!(samples.len() as u64, rounds);
        samples_count += rounds;
        let sums: Vec<_> = out
            .lines()
            .filter_map(|l| l.strip_prefix("SUMMARY "))
            .collect();
        assert_eq!(sums.len(), 1);
        let sum: Value = serde_json::from_str(sums[0]).unwrap();
        assert_eq!(sum["rounds"], rounds);
        assert_eq!(sum["priming"], 3);
        assert_eq!(sum["workers"], j["case"]["workers"]);
        {
            let entries=sum["indexed_entries"].as_u64().unwrap();
            let charge=sum["indexed_max_charge"].as_u64().unwrap();
            if j["case"]["denied"]==true {assert_eq!(entries,0);assert_eq!(charge,0);}
            else if ["1x2","2x2"].iter().any(|shape|j["case"]["shape"]==*shape) {assert_eq!(entries,4*rounds);assert!(charge>0);}
            else {assert_eq!(entries%rounds,0);if entries>0 {assert!(charge>0);}}
        }
        {let eligible=["1x2","2x2"].iter().any(|s|j["case"]["shape"]==*s);let scans=if eligible{1}else{0};assert_eq!(sum["generated_fast_parses"],if eligible{rounds}else{0});assert_eq!(sum["generated_total_key_scans"],scans);assert_eq!(sum["generated_total_fixed_scans"],scans);assert_eq!(sum["generated_timed_key_scans"],0);assert_eq!(sum["generated_timed_fixed_scans"],0);if eligible{assert!(sum["generated_certification_ns"].as_u64().unwrap()>0);}else{assert_eq!(sum["generated_certification_ns"],0);}}
        assert_eq!(sum["placement_before"], sum["placement_after"]);
        let p = &sum["placement_before"];
        assert_eq!(p["mode"], "fixed");
        let workers = sum["workers"].as_u64().unwrap();
        assert_eq!(p["tasks"], workers + 1);
        assert_eq!(p["main_allowed"], json!((0..workers).collect::<Vec<_>>()));
        let worker_rows = p["worker_rows"].as_array().unwrap();
        assert_eq!(worker_rows.len() as u64, workers);
        let mut tids = BTreeSet::new();
        for (i, w) in worker_rows.iter().enumerate() {
            assert_eq!(w["index"], i);
            assert_eq!(w["allowed"], json!([i]));
            assert!(tids.insert(w["tid"].as_u64().unwrap()));
        }
        let dir = Path::new(j["proof_dir"].as_str().unwrap());
        assert_eq!(fs::metadata(dir.join("0.proof")).unwrap().len(), 164);
        let ph = hash(dir.join("0.proof"));
        let pu = hash(dir.join("0.public"));
        assert_eq!(pu, j["case"]["public_sha256"]);
        let verifier = fs::read_to_string(r(format!("{folder}/verify-{name}/stdout.log"))).unwrap();
        for needle in [
            format!("proof_sha256={ph}"),
            format!("public_sha256={pu}"),
            format!(
                "image_sha256={}",
                j["case"]["image_sha256"].as_str().unwrap()
            ),
        ] {
            assert!(verifier.contains(&needle));
        }
        assert!(ledger.insert(ph.clone()));
        let mean = samples.iter().sum::<f64>() / rounds as f64;
        let cpu = (sum["user_cpu_ms"].as_f64().unwrap() + sum["system_cpu_ms"].as_f64().unwrap())
            / rounds as f64;
        rows.push(json!({"name":name,"context":j["case"]["name"],"arm":j["arm"],"block":j["block"],"ms":mean,"cpu_ms":cpu,"summary":sum,"proof_sha256":ph}));
    }
    assert_eq!(
        ledger.len(),
        if phase == "preflight" { 61146 } else { 61182 }
    );
    assert_eq!(samples_count, if phase == "preflight" { 3 } else { 5040 });
    save(
        r(format!("proof-sha256-after-{phase}.json")),
        &json!(ledger),
    );
    save(r(format!("{phase}-rows.json")), &json!(rows));
    if phase == "main" {
        assess(&rows);
    }
    save(
        r(format!("{phase}-review.json")),
        &json!({"verified":true,"new_exports":rows.len(),"canonical_count":ledger.len(),"samples_checked":samples_count}),
    );
    println!(
        "Verified {phase}: {} exports; ledger{}; {samples_count} samples",
        rows.len(),
        ledger.len()
    );
}
fn bounds(mut v:Vec<f64>)->Value{assert_eq!(v.len(),3);v.sort_by(f64::total_cmp);json!({"minimum":v[0],"median":v[1],"maximum":v[2]})}
fn assess(rows:&[Value]){let mut comparisons=vec![];let mut timings=vec![];let mut primary=vec![];let mut guards=true;for ctx in["1x2-w16","1x2-w32","2x2-w32","merge-54x1-w32"]{let arm=|a:&str|{let mut v=rows.iter().filter(|r|r["context"]==ctx&&r["arm"]==a).collect::<Vec<_>>();v.sort_by_key(|r|r["block"].as_u64().unwrap());assert_eq!(v.len(),3);v};let on=arm("ON");let mut useful=true;for a in["REF","OFF","ON"]{let v=arm(a);timings.push(json!({"context":ctx,"arm":a,"ms":bounds(v.iter().map(|r|r["ms"].as_f64().unwrap()).collect()),"cpu_ms":bounds(v.iter().map(|r|r["cpu_ms"].as_f64().unwrap()).collect()),"peak_RSS_MiB":v.iter().map(|r|r["summary"]["whole_process_maxrss_kib"].as_f64().unwrap()/1024.).fold(0.,f64::max)}));}for control in["REF","OFF"]{let other=arm(control);let ratios=on.iter().zip(&other).map(|(a,b)|a["ms"].as_f64().unwrap()/b["ms"].as_f64().unwrap()).collect::<Vec<_>>();let ratio=bounds(ratios.clone())["median"].as_f64().unwrap();let wins=ratios.iter().filter(|&&r|r<1.).count();useful&=ratio<1.&&wins>=2;let cpu=bounds(on.iter().zip(&other).map(|(a,b)|a["cpu_ms"].as_f64().unwrap()/b["cpu_ms"].as_f64().unwrap()).collect())["median"].as_f64().unwrap();let peak=|v:&Vec<&Value>|v.iter().map(|r|r["summary"]["whole_process_maxrss_kib"].as_f64().unwrap()/1024.).fold(0.,f64::max);let(x,y)=(peak(&on),peak(&other));let rss=x<=y*1.1+8.;guards&=rss;comparisons.push(json!({"context":ctx,"control":control,"paired_ratios":ratios,"median_ratio":ratio,"wins":wins,"CPU_ratio":cpu,"RSS_ON":x,"RSS_control":y,"RSS_pass":rss}));}let off=arm("OFF");let rf=arm("REF");let cal=bounds(off.iter().zip(&rf).map(|(a,b)|a["ms"].as_f64().unwrap()/b["ms"].as_f64().unwrap()).collect())["median"].as_f64().unwrap();guards&=(1./1.03..=1.03).contains(&cal);if ctx.starts_with("1x2"){primary.push(json!({"context":ctx,"useful_signal_against_both":useful}));}comparisons.push(json!({"context":ctx,"control":"calibration","OFF_REF":cal,"calibration_pass":(1./1.03..=1.03).contains(&cal)}));}let useful=guards&&primary.iter().any(|p|p["useful_signal_against_both"]==true);save(r("assessment.json"),&json!({"exploratory_only":true,"adopted":false,"useful_primary_signal":useful,"guards_pass":guards,"primary":primary,"comparisons":comparisons,"timings":timings,"full_goal_achieved":false}));println!("Integration primary_signal={useful};adoption=false");}
fn main() {
    match std::env::args().nth(1).as_deref() {
        Some("prepare") => {build_check();prepare();},
        Some("preflight-review") => review("preflight"),
        Some("main-review") => review("main"),
        Some("main-run") => {
            assert_eq!(read(r("preflight-review.json"))["verified"],true);
            assert_eq!(read(r("independent-smoke.json"))["passed"],true);
            assert_eq!(read(r("independent-plan.json"))["passed"],true);
            let status=std::process::Command::new("/home/ubuntu/src/zk-tools/zopro/xtask/target/release/xtask")
                .arg("workflow").arg(r("main-plan.json")).arg(r("main-run")).status().unwrap();
            assert!(status.success(),"main workflow failed");
        },
        _ => panic!("prepare/preflight-review/main-review"),
    }
}

fn build_check(){let mut receipts=vec![];for label in["OFF","ON","generic"]{let(folder,plan)=if label=="generic"{("generic".to_owned(),"generic-plan.json".to_owned())}else{(format!("native-{label}"),format!("native-{label}-plan.json"))};assert_eq!(read(r(format!("{folder}/result.json")))["status"],"complete");for step in read(r(plan))["steps"].as_array().unwrap(){let name=step["name"].as_str().unwrap();let path=r(format!("{folder}/{name}"));let e=read(path.join("exit.json"));assert_eq!(e["success"],true);for stream in["stdout","stderr"]{assert_eq!(hash(path.join(format!("{stream}.log"))),e[format!("{stream}_sha256")]);}let n=match(label,name){("ON","field-tests")=>41,("ON","core-tests")=>141,("generic","generic-field-tests")=>12,_=>0};if n>0{assert!(fs::read_to_string(path.join("stdout.log")).unwrap().contains(&format!("test result: ok. {n} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out")));}receipts.push(json!({"folder":folder,"name":name,"tests":n,"exit":e}));}if label!="generic"{let a=read(r(format!("{folder}/candidate/artifacts.json")));assert_eq!(a["libraries"].as_object().unwrap().len(),8);for(p,h)in a["input_pins"].as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}assert_eq!(hash(a["binary"].as_str().unwrap()),a["binary_sha256"]);assert_eq!(hash(r(format!("{folder}/libraries/stdout.log"))),a["cargo_artifacts_sha256"]);}}save(r("build-review.json"),&json!({"passed":true,"receipts":receipts,"ON_native_field":41,"ON_native_core":141,"generic_field":12,"two_coherent_SDK_links":true}));}

fn check_copies(ids: &Value) {
    use std::os::unix::fs::{MetadataExt,PermissionsExt};
    let mut distinct=BTreeSet::new();
    for arm in ["REF","OFF","ON"] { for f in ids[arm]["copies"].as_array().unwrap() {
        let p=f["path"].as_str().unwrap();let m=fs::metadata(p).unwrap();
        assert_eq!(hash(p),f["sha256"]);assert_eq!(m.dev(),f["device"].as_u64().unwrap());
        assert_eq!(m.ino(),f["inode"].as_u64().unwrap());assert_eq!(m.permissions().mode()as u64,f["mode"].as_u64().unwrap());
        assert!(distinct.insert((m.dev(),m.ino())));
    }} assert_eq!(distinct.len(),9);
}
