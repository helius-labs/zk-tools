// Private experiment: generated Ifma8 arithmetic is unchanged.
#[repr(transparent)]
#[derive(Clone, Copy, Debug)]
pub struct LazyFq([u64; 4]);
impl LazyFq {
    #[inline(always)]
    pub fn from_canonical(x: crate::Fq) -> Self { Self(x.0) }
    #[inline(always)]
    pub fn canonical(self) -> crate::Fq {
        crate::Fq::from_montgomery(crate::portable::reduce_once(self.0, crate::FqConfig::P))
    }
    #[inline(always)]
    pub fn is_zero(self) -> bool { self.0 == [0;4] || self.0 == crate::FqConfig::P }
    pub fn words(self) -> [u64;4] { self.0 }
    #[cfg(test)]
    pub fn qualification_from_words(w: [u64;4]) -> Self {
        assert!(crate::portable::less(w, crate::portable::add4(crate::FqConfig::P,crate::FqConfig::P).0));
        Self(w)
    }
}

#[derive(Clone, Copy)]
pub struct LazyY8(Ifma8<crate::FqConfig,true>);
impl LazyY8 {
    #[inline(always)]
    pub fn new(x: &[LazyFq;8]) -> Self { Self(Ifma8::raw(&x.map(|v|v.0))) }
    #[inline(always)]
    pub fn from_batch(x: Ifma8<crate::FqConfig,true>) -> Self { Self(x) }
    #[inline(always)]
    pub fn batch(self) -> Ifma8<crate::FqConfig,true> { self.0 }
    #[inline(always)]
    pub fn get(self) -> [LazyFq;8] {
        // Exact original mixed export packing and transpose, without reduce(p).
        // SAFETY: normalized numerical values <2p fit in four words; LazyFq
        // is transparent over those words. Four unaligned stores initialize
        // the entire eight-element array. Module guards supply AVX-512.
        unsafe {
            let [t0,t1,t2,t3,t4]=self.0.0;
            let w0=_mm512_or_si512(t0,_mm512_slli_epi64::<52>(t1));
            let w1=_mm512_or_si512(_mm512_srli_epi64::<12>(t1),_mm512_slli_epi64::<40>(t2));
            let w2=_mm512_or_si512(_mm512_srli_epi64::<24>(t2),_mm512_slli_epi64::<28>(t3));
            let w3=_mm512_or_si512(_mm512_srli_epi64::<36>(t3),_mm512_slli_epi64::<16>(t4));
            let a=_mm512_unpacklo_epi64(w0,w1);
            let b=_mm512_unpackhi_epi64(w0,w1);
            let c=_mm512_unpacklo_epi64(w2,w3);
            let d=_mm512_unpackhi_epi64(w2,w3);
            let low=_mm512_set_epi64(11,10,3,2,9,8,1,0);
            let high=_mm512_set_epi64(15,14,7,6,13,12,5,4);
            let even_lo=_mm512_permutex2var_epi64(a,low,c);
            let even_hi=_mm512_permutex2var_epi64(a,high,c);
            let odd_lo=_mm512_permutex2var_epi64(b,low,d);
            let odd_hi=_mm512_permutex2var_epi64(b,high,d);
            let mut out=core::mem::MaybeUninit::<[LazyFq;8]>::uninit();
            let p=out.as_mut_ptr().cast::<__m512i>();
            _mm512_storeu_si512(p,_mm512_shuffle_i64x2::<0x44>(even_lo,odd_lo));
            _mm512_storeu_si512(p.add(1),_mm512_shuffle_i64x2::<0xee>(even_lo,odd_lo));
            _mm512_storeu_si512(p.add(2),_mm512_shuffle_i64x2::<0x44>(even_hi,odd_hi));
            _mm512_storeu_si512(p.add(3),_mm512_shuffle_i64x2::<0xee>(even_hi,odd_hi));
            out.assume_init()
        }
    }
}


/// Canonical incoming Y, typed bucket Y<2p, prefix<2p. Transient D<=3p is
/// consumed privately by full-R260 REDC; p+6p²/2^260<2p. Ordinary API bounds
/// remain unchanged. All operands retain normalized52-bit digits and3p<2^256.
#[inline(always)]
pub fn lazy_g1_scaled_numerator(by:&[crate::Fq;8],ay:&LazyY8,scale:&Ifma8<crate::FqConfig,true>,negative:u8)->Ifma8<crate::FqConfig,true>{
 unsafe{
  type B=Ifma8<crate::FqConfig,true>;
  let by=B::new(by);let p=crate::FqConfig::P;let two=crate::portable::add4(p,p).0;let three=crate::portable::add4(two,p).0;
  let two=split(two);let three=split(three);let flip=_mm512_maskz_mov_epi64(negative,B::splat(MASK));
  let mut carry=_mm512_maskz_mov_epi64(negative,B::splat(1));let mut t=[B::splat(0);5];
  for j in 0..5{let offset=_mm512_mask_blend_epi64(negative,B::splat(two[j]),B::splat(three[j]));let signed=_mm512_xor_si512(by.0[j],flip);
   let v=_mm512_add_epi64(_mm512_sub_epi64(_mm512_add_epi64(offset,signed),ay.0.0[j]),carry);t[j]=_mm512_and_si512(v,B::splat(MASK));carry=_mm512_srai_epi64::<52>(v);
  }
  // Same full-R260 row arithmetic as prefix_mul, with the wider input
  // contract proved locally above; result re-enters the ordinary<2p API.
  let a=Ifma8::<crate::FqConfig,false>(t,PhantomData);let b=Ifma8::<crate::FqConfig,false>(scale.0,PhantomData);let out=a.mul(&b);Ifma8(out.0,PhantomData)
 }
}
#[cfg(test)]
#[path="lazy_g1_tests.rs"]
mod lazy_g1_tests;
