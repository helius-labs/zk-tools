use super::*;
use zopro_bn254::{G1Affine,G1Config,G1Projective};
fn independent_digit(words:[u64;4],column:usize)->i16{
 let bit=|i:usize|if i<256{((words[i/64]>>(i%64))&1)as i32}else{0};let start=12*column;
 let unsigned=(0..12).map(|j|bit(start+j)<<j).sum::<i32>();let previous=if start==0{0}else{bit(start-1)};(unsigned+previous-(bit(start+11)<<12))as i16
}
fn fixture(n:usize)->(Vec<G1Affine>,Vec<Fr>,Vec<[u64;4]>){
 let mut rng=crate::testing::Seeded::new(0x9911443300);let mut coefficients=Vec::new();let mut points=Vec::new();let mut words=Vec::new();
 for i in 0..n{let k=if i%23==0{Fr::ZERO}else{let k=Fr::from((i%37+1)as u64);if i%7==0{-k}else{k}};coefficients.push(k);points.push((G1Projective::generator()*k).to_affine());let s=if i%11==0{Fr::ONE}else if i%13==0{-Fr::ONE}else{rng.fr()};words.push(s.to_canonical());}
 (points,coefficients,words)
}
fn check(points:&[G1Affine],coefficients:&[Fr],words:&[[u64;4]],column:usize,size:usize){
 let mut state=Window::<G1Config>::new(2048,size);let cut=points.len()/2;state.feed(&points[..cut],&words[..cut],column,12,size);state.feed(&points[cut..],&words[cut..],column,12,size);
 let got=state.finish();let mut expected=vec![Fr::ZERO;2048];
 for(&k,&w)in coefficients.iter().zip(words){let d=independent_digit(w,column);if d!=0{expected[d.unsigned_abs()as usize-1]+=if d<0{-k}else{k};}}
 for(p,k)in got.into_iter().zip(expected){assert_eq!(p,(G1Projective::generator()*k).to_affine());}
}
#[test]fn lazy_g1_full_window_sign_exceptions_tails_and_two_feeds(){
 for n in[0,1,7,8,9,33,201,1025]{let(points,k,w)=fixture(n);let before=points.clone();for column in[0,5,21]{for size in[8,9,31,32,33,200]{check(&points,&k,&w,column,size);}}assert_eq!(points,before);}
}
#[test]fn lazy_g1_terminal_conversion_preserves_allocation_in_tested_build(){
 assert_eq!(core::mem::size_of::<LazyG1Bucket<G1Config>>(),64);assert_eq!(core::mem::align_of::<LazyG1Bucket<G1Config>>(),core::mem::align_of::<G1Affine>());
 for n in[0usize,1,7,8,9,33,200,2048]{for spare in[0,37]{let mut v=Vec::with_capacity(n+spare);for i in 0..n{v.push(LazyG1Bucket::<G1Config>::from_affine((G1Projective::generator()*Fr::from((i+1)as u64)).to_affine()));}let ptr=v.as_ptr().cast::<u8>();let cap=v.capacity();let canonical=v.into_iter().map(LazyG1Bucket::canonical).collect::<Vec<_>>();assert_eq!(canonical.as_ptr().cast::<u8>(),ptr);assert_eq!(canonical.capacity(),cap);assert_eq!(canonical.len(),n);}}
}
#[test]fn lazy_g1_complete_windows_on_actual_small_stack_workers(){
 let(points,k,w)=fixture(1025);for threads in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(threads).stack_size(512*1024).build().unwrap();pool.broadcast(|_|check(&points,&k,&w,0,33));}
}
