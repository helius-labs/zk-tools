use super::*;
use ark_ff::{PrimeField,Field};
type B=Ifma8<crate::FqConfig,true>;
type A=ark_ref::Fq;
fn number(w:[u64;4])->A{A::from_le_bytes_mod_order(&w.into_iter().flat_map(u64::to_le_bytes).collect::<Vec<_>>())}
fn less(a:[u64;4],b:[u64;4])->bool{a.iter().rev().cmp(b.iter().rev()).is_lt()}
fn redc260(a:[u64;4],b:[u64;4])->[u64;4]{
 // Independent full schoolbook integer product, THEN five low-word REDC
 // cancellations. Native code interleaves those phases in each CIOS row.
 let a=split(a);let b=split(b);let p=split(crate::FqConfig::P);let mut t=[0u64;11];let mask=(1u128<<52)-1;
 for i in 0..5{let mut carry=0u128;for j in 0..5{let v=t[i+j]as u128+a[i]as u128*b[j]as u128+carry;t[i+j]=(v&mask)as u64;carry=v>>52;}let mut j=i+5;while carry!=0{let v=t[j]as u128+carry;t[j]=(v&mask)as u64;carry=v>>52;j+=1;}}
 for i in 0..5{let m=t[i].wrapping_mul(crate::FqConfig::INV)&MASK;let mut carry=0u128;for j in 0..5{let v=t[i+j]as u128+m as u128*p[j]as u128+carry;t[i+j]=(v&mask)as u64;carry=v>>52;}let mut j=i+5;while carry!=0{let v=t[j]as u128+carry;t[j]=(v&mask)as u64;carry=v>>52;j+=1;}assert_eq!(t[i],0);}
 assert_eq!(t[10],0);assert!(t[9]<1<<48);
 [t[5]|(t[6]<<52),(t[6]>>12)|(t[7]<<40),(t[7]>>24)|(t[8]<<28),(t[8]>>36)|(t[9]<<16)]
}
#[test]
fn lazy_g1_scaled_y_matches_integer_redc_and_arkworks(){
 let p=crate::FqConfig::P;let two=crate::portable::add4(p,p).0;let three=crate::portable::add4(two,p).0;let one=[1,0,0,0];let pm=crate::portable::sub4(p,one).0;let tm=crate::portable::sub4(two,one).0;
 let boundary=[[0;4],one,pm,p,crate::portable::add4(p,one).0,tm];let mut seed=0xc41afed133u64;let mut next=||{seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;seed};let mut checked=0;let mut inclusive=0;
 let inv=A::from(2u64).pow([260]).inverse().unwrap();let mut output=[[0u64;4];8];
 for round in 0..(256*6+1024+256){let negative=round as u8;
  let by: [[u64;4];8]=std::array::from_fn(|i|if round<1536{boundary[(round/256+i)%3]}else{let mut w=std::array::from_fn(|_|next());w[3]&=(1<<61)-1;w});
  let ay: [[u64;4];8]=std::array::from_fn(|i|if round<1536{boundary[(round/256+i)%6]}else if round>=2560{output[i]}else{let mut w=std::array::from_fn(|_|next());w[3]&=(1<<62)-1;w});
  let scales:[[u64;4];8]=std::array::from_fn(|i|if round<1536{boundary[(round/256+2*i)%6]}else{let mut w=std::array::from_fn(|_|next());w[3]&=(1<<62)-1;w});
  assert!(by.iter().all(|w|less(*w,p)));assert!(ay.iter().chain(&scales).all(|w|less(*w,two)));
  let by_fields=by.map(crate::Fq::from_montgomery);let ay_batch=LazyY8::new(&ay.map(LazyFq));let scale=B::raw(&scales);
  let got=lazy_g1_scaled_numerator(&by_fields,&ay_batch,&scale,negative);output=LazyY8::from_batch(got).get().map(LazyFq::words);
  for i in 0..8{let d=if negative>>i&1==0{crate::portable::sub4(crate::portable::add4(two,by[i]).0,ay[i]).0}else{crate::portable::sub4(crate::portable::sub4(three,by[i]).0,ay[i]).0};inclusive+=usize::from(d==three);
   assert_eq!(output[i],redc260(d,scales[i]));assert!(less(output[i],two));let dy=if negative>>i&1==0{number(by[i])-number(ay[i])}else{-number(by[i])-number(ay[i])};assert_eq!(number(output[i]),dy*number(scales[i])*inv);checked+=1;
  }
  assert_eq!(ay_batch.get().map(LazyFq::words),ay);assert_eq!(scale.0.map(|x|unsafe{let mut v=[0u64;8];_mm512_storeu_si512(v.as_mut_ptr().cast(),x);v}),B::raw(&scales).0.map(|x|unsafe{let mut v=[0u64;8];_mm512_storeu_si512(v.as_mut_ptr().cast(),x);v}));
 }
 assert!(inclusive>0);eprintln!("LAZY_G1_NUMERATOR_OUTPUTS={checked} INCLUSIVE3P={inclusive}");
}
#[test]
fn lazy_g1_raw_y_boundary_roundtrips_and_zero_representatives(){
 let p=crate::FqConfig::P;let two=crate::portable::add4(p,p).0;let one=[1,0,0,0];let inputs=[[0;4],one,crate::portable::sub4(p,one).0,p,crate::portable::add4(p,one).0,crate::portable::sub4(two,one).0,[1<<52,0,0,0],[0,0,1,0]];
 let values=inputs.map(LazyFq);assert_eq!(LazyY8::new(&values).get().map(LazyFq::words),inputs);
 for (v,w)in values.into_iter().zip(inputs){assert_eq!(v.canonical().0,crate::portable::reduce_once(w,p));assert_eq!(v.is_zero(),w==[0;4]||w==p);}
 assert_eq!(core::mem::size_of::<LazyFq>(),32);
}
