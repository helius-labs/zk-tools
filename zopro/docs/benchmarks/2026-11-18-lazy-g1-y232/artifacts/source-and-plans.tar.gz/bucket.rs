use super::*;
use zopro_bn254::ifma8::LazyFq;
#[repr(C)]
#[derive(Clone,Copy)]
pub(crate) struct LazyG1Bucket<C:CurveConfig<Base=Fq>>{pub(crate)x:Fq,pub(crate)y:LazyFq,_curve:core::marker::PhantomData<C>}
impl<C:CurveConfig<Base=Fq>>LazyG1Bucket<C>{
 #[inline(always)]pub(crate)fn from_affine(p:Affine<C>)->Self{Self::new(p.x,LazyFq::from_canonical(p.y))}
 #[inline(always)]pub(crate)fn new(x:Fq,y:LazyFq)->Self{Self{x,y,_curve:core::marker::PhantomData}}
 #[inline(always)]pub(crate)fn canonical_y(self)->Fq{self.y.canonical()}
 #[inline(always)]pub(crate)fn canonical(self)->Affine<C>{Affine::new(self.x,self.canonical_y())}
 #[inline(always)]pub(crate)fn is_identity(self)->bool{self.x==Fq::ZERO&&self.y.is_zero()}
}
