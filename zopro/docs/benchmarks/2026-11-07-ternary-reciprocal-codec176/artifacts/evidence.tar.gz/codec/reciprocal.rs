//! Balanced radix-6561 digits with corrected fixed-divisor reciprocals.
pub const RADIX:u128=6561;
pub const fn power(index:usize)->u128{let mut value=1;let mut i=0;while i<index{value*=RADIX;i+=1;}value}
#[inline(always)]
fn high_product(a:u128,b:u128)->u128{
    let (a0,a1)=(a as u64 as u128,a>>64);
    let (b0,b1)=(b as u64 as u128,b>>64);
    let (p00,p01,p10,p11)=(a0*b0,a0*b1,a1*b0,a1*b1);
    let carry=(p00>>64)+(p01 as u64 as u128)+(p10 as u64 as u128);
    p11+(p01>>64)+(p10>>64)+(carry>>64)
}
#[inline(always)]
fn quotient<const D:u128>(n:u128)->u128{
    debug_assert!(D>0&&D<1u128<<127);
    debug_assert!(n<1u128<<127);
    if D==1{return n}
    let reciprocal=const{if D<=1{0}else{u128::MAX/D+1}};
    let approximate=high_product(n,reciprocal);
    let product=approximate*D;
    approximate-u128::from(product>n)
}
#[inline(always)]
fn at<const D:u128>(m:u128)->i16{
    let q=quotient::<D>(m+(D-1)/2);
    let residue=if D>=1u128<<63{(q as u64%RADIX as u64)as u128}else{q-quotient::<RADIX>(q)*RADIX};
    if residue>RADIX/2{(residue as i32-RADIX as i32)as i16}else{residue as i16}
}
#[inline]
pub fn digit(component:i128,index:usize)->i16{
    debug_assert!(component.unsigned_abs()<1u128<<126);
    let m=component.unsigned_abs();
    let d=match index{0=>at::<{power(0)}>(m),1=>at::<{power(1)}>(m),2=>at::<{power(2)}>(m),3=>at::<{power(3)}>(m),4=>at::<{power(4)}>(m),5=>at::<{power(5)}>(m),6=>at::<{power(6)}>(m),7=>at::<{power(7)}>(m),8=>at::<{power(8)}>(m),9=>at::<{power(9)}>(m),10=>at::<{power(10)}>(m),_=>panic!("ternary window exceeds the supported component length")};
    if component<0{-d}else{d}
}
#[cfg(test)]mod tests{
    use super::*;
    fn full_product_u32(a:u128,b:u128)->[u32;8]{let mut out=[0u32;8];for i in 0..4{let ai=(a>>(32*i))as u32 as u64;let mut carry=0u64;for j in 0..4{let bj=(b>>(32*j))as u32 as u64;let value=ai*bj+out[i+j]as u64+carry;out[i+j]=value as u32;carry=value>>32;}out[i+4]=carry as u32;}out}
    fn high_reference(a:u128,b:u128)->u128{let p=full_product_u32(a,b);(p[4]as u128)|((p[5]as u128)<<32)|((p[6]as u128)<<64)|((p[7]as u128)<<96)}
    #[test]fn high_product_full_width_matches_u32_schoolbook(){let values=[0,1,2,(1u128<<32)-1,1u128<<32,(1u128<<64)-1,1u128<<64,(1u128<<64)+1,(1u128<<127)-1,1u128<<127,u128::MAX-1,u128::MAX];let mut cases=0;for a in values{for b in values{assert_eq!(high_product(a,b),high_reference(a,b));cases+=1;}}let mut state=0x518aedc279b38u128;for _ in 0..16384{state=state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);let a=state;state=state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);assert_eq!(high_product(a,state),high_reference(a,state));cases+=1;}println!("HIGH_PRODUCT cases={cases}; independent32bitlimboracle");}
    fn check_divisor<const D:u128>()->usize{
        let mut cases=0;
        if D>1{let mu=const{if D<=1{0}else{u128::MAX/D+1}};let p=full_product_u32(mu,D);assert_eq!(high_reference(mu,D),1);let low=p[..4].iter().enumerate().map(|(i,v)|(*v as u128)<<(32*i)).sum::<u128>();assert!(low<D);assert_eq!(high_reference(mu-1,D),0);}
        let maximum=(1u128<<127)-1;
        for n in [0,1,D-1,D,D+1,maximum,maximum-1,maximum/2]{if n<=maximum{assert_eq!(quotient::<D>(n),n/D);cases+=1;}}
        let mut state=0x49bca1379d25u128;
        for _ in 0..4096{state=state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);let n=state&maximum;assert_eq!(quotient::<D>(n),n/D);cases+=1;let k=state%(maximum/D+1);let center=k*D;for delta in [-1i8,0,1]{let n=if delta<0{center.checked_sub(1)}else{center.checked_add(delta as u128)};if let Some(n)=n{if n<=maximum{assert_eq!(quotient::<D>(n),n/D);cases+=1;}}}}
        cases
    }
    #[test]fn fixed_quotients_match_builtin_division_and_product_bounds(){let mut cases=0;cases+=check_divisor::<{power(0)}>();cases+=check_divisor::<{power(1)}>();cases+=check_divisor::<{power(2)}>();cases+=check_divisor::<{power(3)}>();cases+=check_divisor::<{power(4)}>();cases+=check_divisor::<{power(5)}>();cases+=check_divisor::<{power(6)}>();cases+=check_divisor::<{power(7)}>();cases+=check_divisor::<{power(8)}>();cases+=check_divisor::<{power(9)}>();cases+=check_divisor::<{power(10)}>();println!("RECIPROCAL_QUOTIENT cases={cases}; alldivisors exactproductbounds+builtindivision");}
    fn check_digit(x:i128){let mut remaining=x;let mut expected=[0i16;11];for value in &mut expected{let mut weight=1i128;for _ in 0..8{let r=remaining.rem_euclid(3);let d=if r==2{-1}else{r};*value+=(d*weight)as i16;remaining=(remaining-d)/3;weight*=3;}}assert_eq!(remaining,0);let mut recovered=0i128;for index in (0..11).rev(){let d=digit(x,index);assert_eq!(d,expected[index]);assert!(d.unsigned_abs()<=if index==10{1}else{3280});recovered=recovered.checked_mul(RADIX as i128).unwrap().checked_add(d as i128).unwrap();}assert_eq!(recovered,x);}
    #[test]fn signed_digits_match_trits_carries_and_full_magnitude_range(){let mut cases=0;for x in -65536..=65536{check_digit(x);cases+=1;}for j in 0..=10{let p=power(j)as i128;for center in [p,p/2]{for delta in -3..=3{for sign in [-1,1]{let x=(center+delta)*sign;if x.unsigned_abs()<1u128<<126{check_digit(x);cases+=1;}}}}}for x in [(1i128<<126)-1,-((1i128<<126)-1)]{check_digit(x);cases+=1;}let mut state=0x749c1b32a56fu128;for _ in 0..16384{state=state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);let m=(state&((1u128<<126)-1))as i128;check_digit(if state>>127!=0{-m}else{m});cases+=1;}assert!(std::panic::catch_unwind(||digit(1,11)).is_err());println!("RECIPROCAL_DIGITS cases={cases}; pertrit+checkedHorner; no nativepoint/timeclaim");}
}
