use serde_json::{json, Value};
use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/ternary-reciprocal-codec176";
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(n:&str,v:Value){let p=format!("{R}/{n}");assert!(!Path::new(&p).exists());fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn command(n:&str,a:Vec<String>)->Value{json!({"kind":"command","name":n,"argv":a,"timeout_seconds":300})}
fn prepare(){
 assert_eq!(read(&format!("{R}/native-runs/result.json"))["status"],"complete");
 let mut pins=serde_json::from_value::<BTreeMap<String,String>>(read(&format!("{R}/native-pins.json"))).unwrap();
 for(p,h)in &pins{assert_eq!(&hash(p),h,"{p}");}
 let log=fs::read_to_string(format!("{R}/native-runs/driver-build/stderr.log")).unwrap();
 let rustc=log.lines().find(|l|l.contains("Running")&&l.contains("--crate-name zopro_ternary_g2_caller")).unwrap();
 for f in ["-C opt-level=3","-C lto=fat","-C codegen-units=1","-C target-cpu=native","--cfg zopro_ternary_g2_diagnostic"]{assert!(rustc.contains(f),"{f}");}
 let mut libs=BTreeMap::new();let t=rustc.split_whitespace().collect::<Vec<_>>();
 for p in t.windows(2){if p[0]=="--extern"{let(n,p)=p[1].trim_end_matches('`').split_once('=').unwrap();libs.insert(n.to_string(),json!({"path":p,"sha256":hash(p)}));pins.insert(p.to_string(),hash(p));}}
 assert_eq!(libs.len(),6);assert!(libs.contains_key("zopro_core")&&libs.contains_key("zopro_bn254"));
 let b=format!("{R}/candidate-bin");assert!(!Path::new(&b).exists());fs::copy(format!("{R}/target-driver/release/zopro-ternary-g2-caller"),&b).unwrap();
 save("identities.json",json!({"binary":b,"binary_sha256":hash(&b),"actual_rustc":rustc,"fresh_direct_dependencies":libs,"source_audit":read(&format!("{R}/native-source-audit.json")),"not_SDK":true}));
 for f in ["candidate-bin","identities.json","prepare-codegen.rs","native-runs/driver-build/exit.json","native-runs/driver-build/command.json","native-runs/driver-build/stdout.log","native-runs/driver-build/stderr.log","native-runs/result.json"]{let p=format!("{R}/{f}");pins.insert(p.clone(),hash(&p));}
 save("codegen-pins.json",json!(pins));
 save("listing-plan.json",json!({"version":1,"source_pins":format!("{R}/codegen-pins.json"),"steps":[command("reciprocal-consumer-symbols",vec!["nm".into(),"-S".into(),"--defined-only".into(),b.clone()]),command("reciprocal-consumer-relocations",vec!["readelf".into(),"-rW".into(),b])]}));
 println!("PASS actual O3/native/fatLTO/CGU1 consumer and six linked direct dependencies bound; no query or timing");
}
fn decode(){
 assert_eq!(read(&format!("{R}/listing-runs/result.json"))["status"],"complete");
 let text=fs::read_to_string(format!("{R}/listing-runs/reciprocal-consumer-symbols/stdout.log")).unwrap();
 let mut selected=vec![];let mut all=vec![];
 for l in text.lines(){let f=l.split_whitespace().collect::<Vec<_>>();if f.len()!=4{continue}let name=format!("{:#}",rustc_demangle::demangle(f[3]));if name.starts_with("zopro_core::msm_affine::g2_borrowed::ternary::"){
  let v=json!({"address":u64::from_str_radix(f[0],16).unwrap(),"size":u64::from_str_radix(f[1],16).unwrap(),"symbol":f[3],"demangled":name});
  if name.ends_with("::feed")||name.ends_with("::digit")||name.ends_with("::carry_component")||name.contains("::codec::"){selected.push(v.clone());}all.push(v);
 }}
 assert_eq!(selected.iter().filter(|v|v["demangled"]=="zopro_core::msm_affine::g2_borrowed::ternary::feed").count(),1);
 save("native-symbols.json",json!({"all_ternary_symbols":all,"selected":selected}));
 let mut pins=serde_json::from_value::<BTreeMap<String,String>>(read(&format!("{R}/codegen-pins.json"))).unwrap();
 for f in ["listing-runs/result.json","native-symbols.json"]{let p=format!("{R}/{f}");pins.insert(p.clone(),hash(&p));}
 for n in ["reciprocal-consumer-symbols","reciprocal-consumer-relocations"]{for f in ["command.json","exit.json","stdout.log","stderr.log"]{let p=format!("{R}/listing-runs/{n}/{f}");pins.insert(p.clone(),hash(&p));}}
 save("decode-pins.json",json!(pins));
 let steps=selected.iter().enumerate().map(|(i,v)|command(&format!("reciprocal-boundary-{i}"),vec!["objdump".into(),"-d".into(),"-M".into(),"intel".into(),format!("--disassemble={}",v["symbol"].as_str().unwrap()),format!("{R}/candidate-bin")])).collect::<Vec<_>>();
 save("decode-plan.json",json!({"version":1,"source_pins":format!("{R}/decode-pins.json"),"steps":steps}));
 println!("PASS bound {} actual feed/codec/carry boundary symbols for first decode",selected.len());
}
fn main(){match std::env::args().nth(1).as_deref(){Some("prepare")=>prepare(),Some("decode")=>decode(),_=>panic!("prepare|decode")}}
