use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/ternary-reciprocal-codec176";
const OLD: &str = "/home/ubuntu/src/zopro-perf-work/ternary-g2-caller176";
fn hash(path: &str) -> String { format!("{:x}", Sha256::digest(fs::read(path).unwrap())) }
fn read(path: &str) -> Value { serde_json::from_slice(&fs::read(path).unwrap()).unwrap() }
fn save(name: &str, value: Value) {
    let p = format!("{R}/{name}"); assert!(!Path::new(&p).exists());
    fs::write(p, serde_json::to_vec_pretty(&value).unwrap()).unwrap();
}
fn copy_tree(src: &Path, dst: &Path, files: &mut Vec<String>) {
    fs::create_dir(dst).unwrap();
    let mut entries = fs::read_dir(src).unwrap().map(|v| v.unwrap()).collect::<Vec<_>>();
    entries.sort_by_key(|v| v.file_name());
    for e in entries {
        assert!(!e.file_type().unwrap().is_symlink());
        let next = dst.join(e.file_name());
        if e.file_type().unwrap().is_dir() { copy_tree(&e.path(), &next, files); }
        else { assert!(e.file_type().unwrap().is_file()); fs::copy(e.path(), &next).unwrap(); files.push(next.to_str().unwrap().to_string()); }
    }
}
fn main() {
    let mut pins = BTreeMap::<String, String>::new();
    for p in [format!("{OLD}/driver-repair-pins.json"), format!("{R}/pins.json")] {
        for (file, expected) in serde_json::from_value::<BTreeMap<String, String>>(read(&p)).unwrap() {
            assert_eq!(hash(&file), expected, "{file}"); pins.insert(file, expected);
        }
        pins.insert(p.clone(), hash(&p));
    }
    assert_eq!(read(&format!("{R}/test-runs/result.json"))["status"], "complete");
    for name in ["checked-reciprocal-integer-tests", "optimized-reciprocal-integer-tests"] {
        let base = format!("{R}/test-runs/{name}");
        let e = read(&format!("{base}/exit.json")); assert_eq!(e["success"], true); assert_eq!(e["returncode"], 0);
        for stream in ["stdout", "stderr"] { assert_eq!(hash(&format!("{base}/{stream}.log")), e[format!("{stream}_sha256")].as_str().unwrap()); }
        let s = fs::read_to_string(format!("{base}/stdout.log")).unwrap();
        for needle in ["3 passed; 0 failed", "HIGH_PRODUCT cases=16528", "RECIPROCAL_QUOTIENT cases=178264", "RECIPROCAL_DIGITS cases=147753"] { assert!(s.contains(needle)); }
        for f in ["command.json", "exit.json", "stdout.log", "stderr.log"] { let p = format!("{base}/{f}"); pins.insert(p.clone(), hash(&p)); }
    }
    let mut files = vec![];
    copy_tree(Path::new(&format!("{OLD}/source")), Path::new(&format!("{R}/source")), &mut files);
    let module = "crates/zopro-core/src/msm_affine/g2_borrowed/random_access.rs";
    let mut unchanged = 0;
    for p in &files { let relative = p.strip_prefix(&format!("{R}/source/")).unwrap(); assert_eq!(hash(p), hash(&format!("{OLD}/source/{relative}"))); if relative != module { unchanged += 1; } }
    assert_eq!(files.len(), 178); assert_eq!(unchanged, 177);
    fs::copy(format!("{R}/reciprocal.rs"), format!("{R}/source/{module}")).unwrap();
    let mut driver_files = vec![];
    copy_tree(Path::new(&format!("{OLD}/driver2")), Path::new(&format!("{R}/driver")), &mut driver_files);
    for p in &driver_files { assert_eq!(hash(p), hash(&p.replacen(&format!("{R}/driver/"), &format!("{OLD}/driver2/"), 1))); }
    for p in files.iter().chain(&driver_files) { pins.insert(p.clone(), hash(p)); }
    let mut step = read(&format!("{OLD}/driver-repair-plan.json"))["steps"][0].clone();
    let a = step["argv"].as_array_mut().unwrap();
    assert_eq!(a.last().unwrap(), &format!("{OLD}/driver2/Cargo.toml")); *a.last_mut().unwrap() = format!("{R}/driver/Cargo.toml").into();
    step["environment"]["CARGO_TARGET_DIR"] = format!("{R}/target-driver").into();
    for p in [format!("{R}/prepare-native.rs"),format!("{R}/design.md"),format!("{R}/test-runs/result.json"),format!("{OLD}/driver-repair-plan.json")] { pins.insert(p.clone(), hash(&p)); }
    save("native-source-audit.json", json!({"passed":true,"source_files":178,"unchanged_previous_candidate_files":177,"changed_only":module,"codec_matches_qualified_standalone_bytes":true,"driver_unchanged_files":driver_files.len(),"no_geometry_queue_pool_grouping_or_Phi_changes":true,"inherited_core_point_tests_not_replayed":true,"checked_and_optimized_tests_passed":true,"distinct_cases_per_configuration":{"high_product":16528,"quotients":178264,"signed_digits":147753},"no_new_recording_queries_or_proofs":true}));
    let p = format!("{R}/native-source-audit.json"); pins.insert(p.clone(),hash(&p));
    save("native-pins.json",json!(pins));
    save("native-plan.json",json!({"version":1,"source_pins":format!("{R}/native-pins.json"),"steps":[step]}));
    println!("PASS new reciprocal module only;177/178 source files unchanged;whole-query driver byte-exact;new native build prepared");
}
