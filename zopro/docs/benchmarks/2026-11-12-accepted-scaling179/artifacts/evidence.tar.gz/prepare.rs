use std::{fs,collections::BTreeMap,io::Write,os::unix::fs::{PermissionsExt,MetadataExt}};
use serde_json::{Value,json};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/accepted-scaling179";
const PRIOR:&str="/home/ubuntu/src/zopro-perf-work/phase-search-c7a178/proof-sha256-after-preflight.json";
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(n:&str,v:Value){let mut f=fs::OpenOptions::new().write(true).create_new(true).open(format!("{R}/{n}")).unwrap();f.write_all(&serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn main(){
 let sdk="/home/ubuntu/src/zopro-perf-work/bundle-sdk178/build-run/candidate-sdk";
 assert_eq!(hash(sdk),"b646c7b8c1d8a26a0db45fb3f67c453dd616bd9f02e25c36192721ae02855abe");
 assert_eq!(hash(PRIOR),"22edc7fdac8573e74fd2d476a7af32bc694f4c1ecb5c3ae3b24bde6940a0ff1b");assert_eq!(read(PRIOR).as_array().unwrap().len(),55028);
 let source=read("/home/ubuntu/src/zopro-perf-work/bundle-sdk178/cases.json");
 let base=read("/home/ubuntu/src/zopro-perf-work/phase-search178/preflight-plan.json")["steps"][0]["environment"].clone();
 let verifier="/home/ubuntu/src/zopro-perf-work/batch-local-steal/gnark/verify";
 let mut pins=BTreeMap::<String,String>::new();for p in[sdk,PRIOR,verifier]{pins.insert(p.into(),hash(p));}
 let mut copies=vec![];fs::create_dir(format!("{R}/bin")).unwrap();
 for i in 0..3 {let p=format!("{R}/bin/accepted{i}");let bytes=fs::read(sdk).unwrap();let mut f=fs::OpenOptions::new().write(true).create_new(true).open(&p).unwrap();f.write_all(&bytes).unwrap();f.sync_all().unwrap();fs::set_permissions(&p,fs::Permissions::from_mode(0o755)).unwrap();let m=fs::metadata(&p).unwrap();pins.insert(p.clone(),hash(&p));copies.push(json!({"path":p,"sha256":hash(&p),"inode":m.ino(),"device":m.dev()}));}
 save("copies.json",json!(copies));let mut cases=vec![];
 for w in [1,2,4,8,16,32]{for shape in["1x2","2x2"]{let mut c=source.as_array().unwrap().iter().find(|c|c["shape"]==shape).unwrap().clone();c["workers"]=json!(w);c["cpu_affinity"]=json!(format!("0-{}",w-1));c["name"]=json!(format!("{shape}-w{w}"));for field in["image","request","key","raw"]{let p=c[field].as_str().unwrap();pins.insert(p.into(),hash(p));if field!="request"{assert_eq!(hash(p),c[format!("{field}_sha256")]);}}cases.push(c);}}
 save("cases.json",json!(cases));
 for phase in["preflight","main"]{let mut jobs=vec![];let mut steps=vec![];let rounds=if phase=="main"{17}else{1};let blocks=if phase=="main"{3}else{1};
 for block in 0..blocks{let mut order=(0..12).map(|i|(i+block*4)%12).collect::<Vec<_>>();if block%2==1{order.reverse();}for ci in order{let c=&cases[ci];let name=format!("{phase}-b{block}-{}",c["name"].as_str().unwrap());let dir=format!("{R}/proofs/{name}");let mut env=base.clone();env["RAYON_NUM_THREADS"]=json!(c["workers"].to_string());steps.push(json!({"kind":"command","name":name,"argv":["/usr/bin/taskset","-c",c["cpu_affinity"],copies[block]["path"],c["image"],c["request"],rounds.to_string(),dir],"environment":env,"timeout_seconds":120}));jobs.push(json!({"name":name,"block":block,"backing":block,"case":c,"rounds":rounds,"proof_dir":dir}));}}
 for j in &jobs {let c=&j["case"];let dir=j["proof_dir"].as_str().unwrap();steps.push(json!({"kind":"command","name":format!("verify-{}",j["name"].as_str().unwrap()),"argv":[verifier,c["image"],c["image_sha256"],format!("{dir}/0.proof"),format!("{dir}/0.public"),c["public_sha256"]],"timeout_seconds":120}));}
 save(&format!("{phase}-jobs.json"),json!(jobs));save(&format!("{phase}-plan.json"),json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps}));
 }
 for n in["protocol.md","prepare.rs","review.rs","review","topology.txt","copies.json","cases.json","preflight-plan.json","main-plan.json","preflight-jobs.json","main-jobs.json"]{let p=format!("{R}/{n}");pins.insert(p.clone(),hash(&p));}save("pins.json",json!(pins));println!("Frozen 12 preflights / 36 main processes; accepted SDK retained.");
}
