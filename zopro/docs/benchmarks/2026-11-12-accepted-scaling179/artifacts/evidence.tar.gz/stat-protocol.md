# Follow-up counters, frozen after the latency diagnostic

Primary scaling: one/16/32-worker CPU cost is approximately 88/110/174 ms.
Because workers16..31 share physical cores with0..15, CPU growth alone is not
redundant computation. Question: does retired instruction count grow comparably,
or do cycles per instruction account for most growth?

Use exact accepted backings0/1/2. Three blocks rotate worker order1/16/32,
reverse odd block; one backing per block. 101 measured complete SDK requests
plus3 primes, nine total panels,936SDKcalls,9freshGnarkexports. Gate user cycles,
instructions, generic cache misses and branch misses with retained SDK FIFO
support, excluding loads/primes; one simultaneous event group. All events must
report100%running. No sampling/profile decoding. Run all counters before Gnark
verification. No concurrent owned helper work.

Report all panels and per-block instruction, cycle, IPC ratios. Cycles are
aggregate user cycles, not wall time; generic cache misses identify no level.
No arithmetic-vs-scheduler attribution from total instructions, no speculation
about SMT without corresponding measurements. No adoption or observer-overhead
claim. CPU-time results belong to the earlier unprofiled latency screen.

Expected ledger55076->55085. No SDK rebuild/native/proof replay. Decision:
substantially increased instructions justify locating extra executed work;
near-stable instructions with rising cycles prioritize contention/dependencies.
Mixed results preserve both explanations. This is exploratory evidence.
