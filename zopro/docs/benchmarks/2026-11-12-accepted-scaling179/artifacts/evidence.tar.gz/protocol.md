# Accepted-build local scaling diagnostic

Question: how do latency and aggregate CPU cost of the accepted b646 SDK change
from one through 32 workers? Latest accepted qualification compared 16 and 32.
This diagnostic adds lower-count evidence; it cannot explain C7a causality,
qualify a new implementation or establish an attainable parallel lower bound.

Use the retained SDK without rebuilding. 1x2 and 2x2, workers 1/2/4/8/16/32,
fixed worker i -> CPU i, process mask 0..workers-1. This host has 16 physical
cores, with SMT siblings i/i+16. Record topology. Three independently copied
executable backings; one backing per block, three blocks total. All twelve
contexts appear once per block, rotated by four and reversing odd blocks.
Three excluded primes, seventeen timed complete SDK requests per main process.
Twelve one-timed-request preflights first, all with independent Gnark exports.
Main: 36 processes, 612 timed requests, 720 requests including primes.
Total: 48 exports, 768 SDK calls, canonical count 55028 -> 55076.

Freeze commands and hashes before capture. Run preflights, review, then main.
Only poll the live workflow during capture; no overlapping owned work.
Do not replay successful measurements, extend samples or exclude contexts.
Verify each final exported proof, public/image bindings and unique proof hash.
Internal SDK verification covers every request. Reuse source/native qualification.

Report median of three process means, each raw process mean, min/max, CPU/request,
CPU/latency (average occupied logical cores), CPU relative to one worker and
RSS max. Report per-block scaling ratios too. No confidence or adoption gate.
Different worker counts can select different internal algorithms; do not call
CPU growth scheduler overhead or interpret one-worker work/N as a hard bound.
RSS includes loading/preparation/primes and is not minimum RAM.

Decision: a latency plateau with rising CPU selects work amplification or
parallel orchestration for a targeted follow-up; continuing latency gains with
stable CPU selects arithmetic/dependency work. Both are descriptive priorities,
not causal conclusions. No new profiles unless this curve raises a specific
question not answered by retained captures. Allow 15 minutes preparation and
5 minutes capture; simplify or explain an overrun. No production modification.
