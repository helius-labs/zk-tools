use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-native176";
const REPO: &str = "/home/ubuntu/src/zk-tools";
const DEST: &str = "zopro/docs/benchmarks/2026-11-06-signed-pair52-native176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn write(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn instructions(p: impl AsRef<Path>) -> Vec<String> {
    fs::read_to_string(p)
        .unwrap()
        .lines()
        .filter_map(|l| {
            let (a, s) = l.trim().split_once(':')?;
            u64::from_str_radix(a, 16).ok()?;
            Some(s.to_owned())
        })
        .collect()
}
fn main() {
    let r = PathBuf::from(R);
    let dest = Path::new(REPO).join(DEST);
    assert!(!r.join("review.json").exists());
    let pins = read(r.join("codegen-pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap(), "pin {p}");
    }
    assert_eq!(pins.as_object().unwrap().len(), 262);
    assert_eq!(read(r.join("build/result.json"))["status"], "complete");
    assert!(!r.join("build/attempt-1.json").exists());
    let plan = read(r.join("build-plan.json"));
    let mut members: Vec<String> = [
        "design.md",
        "setup.rs",
        "signed_pair52.rs",
        "signed_pair52_tests.rs",
        "driver.rs",
        "codegen.rs",
        "finish.rs",
        "build-plan.json",
        "build-pins.json",
        "codegen-pins.json",
        "source-audit.json",
        "codegen.json",
        "prepare-initial/setup.rs",
        "prepare-initial/failure.json",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect();
    let mut receipts = 0;
    for step in plan["steps"].as_array().unwrap() {
        let name = step["name"].as_str().unwrap();
        let d = r.join("build").join(name);
        let exit = read(d.join("exit.json"));
        assert_eq!(exit["success"], true);
        assert_eq!(exit["returncode"], 0);
        for stream in ["stdout", "stderr"] {
            assert_eq!(
                exit[format!("{stream}_sha256")],
                hash(d.join(format!("{stream}.log")))
            );
        }
        let command = read(d.join("command.json"));
        let argv = command["argv"].as_array().unwrap();
        assert_eq!(argv[4..], step["argv"].as_array().unwrap()[..]);
        for file in [
            "command.json",
            "exit.json",
            "stdout.log",
            "stderr.log",
            "tests.json",
        ] {
            members.push(format!("build/{name}/{file}"));
        }
        receipts += 1;
    }
    assert_eq!(receipts, 11);
    let log = fs::read_to_string(r.join("build/signed-pair52-tests/stdout.log")).unwrap();
    assert!(log.contains("4 passed; 0 failed"));
    assert_eq!(log.matches("SIGNED_PAIR52_NATIVE_ORACLE").count(), 4);
    for field in ["Fq", "Fr"] {
        for radix in [256, 260] {
            assert!(log.contains(&format!("field={field} radix={radix} checks=60024 boundary_tuples=14884 random=4096 boundary_padding=4 chain=1024 export_checks=60024")));
        }
    }
    let preflight = fs::read(r.join("build/preflight-accepted/stdout.log")).unwrap();
    assert_eq!(std::str::from_utf8(&preflight).unwrap().lines().count(), 16);
    for role in ["OFF", "ON"] {
        assert_eq!(
            preflight,
            fs::read(r.join(format!("build/preflight-{role}/stdout.log"))).unwrap()
        );
    }
    let audit = read(r.join("source-audit.json"));
    assert_eq!(audit["source_files"], 178);
    assert_eq!(audit["exact_originals"], 174);
    assert_eq!(audit["recoverable_originals"], 176);
    for (name, h) in audit["hashes"].as_object().unwrap() {
        assert_eq!(hash(r.join("source").join(name)), h.as_str().unwrap());
    }
    let codegen = read(r.join("codegen.json"));
    assert_eq!(codegen["decodes"], 48);
    let mut same = 0;
    for row in codegen["rows"].as_array().unwrap() {
        let role = row["role"].as_str().unwrap();
        let symbol = row["symbol"].as_str().unwrap();
        let file = format!("disassembly/{role}-{symbol}.txt");
        assert_eq!(hash(r.join(&file)), row["disassembly_sha256"]);
        assert_eq!(row["loop_calls"].as_array().unwrap().len(), 0);
        let wanted = if role == "ON" {
            if symbol.contains("mul") {
                80
            } else {
                110
            }
        } else if symbol.contains("mul") {
            100
        } else {
            150
        };
        assert_eq!(row["loop_ifma"], wanted);
        if role == "ON" {
            assert!(row["loop_signed_shifts"].as_u64().unwrap() >= 8);
        }
        if role == "OFF" {
            assert_eq!(
                instructions(r.join(&file)),
                instructions(r.join(format!("disassembly/accepted-{symbol}.txt")))
            );
            same += 1;
        }
        members.push(file);
    }
    assert_eq!(same, 16);
    // Inspect the four-stream backedge range without assuming four unrolled products.
    // Each decoded body contains one product; the compiler rolls the stream loop.
    let review = json!({"status":"pass","pins":262,"source_files":178,"exact_originals":174,"recoverable_originals":176,
  "command_receipts":11,"native_outputs":240096,"native_export_checks":240096,"new_tests":4,"old_tests_filtered":35,
  "preflight_cases_each":16,"preflight_controls_equal":true,"new_decodes":48,"accepted_OFF_identical_instruction_text_bodies":16,
  "no_calls_in_selected_IFMA_backedges":true,"native_driver_flags":"actual argv -O, native, fatLTO, oneCGU verified",
  "reviewer_source_sha256":hash(r.join("finish.rs")),"reviewer_binary_sha256":hash(r.join("finish")),
  "four_stream_caveat":"four distinct states; compiler rolls rather than unrolls stream loop, not four products simultaneously resident in registers",
  "prepare_repair":"initial snapshot helper decoded binary fixtures as UTF8; changed to byte copies, only two textual edits decoded; no native execution preceded repair",
  "initial_prepare_binary_sha256":hash(r.join("prepare-initial/setup")),
  "warnings":"native test build emitted 9 unused-import warnings, eight inherited and one new; no warning-only rebuild selected",
  "decision":"qualifies one fixed prospective matched primitive timing screen; no speed claim/adoption/fullcaller/proof",
  "new_proofs":0,"production_changed":false,"timing":false});
    write(r.join("review.json"), &review);
    members.push("review.json".into());
    for file in [
        "crates/zopro-bn254/src/ifma8.rs",
        "scripts/ifma8.py",
        "crates/zopro-bn254/src/signed_pair52.rs",
        "crates/zopro-bn254/src/signed_pair52_tests.rs",
    ] {
        members.push(format!("source/{file}"));
    }
    for file in [
        "result.json",
        "protocol.json",
        "source-pins.json",
        "attempt-0.json",
        "completed.json",
        "progress.json",
    ] {
        members.push(format!("build/{file}"));
    }
    fs::create_dir_all(dest.join("artifacts")).unwrap();
    for (src, name) in [
        ("review.json", "review.json"),
        ("codegen.json", "codegen.json"),
        ("source-audit.json", "source-audit.json"),
        ("codegen-pins.json", "source-pins.json"),
        ("design.md", "design.md"),
    ] {
        fs::copy(r.join(src), dest.join("artifacts").join(name)).unwrap();
    }
    let mut hashes = BTreeMap::new();
    for name in &members {
        let bytes = fs::read(r.join(name)).unwrap();
        std::str::from_utf8(&bytes).unwrap();
        hashes.insert(name.clone(), format!("{:x}", Sha256::digest(bytes)));
    }
    write(dest.join("artifacts/archive-members.json"), &json!(hashes));
    let archive = dest.join("artifacts/source-and-receipts.tar.gz");
    assert!(Command::new("tar")
        .arg("-czf")
        .arg(&archive)
        .arg("-C")
        .arg(&r)
        .arg("--")
        .args(&members)
        .status()
        .unwrap()
        .success());
    let listing = Command::new("tar")
        .arg("-tzf")
        .arg(&archive)
        .output()
        .unwrap();
    assert!(listing.status.success());
    assert_eq!(
        String::from_utf8(listing.stdout)
            .unwrap()
            .lines()
            .map(str::to_owned)
            .collect::<Vec<_>>(),
        members
    );
    let extract = r.join("archive-review");
    fs::create_dir(&extract).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&extract)
        .status()
        .unwrap()
        .success());
    for (name, h) in &hashes {
        assert_eq!(&hash(extract.join(name)), h);
    }
    let mut report=String::from("# Signed radix-52 native qualification\n\nThe fixed native signed-difference multiplication passed the focused oracle and code-generation checks. It qualifies one prospective matched primitive timing screen. Production is unchanged, and no speedup has been measured.\n\nThe [exact arithmetic model](../2026-11-06-signed-pair52-model176/README.md) preceded this implementation. The isolated snapshot has 178 files: 174 original files unchanged, two recoverable parent edits (eight-lane selector/include and generator), and two new kernel/test children. The four-lane kernel and accepted field remain unchanged. No old core was linked to a changed field.\n\nFour new native tests compared **240,096 actual SIMD outputs and 240,096 exports against Arkworks**, covering Fq/Fr, R256/R260, ordinary/sum2/complement-difference2, normalized lazy inputs including 2p, boundaries, full-width random tuples and changing chains. Per field/radix: 14,884 boundary tuples, 4,096 random tuples, four padding tuples and 1,024 chain tuples, with three operations each. The chains have eight independently changing lanes over 128 steps. The 35 old tests were filtered; broader integration qualification is still required before adoption. All 16 primitive preflight cases matched accepted and fresh OFF controls.\n\nThe generator check and ten native build/test/preflight commands succeeded in one xtask attempt. Actual final caller command receipts contain O3/native/fat-LTO/one-CGU flags. A separate review verified 262 pins, eleven command receipts, all four test populations and 48 newly decoded optimized primitives, without repeating their execution. Accepted and fresh OFF have identical instruction text in all sixteen complete decoded function bodies; this is not a binary-file identity or timing calibration claim.\n\n## Generated code\n\nThe IFMA reduction survives optimization, but additional instructions and stack-addressed operations increase. Counts below cover the largest backward-branch span containing IFMAs, including conditional paths. They are static rows, not dynamic instructions, spill service time or an exclusive cycle attribution.\n\n| Fq/R256 loop | Accepted IFMA | Candidate IFMA | Accepted rows | Candidate rows | Accepted vector RSP/RBP operand rows | Candidate rows |\n|---|---:|---:|---:|---:|---:|---:|\n");
    for op in ["mul1", "mul4", "sum1", "diff1"] {
        let sym = format!("pair52_fq256_{op}");
        let rows = codegen["rows"].as_array().unwrap();
        let find = |role: &str| {
            rows.iter()
                .find(|x| x["role"] == role && x["symbol"] == sym)
                .unwrap()
        };
        let a = find("accepted");
        let c = find("ON");
        report.push_str(&format!(
            "| {op} | {} | {} | {} | {} | {} | {} |\n",
            a["loop_ifma"],
            c["loop_ifma"],
            a["loop_instruction_rows"],
            c["loop_instruction_rows"],
            a["loop_vector_rsp_rbp_operand_rows"],
            c["loop_vector_rsp_rbp_operand_rows"]
        ));
    }
    report.push_str("\nAll selected backedge spans have no calls. Candidate arithmetic signed shifts are present. The ordinary single-stream Fq/R256 function's explicit RSP subtraction grows from `0x328` (808 bytes) to `0x618` (1,560 bytes); this excludes other stack ownership and is not a measured live-stack peak or minimum RAM. Four-stream callers keep distinct states, but the compiler rolls the stream loop rather than holding four unrolled products simultaneously in registers; their listed IFMA count is one product body. Fused callers have fixed second-product inputs across iterations, allowing some preprocessing to move outside the loop. These are primitive screens, not complete G1/G2 callers. No layout/attribute sweep was used to change the generated code.\n\nThe initial snapshot helper stopped when it attempted to decode a binary fixture as UTF-8. It was repaired to copy files as bytes and decode only the two known textual edits, before any native build or execution. The partial snapshot and original helper/binary remain local; its source/failure summary and binary identity are preserved in the archive/review. The test build emitted nine unused-import warnings (eight inherited, one new); no warning-only rebuild was performed.\n\n## Scope and next stage\n\nThe extra arithmetic and register pressure may outweigh the saved IFMAs. Freeze one paired primitive protocol with the accepted field, fresh OFF and candidate before any clock; retain both fields, both radices and all declared contexts. A primitive win alone does not justify adoption: matched complete callers and verified all-eight plus merge54 full SDK trials, resource checks, portable fallbacks and independent Gnark verification remain necessary.\n\nThere is no new proof timing, AWS/Aeglos comparison, RSS peak, minimum-RAM, large-circuit or mobile result. No lookup table, key copy, execution plan or production thread pool is added. Accepted local32 1×2 remains **7.928660 ms**, merge54 **161.883899 ms**, and inherited RSS **132.75 MiB** is not a new measurement or minimum requirement. Proof ledger remains **30,846**. The complete inherited [eight-shape CPU and Metal comparison table](../2026-11-06-signed-pair52-model176/README.md#accepted-full-proof-baseline-inherited) is unchanged; the 10× CPU goal remains unmet for all eight shapes.\n\nEvidence: [codegen](artifacts/codegen.json), [review](artifacts/review.json), [source audit](artifacts/source-audit.json), [pins](artifacts/source-pins.json), [design](artifacts/design.md), [source and receipts](artifacts/source-and-receipts.tar.gz). The public archive includes only selected UTF-8 sources/deltas/receipts/decodes, with no executable, library, binary fixture, key, witness or proof blobs. The public mathematical fixture is preserved in the parent model archive rather than duplicated.\n");
    fs::write(dest.join("README.md"), report).unwrap();
    let mut checksums = BTreeMap::new();
    for file in [
        "README.md",
        "artifacts/review.json",
        "artifacts/codegen.json",
        "artifacts/source-audit.json",
        "artifacts/source-pins.json",
        "artifacts/design.md",
        "artifacts/archive-members.json",
        "artifacts/source-and-receipts.tar.gz",
    ] {
        checksums.insert(file, hash(dest.join(file)));
    }
    write(dest.join("checksums.json"), &json!(checksums));
    for (file, h) in &checksums {
        assert_eq!(&hash(dest.join(file)), h);
    }
    write(
        r.join("publication.json"),
        &json!({"status":"pass","files":9,"utf8_archive_members":members.len(),"roundtrip_hashes":hashes.len(),"archive_sha256":hash(&archive),"report":dest.join("README.md")}),
    );
    println!("qualification reviewed/published:11commands/240096native+240096exports/48decodes/{}archive members",members.len());
}
