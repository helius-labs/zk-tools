use std::{hint::black_box, time::Instant};
use zopro_bn254::{ifma8::Ifma8, Fp, FpConfig, FqConfig, FrConfig};

#[inline(always)]
fn kernel<C: FpConfig, const M: bool, const S: usize, const OP: usize>(
    rounds: u64,
    seed: u64,
) -> u64 {
    let mut state: [Ifma8<C, M>; S] = core::array::from_fn(|s| {
        Ifma8::new(&core::array::from_fn(|lane| {
            Fp::from(seed.wrapping_add((s * 43 + lane * 11 + 7) as u64))
        }))
    });
    let b: [Ifma8<C, M>; S] = core::array::from_fn(|s| {
        Ifma8::new(&core::array::from_fn(|lane| {
            Fp::from(
                seed.wrapping_mul(31)
                    .wrapping_add((s * 67 + lane * 13 + 19) as u64),
            )
        }))
    });
    let c: [Ifma8<C, M>; S] = core::array::from_fn(|s| {
        Ifma8::new(&core::array::from_fn(|lane| {
            Fp::from(
                seed.wrapping_mul(47)
                    .wrapping_add((s * 17 + lane * 23 + 29) as u64),
            )
        }))
    });
    let d: [Ifma8<C, M>; S] = core::array::from_fn(|s| {
        Ifma8::new(&core::array::from_fn(|lane| {
            Fp::from(
                seed.wrapping_mul(59)
                    .wrapping_add((s * 31 + lane * 29 + 41) as u64),
            )
        }))
    });
    for _ in 0..rounds {
        for s in 0..S {
            state[s] = match OP {
                0 => state[s].mul(&b[s]),
                1 => state[s].sum2(&b[s], &c[s], &d[s]),
                2 => state[s].difference2(&b[s], &c[s], &d[s]),
                _ => unreachable!(),
            };
        }
    }
    state
        .iter()
        .flat_map(|x| x.get())
        .flat_map(|x| x.0)
        .fold(0u64, |sum, x| sum.rotate_left(11) ^ x)
}
macro_rules! entry {
    ($name:ident,$c:ty,$m:literal,$s:literal,$op:literal) => {
        #[unsafe(no_mangle)]
        #[inline(never)]
        pub fn $name(rounds: u64, seed: u64) -> u64 {
            kernel::<$c, $m, $s, $op>(rounds, seed)
        }
    };
}
entry!(pair52_fq256_mul1, FqConfig, true, 1, 0);
entry!(pair52_fq256_mul4, FqConfig, true, 4, 0);
entry!(pair52_fq256_sum1, FqConfig, true, 1, 1);
entry!(pair52_fq256_diff1, FqConfig, true, 1, 2);
entry!(pair52_fr256_mul1, FrConfig, true, 1, 0);
entry!(pair52_fr256_mul4, FrConfig, true, 4, 0);
entry!(pair52_fr256_sum1, FrConfig, true, 1, 1);
entry!(pair52_fr256_diff1, FrConfig, true, 1, 2);
entry!(pair52_fq260_mul1, FqConfig, false, 1, 0);
entry!(pair52_fq260_mul4, FqConfig, false, 4, 0);
entry!(pair52_fq260_sum1, FqConfig, false, 1, 1);
entry!(pair52_fq260_diff1, FqConfig, false, 1, 2);
entry!(pair52_fr260_mul1, FrConfig, false, 1, 0);
entry!(pair52_fr260_mul4, FrConfig, false, 4, 0);
entry!(pair52_fr260_sum1, FrConfig, false, 1, 1);
entry!(pair52_fr260_diff1, FrConfig, false, 1, 2);
const CASES: [(&str, fn(u64, u64) -> u64, usize); 16] = [
    ("fq256_mul1", pair52_fq256_mul1, 1),
    ("fq256_mul4", pair52_fq256_mul4, 4),
    ("fq256_sum1", pair52_fq256_sum1, 1),
    ("fq256_diff1", pair52_fq256_diff1, 1),
    ("fr256_mul1", pair52_fr256_mul1, 1),
    ("fr256_mul4", pair52_fr256_mul4, 4),
    ("fr256_sum1", pair52_fr256_sum1, 1),
    ("fr256_diff1", pair52_fr256_diff1, 1),
    ("fq260_mul1", pair52_fq260_mul1, 1),
    ("fq260_mul4", pair52_fq260_mul4, 4),
    ("fq260_sum1", pair52_fq260_sum1, 1),
    ("fq260_diff1", pair52_fq260_diff1, 1),
    ("fr260_mul1", pair52_fr260_mul1, 1),
    ("fr260_mul4", pair52_fr260_mul4, 4),
    ("fr260_sum1", pair52_fr260_sum1, 1),
    ("fr260_diff1", pair52_fr260_diff1, 1),
];
fn main() {
    assert!(std::is_x86_feature_detected!("avx512ifma"));
    let args: Vec<_> = std::env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("preflight") => {
            for (name, run, _) in CASES {
                let out = run(1024, 0x19a4_783b_ee20_16d5);
                println!("PAIR52_PREFLIGHT {name} {out:016x}");
            }
        }
        Some("measure") => {
            assert_eq!(args.len(), 6);
            let case = &args[2];
            let n: u64 = args[3].parse().unwrap();
            let seed: u64 = args[4].parse().unwrap();
            let label = &args[5];
            let (_, run, streams) = CASES.iter().find(|(name, _, _)| *name == case).unwrap();
            let start = Instant::now();
            let out = black_box(run(black_box(n), black_box(seed)));
            let ns = start.elapsed().as_nanos();
            println!("{{\"case\":\"{case}\",\"label\":\"{label}\",\"rounds\":{n},\"streams\":{streams},\"elapsed_ns\":{ns},\"output\":\"{out:016x}\"}}");
        }
        _ => panic!("preflight | measure case rounds seed label"),
    }
}
