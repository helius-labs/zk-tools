use super::*;
use ark_ff::{Field, PrimeField};
use serde_json::Value;

fn decode(s: &str) -> [u64; 4] {
    assert!(s.len() <= 64);
    let mut out = [0u64; 4];
    let mut end = s.len();
    let mut j = 0;
    while end > 0 {
        let start = end.saturating_sub(16);
        out[j] = u64::from_str_radix(&s[start..end], 16).unwrap();
        end = start;
        j += 1;
    }
    out
}
fn numeric<A: PrimeField>(words: [u64; 4]) -> A {
    let mut bytes = [0u8; 32];
    for j in 0..4 {
        bytes[j * 8..j * 8 + 8].copy_from_slice(&words[j].to_le_bytes());
    }
    A::from_le_bytes_mod_order(&bytes)
}
fn pack<C: FpConfig, const MIXED: bool>(raw: [[u64; 4]; 8]) -> Ifma8<C, MIXED> {
    let columns: [[u64; 8]; 5] =
        core::array::from_fn(|j| core::array::from_fn(|lane| split(raw[lane])[j]));
    let vectors = columns.map(|column| unsafe { _mm512_loadu_si512(column.as_ptr().cast()) });
    Ifma8(vectors, PhantomData)
}
fn raw<C: FpConfig, const MIXED: bool>(value: &Ifma8<C, MIXED>) -> [[u64; 4]; 8] {
    let columns: [[u64; 8]; 5] = value.0.map(|v| unsafe { core::mem::transmute(v) });
    let two = crate::portable::add4(C::P, C::P).0;
    core::array::from_fn(|lane| {
        for j in 0..5 {
            assert!(columns[j][lane] <= MASK);
        }
        assert!(columns[4][lane] < (1u64 << 48));
        let t = core::array::from_fn::<_, 5, _>(|j| columns[j][lane]);
        let out = [
            t[0] | (t[1] << 52),
            (t[1] >> 12) | (t[2] << 40),
            (t[2] >> 24) | (t[3] << 28),
            (t[3] >> 36) | (t[4] << 16),
        ];
        assert!(crate::portable::less(out, two), "native lazy closure");
        out
    })
}
fn check<C: FpConfig, A: PrimeField, const MIXED: bool>(tag: &str) {
    assert!(cfg!(zopro_signed_pair52));
    let path = std::env::var("SIGNED_PAIR52_INPUTS").unwrap();
    let input: Value = serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
    let field = input["fields"]
        .as_array()
        .unwrap()
        .iter()
        .find(|f| f["tag"] == tag)
        .unwrap();
    let boundary: Vec<_> = field["boundary"]
        .as_array()
        .unwrap()
        .iter()
        .map(|v| decode(v.as_str().unwrap()))
        .collect();
    assert_eq!(boundary.len(), 122);
    let mut tuples = Vec::new();
    for (j, a) in boundary.iter().enumerate() {
        for (k, b) in boundary.iter().enumerate() {
            tuples.push([*a, *b, boundary[(j + 3) % 122], boundary[(k + 7) % 122]]);
        }
    }
    for row in field["random"].as_array().unwrap() {
        tuples.push(core::array::from_fn(|j| decode(row[j].as_str().unwrap())));
    }
    assert_eq!(tuples.len(), 18980);
    let bits = if MIXED { 256u64 } else { 260 };
    let inverse = A::from(2u64).pow([bits]).inverse().unwrap();
    let export_factor = if MIXED {
        A::ONE
    } else {
        A::from(16u64).inverse().unwrap()
    };
    let mut count = 0usize;
    let mut test = |chunk: [[[u64; 4]; 4]; 8]| {
        let inputs: [Ifma8<C, MIXED>; 4] =
            core::array::from_fn(|j| pack(core::array::from_fn(|lane| chunk[lane][j])));
        let outputs = [
            inputs[0].mul(&inputs[1]),
            inputs[0].sum2(&inputs[1], &inputs[2], &inputs[3]),
            inputs[0].difference2(&inputs[1], &inputs[2], &inputs[3]),
        ];
        let mut chain_raw = [[0u64; 4]; 8];
        for (mode, out) in outputs.iter().enumerate() {
            let words = raw(out);
            let exported = out.get();
            for lane in 0..8 {
                let [a, b, c, d] = chunk[lane].map(numeric::<A>);
                let expected = (match mode {
                    0 => a * b,
                    1 => a * b + c * d,
                    2 => a * b - c * d,
                    _ => unreachable!(),
                }) * inverse;
                assert_eq!(
                    numeric::<A>(words[lane]),
                    expected,
                    "raw {tag} R{bits} mode{mode} lane{lane}"
                );
                assert!(crate::portable::less(exported[lane].0, C::P));
                assert_eq!(
                    numeric::<A>(exported[lane].0),
                    expected * export_factor,
                    "export semantics"
                );
                count += 1;
            }
            if mode == 0 {
                chain_raw = words;
            }
        }
        chain_raw
    };
    for chunk in tuples.chunks(8) {
        test(core::array::from_fn(|lane| chunk[lane % chunk.len()]));
    }
    let mut chain = core::array::from_fn(|lane| boundary[(lane + 60) % 122]);
    let random = &field["random"];
    for round in 0..128 {
        let chunk = core::array::from_fn(|lane| {
            let row = &random[round * 8 + lane];
            [
                chain[lane],
                decode(row[1].as_str().unwrap()),
                decode(row[2].as_str().unwrap()),
                decode(row[3].as_str().unwrap()),
            ]
        });
        chain = test(chunk);
    }
    assert_eq!(count, 60024);
    println!("SIGNED_PAIR52_NATIVE_ORACLE field={tag} radix={bits} checks={count} boundary_tuples=14884 random=4096 boundary_padding=4 chain=1024 export_checks={count}");
}
#[test]
fn fq_mixed() {
    check::<crate::FqConfig, ark_ref::Fq, true>("Fq");
}
#[test]
fn fr_mixed() {
    check::<crate::FrConfig, ark_ref::Fr, true>("Fr");
}
#[test]
fn fq_uniform() {
    check::<crate::FqConfig, ark_ref::Fq, false>("Fq");
}
#[test]
fn fr_uniform() {
    check::<crate::FrConfig, ark_ref::Fr, false>("Fr");
}
