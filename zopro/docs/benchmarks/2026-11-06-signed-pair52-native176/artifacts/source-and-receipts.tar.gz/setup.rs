use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-native176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
const B: &str = "/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175";
const OLD: &str = "/home/ubuntu/src/zopro-perf-work/inverse-root-codec176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(name: &str, v: &Value) {
    fs::write(format!("{R}/{name}"), serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn replace_strings(v: &Value) -> Value {
    match v {
        Value::String(s) => json!(s.replace(OLD, R)),
        Value::Array(a) => json!(a.iter().map(replace_strings).collect::<Vec<_>>()),
        Value::Object(o) => json!(o
            .iter()
            .map(|(k, v)| (k.clone(), replace_strings(v)))
            .collect::<BTreeMap<_, _>>()),
        _ => v.clone(),
    }
}
fn main() {
    assert!(!Path::new(R).join("source").exists());
    let manifest=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let files = manifest["source_files_sha256"].as_object().unwrap();
    assert_eq!(files.len(), 176);
    let before = "            return self.product_cios::<FUSED>(b, c, d);";
    let after="            #[cfg(zopro_signed_pair52)]\n            return self.signed_pair_product::<FUSED>(b, c, d);\n            #[cfg(not(zopro_signed_pair52))]\n            return self.product_cios::<FUSED>(b, c, d);";
    let suffix = "\ninclude!(\"signed_pair52.rs\");\n";
    let gen_before="source = subprocess.check_output([\"rustfmt\", \"--emit\", \"stdout\", \"--edition\", \"2021\"], input=source, text=True)";
    let gen_after=format!("assert source.count({before:?}) == 1\nsource = source.replace({before:?}, {after:?})\nsource += '\\ninclude!(\"signed_pair52.rs\");\\n'\n{gen_before}");
    let mut pins = BTreeMap::new();
    let mut hashes = BTreeMap::new();
    let mut exact = 0;
    for (name, h) in files {
        let path = Path::new(Z).join(name);
        assert_eq!(hash(&path), h.as_str().unwrap());
        let original = fs::read(path).unwrap();
        let mut modified = original.clone();
        if name == "crates/zopro-bn254/src/ifma8.rs" {
            let mut text = String::from_utf8(modified).unwrap();
            assert_eq!(text.matches(before).count(), 1);
            text = text.replacen(before, after, 1);
            text.push_str(suffix);
            modified = text.into_bytes();
        }
        if name == "scripts/ifma8.py" {
            let text = String::from_utf8(modified).unwrap();
            assert_eq!(text.matches(gen_before).count(), 1);
            modified = text.replacen(gen_before, &gen_after, 1).into_bytes();
        }
        if modified == original {
            exact += 1;
        }
        let dest = Path::new(R).join("source").join(name);
        fs::create_dir_all(dest.parent().unwrap()).unwrap();
        fs::write(&dest, &modified).unwrap();
        let mut recovered = modified;
        if name == "crates/zopro-bn254/src/ifma8.rs" {
            assert!(recovered.ends_with(suffix.as_bytes()));
            recovered.truncate(recovered.len() - suffix.len());
            recovered = String::from_utf8(recovered)
                .unwrap()
                .replacen(after, before, 1)
                .into_bytes();
        }
        if name == "scripts/ifma8.py" {
            recovered = String::from_utf8(recovered)
                .unwrap()
                .replacen(&gen_after, gen_before, 1)
                .into_bytes();
        }
        assert_eq!(recovered, original, "recover {name}");
        hashes.insert(name.clone(), hash(&dest));
        pins.insert(dest.display().to_string(), hash(&dest));
    }
    assert_eq!(exact, 174);
    for child in ["signed_pair52.rs", "signed_pair52_tests.rs"] {
        let dest = format!("{R}/source/crates/zopro-bn254/src/{child}");
        fs::copy(format!("{R}/{child}"), &dest).unwrap();
        pins.insert(dest.clone(), hash(&dest));
        hashes.insert(format!("crates/zopro-bn254/src/{child}"), hash(&dest));
    }
    assert_eq!(hashes.len(), 178);
    for role in ["OFF", "ON"] {
        fs::create_dir_all(format!("{R}/field/{role}")).unwrap();
    }
    let oldplan = replace_strings(&read(format!("{OLD}/build-plan.json")));
    let oldsteps = oldplan["steps"].as_array().unwrap();
    let mut test = oldsteps
        .iter()
        .find(|s| s["name"] == "build-codec-tests")
        .unwrap()
        .clone();
    test["name"] = json!("build-signed-pair52-tests");
    let argv = test["argv"].as_array_mut().unwrap();
    argv.extend([json!("--cfg"),json!("zopro_signed_pair52"),json!("-L"),json!(format!("dependency={B}/frozen/candidate")),json!("--extern"),json!(format!("serde_json={B}/frozen/candidate/libserde_json-792a1ccfa9d7a509acedb3e992a9c8158d940f10c0b04abe034fe51f74e5811f.rlib"))]);
    let fixture = "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/inputs.json";
    test["environment"]["SIGNED_PAIR52_INPUTS"] = json!(fixture);
    let environment = test["environment"].clone();
    let mut steps = vec![
        json!({"kind":"command","name":"generator-check","argv":["/usr/bin/python3",format!("{R}/source/scripts/ifma8.py"),"--check"],"environment":environment,"timeout_seconds":120}),
        test,
    ];
    steps.push(json!({"kind":"command","name":"signed-pair52-tests","argv":[format!("{R}/field-tests"),"ifma8::signed_pair52_tests::","--nocapture","--test-threads=1"],"environment":environment,"timeout_seconds":300,
 "required_tests":["ifma8::signed_pair52_tests::fq_mixed","ifma8::signed_pair52_tests::fr_mixed","ifma8::signed_pair52_tests::fq_uniform","ifma8::signed_pair52_tests::fr_uniform"]}));
    for role in ["OFF", "ON"] {
        let mut step = oldsteps
            .iter()
            .find(|s| s["name"] == "field-library")
            .unwrap()
            .clone();
        step["name"] = json!(format!("field-{role}"));
        let args = step["argv"].as_array_mut().unwrap();
        let out = args.iter().position(|v| v == "-o").unwrap() + 1;
        args[out] = json!(format!("{R}/field/{role}/libzopro_bn254.rlib"));
        if role == "ON" {
            args.extend([json!("--cfg"), json!("zopro_signed_pair52")]);
        }
        steps.push(step);
    }
    let frozen = read(format!("{B}/frozen-candidate.json"));
    for (path, h) in frozen["input_pins"].as_object().unwrap() {
        assert_eq!(hash(path), h.as_str().unwrap());
        pins.insert(path.clone(), h.as_str().unwrap().to_owned());
    }
    let accepted=format!("{B}/frozen/candidate/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib");
    for (role, lib) in [
        ("accepted", accepted),
        ("OFF", format!("{R}/field/OFF/libzopro_bn254.rlib")),
        ("ON", format!("{R}/field/ON/libzopro_bn254.rlib")),
    ] {
        let argv = vec![
            "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc".to_owned(),
            "--edition=2021".into(),
            "--crate-name".into(),
            "signed_pair52_driver".into(),
            format!("{R}/driver.rs"),
            "-O".into(),
            "-C".into(),
            "target-cpu=native".into(),
            "-C".into(),
            "lto=fat".into(),
            "-C".into(),
            "codegen-units=1".into(),
            "-C".into(),
            "debuginfo=1".into(),
            "-L".into(),
            format!("dependency={B}/frozen/candidate"),
            "--extern".into(),
            format!("zopro_bn254={lib}"),
            "-o".into(),
            format!("{R}/driver-{role}"),
        ];
        steps.push(json!({"kind":"command","name":format!("driver-{role}"),"argv":argv,"environment":environment,"timeout_seconds":600}));
    }
    for role in ["accepted", "OFF", "ON"] {
        steps.push(json!({"kind":"command","name":format!("preflight-{role}"),"argv":[format!("{R}/driver-{role}"),"preflight"],"environment":environment,"timeout_seconds":120}));
    }
    // Pin all explicit external inputs and tools used by command steps.
    for step in &steps {
        for arg in step["argv"].as_array().unwrap() {
            let arg = arg.as_str().unwrap();
            let p = arg
                .split_once('=')
                .filter(|(k, _)| {
                    matches!(
                        *k,
                        "dependency"
                            | "ark_ref"
                            | "ark_ec"
                            | "ark_ff"
                            | "ark_std"
                            | "serde_json"
                            | "zopro_bn254"
                    )
                })
                .map(|(_, p)| p)
                .unwrap_or(arg);
            let path = Path::new(p);
            if path.is_file() {
                pins.insert(p.to_owned(), hash(path));
            }
        }
    }
    for p in [
        format!("{R}/setup.rs"),
        format!("{R}/setup"),
        format!("{R}/design.md"),
        format!("{R}/signed_pair52.rs"),
        format!("{R}/signed_pair52_tests.rs"),
        format!("{R}/driver.rs"),
        fixture.into(),
        "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/result.json".into(),
        "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/review.json".into(),
        "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustfmt".into(),
        "/home/ubuntu/src/zopro-perf-work/sdk-link-flags176/tool-target/release/xtask".into(),
    ] {
        pins.insert(p.clone(), hash(p));
    }
    save(
        "source-audit.json",
        &json!({"source_files":178,"exact_originals":174,"recoverable_originals":176,"hashes":hashes,"no_production_changes":true,"new_children":["signed_pair52.rs","signed_pair52_tests.rs"]}),
    );
    save("build-pins.json", &json!(pins));
    save(
        "build-plan.json",
        &json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"environment":{},"steps":steps}),
    );
    println!(
        "prepared178files/174exact/all176recoverable;{} commands,{} pins; no timing",
        steps.len(),
        pins.len()
    );
}
