// Experimental fixed signed-difference recipe. Bounds are in the model report.
#[cfg(zopro_signed_pair52)]
impl<C: FpConfig, const MIXED: bool> Ifma8<C, MIXED> {
    #[inline(always)]
    fn signed_pair_product<const FUSED: bool>(&self, b: &Self, c: &Self, d: &Self) -> Self {
        // SAFETY: module target enables AVX-512 IFMA/DQ/VL. Normalized inputs
        // in [0,2p] give signed coefficients within the separately proved bounds.
        unsafe {
            let zero = Self::splat(0);
            let mut lo = [zero; 5];
            let mut hi = [zero; 5];
            macro_rules! diagonal {
                ($j:literal) => {{
                    lo[$j] = _mm512_madd52lo_epu64(zero, self.0[$j], b.0[$j]);
                    hi[$j] = _mm512_madd52hi_epu64(zero, self.0[$j], b.0[$j]);
                    if FUSED {
                        lo[$j] = _mm512_madd52lo_epu64(lo[$j], c.0[$j], d.0[$j]);
                        hi[$j] = _mm512_madd52hi_epu64(hi[$j], c.0[$j], d.0[$j]);
                    }
                }};
            }
            diagonal!(0);
            diagonal!(1);
            diagonal!(2);
            diagonal!(3);
            diagonal!(4);
            let e = [
                lo[0],
                _mm512_add_epi64(lo[1], hi[0]),
                _mm512_add_epi64(lo[2], hi[1]),
                _mm512_add_epi64(lo[3], hi[2]),
                _mm512_add_epi64(lo[4], hi[3]),
                hi[4],
            ];
            let mut t = [zero; 10];
            t[0] = e[0];
            t[1] = _mm512_add_epi64(t[0], e[1]);
            t[2] = _mm512_add_epi64(t[1], e[2]);
            t[3] = _mm512_add_epi64(t[2], e[3]);
            t[4] = _mm512_add_epi64(t[3], e[4]);
            t[5] = _mm512_sub_epi64(_mm512_add_epi64(t[4], e[5]), e[0]);
            t[6] = _mm512_sub_epi64(t[5], e[1]);
            t[7] = _mm512_sub_epi64(t[6], e[2]);
            t[8] = _mm512_sub_epi64(t[7], e[3]);
            t[9] = e[5];
            macro_rules! pair {
                ($a:expr,$b:expr,$i:literal,$j:literal,$k:literal,$h:literal) => {{
                    let dx = _mm512_sub_epi64($a.0[$i], $a.0[$j]);
                    let dy = _mm512_sub_epi64($b.0[$j], $b.0[$i]);
                    let flip = _mm512_cmplt_epi64_mask(dx, zero);
                    let x = _mm512_abs_epi64(dx);
                    let y = _mm512_mask_sub_epi64(dy, flip, zero, dy);
                    let negative = _mm512_cmplt_epi64_mask(y, zero);
                    t[$k] = _mm512_madd52lo_epu64(t[$k], x, y);
                    t[$h] = _mm512_madd52hi_epu64(t[$h], x, y);
                    t[$h] = _mm512_mask_sub_epi64(t[$h], negative, t[$h], x);
                }};
            }
            macro_rules! crosses {
                ($a:expr,$b:expr) => {{
                    pair!($a, $b, 0, 1, 1, 2);
                    pair!($a, $b, 0, 2, 2, 3);
                    pair!($a, $b, 0, 3, 3, 4);
                    pair!($a, $b, 0, 4, 4, 5);
                    pair!($a, $b, 1, 2, 3, 4);
                    pair!($a, $b, 1, 3, 4, 5);
                    pair!($a, $b, 1, 4, 5, 6);
                    pair!($a, $b, 2, 3, 5, 6);
                    pair!($a, $b, 2, 4, 6, 7);
                    pair!($a, $b, 3, 4, 7, 8);
                }};
            }
            crosses!(self, b);
            if FUSED {
                crosses!(c, d);
            }
            let p = split(C::P).map(Self::splat);
            let mask = Self::splat(MASK);
            let inv = Self::splat(C::INV & MASK);
            macro_rules! row {
                ($i:literal,$n:literal,$n2:literal,$n3:literal,$n4:literal,$n5:literal) => {{
                    let q = _mm512_madd52lo_epu64(zero, t[$i], inv);
                    let ceil = _mm512_srai_epi64::<52>(_mm512_add_epi64(t[$i], mask));
                    let carry = _mm512_madd52hi_epu64(ceil, q, p[0]);
                    t[$n] = _mm512_madd52lo_epu64(t[$n], q, p[1]);
                    t[$n2] = _mm512_madd52hi_epu64(t[$n2], q, p[1]);
                    t[$n2] = _mm512_madd52lo_epu64(t[$n2], q, p[2]);
                    t[$n3] = _mm512_madd52hi_epu64(t[$n3], q, p[2]);
                    t[$n3] = _mm512_madd52lo_epu64(t[$n3], q, p[3]);
                    t[$n4] = _mm512_madd52hi_epu64(t[$n4], q, p[3]);
                    t[$n4] = _mm512_madd52lo_epu64(t[$n4], q, p[4]);
                    t[$n5] = _mm512_madd52hi_epu64(t[$n5], q, p[4]);
                    t[$n] = _mm512_add_epi64(t[$n], carry);
                }};
            }
            row!(0, 1, 2, 3, 4, 5);
            row!(1, 2, 3, 4, 5, 6);
            row!(2, 3, 4, 5, 6, 7);
            row!(3, 4, 5, 6, 7, 8);
            if MIXED {
                let mask48 = Self::splat((1u64 << 48) - 1);
                let q = _mm512_and_si512(_mm512_madd52lo_epu64(zero, t[4], inv), mask48);
                let ceil = _mm512_srai_epi64::<48>(_mm512_add_epi64(t[4], mask48));
                let carry = _mm512_madd52hi_epu64(ceil, _mm512_slli_epi64::<4>(q), p[0]);
                t[5] = _mm512_madd52lo_epu64(t[5], q, p[1]);
                t[6] = _mm512_madd52hi_epu64(t[6], q, p[1]);
                t[6] = _mm512_madd52lo_epu64(t[6], q, p[2]);
                t[7] = _mm512_madd52hi_epu64(t[7], q, p[2]);
                t[7] = _mm512_madd52lo_epu64(t[7], q, p[3]);
                t[8] = _mm512_madd52hi_epu64(t[8], q, p[3]);
                t[8] = _mm512_madd52lo_epu64(t[8], q, p[4]);
                t[9] = _mm512_madd52hi_epu64(t[9], q, p[4]);
                t[5] = _mm512_add_epi64(_mm512_slli_epi64::<4>(t[5]), carry);
                t[6] = _mm512_slli_epi64::<4>(t[6]);
                t[7] = _mm512_slli_epi64::<4>(t[7]);
                t[8] = _mm512_slli_epi64::<4>(t[8]);
                t[9] = _mm512_slli_epi64::<4>(t[9]);
            } else {
                row!(4, 5, 6, 7, 8, 9);
            }
            macro_rules! normalize {
                ($j:literal,$k:literal) => {{
                    t[$k] = _mm512_add_epi64(t[$k], _mm512_srai_epi64::<52>(t[$j]));
                    t[$j] = _mm512_and_si512(t[$j], mask);
                }};
            }
            normalize!(5, 6);
            normalize!(6, 7);
            normalize!(7, 8);
            normalize!(8, 9);
            let result = [t[5], t[6], t[7], t[8], t[9]];
            if FUSED && MIXED {
                Self::reduce_fused(result)
            } else {
                Self(result, PhantomData)
            }
        }
    }
}
#[cfg(test)]
mod signed_pair52_tests {
    include!("signed_pair52_tests.rs");
}
