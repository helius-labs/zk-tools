use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,os::unix::fs::FileTypeExt,path::{Path,PathBuf},process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-ternary-span176";
const D:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-07-g2-ternary-span176";
fn hash(p:&Path)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn collect(base:&Path,dir:&Path,prefix:&str,out:&mut BTreeMap<String,PathBuf>){
 let mut entries=fs::read_dir(dir).unwrap().map(|v|v.unwrap()).collect::<Vec<_>>();entries.sort_by_key(|v|v.file_name());
 for e in entries{assert!(!e.file_type().unwrap().is_symlink());let p=e.path();if e.file_type().unwrap().is_dir(){if !["source","target","target-driver","driver","publication-stage"].contains(&e.file_name().to_str().unwrap()){collect(base,&p,prefix,out);}continue}
  if !e.file_type().unwrap().is_file(){assert!(e.file_type().unwrap().is_fifo());continue}let name=e.file_name();let name=name.to_str().unwrap();let allowed=[".rs",".json",".log",".md",".csv",".txt",".toml",".lock",".events"].iter().any(|s|name.ends_with(s));if !allowed{continue}
  let relative=p.strip_prefix(base).unwrap().to_str().unwrap();assert!(!relative.starts_with('/')&&!relative.split('/').any(|s|s==".."));assert!(out.insert(format!("{prefix}/{relative}"),p).is_none());
 }
}
fn main(){
 let review:Value=serde_json::from_slice(&fs::read(format!("{R}/review.json")).unwrap()).unwrap();assert_eq!(review["passed"],true);assert_eq!(review["new_proofs"],0);assert_eq!(review["diagnostic_closed_no_observer_reroll"],true);
 let mut files=BTreeMap::new();collect(Path::new(R),Path::new(R),"trace",&mut files);
 let source_audit:Value=serde_json::from_slice(&fs::read(format!("{R}/source-audit.json")).unwrap()).unwrap();
 for v in source_audit["changed_parents"].as_array().unwrap(){let n=v.as_str().unwrap();assert!(!n.starts_with('/')&&!n.split('/').any(|v|v==".."));files.insert(format!("trace/source/{n}"),Path::new(R).join("source").join(n));}
 files.insert("trace/source/crates/zopro-core/src/service_trace.rs".into(),Path::new(R).join("source/crates/zopro-core/src/service_trace.rs"));
 for n in ["Cargo.toml","Cargo.lock","src/main.rs","src/perf_support.rs"]{files.insert(format!("trace/driver/{n}"),Path::new(R).join("driver").join(n));}
 let graphs:Value=serde_json::from_slice(&fs::read(format!("{R}/graphs.json")).unwrap()).unwrap();let pre:Value=serde_json::from_slice(&fs::read(format!("{R}/semantic-preflight.json")).unwrap()).unwrap();
 let expected=graphs.as_array().unwrap().iter().chain(pre["graphs"].as_array().unwrap()).map(|g|PathBuf::from(g["graph"]["path"].as_str().unwrap())).collect::<std::collections::BTreeSet<_>>();assert_eq!(expected.len(),120);
 let actual=files.values().filter(|p|p.extension().is_some_and(|e|e=="events")).cloned().collect::<std::collections::BTreeSet<_>>();assert_eq!(actual,expected);
 files.insert("report.md".into(),Path::new(D).join("README.md"));
 let stage=Path::new(R).join("publication-stage");assert!(!stage.exists());fs::create_dir(&stage).unwrap();let mut members=BTreeMap::new();
 for(name,src)in &files{let dst=stage.join(name);fs::create_dir_all(dst.parent().unwrap()).unwrap();fs::copy(src,&dst).unwrap();let h=hash(src);assert_eq!(hash(&dst),h);members.insert(name.clone(),h);}
 let artifacts=Path::new(D).join("artifacts");assert!(!artifacts.exists());fs::create_dir(&artifacts).unwrap();
 fs::write(artifacts.join("evidence-members.json"),serde_json::to_vec_pretty(&json!({"files":members,"members":members.len(),"excluded":"executables, libraries, targets, raw perf recordings, proving fixtures and private inputs"})).unwrap()).unwrap();
 let list=Path::new(R).join("publication-members.txt");assert!(!list.exists());fs::write(&list,members.keys().map(|s|format!("{s}\n")).collect::<String>()).unwrap();
 let archive=artifacts.join("evidence.tar.gz");assert!(Command::new("tar").args(["-czf"]).arg(&archive).arg("-C").arg(&stage).arg("--files-from").arg(&list).status().unwrap().success());
 let listing=Command::new("tar").arg("-tzf").arg(&archive).output().unwrap();assert!(listing.status.success());let actual=String::from_utf8(listing.stdout).unwrap();assert_eq!(actual,fs::read_to_string(&list).unwrap());
 assert!(Command::new("tar").arg("-dzf").arg(&archive).arg("-C").arg(&stage).status().unwrap().success());
 for(name,h)in &members{assert_eq!(hash(&stage.join(name)),*h);assert_eq!(hash(&files[name]),*h);}
 let checksum=format!("{}  evidence.tar.gz\n",hash(&archive));fs::write(artifacts.join("SHA256SUMS"),&checksum).unwrap();
 println!("PASS {} safe text members; exact tar member list, member hashes and single-pass archive comparison; {}",members.len(),checksum.trim());
}
