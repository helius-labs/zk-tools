
// Diagnostic adapter: the caller stays outside every Rayon worker.
pub fn reset_for_pool(pool: &rayon::ThreadPool, enabled: bool) {
    assert!(rayon::current_thread_index().is_none());
    ENABLED.store(false, Ordering::SeqCst);
    CLOCK.get_or_init(Instant::now);
    pool.broadcast(|_| clear());
    clear();
    API.store(0, Ordering::Relaxed);
    ORIGIN.store(CLOCK.get().unwrap().elapsed().as_nanos() as u64, Ordering::Relaxed);
    ENABLED.store(enabled, Ordering::SeqCst);
}
pub fn snapshot_for_pool(pool: &rayon::ThreadPool) -> Vec<(Vec<Event>, u64)> {
    assert!(rayon::current_thread_index().is_none());
    ENABLED.store(false, Ordering::SeqCst);
    let take = || {
        PARENT.with(|x| assert_eq!(x.get(), 0));
        (EVENTS.with(|v| v.borrow().clone()), DROPPED.with(Cell::get))
    };
    let mut all = pool.broadcast(|_| take());
    all.push(take());
    all
}
#[cfg(test)]
mod private_pool_tests {
    use super::*;
    #[test]
    fn private_pool_reset_snapshot_and_disabled_fidelity() {
        for workers in [1, 4] {
            let pool = rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512 * 1024).build().unwrap();
            for _ in 0..2 {
                reset_for_pool(&pool, true);
                {
                    let _api = api();
                    pool.install(|| {
                        let root = root(5, 123, 0);
                        let id = root.id();
                        rayon::broadcast(|context| {
                            let _part = scope(id, 14, context.index(), 0, false);
                            let _leaf = serial(25, 256, 0);
                            std::hint::black_box((0..4096u64).fold(0u64, |x, y| x.wrapping_add(std::hint::black_box(y))));
                        });
                    });
                }
                let snap = snapshot_for_pool(&pool);
                assert_eq!(snap.len(), workers + 1);
                assert!(snap.iter().all(|(_, drops)| *drops == 0));
                let events = snap.iter().flat_map(|(v, _)| v.iter()).collect::<Vec<_>>();
                assert_eq!(events.len(), 2 * workers + 2);
                let ids = events.iter().map(|e| e[0]).collect::<std::collections::BTreeSet<_>>();
                assert_eq!(ids.len(), events.len());
                assert_eq!(snap.last().unwrap().0.len(), 1);
                for event in &snap.last().unwrap().0 { assert_eq!(event[7], 0); }
                for (index, (records, _)) in snap[..workers].iter().enumerate() {
                    assert!(records.iter().all(|e| e[7] == index as u64 + 1));
                }
                for e in &events {
                    assert_eq!(e[0] >> 32, e[7]);
                    assert!(e[6] >= e[5]);
                    if e[1] != 0 {
                        let parent = events.iter().find(|p| p[0] == e[1]).unwrap();
                        assert!(parent[5] <= e[5] && e[6] <= parent[6]);
                    }
                    if e[2] == 25 { assert!(e[8] > 0 && e[9] >= e[8]); }
                }
            }
            reset_for_pool(&pool, false);
            { let _api = api(); pool.install(|| { let _root = root(5, 0, 0); }); }
            assert!(snapshot_for_pool(&pool).iter().all(|(v, d)| v.is_empty() && *d == 0));
        }
    }
}
