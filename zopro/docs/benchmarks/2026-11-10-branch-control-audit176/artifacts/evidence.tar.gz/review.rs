//! Separate raw reader; the previously qualified bootstrap code is shared.
include!("common.rs");
mod statistics;
fn close(a:&Value,b:&Value){match(a,b){
    (Value::Number(a),Value::Number(b))=>{let(a,b)=(a.as_f64().unwrap(),b.as_f64().unwrap());assert!((a-b).abs()<=8.*f64::EPSILON*a.abs().max(b.abs()).max(1.));},
    (Value::Array(a),Value::Array(b))=>{assert_eq!(a.len(),b.len());for(a,b)in a.iter().zip(b){close(a,b);}},
    (Value::Object(a),Value::Object(b))=>{assert_eq!(a.keys().collect::<Vec<_>>(),b.keys().collect::<Vec<_>>());for(k,v)in a{close(v,&b[k]);}},_=>assert_eq!(a,b)
}}
fn main(){
    let report=read(r("analysis.json"));let jobs=read(r("jobs.json"));let plan=read(r("plan.json"));
    assert_eq!(read(r("runs/result.json"))["status"],"complete");for s in plan["steps"].as_array().unwrap(){receipt(s);}
    let pins=read(r("pins.json"));for(p,h)in pins.as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
    let mut medians=BTreeMap::new();let mut summaries=BTreeMap::new();let mut count=0;
    for j in jobs.as_array().unwrap(){let name=j["name"].as_str().unwrap();let text=fs::read_to_string(r(format!("runs/{name}/stdout.log"))).unwrap();let mut values=vec![];
        for l in text.lines().filter(|l|l.starts_with("SAMPLE ")){let v:Value=serde_json::from_str(&l[7..]).unwrap();assert_eq!(v["round"],values.len());let n=v["max_worker_ns"].as_u64().unwrap()as f64/j["calls"].as_u64().unwrap()as f64;assert_eq!(n,v["ns_per_call"].as_f64().unwrap());assert!(n>0.&&n.is_finite());values.push(n);}
        assert_eq!(values.len()as u64,j["rounds"].as_u64().unwrap());count+=values.len();values.sort_by(f64::total_cmp);let median=values[values.len()/2];
        let row=report["rows"].as_array().unwrap().iter().find(|row|row["name"]==name).unwrap();assert_eq!(row["median_ns"].as_f64().unwrap(),median);
        let summary=text.lines().filter_map(|l|l.strip_prefix("SUMMARY ")).collect::<Vec<_>>();assert_eq!(summary.len(),1);let s:Value=serde_json::from_str(summary[0]).unwrap();assert_eq!(s["all_boolean_outputs_checked"],true);assert_eq!(s["workers"],1);close(&s,&row["summary"]);summaries.insert(name.to_owned(),s);medians.insert(name.to_owned(),median);
    }
    let series=|cell:&str|(0..15).map(|b|medians[&format!("latency-{cell}-b{b:02}")]).collect::<Vec<_>>();
    for(label,n,d)in[("default-OFF/REF","default-OFF","default-REF"),("fixed-OFF/REF","fixed-OFF","fixed-REF"),("REF-fixed/default","fixed-REF","default-REF"),("OFF-fixed/default","fixed-OFF","default-OFF")]{close(&statistics::contrast(&series(n),&series(d)),&report["contrasts"][label]);}
    let control=|layout:&str|series(&format!("{layout}-OFF")).into_iter().zip(series(&format!("{layout}-REF"))).map(|(o,r)|o/r).collect::<Vec<_>>();
    close(&statistics::contrast(&control("fixed"),&control("default")),&report["contrasts"]["interaction-fixed/default-control-ratio"]);
    let mut diagnostic_count=0;let mut mappings=BTreeMap::new();
    for j in jobs.as_array().unwrap().iter().filter(|j|["stat","cycles"].contains(&j["panel"].as_str().unwrap())){
        diagnostic_count+=1;let name=j["name"].as_str().unwrap();let d=report["diagnostics"].as_array().unwrap().iter().find(|d|d["name"]==name).unwrap();
        if j["panel"]=="stat"{let raw=fs::read_to_string(j["data"].as_str().unwrap()).unwrap();let mut events=0;let mut valid=true;
            for l in raw.lines().filter(|l|!l.trim().is_empty()&&!l.starts_with('#')){let f=l.split(';').collect::<Vec<_>>();let n=f[0].trim().parse::<f64>().unwrap();let runtime=f[3].trim().parse::<f64>().unwrap();let running=f[4].trim().parse::<f64>().unwrap();assert_eq!(n,d["events"][f[2].trim()]["count"].as_f64().unwrap());valid&=n.is_finite()&&n>=0.&&runtime.is_finite()&&runtime>0.&&running.is_finite()&&running>=99.9;events+=1;}
            assert_eq!(events,4);assert_eq!(d["qualified"],valid);
        }else{
            let s=&summaries[name];let pid=s["pid"].as_u64().unwrap();let worker=s["worker_rows"][0]["tid"].as_u64().unwrap();assert_ne!(pid,worker);
            let raw=fs::read_to_string(r(format!("runs/decode-{name}/stdout.log"))).unwrap();let mut samples=0;let mut unknown=0;let mut valid=true;
            for l in raw.lines().filter(|l|!l.trim().is_empty()&&!l.starts_with('#')){let f=l.split_ascii_whitespace().collect::<Vec<_>>();let(p,t)=f[0].split_once('/').unwrap();let p=p.parse::<u64>().unwrap();let t=t.parse::<u64>().unwrap();let cpu=f[1].trim_matches(['[',']']).parse::<u32>().unwrap();samples+=1;unknown+=usize::from(f[5].starts_with("[unknown]"));valid&=p==pid&&(t==pid||t==worker)&&cpu==2&&f[3]=="16000000";}
            assert_eq!(d["samples"],samples);assert_eq!(d["unknown_samples"],unknown);assert_eq!(d["sample_pid_tid_cpu_period_ok"],valid);
            let meta=fs::read_to_string(r(format!("runs/metadata-{name}/stdout.log"))).unwrap();let lines=meta.lines().filter(|l|l.contains("PERF_RECORD_MMAP")&&l.contains(j["binary"].as_str().unwrap())&&l.contains(": r-xp ")).collect::<Vec<_>>();assert!(!lines.is_empty());let mut starts=BTreeSet::new();for l in lines{assert_eq!(l.split_once('/').unwrap().0.parse::<u64>().unwrap(),pid);let address=l.split_once("[0x").unwrap().1.split_once('(').unwrap().0;starts.insert(u64::from_str_radix(address,16).unwrap());}assert_eq!(starts.len(),1);mappings.insert(j["cell"].as_str().unwrap().to_owned(),*starts.first().unwrap());
            assert_eq!(d["zero_lost"],read(r(format!("runs/loss-{name}/stdout.log")))["zero_lost"]);
        }
    }
    assert_eq!(diagnostic_count,8);close(&json!(mappings),&report["profile_executable_mmap_starts"]);
    // GNU objcopy supplies a second section extractor. An explicit output
    // prevents any mutation of the original ELF input.
    let old="/home/ubuntu/src/zopro-perf-work/seed-naf-callers176";
    for arm in ["REF","OFF"]{assert!(std::process::Command::new("objcopy").args(["--dump-section",&format!(".text={}",r(format!("review-{arm}.text")).display()),"--dump-section",&format!(".rodata={}",r(format!("review-{arm}.rodata")).display()),&format!("{old}/bench-{arm}"),&r(format!("review-copy-{arm}.elf")).display().to_string()]).status().unwrap().success());}
    for section in ["text","rodata"]{assert_eq!(fs::read(r(format!("review-REF.{section}"))).unwrap(),fs::read(r(format!("review-OFF.{section}"))).unwrap());}
    for arm in ["REF","OFF"]{let p=format!("{old}/bench-{arm}");assert_eq!(hash(&p),pins[p]);}
    save(r("review.json"),&json!({"passed":true,"same_agent_separate_raw_reader":true,"shared_qualified_bootstrap":true,"roundtrip_comparison_epsilon":8,"raw_processes":medians.len(),"raw_samples":count,"contrasts_reconstructed":5,"diagnostic_panels":diagnostic_count,"GNU_objcopy_independent_section_equality_confirmed":true,"original_ELF_inputs_unchanged":true,"production_changed":false,"proof_ledger_unchanged":47437}));
    println!("separate reader PASS:72processes/five contrasts/eight diagnostic panels/GNU text+rodata equality; no original binary changed");
}
