use std::{collections::BTreeMap,fs,path::{Path,PathBuf},process::Command};
use serde_json::{json,Value};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/branch-control-audit176";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/seed-naf-callers176";
const RC:&str="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
const DEP:&str="/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
fn r(s:&str)->PathBuf{Path::new(R).join(s)}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(s:&str,v:&Value){fs::write(r(s),serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn step(name:&str,args:Vec<String>)->Value{json!({"kind":"command","name":name,"argv":args,"environment":{},"timeout_seconds":600})}
fn add(steps:&mut Vec<Value>,jobs:&mut Vec<Value>,cell:&str,block:usize,panel:&str){
    let(layout,arm)=cell.split_once('-').unwrap();let name=format!("{panel}-{cell}-b{block:02}");let binary=format!("{OLD}/bench-{arm}");
    let(rounds,calls)=match panel{"pre"=>(1,128),"latency"|"stat"=>(31,1024),"cycles"=>(1,262144),_=>panic!()};
    let mut argv=vec![];let mut data=Value::Null;
    if ["stat","cycles"].contains(&panel){argv.extend(["sudo".into(),"-n".into(),"env".into(),format!("ZOPRO_BENCH_PERF_CTL={}",r("ctl").display()),format!("ZOPRO_BENCH_PERF_ACK={}",r("ack").display()),"perf".into()]);
        if panel=="stat"{data=json!(r(&format!("stat/{name}.csv")));argv.extend(["stat".into(),"--no-big-num".into(),"-x".into(),";".into(),"-e".into(),"{cycles:u,instructions:u,cache-misses:u,branch-misses:u}".into(),"-o".into(),data.as_str().unwrap().into()]);}
        else{data=json!(r(&format!("perf/{name}.data")));argv.extend(["record".into(),"--no-buildid-cache".into(),"--sample-cpu".into(),"--timestamp".into(),"-P".into(),"-e".into(),"cycles:u".into(),"-c".into(),"16000000".into(),"-m".into(),"512".into(),"-o".into(),data.as_str().unwrap().into()]);}
        argv.extend(["--delay=-1".into(),format!("--control=fifo:{},{}",r("ctl").display(),r("ack").display()),"--".into()]);}
    argv.extend(["taskset".into(),"-c".into(),"2".into()]);if layout=="fixed"{argv.extend(["setarch".into(),"x86_64".into(),"-R".into()]);}
    argv.extend([binary.clone(),format!("{OLD}/valid.bin"),"1".into(),rounds.to_string(),calls.to_string()]);
    steps.push(step(&name,argv));jobs.push(json!({"name":name,"cell":cell,"mapping":layout,"arm":arm,"block":block,"panel":panel,"workers":1,"population":"valid","binary":binary,"rounds":rounds,"calls":calls,"data":data}));
}
fn main(){
    let mode=std::env::args().nth(1).unwrap();
    if mode=="build" {
        assert!(!r("build-plan.json").exists());
        let prefix=fs::read_to_string(format!("{OLD}/analyze.rs")).unwrap();let prefix=prefix.split_once("\nfn main() {").unwrap().0;
        fs::write(r("analyze.rs"),format!("{prefix}\n{}",fs::read_to_string(r("analysis-main.rs")).unwrap())).unwrap();
        let common=fs::read_to_string(format!("{OLD}/common.rs")).unwrap().replace(OLD,R);fs::write(r("common.rs"),common).unwrap();
        fs::copy(format!("{OLD}/statistics.rs"),r("statistics.rs")).unwrap();
        let mut steps=vec![];let mut pins=BTreeMap::new();
        for name in ["analyze","review","loss"]{let mut argv=vec![RC.into(),"--edition=2021".into(),"-O".into(),r(&format!("{name}.rs")).display().to_string(),"-o".into(),r(name).display().to_string(),"-L".into(),format!("dependency={DEP}")];
            for(lib,file)in[("serde_json","libserde_json-cdebb9338c2784ad.rlib"),("sha2","libsha2-16b8f2c03bdf5faa.rlib"),("rustc_demangle","librustc_demangle-3e2a96f78b3a16e4.rlib")]{let p=format!("{DEP}/{file}");argv.extend(["--extern".into(),format!("{lib}={p}")]);pins.insert(p.clone(),hash(p));}steps.push(step(&format!("build-{name}"),argv));}
        for f in ["prepare.rs","prepare","common.rs","analyze.rs","analysis-main.rs","review.rs","loss.rs","statistics.rs","design.md","audit.rs","audit.json"] {pins.insert(r(f).display().to_string(),hash(r(f)));}
        for p in [RC,&format!("{OLD}/analyze.rs"),&format!("{OLD}/common.rs"),&format!("{OLD}/statistics.rs")] {pins.insert(p.to_owned(),hash(p));}
        save("build-pins.json",&json!(pins));save("build-plan.json",&json!({"version":1,"source_pins":r("build-pins.json"),"steps":steps}));println!("three reader/loss helper builds frozen; old benchmark binaries untouched");return;
    }
    assert_eq!(mode,"capture");assert!(!r("plan.json").exists());
    let status:Value=serde_json::from_slice(&fs::read(r("build-runs/result.json")).unwrap()).unwrap();assert_eq!(status["status"],"complete");
    let oldpins:Value=serde_json::from_slice(&fs::read(format!("{OLD}/capture-pins.json")).unwrap()).unwrap();
    let mut pins=BTreeMap::new();for f in ["bench-REF","bench-OFF","valid.bin","driver.rs","perf.rs"]{let p=format!("{OLD}/{f}");let h=hash(&p);assert_eq!(oldpins[&p],h);pins.insert(p,h);}
    let cells=["default-REF","default-OFF","fixed-REF","fixed-OFF"];let mut steps=vec![];let mut jobs=vec![];
    for cell in cells{add(&mut steps,&mut jobs,cell,0,"pre");}
    for b in 0..15{let mut order=cells;order.rotate_left(b%4);if b%2==1{order.reverse();}for cell in order{add(&mut steps,&mut jobs,cell,b,"latency");}}
    for dir in ["stat","perf"]{fs::create_dir(r(dir)).unwrap();}for fifo in ["ctl","ack"]{assert!(Command::new("mkfifo").args(["-m","600"]).arg(r(fifo)).status().unwrap().success());}
    for panel in ["stat","cycles"]{for cell in cells{add(&mut steps,&mut jobs,cell,0,panel);}}
    assert_eq!(jobs.len(),72);
    for j in jobs.iter().filter(|j|j["panel"]=="cycles"){let name=j["name"].as_str().unwrap();let data=j["data"].as_str().unwrap();
        steps.push(step(&format!("own-{name}"),vec!["sudo".into(),"-n".into(),"chown".into(),"ubuntu:ubuntu".into(),data.into()]));
        for(label,args)in[("events",vec!["perf","evlist","-v","-i",data]),("decode",vec!["perf","script","--ns","-i",data,"-F","pid,tid,cpu,time,period,ip,sym"]),("metadata",vec!["perf","script","--header","--show-mmap-events","--show-task-events","--ns","-i",data,"-F","pid,tid,cpu,time,period,ip,sym"])]{steps.push(step(&format!("{label}-{name}"),args.into_iter().map(str::to_owned).collect()));}
        steps.push(step(&format!("loss-{name}"),vec![r("loss").display().to_string(),data.into()]));}
    assert_eq!(steps.len(),92);save("jobs.json",&json!(jobs));
    for file in ["prepare.rs","prepare","common.rs","analyze.rs","analyze","analysis-main.rs","review.rs","review","loss.rs","loss","statistics.rs","design.md","audit.rs","audit.json","build-plan.json","build-pins.json","jobs.json"]{pins.insert(r(file).display().to_string(),hash(r(file)));}
    for p in ["/usr/bin/setarch","/usr/bin/taskset","/usr/bin/perf","/usr/bin/sudo","/home/ubuntu/src/zopro-perf-work/tool-target/release/xtask","/home/ubuntu/src/zopro-perf-work/compiler199-sdk176/proof-sha256-after-capture.json"]{pins.insert(p.to_owned(),hash(p));}
    save("pins.json",&json!(pins));save("plan.json",&json!({"version":1,"source_pins":r("pins.json"),"steps":steps}));println!("92commands frozen:4caller preflight+60latency+8diagnostic+20offline; original binaries reused; no clocks");
}
