//! Offline ELF comparison of already captured benchmark binaries; no executions.
use std::{collections::BTreeMap,fs,path::Path};
use sha2::{Digest,Sha256};
use serde_json::{json,Value};
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/branch-control-audit176";
const CAPTURE:&str="/home/ubuntu/src/zopro-perf-work/seed-naf-callers176";
fn h(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn u64at(b:&[u8],p:usize)->u64{u64::from_le_bytes(b[p..p+8].try_into().unwrap())}
fn u32at(b:&[u8],p:usize)->u32{u32::from_le_bytes(b[p..p+4].try_into().unwrap())}
fn u16at(b:&[u8],p:usize)->u16{u16::from_le_bytes(b[p..p+2].try_into().unwrap())}
#[derive(Debug)]struct Section {name:String,flags:u64,address:u64,offset:usize,size:usize}
fn sections(b:&[u8])->Vec<Section>{
    assert_eq!(&b[..7],b"\x7fELF\x02\x01\x01");assert_eq!(u16at(b,18),62);
    let offset=u64at(b,40) as usize;let size=u16at(b,58) as usize;let count=u16at(b,60) as usize;let strings=u16at(b,62) as usize;assert_eq!(size,64);
    let sh=offset+size*strings;let s=u64at(b,sh+24) as usize;let len=u64at(b,sh+32) as usize;let names=&b[s..s+len];
    (1..count).map(|i|{let p=offset+i*size;let n=u32at(b,p) as usize;let name=String::from_utf8(names[n..].iter().copied().take_while(|&x|x!=0).collect()).unwrap();Section{name,flags:u64at(b,p+8),address:u64at(b,p+16),offset:u64at(b,p+24) as usize,size:if u32at(b,p+4)==8{0}else{u64at(b,p+32) as usize}}}).collect()
}
fn main(){
    let refb=fs::read(format!("{CAPTURE}/bench-REF")).unwrap();let offb=fs::read(format!("{CAPTURE}/bench-OFF")).unwrap();
    let pins:Value=serde_json::from_slice(&fs::read(format!("{CAPTURE}/capture-pins.json")).unwrap()).unwrap();
    for(arm,bytes)in[("REF",&refb),("OFF",&offb)]{assert_eq!(h(bytes),pins[format!("{CAPTURE}/bench-{arm}")].as_str().unwrap());}
    let rs=sections(&refb);let os=sections(&offb);let mut rows=vec![];
    for a in &rs{let b=os.iter().find(|s|s.name==a.name).unwrap();if a.flags&2==0{continue;}
        let av=&refb[a.offset..a.offset+a.size];let bv=&offb[b.offset..b.offset+b.size];
        let differences=av.iter().zip(bv).enumerate().filter(|(_, (x,y))|x!=y).map(|(i,(x,y))|json!({"offset":i,"REF":x,"OFF":y})).collect::<Vec<_>>();
        rows.push(json!({"section":a.name,"flags":a.flags,"REF_address":a.address,"OFF_address":b.address,"REF_size":a.size,"OFF_size":b.size,"REF_sha256":h(av),"OFF_sha256":h(bv),"identical_bytes":av==bv,"different_overlapping_bytes":differences.len(),"first_differences":differences.into_iter().take(24).collect::<Vec<_>>()}));
    }
    let clean=|arm:&str|fs::read_to_string(format!("{CAPTURE}/subgroup-{arm}.asm")).unwrap().lines().filter(|l|!l.starts_with(CAPTURE)).collect::<Vec<_>>().join("\n");
    let same=clean("REF")==clean("OFF");assert!(same);
    let analysis:Value=serde_json::from_slice(&fs::read(format!("{CAPTURE}/analysis.json")).unwrap()).unwrap();
    let panels=analysis["diagnostics"].as_array().unwrap().iter().filter(|d|d["name"].as_str().unwrap().starts_with("stat-valid-w1-")).cloned().collect::<Vec<_>>();
    let mut segments=vec![];
    assert_eq!(u64at(&refb,32),u64at(&offb,32));assert_eq!(u16at(&refb,54),u16at(&offb,54));assert_eq!(u16at(&refb,56),u16at(&offb,56));
    let start=u64at(&refb,32)as usize;let size=u16at(&refb,54)as usize;
    for i in 0..u16at(&refb,56)as usize {let p=start+i*size;assert_eq!(&refb[p..p+size],&offb[p..p+size]);if u32at(&refb,p)!=1{continue;}
        let offset=u64at(&refb,p+8)as usize;let len=u64at(&refb,p+32)as usize;let a=&refb[offset..offset+len];let b=&offb[offset..offset+len];
        let differences=a.iter().zip(b).enumerate().filter(|(_, (x,y))|x!=y).map(|(i,(x,y))|json!({"file_offset":offset+i,"REF":x,"OFF":y})).collect::<Vec<_>>();
        segments.push(json!({"index":i,"offset":offset,"virtual_address":u64at(&refb,p+16),"size":len,"flags":u32at(&refb,p+4),"equal_bytes":a==b,"differences":differences}));
    }
    let r=json!({"passed":true,"offline_only":true,"performance_recaptured":false,"source_changed":false,"program_headers_identical":true,"load_segments":segments,"original_binary_identities_rechecked":true,"subgroup_disassembly_equal_after_only_path_header_removal":same,"allocated_sections":rows,"serial_counter_panels":panels,"causal_branch_identified":false,"production_changed":false});
    fs::write(Path::new(ROOT).join("audit.json"),serde_json::to_vec_pretty(&r).unwrap()).unwrap();
    for row in r["allocated_sections"].as_array().unwrap(){println!("{}",json!({"section":row["section"],"identical":row["identical_bytes"],"different_bytes":row["different_overlapping_bytes"],"sizes":[row["REF_size"],row["OFF_size"]]}));}
    let _=BTreeMap::<String,String>::new();
}
