use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{collections::{BTreeMap,BTreeSet},fs,io::Read,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/branch-control-audit176";
const Q:&str="/home/ubuntu/src/zopro-perf-work/seed-naf176";
const ARMS:[&str;3]=["REF","OFF","ON"];
fn r(p:impl AsRef<Path>)->PathBuf {Path::new(R).join(p)}
fn read(p:impl AsRef<Path>)->Value {serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn hash(p:impl AsRef<Path>)->String {let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop {let n=f.read(&mut b).unwrap();if n==0{break;}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn pin(pins:&mut BTreeMap<String,String>,p:impl AsRef<Path>){pins.insert(p.as_ref().display().to_string(),hash(p));}
fn receipt(s:&Value) {
    let folder=r(format!("runs/{}",s["name"].as_str().unwrap()));
    let exit=read(folder.join("exit.json")); assert_eq!(exit["success"],true);assert_eq!(exit["returncode"],0);
    let actual=read(folder.join("command.json"));assert_eq!(&actual["argv"].as_array().unwrap()[4..],s["argv"].as_array().unwrap());
    for (k,v) in s["environment"].as_object().unwrap() {assert_eq!(actual["environment"][k],*v);}
    for stream in ["stdout","stderr"] {assert_eq!(hash(folder.join(format!("{stream}.log"))),exit[format!("{stream}_sha256")]);}
}
