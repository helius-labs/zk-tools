include!("common.rs");
mod statistics;
fn output(j:&Value)->(f64,Value) {
    let text=fs::read_to_string(r(format!("runs/{}/stdout.log",j["name"].as_str().unwrap()))).unwrap();
    let mut samples=vec![];let mut summaries=vec![];
    for line in text.lines() {
        if let Some(raw)=line.strip_prefix("SAMPLE ") {
            let v:Value=serde_json::from_str(raw).unwrap();assert_eq!(v["round"],samples.len());
            let ns=v["ns_per_call"].as_f64().unwrap();assert!(ns.is_finite()&&ns>0.);
            assert!((ns-v["max_worker_ns"].as_u64().unwrap() as f64/j["calls"].as_u64().unwrap() as f64).abs()<1e-8);
            assert!(v["wave_ns"].as_u64().unwrap()>=v["max_worker_ns"].as_u64().unwrap());samples.push(ns);
        } else if let Some(raw)=line.strip_prefix("SUMMARY "){summaries.push(serde_json::from_str::<Value>(raw).unwrap());}
    }
    assert_eq!(samples.len() as u64,j["rounds"].as_u64().unwrap());assert_eq!(summaries.len(),1);
    let s=summaries.remove(0);assert_eq!(s["workers"],j["workers"]);assert_eq!(s["rounds"],j["rounds"]);assert_eq!(s["calls_per_worker_per_round"],j["calls"]);assert_eq!(s["priming"],3);assert_eq!(s["all_boolean_outputs_checked"],true);assert_eq!(s["fixture_points"],128);
    let mut tids=BTreeSet::new();let w=j["workers"].as_u64().unwrap();assert_eq!(s["worker_rows"].as_array().unwrap().len() as u64,w);
    for (i,row) in s["worker_rows"].as_array().unwrap().iter().enumerate(){assert_eq!(row["index"],i);assert!(tids.insert(row["tid"].as_u64().unwrap()));assert_eq!(row["initial_cpu"],if w==1{2}else{i});assert_eq!(row["final_cpu"],row["initial_cpu"]);}
    samples.sort_by(f64::total_cmp);(samples[samples.len()/2],s)
}
fn diagnostic(j:&Value,s:&Value)->Value {
    let name=j["name"].as_str().unwrap();
    if j["panel"]=="stat" {
        let mut events=BTreeMap::new();
        for l in fs::read_to_string(j["data"].as_str().unwrap()).unwrap().lines().filter(|l|!l.trim().is_empty()&&!l.starts_with('#')) {
            let f=l.split(';').collect::<Vec<_>>();assert!(f.len()>=5);
            let count=f[0].trim().parse::<f64>().unwrap();let runtime=f[3].trim().parse::<f64>().unwrap();let coverage=f[4].trim().parse::<f64>().unwrap();
            assert!(count.is_finite()&&count>=0.&&runtime.is_finite()&&runtime>0.&&coverage.is_finite());
            events.insert(f[2].trim().to_owned(),json!({"count":count,"runtime_ns":runtime,"running_percent":coverage,"qualified":coverage>=99.9}));
        }
        assert_eq!(events.keys().map(String::as_str).collect::<BTreeSet<_>>(),BTreeSet::from(["cycles:u","instructions:u","cache-misses:u","branch-misses:u"]));
        return json!({"name":name,"qualified":events.values().all(|v|v["qualified"]==true),"events":events});
    }
    let file=|kind:&str|fs::read_to_string(r(format!("runs/{kind}-{name}/stdout.log"))).unwrap();
    let events=file("events");let event_ok=events.lines().filter(|l|l.starts_with("cycles:u:")).all(|l|l.contains("{ sample_period, sample_freq }: 16000000")&&l.contains("exclude_kernel: 1"))&&events.lines().filter(|l|l.starts_with("cycles:u:")).count()==1;
    let loss:Value=serde_json::from_str(&file("loss")).unwrap();let pid=s["pid"].as_u64().unwrap();
    let mut tids=BTreeMap::from([(pid,None)]);for worker in s["worker_rows"].as_array().unwrap(){tids.insert(worker["tid"].as_u64().unwrap(),Some(worker["initial_cpu"].as_u64().unwrap()));}
    let meta=file("metadata");let owners=meta.lines().filter(|l|l.contains("PERF_RECORD_MMAP")&&l.contains(j["binary"].as_str().unwrap())).map(|l|l.split_whitespace().next().unwrap().split_once('/').unwrap().0.parse::<u64>().unwrap()).collect::<BTreeSet<_>>();
    let mut fork_tids=BTreeSet::from([pid]);for line in meta.lines(){if let Some((_,tail))=line.split_once("PERF_RECORD_FORK("){let child=tail.split_once(')').unwrap().0;let (p,t)=child.split_once(':').unwrap();if p.parse::<u64>().unwrap()==pid{fork_tids.insert(t.parse::<u64>().unwrap());}}}
    let ownership=owners==BTreeSet::from([pid])&&tids.keys().all(|tid|fork_tids.contains(tid));
    let mut samples=0;let mut unknown=0;let mut symbols=BTreeMap::<String,u64>::new();let mut sample_ok=true;
    for line in file("decode").lines().filter(|l|!l.trim().is_empty()&&!l.starts_with('#')){
        let f=line.split_whitespace().collect::<Vec<_>>();assert!(f.len()>=6);
        let (p,t)=f[0].split_once('/').unwrap();let (p,t)=(p.parse::<u64>().unwrap(),t.parse::<u64>().unwrap());
        let cpu=f[1].trim_matches(['[',']']).parse::<u64>().unwrap();let period=f[3].parse::<u64>().unwrap();let ip=u64::from_str_radix(f[4].trim_start_matches("0x"),16).unwrap();assert!(ip>0);
        let symbol=f[5..].join(" ");let symbol=rustc_demangle::try_demangle(&symbol).map(|s|format!("{s:#}")).unwrap_or(symbol);
        samples+=1;unknown+=usize::from(symbol.starts_with("[unknown]"));*symbols.entry(symbol).or_default()+=period;
        sample_ok&=p==pid&&period==16000000&&match tids.get(&t){Some(Some(expected))=>cpu==*expected,Some(None)=>if j["workers"]==1{cpu==2}else{cpu<32},None=>false};
    }
    let unknown_percent=100.*unknown as f64/samples.max(1) as f64;
    let mut ranked=symbols.into_iter().collect::<Vec<_>>();ranked.sort_by_key(|(_,v)|std::cmp::Reverse(*v));
    json!({"name":name,"qualified":event_ok&&ownership&&sample_ok&&loss["zero_lost"]==true&&samples>=1000&&unknown_percent<=5.,"samples":samples,"unknown_samples":unknown,"unknown_percent":unknown_percent,"event_ok":event_ok,"ownership":ownership,"sample_pid_tid_cpu_period_ok":sample_ok,"zero_lost":loss["zero_lost"],"top_symbols":ranked.into_iter().take(20).collect::<Vec<_>>()})
}
fn main(){
    assert_eq!(read(r("runs/result.json"))["status"],"complete");assert!(!r("analysis.json").exists());
    for(p,h)in read(r("pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
    let plan=read(r("plan.json"));for s in plan["steps"].as_array().unwrap(){receipt(s);}
    let jobs=read(r("jobs.json"));let mut rows=vec![];let mut diagnostics=vec![];let mut mappings=BTreeMap::new();
    for j in jobs.as_array().unwrap(){let(m,s)=output(j);let mut row=j.clone();row["median_ns"]=m.into();row["summary"]=s.clone();rows.push(row);
        if ["stat","cycles"].contains(&j["panel"].as_str().unwrap()){diagnostics.push(diagnostic(j,&s));}
        if j["panel"]=="cycles"{let name=j["name"].as_str().unwrap();let meta=fs::read_to_string(r(format!("runs/metadata-{name}/stdout.log"))).unwrap();let starts=meta.lines().filter(|l|l.contains("PERF_RECORD_MMAP")&&l.contains(j["binary"].as_str().unwrap())&&l.contains(": r-xp ")).map(|l|{let tail=l.split_once(": [").unwrap().1;u64::from_str_radix(tail.split_once('(').unwrap().0.trim_start_matches("0x"),16).unwrap()}).collect::<BTreeSet<_>>();assert_eq!(starts.len(),1);mappings.insert(j["cell"].as_str().unwrap().to_owned(),*starts.first().unwrap());}
    }
    let mut series=BTreeMap::new();
    for cell in ["default-REF","default-OFF","fixed-REF","fixed-OFF"]{let values=(0..15).map(|b|rows.iter().find(|j|j["panel"]=="latency"&&j["cell"]==cell&&j["block"]==b).unwrap()["median_ns"].as_f64().unwrap()).collect::<Vec<_>>();series.insert(cell.to_owned(),values);}
    let mut contrasts=BTreeMap::new();
    for(label,n,d)in[("default-OFF/REF","default-OFF","default-REF"),("fixed-OFF/REF","fixed-OFF","fixed-REF"),("REF-fixed/default","fixed-REF","default-REF"),("OFF-fixed/default","fixed-OFF","default-OFF")] {contrasts.insert(label.to_owned(),statistics::contrast(&series[n],&series[d]));}
    let ratios=|layout:&str|(0..15).map(|b|series[&format!("{layout}-OFF")][b]/series[&format!("{layout}-REF")][b]).collect::<Vec<_>>();
    contrasts.insert("interaction-fixed/default-control-ratio".into(),statistics::contrast(&ratios("fixed"),&ratios("default")));
    let fixed_mapping_equal=mappings["fixed-REF"]==mappings["fixed-OFF"];
    let qualified=diagnostics.iter().all(|d|d["qualified"]==true)&&fixed_mapping_equal;
    save(r("analysis.json"),&json!({"diagnostic_qualified":qualified,"production_changed":false,"new_proof_speedup_measured":false,"rows":rows,"diagnostics":diagnostics,"series":series,"contrasts":contrasts,"profile_executable_mmap_starts":mappings,"fixed_profile_mmap_starts_equal":fixed_mapping_equal,"causal_branch_identified":false,"canonical_proofs_unchanged":47437}));
    println!("runtime-layout diagnostic qualified={qualified}; four cells, five declared contrasts; no arithmetic candidate/adoption");
}
