# Retained component CPU samples

Exactunmodified184source-fixed testbinary,primary1x2+2x2at32fixedworkers,
existingparallel_route_screen includescurrent/serial/parallel threeprimesand9
rotatedblocks percase. NoCPUlatencyrescueorparameterchange; collect wholecomponent
cycles includingcoldtablebuild toidentifyhotfunctions/instructions. Setupcannot
be mistaken forquerywork; reportinclusive scope andinspect reducer-specificIPs.
Noexclusivewalltimeclaimfromsamplecount. This isnot a proofbenchmark.

Threeplain/profileprocesspairs,reverseoddblocks. Profilercycles:u fixed16million
period,CPU/timestamp/period/IP/symbol,512pages,zerolost,>=1000samples/capture,
unknown<=5%,PID/MMAPownershipchecks. Wholeprocessandper-case/arm sumoftimedquery
profile/plainmedian3ratiosmustfall[1/1.05,1.05]beforecallingprofilesrepresentative
ofthiscomponent. Noextension/droppedcapture/relaxedguard. Decodeonlyafterallruns.
No phaseobserver, buildsoranalysisduringcapture. Eachprocessselfchecks all outputs
againstretainedindependentMSMoracle,3arms*2cases*(3primes+9timed)=72componentqueries,
6processes432queries. No newproofs,canonical56585same. NoAWS/production/push.
