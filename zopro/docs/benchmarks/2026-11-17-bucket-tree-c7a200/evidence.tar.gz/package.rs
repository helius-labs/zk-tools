use std::{fs,path::Path,process::Command};use serde_json::{Value,json};use sha2::{Sha256,Digest};
const R:&str="/home/ubuntu/src/zopro-perf-work/bucket-tree-c7a200";
fn main(){let r=Path::new(R);let plan:Value=serde_json::from_slice(&fs::read(r.join("build-plan.json")).unwrap()).unwrap();
 let binary=r.join("target/release/deps/zopro_core-640443eaff307a1d");assert!(binary.is_file());let bundle=r.join("bundle");fs::create_dir(&bundle).unwrap();fs::create_dir(bundle.join("inputs")).unwrap();
 for(src,dst)in[(binary.clone(),r.join("bundle/bench")),(r.join("runner"),bundle.join("runner")),(Path::new("/home/ubuntu/src/zk-tools/zopro/xtask/target/release/xtask").into(),bundle.join("xtask")),(r.join("build-plan.json"),bundle.join("build-plan.json")),(r.join("protocol.md"),bundle.join("protocol.md"))]{fs::copy(src,dst).unwrap();}
 for shape in["1x2","2x2"]{fs::copy(format!("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/inputs/{shape}.b2q"),bundle.join(format!("inputs/{shape}.b2q"))).unwrap();}
 let mut steps=vec![];for arm in 0..2{let mut env=plan["environment"].clone();for(k,v)in[("SHIFTED_WORKERS","32".to_owned()),("SHIFTED_ARM",arm.to_string()),("SHIFTED_ROUNDS","1".into()),("SHIFTED_SHAPE","1x2".into())]{env[k]=json!(v);}steps.push(json!({"kind":"command","name":format!("local-a{arm}"),"argv":[binary.to_str().unwrap(),"--exact","msm_affine::g2_phi::c7a_tests::c7a_screen","--ignored","--nocapture","--test-threads=1"],"environment":env,"timeout_seconds":300,"required_tests":["msm_affine::g2_phi::c7a_tests::c7a_screen"]}));}
 fs::write(r.join("local-plan.json"),serde_json::to_vec_pretty(&json!({"version":1,"source_pins":format!("{R}/source/.xtask/source-pins.json"),"steps":steps})).unwrap()).unwrap();
 let status=Command::new("tar").args(["-czf"]).arg(r.join("bundle.tar.gz")).arg("-C").arg(&bundle).arg(".").status().unwrap();assert!(status.success());
 let mut hashes=serde_json::Map::new();for p in[bundle.join("bench"),bundle.join("runner"),bundle.join("xtask"),bundle.join("inputs/1x2.b2q"),bundle.join("inputs/2x2.b2q"),r.join("bundle.tar.gz")]{hashes.insert(p.to_str().unwrap().into(),json!(format!("{:x}",Sha256::digest(fs::read(p).unwrap()))));}
 fs::write(r.join("package-hashes.json"),serde_json::to_vec_pretty(&hashes).unwrap()).unwrap();println!("Frozen bundle and local preflight ready");
}
