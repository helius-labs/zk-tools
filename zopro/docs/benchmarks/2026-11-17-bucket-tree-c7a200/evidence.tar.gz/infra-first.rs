use std::{fs,path::Path};
fn main(){let r=Path::new("/home/ubuntu/src/zopro-perf-work/bucket-tree-c7a200");let old=Path::new("/home/ubuntu/src/zopro-perf-work/shifted-c7a197");
for f in["runner-v2.rs","package.rs","cloud.rs"]{let mut s=fs::read_to_string(old.join(f)).unwrap().replace("shifted-c7a197","bucket-tree-c7a200").replace("shift197","tree200").replace("msm_affine::server_shifted::tests::c7a_screen","msm_affine::g2_phi::c7a_tests::c7a_screen");
if f=="cloud.rs"{s=s.replace("/home/ubuntu/src/zopro-perf-work/fused-preparation-c7a182/sigv4.rs","/home/ubuntu/src/zopro-perf-work/fused-preparation-c7a182/sigv4.rs");s=s.replace("/bench2 /var/tmp/bucket-tree-c7a200/runner-v2 >","/bench2 /var/tmp/bucket-tree-c7a200/runner >");s=s.replace("assert_eq!(list[\"KeyCount\"],0);","assert_eq!(list[\"KeyCount\"].as_u64().unwrap_or(0),0);");}
let name=if f=="runner-v2.rs"{"runner.rs"}else{f};fs::write(r.join(name),s).unwrap();}
println!("Reused197 runner (source_pins repair included), package and constrained cloud lifecycle; isolated paths");}
