use std::{fs,path::Path};use serde_json::{Value,json};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/bucket-tree-c7a200";
fn change(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1);}
fn main(){let prod=Path::new("/home/ubuntu/src/zk-tools/zopro");let r=Path::new(R);let m:Value=serde_json::from_slice(&fs::read(prod.join("docs/benchmarks/2026-11-17-certified-all196/artifacts/production-source-manifest.json")).unwrap()).unwrap();let files=m["source_files_sha256"].as_object().unwrap();assert_eq!(files.len(),179);for(p,h)in files{assert_eq!(format!("{:x}",Sha256::digest(fs::read(prod.join(p)).unwrap())),h.as_str().unwrap());}fs::write(r.join("manifest.json"),serde_json::to_vec_pretty(&json!({"source_files_sha256":files})).unwrap()).unwrap();
let out=r.join("overlay/crates/zopro-core/src/msm_affine");let mut s=fs::read_to_string(prod.join("crates/zopro-core/src/msm_affine/g2_phi.rs")).unwrap();
change(&mut s,"fn hb_window(bases: &[G2Affine], short: &[[u64; 4]], w: usize, bits: usize)","fn hb_window(bases: &[G2Affine], short: &[[u64; 4]], w: usize, bits: usize, tree: bool)");
change(&mut s,"    #[cfg(all(zopro_g2_horner_buckets","    if tree && bits == 12 { return staged_tree::window(bases,short,w); }\n    #[cfg(all(zopro_g2_horner_buckets");
change(&mut s,"fn hb_raw(bases: &[G2Affine], short: &mut [[u64; 4]], bits: usize, parts: usize)","fn hb_raw_mode(bases: &[G2Affine], short: &mut [[u64; 4]], bits: usize, parts: usize, tree: bool)");
change(&mut s,"hb_window(&bases[start..end], &short[start..end], w, bits)","hb_window(&bases[start..end], &short[start..end], w, bits, tree)");
s.push_str(r#"
mod staged_tree;
static CALLS:[std::sync::atomic::AtomicUsize;2]=[const{std::sync::atomic::AtomicUsize::new(0)};2];
fn selected()->usize {static MODE:std::sync::OnceLock<usize>=std::sync::OnceLock::new();*MODE.get_or_init(||{let n=std::env::var("SHIFTED_ARM").unwrap_or("0".into()).parse().unwrap();assert!(n<2);n})}
fn hb_raw(bases:&[G2Affine],words:&mut[[u64;4]],bits:usize,parts:usize)->G2Projective{
 let hold=if selected()==1&&bits==12&&parts==2{staged_tree::admit(bases.len())}else{None};
 let mode=usize::from(hold.is_some());CALLS[mode].fetch_add(1,std::sync::atomic::Ordering::Relaxed);
 hb_raw_mode(bases,words,bits,parts,mode==1)
}
#[cfg(test)] mod c7a_tests;
"#);fs::write(out.join("g2_phi.rs"),s).unwrap();fs::copy("/home/ubuntu/src/zopro-perf-work/bucket-round178/source/crates/zopro-core/src/msm_affine/g2_phi/staged_tree.rs",out.join("g2_phi/staged_tree.rs")).unwrap();fs::copy(r.join("tests.rs"),out.join("g2_phi/c7a_tests.rs")).unwrap();
let mut plan:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zopro-perf-work/g2-central-equality198/build-plan.json").unwrap()).unwrap();plan=serde_json::from_str(&serde_json::to_string(&plan).unwrap().replace("g2-central-equality198","bucket-tree-c7a200")).unwrap();let flags=plan["environment"]["RUSTFLAGS"].as_str().unwrap().to_owned()+" --cfg zopro_borrowed_bucket_tree --check-cfg=cfg(zopro_borrowed_bucket_tree)";plan["environment"]["RUSTFLAGS"]=json!(flags);plan["environment"].as_object_mut().unwrap().remove("ZOPRO_DIAGNOSTIC_G2_CENTRAL_EQUALITY");let a=plan["steps"][0]["argv"].as_array_mut().unwrap();let pos=a.iter().position(|v|v=="g2_borrowed").unwrap();a[pos]=json!("g2_phi::c7a_tests");plan["steps"][0]["required_tests"]=json!(["msm_affine::g2_phi::c7a_tests::complete_queries","msm_affine::g2_phi::c7a_tests::exceptions_and_admission"]);fs::write(r.join("build-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();println!("Prepared exact179 baseline plus one reversible parent and exact historical tree");}
