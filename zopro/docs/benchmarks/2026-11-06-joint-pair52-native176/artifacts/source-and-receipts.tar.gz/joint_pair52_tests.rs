use super::*;
use ark_ff::PrimeField;
use serde_json::Value;
fn decode(s: &str) -> [u64; 4] {
    let mut out = [0u64; 4];
    let mut end = s.len();
    let mut j = 0;
    while end > 0 {
        let start = end.saturating_sub(16);
        out[j] = u64::from_str_radix(&s[start..end], 16).unwrap();
        end = start;
        j += 1;
    }
    out
}
fn numeric<A: PrimeField>(x: [u64; 4]) -> A {
    let mut bytes = [0u8; 32];
    for j in 0..4 {
        bytes[j * 8..j * 8 + 8].copy_from_slice(&x[j].to_le_bytes());
    }
    A::from_le_bytes_mod_order(&bytes)
}
fn pack<C: FpConfig, const M: bool>(x: [[u64; 4]; 8]) -> Ifma8<C, M> {
    let columns: [[u64; 8]; 5] =
        core::array::from_fn(|j| core::array::from_fn(|lane| split(x[lane])[j]));
    Ifma8(
        columns.map(|c| unsafe { _mm512_loadu_si512(c.as_ptr().cast()) }),
        PhantomData,
    )
}
fn raw<C: FpConfig, const M: bool>(x: &Ifma8<C, M>) -> [[u64; 4]; 8] {
    let cols: [[u64; 8]; 5] = x.0.map(|v| unsafe { core::mem::transmute(v) });
    let two = crate::portable::add4(C::P, C::P).0;
    core::array::from_fn(|lane| {
        let t: [u64; 5] = core::array::from_fn(|j| {
            assert!(cols[j][lane] <= MASK);
            cols[j][lane]
        });
        assert!(t[4] < 1u64 << 48);
        let out = [
            t[0] | t[1] << 52,
            t[1] >> 12 | t[2] << 40,
            t[2] >> 24 | t[3] << 28,
            t[3] >> 36 | t[4] << 16,
        ];
        assert!(crate::portable::less(out, two));
        out
    })
}
fn check<C: FpConfig, A: PrimeField, const M: bool>(tag: &str) {
    assert!(cfg!(zopro_joint_pair52_complex));
    let path = std::env::var("JOINT_PAIR52_INPUTS").unwrap();
    let input: Value = serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
    let field = input["fields"]
        .as_array()
        .unwrap()
        .iter()
        .find(|f| f["tag"] == tag)
        .unwrap();
    let boundary: Vec<_> = field["boundary"]
        .as_array()
        .unwrap()
        .iter()
        .map(|v| decode(v.as_str().unwrap()))
        .collect();
    assert_eq!(boundary.len(), 122);
    let mut tuples = Vec::new();
    for (j, a) in boundary.iter().enumerate() {
        for (k, b) in boundary.iter().enumerate() {
            tuples.push([*a, *b, boundary[(j + 3) % 122], boundary[(k + 7) % 122]]);
        }
    }
    for row in field["random"].as_array().unwrap() {
        tuples.push(core::array::from_fn(|j| decode(row[j].as_str().unwrap())));
    }
    let two = crate::portable::add4(C::P, C::P).0;
    let edges = [
        [0; 4],
        [1, 0, 0, 0],
        crate::portable::sub4(two, [1, 0, 0, 0]).0,
        two,
    ];
    for a in edges {
        for b in edges {
            for c in edges {
                for d in edges {
                    tuples.push([a, b, c, d]);
                }
            }
        }
    }
    assert_eq!(tuples.len(), 19236);
    let bits = if M { 256u64 } else { 260 };
    let inverse = A::from(2u64).pow([bits]).inverse().unwrap();
    let export_factor = if M {
        A::ONE
    } else {
        A::from(16u64).inverse().unwrap()
    };
    let mut count = 0;
    let mut check_batch = |chunk: [[[u64; 4]; 4]; 8]| {
        let inputs: [Ifma8<C, M>; 4] =
            core::array::from_fn(|j| pack(core::array::from_fn(|lane| chunk[lane][j])));
        let normal = inputs[0].joint_pair52_complex::<false>(&inputs[1], &inputs[2], &inputs[3]);
        let conjugate = inputs[0].joint_pair52_complex::<true>(&inputs[1], &inputs[2], &inputs[3]);
        let mut chain = [[[0u64; 4]; 2]; 8];
        for (mode, outputs) in [normal, conjugate].into_iter().enumerate() {
            for (component, out) in outputs.iter().enumerate() {
                let words = raw(out);
                let exported = out.get();
                for lane in 0..8 {
                    let [a0, a1, b0, b1] = chunk[lane].map(numeric::<A>);
                    let want = match (mode, component) {
                        (0, 0) => a0 * b0 - a1 * b1,
                        (0, 1) => a0 * b1 + a1 * b0,
                        (1, 0) => a0 * b0 + a1 * b1,
                        (1, 1) => a1 * b0 - a0 * b1,
                        _ => unreachable!(),
                    } * inverse;
                    assert_eq!(
                        numeric::<A>(words[lane]),
                        want,
                        "raw {tag}/R{bits}/mode{mode}/component{component}"
                    );
                    assert!(crate::portable::less(exported[lane].0, C::P));
                    assert_eq!(
                        numeric::<A>(exported[lane].0),
                        want * export_factor,
                        "export"
                    );
                    count += 1;
                    if mode == 0 {
                        chain[lane][component] = words[lane];
                    }
                }
            }
        }
        chain
    };
    for chunk in tuples.chunks(8) {
        check_batch(core::array::from_fn(|lane| chunk[lane % chunk.len()]));
    }
    let mut chain =
        core::array::from_fn(|lane| [boundary[(lane + 60) % 122], boundary[(lane + 70) % 122]]);
    for step in 0..128 {
        let chunk = core::array::from_fn(|lane| {
            let row = &field["random"][step * 8 + lane];
            [
                chain[lane][0],
                chain[lane][1],
                decode(row[2].as_str().unwrap()),
                decode(row[3].as_str().unwrap()),
            ]
        });
        chain = check_batch(chunk);
    }
    assert_eq!(count, 81056);
    println!("JOINT_PAIR52_NATIVE field={tag} radix={bits} outputs={count} exports={count} boundary=14884 random=4096 endpoint=256 padding=4 chain=1024 normal+conjugate");
}
#[test]
fn fq_mixed() {
    check::<crate::FqConfig, ark_ref::Fq, true>("Fq");
}
#[test]
fn fr_mixed() {
    check::<crate::FrConfig, ark_ref::Fr, true>("Fr");
}
#[test]
fn fq_uniform() {
    check::<crate::FqConfig, ark_ref::Fq, false>("Fq");
}
#[test]
fn fr_uniform() {
    check::<crate::FrConfig, ark_ref::Fr, false>("Fr");
}
