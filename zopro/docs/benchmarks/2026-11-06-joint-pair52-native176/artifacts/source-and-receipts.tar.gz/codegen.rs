use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const R: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-native176";
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn main() {
    assert_eq!(read(format!("{R}/build/result.json"))["status"], "complete");
    assert!(!Path::new(R).join("codegen.json").exists());
    let mut pins = read(format!("{R}/build-pins.json"))
        .as_object()
        .unwrap()
        .clone();
    for (p, h) in &pins {
        assert_eq!(hash(p), h.as_str().unwrap(), "{p}");
    }
    for p in [
        format!("{R}/codegen.rs"),
        format!("{R}/codegen"),
        "/usr/bin/objdump".into(),
    ] {
        pins.insert(p.clone(), json!(hash(p)));
    }
    let mut identities = BTreeMap::new();
    for role in ["accepted", "OFF", "ON"] {
        let path = format!("{R}/driver-{role}");
        pins.insert(path.clone(), json!(hash(&path)));
        identities.insert(role, json!({"binary":path,"sha256":hash(&path)}));
        let command = read(format!("{R}/build/driver-{role}/command.json"));
        let argv = command["argv"].as_array().unwrap();
        for flag in ["-O", "target-cpu=native", "lto=fat", "codegen-units=1"] {
            assert!(
                argv.iter().any(|v| v == flag),
                "actual driver {role}: {flag}"
            );
        }
    }
    for role in ["OFF", "ON"] {
        let p = format!("{R}/field/{role}/libzopro_bn254.rlib");
        pins.insert(p.clone(), json!(hash(&p)));
    }
    fs::write(
        format!("{R}/codegen-pins.json"),
        serde_json::to_vec_pretty(&pins).unwrap(),
    )
    .unwrap();
    fs::create_dir(format!("{R}/disassembly")).unwrap();
    let mut rows = Vec::new();
    for role in ["accepted", "OFF", "ON"] {
        for field in ["fq", "fr"] {
            for radix in [256, 260] {
                for op in ["normal1", "normal4", "conj1", "conj4"] {
                    let symbol = format!("joint_{field}{radix}_{op}");
                    let path = format!("{R}/disassembly/{role}-{symbol}.txt");
                    let argv = vec![
                        "-d".to_owned(),
                        "-Mintel".into(),
                        "--no-show-raw-insn".into(),
                        format!("--disassemble={symbol}"),
                        format!("{R}/driver-{role}"),
                    ];
                    let out = Command::new("/usr/bin/objdump")
                        .args(&argv)
                        .output()
                        .unwrap();
                    assert!(out.status.success());
                    assert!(out.stderr.is_empty());
                    let text = String::from_utf8(out.stdout).unwrap();
                    assert!(text.contains(&format!("<{symbol}>:")));
                    fs::write(&path, &text).unwrap();
                    let inst: Vec<(u64, String)> = text
                        .lines()
                        .filter_map(|l| {
                            let (a, s) = l.trim().split_once(':')?;
                            Some((u64::from_str_radix(a, 16).ok()?, s.trim().to_owned()))
                        })
                        .collect();
                    let mut loops = Vec::new();
                    for (address, s) in &inst {
                        let mut parts = s.split_whitespace();
                        let mnemonic = parts.next().unwrap_or("");
                        if !mnemonic.starts_with('j') {
                            continue;
                        }
                        let Some(target) = parts
                            .next()
                            .and_then(|t| u64::from_str_radix(t.trim_start_matches("0x"), 16).ok())
                        else {
                            continue;
                        };
                        if target >= *address {
                            continue;
                        }
                        let body: Vec<_> = inst
                            .iter()
                            .filter(|(a, _)| *a >= target && *a <= *address)
                            .collect();
                        let ifma = body
                            .iter()
                            .filter(|(_, s)| s.starts_with("vpmadd52"))
                            .count();
                        if ifma > 0 {
                            loops.push((ifma, target, *address, body));
                        }
                    }
                    loops.sort_by_key(|(count, lo, hi, _)| (*count, hi - lo));
                    let (ifma, lo, hi, body) = loops.last().expect("resident IFMA loop");
                    let count =
                        |prefix: &str| body.iter().filter(|(_, s)| s.starts_with(prefix)).count();
                    let calls: Vec<_> = body
                        .iter()
                        .filter(|(_, s)| s.starts_with("call"))
                        .map(|(a, s)| json!({"address":a,"instruction":s}))
                        .collect();
                    let stack_rows = body
                        .iter()
                        .filter(|(_, s)| {
                            s.starts_with('v') && (s.contains("[rsp") || s.contains("[rbp"))
                        })
                        .count();
                    let frames: Vec<_> = inst
                        .iter()
                        .filter(|(_, s)| s.starts_with("sub    rsp,") || s.starts_with("sub rsp,"))
                        .map(|(a, s)| json!({"address":a,"instruction":s}))
                        .collect();
                    rows.push(json!({"role":role,"symbol":symbol,"loop_start":lo,"loop_backedge":hi,"loop_ifma":ifma,"loop_instruction_rows":body.len(),
   "loop_vector_adds":count("vpaddq"),"loop_vector_subs":count("vpsubq"),"loop_vector_abs":count("vpabsq"),"loop_signed_shifts":count("vpsraq"),
   "loop_vector_rsp_rbp_operand_rows":stack_rows,"loop_calls":calls,"function_instruction_rows":inst.len(),"function_span_bytes":inst.last().unwrap().0-inst[0].0,
   "explicit_rsp_subtractions":frames,"disassembly_sha256":hash(&path),"decode_argv":argv,
   "scope":"static rows in largest IFMA backedge span, including conditional paths; not dynamic counts, actual spill cycles or lifetime stack peak"}));
                }
            }
        }
    }
    for (p, h) in &pins {
        assert_eq!(hash(p), h.as_str().unwrap(), "post-decode {p}");
    }
    let out = json!({"status":"pass","pins":pins.len(),"identities":identities,"decodes":rows.len(),"rows":rows,
  "new_optimized_consumers":true,"timing":false,"production_changed":false});
    fs::write(
        format!("{R}/codegen.json"),
        serde_json::to_vec_pretty(&out).unwrap(),
    )
    .unwrap();
    println!(
        "decoded48 final optimized primitives once; {} pins verified",
        pins.len()
    );
}
