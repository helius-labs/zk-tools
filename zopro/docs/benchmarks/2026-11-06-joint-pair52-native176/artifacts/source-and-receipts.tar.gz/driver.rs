use zopro_bn254::{ifma8::Ifma8, Fp, FpConfig, FqConfig, FrConfig};
#[inline(always)]
fn run<C: FpConfig, const M: bool, const S: usize, const CONJ: bool>(
    rounds: u64,
    seed: u64,
) -> u64 {
    let values = |stream: usize, lane: usize, k: u64| {
        Fp::<C>::from(
            seed.wrapping_mul(k)
                .wrapping_add((stream * 67 + lane * 13 + 17) as u64),
        )
    };
    let mut a0: [Ifma8<C, M>; S] =
        core::array::from_fn(|s| Ifma8::new(&core::array::from_fn(|l| values(s, l, 31))));
    let mut a1: [Ifma8<C, M>; S] =
        core::array::from_fn(|s| Ifma8::new(&core::array::from_fn(|l| values(s, l, 43))));
    let b0: [Ifma8<C, M>; S] =
        core::array::from_fn(|s| Ifma8::new(&core::array::from_fn(|l| values(s, l, 59))));
    let b1: [Ifma8<C, M>; S] =
        core::array::from_fn(|s| Ifma8::new(&core::array::from_fn(|l| values(s, l, 73))));
    for _ in 0..rounds {
        for s in 0..S {
            #[cfg(zopro_joint_pair52_complex)]
            let out = a0[s].joint_pair52_complex::<CONJ>(&a1[s], &b0[s], &b1[s]);
            #[cfg(not(zopro_joint_pair52_complex))]
            let out = if CONJ {
                [
                    a0[s].sum2(&b0[s], &a1[s], &b1[s]),
                    a1[s].difference2(&b0[s], &a0[s], &b1[s]),
                ]
            } else {
                [
                    a0[s].difference2(&b0[s], &a1[s], &b1[s]),
                    a0[s].sum2(&b1[s], &a1[s], &b0[s]),
                ]
            };
            a0[s] = out[0];
            a1[s] = out[1];
        }
    }
    a0.iter()
        .chain(a1.iter())
        .flat_map(|x| x.get())
        .flat_map(|x| x.0)
        .fold(0u64, |sum, x| sum.rotate_left(11) ^ x)
}
macro_rules! entry {
    ($name:ident,$c:ty,$m:literal,$s:literal,$conj:literal) => {
        #[unsafe(no_mangle)]
        #[inline(never)]
        pub fn $name(n: u64, seed: u64) -> u64 {
            run::<$c, $m, $s, $conj>(n, seed)
        }
    };
}
entry!(joint_fq256_normal1, FqConfig, true, 1, false);
entry!(joint_fq256_normal4, FqConfig, true, 4, false);
entry!(joint_fq256_conj1, FqConfig, true, 1, true);
entry!(joint_fq256_conj4, FqConfig, true, 4, true);
entry!(joint_fr256_normal1, FrConfig, true, 1, false);
entry!(joint_fr256_normal4, FrConfig, true, 4, false);
entry!(joint_fr256_conj1, FrConfig, true, 1, true);
entry!(joint_fr256_conj4, FrConfig, true, 4, true);
entry!(joint_fq260_normal1, FqConfig, false, 1, false);
entry!(joint_fq260_normal4, FqConfig, false, 4, false);
entry!(joint_fq260_conj1, FqConfig, false, 1, true);
entry!(joint_fq260_conj4, FqConfig, false, 4, true);
entry!(joint_fr260_normal1, FrConfig, false, 1, false);
entry!(joint_fr260_normal4, FrConfig, false, 4, false);
entry!(joint_fr260_conj1, FrConfig, false, 1, true);
entry!(joint_fr260_conj4, FrConfig, false, 4, true);
fn main() {
    assert!(std::is_x86_feature_detected!("avx512ifma"));
    assert_eq!(std::env::args().nth(1).unwrap(), "preflight");
    let cases: [(&str, fn(u64, u64) -> u64); 16] = [
        ("fq256_normal1", joint_fq256_normal1),
        ("fq256_normal4", joint_fq256_normal4),
        ("fq256_conj1", joint_fq256_conj1),
        ("fq256_conj4", joint_fq256_conj4),
        ("fr256_normal1", joint_fr256_normal1),
        ("fr256_normal4", joint_fr256_normal4),
        ("fr256_conj1", joint_fr256_conj1),
        ("fr256_conj4", joint_fr256_conj4),
        ("fq260_normal1", joint_fq260_normal1),
        ("fq260_normal4", joint_fq260_normal4),
        ("fq260_conj1", joint_fq260_conj1),
        ("fq260_conj4", joint_fq260_conj4),
        ("fr260_normal1", joint_fr260_normal1),
        ("fr260_normal4", joint_fr260_normal4),
        ("fr260_conj1", joint_fr260_conj1),
        ("fr260_conj4", joint_fr260_conj4),
    ];
    for (name, func) in cases {
        println!(
            "JOINT_NATIVE_PREFLIGHT {name} {:016x}",
            func(1024, 0x19a4_783b_ee20_16d5)
        );
    }
}
