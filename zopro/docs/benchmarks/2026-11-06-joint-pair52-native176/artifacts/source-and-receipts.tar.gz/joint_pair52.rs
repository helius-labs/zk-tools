// Experimental joint complex product. Ordinary field operations stay original.
#[cfg(zopro_joint_pair52_complex)]
impl<C: FpConfig, const MIXED: bool> Ifma8<C, MIXED> {
    /// Eight complex products with shared unreduced work and two REDCs.
    /// Inputs are normalized lazy components in [0,2p]; outputs are below2p.
    #[doc(hidden)]
    #[inline(always)]
    pub fn joint_pair52_complex<const CONJUGATE: bool>(
        &self,
        a1: &Self,
        b0: &Self,
        b1: &Self,
    ) -> [Self; 2] {
        const {
            assert!(C::P[3] < (1u64 << 62));
        }
        let sum_a = self.add(a1);
        let t = if CONJUGATE { b0.sub(b1) } else { b0.add(b1) };
        let d = if CONJUGATE { b0.add(b1) } else { b1.sub(b0) };
        // SAFETY: module target enables IFMA/DQ/VL. Normalized five52-bit
        // operands and the model's32B/64B/1026B bounds keep signed lanes valid.
        unsafe {
            let zero = Self::splat(0);
            let mut rl = [zero; 5];
            let mut rh = [zero; 5];
            let mut il = [zero; 5];
            let mut ih = [zero; 5];
            macro_rules! diagonal {
                ($j:literal) => {{
                    let pl = _mm512_madd52lo_epu64(zero, sum_a.0[$j], b0.0[$j]);
                    let ph = _mm512_madd52hi_epu64(zero, sum_a.0[$j], b0.0[$j]);
                    let ql = _mm512_madd52lo_epu64(zero, a1.0[$j], t.0[$j]);
                    let qh = _mm512_madd52hi_epu64(zero, a1.0[$j], t.0[$j]);
                    let ul = _mm512_madd52lo_epu64(zero, self.0[$j], d.0[$j]);
                    let uh = _mm512_madd52hi_epu64(zero, self.0[$j], d.0[$j]);
                    rl[$j] = _mm512_sub_epi64(pl, ql);
                    rh[$j] = _mm512_sub_epi64(ph, qh);
                    il[$j] = if CONJUGATE {
                        _mm512_sub_epi64(pl, ul)
                    } else {
                        _mm512_add_epi64(pl, ul)
                    };
                    ih[$j] = if CONJUGATE {
                        _mm512_sub_epi64(ph, uh)
                    } else {
                        _mm512_add_epi64(ph, uh)
                    };
                }};
            }
            diagonal!(0);
            diagonal!(1);
            diagonal!(2);
            diagonal!(3);
            diagonal!(4);
            let mut real = Self::joint_pair52_diagonal(rl, rh);
            let mut imag = Self::joint_pair52_diagonal(il, ih);
            macro_rules! cross {
                ($a:expr,$b:expr,$i:literal,$j:literal,$negative:expr,$lo:expr,$hi:expr) => {{
                    let dx = _mm512_sub_epi64($a.0[$i], $a.0[$j]);
                    let dy = if $negative {
                        _mm512_sub_epi64($b.0[$i], $b.0[$j])
                    } else {
                        _mm512_sub_epi64($b.0[$j], $b.0[$i])
                    };
                    let flip = _mm512_cmplt_epi64_mask(dx, zero);
                    let x = _mm512_abs_epi64(dx);
                    let y = _mm512_mask_sub_epi64(dy, flip, zero, dy);
                    let negative = _mm512_cmplt_epi64_mask(y, zero);
                    let lo = _mm512_madd52lo_epu64($lo, x, y);
                    let hi = _mm512_madd52hi_epu64($hi, x, y);
                    let hi = _mm512_mask_sub_epi64(hi, negative, hi, x);
                    (lo, hi)
                }};
            }
            macro_rules! pair {
                ($i:literal,$j:literal,$lo:literal,$hi:literal) => {{
                    let (pl, ph) = cross!(sum_a, b0, $i, $j, false, zero, zero);
                    real[$lo] = _mm512_add_epi64(real[$lo], pl);
                    real[$hi] = _mm512_add_epi64(real[$hi], ph);
                    imag[$lo] = _mm512_add_epi64(imag[$lo], pl);
                    imag[$hi] = _mm512_add_epi64(imag[$hi], ph);
                    let (ql, qh) = cross!(a1, t, $i, $j, true, real[$lo], real[$hi]);
                    real[$lo] = ql;
                    real[$hi] = qh;
                    let (ul, uh) = cross!(self, d, $i, $j, CONJUGATE, imag[$lo], imag[$hi]);
                    imag[$lo] = ul;
                    imag[$hi] = uh;
                }};
            }
            pair!(0, 1, 1, 2);
            pair!(0, 2, 2, 3);
            pair!(0, 3, 3, 4);
            pair!(0, 4, 4, 5);
            pair!(1, 2, 3, 4);
            pair!(1, 3, 4, 5);
            pair!(1, 4, 5, 6);
            pair!(2, 3, 5, 6);
            pair!(2, 4, 6, 7);
            pair!(3, 4, 7, 8);
            [
                Self::joint_pair52_reduce::<true>(real),
                Self::joint_pair52_reduce::<CONJUGATE>(imag),
            ]
        }
    }
    #[inline(always)]
    fn joint_pair52_diagonal(lo: [__m512i; 5], hi: [__m512i; 5]) -> [__m512i; 10] {
        // SAFETY: same module target and signed diagonal bounds as the caller.
        unsafe {
            let e = [
                lo[0],
                _mm512_add_epi64(lo[1], hi[0]),
                _mm512_add_epi64(lo[2], hi[1]),
                _mm512_add_epi64(lo[3], hi[2]),
                _mm512_add_epi64(lo[4], hi[3]),
                hi[4],
            ];
            let mut out = [Self::splat(0); 10];
            out[0] = e[0];
            out[1] = _mm512_add_epi64(out[0], e[1]);
            out[2] = _mm512_add_epi64(out[1], e[2]);
            out[3] = _mm512_add_epi64(out[2], e[3]);
            out[4] = _mm512_add_epi64(out[3], e[4]);
            out[5] = _mm512_sub_epi64(_mm512_add_epi64(out[4], e[5]), e[0]);
            out[6] = _mm512_sub_epi64(out[5], e[1]);
            out[7] = _mm512_sub_epi64(out[6], e[2]);
            out[8] = _mm512_sub_epi64(out[7], e[3]);
            out[9] = e[5];
            out
        }
    }
    #[inline(always)]
    fn joint_pair52_reduce<const SIGNED: bool>(mut t: [__m512i; 10]) -> Self {
        // SAFETY: exact signed cancellation bounds are proved in the parent
        // model. Every arithmetic shift here preserves negative coefficients.
        unsafe {
            let zero = Self::splat(0);
            let mask = Self::splat(MASK);
            let p = split(C::P).map(Self::splat);
            let inv = Self::splat(C::INV & MASK);
            macro_rules! row {
                ($i:literal,$n:literal,$n2:literal,$n3:literal,$n4:literal,$n5:literal) => {{
                    let q = _mm512_madd52lo_epu64(zero, t[$i], inv);
                    let ceil = _mm512_srai_epi64::<52>(_mm512_add_epi64(t[$i], mask));
                    let carry = _mm512_madd52hi_epu64(ceil, q, p[0]);
                    t[$n] = _mm512_madd52lo_epu64(t[$n], q, p[1]);
                    t[$n2] = _mm512_madd52hi_epu64(t[$n2], q, p[1]);
                    t[$n2] = _mm512_madd52lo_epu64(t[$n2], q, p[2]);
                    t[$n3] = _mm512_madd52hi_epu64(t[$n3], q, p[2]);
                    t[$n3] = _mm512_madd52lo_epu64(t[$n3], q, p[3]);
                    t[$n4] = _mm512_madd52hi_epu64(t[$n4], q, p[3]);
                    t[$n4] = _mm512_madd52lo_epu64(t[$n4], q, p[4]);
                    t[$n5] = _mm512_madd52hi_epu64(t[$n5], q, p[4]);
                    t[$n] = _mm512_add_epi64(t[$n], carry);
                }};
            }
            row!(0, 1, 2, 3, 4, 5);
            row!(1, 2, 3, 4, 5, 6);
            row!(2, 3, 4, 5, 6, 7);
            row!(3, 4, 5, 6, 7, 8);
            if MIXED {
                let mask48 = Self::splat((1u64 << 48) - 1);
                let q = _mm512_and_si512(_mm512_madd52lo_epu64(zero, t[4], inv), mask48);
                let ceil = _mm512_srai_epi64::<48>(_mm512_add_epi64(t[4], mask48));
                let carry = _mm512_madd52hi_epu64(ceil, _mm512_slli_epi64::<4>(q), p[0]);
                t[5] = _mm512_madd52lo_epu64(t[5], q, p[1]);
                t[6] = _mm512_madd52hi_epu64(t[6], q, p[1]);
                t[6] = _mm512_madd52lo_epu64(t[6], q, p[2]);
                t[7] = _mm512_madd52hi_epu64(t[7], q, p[2]);
                t[7] = _mm512_madd52lo_epu64(t[7], q, p[3]);
                t[8] = _mm512_madd52hi_epu64(t[8], q, p[3]);
                t[8] = _mm512_madd52lo_epu64(t[8], q, p[4]);
                t[9] = _mm512_madd52hi_epu64(t[9], q, p[4]);
                t[5] = _mm512_add_epi64(_mm512_slli_epi64::<4>(t[5]), carry);
                t[6] = _mm512_slli_epi64::<4>(t[6]);
                t[7] = _mm512_slli_epi64::<4>(t[7]);
                t[8] = _mm512_slli_epi64::<4>(t[8]);
                t[9] = _mm512_slli_epi64::<4>(t[9]);
            } else {
                row!(4, 5, 6, 7, 8, 9);
            }
            macro_rules! normalize {
                ($j:literal,$k:literal) => {{
                    t[$k] = _mm512_add_epi64(t[$k], _mm512_srai_epi64::<52>(t[$j]));
                    t[$j] = _mm512_and_si512(t[$j], mask);
                }};
            }
            normalize!(5, 6);
            normalize!(6, 7);
            normalize!(7, 8);
            normalize!(8, 9);
            let mut out = [t[5], t[6], t[7], t[8], t[9]];
            if SIGNED {
                let negative = _mm512_cmplt_epi64_mask(out[4], zero);
                let two_p = split(crate::portable::add4(C::P, C::P).0).map(Self::splat);
                for j in 0..5 {
                    out[j] = _mm512_mask_add_epi64(out[j], negative, out[j], two_p[j]);
                }
                for j in 0..4 {
                    out[j + 1] = _mm512_add_epi64(out[j + 1], _mm512_srai_epi64::<52>(out[j]));
                    out[j] = _mm512_and_si512(out[j], mask);
                }
                Self(out, PhantomData)
            } else if MIXED {
                Self::reduce_fused(out)
            } else {
                Self(out, PhantomData)
            }
        }
    }
}
#[cfg(test)]
mod joint_pair52_tests {
    include!("joint_pair52_tests.rs");
}
