use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-native176";
const REPO: &str = "/home/ubuntu/src/zk-tools";
const DEST: &str = "zopro/docs/benchmarks/2026-11-06-joint-pair52-native176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn write(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn instructions(p: impl AsRef<Path>) -> Vec<String> {
    fs::read_to_string(p)
        .unwrap()
        .lines()
        .filter_map(|l| {
            let (a, s) = l.trim().split_once(':')?;
            u64::from_str_radix(a, 16).ok()?;
            Some(s.to_owned())
        })
        .collect()
}
fn main() {
    let r = PathBuf::from(R);
    let d = Path::new(REPO).join(DEST);
    assert!(!r.join("review.json").exists());
    let pins = read(r.join("codegen-pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    assert_eq!(pins.as_object().unwrap().len(), 263);
    assert_eq!(read(r.join("build/result.json"))["status"], "complete");
    assert!(!r.join("build/attempt-1.json").exists());
    let plan = read(r.join("build-plan.json"));
    let mut receipts = 0;
    let mut members: Vec<String> = [
        "design.md",
        "joint_pair52.rs",
        "joint_pair52_tests.rs",
        "driver.rs",
        "setup.rs",
        "codegen.rs",
        "finish.rs",
        "source-audit.json",
        "build-plan.json",
        "build-pins.json",
        "codegen-pins.json",
        "codegen.json",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect();
    for step in plan["steps"].as_array().unwrap() {
        let name = step["name"].as_str().unwrap();
        let p = r.join("build").join(name);
        let exit = read(p.join("exit.json"));
        assert_eq!(exit["success"], true);
        assert_eq!(exit["returncode"], 0);
        for stream in ["stdout", "stderr"] {
            assert_eq!(
                exit[format!("{stream}_sha256")],
                hash(p.join(format!("{stream}.log")))
            );
        }
        assert_eq!(
            read(p.join("command.json"))["argv"].as_array().unwrap()[4..],
            step["argv"].as_array().unwrap()[..]
        );
        for file in [
            "command.json",
            "exit.json",
            "stdout.log",
            "stderr.log",
            "tests.json",
        ] {
            members.push(format!("build/{name}/{file}"));
        }
        receipts += 1;
    }
    assert_eq!(receipts, 11);
    let log = fs::read_to_string(r.join("build/joint-native-tests/stdout.log")).unwrap();
    assert!(log.contains("4 passed; 0 failed"));
    assert!(log.contains("35 filtered out"));
    assert_eq!(log.matches("JOINT_PAIR52_NATIVE").count(), 4);
    for field in ["Fq", "Fr"] {
        for radix in [256, 260] {
            assert!(log.contains(&format!("field={field} radix={radix} outputs=81056 exports=81056 boundary=14884 random=4096 endpoint=256 padding=4 chain=1024 normal+conjugate")));
        }
    }
    let preflight = fs::read(r.join("build/preflight-accepted/stdout.log")).unwrap();
    assert_eq!(std::str::from_utf8(&preflight).unwrap().lines().count(), 16);
    for role in ["OFF", "ON"] {
        assert_eq!(
            preflight,
            fs::read(r.join(format!("build/preflight-{role}/stdout.log"))).unwrap()
        );
    }
    let audit = read(r.join("source-audit.json"));
    assert_eq!(audit["source_files"], 178);
    assert_eq!(audit["exact_originals"], 174);
    assert_eq!(audit["recoverable_originals"], 176);
    for (name, h) in audit["hashes"].as_object().unwrap() {
        assert_eq!(hash(r.join("source").join(name)), h.as_str().unwrap());
    }
    let codegen = read(r.join("codegen.json"));
    assert_eq!(codegen["decodes"], 48);
    let mut same = 0;
    for row in codegen["rows"].as_array().unwrap() {
        let role = row["role"].as_str().unwrap();
        let symbol = row["symbol"].as_str().unwrap();
        let file = format!("disassembly/{role}-{symbol}.txt");
        assert_eq!(hash(r.join(&file)), row["disassembly_sha256"]);
        assert!(row["loop_calls"].as_array().unwrap().is_empty());
        assert_eq!(row["loop_ifma"], if role == "ON" { 190 } else { 300 });
        if role == "ON" {
            assert!(row["loop_signed_shifts"].as_u64().unwrap() >= 27);
        }
        if role == "OFF" {
            if instructions(r.join(&file))
                == instructions(r.join(format!("disassembly/accepted-{symbol}.txt")))
            {
                same += 1;
            }
        }
        members.push(file);
    }
    assert_eq!(same, 16);
    let review = json!({"status":"pass","pins":263,"successful_commands":11,"attempts":1,"native_outputs":324224,"export_checks":324224,"new_tests":4,"old_tests_filtered":35,"preflight_cases_each":16,"preflight_controls_equal":true,"decodes":48,"accepted_OFF_instruction_text_equal":same,
 "native_flags":"actual -O/native/fatLTO/oneCGU receipts verified by decoder helper","ordinary_field_and_core_bodies_unchanged":true,"kernel_loop_IFMA":{"accepted":300,"ON":190},"calls_in_selected_loop_spans":0,
 "limitations":"higher instruction/stack-addressed counts; no primitive/fullcaller clock/profile/SDK/proof/actualmemory qualification; fixedB operands may hoist preprocessing; fourstate loop mayroll",
 "reviewer_source_sha256":hash(r.join("finish.rs")),"reviewer_binary_sha256":hash(r.join("finish")),"warnings":"eight inherited unused-import warnings in test build, no new warning-only rebuild",
 "decision":"select actual complete G2 caller integration/qualification and separate prospective matched-caller protocol; no additional favorable primitive-only capture or adoption","new_proofs":0});
    write(r.join("review.json"), &review);
    members.push("review.json".into());
    for file in [
        "result.json",
        "protocol.json",
        "source-pins.json",
        "attempt-0.json",
        "completed.json",
        "progress.json",
    ] {
        members.push(format!("build/{file}"));
    }
    for file in [
        "crates/zopro-bn254/src/ifma8.rs",
        "scripts/ifma8.py",
        "crates/zopro-bn254/src/joint_pair52.rs",
        "crates/zopro-bn254/src/joint_pair52_tests.rs",
    ] {
        members.push(format!("source/{file}"));
    }
    fs::create_dir_all(d.join("artifacts")).unwrap();
    for file in [
        "review.json",
        "codegen.json",
        "codegen-pins.json",
        "source-audit.json",
        "design.md",
    ] {
        fs::copy(r.join(file), d.join("artifacts").join(file)).unwrap();
    }
    let mut hashes = BTreeMap::new();
    for file in &members {
        let bytes = fs::read(r.join(file)).unwrap();
        std::str::from_utf8(&bytes).unwrap();
        hashes.insert(file.clone(), format!("{:x}", Sha256::digest(bytes)));
    }
    write(d.join("artifacts/archive-members.json"), &json!(hashes));
    let archive = d.join("artifacts/source-and-receipts.tar.gz");
    assert!(Command::new("tar")
        .arg("-czf")
        .arg(&archive)
        .arg("-C")
        .arg(&r)
        .arg("--")
        .args(&members)
        .status()
        .unwrap()
        .success());
    let listing = Command::new("tar")
        .arg("-tzf")
        .arg(&archive)
        .output()
        .unwrap();
    assert!(listing.status.success());
    assert_eq!(
        String::from_utf8(listing.stdout)
            .unwrap()
            .lines()
            .map(str::to_owned)
            .collect::<Vec<_>>(),
        members
    );
    let extraction = r.join("archive-review");
    fs::create_dir(&extraction).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&extraction)
        .status()
        .unwrap()
        .success());
    for (file, h) in &hashes {
        assert_eq!(&hash(extraction.join(file)), h);
    }
    let mut report=String::from("# Native joint signed-pair complex qualification\n\nThe fixed native joint complex API passes its focused oracle checks. Its190-IFMA loop count survives optimization, versus300for two retained fused products. **No latency or proving speedup is measured.** More instructions and stack-addressed operations remain material risks. The next measurement must use the actual G2 caller, where previous Gauss variants lost despite primitive gains.\n\nThe [parent exact model](../2026-11-06-joint-pair52-complex176/README.md) checked the joint coefficient algebra and signed reduction before implementation. The private snapshot has178files:174originals byte-exact, two recoverable parent append/generator edits and two kernel/test children. All176originals recover. Ordinary field, FrFFT and core function bodies remain unchanged; no old core is linked to a changed field. No heap/table/key-copy/plan/pool expansion is proposed.\n\n## Actual SIMD checks\n\nFour new native tests compare **324,224raw outputs and324,224exports against independent Arkworks arithmetic** overFq/Fr,R256/R260,normal/conjugated products,lazy[0,2p]endpoints,random tuples and changing chains. Each configuration has81,056outputs:14,884boundary tuples,4,096random,256endpoint-cartesian,four padding,and1,024changing-chain tuples,with four outputs each. Chains have eight independently changing lanes over128steps. Raw outputs must have normalized digits and lie below2p; exports must be canonical and preserve the Montgomery factor. No unreduced host Fp objects are used as inputs. The35old tests are filtered, not claimed rerun.\n\nThe generator check and ten native build/test/preflight commands complete first attempt. The test build has eight inherited unused-import warnings; no warning-only rebuild occurs. All16preflight cases match accepted,freshOFF andON. Three final consumers use actualO3/native/fat-LTO/one-CGU flags. A separate review checks263pins,eleven successful receipts,all four test populations,source identities and48new optimized decodes without repeating execution. Accepted/freshOFF instruction text agrees in all16complete decoded function bodies; this does not replace timing calibration.\n\n## Generated loop tradeoff\n\nCounts cover the largest backward-branch span containing IFMAs, including its conditional paths. They are static rows and literal operand references, not dynamic instructions, measured spills or stall cycles.\n\n| Fq/R256 | Accepted IFMA | ON IFMA | Accepted rows | ON rows | Accepted vector RSP/RBP rows | ON vector RSP/RBP rows |\n|---|---:|---:|---:|---:|---:|---:|\n");
    for op in ["normal1", "normal4", "conj1", "conj4"] {
        let symbol = format!("joint_fq256_{op}");
        let rows = codegen["rows"].as_array().unwrap();
        let find = |role: &str| {
            rows.iter()
                .find(|x| x["role"] == role && x["symbol"] == symbol)
                .unwrap()
        };
        let a = find("accepted");
        let b = find("ON");
        report.push_str(&format!(
            "| {op} | {} | {} | {} | {} | {} | {} |\n",
            a["loop_ifma"],
            b["loop_ifma"],
            a["loop_instruction_rows"],
            b["loop_instruction_rows"],
            a["loop_vector_rsp_rbp_operand_rows"],
            b["loop_vector_rsp_rbp_operand_rows"]
        ));
    }
    report.push_str("\nAll selected spans have no calls, and candidate signed arithmetic shifts are present. The normal single-stateFq/R256 function has literal RSP subtractions0x1000+0x358, versus0x758accepted. Those exclude pushes,alignment and callees; they are not a measured lifetime stack peak. The candidate needs more static instruction rows and stack-addressed vector operations even while saving110IFMAs. Source20-coefficient storage is not a proof of register residency or a RAM bound.\n\nFour-state loops are compiler-rolled, not four fully register-resident products. BothB operands are invariant across these diagnostic iterations, so some preprocessing can move outside the loop. The final drivers support preflight only and no timing mode. Their code is not a complete G2 caller or SDK. No width/layout/attribute sweep or old-kernel rerun was used to improve these counts.\n\n## Next stage and unchanged baseline\n\nIntegrate the qualified API into a separate coherent core snapshot at the actual normal and denominator-conjugated G2 product sites, retaining norm/scale/prefix/inverse/tail behavior and original fallbacks. Qualify changed complete callers, then freeze200/352plus tails,1/16/32workers,accepted+freshOFF,candidate,unchangedG1controls and automaticPMU/cycle profiles before any clock. A caller win still needs verified all-eight+merge54 fullSDK/resource/portable/Gnark qualification before adoption. No additional primitive-only timing run is selected.\n\nThis is a new combined limb decomposition and raw joint complex dataflow, not a representation subset of the closed global ordinary signed-pair build or a rerun of the old250-IFMA Gauss caller. All earlier results remain retained. No new full proof, profiling, AWS/Aeglos, huge/mobile, memory pressure, swap or throughput result exists.\n\nAccepted production176/SDK6d83 remain unchanged: local32 1×2 **7.928660ms**,merge54 **161.883899ms**,inherited132.75MiBRSS(not a new peak/minimum). Proof ledger remains30,846. The inherited [all-eight M5CPU and Metal comparisons](../2026-11-06-signed-pair52-model176/README.md#accepted-full-proof-baseline-inherited) remain current; the10×CPU goal is unmet on all eight shapes.\n\n[Codegen](artifacts/codegen.json),[review](artifacts/review.json),[source audit](artifacts/source-audit.json),[pins](artifacts/codegen-pins.json),[design](artifacts/design.md) and[source/receipts](artifacts/source-and-receipts.tar.gz) are preserved. The archive includes only selectedUTF-8sources/receipts/decodes, with no executable,library,binary fixture,key,witness or proof blobs. The inherited public input fixture remains in its parent archive.\n");
    fs::write(d.join("README.md"), report).unwrap();
    let mut sums = BTreeMap::new();
    for file in [
        "README.md",
        "artifacts/review.json",
        "artifacts/codegen.json",
        "artifacts/codegen-pins.json",
        "artifacts/source-audit.json",
        "artifacts/design.md",
        "artifacts/archive-members.json",
        "artifacts/source-and-receipts.tar.gz",
    ] {
        sums.insert(file, hash(d.join(file)));
    }
    write(d.join("checksums.json"), &json!(sums));
    for (file, h) in &sums {
        assert_eq!(&hash(d.join(file)), h);
    }
    write(
        r.join("publication.json"),
        &json!({"status":"pass","files":9,"utf8_archive_members":members.len(),"roundtrip_members":hashes.len(),"archive_sha256":hash(archive)}),
    );
    println!("native qualification reviewed/published:263pins/11commands/324224outputs+exports/48decodes/{}UTF8members",members.len());
}
