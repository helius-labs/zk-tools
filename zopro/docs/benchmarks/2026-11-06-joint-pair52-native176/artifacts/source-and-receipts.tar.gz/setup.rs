use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-native176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
const OLD: &str = "/home/ubuntu/src/zopro-perf-work/inverse-root-codec176";
const B: &str = "/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(name: &str, v: &Value) {
    fs::write(format!("{R}/{name}"), serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn replace(v: &Value) -> Value {
    match v {
        Value::String(s) => json!(s.replace(OLD, R)),
        Value::Array(a) => json!(a.iter().map(replace).collect::<Vec<_>>()),
        Value::Object(o) => json!(o
            .iter()
            .map(|(k, v)| (k.clone(), replace(v)))
            .collect::<BTreeMap<_, _>>()),
        _ => v.clone(),
    }
}
fn main() {
    assert!(!Path::new(R).join("source").exists());
    let manifest=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let files = manifest["source_files_sha256"].as_object().unwrap();
    assert_eq!(files.len(), 176);
    let suffix = "\ninclude!(\"joint_pair52.rs\");\n";
    let gen_before="source = subprocess.check_output([\"rustfmt\", \"--emit\", \"stdout\", \"--edition\", \"2021\"], input=source, text=True)";
    let gen_after = format!("source += '\\ninclude!(\"joint_pair52.rs\");\\n'\n{gen_before}");
    let mut pins = BTreeMap::new();
    let mut hashes = BTreeMap::new();
    let mut exact = 0;
    for (name, h) in files {
        let path = Path::new(Z).join(name);
        assert_eq!(hash(&path), h.as_str().unwrap());
        let original = fs::read(path).unwrap();
        let mut bytes = original.clone();
        if name == "crates/zopro-bn254/src/ifma8.rs" {
            bytes.extend_from_slice(suffix.as_bytes());
        }
        if name == "scripts/ifma8.py" {
            let text = String::from_utf8(bytes).unwrap();
            assert_eq!(text.matches(gen_before).count(), 1);
            bytes = text.replacen(gen_before, &gen_after, 1).into_bytes();
        }
        if bytes == original {
            exact += 1;
        }
        let dest = Path::new(R).join("source").join(name);
        fs::create_dir_all(dest.parent().unwrap()).unwrap();
        fs::write(&dest, &bytes).unwrap();
        let mut recovered = bytes;
        if name == "crates/zopro-bn254/src/ifma8.rs" {
            assert!(recovered.ends_with(suffix.as_bytes()));
            recovered.truncate(recovered.len() - suffix.len());
        }
        if name == "scripts/ifma8.py" {
            recovered = String::from_utf8(recovered)
                .unwrap()
                .replacen(&gen_after, gen_before, 1)
                .into_bytes();
        }
        assert_eq!(recovered, original);
        hashes.insert(name.clone(), hash(&dest));
        pins.insert(dest.display().to_string(), hash(&dest));
    }
    assert_eq!(exact, 174);
    for file in ["joint_pair52.rs", "joint_pair52_tests.rs"] {
        let dest = format!("{R}/source/crates/zopro-bn254/src/{file}");
        fs::copy(format!("{R}/{file}"), &dest).unwrap();
        pins.insert(dest.clone(), hash(&dest));
        hashes.insert(format!("crates/zopro-bn254/src/{file}"), hash(&dest));
    }
    assert_eq!(hashes.len(), 178);
    for role in ["OFF", "ON"] {
        fs::create_dir_all(format!("{R}/field/{role}")).unwrap();
    }
    let old = replace(&read(format!("{OLD}/build-plan.json")));
    let oldsteps = old["steps"].as_array().unwrap();
    let mut test = oldsteps
        .iter()
        .find(|s| s["name"] == "build-codec-tests")
        .unwrap()
        .clone();
    test["name"] = json!("build-joint-native-tests");
    test["argv"].as_array_mut().unwrap().extend([json!("--cfg"),json!("zopro_joint_pair52_complex"),json!("-L"),json!(format!("dependency={B}/frozen/candidate")),json!("--extern"),json!(format!("serde_json={B}/frozen/candidate/libserde_json-792a1ccfa9d7a509acedb3e992a9c8158d940f10c0b04abe034fe51f74e5811f.rlib"))]);
    let fixture = "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/inputs.json";
    test["environment"]["JOINT_PAIR52_INPUTS"] = json!(fixture);
    let environment = test["environment"].clone();
    let mut steps = vec![
        json!({"kind":"command","name":"generator-check","argv":["/usr/bin/python3",format!("{R}/source/scripts/ifma8.py"),"--check"],"environment":environment,"timeout_seconds":120}),
        test,
    ];
    steps.push(json!({"kind":"command","name":"joint-native-tests","argv":[format!("{R}/field-tests"),"ifma8::joint_pair52_tests::","--nocapture","--test-threads=1"],"environment":environment,"timeout_seconds":300,"required_tests":["ifma8::joint_pair52_tests::fq_mixed","ifma8::joint_pair52_tests::fr_mixed","ifma8::joint_pair52_tests::fq_uniform","ifma8::joint_pair52_tests::fr_uniform"]}));
    for role in ["OFF", "ON"] {
        let mut step = oldsteps
            .iter()
            .find(|s| s["name"] == "field-library")
            .unwrap()
            .clone();
        step["name"] = json!(format!("field-{role}"));
        let a = step["argv"].as_array_mut().unwrap();
        let out = a.iter().position(|v| v == "-o").unwrap() + 1;
        a[out] = json!(format!("{R}/field/{role}/libzopro_bn254.rlib"));
        if role == "ON" {
            a.extend([json!("--cfg"), json!("zopro_joint_pair52_complex")]);
        }
        steps.push(step);
    }
    let frozen = read(format!("{B}/frozen-candidate.json"));
    for (path, h) in frozen["input_pins"].as_object().unwrap() {
        assert_eq!(hash(path), h.as_str().unwrap());
        pins.insert(path.clone(), h.as_str().unwrap().to_owned());
    }
    for(role,lib)in[("accepted",format!("{B}/frozen/candidate/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib")),("OFF",format!("{R}/field/OFF/libzopro_bn254.rlib")),("ON",format!("{R}/field/ON/libzopro_bn254.rlib"))]{
 let mut argv=vec!["/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc".to_owned(),"--edition=2021".into(),"--crate-name".into(),"joint_pair52_driver".into(),format!("{R}/driver.rs"),"-O".into(),"-C".into(),"target-cpu=native".into(),"-C".into(),"lto=fat".into(),"-C".into(),"codegen-units=1".into(),"-C".into(),"debuginfo=1".into(),"-L".into(),format!("dependency={B}/frozen/candidate"),"--extern".into(),format!("zopro_bn254={lib}"),"-o".into(),format!("{R}/driver-{role}")];
 if role=="ON"{argv.extend(["--cfg".into(),"zopro_joint_pair52_complex".into()]);}steps.push(json!({"kind":"command","name":format!("driver-{role}"),"argv":argv,"environment":environment,"timeout_seconds":600}));
}
    for role in ["accepted", "OFF", "ON"] {
        steps.push(json!({"kind":"command","name":format!("preflight-{role}"),"argv":[format!("{R}/driver-{role}"),"preflight"],"environment":environment,"timeout_seconds":120}));
    }
    for step in &steps {
        for arg in step["argv"].as_array().unwrap() {
            let arg = arg.as_str().unwrap();
            let path = arg
                .split_once('=')
                .filter(|(k, _)| {
                    matches!(
                        *k,
                        "dependency"
                            | "ark_ref"
                            | "ark_ec"
                            | "ark_ff"
                            | "ark_std"
                            | "serde_json"
                            | "zopro_bn254"
                    )
                })
                .map(|(_, p)| p)
                .unwrap_or(arg);
            if Path::new(path).is_file() {
                pins.insert(path.to_owned(), hash(path));
            }
        }
    }
    for p in [
        format!("{R}/setup.rs"),
        format!("{R}/setup"),
        format!("{R}/design.md"),
        format!("{R}/joint_pair52.rs"),
        format!("{R}/joint_pair52_tests.rs"),
        format!("{R}/driver.rs"),
        fixture.into(),
        "/home/ubuntu/src/zopro-perf-work/joint-pair52-complex176/result.json".into(),
        "/home/ubuntu/src/zopro-perf-work/joint-pair52-complex176/review.json".into(),
        "/home/ubuntu/src/zopro-perf-work/joint-pair52-complex176/bounds.md".into(),
        "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustfmt".into(),
        "/home/ubuntu/src/zopro-perf-work/sdk-link-flags176/tool-target/release/xtask".into(),
    ] {
        pins.insert(p.clone(), hash(p));
    }
    save(
        "source-audit.json",
        &json!({"source_files":178,"exact_originals":174,"recoverable_originals":176,"hashes":hashes,"ordinary_field_and_core_bodies_unchanged":true}),
    );
    save("build-pins.json", &json!(pins));
    save(
        "build-plan.json",
        &json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"environment":{},"steps":steps}),
    );
    println!(
        "prepared178sources/174exact/all176recoverable;{}commands/{}pins;noclock",
        steps.len(),
        pins.len()
    );
}
