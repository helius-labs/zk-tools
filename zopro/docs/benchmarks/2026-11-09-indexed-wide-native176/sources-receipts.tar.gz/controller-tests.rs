
#[cfg(test)]
mod indexed_wide_tests {
    use super::*;use zopro_bn254::Fr;
    std::thread_local!{pub(super) static DENIAL:std::cell::Cell<u8>=const{std::cell::Cell::new(0)};}
    fn random(s:&mut u64)->Fr{let mut b=[0;32];for c in b.chunks_exact_mut(8){*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;c.copy_from_slice(&s.to_le_bytes());}Fr::from_le_bytes_mod_order(&b)}
    fn fixture(n:usize,grouped:bool)->(Vec<G2Affine>,Vec<[u64;4]>,G2Affine){
        let g=G2Projective::generator();let coefficients=(0..n).map(|i|match i%13{0=>Fr::ZERO,1..=3=>Fr::ONE,4=>-Fr::ONE,_=>Fr::from((i+7)as u64)}).collect::<Vec<_>>();let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|&c|g*c).collect::<Vec<_>>());
        let mut seed=0xa713fe01234;let unique=(0..1051).map(|_|random(&mut seed)).collect::<Vec<_>>();
        let scalars=(0..n).map(|i|if grouped{unique[i%1051]}else if i>=22{random(&mut seed)}else{match i%11{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,3..=7=>{let p=Fr::from(2u64).pow(&[[11,12,63,64,125,126,127,128,253][i%9]]);if i%2==0{p-Fr::ONE}else{p+Fr::ONE}},_=>random(&mut seed)}}).collect::<Vec<_>>();
        let expected=(g*scalars.iter().zip(&coefficients).fold(Fr::ZERO,|a,(s,c)|a+*s**c)).to_affine();(bases,scalars.iter().map(Fr::to_canonical).collect(),expected)
    }
    #[test]fn complete_raw_and_production_grouped_queries_at_worker_counts(){
        for (n,grouped) in[(1024,false),(2051,false),(4097,true)]{let(bases,words,expected)=fixture(n,grouped);let saved=bases.clone();
            for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||{
                let mut input=words.clone();let(out,meta)=crate::coalesce_query_probe::b(&bases,&mut input);assert_eq!(out.to_affine(),expected,"n={n} workers={workers}");assert_eq!(meta.route,318,"candidate must cover both raw and grouped roots");assert!(meta.payload>0);
                if grouped{assert_eq!(input,words);}else{let short=words.iter().copied().map(super::super::phi_split).collect::<Vec<_>>();assert_eq!(input,short);assert_eq!(try_query(&bases,&short).unwrap().to_affine(),expected);}
            });assert_eq!(bases,saved);}
        }
    }
    #[test]fn both_admission_denials_fall_back_without_double_split(){
        let(bases,words,expected)=fixture(1024,false);let short=words.iter().copied().map(super::super::phi_split).collect::<Vec<_>>();let saved=short.clone();assert!(admitted(&bases,&short,None,false).is_none());assert!(admitted(&bases,&short,super::super::super::workspace::indexed_wide_held(bases.len()),true).is_none());assert_eq!(short,saved);
        for mode in[1,2]{DENIAL.with(|d|d.set(mode));let mut input=words.clone();let result=super::super::raw_exclusive(&bases,&mut input);DENIAL.with(|d|d.set(0));assert_eq!(result.to_affine(),expected);assert_eq!(input,short);}
        assert!(try_query(&bases[..1023],&short[..1023]).is_none());assert!(try_query(&bases,&short[..1023]).is_none());
        assert_eq!(try_query(&bases,&short).unwrap().to_affine(),expected,"admission ownership released after denial");
    }
}
