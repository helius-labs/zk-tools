
#[cfg(all(zopro_coalesce_probe,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
pub mod coalesce_query_probe {
 use zopro_bn254::{G1Affine,G2Affine,G1Projective,G2Projective};
 #[derive(Clone,Copy,Debug,Default,PartialEq,Eq)]pub struct Metadata{pub route:u32,pub classes:usize,pub skips:usize,pub payload:usize}
 std::thread_local!{static META:std::cell::Cell<Metadata>=std::cell::Cell::new(Metadata::default());}
 pub(crate)fn record(payload:usize){META.with(|m|m.set(Metadata{route:318,payload,..Metadata::default()}));}
 pub fn a(bases:&[G1Affine],words:&[[u64;4]])->(G1Projective,Metadata){(crate::msm_affine::msm_canonical(bases,words),Metadata::default())}
 pub fn b(bases:&[G2Affine],words:&mut[[u64;4]])->(G2Projective,Metadata){META.with(|m|m.set(Metadata::default()));let p=crate::msm_affine::g2_query_exclusive(bases,words);(p,META.with(|m|m.get()))}
}
