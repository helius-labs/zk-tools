#![recursion_limit="256"]
use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/indexed-wide-native176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn v(n:usize,size:usize,grow:bool)->usize{if n==0{0}else{(if grow{n.max(4).next_power_of_two()}else{n})*size+64}}
fn grouping(n:usize)->usize{if n==0{0}else{v(n,128,false)+v(n+4,8,false)+v(n/16,2880,false)+192+24}}
fn weighted(n:usize)->usize{if n==0{0}else{let g=n.min(256);(v(2*g-1,128,false)+v(g/2,8,true)+v(g/16,2880,false)+24)*n.div_ceil(256)+v(n.div_ceil(256),320,false)}}
fn top(n:usize)->(usize,usize){let tiles=n.div_ceil(1024)+2;let held=6*v(3,8,false)+v(n,4,false)+v(tiles,16,true)+v(tiles,128,false)+v(tiles,4,false)+v(2,128,false)+v(1,320,false);(held,grouping(n.min(1024)).max(grouping(tiles)).max(weighted(2)))}
fn forecast(n:usize,workers:usize,rows:usize)->(usize,usize){
 let(t,leading)=top(n.div_ceil(2));let held=9*(v(32769,4,false)+v(2*n,4,false)+v(32768,2,false)+v(32768,4,false))+v(9,48,false)+9*v(32,320,false)+v(10,192,false)+2*t+16*v(2,128,false)+v(2,24,false);
 // Source-derived x86_64 layouts: Scratch<G2>=1104, BatchAdd<G2>=1320,
 // Group/Fq2AddGroup=2880, tuple(u32,G2Affine)=136. These are this ABI only.
 let grouping_phase=grouping(rows)+2*v(1024,8,false)+v(1024,128,false)+1104;
 let batch=v(32,2880,false)+v(7,320,true)+24;
 let merge_phase=v(1024,128,false)+v(256,136,false)+batch+v(511,128,false)+1320;
 let leaf=grouping_phase.max(merge_phase).max(weighted(256)+1104)+320;
 (held,workers.max(1)*leaf.max(leading).max(weighted(1)))
}
fn main(){let plan=read(&format!("{R}/plan.json"));let pins=read(&format!("{R}/pins.json"));assert_eq!(pins,read(&format!("{R}/run/source-pins.json")));for(p,h)in pins.as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap(),"{p}");}
 assert_eq!(read(&format!("{R}/run/result.json"))["status"],"complete");let mut receipts=vec![];let mut tests=vec![];
 for s in plan["steps"].as_array().unwrap(){let name=s["name"].as_str().unwrap();let root=format!("{R}/run/{name}");let e=read(&format!("{root}/exit.json"));assert_eq!(e["returncode"],0);assert_eq!(e["success"],true);for stream in["stdout","stderr"]{assert_eq!(hash(&format!("{root}/{stream}.log")),e[format!("{stream}_sha256")].as_str().unwrap());}let command=read(&format!("{root}/command.json"));assert_eq!(command["argv"],s["argv"]);if s.get("required_tests").is_some(){let t=read(&format!("{root}/tests.json"));for x in s["required_tests"].as_array().unwrap(){assert!(t["passed_tests"].as_array().unwrap().contains(x));tests.push(x.clone());}}receipts.push(name.to_owned());}
 assert_eq!((receipts.len(),tests.len()),(6,5));
 let manifest=read(&format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));let audit=read(&format!("{R}/source-audit.json"));let hook=audit["hook"].as_str().unwrap();let mut exact=0;
 for(rel,h)in manifest["source_files_sha256"].as_object().unwrap(){let production=format!("{Z}/{rel}");assert_eq!(hash(&production),h.as_str().unwrap());let path=format!("{R}/source/{rel}");let original=fs::read(&production).unwrap();let mut bytes=fs::read(&path).unwrap();if bytes==original{exact+=1;}else if rel=="crates/zopro-core/src/msm_affine/g2_phi.rs"{let mut s=String::from_utf8(bytes).unwrap();assert_eq!(s.matches(hook).count(),1);s=s.replace(hook,"");bytes=s.into_bytes();bytes.truncate(original.len());}else{assert!(audit["changed_parents"].as_array().unwrap().contains(&json!(rel)));bytes.truncate(original.len());}assert_eq!(bytes,original,"{rel}");}assert_eq!(exact,172);
 let resources=fs::read_to_string(format!("{R}/run/qualify-indexed-wide-typed-forecast/stdout.log")).unwrap();let mut resource_rows=vec![];for line in resources.lines(){if let Some((_,values))=line.split_once("indexed-wide resource "){let row=values.split_whitespace().map(|x|{let(k,v)=x.split_once('=').unwrap();(k,v.parse::<usize>().unwrap())}).collect::<BTreeMap<_,_>>();let(h,l)=forecast(row["n"],row["workers"],row["largest"]);assert_eq!((h,l,h+l),(row["held"],row["leaf"],row["total"]));resource_rows.push(json!(row));}}assert_eq!(resource_rows.len(),72);
 let field="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/frozen/candidate/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib";assert_eq!(hash(field),"1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713");
 let output=json!({"passed":true,"checked_pins":pins.as_object().unwrap().len(),"successful_commands":receipts,"new_passed_tests":tests,"resource_rows_independently_recomposed":resource_rows,"resource_ABI":"x86_64 only; source-derived original type sizes; requested capacity, not RSS/stack/process bound","production176_exact":true,"native_originals_exact":172,"native_originals_recoverable":176,"hook_after_single_split_original_remainder_exact":true,"original_field_sha256":hash(field),"release_core_sha256":hash(&format!("{R}/libs/libzopro_core.rlib")),"generic_guard_sha256":hash(&format!("{R}/libzopro_core-generic.rlib")),"preparation_failure_retained":read(&format!("{R}/preparation-failure.json")),"native_workflow_first_execution_passed":true,"new_timing_trials":0,"new_SDK_requests":0,"new_Gnark_exports":0,"new_proofs":0,"adopted":false,"production_changed":false,"goal_complete":false});fs::write(format!("{R}/review.json"),serde_json::to_vec_pretty(&output).unwrap()).unwrap();println!("PASS {}pins/6commands/5newtests/72independentcapacityrows/176recoverable/originalfield;no timing",pins.as_object().unwrap().len());
}
