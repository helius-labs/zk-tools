
#[cfg(test)]
mod indexed_wide_tests {
    use super::*;
    const LAMBDA:Fr=Fr::from_decimal("4407920970296243842393367215006156084916469457145843978461");
    fn check(rows:usize,pattern:usize){
        let g=G2Projective::generator();let mut point=G2Projective::IDENTITY;
        let coefficients=(0..1051).map(|i|match i%13{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,_=>Fr::from((i+1)as u64)}).collect::<Vec<_>>();
        let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|&c|{point=g*c;point}).collect::<Vec<_>>());
        let saved=bases.clone();let mut groups=vec![Vec::new();1024];
        for i in 0..rows {let class=match pattern{0=>i%4,1=>0,_=>(i/17)%4};let bucket=match pattern{0=>[0,7,8,127,255][i%5],1=>255,_=>i%256};let ordinal=match pattern{0=>i%4,1=>i%bases.len(),_=>i.wrapping_mul(37)%bases.len()};let negative=pattern!=1&&i%3==0;groups[class*256+bucket].push(ordinal as u32|if negative{1<<31}else{0});}
        let mut order=vec![0u32;3];let mut starts=vec![3u32];let(mut weighted,mut total)=(Fr::ZERO,Fr::ZERO);
        for (group,items) in groups.iter().enumerate(){for &encoded in items {let mut c=coefficients[(encoded&0x7fff_ffff)as usize];if encoded>>31!=0{c=-c;}if group/256>=2{c*=LAMBDA;}total+=c;weighted+=c*Fr::from((group%256+1)as u64);order.push(encoded);}starts.push(order.len()as u32);}
        let original_order=order.clone();let original_starts=starts.clone();let(w,t)=leaf(&bases,&order,&starts);
        assert_eq!(w.to_affine(),(g*weighted).to_affine(),"weighted rows={rows} pattern={pattern}");assert_eq!(t,(g*total).to_affine(),"total rows={rows} pattern={pattern}");assert_eq!(bases,saved);assert_eq!(order,original_order);assert_eq!(starts,original_starts);
    }
    #[test]fn signed_classes_complete_exceptions_and_lane_boundaries(){for n in[0,1,7,8,9,15,16,17,31,32,33,255,256,257,1023,1024,1025]{check(n,0);check(n,2);}}
    #[test]fn hot_cells_above_old_cutoff_and_deep_reduction(){for n in[1201,2359,4097]{check(n,1);check(n,2);}}
}
