
#[cfg(all(test,zopro_indexed_wide,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
mod indexed_wide_tests{
    use super::*;
    #[test]fn typed_parent_and_leaf_forecasts_are_checked(){
        for n in[1024usize,2051,28852,30089,52274,65535]{let held=indexed_wide_held(n).unwrap();let index_payload=9*(32769*4+2*n*4);assert!(held>index_payload+9*(32768*2+32768*4));for workers in[1,4,16,32]{for largest in[0,2359.min(2*n),2*n]{let leaf=indexed_wide_leaf_charge(n,workers,largest).unwrap();assert_eq!(leaf,indexed_wide_leaf_charge(n,1,largest).unwrap()*workers);assert!(held.checked_add(leaf).is_some());println!("indexed-wide resource n={n} workers={workers} largest={largest} held={held} leaf={leaf} total={}",held+leaf);}}}
        for n in[0,1023,65536,usize::MAX]{assert!(indexed_wide_held(n).is_none());assert!(indexed_wide_leaf_charge(n,32,0).is_none());}
        assert!(indexed_wide_leaf_charge(30089,usize::MAX,2359).is_none());assert!(indexed_wide_leaf_charge(30089,32,60179).is_none());assert!(crate::msm::indexed_wide_leaf_peak(usize::MAX).is_none());
        assert_eq!(indexed_wide_leaf_charge(30089,0,2359),indexed_wide_leaf_charge(30089,1,2359));
    }
}
