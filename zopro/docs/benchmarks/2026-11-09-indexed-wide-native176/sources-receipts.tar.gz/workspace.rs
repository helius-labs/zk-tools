#[cfg(all(zopro_indexed_wide,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
pub(super) fn indexed_wide_held(n:usize)->Option<usize>{
    if !(1024..65536).contains(&n){return None;}
    let per_index=add(vector::<u32>(32769,false)?,vector::<u32>(mul(2,n)?,false)?)?;
    let construction=add(vector::<u16>(32768,false)?,vector::<u32>(32768,false)?)?;
    let mut held=mul(add(per_index,construction)?,9)?;
    // Index headers are retained in the outer collected vector.
    held=add(held,vector::<(Vec<u32>,Vec<u32>)>(9,false)?)?;
    held=add(held,mul(vector::<(Projective<G2Config>,Affine<G2Config>)>(32,false)?,9)?)?;
    held=add(held,vector::<Projective<G2Config>>(10,false)?)?;
    // Two parts can retain their signed-top parents; high/negative outputs
    // also survive while the low component or its merges execute.
    let t=top::<G2Config>(n.div_ceil(2),1)?;
    held=add(held,mul(t.held,2)?)?;
    held=add(held,mul(vector::<Affine<G2Config>>(2,false)?,16)?)?;
    held=add(held,vector::<Vec<Affine<G2Config>>>(2,false)?)?;
    Some(held)
}
#[cfg(all(zopro_indexed_wide,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
pub(super) fn indexed_wide_leaf_charge(n:usize,workers:usize,largest:usize)->Option<usize>{
    if !(1024..65536).contains(&n)||largest>mul(2,n)?{return None;}
    let leading=top::<G2Config>(n.div_ceil(2),1)?;
    let leaf=crate::msm::indexed_wide_leaf_peak(largest)?.max(leading.leaf).max(crate::msm::workspace_weighted::<G2Config>(1)?);
    mul(leaf,workers.max(1))
}
