//! One nonforking leaf for four signed component/partition bucket classes.
use super::*;
use zopro_bn254::{G2Affine,G2Config,G2Projective};
const CELL:usize=256;

fn merge_local(left:&mut[G2Affine],right:&[G2Affine],pairs:&mut Vec<(u32,G2Affine)>,packed:&mut BatchAdd<G2Config>){
    debug_assert_eq!(left.len(),right.len());pairs.clear();
    for(i,(a,&b))in left.iter_mut().zip(right).enumerate(){
        if a.is_identity(){*a=b;}else if b.is_identity(){}else if a.x==b.x{*a=(*a+b).to_affine();}else{pairs.push((i as u32,b));}
    }
    if !pairs.is_empty(){packed.apply(left,pairs);}
}

pub(crate) fn leaf(bases:&[G2Affine],order:&[u32],starts:&[u32])->(G2Projective,G2Affine){
    assert_eq!(starts.len(),4*CELL+1);
    let offset=starts[0]as usize;let end=starts[4*CELL]as usize;
    assert!(end<=order.len()&&offset<=end);
    let mut points=Vec::with_capacity(end-offset);
    for &encoded in &order[offset..end]{let p=bases[(encoded&0x7fff_ffff)as usize];points.push(limbs::<G2Config>(if encoded>>31!=0{-p}else{p}));}
    let mut local_starts=Vec::with_capacity(4*CELL);
    let mut counts=Vec::with_capacity(4*CELL);
    for range in starts.windows(2){assert!(range[1]>=range[0]);local_starts.push(range[0]as usize-offset);counts.push((range[1]-range[0])as usize);}
    let mut scratch=Scratch::<G2Config>::default();
    while counts.iter().any(|&n|n>1){reduce_layer(&mut points,&local_starts,&mut counts,&mut scratch);}
    let mut values=vec![G2Affine::IDENTITY;4*CELL];
    for i in 0..4*CELL{if counts[i]!=0{values[i]=affine::<G2Config>(points[local_starts[i]]);}}
    drop(points);drop(local_starts);drop(counts);drop(scratch);
    let mut pairs=Vec::with_capacity(CELL);let mut packed=BatchAdd::<G2Config>::default();
    let mut tree=vec![LimbPoint::<Fq2>::infinity();2*CELL-1];
    {
        let(low,high)=values.split_at_mut(2*CELL);
        let(high0,high1)=high.split_at_mut(CELL);
        merge_local(high0,high1,&mut pairs,&mut packed);
        let beta=Fq::from_decimal("21888242871839275220042445260109153167277707414472061641714758635765020556616");
        for p in high0.iter_mut(){if !p.is_identity(){p.x=p.x.mul_by_fp(&beta);}}
        let(low0,low1)=low.split_at_mut(CELL);merge_local(low0,low1,&mut pairs,&mut packed);merge_local(high0,low0,&mut pairs,&mut packed);
        for(out,&p)in tree.iter_mut().zip(high0.iter()){*out=limbs::<G2Config>(p);}
    }
    drop(values);drop(pairs);drop(packed);
    let mut scratch=Scratch::<G2Config>::default();let weighted=weighted_sum(&mut tree,CELL,&mut scratch);
    (weighted,affine::<G2Config>(tree[0]))
}

pub(crate) fn leaf_peak(rows:usize)->Option<usize>{
    use crate::msm_affine::workspace::vector as v;
    let add=usize::checked_add;
    let outputs=v::<G2Affine>(4*CELL,false)?;
    let descriptors=v::<usize>(4*CELL,false)?.checked_mul(2)?;
    let grouping=add(add(workspace_grouping::<G2Config>(rows,1)?,descriptors)?,outputs)?.checked_add(core::mem::size_of::<Scratch<G2Config>>())?;
    // The weighted point array is initialized while merge buffers are live.
    let tree=v::<LimbPoint<Fq2>>(2*CELL-1,false)?;
    let merging=add(add(add(outputs,v::<(u32,G2Affine)>(CELL,false)?)?,workspace_batch::<G2Config>(CELL)?)?,tree)?.checked_add(core::mem::size_of::<BatchAdd<G2Config>>())?;
    let weighted=workspace_weighted::<G2Config>(CELL)?.checked_add(core::mem::size_of::<Scratch<G2Config>>())?;
    grouping.max(merging).max(weighted).checked_add(core::mem::size_of::<(G2Projective,G2Affine)>())
}
