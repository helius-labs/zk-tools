#![recursion_limit="256"]
use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/indexed-wide-native176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
const P:&str="/home/ubuntu/src/zopro-perf-work/ring-affine-completion176";
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(p:&str,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn append(rel:&str,extra:&str){let p=format!("{R}/source/{rel}");let s=fs::read_to_string(&p).unwrap();fs::write(p,s+extra).unwrap();}
fn main(){
 assert!(!Path::new(&format!("{R}/source")).exists());
 let manifest=format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");let m=read(&manifest);let mut pins=BTreeMap::new();
 for(rel,h)in m["source_files_sha256"].as_object().unwrap(){let from=format!("{Z}/{rel}");assert_eq!(hash(&from),h.as_str().unwrap());let to=format!("{R}/source/{rel}");fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(from,to).unwrap();}
 let cfg="all(zopro_indexed_wide,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma))";
 let msm_suffix=format!("\n#[cfg({cfg})]mod indexed_wide;\n#[cfg({cfg})]pub(crate)use indexed_wide::{{leaf as indexed_wide_leaf,leaf_peak as indexed_wide_leaf_peak}};\n");append("crates/zopro-core/src/msm.rs",&msm_suffix);
 let controller_suffix=format!("\n#[cfg({cfg})]mod indexed_wide;\n");append("crates/zopro-core/src/msm_affine/g2_phi.rs",&controller_suffix);
 let anchor="    short.par_iter_mut().for_each(|s| *s = phi_split(*s));\n";let hook=format!("    #[cfg({cfg})]\n    if bits==12&&parts==2 {{if let Some(result)=indexed_wide::try_query(bases,short){{return result;}}}}\n");
 let p=format!("{R}/source/crates/zopro-core/src/msm_affine/g2_phi.rs");let s=fs::read_to_string(&p).unwrap();assert_eq!(s.matches(anchor).count(),1);fs::write(p,s.replace(anchor,&format!("{anchor}{hook}"))).unwrap();
 let workspace_suffix=format!("\n{}{}",fs::read_to_string(format!("{R}/workspace.rs")).unwrap(),fs::read_to_string(format!("{R}/workspace-tests.rs")).unwrap());append("crates/zopro-core/src/msm_affine/workspace.rs",&workspace_suffix);
 let probe=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/g2-joint-ring-native176/probe-export.rs").unwrap().replace("route:314","route:318");append("crates/zopro-core/src/lib.rs",&probe);fs::write(format!("{R}/probe-export.rs"),&probe).unwrap();
 let mut children=vec![];for(rel,body,tests)in[("crates/zopro-core/src/msm/indexed_wide.rs","leaf.rs","leaf-tests.rs"),("crates/zopro-core/src/msm_affine/g2_phi/indexed_wide.rs","controller.rs","controller-tests.rs")]{let p=format!("{R}/source/{rel}");fs::create_dir_all(Path::new(&p).parent().unwrap()).unwrap();fs::write(&p,fs::read_to_string(format!("{R}/{body}")).unwrap()+&fs::read_to_string(format!("{R}/{tests}")).unwrap()).unwrap();children.push(p);}
 let suffixes=BTreeMap::from([("crates/zopro-core/src/msm.rs",msm_suffix),("crates/zopro-core/src/msm_affine/g2_phi.rs",controller_suffix),("crates/zopro-core/src/msm_affine/workspace.rs",workspace_suffix),("crates/zopro-core/src/lib.rs",probe)]);
 let(mut exact,mut recovered)=(0,0);for(rel,h)in m["source_files_sha256"].as_object().unwrap(){let p=format!("{R}/source/{rel}");let mut bytes=fs::read(&p).unwrap();if hash(&p)==h.as_str().unwrap(){exact+=1;}if let Some(tail)=suffixes.get(rel.as_str()){let mut s=String::from_utf8(bytes).unwrap();assert!(s.ends_with(tail));s.truncate(s.len()-tail.len());if rel=="crates/zopro-core/src/msm_affine/g2_phi.rs"{assert_eq!(s.matches(&hook).count(),1);s=s.replace(&hook,"");}bytes=s.into_bytes();}assert_eq!(bytes,fs::read(format!("{Z}/{rel}")).unwrap(),"{rel}");recovered+=1;pins.insert(p.clone(),hash(&p));}assert_eq!((exact,recovered),(172,176));
 save(&format!("{R}/source-audit.json"),&json!({"total_sources":178,"exact_originals":exact,"recovered_originals":recovered,"changed_parents":suffixes.keys().collect::<Vec<_>>(),"hook":hook,"original_hb_raw_remainder_byte_exact":true,"original_field_unchanged":true,"production_changed":false,"route":318}));
 let old=read(&format!("{P}/native-plan-fixed.json"));let adapt=|s:&Value|{let mut out=s.clone();out["argv"]=json!(s["argv"].as_array().unwrap().iter().map(|v|v.as_str().unwrap().replace(P,R).replace("ring_affine_completion176","indexed_wide_native176").replace("zopro_g2_ring_completion","zopro_indexed_wide")).collect::<Vec<_>>());for v in out["environment"].as_object_mut().unwrap().values_mut(){if let Some(s)=v.as_str(){*v=json!(s.replace(P,R));}}out["environment"]["ZOPRO_CPU_DEDUP"]=json!("1");out};
 let mut first=adapt(&old["steps"][0]);first["name"]=json!("build-indexed-wide-native-tests");let mut steps=vec![first.clone()];
 for(name,filter,required)in[
 ("qualify-indexed-wide-leaf","msm::indexed_wide::indexed_wide_tests::",vec!["msm::indexed_wide::indexed_wide_tests::signed_classes_complete_exceptions_and_lane_boundaries","msm::indexed_wide::indexed_wide_tests::hot_cells_above_old_cutoff_and_deep_reduction"]),
 ("qualify-indexed-wide-complete-queries-and-fallback","msm_affine::g2_phi::indexed_wide::indexed_wide_tests::",vec!["msm_affine::g2_phi::indexed_wide::indexed_wide_tests::complete_raw_and_production_grouped_queries_at_worker_counts","msm_affine::g2_phi::indexed_wide::indexed_wide_tests::both_admission_denials_fall_back_without_double_split"]),
 ("qualify-indexed-wide-typed-forecast","msm_affine::workspace::indexed_wide_tests::",vec!["msm_affine::workspace::indexed_wide_tests::typed_parent_and_leaf_forecasts_are_checked"])
 ]{steps.push(json!({"kind":"command","name":name,"argv":[format!("{R}/core-tests"),filter,"--nocapture","--test-threads=1"],"required_tests":required,"environment":first["environment"],"timeout_seconds":1200,"unfiltered":false}));}
 for(i,name)in[(5,"compile-indexed-wide-generic-guard"),(6,"build-indexed-wide-release-core")]{let mut s=adapt(&old["steps"][i]);s["name"]=json!(name);steps.push(s);}
 fs::create_dir_all(format!("{R}/libs")).unwrap();for p in children{pins.insert(p.clone(),hash(&p));}
 for tail in["design.md","leaf.rs","leaf-tests.rs","controller.rs","controller-tests.rs","workspace.rs","workspace-tests.rs","prepare.rs","source-audit.json","probe-export.rs"]{let p=format!("{R}/{tail}");pins.insert(p.clone(),hash(&p));}
 for s in &steps{for v in s["argv"].as_array().unwrap(){let a=v.as_str().unwrap();let p=a.split_once('=').map_or(a,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.to_owned(),hash(p));}}}pins.insert(manifest.clone(),hash(&manifest));
 save(&format!("{R}/pins.json"),&json!(pins));save(&format!("{R}/plan.json"),&json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps}));println!("prepared178sources/172exact/176recoverable/6commands;no timing/proofs");
}
