//! Indexed wide windows over already-split exclusive Phi2 scalars.
use super::{hb_digit,hb_window,G2Affine,G2Projective};
use rayon::prelude::*;
const HALF:usize=8192;const CELL:usize=256;const CLASSES:usize=4*HALF;
struct Index{starts:Vec<u32>,order:Vec<u32>}
impl Index{
    fn new(bases:&[G2Affine],short:&[[u64;4]],w:usize)->Self{
        let n=bases.len();let chunk=n.div_ceil(2);let mut counts=vec![0u16;CLASSES];
        let group=|i:usize,c:usize,d:i16|{let b=d.unsigned_abs()as usize-1;debug_assert!(b<HALF);(b/CELL)*(4*CELL)+(c*2+i/chunk)*CELL+b%CELL};
        for(i,(p,s))in bases.iter().zip(short).enumerate(){if p.is_identity(){continue;}for c in 0..2{let d=hb_digit(s,c!=0,w,14);if d!=0{let g=group(i,c,d);counts[g]=counts[g].checked_add(1).expect("one part/component has at most32768 inputs");}}}
        let mut starts=Vec::with_capacity(CLASSES+1);starts.push(0u32);for &n in &counts{starts.push(starts.last().copied().unwrap()+u32::from(n));}
        let mut positions=starts[..CLASSES].to_vec();let mut order=vec![0u32;starts[CLASSES]as usize];
        for(i,(p,s))in bases.iter().zip(short).enumerate(){if p.is_identity(){continue;}for c in 0..2{let d=hb_digit(s,c!=0,w,14);if d!=0{let g=group(i,c,d);order[positions[g]as usize]=i as u32|if d<0{1<<31}else{0};positions[g]+=1;}}}
        drop(counts);drop(positions);Self{starts,order}
    }
    fn largest_leaf(&self)->usize{(0..32).map(|b|(self.starts[(b+1)*4*CELL]-self.starts[b*4*CELL])as usize).max().unwrap()}
}
fn combine(partials:Vec<(G2Projective,G2Affine)>)->G2Projective{
    let mut sum=G2Projective::IDENTITY;let mut offset=G2Projective::IDENTITY;let mut running=G2Projective::IDENTITY;
    for(w,t)in partials.into_iter().rev(){sum+=w;offset+=running;running+=t;}
    for _ in 0..8{offset=offset.double();}sum+offset
}
fn admitted(bases:&[G2Affine],short:&[[u64;4]],held:Option<usize>,deny_leaf:bool)->Option<G2Projective>{
    if bases.len()!=short.len()||!(1024..65536).contains(&bases.len()){return None;}
    if !crate::msm::BatchAdd::<zopro_bn254::G2Config>::default().borrowed_g2_enabled(){return None;}
    let held=held?;let _parent_owner=crate::preparation::Reservation::analysis(Some(held))?;
    let indices=(0..9).into_par_iter().map(|w|Index::new(bases,short,w)).collect::<Vec<_>>();
    let largest=indices.iter().map(Index::largest_leaf).max().unwrap();
    let leaf_charge=super::super::workspace::indexed_wide_leaf_charge(bases.len(),rayon::current_num_threads(),largest)?;
    if deny_leaf{return None;}
    let _leaf_owner=crate::preparation::Reservation::analysis(Some(leaf_charge))?;
    #[cfg(zopro_coalesce_probe)]crate::coalesce_query_probe::record(held.checked_add(leaf_charge)?);
    let chunk=bases.len().div_ceil(2);
    let sums=(0..10).into_par_iter().map(|w|{
        if w==9{
            let mut parts=(0..2).into_par_iter().map(|p|{let first=(p*chunk).min(bases.len());let last=(first+chunk).min(bases.len());hb_window(&bases[first..last],&short[first..last],9,14)}).collect::<Vec<_>>();
            let mut out=parts.swap_remove(0);for p in parts{super::super::merge_buckets(&mut out,&p);}crate::msm::weighted_affine(&out)
        }else{
            let index=&indices[w];let partials=(0..32).into_par_iter().map(|b|crate::msm::indexed_wide_leaf(bases,&index.order,&index.starts[b*4*CELL..(b+1)*4*CELL+1])).collect::<Vec<_>>();combine(partials)
        }
    }).collect::<Vec<_>>();
    let mut result=G2Projective::IDENTITY;for &s in sums.iter().rev(){for _ in 0..14{result=result.double();}result+=s;}Some(result)
}
pub(super) fn try_query(bases:&[G2Affine],short:&[[u64;4]])->Option<G2Projective>{
    #[cfg(test)]let denial=indexed_wide_tests::DENIAL.with(|d|d.get());
    #[cfg(not(test))]let denial=0u8;
    let held=if denial==1{None}else{super::super::workspace::indexed_wide_held(bases.len())};
    admitted(bases,short,held,denial==2)
}
