use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::{BTreeMap, BTreeSet}, fs, path::Path};
mod recoding;
const R: &str = "/home/ubuntu/src/zopro-perf-work/recursive-reuse237";
fn read(p: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(p).unwrap()).unwrap() }
fn hash(p: impl AsRef<Path>) -> String { format!("{:x}", Sha256::digest(fs::read(p).unwrap())) }
fn u32at(b: &[u8], p: usize) -> usize { u32::from_le_bytes(b[p..p + 4].try_into().unwrap()) as usize }
fn u64at(b: &[u8], p: usize) -> u64 { u64::from_le_bytes(b[p..p + 8].try_into().unwrap()) }
fn balanced(s: [u64; 4]) -> Vec<i16> {
    let bit = |i: usize| if i < 256 { ((s[i / 64] >> (i % 64)) & 1) as i32 } else { 0 };
    (0..20).map(|w| {
        let lo = w * 255 / 20; let hi = (w + 1) * 255 / 20;
        let unsigned: i32 = (lo..hi).map(|i| bit(i) << (i - lo)).sum();
        (unsigned + if lo == 0 { 0 } else { bit(lo - 1) } - (bit(hi - 1) << (hi - lo))) as i16
    }).collect()
}
fn main() {
    assert!(!Path::new(R).join("review.json").exists());
    for (p, h) in read(format!("{R}/pins-v2.json")).as_object().unwrap() { assert_eq!(hash(p), h.as_str().unwrap()); }
    let plan = read(format!("{R}/plan-v2.json")); let steps = plan["steps"].as_array().unwrap(); assert_eq!(steps.len(), 5);
    let inherited = read(format!("{R}/plan.json"))["steps"][0].clone();
    let mut receipts = vec![("run", &inherited)];
    receipts.extend(steps[..4].iter().map(|s| ("run-v2", s)));
    for (folder, step) in receipts { let path = format!("{R}/{folder}/{}", step["name"].as_str().unwrap()); let e = read(format!("{path}/exit.json")); assert_eq!(e["success"], true); assert_eq!(e["returncode"], 0); for s in ["stdout", "stderr"] { assert_eq!(hash(format!("{path}/{s}.log")), e[format!("{s}_sha256")]); } assert_eq!(&read(format!("{path}/command.json"))["argv"].as_array().unwrap()[4..], step["argv"].as_array().unwrap()); }
    assert_eq!(read(format!("{R}/run/compile-study/exit.json"))["returncode"], 1);
    let manifest = read("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-18-paired-weighted-adoption236/artifacts/production-source-manifest.json");
    assert_eq!(manifest["source_files_sha256"].as_object().unwrap().len(), 188);
    for (f, h) in manifest["source_files_sha256"].as_object().unwrap() { assert_eq!(hash(format!("/home/ubuntu/src/zk-tools/zopro/{f}")), h.as_str().unwrap()); }
    let analysis = read(format!("{R}/analysis.json")); let mut reviews = vec![];
    for input in read(format!("{R}/inputs.json")).as_array().unwrap() {
        let name = input["name"].as_str().unwrap(); let output = analysis["cases"].as_array().unwrap().iter().find(|v| v["case"] == name).unwrap();
        let bytes = fs::read(input["file"].as_str().unwrap()).unwrap(); assert_eq!(hash(input["file"].as_str().unwrap()), input["sha256"]);
        let g2 = input["kind"] == "G2"; let count = if g2 { assert_eq!(&bytes[..8], b"B2SCAN01"); u64at(&bytes, 8) as usize } else { assert_eq!(&bytes[..8], b"TAGPHI01"); (u64at(&bytes, 8) + u64at(&bytes, 16)) as usize };
        let mut words = BTreeMap::<[u64; 4], usize>::new(); let (mut zero, mut identity) = (0, 0);
        for i in 0..count { let id = if g2 { bytes[16 + i * 128..16 + (i + 1) * 128].iter().all(|&v| v == 0) } else { bytes[64 + i * 65 + 64] != 0 }; if id { identity += 1; continue; } let at = if g2 { 16 + count * 128 + i * 32 } else { 64 + i * 65 }; let row = core::array::from_fn(|j| u64at(&bytes, at + j * 8)); if row == [0; 4] { zero += 1; } else { *words.entry(row).or_default() += 1; } }
        let original: Vec<Vec<i16>> = words.keys().map(|&w| if g2 { recoding::codes(w).to_vec() } else { balanced(w) }).collect();
        let raw_arrivals: usize = original.iter().zip(words.values()).map(|(r, m)| r.iter().filter(|&&v| v != 0).count() * m).sum();
        let class_arrivals = original.iter().flatten().filter(|&&v| v != 0).count(); let exact_forms = words.values().sum::<usize>() - words.len();
        assert_eq!(output["raw_rows"], count); assert_eq!(output["identity_rows"], identity); assert_eq!(output["zero_scalar_rows"], zero); assert_eq!(output["exact_class_point_formations"], exact_forms);
        let dag = fs::read(output["dag_file"].as_str().unwrap()).unwrap(); assert_eq!(hash(output["dag_file"].as_str().unwrap()), output["dag_sha256"]); assert_eq!(&dag[..8], b"RCSRE001");
        let (width, n, total) = (u32at(&dag, 8), u32at(&dag, 12), u32at(&dag, 16)); assert_eq!(n, original.len()); assert_eq!(width, original[0].len()); let forms = total - n;
        assert_eq!(dag.len(), 20 + total * width * 2 + forms * 12); let mut values = vec![vec![0i16; width]; total];
        for i in 0..total { for w in 0..width { let p = 20 + 2 * (i * width + w); values[i][w] = i16::from_le_bytes(dag[p..p + 2].try_into().unwrap()); } }
        let mut edges = vec![None; n]; let mut depth = vec![0usize; n];
        for i in n..total { let at = 20 + total * width * 2 + (i - n) * 12; let (a, b) = (u32at(&dag, at), u32at(&dag, at + 4)); let sign = i32::from_le_bytes(dag[at + 8..at + 12].try_into().unwrap()) as i16; assert!(a < i && b < i && a != b && [1, -1].contains(&sign)); edges.push(Some((a, b, sign))); depth.push(depth[a].max(depth[b]) + 1); }
        // Independently expand each live output into original formal basis vectors.
        let mut coefficients = vec![vec![0i64; width]; n]; let mut visits = 0usize;
        for (root, row) in values.iter().enumerate() { for w in 0..width { if row[w] == 0 { continue; } let mut pending = vec![(root, i64::from(row[w]))]; while let Some((id, coefficient)) = pending.pop() { if let Some((a, b, sign)) = edges[id] { pending.push((b, coefficient.checked_mul(i64::from(sign)).unwrap())); pending.push((a, coefficient)); } else { visits += 1; coefficients[id][w] = coefficients[id][w].checked_add(coefficient).unwrap(); } } } }
        for i in 0..n { for w in 0..width { assert_eq!(coefficients[i][w], i64::from(original[i][w])); } }
        let remaining = values.iter().flatten().filter(|&&d| d != 0).count(); let mut restored = values.clone(); let mut transferred = 0;
        // Recover local pre-merge states in reverse, checking every matching column moved.
        for i in (n..total).rev() { let (a, b, sign) = edges[i].unwrap(); let k = restored[i].iter().filter(|&&d| d != 0).count(); assert!(k >= 2); transferred += k; for w in 0..width { let d = restored[i][w]; if d == 0 { assert!(restored[a][w] == 0 || restored[a][w] != sign * restored[b][w]); } else { assert_eq!(restored[a][w], 0); assert_eq!(restored[b][w], 0); restored[a][w] = d; restored[b][w] = sign * d; } } }
        assert_eq!(&restored[..n], original); assert_eq!(class_arrivals, remaining + transferred); assert!(forms <= class_arrivals / 2);
        let net = transferred - forms; let exact = raw_arrivals - class_arrivals - exact_forms;
        for (key, value) in [("exact_scalar_classes", n), ("raw_nonzero_arrivals", raw_arrivals), ("exact_class_arrivals", class_arrivals), ("recursive_point_formations", forms), ("final_nonzero_arrivals", remaining), ("recursive_net_saved", net), ("combined_net_saved", exact + net), ("maximum_depth", *depth.iter().max().unwrap()), ("transferred_columns", transferred)] { assert_eq!(output[key], value, "{name}:{key}"); }
        assert_eq!(output["recursive_fraction_of_class_arrivals"].as_f64().unwrap(), net as f64 / class_arrivals as f64);
        reviews.push(json!({"case":name,"original_coefficients_checked":n*width,"leaf_visits":visits,"node_edges_checked":forms,"all_formal_coefficients_exact":true,"all_local_merge_guards_and_transfers_exact":true}));
    }
    let ledger = "/home/ubuntu/src/zopro-perf-work/paired-weighted-profile235/proof-sha256-after-profile.json"; let hashes: BTreeSet<String> = serde_json::from_value(read(ledger)).unwrap(); assert_eq!(hashes.len(), 62187); assert_eq!(hash(ledger), "38314450cd7201e88e527845db52c4de60479688cc2c7b8d0201c4d472596ff3");
    fs::write(format!("{R}/review.json"), serde_json::to_vec_pretty(&json!({"passed":true,"cases":reviews,"current188_production_hashes_pass":true,"canonical_count":62187,"canonical_sha256":hash(ledger),"new_exports":0,"scope":"Independent output-to-leaf coefficient expansion and reverse local merge legality; shared inherited GLV recoder; KH bit recoder independent; does not replay optimizer choice order"})).unwrap()).unwrap();
    println!("Independent formal DAG review PASS; current188source and canonical62187 unchanged");
}
