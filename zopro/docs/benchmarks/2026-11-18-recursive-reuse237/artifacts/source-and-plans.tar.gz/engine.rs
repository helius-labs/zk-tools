#[derive(Clone)]
pub struct Node {
    pub codes: Vec<i16>,
    pub parent: Option<(usize, usize, i16)>,
    pub depth: usize,
}

pub struct Forest {
    pub nodes: Vec<Node>,
    pub passes: Vec<usize>,
    pub transferred: usize,
    pub maximum_key_capacity_bytes: usize,
    pub signature_rows: usize,
}

pub fn build(original: &[Vec<i16>]) -> Forest {
    let width = original.first().map_or(0, Vec::len);
    assert!(original.iter().all(|r| r.len() == width));
    let initial = original.iter().flatten().filter(|&&d| d != 0).count();
    let mut nodes: Vec<_> = original.iter().map(|r| Node {
        codes: r.clone(), parent: None, depth: 0,
    }).collect();
    let mut passes = Vec::new();
    let (mut transferred, mut maximum_key_capacity_bytes, mut signature_rows) = (0, 0, 0);
    loop {
        let before = nodes.len();
        for a in 0..width {
            for b in a + 1..width {
                let mut keys = Vec::new();
                for (i, node) in nodes.iter().enumerate() {
                    let (x, y) = (node.codes[a], node.codes[b]);
                    if x == 0 || y == 0 { continue; }
                    keys.push((if x < 0 { -x } else { x }, if x < 0 { -y } else { y }, i));
                }
                signature_rows += keys.len();
                maximum_key_capacity_bytes = maximum_key_capacity_bytes.max(keys.capacity() * core::mem::size_of::<(i16, i16, usize)>());
                keys.sort_unstable();
                let mut lo = 0;
                while lo < keys.len() {
                    let mut hi = lo + 1;
                    while hi < keys.len() && (keys[hi].0, keys[hi].1) == (keys[lo].0, keys[lo].1) { hi += 1; }
                    let mut current = keys[lo].2;
                    for &(_, _, next) in &keys[lo + 1..hi] {
                        let sign = if nodes[current].codes[a] == nodes[next].codes[a] { 1 } else { -1 };
                        let mut result = vec![0; width];
                        let mut matched = 0;
                        for w in 0..width {
                            let d = nodes[current].codes[w];
                            if d != 0 && d == sign * nodes[next].codes[w] {
                                result[w] = d;
                                nodes[current].codes[w] = 0;
                                nodes[next].codes[w] = 0;
                                matched += 1;
                            }
                        }
                        assert!(matched >= 2);
                        let depth = nodes[current].depth.max(nodes[next].depth) + 1;
                        nodes.push(Node { codes: result, parent: Some((current, next, sign)), depth });
                        current = nodes.len() - 1;
                        transferred += matched;
                        assert!(nodes.len() - original.len() <= initial / 2);
                    }
                    lo = hi;
                }
            }
        }
        let added = nodes.len() - before;
        passes.push(added);
        if added == 0 { break; }
    }
    let remaining = nodes.iter().flat_map(|n| &n.codes).filter(|&&d| d != 0).count();
    assert_eq!(initial, remaining + transferred);
    let mut back: Vec<Vec<i64>> = nodes.iter().map(|n| n.codes.iter().map(|&d| i64::from(d)).collect()).collect();
    for i in (original.len()..nodes.len()).rev() {
        let (left, right, sign) = nodes[i].parent.unwrap();
        assert!(left < i && right < i && left != right);
        for w in 0..width {
            back[left][w] = back[left][w].checked_add(back[i][w]).unwrap();
            back[right][w] = back[right][w].checked_add(back[i][w].checked_mul(i64::from(sign)).unwrap()).unwrap();
        }
    }
    for (i, row) in original.iter().enumerate() {
        assert_eq!(back[i], row.iter().map(|&d| i64::from(d)).collect::<Vec<_>>());
    }
    Forest { nodes, passes, transferred, maximum_key_capacity_bytes, signature_rows }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn oracle(rows: Vec<Vec<i16>>) -> Forest {
        let forest = build(&rows);
        let n = rows.len();
        let width = rows.first().map_or(0, Vec::len);
        let mut vectors = Vec::<Vec<i64>>::new();
        for (i, node) in forest.nodes.iter().enumerate() {
            let v = if let Some((a, b, sign)) = node.parent {
                (0..n).map(|j| vectors[a][j] + i64::from(sign) * vectors[b][j]).collect()
            } else { (0..n).map(|j| i64::from(i == j)).collect() };
            vectors.push(v);
        }
        for i in 0..n {
            for w in 0..width {
                let actual: i64 = forest.nodes.iter().zip(&vectors).map(|(node, v)| i64::from(node.codes[w]) * v[i]).sum();
                assert_eq!(actual, i64::from(rows[i][w]));
            }
        }
        forest
    }
    #[test]
    fn exhaustive_signed_three_by_three() {
        for mut code in 0..3usize.pow(9) {
            let mut rows = vec![vec![0; 3]; 3];
            for row in &mut rows { for d in row { *d = (code % 3) as i16 - 1; code /= 3; } }
            oracle(rows);
        }
    }
    #[test]
    fn recursive_depth_residual_reuse_and_empty_cases() {
        let forest = oracle(vec![vec![1, 2, 3]; 7]);
        assert!(forest.nodes.iter().map(|n| n.depth).max().unwrap() >= 6);
        let forest = oracle(vec![vec![1, 1, 1, 1], vec![1, 1, 0, 0], vec![0, 0, -1, -1]]);
        assert_eq!(forest.nodes.len(), 5);
        assert_eq!(forest.transferred, 4);
        oracle(vec![]); oracle(vec![vec![]]); oracle(vec![vec![0, 0], vec![0, 0]]);
        oracle(vec![vec![1], vec![-1]]);
    }
}
