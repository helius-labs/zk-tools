use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, time::Instant};
mod engine;
mod recoding;
const R: &str = "/home/ubuntu/src/zopro-perf-work/recursive-reuse237";
fn hash(p: impl AsRef<Path>) -> String { format!("{:x}", Sha256::digest(fs::read(p).unwrap())) }
fn read(p: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(p).unwrap()).unwrap() }
fn word(bytes: &[u8], at: usize) -> u64 { u64::from_le_bytes(bytes[at..at + 8].try_into().unwrap()) }
fn balanced(words: [u64; 4]) -> Vec<i16> {
    (0..20).map(|i| {
        let start = i * 255 / 20;
        let width = (i + 1) * 255 / 20 - start;
        if start == 0 { let x = words[0] & ((1 << width) - 1); return (x as i64 - ((x >> (width - 1)) << width) as i64) as i16; }
        let at = start - 1; let (j, shift) = (at / 64, at % 64);
        let mut x = words[j] >> shift;
        if shift + width + 1 > 64 && j < 3 { x |= words[j + 1] << (64 - shift); }
        x &= (1 << (width + 1)) - 1;
        (((x + 1) >> 1) as i64 - ((x >> width) << width) as i64) as i16
    }).collect()
}
fn load(case: &Value) -> (usize, usize, usize, BTreeMap<[u64; 4], usize>) {
    let bytes = fs::read(case["file"].as_str().unwrap()).unwrap();
    assert_eq!(hash(case["file"].as_str().unwrap()), case["sha256"]);
    let g2 = case["kind"] == "G2";
    let n = if g2 { assert_eq!(&bytes[..8], b"B2SCAN01"); word(&bytes, 8) as usize }
        else { assert_eq!(&bytes[..8], b"TAGPHI01"); (word(&bytes, 8) + word(&bytes, 16)) as usize };
    assert_eq!(bytes.len(), if g2 { 16 + 160 * n } else { 64 + 65 * n });
    let (mut zero, mut identity) = (0, 0);
    let mut groups = BTreeMap::new();
    for i in 0..n {
        let id = if g2 { bytes[16 + 128 * i..16 + 128 * (i + 1)].iter().all(|&x| x == 0) }
            else { assert!(bytes[64 + 65 * i + 64] <= 1); bytes[64 + 65 * i + 64] == 1 };
        if id { identity += 1; continue; }
        let at = if g2 { 16 + 128 * n + 32 * i } else { 64 + 65 * i };
        let words = core::array::from_fn(|j| word(&bytes, at + 8 * j));
        if words == [0; 4] { zero += 1; continue; }
        *groups.entry(words).or_insert(0) += 1;
    }
    (n, zero, identity, groups)
}
fn main() {
    assert!(!Path::new(R).join("analysis.json").exists());
    let start = Instant::now();
    for (p, h) in read(format!("{R}/pins.json")).as_object().unwrap() { assert_eq!(hash(p), h.as_str().unwrap()); }
    let mut cases = vec![];
    for case in read(format!("{R}/inputs.json")).as_array().unwrap() {
        let case_start = Instant::now();
        let name = case["name"].as_str().unwrap();
        let (raw, zeros, identities, groups) = load(case);
        let original: Vec<Vec<i16>> = groups.keys().map(|&words| if case["kind"] == "G2" { recoding::codes(words).to_vec() } else { balanced(words) }).collect();
        let raw_arrivals: usize = original.iter().zip(groups.values()).map(|(r, &m)| r.iter().filter(|&&d| d != 0).count() * m).sum();
        let class_arrivals = original.iter().flatten().filter(|&&d| d != 0).count();
        let exact_forms = groups.values().sum::<usize>() - groups.len();
        let forest = engine::build(&original);
        let nodes = &forest.nodes;
        let width = original[0].len();
        let forms = nodes.len() - original.len();
        let final_arrivals = nodes.iter().flat_map(|n| &n.codes).filter(|&&d| d != 0).count();
        let net = class_arrivals - final_arrivals - forms;
        let exact_saving = raw_arrivals - class_arrivals - exact_forms;
        let path = format!("{R}/{name}-dag.private.bin"); assert!(!Path::new(&path).exists());
        let mut bytes = b"RCSRE001".to_vec();
        for n in [width, original.len(), nodes.len()] { bytes.extend_from_slice(&u32::try_from(n).unwrap().to_le_bytes()); }
        for node in nodes { for d in &node.codes { bytes.extend_from_slice(&d.to_le_bytes()); } }
        for node in &nodes[original.len()..] { let (a, b, sign) = node.parent.unwrap(); for n in [i32::try_from(a).unwrap(), i32::try_from(b).unwrap(), i32::from(sign)] { bytes.extend_from_slice(&n.to_le_bytes()); } }
        fs::write(&path, &bytes).unwrap();
        let output = json!({"case":name,"kind":case["kind"],"raw_rows":raw,"identity_rows":identities,"zero_scalar_rows":zeros,"exact_scalar_classes":groups.len(),"raw_nonzero_arrivals":raw_arrivals,"exact_class_arrivals":class_arrivals,"exact_class_point_formations":exact_forms,"exact_class_net_saved":exact_saving,"recursive_point_formations":forms,"final_nonzero_arrivals":final_arrivals,"recursive_net_saved":net,"recursive_fraction_of_class_arrivals":net as f64/class_arrivals as f64,"combined_net_saved":exact_saving+net,"combined_fraction_of_raw_arrivals":(exact_saving+net)as f64/raw_arrivals as f64,"passes_formations":forest.passes,"maximum_depth":nodes.iter().map(|n|n.depth).max().unwrap(),"point_node_count":nodes.len(),"live_final_nodes":nodes.iter().filter(|n|n.codes.iter().any(|&d|d!=0)).count(),"transferred_columns":forest.transferred,"exact_all_original_column_coefficients_recovered":true,"signature_rows_sorted":forest.signature_rows,"maximum_signature_vector_capacity_bytes":forest.maximum_key_capacity_bytes,"diagnostic_node_header_capacity_bytes":nodes.capacity()*core::mem::size_of::<engine::Node>(),"diagnostic_node_code_capacity_bytes":nodes.iter().map(|n|n.codes.capacity()*2).sum::<usize>(),"hypothetical_new_affine_point_payload_bytes":forms*if case["kind"]=="G2"{128}else{64},"actual_native_point_allocations":0,"dag_file":path,"dag_sha256":hash(&path),"dag_bytes":bytes.len(),"elapsed_seconds":case_start.elapsed().as_secs_f64()});
        println!("{name}: recursive additional saving {net}/{class_arrivals}; {} formations; depth{}", forms, output["maximum_depth"]);
        cases.push(output);
    }
    fs::write(format!("{R}/analysis.json"), serde_json::to_vec_pretty(&json!({"complete":true,"cases":cases,"elapsed_seconds":start.elapsed().as_secs_f64(),"native_implementation_selected":false,"new_SDK_calls":0,"new_exports":0,"canonical_count":62187,"production_changed":false,"adopted":false,"goal_complete":false,"scope":"Fixed recursive signed construction; formal coefficient conservation, not curve exceptions, wall latency or a general optimum/bound"})).unwrap()).unwrap();
}
