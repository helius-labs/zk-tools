use serde_json::{json,Value};
use std::{collections::BTreeMap,fs,path::Path};
use zopro_bn254::Fr;
#[path="/home/ubuntu/src/zopro-perf-work/tau9-ring-work176/split.rs"] mod split;
const R:&str="/home/ubuntu/src/zopro-perf-work/global-window-pair-bound176";
const LAMBDA:Fr=Fr::from_decimal("4407920970296243842393367215006156084916469457145843978461");
pub type Codes=[i16;22];
fn field(x:i128)->Fr{let n=x.unsigned_abs();let f=Fr::from_canonical([n as u64,(n>>64)as u64,0,0]).unwrap();if x<0{-f}else{f}}
pub fn codes(w:[u64;4])->Codes{
 let s=split::phi_split(w);let pair: [i128;2]=std::array::from_fn(|c|{let n=(s[2*c]as u128)|((s[2*c+1]&0x7fff_ffff_ffff_ffff)as u128)<<64;let x=i128::try_from(n).unwrap();if s[2*c+1]>>63!=0{-x}else{x}});
 let out=std::array::from_fn(|j|{let c=j/11;let n=pair[c].unsigned_abs();let d=split::booth(&[n as u64,(n>>64)as u64,0,0],j%11,12);if pair[c]<0{-d}else{d}});
 for c in 0..2{let n=(0..11).rev().fold(0i128,|v,j|v*4096+out[11*c+j]as i128);assert_eq!(n,pair[c]);}
 assert_eq!(field(pair[0])+LAMBDA*field(pair[1]),Fr::from_canonical(w).unwrap());out
}
