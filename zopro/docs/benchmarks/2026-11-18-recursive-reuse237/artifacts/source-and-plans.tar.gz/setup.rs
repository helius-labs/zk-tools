use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/recursive-reuse237";
fn read(p: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(p).unwrap()).unwrap() }
fn hash(p: impl AsRef<Path>) -> String { format!("{:x}", Sha256::digest(fs::read(p).unwrap())) }
fn main() {
    assert!(!Path::new(R).join("pins.json").exists());
    let prior = "/home/ubuntu/src/zopro-perf-work/global-window-pair-bound176/study.rs";
    let source = fs::read_to_string(prior).unwrap(); let prefix = &source[..source.find("fn key(").unwrap()];
    assert_eq!(prefix.matches("fn codes(").count(), 1); assert_eq!(prefix.matches("type Codes=").count(), 1);
    let recoder = prefix.replace("fn codes(", "pub fn codes(").replace("type Codes=", "pub type Codes=");
    fs::write(format!("{R}/recoding.rs"), recoder).unwrap();
    let inputs = read("/home/ubuntu/src/zopro-perf-work/tau9-ring-work176/inputs.json");
    let mut cases = vec![];
    for (name, input) in inputs.as_object().unwrap() { assert_eq!(hash(input["file"].as_str().unwrap()), input["sha256"]); cases.push(json!({"name":name,"kind":"G2","file":input["file"],"sha256":input["sha256"],"provenance_receipt":input["provenance_receipt"]})); }
    let cache = "/home/ubuntu/src/zopro-perf-work/g1-tagged-phi-review176/private-input-cache.bin";
    assert_eq!(read("/home/ubuntu/src/zopro-perf-work/g1-tagged-phi-review176/review.json")["review_passed"], true);
    assert_eq!(hash(cache), read("/home/ubuntu/src/zopro-perf-work/g1-tagged-phi-review176/analysis.json")["cache"]["sha256"]);
    cases.push(json!({"name":"1x2-KH","kind":"G1","file":cache,"sha256":hash(cache)}));
    fs::write(format!("{R}/inputs.json"), serde_json::to_vec_pretty(&cases).unwrap()).unwrap();
    let oldplan = read("/home/ubuntu/src/zopro-perf-work/global-window-pair-bound176/plan.json");
    let base = oldplan["steps"][0]["argv"].as_array().unwrap();
    let mut steps = vec![];
    for (source, binary, test) in [("engine", "engine-tests", true), ("study", "study", false), ("review", "review", false)] {
        let mut argv: Vec<String> = base.iter().map(|a| a.as_str().unwrap().to_owned()).filter(|a| a != "--test").collect();
        for a in &mut argv { if a == prior { *a = format!("{R}/{source}.rs"); } else if a == "/home/ubuntu/src/zopro-perf-work/global-window-pair-bound176/study-tests" { *a = format!("{R}/{binary}"); } }
        if test { argv.push("--test".into()); }
        steps.push(json!({"kind":"command","name":format!("compile-{binary}"),"argv":argv,"timeout_seconds":300}));
    }
    steps.push(json!({"kind":"command","name":"new-recursive-formal-oracles","argv":[format!("{R}/engine-tests"),"--test-threads=1"],"timeout_seconds":120,"unfiltered":true}));
    steps.push(json!({"kind":"command","name":"fixed-three-fixture-recursive-count","argv":[format!("{R}/study")],"timeout_seconds":300}));
    steps.push(json!({"kind":"command","name":"independent-formal-DAG-review","argv":[format!("{R}/review")],"timeout_seconds":300}));
    let mut pins = BTreeMap::<String, String>::new();
    for f in ["protocol.md", "engine.rs", "study.rs", "review.rs", "setup.rs", "setup", "recoding.rs", "inputs.json"] { let p = format!("{R}/{f}"); pins.insert(p.clone(), hash(p)); }
    for p in [prior, "/home/ubuntu/src/zopro-perf-work/tau9-ring-work176/split.rs", "/home/ubuntu/src/zopro-perf-work/global-window-pair-bound176/analysis.json", "/home/ubuntu/src/zopro-perf-work/global-window-pair-bound176/review.json", "/home/ubuntu/src/zopro-perf-work/g1-tagged-phi-review176/analysis.json", "/home/ubuntu/src/zopro-perf-work/g1-tagged-phi-review176/review.json", "/home/ubuntu/src/zopro-perf-work/paired-weighted-profile235/proof-sha256-after-profile.json"] { pins.insert(p.into(), hash(p)); }
    for case in &cases { for key in ["file", "provenance_receipt"] { if let Some(p) = case[key].as_str() { pins.insert(p.into(), hash(p)); } } }
    let manifest = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-18-paired-weighted-adoption236/artifacts/production-source-manifest.json";
    pins.insert(manifest.into(), hash(manifest));
    for (f, h) in read(manifest)["source_files_sha256"].as_object().unwrap() { let p = format!("/home/ubuntu/src/zk-tools/zopro/{f}"); assert_eq!(hash(&p), h.as_str().unwrap()); pins.insert(p, h.as_str().unwrap().into()); }
    for s in &steps { for a in s["argv"].as_array().unwrap() { let a = a.as_str().unwrap(); let p = a.split_once('=').map_or(a, |(_, p)| p); if Path::new(p).is_file() { pins.insert(p.into(), hash(p)); } } }
    let plan = json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps});
    fs::write(format!("{R}/plan.json"), serde_json::to_vec_pretty(&plan).unwrap()).unwrap(); pins.insert(format!("{R}/plan.json"), hash(format!("{R}/plan.json")));
    fs::write(format!("{R}/pins.json"), serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
    println!("Frozen six commands; three retained input sets; current188source bound; no native/SDK changes");
}
