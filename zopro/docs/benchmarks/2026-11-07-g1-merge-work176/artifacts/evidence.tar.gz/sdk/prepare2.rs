use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g1-merge-work176";
const P: &str = "/home/ubuntu/src/zopro-perf-work/large-canonical-sdk176";
fn read(p: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(p).unwrap()).unwrap() }
fn hash(p: impl AsRef<Path>) -> String { format!("{:x}", Sha256::digest(fs::read(p).unwrap())) }
fn main() {
    let mp = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json";
    let m = read(mp);
    let mut pins = BTreeMap::new();
    assert!(Path::new(&format!("{R}/source")).exists());
    for (n, h) in m["source_files_sha256"].as_object().unwrap() {
        let from = format!("/home/ubuntu/src/zk-tools/zopro/{n}");
        assert_eq!(hash(&from), h.as_str().unwrap());
        let existing = fs::read(format!("{R}/source/{n}")).unwrap();
        let recovered = if n == "crates/zopro-core/src/lib.rs" {
            String::from_utf8(existing).unwrap().replacen("mod msm;\n#[cfg(zopro_merge_work)] pub mod merge_work;", "mod msm;", 1).into_bytes()
        } else { existing };
        assert_eq!(format!("{:x}", Sha256::digest(recovered)), h.as_str().unwrap());
        pins.insert(from, h.as_str().unwrap().to_owned());
    }
    let mut edits = Vec::new();
    for (n, needle, replacement) in [
        ("crates/zopro-core/src/lib.rs", "mod msm;", "mod msm;\n#[cfg(zopro_merge_work)] pub mod merge_work;"),
        ("crates/zopro-core/src/msm.rs", "    let full = batch.len() / LANES * LANES;\n    let mut chains = FqBatch::one();", "    #[cfg(zopro_merge_work)] crate::merge_work::stream(SIGNED,batch.len(),LANES,core::mem::size_of::<FqAddGroup>());\n    let full = batch.len() / LANES * LANES;\n    let mut chains = FqBatch::one();"),
        ("crates/zopro-core/src/msm_affine.rs", "            if !pairs.is_empty() {\n                BatchAdd::<C>::default().apply(left, &pairs);", "            #[cfg(zopro_merge_work)] crate::merge_work::merge(core::mem::size_of::<C::Base>()==32,left.len(),pairs.len(),core::mem::size_of::<Affine<C>>(),core::mem::size_of::<(u32,Affine<C>)>());\n            if !pairs.is_empty() {\n                BatchAdd::<C>::default().apply(left, &pairs);")
    ] {
        let path = format!("{R}/source/{n}");
        let old = fs::read_to_string(&path).unwrap();
        if n == "crates/zopro-core/src/lib.rs" {
            assert_eq!(old.matches(replacement).count(), 1);
        } else {
            let at = if n == "crates/zopro-core/src/msm.rs" {
                let start = old.find("fn stream_g1_impl<").unwrap();
                let at = start + old[start..].find(needle).unwrap();
                assert!(at - start < 1024);
                at
            } else {
                assert_eq!(old.matches(needle).count(), 1);
                old.find(needle).unwrap()
            };
            let mut changed = old.clone();
            changed.replace_range(at..at + needle.len(), replacement);
            assert_eq!(changed.replacen(replacement, needle, 1), old);
            fs::write(&path, changed).unwrap();
        }
        edits.push(json!({"parent":n,"needle":needle,"replacement":replacement,"original_sha256":m["source_files_sha256"][n]}));
    }
    let child = "crates/zopro-core/src/merge_work.rs";
    assert!(!Path::new(&format!("{R}/source/{child}")).exists());
    fs::copy(format!("{R}/merge_work.rs"), format!("{R}/source/{child}")).unwrap();
    for n in m["source_files_sha256"].as_object().unwrap().keys().map(String::as_str).chain(std::iter::once(child)) {
        let p = format!("{R}/source/{n}"); pins.insert(p.clone(), hash(p));
    }
    fs::write(format!("{R}/source-audit.json"), serde_json::to_vec_pretty(&json!({"edits":edits,"new_child":child,"unchanged_originals":173,"recoverable_originals":176,"repair":"Retain original176file copy and successful lib declaration; scope missing stream hook to stream_g1_impl, not the separate stream_g2 body"})).unwrap()).unwrap();
    let old = read(format!("{P}/native-plan.json"));
    let mut portable = old["steps"][0].clone();
    portable["argv"][3] = format!("{R}/source/Cargo.toml").into();
    portable["environment"]["CARGO_TARGET_DIR"] = format!("{R}/target-portable").into();
    portable["environment"]["RUSTFLAGS"] = "-C target-cpu=generic --cfg no_asm --cfg no_ifma --cfg zopro_merge_work".into();
    let mut build = old["steps"][3].clone();
    build["name"] = "libraries-diagnostic".into();
    build["argv"][3] = format!("{R}/source/Cargo.toml").into();
    build["environment"]["CARGO_TARGET_DIR"] = format!("{R}/target-native").into();
    build["environment"]["RUSTFLAGS"] = format!("{} --cfg zopro_merge_work", m["rustflags"].as_str().unwrap()).into();
    let mut test = build.clone(); test["name"] = "new-recorder-test".into();
    test["environment"]["RAYON_NUM_THREADS"] = "4".into();
    test["argv"] = json!(["/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/cargo","test","--manifest-path",format!("{R}/source/Cargo.toml"),"--locked","--offline","--release","-p","zopro-core","--lib","merge_work::tests::caller_worker_reset_disable_and_layout","--","--exact","--nocapture"]);
    for n in ["design.md","merge_work.rs","driver.rs","prepare.rs","prepare2.rs","preparation-failure.md","source-audit.json"] {
        let p=format!("{R}/{n}");pins.insert(p.clone(),hash(p));
    }
    pins.insert(mp.into(),hash(mp));
    fs::write(format!("{R}/native-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
    fs::write(format!("{R}/native-plan.json"),serde_json::to_vec_pretty(&json!({"version":1,"source_pins":format!("{R}/native-pins.json"),"steps":[portable,test,build,{"kind":"link-sdk","name":"diagnostic","artifacts":format!("{R}/native/libraries-diagnostic/stdout.log"),"driver":format!("{R}/driver.rs"),"additional_sources":[],"timeout_seconds":900}]})).unwrap()).unwrap();
    println!("READY retained original copy/lib edit, remaining scoped hooks;173exact/176recover; new recorder test and diagnostic SDK plan");
}
