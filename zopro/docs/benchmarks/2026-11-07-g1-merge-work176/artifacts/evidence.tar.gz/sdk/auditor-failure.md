# Source-audit reader correction before proof capture

capture3 prepare passes the four successful native receipts and recorder-test output checks, then fails reading an unchanged binary manifest member as UTF-8. No job plan, SDK request or proof is created. Its source remains unchanged. The tool-reported InvalidData failure is summarized here rather than recreated as a raw receipt.

capture4 hashes unchanged source members as bytes and decodes only the three reversibly edited text parents. The current child is still compared byte-for-byte with merge_work2.rs. All successful native artifacts, portable check and recorder test are retained without execution. No proving source, counter implementation or protocol changes.
