use std::cell::RefCell;

#[derive(Default)]
struct State {
    enabled: bool,
    counts: [u64; 24],
}
thread_local! {
    static STATE: RefCell<State> = RefCell::new(State::default());
}

pub fn merge(g1: bool, buckets: usize, pairs: usize, point_bytes: usize, pair_bytes: usize) {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if !state.enabled { return; }
        let at = if g1 { 0 } else { 6 };
        state.counts[at] += 1;
        state.counts[at + 1] += buckets as u64;
        state.counts[at + 2] += pairs as u64;
        state.counts[at + 3] += (pairs * pair_bytes) as u64;
        state.counts[at + 4] = point_bytes as u64;
        state.counts[at + 5] = pair_bytes as u64;
    });
}

pub fn stream(signed: bool, points: usize, lanes: usize, group_bytes: usize) {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if !state.enabled { return; }
        let at = if signed { 18 } else { 12 };
        state.counts[at] += 1;
        state.counts[at + 1] += points as u64;
        state.counts[at + 2] += (points / lanes) as u64;
        state.counts[at + 3] += (points / lanes * group_bytes) as u64;
        state.counts[at + 4] += (points % lanes) as u64;
        state.counts[at + 5] = lanes as u64;
    });
}

fn reset_here() {
    STATE.with(|state| *state.borrow_mut() = State { enabled: true, counts: [0; 24] });
}
fn take_here() -> [u64; 24] {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        state.enabled = false;
        state.counts
    })
}
pub fn reset() {
    assert!(rayon::current_thread_index().is_none());
    reset_here();
    rayon::broadcast(|_| reset_here());
}
pub fn snapshot() -> [u64; 24] {
    assert!(rayon::current_thread_index().is_none());
    let mut out = take_here();
    for row in rayon::broadcast(|_| take_here()) {
        for i in 0..24 {
            if [4, 5, 10, 11, 17, 23].contains(&i) {
                if row[i] != 0 {
                    assert!(out[i] == 0 || out[i] == row[i]);
                    out[i] = row[i];
                }
            } else {
                out[i] += row[i];
            }
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn caller_worker_reset_disable_and_layout() {
        reset();
        merge(true, 512, 8, 64, 72);
        stream(false, 9, 8, 1600);
        let workers = rayon::current_num_threads() as u64;
        rayon::broadcast(|_| {
            merge(true, 128, 4, 64, 72);
            stream(false, 7, 8, 1600);
            stream(true, 16, 8, 1600);
        });
        let got = snapshot();
        assert_eq!(got[0], 1 + workers);
        assert_eq!(got[2], 8 + 4 * workers);
        assert_eq!(got[3], (8 + 4 * workers) * 72);
        assert_eq!((got[4], got[5]), (64, 72));
        assert_eq!(got[13], 9 + 7 * workers);
        assert_eq!(got[14], 1);
        assert_eq!(got[16], 1 + 7 * workers);
        assert_eq!(got[19], 16 * workers);
        assert_eq!(got[20], 2 * workers);
        merge(true, 1, 1, 64, 72);
        stream(false, 8, 8, 1600);
        assert_eq!(snapshot(), got);
        reset();
        assert_eq!(snapshot(), [0; 24]);
    }
}
