# Scoped stream-hook preparation

The first prepare helper copies all176source files and adds the diagnostic module declaration. It then stops because its stream-entry needle occurs twice: once in G1 and once in G2. No build, test, proof, timing or model has run. The original helper source remains, and this note summarizes the tool-observed assertion (expected1, actual2); it is not a reconstructed raw receipt.

prepare2 retains and hash-checks the existing copied files and successful lib declaration. It scopes the missing hook to the beginning of stream_g1_impl and adds the remaining merge hook and child. It does not repeat the initial source-copy stage or alter the untouched G2 streaming body. Reversing the three diagnostic insertions must recover all176original hashes.
