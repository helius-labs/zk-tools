use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/store-frame-clean222";
fn main(){let s=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/certified-all196/screen.rs").unwrap();let start=s.find("fn prepare() {").unwrap();let end=s.find("fn review(phase:").unwrap();let mut new=s[..start].to_owned();new.push_str(&fs::read_to_string(format!("{R}/prepare-body.rs")).unwrap());new.push_str(&s[end..]);new=new.replace("/home/ubuntu/src/zopro-perf-work/certified-all196",R).replace("/home/ubuntu/src/zopro-perf-work/certified-profile195/proof-sha256-after-profile.json","/home/ubuntu/src/zopro-perf-work/store-frame221/proof-sha256-after-main.json");
new=new.replace("if phase == \"preflight\" { 57410 } else { 57433 }","if phase == \"preflight\" { 59095 } else { 59125 }").replace("if phase == \"preflight\" { 57433 } else { 58033 }","if phase == \"preflight\" { 59125 } else { 60025 }").replace("if phase == \"preflight\" { 23 } else { 10200 }","if phase == \"preflight\" { 30 } else { 39420 }");
new=new.replace("if j[\"arm\"]==\"ON\" {", "{");
let a=new.find("fn assess(rows: &[Value]) {").unwrap();let b=new[a..].find("fn main() {").unwrap()+a;new.replace_range(a..b,&fs::read_to_string(format!("{R}/assess-body.rs")).unwrap());
new=new.replace("for arm in [\"REF\",\"ON\"]", "for arm in [\"REF\",\"OFF\",\"ON\"]").replace("assert_eq!(distinct.len(),6)","assert_eq!(distinct.len(),9)");
// Unused old preparation helpers are omitted to keep the captured reader clear.
let a=new.find("fn add(\n").unwrap();let b=new[a..].find("fn verify(").unwrap()+a;new.replace_range(a..b,"");
let a=new.find("fn backing_summary(rows:").unwrap();new.truncate(a);
let p=Path::new(R).join("screen.rs");assert!(!p.exists());fs::write(p,new).unwrap();}
