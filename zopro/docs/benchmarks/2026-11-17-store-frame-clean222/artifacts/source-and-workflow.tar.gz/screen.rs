use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::Read,
    path::{Path, PathBuf},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/store-frame-clean222";
const SEED: &str =
    "/home/ubuntu/src/zopro-perf-work/store-frame221/proof-sha256-after-main.json";
const VERIFY: &str = "/home/ubuntu/src/zopro-perf-work/batch-local-steal/gnark/verify";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn save(p: impl AsRef<Path>, v: &Value) {
    assert!(
        !p.as_ref().exists(),
        "already exists: {}",
        p.as_ref().display()
    );
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn hash(p: impl AsRef<Path>) -> String {
    let mut f = fs::File::open(p).unwrap();
    let mut h = Sha256::new();
    let mut b = [0; 65536];
    loop {
        let n = f.read(&mut b).unwrap();
        if n == 0 {
            break;
        }
        h.update(&b[..n]);
    }
    format!("{:x}", h.finalize())
}
fn command(name: &str, argv: Vec<String>, environment: Value) -> Value {
    json!({"kind":"command","name":name,"argv":argv,"environment":environment,"timeout_seconds":1800})
}
fn receipt(folder: &str, s: &Value) {
    let base = r(format!("{folder}/{}", s["name"].as_str().unwrap()));
    let exit = read(base.join("exit.json"));
    assert_eq!(exit["success"], true);
    assert_eq!(exit["returncode"], 0);
    for stream in ["stdout", "stderr"] {
        assert_eq!(
            hash(base.join(format!("{stream}.log"))),
            exit[format!("{stream}_sha256")]
        );
    }
    let c = read(base.join("command.json"));
    assert_eq!(
        &c["argv"].as_array().unwrap()[4..],
        s["argv"].as_array().unwrap()
    );
    for (k, v) in s["environment"].as_object().into_iter().flatten() {
        // xtask records the benchmark environment allowlist. Compiler selection
        // is retained in the build plan, fingerprints and explicit link receipt.
        if !["PATH", "RUSTC", "RUSTUP_TOOLCHAIN"].contains(&k.as_str()) {
            assert_eq!(c["environment"][k], *v);
        }
    }
}
fn verify(j: &Value) -> Value {
    let c = &j["case"];
    let dir = j["proof_dir"].as_str().unwrap();
    command(
        &format!("verify-{}", j["name"].as_str().unwrap()),
        vec![
            VERIFY.into(),
            c["image"].as_str().unwrap().into(),
            c["image_sha256"].as_str().unwrap().into(),
            format!("{dir}/0.proof"),
            format!("{dir}/0.public"),
            c["public_sha256"].as_str().unwrap().into(),
        ],
        json!({}),
    )
}
fn prepare(){
 use std::os::unix::fs::{MetadataExt,PermissionsExt};
 assert_eq!(hash(SEED),"8bde73fa8b3e9b3507774334d3acf8a1631dd51d8ba60cb5ab71324df3378ba2");
 let mut pins=BTreeMap::<String,String>::new();for(p,h)in read(r("build-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pins.insert(p.clone(),h.as_str().unwrap().into());}
 let mut ids=json!({});fs::create_dir(r("bins")).unwrap();for arm in["REF","OFF","ON"]{let sdk=if arm=="REF"{PathBuf::from("/home/ubuntu/src/zopro-perf-work/certified-proof194/build-run-v2/candidate-sdk")}else{r(format!("native-{arm}/candidate-sdk"))};if arm=="REF"{assert_eq!(hash(&sdk),"bcc8e0775bb5bc6c09ad86b1987ca45eebac62617340911266c84aa601fa05b1");}let mut copies=vec![];for i in 0..3{let p=r(format!("bins/{arm}{i}"));fs::copy(&sdk,&p).unwrap();let m=fs::metadata(&p).unwrap();let h=hash(&p);pins.insert(p.display().to_string(),h.clone());copies.push(json!({"path":p,"sha256":h,"device":m.dev(),"inode":m.ino(),"mode":m.permissions().mode()}));}ids[arm]=json!({"sha256":hash(sdk),"copies":copies});}check_copies(&ids);save(r("runtime-consumers.json"),&ids);
 let all=read("/home/ubuntu/src/zopro-perf-work/large-class-sdk176/measure-cases.json");let names=["1x2-w16","1x2-w32","2x2-w32","4x2-w32","8x2-w32","12x2-w32","16x2-w32","24x2-w32","merge-24x1-w32","merge-54x1-w32"];
 let cases=names.iter().map(|n|all.as_array().unwrap().iter().find(|c|c["name"]==*n).unwrap().clone()).collect::<Vec<_>>();for c in&cases{for k in["image","request"]{let p=c[k].as_str().unwrap();let h=hash(p);if k=="image"{assert_eq!(h,c["image_sha256"]);}pins.insert(p.into(),h);}}
 let base=read("/home/ubuntu/src/zopro-perf-work/bundle-sdk178/main-plan.json")["steps"][0]["environment"].clone();assert!(base.get("ZOPRO_CPU_PREPARE_MAX_BYTES").is_none());
 for phase in["preflight","main"]{let(mut jobs,mut steps)=(vec![],vec![]);for b in 0..if phase=="preflight"{1}else{30}{let mut order=(0..10).collect::<Vec<_>>();order.rotate_left(b%10);if b%2==1{order.reverse();}for(ci,i)in order.into_iter().enumerate(){let c=&cases[i];let mut arms=["REF","OFF","ON"];arms.rotate_left((b+ci)%3);if b%2==1{arms.reverse();}for arm in arms{let name=format!("{phase}-{}-{arm}-{b:02}",c["name"].as_str().unwrap());let rounds=if phase=="preflight"{1}else if i<2{151}else{17};let mut env=base.clone();env["RAYON_NUM_THREADS"]=json!(c["workers"].as_u64().unwrap().to_string());for(k,v)in[("ZOPRO_CPU_INDEXED_TILE_BUNDLES","1"),("ZOPRO_BENCH_FUSED_PREPARATION","1"),("ZOPRO_BENCH_CERTIFIED_OUTPUT","1")]{env[k]=json!(v);}let binary=&ids[arm]["copies"][b%3]["path"];let pd=r(format!("proofs/{name}"));steps.push(command(&name,vec!["/usr/bin/taskset".into(),"-c".into(),c["cpu_affinity"].as_str().unwrap().into(),binary.as_str().unwrap().into(),c["image"].as_str().unwrap().into(),c["request"].as_str().unwrap().into(),rounds.to_string(),pd.display().to_string()],env.clone()));jobs.push(json!({"name":name,"case":c,"arm":arm,"block":b,"rounds":rounds,"proof_dir":pd,"environment":env,"binary":binary}));}}}
 assert_eq!(jobs.len(),if phase=="preflight"{30}else{900});steps.extend(jobs.iter().map(verify));save(r(format!("{phase}-jobs.json")),&json!(jobs));save(r(format!("{phase}-plan.json")),&json!({"version":1,"source_pins":r("runtime-pins.json"),"steps":steps}));}
 let mut row=vec![1u64];for _ in 0..30{let mut next=vec![1;row.len()+1];for i in 1..row.len(){next[i]=row[i-1]+row[i];}row=next;}let coverage=row[10..=20].iter().sum::<u64>()as f64/(1u64<<30)as f64;save(r("statistics-model.json"),&json!({"blocks":30,"lower_rank_zero_based":9,"upper_rank_zero_based":20,"marginal_coverage":coverage,"two_primary_one_sided_union_bound":1.-coverage,"joint_confidence_claim":false}));
 for p in[PathBuf::from(SEED),PathBuf::from(VERIFY),PathBuf::from("/usr/bin/taskset")]{pins.insert(p.display().to_string(),hash(p));}
 for f in["protocol.md","setup.rs","adapt-readers.rs","prepare-body.rs","assess-body.rs","screen.rs","screen","independent.rs","independent","statistics-model.json","runtime-consumers.json","preflight-jobs.json","main-jobs.json","preflight-plan.json","main-plan.json","native-OFF-plan.json","native-ON-plan.json","portable-plan.json","native-OFF/result.json","native-ON/result.json","portable/result.json","mechanism.md"]{pins.insert(r(f).display().to_string(),hash(r(f)));}save(r("runtime-pins.json"),&json!(pins));println!("Frozen30preflight+900main exports; all3arms/all10contexts; ledger59095");
}
fn review(phase: &str) {
    assert!(["preflight", "main"].contains(&phase));
    check_copies(&read(r("runtime-consumers.json")));
    let folder = format!("{phase}-run");
    assert_eq!(
        read(r(format!("{folder}/result.json")))["status"],
        "complete"
    );
    for (p, h) in read(r("runtime-pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    for step in read(r(format!("{phase}-plan.json")))["steps"]
        .as_array()
        .unwrap()
    {
        receipt(&folder, step);
    }
    let mut ledger: BTreeSet<String> = serde_json::from_value(read(if phase == "preflight" {
        PathBuf::from(SEED)
    } else {
        r("proof-sha256-after-preflight.json")
    }))
    .unwrap();
    assert_eq!(
        ledger.len(),
        if phase == "preflight" { 59095 } else { 59125 }
    );
    let mut rows = vec![];
    let mut samples_count = 0u64;
    for j in read(r(format!("{phase}-jobs.json"))).as_array().unwrap() {
        let name = j["name"].as_str().unwrap();
        let out = fs::read_to_string(r(format!("{folder}/{name}/stdout.log"))).unwrap();
        let samples: Vec<f64> = out
            .lines()
            .filter_map(|l| l.strip_prefix("SAMPLE "))
            .enumerate()
            .map(|(i, s)| {
                let v: Value = serde_json::from_str(s).unwrap();
                assert_eq!(v["round"], i);
                let x = v["ms"].as_f64().unwrap();
                assert!(x > 0. && x.is_finite());
                x
            })
            .collect();
        let rounds = j["rounds"].as_u64().unwrap();
        assert_eq!(samples.len() as u64, rounds);
        samples_count += rounds;
        let sums: Vec<_> = out
            .lines()
            .filter_map(|l| l.strip_prefix("SUMMARY "))
            .collect();
        assert_eq!(sums.len(), 1);
        let sum: Value = serde_json::from_str(sums[0]).unwrap();
        assert_eq!(sum["rounds"], rounds);
        assert_eq!(sum["priming"], 3);
        assert_eq!(sum["workers"], j["case"]["workers"]);
        {
            let entries=sum["indexed_entries"].as_u64().unwrap();
            let charge=sum["indexed_max_charge"].as_u64().unwrap();
            if j["case"]["denied"]==true {assert_eq!(entries,0);assert_eq!(charge,0);}
            else if ["1x2","2x2"].iter().any(|shape|j["case"]["shape"]==*shape) {assert_eq!(entries,4*rounds);assert!(charge>0);}
            else {assert_eq!(entries%rounds,0);if entries>0 {assert!(charge>0);}}
        }
        {let eligible=["1x2","2x2"].iter().any(|s|j["case"]["shape"]==*s);let scans=if eligible{1}else{0};assert_eq!(sum["generated_fast_parses"],if eligible{rounds}else{0});assert_eq!(sum["generated_total_key_scans"],scans);assert_eq!(sum["generated_total_fixed_scans"],scans);assert_eq!(sum["generated_timed_key_scans"],0);assert_eq!(sum["generated_timed_fixed_scans"],0);if eligible{assert!(sum["generated_certification_ns"].as_u64().unwrap()>0);}else{assert_eq!(sum["generated_certification_ns"],0);}}
        assert_eq!(sum["placement_before"], sum["placement_after"]);
        let p = &sum["placement_before"];
        assert_eq!(p["mode"], "fixed");
        let workers = sum["workers"].as_u64().unwrap();
        assert_eq!(p["tasks"], workers + 1);
        assert_eq!(p["main_allowed"], json!((0..workers).collect::<Vec<_>>()));
        let worker_rows = p["worker_rows"].as_array().unwrap();
        assert_eq!(worker_rows.len() as u64, workers);
        let mut tids = BTreeSet::new();
        for (i, w) in worker_rows.iter().enumerate() {
            assert_eq!(w["index"], i);
            assert_eq!(w["allowed"], json!([i]));
            assert!(tids.insert(w["tid"].as_u64().unwrap()));
        }
        let dir = Path::new(j["proof_dir"].as_str().unwrap());
        assert_eq!(fs::metadata(dir.join("0.proof")).unwrap().len(), 164);
        let ph = hash(dir.join("0.proof"));
        let pu = hash(dir.join("0.public"));
        assert_eq!(pu, j["case"]["public_sha256"]);
        let verifier = fs::read_to_string(r(format!("{folder}/verify-{name}/stdout.log"))).unwrap();
        for needle in [
            format!("proof_sha256={ph}"),
            format!("public_sha256={pu}"),
            format!(
                "image_sha256={}",
                j["case"]["image_sha256"].as_str().unwrap()
            ),
        ] {
            assert!(verifier.contains(&needle));
        }
        assert!(ledger.insert(ph.clone()));
        let mean = samples.iter().sum::<f64>() / rounds as f64;
        let cpu = (sum["user_cpu_ms"].as_f64().unwrap() + sum["system_cpu_ms"].as_f64().unwrap())
            / rounds as f64;
        rows.push(json!({"name":name,"context":j["case"]["name"],"arm":j["arm"],"block":j["block"],"ms":mean,"cpu_ms":cpu,"summary":sum,"proof_sha256":ph}));
    }
    assert_eq!(
        ledger.len(),
        if phase == "preflight" { 59125 } else { 60025 }
    );
    assert_eq!(samples_count, if phase == "preflight" { 30 } else { 39420 });
    save(
        r(format!("proof-sha256-after-{phase}.json")),
        &json!(ledger),
    );
    save(r(format!("{phase}-rows.json")), &json!(rows));
    if phase == "main" {
        assess(&rows);
    }
    save(
        r(format!("{phase}-review.json")),
        &json!({"verified":true,"new_exports":rows.len(),"canonical_count":ledger.len(),"samples_checked":samples_count}),
    );
    println!(
        "Verified {phase}: {} exports; ledger{}; {samples_count} samples",
        rows.len(),
        ledger.len()
    );
}
fn bounds(mut v: Vec<f64>) -> Value {
    assert_eq!(v.len(), 30);
    assert!(v.iter().all(|x| x.is_finite() && *x > 0.));
    v.sort_by(f64::total_cmp);
    json!({"lower":v[9],"median":(v[14]+v[15])/2.,"upper":v[20]})
}
fn assess(rows:&[Value]){
 let mut checks=vec![];let mut timings=vec![];let mut candidates=vec![];let contexts:BTreeSet<_>=rows.iter().map(|r|r["context"].as_str().unwrap()).collect();assert_eq!(contexts.len(),10);
 for ctx in contexts{let arm=|a:&str|{let mut v=rows.iter().filter(|r|r["context"]==ctx&&r["arm"]==a).collect::<Vec<_>>();v.sort_by_key(|r|r["block"].as_u64().unwrap());assert_eq!(v.len(),30);for(i,r)in v.iter().enumerate(){assert_eq!(r["block"],i);}v};let on=arm("ON");for a in["REF","OFF","ON"]{let v=arm(a);timings.push(json!({"context":ctx,"arm":a,"ms":bounds(v.iter().map(|r|r["ms"].as_f64().unwrap()).collect()),"cpu_ms":bounds(v.iter().map(|r|r["cpu_ms"].as_f64().unwrap()).collect()),"peak_RSS_MiB":v.iter().map(|r|r["summary"]["whole_process_maxrss_kib"].as_f64().unwrap()/1024.).fold(0.,f64::max)}));}
 let mut gain=true;for comparator in["REF","OFF"]{let other=arm(comparator);for metric in["ms","cpu_ms"]{let ratios=on.iter().zip(&other).map(|(a,b)|a[metric].as_f64().unwrap()/b[metric].as_f64().unwrap()).collect::<Vec<_>>();let b=bounds(ratios.clone());let upper=b["upper"].as_f64().unwrap();checks.push(json!({"context":ctx,"comparator":comparator,"metric":metric,"ratio":b,"ratios":ratios,"passed":upper<=1.02}));if metric=="ms"{gain&=upper<1.;for copy in 0..3{let mut v=ratios.iter().enumerate().filter(|(i,_)|i%3==copy).map(|(_,v)|*v).collect::<Vec<_>>();v.sort_by(f64::total_cmp);assert_eq!(v.len(),10);gain&=(v[4]+v[5])/2.<1.;}}}
 let peak=|v:&Vec<&Value>|v.iter().map(|r|r["summary"]["whole_process_maxrss_kib"].as_f64().unwrap()).fold(0.,f64::max);let(a,b)=(peak(&on),peak(&other));checks.push(json!({"context":ctx,"comparator":comparator,"metric":"peak_rss_kib","ON":a,"control":b,"passed":a<=b*1.05+1024.}));}
 let(off,rf)=(arm("OFF"),arm("REF"));let calibration=bounds(off.iter().zip(rf).map(|(a,b)|a["ms"].as_f64().unwrap()/b["ms"].as_f64().unwrap()).collect());let m=calibration["median"].as_f64().unwrap();checks.push(json!({"context":ctx,"comparator":"REF","metric":"OFF_REF_calibration","ratio":calibration,"passed":(1./1.03..=1.03).contains(&m)}));if ["1x2-w16","1x2-w32"].contains(&ctx){candidates.push(json!({"context":ctx,"both_control_gain_and_all_backings":gain}));}}
 assert_eq!(checks.len(),70);let pass=checks.iter().all(|g|g["passed"]==true)&&candidates.iter().any(|g|g["both_control_gain_and_all_backings"]==true);save(r("assessment.json"),&json!({"checks":checks,"timings":timings,"primary_gains":candidates,"qualification_passed":pass,"adopted":false,"full_goal_achieved":false}));println!("Clean qualification passed={pass}; no minimum gain floor");
}
fn main() {
    match std::env::args().nth(1).as_deref() {
        Some("prepare") => prepare(),
        Some("preflight-review") => review("preflight"),
        Some("main-review") => review("main"),
        _ => panic!("prepare/preflight-review/main-review"),
    }
}

fn check_copies(ids: &Value) {
    use std::os::unix::fs::{MetadataExt,PermissionsExt};
    let mut distinct=BTreeSet::new();
    for arm in ["REF","OFF","ON"] { for f in ids[arm]["copies"].as_array().unwrap() {
        let p=f["path"].as_str().unwrap();let m=fs::metadata(p).unwrap();
        assert_eq!(hash(p),f["sha256"]);assert_eq!(m.dev(),f["device"].as_u64().unwrap());
        assert_eq!(m.ino(),f["inode"].as_u64().unwrap());assert_eq!(m.permissions().mode()as u64,f["mode"].as_u64().unwrap());
        assert!(distinct.insert((m.dev(),m.ino())));
    }} assert_eq!(distinct.len(),9);
}
