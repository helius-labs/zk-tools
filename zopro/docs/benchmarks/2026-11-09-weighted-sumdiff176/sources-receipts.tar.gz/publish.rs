use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::{Path,PathBuf},process::Command,fmt::Write as _};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-sumdiff176";
const D:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-weighted-sumdiff176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn walk(p:&Path,out:&mut Vec<PathBuf>){for e in fs::read_dir(p).unwrap(){let e=e.unwrap();if e.file_type().unwrap().is_dir(){walk(&e.path(),out);}else if e.file_type().unwrap().is_file(){out.push(e.path());}}}
fn main(){
 assert!(!Path::new(D).exists());let result=read(format!("{R}/result.json"));let review=read(format!("{R}/review-result.json"));assert_eq!(review["passed"],true);assert_eq!(result["necessary_work_gate_passed"],false);for(p,h)in read(format!("{R}/pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
 let decision=json!({"adopted":false,"native_trial_selected":false,"necessary_work_gate_passed":false,"failed_work_cases":4,"close_exact_sumdiff_topology_and_formula":true,"no_unchanged_rerun_or_subset_threshold_rescue":true,"production_unchanged":true,"SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":43073,"goal_active":true,"goal_complete":false,"targets_met":0});fs::write(format!("{R}/decision.json"),serde_json::to_vec_pretty(&decision).unwrap()).unwrap();
 fs::create_dir_all(format!("{D}/artifacts")).unwrap();for f in["model.rs","design.md","result.json","review-result.json","source-binding.json","decision.json","next.md","plan.json","pins.json"]{fs::copy(format!("{R}/{f}"),format!("{D}/artifacts/{f}")).unwrap();}
 let mut report=String::from(r#"# Shared sum/difference weighted fold

**The algebra passes, but this topology fails its work screen and is not selected for native implementation.** At 256 buckets, its optimistic G1 variable multiplication/square proxy rises from **3,012 to 3,774 (+25.30%)**, final projective-add calls rise from **8 to 15**, and doubles from **8 to 22**. Production and accepted performance are unchanged. This is a count result, not a measured slowdown.

The local question was whether sharing a denominator for P+Q and P−Q could improve a different weighted-bucket reduction. For n=2h, split inputs into halves A and B. Set S=A+B and D=A−B elementwise. With W(X)=Σ iXᵢ and T(X)=Σ Xᵢ, for even h:

```
W(A,B) = W(S) + (h/2)·(T(S) − T(D))
T(A,B) = T(S)
```

The candidate reduces D, recurses on S and retains the accepted reconstruction for sizes one and two. Ordinary P±Q uses one shared denominator inverse, four multiplications and two squares; complete identity/equal/opposite guards cover exceptional inputs. The accepted control reproduces the actual `msm.rs::weighted_sum` side copies, simultaneous reduction levels and final double/subtract ladder. No mathematical novelty is claimed.

Two serialized Rust 1.98.1/xtask commands build and execute the checked optimized model successfully on first execution. Across both curves, nine sizes from 1 to 256 and six input patterns produce **108 cases**. Independent generator-coefficient oracles check 432 weighted/total outputs; separate complete-group comparisons check 4,096 paired outputs. All **4,528 output comparisons** pass. Patterns include dense full-width coefficients, identities, equal points, alternating opposites, matching halves and opposite halves. The same populations are reused across cases; these are not proof counts.

The candidate model reuses one n-point slice and checks stable pointer/capacity and immutable inputs. Its recursion introduces no input-sized point buffer, whereas the control models 2n−1 point slots. These are scalar-model slots, not a native byte layout, complete allocation forecast, stack/RSS peak or minimum-RAM result. No production table, key expansion, retained plan, pool or memory cap is introduced.

For dense ordinary G1, the declared proxy charges 5M+S per ordinary affine addition and 7M+2S per shared pair, optimistically amortizing one denominator at 3M. Fixed inversion bridges, packing, tails and projective costs are not folded into this proxy; projective calls/doubles remain separate. It is not a hardware latency model or universal algebraic lower bound. G2 correctness is checked, but its native norm-prefix arithmetic is not assigned these G1 costs.

|Buckets|Accepted M+S|Candidate M+S|Change|Projective adds old/new|Doubles old/new|
|---|---:|---:|---:|---:|---:|
"#);
 for row in result["dense_G1_variable_work"].as_array().unwrap(){let old=row["accepted_M"].as_u64().unwrap()+row["accepted_S"].as_u64().unwrap();let new=row["candidate_M"].as_u64().unwrap()+row["candidate_S"].as_u64().unwrap();writeln!(report,"|{}|{old}|{new}|+{:.2}%|{} /{}|{} /{}|",row["n"],100.*(new as f64/old as f64-1.),row["accepted_projective_adds"],row["candidate_projective_adds"],row["accepted_doubles"],row["candidate_doubles"]).unwrap();}
 report.push_str(r#"
All four prospective work-admission checks fail. The separate reader derives closed counts independently: accepted variable work is 12n−6log₂n−12; candidate work is 15n−6log₂n−18, an excess of 3(n−2). It also verifies 508 linear coefficients of the weighted identity, complete case cardinalities, both command/exit/stream receipts, the actual accepted source binding and all 176 unchanged production-source hashes. The reader imports no model or curve code, but does not independently rerun the curve model or constitute an external audit.

This closes the exact topology/formula without a native trial, timing run or a threshold/curve/shape/worker rescue. The denominator saving loses to the extra reduction work under the declared admission proxy. It does not prove that shared sum/difference formulas cannot benefit a different algorithm, nor that every scalar operation count predicts CPU latency.

A narrow literature/history check revisited [SRE](https://arxiv.org/abs/2610.27452) and the [Waterloo Pippenger thesis](https://uwspace.uwaterloo.ca/items/43cc12b9-cb03-42bd-a01c-4b0ed5e12403). Their scalar-pattern reuse mechanisms already have local studies; no reported speedup or implementation is transferred here. Previous symmetric-square, joint-coordinate endpoint, prefix-tree, global unit-Z and initial-unit-state results remain unchanged.

No native SIMD qualification, SDK request, proof export, timing or hardware profile is added. The canonical verified-proof inventory stays **43,073**. Preparation/review/publication helper invocations are manual and do not all have xtask receipts. No successful old model, native suite, proof, capture or decoder is replayed.

The following are inherited accepted observations from the [latest complete SDK comparison](../2026-11-09-initial-unit-sdk176/README.md), with supplied historical M5 references on different hardware. They are not measurements of this model.

|Shape|Accepted CPU ms|M5 CPU ms / speedup|M5 Metal ms / speedup|CPU 10× target ms|
|---|---:|---:|---:|---:|
"#);
 let comp=read("/home/ubuntu/src/zopro-perf-work/initial-unit-sdk176/fresh-comparison.json");let rows=comp["rows"].as_array().unwrap();assert_eq!(rows.len(),8);for row in rows{writeln!(report,"|{}|{:.6}|{} /{:.3}x|{} /{:.3}x|{}|",row["shape"].as_str().unwrap(),row["REF_CPU_ms"].as_f64().unwrap(),row["M5_CPU_ms"],row["REF_CPU_speedup"].as_f64().unwrap(),row["M5_Metal_ms"],row["REF_Metal_speedup"].as_f64().unwrap(),row["CPU_10x_target_ms"]).unwrap();}
 report.push_str("\nThe full CPU 10× goal remains active and unmet, **0/8**. Accepted primary peak RSS remains 132.50 MiB; merge 54 remains 162.189200 ms without a supplied M5 reference. No new AWS/Aeglos, ARM/mobile, huge-circuit, pressure/swap/minimum-RAM or throughput result is claimed.\n\n[Model](artifacts/model.rs), [design](artifacts/design.md), [results](artifacts/result.json), [separate review](artifacts/review-result.json), [source binding](artifacts/source-binding.json), [decision](artifacts/decision.json), [continuation](artifacts/next.md), [sources and receipts](sources-receipts.tar.gz), [archive index](artifacts/archive-index.json), [checksums](SHA256SUMS).\n");
 fs::write(format!("{D}/README.md"),&report).unwrap();
 let pack=PathBuf::from(format!("{R}/publication-source"));fs::create_dir(&pack).unwrap();let mut files=Vec::new();for f in["model.rs","design.md","prepare.rs","review.rs","publish.rs","next.md","result.json","review-result.json","source-binding.json","decision.json","plan.json","pins.json"]{files.push(PathBuf::from(format!("{R}/{f}")));}walk(Path::new(&format!("{R}/runs")),&mut files);files.sort();let mut members=Vec::new();for p in files{let rel=p.strip_prefix(R).unwrap();let bytes=fs::read(&p).unwrap();assert!(std::str::from_utf8(&bytes).is_ok());let dest=pack.join(rel);fs::create_dir_all(dest.parent().unwrap()).unwrap();fs::write(&dest,&bytes).unwrap();members.push(json!({"path":rel,"bytes":bytes.len(),"sha256":hash(dest)}));}
 let archive=format!("{D}/sources-receipts.tar.gz");assert!(Command::new("tar").args(["-czf",&archive,"-C",pack.to_str().unwrap(),"."]).status().unwrap().success());let round=PathBuf::from(format!("{R}/publication-roundtrip"));fs::create_dir(&round).unwrap();assert!(Command::new("tar").args(["-xzf",&archive,"-C",round.to_str().unwrap(),"."]).status().unwrap().success());for member in&members{assert_eq!(hash(round.join(member["path"].as_str().unwrap())),member["sha256"]);}
 let index=json!({"archive_sha256":hash(&archive),"members":members,"canonical_proofs":43073,"proof_ledger_sha256":review["proof_ledger_sha256"],"excluded":["binaries and rlibs","unchanged full source snapshot","key/image/witness/proof bytes","full proof ledger","full papers"]});fs::write(format!("{D}/artifacts/archive-index.json"),serde_json::to_vec_pretty(&index).unwrap()).unwrap();fs::write(format!("{D}/SHA256SUMS"),"").unwrap();let mut links=0;for part in report.split("](").skip(1){let p=part.split(')').next().unwrap();if !p.starts_with("https://"){assert!(Path::new(D).join(p).exists(),"{p}");}links+=1;}
 let publication=json!({"passed":true,"archive_members":members.len(),"archive_roundtrip":true,"links":links,"model_output_checks":4528,"work_gate_passed":false,"native_trial_selected":false,"production_unchanged":true,"speed_measured":false,"SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":43073,"all8_CPU_Metal_rows":8,"goal_active":true,"goal_complete":false,"targets_met":0});for p in[format!("{R}/publication.json"),format!("{D}/artifacts/publication.json")]{fs::write(p,serde_json::to_vec_pretty(&publication).unwrap()).unwrap();}
 let mut files=Vec::new();walk(Path::new(D),&mut files);files.sort();let mut sums=String::new();for p in files{if p.file_name().unwrap()=="SHA256SUMS"{continue;}writeln!(sums,"{}  {}",hash(&p),p.strip_prefix(D).unwrap().display()).unwrap();}fs::write(format!("{D}/SHA256SUMS"),&sums).unwrap();for line in sums.lines(){let(h,p)=line.split_once("  ").unwrap();assert_eq!(hash(Path::new(D).join(p)),h);}
 println!("SUMDIFF_PUBLICATION_PASS{}members/{}links;modelpass/workgatefail;productionunchanged;canonical43073",members.len(),links);
}
