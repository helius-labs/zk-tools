use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-sumdiff176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
const A:&str="/home/ubuntu/src/zopro-perf-work/word-export176/target-candidate/release/deps";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert!(!Path::new(&format!("{R}/plan.json")).exists());let manifest=format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json");let m=read(&manifest);let originals=m["source_files_sha256"].as_object().unwrap();assert_eq!(originals.len(),176);for(rel,h)in originals{assert_eq!(hash(format!("{Z}/{rel}")),h.as_str().unwrap());}
 let path=format!("{Z}/crates/zopro-core/src/msm.rs");let text=fs::read_to_string(&path).unwrap();let start=text.find("fn weighted_sum<C: CurveConfig>(").unwrap();let end=start+text[start..].find("\n// In Fq2").unwrap();let body=&text[start..end];
 for s in["debug_assert!(n.is_power_of_two());","debug_assert_eq!(points.len(), 2 * n - 1);","points[next + i] = points[2 * i];","reduce_layer(points, &starts[..levels], &mut counts[..levels], scratch);","starts[levels] = next;","counts[levels] = half;","sum = sum.double();","sum -= affine::<C>(points[*start]);"]{assert_eq!(body.matches(s).count(),1);}
 assert!(text.contains("const GROUP: usize = 256;"));
 let bindings=json!({"manifest":manifest,"manifest_sha256":hash(&manifest),"accepted_files":176,"weighted_source":path,"weighted_source_sha256":hash(&path),"weighted_body":body,"accepted_group_size":256,"model_is_Arkworks_not_native_SIMD":true,"control_schedule_binding_not_machine_proof":true});fs::write(format!("{R}/source-binding.json"),serde_json::to_vec_pretty(&bindings).unwrap()).unwrap();
 let deps="/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
 let argv=vec!["/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc".to_string(),"--edition=2021".into(),"-O".into(),"-C".into(),"overflow-checks=yes".into(),"-C".into(),"debug-assertions=yes".into(),format!("{R}/model.rs"),"-o".into(),format!("{R}/model"),"-L".into(),format!("dependency={A}"),"-L".into(),format!("dependency={deps}"),"--extern".into(),format!("serde_json={deps}/libserde_json-cdebb9338c2784ad.rlib"),"--extern".into(),format!("ark_bn254={A}/libark_bn254-d28868a71f06f5b5.rlib"),"--extern".into(),format!("ark_ec={A}/libark_ec-59ebd5b49f9b3011.rlib"),"--extern".into(),format!("ark_ff={A}/libark_ff-3a8e68dc8045d2bd.rlib")];
 let steps=json!([{"kind":"command","name":"build-model","argv":argv,"environment":{},"timeout_seconds":300},{"kind":"command","name":"run-model","argv":[format!("{R}/model")],"environment":{},"timeout_seconds":600}]);let plan=json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps});fs::write(format!("{R}/plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();
 let mut pins=BTreeMap::new();for(rel,h)in originals{pins.insert(format!("{Z}/{rel}"),h.clone());}for f in["design.md","model.rs","prepare.rs","prepare","source-binding.json","plan.json"]{let p=format!("{R}/{f}");pins.insert(p.clone(),json!(hash(p)));}
 for s in steps.as_array().unwrap(){for v in s["argv"].as_array().unwrap(){let t=v.as_str().unwrap();let p=t.split_once('=').map_or(t,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.to_string(),json!(hash(p)));}}}
 fs::write(format!("{R}/pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();println!("Prepared2Rustmodelcommands/176acceptedfiles;fixed4caseworkgate;noSDKcallorclock");
}
