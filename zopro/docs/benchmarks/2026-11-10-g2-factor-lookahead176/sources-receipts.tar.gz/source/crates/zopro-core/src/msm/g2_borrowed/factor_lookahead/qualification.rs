use super::*;
use ark_ec::{AdditiveGroup,CurveGroup,PrimeGroup};
use ark_ff::{Field,PrimeField};
mod q {include!("/home/ubuntu/src/zopro-perf-work/g2-factor-lookahead176/test_support.rs");}
type C=zopro_bn254::G2Config;
type Ark=ark_bn254::G2Projective;
mod original {use super::*;include!("/home/ubuntu/src/zopro-perf-work/g2-factor-lookahead176/original-apply.rs");}
fn fixture(n:usize)->(Vec<Affine<C>>,Vec<Affine<C>>,Vec<ark_bn254::Fr>,Vec<ark_bn254::Fr>){
    let w=q::weights();let initial=(0..n).map(|i|w[(i+5)%w.len()]+ark_bn254::Fr::from((i+700001)as u64)).collect::<Vec<_>>();let incoming=(0..n).map(|i|w[(i+31)%w.len()]*ark_bn254::Fr::from(17u64)+ark_bn254::Fr::from((i+900001)as u64)).collect::<Vec<_>>();
    let cv=|v:&[ark_bn254::Fr]|Ark::normalize_batch(&v.iter().map(|s|Ark::generator()*s).collect::<Vec<_>>()).into_iter().map(q::g2).collect();(cv(&initial),cv(&incoming),initial,incoming)
}
fn check(n:usize,mask:u8,fast:bool,vector:bool){
    let size=n.max(1).next_power_of_two();let(init,input,initial,incoming)=fixture(size);let saved=input.clone();let batch=(0..n).map(|i|(((i*37%size)as u32)|if mask>>(i%8)&1!=0{1<<31}else{0},&input[i])).collect::<Vec<_>>();
    let(mut old,mut new)=(init.clone(),init);let(mut so,mut sn)=(Fq2AddScratch{canonical:fast,vector_inverse:vector,..Default::default()},Fq2AddScratch{canonical:fast,vector_inverse:vector,..Default::default()});
    let mut coefficients=initial.clone();let mut capacities=None;
    for _ in 0..3{
        for(i,&(id,p))in batch.iter().enumerate(){let k=(id&0x7fff_ffff)as usize;assert!(!new[k].is_identity()&&!p.is_identity());assert_ne!(new[k].x,p.x);let v=if id>>31!=0{-incoming[i]}else{incoming[i]};coefficients[k]+=v;}
        if fast{original::apply::<C,true>(&mut old,&batch,&mut so);super::apply::<C,true>(&mut new,&batch,&mut sn);}else{original::apply::<C,false>(&mut old,&batch,&mut so);super::apply::<C,false>(&mut new,&batch,&mut sn);}
        assert_eq!(new,old);let expected=Ark::normalize_batch(&coefficients.iter().map(|s|Ark::generator()*s).collect::<Vec<_>>());for(p,e)in new.iter().zip(expected){assert_eq!(*p,q::g2(e));}
        assert_eq!(so.prefix_records.len(),sn.prefix_records.len());for(a,b)in so.prefix_records.iter().zip(&sn.prefix_records){for i in 0..2{assert_eq!(a[i].get(),b[i].get());}}
        let cap=(sn.prefix_records.capacity(),sn.tail.capacity(),sn.groups.capacity());assert_eq!(cap,(so.prefix_records.capacity(),so.tail.capacity(),so.groups.capacity()));if let Some(before)=capacities{assert_eq!(before,cap);}else{capacities=Some(cap);}
    }assert_eq!(input,saved);
}
#[test]
fn changing_points_tails_signs_inverse_modes_and_reuse(){
    let mut cases=0;for n in[0,1,7,8,9,15,16,17,31,32,33,199,200,201,351,352,353,511]{for mask in[0u8,255,85,129]{for fast in[false,true]{for vector in[false,true]{check(n,mask,fast,vector);cases+=1;}}}}assert_eq!(cases,288);println!("LOOKAHEAD_CASES={cases} PASSES=3 ORACLE=independent_Arkworks FULL_WIDTH=true IMMUTABLE=true CAPACITY_REUSE=true");
}
#[test]
fn factor_schedule_exactness_and_multiplication_conservation(){
    let mul=|a:u64,b:u64|a*b%1009;let mut cases=0;
    for groups in 0..65usize{for seed in 1..19u64{
        let norms=(0..groups).map(|i|1+(seed*37+i as u64*19)%1008).collect::<Vec<_>>();let mut prefixes=vec![];let mut root=1;for &v in&norms{prefixes.push(root);root=mul(root,v);}let mut inv=(1..1009).find(|i|mul(root,*i)==1).unwrap();let mut old=vec![];for j in(0..groups).rev(){old.push((j,mul(prefixes[j],inv)));inv=mul(inv,norms[j]);}assert_eq!(inv,1);
        let mut new=vec![];let mut products=0;let mut inv=(1..1009).find(|i|mul(root,*i)==1).unwrap();if let Some(last)=groups.checked_sub(1){let mut factor=mul(prefixes[last],inv);inv=mul(inv,norms[last]);products+=2;for j in(0..=last).rev(){let next=if j>0{let v=mul(prefixes[j-1],inv);inv=mul(inv,norms[j-1]);products+=2;Some(v)}else{None};new.push((j,factor));if let Some(v)=next{factor=v;}}}assert_eq!(new,old);assert_eq!(products,2*groups);assert_eq!(inv,1);cases+=1;
    }}assert_eq!(cases,1170);println!("LOOKAHEAD_FACTOR_SCHEDULES={cases} SAME_ORDER=true MULTIPLIES=2_per_group EXTRA_PRODUCTS=0");
}
#[test]
fn actual_workers_and_shared_callers(){
    // Smaller immutable fixture shared by every worker; correctness checked independently.
    let n=200;let(init,input,initial,incoming)=fixture(256);let batch=(0..n).map(|i|((i*37%256)as u32|if i%3==0{1<<31}else{0},&input[i])).collect::<Vec<_>>();let mut coefficients=initial;for(i,&(id,_))in batch.iter().enumerate(){coefficients[(id&0x7fff_ffff)as usize]+=if id>>31!=0{-incoming[i]}else{incoming[i]};}let expected=Ark::normalize_batch(&coefficients.iter().map(|s|Ark::generator()*s).collect::<Vec<_>>()).into_iter().map(q::g2).collect::<Vec<_>>();
    let check=||{let mut b=init.clone();let mut s=Fq2AddScratch{canonical:true,vector_inverse:true,..Default::default()};crate::msm::g2_borrowed::apply::<C,true>(&mut b,&batch,&mut s);assert_eq!(b,expected);};
    for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.broadcast(|_|check());}
    let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();std::thread::scope(|scope|{for _ in 0..4{let(pool,check)=(&pool,&check);std::thread::Builder::new().stack_size(512*1024).spawn_scoped(scope,move||pool.install(check)).unwrap();}});
    println!("LOOKAHEAD_OWNER_CONTEXTS=57 WORKERS=1,4,16,32 SHARED_CALLERS=4 POOL=8 STACK_KIB=512 NATIVE_DISPATCH={}",cfg!(all(zopro_g2_factor_lookahead,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma))));
}
