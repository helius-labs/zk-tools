//! Sum eight canonical R256 products before one scalar Montgomery reduction.
use crate::{ifma8::Ifma8,Fp,FpConfig};
use core::arch::x86_64::*;
const MASK:u64=(1<<52)-1;
#[inline(always)]
pub fn dot8<C:FpConfig>(a:&[Fp<C>;8],b:&[Fp<C>;8])->Fp<C>{
 debug_assert!(a.iter().chain(b).all(Fp::is_reduced));
 let x=Ifma8::<C,true>::new(a).0;let y=Ifma8::<C,true>::new(b).0;
 // Each coefficient is <9*2^52 per lane, <72*2^52 across eight lanes.
 let digits=unsafe{let zero=_mm512_setzero_si512();let mut c=[zero;10];
  for i in 0..5{for j in 0..5{c[i+j]=_mm512_madd52lo_epu64(c[i+j],x[i],y[j]);c[i+j+1]=_mm512_madd52hi_epu64(c[i+j+1],x[i],y[j]);}}
  c.map(|v|_mm512_reduce_add_epi64(v)as u64)
 };
 let mut digits=digits;for i in 0..9{digits[i+1]+=digits[i]>>52;digits[i]&=MASK;}
 debug_assert!(digits[9]<(1<<43));let mut t=[0u64;9];
 for(k,d)in digits.into_iter().enumerate(){let bit=k*52;let j=bit/64;let s=bit%64;t[j]|=d<<s;if s!=0&&j+1<8{t[j+1]|=d>>(64-s);}}
 // T<8p²<R²/2. With q=(-T/p) mod R, (T+qp)/R<3p<R.
 for i in 0..4{let q=t[i].wrapping_mul(C::INV);let mut carry=0u128;
  for j in 0..4{let v=q as u128*C::P[j]as u128+t[i+j]as u128+carry;t[i+j]=v as u64;carry=v>>64;}
  let mut carry=carry as u64;for k in i+4..9{let(v,c)=t[k].overflowing_add(carry);t[k]=v;carry=c as u64;}
  debug_assert_eq!(t[i],0);debug_assert_eq!(carry,0);
 }
 debug_assert_eq!(t[8],0);let raw=[t[4],t[5],t[6],t[7]];
 Fp::from_montgomery(crate::portable::reduce_once(crate::portable::reduce_once(raw,C::P),C::P))
}
