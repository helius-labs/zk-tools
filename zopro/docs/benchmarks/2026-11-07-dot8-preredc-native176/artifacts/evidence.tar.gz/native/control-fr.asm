
/home/ubuntu/src/zopro-perf-work/dot8-preredc-native176/target-native/release/zopro-dot8-preredc-native:     file format elf64-x86-64


Disassembly of section .text:

0000000000035ea0 <dot8_control_fr>:
   35ea0:	push   r14
   35ea2:	push   rbx
   35ea3:	sub    rsp,0x28
   35ea7:	vmovdqu64 zmm0,ZMMWORD PTR [rsi]
   35ead:	vmovdqu64 zmm5,ZMMWORD PTR [rsi+0x40]
   35eb4:	vmovdqu64 zmm6,ZMMWORD PTR [rsi+0x80]
   35ebb:	vmovdqu64 zmm7,ZMMWORD PTR [rsi+0xc0]
   35ec2:	vmovdqa64 zmm15,ZMMWORD PTR [rip+0xfffffffffffce634]        # 4500 <_RNvNvXs3_NtNtCs9m2BZmJYoeB_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x680>
   35ecc:	vmovdqa64 zmm17,ZMMWORD PTR [rip+0xfffffffffffce66a]        # 4540 <_RNvNvXs3_NtNtCs9m2BZmJYoeB_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x6c0>
   35ed6:	vmovdqu64 zmm10,ZMMWORD PTR [rdx]
   35edc:	vmovdqu64 zmm11,ZMMWORD PTR [rdx+0x40]
   35ee3:	vmovdqu64 zmm12,ZMMWORD PTR [rdx+0x80]
   35eea:	vmovdqu64 zmm13,ZMMWORD PTR [rdx+0xc0]
   35ef1:	vpbroadcastq zmm26,QWORD PTR [rip+0xfffffffffffce0a5]        # 3fa0 <_RNvNvXs3_NtNtCs9m2BZmJYoeB_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x120>
   35efb:	vmovaps ymm1,YMMWORD PTR [rip+0xfffffffffffce01d]        # 3f20 <_RNvNvXs3_NtNtCs9m2BZmJYoeB_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0xa0>
   35f03:	vpbroadcastq zmm25,QWORD PTR [rip+0xfffffffffffce13b]        # 4048 <_RNvNvXs3_NtNtCs9m2BZmJYoeB_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1c8>
   35f0d:	movabs rax,0x30644e72e131
   35f17:	vpxord xmm21,xmm21,xmm21
   35f1d:	vpxord xmm20,xmm20,xmm20
   35f23:	vpbroadcastq zmm24,QWORD PTR [rip+0xfffffffffffce14b]        # 4078 <_RNvNvXs3_NtNtCs9m2BZmJYoeB_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1f8>
   35f2d:	vpunpcklqdq zmm14,zmm0,zmm5
   35f33:	vpunpckhqdq zmm5,zmm0,zmm5
   35f39:	vpunpcklqdq zmm0,zmm6,zmm7
   35f3f:	vpunpckhqdq zmm6,zmm6,zmm7
   35f45:	vmovups YMMWORD PTR [rsp],ymm1
   35f4a:	mov    QWORD PTR [rsp+0x20],rax
   35f4f:	vmovdqa64 zmm7,zmm14
   35f55:	vmovdqa64 zmm16,zmm5
   35f5b:	vpermt2q zmm7,zmm15,zmm0
   35f61:	vpermt2q zmm16,zmm15,zmm6
   35f67:	vpermt2q zmm14,zmm17,zmm0
   35f6d:	vpermt2q zmm5,zmm17,zmm6
   35f73:	vpbroadcastq zmm4,QWORD PTR [rsp+0x8]
   35f7b:	vpbroadcastq zmm3,QWORD PTR [rsp+0x10]
   35f83:	vpbroadcastq zmm2,QWORD PTR [rsp+0x18]
   35f8b:	vpbroadcastq zmm1,QWORD PTR [rsp+0x20]
   35f93:	vpshldq zmm6,zmm16,zmm7,0xc
   35f9a:	vpandq zmm9,zmm7,zmm26
   35fa0:	vpshldq zmm7,zmm14,zmm16,0x18
   35fa7:	vpunpcklqdq zmm16,zmm10,zmm11
   35fad:	vpunpckhqdq zmm10,zmm10,zmm11
   35fb3:	vpunpcklqdq zmm11,zmm12,zmm13
   35fb9:	vpunpckhqdq zmm12,zmm12,zmm13
   35fbf:	vpshldq zmm14,zmm5,zmm14,0x24
   35fc6:	vpsrlq zmm5,zmm5,0x10
   35fcd:	vmovdqa64 zmm13,zmm16
   35fd3:	vpermt2q zmm13,zmm15,zmm11
   35fd9:	vpermi2q zmm15,zmm10,zmm12
   35fdf:	vpermt2q zmm16,zmm17,zmm11
   35fe5:	vpermt2q zmm10,zmm17,zmm12
   35feb:	vpxord xmm17,xmm17,xmm17
   35ff1:	vpandq zmm8,zmm6,zmm26
   35ff7:	vpandq zmm7,zmm7,zmm26
   35ffd:	vpandq zmm6,zmm14,zmm26
   36003:	vpandq zmm22,zmm13,zmm26
   36009:	vpshldq zmm11,zmm15,zmm13,0xc
   36010:	vpshldq zmm12,zmm16,zmm15,0x18
   36017:	vpxor  xmm13,xmm13,xmm13
   3601c:	vpxor  xmm15,xmm15,xmm15
   36021:	vpmadd52huq zmm15,zmm9,zmm22
   36027:	vpmadd52huq zmm21,zmm8,zmm22
   3602d:	vpmadd52huq zmm20,zmm7,zmm22
   36033:	vpmadd52huq zmm17,zmm6,zmm22
   36039:	vpmadd52luq zmm13,zmm9,zmm22
   3603f:	vpandq zmm18,zmm11,zmm26
   36045:	vpshldq zmm11,zmm10,zmm16,0x24
   3604c:	vpandq zmm19,zmm12,zmm26
   36052:	vpsrlq zmm12,zmm10,0x10
   36059:	vpxor  xmm10,xmm10,xmm10
   3605e:	vpmadd52huq zmm10,zmm5,zmm22
   36064:	vpandq zmm16,zmm11,zmm26
   3606a:	vpxor  xmm11,xmm11,xmm11
   3606f:	vpmadd52luq zmm15,zmm8,zmm22
   36075:	vpmadd52luq zmm21,zmm7,zmm22
   3607b:	vpmadd52luq zmm20,zmm6,zmm22
   36081:	vpmadd52luq zmm17,zmm5,zmm22
   36087:	vpxord xmm22,xmm22,xmm22
   3608d:	vpmadd52luq zmm22,zmm13,zmm25
   36093:	vpaddq zmm13,zmm13,zmm26
   36099:	vpsrlq zmm23,zmm13,0x34
   360a0:	vpmadd52huq zmm21,zmm22,zmm4
   360a6:	vpmadd52huq zmm20,zmm22,zmm3
   360ac:	vpmadd52huq zmm17,zmm22,zmm2
   360b2:	vpmadd52huq zmm23,zmm22,zmm24
   360b8:	vpmadd52luq zmm15,zmm22,zmm4
   360be:	vpmadd52huq zmm10,zmm22,zmm1
   360c4:	vpmadd52luq zmm21,zmm22,zmm3
   360ca:	vpmadd52luq zmm20,zmm22,zmm2
   360d0:	vpmadd52luq zmm17,zmm22,zmm1
   360d6:	vpaddq zmm23,zmm15,zmm23
   360dc:	vpmadd52huq zmm10,zmm6,zmm18
   360e2:	vpxor  xmm15,xmm15,xmm15
   360e7:	vpmadd52huq zmm15,zmm5,zmm18
   360ed:	vpmadd52luq zmm23,zmm9,zmm18
   360f3:	vpmadd52huq zmm21,zmm9,zmm18
   360f9:	vpmadd52huq zmm20,zmm8,zmm18
   360ff:	vpmadd52huq zmm17,zmm7,zmm18
   36105:	vpmadd52luq zmm10,zmm5,zmm18
   3610b:	vpaddq zmm22,zmm23,zmm26
   36111:	vpsrlq zmm22,zmm22,0x34
   36118:	vpmadd52luq zmm21,zmm8,zmm18
   3611e:	vpmadd52luq zmm20,zmm7,zmm18
   36124:	vpmadd52luq zmm17,zmm6,zmm18
   3612a:	vpxord xmm18,xmm18,xmm18
   36130:	vpmadd52luq zmm18,zmm23,zmm25
   36136:	vpmadd52huq zmm20,zmm18,zmm4
   3613c:	vpmadd52huq zmm17,zmm18,zmm3
   36142:	vpmadd52huq zmm10,zmm18,zmm2
   36148:	vpmadd52huq zmm22,zmm18,zmm24
   3614e:	vpmadd52luq zmm21,zmm18,zmm4
   36154:	vpmadd52huq zmm15,zmm18,zmm1
   3615a:	vpmadd52luq zmm20,zmm18,zmm3
   36160:	vpmadd52luq zmm17,zmm18,zmm2
   36166:	vpmadd52luq zmm10,zmm18,zmm1
   3616c:	vpaddq zmm21,zmm21,zmm22
   36172:	vpmadd52huq zmm15,zmm6,zmm19
   36178:	vpxord xmm18,xmm18,xmm18
   3617e:	vpmadd52huq zmm18,zmm5,zmm19
   36184:	vpmadd52luq zmm21,zmm9,zmm19
   3618a:	vpmadd52huq zmm20,zmm9,zmm19
   36190:	vpmadd52huq zmm17,zmm8,zmm19
   36196:	vpmadd52huq zmm10,zmm7,zmm19
   3619c:	vpmadd52luq zmm15,zmm5,zmm19
   361a2:	vpmadd52luq zmm20,zmm8,zmm19
   361a8:	vpmadd52luq zmm17,zmm7,zmm19
   361ae:	vpmadd52luq zmm10,zmm6,zmm19
   361b4:	vpxord xmm19,xmm19,xmm19
   361ba:	vpmadd52luq zmm19,zmm21,zmm25
   361c0:	vpaddq zmm21,zmm21,zmm26
   361c6:	vpsrlq zmm21,zmm21,0x34
   361cd:	vpmadd52huq zmm17,zmm19,zmm4
   361d3:	vpmadd52huq zmm10,zmm19,zmm3
   361d9:	vpmadd52huq zmm15,zmm19,zmm2
   361df:	vpmadd52huq zmm21,zmm19,zmm24
   361e5:	vpmadd52luq zmm20,zmm19,zmm4
   361eb:	vpmadd52huq zmm18,zmm19,zmm1
   361f1:	vpmadd52luq zmm17,zmm19,zmm3
   361f7:	vpmadd52luq zmm10,zmm19,zmm2
   361fd:	vpmadd52luq zmm15,zmm19,zmm1
   36203:	vpaddq zmm20,zmm20,zmm21
   36209:	vpmadd52huq zmm18,zmm6,zmm16
   3620f:	vpxord xmm19,xmm19,xmm19
   36215:	vpmadd52huq zmm19,zmm5,zmm16
   3621b:	vpmadd52luq zmm20,zmm9,zmm16
   36221:	vpmadd52huq zmm17,zmm9,zmm16
   36227:	vpmadd52huq zmm10,zmm8,zmm16
   3622d:	vpmadd52huq zmm15,zmm7,zmm16
   36233:	vpmadd52luq zmm18,zmm5,zmm16
   36239:	vpmadd52luq zmm17,zmm8,zmm16
   3623f:	vpmadd52luq zmm10,zmm7,zmm16
   36245:	vpmadd52luq zmm15,zmm6,zmm16
   3624b:	vpxord xmm16,xmm16,xmm16
   36251:	vpmadd52luq zmm16,zmm20,zmm25
   36257:	vpaddq zmm20,zmm20,zmm26
   3625d:	vpsrlq zmm20,zmm20,0x34
   36264:	vpmadd52huq zmm20,zmm16,zmm24
   3626a:	vpmadd52luq zmm17,zmm16,zmm4
   36270:	vpmadd52huq zmm10,zmm16,zmm4
   36276:	vpmadd52huq zmm15,zmm16,zmm3
   3627c:	vpmadd52huq zmm18,zmm16,zmm2
   36282:	vpmadd52huq zmm19,zmm16,zmm1
   36288:	vpaddq zmm17,zmm17,zmm20
   3628e:	vpmadd52luq zmm10,zmm16,zmm3
   36294:	vpmadd52luq zmm15,zmm16,zmm2
   3629a:	vpmadd52luq zmm18,zmm16,zmm1
   362a0:	vpmadd52huq zmm19,zmm6,zmm12
   362a6:	vpmadd52luq zmm17,zmm9,zmm12
   362ac:	vpmadd52huq zmm10,zmm9,zmm12
   362b2:	vpmadd52huq zmm15,zmm8,zmm12
   362b8:	vpmadd52huq zmm18,zmm7,zmm12
   362be:	vpmadd52luq zmm19,zmm5,zmm12
   362c4:	vpmadd52luq zmm11,zmm17,zmm25
   362ca:	vpandq zmm9,zmm11,QWORD BCST [rip+0xfffffffffffcdcd4]        # 3fa8 <_RNvNvXs3_NtNtCs9m2BZmJYoeB_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x128>
   362d4:	vpmadd52luq zmm15,zmm7,zmm12
   362da:	vpmadd52luq zmm18,zmm6,zmm12
   362e0:	vpmadd52luq zmm10,zmm8,zmm12
   362e6:	vpxor  xmm6,xmm6,xmm6
   362ea:	vpmadd52huq zmm6,zmm5,zmm12
   362f0:	vpaddq zmm7,zmm17,QWORD BCST [rip+0xfffffffffffcdcae]        # 3fa8 <_RNvNvXs3_NtNtCs9m2BZmJYoeB_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x128>
   362fa:	vpsllq zmm8,zmm11,0x4
   36301:	vpmadd52huq zmm15,zmm9,zmm4
   36307:	vpmadd52huq zmm18,zmm9,zmm3
   3630d:	vpmadd52huq zmm19,zmm9,zmm2
   36313:	vpmadd52huq zmm6,zmm9,zmm1
   36319:	vpmadd52luq zmm10,zmm9,zmm4
   3631f:	vpsrlq zmm7,zmm7,0x30
   36326:	vpmadd52luq zmm15,zmm9,zmm3
   3632c:	vpmadd52luq zmm19,zmm9,zmm1
   36332:	vpmadd52luq zmm18,zmm9,zmm2
   36338:	vpbroadcastq zmm9,QWORD PTR [rip+0xfffffffffffcdd1e]        # 4060 <_RNvNvXs3_NtNtCs9m2BZmJYoeB_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1e0>
   36342:	vpmadd52huq zmm7,zmm8,zmm24
   36348:	vpsllq zmm1,zmm10,0x4
   3634f:	vpsrlq zmm3,zmm10,0x30
   36356:	vpsllq zmm6,zmm6,0x4
   3635d:	vpsllq zmm8,zmm18,0x4
   36364:	vpsllq zmm4,zmm15,0x4
   3636b:	vpsrlq zmm5,zmm15,0x30
   36372:	vpsrlq zmm10,zmm18,0x30
   36379:	vpandq zmm1,zmm1,zmm9
   3637f:	vpandq zmm4,zmm4,zmm9
   36385:	vpaddq zmm1,zmm1,zmm7
   3638b:	vpandq zmm7,zmm8,zmm9
   36391:	vpsllq zmm8,zmm19,0x4
   36398:	vpandq zmm2,zmm8,zmm9
   3639e:	vpsrlq zmm8,zmm1,0x34
   363a5:	vpaddq zmm5,zmm7,zmm5
   363ab:	vpandq zmm1,zmm1,zmm26
   363b1:	vpsrlq zmm9,zmm19,0x30
   363b8:	vpaddq zmm3,zmm8,zmm3
   363be:	vpaddq zmm2,zmm2,zmm10
   363c4:	vpaddq zmm6,zmm6,zmm9
   363ca:	vpaddq zmm3,zmm3,zmm4
   363d0:	vpsrlq zmm4,zmm3,0x34
   363d7:	vpandq zmm3,zmm3,zmm26
   363dd:	vpaddq zmm4,zmm4,zmm5
   363e3:	vpsrlq zmm5,zmm4,0x34
   363ea:	vpandq zmm4,zmm4,zmm26
   363f0:	vpaddq zmm2,zmm5,zmm2
   363f6:	vpsrlq zmm5,zmm2,0x34
   363fd:	vpandq zmm0,zmm2,zmm26
   36403:	vextracti64x4 ymm2,zmm1,0x1
   3640a:	vpaddq zmm1,zmm1,zmm2
   36410:	vpaddq zmm5,zmm5,zmm6
   36416:	vextracti128 xmm2,ymm1,0x1
   3641c:	vpaddq xmm1,xmm1,xmm2
   36420:	vpshufd xmm2,xmm1,0xee
   36425:	vpaddq xmm1,xmm1,xmm2
   36429:	vmovq  rcx,xmm1
   3642e:	vextracti64x4 ymm1,zmm3,0x1
   36435:	vpaddq zmm1,zmm3,zmm1
   3643b:	mov    r9,rcx
   3643e:	shr    r9,0x34
   36442:	vextracti128 xmm2,ymm1,0x1
   36448:	vpaddq xmm1,xmm1,xmm2
   3644c:	vpshufd xmm2,xmm1,0xee
   36451:	vpaddq xmm1,xmm1,xmm2
   36455:	vmovq  rax,xmm1
   3645a:	vextracti64x4 ymm1,zmm4,0x1
   36461:	vpaddq zmm1,zmm4,zmm1
   36467:	add    r9,rax
   3646a:	mov    eax,0x54
   3646f:	vextracti128 xmm2,ymm1,0x1
   36475:	mov    r10,r9
   36478:	shr    r10,0x34
   3647c:	vpaddq xmm1,xmm1,xmm2
   36480:	vpshufd xmm2,xmm1,0xee
   36485:	vpaddq xmm1,xmm1,xmm2
   36489:	vmovq  rdx,xmm1
   3648e:	vextracti64x4 ymm1,zmm0,0x1
   36495:	vpaddq zmm0,zmm0,zmm1
   3649b:	add    r10,rdx
   3649e:	vextracti128 xmm1,ymm0,0x1
   364a4:	mov    r11,r10
   364a7:	shr    r11,0x34
   364ab:	vpaddq xmm0,xmm0,xmm1
   364af:	vpshufd xmm1,xmm0,0xee
   364b4:	vpaddq xmm0,xmm0,xmm1
   364b8:	vmovq  rsi,xmm0
   364bd:	vextracti64x4 ymm0,zmm5,0x1
   364c4:	vpaddq zmm0,zmm5,zmm0
   364ca:	add    r11,rsi
   364cd:	vextracti128 xmm1,ymm0,0x1
   364d3:	mov    rdx,r11
   364d6:	shr    rdx,0x34
   364da:	vpaddq xmm0,xmm0,xmm1
   364de:	vpshufd xmm1,xmm0,0xee
   364e3:	vpaddq xmm0,xmm0,xmm1
   364e7:	vmovq  r8,xmm0
   364ec:	add    rdx,r8
   364ef:	mulx   rax,rsi,rax
   364f4:	shld   rax,rsi,0xc
   364f9:	cmp    rax,0xf
   364fd:	ja     3660f <dot8_control_fr+0x76f>
   36503:	lea    rsi,[rax+rax*4]
   36507:	mov    bl,0x34
   36509:	lea    r8,[rip+0xfffffffffffd2be8]        # 90f8 <_RNvNvNtNtCs9m2BZmJYoeB_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4348>
   36510:	mov    r14d,0x1c18
   36516:	bzhi   rax,r11,rbx
   3651b:	bzhi   r11,r9,rbx
   36520:	bzhi   r9,rcx,rbx
   36525:	bzhi   r10,r10,rbx
   3652a:	sub    r9,QWORD PTR [r8+rsi*8]
   3652e:	sub    r11,QWORD PTR [r8+rsi*8+0x8]
   36533:	sub    r10,QWORD PTR [r8+rsi*8+0x10]
   36538:	sub    rax,QWORD PTR [r8+rsi*8+0x18]
   3653d:	sub    rdx,QWORD PTR [r8+rsi*8+0x20]
   36542:	mov    r8d,0x1024
   36548:	bzhi   rcx,r9,rbx
   3654d:	sar    r9,0x34
   36551:	mov    ebx,0x280c
   36556:	add    r11,r9
   36559:	mov    r9,r11
   3655c:	bextr  rbx,r11,rbx
   36561:	sar    r11,0x34
   36565:	shl    r9,0x34
   36569:	add    r10,r11
   3656c:	or     r9,rcx
   3656f:	mov    r11,r10
   36572:	bextr  r14,r10,r14
   36577:	sar    r10,0x34
   3657b:	shl    r11,0x28
   3657f:	mov    rcx,r9
   36582:	add    rax,r10
   36585:	or     r11,rbx
   36588:	movabs r10,0x2833e84879b97091
   36592:	movabs rbx,0xb85045b68181585d
   3659c:	mov    rsi,rax
   3659f:	bextr  r8,rax,r8
   365a4:	sar    rax,0x34
   365a8:	shl    rsi,0x1c
   365ac:	add    rdx,rax
   365af:	movabs rax,0x43e1f593f0000001
   365b9:	or     rsi,r14
   365bc:	movabs r14,0x30644e72e131a029
   365c6:	shl    rdx,0x10
   365ca:	or     rdx,r8
   365cd:	sub    rcx,rax
   365d0:	mov    r8,r11
   365d3:	mov    rax,rdi
   365d6:	sbb    r8,r10
   365d9:	mov    r10,rsi
   365dc:	sbb    r10,rbx
   365df:	mov    rbx,rdx
   365e2:	sbb    rbx,r14
   365e5:	cmovb  rcx,r9
   365e9:	cmovb  r8,r11
   365ed:	cmovb  r10,rsi
   365f1:	cmovb  rbx,rdx
   365f5:	mov    QWORD PTR [rdi],rcx
   365f8:	mov    QWORD PTR [rdi+0x8],r8
   365fc:	mov    QWORD PTR [rdi+0x10],r10
   36600:	mov    QWORD PTR [rdi+0x18],rbx
   36604:	add    rsp,0x28
   36608:	pop    rbx
   36609:	pop    r14
   3660b:	vzeroupper
   3660e:	ret
   3660f:	lea    rdx,[rip+0x4c922]        # 82f38 <__frame_dummy_init_array_entry+0x498>
   36616:	mov    esi,0x10
   3661b:	mov    rdi,rax
   3661e:	vzeroupper
   36621:	call   384fb <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
