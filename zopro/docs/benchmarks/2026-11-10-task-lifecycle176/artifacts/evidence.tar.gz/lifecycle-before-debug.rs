//! Diagnostic-only bounded task lifecycle events; no payload values are inspected.
use std::{cell::RefCell,marker::PhantomData,rc::Rc,sync::{OnceLock,atomic::{AtomicBool,AtomicU64,Ordering}},time::Instant};
pub type Event=[u64;8];
pub type Key=(usize,usize);
pub const PUBLISH_BEFORE:u64=1;pub const PUBLISH_AFTER:u64=2;pub const START:u64=3;pub const END:u64=4;
pub const SEARCH_BEGIN:u64=5;pub const SEARCH_END:u64=6;pub const PHASE_BEGIN:u64=7;pub const PHASE_END:u64=8;
pub const EXTERNAL:usize=usize::MAX;pub const FIFO:usize=usize::MAX-1;pub const BROADCAST:usize=1usize<<(usize::BITS-1);
static LEASE:AtomicBool=AtomicBool::new(false);static ACTIVE:AtomicBool=AtomicBool::new(false);static UNPREPARED:AtomicU64=AtomicU64::new(0);static CLOCK:OnceLock<Instant>=OnceLock::new();
#[derive(Default)]struct Buffer{events:Vec<Event>,limit:usize,dropped:u64,worker:usize,pool:usize,depth:usize,current:Key,late:u64}
thread_local!{static BUFFER:RefCell<Buffer>=RefCell::new(Buffer::default());}
fn now()->u64{CLOCK.get().expect("prepare recorder clock").elapsed().as_nanos().try_into().expect("trace clock overflow")}
pub fn prepare_current(worker:usize,pool:usize,capacity:usize)->Result<(),&'static str>{
 if LEASE.load(Ordering::Acquire){return Err("capture lease held");}if capacity==0{return Err("zero event capacity");}CLOCK.get_or_init(Instant::now);
 BUFFER.with(|b|{let mut b=b.borrow_mut();if b.depth!=0{return Err("outstanding scope");}let mut events=Vec::with_capacity(capacity);events.resize(capacity,[0;8]);std::hint::black_box(events.as_slice());events.clear();*b=Buffer{events,limit:capacity,worker,pool,..Buffer::default()};Ok(())})
}
#[inline]pub(crate) fn enabled()->bool{ACTIVE.load(Ordering::Relaxed)}
#[inline]pub(crate) fn event(kind:u64,key:Key,queue:usize,owner:usize){if enabled(){emit(kind,key,queue,owner,false);}}
fn emit(kind:u64,key:Key,queue:usize,owner:usize,late:bool){
 let time=now();BUFFER.with(|b|{let mut b=b.borrow_mut();if b.limit==0{UNPREPARED.fetch_add(1,Ordering::Relaxed);return;}if late{b.late+=1;}
  if b.events.len()==b.limit{b.dropped+=1;return;}let parent=b.current;let row=[time,kind,key.0 as u64,key.1 as u64,queue as u64,owner as u64,parent.0 as u64,parent.1 as u64];b.events.push(row);
 });
}
pub struct Scope{armed:bool,key:Key,previous:Key,end:u64,_local:PhantomData<Rc<()>>}
impl Scope{fn new(begin:u64,end:u64,key:Key)->Self{let armed=enabled();let mut previous=(0,0);if armed{emit(begin,key,0,0,false);BUFFER.with(|b|{let mut b=b.borrow_mut();previous=b.current;b.depth+=1;if begin==START{b.current=key;}});}Self{armed,key,previous,end,_local:PhantomData}}}
impl Drop for Scope{fn drop(&mut self){if self.armed{let late=!enabled()&&self.end==PHASE_END;emit(self.end,self.key,0,0,late);BUFFER.with(|b|{let mut b=b.borrow_mut();assert!(b.depth>0);b.depth-=1;b.current=self.previous;});}}}
#[inline]pub(crate) fn job(key:Key)->Scope{Scope::new(START,END,key)}
#[inline]pub(crate) fn search()->Scope{Scope::new(SEARCH_BEGIN,SEARCH_END,(0,0))}
pub fn phase(id:usize)->Scope{Scope::new(PHASE_BEGIN,PHASE_END,(id,0))}
#[derive(Debug)]pub struct Snapshot{pub worker:usize,pub pool:usize,pub dropped:u64,pub late:u64,pub outstanding:usize,pub capacity:usize,pub events:Vec<Event>}
pub fn take_current()->Result<Snapshot,&'static str>{if ACTIVE.load(Ordering::Acquire){return Err("capture active");}BUFFER.with(|b|{let mut b=b.borrow_mut();if b.limit==0{return Err("thread unprepared");}let out=Snapshot{worker:b.worker,pool:b.pool,dropped:b.dropped,late:b.late,outstanding:b.depth,capacity:b.limit,events:std::mem::take(&mut b.events)};b.limit=0;Ok(out)})}
pub struct Session{begin:u64,_local:PhantomData<Rc<()>>}
pub struct Stopped{pub begin_ns:u64,pub end_ns:u64,_local:PhantomData<Rc<()>>}
impl Session{pub fn begin()->Result<Self,&'static str>{if CLOCK.get().is_none(){return Err("recorder not prepared");}if !BUFFER.with(|b|{let b=b.borrow();b.limit>0&&b.events.is_empty()&&b.depth==0&&b.events.capacity()>=b.limit}){return Err("caller buffer not ready");}LEASE.compare_exchange(false,true,Ordering::AcqRel,Ordering::Relaxed).map_err(|_|"capture already owned")?;UNPREPARED.store(0,Ordering::Relaxed);let begin=now();ACTIVE.store(true,Ordering::Release);Ok(Self{begin,_local:PhantomData})}
 pub fn stop(self)->Stopped{ACTIVE.store(false,Ordering::Release);let out=Stopped{begin_ns:self.begin,end_ns:now(),_local:PhantomData};std::mem::forget(self);out}}
impl Drop for Session{fn drop(&mut self){ACTIVE.store(false,Ordering::Release);LEASE.store(false,Ordering::Release);}}
impl Stopped{pub fn validate(&self,snapshots:&[Snapshot],expected:&[(usize,usize)])->Result<(),&'static str>{
 let identities=snapshots.iter().map(|s|(s.pool,s.worker)).collect::<std::collections::BTreeSet<_>>();let required=expected.iter().copied().collect::<std::collections::BTreeSet<_>>();if identities.len()!=snapshots.len()||required.len()!=expected.len()||identities!=required{return Err("snapshot participant mismatch");}
 if UNPREPARED.load(Ordering::Relaxed)!=0{return Err("unprepared participant");}
 for s in snapshots{if s.dropped!=0{return Err("event overflow");}if s.outstanding!=0{return Err("outstanding scope");}if s.late!=0{return Err("scope completed after stop");}let mut last=self.begin_ns;for e in &s.events{if e[0]<last{return Err("event before capture or nonmonotonic");}if e[0]>self.end_ns&&!matches!(e[1],END|SEARCH_BEGIN|SEARCH_END){return Err("unexpected work after stop");}last=e[0];}}
 Ok(())}}
impl Drop for Stopped{fn drop(&mut self){LEASE.store(false,Ordering::Release);}}
