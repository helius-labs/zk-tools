# Continue after parallel-root full-SDK negative

Goal ACTIVE/UNMET0/8: verified CPU AVX single-proof>=10x supplied M5 CPU for
EACH ALL8, reporting CPU+Metal. No token budget. Userauthorizes autonomousloop,
noquestions, commitANDpush each finishedexperiment, polite factualreports.
No subagents/Python/C/ASM/giantLUT/expanded keyplan/new productionpool/RAMcap.
Previous goal turn PROGRESS: distinct parallel-root native131+8build/linkcommands
qualified,pushed0c84e1a80e. THIS turn PROGRESS: fullSDKcaptured/Gnarkverified/
analyzed/separate-reader reviewed; clearnegative. Publication/checkpointactual
commitandremoteverify must be inspected, not assumed from an unexecuted plan.

R=/home/ubuntu/src/zopro-perf-work/weighted-root-phases-sdk176
Q=/home/ubuntu/src/zopro-perf-work/weighted-root-phases176
Report zopro/docs/benchmarks/2026-11-10-weighted-root-phases-sdk176/README.md.
Workflow37354TERMINAL0,all1329commands succeededonce. Analysis27749TERMINAL0,
separaterawreader23598TERMINAL0,each firstexecution. No livecapture/build/profile.
Allhelpers/statistics/gates/398pins/order/input/copychoices frozen BEFOREANYSDK
functionalpreflight. No ownedhelper/build/hash/report/analysis overlapped ANYSDK
preflight/recording;ONLY37354polledthroughterminal. Tooloutputtruncatedlargefinal
list,butEXPLICITexit0 received; authoritative runs/result.json completesall1329.
No successfuloldnative/model/crypto/capture replayedforbookkeeping.

RESULT58/79,NOTadopted. Primary32 REF7.827059761589404ms /OFF7.835356715231788 /
ON9.356123867549670. PairedON/OFF1.1952775214091163
CI[1.1928831161597184,1.1977082691431198],0/31wins;
ON/REF1.1968334074576643 CI[1.1940107976781102,1.1994784153221465],0/31.
PrimaryOFF/REF1.0013016943937119 CI[.9990366051277868,1.0035235907245927]
PASSES: primaryclearregression,notinvalidcontrol. AggregateON/OFF1.09763205
CI[1.09010879,1.10295892];ON/REF1.10109191 CI[1.09843165,1.10369219].
8x2OFF/REFcalibrationfails (inspectexactCI),sodonotclaimcleanALL8universalestimate.
10/11calibrations,8/22nonreg,22/22RSS,18/18diag pass;0/4primarygain/wins,
0/2aggregate. ExactrecipeCLOSED,no unchangedrerun/exclusions/extensions/subsetrescue.
PrimaryON132MiB vsREF133.25/OFF135;54ON164.279594ms/1942.93MiB vsREF163.340201/
1921.91MiB.16ON9.733818 vsREF9.170142/OFF9.204555;soloON96.610283 vsREF94.464617/
OFF94.182449. Alltimed/diagnosticmajorfaults0;RSSlifetime notminRAM.

119925profilesamples,all9qualityPASS,maxunknown~2.087%,zeroLOST,actualPID/TID/
CPU/MMAPchecks. WeightednamespaceONonly63(primary16),63(primary32),84(2x2-32)
samples confirmsdynamicexecution,notexclusive/removablewalltime. All9rawprofiles
anddecode/counters/receipts archived. SinglePMUpanelsdescriptive,notcausal.

IMPORTANTnewdiagnostic: primary32 medianuserCPU perproof OFF174.030596ms,
ON170.920205;systemCPU OFF4.627477,ON8.411172;voluntaryswitchesOFF357.496689,
ON532.238411.16sysOFF1.978934->ON4.083066;solo .091636->2.091182. Marginalmedians
notsumtojointmedian. Thesearebatchrusage,notper-functioncosts/syscallcounts/futex
counts orcausalproof. Source Reservation::analysis holdsADMISSIONmutex across
resource_limit_now()->OSheadroom/limits filequeries. Newcandidatecallsitperweighted
entry. Extraquery/locking isplausiblecriticalpathcost; rootheap/barrier/fanout also
changed andhavenotbeenisolated. DoNOT removechecksorclaimRAMcausedthegap.

CANONICALNOW49363:
/home/ubuntu/src/zopro-perf-work/weighted-root-phases-sdk176/proof-sha256-after-capture.json
SHA3cc9ec78c1f9abdf6f26153bd08dbd5a1d5c58b2acf287b78958a0ea401c39ea.
Stage44238SDKrequestsincludingprimes/642freshunique164byteGnarkexports;
48721->48754->49363 checkedbindings/freshness. Everyfutureexportseed49363,
NOT48721/48079/older. No newAWS/cloud/phone/ARM/TEE/250/4999/pressure/swap/
minRAM/concurrentproofthroughputclaim. Prioronlyc7ai-0a15ad9ae313aa976terminated.

CandidatefrozenON Q/sdk-ON SHAde831470be30d466a2782c36f70d680cef1237b08624d518cacd18555f001891.
OFF oldweighted-double-current176/sdk-OFF SHA3da30a5adfe92bb72d4d960d622558aeaa5a4f36b3b8631ce82edaadb59f4703.
REFacceptedbusy-reset-sdk176/sdk-ON SHA7aff5f602a1e250a6b9b28889bf6278b51ec400af8399c7481c36248a8718d01.
Originalfield1200/current176source/allcfgs+densebusyreset unchanged.
131nativecoretests/8native+SDKlinks qualificationinheritedwithoutreplay.

NEXT DISTINCThypothesis (notimplemented/qualified/timed): reuseOWNEDbucketbuffer
forroots instead ofnewheaparray+per-calladmission. Sourceinspectionfindsactual
G1weighted callers ownfreshVecs: borrowed_pending/balanced.rs state.finish(),
borrowed_pending.rs combined/state.finish(),fused_kh.rs affine_buckets(state),
msm_affine.rs affine_buckets/combined/buckets. Existingweighted_affine takes &[Affine]
and cannotoverwrite; anownedVec entrycould consumeit. Forfull256bucketgroups,
copyeachgrouptoold511slottree,computeunchanged9roots,store9rootsinfirst9existing
bucketentries;barrierthenfoldeightgroupsbyreadingtheir9prefixpoints. No new root
allocation/capacity orper-entryOSadmissionneeded IF original parent bucketstorage
and6176fixedleaf forecastreallycoverALLliveobjects. Existing partialoutputVec same
originalcapacity. Originalinputsareconsumedtemporarybuckets,NOTkey points. Both
weightedandunweightedrootsmustsurvive. Short/nonmultiple256/G2/resourceoff decline
BEFOREmutation andretain originalborrowed route. No newABIunsafe,cache,table,
pool,RAMcap,freeguardassumption. Extra barrier/reloads/copy/writes remain timed.

Before implementation audit actualcallerownership,allpostweighteduses/branches,
no hiddenclone/reallocation,sourcefootprints andhistory. TargetedREADMEhistorygrep
found no directowned/inplaceweightedroots candidate, butnotexhaustiveproof. The
prior2026-11-07weighted-transpose176 circuit hadsame502joinsandmissedworkremoval,
NOTthisnewmemoryownershipschedule;do not reviveitsinvalidweighted-onlycount.
DO NOT simply rerun currentrecipewithoutadmission. Need a DISTINCT owned-storage
contract/nativeimplementation plus typedbudget/capacity/source invariants, G1/G2
anddisabledfallback,aliases/inputpreservation,partialgroupguards,independentArk
bothoutputs,1/4/16/32/sharedpooltests. Useexactqualifiedroots/kernel wherepossible,
no standalonealgebrareplay. WholeSDKALL8+54+1/16/32/Gnark automaticprofiles still
required,notisolatedpointproduct gain. This weightedpathalonecan'tpromise2x;
maintainfullgoal whilemakingmeasuredwork/memoryprogress. Reject hypothesis if
ownership/forecast/historyauditinvalidatesit. Otherdistinctwork hypothesesavailable.

LatestfreshacceptedREFALL8ms SAMEbuild:
7.827059761589404 /10.928922419354839 /15.793933806451614 /23.996602225806452 /
34.000511 /39.76668277419355 /66.28598680645162 /65.4422084516129.
Primary16=9.170141788079471;solo94.46461681818181;54=163.34020096774194.
M5CPU37/59/109/189/284/335/528/507;Metal24/30/48/74/101/124/176/175;
CPU10xlimits3.7/5.9/10.9/18.9/28.4/33.5/52.8/50.7. NoM5remeasurement,
differenthardware references.54noM5reference. Goal0/8NOTcomplete.
AWSacceptedreport2026-11-10-accepted-current-c7a176:1x2bestZ11.243892ms32/122.52MiB
vsA7.902802ms96/479.98MiB;A32=11.870012.54Z120.757128ms64/2003.02MiB vsA171.908504
ms96/13102.11MiB. No currentAWSmeasurement.

EarliergroupedweightedSDK362e3fc0cd primarynearparity(.000061OFFratio),67/79,
4x2calfail,notadopted. SIMD Booth3679c82b1e rejected73/79,+1.45%primaryallcontrols
qualified. G1GLV/GCD/phase/lifetime/nativebuckets/persistentquarter/factorrecoding/
HrabarLogJumps/SRE/retainedtailhistoriesalreadyexist. See Q/next.md andolder
weighted-double-sdk176/next.md beforeclaimingnewidea/research. Do not repeatedly
retry403ePrint2024/038PDF. No newexternalpaper speedfactortransferredhere.

Rust1.98.1explicit/serializedretainedxtask;noambient1.99/Python/subagents.
BeforeANYSDKpreflightfreezebothactualreaders/allgates/input/order/copies/profiles.
DuringANYpreflight/recordingonlypollexactconfirmedlivehandlethroughterminal;
nohelper/build/hash/analyze/report/push. Timeout/truncationnotterminal. Allrecording
beforeofflineoperations,thenanalyze/separatereview. Canonicaladvanceonlyafterreal
Gnark/freshness. Do not repeat successfulnative/crypto/modelsforbookkeeping.
CommitANDpush aftercompletedexperiment,verifyexactremoteHEAD,updatecheckpoint
and /home/ubuntu/src/zopro-cpu-perf-handoff.md. Stageonlynewreportdir,leavehundreds
olduntrackedreportsalone. Do not markgoalcompletebecause a report/benchmarkends,
orblockedbecauseworkishard/slow/negative.
