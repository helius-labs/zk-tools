# Parallel roots before the weighted eight-lane fold

The previous goal turn is PROGRESS: current weighted-double whole-SDK data and
642fresh Gnark exports measured/reviewed/pushed362e3fc0cd; no gain/adoption.
The full CPU AVX single-proof>=10xM5 CPU ALL8 objective remains active/unmet0/8,
with CPU+Metal comparisons. Canonical48721, original accepted176/SDK7aff unchanged.

Distinct material schedule: restore one root-building job per256-bucket group,
then a barrier and one SIMD fold job per up-to-eight groups. Previous recipe
builds eight groups sequentially per single job, then folds locally. For2048/
4096/16384buckets root-job descriptors grow1->8/2->16/8->64; fold jobs unchanged.
This is task exposure, not a guarantee of simultaneous execution or more CPU use.
No hypothesis that reduced fanout caused the old near-parity result is established.

Use byte-exact old roots() and double-add arithmetic/kernel; both weighted and
unweighted partials retained. The new heap root array holds nine affine points
per group:576bytes/group, plus existing vector-capacity accounting. Admission
reserves its complete checked cost via existing Reservation::analysis BEFORE any
candidate allocation/work, retains token through final fold, then drops it. Denial,
overflow,disabledresourcepolicy,shortinputs,G2 all retain accepted original path.
Roots are per call and freed, no key/witness cache/table/expanded plan/newpool/RAMcap.
Original forecast's6176logical extra bytes/G1leaf remains to cover fold fixed values;
new full root-array charge is separate, NOT hidden in a per-worker maximum. Phase1
uses original511slot tree+Scratch per job; none survives its parallel barrier. Logical
charges are not emitted stack, allocated RSS or minimum RAM. Extra barrier, root
allocation/init/store/load/drop and all guards must be included in any later timing.

Implementation on private fresh snapshot of current176+qualified hooks only.
Old closed grouped recipe is not repeated or rescued; source/dispatch changes.
Native full suite required for integration (old standalone arithmetic suites NOT
replayed), focused phase/barrier/fallback/overflow/coexistence tests, both outputs
and Arkworks oracles, requested512KiB1/4/16/32workers plus sharedpool concurrent
calls. Portable-disabled compile only. Original field1200 reused unchanged; preserve
densebusyreset/all accepted cfgs. No SDK/proofs/timing added during qualification.

After qualification, coherent SDKs and whole-SDK ALL8+54 primary1/16/32 complete
consumer comparison with acceptedREF+freshOFF, automaticprofiles/resources and both
raw readers frozen before ANYpreflight. No time-only isolated weighted entry may
complete the full goal. Measure every new export once with independent Gnark and
48721seed inventory; do not reexecute successful old tests/captures for bookkeeping.
CommitANDpush completedexperiment,politefactualreport,noquestions/subagents/Python.
