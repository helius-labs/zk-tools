# Continue with the qualified parallel-root weighted reducer

Goal ACTIVE/UNMET0/8: verified CPU AVX single-proof latency >=10x supplied M5CPU
for EACH ALL8 shape; report CPU+Metal. No token budget. User authorizes autonomous
loop/noquestions, commit AND push each finished experiment, polite factualreports.
No subagents/Python/C/ASM/giantLUT/expanded-keyplan/new productionpool/RAMcap.
Previous goal turn PROGRESS: weighted-double SDK completed/reviewed/pushed362e3fc0cd.
Current progress: DISTINCT parallel-root schedule implemented, native+SDK qualified,
not yet timed. Check checkpoint.json for actual commit/push/remote verification.

Root Q=/home/ubuntu/src/zopro-perf-work/weighted-root-phases176.
Native workflow19191 TERMINAL0,4steps succeeded once.131unfiltered nativecore tests,
175inherited weighted+sum oraclecasefamily on NEW integration,53 actualworkers across
1/4/16/32 pools requesting512KiBstacks,12concurrent callers sharing8workerpool.
New fourth weightedtest checks8/16/64 rootjobs,1/2/8foldjobs,phasebarrier,actualzero
optional-budget entryfallback,readmission,checkedrootcostoverflow. Counts are work
items, NOT measured simultaneous CPUs. Portable-disabled compileonly,notARM.
Native review PASS firstexecution/201pins/current176source recovered. No old
standalone algebra suite/nativeOFF/fieldqualification repeated for bookkeeping.

SDK workflow94156 TERMINAL0,4newONprover/Zolana/SDKlink+nmsteps succeeded once.
SDK readerPASS firstexecution/210pins/exactREF+OFF/coherentON/checkallflags.
All8scientificcommands succeedfirstexecution. Preparation exception: initial SDK
planselector ends_with(-ON) misses nmstep named-ON-symbols, asserts3!=4 BEFORE
writingplan; subsequent attemptedxtask has no plan/nochild. Failedsource+streams
saved, selector repaired, four-step plan prepared and executedonce. No native or
successfulbuild/capture/proofreplay. NoSDK functionalpreflight yet.

REF actual /home/ubuntu/src/zopro-perf-work/busy-reset-sdk176/sdk-ON
SHA7aff5f602a1e250a6b9b28889bf6278b51ec400af8399c7481c36248a8718d01.
OFF reuse /home/ubuntu/src/zopro-perf-work/weighted-double-current176/sdk-OFF
SHA3da30a5adfe92bb72d4d960d622558aeaa5a4f36b3b8631ce82edaadb59f4703.
NEW ON Q/sdk-ON
SHAde831470be30d466a2782c36f70d680cef1237b08624d518cacd18555f001891.
See identities.json/review-sdk/codegen for exactpaths. Source179members:174exact
originals,2reversiblehooksparents+3children. roots() andkernel.rs byteEXACT to old
qualified weighted-double-current176; ONLY root schedule+admission/newtest change.
Retainall acceptedcfgs especiallydensebusyreset; originalfield1200 exact, no new
fieldmetadata. StaticONweighted_double symbols present/testcounters absent;
dynamicSDKexecution notyet measured. No speed/adoption claim.

Algorithm: old8groups roots serial perjob -> one256bucketgroup rootjob,barrier,
thenfold8groupSIMDjobs. Rootarray9affines pergroup=576bytes+64vectoroverhead;
4672/9280/36928forecastbytes at2048/4096/16384buckets. Existing6176logical extra
G1leaf forecast remains for fixedfoldobjects, NOT rootparents. New rootarray
explicitReservation::analysis BEFORE allocation/work,token held throughfinalfold.
Denial/overflow/short/resourceoff/G2 returnoriginalpath. Same511slottree+Scratch
perrootjob; none survives phasebarrier. Both weighted andunweighted totals and
oldoffsetcorrections preserved;arbitrarytails fastpath padded as before. Actual
fallback test uses2048power-of-two buckets, acceptedoriginalcallercontract; do not
claim original arbitrarynonpower-of-two fallback newly fixed. No table/keyplan/
pointarrayduplicate/newpool/artificialRAMcap. Forecast islogicalnotemittedstack/RSS.

Important cost: local Reservation::analysis readscurrentOSheadroom/policy per
weightedcall. Fulltimer MUST charge those proc reads/lock,rootvecallocation/init/
store/load/drop,secondbarrier,packing,inversions/guards/offsets. No free-admission
assumption. More exposed workitems may not help while sibling windows are already
active; prior nearparity doesNOT prove fanout caused loss. This local path alone
cannotpromise whole2x. No unchangedoldrecipe rerun or posthocsubset rescue.

NEXT genuine end-state movement: freeze WHOLE-SDK ALL8+54/primary1/16/32 compare
using exactREF/OFF/ON above. Newroot weighted-root-phases-sdk176. Reuse qualified
79gate/statistics/copy-design from weighted-double-sdk176, but source_provenance
must check BOTH newreview-result/sdk-review-result,4+4receipts notold13,source
reverseaudit,oldkernel+roots/newphase,correctOFFpathoutsideQ. DoNOT blindlyuse
oldbin() Q/sdk-OFF; candidateQhasONLYON. Newcanonical count+SHA below. FreezeBOTH
actualreaders,allgates/plans/order/inputs/copies beforeANYSDKpreflight. FullSDK
needed because siblingwindows/queries sharepool; isolatedentrynotwholelatency.
Keep31primary16/32blocks151requests,15other31exceptsolo11,3primes,rotatereverse,
114predeterminedindependentbackings,latenciesbefore9PMU+9profiles(16Mcycles:u),
allrecordingbefore45offline+609captureGnark,33preflightSDK+33Gnark=1329commands.
No exclusions/extensions/compiler/layout/worker rescue. Freshproofs once only.
Before anypreflight onlycapabilitychecks/buildhelpers allowed. DuringANYpreflight/
recordingONLYpollexactreturnedlivehandlethroughterminal;nohelper/build/hash/analyze/
report/push overlap. Timeout/truncationnotterminal. Analyzeafterterminal thenfrozen
separaterawreader;completeallgates/resources/portable/concurrency beforeadoption.

CURRENTCANONICAL48721:
/home/ubuntu/src/zopro-perf-work/weighted-double-sdk176/proof-sha256-after-capture.json
SHAfcb234f117cfa3e9e7f97c5e0ffe62a78b6ecaad67d488ecd4a27f78c63e1df0.
This stageZEROrequests/exports. Next prospective33preflight->48754,609capture->49363
ONLYafter realverification/freshness. Do not advance ledger fromplannednumbers.

Prior groupedweighted trial:67/79,noadoption,primaryREF7.843523/OFF7.848311/
ON7.824952ms. PairedON/OFF1.000061 CI[.993927,1.008862],18/31;ON/REF1.002458
CI[.996015,1.011527],20/31. ALL8descriptively+.69%OFF/+.72%REF,4x2controlcalibration
failsupper1.032599>1.03;notcleanslowdownestimate. Solo/4x2/8x2nonregfailures,
all22RSS+18diagPASS. ON134MiB primary;54=163.150466ms/1951.35MiB.119150samples
weightednamespaceONonlyexecutionconfirmed.642freshGnark/44238requestsverified.
Exactgroupedrecipeclosed;newcodeparallelphasesdiffersmaterially.

AcceptedfreshREF ALL8 fromthatcampaign:
7.843523377483443 /10.999177967741934 /15.904656677419355 /24.339150258064517 /
34.042084225806455 /40.074490870967736 /66.24017041935484 /65.62766338709677ms.
Primary16=9.20016061589404;solo94.62874236363636;54=163.0983425483871.
Sameacceptedbuild,notnewrecord/adoption. M5CPU37/59/109/189/284/335/528/507;
Metal24/30/48/74/101/124/176/175;targetms3.7/5.9/10.9/18.9/28.4/33.5/52.8/50.7.
Shapes1x2,2x2,4x2,8x2,12x2,16x2,24x2,merge24x1. Historicaldifferenthardware,
notremeasured.54noM5ref. Fullgoal0/8; never markcomplete becausebuild/reportdone.

LatestAWSacceptedreport2026-11-10-accepted-current-c7a176:Z1x2best11.243892ms32/
122.52MiB vsAeglos7.902802ms96/479.98MiB;A32=11.870012.54Z120.757128ms64/
2003.02MiB vsA171.908504ms96/13102.11MiB. No newAWS/Aeglos/phone/ARM/TEE/
250/4999/pressure/swap/minRAM/concurrentthroughputclaim,zeroresourcescreated.
Earlieronlyc7ai-0a15ad9ae313aa976terminated/cleanupverified.

Historycurrentturnread/excluded: paired-top-bundles alreadytimed paired-top-query;
G2reversevaluelifetimealreadyearly-factor/factor-lookahead/g2-stack-lifetimes;
G2nativebuckets+persistentquarteralreadynegative;HrabarWaterloo/LogJumps already
screened,notnewpapers. See weighted-double-sdk176/next.md forpreviousGLV/GCD/
Booth/SRE/factor/clusteringnegatives. Do not restartblocked2024/038PDFdownload.

Rust1.98.1 explicit,serializedretainedxtask; sourcebinaryfixturehashbytes notUTF8.
Use rg,concisetargetedreads. No subagents. Keepreversibleproductionunchangeduntil
verifiedall8gates. CommitANDpush completedexperiment,exactremoteverify,update
checkpoint and /home/ubuntu/src/zopro-cpu-perf-handoff.md. Do notstageolduntracked
reports. Do not callgoalblockedmerelyhard/sloworcompletewith0/8.
