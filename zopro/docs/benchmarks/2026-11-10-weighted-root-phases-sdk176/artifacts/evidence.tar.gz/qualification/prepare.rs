use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-root-phases176";
const Q:&str="/home/ubuntu/src/zopro-perf-work/weighted-double-current176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn write(p:impl AsRef<Path>,data:impl AsRef<[u8]>){assert!(!p.as_ref().exists());fs::create_dir_all(p.as_ref().parent().unwrap()).unwrap();fs::write(p,data).unwrap();}
fn save(n:&str,v:Value){write(format!("{R}/{n}"),serde_json::to_vec_pretty(&v).unwrap());}
fn main(){
 assert_eq!(read(format!("{Q}/review-result.json"))["passed"],true);let mut audit=read(format!("{Q}/source-audit.json"));let originals=audit["originals"].as_object().unwrap().clone();let children=audit["children"].as_array().unwrap().clone();
 for(p,h)in &originals {assert_eq!(hash(format!("{Z}/{p}")),h.as_str().unwrap());}
 for p in originals.keys().map(String::as_str).chain(children.iter().map(|p|p.as_str().unwrap())) {write(format!("{R}/source/{p}"),fs::read(format!("{Q}/source/{p}")).unwrap());}
 let rel="crates/zopro-core/src/msm/weighted_double.rs";let path=format!("{R}/source/{rel}");let before=fs::read_to_string(&path).unwrap();let mut s=before.clone();let start=s.find("fn partials<").unwrap();let end=s[start..].find("pub(super) fn weighted<").unwrap()+start;let old=s[start..end].to_owned();s.replace_range(start..end,&(fs::read_to_string(format!("{R}/partials.rs")).unwrap()+"\n"));
 let anchor="static TILES: std::sync::atomic::AtomicUsize=std::sync::atomic::AtomicUsize::new(0);";assert_eq!(s.matches(anchor).count(),1);s=s.replace(anchor,&format!("{anchor}\n#[cfg(test)]\nstatic ROOT_JOBS:std::sync::atomic::AtomicUsize=std::sync::atomic::AtomicUsize::new(0);"));
 let anchor="    let partials=partials(buckets);";assert_eq!(s.matches(anchor).count(),1);s=s.replace(anchor,"    let _root_storage=crate::preparation::Reservation::analysis(root_storage::<C>(buckets.len()))?;\n    let partials=partials(buckets);");fs::write(&path,&s).unwrap();
 let rel_tests="crates/zopro-core/src/msm/weighted_double/tests.rs";let p=format!("{R}/source/{rel_tests}");let mut t=fs::read_to_string(&p).unwrap();let suffix=fs::read_to_string(format!("{R}/phase-tests.rs")).unwrap();t.push_str(&format!("\n{suffix}"));fs::write(p,t).unwrap();
 audit["inherited_qualified_snapshot"]=Q.into();audit["old_weighted_body_and_tests_reused_byte_exact"]=false.into();audit["kernel_and_roots_body_unchanged"]=true.into();audit["phase_change"]=json!({"path":rel,"before":before,"after":s,"old_partials_body":old,"test_path":rel_tests,"test_suffix":format!("\n{suffix}")});save("source-audit.json",audit);
 let old=read(format!("{Q}/plan.json"));let mut steps=vec![];for step in old["steps"].as_array().unwrap(){if step["name"]=="build-core-OFF"{continue}let encoded=serde_json::to_string(step).unwrap().replace(Q,R).replace("weighted_double_current176","weighted_root_phases176");let step:Value=serde_json::from_str(&encoded).unwrap();steps.push(step);}
 for d in["ON","portable-compile"]{fs::create_dir_all(format!("{R}/libs/{d}")).unwrap();}assert_eq!(steps.len(),4);
 let mut pins=BTreeMap::new();for p in originals.keys().map(String::as_str).chain(children.iter().map(|p|p.as_str().unwrap())) {let p=format!("{R}/source/{p}");pins.insert(p.clone(),hash(p));}
 for n in["prepare.rs","partials.rs","phase-tests.rs","source-audit.json","design.md"]{let p=format!("{R}/{n}");pins.insert(p.clone(),hash(p));}
 for p in[format!("{Q}/review-result.json"),format!("{Q}/source/crates/zopro-core/src/msm/weighted_double/kernel.rs"),"/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc".into(),"/home/ubuntu/src/zopro-perf-work/weighted-double-sdk176/proof-sha256-after-capture.json".into()]{pins.insert(p.clone(),hash(p));}
 for step in &steps{for w in step["argv"].as_array().unwrap().windows(2){if w[0]=="--extern"{let p=w[1].as_str().unwrap().split_once('=').unwrap().1;pins.insert(p.to_owned(),hash(p));}}}
 assert_eq!(read("/home/ubuntu/src/zopro-perf-work/weighted-double-sdk176/proof-sha256-after-capture.json").as_array().unwrap().len(),48721);save("pins.json",json!(pins));save("plan.json",json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps}));println!("Prepared4newphasequalificationcommands;176currentparents/3children;oldkernel+roots exact;0SDKrequests/exports;canonical48721");
}
