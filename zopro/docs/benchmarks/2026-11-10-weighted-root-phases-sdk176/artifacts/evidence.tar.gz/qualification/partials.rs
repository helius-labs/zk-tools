fn root_storage<C:CurveConfig<Base=Fq>>(buckets:usize)->Option<usize> {
    crate::msm_affine::workspace::vector::<[Affine<C>;9]>(buckets.div_ceil(256),false)
}

fn partials<C:CurveConfig<Base=Fq>>(buckets:&[Affine<C>])->Vec<(Projective<C>,Affine<C>)> {
    let groups=buckets.len().div_ceil(256);
    let mut all_roots=vec![[Affine::<C>::IDENTITY;9];groups];
    #[cfg(test)] let roots_done=std::sync::atomic::AtomicUsize::new(0);
    all_roots.par_iter_mut().zip(buckets.par_chunks(256)).for_each_init(
        ||(Vec::<LimbPoint<Fq>>::new(),Scratch::<C>::default()),
        |(tree,scratch),(out,input)| {
            *out=roots(input,tree,scratch);
            #[cfg(test)] {
                ROOT_JOBS.fetch_add(1,std::sync::atomic::Ordering::Relaxed);
                roots_done.fetch_add(1,std::sync::atomic::Ordering::Release);
            }
        });
    // for_each_init has returned: no root-construction tree/Scratch stays live.
    let mut partials=vec![(Projective::<C>::IDENTITY,Affine::<C>::IDENTITY);groups];
    partials.par_chunks_mut(8).zip(all_roots.par_chunks(8)).for_each(|(out,input)| {
        #[cfg(test)] {
            assert_eq!(roots_done.load(std::sync::atomic::Ordering::Acquire),groups);
            TILES.fetch_add(1,std::sync::atomic::Ordering::Relaxed);
        }
        let active=out.len();let mut values=[[Affine::<C>::IDENTITY;9];8];
        values[..active].copy_from_slice(input);
        let (weighted,_)=kernel::fold(&values,active);
        for i in 0..active {out[i]=(weighted[i].to_projective(),values[i][0]);}
    });
    partials
}
