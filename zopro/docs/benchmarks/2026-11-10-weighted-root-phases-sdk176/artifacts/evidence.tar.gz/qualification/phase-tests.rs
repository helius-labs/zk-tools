#[test]
fn root_phase_job_counts_storage_and_real_admission_fallback() {
    for n in [2048usize,2049,2303,4096,4097,16384,65536] {
        assert_eq!(root_storage::<G1Config>(n),Some(n.div_ceil(256)*9*core::mem::size_of::<G1Affine>()+64));
    }
    assert_eq!(root_storage::<G1Config>(usize::MAX),None);
    assert_eq!(root_storage::<G1Config>(0),Some(0));
    for n in [2048usize,4096,16384] {
        let (p,c)=population(n,1);
        let before=ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed);
        let folds=TILES.load(std::sync::atomic::Ordering::Relaxed);
        check_g1(weighted_affine(&p),expected(&c,true));
        assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed)-before,n.div_ceil(256));
        assert_eq!(TILES.load(std::sync::atomic::Ordering::Relaxed)-folds,n.div_ceil(2048));
    }
    let (p,c)=population(2048,1);let original=p.clone();
    let prior=std::env::var_os("ZOPRO_CPU_PREPARE_MAX_BYTES");
    let before=ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed);
    let folds=TILES.load(std::sync::atomic::Ordering::Relaxed);
    std::env::set_var("ZOPRO_CPU_PREPARE_MAX_BYTES","0");
    check_g1(weighted_affine(&p),expected(&c,true));
    assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed),before);
    assert_eq!(TILES.load(std::sync::atomic::Ordering::Relaxed),folds);
    assert_eq!(p,original);
    match prior {Some(v)=>std::env::set_var("ZOPRO_CPU_PREPARE_MAX_BYTES",v),None=>std::env::remove_var("ZOPRO_CPU_PREPARE_MAX_BYTES")};
    check_g1(weighted_affine(&p),expected(&c,true));
    assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed)-before,8);
    println!("ROOT_PHASE_JOBS=8/16/64;FOLD_JOBS=1/2/8;PHASE_BARRIER=checked;ROOT_PAYLOAD=576_per_group_plus64;ZERO_BUDGET_ACTUAL_ENTRY_FALLBACK=checked;TOKEN_DROPPED_AND_READMITTED=checked;ROOT_COST_OVERFLOW=declined");
}
