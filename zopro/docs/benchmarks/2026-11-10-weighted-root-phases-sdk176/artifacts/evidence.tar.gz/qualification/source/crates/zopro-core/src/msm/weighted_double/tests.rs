use super::*;
use ark_ec::{AffineRepr,CurveGroup,PrimeGroup};
use ark_ff::{BigInt,PrimeField,Zero};
use zopro_bn254::{G1Config,G1Affine,G2Config,G2Affine};
fn af(v:Fr)->ark_bn254::Fr{ark_bn254::Fr::from_bigint(BigInt(v.to_canonical())).unwrap()}
fn aq(v:ark_bn254::Fq)->Fq{Fq::from_canonical(v.into_bigint().0).unwrap()}
fn check_g1(got:Projective<G1Config>,want:ark_bn254::G1Projective){let got=got.to_affine();let want=want.into_affine();if want.is_zero(){assert!(got.is_identity());}else{assert_eq!([got.x,got.y],[aq(want.x),aq(want.y)]);}}
fn seed(state:&mut u64)->Fr {let mut b=[0;32];for chunk in b.chunks_exact_mut(8){*state^=*state<<13;*state^=*state>>7;*state^=*state<<17;chunk.copy_from_slice(&state.to_le_bytes());}Fr::from_le_bytes_mod_order(&b)}
fn population(n:usize,kind:usize)->(Vec<G1Affine>,Vec<ark_bn254::Fr>){let mut state=0xa851743bacd02e17;let g=ark_bn254::G1Projective::generator();let pool:Vec<_>=(0..64).map(|_|af(seed(&mut state))).collect();let native:Vec<_>=pool.iter().map(|s|{let p=(g* *s).into_affine();G1Affine::new(aq(p.x),aq(p.y))}).collect();let mut coefficients=Vec::with_capacity(n);let points=(0..n).map(|i|{let j=(i*37+i/256)%64;let (s,p)=match kind{0=>(ark_bn254::Fr::zero(),G1Affine::IDENTITY),1=>(pool[j],native[j]),2=>if i%2==0{(pool[j],native[j])}else{(-pool[j],-native[j])},3=>if i%13!=0{(ark_bn254::Fr::zero(),G1Affine::IDENTITY)}else{(pool[j],native[j])},_=>if i%5==0{(-pool[0],-native[0])}else{(pool[0],native[0])}};coefficients.push(s);p}).collect();(points,coefficients)}
fn expected(coefficients:&[ark_bn254::Fr],weighted:bool)->ark_bn254::G1Projective{let sum=coefficients.iter().enumerate().fold(ark_bn254::Fr::zero(),|s,(i,x)|s+ *x*ark_bn254::Fr::from(if weighted{i as u64+1}else{1}));ark_bn254::G1Projective::generator()*sum}
fn verify(points:&[G1Affine],coefficients:&[ark_bn254::Fr],check_partials:bool){let old=points.to_vec();let start=TILES.load(std::sync::atomic::Ordering::Relaxed);check_g1(weighted_affine(points),expected(coefficients,true));if points.len()>=2048&&crate::simd::cpu_option("ZOPRO_CPU_RESOURCE_SCHEDULE"){assert_eq!(TILES.load(std::sync::atomic::Ordering::Relaxed)-start,points.len().div_ceil(2048));}else{assert_eq!(TILES.load(std::sync::atomic::Ordering::Relaxed),start);}if points.len()%256==0||points.len()%256!=0&&(points.len()%256).is_power_of_two(){check_g1(weighted_affine_original(points),expected(coefficients,true));}
 if check_partials&&points.len()>=2048{let p=partials(points);assert_eq!(p.len(),points.len().div_ceil(256));for((weighted,total),c)in p.into_iter().zip(coefficients.chunks(256)){check_g1(weighted,expected(c,true));check_g1(total.to_projective(),expected(c,false));}}
 assert_eq!(points,old);
}
#[test]
fn complete_entry_both_sums_tails_and_original_fallback(){let mut cases=0;for kind in 0..5{let(p,c)=population(16384,kind);for n in[0,1,2,4,8,16,128,256,257,258,260,384,512,768,1024,1792,1920,2048,2049,2303,2304,2559,2560,2816,3072,3328,3584,3840,4095,4096,4097,6143,6144,6145,16384]{verify(&p[..n],&c[..n],true);cases+=1;}}assert_eq!(cases,175);println!("COMPLETE_WEIGHTED_CASES=175;BOTH_GROUP_OUTPUTS=checked;ARBITRARY_LONG_TAILS=checked");}
#[test]
fn all_workers_and_concurrent_callers_use_the_complete_entry(){let(p,c)=population(4097,2);let want=expected(&c,true);let mut seen_total=0;for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();let seen=std::sync::Mutex::new(std::collections::BTreeSet::new());pool.broadcast(|ctx|{check_g1(weighted_affine(&p),want);seen.lock().unwrap().insert(ctx.index());});assert_eq!(seen.into_inner().unwrap().len(),workers);seen_total+=workers;}assert_eq!(seen_total,53);
 let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();std::thread::scope(|scope|{let tasks:Vec<_>=(0..4).map(|_|scope.spawn(||{for _ in 0..3{pool.install(||check_g1(weighted_affine(&p),want));}})).collect();for t in tasks{t.join().unwrap();}});println!("ACTUAL_WORKERS=53;CONCURRENT_COMPLETE_CALLS=12");}
#[test]
fn resource_cost_overflow_admission_and_g2_bypass(){
 let logical=8*9*core::mem::size_of::<G1Affine>()+2*8*core::mem::size_of::<G1Affine>()+core::mem::size_of::<kernel::Output<G1Config>>();assert_eq!(extra::<G1Config>(),Some(logical));assert_eq!(logical,6176);
 use crate::msm_affine::workspace::vector as v;
 let original=|n:usize|->Option<usize>{if n==0{return Some(0)}let group=n.min(256);let pairs=group/2;let per=v::<LimbPoint<Fq>>(2*group-1,false)?.checked_add(v::<usize>(pairs,true)?)?.checked_add(v::<Group<Fq>>(pairs/LANES,false)?)?.checked_add(core::mem::size_of::<Vec<[FqBatch;2]>>())?;per.checked_mul(n.div_ceil(256))?.checked_add(v::<(Projective<G1Config>,G1Affine)>(n.div_ceil(256),false)?)};
 for n in[0usize,1,256,2048,4096,65536]{assert_eq!(workspace_weighted::<G1Config>(n),original(n).and_then(|v|v.checked_add(logical.checked_mul(n.div_ceil(256))?)));}assert_eq!(workspace_weighted::<G1Config>(usize::MAX),None);
 let old_resource=std::env::var_os("ZOPRO_CPU_RESOURCE_SCHEDULE");let old_budget=std::env::var_os("ZOPRO_CPU_PREPARE_MAX_BYTES");let(p,c)=population(2048,1);
 std::env::set_var("ZOPRO_CPU_RESOURCE_SCHEDULE","0");verify(&p,&c,false);std::env::set_var("ZOPRO_CPU_RESOURCE_SCHEDULE","1");
 std::env::set_var("ZOPRO_CPU_PREPARE_MAX_BYTES","0");assert!(crate::preparation::Reservation::analysis(workspace_weighted::<G1Config>(2048)).is_none());
 match old_budget{Some(v)=>std::env::set_var("ZOPRO_CPU_PREPARE_MAX_BYTES",v),None=>std::env::remove_var("ZOPRO_CPU_PREPARE_MAX_BYTES")};match old_resource{Some(v)=>std::env::set_var("ZOPRO_CPU_RESOURCE_SCHEDULE",v),None=>std::env::remove_var("ZOPRO_CPU_RESOURCE_SCHEDULE")};
 let g=ark_bn254::G2Projective::generator();let pool:Vec<_>=(1..=16).map(|i|(g*ark_bn254::Fr::from(i as u64)).into_affine()).collect();let points:Vec<_>=(0..2048).map(|i|{let p=pool[i%16];G2Affine::new(Fq2::new(aq(p.x.c0),aq(p.x.c1)),Fq2::new(aq(p.y.c0),aq(p.y.c1)))}).collect();let before=TILES.load(std::sync::atomic::Ordering::Relaxed);let got=weighted_affine::<G2Config>(&points).to_affine();let want=(g*(0..2048).fold(ark_bn254::Fr::zero(),|s,i|s+ark_bn254::Fr::from((i as u64+1)*(i as u64%16+1)))).into_affine();assert_eq!([got.x.c0,got.x.c1,got.y.c0,got.y.c1],[aq(want.x.c0),aq(want.x.c1),aq(want.y.c0),aq(want.y.c1)]);assert_eq!(TILES.load(std::sync::atomic::Ordering::Relaxed),before);println!("LOGICAL_EXTRA_PER_LEAF=6176;FORECAST_EDGES=6;OVERFLOW=declined;EXPLICIT_ZERO_ADMISSION=declined;RESOURCE_OFF=original;G2=original");
}

#[test]
fn root_phase_job_counts_storage_and_real_admission_fallback() {
    for n in [2048usize,2049,2303,4096,4097,16384,65536] {
        assert_eq!(root_storage::<G1Config>(n),Some(n.div_ceil(256)*9*core::mem::size_of::<G1Affine>()+64));
    }
    assert_eq!(root_storage::<G1Config>(usize::MAX),None);
    assert_eq!(root_storage::<G1Config>(0),Some(0));
    for n in [2048usize,4096,16384] {
        let (p,c)=population(n,1);
        let before=ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed);
        let folds=TILES.load(std::sync::atomic::Ordering::Relaxed);
        check_g1(weighted_affine(&p),expected(&c,true));
        assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed)-before,n.div_ceil(256));
        assert_eq!(TILES.load(std::sync::atomic::Ordering::Relaxed)-folds,n.div_ceil(2048));
    }
    let (p,c)=population(2048,1);let original=p.clone();
    let prior=std::env::var_os("ZOPRO_CPU_PREPARE_MAX_BYTES");
    let before=ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed);
    let folds=TILES.load(std::sync::atomic::Ordering::Relaxed);
    std::env::set_var("ZOPRO_CPU_PREPARE_MAX_BYTES","0");
    check_g1(weighted_affine(&p),expected(&c,true));
    assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed),before);
    assert_eq!(TILES.load(std::sync::atomic::Ordering::Relaxed),folds);
    assert_eq!(p,original);
    match prior {Some(v)=>std::env::set_var("ZOPRO_CPU_PREPARE_MAX_BYTES",v),None=>std::env::remove_var("ZOPRO_CPU_PREPARE_MAX_BYTES")};
    check_g1(weighted_affine(&p),expected(&c,true));
    assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed)-before,8);
    println!("ROOT_PHASE_JOBS=8/16/64;FOLD_JOBS=1/2/8;PHASE_BARRIER=checked;ROOT_PAYLOAD=576_per_group_plus64;ZERO_BUDGET_ACTUAL_ENTRY_FALLBACK=checked;TOKEN_DROPPED_AND_READMITTED=checked;ROOT_COST_OVERFLOW=declined");
}
