# Parallel routing of shared shifted G2 contributions

Parent server-shifted183 lost2.8x atprimary32. New evidence is its two serial
22*n digit scans; test whether replacing these with parallel per-base-range
histogram/scatter then parallel per-bucket concatenation removes that bottleneck.
Keep samewidth12/table/reducer/arithmetic. This is a mechanism follow-up, not
another threshold variant. Two mechanism variants then change family absent new
evidence. Additional costs: one full temporary contribution order plus4096counts
andstarts perchunk, charged in later production budget if wholequerysurvives.

Current complete query, serial sharedbucket andparallel sharedbucket inonefresh
nativebinary. Primary1x2 and2x2,32fixedworkers,threeprimes/arm,ninerotated/reversed
blocks,27timedcalls/context. Setuponeimmutabletablepercontextoutsidewarmtimer.
Allwarmtimersincludewordclone,route,reduce,normalization. Freshserialiscontrol,
parentmeasurementsnotcomparedcausallyacrossbuilds. Coarserouting/reductiontimer
readsinsidebothshiftedarms,exportedaftertiming,no printingduringapply. Atleast
primaryparallel/currentmedian<1with6/9winsand2x2median<=1.05selectsSDKfollowup.
Reportserial/parallelroutingandreductionseparately,retained+extra scratchcost.
AlloutputsmatchunchangedArkworksqueryhashes;runparentedge/sharedtestsagain.
No unchangedtimingreruns,parametersearch,AWSlaunch,productionorGitHubpush.
NoCPUclaimfromwalltimers;processresourceusageaggregateonly. Canonical56585same.
