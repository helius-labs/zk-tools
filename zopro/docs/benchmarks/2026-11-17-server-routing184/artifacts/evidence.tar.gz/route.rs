fn route_parallel(&self,words:&[[u64;4]])->(Vec<u32>,Vec<usize>){
let chunk=self.n.div_ceil(rayon::current_num_threads());
let shards:Vec<_>=words.par_chunks(chunk.max(1)).enumerate().map(|(part,scalars)|{
 let begin=part*chunk;let bucket=|d:i16|d.unsigned_abs()as usize-1+if d<0{HALF}else{0};
 let mut starts=vec![0usize;2*HALF+1];for w in 0..WINDOWS{for(i,s)in scalars.iter().enumerate(){let d=super::digit(s,w,WIDTH);if d!=0&&!self.points[w*self.n+begin+i].is_identity(){starts[bucket(d)+1]+=1;}}}
 for i in 1..starts.len(){starts[i]+=starts[i-1];}let mut pos=starts[..2*HALF].to_vec();let mut order=vec![0u32;*starts.last().unwrap()];for w in 0..WINDOWS{for(i,s)in scalars.iter().enumerate(){let d=super::digit(s,w,WIDTH);if d!=0&&!self.points[w*self.n+begin+i].is_identity(){let b=bucket(d);order[pos[b]]=(w*self.n+begin+i)as u32;pos[b]+=1;}}}(order,starts)
}).collect();
let mut starts=vec![0usize;2*HALF+1];for b in 0..2*HALF{starts[b+1]=starts[b]+shards.iter().map(|(_,s)|s[b+1]-s[b]).sum::<usize>();}
let mut order=vec![0u32;*starts.last().unwrap()];let mut rest=&mut order[..];let mut destinations=Vec::with_capacity(2*HALF);for b in 0..2*HALF{let(out,next)=rest.split_at_mut(starts[b+1]-starts[b]);destinations.push(out);rest=next;}
destinations.into_par_iter().enumerate().for_each(|(b,mut out)|{for(o,s)in &shards{let chunk=&o[s[b]..s[b+1]];let(first,next)=out.split_at_mut(chunk.len());first.copy_from_slice(chunk);out=next;}assert!(out.is_empty());});(order,starts)
}
