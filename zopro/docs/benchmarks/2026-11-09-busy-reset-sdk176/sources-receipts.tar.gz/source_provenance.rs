fn source_provenance() -> Value {
    const P:&str="/home/ubuntu/src/zopro-perf-work/busy-reset176";
    const FIELD:&str="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/frozen/candidate/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib";
    let native=read(format!("{P}/review-result.json"));assert_eq!(native["passed"],true);assert_eq!(native["complete_window_cases"],220);assert_eq!(native["speed_measured"],false);
    for(p,h)in read(format!("{P}/repair-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
    let audit=read(r("source-audit.json"));assert_eq!(audit,read(format!("{P}/repaired-source-audit.json")));assert_eq!(audit["edits"].as_array().unwrap().len(),2);assert_eq!(audit["originals"].as_object().unwrap().len(),176);
    for(rel,h)in audit["originals"].as_object().unwrap(){
        assert_eq!(hash(format!("/home/ubuntu/src/zk-tools/zopro/{rel}")),h.as_str().unwrap());let b=fs::read(r(format!("source/{rel}"))).unwrap();assert_eq!(hash(format!("{P}/source/{rel}")),format!("{:x}",Sha256::digest(&b)));
        let recovered=if let Some(e)=audit["edits"].as_array().unwrap().iter().find(|e|e["path"]==rel.as_str()) {let s=String::from_utf8(b).unwrap();let s=s.strip_suffix(e["suffix"].as_str().unwrap()).unwrap();assert_eq!(s.matches(e["after"].as_str().unwrap()).count(),1);s.replace(e["after"].as_str().unwrap(),e["before"].as_str().unwrap()).into_bytes()}else{b};assert_eq!(format!("{:x}",Sha256::digest(recovered)),h.as_str().unwrap());
    }
    assert_eq!(hash(FIELD),"1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713");
    let plan=read(r("build-plan.json"));assert_eq!(plan["steps"].as_array().unwrap().len(),6);assert_eq!(read(r("build-run/result.json"))["status"],"complete");
    for(p,h)in read(r("build-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
    for arm in["OFF","ON"]{
        let core=format!("{P}/libs/{arm}/libzopro_core.rlib");assert_eq!(hash(&core),native["identities"][arm]["sha256"]);
        for stem in["zopro_prover","zopro_zolana","sdk"]{
            let name=format!("{stem}-{arm}");let step=plan["steps"].as_array().unwrap().iter().find(|v|v["name"]==name).unwrap();let args=step["argv"].as_array().unwrap();for flag in["-O","target-cpu=native","codegen-units=1"]{assert!(args.iter().any(|v|v==flag));}assert!(args.iter().any(|v|v==&format!("zopro_bn254={FIELD}")));if stem!="zopro_zolana"{assert!(args.iter().any(|v|v==&format!("zopro_core={core}")));}
            for v in args{let t=v.as_str().unwrap();assert!(!t.contains("negative-phi-short176"));assert!(!t.contains("prefix-short-composition186"));}
            if stem=="sdk"{assert!(args.iter().any(|v|v=="lto=fat"));assert!(args.iter().any(|v|v=="/home/ubuntu/src/zopro-perf-work/worker-placement-control176/driver.rs"));}
            let dir=r(format!("build-run/{name}"));let exit=read(dir.join("exit.json"));assert_eq!(exit["returncode"],0);assert_eq!(exit["success"],true);let actual=read(dir.join("command.json"));assert_eq!(&actual["argv"].as_array().unwrap()[4..],args);for stream in["stdout","stderr"]{assert_eq!(hash(dir.join(format!("{stream}.log"))),exit[format!("{stream}_sha256")]);}
        }
        let p=r(format!("{arm}.nm"));if !p.exists(){let out=std::process::Command::new("nm").arg("-C").arg(r(format!("sdk-{arm}"))).output().unwrap();assert!(out.status.success());fs::write(&p,out.stdout).unwrap();}
        let text=fs::read_to_string(p).unwrap();for needle in["busy_reset_qualification","exact_pending_set_complete_windows_and_workers","tree_option_owner::factory","negative_phi_short::transform"]{assert!(!text.contains(needle));}
    }
    let ref_plan=read("/home/ubuntu/src/zopro-perf-work/worker-placement-control176/build-plan.json");let args=ref_plan["steps"][0]["argv"].as_array().unwrap();assert_eq!(ref_plan["steps"][0]["name"],"link-neutral-driver");for flag in["-O","target-cpu=native","lto=fat","codegen-units=1"]{assert!(args.iter().any(|v|v==flag));}
    let pins=read("/home/ubuntu/src/zopro-perf-work/worker-placement-control176/build-pins.json");for a in args{let a=a.as_str().unwrap();let p=a.split_once('=').map_or(a,|(_,p)|p);if p.ends_with(".rlib"){assert_eq!(hash(p),pins[p]);}}assert_eq!(read("/home/ubuntu/src/zopro-perf-work/worker-placement-control176/plan-review.json")["passed"],true);
    json!({"source176_recovered":true,"parent_native220Windowcases_inherited":true,"six_coherent_downstream_links":true,"two_exact_qualified_core_libraries_reused":true,"original_field1200":true,"actual_native_O3_fatLTO_oneCGU_driver":true,"release_test_helpers_absent":true,"no_option_owner_or_short_phi_candidate":true})
}
