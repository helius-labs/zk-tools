use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/busy-reset-sdk176";const P:&str="/home/ubuntu/src/zopro-perf-work/busy-reset176";const OLD:&str="/home/ubuntu/src/zopro-perf-work/negative-phi-sdk176";const FIELD:&str="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/frozen/candidate/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}fn save(p:&str,v:Value){fs::write(format!("{R}/{p}"),serde_json::to_vec_pretty(&v).unwrap()).unwrap()}
fn main(){
 assert!(!Path::new(R).join("build-plan.json").exists());let parent=read(format!("{P}/review-result.json"));assert_eq!(parent["passed"],true);assert_eq!(parent["speed_measured"],false);assert_eq!(parent["complete_window_cases"],220);
 let audit=read(format!("{P}/repaired-source-audit.json"));let originals=audit["originals"].as_object().unwrap();assert_eq!(originals.len(),176);let mut pins=BTreeMap::new();
 for(rel,h)in originals{let original=format!("/home/ubuntu/src/zk-tools/zopro/{rel}");assert_eq!(hash(&original),h.as_str().unwrap());pins.insert(original,h.clone());let p=format!("{P}/source/{rel}");let dest=format!("{R}/source/{rel}");fs::create_dir_all(Path::new(&dest).parent().unwrap()).unwrap();fs::copy(&p,&dest).unwrap();pins.insert(p.clone(),json!(hash(&p)));pins.insert(dest.clone(),json!(hash(&dest)));}
 save("source-audit.json",audit.clone());for arm in["OFF","ON"]{let core=format!("{P}/libs/{arm}/libzopro_core.rlib");assert_eq!(hash(&core),parent["identities"][arm]["sha256"]);pins.insert(core.clone(),json!(hash(&core)));fs::create_dir_all(format!("{R}/libs/{arm}")).unwrap();}
 let template=read(format!("{OLD}/build-plan.json"));let mut steps=Vec::new();for arm in["OFF","ON"]{for stem in["zopro_prover","zopro_zolana","sdk"]{
  let name=format!("{stem}-{arm}");let mut s=template["steps"].as_array().unwrap().iter().find(|s|s["name"]==name).unwrap().clone();let old=s["argv"].as_array().unwrap();let mut argv=Vec::new();let mut i=0;
  while i<old.len(){let v=old[i].as_str().unwrap();if v=="-L" && old.get(i+1).and_then(Value::as_str).is_some_and(|s|s.contains("negative-phi-short176")||s.contains("prefix-short-composition186")){i+=2;continue;}
   let mut value=v.replace(OLD,R).replace("short_forward_sdk176", "busy_reset_sdk176");if value.starts_with("zopro_bn254="){value=format!("zopro_bn254={FIELD}");}else if value.starts_with("zopro_core="){value=format!("zopro_core={P}/libs/{arm}/libzopro_core.rlib");}argv.push(value);i+=1;
  }
  argv.extend(["-L".into(),format!("dependency={P}/libs/{arm}")]);s["argv"]=json!(argv);for v in s["environment"].as_object_mut().unwrap().values_mut(){if let Some(t)=v.as_str(){*v=json!(t.replace(OLD,R));}}steps.push(s);
 }}assert_eq!(steps.len(),6);
 for f in["review-result.json","repaired-source-audit.json","repair-pins.json","plan.json","repair-plan.json"]{let p=format!("{P}/{f}");pins.insert(p.clone(),json!(hash(p)));}
 for f in["design.md","prepare.rs","prepare","source-audit.json"]{let p=format!("{R}/{f}");pins.insert(p.clone(),json!(hash(p)));}
 for s in &steps{for v in s["argv"].as_array().unwrap(){let t=v.as_str().unwrap();let p=t.split_once('=').map_or(t,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.to_owned(),json!(hash(p)));}}}
 for p in["/home/ubuntu/src/zopro-perf-work/worker-placement-control176/support/perf.rs","/home/ubuntu/src/zopro-perf-work/worker-placement-control176/plan-review.json"]{pins.insert(p.into(),json!(hash(p)));}
 save("build-plan.json",json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"steps":steps}));pins.insert(format!("{R}/build-plan.json"),json!(hash(format!("{R}/build-plan.json"))));save("build-pins.json",json!(pins));println!("Prepared6coherentprover/zolana/SDKbuilds;reusequalifiedOFFONcores andoriginalfield1200;scopefrozen;no preflight orclock");
}
