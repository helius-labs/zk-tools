use zopro_bn254::{FqConfig,ifma8::{Ifma8,AffineDelta3}};type V=Ifma8<FqConfig,true>;
// Inputs already reside in the native field representation. This codegen
// scope excludes packing, inversions, signs, tails and the complete caller.
#[no_mangle]#[inline(never)]pub fn jointdelta_original_g1(a:&[V;5])->[V;2]{let x=a[0].sub(&a[1].add_canonical(&a[2]));let d=a[1].sub(&x);let y=a[3].mul(&d).sub(&a[4]);[x,y]}
#[no_mangle]#[inline(never)]pub fn jointdelta_candidate_g1(a:&[V;5])->[V;2]{let(x,d)=a[0].joint_x_delta(&a[1],&a[2]);let y=d.mul(&a[3]).sub(&a[4]);[x,y]}
#[no_mangle]#[inline(never)]pub fn jointdelta_original_g2(a:&[V;10])->[V;4]{let x0=a[0].sub(&a[2].add(&a[4]));let x1=a[1].sub(&a[3].add(&a[5]));let d0=a[2].sub(&x0);let d1=a[3].sub(&x1);let y0=a[6].difference2(&d0,&a[7],&d1).sub(&a[8]);let y1=a[6].sum2(&d1,&a[7],&d0).sub(&a[9]);[x0,x1,y0,y1]}
#[no_mangle]#[inline(never)]pub fn jointdelta_candidate_g2(a:&[V;10])->[V;4]{let(x0,d0)=a[0].joint_x_delta(&a[2],&a[4]);let(x1,d1)=a[1].joint_x_delta(&a[3],&a[5]);let[y0,y1]=AffineDelta3::complex_mul(&d0,&d1,&a[6],&a[7]);[x0,x1,y0.sub(&a[8]),y1.sub(&a[9])]}
fn main(){std::hint::black_box([jointdelta_original_g1 as *const (),jointdelta_candidate_g1 as *const (),jointdelta_original_g2 as *const (),jointdelta_candidate_g2 as *const ()]);}
