use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,collections::BTreeMap};mod graph;
const R:&str="/home/ubuntu/src/zopro-perf-work/polar-euler-pruning176";
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
// Independent recursive dependency reader. Stage kinds are derived from level
// numbers; no call to producer forward/backward propagation or butterflies.
struct Reader {n:usize,l:usize,pot:Vec<Vec<Option<bool>>>,seen:Vec<Vec<bool>>,roots:Vec<Vec<bool>>,input:Vec<bool>}
impl Reader{
 fn new(input:&[bool])->Self{let n=input.len();let l=n.trailing_zeros() as usize;Self{n,l,pot:vec![vec![None;n];2*l+2],seen:vec![vec![false;n];2*l+2],roots:vec![vec![false;n/2];2*l+1],input:input.to_vec()}}
 fn k(&self,i:usize)->usize{let mut k=0;for b in 0..self.l{k|=((i>>b)&1)<<(self.l-1-b);}k}
 fn gap(&self,s:usize)->usize {if s<self.l{self.n>>(s+1)}else{1<<(s-self.l-1)}}
 fn possible(&mut self,level:usize,i:usize)->bool{if let Some(v)=self.pot[level][i]{return v;}let v=if level==0{self.input[i]}else{let s=level-1;if s==self.l{self.k(i)!=0&&self.possible(s,i)}else{let g=self.gap(s);let lo=i&!g;self.possible(s,lo)||self.possible(s,lo+g)}};self.pot[level][i]=Some(v);v}
 fn visit(&mut self,level:usize,i:usize){if self.seen[level][i]||!self.possible(level,i){return;}self.seen[level][i]=true;if level==0{return;}let s=level-1;if s==self.l{self.visit(s,i);return;}let g=self.gap(s);let lo=i&!g;let hi=lo+g;let j=lo%g;let site=(lo/(2*g))*g+j;let live=if s<self.l{i==hi}else{self.possible(s,hi)};if j!=0&&live{self.roots[s][site]=true;}self.visit(s,lo);self.visit(s,hi);}
 fn solve(mut self,want:&[bool])->Self{for(i,&w)in want.iter().enumerate(){if w{self.visit(2*self.l+1,i);}}self}
 // Prime-97 independent recursive numerical transform (N=8).
 fn value(&self,level:usize,i:usize,x:&[u64],memo:&mut[Vec<Option<u64>>])->u64{if let Some(v)=memo[level][i]{return v;}let v=if !self.seen[level][i]{0}else if level==0{x[i]}else{let s=level-1;if s==self.l{self.value(s,i,x,memo)*self.k(i) as u64%97}else{let g=self.gap(s);let lo=i&!g;let u=self.value(s,lo,x,memo);let v=self.value(s,lo+g,x,memo);let w=pow(if s<self.l{pow(64,95)}else{64},((lo%g)*self.n/(2*g)) as u64);if s<self.l{if i==lo{(u+v)%97}else{(u+97-v)*w%97}}else{let v=v*w%97;if i==lo{(u+v)%97}else{(u+97-v)%97}}}};memo[level][i]=Some(v);v}
}
fn pow(mut x:u64,mut k:u64)->u64{let mut r=1;while k>0{if k&1!=0{r=r*x%97;}x=x*x%97;k>>=1;}r}
fn count(x:&[Vec<bool>])->usize{x.iter().flatten().filter(|&&v|v).count()}
fn pair(a:&Reader,b:&Reader)->(usize,usize){let mut sites=0;let mut groups=0;for(x,y)in a.roots.iter().zip(&b.roots){for (p,q)in x.chunks(4).zip(y.chunks(4)){let mut any=false;for(&p,&q)in p.iter().zip(q){sites+=usize::from(p||q);any|=p||q;}groups+=usize::from(any);}}(sites,groups)}
fn main(){let mut pins=0;for(p,h)in serde_json::from_slice::<BTreeMap<String,String>>(&fs::read(format!("{R}/pins.json")).unwrap()).unwrap(){assert_eq!(hash(&p),h);pins+=1;}
    let mut exhaustive=0;let mut numerical=0;assert_eq!(pow(64,8),1);assert_ne!(pow(64,4),1);
    for bits in 0..256 {let input:Vec<_>=(0..8).map(|i|bits>>i&1!=0).collect();for demand in 0..256{let want:Vec<_>=(0..8).map(|i|demand>>i&1!=0).collect();let r=Reader::new(&input).solve(&want);let t=graph::Trace::new(&input,&want);assert_eq!(r.roots,t.roots);exhaustive+=1;}
        let r=Reader::new(&input).solve(&[true;8]);let x:Vec<_>=(0..8).map(|i|if input[i]{((i*13+bits*7)%96+1) as u64}else{0}).collect();let mut memo=vec![vec![None;8];8];
        let coeff:Vec<u64>=(0..8).map(|k|(0..8).map(|j|x[j]*pow(pow(64,95),(j*k) as u64)%97).sum::<u64>()%97).collect();for j in 0..8 {let expected=(1..8).map(|k|coeff[k]*(k as u64)*pow(64,(j*k) as u64)%97).sum::<u64>()%97;assert_eq!(r.value(7,j,&x,&mut memo),expected);numerical+=1;}
    }
    let a:Value=serde_json::from_slice(&fs::read(format!("{R}/analysis.json")).unwrap()).unwrap();let m:Value=serde_json::from_slice(&fs::read(format!("{R}/masks.json")).unwrap()).unwrap();let mut decisions=vec![];
    for row in a["rows"].as_array().unwrap(){let shape=row["shape"].as_str().unwrap();let n=row["N"].as_u64().unwrap() as usize;let rows=row["rows"].as_u64().unwrap() as usize;let p:Vec<Vec<bool>>=m["shapes"][shape].as_array().unwrap().iter().map(|v|{let s=v.as_str().unwrap();assert_eq!(s.len(),rows);let mut p:Vec<_>=s.bytes().map(|x|match x{b'0'=>false,b'1'=>true,_=>panic!("mask byte")}).collect();p.resize(n,false);p}).collect();
        let rs=[Reader::new(&p[0]).solve(&p[1]),Reader::new(&p[1]).solve(&p[0]),Reader::new(&p[2]).solve(&p[2]),Reader::new(&p[3]).solve(&p[3])];
        for i in 0..4{assert_eq!(count(&rs[i].roots),row["scalar_root_sites_ABSD"][i].as_u64().unwrap() as usize);}
        let base=pair(&rs[0],&rs[1]);let polar=pair(&rs[2],&rs[3]);assert_eq!(json!(base.0),row["baseline_paired_root_sites"]);assert_eq!(json!(polar.0),row["polar_paired_root_sites"]);assert_eq!(json!(base.1),row["baseline_four_site_groups"]);assert_eq!(json!(polar.1),row["polar_four_site_groups"]);let pass=polar.0<base.0&&polar.1<base.1;assert_eq!(json!(pass),row["native_screen_passed"]);decisions.push(pass);
    }
    assert_eq!(a["native_selected"],json!(decisions.iter().all(|&x|x)));let v=json!({"passed":true,"recursive_vs_iterative_support_demand_pairs":exhaustive,"prime97_direct_DFT_outputs":numerical,"pins":pins,"fixture_decisions":decisions,"actual_fixture_root_counts_recomputed":true,"scope":"separate recursive reader over published formal masks; does not independently parse raw solver images or qualify native code"});fs::write(format!("{R}/review.json"),serde_json::to_vec_pretty(&v).unwrap()).unwrap();println!("{v}");
}
