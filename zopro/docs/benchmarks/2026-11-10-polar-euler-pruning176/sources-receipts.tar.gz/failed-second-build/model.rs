use ark_bn254::Fr;
use ark_ff::{Field,FftField};
use serde_json::{json,Value};
use std::{fs,collections::BTreeMap};
mod parser; mod graph;
use graph::{Trace,Op,butterflies,rev};
const R:&str="/home/ubuntu/src/zopro-perf-work/polar-euler-pruning176";
fn save(name:&str,v:&Value){fs::write(format!("{R}/{name}"),serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn eval(x:&[Fr],t:&Trace)->Vec<Fr>{
    let n=x.len();let omega=Fr::get_root_of_unity(n as u64).unwrap();let inv=omega.inverse().unwrap();
    let mut v:Vec<_>=x.iter().enumerate().map(|(i,&v)|if t.demand[0][i]{v}else{Fr::ZERO}).collect();
    for(s,&op)in t.ops.iter().enumerate(){let d=&t.demand[s+1];let mut out=vec![Fr::ZERO;n];match op{
        Op::Weight=>for i in 0..n{if d[i]{out[i]=v[i]*Fr::from(rev(i,n) as u64);}},
        Op::Dif(g)=>for(lo,hi,j)in butterflies(n,g){if d[lo]{out[lo]=v[lo]+v[hi];}if d[hi]{out[hi]=(v[lo]-v[hi])*inv.pow([(j*n/(2*g)) as u64]);}},
        Op::Dit(g)=>for(lo,hi,j)in butterflies(n,g){if d[lo]||d[hi]{let w=v[hi]*omega.pow([(j*n/(2*g)) as u64]);if d[lo]{out[lo]=v[lo]+w;}if d[hi]{out[hi]=v[lo]-w;}}}}
        for i in 0..n {assert!(t.possible[s+1][i]||out[i]==Fr::ZERO);}v=out;
    }v
}
// Independent O(N^2) coefficient/evaluation oracle: no butterfly, reversal,
// pruning, or producer graph is used. This returns unnormalized N*E(f).
fn direct(x:&[Fr])->Vec<Fr>{let n=x.len();let w=Fr::get_root_of_unity(n as u64).unwrap();let inv=w.inverse().unwrap();let coeff:Vec<Fr>=(0..n).map(|k|x.iter().enumerate().map(|(j,&v)|v*inv.pow([(j*k) as u64])).sum()).collect();(0..n).map(|j|(1..n).map(|k|coeff[k]*Fr::from(k as u64)*w.pow([(j*k) as u64])).sum()).collect()}
fn next(s:&mut u64)->u64{*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;*s}
fn qualify()->Value {
    let mut seed=0x8c361e0592a91b47;let mut outputs=0;let mut demanded=0;let mut identities=0;let mut cases=0;
    for n in [8,16,32,64] {for c in 0..72 {
        let mut a=vec![Fr::ZERO;n];let mut b=a.clone();
        for i in 0..n {let x=Fr::from(next(&mut seed));let y=Fr::from(next(&mut seed));let kind=c%9;
            (a[i],b[i])=match kind {0=>(Fr::ZERO,Fr::ZERO),1=>(x,x),2=>(x,-x),3=>(x,Fr::ZERO),4=>(Fr::ZERO,y),5=>if i<n/3{(x,y)}else{(Fr::ZERO,Fr::ZERO)},6=>if next(&mut seed)%4==0{(x,x)}else{(Fr::ZERO,y)},7=>if i%2==0{(x,y)}else{(Fr::ZERO,Fr::ZERO)},_=>(x,y)};
        }
        let s:Vec<_>=a.iter().zip(&b).map(|(&a,&b)|a+b).collect();let d:Vec<_>=a.iter().zip(&b).map(|(&a,&b)|a-b).collect();
        let mut derivatives=vec![];
        for x in [&a,&b,&s,&d]{let support:Vec<_>=x.iter().map(|&x|x!=Fr::ZERO).collect();let expected=direct(x);let full=Trace::new(&support,&vec![true;n]);assert_eq!(eval(x,&full),expected);outputs+=n;
            let want:Vec<_>=(0..n).map(|i|match c%4{0=>false,1=>true,2=>i<n/2,_=>next(&mut seed)&1!=0}).collect();let pruned=eval(x,&Trace::new(&support,&want));for i in 0..n{if want[i]{assert_eq!(pruned[i],expected[i]);demanded+=1;}}derivatives.push(expected);
        }
        let half=Fr::from(2u64).inverse().unwrap();
        let demands=[b.iter().map(|&x|x!=Fr::ZERO).collect::<Vec<_>>(),a.iter().map(|&x|x!=Fr::ZERO).collect(),s.iter().map(|&x|x!=Fr::ZERO).collect(),d.iter().map(|&x|x!=Fr::ZERO).collect()];
        let pruned:Vec<_>=[&a,&b,&s,&d].iter().zip(&demands).map(|(x,want)|eval(x,&Trace::new(&x.iter().map(|&x|x!=Fr::ZERO).collect::<Vec<_>>(),want))).collect();
        for i in 0..n{let baseline=derivatives[0][i]*b[i]+a[i]*derivatives[1][i];assert_eq!(baseline,(s[i]*derivatives[2][i]-d[i]*derivatives[3][i])*half);assert_eq!(baseline,pruned[0][i]*b[i]+a[i]*pruned[1][i]);assert_eq!(baseline,(s[i]*pruned[2][i]-d[i]*pruned[3][i])*half);identities+=1;}
        cases+=1;
    }}json!({"passed":true,"cases":cases,"Fr_full_derivative_outputs":outputs,"Fr_arbitrary_demand_outputs":demanded,"Fr_complete_polarized_rows":identities,"sizes":[8,16,32,64],"oracle":"independent direct inverse DFT and coefficient-weighted evaluation, unnormalized N*E"})
}
fn main(){let qualification=qualify();println!("exact qualification: {qualification}");let mut rows=vec![];let mut masks=BTreeMap::new();
    for(shape,expected,equal)in[("1x2",30922,18530),("2x2",53874,32128)]{
        let path=format!("/home/ubuntu/src/zopro-perf-work/wire-readiness175/{shape}.solver");let m=parser::read(&fs::read(&path).unwrap());assert_eq!(m.rows,expected);assert_eq!(m.supports[3].iter().filter(|&&x|!x).count(),equal);
        masks.insert(shape.to_string(),m.supports.iter().map(|v|v.iter().map(|&x|if x{'1'}else{'0'}).collect::<String>()).collect::<Vec<_>>());
        let n=m.rows.next_power_of_two();let p:Vec<_>=m.supports.iter().map(|v|{let mut v=v.clone();v.resize(n,false);v}).collect();
        let a=Trace::new(&p[0],&p[1]);let b=Trace::new(&p[1],&p[0]);let s=Trace::new(&p[2],&p[2]);let d=Trace::new(&p[3],&p[3]);
        let base=graph::paired(&a,&b);let polar=graph::paired(&s,&d);let eligible=polar.0<base.0&&polar.1<base.1;
        let stage:Vec<_>=(0..a.ops.len()).map(|i|json!({"op":format!("{:?}",a.ops[i]),"A":a.roots[i].iter().filter(|&&x|x).count(),"B":b.roots[i].iter().filter(|&&x|x).count(),"S":s.roots[i].iter().filter(|&&x|x).count(),"D":d.roots[i].iter().filter(|&&x|x).count()})).collect();
        let weight_counts:Vec<_>=[&a,&b,&s,&d].iter().map(|t|t.weights.iter().filter(|&&x|x).count()).collect();
        let row=json!({"shape":shape,"rows":m.rows,"N":n,"wires":m.wires,"stored_slots":m.stored_slots,"hints":m.hints,"assignments":m.assignments,"formal_supports_ABSD":m.supports.iter().map(|v|v.iter().filter(|&&x|x).count()).collect::<Vec<_>>(),"scalar_root_sites_ABSD":[a.root_count(),b.root_count(),s.root_count(),d.root_count()],"nonunit_weight_sites_ABSD":weight_counts,"baseline_paired_root_sites":base.0,"polar_paired_root_sites":polar.0,"baseline_four_site_groups":base.1,"polar_four_site_groups":polar.1,"native_screen_passed":eligible,"stages":stage});println!("{shape}: paired {} -> {}, groups {} -> {}, pass={eligible}",base.0,polar.0,base.1,polar.1);rows.push(row);
    }
    let gate=rows.iter().all(|v|v["native_screen_passed"]==true);save("masks.json",&json!({"channel_order":["A","B","S=A+B","D=A-B"],"mask_kind":"exact formal nonzero over independent original wires; ordered domain rows","shapes":masks}));save("analysis.json",&json!({"qualification":qualification,"rows":rows,"native_selected":gate,"performance_measured":false,"production_changed":false,"goal_complete":false,"goal_active":true,"new_proofs":0}));
}
