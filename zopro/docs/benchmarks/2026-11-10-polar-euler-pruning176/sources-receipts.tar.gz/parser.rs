// Image-v2 layout follows solver.rs and semantic-cse176/model.rs; unlike that
// semantic study, original wires here stay independent formal variables.
use ark_bn254::Fr;
use ark_ff::{BigInt, PrimeField, Field, AdditiveGroup};
use std::collections::BTreeMap;
type Form=BTreeMap<usize,Fr>;
const STORED:u32=1<<31; const NONE:u32=STORED-1; const CHAIN:u32=STORED-2;
fn add(a:&Form,b:&Form,k:Fr)->Form {
    let mut c=a.clone(); for (&w,&v) in b { let e=c.entry(w).or_default(); *e+=v*k; if *e==Fr::ZERO {c.remove(&w);} } c
}
fn constant(v:Fr)->Form {if v==Fr::ZERO {Form::new()} else {[(0,v)].into()}}
fn wire(w:usize,nw:usize,slots:&[Option<Form>])->Form {
    if w<nw {[(w,Fr::ONE)].into()} else {slots[w-nw].as_ref().expect("undefined slot").clone()}
}
#[derive(Clone,Copy)] struct Term {c:usize,w:usize}
struct Reader<'a>{b:&'a[u8],at:usize}
impl Reader<'_>{
    fn bytes(&mut self,n:usize)->&[u8]{let e=self.at.checked_add(n).unwrap();let v=&self.b[self.at..e];self.at=e;v}
    fn u(&mut self)->usize{u32::from_le_bytes(self.bytes(4).try_into().unwrap()) as usize}
    fn field(&mut self)->Fr{let b=self.bytes(32);let w=std::array::from_fn(|i|u64::from_le_bytes(b[8*i..8*i+8].try_into().unwrap()));let x=BigInt(w);assert!(x<Fr::MODULUS);Fr::new_unchecked(x)}
}
fn term(t:Term,c:&[Fr],nw:usize,s:&[Option<Form>])->Form {add(&Form::new(),&wire(t.w,nw,s),c[t.c])}
fn expr(r:&mut Reader<'_>,c:&[Fr],t:&[Term],nw:usize,s:&[Option<Form>])->Form{
    let(tag,a,b)=(r.u(),r.u(),r.u());match tag{
        0=>Form::new(),1=>wire(a,nw,s),2=>constant(c[a]),3=>term(t[a],c,nw,s),
        4=>t[a..b].iter().fold(Form::new(),|v,&x|add(&v,&term(x,c,nw,s),Fr::ONE)),_=>panic!("expression tag")}
}
pub struct Masks {pub rows:usize,pub wires:usize,pub stored_slots:usize,pub hints:usize,pub assignments:usize,pub supports:[Vec<bool>;4]}
pub fn read(b:&[u8])->Masks{
    let mut r=Reader{b,at:0};assert_eq!(r.u(),0x3150535a);assert_eq!(r.u(),2);
    let(nw,ni,np,nc,na,nb,ncoef,nt,ns,nslots,nops)=(r.u(),r.u(),r.u(),r.u(),r.u(),r.u(),r.u(),r.u(),r.u(),r.u(),r.u());
    assert!(0<np&&np<=ni&&ni<=nw&&nslots<=ns);
    for n in [na,nb] {let mut last=None;for _ in 0..n {let w=r.u();assert!(w<nw&&last.is_none_or(|p|p<w));last=Some(w);}}
    let c:Vec<_>=(0..ncoef).map(|_|r.field()).collect();assert_eq!(c[..5],[Fr::ZERO,Fr::ONE,Fr::from(2u64),-Fr::ONE,-Fr::from(2u64)]);
    let read_term=|r:&mut Reader<'_>|{let(c,w)=(r.u(),r.u());assert!(c<ncoef&&w<nw);Term{c,w}};
    let t:Vec<_>=(0..nt).map(|_|read_term(&mut r)).collect();
    let sums:Vec<_>=(0..ns).map(|_|{let p=r.u() as u32;(p,read_term(&mut r))}).collect();
    let mut slots=vec![None;nslots];let mut seen_rows=vec![false;nc];let mut seen_sums=vec![false;ns];
    let mut supports=std::array::from_fn(|_|vec![false;nc]);let mut hints=0;let mut assignments=0;
    for _ in 0..nops {match r.u(){
        1=>{let(kind,a,b,start,end)=(r.u(),r.u(),r.u(),r.u(),r.u());assert!(kind<=1&&a<=b&&b<=nt&&start<end&&end<=nw&&end-start<=256);assert!(kind!=0||end-start==1);hints+=1;},
        0=>{
            let(row,a,b,first)=(r.u(),r.u(),r.u(),r.u());assert!(row<nc&&!seen_rows[row]&&a<=b&&b<=ns);seen_rows[row]=true;
            let mut slot=first;let mut chain=Form::new();
            for j in a..b {assert!(!seen_sums[j]);seen_sums[j]=true;let(p,t)=sums[j];let v=term(t,&c,nw,&slots);
                chain=match p&!STORED{NONE=>v,CHAIN=>add(&chain,&v,Fr::ONE),w=>add(&wire(w as usize,nw,&slots),&v,Fr::ONE)};
                if p&STORED!=0 {assert!(slots[slot].is_none());slots[slot]=Some(chain.clone());slot+=1;}
            }
            let mut f:[Form;3]=std::array::from_fn(|_|expr(&mut r,&c,&t,nw,&slots));
            match r.u(){0=>{},1=>{let(side,w,ci)=(r.u(),r.u(),r.u());assert!(side<3&&w<nw&&ci<ncoef&&c[ci]!=Fr::ZERO);let inv=r.field();assert_eq!(c[ci]*inv,Fr::ONE);f[side]=add(&f[side],&wire(w,nw,&slots),c[ci]);assignments+=1;},_=>panic!("assignment tag")}
            let v=[f[0].clone(),f[1].clone(),add(&f[0],&f[1],Fr::ONE),add(&f[0],&f[1],-Fr::ONE)];
            for i in 0..4 {supports[i][row]=!v[i].is_empty();}
        },_=>panic!("operation tag")}}
    assert_eq!(r.at,b.len());assert!(seen_rows.iter().all(|&x|x)&&seen_sums.iter().all(|&x|x)&&slots.iter().all(Option::is_some));
    Masks{rows:nc,wires:nw,stored_slots:nslots,hints,assignments,supports}
}
