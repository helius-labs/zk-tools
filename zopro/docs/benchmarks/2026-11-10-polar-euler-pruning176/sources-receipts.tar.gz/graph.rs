#[derive(Clone,Copy,Debug)] pub enum Op {Dif(usize),Weight,Dit(usize)}
pub fn ops(n:usize)->Vec<Op>{assert!(n.is_power_of_two()&&n>=2);let mut v=vec![];let mut g=n/2;while g>0{v.push(Op::Dif(g));g/=2;}v.push(Op::Weight);g=1;while g<n{v.push(Op::Dit(g));g*=2;}v}
pub fn rev(i:usize,n:usize)->usize {i.reverse_bits()>>(usize::BITS-n.trailing_zeros())}
pub fn butterflies(n:usize,g:usize)->impl Iterator<Item=(usize,usize,usize)> {(0..n/(2*g)).flat_map(move|b|(0..g).map(move|j|(b*2*g+j,b*2*g+j+g,j)))}
pub struct Trace {pub n:usize,pub ops:Vec<Op>,pub possible:Vec<Vec<bool>>,pub demand:Vec<Vec<bool>>,pub roots:Vec<Vec<bool>>,pub weights:Vec<bool>}
impl Trace {
 pub fn new(input:&[bool],want:&[bool])->Self{
    let n=input.len();assert_eq!(want.len(),n);let ops=ops(n);let mut possible=vec![input.to_vec()];
    for &op in &ops {let p=possible.last().unwrap();let mut q=vec![false;n];match op {
        Op::Dif(g)|Op::Dit(g)=>for(lo,hi,_)in butterflies(n,g){q[lo]=p[lo]||p[hi];q[hi]=q[lo];},
        Op::Weight=>for i in 0..n{q[i]=p[i]&&rev(i,n)!=0;}}
        possible.push(q);
    }
    let mut demand=vec![vec![false;n];ops.len()+1];let end=ops.len();for i in 0..n {demand[end][i]=want[i]&&possible[end][i];}
    let mut roots=vec![vec![false;n/2];ops.len()];let mut weights=vec![false;n];
    for s in (0..ops.len()).rev(){let mut prev=vec![false;n];let d=&demand[s+1];let p=&possible[s];match ops[s]{
        Op::Dif(g)=>for(k,(lo,hi,j))in butterflies(n,g).enumerate(){let any=d[lo]||d[hi];prev[lo]=any&&p[lo];prev[hi]=any&&p[hi];roots[s][k]=j!=0&&d[hi]&&(p[lo]||p[hi]);},
        Op::Dit(g)=>for(k,(lo,hi,j))in butterflies(n,g).enumerate(){let any=d[lo]||d[hi];prev[lo]=any&&p[lo];prev[hi]=any&&p[hi];roots[s][k]=j!=0&&any&&p[hi];},
        Op::Weight=>for i in 0..n{prev[i]=d[i]&&p[i]&&rev(i,n)!=0;weights[i]=prev[i]&&rev(i,n)>1;}}
        demand[s]=prev;
    }
    Self{n,ops,possible,demand,roots,weights}
 }
 pub fn root_count(&self)->usize {self.roots.iter().flatten().filter(|&&x|x).count()}
}
pub fn paired(a:&Trace,b:&Trace)->(usize,usize){assert_eq!(a.n,b.n);let mut sites=0;let mut groups=0;for(x,y)in a.roots.iter().zip(&b.roots){let union:Vec<_>=x.iter().zip(y).map(|(&x,&y)|x||y).collect();sites+=union.iter().filter(|&&x|x).count();groups+=union.chunks(4).filter(|g|g.iter().any(|&x|x)).count();}(sites,groups)}
