#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
test ! -e host-run
jq -e '.verified_remote_digest' retrieved.json >/dev/null
jq -e '.passed and .unique==64445 and (.rows|length)==24' remote/output/summary.json >/dev/null
./reader "$PWD/bundle" "$PWD/remote/output" finish host-summary.json host-ledger.json
cmp host-summary.json remote/output/summary.json
cmp host-ledger.json remote/output/proof-sha256.json
proofroot="$PWD/remote/output/proofs"
image="$PWD/bundle/images/transfer_confidential_1_2.image"
sha=$(sha256sum "$image" | cut -c1-64)
jq -e --arg h "$sha" '.image_sha256==$h' bundle/config/case.json >/dev/null
find "$proofroot" -type f \( -name '0.proof' -o -name '0.public' \) | sort | xargs sha256sum > host-pins.sha
sha256sum "$image" "$PWD/bundle/bin/verify" >> host-pins.sha
jq -Rn '[inputs|capture("^(?<hash>[a-f0-9]+)  (?<path>.+)$")|{key:.path,value:.hash}]|from_entries' < host-pins.sha > host-pins.json
jq --arg d "$PWD" --arg i "$image" --arg h "$sha" --arg p "$(jq -r .public_sha256 bundle/config/case.json)" '{version:1,source_pins:($d+"/host-pins.json"),steps:map(. as $j|(.proof|sub("/var/tmp/c7a-phase251/output";$d+"/remote/output")) as $pd|{kind:"command",name:("verify-"+.name),argv:[($d+"/bundle/bin/verify"),$i,$h,($pd+"/0.proof"),($pd+"/0.public"),$p],timeout_seconds:90})}' bundle/config/jobs.json > host-plan.json
/home/ubuntu/src/zk-tools/zopro/xtask/target/release/xtask workflow host-plan.json host-run > host.log
jq -e '.status=="complete" and (.steps|length)==24' host-run/result.json >/dev/null
for j in $(jq -r '.[].name' bundle/config/jobs.json); do
 h=$(jq -r --arg j "$j" '.rows[]|select(.job.name==$j)|.proof_sha256' host-summary.json)
 grep -Fq "VERIFIED proof_sha256=$h " "host-run/verify-$j/stdout.log"
done
sha256sum host-ledger.json
