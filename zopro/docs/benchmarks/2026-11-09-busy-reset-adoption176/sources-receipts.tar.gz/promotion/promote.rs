use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/busy-reset-adoption176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";const N:&str="/home/ubuntu/src/zopro-perf-work/busy-reset176";const Q:&str="/home/ubuntu/src/zopro-perf-work/busy-reset-compat176";const S:&str="/home/ubuntu/src/zopro-perf-work/busy-reset-sdk176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert!(!Path::new(R).join("promotion.json").exists());assert_eq!(read(format!("{Q}/review-result.json"))["passed"],true);assert_eq!(read(format!("{Q}/analysis.json"))["canonical_count"],41792);assert_eq!(read(format!("{S}/review-result.json"))["gate_passed"],true);
 let status=Command::new("git").args(["status","--porcelain","--untracked-files=no"]).current_dir("/home/ubuntu/src/zk-tools").output().unwrap();assert!(status.status.success());assert!(status.stdout.is_empty());
 let prior=format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");let old=read(&prior);let originals=old["source_files_sha256"].as_object().unwrap();assert_eq!(originals.len(),176);for(rel,h)in originals{assert_eq!(hash(format!("{Z}/{rel}")),h.as_str().unwrap());}
 let mut changed=Vec::new();for rel in["crates/zopro-core/src/msm_affine/borrowed_pending.rs","crates/zopro-core/src/msm_affine/g2_borrowed.rs"]{
  let to=format!("{Z}/{rel}");let from=format!("{N}/source/{rel}");let backup=format!("{R}/before/{rel}");fs::create_dir_all(Path::new(&backup).parent().unwrap()).unwrap();fs::copy(&to,&backup).unwrap();assert_eq!(hash(&from),hash(format!("{S}/source/{rel}")));fs::copy(&from,&to).unwrap();changed.push(json!({"path":rel,"before_sha256":hash(backup),"after_sha256":hash(&to),"byte_exact_to_measured_native_source":true,"measured_source":from}));
 }
 let rel="crates/zopro-core/build.rs";let path=format!("{Z}/{rel}");let before=fs::read_to_string(&path).unwrap();let insertion=r#"    // Select the measured borrowed-window metadata path on native IFMA builds.
    println!("cargo::rustc-check-cfg=cfg(zopro_dense_busy_reset)");
    let arch = std::env::var("CARGO_CFG_TARGET_ARCH").unwrap_or_default();
    let features = std::env::var("CARGO_CFG_TARGET_FEATURE").unwrap_or_default();
    let ifma8 = std::env::var_os("CARGO_FEATURE_IFMA8").is_some();
    let disabled = std::env::var_os("CARGO_CFG_NO_IFMA").is_some();
    if arch == "x86_64"
        && ifma8
        && !disabled
        && ["avx512ifma", "avx512vl", "avx512dq"]
            .iter()
            .all(|needed| features.split(',').any(|feature| feature == *needed))
    {
        println!("cargo::rustc-cfg=zopro_dense_busy_reset");
    }
"#;assert_eq!(before.matches("fn main() {\n").count(),1);let after=before.replacen("fn main() {\n",&format!("fn main() {{\n{insertion}"),1);let backup=format!("{R}/before/{rel}");fs::create_dir_all(Path::new(&backup).parent().unwrap()).unwrap();fs::write(&backup,&before).unwrap();fs::write(&path,&after).unwrap();changed.push(json!({"path":rel,"before_sha256":hash(backup),"after_sha256":hash(&path),"only_build_selection_changed":true,"insertion":insertion}));
 let out=json!({"promoted_source_changes":changed,"old_manifest":prior,"old_manifest_sha256":hash(&prior),"runtime_files_exact_to_measured_native_snapshot":true,"build_script_emits_existing_measured_native_cfg":true,"originals":originals,"new_source_file_count":176,"native_performance_report":format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-sdk176/README.md"),"qualification_review":format!("{Q}/review-result.json"),"canonical_proofs":41792,"no_new_proofs_during_promotion":true,"adoption_build_selection_checks_pending":true,"goal_complete":false});fs::write(format!("{R}/promotion.json"),serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("Promoted exact2runtime/testfiles+nativebuildselector;176files;buildselectionvalidationpending;no runtime body rewrite");
}
