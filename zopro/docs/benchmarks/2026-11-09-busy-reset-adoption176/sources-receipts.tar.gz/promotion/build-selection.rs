use serde_json::{json,Value};use std::{fs,process::Command};const R:&str="/home/ubuntu/src/zopro-perf-work/busy-reset-adoption176";
fn main(){let script=format!("{R}/build-script");let full="avx512dq,avx512ifma,avx512vl,sse2";let mut rows=Vec::new();
 for(name,arch,features,feature,no_ifma,os,metal,wgpu,want)in[
 ("native-ifma","x86_64",full,true,false,"linux",false,false,true),
 ("missing-ifma","x86_64","avx512dq,avx512vl",true,false,"linux",false,false,false),
 ("missing-vl","x86_64","avx512dq,avx512ifma",true,false,"linux",false,false,false),
 ("missing-dq","x86_64","avx512ifma,avx512vl",true,false,"linux",false,false,false),
 ("feature-disabled","x86_64",full,false,false,"linux",false,false,false),
 ("explicit-no-ifma","x86_64",full,true,true,"linux",false,false,false),
 ("arm","aarch64",full,true,false,"ios",false,false,false),
 ("wasm","wasm32",full,true,false,"unknown",false,false,false),
 ("native-metal-fallback","x86_64",full,true,false,"macos",true,false,true),
 ("native-wgpu-fallback","x86_64",full,true,false,"linux",false,true,true)
 ] {let mut cmd=Command::new(&script);for k in["CARGO_FEATURE_IFMA8","CARGO_CFG_NO_IFMA","CARGO_FEATURE_METAL","CARGO_FEATURE_WGPU"]{cmd.env_remove(k);}cmd.env("CARGO_CFG_TARGET_ARCH",arch).env("CARGO_CFG_TARGET_FEATURE",features).env("CARGO_CFG_TARGET_OS",os);if feature{cmd.env("CARGO_FEATURE_IFMA8","1");}if no_ifma{cmd.env("CARGO_CFG_NO_IFMA","");}if metal{cmd.env("CARGO_FEATURE_METAL","1");}if wgpu{cmd.env("CARGO_FEATURE_WGPU","1");}let out=cmd.output().unwrap();assert!(out.status.success());let stdout=String::from_utf8(out.stdout).unwrap();assert!(stdout.contains("cargo::rustc-check-cfg=cfg(zopro_dense_busy_reset)"));let selected=stdout.lines().any(|l|l=="cargo::rustc-cfg=zopro_dense_busy_reset");assert_eq!(selected,want,"{name}");assert_eq!(stdout.lines().any(|l|l=="cargo::rustc-cfg=gpu"),metal&&(os=="macos"||os=="ios"));assert_eq!(stdout.lines().any(|l|l=="cargo::rustc-cfg=gpu_wgpu"),wgpu&&!metal);rows.push(json!({"name":name,"target_arch":arch,"selected":selected,"expected":want,"stdout":stdout}));}
 let result=json!({"passed":true,"cases":10,"rows":rows,"GPU_selection_preserved":true,"no_runtime_proof_calls":true});fs::write(format!("{R}/build-selection.json"),serde_json::to_vec_pretty(&result).unwrap()).unwrap();println!("BUILD_SELECTION_PASS10cases/native-ifma/featureoptout/noifma/ARM/wasm/GPUfallback");}
