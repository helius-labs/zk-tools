//! Balanced radix-6561 digits read from the original signed magnitude.
pub const RADIX: u128 = 6561;
pub const fn power(index: usize) -> u128 {
    let mut value = 1;
    let mut i = 0;
    while i < index { value *= RADIX; i += 1; }
    value
}
#[inline(always)]
fn at<const DIVISOR: u128>(magnitude: u128) -> i16 {
    let quotient = (magnitude + (DIVISOR - 1) / 2) / DIVISOR;
    let residue = quotient % RADIX;
    if residue > RADIX / 2 { (residue as i32 - RADIX as i32) as i16 }
    else { residue as i16 }
}
#[inline]
pub fn digit(component: i128, index: usize) -> i16 {
    debug_assert!(component.unsigned_abs() < 1u128 << 126);
    let m = component.unsigned_abs();
    let d = match index {
        0 => at::<{ power(0) }>(m),
        1 => at::<{ power(1) }>(m),
        2 => at::<{ power(2) }>(m),
        3 => at::<{ power(3) }>(m),
        4 => at::<{ power(4) }>(m),
        5 => at::<{ power(5) }>(m),
        6 => at::<{ power(6) }>(m),
        7 => at::<{ power(7) }>(m),
        8 => at::<{ power(8) }>(m),
        9 => at::<{ power(9) }>(m),
        10 => at::<{ power(10) }>(m),
        _ => panic!("ternary window exceeds the supported component length"),
    };
    if component < 0 { -d } else { d }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn check(x: i128) {
        let mut remaining=x;
        let mut expected=[0i16;11];
        for block in &mut expected {
            let mut weight=1;
            let mut value=0;
            for _ in 0..8 {
                let residue=remaining.rem_euclid(3);
                let trit=if residue==2{-1}else{residue};
                remaining=(remaining-trit)/3;
                value+=trit*weight;
                weight*=3;
            }
            *block=value as i16;
        }
        assert_eq!(remaining,0);
        let mut restored=0i128;
        for index in (0..11).rev() {
            let d=digit(x,index);
            assert_eq!(d,expected[index]);
            assert!(d.unsigned_abs()<=if index==10{1}else{3280});
            restored=restored.checked_mul(RADIX as i128).unwrap().checked_add(d as i128).unwrap();
        }
        assert_eq!(restored,x);
    }
    #[test]
    fn random_access_matches_trits_across_carries_and_signs() {
        let mut count=0;
        for x in -65536..=65536 {check(x);count+=1;}
        for j in 0..=10 {
            let p=power(j)as i128;
            for center in [p,p/2] {
                for offset in -3..=3 {
                    for sign in [-1,1] {
                        let x=(center+offset)*sign;
                        if x.unsigned_abs()<1u128<<126 {check(x);count+=1;}
                    }
                }
            }
        }
        for x in [(1i128<<126)-1,-((1i128<<126)-1)] {check(x);count+=1;}
        let mut state=0xbc7991d258a13u128;
        for _ in 0..8192 {
            state=state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            let m=(state&((1u128<<126)-1))as i128;
            check(if state>>127!=0{-m}else{m});count+=1;
        }
        assert!(std::panic::catch_unwind(||digit(1,11)).is_err());
        println!("RANDOM_ACCESS_CODEC cases={count}; no recoded scalar array or allocation in digit reader");
    }
}
