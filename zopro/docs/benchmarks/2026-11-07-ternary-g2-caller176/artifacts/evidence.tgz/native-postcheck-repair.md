# Required-name metadata repair

The original unfiltered native cargo command exited0 and all128tests passed, with zero failed/ignored/measured/filtered tests. The three new tests appear under their full module paths. The workflow then stopped in its post-command required-name membership check: setup.rs supplied three short suffix names, while xtask compares exact fully qualified names. The native workflow has no result.json; command exit/stdout/stderr and the terminal tool result establish what succeeded and what failed.

Preserve the original source, plan, pins, successful test receipt and failed workflow log. Repair only the metadata validation with an offline helper that hashes every original input and command stream, checks the actual argv/environment and exact full names, and verifies all128passing entries. Do not rerun cargo, successful tests, input generation, proof or timing. Runtime source and test bytes remain unchanged. The offline recovery is a separate pinned one-command workflow; only it writes qualification.json.

The suite contains125original tests plus three new tests. Earlier128test reports from other diagnostic snapshots included their own additions and are not the unchanged production test count. Field/Phi/prover qualification remains inherited; this is the new native core configuration only. No performance capture has run.
