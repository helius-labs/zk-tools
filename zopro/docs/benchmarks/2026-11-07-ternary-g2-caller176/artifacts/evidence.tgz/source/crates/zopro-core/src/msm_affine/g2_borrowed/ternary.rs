//! Fixed signed-ternary diagnostic path using the original borrowed window.
use super::*;
use rayon::prelude::*;
#[path="random_access.rs"]mod codec;

#[inline]
fn digit(s:&[u64;4],high:bool,w:usize)->i16 {
    let i=usize::from(high)*2;
    let magnitude=s[i]as u128|(((s[i+1]&0x7fffffffffffffff)as u128)<<64);
    let value=if s[i+1]>>63!=0{-(magnitude as i128)}else{magnitude as i128};
    codec::digit(value,w)
}
fn feed<'a>(state:&mut Window<'a>,bases:&'a[G2Affine],short:&[[u64;4]],high:bool,w:usize,size:usize){
    for(p,s)in bases.iter().zip(short){
        let d=digit(s,high,w);
        if d==0||p.is_identity(){continue}
        let b=d.unsigned_abs()as usize-1;
        let encoded=b as u32|if d<0{1<<31}else{0};
        if state.busy(b){state.queue.push((encoded,p));if state.queue.len()==size-1{state.flush_queue();}continue}
        state.add(encoded,p);
        if state.batch.len()==size{state.execute();state.take_from_queue();}
    }
    state.execute();state.flush_queue();
}
fn carry_component(bases:&[G2Affine],short:&[[u64;4]],high:bool)->G2Affine{
    let mut counts=[0usize;2];
    for(p,s)in bases.iter().zip(short){let d=digit(s,high,10);debug_assert!(d.unsigned_abs()<=1);if d!=0&&!p.is_identity(){counts[usize::from(d<0)]+=1;}}
    let starts=[0,counts[0],counts[0]+counts[1]];
    let mut positions=[starts[0],starts[1]];
    let mut order=vec![0u32;starts[2]];
    for(i,(p,s))in bases.iter().zip(short).enumerate(){let d=digit(s,high,10);if d!=0&&!p.is_identity(){let j=usize::from(d<0);order[positions[j]]=i as u32;positions[j]+=1;}}
    let sums=crate::msm::group_affine(bases,&order,&starts,&counts);
    let mut positive=vec![sums[0]];
    super::super::merge_buckets(&mut positive,&[-sums[1]]);
    positive[0]
}
fn window(bases:&[G2Affine],short:&[[u64;4]],w:usize)->Vec<G2Affine>{
    if w==10{
        let mut high=carry_component(bases,short,true);
        if !high.is_identity(){high.x=high.x.mul_by_fp(&BETA);}
        let low=carry_component(bases,short,false);
        let mut result=vec![high];super::super::merge_buckets(&mut result,&[low]);return result;
    }
    let size=200;
    let mut state=Window::new(3328,size,BatchAdd::default());
    feed(&mut state,bases,short,true,w,size);
    debug_assert!(state.batch.is_empty()&&state.queue.is_empty());
    for p in &mut state.affine{if !p.is_identity(){p.x=p.x.mul_by_fp(&BETA);}}
    for p in &mut state.projective{p.x=p.x.mul_by_fp(&BETA);}
    feed(&mut state,bases,short,false,w,size);
    let buckets=state.finish();
    debug_assert!(buckets[3280..].iter().all(|p|p.is_identity()));
    buckets
}
pub(super) fn raw(bases:&[G2Affine],words:&mut[[u64;4]])->G2Projective{
    assert_eq!(bases.len(),words.len());
    if !BatchAdd::<G2Config>::default().borrowed_g2_enabled(){return super::super::g2_phi::raw_exclusive(bases,words)}
    words.par_iter_mut().for_each(|s|*s=super::super::g2_phi::phi_split(*s));
    let chunk=bases.len().div_ceil(2);
    let sums=(0..11usize).into_par_iter().map(|w|{
        let mut parts=(0..2usize).into_par_iter().map(|part|{let first=(part*chunk).min(bases.len());let last=(first+chunk).min(bases.len());window(&bases[first..last],&words[first..last],w)}).collect::<Vec<_>>();
        let mut buckets=parts.swap_remove(0);super::super::merge_buckets(&mut buckets,&parts[0]);crate::msm::weighted_affine(&buckets)
    }).collect::<Vec<_>>();
    let mut result=G2Projective::IDENTITY;
    for sum in sums.iter().rev(){for _ in 0..8{result=result.double()+result;}result+=*sum;}
    result
}
#[cfg(test)]mod tests{
    use super::*;use zopro_bn254::Fr;
    fn random(seed:&mut u64)->Fr{let mut bytes=[0u8;32];for b in bytes.chunks_mut(8){*seed^=*seed<<13;*seed^=*seed>>7;*seed^=*seed<<17;b.copy_from_slice(&seed.to_le_bytes());}Fr::from_le_bytes_mod_order(&bytes)}
    #[test]fn complete_query_generator_oracle_threads_grouping_and_exceptions(){
        for workers in [1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||{
            for (n,pattern)in [(0usize,0),(7,1),(1024,0),(1025,1),(2049,2)]{
                let mut seed=0x68ae24579bd1u64;let mut scalars=Vec::new();let mut coeffs=Vec::new();let mut expected=Fr::ZERO;
                for i in 0..n{let c=if pattern==1{match i%7{0=>Fr::ZERO,1..=3=>Fr::ONE,4=>-Fr::ONE,_=>Fr::from(i as u64+19)}}else{Fr::from(i as u64+17)};let s=if pattern==2{match i%5{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,_=>Fr::from((i%257+3)as u64)}}else{random(&mut seed)};expected+=c*s;coeffs.push(c);scalars.push(s);}
                let g=G2Projective::generator();let bases=G2Projective::batch_to_affine(&coeffs.iter().map(|c|g**c).collect::<Vec<_>>());let original=bases.clone();let mut words=scalars.iter().map(|s|s.to_canonical()).collect::<Vec<_>>();let got=crate::msm_affine::ternary_g2_query(&bases,&mut words);assert_eq!(got.to_affine(),(g*expected).to_affine(),"workers{workers}/n{n}/pattern{pattern}");assert_eq!(bases,original);
            }
        });}
    }
    #[test]fn carry_boundary_windows_match_independent_signed_generator_sum(){
        let g=G2Projective::generator();let half=(codec::power(10)/2)as i128;let lambda=Fr::from_decimal("4407920970296243842393367215006156084916469457145843978461");
        for w in [0usize,1,9,10]{let mut values=vec![];let mut points=vec![];let mut expected=Fr::ZERO;for i in 0..208usize{let c=if i%13==0{Fr::ZERO}else if i%7==0{-Fr::ONE}else{Fr::from((i%31+1)as u64)};let low=if i%2==0{half+i as i128-104}else{-half+i as i128-104};let high=if i%3==0{(1i128<<126)-1}else{-low};let encode=|x:i128|{let mut v=x.unsigned_abs();if x<0{v|=1u128<<127;}[v as u64,(v>>64)as u64]};let a=encode(low);let b=encode(high);let s=[a[0],a[1],b[0],b[1]];let signed=|d:i16|{let v=Fr::from(d.unsigned_abs()as u64);if d<0{-v}else{v}};expected+=c*(signed(digit(&s,false,w))+lambda*signed(digit(&s,true,w)));values.push(s);points.push(g*c);}
            let bases=G2Projective::batch_to_affine(&points);let buckets=window(&bases,&values,w);let got=crate::msm::weighted_affine(&buckets);assert_eq!(got.to_affine(),(g*expected).to_affine(),"window{w}");
        }
    }
}
