use std::{fs,path::Path};
fn main(){let r="/home/ubuntu/src/zopro-perf-work/fft-column-prep-sdk176";assert!(!Path::new(&format!("{r}/preflight.rs")).exists());let old="/home/ubuntu/src/zopro-perf-work/sign-mask-sdk176";let mut s=fs::read_to_string(format!("{old}/preflight.rs")).unwrap().replace(old,r);for(a,b)in[
("/home/ubuntu/src/zopro-perf-work/inverse-seed-sdk176/pilot/proof-sha256-after-diagnostic.json","/home/ubuntu/src/zopro-perf-work/sign-mask-allshape176/proof-sha256-after-diagnostic.json"),
("32857","33449"),("32879","33471"),
("result[\"steps\"].as_array().unwrap().len(),2","result[\"steps\"].as_array().unwrap().len(),3"),
("assert_eq!(read(format!(\"{R}/inherited-portable.json\"))[\"passed\"],true);","assert_eq!(read(format!(\"{R}/native/whole-prover-portable-check/exit.json\"))[\"success\"],true);"),
("Exact bothcurve descriptor-mask helper, no field or inverse changes","Exact qualified ephemeral FFT gap-one factor preparation in both directions and layouts; other64 products ordinary"),
("\"portable_fallback_inherited\":true,\"new_portable_compile\":false","\"portable_fallback_inherited\":false,\"new_portable_compile\":true"),
("format!(\"{R}/make-preflight.rs\"),format!(\"{R}/preflight-head.rs\")","format!(\"{R}/make-preflight.rs\")")]{assert!(s.contains(a),"missing {a}");s=s.replace(a,b);}fs::write(format!("{r}/preflight.rs"),s).unwrap();println!("Prepared new SDK integration/fresh proof reader, original proof-binding utilities reused without replay");}
