use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,os::unix::fs::{MetadataExt,PermissionsExt},process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/finite-all193";
const C:&str="/home/ubuntu/src/zopro-perf-work/finite-sdk191";
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(n:&str,v:Value){let p=format!("{R}/{n}");assert!(!Path::new(&p).exists());fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn one(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1);}
fn main(){
let mut ids=json!({});for(arm,family)in[("REF","ref"),("ON","diag")]{let copies=(0..3).map(|i|{let p=format!("{C}/bins/{family}{i}");let m=fs::metadata(&p).unwrap();json!({"path":p,"sha256":hash(&p),"device":m.dev(),"inode":m.ino(),"mode":m.permissions().mode()})}).collect::<Vec<_>>();ids[arm]=json!({"sha256":copies[0]["sha256"],"copies":copies});}save("consumer-input.json",ids);
let old="/home/ubuntu/src/zopro-perf-work/fused-preparation-all182";
for name in["screen.rs","independent.rs"]{
let mut s=fs::read_to_string(format!("{old}/{name}")).unwrap().replace(old,R)
.replace("/home/ubuntu/src/zopro-perf-work/fused-preparation-profile182/proof-sha256-after-profile.json","/home/ubuntu/src/zopro-perf-work/finite-profile192/proof-sha256-after-profile.json")
.replace("dce77ba26e6b6635bfcdfaa65b98af87dc9f493c6f884544ecfdde48ad4bcec4","ad8832cbd7619e0ccd682da64e348fda1b1e849fdaed370382ff78d112384d69")
.replace("55879","56686").replace("55902","56709").replace("56502","57309");
if name=="screen.rs"{
one(&mut s,"assert_eq!(ids[\"REF\"][\"sha256\"], \"b646c7b8c1d8a26a0db45fb3f67c453dd616bd9f02e25c36192721ae02855abe\");","assert_eq!(ids[\"REF\"][\"sha256\"], \"c285cbc88f783abac203c66db43ea86bda8207338b9fb209df7eb5d846126202\");");
one(&mut s,"assert_eq!(ids[\"ON\"][\"sha256\"], \"c285cbc88f783abac203c66db43ea86bda8207338b9fb209df7eb5d846126202\");","assert_eq!(ids[\"ON\"][\"sha256\"], \"b655c4c68483d54e2343a0593818b49be05e140c949fe83cd6216d332ecb1897\");");
s=s.replace("/home/ubuntu/src/zopro-perf-work/fused-preparation182/{file}",&format!("{C}/{{file}}"));
one(&mut s,"env[\"ZOPRO_BENCH_FUSED_PREPARATION\"]=json!(if arm==\"ON\"{\"1\"}else{\"0\"});","env[\"ZOPRO_BENCH_FUSED_PREPARATION\"]=json!(\"1\");env[\"ZOPRO_BENCH_FINITE_G2\"]=json!(if arm==\"ON\"{\"1\"}else{\"0\"});");
one(&mut s,"        assert_eq!(sum[\"placement_before\"], sum[\"placement_after\"]);",r##"        if j["arm"]=="ON" {let known=sum["finite_known_entries"].as_u64().unwrap();let raw=sum["finite_raw_entries"].as_u64().unwrap();let grouped=sum["finite_grouped_entries"].as_u64().unwrap();assert!(known==0||known==rounds);assert_eq!(raw+grouped,known);if ["1x2","2x2"].iter().any(|s|j["case"]["shape"]==*s){assert_eq!(known,rounds);}if j["case"]["shape"]=="1x2"{assert_eq!(raw,rounds);assert_eq!(grouped,0);}}
        assert_eq!(sum["placement_before"], sum["placement_after"]);"##);
s=s.replace("context == \"1x2-w32\" && metric","context == \"1x2-w16\" && metric").replace("r[\"context\"]==\"1x2-w32\"","r[\"context\"]==\"1x2-w16\"").replace("\"context\":\"1x2-w32\",\"comparator\":\"REF\",\"metric\":\"backing_median\"","\"context\":\"1x2-w16\",\"comparator\":\"REF\",\"metric\":\"backing_median\"").replace("if context==\"1x2-w32\"","if context==\"1x2-w16\"");
}else{
one(&mut s,"assert_eq!(j[\"environment\"][\"ZOPRO_BENCH_FUSED_PREPARATION\"],if arm==\"ON\"{\"1\"}else{\"0\"});","assert_eq!(j[\"environment\"][\"ZOPRO_BENCH_FUSED_PREPARATION\"],\"1\");assert_eq!(j[\"environment\"][\"ZOPRO_BENCH_FINITE_G2\"],if arm==\"ON\"{\"1\"}else{\"0\"});");
s=s.replace("ctx==\"1x2-w32\"&&metric","ctx==\"1x2-w16\"&&metric");
}fs::write(format!("{R}/{name}"),s).unwrap();}
let mut files=json!({});let prefix=format!("{C}/source/");for(p,h)in read(format!("{C}/source/.xtask/source-pins.json")).as_object().unwrap(){files[p.strip_prefix(&prefix).unwrap()]=h.clone();}save("qualification-manifest.json",json!({"source_files_sha256":files}));
let rel="crates/zopro-core/src/msm_affine/server_shifted.rs";let mut child=fs::read_to_string(format!("{C}/source/{rel}")).unwrap();let last=child.rfind('}').unwrap();child.insert_str(last,r##"
#[cfg(all(target_arch="x86_64",target_os="linux",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",feature="ifma8",not(no_ifma)))]
#[test]fn finite_concurrent_shared_certificate_small_worker_stacks(){
 let(points,words,expected)=fixture("1x2");let certificate=super::super::FiniteG2::new(&points).unwrap();let before=crate::finite_probe::snapshot();
 for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();let barrier=std::sync::Barrier::new(4);
 std::thread::scope(|scope|{for _ in 0..4{let(pool,certificate,words,expected,barrier)=(&pool,&certificate,&words,&expected,&barrier);scope.spawn(move||{barrier.wait();for _ in 0..2{let result=pool.install(||certificate.query(&mut words.clone()));assert_eq!(&coords(result),expected);}});}});}
 let after=crate::finite_probe::snapshot();assert_eq!(after.0-before.0,0);assert_eq!(after.1-before.1,32);assert_eq!(after.2-before.2,0);
}
"##);let ov=format!("{R}/qualification-overlay/{rel}");fs::create_dir_all(Path::new(&ov).parent().unwrap()).unwrap();fs::write(&ov,child).unwrap();
assert!(Command::new("/home/ubuntu/src/zk-tools/zopro/xtask/target/release/xtask").args(["prepare",&format!("{R}/qualification-manifest.json"),&format!("{C}/source"),&format!("{R}/qualification-source"),&format!("{R}/qualification-overlay")]).status().unwrap().success());
let mut portable=read(format!("{old}/release-plan.json"))["steps"][2].clone();for a in portable["argv"].as_array_mut().unwrap(){if let Some(s)=a.as_str(){*a=json!(s.replace("/home/ubuntu/src/zopro-perf-work/fused-preparation182/source",&format!("{R}/qualification-source")));}}portable["environment"]["CARGO_TARGET_DIR"]=json!(format!("{R}/target-portable"));portable["environment"]["CARGO_BUILD_JOBS"]=json!("8");portable["environment"]["ZOPRO_BENCH_FINITE_G2"]=json!("1");
let mut native=read(format!("{C}/build-plan.json"))["steps"][0].clone();let mut env=read(format!("{C}/build-plan.json"))["environment"].clone();env["CARGO_TARGET_DIR"]=json!(format!("{R}/target-native"));env["ZOPRO_BENCH_FUSED_PREPARATION"]=json!("1");env["ZOPRO_BENCH_FINITE_G2"]=json!("1");native["environment"]=env;native["name"]=json!("native-concurrent");native["argv"][0]=json!("/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/cargo");native["argv"][6]=json!(format!("{R}/qualification-source/Cargo.toml"));native["argv"].as_array_mut().unwrap().insert(12,json!("finite_concurrent_shared_certificate_small_worker_stacks"));native["required_tests"]=json!(["msm_affine::server_shifted::tests::finite_concurrent_shared_certificate_small_worker_stacks"]);native["unfiltered"]=json!(false);
// argv manifest replacement and filter must match the inherited cargo test layout.
assert!(native["argv"].as_array().unwrap().iter().any(|v|v==&json!(format!("{R}/qualification-source/Cargo.toml"))));
let mut pins=read(format!("{R}/qualification-source/.xtask/source-pins.json"));for n in["adapt.rs","protocol.md","qualification-manifest.json"]{let p=format!("{R}/{n}");pins[&p]=json!(hash(&p));}save("release-pins.json",pins);save("release-plan.json",json!({"version":1,"source_pins":format!("{R}/release-pins.json"),"steps":[native,portable]}));
}
