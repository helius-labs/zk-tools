# Finite immutable G2 certificate: exact SDK qualification

Candidate b655c4c68483d54e2343a0593818b49be05e140c949fe83cd6216d332ecb1897
versus accepted c285cbc88f783abac203c66db43ea86bda8207338b9fb209df7eb5d846126202.
Reuse finite-sdk191's three REF and three candidate backings without rebuilding.
Both arms enable fused preparation and indexed batching; only ON enables finite
certification. Previous same-binary OFF/ON screen and exact-build profile retain
mechanism evidence. REF is the adoption comparator. No minimum gain floor.

Full fresh-request SDK boundary including witness, randomness, proving, SDK
verification and serialization; loading, three primes and export excluded.
Ten contexts: eight supplied shapes and merge54 at32 workers, primary also16.
23 preflights: REF/ON each context and ON preparation-denied primary16,2x2/32,
merge54/32, one timed plus three primes. Review before main. Main30 pairs per
context,17timed plus3primes:600processes,12000calls,10200timed samples. Rotate
contexts, reverse odd blocks, alternate arms every3blocks, backing=block%3.
Run all captures before Gnark verifiers per phase. During capture only poll
confirmed live handle; no owned analysis, hashing or builds overlap.

Prospective primary16: paired latency upper<1 and all three backing medians<1.
Other9 latency uppers<=1.02; all10 CPU uppers<=1.02; each maximum RSS no greater
than REF*1.05+1MiB.33checks. Unit paired process means; sorted30ratio ranks10/21
one-based,95.7226% nominal marginal median coverage, exchangeable independent
blocks assumed, no joint guarantee. No extension, dropped results or rescue
replay. Backing spread diagnostic only. Report all8 CPU/Metal and merge54 apart.

Seed56686 ad8832cbd7619e0ccd682da64e348fda1b1e849fdaed370382ff78d112384d69
at finite-profile192/proof-sha256-after-profile.json. Preflight56709,main57309.
All623exports independently verified by Gnark with input/hash/freshness binding;
SDK verifies all12092calls. ON primary finite known/raw=rounds,grouped0; ON2x2
known=rounds with raw+grouped=rounds (grouping may be denied). Larger shapes
record actual eligibility; finite counters must be either zero or full rounds,
never partially observed. REF has no finite counters. Retain indexed admission
observers. Denial tests configured scratch denial, not physical OOM.

Before capture, portable no-IFMA/no-ASM unfiltered core suite and native concurrent
finite oracle run in a separate source snapshot with only an appended test.
SDK191 source/artifact unchanged. Concurrent test: 1/4/16/32 workers,512KiB worker
stacks, four simultaneous OS callers share immutable checked certificate, each
two private scalar requests;32results match retained independent Arkworks hash.
Native route counter confirms32 raw finite calls. No new exports from tests.
Existing native135test pass retained. New runtime memory is one Boolean per Key
and three process-global counters, no lookup table or extra mutable shared pool.
Large keys skip scan. Existing field, resource and solver checks inherited.
No physical ARM/mobile, large forester or physical memory pressure claim.

If all declared checks pass, apply exact tested runtime source with opt-in flag
retained. Default/selector cleanup is separate artifact. Commit locally; no new
push authorization. AWS evidence unchanged. Full10xgoal remains unmet.
