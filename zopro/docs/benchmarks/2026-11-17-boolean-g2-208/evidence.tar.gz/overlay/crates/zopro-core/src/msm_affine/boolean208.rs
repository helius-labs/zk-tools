// Test-only complete-query experiment. Static positions come from HintBits,
// but every value and index is guarded before any input word is changed.
use super::*;
use zopro_bn254::{G2Affine,G2Projective};
use std::sync::atomic::{AtomicUsize,Ordering};
static ROUTES:[AtomicUsize;4]=[const{AtomicUsize::new(0)};4];

fn peel(bases:&[G2Affine],words:&mut[[u64;4]],positions:&[u32])->Option<Vec<u32>>{
    if bases.len()!=words.len()||positions.is_empty()
        ||positions.windows(2).any(|p|p[0]>=p[1])
        ||positions.iter().any(|&i|i as usize>=words.len()
           ||words[i as usize]!=[0;4]&&words[i as usize]!=[1,0,0,0]) {return None;}
    let selected=positions.iter().copied().filter(|&i|words[i as usize]==[1,0,0,0]).collect::<Vec<_>>();
    for&i in positions {words[i as usize]=[0;4];}
    Some(selected)
}

fn boolean_sum(bases:&[G2Affine],selected:&[u32])->G2Projective{
    if selected.is_empty(){G2Projective::IDENTITY}else{
        let starts=[0,selected.len()];
        crate::msm::reduce_indexed_buckets(bases,selected,&starts)[0].to_projective()
    }
}
pub(super) fn query(
    bases: &[zopro_bn254::G2Affine],
    words: &mut [[u64; 4]],
    positions: &[u32], on: bool,
) -> zopro_bn254::G2Projective {
    assert_eq!(bases.len(), words.len());
    let groups = crate::simd::cpu_option("ZOPRO_CPU_DEDUP")
        .then(|| scalar_groups(words))
        .flatten();
    if on && groups.is_none() && (1024..65536).contains(&bases.len()) {
        if let Some(selected)=peel(bases,words,positions) {
            ROUTES[1].fetch_add(1,Ordering::Relaxed);
            let(a,b)=rayon::join(||g2_phi::raw_exclusive(bases,words),||boolean_sum(bases,&selected));
            return a+b;
        }
        ROUTES[3].fetch_add(1,Ordering::Relaxed);
    } else {ROUTES[if on{2}else{0}].fetch_add(1,Ordering::Relaxed);}
    #[cfg(all(
        zopro_g2_horner_buckets,
        target_arch = "x86_64",
        target_feature = "avx512ifma",
        target_feature = "avx512vl",
        target_feature = "avx512dq",
        feature = "ifma8",
        not(no_ifma)
    ))]
    if (1024..65536).contains(&bases.len()) {
        if let Some(mut g) = groups {
            if !(1024..65536).contains(&g.values.len()) {
                return crate::msm_grouped_b2(bases, &g);
            }
            let points = crate::msm::group_affine(bases, &g.order, &g.starts, &g.counts);
            return g2_phi::raw_exclusive(&points, &mut g.values);
        }
        return g2_phi::raw_exclusive(bases, words);
    }
    match groups {
        Some(g) => crate::msm_grouped_b2(bases, &g),
        None => crate::msm_raw_b2(bases, words),
    }
}#[cfg(test)]mod tests{
 use super::*;use zopro_bn254::{Fq,Fq2,Fr};use sha2::{Sha256,Digest};use std::{fs,time::Instant};
 fn positions(name:&str)->Vec<u32>{let b=fs::read(format!("/home/ubuntu/src/zopro-perf-work/boolean-g2-208/{name}.positions")).unwrap();let sha=match name{"1x2"=>"73fbf326bb45062ba8990b12058e1b2ed5dc4761bbf7055005bf411388cda303","2x2"=>"efc9fb8919dee9135d4154cb12f90c4f24c7319f8e4b5a78134197ffebc10636",_=>panic!()};assert_eq!(format!("{:x}",Sha256::digest(&b)),sha);b.chunks_exact(4).map(|v|u32::from_le_bytes(v.try_into().unwrap())).collect()}
 fn fixture(name:&str)->(Vec<G2Affine>,Vec<[u64;4]>,String){
  let b=fs::read(format!("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/inputs/{name}.b2q")).unwrap();let(sha,out)=match name{"1x2"=>("421d6ba37e8b3a6f5feb23829c174d11bc034cb9bd8874adf672d65038fb0ad0","8ff656ce44bbebe641139dbc019ae10fc8b3146db4e3af5ad45a0ed3832d4dd7"),"2x2"=>("2b325a5850f1fc9ea21e715e6027f14cc7a29d2c602d0acc683bbfb8377921bc","0fb52c0dece236bf024cfb1afade3d403618730859e99e60bb2bea90b866ecae"),_=>panic!()};assert_eq!(format!("{:x}",Sha256::digest(&b)),sha);assert_eq!(&b[..8],b"B2SCAN01");let n=u64::from_le_bytes(b[8..16].try_into().unwrap())as usize;assert_eq!(b.len(),16+160*n);let p=b[16..16+128*n].chunks_exact(128).map(|b|{let f=b.chunks_exact(32).map(|v|Fq::from_be_bytes(v.try_into().unwrap()).unwrap()).collect::<Vec<_>>();G2Affine::new(Fq2::new(f[1],f[0]),Fq2::new(f[3],f[2]))}).collect();let w=b[16+128*n..].chunks_exact(32).map(|v|std::array::from_fn(|i|u64::from_le_bytes(v[i*8..i*8+8].try_into().unwrap()))).collect();(p,w,out.into())
 }
 fn point_hash(p:&G2Affine)->String{let mut h=Sha256::new();for f in[p.x.c0,p.x.c1,p.y.c0,p.y.c1]{for w in f.to_canonical(){h.update(w.to_le_bytes());}}format!("{:x}",h.finalize())}
 fn array_hash(p:&[G2Affine])->String{let mut h=Sha256::new();for p in p{h.update(point_hash(p).as_bytes());}format!("{:x}",h.finalize())}
 fn pool(workers:usize)->rayon::ThreadPool{rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).start_handler(move|i|unsafe{let mut s:libc::cpu_set_t=std::mem::zeroed();libc::CPU_ZERO(&mut s);libc::CPU_SET(if workers==1{2}else{i},&mut s);assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&s),&s),0);}).build().unwrap()}
 #[test]fn guards_complete_sums_and_query_routes(){
  let g=G2Projective::generator();let coeff=(0..1024).map(|i|if i%16==0{Fr::from([1u64,1,1,0,2,2][i/16%6])*if [1usize,5].contains(&(i/16%6)){-Fr::ONE}else{Fr::ONE}}else{match i%19{0=>Fr::ZERO,1=>-Fr::from((i+22)as u64),_=>Fr::from((i+22)as u64)}}).collect::<Vec<_>>();let points=G2Projective::batch_to_affine(&coeff.iter().map(|&s|g*s).collect::<Vec<_>>());let original=points.clone();let positions=(0..1024).step_by(16).map(|i|i as u32).collect::<Vec<_>>();
  for workers in[1,4,16,32]{let pool=pool(workers);pool.install(||{for mode in[0,1,2]{let words=(0..1024).map(|i|if i%16==0{[u64::from(mode==1||mode==2&&i%3==0),0,0,0]}else{Fr::from((i*739+100003)as u64).to_canonical()}).collect::<Vec<_>>();let expected=(g*coeff.iter().zip(&words).fold(Fr::ZERO,|s,(&c,&w)|s+c*Fr::from_canonical(w).unwrap())).to_affine();for on in[false,true]{assert_eq!(query(&points,&mut words.clone(),&positions,on).to_affine(),expected);}
   let mut bad=words.clone();bad[positions[1]as usize]=[2,0,0,0];let before=bad.clone();assert!(peel(&points,&mut bad,&positions).is_none());assert_eq!(bad,before);
   for invalid in[vec![],vec![3,3],vec![4,3],vec![1024]]{let mut w=words.clone();assert!(peel(&points,&mut w,&invalid).is_none());assert_eq!(w,words);}
  }
  let words=vec![[1,0,0,0];1024];let expected=(g*coeff.iter().copied().fold(Fr::ZERO,|a,b|a+b)).to_affine();assert_eq!(query(&points,&mut words.clone(),&positions,true).to_affine(),expected);
  });}assert_eq!(points,original);
 }
 #[test]fn complete_queries_match_retained_oracles(){for name in["1x2","2x2"]{let(p,w,e)=fixture(name);let before=array_hash(&p);let pos=positions(name);let pool=pool(4);for on in[false,true]{assert_eq!(point_hash(&pool.install(||query(&p,&mut w.clone(),&pos,on).to_affine())),e);}assert_eq!(array_hash(&p),before);}}
 #[test]#[ignore]fn frozen_query_screen(){let workers=std::env::var("CENTRAL_WORKERS").unwrap().parse::<usize>().unwrap();assert!([1,16,32].contains(&workers));let name=std::env::var("CENTRAL_SHAPE").unwrap();let rounds=std::env::var("CENTRAL_ROUNDS").unwrap().parse::<usize>().unwrap();let on=std::env::var("BOOLEAN208_ON").unwrap()=="1";let(p,w,e)=fixture(&name);let before=array_hash(&p);let pos=positions(&name);let pool=pool(workers);let run=||pool.install(||{let mut words=w.clone();query(&p,&mut words,&pos,on).to_affine()});for _ in 0..3{assert_eq!(point_hash(&run()),e);}let usage=||unsafe{let mut u:libc::rusage=std::mem::zeroed();assert_eq!(libc::getrusage(libc::RUSAGE_SELF,&mut u),0);u};let cpu=|u:&libc::rusage|(u.ru_utime.tv_sec+u.ru_stime.tv_sec)*1_000_000+u.ru_utime.tv_usec+u.ru_stime.tv_usec;let a=usage();let mut times=Vec::with_capacity(rounds);for _ in 0..rounds{let start=Instant::now();let out=std::hint::black_box(run());times.push(start.elapsed().as_nanos());assert_eq!(point_hash(&out),e);}let b=usage();assert_eq!(point_hash(&run()),e);assert_eq!(array_hash(&p),before);let route=if !on{0}else if name=="1x2"{1}else{2};for i in 0..4{assert_eq!(ROUTES[i].load(Ordering::Relaxed),if i==route{rounds+4}else{0});}println!("CENTRAL {{\"shape\":\"{name}\",\"workers\":{workers},\"on\":{on},\"rounds\":{rounds},\"cpu_us\":{},\"peak_kib\":{},\"times_ns\":{:?}}}",cpu(&b)-cpu(&a),b.ru_maxrss,times);}
}
