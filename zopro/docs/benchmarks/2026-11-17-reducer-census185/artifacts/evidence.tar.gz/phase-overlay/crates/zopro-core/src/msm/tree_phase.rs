use std::{cell::Cell,sync::atomic::{AtomicBool,Ordering},time::Instant};
static ENABLED:AtomicBool=AtomicBool::new(false);
thread_local!{static VALUES:Cell<[u64;5]>=const{Cell::new([0;5])};}
pub(crate)fn begin()->Option<Instant>{if ENABLED.load(Ordering::Relaxed){VALUES.with(|v|{let mut x=v.get();x[4]+=1;v.set(x);});Some(Instant::now())}else{None}}
pub(crate)fn mark(slot:usize,t:&mut Option<Instant>){if let Some(old)=t{let now=Instant::now();let elapsed=now.duration_since(*old).as_nanos()as u64;VALUES.with(|v|{let mut x=v.get();x[slot]+=elapsed;v.set(x);});*old=now;}}
pub(crate)fn reset(pool:&rayon::ThreadPool,on:bool){ENABLED.store(false,Ordering::Relaxed);pool.broadcast(|_|VALUES.with(|v|v.set([0;5])));ENABLED.store(on,Ordering::Relaxed);}
pub(crate)fn finish(pool:&rayon::ThreadPool)->[u64;5]{ENABLED.store(false,Ordering::Relaxed);let mut total=[0;5];for row in pool.broadcast(|_|VALUES.with(Cell::get)){for i in 0..5{total[i]+=row[i];}}total}
