# Reducer census, not another timing screen

Read exact1x2/2x2capturedB2queries andoraclefixturehashes. Count actualnonzero
Boothdigits andsignedbucketoccupancy,model unchanged1024pointtilepacking,
perbundle treelayers andpartialmergegeometry. Layers/paircounts arestaticbounds,
not exactinversioncalls, CPUtimeorlatency. Equal/opposite/identity pairs canchange
active affine formulas. Wholepointcopies count128bytes natively,FqLimbs wrapsFq;
this is not a radix52expandedtable. Initialdraftassumed160,correctedfromsource
beforepublishing, withoutbenchreplay. Do notinferactualDRAMbytesfrompayloads.

Nativecrosscheck: a newdiagnostictest constructs originalimmutabletables,compares
actualroutedlengths, asserts native pointrepresentation size andoneindexedreducer
entry per complete sharedquery, matches retained fullMSMoracle. Queryscalar_groups
on actualcurrentpolicy andreportresultlen. No performance assertion, observer
qualificationorfullproofclaim. Adds two diagnostic sharedqueries, no newproofs.
No rerunofsuccessfultimingdata; canon56585same; noAWSorproductionchange.
