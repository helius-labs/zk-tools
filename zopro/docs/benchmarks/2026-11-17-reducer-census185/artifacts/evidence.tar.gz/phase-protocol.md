# Coarse tree-reducer attribution

Use native diagnostic build from exact current runtime plus retained184 component,
adding four TLSelapsed counters only in reduce_layer: forwardpairscan/prefix,
chaininversionincludingtailhandling,backwardcoordinates,compaction/exceptionals.
No arithmetic,geometryorinputchange. One extra representation/routing oracle test
before capture; no performance decision from its output.

Captureonlysharedparallel caller for1x2/2x2 at32fixedworkers,oneimmutabletablepercase.
3plainprimes then3pairedplain/observedblocks,reverseoddblock.12timedqueries total,
alloutputscheckedagainstretainedArkworksoracle. Tablecoldsetupoutsidewarmtimers.
TLSreset/collect outsidetiming; toggleenabledatomicwithinsamebinary,noatomics in
worker stageaccumulators. Every observed reduce_layer increments perthread count.
Expected5121+4first/partiallayersfor1x2,10113+5for2x2; finalweightedtreeaddsotherlayers,
soverify/reportactualcounts ratherthanassertstaticcountasmeasuredinversecount.

For eachcase medianpaired observed/plainlatencyratio must lie[1/1.05,1.05] to
useattributionasrepresentativeofthisfreshdiagnosticcaller. This iscoarsecalibration,
notstatisticalequivalence or exactparent/productioncalibration. No drop/extension/
rerunif fails. Report spansasaggregateworkerelapsed,includingpreemption/allocator,
notexclusiveCPUtimeorremovableprooflatency. Shareofinstrumentedtreesonly; route,
initialgathercopy,taskdispatchandothertreesareoutside/thesecounters. NoCPU10xclaim.
NoAWS,SDKproofs,productionchangeorpush. Canon56585unchanged.
