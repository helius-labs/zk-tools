use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/scaled-prefix-current227";
const P:&str="/home/ubuntu/src/zopro-perf-work/certified-proof194";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/uniform-carry-default182";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(n:&str,v:Value){let p=format!("{R}/{n}");assert!(!Path::new(&p).exists());fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn main(){
 let manifest=read("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-17-certified-all196/artifacts/production-source-manifest.json");
 let files=manifest["source_files_sha256"].as_object().unwrap();assert_eq!(files.len(),179);
 let mut pins=BTreeMap::new();
 for(f,h)in files{let p=Path::new(P).join("source-v2").join(f);assert_eq!(hash(&p),h.as_str().unwrap());assert_eq!(hash(Path::new("/home/ubuntu/src/zk-tools/zopro").join(f)),h.as_str().unwrap());let dest=Path::new(R).join("source").join(f);assert!(!dest.exists());fs::create_dir_all(dest.parent().unwrap()).unwrap();fs::copy(&p,&dest).unwrap();pins.insert(p.display().to_string(),hash(&p));}
 let parents=["crates/zopro-bn254/src/ifma.rs","crates/zopro-bn254/src/ifma8.rs","crates/zopro-bn254/src/lib.rs","crates/zopro-core/src/msm.rs","crates/zopro-core/src/msm/g2_borrowed.rs","crates/zopro-core/src/simd.rs","scripts/ifma8.py"];
 let children=["crates/zopro-bn254/src/uniform_prefix.rs","crates/zopro-bn254/src/uniform_prefix_tests.rs","crates/zopro-bn254/src/linear_carry.rs","crates/zopro-bn254/src/linear_carry_tests.rs","crates/zopro-core/src/msm/uniform_prefix.rs","crates/zopro-core/src/msm/linear_carry_caller.rs"];
 let oldpins=read(format!("{OLD}/build-pins.json"));let mut deltas=vec![];
 for f in parents.into_iter().chain(children){let p=format!("{OLD}/source/{f}");assert_eq!(hash(&p),oldpins[&p].as_str().unwrap());let mut s=fs::read_to_string(&p).unwrap();if f=="crates/zopro-core/src/msm.rs"{let current=fs::read_to_string(format!("{P}/source-v2/{f}")).unwrap();let branch="    #[cfg(zopro_indexed_tile_bundles)]\n    if crate::simd::cpu_option(\"ZOPRO_CPU_INDEXED_TILE_BUNDLES\") {\n        if let Some(out)=indexed_tiles::try_reduce::<C>(bases,order,starts){return out;}\n    }\n";assert_eq!(current.matches(branch).count(),1);assert_eq!(s.matches(branch).count(),0);let anchor="    let tile = 2048 / (core::mem::size_of::<C::Base>() / 32);";assert_eq!(s.matches(anchor).count(),1);s=s.replace(anchor,&format!("{branch}{anchor}"));let module="#[cfg(zopro_indexed_tile_bundles)]mod indexed_tiles;\n";assert_eq!(current.matches(module).count(),1);s.push_str(&format!("\n{module}"));}
  let dst=Path::new(R).join("source").join(f);fs::create_dir_all(dst.parent().unwrap()).unwrap();fs::write(&dst,s).unwrap();pins.insert(p.clone(),hash(&p));deltas.push(json!({"file":f,"new":children.contains(&f),"before":files.get(f),"after":hash(&dst),"arithmetic_parent_sha256":hash(&p),"current_dispatch_preserved":f=="crates/zopro-core/src/msm.rs"}));
 }
 for(f,h)in files{let p=Path::new(R).join("source").join(f);if !parents.contains(&f.as_str()){assert_eq!(hash(&p),h.as_str().unwrap());}pins.insert(p.display().to_string(),hash(&p));}
 for f in children{let p=Path::new(R).join("source").join(f);pins.insert(p.display().to_string(),hash(&p));}
 fs::create_dir(format!("{R}/support")).unwrap();for f in["driver.rs","support/perf.rs"]{let p=format!("{P}/{f}");fs::copy(&p,format!("{R}/{f}")).unwrap();pins.insert(p.clone(),hash(&p));pins.insert(format!("{R}/{f}"),hash(format!("{R}/{f}")));}
 save("source-audit.json",json!({"baseline_files":179,"source_files":185,"changed_parents":parents,"added_children":children,"deltas":deltas,"unchanged_accepted_files":172,"old_failed_decisions_preserved":true,"new_allocation_or_table":false,"production_changed":false}));
 let mut plan:Value=serde_json::from_str(&fs::read_to_string(format!("{P}/build-plan-v2.json")).unwrap().replace(P,R).replace("/source-v2/","/source/").replace("/build-run-v2/","/build-run/")).unwrap();
 let mut field=plan["steps"][0].clone();field["name"]=json!("field-tests");for arg in field["argv"].as_array_mut().unwrap(){if *arg=="zopro-core"{*arg=json!("zopro-bn254");}}field["required_tests"]=json!(["uniform_prefix::tests::both_prime_raw_scalar_roots","linear_carry::tests::uncarried_sums_both_fields_and_radices"]);
 // Existing test path is resolved before freezing, not guessed in a required-test gate.
 field.as_object_mut().unwrap().remove("required_tests");
 let mut steps=plan["steps"].as_array().unwrap().clone();steps.insert(0,field);plan["steps"]=json!(steps);plan["source_pins"]=json!(format!("{R}/build-pins.json"));
 for name in["protocol.md","setup.rs","source-audit.json"]{pins.insert(format!("{R}/{name}"),hash(format!("{R}/{name}")));}
 save("build-pins.json",json!(pins));save("build-plan.json",plan);
 println!("New185-file composition,172 accepted unchanged,7parents+6children; native field/core then coherent SDK");
}
