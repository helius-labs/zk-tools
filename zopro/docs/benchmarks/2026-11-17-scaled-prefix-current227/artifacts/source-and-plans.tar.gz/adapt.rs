use std::fs;
const R:&str="/home/ubuntu/src/zopro-perf-work/scaled-prefix-current227";
const P:&str="/home/ubuntu/src/zopro-perf-work/g2-group-counterfactual225";
fn replace(s:&mut String,a:&str,b:&str){assert!(s.contains(a),"missing {a}");*s=s.replace(a,b);}
fn main(){
 let mut s=fs::read_to_string(format!("{P}/screen.rs")).unwrap().replace(P,R);
 replace(&mut s,"/home/ubuntu/src/zopro-perf-work/clean-stack224/proof-sha256-after-main.json","/home/ubuntu/src/zopro-perf-work/query-deadlines226/proof-sha256-after-main.json");
 replace(&mut s,"4d2bb688410d7b16c36cd9a20420548e01bc27278c61f6336c818f72e9b67b87","cec1b30046897101546b87a053f7194f6d0e07d523c2237e33ff6d501ef86ef3");
 replace(&mut s,"60046","60099");replace(&mut s,"60049","60102");replace(&mut s,"60085","60138");
 replace(&mut s,"\"setup.rs\",\"adapt.rs\",\"prepare-body.rs\",\"assess-body.rs\",","\"setup.rs\",\"adapt.rs\",\"source-audit.json\",");
 replace(&mut s,"fn prepare(){use", "fn prepare(){assert_eq!(read(r(\"build-run/result.json\"))[\"status\"],\"complete\");use");
 replace(&mut s,"G2-only counterfactual","new scaled-prefix integration");replace(&mut s,"\"counterfactual_only\":true","\"exploratory_only\":true");replace(&mut s,"Counterfactual primary_signal=","Integration primary_signal=");
 fs::write(format!("{R}/screen.rs"),s).unwrap();
 let mut s=fs::read_to_string(format!("{P}/independent.rs")).unwrap().replace(P,R);
 replace(&mut s,"/home/ubuntu/src/zopro-perf-work/clean-stack224/proof-sha256-after-main.json","/home/ubuntu/src/zopro-perf-work/query-deadlines226/proof-sha256-after-main.json");
 replace(&mut s,"60046","60099");replace(&mut s,"60085","60138");
 replace(&mut s,"let planonly=std::env::args().nth(1).as_deref()==Some(\"plan\");","let mode=std::env::args().nth(1).unwrap();let planonly=mode==\"plan\";let smokeonly=mode==\"smoke\";assert!([\"plan\",\"smoke\",\"main\"].contains(&mode.as_str()));");
 replace(&mut s,"for phase in[\"preflight\",\"main\"]","for phase in if smokeonly{vec![\"preflight\"]}else{vec![\"preflight\",\"main\"]}");
 replace(&mut s,"assert_eq!((exports,calls,samples),(39,5160,5043));","assert_eq!((exports,calls,samples),if smokeonly{(3,12,3)}else{(39,5160,5043)});");
 let a=s.find("assert_eq!(changed,vec![").unwrap();let b=s[a..].find("let mut useful=false;").unwrap()+a;
 s.replace_range(a..b,r#"let audit=read(format!("{R}/source-audit.json"));let expected=audit["changed_parents"].as_array().unwrap().iter().map(|v|v.as_str().unwrap()).collect::<Vec<_>>();assert_eq!(changed,expected);for d in audit["deltas"].as_array().unwrap(){let file=d["file"].as_str().unwrap();assert_eq!(hash(format!("{R}/source/{file}")),d["after"]);let old=format!("/home/ubuntu/src/zopro-perf-work/uniform-carry-default182/source/{file}");assert_eq!(hash(&old),d["arithmetic_parent_sha256"]);if file!="crates/zopro-core/src/msm.rs"{assert_eq!(hash(&old),hash(format!("{R}/source/{file}")));}else{let current=fs::read_to_string(format!("{R}/source/{file}")).unwrap();let old=fs::read_to_string(old).unwrap();let dispatch="    #[cfg(zopro_indexed_tile_bundles)]\n    if crate::simd::cpu_option(\"ZOPRO_CPU_INDEXED_TILE_BUNDLES\") {\n        if let Some(out)=indexed_tiles::try_reduce::<C>(bases,order,starts){return out;}\n    }\n";let footer="\n#[cfg(zopro_indexed_tile_bundles)]mod indexed_tiles;\n";assert_eq!(current.matches(dispatch).count(),1);assert!(current.ends_with(footer));assert_eq!(current.strip_suffix(footer).unwrap().replace(dispatch,""),old);}}for(p,h)in read(format!("{R}/runtime-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
"#);
 replace(&mut s,"if !planonly{assert_eq!(data.len(),36)","if !planonly&&!smokeonly{assert_eq!(data.len(),36)");
 replace(&mut s,"\"inverse_delta_recovers_original\":true","\"arithmetic_identity_and_current_dispatch_checked\":true");
 replace(&mut s,"if planonly{60099}else{60138}","if planonly{60099}else if smokeonly{60102}else{60138}");
 replace(&mut s,"hash(format!(\"{R}/proof-sha256-after-main.json\"))","hash(format!(\"{R}/proof-sha256-after-{}.json\",if smokeonly{\"preflight\"}else{\"main\"}))");
 replace(&mut s,"if planonly{\"plan\"}else{\"main\"}","mode.as_str()");
 fs::write(format!("{R}/independent.rs"),s).unwrap();
}
