use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/tune-spr176";const OLD:&str="/home/ubuntu/src/zopro-perf-work/fft-column-prep-sdk176";
fn main(){assert!(!Path::new(&format!("{R}/preflight.rs")).exists());let mut s=fs::read_to_string(format!("{OLD}/preflight.rs")).unwrap().replace(OLD,R);for(a,b)in[
("/home/ubuntu/src/zopro-perf-work/sign-mask-allshape176/proof-sha256-after-diagnostic.json","/home/ubuntu/src/zopro-perf-work/inverse-arrival176/proof-sha256-after.json"),
("33449","33949"),("33471","33971"),
("native/whole-prover-portable-check/exit.json","native/new-compiler-native-qualification/exit.json"),
("Exact qualified ephemeral FFT gap-one factor preparation in both directions and layouts; other64 products ordinary","Accepted arithmetic and native target ISA unchanged; separate SPR compiler scheduling tune only"),
("\"portable_fallback_inherited\":false,\"new_portable_compile\":true","\"portable_fallback_inherited\":true,\"new_portable_compile\":false"),
("\"caller_gate_failure_retained_as_explicit_engineering_exception\":true","\"compiler_configuration_native_qualification\":true"),
("format!(\"{R}/make-preflight.rs\")","format!(\"{R}/adapt-preflight.rs\")")]{assert!(s.contains(a),"missing {a}");s=s.replace(a,b);}
let needle="assert_eq!(read(format!(\"{R}/native/new-compiler-native-qualification/exit.json\"))[\"success\"],true);";
assert!(s.contains(needle));let extra=r#"assert_eq!(read(format!("{R}/probe-analysis.json"))["passed"],true);let native=read(format!("{R}/native-plan.json"));assert_eq!(native["environment"]["RUSTC_BOOTSTRAP"],"1");assert!(native["steps"][1]["environment"]["RUSTFLAGS"].as_str().unwrap().ends_with("-Z tune-cpu=sapphirerapids"));let lc=read(format!("{R}/native/candidate/command.json"));assert!(lc["argv"].as_array().unwrap().iter().any(|v|v=="tune-cpu=sapphirerapids"));assert!(lc["argv"].as_array().unwrap().iter().any(|v|v=="-Z"));let test=read(format!("{R}/native/new-compiler-native-qualification/tests.json"));assert_eq!(test["unfiltered"],true);"#;
s=s.replace(needle,&format!("{needle}{extra}"));fs::write(format!("{R}/preflight.rs"),s).unwrap();println!("Adapted frozen proof-binding helper to new compiler configuration/ledger33949; no proof or successful stage replay");}
