; ModuleID = 'tune_probe.3e76117d9c4d24de-cgu.0'
source_filename = "tune_probe.3e76117d9c4d24de-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind nonlazybind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @tune_fq_mul(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([320 x i8]) align 64 captures(none) dereferenceable(320) initializes((0, 320)) %_0, ptr noalias nofree noundef readonly align 64 captures(none) dereferenceable(320) %a, ptr noalias nofree noundef readonly align 64 captures(none) dereferenceable(320) %b) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %_8.i = alloca [40 x i8], align 16
  tail call void @llvm.experimental.noalias.scope.decl(metadata !4)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i)
  store <4 x i64> <i64 154029749239111, i64 2558044347618242, i64 423691504025962, i64 2817616741948264>, ptr %_8.i, align 16, !noalias !11
  %_8.i.32._8.i.32._8.i.32..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 32
  store i64 53207371014449, ptr %_8.i.32._8.i.32._8.i.32..sroa_idx, align 16, !noalias !11
  %_8.i.8._8.i.8._8.i.8..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 8
  %_8.i.8. = load <1 x i64>, ptr %_8.i.8._8.i.8._8.i.8..sroa_idx, align 8, !alias.scope !12, !noalias !15
  %_8.i.16._8.i.16._8.i.16..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 16
  %_8.i.16. = load <1 x i64>, ptr %_8.i.16._8.i.16._8.i.16..sroa_idx, align 16, !alias.scope !12, !noalias !15
  %_8.i.24._8.i.24._8.i.24..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 24
  %_8.i.24._8.i.24._8.i.24. = load <2 x i64>, ptr %_8.i.24._8.i.24._8.i.24..sroa_idx, align 8, !alias.scope !12, !noalias !15
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i)
  %0 = shufflevector <1 x i64> %_8.i.8., <1 x i64> poison, <8 x i32> zeroinitializer
  %1 = shufflevector <1 x i64> %_8.i.16., <1 x i64> poison, <8 x i32> zeroinitializer
  %2 = shufflevector <2 x i64> %_8.i.24._8.i.24._8.i.24., <2 x i64> poison, <8 x i32> zeroinitializer
  %3 = shufflevector <2 x i64> %_8.i.24._8.i.24._8.i.24., <2 x i64> poison, <8 x i32> <i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1>
  %_14.i = load <8 x i64>, ptr %a, align 64, !alias.scope !7, !noalias !17
  %_15.i = load <8 x i64>, ptr %b, align 64, !alias.scope !9, !noalias !18
  %4 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_14.i, <8 x i64> %_15.i)
  %5 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_14.i, <8 x i64> %_15.i)
  %6 = getelementptr inbounds nuw i8, ptr %a, i64 64
  %_20.i = load <8 x i64>, ptr %6, align 64, !alias.scope !7, !noalias !17
  %7 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %5, <8 x i64> %_20.i, <8 x i64> %_15.i)
  %8 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_20.i, <8 x i64> %_15.i)
  %9 = getelementptr inbounds nuw i8, ptr %a, i64 128
  %_25.i = load <8 x i64>, ptr %9, align 64, !alias.scope !7, !noalias !17
  %10 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %8, <8 x i64> %_25.i, <8 x i64> %_15.i)
  %11 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_25.i, <8 x i64> %_15.i)
  %12 = getelementptr inbounds nuw i8, ptr %a, i64 192
  %_30.i = load <8 x i64>, ptr %12, align 64, !alias.scope !7, !noalias !17
  %13 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %11, <8 x i64> %_30.i, <8 x i64> %_15.i)
  %14 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_30.i, <8 x i64> %_15.i)
  %15 = getelementptr inbounds nuw i8, ptr %a, i64 256
  %_35.i = load <8 x i64>, ptr %15, align 64, !alias.scope !7, !noalias !17
  %16 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %14, <8 x i64> %_35.i, <8 x i64> %_15.i)
  %17 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_15.i)
  %18 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %4, <8 x i64> splat (i64 571208714576777))
  %19 = and <8 x i64> %18, splat (i64 4503599627370495)
  %_3.i1 = add <8 x i64> %4, splat (i64 4503599627370495)
  %_3.i2 = lshr <8 x i64> %_3.i1, splat (i64 52)
  %20 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i2, <8 x i64> %19, <8 x i64> splat (i64 154029749239111))
  %21 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %7, <8 x i64> %19, <8 x i64> %0)
  %22 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %10, <8 x i64> %19, <8 x i64> %0)
  %23 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %22, <8 x i64> %19, <8 x i64> %1)
  %24 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %13, <8 x i64> %19, <8 x i64> %1)
  %25 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %24, <8 x i64> %19, <8 x i64> %2)
  %26 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %16, <8 x i64> %19, <8 x i64> %2)
  %27 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %26, <8 x i64> %19, <8 x i64> %3)
  %28 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %17, <8 x i64> %19, <8 x i64> %3)
  %_3.i3 = add <8 x i64> %21, %20
  %29 = getelementptr inbounds nuw i8, ptr %b, i64 64
  %_101.i = load <8 x i64>, ptr %29, align 64, !alias.scope !9, !noalias !18
  %30 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i3, <8 x i64> %_14.i, <8 x i64> %_101.i)
  %31 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %23, <8 x i64> %_14.i, <8 x i64> %_101.i)
  %32 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %31, <8 x i64> %_20.i, <8 x i64> %_101.i)
  %33 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %25, <8 x i64> %_20.i, <8 x i64> %_101.i)
  %34 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %33, <8 x i64> %_25.i, <8 x i64> %_101.i)
  %35 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %27, <8 x i64> %_25.i, <8 x i64> %_101.i)
  %36 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %35, <8 x i64> %_30.i, <8 x i64> %_101.i)
  %37 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %28, <8 x i64> %_30.i, <8 x i64> %_101.i)
  %38 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %37, <8 x i64> %_35.i, <8 x i64> %_101.i)
  %39 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_101.i)
  %40 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %30, <8 x i64> splat (i64 571208714576777))
  %41 = and <8 x i64> %40, splat (i64 4503599627370495)
  %_3.i5 = add <8 x i64> %30, splat (i64 4503599627370495)
  %_3.i6 = lshr <8 x i64> %_3.i5, splat (i64 52)
  %42 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i6, <8 x i64> %41, <8 x i64> splat (i64 154029749239111))
  %43 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %32, <8 x i64> %41, <8 x i64> %0)
  %44 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %34, <8 x i64> %41, <8 x i64> %0)
  %45 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %44, <8 x i64> %41, <8 x i64> %1)
  %46 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %36, <8 x i64> %41, <8 x i64> %1)
  %47 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %46, <8 x i64> %41, <8 x i64> %2)
  %48 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %38, <8 x i64> %41, <8 x i64> %2)
  %49 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %48, <8 x i64> %41, <8 x i64> %3)
  %50 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %39, <8 x i64> %41, <8 x i64> %3)
  %_3.i7 = add <8 x i64> %43, %42
  %51 = getelementptr inbounds nuw i8, ptr %b, i64 128
  %_178.i = load <8 x i64>, ptr %51, align 64, !alias.scope !9, !noalias !18
  %52 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i7, <8 x i64> %_14.i, <8 x i64> %_178.i)
  %53 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %45, <8 x i64> %_14.i, <8 x i64> %_178.i)
  %54 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %53, <8 x i64> %_20.i, <8 x i64> %_178.i)
  %55 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %47, <8 x i64> %_20.i, <8 x i64> %_178.i)
  %56 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %55, <8 x i64> %_25.i, <8 x i64> %_178.i)
  %57 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %49, <8 x i64> %_25.i, <8 x i64> %_178.i)
  %58 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %57, <8 x i64> %_30.i, <8 x i64> %_178.i)
  %59 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %50, <8 x i64> %_30.i, <8 x i64> %_178.i)
  %60 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %59, <8 x i64> %_35.i, <8 x i64> %_178.i)
  %61 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_178.i)
  %62 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %52, <8 x i64> splat (i64 571208714576777))
  %63 = and <8 x i64> %62, splat (i64 4503599627370495)
  %_3.i9 = add <8 x i64> %52, splat (i64 4503599627370495)
  %_3.i10 = lshr <8 x i64> %_3.i9, splat (i64 52)
  %64 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i10, <8 x i64> %63, <8 x i64> splat (i64 154029749239111))
  %65 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %54, <8 x i64> %63, <8 x i64> %0)
  %66 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %56, <8 x i64> %63, <8 x i64> %0)
  %67 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %66, <8 x i64> %63, <8 x i64> %1)
  %68 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %58, <8 x i64> %63, <8 x i64> %1)
  %69 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %68, <8 x i64> %63, <8 x i64> %2)
  %70 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %60, <8 x i64> %63, <8 x i64> %2)
  %71 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %70, <8 x i64> %63, <8 x i64> %3)
  %72 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %61, <8 x i64> %63, <8 x i64> %3)
  %_3.i11 = add <8 x i64> %65, %64
  %73 = getelementptr inbounds nuw i8, ptr %b, i64 192
  %_255.i = load <8 x i64>, ptr %73, align 64, !alias.scope !9, !noalias !18
  %74 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i11, <8 x i64> %_14.i, <8 x i64> %_255.i)
  %75 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %67, <8 x i64> %_14.i, <8 x i64> %_255.i)
  %76 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %75, <8 x i64> %_20.i, <8 x i64> %_255.i)
  %77 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %69, <8 x i64> %_20.i, <8 x i64> %_255.i)
  %78 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %77, <8 x i64> %_25.i, <8 x i64> %_255.i)
  %79 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %71, <8 x i64> %_25.i, <8 x i64> %_255.i)
  %80 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %79, <8 x i64> %_30.i, <8 x i64> %_255.i)
  %81 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %72, <8 x i64> %_30.i, <8 x i64> %_255.i)
  %82 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %81, <8 x i64> %_35.i, <8 x i64> %_255.i)
  %83 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_255.i)
  %84 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %74, <8 x i64> splat (i64 571208714576777))
  %85 = and <8 x i64> %84, splat (i64 4503599627370495)
  %_3.i13 = add <8 x i64> %74, splat (i64 4503599627370495)
  %_3.i14 = lshr <8 x i64> %_3.i13, splat (i64 52)
  %86 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i14, <8 x i64> %85, <8 x i64> splat (i64 154029749239111))
  %87 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %76, <8 x i64> %85, <8 x i64> %0)
  %88 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %78, <8 x i64> %85, <8 x i64> %0)
  %89 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %88, <8 x i64> %85, <8 x i64> %1)
  %90 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %80, <8 x i64> %85, <8 x i64> %1)
  %91 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %90, <8 x i64> %85, <8 x i64> %2)
  %92 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %82, <8 x i64> %85, <8 x i64> %2)
  %93 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %92, <8 x i64> %85, <8 x i64> %3)
  %94 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %83, <8 x i64> %85, <8 x i64> %3)
  %_3.i15 = add <8 x i64> %87, %86
  %95 = getelementptr inbounds nuw i8, ptr %b, i64 256
  %_436.i = load <8 x i64>, ptr %95, align 64, !alias.scope !9, !noalias !18
  %96 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i15, <8 x i64> %_14.i, <8 x i64> %_436.i)
  %97 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %89, <8 x i64> %_14.i, <8 x i64> %_436.i)
  %98 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %97, <8 x i64> %_20.i, <8 x i64> %_436.i)
  %99 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %91, <8 x i64> %_20.i, <8 x i64> %_436.i)
  %100 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %99, <8 x i64> %_25.i, <8 x i64> %_436.i)
  %101 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %93, <8 x i64> %_25.i, <8 x i64> %_436.i)
  %102 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %101, <8 x i64> %_30.i, <8 x i64> %_436.i)
  %103 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %94, <8 x i64> %_30.i, <8 x i64> %_436.i)
  %104 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %103, <8 x i64> %_35.i, <8 x i64> %_436.i)
  %105 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_436.i)
  %106 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %96, <8 x i64> splat (i64 571208714576777))
  %107 = and <8 x i64> %106, splat (i64 4503599627370495)
  %_3.i17 = add <8 x i64> %96, splat (i64 4503599627370495)
  %_3.i18 = lshr <8 x i64> %_3.i17, splat (i64 52)
  %108 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i18, <8 x i64> %107, <8 x i64> splat (i64 154029749239111))
  %109 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %98, <8 x i64> %107, <8 x i64> %0)
  %110 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %100, <8 x i64> %107, <8 x i64> %0)
  %111 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %110, <8 x i64> %107, <8 x i64> %1)
  %112 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %102, <8 x i64> %107, <8 x i64> %1)
  %113 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %112, <8 x i64> %107, <8 x i64> %2)
  %114 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %104, <8 x i64> %107, <8 x i64> %2)
  %115 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %114, <8 x i64> %107, <8 x i64> %3)
  %116 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %105, <8 x i64> %107, <8 x i64> %3)
  %_3.i19 = add <8 x i64> %109, %108
  %_3.i20 = lshr <8 x i64> %_3.i19, splat (i64 52)
  %_3.i21 = add <8 x i64> %_3.i20, %111
  %117 = and <8 x i64> %_3.i19, splat (i64 4503599627370495)
  %_3.i20.1 = lshr <8 x i64> %_3.i21, splat (i64 52)
  %_3.i21.1 = add <8 x i64> %_3.i20.1, %113
  %118 = and <8 x i64> %_3.i21, splat (i64 4503599627370495)
  %_3.i20.2 = lshr <8 x i64> %_3.i21.1, splat (i64 52)
  %_3.i21.2 = add <8 x i64> %_3.i20.2, %115
  %119 = and <8 x i64> %_3.i21.1, splat (i64 4503599627370495)
  %_3.i20.3 = lshr <8 x i64> %_3.i21.2, splat (i64 52)
  %_3.i21.3 = add <8 x i64> %_3.i20.3, %116
  %120 = and <8 x i64> %_3.i21.2, splat (i64 4503599627370495)
  store <8 x i64> %117, ptr %_0, align 64, !alias.scope !4, !noalias !19
  %result.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 64
  store <8 x i64> %118, ptr %result.sroa.4.0._0.sroa_idx.i, align 64, !alias.scope !4, !noalias !19
  %result.sroa.5.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 128
  store <8 x i64> %119, ptr %result.sroa.5.0._0.sroa_idx.i, align 64, !alias.scope !4, !noalias !19
  %result.sroa.6.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 192
  store <8 x i64> %120, ptr %result.sroa.6.0._0.sroa_idx.i, align 64, !alias.scope !4, !noalias !19
  %result.sroa.7.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 256
  store <8 x i64> %_3.i21.3, ptr %result.sroa.7.0._0.sroa_idx.i, align 64, !alias.scope !4, !noalias !19
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind nonlazybind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @tune_fq_sum(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([320 x i8]) align 64 captures(none) dereferenceable(320) initializes((0, 320)) %_0, ptr noalias nofree noundef readonly align 64 captures(none) dereferenceable(320) %a, ptr noalias nofree noundef readonly align 64 captures(none) dereferenceable(320) %b, ptr noalias nofree noundef readonly align 64 captures(none) dereferenceable(320) %c, ptr noalias nofree noundef readonly align 64 captures(none) dereferenceable(320) %d) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %_8.i = alloca [40 x i8], align 16
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !23)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !25)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !27)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !29)
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i)
  store <4 x i64> <i64 154029749239111, i64 2558044347618242, i64 423691504025962, i64 2817616741948264>, ptr %_8.i, align 16, !noalias !31
  %_8.i.32._8.i.32._8.i.32..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 32
  store i64 53207371014449, ptr %_8.i.32._8.i.32._8.i.32..sroa_idx, align 16, !noalias !31
  %_8.i.8._8.i.8._8.i.8..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 8
  %_8.i.8. = load <1 x i64>, ptr %_8.i.8._8.i.8._8.i.8..sroa_idx, align 8, !alias.scope !32, !noalias !35
  %_8.i.16._8.i.16._8.i.16..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 16
  %_8.i.16. = load <1 x i64>, ptr %_8.i.16._8.i.16._8.i.16..sroa_idx, align 16, !alias.scope !32, !noalias !35
  %_8.i.24._8.i.24._8.i.24..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 24
  %_8.i.24._8.i.24._8.i.24. = load <2 x i64>, ptr %_8.i.24._8.i.24._8.i.24..sroa_idx, align 8, !alias.scope !32, !noalias !35
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i)
  %0 = shufflevector <1 x i64> %_8.i.8., <1 x i64> poison, <8 x i32> zeroinitializer
  %1 = shufflevector <1 x i64> %_8.i.16., <1 x i64> poison, <8 x i32> zeroinitializer
  %2 = shufflevector <2 x i64> %_8.i.24._8.i.24._8.i.24., <2 x i64> poison, <8 x i32> zeroinitializer
  %3 = shufflevector <2 x i64> %_8.i.24._8.i.24._8.i.24., <2 x i64> poison, <8 x i32> <i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1>
  %_14.i = load <8 x i64>, ptr %a, align 64, !alias.scope !23, !noalias !37
  %_15.i = load <8 x i64>, ptr %b, align 64, !alias.scope !25, !noalias !38
  %4 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_14.i, <8 x i64> %_15.i)
  %5 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_14.i, <8 x i64> %_15.i)
  %6 = getelementptr inbounds nuw i8, ptr %a, i64 64
  %_20.i = load <8 x i64>, ptr %6, align 64, !alias.scope !23, !noalias !37
  %7 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %5, <8 x i64> %_20.i, <8 x i64> %_15.i)
  %8 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_20.i, <8 x i64> %_15.i)
  %9 = getelementptr inbounds nuw i8, ptr %a, i64 128
  %_25.i = load <8 x i64>, ptr %9, align 64, !alias.scope !23, !noalias !37
  %10 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %8, <8 x i64> %_25.i, <8 x i64> %_15.i)
  %11 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_25.i, <8 x i64> %_15.i)
  %12 = getelementptr inbounds nuw i8, ptr %a, i64 192
  %_30.i = load <8 x i64>, ptr %12, align 64, !alias.scope !23, !noalias !37
  %13 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %11, <8 x i64> %_30.i, <8 x i64> %_15.i)
  %14 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_30.i, <8 x i64> %_15.i)
  %15 = getelementptr inbounds nuw i8, ptr %a, i64 256
  %_35.i = load <8 x i64>, ptr %15, align 64, !alias.scope !23, !noalias !37
  %16 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %14, <8 x i64> %_35.i, <8 x i64> %_15.i)
  %17 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_15.i)
  %_40.i = load <8 x i64>, ptr %c, align 64, !alias.scope !27, !noalias !39
  %_41.i = load <8 x i64>, ptr %d, align 64, !alias.scope !29, !noalias !40
  %18 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %4, <8 x i64> %_40.i, <8 x i64> %_41.i)
  %19 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %7, <8 x i64> %_40.i, <8 x i64> %_41.i)
  %20 = getelementptr inbounds nuw i8, ptr %c, i64 64
  %_46.i = load <8 x i64>, ptr %20, align 64, !alias.scope !27, !noalias !39
  %21 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %19, <8 x i64> %_46.i, <8 x i64> %_41.i)
  %22 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %10, <8 x i64> %_46.i, <8 x i64> %_41.i)
  %23 = getelementptr inbounds nuw i8, ptr %c, i64 128
  %_51.i = load <8 x i64>, ptr %23, align 64, !alias.scope !27, !noalias !39
  %24 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %22, <8 x i64> %_51.i, <8 x i64> %_41.i)
  %25 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %13, <8 x i64> %_51.i, <8 x i64> %_41.i)
  %26 = getelementptr inbounds nuw i8, ptr %c, i64 192
  %_56.i = load <8 x i64>, ptr %26, align 64, !alias.scope !27, !noalias !39
  %27 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %25, <8 x i64> %_56.i, <8 x i64> %_41.i)
  %28 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %16, <8 x i64> %_56.i, <8 x i64> %_41.i)
  %29 = getelementptr inbounds nuw i8, ptr %c, i64 256
  %_61.i = load <8 x i64>, ptr %29, align 64, !alias.scope !27, !noalias !39
  %30 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %28, <8 x i64> %_61.i, <8 x i64> %_41.i)
  %31 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %17, <8 x i64> %_61.i, <8 x i64> %_41.i)
  %32 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %18, <8 x i64> splat (i64 571208714576777))
  %33 = and <8 x i64> %32, splat (i64 4503599627370495)
  %_3.i1 = add <8 x i64> %18, splat (i64 4503599627370495)
  %_3.i2 = lshr <8 x i64> %_3.i1, splat (i64 52)
  %34 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i2, <8 x i64> %33, <8 x i64> splat (i64 154029749239111))
  %35 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %21, <8 x i64> %33, <8 x i64> %0)
  %36 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %24, <8 x i64> %33, <8 x i64> %0)
  %37 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %36, <8 x i64> %33, <8 x i64> %1)
  %38 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %27, <8 x i64> %33, <8 x i64> %1)
  %39 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %38, <8 x i64> %33, <8 x i64> %2)
  %40 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %30, <8 x i64> %33, <8 x i64> %2)
  %41 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %40, <8 x i64> %33, <8 x i64> %3)
  %42 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %31, <8 x i64> %33, <8 x i64> %3)
  %_3.i3 = add <8 x i64> %35, %34
  %43 = getelementptr inbounds nuw i8, ptr %b, i64 64
  %_101.i = load <8 x i64>, ptr %43, align 64, !alias.scope !25, !noalias !38
  %44 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i3, <8 x i64> %_14.i, <8 x i64> %_101.i)
  %45 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %37, <8 x i64> %_14.i, <8 x i64> %_101.i)
  %46 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %45, <8 x i64> %_20.i, <8 x i64> %_101.i)
  %47 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %39, <8 x i64> %_20.i, <8 x i64> %_101.i)
  %48 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %47, <8 x i64> %_25.i, <8 x i64> %_101.i)
  %49 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %41, <8 x i64> %_25.i, <8 x i64> %_101.i)
  %50 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %49, <8 x i64> %_30.i, <8 x i64> %_101.i)
  %51 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %42, <8 x i64> %_30.i, <8 x i64> %_101.i)
  %52 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %51, <8 x i64> %_35.i, <8 x i64> %_101.i)
  %53 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_101.i)
  %54 = getelementptr inbounds nuw i8, ptr %d, i64 64
  %_123.i = load <8 x i64>, ptr %54, align 64, !alias.scope !29, !noalias !40
  %55 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %44, <8 x i64> %_40.i, <8 x i64> %_123.i)
  %56 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %46, <8 x i64> %_40.i, <8 x i64> %_123.i)
  %57 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %56, <8 x i64> %_46.i, <8 x i64> %_123.i)
  %58 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %48, <8 x i64> %_46.i, <8 x i64> %_123.i)
  %59 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %58, <8 x i64> %_51.i, <8 x i64> %_123.i)
  %60 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %50, <8 x i64> %_51.i, <8 x i64> %_123.i)
  %61 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %60, <8 x i64> %_56.i, <8 x i64> %_123.i)
  %62 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %52, <8 x i64> %_56.i, <8 x i64> %_123.i)
  %63 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %62, <8 x i64> %_61.i, <8 x i64> %_123.i)
  %64 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %53, <8 x i64> %_61.i, <8 x i64> %_123.i)
  %65 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %55, <8 x i64> splat (i64 571208714576777))
  %66 = and <8 x i64> %65, splat (i64 4503599627370495)
  %_3.i5 = add <8 x i64> %55, splat (i64 4503599627370495)
  %_3.i6 = lshr <8 x i64> %_3.i5, splat (i64 52)
  %67 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i6, <8 x i64> %66, <8 x i64> splat (i64 154029749239111))
  %68 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %57, <8 x i64> %66, <8 x i64> %0)
  %69 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %59, <8 x i64> %66, <8 x i64> %0)
  %70 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %69, <8 x i64> %66, <8 x i64> %1)
  %71 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %61, <8 x i64> %66, <8 x i64> %1)
  %72 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %71, <8 x i64> %66, <8 x i64> %2)
  %73 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %63, <8 x i64> %66, <8 x i64> %2)
  %74 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %73, <8 x i64> %66, <8 x i64> %3)
  %75 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %64, <8 x i64> %66, <8 x i64> %3)
  %_3.i7 = add <8 x i64> %68, %67
  %76 = getelementptr inbounds nuw i8, ptr %b, i64 128
  %_178.i = load <8 x i64>, ptr %76, align 64, !alias.scope !25, !noalias !38
  %77 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i7, <8 x i64> %_14.i, <8 x i64> %_178.i)
  %78 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %70, <8 x i64> %_14.i, <8 x i64> %_178.i)
  %79 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %78, <8 x i64> %_20.i, <8 x i64> %_178.i)
  %80 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %72, <8 x i64> %_20.i, <8 x i64> %_178.i)
  %81 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %80, <8 x i64> %_25.i, <8 x i64> %_178.i)
  %82 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %74, <8 x i64> %_25.i, <8 x i64> %_178.i)
  %83 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %82, <8 x i64> %_30.i, <8 x i64> %_178.i)
  %84 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %75, <8 x i64> %_30.i, <8 x i64> %_178.i)
  %85 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %84, <8 x i64> %_35.i, <8 x i64> %_178.i)
  %86 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_178.i)
  %87 = getelementptr inbounds nuw i8, ptr %d, i64 128
  %_200.i = load <8 x i64>, ptr %87, align 64, !alias.scope !29, !noalias !40
  %88 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %77, <8 x i64> %_40.i, <8 x i64> %_200.i)
  %89 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %79, <8 x i64> %_40.i, <8 x i64> %_200.i)
  %90 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %89, <8 x i64> %_46.i, <8 x i64> %_200.i)
  %91 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %81, <8 x i64> %_46.i, <8 x i64> %_200.i)
  %92 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %91, <8 x i64> %_51.i, <8 x i64> %_200.i)
  %93 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %83, <8 x i64> %_51.i, <8 x i64> %_200.i)
  %94 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %93, <8 x i64> %_56.i, <8 x i64> %_200.i)
  %95 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %85, <8 x i64> %_56.i, <8 x i64> %_200.i)
  %96 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %95, <8 x i64> %_61.i, <8 x i64> %_200.i)
  %97 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %86, <8 x i64> %_61.i, <8 x i64> %_200.i)
  %98 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %88, <8 x i64> splat (i64 571208714576777))
  %99 = and <8 x i64> %98, splat (i64 4503599627370495)
  %_3.i9 = add <8 x i64> %88, splat (i64 4503599627370495)
  %_3.i10 = lshr <8 x i64> %_3.i9, splat (i64 52)
  %100 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i10, <8 x i64> %99, <8 x i64> splat (i64 154029749239111))
  %101 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %90, <8 x i64> %99, <8 x i64> %0)
  %102 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %92, <8 x i64> %99, <8 x i64> %0)
  %103 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %102, <8 x i64> %99, <8 x i64> %1)
  %104 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %94, <8 x i64> %99, <8 x i64> %1)
  %105 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %104, <8 x i64> %99, <8 x i64> %2)
  %106 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %96, <8 x i64> %99, <8 x i64> %2)
  %107 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %106, <8 x i64> %99, <8 x i64> %3)
  %108 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %97, <8 x i64> %99, <8 x i64> %3)
  %_3.i11 = add <8 x i64> %101, %100
  %109 = getelementptr inbounds nuw i8, ptr %b, i64 192
  %_255.i = load <8 x i64>, ptr %109, align 64, !alias.scope !25, !noalias !38
  %110 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i11, <8 x i64> %_14.i, <8 x i64> %_255.i)
  %111 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %103, <8 x i64> %_14.i, <8 x i64> %_255.i)
  %112 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %111, <8 x i64> %_20.i, <8 x i64> %_255.i)
  %113 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %105, <8 x i64> %_20.i, <8 x i64> %_255.i)
  %114 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %113, <8 x i64> %_25.i, <8 x i64> %_255.i)
  %115 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %107, <8 x i64> %_25.i, <8 x i64> %_255.i)
  %116 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %115, <8 x i64> %_30.i, <8 x i64> %_255.i)
  %117 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %108, <8 x i64> %_30.i, <8 x i64> %_255.i)
  %118 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %117, <8 x i64> %_35.i, <8 x i64> %_255.i)
  %119 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_255.i)
  %120 = getelementptr inbounds nuw i8, ptr %d, i64 192
  %_277.i = load <8 x i64>, ptr %120, align 64, !alias.scope !29, !noalias !40
  %121 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %110, <8 x i64> %_40.i, <8 x i64> %_277.i)
  %122 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %112, <8 x i64> %_40.i, <8 x i64> %_277.i)
  %123 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %122, <8 x i64> %_46.i, <8 x i64> %_277.i)
  %124 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %114, <8 x i64> %_46.i, <8 x i64> %_277.i)
  %125 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %124, <8 x i64> %_51.i, <8 x i64> %_277.i)
  %126 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %116, <8 x i64> %_51.i, <8 x i64> %_277.i)
  %127 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %126, <8 x i64> %_56.i, <8 x i64> %_277.i)
  %128 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %118, <8 x i64> %_56.i, <8 x i64> %_277.i)
  %129 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %128, <8 x i64> %_61.i, <8 x i64> %_277.i)
  %130 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %119, <8 x i64> %_61.i, <8 x i64> %_277.i)
  %131 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %121, <8 x i64> splat (i64 571208714576777))
  %132 = and <8 x i64> %131, splat (i64 4503599627370495)
  %_3.i13 = add <8 x i64> %121, splat (i64 4503599627370495)
  %_3.i14 = lshr <8 x i64> %_3.i13, splat (i64 52)
  %133 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i14, <8 x i64> %132, <8 x i64> splat (i64 154029749239111))
  %134 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %123, <8 x i64> %132, <8 x i64> %0)
  %135 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %125, <8 x i64> %132, <8 x i64> %0)
  %136 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %135, <8 x i64> %132, <8 x i64> %1)
  %137 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %127, <8 x i64> %132, <8 x i64> %1)
  %138 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %137, <8 x i64> %132, <8 x i64> %2)
  %139 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %129, <8 x i64> %132, <8 x i64> %2)
  %140 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %139, <8 x i64> %132, <8 x i64> %3)
  %141 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %130, <8 x i64> %132, <8 x i64> %3)
  %_3.i15 = add <8 x i64> %134, %133
  %142 = getelementptr inbounds nuw i8, ptr %b, i64 256
  %_436.i = load <8 x i64>, ptr %142, align 64, !alias.scope !25, !noalias !38
  %143 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i15, <8 x i64> %_14.i, <8 x i64> %_436.i)
  %144 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %136, <8 x i64> %_14.i, <8 x i64> %_436.i)
  %145 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %144, <8 x i64> %_20.i, <8 x i64> %_436.i)
  %146 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %138, <8 x i64> %_20.i, <8 x i64> %_436.i)
  %147 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %146, <8 x i64> %_25.i, <8 x i64> %_436.i)
  %148 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %140, <8 x i64> %_25.i, <8 x i64> %_436.i)
  %149 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %148, <8 x i64> %_30.i, <8 x i64> %_436.i)
  %150 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %141, <8 x i64> %_30.i, <8 x i64> %_436.i)
  %151 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %150, <8 x i64> %_35.i, <8 x i64> %_436.i)
  %152 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_436.i)
  %153 = getelementptr inbounds nuw i8, ptr %d, i64 256
  %_458.i = load <8 x i64>, ptr %153, align 64, !alias.scope !29, !noalias !40
  %154 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %143, <8 x i64> %_40.i, <8 x i64> %_458.i)
  %155 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %145, <8 x i64> %_40.i, <8 x i64> %_458.i)
  %156 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %155, <8 x i64> %_46.i, <8 x i64> %_458.i)
  %157 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %147, <8 x i64> %_46.i, <8 x i64> %_458.i)
  %158 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %157, <8 x i64> %_51.i, <8 x i64> %_458.i)
  %159 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %149, <8 x i64> %_51.i, <8 x i64> %_458.i)
  %160 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %159, <8 x i64> %_56.i, <8 x i64> %_458.i)
  %161 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %151, <8 x i64> %_56.i, <8 x i64> %_458.i)
  %162 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %161, <8 x i64> %_61.i, <8 x i64> %_458.i)
  %163 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %152, <8 x i64> %_61.i, <8 x i64> %_458.i)
  %164 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %154, <8 x i64> splat (i64 571208714576777))
  %165 = and <8 x i64> %164, splat (i64 4503599627370495)
  %_3.i17 = add <8 x i64> %154, splat (i64 4503599627370495)
  %_3.i18 = lshr <8 x i64> %_3.i17, splat (i64 52)
  %166 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i18, <8 x i64> %165, <8 x i64> splat (i64 154029749239111))
  %167 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %156, <8 x i64> %165, <8 x i64> %0)
  %168 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %158, <8 x i64> %165, <8 x i64> %0)
  %169 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %168, <8 x i64> %165, <8 x i64> %1)
  %170 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %160, <8 x i64> %165, <8 x i64> %1)
  %171 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %170, <8 x i64> %165, <8 x i64> %2)
  %172 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %162, <8 x i64> %165, <8 x i64> %2)
  %173 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %172, <8 x i64> %165, <8 x i64> %3)
  %174 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %163, <8 x i64> %165, <8 x i64> %3)
  %_3.i19 = add <8 x i64> %167, %166
  %_3.i20 = lshr <8 x i64> %_3.i19, splat (i64 52)
  %_3.i21 = add <8 x i64> %_3.i20, %169
  %175 = and <8 x i64> %_3.i19, splat (i64 4503599627370495)
  %_3.i20.1 = lshr <8 x i64> %_3.i21, splat (i64 52)
  %_3.i21.1 = add <8 x i64> %_3.i20.1, %171
  %176 = and <8 x i64> %_3.i21, splat (i64 4503599627370495)
  %_3.i20.2 = lshr <8 x i64> %_3.i21.1, splat (i64 52)
  %_3.i21.2 = add <8 x i64> %_3.i20.2, %173
  %177 = and <8 x i64> %_3.i21.1, splat (i64 4503599627370495)
  %_3.i20.3 = lshr <8 x i64> %_3.i21.2, splat (i64 52)
  %_3.i21.3 = add <8 x i64> %_3.i20.3, %174
  %178 = and <8 x i64> %_3.i21.2, splat (i64 4503599627370495)
  store <8 x i64> %175, ptr %_0, align 64, !alias.scope !20, !noalias !41
  %result.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 64
  store <8 x i64> %176, ptr %result.sroa.4.0._0.sroa_idx.i, align 64, !alias.scope !20, !noalias !41
  %result.sroa.5.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 128
  store <8 x i64> %177, ptr %result.sroa.5.0._0.sroa_idx.i, align 64, !alias.scope !20, !noalias !41
  %result.sroa.6.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 192
  store <8 x i64> %178, ptr %result.sroa.6.0._0.sroa_idx.i, align 64, !alias.scope !20, !noalias !41
  %result.sroa.7.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 256
  store <8 x i64> %_3.i21.3, ptr %result.sroa.7.0._0.sroa_idx.i, align 64, !alias.scope !20, !noalias !41
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind nonlazybind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @tune_fr_mul(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([320 x i8]) align 64 captures(none) dereferenceable(320) initializes((0, 320)) %_0, ptr noalias nofree noundef readonly align 64 captures(none) dereferenceable(320) %a, ptr noalias nofree noundef readonly align 64 captures(none) dereferenceable(320) %b) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %_8.i = alloca [40 x i8], align 16
  tail call void @llvm.experimental.noalias.scope.decl(metadata !42)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !45)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !47)
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i)
  store <4 x i64> <i64 551490712240129, i64 1275002230477886, i64 423691496731624, i64 2817616741948264>, ptr %_8.i, align 16, !noalias !49
  %_8.i.32._8.i.32._8.i.32..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 32
  store i64 53207371014449, ptr %_8.i.32._8.i.32._8.i.32..sroa_idx, align 16, !noalias !49
  %_8.i.8._8.i.8._8.i.8..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 8
  %_8.i.8. = load <1 x i64>, ptr %_8.i.8._8.i.8._8.i.8..sroa_idx, align 8, !alias.scope !50, !noalias !53
  %_8.i.16._8.i.16._8.i.16..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 16
  %_8.i.16. = load <1 x i64>, ptr %_8.i.16._8.i.16._8.i.16..sroa_idx, align 16, !alias.scope !50, !noalias !53
  %_8.i.24._8.i.24._8.i.24..sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 24
  %_8.i.24._8.i.24._8.i.24. = load <2 x i64>, ptr %_8.i.24._8.i.24._8.i.24..sroa_idx, align 8, !alias.scope !50, !noalias !53
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i)
  %0 = shufflevector <1 x i64> %_8.i.8., <1 x i64> poison, <8 x i32> zeroinitializer
  %1 = shufflevector <1 x i64> %_8.i.16., <1 x i64> poison, <8 x i32> zeroinitializer
  %2 = shufflevector <2 x i64> %_8.i.24._8.i.24._8.i.24., <2 x i64> poison, <8 x i32> zeroinitializer
  %3 = shufflevector <2 x i64> %_8.i.24._8.i.24._8.i.24., <2 x i64> poison, <8 x i32> <i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1>
  %_14.i = load <8 x i64>, ptr %a, align 64, !alias.scope !45, !noalias !55
  %_15.i = load <8 x i64>, ptr %b, align 64, !alias.scope !47, !noalias !56
  %4 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_14.i, <8 x i64> %_15.i)
  %5 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_14.i, <8 x i64> %_15.i)
  %6 = getelementptr inbounds nuw i8, ptr %a, i64 64
  %_20.i = load <8 x i64>, ptr %6, align 64, !alias.scope !45, !noalias !55
  %7 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %5, <8 x i64> %_20.i, <8 x i64> %_15.i)
  %8 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_20.i, <8 x i64> %_15.i)
  %9 = getelementptr inbounds nuw i8, ptr %a, i64 128
  %_25.i = load <8 x i64>, ptr %9, align 64, !alias.scope !45, !noalias !55
  %10 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %8, <8 x i64> %_25.i, <8 x i64> %_15.i)
  %11 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_25.i, <8 x i64> %_15.i)
  %12 = getelementptr inbounds nuw i8, ptr %a, i64 192
  %_30.i = load <8 x i64>, ptr %12, align 64, !alias.scope !45, !noalias !55
  %13 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %11, <8 x i64> %_30.i, <8 x i64> %_15.i)
  %14 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_30.i, <8 x i64> %_15.i)
  %15 = getelementptr inbounds nuw i8, ptr %a, i64 256
  %_35.i = load <8 x i64>, ptr %15, align 64, !alias.scope !45, !noalias !55
  %16 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %14, <8 x i64> %_35.i, <8 x i64> %_15.i)
  %17 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_15.i)
  %18 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %4, <8 x i64> splat (i64 551490712240127))
  %19 = and <8 x i64> %18, splat (i64 4503599627370495)
  %_3.i1 = add <8 x i64> %4, splat (i64 4503599627370495)
  %_3.i2 = lshr <8 x i64> %_3.i1, splat (i64 52)
  %20 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i2, <8 x i64> %19, <8 x i64> splat (i64 551490712240129))
  %21 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %7, <8 x i64> %19, <8 x i64> %0)
  %22 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %10, <8 x i64> %19, <8 x i64> %0)
  %23 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %22, <8 x i64> %19, <8 x i64> %1)
  %24 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %13, <8 x i64> %19, <8 x i64> %1)
  %25 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %24, <8 x i64> %19, <8 x i64> %2)
  %26 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %16, <8 x i64> %19, <8 x i64> %2)
  %27 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %26, <8 x i64> %19, <8 x i64> %3)
  %28 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %17, <8 x i64> %19, <8 x i64> %3)
  %_3.i3 = add <8 x i64> %21, %20
  %29 = getelementptr inbounds nuw i8, ptr %b, i64 64
  %_101.i = load <8 x i64>, ptr %29, align 64, !alias.scope !47, !noalias !56
  %30 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i3, <8 x i64> %_14.i, <8 x i64> %_101.i)
  %31 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %23, <8 x i64> %_14.i, <8 x i64> %_101.i)
  %32 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %31, <8 x i64> %_20.i, <8 x i64> %_101.i)
  %33 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %25, <8 x i64> %_20.i, <8 x i64> %_101.i)
  %34 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %33, <8 x i64> %_25.i, <8 x i64> %_101.i)
  %35 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %27, <8 x i64> %_25.i, <8 x i64> %_101.i)
  %36 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %35, <8 x i64> %_30.i, <8 x i64> %_101.i)
  %37 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %28, <8 x i64> %_30.i, <8 x i64> %_101.i)
  %38 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %37, <8 x i64> %_35.i, <8 x i64> %_101.i)
  %39 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_101.i)
  %40 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %30, <8 x i64> splat (i64 551490712240127))
  %41 = and <8 x i64> %40, splat (i64 4503599627370495)
  %_3.i5 = add <8 x i64> %30, splat (i64 4503599627370495)
  %_3.i6 = lshr <8 x i64> %_3.i5, splat (i64 52)
  %42 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i6, <8 x i64> %41, <8 x i64> splat (i64 551490712240129))
  %43 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %32, <8 x i64> %41, <8 x i64> %0)
  %44 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %34, <8 x i64> %41, <8 x i64> %0)
  %45 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %44, <8 x i64> %41, <8 x i64> %1)
  %46 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %36, <8 x i64> %41, <8 x i64> %1)
  %47 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %46, <8 x i64> %41, <8 x i64> %2)
  %48 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %38, <8 x i64> %41, <8 x i64> %2)
  %49 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %48, <8 x i64> %41, <8 x i64> %3)
  %50 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %39, <8 x i64> %41, <8 x i64> %3)
  %_3.i7 = add <8 x i64> %43, %42
  %51 = getelementptr inbounds nuw i8, ptr %b, i64 128
  %_178.i = load <8 x i64>, ptr %51, align 64, !alias.scope !47, !noalias !56
  %52 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i7, <8 x i64> %_14.i, <8 x i64> %_178.i)
  %53 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %45, <8 x i64> %_14.i, <8 x i64> %_178.i)
  %54 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %53, <8 x i64> %_20.i, <8 x i64> %_178.i)
  %55 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %47, <8 x i64> %_20.i, <8 x i64> %_178.i)
  %56 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %55, <8 x i64> %_25.i, <8 x i64> %_178.i)
  %57 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %49, <8 x i64> %_25.i, <8 x i64> %_178.i)
  %58 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %57, <8 x i64> %_30.i, <8 x i64> %_178.i)
  %59 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %50, <8 x i64> %_30.i, <8 x i64> %_178.i)
  %60 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %59, <8 x i64> %_35.i, <8 x i64> %_178.i)
  %61 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_178.i)
  %62 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %52, <8 x i64> splat (i64 551490712240127))
  %63 = and <8 x i64> %62, splat (i64 4503599627370495)
  %_3.i9 = add <8 x i64> %52, splat (i64 4503599627370495)
  %_3.i10 = lshr <8 x i64> %_3.i9, splat (i64 52)
  %64 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i10, <8 x i64> %63, <8 x i64> splat (i64 551490712240129))
  %65 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %54, <8 x i64> %63, <8 x i64> %0)
  %66 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %56, <8 x i64> %63, <8 x i64> %0)
  %67 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %66, <8 x i64> %63, <8 x i64> %1)
  %68 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %58, <8 x i64> %63, <8 x i64> %1)
  %69 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %68, <8 x i64> %63, <8 x i64> %2)
  %70 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %60, <8 x i64> %63, <8 x i64> %2)
  %71 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %70, <8 x i64> %63, <8 x i64> %3)
  %72 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %61, <8 x i64> %63, <8 x i64> %3)
  %_3.i11 = add <8 x i64> %65, %64
  %73 = getelementptr inbounds nuw i8, ptr %b, i64 192
  %_255.i = load <8 x i64>, ptr %73, align 64, !alias.scope !47, !noalias !56
  %74 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i11, <8 x i64> %_14.i, <8 x i64> %_255.i)
  %75 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %67, <8 x i64> %_14.i, <8 x i64> %_255.i)
  %76 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %75, <8 x i64> %_20.i, <8 x i64> %_255.i)
  %77 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %69, <8 x i64> %_20.i, <8 x i64> %_255.i)
  %78 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %77, <8 x i64> %_25.i, <8 x i64> %_255.i)
  %79 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %71, <8 x i64> %_25.i, <8 x i64> %_255.i)
  %80 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %79, <8 x i64> %_30.i, <8 x i64> %_255.i)
  %81 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %72, <8 x i64> %_30.i, <8 x i64> %_255.i)
  %82 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %81, <8 x i64> %_35.i, <8 x i64> %_255.i)
  %83 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_255.i)
  %84 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %74, <8 x i64> splat (i64 551490712240127))
  %85 = and <8 x i64> %84, splat (i64 4503599627370495)
  %_3.i13 = add <8 x i64> %74, splat (i64 4503599627370495)
  %_3.i14 = lshr <8 x i64> %_3.i13, splat (i64 52)
  %86 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i14, <8 x i64> %85, <8 x i64> splat (i64 551490712240129))
  %87 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %76, <8 x i64> %85, <8 x i64> %0)
  %88 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %78, <8 x i64> %85, <8 x i64> %0)
  %89 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %88, <8 x i64> %85, <8 x i64> %1)
  %90 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %80, <8 x i64> %85, <8 x i64> %1)
  %91 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %90, <8 x i64> %85, <8 x i64> %2)
  %92 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %82, <8 x i64> %85, <8 x i64> %2)
  %93 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %92, <8 x i64> %85, <8 x i64> %3)
  %94 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %83, <8 x i64> %85, <8 x i64> %3)
  %_3.i15 = add <8 x i64> %87, %86
  %95 = getelementptr inbounds nuw i8, ptr %b, i64 256
  %_436.i = load <8 x i64>, ptr %95, align 64, !alias.scope !47, !noalias !56
  %96 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %_3.i15, <8 x i64> %_14.i, <8 x i64> %_436.i)
  %97 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %89, <8 x i64> %_14.i, <8 x i64> %_436.i)
  %98 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %97, <8 x i64> %_20.i, <8 x i64> %_436.i)
  %99 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %91, <8 x i64> %_20.i, <8 x i64> %_436.i)
  %100 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %99, <8 x i64> %_25.i, <8 x i64> %_436.i)
  %101 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %93, <8 x i64> %_25.i, <8 x i64> %_436.i)
  %102 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %101, <8 x i64> %_30.i, <8 x i64> %_436.i)
  %103 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %94, <8 x i64> %_30.i, <8 x i64> %_436.i)
  %104 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %103, <8 x i64> %_35.i, <8 x i64> %_436.i)
  %105 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> zeroinitializer, <8 x i64> %_35.i, <8 x i64> %_436.i)
  %106 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> zeroinitializer, <8 x i64> %96, <8 x i64> splat (i64 551490712240127))
  %107 = and <8 x i64> %106, splat (i64 4503599627370495)
  %_3.i17 = add <8 x i64> %96, splat (i64 4503599627370495)
  %_3.i18 = lshr <8 x i64> %_3.i17, splat (i64 52)
  %108 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %_3.i18, <8 x i64> %107, <8 x i64> splat (i64 551490712240129))
  %109 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %98, <8 x i64> %107, <8 x i64> %0)
  %110 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %100, <8 x i64> %107, <8 x i64> %0)
  %111 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %110, <8 x i64> %107, <8 x i64> %1)
  %112 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %102, <8 x i64> %107, <8 x i64> %1)
  %113 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %112, <8 x i64> %107, <8 x i64> %2)
  %114 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %104, <8 x i64> %107, <8 x i64> %2)
  %115 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64> %114, <8 x i64> %107, <8 x i64> %3)
  %116 = tail call <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64> %105, <8 x i64> %107, <8 x i64> %3)
  %_3.i19 = add <8 x i64> %109, %108
  %_3.i20 = lshr <8 x i64> %_3.i19, splat (i64 52)
  %_3.i21 = add <8 x i64> %_3.i20, %111
  %117 = and <8 x i64> %_3.i19, splat (i64 4503599627370495)
  %_3.i20.1 = lshr <8 x i64> %_3.i21, splat (i64 52)
  %_3.i21.1 = add <8 x i64> %_3.i20.1, %113
  %118 = and <8 x i64> %_3.i21, splat (i64 4503599627370495)
  %_3.i20.2 = lshr <8 x i64> %_3.i21.1, splat (i64 52)
  %_3.i21.2 = add <8 x i64> %_3.i20.2, %115
  %119 = and <8 x i64> %_3.i21.1, splat (i64 4503599627370495)
  %_3.i20.3 = lshr <8 x i64> %_3.i21.2, splat (i64 52)
  %_3.i21.3 = add <8 x i64> %_3.i20.3, %116
  %120 = and <8 x i64> %_3.i21.2, splat (i64 4503599627370495)
  store <8 x i64> %117, ptr %_0, align 64, !alias.scope !42, !noalias !57
  %result.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 64
  store <8 x i64> %118, ptr %result.sroa.4.0._0.sroa_idx.i, align 64, !alias.scope !42, !noalias !57
  %result.sroa.5.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 128
  store <8 x i64> %119, ptr %result.sroa.5.0._0.sroa_idx.i, align 64, !alias.scope !42, !noalias !57
  %result.sroa.6.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 192
  store <8 x i64> %120, ptr %result.sroa.6.0._0.sroa_idx.i, align 64, !alias.scope !42, !noalias !57
  %result.sroa.7.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 256
  store <8 x i64> %_3.i21.3, ptr %result.sroa.7.0._0.sroa_idx.i, align 64, !alias.scope !42, !noalias !57
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: nounwind nonlazybind uwtable
declare noundef range(i32 0, 10) i32 @rust_eh_personality(i32 noundef, i32 noundef, i64 noundef, ptr noundef, ptr noundef) unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(none)
declare <8 x i64> @llvm.x86.avx512.vpmadd52h.uq.512(<8 x i64>, <8 x i64>, <8 x i64>) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(none)
declare <8 x i64> @llvm.x86.avx512.vpmadd52l.uq.512(<8 x i64>, <8 x i64>, <8 x i64>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #4

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind nonlazybind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "probe-stack"="inline-asm" "target-cpu"="znver5" "target-features"="+prfchw,-cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,-avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,+avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,-amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,-serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,-amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,-amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,+clzero,+mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,+rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,+prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,+shstk,+vaes,-waitpkg,-sgx,+fxsr,+avx512dq,+sse4a" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="znver5" "target-features"="+prfchw,-cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,-avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,+avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,-amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,-serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,-amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,-amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,+clzero,+mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,+rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,+prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,+shstk,+vaes,-waitpkg,-sgx,+fxsr,+avx512dq,+sse4a" }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 2, !"RtLibUseGOT", i32 1}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{!"rustc version 1.98.1 (48a229cea 2026-09-01)"}
!4 = !{!5}
!5 = distinct !{!5, !6, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb0_ECs5mtJiiTyqm0_10tune_probe: %_0"}
!6 = distinct !{!6, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb0_ECs5mtJiiTyqm0_10tune_probe"}
!7 = !{!8}
!8 = distinct !{!8, !6, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb0_ECs5mtJiiTyqm0_10tune_probe: %self"}
!9 = !{!10}
!10 = distinct !{!10, !6, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb0_ECs5mtJiiTyqm0_10tune_probe: %b"}
!11 = !{!5, !8, !10}
!12 = !{!13}
!13 = distinct !{!13, !14, !"_RINvMsm_NtCsgxBkk5gSRhY_4core5arrayAyj5_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitNtNtNtB8_9core_arch3x867___m512iENCINvMBN_BK_10wrap_mut_1yNvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB2s_5Ifma8NtB2u_8FqConfigE5splatE0ECs5mtJiiTyqm0_10tune_probe: %self"}
!14 = distinct !{!14, !"_RINvMsm_NtCsgxBkk5gSRhY_4core5arrayAyj5_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitNtNtNtB8_9core_arch3x867___m512iENCINvMBN_BK_10wrap_mut_1yNvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB2s_5Ifma8NtB2u_8FqConfigE5splatE0ECs5mtJiiTyqm0_10tune_probe"}
!15 = !{!16, !5, !8, !10}
!16 = distinct !{!16, !14, !"_RINvMsm_NtCsgxBkk5gSRhY_4core5arrayAyj5_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitNtNtNtB8_9core_arch3x867___m512iENCINvMBN_BK_10wrap_mut_1yNvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB2s_5Ifma8NtB2u_8FqConfigE5splatE0ECs5mtJiiTyqm0_10tune_probe: %_0"}
!17 = !{!5, !10}
!18 = !{!5, !8}
!19 = !{!8, !10}
!20 = !{!21}
!21 = distinct !{!21, !22, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb1_ECs5mtJiiTyqm0_10tune_probe: %_0"}
!22 = distinct !{!22, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb1_ECs5mtJiiTyqm0_10tune_probe"}
!23 = !{!24}
!24 = distinct !{!24, !22, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb1_ECs5mtJiiTyqm0_10tune_probe: %self"}
!25 = !{!26}
!26 = distinct !{!26, !22, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb1_ECs5mtJiiTyqm0_10tune_probe: %b"}
!27 = !{!28}
!28 = distinct !{!28, !22, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb1_ECs5mtJiiTyqm0_10tune_probe: %c"}
!29 = !{!30}
!30 = distinct !{!30, !22, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FqConfigE12product_ciosKb1_ECs5mtJiiTyqm0_10tune_probe: %d"}
!31 = !{!21, !24, !26, !28, !30}
!32 = !{!33}
!33 = distinct !{!33, !34, !"_RINvMsm_NtCsgxBkk5gSRhY_4core5arrayAyj5_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitNtNtNtB8_9core_arch3x867___m512iENCINvMBN_BK_10wrap_mut_1yNvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB2s_5Ifma8NtB2u_8FqConfigE5splatE0ECs5mtJiiTyqm0_10tune_probe: %self"}
!34 = distinct !{!34, !"_RINvMsm_NtCsgxBkk5gSRhY_4core5arrayAyj5_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitNtNtNtB8_9core_arch3x867___m512iENCINvMBN_BK_10wrap_mut_1yNvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB2s_5Ifma8NtB2u_8FqConfigE5splatE0ECs5mtJiiTyqm0_10tune_probe"}
!35 = !{!36, !21, !24, !26, !28, !30}
!36 = distinct !{!36, !34, !"_RINvMsm_NtCsgxBkk5gSRhY_4core5arrayAyj5_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitNtNtNtB8_9core_arch3x867___m512iENCINvMBN_BK_10wrap_mut_1yNvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB2s_5Ifma8NtB2u_8FqConfigE5splatE0ECs5mtJiiTyqm0_10tune_probe: %_0"}
!37 = !{!21, !26, !28, !30}
!38 = !{!21, !24, !28, !30}
!39 = !{!21, !24, !26, !30}
!40 = !{!21, !24, !26, !28}
!41 = !{!24, !26, !28, !30}
!42 = !{!43}
!43 = distinct !{!43, !44, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FrConfigE12product_ciosKb0_ECs5mtJiiTyqm0_10tune_probe: %_0"}
!44 = distinct !{!44, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FrConfigE12product_ciosKb0_ECs5mtJiiTyqm0_10tune_probe"}
!45 = !{!46}
!46 = distinct !{!46, !44, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FrConfigE12product_ciosKb0_ECs5mtJiiTyqm0_10tune_probe: %self"}
!47 = !{!48}
!48 = distinct !{!48, !44, !"_RINvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB5_5Ifma8NtB7_8FrConfigE12product_ciosKb0_ECs5mtJiiTyqm0_10tune_probe: %b"}
!49 = !{!43, !46, !48}
!50 = !{!51}
!51 = distinct !{!51, !52, !"_RINvMsm_NtCsgxBkk5gSRhY_4core5arrayAyj5_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitNtNtNtB8_9core_arch3x867___m512iENCINvMBN_BK_10wrap_mut_1yNvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB2s_5Ifma8NtB2u_8FrConfigE5splatE0ECs5mtJiiTyqm0_10tune_probe: %self"}
!52 = distinct !{!52, !"_RINvMsm_NtCsgxBkk5gSRhY_4core5arrayAyj5_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitNtNtNtB8_9core_arch3x867___m512iENCINvMBN_BK_10wrap_mut_1yNvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB2s_5Ifma8NtB2u_8FrConfigE5splatE0ECs5mtJiiTyqm0_10tune_probe"}
!53 = !{!54, !43, !46, !48}
!54 = distinct !{!54, !52, !"_RINvMsm_NtCsgxBkk5gSRhY_4core5arrayAyj5_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitNtNtNtB8_9core_arch3x867___m512iENCINvMBN_BK_10wrap_mut_1yNvMs_NtCsgHCcee0nhgM_11zopro_bn2545ifma8INtB2s_5Ifma8NtB2u_8FrConfigE5splatE0ECs5mtJiiTyqm0_10tune_probe: %_0"}
!55 = !{!43, !48}
!56 = !{!43, !46}
!57 = !{!46, !48}
