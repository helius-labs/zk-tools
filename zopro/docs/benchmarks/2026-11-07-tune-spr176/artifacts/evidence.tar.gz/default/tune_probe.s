	.file	"tune_probe.3e76117d9c4d24de-cgu.0"
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI0_0:
	.quad	154029749239111
	.quad	2558044347618242
	.quad	423691504025962
	.quad	2817616741948264
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI0_1:
	.quad	571208714576777
.LCPI0_2:
	.quad	4503599627370495
.LCPI0_3:
	.quad	154029749239111
	.section	.text.tune_fq_mul,"ax",@progbits
	.globl	tune_fq_mul
	.p2align	4
	.type	tune_fq_mul,@function
tune_fq_mul:
	.cfi_startproc
	vmovaps	.LCPI0_0(%rip), %ymm0
	vmovdqa64	(%rsi), %zmm9
	vmovdqa64	64(%rsi), %zmm8
	vmovdqa64	128(%rsi), %zmm7
	vmovdqa64	192(%rsi), %zmm6
	vmovdqa64	(%rdx), %zmm5
	vmovdqa64	256(%rsi), %zmm11
	vpbroadcastq	.LCPI0_1(%rip), %zmm12
	movabsq	$53207371014449, %rcx
	vpxor	%xmm13, %xmm13, %xmm13
	vpxord	%xmm20, %xmm20, %xmm20
	vpxord	%xmm19, %xmm19, %xmm19
	vpxord	%xmm16, %xmm16, %xmm16
	vpbroadcastq	.LCPI0_2(%rip), %zmm24
	vpxor	%xmm14, %xmm14, %xmm14
	vpbroadcastq	.LCPI0_3(%rip), %zmm23
	vpxord	%xmm21, %xmm21, %xmm21
	vpxor	%xmm10, %xmm10, %xmm10
	vmovdqa64	64(%rdx), %zmm17
	vmovdqa64	128(%rdx), %zmm18
	vmovdqa64	192(%rdx), %zmm15
	vpxor	%xmm1, %xmm1, %xmm1
	movq	%rdi, %rax
	vmovups	%ymm0, -40(%rsp)
	movq	%rcx, -8(%rsp)
	vpmadd52huq	%zmm5, %zmm8, %zmm20
	vpmadd52huq	%zmm5, %zmm7, %zmm19
	vpmadd52huq	%zmm5, %zmm6, %zmm16
	vpmadd52luq	%zmm5, %zmm9, %zmm13
	vpmadd52huq	%zmm5, %zmm9, %zmm14
	vpmadd52huq	%zmm5, %zmm11, %zmm10
	vpbroadcastq	-32(%rsp), %zmm4
	vpbroadcastq	-24(%rsp), %zmm3
	vpbroadcastq	-16(%rsp), %zmm2
	vpbroadcastq	-8(%rsp), %zmm0
	vpmadd52luq	%zmm12, %zmm13, %zmm21
	vpmadd52luq	%zmm5, %zmm7, %zmm20
	vpmadd52luq	%zmm5, %zmm6, %zmm19
	vpmadd52luq	%zmm5, %zmm11, %zmm16
	vpmadd52luq	%zmm5, %zmm8, %zmm14
	vpaddq	%zmm24, %zmm13, %zmm13
	vpsrlq	$52, %zmm13, %zmm22
	vpmadd52huq	%zmm23, %zmm21, %zmm22
	vpmadd52huq	%zmm4, %zmm21, %zmm20
	vpmadd52huq	%zmm3, %zmm21, %zmm19
	vpmadd52huq	%zmm2, %zmm21, %zmm16
	vpmadd52luq	%zmm4, %zmm21, %zmm14
	vpmadd52huq	%zmm0, %zmm21, %zmm10
	vpmadd52luq	%zmm3, %zmm21, %zmm20
	vpmadd52luq	%zmm2, %zmm21, %zmm19
	vpmadd52luq	%zmm0, %zmm21, %zmm16
	vpaddq	%zmm22, %zmm14, %zmm22
	vpmadd52huq	%zmm17, %zmm6, %zmm10
	vpxor	%xmm14, %xmm14, %xmm14
	vpmadd52huq	%zmm17, %zmm11, %zmm14
	vpmadd52luq	%zmm17, %zmm9, %zmm22
	vpmadd52huq	%zmm17, %zmm9, %zmm20
	vpmadd52huq	%zmm17, %zmm8, %zmm19
	vpmadd52huq	%zmm17, %zmm7, %zmm16
	vpmadd52luq	%zmm17, %zmm11, %zmm10
	vpaddq	%zmm24, %zmm22, %zmm21
	vpsrlq	$52, %zmm21, %zmm21
	vpmadd52luq	%zmm17, %zmm8, %zmm20
	vpmadd52luq	%zmm17, %zmm7, %zmm19
	vpmadd52luq	%zmm17, %zmm6, %zmm16
	vpxord	%xmm17, %xmm17, %xmm17
	vpmadd52luq	%zmm12, %zmm22, %zmm17
	vpmadd52huq	%zmm4, %zmm17, %zmm19
	vpmadd52huq	%zmm3, %zmm17, %zmm16
	vpmadd52huq	%zmm2, %zmm17, %zmm10
	vpmadd52huq	%zmm23, %zmm17, %zmm21
	vpmadd52luq	%zmm4, %zmm17, %zmm20
	vpmadd52huq	%zmm0, %zmm17, %zmm14
	vpmadd52luq	%zmm3, %zmm17, %zmm19
	vpmadd52luq	%zmm2, %zmm17, %zmm16
	vpmadd52luq	%zmm0, %zmm17, %zmm10
	vpaddq	%zmm21, %zmm20, %zmm20
	vpmadd52huq	%zmm18, %zmm6, %zmm14
	vpxord	%xmm17, %xmm17, %xmm17
	vpmadd52huq	%zmm18, %zmm11, %zmm17
	vpmadd52luq	%zmm18, %zmm9, %zmm20
	vpmadd52huq	%zmm18, %zmm9, %zmm19
	vpmadd52huq	%zmm18, %zmm8, %zmm16
	vpmadd52huq	%zmm18, %zmm7, %zmm10
	vpmadd52luq	%zmm18, %zmm11, %zmm14
	vpmadd52luq	%zmm18, %zmm8, %zmm19
	vpmadd52luq	%zmm18, %zmm7, %zmm16
	vpmadd52luq	%zmm18, %zmm6, %zmm10
	vpxord	%xmm18, %xmm18, %xmm18
	vpmadd52luq	%zmm12, %zmm20, %zmm18
	vpaddq	%zmm24, %zmm20, %zmm20
	vpsrlq	$52, %zmm20, %zmm20
	vpmadd52huq	%zmm4, %zmm18, %zmm16
	vpmadd52huq	%zmm3, %zmm18, %zmm10
	vpmadd52huq	%zmm2, %zmm18, %zmm14
	vpmadd52huq	%zmm23, %zmm18, %zmm20
	vpmadd52luq	%zmm4, %zmm18, %zmm19
	vpmadd52huq	%zmm0, %zmm18, %zmm17
	vpmadd52luq	%zmm3, %zmm18, %zmm16
	vpmadd52luq	%zmm2, %zmm18, %zmm10
	vpmadd52luq	%zmm0, %zmm18, %zmm14
	vpaddq	%zmm20, %zmm19, %zmm19
	vpmadd52huq	%zmm15, %zmm6, %zmm17
	vpxord	%xmm18, %xmm18, %xmm18
	vpmadd52huq	%zmm15, %zmm11, %zmm18
	vpmadd52luq	%zmm15, %zmm9, %zmm19
	vpmadd52huq	%zmm15, %zmm9, %zmm16
	vpmadd52huq	%zmm15, %zmm8, %zmm10
	vpmadd52huq	%zmm15, %zmm7, %zmm14
	vpmadd52luq	%zmm15, %zmm11, %zmm17
	vpmadd52luq	%zmm15, %zmm8, %zmm16
	vpmadd52luq	%zmm15, %zmm7, %zmm10
	vpmadd52luq	%zmm15, %zmm6, %zmm14
	vpxor	%xmm15, %xmm15, %xmm15
	vpmadd52luq	%zmm12, %zmm19, %zmm15
	vpaddq	%zmm24, %zmm19, %zmm19
	vpsrlq	$52, %zmm19, %zmm19
	vpmadd52huq	%zmm23, %zmm15, %zmm19
	vpmadd52luq	%zmm4, %zmm15, %zmm16
	vpmadd52huq	%zmm3, %zmm15, %zmm14
	vpmadd52huq	%zmm4, %zmm15, %zmm10
	vpmadd52huq	%zmm2, %zmm15, %zmm17
	vpmadd52huq	%zmm0, %zmm15, %zmm18
	vpaddq	%zmm19, %zmm16, %zmm16
	vmovdqa64	256(%rdx), %zmm19
	vpmadd52luq	%zmm2, %zmm15, %zmm14
	vpmadd52luq	%zmm3, %zmm15, %zmm10
	vpmadd52luq	%zmm0, %zmm15, %zmm17
	vpmadd52huq	%zmm19, %zmm8, %zmm14
	vpmadd52luq	%zmm19, %zmm9, %zmm16
	vpmadd52huq	%zmm19, %zmm9, %zmm10
	vpmadd52huq	%zmm19, %zmm7, %zmm17
	vpmadd52huq	%zmm19, %zmm6, %zmm18
	vpmadd52luq	%zmm19, %zmm7, %zmm14
	vpmadd52luq	%zmm12, %zmm16, %zmm1
	vpmadd52luq	%zmm19, %zmm6, %zmm17
	vpmadd52luq	%zmm19, %zmm8, %zmm10
	vpmadd52luq	%zmm19, %zmm11, %zmm18
	vpaddq	%zmm24, %zmm16, %zmm7
	vpxor	%xmm6, %xmm6, %xmm6
	vpmadd52huq	%zmm19, %zmm11, %zmm6
	vpsrlq	$52, %zmm7, %zmm7
	vpmadd52huq	%zmm4, %zmm1, %zmm14
	vpmadd52huq	%zmm3, %zmm1, %zmm17
	vpmadd52huq	%zmm23, %zmm1, %zmm7
	vpmadd52luq	%zmm4, %zmm1, %zmm10
	vpmadd52huq	%zmm2, %zmm1, %zmm18
	vpmadd52huq	%zmm0, %zmm1, %zmm6
	vpmadd52luq	%zmm3, %zmm1, %zmm14
	vpaddq	%zmm7, %zmm10, %zmm7
	vpmadd52luq	%zmm2, %zmm1, %zmm17
	vpmadd52luq	%zmm0, %zmm1, %zmm18
	vpsrlq	$52, %zmm7, %zmm0
	vpandq	%zmm24, %zmm7, %zmm1
	vmovdqa64	%zmm1, (%rdi)
	vpaddq	%zmm14, %zmm0, %zmm0
	vpsrlq	$52, %zmm0, %zmm2
	vpandq	%zmm24, %zmm0, %zmm0
	vpaddq	%zmm17, %zmm2, %zmm2
	vmovdqa64	%zmm0, 64(%rdi)
	vpsrlq	$52, %zmm2, %zmm3
	vpandq	%zmm24, %zmm2, %zmm2
	vpaddq	%zmm18, %zmm3, %zmm3
	vmovdqa64	%zmm2, 128(%rdi)
	vpsrlq	$52, %zmm3, %zmm4
	vpandq	%zmm24, %zmm3, %zmm3
	vpaddq	%zmm6, %zmm4, %zmm4
	vmovdqa64	%zmm3, 192(%rdi)
	vmovdqa64	%zmm4, 256(%rdi)
	vzeroupper
	retq
.Lfunc_end0:
	.size	tune_fq_mul, .Lfunc_end0-tune_fq_mul
	.cfi_endproc

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI1_0:
	.quad	154029749239111
	.quad	2558044347618242
	.quad	423691504025962
	.quad	2817616741948264
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI1_1:
	.quad	571208714576777
.LCPI1_2:
	.quad	4503599627370495
.LCPI1_3:
	.quad	154029749239111
	.section	.text.tune_fq_sum,"ax",@progbits
	.globl	tune_fq_sum
	.p2align	4
	.type	tune_fq_sum,@function
tune_fq_sum:
	.cfi_startproc
	vmovdqa64	(%rsi), %zmm11
	vmovdqa64	64(%rsi), %zmm9
	vmovdqa64	128(%rsi), %zmm8
	vmovdqa64	192(%rsi), %zmm7
	vmovdqa64	(%rdx), %zmm6
	vmovdqa64	256(%rsi), %zmm14
	vpxord	%xmm19, %xmm19, %xmm19
	vpxord	%xmm24, %xmm24, %xmm24
	vpxord	%xmm23, %xmm23, %xmm23
	vpxord	%xmm20, %xmm20, %xmm20
	vmovdqa64	(%rcx), %zmm15
	vmovdqa64	64(%rcx), %zmm13
	vmovdqa64	128(%rcx), %zmm12
	vmovdqa64	192(%rcx), %zmm10
	vmovdqa64	(%r8), %zmm17
	vmovdqa64	256(%rcx), %zmm16
	vmovaps	.LCPI1_0(%rip), %ymm0
	vpxord	%xmm18, %xmm18, %xmm18
	vpxor	%xmm5, %xmm5, %xmm5
	movq	%rdi, %rax
	movabsq	$53207371014449, %rdi
	vpxord	%xmm29, %xmm29, %xmm29
	vpbroadcastq	.LCPI1_3(%rip), %zmm31
	vmovdqa64	64(%rdx), %zmm27
	vmovdqa64	64(%r8), %zmm28
	vmovdqa64	128(%rdx), %zmm25
	vmovdqa64	128(%r8), %zmm26
	vmovdqa64	192(%rdx), %zmm21
	vmovdqa64	192(%r8), %zmm22
	vpxor	%xmm1, %xmm1, %xmm1
	vpmadd52huq	%zmm6, %zmm11, %zmm19
	vpmadd52huq	%zmm6, %zmm9, %zmm24
	vpmadd52huq	%zmm6, %zmm8, %zmm23
	vpmadd52huq	%zmm6, %zmm7, %zmm20
	vpmadd52luq	%zmm6, %zmm11, %zmm18
	vpmadd52huq	%zmm6, %zmm14, %zmm5
	vmovups	%ymm0, -40(%rsp)
	movq	%rdi, -8(%rsp)
	vpbroadcastq	-16(%rsp), %zmm2
	vpbroadcastq	-8(%rsp), %zmm0
	vpbroadcastq	-32(%rsp), %zmm4
	vpbroadcastq	-24(%rsp), %zmm3
	vpmadd52luq	%zmm6, %zmm9, %zmm19
	vpmadd52luq	%zmm6, %zmm8, %zmm24
	vpmadd52luq	%zmm6, %zmm7, %zmm23
	vpmadd52luq	%zmm6, %zmm14, %zmm20
	vpmadd52luq	%zmm17, %zmm15, %zmm18
	vpmadd52huq	%zmm17, %zmm16, %zmm5
	vpbroadcastq	.LCPI1_2(%rip), %zmm6
	vpmadd52huq	%zmm17, %zmm15, %zmm19
	vpmadd52huq	%zmm17, %zmm13, %zmm24
	vpmadd52huq	%zmm17, %zmm12, %zmm23
	vpmadd52huq	%zmm17, %zmm10, %zmm20
	vpmadd52luq	%zmm17, %zmm13, %zmm19
	vpmadd52luq	%zmm17, %zmm12, %zmm24
	vpmadd52luq	%zmm17, %zmm10, %zmm23
	vpmadd52luq	%zmm17, %zmm16, %zmm20
	vpbroadcastq	.LCPI1_1(%rip), %zmm17
	vpmadd52luq	%zmm17, %zmm18, %zmm29
	vpaddq	%zmm6, %zmm18, %zmm18
	vpsrlq	$52, %zmm18, %zmm30
	vpmadd52huq	%zmm2, %zmm29, %zmm20
	vpmadd52huq	%zmm0, %zmm29, %zmm5
	vpmadd52huq	%zmm4, %zmm29, %zmm24
	vpmadd52huq	%zmm3, %zmm29, %zmm23
	vpmadd52huq	%zmm31, %zmm29, %zmm30
	vpmadd52luq	%zmm4, %zmm29, %zmm19
	vpmadd52luq	%zmm0, %zmm29, %zmm20
	vpmadd52huq	%zmm27, %zmm7, %zmm5
	vpaddq	%zmm30, %zmm19, %zmm30
	vpmadd52luq	%zmm3, %zmm29, %zmm24
	vpmadd52luq	%zmm2, %zmm29, %zmm23
	vpxord	%xmm19, %xmm19, %xmm19
	vpmadd52huq	%zmm27, %zmm14, %zmm19
	vpmadd52luq	%zmm27, %zmm11, %zmm30
	vpmadd52huq	%zmm27, %zmm8, %zmm20
	vpmadd52luq	%zmm27, %zmm14, %zmm5
	vpmadd52huq	%zmm27, %zmm11, %zmm24
	vpmadd52huq	%zmm27, %zmm9, %zmm23
	vpmadd52huq	%zmm28, %zmm16, %zmm19
	vpmadd52luq	%zmm28, %zmm15, %zmm30
	vpmadd52luq	%zmm27, %zmm7, %zmm20
	vpmadd52huq	%zmm28, %zmm10, %zmm5
	vpmadd52luq	%zmm27, %zmm9, %zmm24
	vpmadd52luq	%zmm27, %zmm8, %zmm23
	vpxord	%xmm27, %xmm27, %xmm27
	vpmadd52luq	%zmm17, %zmm30, %zmm27
	vpmadd52huq	%zmm28, %zmm12, %zmm20
	vpmadd52luq	%zmm28, %zmm16, %zmm5
	vpmadd52huq	%zmm28, %zmm15, %zmm24
	vpmadd52huq	%zmm28, %zmm13, %zmm23
	vpmadd52huq	%zmm0, %zmm27, %zmm19
	vpmadd52luq	%zmm28, %zmm10, %zmm20
	vpmadd52huq	%zmm2, %zmm27, %zmm5
	vpmadd52luq	%zmm28, %zmm13, %zmm24
	vpmadd52luq	%zmm28, %zmm12, %zmm23
	vpaddq	%zmm6, %zmm30, %zmm28
	vpsrlq	$52, %zmm28, %zmm28
	vpmadd52huq	%zmm25, %zmm7, %zmm19
	vpmadd52huq	%zmm31, %zmm27, %zmm28
	vpmadd52huq	%zmm3, %zmm27, %zmm20
	vpmadd52luq	%zmm0, %zmm27, %zmm5
	vpmadd52huq	%zmm4, %zmm27, %zmm23
	vpmadd52luq	%zmm4, %zmm27, %zmm24
	vpmadd52luq	%zmm25, %zmm14, %zmm19
	vpmadd52luq	%zmm2, %zmm27, %zmm20
	vpmadd52huq	%zmm25, %zmm8, %zmm5
	vpaddq	%zmm28, %zmm24, %zmm28
	vpmadd52luq	%zmm3, %zmm27, %zmm23
	vpxord	%xmm24, %xmm24, %xmm24
	vpmadd52huq	%zmm25, %zmm14, %zmm24
	vpmadd52luq	%zmm25, %zmm11, %zmm28
	vpmadd52huq	%zmm26, %zmm10, %zmm19
	vpmadd52huq	%zmm25, %zmm9, %zmm20
	vpmadd52luq	%zmm25, %zmm7, %zmm5
	vpmadd52huq	%zmm25, %zmm11, %zmm23
	vpmadd52huq	%zmm26, %zmm16, %zmm24
	vpmadd52luq	%zmm26, %zmm15, %zmm28
	vpmadd52luq	%zmm26, %zmm16, %zmm19
	vpmadd52luq	%zmm25, %zmm8, %zmm20
	vpmadd52huq	%zmm26, %zmm12, %zmm5
	vpmadd52luq	%zmm25, %zmm9, %zmm23
	vpxord	%xmm25, %xmm25, %xmm25
	vpmadd52luq	%zmm17, %zmm28, %zmm25
	vpmadd52huq	%zmm26, %zmm13, %zmm20
	vpmadd52luq	%zmm26, %zmm10, %zmm5
	vpmadd52huq	%zmm26, %zmm15, %zmm23
	vpmadd52huq	%zmm2, %zmm25, %zmm19
	vpmadd52huq	%zmm0, %zmm25, %zmm24
	vpmadd52luq	%zmm26, %zmm12, %zmm20
	vpmadd52huq	%zmm3, %zmm25, %zmm5
	vpmadd52luq	%zmm26, %zmm13, %zmm23
	vpaddq	%zmm6, %zmm28, %zmm26
	vpsrlq	$52, %zmm26, %zmm26
	vpmadd52luq	%zmm0, %zmm25, %zmm19
	vpmadd52huq	%zmm21, %zmm7, %zmm24
	vpmadd52huq	%zmm31, %zmm25, %zmm26
	vpmadd52huq	%zmm4, %zmm25, %zmm20
	vpmadd52luq	%zmm2, %zmm25, %zmm5
	vpmadd52luq	%zmm4, %zmm25, %zmm23
	vpmadd52huq	%zmm21, %zmm8, %zmm19
	vpmadd52luq	%zmm21, %zmm14, %zmm24
	vpmadd52luq	%zmm3, %zmm25, %zmm20
	vpmadd52huq	%zmm21, %zmm9, %zmm5
	vpaddq	%zmm26, %zmm23, %zmm26
	vpxord	%xmm23, %xmm23, %xmm23
	vpmadd52huq	%zmm21, %zmm14, %zmm23
	vpmadd52luq	%zmm21, %zmm11, %zmm26
	vpmadd52luq	%zmm21, %zmm7, %zmm19
	vpmadd52huq	%zmm22, %zmm10, %zmm24
	vpmadd52huq	%zmm21, %zmm11, %zmm20
	vpmadd52luq	%zmm21, %zmm8, %zmm5
	vpmadd52huq	%zmm22, %zmm16, %zmm23
	vpmadd52luq	%zmm22, %zmm15, %zmm26
	vpmadd52huq	%zmm22, %zmm12, %zmm19
	vpmadd52luq	%zmm22, %zmm16, %zmm24
	vpmadd52luq	%zmm21, %zmm9, %zmm20
	vpmadd52huq	%zmm22, %zmm13, %zmm5
	vpxord	%xmm21, %xmm21, %xmm21
	vpmadd52luq	%zmm17, %zmm26, %zmm21
	vpmadd52luq	%zmm22, %zmm10, %zmm19
	vpmadd52huq	%zmm22, %zmm15, %zmm20
	vpmadd52luq	%zmm22, %zmm12, %zmm5
	vpmadd52huq	%zmm3, %zmm21, %zmm19
	vpmadd52huq	%zmm2, %zmm21, %zmm24
	vpmadd52huq	%zmm0, %zmm21, %zmm23
	vpmadd52luq	%zmm22, %zmm13, %zmm20
	vpaddq	%zmm6, %zmm26, %zmm22
	vpmadd52huq	%zmm4, %zmm21, %zmm5
	vpsrlq	$52, %zmm22, %zmm22
	vpmadd52luq	%zmm2, %zmm21, %zmm19
	vpmadd52luq	%zmm0, %zmm21, %zmm24
	vpmadd52huq	%zmm31, %zmm21, %zmm22
	vpmadd52luq	%zmm4, %zmm21, %zmm20
	vpmadd52luq	%zmm3, %zmm21, %zmm5
	vpaddq	%zmm22, %zmm20, %zmm20
	vmovdqa64	256(%rdx), %zmm22
	vpmadd52huq	%zmm22, %zmm11, %zmm5
	vpmadd52huq	%zmm22, %zmm9, %zmm19
	vpmadd52huq	%zmm22, %zmm8, %zmm24
	vpmadd52huq	%zmm22, %zmm7, %zmm23
	vpmadd52luq	%zmm22, %zmm11, %zmm20
	vpmadd52luq	%zmm22, %zmm9, %zmm5
	vmovdqa64	256(%r8), %zmm9
	vpmadd52luq	%zmm22, %zmm8, %zmm19
	vpmadd52luq	%zmm22, %zmm7, %zmm24
	vpmadd52luq	%zmm22, %zmm14, %zmm23
	vpxor	%xmm7, %xmm7, %xmm7
	vpmadd52huq	%zmm22, %zmm14, %zmm7
	vpmadd52luq	%zmm9, %zmm15, %zmm20
	vpmadd52huq	%zmm9, %zmm13, %zmm19
	vpmadd52huq	%zmm9, %zmm15, %zmm5
	vpmadd52huq	%zmm9, %zmm12, %zmm24
	vpmadd52huq	%zmm9, %zmm10, %zmm23
	vpmadd52huq	%zmm9, %zmm16, %zmm7
	vpmadd52luq	%zmm17, %zmm20, %zmm1
	vpmadd52luq	%zmm9, %zmm12, %zmm19
	vpmadd52luq	%zmm9, %zmm13, %zmm5
	vpmadd52luq	%zmm9, %zmm10, %zmm24
	vpmadd52luq	%zmm9, %zmm16, %zmm23
	vpaddq	%zmm6, %zmm20, %zmm8
	vpsrlq	$52, %zmm8, %zmm8
	vpmadd52huq	%zmm4, %zmm1, %zmm19
	vpmadd52huq	%zmm3, %zmm1, %zmm24
	vpmadd52huq	%zmm31, %zmm1, %zmm8
	vpmadd52luq	%zmm4, %zmm1, %zmm5
	vpmadd52huq	%zmm2, %zmm1, %zmm23
	vpmadd52huq	%zmm0, %zmm1, %zmm7
	vpmadd52luq	%zmm3, %zmm1, %zmm19
	vpaddq	%zmm8, %zmm5, %zmm5
	vpmadd52luq	%zmm2, %zmm1, %zmm24
	vpmadd52luq	%zmm0, %zmm1, %zmm23
	vpsrlq	$52, %zmm5, %zmm0
	vpandq	%zmm6, %zmm5, %zmm1
	vmovdqa64	%zmm1, (%rax)
	vpaddq	%zmm19, %zmm0, %zmm0
	vpsrlq	$52, %zmm0, %zmm2
	vpandq	%zmm6, %zmm0, %zmm0
	vpaddq	%zmm24, %zmm2, %zmm2
	vmovdqa64	%zmm0, 64(%rax)
	vpsrlq	$52, %zmm2, %zmm3
	vpandq	%zmm6, %zmm2, %zmm2
	vpaddq	%zmm23, %zmm3, %zmm3
	vmovdqa64	%zmm2, 128(%rax)
	vpsrlq	$52, %zmm3, %zmm4
	vpandq	%zmm6, %zmm3, %zmm3
	vpaddq	%zmm7, %zmm4, %zmm4
	vmovdqa64	%zmm3, 192(%rax)
	vmovdqa64	%zmm4, 256(%rax)
	vzeroupper
	retq
.Lfunc_end1:
	.size	tune_fq_sum, .Lfunc_end1-tune_fq_sum
	.cfi_endproc

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI2_0:
	.quad	551490712240129
	.quad	1275002230477886
	.quad	423691496731624
	.quad	2817616741948264
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI2_1:
	.quad	551490712240127
.LCPI2_2:
	.quad	4503599627370495
.LCPI2_3:
	.quad	551490712240129
	.section	.text.tune_fr_mul,"ax",@progbits
	.globl	tune_fr_mul
	.p2align	4
	.type	tune_fr_mul,@function
tune_fr_mul:
	.cfi_startproc
	vmovaps	.LCPI2_0(%rip), %ymm0
	vmovdqa64	(%rsi), %zmm9
	vmovdqa64	64(%rsi), %zmm8
	vmovdqa64	128(%rsi), %zmm7
	vmovdqa64	192(%rsi), %zmm6
	vmovdqa64	(%rdx), %zmm5
	vmovdqa64	256(%rsi), %zmm11
	vpbroadcastq	.LCPI2_1(%rip), %zmm12
	movabsq	$53207371014449, %rcx
	vpxor	%xmm13, %xmm13, %xmm13
	vpxord	%xmm20, %xmm20, %xmm20
	vpxord	%xmm19, %xmm19, %xmm19
	vpxord	%xmm16, %xmm16, %xmm16
	vpbroadcastq	.LCPI2_2(%rip), %zmm24
	vpxor	%xmm14, %xmm14, %xmm14
	vpbroadcastq	.LCPI2_3(%rip), %zmm23
	vpxord	%xmm21, %xmm21, %xmm21
	vpxor	%xmm10, %xmm10, %xmm10
	vmovdqa64	64(%rdx), %zmm17
	vmovdqa64	128(%rdx), %zmm18
	vmovdqa64	192(%rdx), %zmm15
	vpxor	%xmm1, %xmm1, %xmm1
	movq	%rdi, %rax
	vmovups	%ymm0, -40(%rsp)
	movq	%rcx, -8(%rsp)
	vpmadd52huq	%zmm5, %zmm8, %zmm20
	vpmadd52huq	%zmm5, %zmm7, %zmm19
	vpmadd52huq	%zmm5, %zmm6, %zmm16
	vpmadd52luq	%zmm5, %zmm9, %zmm13
	vpmadd52huq	%zmm5, %zmm9, %zmm14
	vpmadd52huq	%zmm5, %zmm11, %zmm10
	vpbroadcastq	-32(%rsp), %zmm4
	vpbroadcastq	-24(%rsp), %zmm3
	vpbroadcastq	-16(%rsp), %zmm2
	vpbroadcastq	-8(%rsp), %zmm0
	vpmadd52luq	%zmm12, %zmm13, %zmm21
	vpmadd52luq	%zmm5, %zmm7, %zmm20
	vpmadd52luq	%zmm5, %zmm6, %zmm19
	vpmadd52luq	%zmm5, %zmm11, %zmm16
	vpmadd52luq	%zmm5, %zmm8, %zmm14
	vpaddq	%zmm24, %zmm13, %zmm13
	vpsrlq	$52, %zmm13, %zmm22
	vpmadd52huq	%zmm23, %zmm21, %zmm22
	vpmadd52huq	%zmm4, %zmm21, %zmm20
	vpmadd52huq	%zmm3, %zmm21, %zmm19
	vpmadd52huq	%zmm2, %zmm21, %zmm16
	vpmadd52luq	%zmm4, %zmm21, %zmm14
	vpmadd52huq	%zmm0, %zmm21, %zmm10
	vpmadd52luq	%zmm3, %zmm21, %zmm20
	vpmadd52luq	%zmm2, %zmm21, %zmm19
	vpmadd52luq	%zmm0, %zmm21, %zmm16
	vpaddq	%zmm22, %zmm14, %zmm22
	vpmadd52huq	%zmm17, %zmm6, %zmm10
	vpxor	%xmm14, %xmm14, %xmm14
	vpmadd52huq	%zmm17, %zmm11, %zmm14
	vpmadd52luq	%zmm17, %zmm9, %zmm22
	vpmadd52huq	%zmm17, %zmm9, %zmm20
	vpmadd52huq	%zmm17, %zmm8, %zmm19
	vpmadd52huq	%zmm17, %zmm7, %zmm16
	vpmadd52luq	%zmm17, %zmm11, %zmm10
	vpaddq	%zmm24, %zmm22, %zmm21
	vpsrlq	$52, %zmm21, %zmm21
	vpmadd52luq	%zmm17, %zmm8, %zmm20
	vpmadd52luq	%zmm17, %zmm7, %zmm19
	vpmadd52luq	%zmm17, %zmm6, %zmm16
	vpxord	%xmm17, %xmm17, %xmm17
	vpmadd52luq	%zmm12, %zmm22, %zmm17
	vpmadd52huq	%zmm4, %zmm17, %zmm19
	vpmadd52huq	%zmm3, %zmm17, %zmm16
	vpmadd52huq	%zmm2, %zmm17, %zmm10
	vpmadd52huq	%zmm23, %zmm17, %zmm21
	vpmadd52luq	%zmm4, %zmm17, %zmm20
	vpmadd52huq	%zmm0, %zmm17, %zmm14
	vpmadd52luq	%zmm3, %zmm17, %zmm19
	vpmadd52luq	%zmm2, %zmm17, %zmm16
	vpmadd52luq	%zmm0, %zmm17, %zmm10
	vpaddq	%zmm21, %zmm20, %zmm20
	vpmadd52huq	%zmm18, %zmm6, %zmm14
	vpxord	%xmm17, %xmm17, %xmm17
	vpmadd52huq	%zmm18, %zmm11, %zmm17
	vpmadd52luq	%zmm18, %zmm9, %zmm20
	vpmadd52huq	%zmm18, %zmm9, %zmm19
	vpmadd52huq	%zmm18, %zmm8, %zmm16
	vpmadd52huq	%zmm18, %zmm7, %zmm10
	vpmadd52luq	%zmm18, %zmm11, %zmm14
	vpmadd52luq	%zmm18, %zmm8, %zmm19
	vpmadd52luq	%zmm18, %zmm7, %zmm16
	vpmadd52luq	%zmm18, %zmm6, %zmm10
	vpxord	%xmm18, %xmm18, %xmm18
	vpmadd52luq	%zmm12, %zmm20, %zmm18
	vpaddq	%zmm24, %zmm20, %zmm20
	vpsrlq	$52, %zmm20, %zmm20
	vpmadd52huq	%zmm4, %zmm18, %zmm16
	vpmadd52huq	%zmm3, %zmm18, %zmm10
	vpmadd52huq	%zmm2, %zmm18, %zmm14
	vpmadd52huq	%zmm23, %zmm18, %zmm20
	vpmadd52luq	%zmm4, %zmm18, %zmm19
	vpmadd52huq	%zmm0, %zmm18, %zmm17
	vpmadd52luq	%zmm3, %zmm18, %zmm16
	vpmadd52luq	%zmm2, %zmm18, %zmm10
	vpmadd52luq	%zmm0, %zmm18, %zmm14
	vpaddq	%zmm20, %zmm19, %zmm19
	vpmadd52huq	%zmm15, %zmm6, %zmm17
	vpxord	%xmm18, %xmm18, %xmm18
	vpmadd52huq	%zmm15, %zmm11, %zmm18
	vpmadd52luq	%zmm15, %zmm9, %zmm19
	vpmadd52huq	%zmm15, %zmm9, %zmm16
	vpmadd52huq	%zmm15, %zmm8, %zmm10
	vpmadd52huq	%zmm15, %zmm7, %zmm14
	vpmadd52luq	%zmm15, %zmm11, %zmm17
	vpmadd52luq	%zmm15, %zmm8, %zmm16
	vpmadd52luq	%zmm15, %zmm7, %zmm10
	vpmadd52luq	%zmm15, %zmm6, %zmm14
	vpxor	%xmm15, %xmm15, %xmm15
	vpmadd52luq	%zmm12, %zmm19, %zmm15
	vpaddq	%zmm24, %zmm19, %zmm19
	vpsrlq	$52, %zmm19, %zmm19
	vpmadd52huq	%zmm23, %zmm15, %zmm19
	vpmadd52luq	%zmm4, %zmm15, %zmm16
	vpmadd52huq	%zmm3, %zmm15, %zmm14
	vpmadd52huq	%zmm4, %zmm15, %zmm10
	vpmadd52huq	%zmm2, %zmm15, %zmm17
	vpmadd52huq	%zmm0, %zmm15, %zmm18
	vpaddq	%zmm19, %zmm16, %zmm16
	vmovdqa64	256(%rdx), %zmm19
	vpmadd52luq	%zmm2, %zmm15, %zmm14
	vpmadd52luq	%zmm3, %zmm15, %zmm10
	vpmadd52luq	%zmm0, %zmm15, %zmm17
	vpmadd52huq	%zmm19, %zmm8, %zmm14
	vpmadd52luq	%zmm19, %zmm9, %zmm16
	vpmadd52huq	%zmm19, %zmm9, %zmm10
	vpmadd52huq	%zmm19, %zmm7, %zmm17
	vpmadd52huq	%zmm19, %zmm6, %zmm18
	vpmadd52luq	%zmm19, %zmm7, %zmm14
	vpmadd52luq	%zmm12, %zmm16, %zmm1
	vpmadd52luq	%zmm19, %zmm6, %zmm17
	vpmadd52luq	%zmm19, %zmm8, %zmm10
	vpmadd52luq	%zmm19, %zmm11, %zmm18
	vpaddq	%zmm24, %zmm16, %zmm7
	vpxor	%xmm6, %xmm6, %xmm6
	vpmadd52huq	%zmm19, %zmm11, %zmm6
	vpsrlq	$52, %zmm7, %zmm7
	vpmadd52huq	%zmm4, %zmm1, %zmm14
	vpmadd52huq	%zmm3, %zmm1, %zmm17
	vpmadd52huq	%zmm23, %zmm1, %zmm7
	vpmadd52luq	%zmm4, %zmm1, %zmm10
	vpmadd52huq	%zmm2, %zmm1, %zmm18
	vpmadd52huq	%zmm0, %zmm1, %zmm6
	vpmadd52luq	%zmm3, %zmm1, %zmm14
	vpaddq	%zmm7, %zmm10, %zmm7
	vpmadd52luq	%zmm2, %zmm1, %zmm17
	vpmadd52luq	%zmm0, %zmm1, %zmm18
	vpsrlq	$52, %zmm7, %zmm0
	vpandq	%zmm24, %zmm7, %zmm1
	vmovdqa64	%zmm1, (%rdi)
	vpaddq	%zmm14, %zmm0, %zmm0
	vpsrlq	$52, %zmm0, %zmm2
	vpandq	%zmm24, %zmm0, %zmm0
	vpaddq	%zmm17, %zmm2, %zmm2
	vmovdqa64	%zmm0, 64(%rdi)
	vpsrlq	$52, %zmm2, %zmm3
	vpandq	%zmm24, %zmm2, %zmm2
	vpaddq	%zmm18, %zmm3, %zmm3
	vmovdqa64	%zmm2, 128(%rdi)
	vpsrlq	$52, %zmm3, %zmm4
	vpandq	%zmm24, %zmm3, %zmm3
	vpaddq	%zmm6, %zmm4, %zmm4
	vmovdqa64	%zmm3, 192(%rdi)
	vmovdqa64	%zmm4, 256(%rdi)
	vzeroupper
	retq
.Lfunc_end2:
	.size	tune_fr_mul, .Lfunc_end2-tune_fr_mul
	.cfi_endproc

	.ident	"rustc version 1.98.1 (48a229cea 2026-09-01)"
	.section	".note.GNU-stack","",@progbits
