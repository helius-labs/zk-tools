# Native-feature compiler scheduling experiment

7 November 2026, frozen before the first probe. Arithmetic source and target
features stay accepted. One candidate adds `-Z tune-cpu=sapphirerapids` with
RUSTC_BOOTSTRAP=1 to Rust1.98.1's native build. This is an isolated compiler
experiment, not a production toolchain policy or a target-CPU substitution.

Motivation: the prior LLVM audit found upstream znver5 uses Znver4Model; the
prior hardware calibration measured roughly two register IFMAs/cycle instead
of the model's one per two cycles. A scheduling mismatch is not by itself a
proved compiler defect or a speedup. Inspect exactly one alternative model
before native testing; no target/tuning/attribute sweep. Sapphire Rapids is a
full-width AVX512/IFMA model. Its memory/resource model is not a calibrated
model of the Ryzen, and no modeled cycle count selects adoption.

First compile identical accepted-field wrappers with native default versus
native+SPR tuning. Verify exact target feature strings, target-cpu, tune-cpu,
function bodies, IFMA selection and actual assembly changes. The inherited
eight-instruction llvm-mca input is evaluated only under the new SPR model;
the old znver5 evaluation is inherited, not rerun. These are emitted-code and
model checks, not arithmetic or latency qualifications.

Only if tuning reaches the intended functions without changing enabled ISA,
freeze a full accepted-source native build with coherent libraries, the same
driver, and explicit O3/native/fatLTO/one-CGU final flags including the tuning.
Check field/curve/prover correctness for this new compiler configuration,
independent Gnark exports for all9 circuits, real caller disassembly and
native target flags before clocks. Do not replay old qualifications merely
for report bookkeeping; compiler-specific new qualification is distinct.

Full proof measurements, if selected, need fixed matched accepted/fresh-control/
candidate comparisons, all8 plus merge54 and primary16, with profiling and
memory observations. Freeze that capture protocol before its first clock.
No favorable subset, unchanged retry or threshold change. No inference from
isolated wrapper or model to full-proof performance. Original all8 CPU>=10x
M5CPU objective and CPU/Metal reporting remain unchanged and unmet0/8.

No arithmetic source edits, lookup table, key copy, plan or pool are proposed.
Target features and source-level memory policy stay accepted; compiler spills,
code size and process RSS can change. No AWS/mobile/huge/pressure claim follows.
