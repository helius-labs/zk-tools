use zopro_bn254::{FqConfig,FrConfig,ifma8::Ifma8};
#[unsafe(no_mangle)]
#[inline(never)]
pub fn tune_fq_mul(a:&Ifma8<FqConfig>,b:&Ifma8<FqConfig>)->Ifma8<FqConfig>{a.mul(b)}
#[unsafe(no_mangle)]
#[inline(never)]
pub fn tune_fq_sum(a:&Ifma8<FqConfig>,b:&Ifma8<FqConfig>,c:&Ifma8<FqConfig>,d:&Ifma8<FqConfig>)->Ifma8<FqConfig>{a.sum2(b,c,d)}
#[unsafe(no_mangle)]
#[inline(never)]
pub fn tune_fr_mul(a:&Ifma8<FrConfig,false>,b:&Ifma8<FrConfig,false>)->Ifma8<FrConfig,false>{a.mul(b)}
