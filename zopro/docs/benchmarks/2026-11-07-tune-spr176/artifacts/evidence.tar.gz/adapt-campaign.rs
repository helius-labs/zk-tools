use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/tune-spr176";const OLD:&str="/home/ubuntu/src/zopro-perf-work/fft-column-prep-sdk176";
fn main(){assert!(!Path::new(&format!("{R}/campaign.rs")).exists());let mut s=fs::read_to_string(format!("{OLD}/campaign.rs")).unwrap().replace(OLD,R);for(a,b)in[
("33471","33971"),("33939","34439"),
("\"prior_component_latency_gate_still_false\":true,\"prior_component_profile_quality_still_false\":true","\"compiler_configuration_changed\":true,\"new_compiler_native_qualification_passed\":true"),
(" Previous failed column profile flags remain false."," The SPR model is not a calibrated Ryzen performance model."),
("for p in[format!(\"{R}/campaign.rs\"),","for p in[format!(\"{R}/adapt-campaign.rs\"),format!(\"{R}/codegen.rs\"),format!(\"{R}/codegen-tool\"),format!(\"{R}/native-test-qualification.json\"),format!(\"{R}/campaign.rs\"),")]{assert!(s.contains(a),"missing {a}");s=s.replace(a,b);}fs::write(format!("{R}/campaign.rs"),s).unwrap();println!("Adapted fixed all8+merge54/primary16 completeSDK protocol;450latency+18diagnostics thenverifiers/offline;notyetfrozenorexecuted");}
