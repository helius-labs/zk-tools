# Fused wire conversion and sorted query extraction

Hypothesis: independently converting wire blocks and immediately extracting their
A/B outputs removes the global conversion-to-gather barrier and separate Rayon
iterator trees. Each wire is still converted exactly once; outputs retain order.
Both solver loaders already enforce strictly increasing in-range A/B indices.
This is distinct from the prior gather-only minimum-grain policy and from moving
whole preparation alongside FFT. No key metadata, lookup table, new pool, scalar
copy or retained memory is added. The existing two output capacities remain;
recursive slices and binary searches replace global gather scheduling. Leaf size
1024 is fixed before measurement; no sweep or best-copy selection.

Expected observation: less complete-proof time/CPU with similar peak RSS. A faster
helper alone does not establish this. Refutation: no full-request gain or new
resource/correctness cost. Actual stage attribution will use a bounded subsequent
profile only if the short verified screen warrants it. Local results cannot prove
C7a behavior. No adoption without missing native/portable/all-shape qualification.

Initial build from accepted177-file source, coherent native SDK, REF exact accepted
SDK, shared OFF/ON candidate with runtime selector. Focused native core tests must
check empty/sparse/dense, leaf boundaries, all canonical wires, concurrent callers
on1/4/16/32 workers with512KiB stacks and panic behavior. No extra initialized
output pass: spare capacity written through safe disjoint slices, lengths set only
after every descendant joins. No unsafe aliasing or unsafe arithmetic is added.

Screen: primary1x2 at16/32 fixed workers plus2x2 at32,3 independent byte-exact
backings per binary,9 rotated/reversed blocks,31 timed SDK requests after3 primes.
OFF/ON functional4worker primary preflights1timed+3primes precede main.83processes,
2762SDKcalls,83fresh Gnark exports. Start canonical55778, end55861. No analysis,
build,hash or helper overlap capture. Preserve every outcome, no extension or
retry. Independent proof verification and input bindings required for all exports.

Exploratory advancement: at least one primary paired ON/REF and ON/OFF median
below1 with at least6/9 winning blocks; no case median latency>1.03 or CPU>1.05
against either control; each case max RSS <= comparator maxRSS*1.05+8MiB. Report
nine-block rank1..7 intervals separately, with their finite-sample assumptions.
OFF/REF calibration is descriptive, not an adoption veto. Failed screen is closed;
passing screen triggers mechanism profile then remaining qualification, not adoption.
Preparation allowance45min; measured panel5min. Full all8CPU10x goal remains unmet.
Commit locally after experiment. No push. No AWS resources until target work ready.
