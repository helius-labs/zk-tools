# Exact fused preparation candidate: local release qualification

Exact candidate c285cbc88f783abac203c66db43ea86bda8207338b9fb209df7eb5d846126202
versus accepted b646c7b8c1d8a26a0db45fb3f67c453dd616bd9f02e25c36192721ae02855abe.
Reuse screen's three REF and three candidate backing files, no SDK rebuild.
ON sets ZOPRO_BENCH_FUSED_PREPARATION=1, REF=0. Both use accepted G2 batching.
OFF is not an additional adoption veto; screen and profile address mechanism.
Full fresh-request SDK boundary including witness/proof/randomness/verification
and serialization, excluding loading,3primes and export. Fixed native32workers
for eight supplied shapes andmerge54; primary also16. Same accepted allocator.

Reuse prior all-shape protocol:23preflight processes(20paired contexts plus
ONoptional-preparation-denied primary16,2x2/32,merge54/32),1timed+3primes each.
Main30pairs/context,17timed+3primes.600processes,12000calls,10200timed samples.
Rotate contexts/reverse oddblocks; alternate arms per3blocks; backing=block%3.
All timing precedes verification per phase. Preflight reviewed before main.
During capture only poll confirmed handle, no owned analysis/build work.

Prospective primary32 latency upper<1 and each primary32backing median<1.
Other9latency uppers<=1.02; all10CPUuppers<=1.02; eachcase maxRSS<=REF*1.05+1MiB.
33checks. No gainfloor. Unit paired processmean;30ratios, sorted ranks10/21
(one-based),95.7226%marginal median coverage assuming independent exchangeable
blocks; no joint guarantee. Report primary32backing spread>1.02 descriptively,
not new veto; retained screen already shows REFcopy0 slower. Do not attribute
whole REFdifference to fusion. Unchanged candidate ON/OFF profile supports gain.
No sample extension,copy swapping or dropped results. Failure remains scoped.

All exports independent Gnark+inputbinding+freshness,SDK verifies every request.
Seed55879 dce77ba26e6b6635bfcdfaa65b98af87dc9f493c6f884544ecfdde48ad4bcec4;
preflight55902,main56502. Preserve indexed route observers for existing G2 path;
they do not count fused preparation. New path is source guarded by canonical-wire
eligibility, confirmed by exactSDK ON-only cycle samples forprimary32; no new
counter/relink. Larger fallback shapes are compatibility/nonregression coverage.
Denial preflights test configured G2 scratch denial, not physical OOM.

Before capture complete native concurrent dense-index/stack oracle and generic
no-IFMA/no-ASM core tests with exact new module. Inherit unchanged field/MSM,
solver index validation, resource admissions, selector and architecture code
qualification from accepted production. New module allocates only existing two
query outputs, no tables/pools; two queries now allocated before conversion,
so wholeprocessRSS and panic/concurrent tests remain required. Generic production
route is unchanged; direct helper tests exercise portable conversion separately.
No claim of physical ARM/mobile or largeforester/pressure testing.

If all declared performance/release checks pass, apply exact runtime source with
explicit opt-in selector retained; removing instrumentation or changing default
branch is a separate measured artifact. No AWS claim. C7a comparison is subsequent
work if credentials available, not needed to infer local qualification. Report
all8 CPU/Metal andmerge54separately,fullCPU10xgoalremains. Commitlocally,nopush.
Preparation allowance30min, capture20min excludingverify; use existingreaders.
