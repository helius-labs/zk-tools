#[path="/home/ubuntu/src/zopro-perf-work/fused-preparation182/source/crates/zopro-core/src/fused_canonical_gather.rs"] mod fused;
use zopro_bn254::Fr;
#[test] fn dense_and_sparse_four_os_callers(){
 for workers in [1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();
 std::thread::scope(|s|{for caller in 0..4{let pool=&pool;s.spawn(move||{
 for n in [2,1024,1025,65535]{let values:Vec<_>=(0..n).map(|i|if i%7==0{-Fr::ONE}else{Fr::from((i+caller*101+1)as u64).square()}).collect();
 let expected:Vec<_>=values.iter().map(Fr::to_canonical).collect();let indices:Vec<_>=(0..n as u32).collect();let sparse:Vec<_>=indices.iter().copied().step_by(103).collect();
 let (a,b,w)=pool.install(||{let mut w=values;let(a,b)=fused::prepare(&mut w,&indices,&sparse);(a,b,w)});
 assert_eq!(a,expected);assert_eq!(b,sparse.iter().map(|&i|expected[i as usize]).collect::<Vec<_>>());assert_eq!(w.iter().map(|x|x.0).collect::<Vec<_>>(),expected);
 } });}}); }
}
