use std::fs;
fn main(){
 let old="/home/ubuntu/src/zopro-perf-work/bounded-gather-profile177";
 let root="/home/ubuntu/src/zopro-perf-work/fused-preparation-profile182";
 for f in ["common.rs","sampling.rs","metadata.rs","counter.rs"] {
 let s=fs::read_to_string(format!("{old}/{f}")).unwrap().replace(old,root).replace("/home/ubuntu/src/zopro-perf-work/bounded-gather-sdk177/proof-sha256-after-main.json","/home/ubuntu/src/zopro-perf-work/fused-preparation182/proof-sha256.json");
 fs::write(format!("{root}/{f}"),s).unwrap(); }
 let mut s=fs::read_to_string(format!("{old}/profile.rs")).unwrap();
 s=s.replace("let parent=\"/home/ubuntu/src/zopro-perf-work/bounded-gather-sdk177\";let ids=read(format!(\"{parent}/checkpoint.json\"));let case=read(format!(\"{parent}/main-jobs.json\"))[0][\"case\"].clone();assert_eq!(case[\"name\"],\"1x2-w16\");let base=read(format!(\"{parent}/main-jobs.json\"))[0][\"environment\"].clone();", "let parent=\"/home/ubuntu/src/zopro-perf-work/fused-preparation182\";let template=read(format!(\"{parent}/plan.json\"));let step=template[\"steps\"].as_array().unwrap().iter().find(|s|s[\"name\"]==\"main-1x2-w32-OFF-b00\").unwrap();let base=step[\"environment\"].clone();let v=template[\"steps\"].as_array().unwrap().iter().find(|s|s[\"name\"]==\"verify-main-1x2-w32-OFF-b00\").unwrap();let case=json!({\"name\":\"1x2-w32\",\"workers\":32,\"image\":step[\"argv\"][4],\"request\":step[\"argv\"][5],\"image_sha256\":v[\"argv\"][2],\"public_sha256\":v[\"argv\"][5]});");
 s=s.replace("let binary=ids[*arm][\"path\"].as_str().unwrap();assert_eq!(hash(binary),ids[*arm][\"sha256\"]);let mut env=base.clone();", "let bp=format!(\"{parent}/bins/diag{block}\");let binary=bp.as_str();assert_eq!(hash(binary),\"c285cbc88f783abac203c66db43ea86bda8207338b9fb209df7eb5d846126202\");let mut env=base.clone();env[\"ZOPRO_BENCH_FUSED_PREPARATION\"]=json!(if *arm==\"ON\"{\"1\"}else{\"0\"});");
 s=s.replace("\"0-15\".into()","\"0-31\".into()");
 s=s.replace("ids[\"OFF\"][\"path\"].as_str().unwrap(),ids[\"ON\"][\"path\"].as_str().unwrap(),", "");
 s=s.replace("save(\"pins.json\",&json!(pins));", "for block in 0..3 {let p=format!(\"{parent}/bins/diag{block}\");pins.insert(p.clone(),hash(p));} save(\"pins.json\",&json!(pins));");
 s=s.replace("51892","55861").replace("51910","55879");
 assert!(!s.contains("ids["));
 fs::write(format!("{root}/profile.rs"),s).unwrap();
 let h="/home/ubuntu/src/zopro-cpu-perf-handoff.md";
 let prefix=fs::read_to_string(format!("{parent}/checkpoint.txt",parent="/home/ubuntu/src/zopro-perf-work/fused-preparation182")).unwrap();
 fs::write(h,format!("# Current checkpoint — fused preparation screen advances\n\n{prefix}\nPrivate root /home/ubuntu/src/zopro-perf-work/fused-preparation182.\nProfile preparing in fused-preparation-profile182; no capture yet.\nEarlier ledger/current labels below are historical.\n\n{}",fs::read_to_string(h).unwrap())).unwrap();
}
