# Fused preparation mechanism profile

Retain exact screen candidate c285cbc88f783abac203c66db43ea86bda8207338b9fb209df7eb5d846126202.
Use its three independently written diag0/1/2 backings in blocks0/1/2, both
OFF/ON runtime settings. 1x2,32 fixed workers CPUs0-31, accepted screen env.
Rotate plain/stat/cycles panels and reverse odd blocks and arm order. 251timed
SDK requests after3primes each.18processes,4572calls,18fresh Gnark exports.
Seed55861 ->55879 only after independent bindings/verification/freshness checks.

Counters: grouped user cycles,instructions,cache-misses,branch-misses,>=99.9%
running coverage. Cycles: fixed16000000period,CPU/time/period/IP/symbol with
actual executable MMAP and PID/TID ownership; >=1000samples,unknown<=5%,zeroLOST.
FIFO enables observers only around measured SDK loops. Median3 per-arm/panel
mean-latency ratios versus sameblock plain must be within factor1.05. This is
coarse descriptive observer calibration, not statistical equivalence. Retain
failures; no unchanged reruns. All capture precedes decode/analysis/verification.
No owned work overlaps capture. No new source or SDK build.

Question: does ON remove the separate conversion/gather execution topology,
with reduced total CPU work or scheduler cost rather than transferring work
elsewhere? Check fused fill is sampled ON and absent OFF, instructions/cycles
per proof and symbol counts. Samples cannot measure an exact synchronization
barrier or exclusive/removable latency. A qualified profile can support or
contradict the mechanism, not qualify release by itself. Do not treat raw
scheduler shares as avoidable work. Subsequent all-shape/portable/resource
qualification remains necessary. No AWS resources or public push.
