use zopro_bn254::{Field,Fr,G1Affine,G1Projective,G2Affine,G2Projective};
fn main(){
 let n=2051usize;let weights:Vec<_>=(0..n).map(|i|if i%19==0{Fr::ZERO}else if i%7==0{-Fr::from((i+1)as u64)}else if i%11==0{Fr::ONE}else{Fr::from((i+1)as u64)}).collect();
 let g1=G1Projective::batch_to_affine(&weights.iter().map(|w|G1Affine::GENERATOR * *w).collect::<Vec<_>>());
 let g2=G2Projective::batch_to_affine(&weights.iter().map(|w|G2Affine::GENERATOR * *w).collect::<Vec<_>>());
 let mut variants=Vec::new();for mode in 0..5 {let mut make=|len:usize,seed:u64|{let mut expected=Fr::ZERO;let words=(0..len).map(|i|{let s=match mode{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,3=>Fr::from((i as u64)+seed).pow(&[19]),_=>Fr::from((i%1100)as u64+seed).pow(&[19])};expected+=weights[i]*s;s.to_canonical()}).collect::<Vec<_>>();(words,expected)};let(sa,ea)=make(n,7);let(sk,ek)=make(1025,17);let(sh,eh)=make(1031,31);let(sb,eb)=make(n,43);variants.push((sa,sk,sh,sb,(G1Affine::GENERATOR*ea).to_affine(),(G1Affine::GENERATOR*(ek+eh)).to_affine(),(G2Affine::GENERATOR*eb).to_affine()));}
 let grouped=std::env::var("ZOPRO_CPU_DEDUP").unwrap()!="0";let mut checks=0;let mut fallback=0;
 let check=|mode:usize|{let(sa,sk,sh,sb,ea,ek,eb)=&variants[mode];match zopro_core::joint_probe(&g1,sa,&g1[..1025],sk,&g1[..1031],sh,&g2,sb){Some((a,k,b))=>{assert_eq!(a.to_affine(),*ea);assert_eq!(k.to_affine(),*ek);assert_eq!(b.to_affine(),*eb);true},None=>{assert!(grouped&&mode<3);false}}};
 for workers in[1,2,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();for mode in 0..5{if pool.install(||check(mode)){checks+=1}else{fallback+=1}}
 let(x,y)=pool.install(||rayon::join(||check(3),||check(4)));assert!(x&&y);checks+=2;
 }
 let pool=rayon::ThreadPoolBuilder::new().num_threads(4).stack_size(512*1024).build().unwrap();std::thread::scope(|scope|{let mut hs=Vec::new();for i in 0..4{let(pool,check)=(&pool,&check);hs.push(scope.spawn(move||assert!(pool.install(||check(3+i%2)))));}for h in hs{h.join().unwrap();}});checks+=4;
 println!("{}",serde_json::json!({"passed":true,"grouped":grouped,"three_query_oracle_checks":checks,"fallback_checks":fallback,"worker_counts":[1,2,4,16,32],"nested_pools":5,"concurrent_callers":4}));
}
