// Private scheduling probe. Arithmetic copied literally from weighted_affine.
pub(super) struct JointScratch<C:CurveConfig> where C::Base:BatchInverse {
 tree:Vec<LimbPoint<C::Base>>,
 scratch:Scratch<C>,
}
impl<C:CurveConfig> Default for JointScratch<C> where C::Base:BatchInverse {fn default()->Self{Self{tree:Vec::new(),scratch:Scratch::default()}}}
impl<C:CurveConfig> JointScratch<C> where C::Base:BatchInverse {
 pub(super) fn leaf(&mut self,buckets:&[Affine<C>])->(Projective<C>,Affine<C>){
  let n=buckets.len();assert!(n>0&&n<=256);
  self.tree.resize(2*n-1,LimbPoint::<C::Base>::infinity());
  for(out,&point)in self.tree.iter_mut().zip(buckets){*out=limbs::<C>(point);}
  let weighted=weighted_sum(&mut self.tree,n,&mut self.scratch);
  (weighted,affine::<C>(self.tree[0]))
 }
}
pub(super) fn joint_finish<C:CurveConfig>(partials:&[(Projective<C>,Affine<C>)])->Projective<C> where C::Base:BatchInverse {
 let mut sum=Projective::<C>::IDENTITY;
 let mut offset=Projective::<C>::IDENTITY;
 let mut running=Projective::<C>::IDENTITY;
 for &(weighted,total)in partials.iter().rev(){sum+=weighted;offset+=running;running+=total;}
 for _ in 0..8{offset=offset.double();}
 sum+offset
}
