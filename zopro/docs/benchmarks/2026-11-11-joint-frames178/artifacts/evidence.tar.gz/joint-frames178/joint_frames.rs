//! Private joint ready-window experiment; all arithmetic remains in existing helpers.
use super::*;
use std::{borrow::Cow,sync::{OnceLock,Mutex,atomic::{AtomicUsize,Ordering}}};
use zopro_bn254::{G1Affine,G1Config,G1Projective,G2Affine,G2Config,G2Projective};
struct Frame<C:CurveConfig> {
    buckets:OnceLock<Vec<Affine<C>>>, next:AtomicUsize,left:AtomicUsize,
    partials:Vec<OnceLock<(Projective<C>,Affine<C>)>>, result:OnceLock<Projective<C>>,
}
impl<C:CurveConfig> Frame<C> where C::Base:BatchInverse {
    fn new(n:usize)->Self {let count=n.div_ceil(256);Self{buckets:OnceLock::new(),next:AtomicUsize::new(0),left:AtomicUsize::new(count),partials:(0..count).map(|_|OnceLock::new()).collect(),result:OnceLock::new()}}
    fn publish(&self,v:Vec<Affine<C>>){assert_eq!(v.len().div_ceil(256),self.partials.len());assert!(self.buckets.set(v).is_ok());}
    fn help(&self,scratch:&mut crate::msm::JointScratch<C>)->bool {
        let Some(b)=self.buckets.get()else{return false};
        if self.next.load(Ordering::Relaxed)>=self.partials.len(){return false;}
        let i=self.next.fetch_add(1,Ordering::Relaxed);if i>=self.partials.len(){return false;}
        let p=scratch.leaf(&b[i*256..((i+1)*256).min(b.len())]);
        assert!(self.partials[i].set(p).is_ok());
        if self.left.fetch_sub(1,Ordering::AcqRel)==1 {
            let parts:Vec<_>=self.partials.iter().map(|p|*p.get().unwrap()).collect();
            assert!(self.result.set(crate::msm::joint_finish(&parts)).is_ok());
        }
        true
    }
}
fn prepare<'a,C:CurveConfig>(p:&'a[Affine<C>],s:&'a[[u64;4]])->(Cow<'a,[Affine<C>]>,Cow<'a,[[u64;4]]>) where C::Base:BatchInverse {
    if crate::simd::cpu_option("ZOPRO_CPU_DEDUP") {if let Some(g)=scalar_groups(s){
        return (Cow::Owned(crate::msm::group_affine(p,&g.order,&g.starts,&g.counts)),Cow::Owned(g.values));
    }}
    (Cow::Borrowed(p),Cow::Borrowed(s))
}
pub(crate) fn run(a:&[G1Affine],sa:&[[u64;4]],k:&[G1Affine],sk:&[[u64;4]],h:&[G1Affine],sh:&[[u64;4]],b:&[G2Affine],sb:&[[u64;4]])->Option<(G1Projective,G1Projective,G2Projective)> {
    assert_eq!(a.len(),sa.len());assert_eq!(b.len(),sb.len());assert_eq!(k.len(),sk.len());assert_eq!(h.len(),sh.len());
    let ((ap,aw),(bp,mut bw))=rayon::join(||prepare::<G1Config>(a,sa),||prepare::<G2Config>(b,sb));
    if !(1024..65536).contains(&ap.len())||!(1024..65536).contains(&bp.len()){return None;}
    bw.to_mut().par_iter_mut().with_min_len(128).for_each(|s|*s=super::g2_phi::phi_split(*s));
    let af:Vec<Frame<G1Config>>=(0..22).map(|_|Frame::new(2048)).collect();
    let kf:Vec<Frame<G1Config>>=(0..20).map(|i|Frame::new(1usize<<((i+1)*255/20-i*255/20-1))).collect();
    let bf:Vec<Frame<G2Config>>=(0..11).map(|i|Frame::new(if i==10{64}else{2048})).collect();
    let halves:Vec<_>=(0..11).map(|_|Mutex::new([None,None])).collect();
    let pending:Vec<_>=(0..11).map(|_|AtomicUsize::new(2)).collect();
    let mut jobs=Vec::new();for w in 0..22 {jobs.push((0,w,0));if w<20{jobs.push((1,w,0));}if w<11{jobs.push((2,w,0));jobs.push((2,w,1));}}
    let next=AtomicUsize::new(0);
    rayon::scope(|scope|{for worker in 0..rayon::current_num_threads(){
        let (af,kf,bf,halves,pending,jobs,next)=(&af,&kf,&bf,&halves,&pending,&jobs,&next);
        let (ap,aw,bp,bw)=(&ap,&aw,&bp,&bw);
        scope.spawn(move |_|{
            let mut gs=crate::msm::JointScratch::<G1Config>::default();let mut bs=crate::msm::JointScratch::<G2Config>::default();
            let mut cursor=worker%53;
            loop {
                let n=next.fetch_add(1,Ordering::Relaxed);
                if let Some(&(q,w,part))=jobs.get(n){match q {
                    0=>{if let Some(sum)=super::top_window::<G1Config,true>(ap,aw,w,12){assert!(af[w].result.set(sum).is_ok());}else{af[w].publish(super::borrowed_pending::joint_fill(ap,aw,w));}},
                    1=>kf[w].publish(super::borrowed_pending::joint_kh(k,sk,h,sh,w)),
                    2=>{let chunk=bp.len().div_ceil(2);let start=part*chunk;let end=(start+chunk).min(bp.len());let buckets=super::g2_phi::joint_fill(&bp[start..end],&bw[start..end],w);
                        halves[w].lock().unwrap()[part]=Some(buckets);
                        if pending[w].fetch_sub(1,Ordering::AcqRel)==1{
                            let pair={let mut lock=halves[w].lock().unwrap();[lock[0].take().unwrap(),lock[1].take().unwrap()]};
                            let [mut first,second]=pair;super::merge_buckets(&mut first,&second);bf[w].publish(first);
                        }
                    },_=>unreachable!()};continue;
                }
                let mut found=false;
                for delta in 0..53 {let i=(cursor+delta)%53;let did=if i<22{af[i].help(&mut gs)}else if i<42{kf[i-22].help(&mut gs)}else{bf[i-42].help(&mut bs)};
                    if did{cursor=(i+1)%53;found=true;break;}
                }
                if !found {return;}
            }
        });
    }});
    let fold_g1=|frames:&[Frame<G1Config>],balanced:bool|{let mut out=G1Projective::IDENTITY;for i in(0..frames.len()).rev(){let width=if balanced{(i+1)*255/20-i*255/20}else{12};for _ in 0..width{out=out.double();}out+=frames[i].result.get().expect("all produced chunks completed");}out};
    let mut br=G2Projective::IDENTITY;for f in bf.iter().rev(){for _ in 0..12{br=br.double();}br+=f.result.get().expect("all G2 chunks completed");}
    Some((fold_g1(&af,false),fold_g1(&kf,true),br))
}
