use super::*;
use zopro_bn254::{G1Affine, G1Config, G1Projective};

#[cfg(zopro_mixed9)]
fn mixed<const SIGNED: bool>(buckets: &mut [G1Affine], batch: &[(u32, impl std::borrow::Borrow<G1Affine> + Copy)], s: &mut FqAddScratch) {
    if batch.len() < 9 { return stream_g1_impl::<G1Config,true,SIGNED>(buckets,batch,s); }
    let count=batch.len()/9;
    s.groups.clear(); s.tail.clear();
    s.groups.reserve(count); s.tail.reserve(count+batch.len()%9);
    let mut chain=FqBatch::one(); let mut scalar=Fq::ONE;
    for j in 0..count {
        let k=j*9;
        let a:[G1Affine;8]=core::array::from_fn(|i|buckets[batch_index::<SIGNED>(batch[k+i].0)]);
        let b:[G1Affine;8]=core::array::from_fn(|i|*batch[k+i].1.borrow());
        let ax=FqBatch::new(&a.map(|p|p.x)); let ay=FqBatch::new(&a.map(|p|p.y));
        let bx=FqBatch::new(&b.map(|p|p.x)); let by=FqBatch::new(&b.map(|p|p.y));
        let (index,b)=batch[k+8]; let b=*b.borrow(); let a=buckets[batch_index::<SIGNED>(index)];
        let sy=if SIGNED && index>>31!=0 {-b.y} else {b.y}; let dx=b.x-a.x;
        let numerator=(sy-a.y)*scalar;
        let vn=scaled_signed_dy::<true,SIGNED>(&by,&ay,&chain,signs::<SIGNED,G1Config>(&batch[k..k+8]));
        scalar*=dx;
        let vd=canonical_sub::<true>(&bx,&ax); chain=chain.mul(&vd);
        s.tail.push([a.x,a.y,a.x+b.x,dx,numerator]);
        s.groups.push(FqAddGroup{ax,ay,xsum:canonical_add::<true>(&ax,&bx),denominator:vd,numerator:vn});
    }
    for &(index,b) in &batch[count*9..] {
        let b=*b.borrow();let a=buckets[batch_index::<SIGNED>(index)];
        let by=if SIGNED && index>>31!=0 {-b.y}else{b.y};let dx=b.x-a.x;
        let numerator=(by-a.y)*scalar;scalar*=dx;
        s.tail.push([a.x,a.y,a.x+b.x,dx,numerator]);
    }
    let (mut inverse,mut scalar_inverse)=chain.inverse_with_extra(scalar);
    for k in (count*9..batch.len()).rev() {
        let [ax,ay,xsum,dx,numerator]=s.tail[count+k-count*9];
        let slope=numerator*scalar_inverse;scalar_inverse*=dx;
        let x=slope.square()-xsum;let y=slope*(ax-x)-ay;
        buckets[batch_index::<SIGNED>(batch[k].0)]=G1Affine::new(x,y);
    }
    for j in (0..count).rev() {
        let g=&s.groups[j];let [ax,ay,xsum,dx,numerator]=s.tail[j];
        let ss=numerator*scalar_inverse;
        let slope=g.numerator.mul(&inverse);
        scalar_inverse*=dx;
        inverse=inverse.mul(&g.denominator);
        let sx=ss.square()-xsum;
        let x=slope.mul(&slope).sub(&g.xsum);
        let sy=ss*(ax-sx)-ay;
        let y=slope.mul(&g.ax.sub(&x)).sub(&g.ay);
        let (x,y)=(x.get(),y.get());
        buckets[batch_index::<SIGNED>(batch[j*9+8].0)]=G1Affine::new(sx,sy);
        for i in 0..8 {buckets[batch_index::<SIGNED>(batch[j*9+i].0)]=G1Affine::new(x[i],y[i]);}
    }
}

pub struct Caller {
    source:Vec<G1Affine>, buckets:Vec<G1Affine>, incoming:Vec<G1Affine>,
    owned:Vec<(u32,G1Affine)>, unsigned:Vec<(u32,G1Affine)>, scratch:FqAddScratch, size:usize, seed:u64,
}
impl Caller {
    pub fn new(n:usize,seed:u64)->Self {
        assert!(n<=512);
        let size=n.max(1).next_power_of_two();
        let source=G1Projective::batch_to_affine(&(0..size).map(|i|G1Affine::GENERATOR*Fr::from(Self::base(i,seed))).collect::<Vec<_>>());
        let incoming=G1Projective::batch_to_affine(&(0..n).map(|i|G1Affine::GENERATOR*Fr::from(Self::step(i,seed))).collect::<Vec<_>>());
        let owned:Vec<_>=incoming.iter().enumerate().map(|(i,&p)|((((i*37+seed as usize)%size)as u32)|if i%3!=1{1<<31}else{0},p)).collect();
        let unsigned=owned.iter().map(|&(i,p)|((i&0x7fffffff),if i>>31!=0{-p}else{p})).collect();
        Self{buckets:source.clone(),source,incoming,owned,unsigned,size,seed,scratch:FqAddScratch{write_groups:true,reserve_groups:true,vector_inverse:true,canonical:true,..Default::default()}}
    }
    fn base(i:usize,seed:u64)->u64 {(1u64<<48)*(i as u64+1)+(seed+1)*100000003}
    fn step(i:usize,seed:u64)->u64 {11111+(seed+1)*1337+i as u64*101}
    pub fn reset(&mut self){self.buckets.copy_from_slice(&self.source);}
    #[inline(never)]
    pub fn run(&mut self,rounds:usize,mixed_path:bool,borrowed:bool){
        if borrowed {
            // The production borrowed caller already owns its pending refs.
            // Build those once per driver call, outside the per-batch loop.
            let mut storage=[(0,&self.source[0]);512];
            for (slot,(&(i,_),p)) in storage.iter_mut().zip(self.owned.iter().zip(&self.incoming)){*slot=(i,p);}
            let refs=&storage[..self.owned.len()];
            if mixed_path {
                #[cfg(zopro_mixed9)] {for _ in 0..rounds{mixed::<true>(&mut self.buckets,refs,&mut self.scratch);}return;}
            }
            for _ in 0..rounds{stream_g1_impl::<G1Config,true,true>(&mut self.buckets,refs,&mut self.scratch);}
        }else{
            if mixed_path {
                #[cfg(zopro_mixed9)] {for _ in 0..rounds{mixed::<false>(&mut self.buckets,&self.unsigned,&mut self.scratch);}return;}
            }
            for _ in 0..rounds{stream_g1_impl::<G1Config,true,false>(&mut self.buckets,&self.unsigned,&mut self.scratch);}
        }
    }
    pub fn check(&self,rounds:usize){
        let mut coeff=(0..self.size).map(|i|Fr::from(Self::base(i,self.seed))).collect::<Vec<_>>();
        for (j,&(index,_)) in self.owned.iter().enumerate(){let s=Fr::from(Self::step(j,self.seed))*Fr::from(rounds as u64);let k=(index&0x7fffffff)as usize;coeff[k]+=if index>>31!=0{-s}else{s};}
        let expected=G1Projective::batch_to_affine(&coeff.iter().map(|&c|G1Affine::GENERATOR*c).collect::<Vec<_>>());assert_eq!(self.buckets,expected);
    }
    pub fn capacities(&self)->[usize;2]{[self.scratch.groups.capacity()*core::mem::size_of::<FqAddGroup>(),self.scratch.tail.capacity()*core::mem::size_of::<[Fq;5]>()]}
    pub fn digest(&self)->Vec<u8>{let mut out=vec![];for p in &self.buckets{for f in[p.x,p.y]{for w in f.to_canonical(){out.extend_from_slice(&w.to_le_bytes());}}}out}
}

#[cfg(test)]mod tests{
use super::*;
#[test]fn complete_generator_oracle_tails_signs_and_reuse(){
for n in[0,1,7,8,9,10,17,18,23,199,200,352,511]{for borrowed in[false,true]{for path in[false,true]{let mut f=Caller::new(n,19);for rounds in[1,3,17]{f.reset();f.run(rounds,path,borrowed);f.check(rounds);}}}}
}
#[cfg(zopro_mixed9)]#[test]fn nine_chain_inverse(){for seed in[0,1,7,519]{let a=core::array::from_fn(|i|Fq::from(seed+i as u64*37+1));let b=Fq::from(seed+12345);let(x,y)=FqBatch::new(&a).inverse_with_extra(b);for(i,x)in x.get().iter().enumerate(){assert_eq!(*x*a[i],Fq::ONE);}assert_eq!(y*b,Fq::ONE);}}
}
