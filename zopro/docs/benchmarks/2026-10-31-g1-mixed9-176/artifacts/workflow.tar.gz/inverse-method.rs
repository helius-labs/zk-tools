    #[cfg(zopro_mixed9)]
    #[inline]
    pub(crate) fn inverse_with_extra(&self, extra:Fq)->(Self,Fq) {
        use zopro_bn254::ifma8::Ifma8;
        let swapped=Self(Ifma8::shuffle_pair::<1,0,3,2>(&self.0,&self.0));
        let pairs=self.mul(&swapped);
        let other_pair=Self(Ifma8::shuffle_pair::<2,3,0,1>(&pairs.0,&pairs.0));
        let quads=pairs.mul(&other_pair);let p=quads.get();let prod=p[0]*p[4];
        let common=(prod*extra).inverse().unwrap();let scalar=common*prod;
        let(lo,hi)=quads.0.halves();let other_quad=Self(Ifma8::from_halves(&hi,&lo));
        (Self::new(&[common*extra;8]).mul(&other_quad).mul(&other_pair).mul(&swapped),scalar)
    }
