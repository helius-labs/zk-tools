use std::{fs,path::Path,collections::BTreeMap};
use serde_json::json;
use sha2::{Sha256,Digest};
fn main()->Result<(),Box<dyn std::error::Error>>{
 let r=Path::new("/home/ubuntu/src/zopro-perf-work/c7a-worker-residence176");
 let a=Path::new("/home/ubuntu/src/zopro-perf-work/accepted-current-c7a176");
 let b=a.join("remote-results/output/measure");
 let mut pins=BTreeMap::<String,String>::new();
 let mut add=|p:std::path::PathBuf|->Result<(),Box<dyn std::error::Error>>{pins.insert(p.display().to_string(),format!("{:x}",Sha256::digest(fs::read(p)?)));Ok(())};
 for p in [r.join("design.md"),r.join("setup.rs"),a.join("quality.json"),a.join("sdk-accepted-znver4"),a.join("analysis.json")]{add(p)?;}
 let mut steps=vec![];
 for name in ["cycles-1x2-w32-accepted","cycles-1x2-w96-accepted","cycles-1x2-w32-aeglos","cycles-1x2-w96-aeglos"]{
  let raw=b.join("runs").join(name).join("perf.data"); add(raw.clone())?;
  for kind in ["symbols","events","measure","loss"] {let d=b.join("workflow").join(format!("{kind}-{name}"));for f in ["command.json","exit.json","stdout.log","stderr.log"]{add(d.join(f))?;}}
  steps.push(json!({"kind":"command","name":format!("time-mmap-{name}"),"argv":["/usr/bin/perf","script","--show-lost-events","--show-mmap-events","-i",raw.display().to_string(),"-F","pid,tid,time,period,ip"],"timeout_seconds":120}));
 }
 let elf=a.join("sdk-accepted-znver4");let elf=elf.to_str().unwrap();
 for (name,argv) in [("elf-loads",vec!["/usr/bin/readelf","-lW",elf]),("native-symbols",vec!["/usr/bin/nm","-n","-S","-C",elf]),("native-assembly",vec!["/usr/bin/objdump","-d","-C","-Mintel",elf])]{steps.push(json!({"kind":"command","name":name,"argv":argv,"timeout_seconds":120}));}
 for p in ["/usr/bin/perf","/usr/bin/readelf","/usr/bin/nm","/usr/bin/objdump","/home/ubuntu/src/zopro-perf-work/tool-target/release/xtask"]{add(p.into())?;}
 let root=Path::new("/home/ubuntu/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f");
 for p in ["crossbeam-epoch-0.9.21/src/internal.rs","crossbeam-deque-0.8.8/src/deque.rs","rayon-core-1.13.0/src/registry.rs"]{add(root.join(p))?;}
 fs::write(r.join("pins.json"),serde_json::to_vec_pretty(&pins)?)?;
 fs::write(r.join("projection-plan.json"),serde_json::to_vec_pretty(&json!({"version":1,"source_pins":r.join("pins.json"),"environment":{"LC_ALL":"C"},"steps":steps}))?)?;
 println!("pinned {} inputs; prepared {} new offline projections/ELF inspections",pins.len(),steps.len()); Ok(())
}
