use std::{fs,collections::{BTreeMap,BTreeSet},path::Path};
use serde_json::{Value,json};use sha2::{Digest,Sha256};
fn main()->Result<(),Box<dyn std::error::Error>>{
 let root=Path::new("/home/ubuntu/src/zopro-perf-work/c7a-worker-residence176");
 let parent=Path::new("/home/ubuntu/src/zopro-perf-work/accepted-current-c7a176");
 let data:Value=serde_json::from_slice(&fs::read(root.join("analysis.json"))?)?;
 let quality:Value=serde_json::from_slice(&fs::read(parent.join("quality.json"))?)?;
 let mut total=0usize;let mut instruction_count=0;
 for report in data["profiles"].as_array().unwrap(){
  let name=report["name"].as_str().unwrap();
  let old=fs::read_to_string(parent.join("remote-results/output/measure/workflow").join(format!("symbols-{name}")).join("stdout.log"))?;
  let new=fs::read_to_string(root.join("projection").join(format!("time-mmap-{name}")).join("stdout.log"))?;
  let mut original=BTreeMap::<(String,u64,u64),u64>::new();
  let mut tid_bins=BTreeMap::<u64,BTreeMap<&str,u64>>::new();let mut counts=BTreeMap::<u64,usize>::new();let mut ips=BTreeMap::<u64,u64>::new();let mut pids=BTreeSet::new();
  for line in old.lines().filter(|l|!l.trim().is_empty()&&!l.trim().starts_with('#')){
   assert!(!line.contains("PERF_RECORD_LOST"));let mut iter=line.split_whitespace();let id=iter.next().unwrap();let(p,t)=id.split_once('/').unwrap();pids.insert(p.parse::<u64>()?);let tid=t.parse::<u64>()?;let weight=iter.next().unwrap().parse::<u64>()?;let ip=u64::from_str_radix(iter.next().unwrap(),16)?;let raw=iter.collect::<Vec<_>>().join(" ");assert!(weight>0);
   *original.entry((id.into(),weight,ip)).or_default()+=1;*counts.entry(tid).or_default()+=1;
   let category=if raw.contains("crossbeam_epoch"){"epoch"}else if raw.contains("rayon_core")||raw.contains("crossbeam_deque"){"scheduler"}else if raw.contains("stream_g1_impl"){"g1_stream"}else if raw.contains("g2_borrowed")&&raw.contains("apply"){"g2_apply"}else{"other"};
   let bins=tid_bins.entry(tid).or_default();*bins.entry("all").or_default()+=weight;*bins.entry(category).or_default()+=weight;
   if category=="epoch"{*ips.entry(ip).or_default()+=weight;}
  }
  let mut projected=BTreeMap::<(String,u64,u64),u64>::new();let mut times=vec![];let mut map=None;
  for line in new.lines().filter(|l|!l.trim().is_empty()&&!l.trim().starts_with('#')){
   assert!(!line.contains("PERF_RECORD_LOST"));
   if line.contains("PERF_RECORD_"){
    if name.ends_with("accepted")&&line.contains(&format!("PERF_RECORD_MMAP2 {0}/{0}:",report["pid"].as_u64().unwrap()))&&line.ends_with("/usr/local/bin/cr-previous"){
     let l=line.find('[').unwrap()+1;let m=line[l..].find('(').unwrap()+l;let off=line.find(" @ ").unwrap()+3;let stop=line[off..].find(' ').unwrap()+off;
     map=Some((u64::from_str_radix(line[l..m].trim_start_matches("0x"),16)?,u64::from_str_radix(line[off..stop].trim_start_matches("0x"),16)?));
    }continue;
   }
   let words=line.split_whitespace().collect::<Vec<_>>();assert_eq!(words.len(),4);let(s,f)=words[1].trim_end_matches(':').split_once('.').unwrap();times.push(s.parse::<u64>()?*1_000_000_000+format!("{f:0<9}").parse::<u64>()?);
   let w=words[2].parse::<u64>()?;let address=u64::from_str_radix(words[3],16)?;*projected.entry((words[0].into(),w,address)).or_default()+=1;
  }
  assert_eq!(original,projected);assert_eq!(pids.len(),1);
  assert_eq!(report["samples"].as_u64().unwrap()as usize,counts.values().sum::<usize>());assert_eq!(report["sampled_tids"].as_u64().unwrap()as usize,counts.len());
  let q=quality["profiles"].as_array().unwrap().iter().find(|p|p["name"]==name).unwrap();assert_eq!(q["profile"]["samples"],report["samples"]);assert_eq!(q["profile"]["period"],report["period"]);
  assert_eq!(report["sample_time_span_ns"].as_u64().unwrap(),times.iter().max().unwrap()-times.iter().min().unwrap());
  let mut recomputed=0u64;
  for row in report["threads"].as_array().unwrap(){let t=row["tid"].as_u64().unwrap();assert_eq!(row["samples"].as_u64().unwrap()as usize,counts[&t]);let actual:BTreeMap<String,u64>=serde_json::from_value(row["periods"].clone())?;let expected=tid_bins[&t].iter().map(|(k,&v)|(k.to_string(),v)).collect::<BTreeMap<_,_>>();assert_eq!(actual,expected);recomputed+=actual["all"];}
  assert_eq!(recomputed,report["period"].as_u64().unwrap());
  let caller=report["pid"].as_u64().unwrap();
  for(c,dist)in report["distributions_excluding_caller"].as_object().unwrap(){
   let mut v=tid_bins.iter().filter(|(&tid,_)|tid!=caller).map(|(_,bins)|*bins.get(c.as_str()).unwrap_or(&0)).collect::<Vec<_>>();v.sort_unstable();
   let sum:u64=v.iter().sum();assert_eq!(dist["period"].as_u64().unwrap(),sum);assert_eq!(dist["threads"].as_u64().unwrap()as usize,v.len());assert_eq!(dist["nonzero"].as_u64().unwrap()as usize,v.iter().filter(|&&n|n!=0).count());
   if sum>0 {let eff=1./v.iter().map(|&n|(n as f64/sum as f64).powi(2)).sum::<f64>();assert!((eff-dist["effective_threads"].as_f64().unwrap()).abs()<1e-9);let mut sum90=0;let mut n=0;for &w in v.iter().rev(){sum90+=w;n+=1;if 10u128*sum90 as u128>=9u128*sum as u128{break;}}assert_eq!(dist["threads_for_90_percent"].as_u64().unwrap()as usize,n);assert!((dist["top_thread_percent"].as_f64().unwrap()-100.*v[v.len()-1]as f64/sum as f64).abs()<1e-9);}
  }
  if name.ends_with("accepted"){
   let elf=fs::read(parent.join("sdk-accepted-znver4"))?;let ph=u64::from_le_bytes(elf[32..40].try_into()?)as usize;let stride=u16::from_le_bytes(elf[54..56].try_into()?)as usize;let num=u16::from_le_bytes(elf[56..58].try_into()?)as usize;let(start,offset)=map.unwrap();let mut load_bias=None;
   for i in 0..num{let h=&elf[ph+i*stride..ph+(i+1)*stride];if u32::from_le_bytes(h[0..4].try_into()?)==1&&u32::from_le_bytes(h[4..8].try_into()?)&1!=0{let o=u64::from_le_bytes(h[8..16].try_into()?);let v=u64::from_le_bytes(h[16..24].try_into()?);let size=u64::from_le_bytes(h[32..40].try_into()?);if offset>=o/4096*4096&&offset<o+size {load_bias=Some(start-(offset-o/4096*4096+v/4096*4096));}}}
   let assembly=fs::read_to_string(root.join("projection/native-assembly/stdout.log"))?;let mut seen=BTreeMap::new();
   for site in report["epoch_instruction_sites"].as_array().unwrap(){let ip=u64::from_str_radix(site["ip"].as_str().unwrap().trim_start_matches("0x"),16)?;let address=ip-load_bias.unwrap();assert_eq!(site["elf_address"],format!("0x{address:x}"));assert_eq!(site["period"].as_u64().unwrap(),ips[&ip]);
    let line=assembly.lines().find(|line|line.split_once(':').is_some_and(|(a,_)|a.trim()==format!("{address:x}"))).unwrap();let text=line.split('\t').skip(2).collect::<Vec<_>>().join(" ");assert_eq!(site["instruction"],text);seen.insert(ip,site["period"].as_u64().unwrap());instruction_count+=1;
   }assert_eq!(seen,ips);
  }
  total+=counts.values().sum::<usize>();
 }
 assert_eq!(total,97089);
 // Command exit receipts bind each projection's actual byte streams.
 let mut commands=0;
 for entry in fs::read_dir(root.join("projection"))?{let d=entry?.path();if !d.is_dir(){continue;}let exit:Value=serde_json::from_slice(&fs::read(d.join("exit.json"))?)?;assert_eq!(exit["success"],true);for (file,key)in [("stdout.log","stdout_sha256"),("stderr.log","stderr_sha256")]{let hash=format!("{:x}",Sha256::digest(fs::read(d.join(file))?));assert_eq!(exit[key],hash);}commands+=1;}
 assert_eq!(commands,7);
 let result=json!({"status":"PASS","samples_reconciled":total,"epoch_instruction_sites_checked":instruction_count,"projection_command_receipts_checked":commands,"independent_raw_symbol_classification":true,"new_proofs":0});fs::write(root.join("review.json"),serde_json::to_vec_pretty(&result)?)?;println!("{result}");Ok(())
}
