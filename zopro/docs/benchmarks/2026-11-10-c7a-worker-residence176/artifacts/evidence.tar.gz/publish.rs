use std::{fs,path::{Path,PathBuf},process::Command,collections::BTreeMap};use serde_json::{Value,json};use sha2::{Digest,Sha256};
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn copy_tree(src:&Path,dst:&Path,files:&mut BTreeMap<String,String>,base:&Path)->Result<(),Box<dyn std::error::Error>>{fs::create_dir_all(dst)?;let mut es=fs::read_dir(src)?.map(|x|x.unwrap().path()).collect::<Vec<_>>();es.sort();for s in es{let d=dst.join(s.file_name().unwrap());if s.is_dir(){copy_tree(&s,&d,files,base)?;}else{fs::copy(&s,&d)?;files.insert(d.strip_prefix(base)?.display().to_string(),hash(&d));}}Ok(())}
fn main()->Result<(),Box<dyn std::error::Error>>{
 let r=Path::new("/home/ubuntu/src/zopro-perf-work/c7a-worker-residence176");let dst=Path::new("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-10-c7a-worker-residence176");let artifacts=dst.join("artifacts");assert!(!artifacts.exists());fs::create_dir(&artifacts)?;
 let report=fs::read_to_string(dst.join("README.md"))?;let a:Value=serde_json::from_slice(&fs::read(r.join("analysis.json"))?)?;let review:Value=serde_json::from_slice(&fs::read(r.join("review.json"))?)?;assert_eq!(review["status"],"PASS");assert_eq!(review["samples_reconciled"],97089);assert_eq!(review["epoch_instruction_sites_checked"],96);
 for p in a["profiles"].as_array().unwrap().iter().filter(|p|p["name"].as_str().unwrap().ends_with("accepted")){for c in ["all","g1_stream","g2_apply","epoch"]{let d=&p["distributions_excluding_caller"][c];assert!(report.contains(&format!("{:.2}",d["effective_threads"].as_f64().unwrap())));}}
 let stage=r.join("publication-source");assert!(!stage.exists());fs::create_dir(&stage)?;let mut manifest=BTreeMap::new();
 for f in ["design.md","setup.rs","analyze.rs","review.rs","prepare-analysis.rs","publish.rs","pins.json","projection-plan.json","analysis-pins.json","analysis-plan.json","analysis.json","review.json"]{fs::copy(r.join(f),stage.join(f))?;manifest.insert(f.to_owned(),hash(stage.join(f)));}
 for sub in ["projection","analysis-runs"]{copy_tree(&r.join(sub),&stage.join(sub),&mut manifest,&stage)?;}
 fs::write(stage.join("manifest.json"),serde_json::to_vec_pretty(&manifest)?)?;
 let archive=artifacts.join("evidence.tar.gz");let args=vec!["--sort=name".to_owned(),"--mtime=2026-11-10 00:00:00Z".into(),"--owner=0".into(),"--group=0".into(),"--numeric-owner".into(),"-czf".into(),archive.display().to_string(),"-C".into(),stage.display().to_string(),".".into()];assert!(Command::new("tar").args(&args).status()?.success());
 let round=r.join("publication-roundtrip");fs::create_dir(&round)?;assert!(Command::new("tar").args(["-xzf",archive.to_str().unwrap(),"-C",round.to_str().unwrap()]).status()?.success());for(p,h)in &manifest{assert_eq!(&hash(round.join(p)),h);}
 let restored:BTreeMap<String,String>=serde_json::from_slice(&fs::read(round.join("manifest.json"))?)?;assert_eq!(restored,manifest);
 for f in ["analysis.json","review.json","design.md"]{fs::copy(r.join(f),artifacts.join(f))?;}
 let result=json!({"status":"PASS","new_recordings":0,"new_proofs":0,"canonical_verified_exports":50005,"archive_sha256":hash(&archive),"archive_bytes":fs::metadata(&archive)?.len(),"roundtrip_members_checked":manifest.len(),"source_and_stream_roundtrip":true,"analysis_and_review_first_execution_success":true,"report_distribution_values_checked":true});fs::write(artifacts.join("publication.json"),serde_json::to_vec_pretty(&result)?)?;
 let mut checks=String::new();for f in ["analysis.json","review.json","design.md","evidence.tar.gz","publication.json"]{checks+=&format!("{}  artifacts/{f}\n",hash(artifacts.join(f)));}fs::write(dst.join("SHA256SUMS"),checks)?;
 assert!(Command::new("sha256sum").arg("-c").arg("SHA256SUMS").current_dir(dst).status()?.success());
 fs::write(r.join("publication.json"),serde_json::to_vec_pretty(&result)?)?;println!("{result}");Ok(())
}
