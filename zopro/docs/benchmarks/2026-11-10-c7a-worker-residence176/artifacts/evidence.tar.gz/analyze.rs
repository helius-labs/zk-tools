use std::{collections::{BTreeMap,BTreeSet},fs,path::Path};
use serde_json::{Value,json};
use sha2::{Digest,Sha256};
type E=Box<dyn std::error::Error>;
type Key=(u32,u32,u64,u64);
const R:&str="/home/ubuntu/src/zopro-perf-work/c7a-worker-residence176";
const A:&str="/home/ubuntu/src/zopro-perf-work/accepted-current-c7a176";
fn read(p:impl AsRef<Path>)->String{fs::read_to_string(p).unwrap()}
fn hex(s:&str)->u64{u64::from_str_radix(s.trim_start_matches("0x"),16).unwrap()}
fn cat(s:&str)->&'static str{
 if s.contains("crossbeam_epoch"){"epoch"}
 else if s.contains("rayon_core")||s.contains("crossbeam_deque"){"scheduler"}
 else if s.contains("stream_g1_impl"){"g1_stream"}
 else if s.contains("g2_borrowed")&&s.contains("apply"){"g2_apply"}
 else {"other"}
}
fn distribution(v:&[u64])->Value{
 let sum:u64=v.iter().sum();let mut sorted=v.to_vec();sorted.sort_unstable_by(|a,b|b.cmp(a));
 if sum==0{return json!({"period":0,"threads":v.len(),"nonzero":0});}
 let mut n90=0;let mut partial=0u64;while (partial as f64)<sum as f64*0.9 {partial+=sorted[n90];n90+=1;}
 let sq:f64=v.iter().map(|&x|(x as f64).powi(2)).sum();
 json!({"period":sum,"threads":v.len(),"nonzero":v.iter().filter(|&&x|x>0).count(),"effective_threads":(sum as f64).powi(2)/sq,"top_thread_percent":100.*sorted[0]as f64/sum as f64,"threads_for_90_percent":n90,"min":v.iter().min(),"max":sorted[0]})
}
fn main()->Result<(),E>{
 let r=Path::new(R);let a=Path::new(A);let b=a.join("remote-results/output/measure");
 let pins: BTreeMap<String,String>=serde_json::from_str(&read(r.join("pins.json")))?;
 for(p,h)in &pins{assert_eq!(&format!("{:x}",Sha256::digest(fs::read(p)?)),h,"pin {p}");}
 let quality:Value=serde_json::from_str(&read(a.join("quality.json")))?;
 let mut nm=Vec::new();
 for l in read(r.join("projection/native-symbols/stdout.log")).lines(){let f=l.split_whitespace().collect::<Vec<_>>();if f.len()>=4&&f[0].len()==16&&f[1].len()==16 {nm.push((hex(f[0]),hex(f[1]),f[3..].join(" ")));}}
 nm.sort_by_key(|s|s.0);
 let mut asm=BTreeMap::<u64,String>::new();
 for l in read(r.join("projection/native-assembly/stdout.log")).lines(){let f=l.split('\t').collect::<Vec<_>>();if f.len()>=3 {if let Some(s)=f[0].trim().strip_suffix(':'){if s.bytes().all(|b|b.is_ascii_hexdigit()){asm.insert(hex(s),f[2..].join(" "));}}}}
 let elf=fs::read(a.join("sdk-accepted-znver4"))?;assert_eq!(&elf[..6],b"\x7fELF\x02\x01");
 let u64at=|off:usize|u64::from_le_bytes(elf[off..off+8].try_into().unwrap());
 let u16at=|off:usize|u16::from_le_bytes(elf[off..off+2].try_into().unwrap());
 let ph=u64at(32)as usize;let stride=u16at(54)as usize;let mut loads=vec![];
 for i in 0..u16at(56)as usize{let o=ph+i*stride;let kind=u32::from_le_bytes(elf[o..o+4].try_into().unwrap());let flags=u32::from_le_bytes(elf[o+4..o+8].try_into().unwrap());if kind==1&&flags&1!=0 {loads.push((u64at(o+8),u64at(o+16),u64at(o+32)));}}
 let mut reports=vec![];
 for name in ["cycles-1x2-w32-accepted","cycles-1x2-w96-accepted","cycles-1x2-w32-aeglos","cycles-1x2-w96-aeglos"]{
  let old=read(b.join("workflow").join(format!("symbols-{name}")).join("stdout.log"));
  let mut keys=BTreeMap::<Key,(usize,String)>::new();let mut threads=BTreeMap::<u32,(usize,BTreeMap<String,u64>)>::new();let mut ip_bins=BTreeMap::<(u64,String),u64>::new();let mut pids=BTreeSet::new();let mut total=0u64;let mut samples=0;
  for l in old.lines().map(str::trim).filter(|l|!l.is_empty()&&!l.starts_with('#')){
   assert!(!l.contains("PERF_RECORD_LOST"));let f=l.split_whitespace().collect::<Vec<_>>();let(pid,tid)=f[0].split_once('/').unwrap();let(pid,tid)=(pid.parse::<u32>()?,tid.parse::<u32>()?);let period=f[1].parse::<u64>()?;assert!(period>0);let ip=hex(f[2]);let raw=f[3..].join(" ");let symbol=rustc_demangle::try_demangle(&raw).map(|s|format!("{s:#}")).unwrap_or(raw);
   let ent=keys.entry((pid,tid,period,ip)).or_insert((0,symbol.clone()));assert_eq!(ent.1,symbol);ent.0+=1;
   let t=threads.entry(tid).or_default();t.0+=1;*t.1.entry("all".into()).or_default()+=period;*t.1.entry(cat(&symbol).into()).or_default()+=period;
   *ip_bins.entry((ip,symbol)).or_default()+=period;pids.insert(pid);total=total.checked_add(period).unwrap();samples+=1;
  }
  assert_eq!(pids.len(),1);let pid=*pids.first().unwrap();
  let q=quality["profiles"].as_array().unwrap().iter().find(|q|q["name"]==name).unwrap();assert_eq!(q["profile"]["samples"].as_u64().unwrap()as usize,samples);assert_eq!(q["profile"]["period"].as_u64().unwrap(),total);assert_eq!(q["profile"]["lost_records"],0);
  let new=read(r.join("projection").join(format!("time-mmap-{name}")).join("stdout.log"));let mut newkeys=BTreeMap::<Key,usize>::new();let mut mapping=None;let mut first=u64::MAX;let mut last=0;let mut observed=0;
  for l in new.lines().map(str::trim).filter(|l|!l.is_empty()&&!l.starts_with('#')){
   assert!(!l.contains("PERF_RECORD_LOST"));
   if l.contains("PERF_RECORD_MMAP2"){
    if name.ends_with("accepted")&&l.contains(&format!("PERF_RECORD_MMAP2 {pid}/{pid}:"))&&l.ends_with("/usr/local/bin/cr-previous"){
     let s=l.split_once('[').unwrap().1;let (start,tail)=s.split_once('(').unwrap();let(len,tail)=tail.split_once(')').unwrap();let off=tail.split_once('@').unwrap().1.split_whitespace().next().unwrap();assert!(mapping.is_none());mapping=Some((hex(start),hex(len),hex(off)));
    }continue;
   }
   if l.contains("PERF_RECORD_"){continue;}
   let f=l.split_whitespace().collect::<Vec<_>>();assert_eq!(f.len(),4,"unexpected projection row {l}");let(p,t)=f[0].split_once('/').unwrap();let(sec,frac)=f[1].trim_end_matches(':').split_once('.').unwrap();assert!(frac.len()<=9);let time=sec.parse::<u64>()?*1_000_000_000+frac.parse::<u64>()?*10u64.pow(9-frac.len()as u32);
   let k=(p.parse::<u32>()?,t.parse::<u32>()?,f[2].parse::<u64>()?,hex(f[3]));*newkeys.entry(k).or_default()+=1;first=first.min(time);last=last.max(time);observed+=1;
  }
  assert_eq!(observed,samples);assert_eq!(keys.len(),newkeys.len());for(k,(count,_))in &keys{assert_eq!(newkeys.get(k),Some(count),"old/new mismatch {k:?}");}
  let summary=read(b.join("workflow").join(format!("measure-{name}")).join("stdout.log"));let summary:Value=serde_json::from_str(summary.lines().find_map(|l|l.strip_prefix("SUMMARY ")).unwrap())?;
  let mut workers=BTreeMap::<u32,usize>::new();
  if name.ends_with("accepted"){for w in summary["placement_after"]["worker_rows"].as_array().unwrap(){workers.insert(w["tid"].as_u64().unwrap()as u32,w["index"].as_u64().unwrap()as usize);}assert_eq!(workers.len(),summary["workers"].as_u64().unwrap()as usize);assert!(threads.keys().all(|&t|t==pid||workers.contains_key(&t)));}
  let mut dist=BTreeMap::new();
  for c in ["all","epoch","scheduler","g1_stream","g2_apply"]{
   let ids=if workers.is_empty(){threads.keys().copied().filter(|&t|t!=pid).collect::<Vec<_>>()}else{workers.keys().copied().collect::<Vec<_>>()};
   dist.insert(c,distribution(&ids.iter().map(|t|threads.get(t).and_then(|x|x.1.get(c)).copied().unwrap_or(0)).collect::<Vec<_>>()));
  }
  let mut rows=vec![];for(t,(n,bins))in &threads{rows.push(json!({"tid":t,"samples":n,"periods":bins,"caller":*t==pid,"worker_index":workers.get(t)}));}
  let mut ips=vec![];
  if let Some((start,len,off))=mapping{
   let mut candidates=loads.iter().filter(|&&(o,_,size)|off>=o&!4095&&off<o+size);let &(o,v,_)=candidates.next().unwrap();assert!(candidates.next().is_none());let mapped_v=(v&!4095)+(off-(o&!4095));let bias=start.checked_sub(mapped_v).unwrap();
   for((ip,symbol),period)in ip_bins.iter().filter(|((_,s),_)|s.contains("crossbeam_epoch")){
    assert!(*ip>=start&&*ip<start+len);let address=ip-bias;let known=nm.iter().find(|(s,n,name)|address>=*s&&address<*s+*n&&name==symbol).unwrap_or_else(||panic!("symbol mismatch {address:x} {symbol}"));
    let(at,instruction)=asm.range(..=address).next_back().unwrap();assert_eq!(*at,address,"sample not at instruction boundary");
    ips.push(json!({"ip":format!("0x{ip:x}"),"elf_address":format!("0x{address:x}"),"symbol":symbol,"symbol_offset":address-known.0,"instruction":instruction,"period":period,"profile_percent":100.*(*period as f64)/total as f64}));
   }
   ips.sort_by_key(|v|std::cmp::Reverse(v["period"].as_u64().unwrap()));
  }
  let report=json!({"name":name,"samples":samples,"period":total,"pid":pid,"sampled_tids":threads.len(),"registered_workers":workers.len(),"sample_time_span_ns":last-first,"caller":threads.get(&pid).map(|(n,b)|json!({"samples":n,"periods":b})),"distributions_excluding_caller":dist,"threads":rows,"epoch_instruction_sites":ips});
  println!("{name}: {} samples, {} threads; distributions {}",samples,threads.len(),report["distributions_excluding_caller"]);
  if name.ends_with("accepted"){for v in report["epoch_instruction_sites"].as_array().unwrap().iter().take(8){println!("  {} {} {} {}",v["elf_address"],v["period"],v["instruction"],v["symbol"]);}}
  reports.push(report);
 }
 fs::write(r.join("analysis.json"),serde_json::to_vec_pretty(&json!({"profiles":reports,"new_proofs":0,"new_recordings":0,"sample_multisets_reconcile":true,"absolute_period_coverage_unvalidated":true,"instantaneous_concurrency_measured":false}))?)?;
 Ok(())
}
