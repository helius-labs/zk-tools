use zopro_bn254::{Fp,FpConfig,FqConfig,FrConfig,ifma8::{Ifma8,FixedFactor8}};
macro_rules! wrappers {
    ($c:ty,$m:literal,$om:ident,$nm:ident,$ob:ident,$nb:ident) => {
        #[no_mangle]#[inline(never)]pub fn $om(x:&Ifma8<$c,$m>,w:&Ifma8<$c,$m>)->Ifma8<$c,$m>{x.mul(w)}
        #[no_mangle]#[inline(never)]pub fn $nm(x:&Ifma8<$c,$m>,w:&FixedFactor8<$c>)->Ifma8<$c,$m>{w.mul(x)}
        #[no_mangle]#[inline(never)]pub fn $ob(x:&[Ifma8<$c,$m>;2],w:&Ifma8<$c,$m>)->[Ifma8<$c,$m>;2]{let t=x[1].mul(w);[x[0].add(&t),x[0].sub(&t)]}
        #[no_mangle]#[inline(never)]pub fn $nb(x:&[Ifma8<$c,$m>;2],w:&FixedFactor8<$c>)->[Ifma8<$c,$m>;2]{let t=w.mul(&x[1]);[x[0].add(&t),x[0].sub(&t)]}
    };
}
wrappers!(FqConfig,true,fixed_old_fq256,fixed_new_fq256,butterfly_old_fq256,butterfly_new_fq256);
wrappers!(FqConfig,false,fixed_old_fq260,fixed_new_fq260,butterfly_old_fq260,butterfly_new_fq260);
wrappers!(FrConfig,true,fixed_old_fr256,fixed_new_fr256,butterfly_old_fr256,butterfly_new_fr256);
wrappers!(FrConfig,false,fixed_old_fr260,fixed_new_fr260,butterfly_old_fr260,butterfly_new_fr260);
fn main(){std::hint::black_box([
fixed_old_fq256 as *const(),fixed_new_fq256 as *const(),butterfly_old_fq256 as *const(),butterfly_new_fq256 as *const(),
fixed_old_fq260 as *const(),fixed_new_fq260 as *const(),butterfly_old_fq260 as *const(),butterfly_new_fq260 as *const(),
fixed_old_fr256 as *const(),fixed_new_fr256 as *const(),butterfly_old_fr256 as *const(),butterfly_new_fr256 as *const(),
fixed_old_fr260 as *const(),fixed_new_fr260 as *const(),butterfly_old_fr260 as *const(),butterfly_new_fr260 as *const()]);}

#[cfg(test)]mod emitted_oracles {
    use super::*;use ark_ff::{PrimeField,BigInteger};use ark_bn254::{Fq as Aq,Fr as Ar};use zopro_bn254::ifma8::FixedFactor;
    fn next(s:&mut u64)->u64{*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;*s}
    fn random<A:PrimeField>(s:&mut u64)->A{let bytes:Vec<_>=(0..4).flat_map(|_|next(s).to_le_bytes()).collect();A::from_le_bytes_mod_order(&bytes)}
    fn host<C:FpConfig,A:PrimeField>(x:A)->Fp<C>{Fp::from_le_bytes_mod_order(&x.into_bigint().to_bytes_le())}
    fn canon<C:FpConfig,A:PrimeField>(x:Fp<C>)->A{A::from_le_bytes_mod_order(&x.to_canonical().into_iter().flat_map(u64::to_le_bytes).collect::<Vec<_>>())}
    fn check<C:FpConfig,A:PrimeField,const M:bool>(old:fn(&Ifma8<C,M>,&Ifma8<C,M>)->Ifma8<C,M>,new:fn(&Ifma8<C,M>,&FixedFactor8<C>)->Ifma8<C,M>,ob:fn(&[Ifma8<C,M>;2],&Ifma8<C,M>)->[Ifma8<C,M>;2],nb:fn(&[Ifma8<C,M>;2],&FixedFactor8<C>)->[Ifma8<C,M>;2]){
        let mut seed=0x6669786266742d38+u64::from(M);let mut a:[A;8]=core::array::from_fn(|_|random(&mut seed));let mut b:[A;8]=core::array::from_fn(|_|random(&mut seed));let mut values=[Ifma8::new(&a.map(host::<C,A>)),Ifma8::new(&b.map(host::<C,A>))];let mut outputs=0;
        for row in 0..1024 {if row%64==0{a=core::array::from_fn(|_|random(&mut seed));b=core::array::from_fn(|_|random(&mut seed));values=[Ifma8::new(&a.map(host::<C,A>)),Ifma8::new(&b.map(host::<C,A>))];}let w:[A;8]=core::array::from_fn(|i|if row%16==0&&i<3{match i{0=>A::from(0u64),1=>A::from(1u64),_=>-A::from(1u64)}}else{random(&mut seed)});
            let normal=w.map(host::<C,A>);let original=Ifma8::new(&normal);let factors=FixedFactor8::new(&normal.map(|x|FixedFactor::<C>::from_canonical(x.to_canonical()).unwrap()));let product=new(&values[1],&factors);assert_eq!(product.get(),old(&values[1],&original).get());let got=nb(&values,&factors);let baseline=ob(&values,&original);assert_eq!(got[0].get(),baseline[0].get());assert_eq!(got[1].get(),baseline[1].get());let p=product.get();let left=got[0].get();let right=got[1].get();for i in 0..8{let t=b[i]*w[i];assert_eq!(canon::<C,A>(p[i]),t);assert_eq!(canon::<C,A>(left[i]),a[i]+t);assert_eq!(canon::<C,A>(right[i]),a[i]-t);a[i]+=t;b[i]=a[i]-t-t;outputs+=3;}values=got;
        }
        assert_eq!(outputs,24576);println!("FIXED_EMITTED prime={} radix={} rows=1024 field_outputs={outputs} native_lazy_butterfly_chains=true",if C::P==FqConfig::P{"Fq"}else{"Fr"},if M{256}else{260});
    }
    #[test]fn fq256_release_wrappers(){check::<FqConfig,Aq,true>(fixed_old_fq256,fixed_new_fq256,butterfly_old_fq256,butterfly_new_fq256);}
    #[test]fn fq260_release_wrappers(){check::<FqConfig,Aq,false>(fixed_old_fq260,fixed_new_fq260,butterfly_old_fq260,butterfly_new_fq260);}
    #[test]fn fr256_release_wrappers(){check::<FrConfig,Ar,true>(fixed_old_fr256,fixed_new_fr256,butterfly_old_fr256,butterfly_new_fr256);}
    #[test]fn fr260_release_wrappers(){check::<FrConfig,Ar,false>(fixed_old_fr260,fixed_new_fr260,butterfly_old_fr260,butterfly_new_fr260);}
}
