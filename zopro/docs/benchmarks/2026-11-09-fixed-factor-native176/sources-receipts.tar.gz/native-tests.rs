use ark_bn254::{Fq as Aq,Fr as Ar};
use ark_ff::{PrimeField,BigInteger,Field};
use num_bigint::BigUint as U;
use zopro_bn254::{Fp,FpConfig,FqConfig,FrConfig,ifma8::{Ifma8,FixedFactor,FixedFactor8}};
fn words(v:[u64;4])->U{U::from_bytes_le(&v.into_iter().flat_map(u64::to_le_bytes).collect::<Vec<_>>())}
fn repr(x:&U)->[u64;4]{let v=x.to_u64_digits();assert!(v.len()<=4);let mut out=[0;4];out[..v.len()].copy_from_slice(&v);out}
fn digits(x:&U)->[u64;5]{std::array::from_fn(|j|((x>>(52*j))&U::from((1u64<<52)-1)).to_u64_digits().first().copied().unwrap_or(0))}
fn integer(d:[u64;5])->U{d.iter().enumerate().map(|(j,&w)|{assert!(w<(1u64<<52));U::from(w)<<(52*j)}).sum()}
fn lane(d:&[[u64;8];5],i:usize)->U{integer(std::array::from_fn(|j|d[j][i]))}
fn ark<A:PrimeField>(x:&U)->A{A::from_le_bytes_mod_order(&x.to_bytes_le())}
fn ai<A:PrimeField>(x:A)->U{U::from_bytes_le(&x.into_bigint().to_bytes_le())}
fn next(s:&mut u64)->u64{*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;*s}
fn random(s:&mut u64,limit:&U)->U{words(std::array::from_fn(|_|next(s)))%limit}
fn edges(limit:&U,p:&U)->Vec<U>{let mut out=vec![U::from(0u8),U::from(1u8),limit.clone()];for k in[1u8,2]{for delta in[-1i32,0,1]{let base=p*k;let value=if delta<0{base-U::from(1u8)}else{base+U::from(delta as u8)};if &value<=limit{out.push(value);}}}for bit in[1usize,51,52,53,63,64,103,104,105,127,128,155,156,157,191,192,207,208,209,251,252,253]{for delta in[-1i32,0,1]{let base=U::from(1u8)<<bit;let value=if delta<0{base-U::from(1u8)}else{base+U::from(delta as u8)};if &value<=limit{out.push(value);}}}out.sort();out.dedup();out}
fn exact(x:&U,w:&U,p:&U)->U{let r=U::from(1u8)<<260;let q=w*&r/p;let xd=digits(x);let qd=digits(&q);let mut h=U::from(0u8);for i in 0..5{for j in 0..5{let product=U::from(xd[i])*qd[j];if i+j>=5{h+=product<<(52*(i+j-5));}else if i+j==4{h+=product>>52;}}}assert!(h<=x*w/p);let rem=x*w-h*p;assert!(rem<p*10u8);let mu=(U::from(1u8)<<52)/((p>>208)+U::from(1u8));let k=((&rem>>208)*mu)>>52;let out=rem-k*p;assert!(out<p*2u8);out}
fn check<C:FpConfig,A:PrimeField,const M:bool>(){let p=words(C::P);assert_eq!(p,U::from_bytes_le(&A::MODULUS.to_bytes_le()));let p2=&p*2u8;let xs=edges(&p2,&p);let ws=edges(&(&p-U::from(1u8)),&p);let cached:Vec<_>=ws.iter().map(|w|{let f=FixedFactor::<C>::from_canonical(repr(w)).unwrap();let(a,q)=f.fixed_digits();assert_eq!(integer(a),*w);assert_eq!(integer(q),w*(U::from(1u8)<<260)/&p);f}).collect();assert!(FixedFactor::<C>::from_canonical(C::P).is_none());assert!(FixedFactor::<C>::from_canonical([u64::MAX;4]).is_none());let rinv=A::from(2u64).pow([if M{256}else{260}]).inverse().unwrap();let mut seed=if M{0x6d69786564666978}else{0x756e69666f726d38};let mut chain:[U;8]=std::array::from_fn(|_|random(&mut seed,&(&p2+U::from(1u8))));let mut comparisons=0;let mut broadcasts=0;let rows=xs.len()*ws.len()+1024+512;
for row in 0..rows {let x:[U;8]=if row<xs.len()*ws.len(){std::array::from_fn(|i|xs[(row/ws.len()+i*7)%xs.len()].clone())}else if row<xs.len()*ws.len()+1024{std::array::from_fn(|_|random(&mut seed,&(&p2+U::from(1u8))))}else{chain.clone()};let w:[U;8]=if row<xs.len()*ws.len(){std::array::from_fn(|i|ws[(row%ws.len()+i*11)%ws.len()].clone())}else{std::array::from_fn(|_|random(&mut seed,&p))};let factors:[FixedFactor<C>;8]=std::array::from_fn(|i|{let f=if row<xs.len()*ws.len(){cached[(row%ws.len()+i*11)%ws.len()]}else{FixedFactor::from_canonical(repr(&w[i])).unwrap()};let(a,q)=f.fixed_digits();assert_eq!(integer(a),w[i]);assert_eq!(integer(q),&w[i]*(U::from(1u8)<<260)/&p);f});let expanded=FixedFactor8::new(&factors);let raw=unsafe{Ifma8::<C,M>::fixed_raw(&x.each_ref().map(repr))};let out=expanded.mul(&raw);let output=out.fixed_digits();let exported=out.get();let ordinary=Ifma8::<C,M>::new(&w.each_ref().map(|w|Fp::<C>::from_le_bytes_mod_order(&w.to_bytes_le())));assert_eq!(exported,raw.mul(&ordinary).get());
for i in 0..8{let n=lane(&output,i);assert_eq!(n,exact(&x[i],&w[i],&p));assert!(n<p2);assert_eq!(&n%&p,(&x[i]*&w[i])%&p);assert_eq!(words(exported[i].to_canonical()),ai(ark::<A>(&x[i])*ark::<A>(&w[i])*rinv));chain[i]=n;comparisons+=1;}
if row%17==0{let uniform=factors[0].broadcast().mul(&raw);let d=uniform.fixed_digits();let got=uniform.get();for i in 0..8{assert_eq!(lane(&d,i),exact(&x[i],&w[0],&p));assert_eq!(words(got[i].to_canonical()),ai(ark::<A>(&x[i])*ark::<A>(&w[0])*rinv));broadcasts+=1;}}
}
assert_eq!(std::mem::size_of::<FixedFactor<C>>(),80);assert_eq!(std::mem::size_of::<FixedFactor8<C>>(),640);println!("FIXED_NATIVE prime={} radix={} x_edges={} w_edges={} rows={rows} lane_outputs={comparisons} broadcast_outputs={broadcasts} scalar_factor_bytes=80 expanded_factor_bytes=640",if C::P==FqConfig::P{"Fq"}else{"Fr"},if M{256}else{260},xs.len(),ws.len());}
#[test]fn fq_mixed_fixed_factors(){check::<FqConfig,Aq,true>();}
#[test]fn fq_uniform_fixed_factors(){check::<FqConfig,Aq,false>();}
#[test]fn fr_mixed_fixed_factors(){check::<FrConfig,Ar,true>();}
#[test]fn fr_uniform_fixed_factors(){check::<FrConfig,Ar,false>();}
