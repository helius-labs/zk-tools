# Reader generation failures before clocks

The first prepare-readers generator failed looking for a leading space before `let mut codegen`, before writing any reader. prepare-readers2 fixes that selector and writes preflight.rs, pilot-prepare.rs and pilot-analyze.rs. It then fails an assertion because the general `helper_samples` substitution already consumed the `paired_helper_samples` key targeted by the next replacement. Both failed generator sources remain. Tool-reported failure outputs are summarized here, not reconstructed as raw receipts.

prepare-diagnostic.rs creates only the missing diagnostic reader, applies the specific key substitution first, records all four parent/output hashes and copies the existing hardware-topology description. The three successful outputs and the already compiled preflight helper are retained. No native test, proof, capture, bootstrap population, verifier or decoder has run at this point.
