// Keep both outputs live across the call boundary before the caller's branch.
#[inline(never)]
pub(super) fn divrem(a:u64,b:u64)->(u64,u64){(a/b,a%b)}
