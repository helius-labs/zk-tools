use core::arch::x86_64::*;
/// Exact quotient/remainder; callers require b!=0 and AVX512F.
#[inline(always)]
pub(crate) fn divrem(a:u64,b:u64)->(u64,u64){
 debug_assert_ne!(b,0);
 if (a|b)<=u32::MAX as u64||b<=a>>16{return(a/b,a%b)}
 // Eligible quotient <2^16. Three correctly rounded operations have
 // absolute error <1, including all rounding modes of the integer model.
 // Explicit RN/SAE also preserves the caller's floating environment.
 let mut q=unsafe{
  let zero=_mm_setzero_ps();
  let x=_mm_cvt_roundu64_ss::<{_MM_FROUND_TO_NEAREST_INT|_MM_FROUND_NO_EXC}>(zero,a);
  let y=_mm_cvt_roundu64_ss::<{_MM_FROUND_TO_NEAREST_INT|_MM_FROUND_NO_EXC}>(zero,b);
  let estimate=_mm_div_round_ss::<{_MM_FROUND_TO_NEAREST_INT|_MM_FROUND_NO_EXC}>(x,y);
  _mm_cvtt_roundss_u64::<_MM_FROUND_NO_EXC>(estimate)
 };
 let mut product=q as u128*b as u128;
 if product>a as u128{q-=1;product-=b as u128;}else if a as u128-product>=b as u128{q+=1;product+=b as u128;}
 debug_assert!(product<=a as u128&&a as u128-product<b as u128);
 (q,(a as u128-product)as u64)
}
