# Complete SDK test of bounded SIMD Booth decoding

Frozen before any SDK preflight or timing. Qualified consumers are reused,
without source/compiler/field changes or native-suite replay. REF is accepted
7aff; OFF and ON are exact qualified simd-booth176 consumers. Same Rust1.98.1,
native O3/fatLTO/oneCGU driver/default worker stacks and accepted environment.
Only ON enables eight-row integer decoding. All field operations, windows,
bucket/queue boundaries and production resource policy remain original.

ALL8 plus merge54 run at32 workers; primary also at1 and16 (11 contexts).
Worker i pins to CPUi; solo pins to CPU2. Coordinator retains context mask.
Full SDK solve/fresh randomized proving/internal verification/serialization is
timed; image load, pool startup, three primes and final proof export excluded.
No concurrent-proof throughput, phone/minRAM/pressure or AWS inference.

Executable backing: create31 predetermined independent whole-ELF files per arm,
one per matched latency block, reused by contexts within that block. Use equal
length arm names and identical modes. All3 originals remain immutable. Also
create3 separate functional-preflight backings and18 separate diagnostic
backings, fixed before first SDK.114 distinct new dev/inodes total, each content
hash/mode/size/inode checked before and after the experiment. No fastest-copy
selection, discarded copy, physical-color explanation or claim that copying
normalizes all possible drift. Backing variation is part of the measured block
population. These files are benchmark fixtures, not retained prover state.

Functional preflight: all11 contexts across3 arms, one measured-but-unselected
request plus3primes,33fresh exports independently Gnark-verified before timing.
All preflight outputs retained; their clocks are not performance selection.

Latency:31 fixed matched blocks for primary16/32,15 for others.151requests per
primary16/32 process,11solo and31other, after3primes. Rotate/reverse context and
arm order by fixed block index.591latency processes, no exclusions/extensions/
compiler/layout/worker rescue. Each process mean derives from integer-rounded
SDK nanoseconds. Report median of process means and paired geometric ratios.

Diagnostics follow ALL latency:9grouped stat panels then9cycles profiles across
primary16,primary32,2x2-32 and3arms. Stat31requests; profile251requests; all3primes
excluded with existing FIFO control. Exact actual launched paths/PID/TID/CPU/
MMAP checked. Four counters cycles:u,instructions:u,cache-misses:u,branch-misses:u
require finite counts and>=99.9%running. Fixed16Muser-cycle period;>=1000samples,
<=5%unknown,zeroLOST and assigned process/thread/CPU checks. Absolute sampled
period coverage unvalidated; symbols may include inlined payload and are not
removable exclusive wall fractions. Raw profiles stay local/hash-bound; decoded
ownership/loss/counts and selected evidence are public.

Fixed79checks match the latest complete SDK campaign:11OFF/REF calibration CIs
entirely[1/1.03,1.03];22ON/control nonregression upper bounds<=1.03;22maxRSS guards
ON<=1.05control; primary32 upper bound<1 AND>=21/31winning blocks against BOTH
controls (4checks); ALL8 equal-log aggregate upper<1 against both (2checks);
9PMU+9profilequalitychecks. No arbitrary positive-gain floor. Retained20,000
fixedseed paired-log bootstrap (15/31blocks) and stratified equal-shape aggregate
are reused verbatim. Assumptions of independent exchangeable blocks/stationarity
are not guaranteed; no familywise coverage guarantee. Shared backing across
contexts and host drift can correlate observations. Retain every outcome.

All1329 workflow commands frozen before first SDK:66preflight/verification,
591latency,18diagnostic,45offline,609capture Gnark verifications. All recording
finishes before offline decoding and capture Gnark.33preflight+609capture unique
exports,642total,all164bytes;132+44,106=44,238internally checked SDK requests.
Seed original47,437 canonical proofs; intermediate47,470 and final48,079 only
after actual binding/freshness/Gnark checks. Old successful crypto work is not
replayed for bookkeeping. Private key/request/proof/ledger payload stays local.

Both raw readers, exact source/input/tool/copy pins and protocol frozen before
any functional preflight. Source/reader errors are corrected transparently
without recapture or gate changes. During ANY preflight/recording only poll the
exact live workflow handle through terminal; no owned builds/helpers/hashing/
analysis/report/push overlap. No Python, subagents or new production worker pool.

If ANY gate fails, preserve all positives/negatives and close this exact recipe;
do not adopt or reroll a favorable subset. If all pass, further required portable/
concurrent/resource compatibility review precedes default changes. No component
or ALL8aggregate gain achieves the original goal by itself. Full goal remains
verified CPU AVX single-proof>=10× supplied M5 CPU for EACH ALL8, reporting CPU+
Metal comparisons. Commit AND push each completed experiment, polite factual
report, update canonical and checkpoint, then continue the full objective.
