# Preparation exceptions before SDK preflight

The first direct campaign prepare exits101 while source_provenance attempts
UTF-8 decoding on every member of the176-file accepted manifest. The manifest
includes binary fixtures. This occurs after114 predetermined executable copies
are created and before any capture plan, FIFO, SDK request or performance clock.
Original common.rs/campaign_ops.rs and captured prepare.stdout/prepare.stderr
are retained. The original campaign and reader executables remain local under
their before-utf8 names; no successful SDK/native qualification is repeated.

The repair hashes unedited members as raw bytes and decodes only the four known
text parents for source reversal. The preparer resumes by checking existing
cases/identities/environment/copies instead of overwriting or generating new
backings. Both affected helpers are recompiled before any SDK preflight. The
candidate SDKs, inputs,114original copies, protocol/gates, shared statistics and
sample/profile parsers remain unchanged. These are preparation/helper commands,
not a benchmark rerun or a control-layout selection.

Unchanged parser/statistics qualification is inherited. Unused-import/dead-code
helper warnings are retained without warning-only rebuilds.

The first repaired helper compiles both stop on an extra closing brace in the
source-reversal edit. common-before-brace.rs and both build-*-repaired streams
are preserved. Correcting this syntax precedes the final helper builds; no SDK
request or successful native step occurs between these preparation fixes.
