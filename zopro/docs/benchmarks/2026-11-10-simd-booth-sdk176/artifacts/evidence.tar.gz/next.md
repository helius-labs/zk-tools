# Continue after the complete SDK SIMD Booth negative

Goal ACTIVE/UNMET0/8: verified CPU AVX single-proof>=10× supplied M5 CPU for
EACH supplied shape, reporting CPU+Metal. No token budget. Do not shrink success
to a component, aggregate, a subset or a clean benchmark. User authorizes
autonomous loop/no questions, commit AND push each finished experiment, polite
factual reports. No subagents, Python/C/ASM rewrite, giant LUT/expanded key plan,
new production pool or artificial architectural RAM cap.

This goal turn made PROGRESS: exact qualified SIMD Booth SDK measured across
ALL8+54 and primary1/16/32, independently Gnark-verified and raw-reader reviewed;
the fixed candidate is slower/rejected. Next step is a DISTINCT material prover
work hypothesis after history/source checks, not an unchanged rerun of this one.

Current root /home/ubuntu/src/zopro-perf-work/simd-booth-sdk176; report
zopro/docs/benchmarks/2026-11-10-simd-booth-sdk176/README.md. Publication commit
and exact remote verification are recorded in checkpoint.json after push. Do not
assume pending publication completed; inspect actual git/checkpoint state.

NO LIVE RECORDING: workflow41138 TERMINAL0,1329 commands succeeded once. Primary
analysis87405 TERMINAL0 first execution. Frozen separate raw reader81380
TERMINAL0 first execution. Both readers/gates/statistics/scripts were frozen
before ANY functional SDK preflight. Do not poll/restart old handles, repeat
native qualification or replay successful crypto/decoder work for bookkeeping.

RESULT73/79. All11control calibrations,22nonregressions,22RSS guards,9PMU quality,
9profile quality PASS. The6 failures are both primary gain+win checks and both
ALL8gain checks. No minimum-gain floor; no excluded blocks, added samples,
favorable subset, compiler/layout/worker rescue or recapture. Exact recipe CLOSED.

Primary32 REF7.811658450331126ms / OFF7.817748417218542 / ON7.898484205298013.
ON/OFF1.01453273516558 CI[1.0118763457371343,1.0172051059703409],1/31wins;
ON/REF1.015099936926406 CI[1.012448715443108,1.017696748518869],0/31wins.
FreshOFF/REF1.0005591 CI[.99889725,1.00222827]. Clean calibration, not an invalid
control effect. ALL8 ON/OFF1.0048687361 CI[1.0024731719,1.0073231076]; ON/REF
1.0057840116 CI[1.0036008247,1.0079478060]. Both aggregates slower above parity.
Solo ON/OFF1.015373 CI[1.011646,1.019045],0/15;16workers1.017860
CI[1.016441,1.019332],0/31. General scalar/SMT split does not rescue recipe.

Positive retained: merge54 ON162.454621ms vsOFF163.726624/REF163.261357.
PairedON/OFF.994360416 CI[.989796837,.999745660],12/15; ON/REF.996112042
CI[.991797673,1.000166596],9/15. Not confirmed against BOTH controls; no shape
subset adoption. Larger shapes mostly parity intervals; retain all exact tables.

Mechanism: packet SIMD Booth decoder, constant16-byte output stack array, no new
heap/key table/cache/expanded execution plan. Original point/queue/batch/field
work untouched; scalar tail original. Different from prior SIMD bucket admission
and full digit-plane matrix (both remain rejected). Candidate loses despite a
small instruction reduction: single primary32 stat panel ON/OFF instructions
.99385818,cycles1.0153405,branchmisses1.10485,cachemisses1.00176.16worker panel
instructions.9934452,cycles1.0268275;2x2 instructions.996269,cycles1.0471884.
These are descriptive single panels, not a replicated causal attribution or
proof that branch misses, gathers, code size or particular cache level caused it.
Do not claim fewer instructions implies faster CPU work.

Profiles:120,094 actual samples across9profiles (8,830–18,495), maxunknown1.964%,
zeroLOST, actualPID/TID/CPU/binaryMMAP/fixed16Mperiod ownership checked. All9PMU
groups>=99.9%running. Profile symbols include inlined payload; epoch/runtime
samples are NOTidle, removable wall time or syscalls. Absolute sampled period
coverage unvalidated. Raw9perf.data+all decoded/mapping/loss outputs retained.
Current primaryON profile: G1stream20.14%,G2borrowed15.88%,epochwithhandle8.34%,
scalarinverse7.02%,balancedG1feed5.94%,G2reduce5.83%,G1reduce4.18%,G2feed3.15%.
These flat samples are NOTexclusive critical-path fractions. Existing operation
census/front-end/IBS and scheduling studies should be read before repeating them.

Resource: primary32 REF/OFF/ON maxRSS133.75/136.25/133.25MiB, medianCPUperproof
178.139/178.290/180.874ms;minor129.205/129.940/128.305. Primary16 RSS89/88.5/87.5,
CPU117.249/117.224/119.786ms.54RSS1965.828/1950.781/1937.766MiB. Process RSS
includes loading/primes and retained buffers, not minRAM or a stack bound.
Usage counters cover timed batch; current actual driver exports major_faults,
and ALL609 timed/diagnostic batches record zero major faults. Do not repeat
earlier stage's claim that this driver has no major-fault field. Fault counts
do not give service time; no phone/pressure/swap/minRAM/concurrent-throughput
qualification follows.

BACKING DESIGN:114 predeclared independently written complete-ELF copies:
31perarm latencybackings reused by contexts within block,3separatepreflight and
18separatediagnostic backings. Allsame775mode/equal-length arm names/newunique
dev/inodes/nlink1, exact complete SHA/length/mode/dev/inode checked before/after;
all114copies retained, none selected/discarded. Sources immutable. No fixedASLR
or physical-color claim. This incorporates variation prospectively, not a
production copy optimization or a retroactive rescue of old invalid controls.
Copies are disk benchmark fixtures, not retained key lookup tables.

Frozen schedule:33SDKfunctionalpreflights+33Gnark,591latencies (31primary16/32
blocks×151requests,15otherblocks×31exceptsolo11),9stat×31 and9profiles×251,
3primes each,45offline profile operations,609captureGnark verifications.1329
serialized commands;44,238internally checked SDK requests;642fresh unique164-byte
Gnark-verified exports. All8+54 complete solve/prove/verify/serialize timed at32,
primary1/16; default SDK worker stacks, fixed workersCPUi/soloCPU2. Startup,
loading,3primes and final export excluded. No owned helper/build/hash/report/
analysis overlapped ANYpreflight/recording: only exact live41138 polled through
terminal, then primary/readers. Same retained Rust1.98 xtask, no SDK/native rebuild.

Frozen statistics copied BYTEEXACT from compiler199-sdk176/statistics.rs:
20kfixedseed paired-logbootstrap15/31blocks, stratified equal-shape aggregate.
No familywise/stationarity/independent-block guarantee. Controls have only small
measured calibration intervals; copy independence not proof all host effects
eliminated. Reader independently reconstructs591raw integer means/79gates/
609capture+33preflight exports/402pins/current176source reversal/114backings,
shares qualified diagnostic and statistical parsers, is same agent not external
audit. Native qualification129tests/8.56Mdigits/219060exactintegers/45056Ark
buckets inherited from previous f42a739630, not rerun. Actual consumers unchanged.

Preparation exceptions retained: firstsourcecheck decoded all176manifestmembers
asUTF8, hit binaryfixture after114copies butbeforeANYSDK/plan; repair hashes
unedited bytes and reverses only4textparents, reuses exact existingcopies. First
repair compile hadextrabrace, bothfailedstreams preserved. Finalhelperbuilds
pass beforefreeze. No successful native stage/copy/SDK repeated. Currentreader
and analysis both pass firstexecution; gates/rawsamples/canonical counts unchanged.

NEW CANONICAL48,079:
/home/ubuntu/src/zopro-perf-work/simd-booth-sdk176/proof-sha256-after-capture.json
SHA7c57aaa1b5940cb51f5b0b82234026e16b617148cf121bbf90681013cd5630f9.
EVERY future export must seed THIS, not old47437/46828/46802. Intermediate47470
from33preflights, plus609capture=48079. Original47437ledger remains immutable.
Do not use most recent old prompt's canonical path without this correction.

Production176/accepted SDK7aff unchanged. Latest fresh accepted ALL8 localms:
7.811658450331126 /10.96752770967742 /15.786866354838711 /
23.926490258064515 /33.76707877419355 /39.718288225806454 /
66.22940858064516 /66.08023770967742.
Primary16=9.168598701986754;solo94.29869063636365;54=163.26135729032256.
These are observations of the SAME accepted build, not new adoption. Prior7.86
and7.77 observations remain separate campaigns. Accepted SDK:
/home/ubuntu/src/zopro-perf-work/busy-reset-sdk176/sdk-ON
SHA7aff5f602a1e250a6b9b28889bf6278b51ec400af8399c7481c36248a8718d01.
Accepted corebusy-reset176/libs/ON/libzopro_core.rlib, field1200 in
g2-vector-sign-default175/frozen/candidate. Preserveallmanualcfgs densebusyreset.

Rejected exact SDKs remain simd-booth176/sdk-OFF SHA7abaa14cc6b0908e373786fe0674c27bb8084ac5dee12e6010bf77d4a785b38f
and sdk-ON SHAd6b18ee4e37d190e3ca2ba13786aefb6b450cb9e65f5c66c7388a0243f01fe8a.
No unchanged comparison, faster-copy choice or source-constant tweak rescue.
Different future algorithm requires genuine new design/history check and freshly
frozen complete consumer validation. Don't claim all SIMD recoding impossible.

M5CPU37/59/109/189/284/335/528/507ms,Metal24/30/48/74/101/124/176/175,
CPU10×limits3.7/5.9/10.9/18.9/28.4/33.5/52.8/50.7. Shapes1x2,2x2,4x2,8x2,
12x2,16x2,24x2,merge24x1. Historicaldifferenthardware refs, not remeasured;0/8
on local andAWS.54noM5reference. No newAWS/Aeglos/huge250/4999/ARM/TEE/phone/
pressure/swap/minRAM/concurrentproof result. AWS accepted2026-11-10-accepted-current-c7a176:
1x2Z11.243892ms32/122.52MiB vsA7.902802ms96/479.98MiB;A32=11.870012.
54Z120.757128ms64/2003.02MiB vsA171.908504ms96/13102.11MiB. Zbest6/9.
Only earlierc7ai-0a15ad9ae313aa976TERMINATED/cleanupverified, no cloud here.

NEXT: return to actual point work/critical-path reduction after targeted history
checks; not more identical-control/backing studies or unchanged whole-frontend/
IBS recapture. Current data already has full accepted+candidate profiles and raw
addresses; use these before recording another profile. Existing large histories
from backing-control176/next.md and simd-booth176/next.md include closed queue
scan/drain, four-lane MSM, digit matrices, scalar class/grouping, field outlining,
GLS4/ring/LFG/R260/VNNI/FMA/Toom/coordination paths. Do not re-propose unchanged
methods just because names match a fresh paper. Original10×goal still needs a
large material improvement; this candidate supplies a clean negative, not one.

Autoresearch: history+primarypapers/code -> distinct bounded hypothesis ->
meaningful independent math/native/portable/concurrent/resource qualification ->
freeze coherent actual consumers/accepted+fresh controls/inputs/order/gates/two
readers/automaticprofiles BEFOREanypreflight -> serializedRust1.98xtask -> ONLY
pollexactconfirmedlivehandleduringANYpreflight/recordingthroughterminal (no
helper/build/hash/analyze/report/push overlap;timeout/truncationnotterminal) ->
allrecordingbeforeoffline -> ALL8+54SDK/Gnark/resource/compatibilityreview before
adoption -> polite report -> commitANDpush/exactremote -> NEWcanonical/checkpoint
-> continue fullgoal. Do not markcomplete/blocked merely because hard/slow.

ExplicitRust1.98.1 compiler (ambient1.99.1):
/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc.
xtask /home/ubuntu/src/zopro-perf-work/tool-target/release/xtask; helperdeps same
tool-target/release/deps, nofatLTO with nonbitcodehelpers. Commentary<=60sec;
poll30+20. Stageonlynewreportdir; olduntrackedreportsuntouched. Git gc.auto=0,
HTTP/1.1, httpsinsteadOfgit@github.com:, gh auth git-credential; push
HEAD:refs/heads/sergei/zopro-cpu-perf thenverifyexactls-remote.
