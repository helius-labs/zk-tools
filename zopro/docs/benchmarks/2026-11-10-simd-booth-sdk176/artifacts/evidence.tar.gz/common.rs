use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{fs,path::{Path,PathBuf},io::{Read,BufRead,BufReader},process::{Command,Stdio},collections::{BTreeMap,BTreeSet}};
const R:&str="/home/ubuntu/src/zopro-perf-work/simd-booth-sdk176";
const Q:&str="/home/ubuntu/src/zopro-perf-work/simd-booth176";
const PRIOR:&str="/home/ubuntu/src/zopro-perf-work/compiler199-sdk176/proof-sha256-after-capture.json";
const REF:&str="/home/ubuntu/src/zopro-perf-work/busy-reset-sdk176/sdk-ON";
const VERIFY:&str="/home/ubuntu/src/zopro-perf-work/batch-local-steal/gnark/verify";
const LEDGER:&str="/home/ubuntu/src/zopro-perf-work/simd-booth-sdk176/proof-sha256-after-preflight.json";
const ARMS:[&str;3]=["REF","OFF","ON"];
fn r(p:impl AsRef<Path>)->PathBuf{Path::new(R).join(p)}
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn save(p:impl AsRef<Path>,v:&Value){assert!(!p.as_ref().exists(),"{}",p.as_ref().display());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn step(name:&str,argv:Vec<String>,env:Value)->Value{json!({"kind":"command","name":name,"argv":argv,"environment":env,"timeout_seconds":1800})}
fn blocks(c:&Value)->usize{if c["shape"]=="1x2"&&c["workers"]!=1{31}else{15}}
fn receipt(folder:&str,s:&Value){
 let base=r(format!("{folder}/{}",s["name"].as_str().unwrap()));let exit=read(base.join("exit.json"));assert_eq!(exit["returncode"],0);assert_eq!(exit["success"],true);for stream in["stdout","stderr"]{assert_eq!(hash(base.join(format!("{stream}.log"))),exit[format!("{stream}_sha256")]);}let cmd=read(base.join("command.json"));assert_eq!(&cmd["argv"].as_array().unwrap()[4..],s["argv"].as_array().unwrap());for(k,v)in s["environment"].as_object().into_iter().flatten(){assert_eq!(cmd["environment"][k],*v);}
}
fn check_backings(){
 use std::os::unix::fs::{MetadataExt,PermissionsExt};let copies=read(r("copies.json"));assert_eq!(copies.as_array().unwrap().len(),114);let mut seen=BTreeSet::new();
 for c in copies.as_array().unwrap(){let p=c["path"].as_str().unwrap();let m=fs::metadata(p).unwrap();assert_eq!(hash(p),c["sha256"]);assert_eq!(m.dev(),c["dev"]);assert_eq!(m.ino(),c["ino"]);assert_eq!(m.len(),c["bytes"]);assert_eq!(m.permissions().mode(),c["mode"]);assert_eq!(m.nlink(),1);assert!(seen.insert((m.dev(),m.ino())));let src=c["source"].as_str().unwrap();assert_eq!(hash(src),c["sha256"]);let src=fs::metadata(src).unwrap();assert_ne!((m.dev(),m.ino()),(src.dev(),src.ino()));}
}
fn source_provenance()->Value{
 let qual=read(format!("{Q}/review-result.json"));assert_eq!(qual["passed"],true);assert_eq!(qual["native_core_tests_passed"],129);assert_eq!(qual["independent_digit_comparisons"],8562812);assert_eq!(qual["independent_Arkworks_bucket_outputs"],45056);
 let a=read(format!("{Q}/source-audit.json"));let manifest=read("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json");assert_eq!(a["originals"],manifest["source_files_sha256"]);assert_eq!(a["originals"].as_object().unwrap().len(),176);
 for (p,h) in a["originals"].as_object().unwrap() {
     assert_eq!(hash(format!("/home/ubuntu/src/zk-tools/zopro/{p}")),h.as_str().unwrap());
     let bytes=fs::read(format!("{Q}/source/{p}")).unwrap();
     if let Some(e)=a["edits"].as_array().unwrap().iter().find(|e|e["path"]==p.as_str()) {
         let mut s=String::from_utf8(bytes).unwrap();
         if e["kind"]=="suffix" {
             s=s.strip_suffix(e["after"].as_str().unwrap()).unwrap().to_string();
         } else {
             if let Some(suffix)=e.get("suffix") {
                 s=s.strip_suffix(suffix.as_str().unwrap()).unwrap().to_string();
             }
             assert_eq!(s.matches(e["after"].as_str().unwrap()).count(),1);
             s=s.replace(e["after"].as_str().unwrap(),e["before"].as_str().unwrap());
         }
         assert_eq!(format!("{:x}",Sha256::digest(s.as_bytes())),h.as_str().unwrap());
     } else {
         assert_eq!(format!("{:x}",Sha256::digest(bytes)),h.as_str().unwrap());
     }
 }
 let ids=read(r("identities.json"));for(arm,expected)in[("REF","7aff5f602a1e250a6b9b28889bf6278b51ec400af8399c7481c36248a8718d01"),("OFF","7abaa14cc6b0908e373786fe0674c27bb8084ac5dee12e6010bf77d4a785b38f"),("ON","d6b18ee4e37d190e3ca2ba13786aefb6b450cb9e65f5c66c7388a0243f01fe8a")]{assert_eq!(ids[arm]["sha256"],expected);assert_eq!(hash(ids[arm]["binary"].as_str().unwrap()),expected);}
 for (plan,folder)in[("plan-v1.json","runs-v1"),("sdk-plan.json","sdk-runs")]{let p=read(format!("{Q}/{plan}"));assert_eq!(read(format!("{Q}/{folder}/result.json"))["status"],"complete");for s in p["steps"].as_array().unwrap(){let d=format!("{Q}/{folder}/{}",s["name"].as_str().unwrap());let e=read(format!("{d}/exit.json"));assert_eq!(e["returncode"],0);for stream in["stdout","stderr"]{assert_eq!(hash(format!("{d}/{stream}.log")),e[format!("{stream}_sha256")]);}let cmd=read(format!("{d}/command.json"));assert_eq!(&cmd["argv"].as_array().unwrap()[4..],s["argv"].as_array().unwrap());}}
 assert_eq!(read(PRIOR).as_array().unwrap().len(),47437);assert_eq!(hash(PRIOR),"04f436ae856d2f68595d6b97bb79ce73517d91501d2a203153bf52f0f26aeda8");
 check_backings();json!({"passed":true,"source176_recovered":true,"production176_unchanged":true,"qualified_native129_and_independent_math_inherited_not_replayed":true,"exact_qualified_consumers_reused":true,"same_field1200":true,"same_driver_default_stacks":true,"predetermined114_independent_executable_backings_checked":true,"portable_compile_only_not_ARM_execution":true})
}
