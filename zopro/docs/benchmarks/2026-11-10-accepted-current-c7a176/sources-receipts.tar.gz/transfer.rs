//! Private owned-bucket transport; presigned command files are secret and excluded from reports.
#[path = "sigv4.rs"]
mod sigv4;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, io::Read, os::unix::fs::PermissionsExt, path::Path, process::Command};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/accepted-current-c7a176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn aws(args: &[&str]) -> Value {
    let o = Command::new("aws")
        .args([
            "--profile",
            "dev",
            "--region",
            "eu-north-1",
            "--no-cli-pager",
        ])
        .args(args)
        .output()
        .unwrap();
    assert!(
        o.status.success(),
        "AWS transport operation failed; credential-bearing error text is not logged"
    );
    if o.stdout.iter().all(|b| b.is_ascii_whitespace()) {
        Value::Null
    } else {
        serde_json::from_slice(&o.stdout).unwrap()
    }
}
fn presign(bucket: &str, key: &str) -> String {
    let credentials = aws(&["configure", "export-credentials", "--format", "process"]);
    let date = Command::new("date")
        .args(["-u", "+%Y%m%dT%H%M%SZ"])
        .output()
        .unwrap();
    assert!(date.status.success());
    sigv4::url(
        "PUT",
        &format!("{bucket}.s3.eu-north-1.amazonaws.com"),
        "eu-north-1",
        key,
        credentials["AccessKeyId"].as_str().unwrap(),
        credentials["SecretAccessKey"].as_str().unwrap(),
        credentials["SessionToken"].as_str(),
        String::from_utf8(date.stdout).unwrap().trim(),
        900,
    )
}
fn sha(p: &Path) -> String {
    let mut f = fs::File::open(p).unwrap();
    let mut h = Sha256::new();
    let mut b = [0u8; 65536];
    loop {
        let n = f.read(&mut b).unwrap();
        if n == 0 {
            break;
        }
        h.update(&b[..n]);
    }
    format!("{:x}", h.finalize())
}
fn main() {
    let op = std::env::args().nth(1).unwrap();
    let r = Path::new(ROOT);
    let id = fs::read_to_string(r.join("run-id.txt")).unwrap();
    let bucket = format!("zopro-{id}-558215002830");
    assert!(bucket.len() <= 63);
    let key = "results.tar.gz";
    match op.as_str() {
        "create" => {
            if r.join("bucket.json").exists() {
                assert_eq!(read(r.join("bucket.json"))["name"], bucket);
            } else {
                let created = aws(&[
                    "s3api",
                    "create-bucket",
                    "--bucket",
                    &bucket,
                    "--create-bucket-configuration",
                    "LocationConstraint=eu-north-1",
                ]);
                save(
                    r.join("bucket.json"),
                    &json!({"name":bucket,"key":key,"run_id":id,"create":created,"purpose":"owned temporary benchmark transfer"}),
                );
            }
            aws(&["s3api","put-public-access-block","--bucket",&bucket,"--public-access-block-configuration","BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"]);
            aws(&["s3api","put-bucket-tagging","--bucket",&bucket,"--tagging",&format!("TagSet=[{{Key=Purpose,Value=TemporaryProverBenchmark}},{{Key=RunId,Value={id}}}]")]);
            println!("Created private owned transfer bucket");
        }
        "test" => {
            assert_eq!(read(r.join("bucket.json"))["name"], bucket);
            let key = "transport-check";
            let path = r.join("transport-check.txt");
            fs::write(&path, b"owned benchmark transport check\n").unwrap();
            let url = presign(&bucket, key);
            let response = r.join("transport-response.secret");
            let o = Command::new("curl")
                .args(["--silent", "--show-error", "--fail", "--output"])
                .arg(&response)
                .arg("--upload-file")
                .arg(&path)
                .arg(&url)
                .output()
                .unwrap();
            if response.exists() {
                fs::set_permissions(&response, fs::Permissions::from_mode(0o600)).unwrap();
            }
            assert!(o.status.success(), "private upload transport check failed");
            let downloaded = r.join("transport-check-downloaded.txt");
            aws(&[
                "s3api",
                "get-object",
                "--bucket",
                &bucket,
                "--key",
                key,
                downloaded.to_str().unwrap(),
            ]);
            assert_eq!(fs::read(&path).unwrap(), fs::read(&downloaded).unwrap());
            aws(&["s3api", "delete-object", "--bucket", &bucket, "--key", key]);
            save(
                r.join("transport-check.json"),
                &json!({"status":"passed","bytes":fs::metadata(&path).unwrap().len(),"scoped_put_then_get_hash_match":true,"test_object_deleted":true}),
            );
            println!("One-object presigned transport check passed; test object removed");
        }
        "upload" => {
            assert_eq!(read(r.join("bucket.json"))["name"], bucket);
            assert!(!r.join("upload-command.json").exists());
            let package = read(r.join("package-result.json"));
            assert_eq!(package["Status"], "Success");
            let url = presign(&bucket, key);
            let base = format!("/var/tmp/zopro-{id}");
            let parameters = json!({"commands":["set -eu",format!("curl --silent --show-error --fail --output {base}/upload-response.secret --upload-file {base}/results.tar.gz '{url}'"),"echo owned-upload-complete"],"executionTimeout":["600"]});
            let secret = r.join("upload-parameters.secret.json");
            save(&secret, &parameters);
            fs::set_permissions(&secret, fs::Permissions::from_mode(0o600)).unwrap();
            let instance = fs::read_to_string(r.join("instance-id.txt")).unwrap();
            let out = aws(&[
                "ssm",
                "send-command",
                "--instance-ids",
                instance.trim(),
                "--document-name",
                "AWS-RunShellScript",
                "--comment",
                &format!("Owned {id} private artifact upload"),
                "--parameters",
                &format!("file://{}", secret.display()),
            ]);
            save(
                r.join("upload-command.json"),
                &json!({"Command":{"CommandId":out["Command"]["CommandId"],"InstanceIds":out["Command"]["InstanceIds"]},"sensitive_parameters_excluded":true}),
            );
            save(
                r.join("upload-parameters-redacted.json"),
                &json!({"command":"curl scoped900second PUT URL to owned bucket/key; URL excluded","bucket":bucket,"key":key,"parameter_sha256":sha(&secret)}),
            );
            println!("Submitted private artifact upload; URL not logged");
        }
        "poll" => {
            let command = read(r.join("upload-command.json"));
            let instance = fs::read_to_string(r.join("instance-id.txt")).unwrap();
            let out = aws(&[
                "ssm",
                "get-command-invocation",
                "--command-id",
                command["Command"]["CommandId"].as_str().unwrap(),
                "--instance-id",
                instance.trim(),
            ]);
            let redacted = json!({"Status":out["Status"],"ResponseCode":out["ResponseCode"],"ExecutionStartDateTime":out["ExecutionStartDateTime"],"ExecutionEndDateTime":out["ExecutionEndDateTime"],"sensitive_command_output_excluded":true});
            save(r.join("upload-result.json"), &redacted);
            println!("Upload status: {}", out["Status"]);
        }
        "download" => {
            assert_eq!(read(r.join("upload-result.json"))["Status"], "Success");
            let package = read(r.join("package-result.json"));
            let output = package["StandardOutputContent"].as_str().unwrap();
            let mut lines = output.lines().rev();
            let bytes = lines.next().unwrap().trim().parse::<u64>().unwrap();
            let expected = lines.next().unwrap().split_whitespace().next().unwrap();
            assert_eq!(expected.len(), 64);
            let target = r.join("results.tar.gz");
            assert!(!target.exists());
            aws(&[
                "s3api",
                "get-object",
                "--bucket",
                &bucket,
                "--key",
                key,
                target.to_str().unwrap(),
            ]);
            assert_eq!(fs::metadata(&target).unwrap().len(), bytes);
            assert_eq!(sha(&target), expected);
            save(
                r.join("retrieval-complete.json"),
                &json!({"status":"downloaded and remote SHA256/size matched","bytes":bytes,"sha256":expected,"bucket":bucket,"key":key}),
            );
            println!("Downloaded owned archive; {bytes}bytes and SHA256 verified");
        }
        "cleanup" => {
            assert!(r.join("retrieval-complete.json").exists());
            assert_eq!(read(r.join("bucket.json"))["name"], bucket);
            aws(&["s3api", "delete-object", "--bucket", &bucket, "--key", key]);
            let list = aws(&[
                "s3api",
                "list-objects-v2",
                "--bucket",
                &bucket,
                "--no-paginate",
            ]);
            assert_eq!(list["KeyCount"], 0);
            assert!(!list["IsTruncated"].as_bool().unwrap());
            aws(&["s3api", "delete-bucket", "--bucket", &bucket]);
            save(
                r.join("bucket-cleanup.json"),
                &json!({"status":"owned object removed; bucket deleted","bucket":bucket}),
            );
            fs::remove_file(r.join("upload-parameters.secret.json")).unwrap();
            println!("Owned transfer object/bucket removed and secret URL file deleted");
        }
        _ => panic!("unknown transport operation"),
    }
}
