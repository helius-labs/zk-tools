# Accepted Zopro and pinned Aeglos on C7a

The current accepted Zopro source measures **11.243892ms** for1x2 at32workers, versus pinned Aeglos **11.870012ms** at the same count. The paired Zopro/Aeglos ratio is0.950116[0.942381,0.952890],15/15wins. Aeglos reaches **7.902802ms** at96workers; Zopro's fastest tested count remains32. Zopro has the lower displayed best-count median on six of nine circuits; Aeglos on1x2,2x2,4x2. These best-count selections are descriptive, with same-worker paired results retained below.

At their fastest tested counts, primary RSS is122.52MiB for Zopro and479.98MiB for Aeglos. For54-to-1,Zopro64 measures120.757128ms with2003.02MiB RSS versus Aeglos96's171.908504ms and13102.11MiB. RSS includes setup and preparation; these are not minimum RAM requirements. No supplied M5CPU10x target is met.

This is a fresh Zen4 build of all176accepted source files, Rust1.98.1/LLVM22.1.8, `target-cpu=znver4`, nativeO3/fat-LTO/one-CGU and the existing manual flags, including dense busy reset. SDK SHA256 is `d5e1b2c981fb9bcab2beb69e3b2af5608d298d792c7e3814e87273b04509662e`. It is a distinct architecture build, not the byte-identical local Zen5 executable. The accepted fixed-worker-placement SDK driver and default worker stacks are used. The local7.772288ms result remains local; it is not an AWS measurement. Production is unchanged. The rejected packed G2 filter is excluded.

Aeglos reuses pinned commit0290613e8eeca17a4ce88f6f2d726e8e06a5385d,Sorted engine,qualified native archive and pool-aware SDK adapter. It is not asserted to be latest upstream. Both engines use the established matching keys, requests and public-input bindings. Aeglos retains its native24GiB preparation limit and existing setup/cache policy; Zopro adds no expanded key table or solver plan.

One c7a.24xlarge instance provides96physical cores without SMT. Whole processes pin to0..N-1 for32/64/96workers; Zopro additionally checks each worker's fixed CPU mask before and after proof timing. Aeglos uses its existing pool-aware driver under the same process affinity. Physical-host exclusivity is not established. The network-disabled container has CPUquota96,memory30GiB,no swap and pids2048; the container bound is a harness setting, not an architectural RAM cap or minimum. All three worker counts, all nine shapes and both engines are fixed before capture.

Fifteen fixed blocks rotate/reverse context and engine order. Primary processes measure101requests after three primes; other circuits17after three. Each cell is the median of15process medians. A paired ratio divides corresponding process medians by block; bounds are sorted zero-based ranks3/7/11, nominal96.484375% marginal median coverage conditional on independent exchangeable blocks, without familywise or stationarity guarantees. No extra blocks, exclusions or timing reruns occur. Timers cover fresh assignment/witness solving, proof randomness, proving, internal verification and serialization; they exclude image load, key preparation and primes. CPU columns are medians of per-process mean user+system CPU milliseconds per request. RSS is maximum process lifetime RSS over15processes, including load/preparation/primes.

|Circuit|Workers|Zopro ms|Aeglos ms|Zopro CPU ms|Aeglos CPU ms|Zopro RSS MiB|Aeglos RSS MiB|Zopro/Aeglos [bounds], wins|
|---|---:|---:|---:|---:|---:|---:|---:|---|
|1x2|32|11.243892|11.870012|247.072|327.646|122.52|428.12|0.950116[0.942381,0.952890],15/15|
|1x2|64|11.567772|8.852565|432.758|428.870|124.72|445.51|1.285063[1.265591,1.317852],0/15|
|1x2|96|13.502813|7.902802|771.838|518.202|118.04|479.98|1.711440[1.693327,1.740419],0/15|
|2x2|32|15.263659|18.574454|343.181|536.961|223.98|725.20|0.822767[0.809091,0.826758],15/15|
|2x2|64|16.214128|13.140633|631.251|681.470|223.78|752.74|1.235636[1.193169,1.244625],0/15|
|2x2|96|18.416164|11.679913|1095.825|831.031|214.80|810.55|1.584437[1.551735,1.596794],0/15|
|4x2|32|19.648714|30.778427|504.262|911.380|272.52|1257.91|0.638439[0.633860,0.641463],15/15|
|4x2|64|19.121785|20.871367|881.273|1142.282|268.83|1280.09|0.922530[0.893927,0.926474],15/15|
|4x2|96|21.297714|18.240823|1470.066|1392.436|283.82|1350.33|1.162406[1.140540,1.178891],0/15|
|8x2|32|27.347865|54.574932|753.469|1653.467|466.35|2311.38|0.499854[0.495530,0.518695],15/15|
|8x2|64|25.894916|35.399268|1319.592|2069.819|458.53|2381.57|0.729232[0.723040,0.738316],15/15|
|8x2|96|28.751237|30.951086|2165.413|2575.393|470.99|2467.30|0.930833[0.913002,0.948533],15/15|
|12x2|32|35.822934|87.049778|1005.536|2641.868|643.13|3438.30|0.412832[0.409825,0.426193],15/15|
|12x2|64|33.778290|56.072003|1688.772|3329.409|657.43|3522.01|0.606768[0.596509,0.613222],15/15|
|12x2|96|36.647819|48.320431|2651.011|4124.206|662.32|3722.73|0.755233[0.745555,0.768114],15/15|
|16x2|32|41.956174|104.945834|1195.580|3160.794|801.33|4335.46|0.400828[0.394144,0.406741],15/15|
|16x2|64|37.977699|65.117610|1895.459|3862.278|766.29|4413.95|0.583497[0.576315,0.587619],15/15|
|16x2|96|41.937149|56.830844|2947.662|4882.137|783.02|4618.36|0.734419[0.729043,0.752428],15/15|
|24x2|32|60.656766|170.564406|1782.102|5170.000|1271.06|6481.65|0.356375[0.351469,0.362491],15/15|
|24x2|64|53.297583|104.927354|2612.471|6192.447|1223.63|6471.72|0.511228[0.497894,0.513103],15/15|
|24x2|96|57.663959|86.494125|3869.749|7407.500|1221.12|6877.96|0.667928[0.661162,0.675173],15/15|
|merge-24x1|32|61.736049|164.943925|1725.477|5023.130|1094.82|6172.62|0.373136[0.368007,0.382405],15/15|
|merge-24x1|64|56.324672|101.016373|2592.544|5966.855|1114.06|6257.07|0.558641[0.552034,0.565433],15/15|
|merge-24x1|96|61.869262|84.047696|3992.681|7222.138|1122.89|6599.03|0.735945[0.733222,0.748602],15/15|
|merge-54x1|32|138.695323|345.936677|3672.023|10657.675|2175.59|12596.56|0.401397[0.393593,0.405777],15/15|
|merge-54x1|64|120.757128|206.945251|4709.187|12156.837|2003.02|12612.08|0.583617[0.578314,0.599423],15/15|
|merge-54x1|96|125.244950|171.908504|6591.391|14890.209|2075.50|13102.11|0.729394[0.725099,0.742096],15/15|

Zopro wins all nine matched32worker comparisons, seven at64 and six at96; all winning comparisons have15/15wins and bounds below parity, and the complementary comparisons have0/15. At respective fastest tested counts, Zopro uses32workers for1x2/2x2 and64for the remaining seven; Aeglos uses96for all nine.

The supplied M5CPU/Metal references are historical measurements on different hardware, not devices remeasured here. The table uses each circuit's fastest tested Zopro count; selecting those counts does not establish a portable production selection policy.

|Circuit|Zopro workers / ms|M5CPU ms / speedup|M5Metal ms / speedup|CPU10x target ms|
|---|---:|---:|---:|---:|
|1x2|32 / 11.243892|37 / 3.291x|24 / 2.134x|3.7|
|2x2|32 / 15.263659|59 / 3.865x|30 / 1.965x|5.9|
|4x2|64 / 19.121785|109 / 5.700x|48 / 2.510x|10.9|
|8x2|64 / 25.894916|189 / 7.299x|74 / 2.858x|18.9|
|12x2|64 / 33.778290|284 / 8.408x|101 / 2.990x|28.4|
|16x2|64 / 37.977699|335 / 8.821x|124 / 3.265x|33.5|
|24x2|64 / 53.297583|528 / 9.907x|176 / 3.302x|52.8|
|merge-24x1|64 / 56.324672|507 / 9.001x|175 / 3.107x|50.7|

No reference is supplied for54-to-1. The24x2 result,53.297583ms,is close to the52.8ms target but does not satisfy it. The complete CPU AVXsingle-proof10x goal remains active and unmet,0/8.

Primary Zopro latency worsens from11.243892to13.502813ms as workers rise32to96, while CPU service rises247.072to771.838ms/request. Aeglos latency falls11.870012to7.902802ms while CPU service rises327.646to518.202ms. At32,Zopro uses less CPU and lower latency on this workload; the larger-worker comparison identifies a scalability problem worth investigating. The historical October29Zopro best-count observation was11.915591ms; the new11.243892ms is about5.6%lower descriptively. Different campaign, build and worker-placement conditions prevent attributing that difference solely to the source change.

After all810latency processes and their independent verifications, four FIFO-gated primary user-cycle profiles run251requests each after three primes, at32/96workers for both engines. All four captures end before decoding. They contain97089samples with zeroLOST and one sampled PID each. Absolute sample-period coverage is unvalidated.

|Profile|Samples|Sampled TIDs|Epoch %|Scheduler %|Unknown period %|
|---|---:|---:|---:|---:|---:|
|cycles-1x2-w32-accepted|13039|33|8.77|5.31|2.52|
|cycles-1x2-w32-aeglos|17214|40|0.00|0.00|1.06|
|cycles-1x2-w96-accepted|39821|97|53.08|11.93|2.10|
|cycles-1x2-w96-aeglos|27015|104|0.00|0.00|1.26|

Zopro's combined epoch/scheduler residence rises14.08%to65.01%. G1stream flat period totals remain47.29to47.50billion and G2borrowed36.62to37.57billion across equal251request windows; the coordinator/epoch symbols grow sharply. These samples support investigating work availability, scheduling and work amplification. They are not exclusive wall-time fractions or a prediction that removing a symbol removes its sampled share of latency. They do not isolate frequency, cache, DRAM capacity, fences or a syscall cause.

The inherited category rules name Rust symbols; Aeglos therefore appears in`other`, not100%unknown. Its resolved C++symbols are retained. A descriptive post-capture grouping gives Pool::work about16.06%at32and25.87%at96. That function can include work and coordination and is not an idle-time measurement. No direct category equivalence between that function and Rust epoch samples is asserted.

The whole-container workflow records46throttled periods and341760throttled microseconds. This scope includes load/preparation/primes/latency/profiles/verifiers, so it cannot be attributed to an engine's timed proof. All memory/swap/OOMevent deltas are zero; cgroup peak is13896298496bytes across the full workflow. This provides no evidence of a RAM-capacity limit causing the measured gap. It does not establish minimum RAM or absence of cache/bandwidth costs.

|Primary engine|Workers|Median minor faults/request|Median major faults/request|
|---|---:|---:|---:|
|accepted|32|181.832|0.000|
|accepted|64|195.614|0.000|
|accepted|96|199.050|0.000|
|aeglos|32|34.584|unreported|
|aeglos|64|71.851|unreported|
|aeglos|96|91.317|unreported|

Minor faults can include demand-zero/first-touch or mapping work; they do not by themselves establish disk paging. Aeglos's driver does not report major faults here. No pressure/swap/mobile/ARM/TEE,huge250/4999or concurrent-throughput qualification is added.

Fresh Zen4 qualification passes35field,127core and8prover tests. Exact-container local preflight performs72SDKrequests and18fresh independent Gnark exports across nine shapes/two engines at four workers. AWS performs24776requests and814fresh exports:810latency and4profiles. All832new exports are164bytes with expected public bindings, independently verified and disjoint from prior/new proof identities. The retrieved archive's6174518bytes and SHA256 match remote output. All814transported proofs are independently reverified locally once; this adds no new proofs. Canonical count advances45335to46167. Every future export must seed accepted-current-c7a176/proof-sha256-after-capture.json.

The producer and independent-rank reader are compiled and pinned before local preflight. Producer succeeds; the original reader's direct in-memory-versus-reparsed JSON equality fails on10floating values, with maximum relative difference1.991e-16. A post-capture comparison-only repair retains the original ranking computation and requires its serialized output bytes to equal the producer's file exactly. That stricter representation comparison passes. Original source/binary/failure logs are retained; no performance number, threshold or capture changes, and neither successful producer nor proof verification is rerun. This is a same-agent cross-check with shared parsing, not an external audit.

The validated receipt inventory contains1697commands:1694successes and3retained failures. All1640cloud and36local-container workflow commands pass. Host failures are the initial typed link, first container permission attempt and original rank reader. The typed link referenced an old artifact path/default1.99compiler; an explicit Rust1.98.1link uses newly frozen accepted-source dependencies. Five successful native build/test/freeze steps are retained without replay. The first container attempt stops before SDK calls because capability dropping prevents root from writing the Ubuntu-owned output directory; adding its existing group fixes local access. Two initial typed-plan parse errors and a premature plan lookup execute no command or SDK request. Direct preparer/compiler/lifecycle invocations are separate from the receipt count. During every functional preflight/recording only its confirmed live handle is polled; no owned build/helper/hash/analysis/report/progress task overlaps capture. The AWS command runs44minutes.

The prior qualification subnet/securitygroup/profile no longer existed. Launch resolves to existing resources: a no-ingress group and public subnet, plus an existing SSM/ECR-read-only instance profile. No network or IAM resource is created or modified. Exactly one owned instance,i-0a15ad9ae313aa976,uses encrypted delete-on-termination storage and a90minute termination timer. After SHA-checked retrieval it is terminated; the volume is absent, temporary ECRtag and private S3object/bucket are removed, and local Docker auth/signed URL files are absent. Cleanup is complete; no production resource changes.

The next optimization should address useful work and coordination at larger pools while preserving the current memory behavior. The prior packed exception filter remains rejected. This benchmark changes no production prover algorithm or acceptance policy.

[All results](artifacts/analysis.json),[best-count selection](artifacts/best-counts.json),[profiles and faults](artifacts/quality.json),[reader](artifacts/review.json),[reader audit](artifacts/reader-failure-audit.json),[proof checks](artifacts/post-verification.json),[build identity](artifacts/build-identity.json),[source audit](artifacts/source-audit.json),[protocol](artifacts/design.md),[container hashes without ledger](artifacts/container-manifest-without-ledger.json),[receipts](artifacts/receipts.json),[cleanup](artifacts/cleanup.json),[raw perf data](raw-perf-data.tar.gz),[sources and raw driver streams](sources-receipts.tar.gz),[archive index](artifacts/archive-index.json),[checksums](SHA256SUMS).
