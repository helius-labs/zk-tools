pub fn aggregate(strata:&BTreeMap<String,Vec<f64>>)->Value {
 assert_eq!(strata.len(),4);assert!(strata.values().all(|v|v.len()==15||v.len()==31));
 fn rng(s:&mut u64)->u64{*s=s.wrapping_add(0x9e3779b97f4a7c15);let mut z=*s;z=(z^(z>>30)).wrapping_mul(0xbf58476d1ce4e5b9);z=(z^(z>>27)).wrapping_mul(0x94d049bb133111eb);z^(z>>31)}
 let gm=(strata.values().map(|v|v.iter().map(|r|r.ln()).sum::<f64>()/v.len()as f64).sum::<f64>()/4.).exp();let mut seed=0x551c36a48ee2d971;let mut boot=Vec::with_capacity(20000);
 for _ in 0..20000{let mut sum=0.;for v in strata.values(){let mut local=0.;for _ in 0..v.len(){local+=v[(rng(&mut seed)%v.len()as u64)as usize].ln();}sum+=local/v.len()as f64;}boot.push((sum/4.).exp());}boot.sort_by(f64::total_cmp);
 json!({"equal_log_geomean":gm,"stratified_bootstrap95":[boot[499],boot[19499]],"ratios_by_context":strata,"block_counts":strata.iter().map(|(k,v)|(k,v.len())).collect::<BTreeMap<_,_>>(),"within_context_resampling_not_synchronized":true})
}
