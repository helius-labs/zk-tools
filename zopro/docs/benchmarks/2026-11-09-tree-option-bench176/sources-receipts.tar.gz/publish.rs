use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fmt::Write as _, fs, path::{Path, PathBuf}, process::Command};
const R: &str = "/home/ubuntu/src/zopro-perf-work/tree-option-bench176";
const D: &str = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-tree-option-bench176";
fn read(p: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(p).unwrap()).unwrap() }
fn hash(p: impl AsRef<Path>) -> String { format!("{:x}", Sha256::digest(fs::read(p).unwrap())) }
fn save(p: impl AsRef<Path>, v: Value) { fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap() }
fn walk(p: &Path, out: &mut Vec<PathBuf>) {
    for e in fs::read_dir(p).unwrap() {
        let e = e.unwrap();
        if e.file_type().unwrap().is_dir() { walk(&e.path(), out); }
        else if e.file_type().unwrap().is_file() { out.push(e.path()); }
    }
}
fn contrast(p: &Value) -> String {
    format!("{:.6} [{:.6}, {:.6}], {}", p["paired_geomean"].as_f64().unwrap(), p["bootstrap95"][0].as_f64().unwrap(), p["bootstrap95"][1].as_f64().unwrap(), p["wins"])
}
fn main() {
    assert!(!Path::new(D).exists());
    let a = read(format!("{R}/analysis.json"));
    let review = read(format!("{R}/review-result.json"));
    assert_eq!(review["passed"], true);
    assert_eq!(a["gate_passed"], false);
    assert_eq!(a["failed_checks"], review["failed_checks"]);
    assert_eq!(a["failed_checks"].as_array().unwrap().len(), 9);
    assert_eq!(review["numeric_checks"], 89);
    assert_eq!(review["profile_samples"], 93509);
    for (p, h) in read(format!("{R}/capture-pins.json")).as_object().unwrap() { assert_eq!(hash(p), h.as_str().unwrap()); }
    let ledger = "/home/ubuntu/src/zopro-perf-work/negative-phi-sdk176/proof-sha256-after-capture.json";
    assert_eq!(read(ledger).as_array().unwrap().len(), 41104);
    let decision = json!({
        "gate_passed": false, "failed_checks": a["failed_checks"],
        "closed_without_adoption_or_unchanged_recapture": true,
        "exact_tree_option_owner_recipe_closed": true,
        "no_posthoc_compiler_layout_threshold_or_subset_rescue": true,
        "primary_component_positive_retained": true,
        "reason": "Calibrated balanced20-w32 gains 0.899% against accepted REF and 2.617% against OFF. Eight other fresh-control calibrations fail and the four-context aggregate gain against REF is unproven. The complete declared gate fails 9 of 89 checks.",
        "full_SDK_followup_selected": false, "production_changed": false,
        "next": "Select a materially distinct bounded-work/dependency hypothesis from full-proof profiles and closed-history evidence. Retain this primary positive without treating it as proof latency or overriding the frozen gate.",
        "canonical_proofs": 41104, "ledger_sha256": hash(ledger), "new_proofs": 0,
        "goal_active": true, "goal_complete": false
    });
    save(format!("{R}/decision.json"), decision);
    let notes = json!({
        "native_qualification_inherited": "Parent tree-option-owner176: first native run52194 retained a test fixture failure at G2 weighted length65, violating the original power-of-two debug precondition. Only cfg(test) length65->64 was repaired; repair69880 completed. Successful OFF/ON release libraries were not rebuilt. This comparison reuses those exact release identities.",
        "benchmark_preparation": "Three identical-driver native O3/fatLTO/one-CGU links completed. Existing weighted-double-bench176 fixture/oracle files, driver and perf support reused byte-exact, without regeneration. The separate review reader inherited 1e-12 floating comparison tolerance before clocks; there was no post-capture reader repair in this experiment.",
        "capture_session": 82958, "capture_terminal_exit": 0,
        "capture_steps": 735, "all_recordings_terminal_before_analysis": true,
        "prospective_reader_passed_before_clocks": true,
        "no_new_proofs": true
    });
    save(format!("{R}/preparation-notes.json"), notes);
    let next = r#"# Continue after the tree-option owner comparison

Goal active/unmet: verified CPU AVX single-proof >=10x supplied M5 CPU ALL8; report CPU and Metal. Accepted local 1x2 is ALREADY below8ms:7.832707987ms median of process means. Historical7.699867ms was a different campaign/statistic. Do not portray the latest component gain as a new sub8ms milestone or subtract it from full-proof latency.

Private root /home/ubuntu/src/zopro-perf-work/tree-option-bench176. Read protocol.md,analysis.json,review-result.json,decision.json,preparation-notes.json,publication.json. Capture82958 terminal0/735steps;3driverlinks terminal0;prospective reader and separate post reader PASS. No live recording/cloud. Parent native test-only fixture repair is inherited, not a new release build or replay.

Actual three-arm complete weighted consumer:13conditions,633latencyprocesses/690callers,205833timedlatencywaves,291576completewaves includingdiagnostics/primes/post,1357590completeweightedcalls. Repeated componentcalls,notproofs/uniqueinputs. Nine qualified PMUpanels+9profiles/93509samples/zeroLOST/maxunknown1.415%. Source+library+flags+actualbinary/TID/CPU identities checked. Canonical41104 unchanged,0newSDK/Gnark/proofs.

Primarybalanced20-w32 REF/OFF/ON0.351651411/0.358463086/0.348929199ms per20-reducerwave. ON/OFF0.973829174CI[0.969124219,0.978626878],30/31wins. ON/REF0.991014682CI[0.986330509,0.995559558],23/31wins. Primarycalibration passes; supported0.899%gainagainstacceptedmustnotbedismissed. All26nonregression+26RSSchecks+18diagnosticchecks pass. WholeprocessprimaryRSS11.25/11.50/11.25MiB,notminRAM/fullproofmemory.

CompletegateFALSE9/89:8OFF/REFcalibration failures (balanced20-w16,fallback512-w32,w16384/w2048/w4096at16and32) plusfour-context32ON/REFgain. FreshOFFismostlyslowerthanoriginalREF; don't claim ONregression or uniquely blame compiler/lock/layout. Four-contextON/OFF0.950782698CI[0.946703374,0.954580686];ON/REF0.999988405CI[0.997014015,1.002906486]. Notall8proofaggregate. Historicalfallback512fixtureISaffectedinthiscandidate,no unchangedfallbackcontrol. RSSguard5%+1MiBwasprospective,notpostresultexceptionorarchitecturalcap.

Exactoption-ownerrecipeCLOSEDwithoutadoption,unchangedrecapture,compiler/layout/threshold/subsetrescueorSDKexception. Keeppositiveprimary. A change to OFF factory layout followed by unchanged reroll is not authorized by this frozen experiment. Nextworkmustbemateriallydistinct and budget usefulwork/dependency/memoryagainstfullproofheadroom. Acceptedprimaryprofiles G1stream20.8%,G2borrowedapply15.5%,sharedinverse7.44%,G2reduce5.78%,G1balancedfeed4.72%,G1reduce4.56%,crossbeam8.28% are flat CPU shares, not wall-critical-path fractions. Weighted wave alone is ~0.35ms and not a validated subtraction from~7.83msproof. Hundreds of closed reports include indexed/columns/nativebuckets/pairedwindow/weighted8group/field/GLV/G2/FFT/scheduler variants; inspect relevant exact history before proposing a concrete distinct implementation. Do not repeat broad audits instead of progress or claim all techniques in a family are ruled out.

Autoresearch loop: inspect actual code+profiles+closedhistory -> distinct falsifiable hypothesis with useful-work/dependency/resource model -> bounded Rust implementation -> targeted independent curve/resource/generic/concurrency qualification -> freeze complete consumer and coherent SDK all8+54 controls/automatic profiles before clocks -> serialized Rust1.98.1 xtask -> ONLY poll exact live handle during ANY preflight/recording until terminal; timeout/truncation is not terminal -> all recording ends -> verify/analyze every observation -> polite factual report,commit AND push,exact remote HEAD verification,checkpoint. No questions/Python/subagents/persistentbigLUT/keyplan/newpool/artificialRAMcap/CASM. No successful inherited suites/fixtures rerun without dependency change. Positive small results matter but cannot redefine the all8 goal or bypass frozen gates.

Accepted fullproof all8 CPUms7.832707987/11.065988613/15.913588194/24.254932903/34.007119871/40.086324129/66.467587258/65.569872290;M5CPU37/59/109/189/284/335/528/507;Metal24/30/48/74/101/124/176/175;CPU10xtargets3.7/5.9/10.9/18.9/28.4/33.5/52.8/50.7,0/8met. Merge54REF162.947719ms,noM5reference. Latestshortmap7.818977unadopted. Ledger /home/ubuntu/src/zopro-perf-work/negative-phi-sdk176/proof-sha256-after-capture.json remains41104. No new AWS/Aeglos/phone/huge/swap/pressure/minRAM/concurrentthroughput result. Goal remains active.
"#;
    fs::write(format!("{R}/next.md"), next).unwrap();
    fs::create_dir_all(format!("{D}/artifacts")).unwrap();
    for f in ["analysis.json", "review-result.json", "prospective-review.json", "decision.json", "preparation-notes.json", "protocol.md", "next.md", "fixtures.json", "identities.json"] {
        fs::copy(format!("{R}/{f}"), format!("{D}/artifacts/{f}")).unwrap();
    }
    let inherited = read("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-negative-phi-sdk176/artifacts/fresh-accepted-comparison.json");
    save(format!("{D}/artifacts/accepted-comparison.json"), inherited.clone());
    let mut report = r#"# Tree-option owner complete-consumer comparison

The 32-worker balanced weighted consumer improves by 0.90% against the accepted reference and 2.62% against the fresh disabled control under the declared paired analysis. The complete gate fails nine of 89 checks: eight fresh-control calibrations and aggregate gain against the accepted reference. The primary gain is retained as a positive result; production is unchanged and this exact recipe is closed without adoption, an unchanged recapture or full-SDK follow-up.

This is a local component measurement. The accepted local full-proof 1x2 result was already **7.832708 ms**; this experiment provides no new proof timing. The historical 7.699867 ms figure used a different campaign and median of process medians. Neither figure is a matched measurement of this candidate. There is no new AWS or Aeglos comparison.

The candidate captures the tree-vector-inverse option once at entry to each nonempty grouped, indexed or weighted reduction and passes the boolean into scratch construction. It changes option ownership, leaving field arithmetic, queue geometry, Rayon task grain and allocation policy intact. It introduces no persistent lookup table, point copy, retained workspace, new pool or RAM cap. Changes to the option between calls remain visible. Native parsing, G1/G2, concurrency, generic compile and source qualification are inherited from the [parent experiment](../2026-11-09-tree-option-owner176/README.md), rather than rerun.

REF reuses the accepted 176-source core with only the common benchmark API appended. OFF and ON reuse the exact parent-qualified release cores; ON enables the private option-owner configuration. All callers use identical driver bytes and the original field, native O3, fat LTO, one codegen unit and allocator. All three actual links and source/library/binary identities were checked. One Rayon pool uses fixed CPU placement and default worker stacks on this local 16-core/32-thread machine. The generic parent build is a compile guard, not ARM execution.

Each timed wave includes the complete original weighted reduction, allocations and drops in the consumer, tree work, output collection and affine normalization. Loading, three primes and oracle checks are outside the timer. The balanced wave contains five 2048-bucket and fifteen 4096-bucket reducers, matching primary K/H bucket sizes; it excludes bucket filling, solver, FFT and proof assembly. Each other case has one reducer. Existing fixtures/oracles were reused byte-exact without regeneration: 94,720 distinct full-width scalar coefficients across 24 vectors, generated by a deterministic double-plus-fixed-point recurrence. These are neither independent random draws nor actual proving-key buckets. Every timed output is compared with its independent Arkworks oracle, and input hashes are checked for preservation. The historical label `fallback512` denotes an affected case here, with no unchanged-fallback claim or check.

|Case/workers|REF ms/wave|OFF ms/wave|ON ms/wave|ON/OFF ratio [95%], wins|ON/REF ratio [95%], wins|
|---|---:|---:|---:|---|---|
"#.to_string();
    for case in read(format!("{R}/cases.json")).as_array().unwrap() {
        let n = case["name"].as_str().unwrap();
        let cell = |arm: &str| a["cells"][format!("{n}/{arm}")]["median_ms_per_wave"].as_f64().unwrap();
        let blocks = if n == "balanced20-w32" { 31 } else { 15 };
        writeln!(report, "|{n}|{:.6}|{:.6}|{:.6}|{}/{blocks}|{}/{blocks}|", cell("REF"), cell("OFF"), cell("ON"), contrast(&a["pairs"][format!("{n}/ON/OFF")]), contrast(&a["pairs"][format!("{n}/ON/REF")])).unwrap();
    }
    report += r#"
Latency is the median of process arithmetic means of emitted integer nanosecond samples. Paired geometric ratios use corresponding blocks and 20,000 log-bootstrap resamples; medians need not divide to the paired estimate. The primary case has 31 blocks and each other case 15. Intervals assume exchangeable blocks and provide no familywise guarantee. All observations are retained without extension, exclusions or rerolls.

The primary OFF/REF calibration passes. Primary ON/OFF is 0.973829 [0.969124, 0.978627], with 30/31 wins; ON/REF is 0.991015 [0.986331, 0.995560], with 23/31 wins. Both gain and win checks pass. These support a small component gain against both controls, without establishing a full-proof gain.

The four-context native-32 aggregate is 0.950783 [0.946703, 0.954581] against OFF and 0.999988 [0.997014, 1.002906] against REF. It uses equal log weights and independent within-context resampling for 2048, 4096, 16384 and balanced20, not synchronized cross-case observations or the all-eight proof aggregate. Gain against the accepted reference is unproven.

The failed checks are retained in full:

"#;
    for f in a["failed_checks"].as_array().unwrap() { writeln!(report, "- `{}`", f.as_str().unwrap()).unwrap(); }
    report += r#"
All 26 ON/control nonregression checks, 26 RSS checks and 18 PMU/profile quality checks pass. The eight calibration failures concern the fresh OFF control versus original REF, mostly with slower OFF values; they are not evidence that ON regresses in those cases. This experiment does not establish a unique cause for the control difference. Possible compiler or constructor-layout effects require separate evidence and do not authorize a rescue of this closed recipe.

The RSS rule was fixed before clocks at ON maximum whole-process RSS <= 1.05 times control maximum plus 1 MiB. The allowance follows the existing complete-query convention for small-process granularity; it is neither an architectural cap nor a post-result exception. Balanced-wave REF/OFF/ON peaks at 32 workers are 11.25/11.50/11.25 MiB; all arms are 11.25 MiB at one and 16 workers. These component peaks include fixture and benchmark state and do not establish full-proof memory, minimum RAM or mobile behavior.

At 32 workers, balanced-wave aggregate CPU time is REF/OFF/ON 11.0468/11.1751/10.9613 ms per wave. The corresponding single descriptive PMU panels report cycles 49.909/50.490/49.331 million and retired instructions 83.141/83.522/82.828 million per wave. Cache misses are 47,101/48,862/45,308 and branch misses 52,021/51,610/49,379. These panels are observations without replication confidence intervals; they do not isolate the full-proof critical path or prove a memory-bandwidth bottleneck.

All nine grouped PMU panels meet 99.9% running coverage. All nine profiles qualify with 93,509 total samples, zero lost records, at least 1000 samples each, fixed 16M user-cycle periods, actual executable/PID/TID/CPU ownership and at most 1.415% unknown symbols. Flat sample attribution is not a wall-time critical-path fraction; absolute period coverage is unvalidated. Detailed counters and profile symbols are retained in the source/receipt archive.

The separate same-agent raw reader confirms 735 command receipts, 690 caller outputs, 633 latency rows, all 89 decisions and actual source/link/profile identities. It independently reconstructs raw means, gates and the stratified aggregate while sharing the qualified paired-bootstrap and PMU/profile parsers. The prospective reader passed before clocks; the post reader used its floating tolerance from the outset, without a new reader repair. All recording finished before analysis and publication. [Preparation notes](artifacts/preparation-notes.json) distinguish this experiment from the inherited native fixture repair.

There are 205,833 timed latency waves, 291,576 complete waves including diagnostics, primes and postchecks, and 1,357,590 complete weighted calls. These are repeated component invocations, not proofs or unique cryptographic inputs. The canonical proof ledger remains 41,104, with no new SDK requests or Gnark exports.

Further work must select a materially distinct bounded-work or dependency hypothesis from full-proof profiles and prior results. A measured ~0.35 ms component is not a validated subtraction from ~7.83 ms proof latency. This positive result does not establish enough full-proof headroom for the goal, and the frozen gate does not select this recipe for SDK follow-up.

The following accepted full-proof timings are inherited from the [last unchanged SDK campaign](../2026-11-09-negative-phi-sdk176/README.md). M5 CPU and Metal are supplied reference values, not newly measured devices. None of the eight CPU 10× targets is met.

|Shape|Accepted CPU ms|M5 CPU ms|M5 Metal ms|CPU speedup|Metal speedup|CPU 10× target ms|
|---|---:|---:|---:|---:|---:|---:|
"#;
    for row in inherited["rows"].as_array().unwrap() {
        let f = |k: &str| row[k].as_f64().unwrap();
        writeln!(report, "|{}|{:.6}|{:.0}|{:.0}|{:.3}×|{:.3}×|{:.1}|", row["shape"].as_str().unwrap(), f("CPU_ms"), f("M5_CPU_ms"), f("M5_Metal_ms"), f("CPU_speedup"), f("Metal_speedup"), f("CPU_10x_target_ms")).unwrap();
    }
    report += "\n[Results](artifacts/analysis.json), [protocol](artifacts/protocol.md), [review](artifacts/review-result.json), [prospective review](artifacts/prospective-review.json), [decision](artifacts/decision.json), [continuation](artifacts/next.md), [sources and receipts](sources-receipts.tar.gz), [archive index](artifacts/archive-index.json), [checksums](SHA256SUMS). Binaries, libraries, raw perf recordings, point fixtures and the full proof ledger remain local. Unchanged accepted and parent-qualified sources are identified by hashes and earlier reports rather than duplicated here. No new AWS, Aeglos, ARM, mobile, huge-circuit, pressure, swap, minimum-RAM or concurrent-throughput result is claimed.\n";
    fs::write(format!("{D}/README.md"), &report).unwrap();
    let pack = PathBuf::from(format!("{R}/publication-source"));
    fs::create_dir(&pack).unwrap();
    let mut files = vec![]; walk(Path::new(R), &mut files); files.sort();
    let mut members = vec![]; let mut omitted = vec![];
    for p in files {
        let rel = p.strip_prefix(R).unwrap();
        if ["reference", "libs", "publication-source", "publication-roundtrip"].iter().any(|x| rel.starts_with(x)) { continue; }
        let ext = p.extension().and_then(|v| v.to_str()).unwrap_or("");
        if !["rs", "json", "md", "log", "csv", "nm"].contains(&ext) { continue; }
        let size = fs::metadata(&p).unwrap().len();
        if ext == "log" && size > 1024 * 1024 {
            omitted.push(json!({"path":rel,"bytes":size,"sha256":hash(&p),"reason":"large decode retained locally; summaries, ownership and receipts archived"})); continue;
        }
        let bytes = fs::read(&p).unwrap(); assert!(std::str::from_utf8(&bytes).is_ok());
        let to = pack.join(rel); fs::create_dir_all(to.parent().unwrap()).unwrap(); fs::write(&to, bytes).unwrap();
        members.push(json!({"path":rel,"bytes":size,"sha256":hash(&to)}));
    }
    let archive = format!("{D}/sources-receipts.tar.gz");
    assert!(Command::new("tar").args(["-czf", &archive, "-C", pack.to_str().unwrap(), "."]).status().unwrap().success());
    let unpack = PathBuf::from(format!("{R}/publication-roundtrip")); fs::create_dir(&unpack).unwrap();
    assert!(Command::new("tar").args(["-xzf", &archive, "-C", unpack.to_str().unwrap()]).status().unwrap().success());
    for m in &members { assert_eq!(hash(unpack.join(m["path"].as_str().unwrap())), m["sha256"]); }
    save(format!("{D}/artifacts/archive-index.json"), json!({"archive_sha256":hash(&archive),"UTF8_members":members,"large_local_logs":omitted,"private_profile_hashes":a["profiles"],"excluded":"binaries/libraries/rawperf/pointfixtures/fullproofledger/unchangedacceptedandparentsources"}));
    fs::write(format!("{D}/SHA256SUMS"), "").unwrap();
    let mut links = 0;
    for piece in report.split("](").skip(1) {
        let link = piece.split(')').next().unwrap();
        if !link.starts_with("http") { assert!(Path::new(D).join(link).is_file(), "{link}"); links += 1; }
    }
    let publication = json!({"passed":true,"archive_roundtrip":true,"UTF8_members":members.len(),"large_local_logs":omitted.len(),"local_links":links,"capture_steps":735,"caller_processes":690,"profile_samples":93509,"numeric_checks":89,"failed_checks_retained":9,"primary_positive_retained":true,"gate_passed":false,"production_unchanged":176,"canonical_proofs":41104,"new_proofs":0,"CPU_Metal_inherited_rows":8,"goal_complete":false});
    save(format!("{D}/artifacts/publication.json"), publication.clone());
    let mut files = vec![]; walk(Path::new(D), &mut files); files.sort();
    let mut sums = String::new();
    for p in files { if p.file_name().unwrap() == "SHA256SUMS" { continue; } writeln!(sums, "{}  {}", hash(&p), p.strip_prefix(D).unwrap().display()).unwrap(); }
    fs::write(format!("{D}/SHA256SUMS"), &sums).unwrap();
    for line in sums.lines() { let (h, p) = line.split_once("  ").unwrap(); assert_eq!(hash(Path::new(D).join(p)), h); }
    save(format!("{R}/publication.json"), publication);
    println!("Publication PASS: {} UTF8 members, {} large local logs, {} links; primary positive and all 9 failures retained; no adoption", members.len(), omitted.len(), links);
}
