use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/sign-mask-sdk176";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/inverse-seed-sdk176";
fn write(n:&str,s:String){let p=format!("{R}/{n}");assert!(!Path::new(&p).exists());fs::write(p,s).unwrap();}
fn main(){
 let common=|name:&str|fs::read_to_string(format!("{OLD}/{name}")).unwrap().replace(OLD,R).replace("32659","32879").replace("32845","33065").replace("32857","33077").replace("28644","47244");
 let prep=common("pilot-prepare.rs").replace("let rounds=151;","let rounds=251;").replace("\"rounds32\":151","\"rounds32\":251").replace("\"rounds16\":151","\"rounds16\":251").replace("\"counter_running_percent_required\":100","\"counter_running_percent_required\":99.9");
 assert!(prep.contains("let rounds=251;"));assert!(!prep.contains("rounds=151"));write("pilot-prepare.rs",prep);
 let analyze=common("pilot-analyze.rs").replace("assert_eq!(rounds,151)","assert_eq!(rounds,251)");
 assert!(analyze.contains("assert_eq!(rounds,251)"));write("pilot-analyze.rs",analyze);
 let diagnostic=common("pilot-diagnostic.rs");
 let start=diagnostic.find("let old=attrs(").unwrap();let end=start+diagnostic[start..].find("requests+=rounds+3;").unwrap();
 let mut d=diagnostic[..start].to_owned();d.push_str("assert_eq!(v[\"vk_sha256\"],j[\"expected_vk_sha256\"].as_str().unwrap());");d.push_str(&diagnostic[end..]);
 d=d.replace("running>=99.999","running>=99.9").replace("&&g1&&g2&&(arm!=\"candidate\"||helper_samples>0)","&&g1&&g2").replace("shared_inverse_samples","inverse_samples_context_only").replace("isolated constant-change causality","isolated mask-change causality");
 assert!(!d.contains("helper_samples>0"));write("pilot-diagnostic.rs",d);
 fs::copy(format!("{OLD}/hardware-topology.txt"),format!("{R}/hardware-topology.txt")).unwrap();
 println!("Prepared new fixed251-round matched SDK readers; same statistics and receipt/profile quality logic; no measurements executed");
}
