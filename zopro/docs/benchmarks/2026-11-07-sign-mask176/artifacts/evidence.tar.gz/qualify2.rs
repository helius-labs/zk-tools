const LANES:usize=8;
use zopro_bn254::{Affine,CurveConfig,G1Affine,G2Affine,G1Config,G2Config};
include!("original.rs");include!("candidate.rs");
static P1:G1Affine=G1Affine::IDENTITY;static P2:G2Affine=G2Affine::IDENTITY;
#[no_mangle]#[inline(never)]pub fn scalar_g1(b:&[(u32,&G1Affine)])->u8{original::<true,G1Config>(b)}
#[no_mangle]#[inline(never)]pub fn vector_g1(b:&[(u32,&G1Affine)])->u8{packed_signs::<true,G1Config,_>(b)}
#[no_mangle]#[inline(never)]pub fn scalar_g2(b:&[(u32,&G2Affine)])->u8{original::<true,G2Config>(b)}
#[no_mangle]#[inline(never)]pub fn vector_g2(b:&[(u32,&G2Affine)])->u8{packed_signs::<true,G2Config,_>(b)}
fn encoded(mask:u8,i:usize)->u32{((i as u32).wrapping_mul(0x62b9f275)&0x7fffffff)|(((mask>>(i%8))as u32&1)<<31)}
fn normal<C:CurveConfig>(point:&Affine<C>)->usize{let mut count=0;for offset in 0usize..8{for mask in 0..=255u8{let records=(0..offset+8).map(|i|(encoded(mask,i.wrapping_sub(offset)),point)).collect::<Vec<_>>();let untouched=records.clone();let b=&records[offset..];assert_eq!(original::<true,C>(b),mask);assert_eq!(packed_signs::<true,C,_>(b),mask);assert_eq!(packed_signs::<false,C,_>(&[]as&[(u32,&Affine<C>)]),0);for(a,b)in records.iter().zip(&untouched){assert_eq!(a.0,b.0);assert!(core::ptr::eq(a.1,b.1));}count+=1;}}count}
fn owned<C:CurveConfig>(point:Affine<C>)->usize{let mut count=0;for mask in 0..=255u8{let b=core::array::from_fn::<_,8,_>(|i|(encoded(mask,i),point));assert_ne!(core::mem::size_of::<(u32,Affine<C>)>(),16);assert_eq!(packed_signs::<true,C,_>(&b),mask);assert_eq!(original::<true,C>(&b),mask);count+=1;}count}
fn boundary<C:CurveConfig>(point:&Affine<C>)->usize{
 let page=unsafe{libc::sysconf(libc::_SC_PAGESIZE)}as usize;assert!(page>=4096);assert_eq!(core::mem::size_of::<(u32,&Affine<C>)>(),16);
 let allocation=unsafe{libc::mmap(core::ptr::null_mut(),2*page,libc::PROT_READ|libc::PROT_WRITE,libc::MAP_PRIVATE|libc::MAP_ANONYMOUS,-1,0)};assert_ne!(allocation,libc::MAP_FAILED);assert_eq!(unsafe{libc::mprotect(allocation.cast::<u8>().add(page).cast(),page,libc::PROT_NONE)},0);
 let records=unsafe{allocation.cast::<u8>().add(page-128).cast::<(u32,&Affine<C>)>()};let mut count=0;
 for mask in 0..=255u8{for i in 0..8{unsafe{records.add(i).write((encoded(mask,i),point));}}let b=unsafe{core::slice::from_raw_parts(records,8)};let first=core::ptr::addr_of!(b[0].0)as usize;for i in 0..8{assert_eq!(first+16*i,core::ptr::addr_of!(b[i].0)as usize);assert!(first+16*i+4<=allocation as usize+page);}assert_eq!(original::<true,C>(b),mask);assert_eq!(packed_signs::<true,C,_>(b),mask);count+=1;}
 assert_eq!(unsafe{libc::munmap(allocation,2*page)},0);count
}
fn main(){
 let output="/home/ubuntu/src/zopro-perf-work/sign-mask176/qualification.json";assert!(!std::path::Path::new(output).exists());
 let borrowed=normal::<G1Config>(&P1)+normal::<G2Config>(&P2);let fallback=owned::<G1Config>(P1)+owned::<G2Config>(P2);let boundary=boundary::<G1Config>(&P1)+boundary::<G2Config>(&P2);
 // Actual opaque-slice wrappers are retained and called, not dead artifacts.
 for mask in 0..=255u8{let a=core::array::from_fn::<_,8,_>(|i|(encoded(mask,i),&P1));let b=core::array::from_fn::<_,8,_>(|i|(encoded(mask,i),&P2));assert_eq!(std::hint::black_box(scalar_g1)(&a),mask);assert_eq!(std::hint::black_box(vector_g1)(&a),mask);assert_eq!(std::hint::black_box(scalar_g2)(&b),mask);assert_eq!(std::hint::black_box(vector_g2)(&b),mask);}
 let result=format!("{{\"passed\":true,\"borrowed_cases\":{borrowed},\"owned_fallback_cases\":{fallback},\"protected_boundary_cases\":{boundary},\"wrapper_comparisons\":1024,\"borrowed_stride\":16,\"g1_index_offset\":{},\"g2_index_offset\":{},\"owned_g1_stride\":{},\"owned_g2_stride\":{},\"masked_read_offsets\":[0,16,32,48,64,80,96,112],\"new_proofs\":0,\"new_timings\":0,\"production_adopted\":false}}",core::mem::offset_of!((u32,&G1Affine),0),core::mem::offset_of!((u32,&G2Affine),0),core::mem::size_of::<(u32,G1Affine)>(),core::mem::size_of::<(u32,G2Affine)>());
 std::fs::write(output,&result).unwrap();println!("{result}");
}
