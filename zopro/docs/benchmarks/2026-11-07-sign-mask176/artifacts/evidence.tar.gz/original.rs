#[inline(always)]
fn original<const SIGNED:bool,C:CurveConfig>(batch:&[(u32,impl std::borrow::Borrow<Affine<C>> )])->u8 {
    if !SIGNED {return 0;}let mut bits=0u8;for i in 0..LANES {bits|=((batch[i].0>>31)as u8)<<i;}bits
}
