use ark_bn254::{G1Affine as ArkAffine,G1Projective as ArkProjective};
use ark_ec::{AffineRepr,CurveGroup};use ark_ff::{PrimeField,Zero};
use std::sync::{Arc,atomic::{AtomicUsize,Ordering}};
use zopro_bn254::{G1Affine,G1Config};
struct Fixture{initial:Vec<G1Affine>,incoming:Vec<G1Affine>,ark_initial:Vec<ArkProjective>,ark_incoming:Vec<ArkProjective>}
fn native(p:ArkAffine)->G1Affine{if p.is_zero(){G1Affine::IDENTITY}else{G1Affine::new(Fq::from_canonical(p.x.into_bigint().0).unwrap(),Fq::from_canonical(p.y.into_bigint().0).unwrap())}}
fn fixture()->Fixture{let g=ArkAffine::generator();let a=(0..2048).map(|i|g.mul_bigint(ark_bn254::Fr::from((i+12345)as u64).into_bigint())).collect::<Vec<_>>();let b=(0..1025).map(|i|g.mul_bigint(ark_bn254::Fr::from((i+900001)as u64).into_bigint())).collect::<Vec<_>>();Fixture{initial:ArkProjective::normalize_batch(&a).into_iter().map(native).collect(),incoming:ArkProjective::normalize_batch(&b).into_iter().map(native).collect(),ark_initial:a,ark_incoming:b}}
static RAW:AtomicUsize=AtomicUsize::new(0);static ARK:AtomicUsize=AtomicUsize::new(0);static CASES:AtomicUsize=AtomicUsize::new(0);
fn run<const FAST:bool,const SIGNED:bool>(f:&Fixture,n:usize,mask:u8,write:bool,reserve:bool,vector:bool){
 let size=n.max(1).next_power_of_two();let mut got=f.initial[..size].to_vec();let mut want=got.clone();let mut expected=f.ark_initial[..size].to_vec();let mut scratch=FqAddScratch{write_groups:write,reserve_groups:reserve,vector_inverse:vector,canonical:FAST,..Default::default()};let mut old=accepted::ReferenceScratch::new(write,reserve,vector,FAST);
 let batch=(0..n).map(|i|(((i*37%size)as u32)|if SIGNED&&mask>>(i%8)&1!=0{1<<31}else{0},&f.incoming[i])).collect::<Vec<_>>();let input_before=f.incoming[..n].to_vec();
 for _ in 0..3{stream_g1_impl::<G1Config,FAST,SIGNED>(&mut got,&batch,&mut scratch);accepted::original::<G1Config,FAST,SIGNED>(&mut want,&batch,&mut old);
  for(i,w)in got.iter().zip(&want){assert_eq!(i.x.0,w.x.0);assert_eq!(i.y.0,w.y.0);}RAW.fetch_add(size,Ordering::Relaxed);
  for(i,(id,_))in batch.iter().enumerate(){let index=(id&0x7fffffff)as usize;if SIGNED&&id>>31!=0{expected[index]-=f.ark_incoming[i];}else{expected[index]+=f.ark_incoming[i];}}
  let oracle=ArkProjective::normalize_batch(&expected);for(p,q)in got.iter().zip(oracle){let q=native(q);assert_eq!(*p,q);}ARK.fetch_add(size,Ordering::Relaxed);
  assert_eq!(scratch.groups.capacity(),old.record_capacity());assert_eq!(scratch.groups.len(),n/8);assert_eq!(scratch.groups.capacity()*std::mem::size_of::<FqAddGroup>()*5,old.record_capacity()*1600*4);
 }
 assert_eq!(f.incoming[..n],input_before);CASES.fetch_add(1,Ordering::Relaxed);
}
#[test]fn exact_records_all_signs_tails_and_write_modes(){let f=fixture();let start=(RAW.load(Ordering::Relaxed),ARK.load(Ordering::Relaxed),CASES.load(Ordering::Relaxed));
 for n in[0usize,1,7,8,9,15,16,31,32,63,64,127,128,199,200,201,351,352,353,511,512,513,1025]{for mask in[0u8,85,255]{for(w,r)in[(false,false),(false,true),(true,false),(true,true)]{run::<true,true>(&f,n,mask,w,r,true);run::<false,true>(&f,n,mask,w,r,true);run::<true,false>(&f,n,mask,w,r,false);}}}
 for n in[8usize,9,200,201]{for mask in 0..=255u8{for(w,r)in[(false,false),(false,true),(true,false),(true,true)]{run::<true,true>(&f,n,mask,w,r,true);}}}
 println!("G1_RECOMPUTED_DX raw_slots={} independent_Ark_slots={} cases={}",RAW.load(Ordering::Relaxed)-start.0,ARK.load(Ordering::Relaxed)-start.1,CASES.load(Ordering::Relaxed)-start.2);
}
#[test]fn threaded_and_shared_caller_records(){let f=Arc::new(fixture());let mut workers=0usize;let before=CASES.load(Ordering::Relaxed);
 for nworkers in[1usize,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(nworkers).stack_size(512*1024).build().unwrap();let seen=pool.broadcast(|ctx|{let i=ctx.index();run::<true,true>(&f,65,i as u8,i%2==0,i%3==0,true);run::<true,true>(&f,200,(i as u8).wrapping_mul(37),i%2!=0,true,true);i});assert_eq!(seen,(0..nworkers).collect::<Vec<_>>());workers+=seen.len();}
 let pool=Arc::new(rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap());let threads=(0..4).map(|i|{let f=f.clone();let pool=pool.clone();std::thread::spawn(move||pool.install(||{for n in[7usize,8,65,201]{run::<true,true>(&f,n,0x55^i,true,true,true);}}))}).collect::<Vec<_>>();for t in threads{t.join().unwrap();}assert_eq!(workers,53);println!("G1_RECOMPUTED_DX_THREADS workers={workers} cases={}",CASES.load(Ordering::Relaxed)-before);
}
#[test]fn record_layout_and_checked_payloads(){assert_eq!(std::mem::size_of::<FqAddGroup>(),1280);assert_eq!(std::mem::align_of::<FqAddGroup>(),64);
 let cases=[0usize,1,2,3,7,8,9,25,44,64,128,usize::MAX/1600,usize::MAX];for n in cases{let old=n.checked_mul(1600);let new=n.checked_mul(std::mem::size_of::<FqAddGroup>());match(old,new){(Some(a),Some(b))=>assert_eq!(a as u128*4,b as u128*5),(None,Some(_))|(None,None)=>{},_=>panic!("smaller record overflowed first")}}
 println!("G1_RECOMPUTED_DX_LAYOUT record1280/alignment64/13checkedcases;originalrecord1600");}
