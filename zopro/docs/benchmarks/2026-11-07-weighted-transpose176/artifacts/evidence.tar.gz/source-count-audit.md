# Pre-execution scalar-tail correction

The initial draft was compiled but no model or tests had executed. A direct source audit of reduce_layer, Fq2::prefix/reverse/denominator_inverse and scalar Fq2::square/mul corrected its G2 scalar-tail ledger from9M+S+3F to **7M+5F** per pair. The accepted field's scalar complex square uses two multiplies; its two general complex products use four fused-two-product operations, and the norm uses a fifth. Prefix/reverse/denominator recovery contribute five other scalar multiplies. This matches the previously source-bound g2-real-norm-z176 accepted formula without replaying that model.

No circuit algorithm, shape population or output changed. The draft source is preserved as model-pre-source-audit.rs. The final source is rebuilt before its first tests and model execution. No draft arithmetic output or timing is reported.
