use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/fused-epoch-sdk176";
const O:&str="/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
const TOOL:&str="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin";
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn write(n:&str,v:Value){let p=format!("{R}/{n}");assert!(!Path::new(&p).exists());fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn tree(src:&Path,dst:&Path,pins:&mut BTreeMap<String,String>,pairs:&mut Vec<Value>){
    fs::create_dir_all(dst).unwrap();
    let mut entries=fs::read_dir(src).unwrap().map(|e|e.unwrap().path()).collect::<Vec<_>>();entries.sort();
    for p in entries {let d=dst.join(p.file_name().unwrap());assert!(!p.is_symlink());if p.is_dir(){tree(&p,&d,pins,pairs)}else{let h=hash(&p);assert_eq!(hash(&d),h);pins.insert(p.display().to_string(),h.clone());pins.insert(d.display().to_string(),h.clone());pairs.push(json!({"source":p,"destination":d,"sha256":h}));}}
}
fn main(){
    assert!(Path::new(&format!("{R}/source")).is_dir()); assert!(!Path::new(&format!("{R}/native-plan.json")).exists());
    let manifest=format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");
    let m=read(&manifest);let mut pins=BTreeMap::new();
    for(n,h)in m["source_files_sha256"].as_object().unwrap(){let src=format!("{Z}/{n}");assert_eq!(hash(&src),h.as_str().unwrap());let dst=format!("{R}/source/{n}");if !["Cargo.toml","Cargo.lock"].contains(&n.as_str()){assert_eq!(hash(&dst),h.as_str().unwrap());}pins.insert(src,h.as_str().unwrap().to_owned());}
    let cargo=fs::read_to_string(format!("{Z}/Cargo.toml")).unwrap();assert!(!cargo.contains("[patch.crates-io]"));
    let patch="\n[patch.crates-io]\ncrossbeam-epoch = { path = \"vendor/crossbeam-epoch\" }\ncrossbeam-deque = { path = \"vendor/crossbeam-deque\" }\n";
    assert_eq!(fs::read_to_string(format!("{R}/source/Cargo.toml")).unwrap(),format!("{cargo}{patch}"));
    let original=fs::read_to_string(format!("{Z}/Cargo.lock")).unwrap();let modified=fs::read_to_string(format!("{O}/source-fixed/Cargo.lock")).unwrap();
    let a=original.split("[[package]]\n").collect::<Vec<_>>();let b=modified.split("[[package]]\n").collect::<Vec<_>>();assert_eq!(a.len(),b.len());let mut changes=vec![];
    for (x,y) in a.iter().zip(&b){if x!=y{let name=x.lines().next().unwrap();assert!(["name = \"crossbeam-epoch\"","name = \"crossbeam-deque\""].contains(&name));assert_eq!(x.lines().filter(|l|!l.starts_with("source = ")&&!l.starts_with("checksum = ")).map(|l|format!("{l}\n")).collect::<String>(),*y);changes.push(name.to_owned());}}
    assert_eq!(changes.len(),2);assert_eq!(fs::read_to_string(format!("{R}/source/Cargo.lock")).unwrap(),modified);
    let mut copies=vec![];for name in["crossbeam-epoch","crossbeam-deque"]{tree(Path::new(&format!("{O}/source-fixed/vendor/{name}")),Path::new(&format!("{R}/source/vendor/{name}")),&mut pins,&mut copies);}
    let oldreview=read(format!("{O}/review.json"));
    assert_eq!(oldreview["passed"],true); assert_eq!(oldreview["gate"],false);
    let mut unchanged=0;for(n,h)in m["source_files_sha256"].as_object().unwrap(){let dst=format!("{R}/source/{n}");if !["Cargo.toml","Cargo.lock"].contains(&n.as_str()){assert_eq!(hash(&dst),h.as_str().unwrap());unchanged+=1;}pins.insert(dst.clone(),hash(&dst));}assert_eq!(unchanged,174);
    assert_eq!(fs::read_to_string(format!("{R}/source/Cargo.toml")).unwrap().strip_suffix(patch),Some(cargo.as_str()));
    fs::create_dir_all(format!("{R}/support")).unwrap();for name in["driver.rs","support/perf.rs"]{let src=format!("/home/ubuntu/src/zopro-perf-work/tune-spr176/{name}");let dst=format!("{R}/{name}");fs::copy(&src,&dst).unwrap();pins.insert(src.clone(),hash(src));pins.insert(dst.clone(),hash(dst));}
    let sourceaudit=json!({"passed":true,"accepted_originals":176,"byte_exact_originals":174,"changed_originals":["Cargo.toml","Cargo.lock"],"cargo_patch_suffix":patch,"lock_packages_unchanged_except_registry_metadata_removed":changes,"all_runtime_prover_sources_byte_exact":true,"private_dependencies_exact_from_previously_qualified_trial":copies,"previous_query_gate_remains_false":true,"new_optimized_SDK_engineering_trial_selected_before_build":true,"no_new_table_key_copy_plan_pool_or_allocation_policy":true,"canonical_unchanged":34439});write("source-audit.json",sourceaudit);
    let mut steps=vec![];
    for label in["control","candidate"]{
        let mut env=json!({"PATH":format!("{TOOL}:/usr/bin:/bin"),"RUSTC":format!("{TOOL}/rustc"),"CARGO_BUILD_JOBS":"16","CARGO_TARGET_DIR":format!("{R}/target-{label}"),"RUSTFLAGS":m["rustflags"].as_str().unwrap()});
        if label=="candidate"{env["RUSTFLAGS"]=format!("{} --cfg zopro_fused_epoch_pin",m["rustflags"].as_str().unwrap()).into();}
        if label=="candidate"{steps.push(json!({"kind":"command","name":"new-integrated-runtime-core-prover-tests","argv":[format!("{TOOL}/cargo"),"test","--manifest-path",format!("{R}/source/Cargo.toml"),"--locked","--offline","--release","--lib","-p","zopro-core","-p","zopro-prover","--","--test-threads=1"],"environment":env,"timeout_seconds":1800,"unfiltered":true}));}
        steps.push(json!({"kind":"command","name":format!("libraries-{label}"),"argv":[format!("{TOOL}/cargo"),"build","--manifest-path",format!("{R}/source/Cargo.toml"),"--locked","--offline","--release","-p","zopro-bench","--lib","--message-format=json"],"environment":env,"timeout_seconds":1800}));
        steps.push(json!({"kind":"link-sdk","name":label,"artifacts":format!("{R}/native/libraries-{label}/stdout.log"),"driver":format!("{R}/driver.rs"),"additional_sources":[format!("{R}/support/perf.rs")],"timeout_seconds":1200}));
    }
    let mut portable=json!({"PATH":format!("{TOOL}:/usr/bin:/bin"),"RUSTC":format!("{TOOL}/rustc"),"CARGO_BUILD_JOBS":"16","CARGO_TARGET_DIR":format!("{R}/target-portable"),"RUSTFLAGS":"-C target-cpu=generic --cfg no_asm --cfg no_ifma --cfg zopro_fused_epoch_pin"});portable["CARGO_INCREMENTAL"]="0".into();
    steps.push(json!({"kind":"command","name":"portable-runtime-integration-check","argv":[format!("{TOOL}/cargo"),"check","--manifest-path",format!("{R}/source/Cargo.toml"),"--locked","--offline","-p","zopro-core","-p","zopro-prover"],"environment":portable,"timeout_seconds":1200}));
    for p in[manifest,format!("{R}/finish-prepare.rs"),format!("{R}/prepare-attempt1.rs"),format!("{R}/repair-preparation.rs"),format!("{R}/preparation-failure.json"),format!("{R}/design.md"),format!("{R}/source-audit.json"),format!("{O}/review.json"),format!("{O}/source-audit.json"),format!("{O}/source-fixed/Cargo.lock")]{pins.insert(p.clone(),hash(p));}
    write("native-pins.json",serde_json::to_value(pins).unwrap());
    write("native-plan.json",json!({"version":1,"source_pins":format!("{R}/native-pins.json"),"steps":steps}));
    println!("Prepared first optimized full-SDK trial;174 exact originals +2 reversible Cargo metadata changes; exact qualified runtime import;6 native steps; no clock/proof.");
}
