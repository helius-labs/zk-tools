use std::fs;
const R:&str="/home/ubuntu/src/zopro-perf-work/fused-epoch-sdk176";
fn replace(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replace(a,b);}
fn main(){
 let mut s=fs::read_to_string(format!("{R}/prepare-attempt1.rs")).unwrap();
 replace(&mut s,"assert!(!Path::new(&format!(\"{R}/source\")).exists());","assert!(Path::new(&format!(\"{R}/source\")).is_dir()); assert!(!Path::new(&format!(\"{R}/native-plan.json\")).exists());");
 replace(&mut s,"fs::create_dir_all(Path::new(&dst).parent().unwrap()).unwrap();fs::copy(&src,&dst).unwrap();pins.insert(src,h.as_str().unwrap().to_owned());","if ![\"Cargo.toml\",\"Cargo.lock\"].contains(&n.as_str()){assert_eq!(hash(&dst),h.as_str().unwrap());}pins.insert(src,h.as_str().unwrap().to_owned());");
 replace(&mut s,"let cargo=fs::read_to_string(format!(\"{R}/source/Cargo.toml\")).unwrap();","let cargo=fs::read_to_string(format!(\"{Z}/Cargo.toml\")).unwrap();");
 replace(&mut s,"fs::write(format!(\"{R}/source/Cargo.toml\"),format!(\"{cargo}{patch}\")).unwrap();","assert_eq!(fs::read_to_string(format!(\"{R}/source/Cargo.toml\")).unwrap(),format!(\"{cargo}{patch}\"));");
 replace(&mut s,"fs::write(format!(\"{R}/source/Cargo.lock\"),modified).unwrap();","assert_eq!(fs::read_to_string(format!(\"{R}/source/Cargo.lock\")).unwrap(),modified);");
 replace(&mut s,"fs::copy(&p,&d).unwrap();let h=hash(&p);","let h=hash(&p);");
 replace(&mut s,"let oldreview=read(format!(\"{O}/postcapture-review.json\"));\n    assert!(oldreview.is_object());","let oldreview=read(format!(\"{O}/review.json\"));\n    assert_eq!(oldreview[\"passed\"],true); assert_eq!(oldreview[\"gate\"],false);");
 replace(&mut s,"format!(\"{O}/postcapture-review.json\")","format!(\"{O}/review.json\")");
 replace(&mut s,"format!(\"{R}/prepare.rs\"),format!(\"{R}/design.md\")","format!(\"{R}/finish-prepare.rs\"),format!(\"{R}/prepare-attempt1.rs\"),format!(\"{R}/repair-preparation.rs\"),format!(\"{R}/preparation-failure.json\"),format!(\"{R}/design.md\")");
 replace(&mut s,"\"name\":format!(\"{label}-sdk\")","\"name\":label");
 fs::write(format!("{R}/finish-prepare.rs"),s).unwrap();
 fs::write(format!("{R}/preparation-failure.json"),r#"{"exit_code":101,"stage":"preparation after source/dependency copies, before native build or timings","cause":"historical review is review.json, not postcapture-review.json","repair":"preserve original helper; audit already copied bytes without copying again; consume actual passed historical review; finish unstarted source-audit/driver/pin/plan creation","native_commands_executed":0,"SDK_requests":0}"#).unwrap();
 println!("Prepared source-preserving continuation; original failure retained.");
}
