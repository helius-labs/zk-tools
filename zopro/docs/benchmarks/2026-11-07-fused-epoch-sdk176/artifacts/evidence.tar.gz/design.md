# Fused epoch handle access: first optimized full-SDK experiment

Frozen 7 November 2026 before native builds or timings. Production remains
accepted source176 / SDK6d83. The goal remains verified CPU AVX single-proof
latency >=10x supplied M5 CPU across all eight shapes, with CPU/Metal reporting.

This is an explicit engineering exception to the previous component stop rule,
not a new arithmetic idea or a reinterpretation of its failed gate. The Oct31
query trial's fresh comparison was positive, but its final driver accidentally
omitted O3/native/fatLTO/one-CGU and its original-control calibration failed.
That trial stays rejected within its recorded scope. No previous benchmark,
qualification, decoder or verifier is rerun. The actual optimized SDK has never
tested this runtime integration. Its first full-SDK comparison is selected now,
before compilation, to settle that unresolved implementation question.

Import the exact qualified private Crossbeam epoch0.9.21/deque0.8.8 sources from
fused-epoch-pin176/source-fixed. Keep their original local pin, guard drop,
unpinned CAS, nested SeqCst fence, collection cadence and steal body. The single
change under zopro_fused_epoch_pin combines is_pinned/fence/pin within one
with_handle callback instead of two. No other stealing, batching, victim,
sleep/wake, task, solver, arithmetic, representation or resource policy changes.
All 176 accepted files must remain exact except reversible Cargo patch/lock
metadata. No diagnostic query exports, previous coalescer or compiler tuning.

The earlier dependency lifetime/concurrency tests are inherited by exact source
and receipts, including preserved initial failures/repairs, not rerun. Qualify
the new integrated cfg with core/prover library tests serially (allocator tests
assert process-global state), coherent eight-library builds and actual optimized
SDK links. Field bodies/accepted flags are unchanged; prior field qualification
is inherited, not replayed. Check portable generic/no-ASM/no-IFMA compilation.
Inspect actual final link argv and actual new SDK steal code before timing.
Both fresh OFF and candidate plus accepted remain distinct controls. Fresh
Gnark preflight all9 and primary1/16 precedes any performance capture.

Prospective full capture: reuse the parent all-nine plus primary16 structure,
15 fixed rotated/reversed blocks, primary151/others31 requests plus3 primes.
Freeze exact inputs, binaries, sources, affinity, allocator/resource environment,
raw output and canonical proof ledger before capture. Record all latencies,
then automatic FIFO PMU/profiles, then independent verifiers/offline analysis.
No build/helper/hash/report/push or second benchmark during recordings.

Selection requires primary32 AND equal-log original-eight aggregate upper
paired95% bootstrap ratios <1 against BOTH controls, every context upper<=1.02,
fresh/accepted calibration entirely inside factor1.03. Primary16 remains a
nonregression/calibration context. Preserve all10 and all gates, with no
minimum gain floor, exclusion, extension, subset promotion or unchanged reroll.
20,000 paired bootstrap resamples; exact seed/ranks frozen in capture plan.
Data-quality gates: zeroLOST, profiles>=1000samples/unknown<=5%, PMU>=99.9%
running, process/thread/CPU/MMAP ownership and FIFO boundaries bound. Earlier
query gates remain false even if this separate integration passes.

No new persistent allocation, lookup table, copied key, solver plan or pool is
proposed. Guard lifetimes stay identical. Compiler code/liveness/layout and
measured process RSS may change. Record RSS/faults as observations, not minimum
RAM or a complete lifetime bound. Any eventual adoption additionally requires
resource admission/fallback coverage appropriate to this runtime change.
No AWS/Aeglos/phone/ARM/large250/4999/concurrent-throughput claim follows.

Current canonical34439 and latest full SDK tune-spr176 remain authoritative
until new independently verified exports/complete measured evidence exist.
Commit and push every completed experiment; never bulk-stage old reports.
