use std::{collections::{BTreeMap,BTreeSet,VecDeque},fs};
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
type W=[u64;4];type E=(usize,usize,u8,bool);
const R:W=[4891460686036598785,2896914383306846353,13281191951274694749,3486998266802970665];
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/odd-scalar-relations203";
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn less(a:W,b:W)->bool{a.into_iter().rev().cmp(b.into_iter().rev()).is_lt()}
fn sub(a:W,b:W)->W{let mut carry=false;std::array::from_fn(|i|{let(x,c)=a[i].overflowing_sub(b[i]);let(y,d)=x.overflowing_sub(u64::from(carry));carry=c||d;y})}
fn add(a:W,b:W)->W{let mut carry=0u128;let out=std::array::from_fn(|i|{carry+=a[i]as u128+b[i]as u128;let w=carry as u64;carry>>=64;w});assert_eq!(carry,0);if less(out,R){out}else{sub(out,R)}}
fn neg(a:W)->W{if a==[0;4]{a}else{sub(R,a)}}
fn times(a:W,c:u8)->W{(0..c).fold([0;4],|x,_|add(x,a))}
fn bits(a:W)->usize{a.iter().enumerate().rev().find(|(_,x)|**x!=0).map_or(0,|(i,x)|i*64+64-x.leading_zeros()as usize)}
fn component_sizes(n:usize,es:&[E],odd:bool)->Vec<usize>{
 let mut adj=vec![Vec::<usize>::new();n];for&(i,j,c,_)in es{if odd||c==1{adj[i].push(j);adj[j].push(i);}}
 let mut seen=vec![false;n];let mut sizes=Vec::new();for i in 0..n{if seen[i]{continue;}let mut q=VecDeque::from([i]);seen[i]=true;let mut count=0;while let Some(v)=q.pop_front(){count+=1;for&u in&adj[v]{if !seen[u]{seen[u]=true;q.push_back(u);}}}sizes.push(count);}sizes.sort_unstable();sizes
}
fn main(){
 let initial:Value=serde_json::from_slice(&fs::read(format!("{ROOT}/result.json")).unwrap()).unwrap();let mut rows=Vec::new();
 for base in initial["rows"].as_array().unwrap(){
  let name=base["shape"].as_str().unwrap();let b=fs::read(format!("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/inputs/{name}.b2q")).unwrap();assert_eq!(hash(&b),base["fixture_sha256"]);let n=u64::from_le_bytes(b[8..16].try_into().unwrap())as usize;
  let mut counts=BTreeMap::<W,(usize,usize)>::new();let mut identity_rows=0;let mut live_nonzero_rows=0;
  for(i,raw)in b[16+128*n..].chunks_exact(32).enumerate(){let w=std::array::from_fn(|j|u64::from_le_bytes(raw[8*j..8*j+8].try_into().unwrap()));assert!(less(w,R));let identity=b[16+128*i..16+128*(i+1)].iter().all(|&v|v==0);identity_rows+=usize::from(identity);if w==[0;4]{continue;}let entry=counts.entry(w).or_default();entry.0+=1;entry.1+=usize::from(!identity);live_nonzero_rows+=usize::from(!identity);}
  let original=counts.keys().copied().collect::<Vec<_>>();let values=counts.iter().filter_map(|(&k,&v)|(v.1!=0).then_some(k)).collect::<Vec<_>>();let mut views=Vec::new();
  for(label,v)in[("all_scalar_classes",&original),("classes_with_nonidentity_inputs",&values)]{
   let ix:BTreeMap<_,_>=v.iter().enumerate().map(|(i,&w)|(w,i)).collect();let mut es=BTreeSet::new();for(i,&w)in v.iter().enumerate(){for c in[1,3,5,7]{for negative in[false,true]{if c==1&&!negative{continue;}let t=times(w,c);let t=if negative{neg(t)}else{t};if let Some(&j)=ix.get(&t){if i!=j{es.insert((i.min(j),i.max(j),c,negative));}}}}}
   let es=es.into_iter().collect::<Vec<_>>();let sign=component_sizes(v.len(),&es,false);let all=component_sizes(v.len(),&es,true);let mut affected=BTreeSet::new();for&(i,j,c,_)in&es{if c!=1{affected.insert(i);affected.insert(j);}}
   let detail=affected.iter().map(|&i|{let w=v[i];let minus=neg(w);let centered=if less(w,minus){w}else{minus};json!({"centered_bits":bits(centered),"original_rows":counts[&w].0,"nonidentity_rows":counts[&w].1})}).collect::<Vec<_>>();
   if label=="all_scalar_classes"{assert_eq!(base["edge_digest"],hash(&serde_json::to_vec(&es).unwrap()));}
   views.push(json!({"view":label,"distinct_nonzero":v.len(),"sign_components":sign.len(),"all_components":all.len(),"additional_odd_merges_upper_bound":sign.len()-all.len(),"edge_count":es.len(),"edge_digest":hash(&serde_json::to_vec(&es).unwrap()),"affected_class_details":detail}));
  }
  rows.push(json!({"shape":name,"identity_input_rows":identity_rows,"nonidentity_nonzero_input_rows":live_nonzero_rows,"views":views}));
 }
 let out=json!({"stage":"post-census check of affected point inputs; original census retained unchanged","identity_encoding":"all four canonical Fq coordinates zero, matching current Affine::IDENTITY/is_identity","native_latency_measured":false,"rows":rows});fs::write(format!("{ROOT}/live.json"),serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("{}",serde_json::to_string_pretty(&out).unwrap());
}
