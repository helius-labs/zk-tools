use std::{collections::{BTreeMap,BTreeSet,VecDeque},fs};
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
type W=[u64;4];type E=(usize,usize,u8,bool);
const R:W=[4891460686036598785,2896914383306846353,13281191951274694749,3486998266802970665];
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/odd-scalar-relations203";
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn less(a:W,b:W)->bool{a.into_iter().rev().cmp(b.into_iter().rev()).is_lt()}
fn sub(a:W,b:W)->W{let mut carry=false;std::array::from_fn(|i|{let(x,c)=a[i].overflowing_sub(b[i]);let(y,d)=x.overflowing_sub(u64::from(carry));carry=c||d;y})}
fn add(a:W,b:W)->W{let mut carry=0u128;let out=std::array::from_fn(|i|{carry+=a[i]as u128+b[i]as u128;let w=carry as u64;carry>>=64;w});assert_eq!(carry,0);if less(out,R){out}else{sub(out,R)}}
fn neg(a:W)->W{if a==[0;4]{a}else{sub(R,a)}}
fn times(a:W,c:u8)->W{(0..c).fold([0;4],|x,_|add(x,a))}
fn bits(a:W)->usize{a.iter().enumerate().rev().find(|(_,x)|**x!=0).map_or(0,|(i,x)|i*64+64-x.leading_zeros()as usize)}
fn component_sizes(n:usize,es:&[E],odd:bool)->Vec<usize>{
 let mut adj=vec![Vec::<usize>::new();n];for&(i,j,c,_)in es{if odd||c==1{adj[i].push(j);adj[j].push(i);}}
 let mut seen=vec![false;n];let mut sizes=Vec::new();for i in 0..n{if seen[i]{continue;}let mut q=VecDeque::from([i]);seen[i]=true;let mut count=0;while let Some(v)=q.pop_front(){count+=1;for&u in&adj[v]{if !seen[u]{seen[u]=true;q.push_back(u);}}}sizes.push(count);}sizes.sort_unstable();sizes
}
fn main(){
 // Boundary controls for modular repeated addition, including the nonzero
 // maximum and carries between each pair of saturated machine words.
 assert_eq!(add(sub(R,[1,0,0,0]),[1,0,0,0]),[0;4]);assert_eq!(neg(neg([1,0,0,0])),[1,0,0,0]);
 for i in 0..4 {let mut x=[0;4];x[i]=1;let lo=sub(x,[1,0,0,0]);assert_eq!(add(lo,[1,0,0,0]),x);}
 let m:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-17-certified-all196/artifacts/production-source-manifest.json").unwrap()).unwrap();
 assert_eq!(m["source_files_sha256"].as_object().unwrap().len(),179);for(p,h)in m["source_files_sha256"].as_object().unwrap(){assert_eq!(hash(&fs::read(format!("/home/ubuntu/src/zk-tools/zopro/{p}")).unwrap()),h.as_str().unwrap());}
 assert_eq!(hash(&fs::read("/home/ubuntu/src/zopro-perf-work/accepted-c7a201/host-remote/proof-sha256.json").unwrap()),"7f4ec2097957bcc2f063d32778300edba00d8adc238787e44c0d3e9e2e2eab9e");
 let result:Value=serde_json::from_slice(&fs::read(format!("{ROOT}/result.json")).unwrap()).unwrap();let mut details=Vec::new();
 for row in result["rows"].as_array().unwrap(){let name=row["shape"].as_str().unwrap();let bytes=fs::read(format!("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/inputs/{name}.b2q")).unwrap();assert_eq!(hash(&bytes),row["fixture_sha256"]);assert_eq!(&bytes[..8],b"B2SCAN01");let n=u64::from_le_bytes(bytes[8..16].try_into().unwrap())as usize;assert_eq!(bytes.len(),16+n*160);let mut counts=BTreeMap::<W,usize>::new();let mut zeros=0;
  for b in bytes[16+128*n..].chunks_exact(32){let w=std::array::from_fn(|i|u64::from_le_bytes(b[i*8..i*8+8].try_into().unwrap()));assert!(less(w,R));if w==[0;4]{zeros+=1;}else{*counts.entry(w).or_default()+=1;}}
  let values=counts.keys().copied().collect::<Vec<_>>();let index:BTreeMap<_,_>=values.iter().enumerate().map(|(i,&w)|(w,i)).collect();let mut edges=BTreeSet::new();
  for(i,&v)in values.iter().enumerate(){for c in[1u8,3,5,7]{for negative in[false,true]{if c==1&&!negative{continue;}let p=times(v,c);let p=if negative{neg(p)}else{p};if let Some(&j)=index.get(&p){if i!=j{edges.insert((i.min(j),i.max(j),c,negative));}}}}}
  let es=edges.into_iter().collect::<Vec<_>>();let sign=component_sizes(values.len(),&es,false);let all=component_sizes(values.len(),&es,true);let mut hist=BTreeMap::<String,usize>::new();let mut affected=BTreeSet::new();for&(i,j,c,negative)in&es{*hist.entry(format!("{}{}",if negative{"-"}else{"+"},c)).or_default()+=1;if c!=1{affected.insert(i);affected.insert(j);}}
  let affected_rows:usize=affected.iter().map(|i|counts[&values[*i]]).sum();let small=affected.iter().filter(|&&i|values[i][1..]==[0;3]&&values[i][0]<=65535).count();
  for(k,v)in[("input_rows",n),("zero_rows",zeros),("distinct_nonzero",values.len()),("exact_group_eliminated_rows",n-zeros-values.len()),("sign_components",sign.len()),("all_components",all.len()),("additional_odd_merges_upper_bound",sign.len()-all.len()),("edge_count",es.len()),("odd_affected_classes",affected.len()),("odd_affected_original_rows",affected_rows),("odd_affected_small_residue_classes",small),("minimum_additional_hash_probes",6*values.len())]{assert_eq!(row[k],json!(v),"{name} {k}");}
  assert_eq!(row["edge_histogram"],json!(hist));assert_eq!(row["edge_digest"],hash(&serde_json::to_vec(&es).unwrap()));assert_eq!(row["nontrivial_component_sizes"],json!(all.into_iter().filter(|&n|n>1).collect::<Vec<_>>()));
  let mut centered_bits=BTreeMap::<usize,usize>::new();let mut centered_small=0;for&i in&affected{let w=values[i];let minus=neg(w);let centered=if less(w,minus){w}else{minus};*centered_bits.entry(bits(centered)).or_default()+=1;if centered[1..]==[0;3]&&centered[0]<=65535{centered_small+=1;}}
  details.push(json!({"shape":name,"independent_edges":es.len(),"all_counts_and_edge_digest_match":true,"odd_affected_centered_bits_histogram":centered_bits,"odd_affected_centered_small_classes":centered_small,"odd_affected_classes":affected.len(),"all_odd_affected_classes_centered_small":centered_small==affected.len()}));
 }
 let report=json!({"passed":true,"method":"canonical four-word repeated modular addition and BFS, independent of Fr Montgomery arithmetic and DSU","source_hashes_checked":179,"ledger_unchanged":58257,"rows":details,"no_native_latency_or_full_proof_claim":true});fs::write(format!("{ROOT}/review.json"),serde_json::to_vec_pretty(&report).unwrap()).unwrap();println!("{}",serde_json::to_string_pretty(&report).unwrap());
}
