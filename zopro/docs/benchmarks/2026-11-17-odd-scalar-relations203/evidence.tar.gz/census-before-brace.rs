use std::{collections::{BTreeMap,BTreeSet,HashMap},fs,path::Path};
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use zopro_bn254::Fr;
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/odd-scalar-relations203";
const PROD:&str="/home/ubuntu/src/zk-tools/zopro";
const MANIFEST:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-17-certified-all196/artifacts/production-source-manifest.json";
const LEDGER:&str="/home/ubuntu/src/zopro-perf-work/accepted-c7a201/host-remote/proof-sha256.json";
type Word=[u64;4];
type Edge=(usize,usize,u8,bool);
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn fixture(name:&str)->(usize,Vec<Word>,String){
 let b=fs::read(format!("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/inputs/{name}.b2q")).unwrap();
 let expected=match name{"1x2"=>"421d6ba37e8b3a6f5feb23829c174d11bc034cb9bd8874adf672d65038fb0ad0","2x2"=>"2b325a5850f1fc9ea21e715e6027f14cc7a29d2c602d0acc683bbfb8377921bc",_=>panic!()};
 assert_eq!(hash(&b),expected); assert_eq!(&b[..8],b"B2SCAN01");
 let n=u64::from_le_bytes(b[8..16].try_into().unwrap())as usize;assert_eq!(b.len(),16+160*n);
 let w=b[16+128*n..].chunks_exact(32).map(|v|std::array::from_fn(|i|u64::from_le_bytes(v[8*i..8*i+8].try_into().unwrap()))).collect();(n,w,hash(&b))
}
fn fr(w:Word)->Fr{Fr::from_canonical(w).expect("canonical scalar")}
fn source_check()->usize{
 let m:Value=serde_json::from_slice(&fs::read(MANIFEST).unwrap()).unwrap();let files=m["source_files_sha256"].as_object().unwrap();assert_eq!(files.len(),179);
 for(p,h)in files{assert_eq!(hash(&fs::read(Path::new(PROD).join(p)).unwrap()),h.as_str().unwrap(),"{p}");}
 assert_eq!(hash(&fs::read(LEDGER).unwrap()),"7f4ec2097957bcc2f063d32778300edba00d8adc238787e44c0d3e9e2e2e2eab9e");files.len()
}
fn edges(values:&[Word])->Vec<Edge>{
 let index:HashMap<_,_>=values.iter().copied().enumerate().map(|(i,w)|(w,i)).collect();let mut out=BTreeSet::new();
 for(i,w)in values.iter().enumerate(){let a=fr(*w);for c in[1u8,3,5,7]{let p=a*Fr::from_u64(c as u64);for neg in[false,true]{if c==1&&!neg{continue;}let t=if neg{-p}else{p};if let Some(&j)=index.get(&t.to_canonical()){if i!=j{out.insert((i.min(j),i.max(j),c,neg));}}}}out.into_iter().collect()
}
fn root(parent:&mut[usize],i:usize)->usize{if parent[i]!=i{parent[i]=root(parent,parent[i]);}parent[i]}
fn components(n:usize,es:&[Edge],odd:bool)->Vec<usize>{let mut p=(0..n).collect::<Vec<_>>();for&(i,j,c,_)in es{if odd||c==1{let a=root(&mut p,i);let b=root(&mut p,j);p[a]=b;}}let mut sizes=BTreeMap::<usize,usize>::new();for i in 0..n{*sizes.entry(root(&mut p,i)).or_default()+=1;}let mut s=sizes.into_values().collect::<Vec<_>>();s.sort_unstable();s}
fn analyze(name:&str)->Value{
 let(n,w,sha)=fixture(name);let mut counts=BTreeMap::<Word,usize>::new();let mut zero=0;for a in w{fr(a);if a==[0;4]{zero+=1;}else{*counts.entry(a).or_default()+=1;}}
 let values=counts.keys().copied().collect::<Vec<_>>();let es=edges(&values);let sign=components(values.len(),&es,false);let all=components(values.len(),&es,true);let mut histogram=BTreeMap::<String,usize>::new();for&(_,_,c,neg)in&es{*histogram.entry(format!("{}{}",if neg{"-"}else{"+"},c)).or_default()+=1;}
 let mut affected=BTreeSet::new();for&(i,j,c,_)in&es{if c!=1{affected.insert(i);affected.insert(j);}}
 let affected_rows:usize=affected.iter().map(|i|counts[&values[*i]]).sum();let small_affected=affected.iter().filter(|&&i|values[i][1..]==[0;3]&&values[i][0]<=65535).count();
 json!({"shape":name,"fixture_sha256":sha,"input_rows":n,"zero_rows":zero,"distinct_nonzero":values.len(),"exact_group_eliminated_rows":n-zero-values.len(),"sign_components":sign.len(),"all_components":all.len(),"additional_odd_merges_upper_bound":sign.len()-all.len(),"nontrivial_component_sizes":all.iter().copied().filter(|&n|n>1).collect::<Vec<_>>(),"edge_histogram":histogram,"edge_count":es.len(),"edge_digest":hash(&serde_json::to_vec(&es).unwrap()),"odd_affected_classes":affected.len(),"odd_affected_original_rows":affected_rows,"odd_affected_small_residue_classes":small_affected,"minimum_additional_hash_probes":6*values.len(),"native_latency_measured":false,"point_transform_measured":false})
}
fn main(){let sources=source_check();let rows=[analyze("1x2"),analyze("2x2")];let any=rows.iter().any(|r|r["additional_odd_merges_upper_bound"].as_u64().unwrap()>0);let result=json!({"production_sources_checked":sources,"verified_proof_inventory":58257,"production_changed":false,"rows":rows,"any_opportunity":any,"next_action":if any{"inspect transformation and detection cost before selecting runtime"}else{"close this fixed relation family for these two fixtures"}});fs::write(format!("{ROOT}/result.json"),serde_json::to_vec_pretty(&result).unwrap()).unwrap();println!("{}",serde_json::to_string_pretty(&result).unwrap());}
#[cfg(test)]mod tests{use super::*;
 #[test]fn signed_odd_graph_matches_known_components(){let base=Fr::from_u64(23);let vals=[Fr::ONE,-Fr::ONE,base,base*Fr::from_u64(3),-base*Fr::from_u64(5),base*Fr::from_u64(35),Fr::from_u64(100003)].map(|v|v.to_canonical());let es=edges(&vals);assert_eq!(components(vals.len(),&es,false),vec![1,1,1,1,1,2]);assert_eq!(components(vals.len(),&es,true),vec![1,2,4]);}
 #[test]fn transformed_group_identity_in_scalar_additive_group(){let s=Fr::from_u64(37);for c in[3u64,5,7]{for neg in[false,true]{let a=Fr::from_u64(997);let b=Fr::from_u64(1237);let k=if neg{-Fr::from_u64(c)}else{Fr::from_u64(c)};assert_eq!(s*a+(s*k)*b,s*(a+k*b));}}}
}
