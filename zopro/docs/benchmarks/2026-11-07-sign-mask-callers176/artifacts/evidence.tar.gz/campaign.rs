use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::{BufRead, BufReader},
    os::unix::fs::MetadataExt,
    path::{Path, PathBuf},
    process::{Command, Stdio},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/sign-mask-callers176";
const X: &str = "/home/ubuntu/src/zopro-perf-work/sdk-link-flags176/tool-target/release/xtask";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn walk(p: &Path, out: &mut Vec<PathBuf>) {
    for e in fs::read_dir(p).unwrap() {
        let e = e.unwrap();
        if e.file_type().unwrap().is_dir() {
            walk(&e.path(), out)
        } else if e.file_type().unwrap().is_file() {
            out.push(e.path())
        }
    }
}
fn contexts() -> Vec<(String, String, usize, usize)> {
    let mut out = vec![];
    for (kind, n) in [("G2", 200), ("G2", 352), ("G1", 200), ("G1", 352)] {
        for w in [1, 16, 32] {
            out.push((format!("{kind}-{n}-w{w}"), kind.into(), n, w));
        }
    }
    out
}
fn args(c: &(String, String, usize, usize), arm: &str, rounds: usize) -> Vec<String> {
    vec![
        "taskset".into(),
        "-c".into(),
        if c.3 == 1 {
            "2".into()
        } else if c.3 == 16 {
            "0-15".into()
        } else {
            "0-31".into()
        },
        r(match arm {
            "frozen" => "caller-frozen",
            "OFF" => "caller-OFF",
            "ON" => "caller-ON",
            _ => panic!("arm"),
        })
        .display()
        .to_string(),
        c.1.clone(),
        c.2.to_string(),
        c.3.to_string(),
        rounds.to_string(),
        if arm == "ON" {
            "ON".into()
        } else {
            "OFF".into()
        },
    ]
}
fn step(name: String, argv: Vec<String>) -> Value {
    json!({"kind":"command","name":name,"argv":argv,"timeout_seconds":600})
}
fn prepare() {
 assert!(!r("plan.json").exists());assert_eq!(read(r("native-continuation/result.json"))["status"],"complete");assert_eq!(read(r("native-test-qualification.json"))["passed"],true);
 let test=fs::read_to_string(r("native-runs/core-test-ON/stdout.log")).unwrap();assert!(test.contains("3 passed; 0 failed")&&test.contains("125 filtered out"));
 let native=read(r("native-plan.json"));let mut pins=read(r("native-continuation-pins.json")).as_object().unwrap().iter().map(|(p,h)|(p.clone(),h.as_str().unwrap().to_owned())).collect::<BTreeMap<_,_>>();for(p,h)in &pins{assert_eq!(hash(p),*h);}
 let field="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/frozen/candidate/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib";
 let mut identities=BTreeMap::new();for arm in["OFF","ON"]{
  for n in[format!("core-{arm}"),format!("driver-{arm}")]{let dir=if n=="driver-ON"{"native-continuation"}else{"native-runs"};let step=native["steps"].as_array().unwrap().iter().find(|s|s["name"]==n).unwrap();let cmd=read(r(format!("{dir}/{n}/command.json")));assert_eq!(&cmd["argv"].as_array().unwrap()[4..],step["argv"].as_array().unwrap().as_slice());let e=read(r(format!("{dir}/{n}/exit.json")));assert_eq!(e["success"],true);if n.starts_with("core-"){assert!(cmd["argv"].as_array().unwrap().iter().any(|v|v.as_str()==Some(&format!("zopro_bn254={field}"))));}else{let args=cmd["argv"].as_array().unwrap();for flag in["-O","target-cpu=native","lto=fat","codegen-units=1"]{assert!(args.iter().any(|v|v.as_str()==Some(flag)));}}
  }
  let binary=r(format!("caller-{arm}"));let core=r(format!("libs/{arm}/libzopro_core.rlib"));identities.insert(arm,json!({"binary":binary,"binary_sha256":hash(&binary),"core_library":core,"core_sha256":hash(&core),"field_library":field,"field_sha256":hash(field)}));
 }
 let frozen=read(r("frozen-reference.json"));let source=frozen["binary"].as_str().unwrap();assert_eq!(hash(source),frozen["binary_sha256"]);assert!(!r("caller-frozen").exists());fs::copy(source,r("caller-frozen")).unwrap();assert_eq!(hash(r("caller-frozen")),frozen["binary_sha256"]);let mut reference=frozen.clone();reference["binary"]=json!(r("caller-frozen"));identities.insert("frozen",reference);assert_ne!(identities["OFF"]["binary_sha256"],identities["ON"]["binary_sha256"]);save(r("caller-identities.json"),&json!(identities));
 for leaf in["caller-identities.json","campaign.rs","campaign","campaign-head.rs","make-campaign.rs","campaign-source-audit.json","design.md","source-audit.json","caller.rs","perf.rs","caller-OFF","caller-ON","caller-frozen","libs/OFF/libzopro_core.rlib","libs/ON/libzopro_core.rlib"]{let p=r(leaf);pins.insert(p.display().to_string(),hash(p));}
 let mut receipts=Vec::new();walk(&r("native-runs"),&mut receipts);walk(&r("native-continuation"),&mut receipts);for p in receipts{pins.insert(p.display().to_string(),hash(p));}for leaf in["native-test-qualification.json","native-continuation-plan.json","repair-native.rs"]{let p=r(leaf);pins.insert(p.display().to_string(),hash(p));}pins.insert(X.into(),hash(X));
 let env=json!({"MALLOC_ARENA_MAX":"32","MALLOC_MMAP_THRESHOLD_":"1073741824","MALLOC_TRIM_THRESHOLD_":"-1"});
    let cs = contexts();
    let mut steps = vec![];
    for c in &cs {
        for arm in ["frozen", "OFF", "ON"] {
            steps.push(step(format!("preflight-{}-{arm}", c.0), args(c, arm, 64)));
        }
    }
    steps.push(step(
        "preflight-check".into(),
        vec![r("campaign").display().to_string(), "preflight".into()],
    ));
    for b in 0..15 {
        let mut order = (0..cs.len()).collect::<Vec<_>>();
        order.rotate_left(b % cs.len());
        if b % 2 == 1 {
            order.reverse();
        }
        for i in order {
            let c = &cs[i];
            let mut arms = ["frozen", "OFF", "ON"];
            arms.rotate_left((b + i) % 3);
            if b % 2 == 1 {
                arms.reverse();
            }
            for arm in arms {
                steps.push(step(
                    format!("latency-{}-b{b:02}-{arm}", c.0),
                    args(c, arm, 4096),
                ));
            }
        }
    }
    for dir in ["stat", "perf"] {
        fs::create_dir(r(dir)).unwrap();
    }
    for name in ["ctl", "ack"] {
        assert!(Command::new("mkfifo")
            .arg(r(name))
            .status()
            .unwrap()
            .success());
    }
    let selected = cs.iter().filter(|c| c.3 == 32).collect::<Vec<_>>();
    for profile in [false, true] {
        for c in &selected {
            for arm in ["OFF", "ON"] {
                let name = format!("{}-{}-{arm}", if profile { "cycles" } else { "stat" }, c.0);
                let mut penv = env.clone();
                penv["ZOPRO_BENCH_PERF_CTL"] = json!(r("ctl"));
                penv["ZOPRO_BENCH_PERF_ACK"] = json!(r("ack"));
                let mut argv = vec!["sudo".into(), "-n".into(), "env".into()];
                for (k, v) in penv.as_object().unwrap() {
                    argv.push(format!("{k}={}", v.as_str().unwrap()));
                }
                argv.push("perf".into());
                if profile {
                    argv.extend([
                        "record".into(),
                        "--no-buildid-cache".into(),
                        "--sample-cpu".into(),
                        "--timestamp".into(),
                        "-P".into(),
                        "-e".into(),
                        "cycles:u".into(),
                        "-c".into(),
                        "16000000".into(),
                        "-m".into(),
                        "512".into(),
                        "-o".into(),
                        format!("{R}/perf/{name}.data"),
                    ]);
                } else {
                    argv.extend([
                        "stat".into(),
                        "--no-big-num".into(),
                        "-x".into(),
                        ";".into(),
                        "-e".into(),
                        "{cycles:u,instructions:u,cache-misses:u,branch-misses:u}".into(),
                        "-o".into(),
                        format!("{R}/stat/{name}.csv"),
                    ]);
                }
                argv.extend([
                    "--delay=-1".into(),
                    format!("--control=fifo:{R}/ctl,{R}/ack"),
                    "--".into(),
                ]);
                argv.extend(args(c, arm, if profile { 65536 } else { 16384 }));
                let mut s = step(name, argv);
                s["environment"] = penv;
                steps.push(s);
            }
        }
    }
    for c in selected {
        for arm in ["OFF", "ON"] {
            let name = format!("cycles-{}-{arm}", c.0);
            let data = format!("{R}/perf/{name}.data");
            steps.push(step(
                format!("own-{name}"),
                vec![
                    "sudo".into(),
                    "-n".into(),
                    r("campaign").display().to_string(),
                    "own".into(),
                    data.clone(),
                ],
            ));
            for meta in [false, true] {
                let mut argv = vec![
                    "perf".into(),
                    "script".into(),
                    "--header".into(),
                    "--ns".into(),
                    "-i".into(),
                    data.clone(),
                    "-F".into(),
                    "pid,tid,cpu,time,period,ip,sym".into(),
                ];
                if meta {
                    argv.extend([
                        "--show-mmap-events".into(),
                        "--show-task-events".into(),
                        "--show-lost-events".into(),
                    ]);
                }
                steps.push(step(
                    format!("{}-{name}", if meta { "metadata" } else { "decode" }),
                    argv,
                ));
            }
            steps.push(step(
                format!("events-{name}"),
                vec![
                    "perf".into(),
                    "evlist".into(),
                    "-v".into(),
                    "-i".into(),
                    data.clone(),
                ],
            ));
            steps.push(step(
                format!("loss-{name}"),
                vec![r("campaign").display().to_string(), "loss".into(), data],
            ));
        }
    }
    assert_eq!(steps.len(), 633);
    save(r("pins.json"), &json!(pins));
    save(
        r("plan.json"),
        &json!({"version":1,"source_pins":r("pins.json"),"environment":env,"steps":steps}),
    );
    println!("Frozen633 commands/592caller processes/{}pins;36preflights+check/540latency/8PMU/8profiles/40offline; no capture yet",pins.len());
}
fn preflight() {
    let mut count = 0;
    for c in contexts() {
        let mut expected = None;
        let mut caps = None;
        for arm in ["frozen", "OFF", "ON"] {
            let n = format!("preflight-{}-{arm}", c.0);
            let v = caller(&n);
            assert_eq!(read(r(format!("runs/{n}/exit.json")))["returncode"], 0);
            assert_eq!(v["rounds_per_worker"], 64);
            assert_eq!(v["complete_generator_oracle"], true);
            assert_eq!(v["timed_allocations"], 0);
            assert_eq!(v["kind"], c.1);
            assert_eq!(v["size"], c.2);
            assert_eq!(v["workers"], c.3);
            if let Some(e) = &expected {
                assert_eq!(&v["output_sha256"], e);
            } else {
                expected = Some(v["output_sha256"].clone());
            }
            if let Some(e) = &caps {
                assert_eq!(&v["scratch_capacity_bytes_by_worker"], e);
            } else {
                caps = Some(v["scratch_capacity_bytes_by_worker"].clone());
            }
            count += 1;
        }
    }
    assert_eq!(count, 36);
    println!("Checked36preflights/complete independent generator hashes/capacities/zero timed allocations");
}
fn own(data: &str) {
    assert!(Path::new(data).starts_with(r("perf")));
    assert!(data.ends_with(".data"));
    let before = hash(data);
    let md = fs::metadata(r("campaign")).unwrap();
    assert!(Command::new("chown")
        .arg(format!("{}:{}", md.uid(), md.gid()))
        .arg(data)
        .status()
        .unwrap()
        .success());
    assert_eq!(hash(data), before);
    println!(
        "{}",
        json!({"sha256_before":before,"sha256_after":hash(data),"data":data})
    );
}
fn loss(data: &str) {
    let mut child = Command::new("perf")
        .args(["script", "-D", "-i", data])
        .stdout(Stdio::piped())
        .spawn()
        .unwrap();
    let mut lines = 0;
    let mut lost = vec![];
    for line in BufReader::new(child.stdout.take().unwrap()).lines() {
        let line = line.unwrap();
        lines += 1;
        if line.contains("PERF_RECORD_LOST") {
            lost.push(line);
        }
    }
    assert!(child.wait().unwrap().success());
    println!(
        "{}",
        json!({"lines":lines,"zero_lost":lost.is_empty(),"lost":lost})
    );
}
fn caller(n: &str) -> Value {
    let text = fs::read_to_string(r(format!("runs/{n}/stdout.log"))).unwrap();
    let mut rows = text.lines().filter_map(|l| l.strip_prefix("CALLER "));
    let value = serde_json::from_str(rows.next().unwrap()).unwrap();
    assert!(rows.next().is_none());
    value
}
fn median(a: &[f64]) -> f64 {
    let mut a = a.to_vec();
    a.sort_by(f64::total_cmp);
    a[a.len() / 2]
}
fn interval(a: &[f64]) -> Value {
    assert_eq!(a.len(), 15);
    let mut x = a.to_vec();
    x.sort_by(f64::total_cmp);
    json!({"median":x[7],"low":x[3],"high":x[11],"wins":a.iter().filter(|&&r|r<1.).count(),"ratios":a})
}
fn finish() {
    assert!(!r("analysis.json").exists());
    assert_eq!(read(r("runs/result.json"))["status"], "complete");
    for (p, h) in read(r("pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let plan = read(r("plan.json"));
    let mut callers = BTreeMap::new();
    let mut receipts = vec![];
    for step in plan["steps"].as_array().unwrap() {
        let n = step["name"].as_str().unwrap();
        let base = r(format!("runs/{n}"));
        let e = read(base.join("exit.json"));
        assert_eq!(e["success"], true);
        assert_eq!(e["returncode"], 0);
        for f in ["stdout", "stderr"] {
            assert_eq!(
                hash(base.join(format!("{f}.log"))),
                e[format!("{f}_sha256")]
            );
        }
        receipts.push(json!({"name":n,"exit_sha256":hash(base.join("exit.json"))}));
        if n != "preflight-check"
            && ["preflight-", "latency-", "stat-", "cycles-"]
                .iter()
                .any(|p| n.starts_with(p))
        {
            let v = caller(n);
            assert_eq!(v["complete_generator_oracle"], true);
            assert_eq!(v["timed_allocations"], 0);
            assert_eq!(v["priming_passes"], 3);
            assert_eq!(v["priming_rounds"], 128);
            callers.insert(n.to_owned(), v);
        }
    }
    assert_eq!(callers.len(), 592);
    let mut rows = vec![];
    let mut failed = vec![];
    let mut time_vectors = BTreeMap::new();
    for c in contexts() {
        let mut times = BTreeMap::new();
        let mut cpu = BTreeMap::new();
        let mut rss = BTreeMap::new();
        let mut capacities = BTreeMap::new();
        for arm in ["frozen", "OFF", "ON"] {
            let mut t = vec![];
            let mut u = vec![];
            let mut hwm = 0f64;
            for b in 0..15 {
                let n = format!("latency-{}-b{b:02}-{arm}", c.0);
                let v = &callers[&n];
                assert_eq!(v["kind"], c.1);
                assert_eq!(v["size"], c.2);
                assert_eq!(v["workers"], c.3);
                assert_eq!(v["rounds_per_worker"], 4096);
                for other in ["frozen", "OFF", "ON"] {
                    let ov = &callers[&format!("latency-{}-b{b:02}-{other}", c.0)];
                    assert_eq!(v["output_sha256"], ov["output_sha256"]);
                    assert_eq!(
                        v["scratch_capacity_bytes_by_worker"],
                        ov["scratch_capacity_bytes_by_worker"]
                    );
                }
                let cap = v["scratch_capacity_bytes_by_worker"][0].clone();
                for each in v["scratch_capacity_bytes_by_worker"].as_array().unwrap() {
                    assert_eq!(*each, cap);
                }
                capacities.insert(arm, cap);
                t.push(v["elapsed_ns"].as_f64().unwrap() / 4096.);
                u.push(
                    (v["usage"]["user_cpu_ms"].as_f64().unwrap()
                        + v["usage"]["system_cpu_ms"].as_f64().unwrap())
                        / 4096.,
                );
                hwm = hwm.max(v["usage"]["whole_process_maxrss_kib"].as_f64().unwrap() / 1024.);
            }
            times.insert(arm, t);
            cpu.insert(arm, median(&u));
            rss.insert(arm, hwm);
        }
        let mut pairs = BTreeMap::new();
        for (num, den) in [("OFF", "frozen"), ("ON", "frozen"), ("ON", "OFF")] {
            let ratios = times[num]
                .iter()
                .zip(&times[den])
                .map(|(x, y)| x / y)
                .collect::<Vec<_>>();
            let stats = interval(&ratios);
            let pass = if num == "OFF" {
                stats["low"].as_f64().unwrap() >= 1. / 1.03
                    && stats["high"].as_f64().unwrap() <= 1.03
            } else {
                stats["high"].as_f64().unwrap() <= 1.03
            };
            if !pass {
                failed.push(format!(
                    "{}/{num}/{den}/{}",
                    c.0,
                    if num == "OFF" {
                        "calibration"
                    } else {
                        "nonregression"
                    }
                ));
            }
            pairs.insert(format!("{num}/{den}"), stats);
            time_vectors.insert(format!("{}/{num}/{den}", c.0), ratios);
        }
        rows.push(json!({"context":c.0,"median_ns_per_wave":times.iter().map(|(k,v)|(*k,median(v))).collect::<BTreeMap<_,_>>(),"CPU_ms_per_wave":cpu,"counter_RSS_MiB_diagnostic":rss,"scratch_capacity_bytes_first_worker":capacities,"pairs":pairs}));
    }
    let mut aggregates = BTreeMap::new();
    for curve in ["G1", "G2"] {
        for den in ["frozen", "OFF"] {
            let values = (0..15)
                .map(|b| {
                    ((time_vectors[&format!("{curve}-200-w32/ON/{den}")][b].ln()
                        + time_vectors[&format!("{curve}-352-w32/ON/{den}")][b].ln())
                        / 2.)
                        .exp()
                })
                .collect::<Vec<_>>();
            let stats = interval(&values);
            if stats["high"].as_f64().unwrap() >= 1. || stats["wins"].as_u64().unwrap() < 10 {
                failed.push(format!("{curve}-32aggregate/ON/{den}/gain"));
            }
            aggregates.insert(format!("{curve}/{den}"), stats);
        }
    }

    let mut counters = BTreeMap::new();
    let mut profiles = BTreeMap::new();
    let mut symbols_all = BTreeMap::new();
    for c in contexts().iter().filter(|c| c.3 == 32) {
        for arm in ["OFF", "ON"] {
            let stat = format!("stat-{}-{arm}", c.0);
            let mut values = BTreeMap::new();
            for line in fs::read_to_string(r(format!("stat/{stat}.csv")))
                .unwrap()
                .lines()
                .filter(|l| !l.starts_with('#') && !l.trim().is_empty())
            {
                let fields = line.split(';').collect::<Vec<_>>();
                let event = fields[2].trim();
                if ![
                    "cycles:u",
                    "instructions:u",
                    "cache-misses:u",
                    "branch-misses:u",
                ]
                .contains(&event)
                {
                    continue;
                }
                let count = fields[0].trim().parse::<f64>().unwrap();
                assert!(fields[4].trim().parse::<f64>().unwrap() >= 99.9);
                values.insert(
                    event.to_owned(),
                    json!({"count":count,"per_wave":count/16384.}),
                );
            }
            assert_eq!(values.len(), 4);
            counters.insert(stat, json!(values));
            let name = format!("cycles-{}-{arm}", c.0);
            let v = &callers[&name];
            let pid = v["pid"].as_u64().unwrap();
            let tids = v["worker_rows"]
                .as_array()
                .unwrap()
                .iter()
                .map(|x| x["tid"].as_u64().unwrap())
                .chain([pid])
                .collect::<BTreeSet<_>>();
            let binary = r(match arm {
                "frozen" => "caller-frozen",
                "OFF" => "caller-OFF",
                "ON" => "caller-ON",
                _ => panic!("arm"),
            });
            let metadata =
                fs::read_to_string(r(format!("runs/metadata-{name}/stdout.log"))).unwrap();
            let owners = metadata
                .lines()
                .filter(|l| l.contains("PERF_RECORD_MMAP") && l.contains(binary.to_str().unwrap()))
                .map(|l| {
                    l.split_whitespace()
                        .next()
                        .unwrap()
                        .split('/')
                        .next()
                        .unwrap()
                        .parse::<u64>()
                        .unwrap()
                })
                .collect::<BTreeSet<_>>();
            assert_eq!(owners, BTreeSet::from([pid]));
            let mut forked = BTreeSet::from([pid]);
            for l in metadata.lines() {
                if let Some((_, tail)) = l.split_once("PERF_RECORD_FORK(") {
                    let f = tail
                        .split(')')
                        .next()
                        .unwrap()
                        .split(':')
                        .map(|x| x.parse::<u64>().unwrap())
                        .collect::<Vec<_>>();
                    if f[0] == pid {
                        forked.insert(f[1]);
                    }
                }
            }
            assert!(tids.is_subset(&forked));
            let attrs = fs::read_to_string(r(format!("runs/events-{name}/stdout.log"))).unwrap();
            for needle in ["cycles:u", "16000000", "CPU", "TIME", "PERIOD"] {
                assert!(attrs.contains(needle));
            }
            assert!(!attrs.contains("freq: 1"));
            assert_eq!(
                read(r(format!("runs/loss-{name}/stdout.log")))["zero_lost"],
                true
            );
            let data = r(format!("perf/{name}.data"));
            let owner = read(r(format!("runs/own-{name}/stdout.log")));
            assert_eq!(owner["sha256_before"], owner["sha256_after"]);
            assert_eq!(hash(&data), owner["sha256_before"]);
            let assigned = v["worker_rows"]
                .as_array()
                .unwrap()
                .iter()
                .map(|v| (v["tid"].as_u64().unwrap(), v["cpu"].as_u64().unwrap()))
                .collect::<BTreeMap<_, _>>();
            let mut count = 0u64;
            let mut unknown = 0;
            let mut bins = BTreeMap::<String, u64>::new();
            for l in fs::read_to_string(r(format!("runs/decode-{name}/stdout.log")))
                .unwrap()
                .lines()
                .filter(|l| !l.starts_with('#') && !l.trim().is_empty())
            {
                let f = l.split_whitespace().collect::<Vec<_>>();
                let (p, t) = f[0].split_once('/').unwrap();
                assert_eq!(p.parse::<u64>().unwrap(), pid);
                assert!(tids.contains(&t.parse::<u64>().unwrap()));
                let cpu = f[1].trim_matches(['[', ']']).parse::<u64>().unwrap();
                assert!(cpu < 32);
                let tid = t.parse::<u64>().unwrap();
                if tid != pid {
                    assert_eq!(assigned[&tid], cpu);
                }
                assert_eq!(f[3].parse::<u64>().unwrap(), 16000000);
                let raw = f[5..].join(" ");
                let sym = rustc_demangle::try_demangle(&raw)
                    .map(|v| format!("{v:#}"))
                    .unwrap_or(raw);
                if sym.starts_with("[unknown]") {
                    unknown += 1;
                }
                *bins.entry(sym).or_default() += 1;
                count += 1;
            }
            let unknown_share = unknown as f64 / count as f64;
            let qualified = count >= 1000 && unknown_share <= 0.05;
            if !qualified {
                failed.push(format!("{name}/profile"));
            }
            symbols_all.insert(name.clone(), json!(bins));
            profiles.insert(name,json!({"samples":count,"unknown_share":unknown_share,"qualified":qualified,"zero_lost":true,"PID":pid,"TIDs":tids,"raw_sha256":hash(data)}));
        }
    }
    save(r("profile-symbols.json"), &json!(symbols_all));
    save(
        r("analysis.json"),
        &json!({"gate_passed":failed.is_empty(),"failed_checks":failed,"adopted":false,"production_changed":false,"goal_achieved":false,"new_proofs":0,"proof_ledger":32857,"rows":rows,"curve32_aggregates":aggregates,"counters":counters,"profiles":profiles,"caller_receipts":callers,"command_receipts":receipts}),
    );
    println!(
        "Closed633 commands/592checkedcallers;gate={};{}failed checks",
        failed.is_empty(),
        failed.len()
    );
}
fn main() {
    match std::env::args().nth(1).as_deref() {
        Some("prepare") => prepare(),
        Some("finish") => finish(),
        Some("preflight") => preflight(),
        Some("own") => own(&std::env::args().nth(2).unwrap()),
        Some("loss") => loss(&std::env::args().nth(2).unwrap()),
        _ => panic!("prepare/finish/own/loss"),
    }
}
