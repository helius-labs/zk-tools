use super::*;
use zopro_bn254::{G1Config,G2Config};
macro_rules! check_curve {
 ($name:ident,$config:ty,$scratch:expr,$apply:expr,$capacity:expr) => {
 #[test]fn $name(){
  use rayon::prelude::*;type C=$config;type A=Affine<C>;type P=Projective<C>;
  let g=P::generator();let nmax=512usize;
  let base=|i:usize|Fr::from((1u64<<48)*(i as u64+1)+123);
  let step=|j:usize|Fr::from(13007+j as u64*101);
  let source=P::batch_to_affine(&(0..nmax).map(|i|g*base(i)).collect::<Vec<_>>());
  let incoming=P::batch_to_affine(&(0..nmax).map(|j|g*step(j)).collect::<Vec<_>>());
  let mut inverse=vec![0;nmax];for j in 0..nmax{inverse[j*37%nmax]=j;}
  let expected=(0..7).map(|pass|P::batch_to_affine(&(0..nmax).map(|i|{let j=inverse[i];g*(base(i)+if pass<=3{step(j)*Fr::from(pass as u64)}else{-step(j)*Fr::from((pass-3)as u64)})}).collect::<Vec<_>>())).collect::<Vec<_>>();
  let original_source=source.clone();let original_incoming=incoming.clone();
  for workers in[1,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||(0..256usize).into_par_iter().for_each(|mask|{
   for n in[0,1,7,8,9,15,16,31,32,33,63,64,199,200,201,351,352,353]{
    let refs=(0..n).map(|j|((j*37%nmax)as u32|if mask>>(j%8)&1!=0{1<<31}else{0},&incoming[j])).collect::<Vec<_>>();
    let mut buckets=source.clone();let mut scratch=$scratch;let mut capacities=None;
    for pass in 1..=3{($apply)(&mut buckets,&refs,&mut scratch);for i in 0..nmax{let j=inverse[i];let row=if j>=n{0}else if mask>>(j%8)&1!=0{pass+3}else{pass};assert!(buckets[i]==expected[row][i],"n={n}mask={mask}pass={pass}slot={i}");}
     let observed=($capacity)(&scratch);if pass==3{assert_eq!(Some(observed),capacities);}capacities=Some(observed);
    }
   }
  }));}
  assert!(source==original_source);assert!(incoming==original_incoming);
 }
 };
}
check_curve!(g1_all_masks_tails_reuse_small_stack,G1Config,FqAddScratch{write_groups:true,reserve_groups:true,canonical:true,vector_inverse:true,..Default::default()},|b:&mut[Affine<G1Config>],p:&[(u32,&Affine<G1Config>)],s:&mut FqAddScratch|stream_g1_impl::<G1Config,true,true>(b,p,s),|s:&FqAddScratch|(s.groups.capacity(),s.tail.capacity()));
check_curve!(g2_all_masks_tails_reuse_small_stack,G2Config,Fq2AddScratch{canonical:true,vector_inverse:true,..Default::default()},|b:&mut[Affine<G2Config>],p:&[(u32,&Affine<G2Config>)],s:&mut Fq2AddScratch|super::g2_borrowed::apply::<G2Config,true>(b,p,s),|s:&Fq2AddScratch|(s.prefix_records.capacity(),s.tail.capacity()));

#[test]fn original_borrow_only_interface_accepts_noncopy_payload(){
 use zopro_bn254::G1Affine;
 struct NonCopy<'a>(&'a G1Affine);
 impl std::borrow::Borrow<G1Affine> for NonCopy<'_>{fn borrow(&self)->&G1Affine{self.0}}
 let p=G1Affine::IDENTITY;assert_eq!(std::mem::size_of::<(u32,NonCopy<'_>)>(),16);
 for mask in 0..=255u8{let records=(0..8).map(|i|(((mask as u32>>i)&1)<<31|i as u32,NonCopy(&p))).collect::<Vec<_>>();assert_eq!(signs::<true,G1Config>(&records),mask);assert_eq!(signs::<false,G1Config>(&records),0);}
}
