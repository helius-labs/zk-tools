use super::*;
#[inline(always)]
fn original<const SIGNED:bool,C:CurveConfig>(batch:&[(u32,impl std::borrow::Borrow<Affine<C>> )])->u8 {
    if !SIGNED {return 0;}let mut bits=0u8;for i in 0..LANES {bits|=((batch[i].0>>31)as u8)<<i;}bits
}

use core::arch::x86_64::*;
#[inline(always)]
pub(super) fn packed_signs<const SIGNED:bool,C:zopro_bn254::CurveConfig,P:std::borrow::Borrow<zopro_bn254::Affine<C>>>(batch:&[(u32,P)])->u8 {
 if !SIGNED{return 0;}
 if core::mem::size_of::<(u32,P)>()!=16{return original::<SIGNED,C>(batch);}
 assert!(batch.len()>=8);
 let index=core::ptr::addr_of!(batch[0].0);
 // SAFETY: stride==16 and len>=8. The masked32-bit loads read exactly
 // the eight initialized index fields; masked-off pointer/padding/out-of-
 // object lanes are not accessed. add(16) advances64bytes within the same
 // batch allocation. No tuple field offset is assumed. Native AVX512
 // F/VL/DQ features are fixed for this diagnostic consumer.
 unsafe {
  let a=_mm512_maskz_loadu_epi32(0x1111,index.cast());
  let b=_mm512_maskz_loadu_epi32(0x1111,index.add(16).cast());
  let select=_mm512_set_epi32(0,0,0,0,0,0,0,0,28,24,20,16,12,8,4,0);
  let values=_mm512_permutex2var_epi32(a,select,b);
  _mm256_movepi32_mask(_mm512_castsi512_si256(values))
 }
}
