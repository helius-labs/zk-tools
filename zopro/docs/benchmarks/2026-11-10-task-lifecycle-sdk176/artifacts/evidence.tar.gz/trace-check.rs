use std::collections::BTreeMap;
use zopro_prover::zopro_core::task_lifecycle::{self as trace,Snapshot};
pub fn check(done:&trace::Stopped,snapshots:&[Snapshot],workers:usize)->serde_json::Value{
 let expected=std::iter::once((0,trace::EXTERNAL)).chain((0..workers).map(|w|(1,w))).collect::<Vec<_>>();done.validate(snapshots,&expected).expect("complete trace participants/bounds");
 let mut jobs=BTreeMap::<(u64,u64),[usize;4]>::new();let mut phases=BTreeMap::<u64,(u64,u64)>::new();let mut count=0;let mut searches=0;let mut tails=0;
 for s in snapshots{let mut stack=Vec::<(u64,u64,u64)>::new();for e in &s.events{count+=1;if e[0]>done.end_ns{tails+=1;}match e[1]{1|2=>{assert!(e[2]>0&&e[3]>0);jobs.entry((e[2],e[3])).or_default()[(e[1]-1)as usize]+=1;},3|5|7=>{stack.push((e[1],e[2],e[3]));if e[1]==3{assert!(e[2]>0&&e[3]>0);jobs.entry((e[2],e[3])).or_default()[2]+=1;}else if e[1]==5{searches+=1;}else{let p=phases.entry(e[2]).or_default();assert_eq!(p.0,0,"duplicate phase {}",e[2]);p.0=e[0];}},4|6|8=>{assert_eq!(stack.pop(),Some((e[1]-1,e[2],e[3])),"scope nesting");if e[1]==4{jobs.entry((e[2],e[3])).or_default()[3]+=1;}else if e[1]==8{let p=phases.entry(e[2]).or_default();assert_eq!(p.1,0);assert!(p.0>0&&e[0]>=p.0);p.1=e[0];}},_=>panic!("unknown event kind")}}
  assert!(stack.is_empty());
 }
 for(k,c)in &jobs{assert_eq!(*c,[c[0];4],"unmatched queued-job generation(s) {k:?}");}assert!(!jobs.is_empty());
 for id in 1..=9{let p=phases.get(&id).unwrap_or_else(||panic!("required primary phase {id} missing"));assert!(p.1>=p.0&&p.0>=done.begin_ns&&p.1<=done.end_ns);}
 let root=phases[&1];for id in 2..=9{let p=phases[&id];assert!(p.0>=root.0&&p.1<=root.1,"request containment");}
 for ids in [[2,3],[3,4],[4,5],[5,6]]{assert!(phases[&ids[0]].1<=phases[&ids[1]].0,"phase order {ids:?}");}
 for id in 7..=9{let p=phases[&id];let q=phases[&5];assert!(p.0>=q.0&&p.1<=q.1,"query containment");}
 serde_json::json!({"events":count,"job_keys":jobs.len(),"published_jobs":jobs.values().map(|c|c[0]).sum::<usize>(),"repeated_keys":jobs.values().filter(|c|c[0]>1).count(),"searches":searches,"post_stop_boundary_events":tails,"phases":phases,"complete":true})
}
