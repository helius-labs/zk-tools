use super::*;
use zopro_bn254::{G2Affine,G2Projective,G2Config};
const TILE:usize=1024;
pub(crate)fn reduce(bases:&[G2Affine],order:&[u32],starts:&[usize])->Vec<G2Affine>{
 let mut packed=BatchAdd::<G2Config>::default();if !packed.borrowed_g2_enabled(){return super::reduce_indexed_buckets(bases,order,starts);}
 let mut tasks=Vec::new();let mut partial_starts=vec![0];for r in starts.windows(2){for first in(r[0]..r[1]).step_by(TILE){tasks.push((first,(first+TILE).min(r[1])));}partial_starts.push(tasks.len());}
 let mut partials=vec![G2Affine::IDENTITY;tasks.len()];let mut jobs=Vec::with_capacity(tasks.len());let mut remaining=partials.as_mut_slice();let mut first=0;while first<tasks.len(){let mut end=first;let mut n=0;while end<tasks.len()&&n+tasks[end].1-tasks[end].0<=TILE{n+=tasks[end].1-tasks[end].0;end+=1;}let(out,rest)=remaining.split_at_mut(end-first);remaining=rest;jobs.push((&tasks[first..end],out));first=end;}
 jobs.into_par_iter().for_each(|(tiles,out)|{
 let n=tiles.iter().map(|&(a,b)|(b-a).div_ceil(2)).sum::<usize>();let mut points=Vec::<LimbPoint<Fq2>>::with_capacity(n);let mut offsets=Vec::with_capacity(tiles.len());let mut counts=Vec::with_capacity(tiles.len());let mut firsts=Vec::with_capacity(n);let mut batch=Vec::with_capacity(n);let mut filled=0;
 {let output=&mut points.spare_capacity_mut()[..n];for &(start,end)in tiles{offsets.push(filled);counts.push((end-start).div_ceil(2));let mut i=start;while i<end{let a=&bases[order[i]as usize];let slot=filled;firsts.push(a);if i+1==end{output[slot].write(limbs::<G2Config>(*a));}else{let b=&bases[order[i+1]as usize];if a.is_identity(){output[slot].write(limbs::<G2Config>(*b));}else if b.is_identity(){output[slot].write(limbs::<G2Config>(*a));}else if a.x==b.x{output[slot].write(limbs::<G2Config>((*a+*b).to_affine()));}else{batch.push((slot as u32,b));}}filled+=1;i+=2;}}assert_eq!(filled,n);if !batch.is_empty(){let mut packed=BatchAdd::<G2Config>::default();gather_pairs::<G2Config,true>(output,&firsts,&batch,&mut packed.fq2);}}
 // SAFETY: each slot corresponds to one original pair or odd leaf. The
 // complete cases above write it immediately; the remaining unique slots
 // are written by gather_pairs. No length is published if either panics.
 unsafe{points.set_len(n);}
 let mut scratch=Scratch::<G2Config>::default();while counts.iter().any(|&n|n>1){reduce_layer(&mut points,&offsets,&mut counts,&mut scratch);}for(i,p)in out.iter_mut().enumerate(){*p=affine::<G2Config>(points[offsets[i]]);}
 });let counts=partial_starts.windows(2).map(|r|r[1]-r[0]).collect::<Vec<_>>();let partial_order=(0..partials.len()as u32).collect::<Vec<_>>();group_affine(&partials,&partial_order,&partial_starts,&counts)
}
#[cfg(test)]mod tests{use super::*;
#[test]fn ragged_first_pairs_match_generator_and_original(){for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||{for n in[0usize,1,7,8,9,31,32,1023,1024,1025,4097]{let coefficients=(0..n).map(|i|match i%9{0=>0i64,1|2=>1,3=>-1,4=>2,_=>(i%37+3)as i64}).collect::<Vec<_>>();let scalar=|n:i64|if n<0{-Fr::from(n.unsigned_abs())}else{Fr::from(n as u64)};let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|&c|G2Projective::generator()*scalar(c)).collect::<Vec<_>>());for bins in[1usize,17,1031]{let mut lists=vec![vec![];bins];for i in 0..n{lists[(i*37)%bins].push(i as u32);}let mut starts=vec![0];let mut order=vec![];for list in &lists{order.extend(list);starts.push(order.len());}let saved=order.clone();let actual=reduce(&bases,&order,&starts);let expected=super::super::reduce_indexed_buckets(&bases,&order,&starts);assert_eq!(actual,expected);for(b,list)in lists.iter().enumerate(){let c=list.iter().map(|&i|coefficients[i as usize]).sum::<i64>();assert_eq!(actual[b],(G2Projective::generator()*scalar(c)).to_affine());}assert_eq!(order,saved);}}});}}
}
