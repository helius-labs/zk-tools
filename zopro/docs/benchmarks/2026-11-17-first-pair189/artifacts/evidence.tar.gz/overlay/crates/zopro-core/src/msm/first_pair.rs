use super::*;
use zopro_bn254::{G2Affine,G2Projective,G2Config};
const TILE:usize=1024;
pub(crate)fn reduce(bases:&[G2Affine],order:&[u32],starts:&[usize])->Vec<G2Affine>{
 let mut packed=BatchAdd::<G2Config>::default();if !packed.borrowed_g2_enabled(){return super::reduce_indexed_buckets(bases,order,starts);}
 let mut tasks=Vec::new();let mut partial_starts=vec![0];for r in starts.windows(2){for first in(r[0]..r[1]).step_by(TILE){tasks.push((first,(first+TILE).min(r[1])));}partial_starts.push(tasks.len());}
 let mut partials=vec![G2Affine::IDENTITY;tasks.len()];let mut jobs=Vec::with_capacity(tasks.len());let mut remaining=partials.as_mut_slice();let mut first=0;while first<tasks.len(){let mut end=first;let mut n=0;while end<tasks.len()&&n+tasks[end].1-tasks[end].0<=TILE{n+=tasks[end].1-tasks[end].0;end+=1;}let(out,rest)=remaining.split_at_mut(end-first);remaining=rest;jobs.push((&tasks[first..end],out));first=end;}
 jobs.into_par_iter().for_each(|(tiles,out)|{
 let n=tiles.iter().map(|&(a,b)|(b-a).div_ceil(2)).sum::<usize>();let mut points=Vec::<LimbPoint<Fq2>>::with_capacity(n);let mut offsets=Vec::with_capacity(tiles.len());let mut counts=Vec::with_capacity(tiles.len());let mut firsts=Vec::with_capacity(n);let mut batch=Vec::with_capacity(n);let mut filled=0;
 {let output=&mut points.spare_capacity_mut()[..n];for &(start,end)in tiles{offsets.push(filled);counts.push((end-start).div_ceil(2));let mut i=start;while i<end{let a=&bases[order[i]as usize];let slot=filled;firsts.push(a);if i+1==end{output[slot].write(limbs::<G2Config>(*a));}else{let b=&bases[order[i+1]as usize];if a.is_identity(){output[slot].write(limbs::<G2Config>(*b));}else if b.is_identity(){output[slot].write(limbs::<G2Config>(*a));}else if a.x==b.x{output[slot].write(limbs::<G2Config>((*a+*b).to_affine()));}else{batch.push((slot as u32,b));}}filled+=1;i+=2;}}assert_eq!(filled,n);if !batch.is_empty(){let mut packed=BatchAdd::<G2Config>::default();gather_pairs::<G2Config,true>(output,&firsts,&batch,&mut packed.fq2);}}
 // SAFETY: each slot corresponds to one original pair or odd leaf. The
 // complete cases above write it immediately; the remaining unique slots
 // are written by gather_pairs. No length is published if either panics.
 unsafe{points.set_len(n);}
 let mut scratch=Scratch::<G2Config>::default();while counts.iter().any(|&n|n>1){reduce_layer(&mut points,&offsets,&mut counts,&mut scratch);}for(i,p)in out.iter_mut().enumerate(){*p=affine::<G2Config>(points[offsets[i]]);}
 });let counts=partial_starts.windows(2).map(|r|r[1]-r[0]).collect::<Vec<_>>();let partial_order=(0..partials.len()as u32).collect::<Vec<_>>();group_affine(&partials,&partial_order,&partial_starts,&counts)
}
#[cfg(test)]mod tests{use super::*;
#[test]fn ragged_first_pairs_match_generator_and_original(){for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||{for n in[0usize,1,7,8,9,31,32,1023,1024,1025,4097]{let coefficients=(0..n).map(|i|match i%9{0=>0i64,1|2=>1,3=>-1,4=>2,_=>(i%37+3)as i64}).collect::<Vec<_>>();let scalar=|n:i64|if n<0{-Fr::from(n.unsigned_abs())}else{Fr::from(n as u64)};let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|&c|G2Projective::generator()*scalar(c)).collect::<Vec<_>>());for bins in[1usize,17,1031]{let mut lists=vec![vec![];bins];for i in 0..n{lists[(i*37)%bins].push(i as u32);}let mut starts=vec![0];let mut order=vec![];for list in &lists{order.extend(list);starts.push(order.len());}let saved=order.clone();let actual=reduce(&bases,&order,&starts);let expected=super::super::reduce_indexed_buckets(&bases,&order,&starts);assert_eq!(actual,expected);for(b,list)in lists.iter().enumerate(){let c=list.iter().map(|&i|coefficients[i as usize]).sum::<i64>();assert_eq!(actual[b],(G2Projective::generator()*scalar(c)).to_affine());}assert_eq!(order,saved);}}});}}
}

fn gather_pairs<C: CurveConfig<Base = Fq2>, const FAST: bool>(
    outputs: &mut [std::mem::MaybeUninit<LimbPoint<C::Base>>],
    first: &[&Affine<C>],
    batch: &[(u32, &Affine<C>)],
    s: &mut Fq2AddScratch,
) {
    let full = batch.len() / LANES * LANES;
    let mut chains = FqBatch::one();
    s.prefix_records.clear();
    s.prefix_records.reserve(full / LANES);
    for k in (0..full).step_by(LANES) {
        let ax = fq2_pack(core::array::from_fn(|i| {
            first[(batch[k + i].0 & 0x7fffffff) as usize].x
        }));
        let bx = fq2_pack(core::array::from_fn(|i| batch[k + i].1.x));
        let denominator = core::array::from_fn(|i| canonical_sub::<FAST>(&bx[i], &ax[i]));
        let norm = Fq2::lanes_norm(&denominator);
        s.prefix_records.push([chains, norm]);
        chains = chains.mul(&norm);
    }
    s.tail.clear();
    let mut inverse =
        if let Some(value) = direct_chain_inverse(&chains, full == batch.len(), s.vector_inverse) {
            value
        } else {
            let mut tail = chains.get();
            for k in full..batch.len() {
                let (encoded, b) = batch[k];
                let index = encoded & 0x7fffffff;
                let b = if encoded >> 31 != 0 { -*b } else { *b };
                let a = *first[index as usize];
                let denominator = b.x - a.x;
                let norm = denominator.c0.square() + denominator.c1.square();
                let numerator = ((b.y - a.y) * denominator.conjugate()).mul_by_fp(&tail[k % LANES]);
                tail[k % LANES] *= norm;
                s.tail
                    .push([a.x, a.y, a.x + b.x, Fq2::new(norm, Fq::ZERO), numerator]);
            }
            let mut inverse = invert_lanes(tail, s.vector_inverse);
            for k in (full..batch.len()).rev() {
                let [ax, ay, xsum, norm, numerator] = s.tail[k - full];
                let slope = numerator.mul_by_fp(&inverse[k % LANES]);
                inverse[k % LANES] *= norm.c0;
                let x = slope.square() - xsum;
                let y = slope * (ax - x) - ay;
                outputs[(batch[k].0 & 0x7fffffff) as usize].write(limbs::<C>(Affine::new(x, y)));
            }
            FqBatch::new(&inverse)
        };
    for j in (0..full / LANES).rev() {
        let k = j * LANES;
        let a: [Affine<C>; LANES] =
            core::array::from_fn(|i| *first[(batch[k + i].0 & 0x7fffffff) as usize]);
        let b: [&Affine<C>; LANES] = core::array::from_fn(|i| batch[k + i].1);
        let ax = fq2_pack(a.map(|p| p.x));
        let ay = fq2_pack(a.map(|p| p.y));
        let bx = fq2_pack(b.map(|p| p.x));
        let dy=if FAST{
            let by=fq2_pack(b.map(|p|p.y));
            let negative=signs::<true,C>(&batch[k..k+LANES]);
            core::array::from_fn(|i|by[i].signed_difference_canonical(&ay[i],negative))
        }else{
            let by=fq2_pack(core::array::from_fn(|i|if batch[k+i].0>>31!=0{-b[i].y}else{b[i].y}));
            core::array::from_fn(|i|canonical_sub::<FAST>(&by[i],&ay[i]))
        };
        let denominator=core::array::from_fn(|i|canonical_sub::<FAST>(&bx[i],&ax[i]));
        let factor = s.prefix_records[j][0].mul(&inverse);
        inverse = inverse.mul(&s.prefix_records[j][1]);
        let slope = Fq2::lanes_scaled_numerator(&dy, &denominator, &factor);
        let x = Fq2::lanes_sub(&Fq2::lanes_square(&slope), &Fq2::lanes_add(&ax, &bx));
        let y = Fq2::lanes_sub(&Fq2::lanes_mul(&slope, &Fq2::lanes_sub(&ax, &x)), &ay);
        let (x, y) = (fq2_unpack(x), fq2_unpack(y));
        for i in 0..LANES {
            outputs[(batch[k + i].0 & 0x7fffffff) as usize].write(limbs::<C>(Affine::new(x[i], y[i])));
        }
    }
}
