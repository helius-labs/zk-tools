# G2 width13 with an indexed nine-bit top

The complete-query gate is **false**. The candidate is rejected; this fixed recipe is closed without an unchanged rerun or width/partition search. Production remains source176/SDK6d83; the accepted primary proof latency remains7.928660ms. These measurements are complete MSM queries, not proof timings.

Primary B2/32 ON/OFF is **1.365277554 [1.356242657, 1.380966286], 0/15**, and ON/frozen is **1.362657056 [1.347701272, 1.383632946], 0/15**. Failed checks:`["1x2-A-w32/candidate_over_frozen/nonregression","1x2-B-w1/candidate_over_control/nonregression","1x2-B-w1/candidate_over_frozen/nonregression","1x2-B-w1/calibration","1x2-B-w16/candidate_over_control/nonregression","1x2-B-w16/candidate_over_frozen/nonregression","1x2-B-w32/candidate_over_control/nonregression","1x2-B-w32/candidate_over_control/gain","1x2-B-w32/candidate_over_frozen/nonregression","1x2-B-w32/candidate_over_frozen/gain","2x2-A-w32/candidate_over_control/nonregression","2x2-A-w32/calibration","2x2-B-w1/candidate_over_control/nonregression","2x2-B-w1/candidate_over_frozen/nonregression","2x2-B-w1/calibration","2x2-B-w16/candidate_over_control/nonregression","2x2-B-w16/candidate_over_frozen/nonregression","2x2-B-w32/candidate_over_control/nonregression","2x2-B-w32/candidate_over_frozen/nonregression","2x2-B-w32/calibration","primary_equal_log_32/gain","primary_equal_log_32_vs_frozen/gain"]`. All observations, including control-calibration failures and positive estimates, remain.

The candidate keeps the current Phi2 split into signed magnitudes below2^126. It replaces ten ordinary12-bit windows plus a six-bit indexed top with nine ordinary13-bit windows plus a nine-bit indexed top. The original native width13 batch policy supplies352entries. Ordinary bucket slots grow2048→4096; top magnitude bins grow64→512. Original two point partitions, field arithmetic, borrowed signed queues, exceptional handling, indexed reduction, phi transform, merges, weighting and Horner recombination remain. The new child copies the original window/raw function bodies with only the nine-bit top guard and its required relative module path changed. This removes one ordinary pass over each component/part while increasing bucket work and scratch.

This differs from rejected width11/four-part, balanced11/12-span, GLS4, independent-plane and G1column candidates; their results remain closed. No table, transformed/copied key, duplicate solver plan, pool, arbitrary RAM cap or field representation is added. An optional checked whole-candidate reservation uses existing typed shape/top/leaf formulas before decomposition; denial preserves scalar words. Original forecasts remain charged, so this is conservative additional admission, not a process-memory bound. Route receipts require actual candidate entry for every ON B query, with no silent fallback. Zero overlay payload metadata does not mean zero scratch.

Ryzen9950X,16physical/32logical CPUs, shared host. Corrected optimized frozen original caller0ba4cd4e… is retained; freshOFF/ON share one executable with dispatch before the query. Actual final compiler commands require -O/native/fatLTO/CGU1, with SHA2 passed through additional_rustc_flags. Exact driver/perf sources and four independent Arkworks complete-MSM fixture references are reused. CPU2solo/0–15physical/0–31logical, individually pinned512KiB-stack Rayon workers and constrained coordinator. Timers include classification/grouping, B scalar reset, decomposition, all fills/top/merge/weighting/Horner, normalization, allocations/drop and pool dispatch/wait. Loading/pool/oracle checks are outside. Every timed output, three primes and one post-check match the independent oracle; original points remain unchanged.

Fifteen fixed rotated/reversed blocks,20timed queries per process. Primary B32 and primary equal-log A/B32 must improve against both controls: rank4–12 upper<1 and>=10/15wins. Every context upper<=1.03 and all OFF/frozen intervals within factor1.03 remain required. Rank bounds have nominal96.484375%marginal coverage conditional on independent exchangeable blocks, without a familywise guarantee. No gain floor, excluded observation, extension, favorable subset, changed threshold or parameter sweep. Unchanged A is a negative control. Marginal medians and paired ratios need not divide identically.

|Context|Frozen ms|OFF ms|ON ms|ON/OFF [bounds],wins|ON/frozen [bounds],wins|OFF/frozen [bounds],wins|
|---|---:|---:|---:|---|---|---|
|1x2-A-w1|14.588219|14.671075|14.669090|1.000695620 [0.999368238, 1.003212140], 7/15|1.006159926 [1.002380126, 1.008917745], 1/15|1.004773343 [1.002967140, 1.007530910], 0/15|
|1x2-A-w16|1.535964|1.532880|1.533763|0.997917679 [0.988562312, 1.005988917], 9/15|1.000365051 [0.985261745, 1.011543419], 7/15|1.000436694 [0.990856546, 1.011266039], 7/15|
|1x2-A-w32|1.211376|1.206471|1.211203|0.996734268 [0.984808730, 1.020973187], 9/15|0.993775026 [0.963762198, 1.030330235], 9/15|0.998060340 [0.982626983, 1.005747612], 9/15|
|1x2-B-w1|37.352115|38.971471|62.202521|1.594099694 [1.591285341, 1.596513537], 0/15|1.666568728 [1.660111543, 1.668842751], 0/15|1.045190554 [1.043805524, 1.046893538], 0/15|
|1x2-B-w16|3.667238|3.683652|5.361402|1.458193289 [1.440216098, 1.469712787], 0/15|1.451982012 [1.440540590, 1.486956691], 0/15|1.003538545 [0.988359887, 1.008138684], 6/15|
|1x2-B-w32|3.314487|3.287470|4.492732|1.365277554 [1.356242657, 1.380966286], 0/15|1.362657056 [1.347701272, 1.383632946], 0/15|0.991668116 [0.976467528, 1.021926485], 9/15|
|2x2-A-w1|14.590787|14.503265|14.494082|0.999809841 [0.997138534, 1.002913092], 8/15|0.993623062 [0.990623117, 0.998128356], 13/15|0.994646178 [0.991501372, 0.996474440], 14/15|
|2x2-A-w16|1.881469|1.877524|1.881402|1.002721709 [0.993886332, 1.028040928], 6/15|0.997577444 [0.944291384, 1.024752850], 9/15|0.999779664 [0.979533279, 1.017430181], 8/15|
|2x2-A-w32|1.545961|1.510587|1.535232|1.004107715 [0.971591907, 1.035545227], 6/15|0.991164957 [0.972075061, 1.014391974], 10/15|0.983885428 [0.961922785, 1.005497917], 10/15|
|2x2-B-w1|39.940540|41.905484|59.159698|1.412190596 [1.410672912, 1.414044599], 0/15|1.482026920 [1.481194241, 1.484420301], 0/15|1.050142161 [1.048018546, 1.051313254], 0/15|
|2x2-B-w16|4.250299|4.294850|5.607272|1.301047137 [1.297176931, 1.316052340], 0/15|1.324154101 [1.307017425, 1.335893951], 0/15|1.009896146 [0.997863762, 1.026703384], 6/15|
|2x2-B-w32|3.888798|3.939632|4.751345|1.216104237 [1.188917670, 1.240185100], 0/15|1.228337433 [1.217402760, 1.249677004], 0/15|1.008030063 [0.997034421, 1.037143995], 4/15|

Primary equal-log A/B32: ON/OFF **1.172693344 [1.151834515, 1.186843136], 0/15**; ON/frozen **1.166533718 [1.134136043, 1.195675744], 0/15**. All12 calibrations pass: **false**.


|Context|Frozen/OFF/ON CPU ms/query|Frozen/OFF/ON peak process RSS MiB|
|---|---:|---:|
|1x2-A-w1|14.588/14.671/14.669|9.50/9.50/9.50|
|1x2-A-w16|17.004/16.961/16.961|18.50/18.75/18.75|
|1x2-A-w32|24.800/25.085/24.996|24.00/22.75/24.50|
|1x2-B-w1|37.351/38.971/62.201|15.50/15.50/15.75|
|1x2-B-w16|44.839/46.605/73.202|27.00/27.75/38.75|
|1x2-B-w32|70.958/71.071/109.443|32.25/35.25/50.00|
|2x2-A-w1|14.591/14.503/14.494|12.75/13.00/13.00|
|2x2-A-w16|17.632/17.611/17.629|22.50/22.50/24.25|
|2x2-A-w32|26.384/26.319/26.188|28.50/33.25/28.50|
|2x2-B-w1|39.940/41.904/59.158|27.25/27.25/27.25|
|2x2-B-w16|48.191/50.362/70.999|43.25/36.00/50.00|
|2x2-B-w32|76.536/77.811/105.790|60.25/60.50/76.25|

CPU is summed process service. RSS is lifetime high-water including loading/primes and fixture arrays, not prover peak, incremental workspace or minimumRAM. Fault/context-switch counters remain in raw receipts; they do not isolate a latency cause.

After all latency,12FIFO-gated grouped counter panels and12separate fixed16M cycles:u profiles run200queries after3excluded primes. The prospectively declared capture amendment adds unchanged-A and frozen panels to the initial B-only diagnostic proposal; it changes no latency gate. All600caller processes finish before60ownership/decode/event/loss steps. No owned build/helper/hash/archive/analyzer/second workload overlaps capture.

|Panel|Cycles M/query|Instructions M/query|Cache misses M/query|Branch misses M/query|Samples|Qualified counter/profile|
|---|---:|---:|---:|---:|---:|---|
|stat-1x2-A-w16-candidate|85.554|207.352|0.213710|0.136892|1066|true/null|
|stat-1x2-A-w16-control|85.587|207.283|0.217429|0.136196|1063|true/null|
|stat-1x2-A-w16-frozen|85.526|207.397|0.210457|0.137978|1063|true/null|
|stat-1x2-A-w32-candidate|113.356|212.754|0.287308|0.162598|1415|true/null|
|stat-1x2-A-w32-control|113.497|212.896|0.283692|0.161613|1412|true/null|
|stat-1x2-A-w32-frozen|114.630|213.359|0.282631|0.164436|1424|true/null|
|stat-1x2-B-w16-candidate|370.127|855.915|1.217808|0.556663|4619|true/null|
|stat-1x2-B-w16-control|232.546|550.175|1.002094|0.270759|2897|true/null|
|stat-1x2-B-w16-frozen|223.104|549.324|0.748307|0.264358|2787|true/null|
|stat-1x2-B-w32-candidate|512.437|880.051|1.681690|0.615941|6412|true/null|
|stat-1x2-B-w32-control|325.337|567.891|1.154481|0.304875|4057|true/null|
|stat-1x2-B-w32-frozen|321.718|568.030|1.043670|0.311752|4012|true/null|

All32227samples are independently checked against executablePID/MMAP/FORK, registered workerTIDs/pinnedCPU and16Mperiod, with original event/loss receipts retained. Single panels and symbol/IP attribution do not establish exclusive stalls, local CPI, dynamic spills, an isolated cache/RAM cause or removable wall-time fractions. Absolute period coverage remains unvalidated. Static linked functions/disassembly are retained separately.

Corrected native qualification passes128unfiltered core tests, including three new complete-generator/bucket/recoding/admission tests, and both raw-image prover tests. New full-query cases span1/4workers,512KiB stacks,1024/1025/4097/8193points, full-width/edge scalars and identity/equal/opposite points. Independent width13 component reconstruction covers all126bit boundaries,8192deterministic full-width component values and both signs/components; ordinary0/4and indexedtop9buckets match generator sums. Fields remain byte-exact and inherit prior qualification; no fresh field/portable/cubic/fullSDK claim follows.

The first native core compilation failed before tests because the copied child needed one more super module qualifier. Original177-file source and failure are preserved; source-fixed changes only that child path.172original files stay exact; all four parent edits reverse to the176accepted originals. A small seal-helper compilation also needed a borrowed PathBuf; initial helper source is retained. These repairs precede successful qualification and all measurements. Display-only float checks use relative1e-12 before capture; integer durations/gates remain exact. Successful tests/builds/captures are not repeated.

The665successful workflow commands plus one initial failed native compile are retained.600caller processes check18036complete query outputs against reused independent references. No solve, oracle execution, SDK proof or Gnark export is added; verified ledger27353 stays unchanged. Independent review recomputes raw command exits/streams, all wall/CPU/RSS pairs, full failed/passed gate, counters and every sampled symbol bin and thread binding. Final archive verification checks exact bytes and report links without rerunning queries.

Inherited accepted proof timings versus supplied M5 CPU/Metal references follow. None is newly measured by this query trial.

|Shape|Accepted ms|M5 CPU ms / speedup|M5 Metal ms / speedup|CPU 10× target ms|
|---|---:|---:|---:|---:|
|1×2|7.928660|37 / 4.667×|24 / 3.027×|3.7|
|2×2|11.151932|59 / 5.291×|30 / 2.690×|5.9|
|4×2|16.086386|109 / 6.776×|48 / 2.984×|10.9|
|8×2|24.179453|189 / 7.817×|74 / 3.060×|18.9|
|12×2|33.884455|284 / 8.381×|101 / 2.981×|28.4|
|16×2|40.077381|335 / 8.359×|124 / 3.094×|33.5|
|24×2|65.850777|528 / 8.018×|176 / 2.673×|52.8|
|merge 24→1|65.060937|507 / 7.793×|175 / 2.690×|50.7|

All eight10×CPU targets remain unmet,0/8. Primary7.928660ms/132.75MiB; target3.7ms. Merge54 remains161.883899ms/1876.9609375MiB with no supplied M5 reference. Historical c7a source175 primary: Zopro11.915591ms/32workers versus Aeglos7.959184ms/96workers; these predate source176 and are not refreshed here. Accepted physical16 calibration engineering exception remains documented. No new AWS resources, Aeglos comparison, mobile/ARM/TEE, huge-circuit, pressure/swap, minimumRAM or concurrent-throughput result.

[Design](artifacts/design.md), [capture protocol](artifacts/capture-design.md), [all observations](artifacts/analysis.json), [independent review](artifacts/review.json), [source audit](artifacts/source-audit-fixed.json), [identities](artifacts/identities.json), [symbols](artifacts/symbols.json), [linked code](artifacts/codegen.json). Archives: [both source snapshots](artifacts/source.tar.gz), [workflow/helper sources](artifacts/workflow.tar.gz), [all raw command receipts](artifacts/receipts.tar.gz), [linked disassembly](artifacts/codegen.tar.gz). [Checksums](SHA256SUMS). Raw fixture/scalar/unblinded-point inputs, executables/libraries and perf.data stay local with hashes. Local root:`/home/ubuntu/src/zopro-perf-work/g2-wide-top176`.
