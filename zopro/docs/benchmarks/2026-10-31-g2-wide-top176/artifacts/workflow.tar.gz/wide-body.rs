
pub(super) fn try_raw(bases:&[G2Affine],words:&mut[[u64;4]],allow:bool)->Option<G2Projective>{
    assert_eq!(bases.len(),words.len());
    if !allow || !(MIN_QUERY..MAX_QUERY).contains(&bases.len())
       || !crate::msm::BatchAdd::<G2Config>::default().borrowed_g2_enabled(){return None;}
    let _reservation=crate::preparation::Reservation::analysis(
        super::super::workspace::wide_g2(bases.len(),rayon::current_num_threads()))?;
    ENTERED.fetch_add(1,Ordering::Relaxed);
    Some(hb_raw(bases,words,13,2))
}

#[cfg(test)]mod tests{
 use super::*;use zopro_bn254::Fr;
 #[test]fn complete_queries_match_independent_generator_sum(){
  for workers in[1,4]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();
   for n in[1024,1025,4097,8193]{let coefficients=(0..n).map(|i|match i%7{0=>Fr::ZERO,1|2=>Fr::ONE,3=>-Fr::ONE,_=>Fr::from((i+129)as u64)}).collect::<Vec<_>>();let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|s|G2Affine::GENERATOR**s).collect::<Vec<_>>());let original=bases.clone();
    for family in 0..3{let scalars=(0..n).map(|i|match family{0=>match i%6{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,3=>Fr::from(4096u64),4=>-Fr::from(4096u64),_=>Fr::from(1u64<<63)},1=>Fr::from((i+987)as u64).pow(&[239]),_=>Fr::from(2u64).pow(&[(i%254)as u64])-Fr::ONE}).collect::<Vec<_>>();let expected=G2Affine::GENERATOR*scalars.iter().zip(&coefficients).fold(Fr::ZERO,|a,(s,c)|a+*s**c);let mut words=scalars.iter().map(Fr::to_canonical).collect::<Vec<_>>();let out=pool.install(||try_raw(&bases,&mut words,true)).unwrap();assert_eq!(out.to_affine(),expected.to_affine(),"workers={workers}n={n}family={family}");assert_eq!(words,scalars.iter().map(|s|phi_split(s.to_canonical())).collect::<Vec<_>>());assert_eq!(bases,original);}
   }
  }
 }
 #[test]fn component_bucket_oracles_cover_signs_top_and_exceptions(){
  // Independent coefficient reconstruction, not the original Booth reader.
  let mut values=vec![0u128,1,(1u128<<126)-1];for bit in 0..126{let p=1u128<<bit;values.extend([p-1,p,(p+1).min((1u128<<126)-1)]);}
  let mut state=0x81739a1dbcea8f42u64;for _ in 0..8192{state^=state<<13;state^=state>>7;state^=state<<17;let lo=state;state^=state<<13;state^=state>>7;state^=state<<17;values.push((lo as u128|((state as u128)<<64))&((1u128<<126)-1));}
  for &m in &values{for sign in[false,true]{let component=m|if sign{1u128<<127}else{0};let words=[component as u64,(component>>64)as u64,component as u64,(component>>64)as u64];for high in[false,true]{let mut reconstructed=Fr::ZERO;for w in 0..10{let d=hb_digit(&words,high,w,13);assert!(d.unsigned_abs()as usize<=if w==9{512}else{4096});let x=Fr::from(d.unsigned_abs()as u64)*Fr::from(2u64).pow(&[(13*w)as u64]);reconstructed+=if d<0{-x}else{x};}let expected=Fr::from_canonical([m as u64,(m>>64)as u64,0,0]).unwrap();assert_eq!(reconstructed,if sign{-expected}else{expected});}}}
  let n=1031;let coefficients=(0..n).map(|i|match i%5{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,_=>Fr::from((i+9)as u64)}).collect::<Vec<_>>();let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|s|G2Affine::GENERATOR**s).collect::<Vec<_>>());let words=(0..n).map(|i|phi_split(Fr::from((i+77)as u64).pow(&[251]).to_canonical())).collect::<Vec<_>>();
  for w in[0,4,9]{let got=hb_window(&bases,&words,w,13);assert_eq!(got.len(),if w==9{512}else{4096});let mut expected=vec![Fr::ZERO;got.len()];for(i,s)in words.iter().enumerate(){for high in[false,true]{let d=hb_digit(s,high,w,13);if d!=0{let c=coefficients[i]*if high{Fr::from_decimal("4407920970296243842393367215006156084916469457145843978461")}else{Fr::ONE};expected[d.unsigned_abs()as usize-1]+=if d<0{-c}else{c};}}}for(p,s)in got.iter().zip(expected){assert_eq!(*p,(G2Affine::GENERATOR*s).to_affine());}}
 }
 #[test]fn denial_and_bounds_leave_inputs_unchanged(){
  let mut words=vec![[3,0,0,0];1024];let before=words.clone();assert!(try_raw(&vec![G2Affine::GENERATOR;1024],&mut words,false).is_none());assert_eq!(words,before);assert!(try_raw(&[],&mut[],true).is_none());let cost=super::super::super::workspace::wide_g2;assert!(cost(65536,4).is_none());assert!(cost(1024,0).is_none());assert!(cost(1024,usize::MAX).is_none());assert!(cost(4097,32).unwrap()>cost(1024,1).unwrap());assert!(cost(65535,32).is_some());
 }
}
