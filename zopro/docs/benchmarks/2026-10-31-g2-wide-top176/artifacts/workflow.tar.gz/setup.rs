use serde_json::{json,Value}; use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-wide-top176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/g2-independent-planes176";
fn r(p:impl AsRef<Path>)->PathBuf{Path::new(R).join(p)}
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn pin(m:&mut BTreeMap<String,String>,p:impl AsRef<Path>){m.insert(p.as_ref().display().to_string(),hash(&p));}
fn append(p:&str,s:&str){let p=r("source").join(p);let mut v=fs::read_to_string(&p).unwrap();v.push_str("\n// BEGIN PRIVATE WIDE G2 TOP\n");v.push_str(s);fs::write(p,v).unwrap()}
fn main(){
 assert!(!r("source").exists());
 let m=read(Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
 let mut pins=BTreeMap::new();
 for(p,h)in m["source_files_sha256"].as_object().unwrap(){let from=Path::new(Z).join(p);assert_eq!(hash(&from),h.as_str().unwrap());let to=r("source").join(p);fs::create_dir_all(to.parent().unwrap()).unwrap();fs::copy(&from,to).unwrap();pin(&mut pins,&from);}
 let original=fs::read_to_string(Path::new(Z).join("crates/zopro-core/src/msm_affine/g2_phi.rs")).unwrap();
 let a=original.find("fn hb_window(").unwrap();let b=original.find("pub(super) fn raw_exclusive(").unwrap();
 let original_functions=&original[a..b];assert_eq!(original_functions.matches("<= 8").count(),1);
 let mut child=String::from("// Private width13 caller. Original window/raw bodies copied exactly except the documented nine-bit indexed-top guard.\nuse super::*;\nuse std::sync::atomic::{AtomicUsize, Ordering};\npub(crate) static ENTERED:AtomicUsize=AtomicUsize::new(0);\n");
 child.push_str(&original_functions.replace("<= 8","<= 9"));child.push_str(&fs::read_to_string(r("wide-body.rs")).unwrap());
 fs::create_dir_all(r("source/crates/zopro-core/src/msm_affine/g2_phi")).unwrap();fs::write(r("wide.rs"),&child).unwrap();fs::write(r("source/crates/zopro-core/src/msm_affine/g2_phi/wide.rs"),&child).unwrap();
 append("crates/zopro-core/src/msm_affine/g2_phi.rs", "#[cfg(zopro_wide_g2_top)] pub(super) mod wide;\n");
 let p=r("source/crates/zopro-core/src/msm_affine/g2_phi.rs");let mut s=fs::read_to_string(&p).unwrap();let a="    hb_raw(bases, words, 12, 2)";assert_eq!(s.matches(a).count(),1);s=s.replace(a,"    #[cfg(zopro_wide_g2_top)]\n    if std::env::var(\"ZOPRO_CPU_WIDE_G2_TOP\").ok().as_deref()==Some(\"1\") {\n        if let Some(out)=wide::try_raw(bases,words,true) {return out;}\n    }\n    hb_raw(bases, words, 12, 2)");fs::write(p,s).unwrap();
 append("crates/zopro-core/src/msm_affine/workspace.rs",r#"
#[cfg(zopro_wide_g2_top)]
pub(crate) fn wide_g2(n:usize,workers:usize)->Option<usize>{
 if !(1024..65536).contains(&n)||workers==0{return None;}
 let p=shape::<G2Config>(4096,10,2,batch_size(13).max(32))?;
 let t=top::<G2Config>(n.div_ceil(2),10)?;
 let extra=mul(vector::<zopro_bn254::G2Affine>(512,false)?,3)?;
 let held=add(add(p.held,mul(add(t.held,extra)?,2)?)?,vector::<[u64;4]>(n,false)?)?;
 add(held,mul(p.leaf.max(t.leaf),workers)?)
}
"#);
 append("crates/zopro-core/src/msm_affine.rs","#[cfg(zopro_wide_g2_top)] pub(crate) fn wide_g2_calls()->usize{g2_phi::wide::ENTERED.load(std::sync::atomic::Ordering::Relaxed)}\n");
 let probe=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/coalesce-query176/probe-export.rs").unwrap();let needle="(crate::msm_affine::g2_query_exclusive(bases,words),Metadata::default())";assert_eq!(probe.matches(needle).count(),1);let probe=probe.replace(needle,"{let before=crate::msm_affine::wide_g2_calls();let out=crate::msm_affine::g2_query_exclusive(bases,words);let calls=crate::msm_affine::wide_g2_calls()-before;(out,Metadata{route:calls as u32,..Metadata::default()})}");fs::write(r("probe-export.rs"),&probe).unwrap();append("crates/zopro-core/src/lib.rs",&probe);
 let mut exact=0;let mut files=BTreeMap::new();for(p,h)in m["source_files_sha256"].as_object().unwrap(){let path=r("source").join(p);let bytes=fs::read(&path).unwrap();let original=fs::read(Path::new(Z).join(p)).unwrap();let is_exact=hash(&path)==h.as_str().unwrap();if is_exact{exact+=1;}else{let marker=b"\n// BEGIN PRIVATE WIDE G2 TOP\n";let at=bytes.windows(marker.len()).position(|v|v==marker).unwrap();let mut recovered=String::from_utf8(bytes[..at].to_vec()).unwrap();if p.ends_with("g2_phi.rs"){let a=recovered.find("    #[cfg(zopro_wide_g2_top)]\n").unwrap();let b=a+recovered[a..].find("    hb_raw(bases, words, 12, 2)").unwrap();recovered.replace_range(a..b,"");}assert_eq!(recovered.as_bytes(),original);}files.insert(p.clone(),json!({"original_sha256":h,"private_sha256":hash(path),"exact":is_exact,"recovered":true}));}
 assert_eq!(exact,172);save(r("source-audit.json"),&json!({"originals":176,"exact":exact,"changed_parents":4,"new_children":1,"all_originals_recover_exactly":true,"all_field_sources_exact":true,"window_raw_original_text_sha256":format!("{:x}",Sha256::digest(original_functions)),"only_copied_function_change":"indexed top guard<=8 to<=9 in new child only","files":files}));
 let flags=m["rustflags"].as_str().unwrap().to_owned()+" --cfg zopro_coalesce_probe --cfg zopro_wide_g2_top";for f in["native-flags.txt","candidate-flags.txt"]{fs::write(r(f),&flags).unwrap();}
 for file in["native.rs","build.rs","link.rs","capture.rs","counter.rs","sampling.rs","codegen.rs","review.rs"]{let mut s=fs::read_to_string(Path::new(OLD).join(file)).unwrap().replace(OLD,R).replace("ZOPRO_CPU_INDEPENDENT_G2","ZOPRO_CPU_WIDE_G2_TOP").replace("g2_phi::independent::","g2_phi::wide::").replace("independent.rs","wide.rs");if file=="build.rs"{s=s.replace("\"make-review.rs\",","");}if file=="review.rs"{s=s.replace("independent::","wide::").replace("assert_eq!(exact,171)","assert_eq!(exact,172)").replace("PRIVATE INDEPENDENT G2 PLANES","PRIVATE WIDE G2 TOP");}fs::write(r(file),s).unwrap();}
 save(r("production-pins.json"),&json!(pins));println!("177private files;172exact originals;4reversible parents;copied original fill/raw bodies onlyextend newtopguard;all fields unchanged");
}
