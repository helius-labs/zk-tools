
/home/ubuntu/src/zopro-perf-work/g2-wide-top176/links/query-sdk:     file format elf64-x86-64


Disassembly of section .text:

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
