// Test-only complete-query experiment. Static positions come from HintBits,
// but every value and index is guarded before any input word is changed.
use super::*;
use zopro_bn254::{G2Affine,G2Projective};
use std::sync::atomic::{AtomicUsize,Ordering};
static ROUTES:[AtomicUsize;4]=[const{AtomicUsize::new(0)};4];

fn peel(bases:&[G2Affine],words:&mut[[u64;4]],positions:&[u32])->Option<G2Projective>{
    if bases.len()!=words.len()||positions.is_empty()
        ||positions.windows(2).any(|p|p[0]>=p[1])
        ||positions.iter().any(|&i|i as usize>=words.len()
           ||words[i as usize]!=[0;4]&&words[i as usize]!=[1,0,0,0]) {return None;}
    let selected=positions.iter().copied().filter(|&i|words[i as usize]==[1,0,0,0]).collect::<Vec<_>>();
    let sum=if selected.is_empty(){G2Projective::IDENTITY}else{
        let starts=[0,selected.len()];
        crate::msm::reduce_indexed_buckets(bases,&selected,&starts)[0].to_projective()
    };
    for&i in positions {words[i as usize]=[0;4];}
    Some(sum)
}
