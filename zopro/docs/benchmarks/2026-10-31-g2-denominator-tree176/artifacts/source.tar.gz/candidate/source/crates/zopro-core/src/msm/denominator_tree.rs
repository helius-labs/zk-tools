use super::*;use zopro_bn254::{G1Affine,G1Config,G1Projective,G2Affine,G2Config,G2Projective};
// Internal nodes use record[0]; the original norm leaves use record[1].
// A complete heap with m leaves has m-1 internal nodes, so existing storage suffices.
#[inline(always)]fn node(records:&[[FqBatch;2]],m:usize,i:usize)->FqBatch {if i<m-1{records[i][0]}else{records[i-(m-1)][1]}}
#[inline(always)]fn set_node(records:&mut[[FqBatch;2]],m:usize,i:usize,value:FqBatch){if i<m-1{records[i][0]=value}else{records[i-(m-1)][1]=value}}
fn build_products(records:&mut[[FqBatch;2]])->FqBatch {let m=records.len();if m==0{return FqBatch::one();}if m==1{return records[0][1];}for i in(0..m-1).rev(){records[i][0]=node(records,m,2*i+1).mul(&node(records,m,2*i+2));}records[0][0]}
fn propagate_inverse(records:&mut[[FqBatch;2]],inverse:FqBatch){let m=records.len();if m==0{return;}if m==1{records[0][1]=inverse;return;}records[0][0]=inverse;for i in 0..m-1{let a=node(records,m,2*i+1);let b=node(records,m,2*i+2);let inverse=records[i][0];let ia=inverse.mul(&b);let ib=inverse.mul(&a);set_node(records,m,2*i+1,ia);set_node(records,m,2*i+2,ib);}}

pub(super) fn apply<C: CurveConfig<Base = Fq2>, const FAST: bool>(
    buckets: &mut [Affine<C>],
    batch: &[(u32, &Affine<C>)],
    s: &mut Fq2AddScratch,
) {
    let full=batch.len()/LANES*LANES;
    let m=full/LANES;
    s.prefix_records.clear();s.prefix_records.reserve(m);
    for k in (0..full).step_by(LANES){
        let ax=fq2_pack(core::array::from_fn(|i|buckets[(batch[k+i].0&0x7fffffff)as usize].x));
        let bx=fq2_pack(core::array::from_fn(|i|batch[k+i].1.x));
        let denominator=core::array::from_fn(|i|canonical_sub::<FAST>(&bx[i],&ax[i]));
        let norm=Fq2::lanes_norm(&denominator);
        s.prefix_records.push([FqBatch::one(),norm]);
    }
    let chains=build_products(&mut s.prefix_records);
    s.tail.clear();
    let inverse =
        if let Some(value) = direct_chain_inverse(&chains, full == batch.len(), s.vector_inverse) {
            value
        } else {
            let mut tail = chains.get();
            for k in full..batch.len() {
                let (encoded, b) = batch[k];
                let index = encoded & 0x7fffffff;
                let b = if encoded >> 31 != 0 { -*b } else { *b };
                let a = buckets[index as usize];
                let denominator = b.x - a.x;
                let norm = denominator.c0.square() + denominator.c1.square();
                let numerator = ((b.y - a.y) * denominator.conjugate()).mul_by_fp(&tail[k % LANES]);
                tail[k % LANES] *= norm;
                s.tail
                    .push([a.x, a.y, a.x + b.x, Fq2::new(norm, Fq::ZERO), numerator]);
            }
            let mut inverse = invert_lanes(tail, s.vector_inverse);
            for k in (full..batch.len()).rev() {
                let [ax, ay, xsum, norm, numerator] = s.tail[k - full];
                let slope = numerator.mul_by_fp(&inverse[k % LANES]);
                inverse[k % LANES] *= norm.c0;
                let x = slope.square() - xsum;
                let y = slope * (ax - x) - ay;
                buckets[(batch[k].0 & 0x7fffffff) as usize] = Affine::new(x, y);
            }
            FqBatch::new(&inverse)
        };
    propagate_inverse(&mut s.prefix_records,inverse);
    for j in (0..full / LANES).rev() {
        let k = j * LANES;
        let a: [Affine<C>; LANES] =
            core::array::from_fn(|i| buckets[(batch[k + i].0 & 0x7fffffff) as usize]);
        let b: [&Affine<C>; LANES] = core::array::from_fn(|i| batch[k + i].1);
        let ax = fq2_pack(a.map(|p| p.x));
        let ay = fq2_pack(a.map(|p| p.y));
        let bx = fq2_pack(b.map(|p| p.x));
        let dy=if FAST{
            let by=fq2_pack(b.map(|p|p.y));
            let negative=signs::<true,C>(&batch[k..k+LANES]);
            core::array::from_fn(|i|by[i].signed_difference_canonical(&ay[i],negative))
        }else{
            let by=fq2_pack(core::array::from_fn(|i|if batch[k+i].0>>31!=0{-b[i].y}else{b[i].y}));
            core::array::from_fn(|i|canonical_sub::<FAST>(&by[i],&ay[i]))
        };
        let denominator=core::array::from_fn(|i|canonical_sub::<FAST>(&bx[i],&ax[i]));
        let factor=s.prefix_records[j][1];
        let slope = Fq2::lanes_scaled_numerator(&dy, &denominator, &factor);
        let x = Fq2::lanes_sub(&Fq2::lanes_square(&slope), &Fq2::lanes_add(&ax, &bx));
        let y = Fq2::lanes_sub(&Fq2::lanes_mul(&slope, &Fq2::lanes_sub(&ax, &x)), &ay);
        let (x, y) = (fq2_unpack(x), fq2_unpack(y));
        for i in 0..LANES {
            buckets[(batch[k + i].0 & 0x7fffffff) as usize] = Affine::new(x[i], y[i]);
        }
    }
}

pub struct G1Caller {
    source:Vec<G1Affine>, buckets:Vec<G1Affine>, incoming:Vec<G1Affine>,
    owned:Vec<(u32,G1Affine)>, unsigned:Vec<(u32,G1Affine)>, scratch:FqAddScratch, size:usize, seed:u64,
}
impl G1Caller {
    pub fn new(n:usize,seed:u64)->Self {
        assert!(n<=512);
        let size=n.max(1).next_power_of_two();
        let source=G1Projective::batch_to_affine(&(0..size).map(|i|G1Affine::GENERATOR*Fr::from(Self::base(i,seed))).collect::<Vec<_>>());
        let incoming=G1Projective::batch_to_affine(&(0..n).map(|i|G1Affine::GENERATOR*Fr::from(Self::step(i,seed))).collect::<Vec<_>>());
        let owned:Vec<_>=incoming.iter().enumerate().map(|(i,&p)|((((i*37+seed as usize)%size)as u32)|if i%3!=1{1<<31}else{0},p)).collect();
        let unsigned=owned.iter().map(|&(i,p)|((i&0x7fffffff),if i>>31!=0{-p}else{p})).collect();
        Self{buckets:source.clone(),source,incoming,owned,unsigned,size,seed,scratch:FqAddScratch{write_groups:true,reserve_groups:true,vector_inverse:true,canonical:true,..Default::default()}}
    }
    fn base(i:usize,seed:u64)->u64 {(1u64<<48)*(i as u64+1)+(seed+1)*100000003}
    fn step(i:usize,seed:u64)->u64 {11111+(seed+1)*1337+i as u64*101}
    pub fn reset(&mut self){self.buckets.copy_from_slice(&self.source);}
    #[inline(never)]
    pub fn run(&mut self,rounds:usize,_tree:bool,borrowed:bool){
        if borrowed {
            // The production borrowed caller already owns its pending refs.
            // Build those once per driver call, outside the per-batch loop.
            let mut storage=[(0,&self.source[0]);512];
            for (slot,(&(i,_),p)) in storage.iter_mut().zip(self.owned.iter().zip(&self.incoming)){*slot=(i,p);}
            let refs=&storage[..self.owned.len()];
            for _ in 0..rounds{stream_g1_impl::<G1Config,true,true>(&mut self.buckets,refs,&mut self.scratch);}
        }else{
            for _ in 0..rounds{stream_g1_impl::<G1Config,true,false>(&mut self.buckets,&self.unsigned,&mut self.scratch);}
        }
    }
    pub fn check(&self,rounds:usize){
        let mut coeff=(0..self.size).map(|i|Fr::from(Self::base(i,self.seed))).collect::<Vec<_>>();
        for (j,&(index,_)) in self.owned.iter().enumerate(){let s=Fr::from(Self::step(j,self.seed))*Fr::from(rounds as u64);let k=(index&0x7fffffff)as usize;coeff[k]+=if index>>31!=0{-s}else{s};}
        let expected=G1Projective::batch_to_affine(&coeff.iter().map(|&c|G1Affine::GENERATOR*c).collect::<Vec<_>>());assert_eq!(self.buckets,expected);
    }
    pub fn capacities(&self)->[usize;2]{[self.scratch.groups.capacity()*core::mem::size_of::<FqAddGroup>(),self.scratch.tail.capacity()*core::mem::size_of::<[Fq;5]>()]}
    pub fn digest(&self)->Vec<u8>{let mut out=vec![];for p in &self.buckets{for f in[p.x,p.y]{for w in f.to_canonical(){out.extend_from_slice(&w.to_le_bytes());}}}out}
}

pub struct G2Caller {
    source:Vec<G2Affine>, buckets:Vec<G2Affine>, incoming:Vec<G2Affine>,
    owned:Vec<(u32,G2Affine)>, unsigned:Vec<(u32,G2Affine)>, scratch:Fq2AddScratch, size:usize, seed:u64,
}
impl G2Caller {
    pub fn new(n:usize,seed:u64)->Self {
        assert!(n<=512);
        let size=n.max(1).next_power_of_two();
        let source=G2Projective::batch_to_affine(&(0..size).map(|i|G2Affine::GENERATOR*Fr::from(Self::base(i,seed))).collect::<Vec<_>>());
        let incoming=G2Projective::batch_to_affine(&(0..n).map(|i|G2Affine::GENERATOR*Fr::from(Self::step(i,seed))).collect::<Vec<_>>());
        let owned:Vec<_>=incoming.iter().enumerate().map(|(i,&p)|((((i*37+seed as usize)%size)as u32)|if i%3!=1{1<<31}else{0},p)).collect();
        let unsigned=owned.iter().map(|&(i,p)|((i&0x7fffffff),if i>>31!=0{-p}else{p})).collect();
        Self{buckets:source.clone(),source,incoming,owned,unsigned,size,seed,scratch:Fq2AddScratch{vector_inverse:true,canonical:true,..Default::default()}}
    }
    fn base(i:usize,seed:u64)->u64 {(1u64<<48)*(i as u64+1)+(seed+1)*100000003}
    fn step(i:usize,seed:u64)->u64 {11111+(seed+1)*1337+i as u64*101}
    pub fn reset(&mut self){self.buckets.copy_from_slice(&self.source);}
    #[inline(never)]
    pub fn run(&mut self,rounds:usize,tree:bool,borrowed:bool){
        if borrowed {
            // The production borrowed caller already owns its pending refs.
            // Build those once per driver call, outside the per-batch loop.
            let mut storage=[(0,&self.source[0]);512];
            for (slot,(&(i,_),p)) in storage.iter_mut().zip(self.owned.iter().zip(&self.incoming)){*slot=(i,p);}
            let refs=&storage[..self.owned.len()];
            for _ in 0..rounds {
                #[cfg(zopro_denominator_tree)] if tree {apply::<G2Config,true>(&mut self.buckets,refs,&mut self.scratch);continue;}
                let _=tree;super::g2_borrowed::apply::<G2Config,true>(&mut self.buckets,refs,&mut self.scratch);
            }
        }else{panic!("G2 caller is borrowed");
        }
    }
    pub fn check(&self,rounds:usize){
        let mut coeff=(0..self.size).map(|i|Fr::from(Self::base(i,self.seed))).collect::<Vec<_>>();
        for (j,&(index,_)) in self.owned.iter().enumerate(){let s=Fr::from(Self::step(j,self.seed))*Fr::from(rounds as u64);let k=(index&0x7fffffff)as usize;coeff[k]+=if index>>31!=0{-s}else{s};}
        let expected=G2Projective::batch_to_affine(&coeff.iter().map(|&c|G2Affine::GENERATOR*c).collect::<Vec<_>>());assert_eq!(self.buckets,expected);
    }
    pub fn capacities(&self)->[usize;2]{[self.scratch.prefix_records.capacity()*core::mem::size_of::<[FqBatch;2]>(),self.scratch.tail.capacity()*core::mem::size_of::<[Fq2;5]>()]}
    pub fn digest(&self)->Vec<u8>{let mut out=vec![];for p in &self.buckets{for f in[p.x.c0,p.x.c1,p.y.c0,p.y.c1]{for w in f.to_canonical(){out.extend_from_slice(&w.to_le_bytes());}}}out}
}

#[cfg(test)]mod tree_tests {
use super::*;
#[test]fn all_heap_shapes_inverse_leaf_oracle(){for m in 0..=65 {for seed in[0u64,17,100003]{let leaves=(0..m).map(|j|core::array::from_fn::<_,8,_>(|i|Fq::from(seed+(j*8+i)as u64+1))).collect::<Vec<_>>();let mut records=leaves.iter().map(|x|[FqBatch::one(),FqBatch::new(x)]).collect::<Vec<_>>();let cap=records.capacity();let root=build_products(&mut records);let product=root.get();for i in 0..8{assert_eq!(product[i],leaves.iter().fold(Fq::ONE,|p,x|p*x[i]));}propagate_inverse(&mut records,root.inverse_nonzero());for(j,r)in records.iter().enumerate(){for(i,v)in r[1].get().iter().enumerate(){assert_eq!(*v*leaves[j][i],Fq::ONE);}}assert_eq!(records.capacity(),cap);}}}
#[test]fn complete_g2_changing_generator_tails_and_reuse(){for n in[0,1,7,8,9,15,16,17,31,32,33,63,64,65,199,200,201,351,352,353,511,512]{for seed in[0,19]{let mut f=G2Caller::new(n,seed);for path in[false,true]{for rounds in[1,3,17]{f.reset();f.run(rounds,path,true);f.check(rounds);}}}}}
#[test]fn threaded_small_stack_and_equal_capacity(){use rayon::prelude::*;for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||(0..workers).into_par_iter().for_each(|i|{for n in[200,352]{let mut f=G2Caller::new(n,i as u64+1);f.run(7,false,true);f.check(7);let capacity=f.capacities();f.reset();f.run(7,true,true);f.check(7);assert_eq!(f.capacities(),capacity);}}));}}
}

