// Internal nodes use record[0]; the original norm leaves use record[1].
// A complete heap with m leaves has m-1 internal nodes, so existing storage suffices.
#[inline(always)]fn node(records:&[[FqBatch;2]],m:usize,i:usize)->FqBatch {if i<m-1{records[i][0]}else{records[i-(m-1)][1]}}
#[inline(always)]fn set_node(records:&mut[[FqBatch;2]],m:usize,i:usize,value:FqBatch){if i<m-1{records[i][0]=value}else{records[i-(m-1)][1]=value}}
fn build_products(records:&mut[[FqBatch;2]])->FqBatch {let m=records.len();if m==0{return FqBatch::one();}if m==1{return records[0][1];}for i in(0..m-1).rev(){records[i][0]=node(records,m,2*i+1).mul(&node(records,m,2*i+2));}records[0][0]}
fn propagate_inverse(records:&mut[[FqBatch;2]],inverse:FqBatch){let m=records.len();if m==0{return;}if m==1{records[0][1]=inverse;return;}records[0][0]=inverse;for i in 0..m-1{let a=node(records,m,2*i+1);let b=node(records,m,2*i+2);let inverse=records[i][0];let ia=inverse.mul(&b);let ib=inverse.mul(&a);set_node(records,m,2*i+1,ia);set_node(records,m,2*i+2,ib);}}
