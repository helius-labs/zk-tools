//! Statically dispatched sparse residual points; ordinary affine streams stay unchanged.
use zopro_bn254::{Affine, CurveConfig, Projective};
mod xyzz;
pub(super) use xyzz::Xyzz;

pub(super) trait SparsePoint<C: CurveConfig>: Copy + Send + Sync {
    fn from_affine(p: Affine<C>) -> Self;
    fn add_affine(&self, p: &Affine<C>) -> Self;
    fn batch_to_affine(points: &[Self]) -> Vec<Affine<C>>;
    fn map_x(&mut self, f: impl FnOnce(C::Base) -> C::Base);
}
impl<C: CurveConfig> SparsePoint<C> for Projective<C> {
    #[inline]
    fn from_affine(p: Affine<C>) -> Self { p.to_projective() }
    #[inline]
    fn add_affine(&self, p: &Affine<C>) -> Self { Projective::add_affine(self, p) }
    #[inline]
    fn batch_to_affine(points: &[Self]) -> Vec<Affine<C>> { Projective::batch_to_affine(points) }
    #[inline]
    fn map_x(&mut self, f: impl FnOnce(C::Base) -> C::Base) { self.x = f(self.x); }
}
impl<C: CurveConfig> SparsePoint<C> for Xyzz<C> {
    #[inline]
    fn from_affine(p: Affine<C>) -> Self { Xyzz::from_affine(p) }
    #[inline]
    fn add_affine(&self, p: &Affine<C>) -> Self { Xyzz::add_affine(self, p) }
    #[inline]
    fn batch_to_affine(points: &[Self]) -> Vec<Affine<C>> { Xyzz::batch_to_affine(points) }
    #[inline]
    fn map_x(&mut self, f: impl FnOnce(C::Base) -> C::Base) { self.x = f(self.x); }
}

/// Extra peak over the unchanged required Jacobian forecast. Charge both
/// one-field deltas (growing sparse vector and collected normalization input),
/// plus an entire previous XYZZ allocation during a growing Vec reallocation.
/// Prefix products and affine outputs have unchanged layouts. All potential
/// windows/parts are charged, including those not simultaneously executing.
pub(super) fn extra<C: CurveConfig>(half: usize, windows: usize) -> Option<usize> {
    if half == 0 || windows == 0 { return None; }
    let grown = half.max(4).checked_next_power_of_two()?;
    let delta = grown.checked_add(half)?.checked_mul(core::mem::size_of::<C::Base>())?;
    let transient = grown.checked_mul(core::mem::size_of::<Xyzz<C>>())?;
    delta.checked_add(transient)?.checked_add(256)?.checked_mul(windows)?.checked_add(128)
}

/// One OS resource snapshot per operation, before any changed Window exists.
/// The owner retains this token through feeds, Phi mapping and normalization.
pub(super) fn admit<C: CurveConfig>(half: usize, windows: usize) -> Option<crate::preparation::Reservation> {
    #[cfg(all(zopro_sparse_xyzz, feature="ifma8", target_arch="x86_64", target_feature="avx512ifma", target_feature="avx512vl", target_feature="avx512dq", not(no_ifma)))]
    if crate::simd::cpu_option("ZOPRO_CPU_SPARSE_XYZZ") {
        return crate::preparation::Reservation::analysis(extra::<C>(half, windows));
    }
    let _ = (half, windows);
    None
}

#[cfg(test)]
pub(crate) mod qualification_support;
