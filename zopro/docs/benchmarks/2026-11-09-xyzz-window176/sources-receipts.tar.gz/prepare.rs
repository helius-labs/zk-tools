use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/xyzz-window176";const P:&str="/home/ubuntu/src/zopro-perf-work/initial-unit176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(f:&str,v:Value){fs::write(format!("{R}/{f}"),serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn main(){
    assert!(!Path::new(R).join("build-plan.json").exists());
    let base="crates/zopro-core/src/msm_affine";
    for(from,to)in[("qualification_support.rs","sparse_point/qualification_support.rs"),("g1_tests.rs","borrowed_pending/xyzz_qualification.rs"),("g2_tests.rs","g2_borrowed/xyzz_qualification.rs")]{let to=format!("{R}/source/{base}/{to}");fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(format!("{R}/{from}"),to).unwrap();}
    let p=format!("{R}/source/{base}/sparse_point.rs");let mut s=fs::read_to_string(&p).unwrap();s.push_str("\n#[cfg(test)]\npub(crate) mod qualification_support;\n");fs::write(&p,s).unwrap();
    let old=read(format!("{P}/plan.json"));let mut steps=vec![];
    for variant in ["OFF","ON"]{fs::create_dir_all(format!("{R}/libs/{variant}")).unwrap();let mut s=old["steps"][0].clone();s["name"]=json!(format!("build-core-{variant}"));
        for v in s["argv"].as_array_mut().unwrap(){*v=json!(v.as_str().unwrap().replace(P,R).replace("initial_unit176_OFF",&format!("xyzz_window176_{variant}")).replace("libs/OFF",&format!("libs/{variant}")));}
        if variant=="ON"{s["argv"].as_array_mut().unwrap().extend([json!("--cfg"),json!("zopro_sparse_xyzz")]);}s["environment"]["CARGO_MANIFEST_DIR"]=json!(format!("{R}/source/crates/zopro-core"));steps.push(s);
    }
    let mut native=old["steps"].as_array().unwrap().iter().find(|s|s["name"]=="build-core-OFF-test").unwrap().clone();native["name"]=json!("build-native-tests");
    for v in native["argv"].as_array_mut().unwrap(){*v=json!(v.as_str().unwrap().replace(P,R).replace("initial_unit176_OFF-test","xyzz_window176_test").replace("core-tests-OFF-test","native-tests"));}
    native["argv"].as_array_mut().unwrap().extend([json!("--cfg"),json!("zopro_sparse_xyzz"),json!("-C"),json!("debug-assertions=yes"),json!("-C"),json!("overflow-checks=yes")]);native["environment"]["CARGO_MANIFEST_DIR"]=json!(format!("{R}/source/crates/zopro-core"));steps.push(native.clone());
    // Both admitted and denied processes run the new complete owner fixtures.
    for(name,filter,mut env)in[("qualify-native-admitted","xyzz_qualification::",json!({"XYZZ_EXPECT_ADMISSION":"yes","ZOPRO_CPU_PREPARE_MAX_BYTES":"1073741824"})),("qualify-native-denied-g1","borrowed_pending::xyzz_qualification::g1_complete_owners_match_arkworks",json!({"XYZZ_EXPECT_ADMISSION":"no","ZOPRO_CPU_PREPARE_MAX_BYTES":"0"})),("qualify-native-denied-g2","g2_borrowed::xyzz_qualification::g2_complete_phi_owner_matches_arkworks",json!({"XYZZ_EXPECT_ADMISSION":"no","ZOPRO_CPU_PREPARE_MAX_BYTES":"0"})),("qualify-token-lifetime","resource_token_lifetime_and_unwind",json!({"XYZZ_RESOURCE_LIFETIME":"1","ZOPRO_CPU_PREPARE_MAX_BYTES":"15733888"}))]{env["RAYON_NUM_THREADS"]=json!("4");steps.push(json!({"kind":"command","name":name,"argv":[format!("{R}/native-tests"),filter,"--nocapture","--test-threads=1"],"environment":env,"timeout_seconds":900}));}
    let gp=read("/home/ubuntu/src/zopro-perf-work/busy-reset176/repair-plan.json");let mut generic=gp["steps"].as_array().unwrap().last().unwrap().clone();generic["name"]=json!("build-generic-core");
    for v in generic["argv"].as_array_mut().unwrap(){*v=json!(v.as_str().unwrap().replace("/home/ubuntu/src/zopro-perf-work/busy-reset176",R).replace("busy_reset176_generic","xyzz_window176_generic"));}generic["argv"].as_array_mut().unwrap().extend([json!("--cfg"),json!("zopro_sparse_xyzz")]);generic["environment"]["CARGO_MANIFEST_DIR"]=json!(format!("{R}/source/crates/zopro-core"));steps.push(generic.clone());
    let mut gt=native;gt["name"]=json!("build-generic-tests");
    let a=gt["argv"].as_array_mut().unwrap();
    for i in 0..a.len(){let s=a[i].as_str().unwrap().to_owned();if s.starts_with("zopro_bn254="){a[i]=json!("zopro_bn254=/home/ubuntu/src/zopro-perf-work/tree-policy-owner176/libzopro_bn254-generic.rlib");}else if s.starts_with("target-cpu="){a[i]=json!("target-cpu=x86-64");}else{a[i]=json!(s.replace("xyzz_window176_test","xyzz_window176_generic_test").replace("/native-tests","/generic-tests"));}}
    a.extend([json!("--cfg"),json!("no_asm"),json!("--cfg"),json!("no_ifma")]);steps.push(gt);
    steps.push(json!({"kind":"command","name":"qualify-generic-g1-fallback","argv":[format!("{R}/generic-tests"),"borrowed_pending::xyzz_qualification::","--nocapture","--test-threads=1"],"environment":{"XYZZ_EXPECT_ADMISSION":"no","RAYON_NUM_THREADS":"4"},"timeout_seconds":900}));
    let mut pins=BTreeMap::new();let m=read(format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json"));for(rel,h)in m["source_files_sha256"].as_object().unwrap(){let p=format!("{Z}/{rel}");assert_eq!(hash(&p),h.as_str().unwrap());pins.insert(p,h.clone());let p=format!("{R}/source/{rel}");pins.insert(p.clone(),json!(hash(p)));}
    for rel in ["sparse_point.rs","sparse_point/xyzz.rs","sparse_point/qualification_support.rs","borrowed_pending/xyzz_qualification.rs","g2_borrowed/xyzz_qualification.rs"]{let p=format!("{R}/source/{base}/{rel}");pins.insert(p.clone(),json!(hash(p)));}
    for f in ["sparse_point.rs","qualification_support.rs","g1_tests.rs","g2_tests.rs","design.md","integrate.rs","integrate","source-audit.json","prepare.rs","prepare"]{let p=format!("{R}/{f}");pins.insert(p.clone(),json!(hash(p)));}
    let ledger="/home/ubuntu/src/zopro-perf-work/large-class-sdk176/proof-sha256-after-capture.json";assert_eq!(read(ledger).as_array().unwrap().len(),43730);pins.insert(ledger.into(),json!(hash(ledger)));
    for s in &steps{for v in s["argv"].as_array().unwrap(){let a=v.as_str().unwrap();let p=a.split_once('=').map_or(a,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.to_owned(),json!(hash(p)));}}}
    save("build-plan.json",json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"steps":steps}));pins.insert(format!("{R}/build-plan.json"),json!(hash(format!("{R}/build-plan.json"))));save("build-pins.json",json!(pins));println!("Prepared10serializedcommands;newWindowqualificationonly;noSDKorlatency");
}
