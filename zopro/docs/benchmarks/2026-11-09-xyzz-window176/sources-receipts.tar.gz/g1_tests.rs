use super::*;
use super::super::sparse_point::{qualification_support as q, Xyzz};
use ark_ec::{AdditiveGroup, CurveGroup, PrimeGroup};
use ark_ff::{PrimeField, Zero};
use zopro_bn254::{G1Affine,G1Config,G1Projective};
type Ark=ark_bn254::G1Projective;
fn fixture(n:usize)->(Vec<G1Affine>,Vec<ark_bn254::G1Affine>){
    let pool=Ark::normalize_batch(&q::weights().iter().map(|s|Ark::generator()*s).collect::<Vec<_>>());
    let a:Vec<_>=(0..n).map(|i|pool[if i%17==0{0}else{i%64}]).collect();(a.iter().copied().map(q::g1).collect(),a)
}
fn want(a:&[ark_bn254::G1Affine],s:&[[u64;4]],w:usize,bits:usize)->Vec<G1Affine>{
    let mut out=vec![Ark::ZERO;1<<(bits-1)];
    for(p,s)in a.iter().zip(s){let d=q::recode(*s,&vec![bits;w+1])[w];if d>0{out[d as usize-1]+=p;}else if d<0{out[(-d)as usize-1]-=p;}}
    Ark::normalize_batch(&out).into_iter().map(q::g1).collect()
}
fn run<P:SparsePoint<G1Config>>(p:&[G1Affine],s:&[[u64;4]],w:usize,bits:usize)->Vec<G1Affine>{
    let size=batch_size(bits).max(32);let mut state=Window::<G1Config,P>::new(1<<(bits-1),size);
    let cut=p.len()/2;state.feed(&p[..cut],&s[..cut],w,bits,size);state.feed(&p[cut..],&s[cut..],w,bits,size);state.finish()
}
#[test]
fn actual_g1_windows_match_arkworks(){
    let mut cases=0;
    for n in [0,1,7,31,32,199,200,201,401,1025,4097]{
        let(p,a)=fixture(n);let unchanged=p.clone();
        for kind in 0..6{let bits=[4,10,12,13,14,12][kind];let w=if kind==4{255usize.div_ceil(bits)-1}else{kind%3};
            let s:Vec<_>=q::scalars(n,kind).iter().map(|s|s.into_bigint().0).collect();let expected=want(&a,&s,w,bits);
            assert_eq!(run::<G1Projective>(&p,&s,w,bits),expected,"old n={n} kind={kind}");
            assert_eq!(run::<Xyzz<G1Config>>(&p,&s,w,bits),expected,"XYZZ n={n} kind={kind}");cases+=1;
        }assert_eq!(p,unchanged);
    }println!("G1_WINDOW_CASES={cases} TYPES=2 INDEPENDENT_ARK=true TWO_FEEDS=true");
}
fn queue_run<P:SparsePoint<G1Config>>()->Vec<G1Affine>{
    let(p,a)=fixture(401);let mut state=Window::<G1Config,P>::new(64,32);let mut want=vec![Ark::ZERO;64];
    let(mut equal,mut opposite,mut queued,mut flushes,mut packed)=(0,0,0,0,0);
    for round in 0..3{for(i,point)in p.iter().enumerate(){if point.is_identity(){continue;}let b=if i%3==0{0}else{i%32};let neg=(i+round)%3==0;let encoded=b as u32|if neg{1<<31}else{0};
        let signed=if neg{-*point}else{*point};if state.affine[b].x==signed.x&&!state.affine[b].is_identity(){if state.affine[b].y==signed.y{equal+=1}else{opposite+=1}}
        if neg{want[b]-=a[i]}else{want[b]+=a[i]}
        if state.busy(b){state.queue.push((encoded,point));queued+=1;if state.queue.len()==31{state.flush_queue();flushes+=1;}}
        else{state.add(encoded,point);if state.batch.len()==32{state.execute();state.take_from_queue();packed+=1;}}
        let mut busy=vec![0u64;state.busy.len()];for(e,_)in &state.batch{let j=(e&0x7fffffff)as usize;assert_eq!(busy[j/64]>>(j%64)&1,0);busy[j/64]|=1<<(j%64);}assert_eq!(state.busy,busy);
    }state.execute();state.flush_queue();}
    // Explicit equal/opposite sparse updates exercise doubling and cancellation.
    for index in [1,1,2,2,1,2,3,3,2]{state.projective(63,p[index]);want[63]+=a[index];}
    assert!(queued>0&&flushes>0&&packed>0);let actual=state.finish();assert_eq!(actual,Ark::normalize_batch(&want).into_iter().map(q::g1).collect::<Vec<_>>());
    println!("G1_QUEUE queued={queued} flushes={flushes} packed={packed} equal={equal} opposite={opposite}");actual
}
#[test]
fn actual_g1_queue_reuse_merge_and_normalize(){assert_eq!(queue_run::<G1Projective>(),queue_run::<Xyzz<G1Config>>());}
#[test]
fn g1_complete_owners_match_arkworks(){
    let(p,a)=fixture(2056);let cut=1025;
    for kind in [1,2,3,4]{let s=q::scalars(p.len(),kind);let words:Vec<_>=s.iter().map(|x|x.into_bigint().0).collect();let expected=a.iter().zip(&s).fold(Ark::ZERO,|sum,(p,s)|sum+*p**s).into_affine();
        for bits in [12,13,14]{assert_eq!(fused::<G1Config>(&p[..cut],&words[..cut],&p[cut..],&words[cut..],bits).to_affine(),q::g1(expected));}
        for parts in [1,2]{assert_eq!(msm::<G1Config>(&p,&words,parts,10).to_affine(),q::g1(expected));}
    }
    let half=4096;let peak=super::super::sparse_point::extra::<G1Config>(half,20).unwrap();assert!(peak>half*20*32*2);
    assert!(super::super::sparse_point::extra::<G1Config>(usize::MAX,20).is_none());assert!(super::super::sparse_point::extra::<G1Config>(4096,usize::MAX).is_none());
    let admitted=super::super::sparse_point::admit::<G1Config>(4096,20).is_some();
    let expected=std::env::var("XYZZ_EXPECT_ADMISSION").unwrap();assert_eq!(admitted,expected=="yes");println!("G1_COMPLETE_OWNER_CASES=20 ADMISSION={admitted} EXTRA_PEAK={peak}");
}
#[test]
fn g1_real_small_stack_workers_and_shared_callers(){
    let(p,a)=fixture(1025);let s:Vec<_>=q::scalars(p.len(),3).iter().map(|x|x.into_bigint().0).collect();let expected=want(&a,&s,0,10);
    for workers in [1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||{(0..workers).into_par_iter().for_each(|_|{assert_eq!(run::<Xyzz<G1Config>>(&p,&s,0,10),expected);assert_eq!(run::<G1Projective>(&p,&s,0,10),expected);});});}
    let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();std::thread::scope(|scope|{for _ in 0..4{let(pool,p,s,expected)=(&pool,&p,&s,&expected);std::thread::Builder::new().stack_size(512*1024).spawn_scoped(scope,move||pool.install(||{for _ in 0..2{assert_eq!(run::<Xyzz<G1Config>>(p,s,0,10),*expected);}})).unwrap();}});
    println!("G1_WORKER_CASES=53 BOTH_TYPES=true OS_CALLERS=4 SHARED_POOL=8 STACK_KIB=512");
}

#[test]
fn resource_token_lifetime_and_unwind(){
    if std::env::var("XYZZ_RESOURCE_LIFETIME").as_deref()!=Ok("1"){return;}
    let a=super::super::sparse_point::admit::<G1Config>(4096,20).expect("first owner admitted");
    assert!(super::super::sparse_point::admit::<G1Config>(4096,20).is_none());
    drop(a);
    let a=super::super::sparse_point::admit::<G1Config>(4096,20).expect("credit released");
    assert!(std::panic::catch_unwind(move||{let _owner=a;panic!("intentional token unwind");}).is_err());
    assert!(super::super::sparse_point::admit::<G1Config>(4096,20).is_some());
    assert!(super::super::sparse_point::admit::<G1Config>(usize::MAX,20).is_none());
    println!("RESOURCE_LIFETIME admitted denied dropped readmitted panic_released overflow_denied");
}

#[test]
fn admitted_g1_owners_share_eight_worker_pool(){
    let(p,a)=fixture(2056);let s=q::scalars(p.len(),3);let words:Vec<_>=s.iter().map(|x|x.into_bigint().0).collect();
    let expected=q::g1(a.iter().zip(&s).fold(Ark::ZERO,|sum,(p,s)|sum+*p**s).into_affine());
    let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();
    std::thread::scope(|scope|{for _ in 0..4{let(pool,p,words)=(&pool,&p,&words);std::thread::Builder::new().stack_size(512*1024).spawn_scoped(scope,move||pool.install(||{
        assert_eq!(fused::<G1Config>(&p[..1025],&words[..1025],&p[1025..],&words[1025..],13).to_affine(),expected);
        assert_eq!(msm::<G1Config>(p,words,2,10).to_affine(),expected);
    })).unwrap();}});
    println!("G1_CONCURRENT_COMPLETE_OWNERS=8 OS_CALLERS=4 SHARED_POOL=8 STACK_KIB=512");
}

#[test]
fn fused_owner_preserves_preconditions(){
    let(p,_)=fixture(1025);let words=vec![[0;4];1025];let mut cases=0;
    for bits in [12,13,14]{for kind in 0..3{
        let result=std::panic::catch_unwind(||match kind{
            0=>fused::<G1Config>(&p,&words[..1024],&p,&words,bits),
            1=>fused::<G1Config>(&p,&words,&p,&words[..1024],bits),
            _=>fused::<G1Config>(&p[..1023],&words[..1023],&p,&words,bits)
        });assert!(result.is_err(),"bits={bits} kind={kind}");cases+=1;
    }}println!("FUSED_PRECONDITION_PANICS={cases} ALL_WIDTHS=true");
}
