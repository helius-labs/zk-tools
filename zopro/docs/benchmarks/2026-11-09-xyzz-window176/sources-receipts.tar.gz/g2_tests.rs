use super::*;
use super::super::sparse_point::{qualification_support as q, Xyzz};
use ark_ec::{AdditiveGroup, AffineRepr, CurveGroup, PrimeGroup};
use ark_ff::{PrimeField, Zero};
use rayon::prelude::*;
type Ark=ark_bn254::G2Projective;
fn fixture(n:usize)->(Vec<G2Affine>,Vec<ark_bn254::G2Affine>){
    let pool=Ark::normalize_batch(&q::weights().iter().map(|s|Ark::generator()*s).collect::<Vec<_>>());
    let a:Vec<_>=(0..n).map(|i|pool[if i%17==0{0}else{i%64}]).collect();(a.iter().copied().map(q::g2).collect(),a)
}
fn phi(mut p:ark_bn254::G2Affine)->ark_bn254::G2Affine {
    if !p.is_zero(){let beta=ark_bn254::Fq::from_bigint(ark_ff::BigInt(BETA.to_canonical())).unwrap();p.x.c0*=beta;p.x.c1*=beta;}p
}
fn want(a:&[ark_bn254::G2Affine],short:&[[u64;4]],w:usize,bits:usize)->Vec<G2Affine>{
    let mut out=vec![Ark::ZERO;1<<(bits-1)];
    for(p,s)in a.iter().zip(short){for high in [true,false]{let j=usize::from(high)*2;let words=[s[j],s[j+1]&0x7fffffffffffffff,0,0];let mut d=q::recode(words,&vec![bits;w+1])[w];if s[j+1]>>63!=0{d=-d;}let point=if high{phi(*p)}else{*p};if d>0{out[d as usize-1]+=point;}else if d<0{out[(-d)as usize-1]-=point;}}}
    Ark::normalize_batch(&out).into_iter().map(q::g2).collect()
}
fn short(n:usize,kind:usize)->Vec<[u64;4]>{
    if kind<5{return q::scalars(n,kind).iter().map(|s|super::super::g2_phi::phi_split(s.into_bigint().0)).collect();}
    (0..n).map(|i|{let low=(i%5+1)as u64;let high=(i%7+1)as u64;[low,if i%2==0{1<<63}else{0},high,if i%3==0{1<<63}else{0}]}).collect()
}
#[test]
fn actual_g2_high_phi_low_windows_match_arkworks(){
    let mut cases=0;
    for n in [0,1,7,31,32,199,200,201,401,1025,4097]{let(p,a)=fixture(n);let unchanged=p.clone();
        for kind in 0..6{let bits=[4,10,12,13,14,12][kind];let w=if kind==4{126usize.div_ceil(bits)-1}else{kind%3};let s=short(n,kind);let expected=want(&a,&s,w,bits);
            assert_eq!(try_window::<G2Projective>(&p,&s,w,bits).unwrap(),expected,"old n={n} kind={kind}");
            assert_eq!(try_window::<Xyzz<G2Config>>(&p,&s,w,bits).unwrap(),expected,"XYZZ n={n} kind={kind}");cases+=1;
        }assert_eq!(p,unchanged);
    }println!("G2_WINDOW_CASES={cases} TYPES=2 INDEPENDENT_ARK=true HIGH_PHI_LOW=true");
}
fn queue_run<P:SparsePoint<G2Config>>()->Vec<G2Affine>{
    let(p,a)=fixture(401);let mut state=Window::<P>::new(64,32,BatchAdd::default());let mut want=vec![Ark::ZERO;64];
    let(mut queued,mut flushes,mut packed)=(0,0,0);
    for round in 0..3{for(i,point)in p.iter().enumerate(){if point.is_identity(){continue;}let b=if i%3==0{0}else{i%32};let neg=(i+round)%3==0;let encoded=b as u32|if neg{1<<31}else{0};
        if neg{want[b]-=a[i]}else{want[b]+=a[i]}
        if state.busy(b){state.queue.push((encoded,point));queued+=1;if state.queue.len()==31{state.flush_queue();flushes+=1;}}
        else{state.add(encoded,point);if state.batch.len()==32{state.execute();state.take_from_queue();packed+=1;}}
        let mut busy=vec![0u64;state.busy.len()];for(e,_)in &state.batch{let j=(e&0x7fffffff)as usize;assert_eq!(busy[j/64]>>(j%64)&1,0);busy[j/64]|=1<<(j%64);}assert_eq!(state.busy,busy);
    }state.execute();state.flush_queue();if round==1{for p in &mut state.affine{if !p.is_identity(){p.x=p.x.mul_by_fp(&BETA);}}for p in &mut state.projective{p.map_x(|x|x.mul_by_fp(&BETA));}for p in &mut want{*p=phi(p.into_affine()).into();}}}
    for index in [1,1,2,2,1,2,3,3,2]{state.projective(63,p[index]);want[63]+=a[index];}
    assert!(queued>0&&flushes>0&&packed>0);state.execute();state.flush_queue();let actual=state.finish();assert_eq!(actual,Ark::normalize_batch(&want).into_iter().map(q::g2).collect::<Vec<_>>());
    println!("G2_QUEUE queued={queued} flushes={flushes} packed={packed} PHI_BETWEEN_REUSE=true");actual
}
#[test]
fn actual_g2_queue_reuse_phi_merge_and_normalize(){assert_eq!(queue_run::<G2Projective>(),queue_run::<Xyzz<G2Config>>());}
#[test]
fn g2_complete_phi_owner_matches_arkworks(){
    let(p,a)=fixture(1025);for kind in [1,2,3,4]{let s=q::scalars(p.len(),kind);let mut words:Vec<_>=s.iter().map(|s|s.into_bigint().0).collect();let expected=a.iter().zip(s).fold(Ark::ZERO,|sum,(p,s)|sum+*p*s).into_affine();
        assert_eq!(super::super::g2_phi::raw_exclusive(&p,&mut words).to_affine(),q::g2(expected));
    }
    let peak=super::super::sparse_point::extra::<G2Config>(2048,22).unwrap();assert!(peak>2048*22*64*2);assert!(super::super::sparse_point::extra::<G2Config>(usize::MAX,22).is_none());
    let admitted=super::super::sparse_point::admit::<G2Config>(2048,22).is_some();assert_eq!(admitted,std::env::var("XYZZ_EXPECT_ADMISSION").unwrap()=="yes");println!("G2_COMPLETE_OWNER_CASES=4 ADMISSION={admitted} EXTRA_PEAK={peak}");
}
#[test]
fn g2_real_small_stack_workers_and_shared_callers(){
    let(p,a)=fixture(1025);let s=short(p.len(),3);let expected=want(&a,&s,0,10);
    for workers in [1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||{(0..workers).into_par_iter().for_each(|_|{assert_eq!(try_window::<Xyzz<G2Config>>(&p,&s,0,10).unwrap(),expected);assert_eq!(try_window::<G2Projective>(&p,&s,0,10).unwrap(),expected);});});}
    let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();std::thread::scope(|scope|{for _ in 0..4{let(pool,p,s,expected)=(&pool,&p,&s,&expected);std::thread::Builder::new().stack_size(512*1024).spawn_scoped(scope,move||pool.install(||{for _ in 0..2{assert_eq!(try_window::<Xyzz<G2Config>>(p,s,0,10).unwrap(),*expected);}})).unwrap();}});
    println!("G2_WORKER_CASES=53 BOTH_TYPES=true OS_CALLERS=4 SHARED_POOL=8 STACK_KIB=512");
}

#[test]
fn admitted_g2_owners_share_eight_worker_pool(){
    let(p,a)=fixture(1025);let s=q::scalars(p.len(),3);let words:Vec<_>=s.iter().map(|x|x.into_bigint().0).collect();
    let expected=q::g2(a.iter().zip(&s).fold(Ark::ZERO,|sum,(p,s)|sum+*p**s).into_affine());
    let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();
    std::thread::scope(|scope|{for _ in 0..4{let(pool,p,words)=(&pool,&p,&words);std::thread::Builder::new().stack_size(512*1024).spawn_scoped(scope,move||pool.install(||{
        let mut local=words.clone();assert_eq!(super::super::g2_phi::raw_exclusive(p,&mut local).to_affine(),expected);
    })).unwrap();}});
    println!("G2_CONCURRENT_COMPLETE_OWNERS=4 OS_CALLERS=4 SHARED_POOL=8 STACK_KIB=512");
}
