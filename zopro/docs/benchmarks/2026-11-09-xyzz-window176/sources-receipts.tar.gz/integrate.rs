use serde_json::{json, Value};
use sha2::{Digest,Sha256};
use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/xyzz-window176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn main(){
    assert!(!Path::new(R).join("source").exists());
    let m=read(format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json"));
    let originals=m["source_files_sha256"].as_object().unwrap(); assert_eq!(originals.len(),176);
    for(rel,h)in originals {let p=format!("{Z}/{rel}");assert_eq!(hash(&p),h.as_str().unwrap());let to=format!("{R}/source/{rel}");fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(p,to).unwrap();}
    let base="crates/zopro-core/src/msm_affine";
    let mut edits:BTreeMap<String,Vec<(String,String)>>=BTreeMap::new();
    let mut edit=|rel:&str,a:&str,b:&str|{
        let p=format!("{R}/source/{rel}");let s=fs::read_to_string(&p).unwrap();assert_eq!(s.matches(a).count(),1,"{rel}: {a}");fs::write(p,s.replacen(a,b,1)).unwrap();edits.entry(rel.into()).or_default().push((a.into(),b.into()));
    };
    edit(&format!("{base}.rs"),"mod grouping_cost;","mod grouping_cost;\nmod sparse_point;");
    let g=format!("{base}/borrowed_pending.rs");
    edit(&g,"mod balanced;","mod balanced;\nuse super::sparse_point::{self, SparsePoint, Xyzz};");
    edit(&g,"struct Window<'a, C: CurveConfig<Base = Fq>> {","struct Window<'a, C: CurveConfig<Base = Fq>, P: SparsePoint<C> = Projective<C>> {");
    edit(&g,"projective: Vec<Projective<C>>","projective: Vec<P>");
    edit(&g,"impl<'a, C: CurveConfig<Base = Fq>> Window<'a, C> {","impl<'a, C: CurveConfig<Base = Fq>, P: SparsePoint<C>> Window<'a, C, P> {");
    edit(&g,"self.projective.push(point.to_projective());","self.projective.push(P::from_affine(point));");
    edit(&g,"self.projective[index as usize] += point;","self.projective[index as usize] = self.projective[index as usize].add_affine(&point);");
    edit(&g,".map(|(p, &i)| *p + self.affine[i])",".map(|(p, &i)| p.add_affine(&self.affine[i]))");
    edit(&g,"for (p, &i) in Projective::<C>::batch_to_affine(&combined)","for (p, &i) in P::batch_to_affine(&combined)");
    edit(&g,"pub(super) fn fused<C: CurveConfig<Base = Fq>>(","fn fused_with<C: CurveConfig<Base = Fq>, P: SparsePoint<C>>(");
    edit(&g,"    if bits == 13 {\n        return balanced::fused(k, sk, h, sh);\n    }\n","    // The operation owner dispatches balanced windows before admission.\n");
    edit(&g,"let mut state = Window::new(1usize << (bits - 1), size);","let mut state = Window::<C,P>::new(1usize << (bits - 1), size);");
    edit(&g,"pub(crate) fn msm<C: CurveConfig<Base = Fq>>(","fn msm_with<C: CurveConfig<Base = Fq>, P: SparsePoint<C>>(");
    edit(&g,"let mut state = Window::new(1usize << (width - 1), size);","let mut state = Window::<C,P>::new(1usize << (width - 1), size);");
    edit(&g,"let mut state = Window::new(32, 8);","let mut state = Window::<zopro_bn254::G1Config>::new(32, 8);");
    let wrapper=r#"
pub(super) fn fused<C: CurveConfig<Base=Fq>>(k:&[Affine<C>],sk:&[[u64;4]],h:&[Affine<C>],sh:&[[u64;4]],bits:usize)->Projective<C>{
    assert!((12..=14).contains(&bits));
    if bits==13 {return balanced::fused(k,sk,h,sh);}
    let windows=(Fr::MODULUS_BITS as usize+1).div_ceil(bits);
    if let Some(_reservation)=sparse_point::admit::<C>(1usize<<(bits-1),windows){
        return fused_with::<C,Xyzz<C>>(k,sk,h,sh,bits);
    }
    fused_with::<C,Projective<C>>(k,sk,h,sh,bits)
}
pub(crate) fn msm<C: CurveConfig<Base=Fq>>(bases:&[Affine<C>],scalars:&[[u64;4]],parts:usize,width:usize)->Projective<C>{
    assert!((1..=2).contains(&parts));assert!((10..=14).contains(&width));
    let windows=(Fr::MODULUS_BITS as usize+1).div_ceil(width);
    if let Some(_reservation)=sparse_point::admit::<C>(1usize<<(width-1),windows*parts){
        return msm_with::<C,Xyzz<C>>(bases,scalars,parts,width);
    }
    msm_with::<C,Projective<C>>(bases,scalars,parts,width)
}
#[cfg(test)]
#[path="borrowed_pending/xyzz_qualification.rs"]
mod xyzz_qualification;
"#;
    edit(&g,"mod balanced;",&format!("mod balanced;\n{wrapper}"));
    let b=format!("{base}/borrowed_pending/balanced.rs");
    edit(&b,"fn feed<'a, C: CurveConfig<Base = Fq>>(","fn feed<'a, C: CurveConfig<Base = Fq>, P: SparsePoint<C>>(");
    edit(&b,"state: &mut Window<'a, C>","state: &mut Window<'a, C, P>");
    edit(&b,"pub(super) fn fused<C: CurveConfig<Base = Fq>>(","fn fused_with<C: CurveConfig<Base = Fq>, P: SparsePoint<C>>(");
    edit(&b,"let mut state = Window::new(1usize << (span.width - 1), size);","let mut state = Window::<C,P>::new(1usize << (span.width - 1), size);");
    edit(&b,"const COUNT: usize = 20;",r#"const COUNT: usize = 20;
pub(super) fn fused<C: CurveConfig<Base=Fq>>(k:&[Affine<C>],sk:&[[u64;4]],h:&[Affine<C>],sh:&[[u64;4]])->Projective<C>{
    if let Some(_reservation)=sparse_point::admit::<C>(4096,COUNT){return fused_with::<C,Xyzz<C>>(k,sk,h,sh);}
    fused_with::<C,Projective<C>>(k,sk,h,sh)
}"#);
    let g=format!("{base}/g2_borrowed.rs");
    edit(&g,"use super::{batch_size, digit};","use super::{batch_size, digit};\nuse super::sparse_point::SparsePoint;");
    edit(&g,"struct Window<'a> {","struct Window<'a, P: SparsePoint<G2Config> = G2Projective> {");
    edit(&g,"projective: Vec<G2Projective>","projective: Vec<P>");
    edit(&g,"impl<'a> Window<'a> {","impl<'a, P: SparsePoint<G2Config>> Window<'a,P> {");
    edit(&g,"self.projective.push(p.to_projective());","self.projective.push(P::from_affine(p));");
    edit(&g,"self.projective[i as usize] += p;","self.projective[i as usize] = self.projective[i as usize].add_affine(&p);");
    edit(&g,".map(|(p, &i)| *p + self.affine[i])",".map(|(p, &i)| p.add_affine(&self.affine[i]))");
    edit(&g,"for (p, &i) in G2Projective::batch_to_affine(&combined)","for (p, &i) in P::batch_to_affine(&combined)");
    edit(&g,"pub(super) fn try_window(","pub(super) fn try_window<P: SparsePoint<G2Config>>(");
    edit(&g,"let mut s = Window::new(1 << (bits - 1), size, packed);","let mut s = Window::<P>::new(1 << (bits - 1), size, packed);");
    edit(&g,"        p.x = p.x.mul_by_fp(&BETA);\n    }\n    s.feed", "        p.map_x(|x| x.mul_by_fp(&BETA));\n    }\n    s.feed");
    edit(&g,"//! Proof-local borrowed pending operands for ordinary G2 phi windows.","//! Proof-local borrowed pending operands for ordinary G2 phi windows.\n#[cfg(test)]\nmod xyzz_qualification;");
    let g=format!("{base}/g2_phi.rs");
    edit(&g,"use rayon::prelude::*;","use rayon::prelude::*;\nuse super::sparse_point::{self, SparsePoint, Xyzz};");
    edit(&g,"fn hb_window(bases:","fn hb_window<P: SparsePoint<G2Config>>(bases:");
    edit(&g,"super::g2_borrowed::try_window(bases, short, w, bits)","super::g2_borrowed::try_window::<P>(bases, short, w, bits)");
    edit(&g,"fn hb_raw(bases:","fn hb_raw_with<P: SparsePoint<G2Config>>(bases:");
    edit(&g,"hb_window(&bases[start..end], &short[start..end], w, bits)","hb_window::<P>(&bases[start..end], &short[start..end], w, bits)");
    edit(&g,"pub(super) fn raw_exclusive(",r#"fn hb_raw(bases:&[G2Affine],short:&mut [[u64;4]],bits:usize,parts:usize)->G2Projective{
    assert!((3..=15).contains(&bits));assert!(parts>0);
    let windows=127usize.div_ceil(bits);
    if let Some(_reservation)=windows.checked_mul(parts).and_then(|n|sparse_point::admit::<G2Config>(1usize<<(bits-1),n)){
        return hb_raw_with::<Xyzz<G2Config>>(bases,short,bits,parts);
    }
    hb_raw_with::<G2Projective>(bases,short,bits,parts)
}
pub(super) fn raw_exclusive("#);
    let mut extras=vec![];
    for (from,rel) in [(format!("{R}/sparse_point.rs"),format!("{base}/sparse_point.rs")),("/home/ubuntu/src/zopro-perf-work/xyzz-fallback176/xyzz.rs".into(),format!("{base}/sparse_point/xyzz.rs"))]{let p=format!("{R}/source/{rel}");fs::create_dir_all(Path::new(&p).parent().unwrap()).unwrap();fs::copy(from,p).unwrap();extras.push(rel);}
    // Recover every modified parent exactly, in reverse edit order.
    for(rel,es)in &edits{let mut s=fs::read_to_string(format!("{R}/source/{rel}")).unwrap();for(a,b)in es.iter().rev(){assert_eq!(s.matches(b).count(),1);s=s.replacen(b,a,1);}assert_eq!(format!("{:x}",Sha256::digest(s.as_bytes())),originals[rel].as_str().unwrap());}
    fs::write(format!("{R}/source-audit.json"),serde_json::to_vec_pretty(&json!({"originals":originals,"edits":edits,"extras":extras,"production_unchanged":true,"field_original1200":true})).unwrap()).unwrap();
    println!("Integrated5reversibleparents+2children;176originalsrecover;productionunchanged");
}
