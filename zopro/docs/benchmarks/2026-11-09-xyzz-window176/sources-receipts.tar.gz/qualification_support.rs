use ark_ec::AffineRepr;
use ark_ff::{PrimeField, Zero};
pub(crate) fn fq(x:ark_bn254::Fq)->zopro_bn254::Fq {zopro_bn254::Fq::from_canonical(x.into_bigint().0).unwrap()}
pub(crate) fn g1(p:ark_bn254::G1Affine)->zopro_bn254::G1Affine {
    if p.is_zero(){zopro_bn254::G1Affine::IDENTITY}else{zopro_bn254::G1Affine::new(fq(p.x),fq(p.y))}
}
pub(crate) fn g2(p:ark_bn254::G2Affine)->zopro_bn254::G2Affine {
    if p.is_zero(){zopro_bn254::G2Affine::IDENTITY}else{zopro_bn254::G2Affine::new(zopro_bn254::Fq2::new(fq(p.x.c0),fq(p.x.c1)),zopro_bn254::Fq2::new(fq(p.y.c0),fq(p.y.c1)))}
}
pub(crate) fn random(seed:&mut u64)->ark_bn254::Fr {
    let mut b=[0;32];for word in b.chunks_mut(8){*seed^=*seed<<13;*seed^=*seed>>7;*seed^=*seed<<17;word.copy_from_slice(&seed.to_le_bytes());}ark_bn254::Fr::from_le_bytes_mod_order(&b)
}
pub(crate) fn weights()->Vec<ark_bn254::Fr>{
    let mut seed=0x78797a7a77696e64;let mut w=vec![ark_bn254::Fr::zero(),1u64.into(),-ark_bn254::Fr::from(1u64),2u64.into(),2u64.into()];w.extend((0..59).map(|_|random(&mut seed)));w
}
pub(crate) fn scalars(n:usize,kind:usize)->Vec<ark_bn254::Fr>{
    let mut seed=0x7363616c61727461; (0..n).map(|i|match kind{
        0=>ark_bn254::Fr::zero(),1=>1u64.into(),2=>-ark_bn254::Fr::from(1u64),3=>random(&mut seed),
        4=>{let mut words=[0;4];let bit=[0,11,12,13,63,64,127,128,247,253][i%10];words[bit/64]=1u64<<(bit%64);let s=ark_bn254::Fr::from_bigint(ark_ff::BigInt(words)).unwrap();if i%2==0{s-ark_bn254::Fr::from(1u64)}else{s+ark_bn254::Fr::from(1u64)}},
        _=>ark_bn254::Fr::from((i%5+1)as u64)
    }).collect()
}
/// Independent carry recoding, from least significant bits upward. The
/// production reader instead overlaps bit fields directly at the requested span.
pub(crate) fn recode(words:[u64;4],widths:&[usize])->Vec<i16>{
    let(mut offset,mut carry)=(0,0i64);let mut out=vec![];
    for &width in widths{let mut v=carry;for j in 0..width{let bit=offset+j;if bit<256{v+=(((words[bit/64]>>(bit%64))&1)as i64)<<j;}}
        let half=1i64<<(width-1);carry=i64::from(v>=half);out.push((v-carry*(half*2))as i16);offset+=width;
    }out
}
