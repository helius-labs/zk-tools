use super::*;
impl<C:FpConfig,const MIXED:bool>Ifma8<C,MIXED>{
 /// Equality of the raw low radix-52 digit only. Not field equality.
 #[inline(always)]pub fn low_limb_eq_mask(&self,b:&Self)->u8{
  // SAFETY: parent module requires AVX512IFMA/VL/DQ; normalized limbs are52bits.
  unsafe{_mm512_cmpeq_epi64_mask(self.0[0],b.0[0])}
 }
 /// Retain ordinary normalized limbs; replace selected lanes with field one.
 #[inline(always)]pub fn masked_one(&self,mask:u8)->Self{
  let one=Self::one();
  // SAFETY: both sources have the parent's normalized-limb/range contract.
  unsafe{Self(core::array::from_fn(|i|_mm512_mask_mov_epi64(self.0[i],mask,one.0[i])),PhantomData)}
 }
}
#[cfg(test)]mod tests{
 use super::*;use crate::{Fq,FqConfig};
 fn raw(v:&Ifma8<FqConfig,true>)->[[u64;8];5]{core::array::from_fn(|i|{let mut a=[0u64;8];unsafe{_mm512_storeu_si512(a.as_mut_ptr().cast(),v.0[i]);}a})}
 #[test]fn exact_low_filter_collisions_and_masked_one(){
  let mut groups=0usize;let mut lanes=0usize;let mut collisions=0usize;let mut seed=0x6c6f772d66696c74u64;
  for mask in 0..=255u8{for round in 0..128u64{let a=core::array::from_fn(|i|{seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;Fq::from_montgomery([seed,round+i as u64,0,0])});let b=core::array::from_fn(|i|{let mut w=a[i].0;if mask>>i&1!=0{w[1]=w[1].wrapping_add(17);}else{w[0]^=1;}Fq::from_montgomery(w)});let aa=Ifma8::<FqConfig,true>::new(&a);let bb=Ifma8::<FqConfig,true>::new(&b);assert_eq!(aa.low_limb_eq_mask(&bb),mask);for i in 0..8{if mask>>i&1!=0{assert_ne!(a[i],b[i]);collisions+=1;}}let raw_before=raw(&aa);let selected=aa.masked_one(mask);let got=selected.get();let after=raw(&selected);let one=raw(&Ifma8::<FqConfig,true>::one());for i in 0..8{assert_eq!(got[i],if mask>>i&1!=0{Fq::ONE}else{a[i]});for j in 0..5{assert_eq!(after[j][i],if mask>>i&1!=0{one[j][i]}else{raw_before[j][i]});}lanes+=1;}assert_eq!(aa.get(),a);assert_eq!(bb.get(),b);groups+=1;}}
  assert_eq!(groups,32768);assert_eq!(lanes,262144);assert_eq!(collisions,131072);println!("PACKED_FILTER_FIELD groups={groups} lanes={lanes} deliberate_collisions={collisions}");
 }
 #[test]fn masked_one_preserves_output_fed_lazy_products(){let mut values=Ifma8::<FqConfig,true>::new(&core::array::from_fn(|i|Fq::from((i+19)as u64)));let mut lanes=0;for step in 0..4096usize{let product=values.mul(&values);let before=raw(&product);let mask=(step as u8).wrapping_mul(37);let got=product.masked_one(mask);let after=raw(&got);let one=raw(&Ifma8::<FqConfig,true>::one());for i in 0..8{for j in 0..5{assert_eq!(after[j][i],if mask>>i&1!=0{one[j][i]}else{before[j][i]});}lanes+=1;}values=got;}assert_eq!(lanes,32768);println!("PACKED_FILTER_LAZY lanes={lanes}");}
}
