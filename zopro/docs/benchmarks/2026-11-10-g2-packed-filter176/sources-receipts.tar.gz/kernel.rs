use super::*;
pub(super) fn apply<C:CurveConfig<Base=Fq2>>(buckets:&mut[Affine<C>],batch:&[(u32,&Affine<C>)],s:&mut Fq2AddScratch){
 let full=batch.len()/LANES*LANES;let groups=full/LANES;
 s.classified.clear();s.classified.reserve_exact(groups+1);s.classified.resize(groups+1,0);
 s.prefix_records.clear();s.prefix_records.reserve(groups);let mut chains=FqBatch::one();
 for k in(0..full).step_by(LANES){
  let ax=fq2_pack(core::array::from_fn(|i|buckets[(batch[k+i].0&0x7fffffff)as usize].x));
  let bx=fq2_pack(core::array::from_fn(|i|batch[k+i].1.x));
  let mut candidates=ax[0].low_limb_eq_mask(&bx[0]);let mut special=0u8;
  while candidates!=0{let i=candidates.trailing_zeros()as usize;candidates&=candidates-1;let(encoded,p)=batch[k+i];let index=(encoded&0x7fffffff)as usize;let a=buckets[index];if a.x==p.x{special|=1<<i;let b=if encoded>>31!=0{-*p}else{*p};buckets[index]=(a+b).to_affine();}}
  let denominator=core::array::from_fn(|i|canonical_sub::<true>(&bx[i],&ax[i]));let mut norm=Fq2::lanes_norm(&denominator);if special!=0{norm=norm.masked_one(special);}s.classified[k/LANES]=special;s.prefix_records.push([chains,norm]);chains=chains.mul(&norm);
 }
 s.tail.clear();let mut inverse=if let Some(value)=direct_chain_inverse(&chains,full==batch.len(),s.vector_inverse){value}else{
  let mut tail=chains.get();for k in full..batch.len(){let(encoded,p)=batch[k];let index=(encoded&0x7fffffff)as usize;let b=if encoded>>31!=0{-*p}else{*p};let a=buckets[index];let special=a.x==b.x;
   let(norm,numerator)=if special{s.classified[groups]|=1<<(k-full);buckets[index]=(a+b).to_affine();(Fq::ONE,Fq2::ZERO)}else{let denominator=b.x-a.x;let norm=denominator.c0.square()+denominator.c1.square();let numerator=((b.y-a.y)*denominator.conjugate()).mul_by_fp(&tail[k%LANES]);(norm,numerator)};
   tail[k%LANES]*=norm;s.tail.push([a.x,a.y,a.x+b.x,Fq2::new(norm,Fq::ZERO),numerator]);
  }let mut inv=invert_lanes(tail,s.vector_inverse);for k in(full..batch.len()).rev(){let[ax,ay,xsum,norm,numerator]=s.tail[k-full];let slope=numerator.mul_by_fp(&inv[k%LANES]);inv[k%LANES]*=norm.c0;let x=slope.square()-xsum;let y=slope*(ax-x)-ay;if s.classified[groups]>>(k-full)&1==0{buckets[(batch[k].0&0x7fffffff)as usize]=Affine::new(x,y);}}FqBatch::new(&inv)
 };
 for j in(0..groups).rev(){let k=j*LANES;let a:[Affine<C>;LANES]=core::array::from_fn(|i|buckets[(batch[k+i].0&0x7fffffff)as usize]);let b:[&Affine<C>;LANES]=core::array::from_fn(|i|batch[k+i].1);
  let ax=fq2_pack(a.map(|p|p.x));let ay=fq2_pack(a.map(|p|p.y));let bx=fq2_pack(b.map(|p|p.x));let by=fq2_pack(b.map(|p|p.y));let negative=signs::<true,C>(&batch[k..k+LANES]);let dy=core::array::from_fn(|i|by[i].signed_difference_canonical(&ay[i],negative));let denominator=core::array::from_fn(|i|canonical_sub::<true>(&bx[i],&ax[i]));let factor=s.prefix_records[j][0].mul(&inverse);inverse=inverse.mul(&s.prefix_records[j][1]);let slope=Fq2::lanes_scaled_numerator(&dy,&denominator,&factor);let x=Fq2::lanes_sub(&Fq2::lanes_square(&slope),&Fq2::lanes_add(&ax,&bx));let y=Fq2::lanes_sub(&Fq2::lanes_mul(&slope,&Fq2::lanes_sub(&ax,&x)),&ay);let(x,y)=(fq2_unpack(x),fq2_unpack(y));
  if s.classified[j]==0{for i in 0..LANES{buckets[(batch[k+i].0&0x7fffffff)as usize]=Affine::new(x[i],y[i]);}}else{for i in 0..LANES{if s.classified[j]>>i&1==0{buckets[(batch[k+i].0&0x7fffffff)as usize]=Affine::new(x[i],y[i]);}}}
 }
}
impl<C:CurveConfig<Base=Fq2>>BatchAdd<C>{
 pub(crate) fn apply_signed_filtered_g2(&mut self,buckets:&mut[Affine<C>],batch:&[(u32,&Affine<C>)]){
  debug_assert!(self.borrowed_g2_enabled());apply::<C>(buckets,batch,&mut self.fq2);
 }
}
