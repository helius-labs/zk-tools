use super::*;use zopro_bn254::{Fr,G2Affine,G2Projective};
#[path="g2_filter_original.rs"]mod accepted;
#[test]fn complete_windows_match_original_with_identities_and_exceptions(){let g=G2Projective::generator();let mut cases=0;let mut checked=0;
 for workers in[1usize,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||{for n in[0usize,1,7,8,9,15,16,31,32,63,128,257,1025]{for mode in 0..3{
  let bases=G2Projective::batch_to_affine(&(0..n).map(|i|match mode{0=>g*Fr::from((i+12345)as u64),1=>match i%4{0=>G2Projective::IDENTITY,1=>g,2=>-g,_=>g.double()},_=>g*Fr::from((i%13+1)as u64)}).collect::<Vec<_>>());let short=(0..n).map(|i|{let lo=((i*13+17)%4093)as u64;let hi=((i*19+41)%4093)as u64;[lo,if i%3==0{1<<63}else{0},hi,if i%5==0{1<<63}else{0}]}).collect::<Vec<_>>();
  for w in[0usize,1,4,9]{let want=accepted::try_window(&bases,&short,w,12).unwrap();let got=super::try_window(&bases,&short,w,12).unwrap();assert_eq!(got,want,"n={n} mode={mode} w={w} workers={workers}");assert_eq!(got.len(),2048);checked+=got.len();cases+=1;}
 }}});}
 assert_eq!(cases,624);println!("PACKED_FILTER_WINDOWS cases={cases} original_bucket_checks={checked}");
}
