use serde_json::{json,Value};use std::fs;
fn main(){
 let root="/home/ubuntu/src/zopro-perf-work/ternary-reciprocal-caller176";
 let checkpoint=fs::read_to_string(format!("{root}/checkpoint-pre-latency.md")).unwrap();
 let handoff="/home/ubuntu/src/zopro-cpu-perf-handoff.md";let old=fs::read_to_string(handoff).unwrap();assert!(!old.starts_with(&checkpoint));fs::write(handoff,format!("{checkpoint}\n{old}")).unwrap();
 let prompt="/home/ubuntu/src/zopro-next-agent-prompt.md";let old=fs::read_to_string(prompt).unwrap();let marker="EXECUTION MANDATE FOR THE NEXT AGENT:";let start=old.find(marker).unwrap();let suffix=&old[start..];fs::write(prompt,format!("{checkpoint}\n{suffix}")).unwrap();let new=fs::read_to_string(prompt).unwrap();assert_eq!(&new[new.find(marker).unwrap()..],suffix);
 let status="/home/ubuntu/src/zopro-perf-work/latest-status.json";let mut v:Value=serde_json::from_slice(&fs::read(status).unwrap()).unwrap();
 v["commit"]="103098a6a383a5109bb75d2f52e5e90bcffa43f0".into();v["active_experiment"]="ternary-reciprocal-caller176: four-arm correctness preflights pass; fixed latency trial ready".into();v["goal_status"]="active".into();v["goal_achieved"]=false.into();v["canonical_proof_ledger_count"]=32196.into();
 v["ternary_reciprocal176"]=json!({"screen_pushed":true,"report":"zopro/docs/benchmarks/2026-11-07-ternary-reciprocal-codec176/README.md","review":"/home/ubuntu/src/zopro-perf-work/ternary-reciprocal-codec176/review.json","consumer_sha256":"28bce6f68ae92bf79acfc22161f9a59c17c6aaf34e432dd389cf26d2cceeb35a","production_unchanged":true,"preflight_processes":24,"preflight_queries":120,"first_unfinished":"launch fixed latency-plan.json once; poll returned same native handle; after terminal success run fixed diagnostic-plan.json before analysis","trial_root":root,"prelaunch_checkpoint":format!("{root}/checkpoint-pre-latency.md"),"latency_plan":format!("{root}/latency-plan.json"),"no_live_job_at_prelaunch_checkpoint":true,"latency_outcome":null,"adopted":false,"goal_shapes_met":0});
 fs::write(status,serde_json::to_vec_pretty(&v).unwrap()).unwrap();println!("Checkpoint updated; prompt mandate suffix preserved byte-exact; goal active0/8");
}
