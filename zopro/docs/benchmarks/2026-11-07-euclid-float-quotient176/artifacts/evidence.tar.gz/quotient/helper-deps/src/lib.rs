//! Build LTO-compatible reference/hash dependencies for the isolated consumer.
pub fn qualification_dependency_anchor() {}
