0000000000010f60 <probe::floating_raw>:
   10f60:	55                   	push   rbp
   10f61:	48 89 e5             	mov    rbp,rsp
   10f64:	48 83 e4 c0          	and    rsp,0xffffffffffffffc0
   10f68:	48 81 ec c0 02 00 00 	sub    rsp,0x2c0
   10f6f:	62 f1 fe 48 7a 06    	vcvtuqq2pd zmm0,ZMMWORD PTR [rsi]
   10f75:	62 f1 fe 48 7a 4e 01 	vcvtuqq2pd zmm1,ZMMWORD PTR [rsi+0x40]
   10f7c:	62 f1 fe 48 7a 56 02 	vcvtuqq2pd zmm2,ZMMWORD PTR [rsi+0x80]
   10f83:	62 f1 fe 48 7a 5e 03 	vcvtuqq2pd zmm3,ZMMWORD PTR [rsi+0xc0]
   10f8a:	62 f1 fe 48 7a 66 04 	vcvtuqq2pd zmm4,ZMMWORD PTR [rsi+0x100]
   10f91:	62 f1 fe 48 7a 32    	vcvtuqq2pd zmm6,ZMMWORD PTR [rdx]
   10f97:	62 f1 fe 48 7a 6a 04 	vcvtuqq2pd zmm5,ZMMWORD PTR [rdx+0x100]
   10f9e:	48 89 e6             	mov    rsi,rsp
   10fa1:	62 f1 7c 48 29 04 24 	vmovaps ZMMWORD PTR [rsp],zmm0
   10fa8:	62 f1 7c 48 29 4c 24 	vmovaps ZMMWORD PTR [rsp+0x40],zmm1
   10faf:	01 
   10fb0:	62 f1 7c 48 29 54 24 	vmovaps ZMMWORD PTR [rsp+0x80],zmm2
   10fb7:	02 
   10fb8:	62 f1 7c 48 29 5c 24 	vmovaps ZMMWORD PTR [rsp+0xc0],zmm3
   10fbf:	03 
   10fc0:	62 f1 fe 48 7a 4a 01 	vcvtuqq2pd zmm1,ZMMWORD PTR [rdx+0x40]
   10fc7:	62 f1 fe 48 7a 52 02 	vcvtuqq2pd zmm2,ZMMWORD PTR [rdx+0x80]
   10fce:	62 f1 fe 48 7a 5a 03 	vcvtuqq2pd zmm3,ZMMWORD PTR [rdx+0xc0]
   10fd5:	48 8d 94 24 40 01 00 	lea    rdx,[rsp+0x140]
   10fdc:	00 
   10fdd:	62 f1 7c 48 29 74 24 	vmovaps ZMMWORD PTR [rsp+0x140],zmm6
   10fe4:	05 
   10fe5:	62 f1 7c 48 29 64 24 	vmovaps ZMMWORD PTR [rsp+0x100],zmm4
   10fec:	04 
   10fed:	62 f1 7c 48 29 4c 24 	vmovaps ZMMWORD PTR [rsp+0x180],zmm1
   10ff4:	06 
   10ff5:	62 f1 7c 48 29 54 24 	vmovaps ZMMWORD PTR [rsp+0x1c0],zmm2
   10ffc:	07 
   10ffd:	62 f1 7c 48 29 5c 24 	vmovaps ZMMWORD PTR [rsp+0x200],zmm3
   11004:	08 
   11005:	62 f1 7c 48 29 6c 24 	vmovaps ZMMWORD PTR [rsp+0x240],zmm5
   1100c:	09 
   1100d:	c5 f8 77             	vzeroupper
   11010:	e8 6b 3e 00 00       	call   14e80 <probe::floating>
   11015:	48 89 ec             	mov    rsp,rbp
   11018:	5d                   	pop    rbp
   11019:	c3                   	ret
   1101a:	cc                   	int3
   1101b:	cc                   	int3
   1101c:	cc                   	int3
   1101d:	cc                   	int3
   1101e:	cc                   	int3
   1101f:	cc                   	int3

0000000000014bf0 <probe::integer>:
   14bf0:	62 71 fd 48 6f 2e    	vmovdqa64 zmm13,ZMMWORD PTR [rsi]
   14bf6:	62 71 fd 48 6f 5a 04 	vmovdqa64 zmm11,ZMMWORD PTR [rdx+0x100]
   14bfd:	62 f1 fd 48 6f 5a 03 	vmovdqa64 zmm3,ZMMWORD PTR [rdx+0xc0]
   14c04:	62 71 fd 48 6f 76 01 	vmovdqa64 zmm14,ZMMWORD PTR [rsi+0x40]
   14c0b:	62 71 fd 48 6f 12    	vmovdqa64 zmm10,ZMMWORD PTR [rdx]
   14c11:	62 f1 fd 48 6f 7a 01 	vmovdqa64 zmm7,ZMMWORD PTR [rdx+0x40]
   14c18:	62 f1 fd 48 6f 62 02 	vmovdqa64 zmm4,ZMMWORD PTR [rdx+0x80]
   14c1f:	c4 41 31 ef c9       	vpxor  xmm9,xmm9,xmm9
   14c24:	c4 41 39 ef c0       	vpxor  xmm8,xmm8,xmm8
   14c29:	62 71 fd 48 6f 7e 02 	vmovdqa64 zmm15,ZMMWORD PTR [rsi+0x80]
   14c30:	c5 e9 ef d2          	vpxor  xmm2,xmm2,xmm2
   14c34:	c5 d1 ef ed          	vpxor  xmm5,xmm5,xmm5
   14c38:	c5 c9 ef f6          	vpxor  xmm6,xmm6,xmm6
   14c3c:	c5 f1 ef c9          	vpxor  xmm1,xmm1,xmm1
   14c40:	62 71 fd 48 6f 66 03 	vmovdqa64 zmm12,ZMMWORD PTR [rsi+0xc0]
   14c47:	62 e1 fd 48 6f 46 04 	vmovdqa64 zmm16,ZMMWORD PTR [rsi+0x100]
   14c4e:	c5 f9 ef c0          	vpxor  xmm0,xmm0,xmm0
   14c52:	62 52 95 48 b5 cb    	vpmadd52huq zmm9,zmm13,zmm11
   14c58:	62 72 95 48 b5 c3    	vpmadd52huq zmm8,zmm13,zmm3
   14c5e:	62 d2 95 48 b5 d2    	vpmadd52huq zmm2,zmm13,zmm10
   14c64:	62 f2 95 48 b5 ef    	vpmadd52huq zmm5,zmm13,zmm7
   14c6a:	62 f2 95 48 b5 f4    	vpmadd52huq zmm6,zmm13,zmm4
   14c70:	62 d2 95 48 b4 ca    	vpmadd52luq zmm1,zmm13,zmm10
   14c76:	62 d2 fd 40 b5 c3    	vpmadd52huq zmm0,zmm16,zmm11
   14c7c:	62 72 8d 48 b5 cb    	vpmadd52huq zmm9,zmm14,zmm3
   14c82:	62 52 95 48 b4 c3    	vpmadd52luq zmm8,zmm13,zmm11
   14c88:	62 f2 95 48 b4 d7    	vpmadd52luq zmm2,zmm13,zmm7
   14c8e:	62 f2 95 48 b4 ec    	vpmadd52luq zmm5,zmm13,zmm4
   14c94:	62 f2 95 48 b4 f3    	vpmadd52luq zmm6,zmm13,zmm3
   14c9a:	c4 41 11 ef ed       	vpxor  xmm13,xmm13,xmm13
   14c9f:	62 52 8d 48 b5 eb    	vpmadd52huq zmm13,zmm14,zmm11
   14ca5:	62 f1 fd 48 7f 0f    	vmovdqa64 ZMMWORD PTR [rdi],zmm1
   14cab:	62 52 8d 48 b4 cb    	vpmadd52luq zmm9,zmm14,zmm11
   14cb1:	62 72 8d 48 b5 c4    	vpmadd52huq zmm8,zmm14,zmm4
   14cb7:	62 72 85 48 b5 eb    	vpmadd52huq zmm13,zmm15,zmm3
   14cbd:	62 f2 8d 48 b5 f7    	vpmadd52huq zmm6,zmm14,zmm7
   14cc3:	62 d2 8d 48 b5 ea    	vpmadd52huq zmm5,zmm14,zmm10
   14cc9:	62 d2 8d 48 b4 d2    	vpmadd52luq zmm2,zmm14,zmm10
   14ccf:	62 72 85 48 b5 cc    	vpmadd52huq zmm9,zmm15,zmm4
   14cd5:	62 72 8d 48 b4 c3    	vpmadd52luq zmm8,zmm14,zmm3
   14cdb:	62 52 85 48 b4 eb    	vpmadd52luq zmm13,zmm15,zmm11
   14ce1:	62 f2 8d 48 b4 f4    	vpmadd52luq zmm6,zmm14,zmm4
   14ce7:	62 f2 8d 48 b4 ef    	vpmadd52luq zmm5,zmm14,zmm7
   14ced:	c4 41 09 ef f6       	vpxor  xmm14,xmm14,xmm14
   14cf2:	62 52 85 48 b5 f3    	vpmadd52huq zmm14,zmm15,zmm11
   14cf8:	62 72 85 48 b4 cb    	vpmadd52luq zmm9,zmm15,zmm3
   14cfe:	62 72 85 48 b5 c7    	vpmadd52huq zmm8,zmm15,zmm7
   14d04:	62 72 9d 48 b5 ec    	vpmadd52huq zmm13,zmm12,zmm4
   14d0a:	62 d2 85 48 b5 f2    	vpmadd52huq zmm6,zmm15,zmm10
   14d10:	62 72 9d 48 b5 f3    	vpmadd52huq zmm14,zmm12,zmm3
   14d16:	62 d2 85 48 b4 ea    	vpmadd52luq zmm5,zmm15,zmm10
   14d1c:	62 72 9d 48 b5 cf    	vpmadd52huq zmm9,zmm12,zmm7
   14d22:	62 72 85 48 b4 c4    	vpmadd52luq zmm8,zmm15,zmm4
   14d28:	62 72 9d 48 b4 eb    	vpmadd52luq zmm13,zmm12,zmm3
   14d2e:	62 f2 85 48 b4 f7    	vpmadd52luq zmm6,zmm15,zmm7
   14d34:	62 52 9d 48 b4 f3    	vpmadd52luq zmm14,zmm12,zmm11
   14d3a:	c4 41 01 ef ff       	vpxor  xmm15,xmm15,xmm15
   14d3f:	62 52 9d 48 b5 fb    	vpmadd52huq zmm15,zmm12,zmm11
   14d45:	62 72 9d 48 b4 cc    	vpmadd52luq zmm9,zmm12,zmm4
   14d4b:	62 52 9d 48 b5 c2    	vpmadd52huq zmm8,zmm12,zmm10
   14d51:	62 72 fd 40 b5 ef    	vpmadd52huq zmm13,zmm16,zmm7
   14d57:	62 d2 9d 48 b4 f2    	vpmadd52luq zmm6,zmm12,zmm10
   14d5d:	62 72 fd 40 b5 f4    	vpmadd52huq zmm14,zmm16,zmm4
   14d63:	62 72 fd 40 b5 fb    	vpmadd52huq zmm15,zmm16,zmm3
   14d69:	62 52 fd 40 b5 ca    	vpmadd52huq zmm9,zmm16,zmm10
   14d6f:	62 72 9d 48 b4 c7    	vpmadd52luq zmm8,zmm12,zmm7
   14d75:	62 72 fd 40 b4 ec    	vpmadd52luq zmm13,zmm16,zmm4
   14d7b:	62 72 fd 40 b4 f3    	vpmadd52luq zmm14,zmm16,zmm3
   14d81:	62 f2 fd 48 59 1d 55 	vpbroadcastq zmm3,QWORD PTR [rip+0xfffffffffffee655]        # 33e0 <__abi_tag+0x30e4>
   14d88:	e6 fe ff 
   14d8b:	62 52 fd 40 b4 fb    	vpmadd52luq zmm15,zmm16,zmm11
   14d91:	62 72 fd 40 b4 cf    	vpmadd52luq zmm9,zmm16,zmm7
   14d97:	62 f1 c5 48 73 d2 34 	vpsrlq zmm7,zmm2,0x34
   14d9e:	62 52 fd 40 b4 c2    	vpmadd52luq zmm8,zmm16,zmm10
   14da4:	62 f1 c5 48 d4 e5    	vpaddq zmm4,zmm7,zmm5
   14daa:	62 f1 d5 48 73 d4 34 	vpsrlq zmm5,zmm4,0x34
   14db1:	62 f1 d5 48 d4 ee    	vpaddq zmm5,zmm5,zmm6
   14db7:	62 f1 cd 48 73 d5 34 	vpsrlq zmm6,zmm5,0x34
   14dbe:	62 f1 ed 48 db d3    	vpandq zmm2,zmm2,zmm3
   14dc4:	62 f1 dd 48 db e3    	vpandq zmm4,zmm4,zmm3
   14dca:	62 f1 d5 48 db eb    	vpandq zmm5,zmm5,zmm3
   14dd0:	62 d1 cd 48 d4 f0    	vpaddq zmm6,zmm6,zmm8
   14dd6:	62 f1 fd 48 7f 57 01 	vmovdqa64 ZMMWORD PTR [rdi+0x40],zmm2
   14ddd:	62 f1 fd 48 7f 67 02 	vmovdqa64 ZMMWORD PTR [rdi+0x80],zmm4
   14de4:	62 f1 fd 48 7f 6f 03 	vmovdqa64 ZMMWORD PTR [rdi+0xc0],zmm5
   14deb:	62 f1 c5 48 73 d6 34 	vpsrlq zmm7,zmm6,0x34
   14df2:	62 f1 cd 48 db f3    	vpandq zmm6,zmm6,zmm3
   14df8:	62 d1 c5 48 d4 f9    	vpaddq zmm7,zmm7,zmm9
   14dfe:	62 f1 fd 48 7f 77 04 	vmovdqa64 ZMMWORD PTR [rdi+0x100],zmm6
   14e05:	62 f1 bd 48 73 d7 34 	vpsrlq zmm8,zmm7,0x34
   14e0c:	62 f1 c5 48 db fb    	vpandq zmm7,zmm7,zmm3
   14e12:	62 51 bd 48 d4 c5    	vpaddq zmm8,zmm8,zmm13
   14e18:	62 f1 fd 48 7f 7f 05 	vmovdqa64 ZMMWORD PTR [rdi+0x140],zmm7
   14e1f:	62 d1 b5 48 73 d0 34 	vpsrlq zmm9,zmm8,0x34
   14e26:	62 71 bd 48 db c3    	vpandq zmm8,zmm8,zmm3
   14e2c:	62 51 b5 48 d4 ce    	vpaddq zmm9,zmm9,zmm14
   14e32:	62 71 fd 48 7f 47 06 	vmovdqa64 ZMMWORD PTR [rdi+0x180],zmm8
   14e39:	62 d1 ad 48 73 d1 34 	vpsrlq zmm10,zmm9,0x34
   14e40:	62 71 b5 48 db cb    	vpandq zmm9,zmm9,zmm3
   14e46:	62 51 ad 48 d4 d7    	vpaddq zmm10,zmm10,zmm15
   14e4c:	62 71 fd 48 7f 4f 07 	vmovdqa64 ZMMWORD PTR [rdi+0x1c0],zmm9
   14e53:	62 d1 a5 48 73 d2 34 	vpsrlq zmm11,zmm10,0x34
   14e5a:	62 f1 ad 48 db db    	vpandq zmm3,zmm10,zmm3
   14e60:	62 f1 a5 48 d4 c0    	vpaddq zmm0,zmm11,zmm0
   14e66:	62 f1 fd 48 7f 5f 08 	vmovdqa64 ZMMWORD PTR [rdi+0x200],zmm3
   14e6d:	62 f1 fd 48 7f 47 09 	vmovdqa64 ZMMWORD PTR [rdi+0x240],zmm0
   14e74:	c5 f8 77             	vzeroupper
   14e77:	c3                   	ret
   14e78:	cc                   	int3
   14e79:	cc                   	int3
   14e7a:	cc                   	int3
   14e7b:	cc                   	int3
   14e7c:	cc                   	int3
   14e7d:	cc                   	int3
   14e7e:	cc                   	int3
   14e7f:	cc                   	int3

0000000000014e80 <probe::floating>:
   14e80:	62 f2 fd 48 19 35 96 	vbroadcastsd zmm6,QWORD PTR [rip+0xfffffffffffee596]        # 3420 <__abi_tag+0x3124>
   14e87:	e5 fe ff 
   14e8a:	62 e1 fd 48 28 42 04 	vmovapd zmm16,ZMMWORD PTR [rdx+0x100]
   14e91:	62 71 fd 48 28 76 04 	vmovapd zmm14,ZMMWORD PTR [rsi+0x100]
   14e98:	62 72 fd 48 19 0d 86 	vbroadcastsd zmm9,QWORD PTR [rip+0xfffffffffffee586]        # 3428 <__abi_tag+0x312c>
   14e9f:	e5 fe ff 
   14ea2:	62 71 fd 48 28 6a 03 	vmovapd zmm13,ZMMWORD PTR [rdx+0xc0]
   14ea9:	62 71 fd 48 28 5e 03 	vmovapd zmm11,ZMMWORD PTR [rsi+0xc0]
   14eb0:	62 71 fd 48 28 46 02 	vmovapd zmm8,ZMMWORD PTR [rsi+0x80]
   14eb7:	62 71 fd 48 28 52 02 	vmovapd zmm10,ZMMWORD PTR [rdx+0x80]
   14ebe:	62 f1 fd 48 28 6e 01 	vmovapd zmm5,ZMMWORD PTR [rsi+0x40]
   14ec5:	62 f1 fd 48 28 62 01 	vmovapd zmm4,ZMMWORD PTR [rdx+0x40]
   14ecc:	62 f1 fd 48 28 1e    	vmovapd zmm3,ZMMWORD PTR [rsi]
   14ed2:	62 f1 fd 48 28 0a    	vmovapd zmm1,ZMMWORD PTR [rdx]
   14ed8:	62 b1 fd 48 28 c0    	vmovapd zmm0,zmm16
   14ede:	62 b1 fd 48 28 f8    	vmovapd zmm7,zmm16
   14ee4:	62 51 fd 48 28 e5    	vmovapd zmm12,zmm13
   14eea:	62 a1 fd 48 28 e8    	vmovapd zmm21,zmm16
   14ef0:	62 c1 fd 48 28 cd    	vmovapd zmm17,zmm13
   14ef6:	62 c1 fd 48 28 da    	vmovapd zmm19,zmm10
   14efc:	62 a1 fd 48 28 f8    	vmovapd zmm23,zmm16
   14f02:	62 c1 fd 48 28 e5    	vmovapd zmm20,zmm13
   14f08:	62 41 fd 48 28 d2    	vmovapd zmm26,zmm10
   14f0e:	62 f2 8d 78 a8 c6    	vfmadd213pd zmm0,zmm14,zmm6{rz-sae}
   14f14:	62 f2 a5 78 a8 fe    	vfmadd213pd zmm7,zmm11,zmm6{rz-sae}
   14f1a:	62 72 8d 78 a8 e6    	vfmadd213pd zmm12,zmm14,zmm6{rz-sae}
   14f20:	62 e2 a5 78 a8 ce    	vfmadd213pd zmm17,zmm11,zmm6{rz-sae}
   14f26:	62 e2 bd 78 a8 ee    	vfmadd213pd zmm21,zmm8,zmm6{rz-sae}
   14f2c:	62 e2 8d 78 a8 de    	vfmadd213pd zmm19,zmm14,zmm6{rz-sae}
   14f32:	62 e2 d5 78 a8 fe    	vfmadd213pd zmm23,zmm5,zmm6{rz-sae}
   14f38:	62 e2 bd 78 a8 e6    	vfmadd213pd zmm20,zmm8,zmm6{rz-sae}
   14f3e:	62 62 d5 78 a8 d6    	vfmadd213pd zmm26,zmm5,zmm6{rz-sae}
   14f44:	62 71 b5 48 5c f8    	vsubpd zmm15,zmm9,zmm0
   14f4a:	62 d1 c5 48 d4 d4    	vpaddq zmm2,zmm7,zmm12
   14f50:	62 f1 b5 48 5c ff    	vsubpd zmm7,zmm9,zmm7
   14f56:	62 51 b5 48 5c e4    	vsubpd zmm12,zmm9,zmm12
   14f5c:	62 a1 b5 48 5c f1    	vsubpd zmm22,zmm9,zmm17
   14f62:	62 a1 d5 40 d4 d1    	vpaddq zmm18,zmm21,zmm17
   14f68:	62 e1 fd 48 28 cc    	vmovapd zmm17,zmm4
   14f6e:	62 e2 8d 78 a8 ce    	vfmadd213pd zmm17,zmm14,zmm6{rz-sae}
   14f74:	62 a1 ed 40 d4 d3    	vpaddq zmm18,zmm18,zmm19
   14f7a:	62 a1 b5 48 5c db    	vsubpd zmm19,zmm9,zmm19
   14f80:	62 32 8d 78 b8 f8    	vfmadd231pd zmm15,zmm14,zmm16{rz-sae}
   14f86:	62 b2 a5 78 b8 f8    	vfmadd231pd zmm7,zmm11,zmm16{rz-sae}
   14f8c:	62 52 8d 78 b8 e5    	vfmadd231pd zmm12,zmm14,zmm13{rz-sae}
   14f92:	62 c2 a5 78 b8 f5    	vfmadd231pd zmm22,zmm11,zmm13{rz-sae}
   14f98:	62 c2 8d 78 b8 da    	vfmadd231pd zmm19,zmm14,zmm10{rz-sae}
   14f9e:	62 d1 ed 48 d4 d7    	vpaddq zmm2,zmm2,zmm15
   14fa4:	62 31 b5 48 5c fd    	vsubpd zmm15,zmm9,zmm21
   14faa:	62 c1 fd 48 28 ea    	vmovapd zmm21,zmm10
   14fb0:	62 e2 a5 78 a8 ee    	vfmadd213pd zmm21,zmm11,zmm6{rz-sae}
   14fb6:	62 f1 ed 40 d4 ff    	vpaddq zmm7,zmm18,zmm7
   14fbc:	62 a1 b5 48 5c d7    	vsubpd zmm18,zmm9,zmm23
   14fc2:	62 d1 c5 48 d4 fc    	vpaddq zmm7,zmm7,zmm12
   14fc8:	62 31 c5 40 d4 e4    	vpaddq zmm12,zmm23,zmm20
   14fce:	62 c1 fd 48 28 fa    	vmovapd zmm23,zmm10
   14fd4:	62 e2 bd 78 a8 fe    	vfmadd213pd zmm23,zmm8,zmm6{rz-sae}
   14fda:	62 32 bd 78 b8 f8    	vfmadd231pd zmm15,zmm8,zmm16{rz-sae}
   14fe0:	62 a2 d5 78 b8 d0    	vfmadd231pd zmm18,zmm5,zmm16{rz-sae}
   14fe6:	62 31 9d 48 d4 e5    	vpaddq zmm12,zmm12,zmm21
   14fec:	62 21 b5 48 5c cd    	vsubpd zmm25,zmm9,zmm21
   14ff2:	62 e1 fd 48 28 e9    	vmovapd zmm21,zmm1
   14ff8:	62 e2 8d 78 a8 ee    	vfmadd213pd zmm21,zmm14,zmm6{rz-sae}
   14ffe:	62 51 9d 48 d4 e7    	vpaddq zmm12,zmm12,zmm15
   15004:	62 31 cd 40 d4 f9    	vpaddq zmm15,zmm22,zmm17
   1500a:	62 c1 fd 48 28 f5    	vmovapd zmm22,zmm13
   15010:	62 e2 d5 78 a8 f6    	vfmadd213pd zmm22,zmm5,zmm6{rz-sae}
   15016:	62 a1 b5 48 5c c9    	vsubpd zmm17,zmm9,zmm17
   1501c:	62 42 a5 78 b8 ca    	vfmadd231pd zmm25,zmm11,zmm10{rz-sae}
   15022:	62 51 9d 48 d4 e7    	vpaddq zmm12,zmm12,zmm15
   15028:	62 31 9d 48 d4 e3    	vpaddq zmm12,zmm12,zmm19
   1502e:	62 a1 fd 48 28 d8    	vmovapd zmm19,zmm16
   15034:	62 e2 e5 78 a8 de    	vfmadd213pd zmm19,zmm3,zmm6{rz-sae}
   1503a:	62 e2 8d 78 b8 cc    	vfmadd231pd zmm17,zmm14,zmm4{rz-sae}
   15040:	62 21 e5 40 d4 c6    	vpaddq zmm24,zmm19,zmm22
   15046:	62 31 bd 40 d4 ff    	vpaddq zmm15,zmm24,zmm23
   1504c:	62 21 b5 48 5c c4    	vsubpd zmm24,zmm9,zmm20
   15052:	62 e1 fd 48 28 e4    	vmovapd zmm20,zmm4
   15058:	62 e2 a5 78 a8 e6    	vfmadd213pd zmm20,zmm11,zmm6{rz-sae}
   1505e:	62 31 85 48 d4 fa    	vpaddq zmm15,zmm15,zmm18
   15064:	62 42 bd 78 b8 c5    	vfmadd231pd zmm24,zmm8,zmm13{rz-sae}
   1506a:	62 a1 bd 40 d4 d4    	vpaddq zmm18,zmm24,zmm20
   15070:	62 21 b5 48 5c c3    	vsubpd zmm24,zmm9,zmm19
   15076:	62 a1 b5 48 5c e4    	vsubpd zmm20,zmm9,zmm20
   1507c:	62 31 85 48 d4 fa    	vpaddq zmm15,zmm15,zmm18
   15082:	62 a1 b5 40 d4 d5    	vpaddq zmm18,zmm25,zmm21
   15088:	62 21 b5 48 5c ce    	vsubpd zmm25,zmm9,zmm22
   1508e:	62 e1 fd 48 28 f4    	vmovapd zmm22,zmm4
   15094:	62 e2 bd 78 a8 f6    	vfmadd213pd zmm22,zmm8,zmm6{rz-sae}
   1509a:	62 a1 ed 40 d4 c9    	vpaddq zmm17,zmm18,zmm17
   150a0:	62 31 85 48 d4 f9    	vpaddq zmm15,zmm15,zmm17
   150a6:	62 c1 fd 48 28 cd    	vmovapd zmm17,zmm13
   150ac:	62 e2 e5 78 a8 ce    	vfmadd213pd zmm17,zmm3,zmm6{rz-sae}
   150b2:	62 22 e5 78 b8 c0    	vfmadd231pd zmm24,zmm3,zmm16{rz-sae}
   150b8:	62 e2 a5 78 b8 e4    	vfmadd231pd zmm20,zmm11,zmm4{rz-sae}
   150be:	62 81 b5 48 5c c2    	vsubpd zmm16,zmm9,zmm26
   150c4:	62 42 d5 78 b8 cd    	vfmadd231pd zmm25,zmm5,zmm13{rz-sae}
   150ca:	62 c2 d5 78 b8 c2    	vfmadd231pd zmm16,zmm5,zmm10{rz-sae}
   150d0:	62 81 f5 40 d4 da    	vpaddq zmm19,zmm17,zmm26
   150d6:	62 a1 b5 48 5c c9    	vsubpd zmm17,zmm9,zmm17
   150dc:	62 81 e5 40 d4 d0    	vpaddq zmm18,zmm19,zmm24
   150e2:	62 21 b5 48 5c c7    	vsubpd zmm24,zmm9,zmm23
   150e8:	62 e1 fd 48 28 f9    	vmovapd zmm23,zmm1
   150ee:	62 e2 a5 78 a8 fe    	vfmadd213pd zmm23,zmm11,zmm6{rz-sae}
   150f4:	62 a1 b5 40 d4 de    	vpaddq zmm19,zmm25,zmm22
   150fa:	62 a1 b5 48 5c f6    	vsubpd zmm22,zmm9,zmm22
   15100:	62 a1 ed 40 d4 d3    	vpaddq zmm18,zmm18,zmm19
   15106:	62 c2 e5 78 b8 cd    	vfmadd231pd zmm17,zmm3,zmm13{rz-sae}
   1510c:	62 71 fd 48 28 ec    	vmovapd zmm13,zmm4
   15112:	62 72 d5 78 a8 ee    	vfmadd213pd zmm13,zmm5,zmm6{rz-sae}
   15118:	62 42 bd 78 b8 c2    	vfmadd231pd zmm24,zmm8,zmm10{rz-sae}
   1511e:	62 e2 bd 78 b8 f4    	vfmadd231pd zmm22,zmm8,zmm4{rz-sae}
   15124:	62 a1 bd 40 d4 df    	vpaddq zmm19,zmm24,zmm23
   1512a:	62 61 fd 48 28 c1    	vmovapd zmm24,zmm1
   15130:	62 62 bd 78 a8 c6    	vfmadd213pd zmm24,zmm8,zmm6{rz-sae}
   15136:	62 a1 e5 40 d4 dc    	vpaddq zmm19,zmm19,zmm20
   1513c:	62 a1 b5 48 5c e5    	vsubpd zmm20,zmm9,zmm21
   15142:	62 c1 fd 48 28 ea    	vmovapd zmm21,zmm10
   15148:	62 e2 e5 78 a8 ee    	vfmadd213pd zmm21,zmm3,zmm6{rz-sae}
   1514e:	62 a1 ed 40 d4 d3    	vpaddq zmm18,zmm18,zmm19
   15154:	62 c2 f5 78 b8 e6    	vfmadd231pd zmm20,zmm1,zmm14{rz-sae}
   1515a:	62 81 fd 40 d4 c0    	vpaddq zmm16,zmm16,zmm24
   15160:	62 c1 d5 40 d4 dd    	vpaddq zmm19,zmm21,zmm13
   15166:	62 a1 b5 48 5c ed    	vsubpd zmm21,zmm9,zmm21
   1516c:	62 51 b5 48 5c ed    	vsubpd zmm13,zmm9,zmm13
   15172:	62 a1 e5 40 d4 c9    	vpaddq zmm17,zmm19,zmm17
   15178:	62 81 b5 48 5c d8    	vsubpd zmm19,zmm9,zmm24
   1517e:	62 a1 f5 40 d4 c0    	vpaddq zmm16,zmm17,zmm16
   15184:	62 31 ed 40 d4 f4    	vpaddq zmm14,zmm18,zmm20
   1518a:	62 a1 b5 48 5c e7    	vsubpd zmm20,zmm9,zmm23
   15190:	62 c2 e5 78 b8 ea    	vfmadd231pd zmm21,zmm3,zmm10{rz-sae}
   15196:	62 72 d5 78 b8 ec    	vfmadd231pd zmm13,zmm5,zmm4{rz-sae}
   1519c:	62 c2 f5 78 b8 d8    	vfmadd231pd zmm19,zmm1,zmm8{rz-sae}
   151a2:	62 c2 f5 78 b8 e3    	vfmadd231pd zmm20,zmm1,zmm11{rz-sae}
   151a8:	62 31 95 48 d4 c3    	vpaddq zmm8,zmm13,zmm19
   151ae:	62 31 cd 40 d4 dc    	vpaddq zmm11,zmm22,zmm20
   151b4:	62 e1 fd 48 28 e1    	vmovapd zmm20,zmm1
   151ba:	62 e2 d5 78 a8 e6    	vfmadd213pd zmm20,zmm5,zmm6{rz-sae}
   151c0:	62 51 fd 40 d4 db    	vpaddq zmm11,zmm16,zmm11
   151c6:	62 e1 fd 48 28 c4    	vmovapd zmm16,zmm4
   151cc:	62 e2 e5 78 a8 c6    	vfmadd213pd zmm16,zmm3,zmm6{rz-sae}
   151d2:	62 f2 e5 78 b8 f1    	vfmadd231pd zmm6,zmm3,zmm1{rz-sae}
   151d8:	62 31 b5 48 5c d4    	vsubpd zmm10,zmm9,zmm20
   151de:	62 a1 fd 40 d4 d4    	vpaddq zmm18,zmm16,zmm20
   151e4:	62 a1 b5 48 5c c0    	vsubpd zmm16,zmm9,zmm16
   151ea:	62 a1 ed 40 d4 cd    	vpaddq zmm17,zmm18,zmm21
   151f0:	62 72 f5 78 b8 d5    	vfmadd231pd zmm10,zmm1,zmm5{rz-sae}
   151f6:	62 f1 b5 48 5c ee    	vsubpd zmm5,zmm9,zmm6
   151fc:	62 51 f5 40 d4 c0    	vpaddq zmm8,zmm17,zmm8
   15202:	62 e2 e5 78 b8 c4    	vfmadd231pd zmm16,zmm3,zmm4{rz-sae}
   15208:	62 f2 e5 78 b8 e9    	vfmadd231pd zmm5,zmm3,zmm1{rz-sae}
   1520e:	62 f1 d5 58 d4 0d 88 	vpaddq zmm1,zmm5,QWORD BCST [rip+0xfffffffffffee288]        # 34a0 <__abi_tag+0x31a4>
   15215:	e2 fe ff 
   15218:	62 b1 cd 48 d4 e0    	vpaddq zmm4,zmm6,zmm16
   1521e:	62 d1 dd 48 d4 e2    	vpaddq zmm4,zmm4,zmm10
   15224:	62 f1 f5 48 73 d1 34 	vpsrlq zmm1,zmm1,0x34
   1522b:	62 f1 dd 48 d4 c9    	vpaddq zmm1,zmm4,zmm1
   15231:	62 f1 f5 58 d4 0d 6d 	vpaddq zmm1,zmm1,QWORD BCST [rip+0xfffffffffffee26d]        # 34a8 <__abi_tag+0x31ac>
   15238:	e2 fe ff 
   1523b:	62 f1 e5 48 73 d1 34 	vpsrlq zmm3,zmm1,0x34
   15242:	62 f1 bd 48 d4 db    	vpaddq zmm3,zmm8,zmm3
   15248:	62 f1 e5 58 d4 1d a6 	vpaddq zmm3,zmm3,QWORD BCST [rip+0xfffffffffffee1a6]        # 33f8 <__abi_tag+0x30fc>
   1524f:	e1 fe ff 
   15252:	62 f1 dd 48 73 d3 34 	vpsrlq zmm4,zmm3,0x34
   15259:	62 f1 a5 48 d4 e4    	vpaddq zmm4,zmm11,zmm4
   1525f:	62 f1 dd 58 d4 25 f7 	vpaddq zmm4,zmm4,QWORD BCST [rip+0xfffffffffffee1f7]        # 3460 <__abi_tag+0x3164>
   15266:	e1 fe ff 
   15269:	62 72 fd 48 59 1d 6d 	vpbroadcastq zmm11,QWORD PTR [rip+0xfffffffffffee16d]        # 33e0 <__abi_tag+0x30e4>
   15270:	e1 fe ff 
   15273:	62 f1 cd 48 73 d4 34 	vpsrlq zmm6,zmm4,0x34
   1527a:	62 d1 d5 48 db eb    	vpandq zmm5,zmm5,zmm11
   15280:	62 d1 f5 48 db cb    	vpandq zmm1,zmm1,zmm11
   15286:	62 d1 e5 48 db db    	vpandq zmm3,zmm3,zmm11
   1528c:	62 d1 dd 48 db e3    	vpandq zmm4,zmm4,zmm11
   15292:	62 f1 8d 48 d4 f6    	vpaddq zmm6,zmm14,zmm6
   15298:	62 f1 cd 58 d4 35 76 	vpaddq zmm6,zmm6,QWORD BCST [rip+0xfffffffffffee176]        # 3418 <__abi_tag+0x311c>
   1529f:	e1 fe ff 
   152a2:	62 f1 fd 48 7f 2f    	vmovdqa64 ZMMWORD PTR [rdi],zmm5
   152a8:	62 f1 fd 48 7f 4f 01 	vmovdqa64 ZMMWORD PTR [rdi+0x40],zmm1
   152af:	62 f1 fd 48 7f 5f 02 	vmovdqa64 ZMMWORD PTR [rdi+0x80],zmm3
   152b6:	62 f1 fd 48 7f 67 03 	vmovdqa64 ZMMWORD PTR [rdi+0xc0],zmm4
   152bd:	62 f1 bd 48 73 d6 34 	vpsrlq zmm8,zmm6,0x34
   152c4:	62 d1 cd 48 db f3    	vpandq zmm6,zmm6,zmm11
   152ca:	62 51 85 48 d4 c0    	vpaddq zmm8,zmm15,zmm8
   152d0:	62 71 bd 58 d4 05 ae 	vpaddq zmm8,zmm8,QWORD BCST [rip+0xfffffffffffee1ae]        # 3488 <__abi_tag+0x318c>
   152d7:	e1 fe ff 
   152da:	62 f1 fd 48 7f 77 04 	vmovdqa64 ZMMWORD PTR [rdi+0x100],zmm6
   152e1:	62 d1 b5 48 73 d0 34 	vpsrlq zmm9,zmm8,0x34
   152e8:	62 51 bd 48 db c3    	vpandq zmm8,zmm8,zmm11
   152ee:	62 51 9d 48 d4 c9    	vpaddq zmm9,zmm12,zmm9
   152f4:	62 71 b5 58 d4 0d 42 	vpaddq zmm9,zmm9,QWORD BCST [rip+0xfffffffffffee142]        # 3440 <__abi_tag+0x3144>
   152fb:	e1 fe ff 
   152fe:	62 71 fd 48 7f 47 05 	vmovdqa64 ZMMWORD PTR [rdi+0x140],zmm8
   15305:	62 d1 ad 48 73 d1 34 	vpsrlq zmm10,zmm9,0x34
   1530c:	62 51 b5 48 db cb    	vpandq zmm9,zmm9,zmm11
   15312:	62 d1 c5 48 d4 fa    	vpaddq zmm7,zmm7,zmm10
   15318:	62 f1 c5 58 d4 3d 2e 	vpaddq zmm7,zmm7,QWORD BCST [rip+0xfffffffffffee12e]        # 3450 <__abi_tag+0x3154>
   1531f:	e1 fe ff 
   15322:	62 71 fd 48 7f 4f 06 	vmovdqa64 ZMMWORD PTR [rdi+0x180],zmm9
   15329:	62 f1 ad 48 73 d7 34 	vpsrlq zmm10,zmm7,0x34
   15330:	62 d1 c5 48 db fb    	vpandq zmm7,zmm7,zmm11
   15336:	62 d1 ed 48 d4 d2    	vpaddq zmm2,zmm2,zmm10
   1533c:	62 f1 ed 58 d4 15 52 	vpaddq zmm2,zmm2,QWORD BCST [rip+0xfffffffffffee152]        # 3498 <__abi_tag+0x319c>
   15343:	e1 fe ff 
   15346:	62 f1 fd 48 7f 7f 07 	vmovdqa64 ZMMWORD PTR [rdi+0x1c0],zmm7
   1534d:	62 f1 ad 48 73 d2 34 	vpsrlq zmm10,zmm2,0x34
   15354:	62 d1 ed 48 db d3    	vpandq zmm2,zmm2,zmm11
   1535a:	62 d1 fd 48 d4 c2    	vpaddq zmm0,zmm0,zmm10
   15360:	62 f1 fd 58 d4 05 16 	vpaddq zmm0,zmm0,QWORD BCST [rip+0xfffffffffffee116]        # 3480 <__abi_tag+0x3184>
   15367:	e1 fe ff 
   1536a:	62 f1 fd 48 7f 57 08 	vmovdqa64 ZMMWORD PTR [rdi+0x200],zmm2
   15371:	62 f1 fd 48 7f 47 09 	vmovdqa64 ZMMWORD PTR [rdi+0x240],zmm0
   15378:	c5 f8 77             	vzeroupper
   1537b:	c3                   	ret
   1537c:	cc                   	int3
   1537d:	cc                   	int3
   1537e:	cc                   	int3
   1537f:	cc                   	int3

