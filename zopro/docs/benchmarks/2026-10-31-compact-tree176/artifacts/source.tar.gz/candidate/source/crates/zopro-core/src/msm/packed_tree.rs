//! Bounded complete unweighted tree. Native coordinates persist across levels.
use super::*;
use zopro_bn254::{G1Config,G2Config};
trait PackedBase:BatchInverse {
    type Stored:Copy;
    fn adjacent(a:&Self::Lanes,b:&Self::Lanes)->(Self::Lanes,Self::Lanes);
    fn store_native(a:&Self::Lanes)->Self::Stored;
    fn load_native(a:&Self::Stored)->Self::Lanes;
    fn adjacent_native(a:&Self::Stored,b:&Self::Stored)->(Self::Lanes,Self::Lanes);
    fn copy_lane(dst:&Self::Stored,src:&Self::Stored,from:usize,to:usize)->Self::Stored;
    fn stored_zero()->Self::Stored;
}
impl PackedBase for Fq {
    type Stored=zopro_bn254::ifma8::PackedIfma8<zopro_bn254::FqConfig,true>;
    fn store_native(a:&FqBatch)->Self::Stored{a.tree_compact()}
    fn load_native(a:&Self::Stored)->FqBatch{FqBatch::tree_expand(a)}
    fn adjacent_native(a:&Self::Stored,b:&Self::Stored)->(FqBatch,FqBatch){FqBatch::tree_adjacent_compact(a,b)}
    fn copy_lane(dst:&Self::Stored,src:&Self::Stored,from:usize,to:usize)->Self::Stored{FqBatch::tree_copy_compact_lane(dst,src,from,to)}
    fn stored_zero()->Self::Stored{FqBatch::zero().tree_compact()}
    fn adjacent(a:&FqBatch,b:&FqBatch)->(FqBatch,FqBatch){
        #[cfg(zopro_packed_tree)]{FqBatch::tree_adjacent(a,b)}
        #[cfg(not(zopro_packed_tree))]{let x=a.get();let y=b.get();let all=[x,y].concat();(FqBatch::new(&core::array::from_fn(|i|all[i*2])),FqBatch::new(&core::array::from_fn(|i|all[i*2+1])))}
    }
}
impl PackedBase for Fq2 {
    type Stored=[<Fq as PackedBase>::Stored;2];
    fn store_native(a:&[FqBatch;2])->Self::Stored{[Fq::store_native(&a[0]),Fq::store_native(&a[1])]}
    fn load_native(a:&Self::Stored)->[FqBatch;2]{[Fq::load_native(&a[0]),Fq::load_native(&a[1])]}
    fn adjacent_native(a:&Self::Stored,b:&Self::Stored)->([FqBatch;2],[FqBatch;2]){let(x0,y0)=Fq::adjacent_native(&a[0],&b[0]);let(x1,y1)=Fq::adjacent_native(&a[1],&b[1]);([x0,x1],[y0,y1])}
    fn copy_lane(dst:&Self::Stored,src:&Self::Stored,from:usize,to:usize)->Self::Stored{[Fq::copy_lane(&dst[0],&src[0],from,to),Fq::copy_lane(&dst[1],&src[1],from,to)]}
    fn stored_zero()->Self::Stored{[Fq::stored_zero(),Fq::stored_zero()]}
    fn adjacent(a:&[FqBatch;2],b:&[FqBatch;2])->([FqBatch;2],[FqBatch;2]){let(x0,y0)=Fq::adjacent(&a[0],&b[0]);let(x1,y1)=Fq::adjacent(&a[1],&b[1]);([x0,x1],[y0,y1])}
}
#[derive(Clone,Copy)]struct Point<F:PackedBase>{x:F::Stored,y:F::Stored}
struct Work<C:CurveConfig>where C::Base:PackedBase {
    a:Vec<Point<C::Base>>,prefix:Vec<[FqBatch;2]>,
    original:Vec<LimbPoint<C::Base>>,scratch:Scratch<C>, fallback:usize,
}
impl<C:CurveConfig>Default for Work<C>where C::Base:PackedBase {
    fn default()->Self{Self{a:vec![],prefix:vec![],original:vec![],scratch:Scratch{vector_inverse:true,..Default::default()},fallback:0}}
}
impl<C:CurveConfig>Work<C>where C::Base:PackedBase {
    fn original(&mut self,input:&[Affine<C>])->Affine<C>{
        self.original.clear();self.original.extend(input.iter().copied().map(limbs::<C>));
        let mut count=[input.len()];while count[0]>1{reduce_layer(&mut self.original,&[0],&mut count,&mut self.scratch);}
        self.original.first().copied().map(affine::<C>).unwrap_or(Affine::<C>::IDENTITY)
    }
    fn run(&mut self,input:&[Affine<C>],on:bool)->Affine<C>{
        #[cfg(zopro_packed_tree)]if on{if let Some(p)=self.packed(input){return p;}
            // Release private packed buffers before allocating the complete
            // fallback. No second family of large buffers is retained.
            self.a=Vec::new();self.prefix=Vec::new();self.fallback+=1;}
        let _=on;self.original(input)
    }
    #[cfg(zopro_packed_tree)]
    fn packed(&mut self,input:&[Affine<C>])->Option<Affine<C>>{
        type F<C>=<C as CurveConfig>::Base;
        if input.len()<=8{return None;}
        // A previous complete fallback cannot remain resident alongside a
        // new packed tree. The eight-point tail needs at most four pairs.
        self.original=Vec::new();self.scratch.groups=Vec::new();self.scratch.prefix_records=Vec::new();
        if self.scratch.pairs.capacity()>4{self.scratch.pairs=Vec::new();}
        self.a.clear();self.a.reserve_exact(input.len().div_ceil(8));
        for group in input.chunks(8){if group.iter().any(|p|p.is_identity()){return None;}
            let raw:[LimbPoint<C::Base>;8]=core::array::from_fn(|i|group.get(i).copied().map(limbs::<C>).unwrap_or_else(LimbPoint::infinity));
            self.a.push(Point{x:F::<C>::store_native(&F::<C>::load(core::array::from_fn(|i|&raw[i].x))),y:F::<C>::store_native(&F::<C>::load(core::array::from_fn(|i|&raw[i].y)))});
        }
        let mut live=input.len();let zero=Point{x:F::<C>::stored_zero(),y:F::<C>::stored_zero()};
        self.prefix.clear();self.prefix.reserve_exact((live/2).div_ceil(8));
        while live>8 {
            let pairs=live/2;let groups=pairs.div_ceil(8);
            let carry=if live%2!=0{Some((self.a[(live-1)/8],(live-1)%8))}else{None};
            self.prefix.clear();let mut chains=FqBatch::one();
            for j in 0..groups{let a=self.a[2*j];let b=self.a.get(2*j+1).copied().unwrap_or(zero);let(ax,bx)=F::<C>::adjacent_native(&a.x,&b.x);let dx=F::<C>::lanes_sub(&bx,&ax);let norm=F::<C>::lanes_norm(&dx);
                let active=((1u16<<((pairs-j*8).min(8)))-1)as u8;
                if norm.tree_zero_mask()&active!=0{return None;}
                // Padding lanes contribute one to the product, never zero.
                let norm=norm.tree_active_norm(active);
                self.prefix.push([chains,norm]);chains=chains.mul(&norm);
            }
            let mut inverse=chains.inverse_nonzero();
            for j in(0..groups).rev(){
                let factor=self.prefix[j][0].mul(&inverse);inverse=inverse.mul(&self.prefix[j][1]);
                self.prefix[j][0]=factor;
            }
            // All factors are ready before any coordinate is overwritten.
            // Output j precedes every future source pair 2k,2k+1 (k>j).
            for j in 0..groups{let a=self.a[2*j];let b=self.a.get(2*j+1).copied().unwrap_or(zero);
                let(ax,bx)=F::<C>::adjacent_native(&a.x,&b.x);let(ay,by)=F::<C>::adjacent_native(&a.y,&b.y);let dx=F::<C>::lanes_sub(&bx,&ax);let factor=self.prefix[j][0];
                let slope=F::<C>::lanes_scaled_numerator(&F::<C>::lanes_sub(&by,&ay),&dx,&factor);
                let x=F::<C>::lanes_sub(&F::<C>::lanes_square(&slope),&F::<C>::lanes_add(&ax,&bx));
                let y=F::<C>::lanes_sub(&F::<C>::lanes_mul(&slope,&F::<C>::lanes_sub(&ax,&x)),&ay);self.a[j]=Point{x:F::<C>::store_native(&x),y:F::<C>::store_native(&y)};
            }
            live=live.div_ceil(2);
            if let Some((src,from))=carry{let j=(live-1)/8;let to=(live-1)%8;let dst=self.a[j];self.a[j]=Point{x:F::<C>::copy_lane(&dst.x,&src.x,from,to),y:F::<C>::copy_lane(&dst.y,&src.y,from,to)};}
            self.a.truncate(live.div_ceil(8));
        }
        let p=self.a[0];let x=F::<C>::store(&F::<C>::load_native(&p.x));let y=F::<C>::store(&F::<C>::load_native(&p.y));
        let mut tail:[LimbPoint<C::Base>;8]=core::array::from_fn(|i|LimbPoint{x:x[i],y:y[i]});let mut count=[live];
        while count[0]>1{reduce_layer(&mut tail,&[0],&mut count,&mut self.scratch);}Some(affine::<C>(tail[0]))
    }
    fn capacity(&self)->usize{self.a.capacity()*core::mem::size_of::<Point<C::Base>>()+self.prefix.capacity()*core::mem::size_of::<[FqBatch;2]>()+self.original.capacity()*core::mem::size_of::<LimbPoint<C::Base>>()+self.scratch.groups.capacity()*core::mem::size_of::<Group<C::Base>>()+self.scratch.prefix_records.capacity()*core::mem::size_of::<[FqBatch;2]>()+self.scratch.pairs.capacity()*core::mem::size_of::<usize>()}
}
struct Fixture<C:CurveConfig>where C::Base:PackedBase{source:Vec<Affine<C>>,last:[Affine<C>;2],work:Work<C>,n:usize,seed:u64}
impl<C:CurveConfig>Fixture<C>where C::Base:PackedBase{
fn new(n:usize,seed:u64)->Self{let g=Projective::<C>::generator();let source=Projective::<C>::batch_to_affine(&(0..n+1).map(|i|g*Fr::from(seed*1000003+i as u64+1)).collect::<Vec<_>>());Self{source,last:[Affine::IDENTITY;2],work:Work::default(),n,seed}}
fn run(&mut self,rounds:usize,on:bool){for i in 0..rounds{let k=i%2;self.last[k]=std::hint::black_box(self.work.run(std::hint::black_box(&self.source[k..k+self.n]),on));}}
fn check(&self){for k in 0..2{let sum=(0..self.n).fold(Fr::ZERO,|v,i|v+Fr::from(self.seed*1000003+i as u64+k as u64+1));assert_eq!(self.last[k],(Projective::<C>::generator()*sum).to_affine());}}
}
pub struct CallerG1(Fixture<G1Config>);pub struct CallerG2(Fixture<G2Config>);
macro_rules! caller{($t:ident)=>{impl $t{pub fn new(n:usize,seed:u64)->Self{Self(Fixture::new(n,seed))}pub fn run(&mut self,n:usize,on:bool){self.0.run(n,on)}pub fn check(&self){self.0.check()}pub fn capacity_bytes(&self)->usize{self.0.work.capacity()}pub fn fallback_count(&self)->usize{self.0.work.fallback}pub fn digest(&self)->String{format!("{:?}",self.0.last)}}};}
caller!(CallerG1);caller!(CallerG2);
#[cfg(test)]mod tests{
use super::*;
fn check<C:CurveConfig>()where C::Base:PackedBase{
let g=Projective::<C>::generator();for n in[0usize,1,7,8,9,15,16,17,31,32,33,63,64,127,128,255,256,1023,1024,1025,2048,2049]{for family in 0..5{let mut p=Projective::<C>::batch_to_affine(&(0..n).map(|i|g*Fr::from(i as u64+73)).collect::<Vec<_>>());if n>=2{match family{1=>p[n/2]=Affine::IDENTITY,2=>p[1]=p[0],3=>p[1]=-p[0],4=>{p[1]=-p[0];if n>=4{p[3]=-p[2];}},_=>{}}}let sum=p.iter().fold(Projective::<C>::IDENTITY,|s,p|s+*p).to_affine();let before=p.clone();for on in[false,true]{let mut w=Work::<C>::default();for _ in 0..3{assert_eq!(w.run(&p,on),sum,"n{n} family{family} on{on}");}assert_eq!(p,before);}}}
}
#[test]fn complete_g1_generator_tails_exceptions_reuse(){check::<G1Config>();}
#[test]fn complete_g2_generator_tails_exceptions_reuse(){check::<G2Config>();}
#[test]fn small_stack_pools(){use rayon::prelude::*;for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||(0..workers*2).into_par_iter().for_each(|i|{let mut a=CallerG1::new(256,i as u64+1);let mut b=CallerG2::new(256,i as u64+1);for on in[false,true]{a.run(4,on);a.check();b.run(4,on);b.check();}}));}}
#[cfg(zopro_packed_tree)]#[test]fn late_fallback_releases_packed_then_normal_releases_original(){
fn check<C:CurveConfig>()where C::Base:PackedBase{let g=Projective::<C>::generator();let p=Projective::<C>::batch_to_affine(&(0..255).map(|i|g*Fr::from(i+10000)).collect::<Vec<_>>());let mut w=Work::<C>::default();let expected=p.iter().fold(Projective::<C>::IDENTITY,|s,p|s+*p).to_affine();assert_eq!(w.run(&p,true),expected);assert_eq!(w.fallback,0);let capacity=w.capacity();let mut edge=p.clone();for(i,s)in[Fr::from(3),Fr::from(5),Fr::from(11),-Fr::from(19)].into_iter().enumerate(){edge[i]=(g*s).to_affine();}let sum=edge.iter().fold(Projective::<C>::IDENTITY,|s,p|s+*p).to_affine();let original=edge.clone();assert_eq!(w.run(&edge,true),sum);assert_eq!(edge,original);assert_eq!(w.fallback,1);assert_eq!(w.a.capacity(),0);assert_eq!(w.prefix.capacity(),0);assert!(w.original.capacity()>0);for _ in 0..3{assert_eq!(w.run(&p,true),expected);assert_eq!(w.original.capacity(),0);assert_eq!(w.scratch.groups.capacity(),0);assert_eq!(w.scratch.prefix_records.capacity(),0);assert_eq!(w.capacity(),capacity);} }
check::<G1Config>();check::<G2Config>();
}
}

