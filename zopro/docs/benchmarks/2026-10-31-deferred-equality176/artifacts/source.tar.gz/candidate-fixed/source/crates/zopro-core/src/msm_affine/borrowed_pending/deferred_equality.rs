//! The original ordinary feeder with only equal-X handling deferred.
use super::*;
use zopro_bn254::{G1Affine,G1Config};
const WINDOWS:usize=21;const WIDTH:usize=12;
#[cfg(zopro_deferred_equality)]mod deferred{use super::*;
struct Window<'a, C: CurveConfig<Base = Fq>> {
    affine: Vec<Affine<C>>,
    projective: Vec<Projective<C>>,
    projective_indices: Vec<u32>,
    projective_buckets: Vec<usize>,
    busy: Vec<u64>,
    batch: Vec<(u32, &'a Affine<C>)>,
    queue: Vec<(u32, &'a Affine<C>)>,
    packed: BatchAdd<C>,
}
impl<'a, C: CurveConfig<Base = Fq>> Window<'a, C> {
    fn new(half: usize, size: usize) -> Self {
        Self {
            affine: vec![Affine::<C>::IDENTITY; half],
            projective: Vec::new(),
            projective_indices: vec![u32::MAX; half],
            projective_buckets: Vec::new(),
            busy: vec![0; half.div_ceil(64)],
            batch: Vec::with_capacity(size),
            queue: Vec::with_capacity(size),
            packed: BatchAdd::default(),
        }
    }
    #[inline(always)]
    fn busy(&self, bucket: usize) -> bool {
        self.busy[bucket / 64] >> (bucket % 64) & 1 == 1
    }
    fn projective(&mut self, bucket: usize, point: Affine<C>) {
        let index = self.projective_indices[bucket];
        if index == u32::MAX {
            self.projective_indices[bucket] = self.projective.len() as u32;
            self.projective_buckets.push(bucket);
            self.projective.push(point.to_projective());
        } else {
            self.projective[index as usize] += point;
        }
    }
    #[inline(always)]
    fn add(&mut self, encoded: u32, point: &'a Affine<C>) {
        let bucket = (encoded & 0x7fffffff) as usize;
        let negative = encoded >> 31 != 0;
        let current = &mut self.affine[bucket];
        if current.is_identity() {
            *current = if negative { -*point } else { *point };
            return;
        }
        self.busy[bucket / 64] |= 1 << (bucket % 64);
        self.batch.push((encoded, point));
    }
    fn execute(&mut self) {
        if self.batch.is_empty() {
            return;
        }
        self.packed
            .apply_deferred_equality(&mut self.affine, &self.batch);
        for (index, _) in &self.batch {
            self.busy[(index & 0x7fffffff) as usize / 64] = 0;
        }
        self.batch.clear();
    }
    fn take_from_queue(&mut self) {
        while let Some(&(encoded, point)) = self.queue.last() {
            if self.busy((encoded & 0x7fffffff) as usize) {
                return;
            }
            self.queue.pop();
            self.add(encoded, point);
        }
    }
    fn flush_queue(&mut self) {
        for i in 0..self.queue.len() {
            let (encoded, point) = self.queue[i];
            self.projective(
                (encoded & 0x7fffffff) as usize,
                if encoded >> 31 != 0 { -*point } else { *point },
            );
        }
        self.queue.clear();
    }
    fn feed(
        &mut self,
        points: &'a [Affine<C>],
        scalars: &[[u64; 4]],
        w: usize,
        bits: usize,
        size: usize,
    ) {
        for (point, scalar) in points.iter().zip(scalars) {
            let d = digit(scalar, w, bits);
            if d == 0 || point.is_identity() {
                continue;
            }
            let bucket = d.unsigned_abs() as usize - 1;
            let encoded = bucket as u32 | if d < 0 { 1 << 31 } else { 0 };
            if self.busy(bucket) {
                self.queue.push((encoded, point));
                if self.queue.len() == size - 1 {
                    self.flush_queue();
                }
                continue;
            }
            self.add(encoded, point);
            if self.batch.len() == size {
                self.execute();
                self.take_from_queue();
            }
        }
    }
    fn finish(mut self) -> Vec<Affine<C>> {
        self.execute();
        self.flush_queue();
        let combined: Vec<_> = self
            .projective
            .iter()
            .zip(&self.projective_buckets)
            .map(|(p, &i)| *p + self.affine[i])
            .collect();
        for (p, &i) in Projective::<C>::batch_to_affine(&combined)
            .into_iter()
            .zip(&self.projective_buckets)
        {
            self.affine[i] = p;
        }
        self.affine
    }
}


pub(super) fn fill(points:&[G1Affine],words:&[[u64;4]])->Vec<Vec<G1Affine>>{let size=batch_size(WIDTH).max(32);(0..WINDOWS).into_par_iter().map(|w|{let mut state=Window::<G1Config>::new(1<<(WIDTH-1),size);state.feed(points,words,w,WIDTH,size);state.finish()}).collect()}
}
pub(crate) fn fill(points:&[G1Affine],words:&[[u64;4]],on:bool)->(Vec<Vec<G1Affine>>,bool){assert_eq!(points.len(),words.len());#[cfg(zopro_deferred_equality)]if on{return(deferred::fill(points,words),true);}let _=on;let size=batch_size(WIDTH).max(32);let buckets=(0..WINDOWS).into_par_iter().map(|w|{let mut s=super::Window::<G1Config>::new(1<<(WIDTH-1),size);s.feed(points,words,w,WIDTH,size);s.finish()}).collect();(buckets,false)}
#[cfg(all(test,zopro_deferred_equality))]mod tests{
 use super::*;use zopro_bn254::{Field,Fr,G1Projective};
 #[test]fn complete_queue_exception_windows_generator_oracle(){
  let n=769;let g=G1Affine::GENERATOR;
  // Long same-bucket runs force queued spills; repeated, opposite and identity
  // points force exceptions after both normal execution and queued additions.
  let coefficients=(0..n).map(|i|match i%11{0=>Fr::ZERO,1|2=>Fr::ONE,3=>-Fr::ONE,_=>Fr::from(i as u64+17)}).collect::<Vec<_>>();
  let points=G1Projective::batch_to_affine(&coefficients.iter().map(|c|g**c).collect::<Vec<_>>());let original=points.clone();
  let words=(0..n).map(|i|match i%5{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,3=>Fr::from(4097u64),_=>Fr::from((i%2050+1)as u64)}.to_canonical()).collect::<Vec<_>>();
  let expected=(0..WINDOWS).map(|w|{let mut sums=vec![Fr::ZERO;1<<(WIDTH-1)];for(s,c)in words.iter().zip(&coefficients){let d=digit(s,w,WIDTH);if d!=0{sums[d.unsigned_abs()as usize-1]+=if d<0{-*c}else{*c};}}G1Projective::batch_to_affine(&sums.into_iter().map(|c|g*c).collect::<Vec<_>>())}).collect::<Vec<_>>();
  for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();for on in[false,true,false,true]{let(actual,entered)=pool.install(||fill(&points,&words,on));assert_eq!(entered,on);assert_eq!(actual,expected);assert_eq!(points,original);}}
 }
}
