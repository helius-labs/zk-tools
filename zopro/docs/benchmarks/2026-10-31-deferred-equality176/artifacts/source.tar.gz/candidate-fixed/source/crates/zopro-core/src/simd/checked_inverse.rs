//! Fallible version of the accepted eight-chain inverse.
use super::*;
impl FqBatch {
    #[inline]
    pub(crate) fn inverse_checked(&self) -> Option<Self> {
        use zopro_bn254::ifma8::Ifma8;
        let swapped = Self(Ifma8::shuffle_pair::<1, 0, 3, 2>(&self.0, &self.0));
        let pairs = self.mul(&swapped);
        let other_pair = Self(Ifma8::shuffle_pair::<2, 3, 0, 1>(&pairs.0, &pairs.0));
        let quads = pairs.mul(&other_pair);
        let products = quads.get();
        let inverse = (products[0] * products[4]).inverse()?;
        let (lo, hi) = quads.0.halves();
        let other_quad = Self(Ifma8::from_halves(&hi, &lo));
        Some(Self::new(&[inverse; 8])
            .mul(&other_quad)
            .mul(&other_pair)
            .mul(&swapped))
    }
}
