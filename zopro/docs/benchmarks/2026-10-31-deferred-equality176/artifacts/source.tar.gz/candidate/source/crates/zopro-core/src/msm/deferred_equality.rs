//! Deferred equal-X exception detection before all destination writes.
use super::*;
fn complete<C:CurveConfig<Base=Fq>,const SIGNED:bool>(buckets:&mut[Affine<C>],batch:&[(u32,impl std::borrow::Borrow<Affine<C>>+Copy)]){for &(id,p) in batch{let p=*p.borrow();let p=if SIGNED&&id>>31!=0{-p}else{p};let i=batch_index::<SIGNED>(id);buckets[i]=(buckets[i]+p).to_affine();}}
fn invert_checked(c: [Fq; LANES], vector_inverse: bool) -> Option<[Fq; LANES]> {
    #[cfg(all(
        feature = "ifma8",
        target_arch = "x86_64",
        target_feature = "avx512ifma",
        target_feature = "avx512vl",
        target_feature = "avx512dq",
        not(no_ifma)
    ))]
    if vector_inverse {
        return Some(FqBatch::new(&c).inverse_checked()?.get());
    }
    let _ = vector_inverse;
    let mut prefixes = [Fq::ONE; LANES];
    let mut product = Fq::ONE;
    for i in 0..LANES {
        prefixes[i] = product;
        product *= c[i];
    }
    let mut inverse = product.inverse()?;
    let mut result = [Fq::ZERO; LANES];
    for i in (0..LANES).rev() {
        result[i] = inverse * prefixes[i];
        inverse *= c[i];
    }
    Some(result)
}

fn stream_checked<C: CurveConfig<Base = Fq>, const FAST: bool, const SIGNED: bool>(
    buckets: &mut [Affine<C>],
    batch: &[(u32, impl std::borrow::Borrow<Affine<C>> + Copy)],
    s: &mut FqAddScratch,
) -> bool {
    let full = batch.len() / LANES * LANES;
    let mut chains = FqBatch::one();
    s.groups.clear();
    if s.write_groups {
        // Reserve all records before taking any pointers. Each record is
        // Copy and its length is published only after all five fields are
        // initialized. A panic before then leaves no partial record in len.
        s.groups.reserve(full / LANES);
        for k in (0..full).step_by(LANES) {
            let a: [Affine<C>; LANES] = core::array::from_fn(|i| buckets[batch_index::<SIGNED>(batch[k + i].0)]);
            let b: [Affine<C>; LANES] = core::array::from_fn(|i| *batch[k + i].1.borrow());
            // SAFETY: reserve covers full/LANES records, k/LANES is in
            // that range, and no allocation changes during these writes.
            // addr_of_mut! creates no reference to uninitialized storage.
            unsafe {
                let slot = s.groups.as_mut_ptr().add(k / LANES);
                let ax = FqBatch::new(&a.map(|p| p.x));
                core::ptr::addr_of_mut!((*slot).ax).write(ax);
                let bx = FqBatch::new(&b.map(|p| p.x));
                let denominator = canonical_sub::<FAST>(&bx, &ax);
                core::ptr::addr_of_mut!((*slot).xsum).write(canonical_add::<FAST>(&ax, &bx));
                core::ptr::addr_of_mut!((*slot).denominator).write(denominator);
                let ay = FqBatch::new(&a.map(|p| p.y));
                core::ptr::addr_of_mut!((*slot).ay).write(ay);
                let by = FqBatch::new(&b.map(|p| p.y));
                let numerator = scaled_signed_dy::<FAST,SIGNED>(&by,&ay,&chains,signs::<SIGNED,C>(&batch[k..k+LANES]));
                core::ptr::addr_of_mut!((*slot).numerator).write(numerator);
                chains = chains.mul(&denominator);
                // All five fields of this record are now initialized.
                s.groups.set_len(k / LANES + 1);
            }
        }
    } else {
        if s.reserve_groups {
            s.groups.reserve(full / LANES);
        }
        for k in (0..full).step_by(LANES) {
            let a: [Affine<C>; LANES] = core::array::from_fn(|i| buckets[batch_index::<SIGNED>(batch[k + i].0)]);
            let b: [Affine<C>; LANES] = core::array::from_fn(|i| *batch[k + i].1.borrow());
            let ax = FqBatch::new(&a.map(|p| p.x));
            let ay = FqBatch::new(&a.map(|p| p.y));
            let bx = FqBatch::new(&b.map(|p| p.x));
            let by = FqBatch::new(&b.map(|p| p.y));
            // Host coordinates are canonical; only the resulting differences are lazy.
            let denominator = canonical_sub::<FAST>(&bx, &ax);
            let numerator = scaled_signed_dy::<FAST,SIGNED>(&by,&ay,&chains,signs::<SIGNED,C>(&batch[k..k+LANES]));
            chains = chains.mul(&denominator);
            s.groups.push(FqAddGroup {
                ax,
                ay,
                xsum: canonical_add::<FAST>(&ax, &bx),
                denominator,
                numerator,
            });
        }
    }
    s.tail.clear();
    let mut inverse = if full==batch.len() && s.vector_inverse {
        let Some(value)=chains.inverse_checked() else {complete::<C,SIGNED>(buckets,batch);return false;};
        value
    } else {
        let mut tail = chains.get();
        for k in full..batch.len() {
            let (index, b) = batch[k];
            let b = *b.borrow();
            let b = if SIGNED && index>>31!=0 {-b}else{b};
            let a = buckets[batch_index::<SIGNED>(index)];
            let denominator = b.x - a.x;
            let numerator = (b.y - a.y) * tail[k % LANES];
            tail[k % LANES] *= denominator;
            s.tail.push([a.x, a.y, a.x + b.x, denominator, numerator]);
        }
        let Some(mut inverse) = invert_checked(tail, s.vector_inverse) else {complete::<C,SIGNED>(buckets,batch);return false;};
        for k in (full..batch.len()).rev() {
            let [ax, ay, xsum, denominator, numerator] = s.tail[k - full];
            let slope = numerator * inverse[k % LANES];
            inverse[k % LANES] *= denominator;
            let x = slope.square() - xsum;
            let y = slope * (ax - x) - ay;
            buckets[batch_index::<SIGNED>(batch[k].0)] = Affine::new(x, y);
        }
        FqBatch::new(&inverse)
    };
    for (j, g) in s.groups.iter().enumerate().rev() {
        let slope = g.numerator.mul(&inverse);
        inverse = inverse.mul(&g.denominator);
        let x = slope.mul(&slope).sub(&g.xsum);
        let y = slope.mul(&g.ax.sub(&x)).sub(&g.ay);
        let (x, y) = (x.get(), y.get());
        for i in 0..LANES {
            buckets[batch_index::<SIGNED>(batch[j * LANES + i].0)] = Affine::new(x[i], y[i]);
        }
    }
    true
}

impl<C:CurveConfig<Base=Fq>> BatchAdd<C>{pub(crate) fn apply_deferred_equality(&mut self,buckets:&mut[Affine<C>],batch:&[(u32,&Affine<C>)])->bool{if self.fq.canonical&&self.fq.vector_inverse{stream_checked::<C,true,true>(buckets,batch,&mut self.fq)}else{complete::<C,true>(buckets,batch);false}}
#[cfg(test)]mod tests{
 use super::*;use zopro_bn254::{G1Config,G1Affine,G1Projective,Fr};
 #[test]fn checked_product_inverse_all_zero_masks(){
  for mask in 0..256 {let a=core::array::from_fn(|i|if mask>>i&1!=0{Fq::ZERO}else{Fq::from(i as u64+2)});let value=FqBatch::new(&a);let checked=value.inverse_checked();if mask!=0{assert!(checked.is_none());}else{assert_eq!(checked.unwrap().get(),core::array::from_fn(|i|a[i].inverse().unwrap()));assert_eq!(value.inverse_checked().unwrap().get(),value.inverse_nonzero().get());}}
 }
 #[test]fn signed_complete_batches_and_each_exception_position(){
  let g=G1Affine::GENERATOR;let mut cases=vec![(0usize,None),(1,None),(7,None),(8,None),(9,None),(15,None),(16,None),(31,None),(32,None),(33,None),(199,None),(200,None),(201,None),(351,None),(352,None),(511,None)];cases.extend((0..33).map(|i|(33,Some(i))));
  for(n,exception)in cases {let initial_co=(0..n).map(|i|Fr::from(i as u64+12345)).collect::<Vec<_>>();let initial=G1Projective::batch_to_affine(&initial_co.iter().map(|c|g**c).collect::<Vec<_>>());let mut in_co=(0..n).map(|i|Fr::from(i as u64+900001)).collect::<Vec<_>>();if let Some(i)=exception{in_co[i]=initial_co[i];}let incoming=G1Projective::batch_to_affine(&in_co.iter().map(|c|g**c).collect::<Vec<_>>());let original=incoming.clone();
   for sign in 0..3 {let negative=|i:usize|sign==1||sign==2&&i%3==0;let batch=incoming.iter().enumerate().map(|(i,p)|(i as u32|if negative(i){1<<31}else{0},p)).collect::<Vec<_>>();let expected=G1Projective::batch_to_affine(&(0..n).map(|i|g*(initial_co[i]+if negative(i){-in_co[i]}else{in_co[i]})).collect::<Vec<_>>());let mut actual=initial.clone();let mut s=FqAddScratch{canonical:true,vector_inverse:true,..Default::default()};let ordinary=stream_checked::<G1Config,true,true>(&mut actual,&batch,&mut s);assert_eq!(ordinary,exception.is_none(),"n={n} exception={exception:?}");assert_eq!(actual,expected);assert_eq!(incoming,original);}
  }
 }
}
