use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/deferred-equality176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn hash(b: &[u8]) -> String { format!("{:x}", Sha256::digest(b)) }
fn replace(text: &mut String, from: &str, to: &str) {
    assert_eq!(text.matches(from).count(), 1, "ambiguous replacement: {from}");
    *text = text.replacen(from, to, 1);
}
fn main() {
    let manifest: Value = serde_json::from_slice(&fs::read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json")).unwrap()).unwrap();
    let originals = manifest["source_files_sha256"].as_object().unwrap();
    assert_eq!(originals.len(),176);
    let msm=fs::read_to_string(format!("{Z}/crates/zopro-core/src/msm.rs")).unwrap();
    let simd=fs::read_to_string(format!("{Z}/crates/zopro-core/src/simd.rs")).unwrap();
    let pending=fs::read_to_string(format!("{Z}/crates/zopro-core/src/msm_affine/borrowed_pending.rs")).unwrap();
    let mut checked=simd[simd.find("    #[inline]\n    pub(crate) fn inverse_nonzero(&self) -> Self {").unwrap()..].split("    #[inline(always)]").next().unwrap().to_owned();
    replace(&mut checked,"inverse_nonzero(&self) -> Self","inverse_checked(&self) -> Option<Self>");
    replace(&mut checked,"(products[0] * products[4]).inverse().unwrap()","(products[0] * products[4]).inverse()?");
    replace(&mut checked,"        Self::new(&[inverse; 8])","        Some(Self::new(&[inverse; 8])");
    replace(&mut checked,"            .mul(&swapped)\n","            .mul(&swapped))\n");
    let checked=format!("//! Fallible version of the accepted eight-chain inverse.\nuse super::*;\nimpl FqBatch {{\n{checked}}}\n");
    let mut stream=msm[msm.find("fn stream_g1_impl<").unwrap()..msm.find("\n#[derive(Clone, Copy)]\nstruct Fq2AddGroup").unwrap()].to_owned();
    replace(&mut stream,"fn stream_g1_impl<","fn stream_checked<");
    replace(&mut stream,"    s: &mut FqAddScratch,\n) {","    s: &mut FqAddScratch,\n) -> bool {");
    replace(&mut stream,"if let Some(value)=direct_chain_inverse(&chains,full==batch.len(),s.vector_inverse) {\n        value","if full==batch.len() && s.vector_inverse {\n        let Some(value)=chains.inverse_checked() else {complete::<C,SIGNED>(buckets,batch);return false;};\n        value");
    replace(&mut stream,"let mut inverse = invert_lanes(tail, s.vector_inverse);","let Some(mut inverse) = invert_checked(tail, s.vector_inverse) else {complete::<C,SIGNED>(buckets,batch);return false;};");
    assert!(stream.ends_with("}\n"));
    stream.truncate(stream.len()-2);stream.push_str("    true\n}\n");
    let mut invert=msm[msm.find("fn invert_lanes(").unwrap()..msm.find("\n/// Reuses the lane-form").unwrap()].to_owned();
    replace(&mut invert,"fn invert_lanes(c: [Fq; LANES], vector_inverse: bool) -> [Fq; LANES]","fn invert_checked(c: [Fq; LANES], vector_inverse: bool) -> Option<[Fq; LANES]>");
    replace(&mut invert,"return FqBatch::new(&c).inverse_nonzero().get();","return Some(FqBatch::new(&c).inverse_checked()?.get());");
    replace(&mut invert,"product.inverse().unwrap()","product.inverse()?");
    replace(&mut invert,"    result\n}","    Some(result)\n}");
    let kernel=format!("//! Deferred equal-X exception detection before all destination writes.\nuse super::*;\nfn complete<C:CurveConfig<Base=Fq>,const SIGNED:bool>(buckets:&mut[Affine<C>],batch:&[(u32,impl std::borrow::Borrow<Affine<C>>+Copy)]){{for &(id,p) in batch{{let p=*p.borrow();let p=if SIGNED&&id>>31!=0{{-p}}else{{p}};let i=batch_index::<SIGNED>(id);buckets[i]=(buckets[i]+p).to_affine();}}}}\n{invert}\n{stream}\nimpl<C:CurveConfig<Base=Fq>> BatchAdd<C>{{pub(crate) fn apply_deferred_equality(&mut self,buckets:&mut[Affine<C>],batch:&[(u32,&Affine<C>)])->bool{{if self.fq.canonical&&self.fq.vector_inverse{{stream_checked::<C,true,true>(buckets,batch,&mut self.fq)}}else{{complete::<C,true>(buckets,batch);false}}}}\n{}",fs::read_to_string(format!("{R}/kernel-tests.rs.in")).unwrap());
    let mut window=pending[pending.find("struct Window<").unwrap()..pending.find("pub(super) fn fused<").unwrap()].to_owned();
    let from=window.find("        if current.x == point.x {").unwrap();
    let to=window[from..].find("        self.busy[bucket / 64] |=").unwrap()+from;
    window.replace_range(from..to,"");
    replace(&mut window,".apply_signed_borrowed(&mut self.affine, &self.batch);",".apply_deferred_equality(&mut self.affine, &self.batch);");
    let feeder=format!("//! The original ordinary feeder with only equal-X handling deferred.\nuse super::*;\nuse zopro_bn254::{{G1Affine,G1Config}};\nconst WINDOWS:usize=21;const WIDTH:usize=12;\n#[cfg(zopro_deferred_equality)]mod deferred{{use super::*;\n{window}\npub(super) fn fill(points:&[G1Affine],words:&[[u64;4]])->Vec<Vec<G1Affine>>{{let size=batch_size(WIDTH).max(32);(0..WINDOWS).into_par_iter().map(|w|{{let mut state=Window::<G1Config>::new(1<<(WIDTH-1),size);state.feed(points,words,w,WIDTH,size);state.finish()}}).collect()}}\n}}\npub(crate) fn fill(points:&[G1Affine],words:&[[u64;4]],on:bool)->(Vec<Vec<G1Affine>>,bool){{assert_eq!(points.len(),words.len());#[cfg(zopro_deferred_equality)]if on{{return(deferred::fill(points,words),true);}}let _=on;let size=batch_size(WIDTH).max(32);let buckets=(0..WINDOWS).into_par_iter().map(|w|{{let mut s=super::Window::<G1Config>::new(1<<(WIDTH-1),size);s.feed(points,words,w,WIDTH,size);s.finish()}}).collect();(buckets,false)}}\n{}",fs::read_to_string(format!("{R}/feeder-tests.rs.in")).unwrap());
    let native="all(feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma))";
    let mut parents=BTreeMap::new();
    parents.insert("crates/zopro-core/src/lib.rs",format!("\n#[cfg({native})]pub fn g1_deferred_equality_probe(points:&[zopro_bn254::G1Affine],words:&[[u64;4]],on:bool)->(Vec<Vec<zopro_bn254::G1Affine>>,bool){{msm_affine::borrowed_pending::deferred_equality_probe(points,words,on)}}\n"));
    parents.insert("crates/zopro-core/src/msm_affine/borrowed_pending.rs",format!("\n#[cfg({native})]mod deferred_equality;\n#[cfg({native})]pub(crate) fn deferred_equality_probe(points:&[zopro_bn254::G1Affine],words:&[[u64;4]],on:bool)->(Vec<Vec<zopro_bn254::G1Affine>>,bool){{deferred_equality::fill(points,words,on)}}\n"));
    parents.insert("crates/zopro-core/src/msm.rs",format!("\n#[cfg(all(zopro_deferred_equality,{native}))]mod deferred_equality;\n"));
    parents.insert("crates/zopro-core/src/simd.rs",format!("\n#[cfg(all(zopro_deferred_equality,{native}))]mod checked_inverse;\n"));
    let children=[("crates/zopro-core/src/msm_affine/borrowed_pending/deferred_equality.rs",feeder),("crates/zopro-core/src/msm/deferred_equality.rs",kernel),("crates/zopro-core/src/simd/checked_inverse.rs",checked)];
    for label in ["control","candidate"] {
        let mut pins=BTreeMap::new();
        for(p,h)in originals {let bytes=fs::read(format!("{Z}/{p}")).unwrap();assert_eq!(hash(&bytes),h.as_str().unwrap());let dest=format!("{R}/{label}/source/{p}");assert!(!Path::new(&dest).exists());fs::create_dir_all(Path::new(&dest).parent().unwrap()).unwrap();let mut changed=bytes;if let Some(extra)=parents.get(p.as_str()){changed.extend_from_slice(extra.as_bytes());}fs::write(&dest,&changed).unwrap();pins.insert(p.to_owned(),hash(&changed));}
        for(p,source)in &children {let dest=format!("{R}/{label}/source/{p}");fs::create_dir_all(Path::new(&dest).parent().unwrap()).unwrap();fs::write(dest,source).unwrap();pins.insert((*p).to_owned(),hash(source.as_bytes()));}
        assert_eq!(pins.len(),179);
        fs::write(format!("{R}/{label}/source-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
        fs::write(format!("{R}/{label}-flags.txt"),format!("{}{}",manifest["rustflags"].as_str().unwrap(),if label=="candidate"{" --cfg zopro_deferred_equality"}else{""})).unwrap();
    }
    fs::write(format!("{R}/parents.json"),serde_json::to_vec_pretty(&json!(parents)).unwrap()).unwrap();
    fs::write(format!("{R}/derivation.json"),serde_json::to_vec_pretty(&json!({"originals":176,"source_files_each":179,"parents":4,"children":3,"originals_exact_each":172,"original_window_sha256":hash(pending[pending.find("struct Window<").unwrap()..pending.find("pub(super) fn fused<").unwrap()].as_bytes()),"generated_checked_inverse_sha256":hash(children[2].1.as_bytes()),"production_changed":false})).unwrap()).unwrap();
    println!("SetupPASS:179files each;172 original exact;4 append parents;3 children;original stream arithmetic copied with fallible central inverse");
}
