use std::{fs, path::Path, time::Instant};
use zopro_bn254::{Fq, Fr, G1Affine};
#[path = "perf_support.rs"]
mod perf;
#[global_allocator]
static ALLOCATOR: zopro_core::alloc::Allocator = zopro_core::alloc::Allocator;
fn point(b: &[u8]) -> G1Affine {
    if b.iter().all(|&x| x == 0) {
        G1Affine::IDENTITY
    } else {
        let p = G1Affine::new(
            Fq::from_be_bytes(b[..32].try_into().unwrap()).unwrap(),
            Fq::from_be_bytes(b[32..].try_into().unwrap()).unwrap(),
        );
        assert!(p.is_on_curve());
        p
    }
}
fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    assert_eq!(args.len(),6);let on=match args[5].as_str(){"OFF"=>false,"ON"=>true,_=>panic!("arm")};assert!(!on||cfg!(zopro_deferred_equality));
    let bytes = fs::read(&args[1]).unwrap();
    assert_eq!(&bytes[..8], b"ACOLMSM1");
    let n = u64::from_le_bytes(bytes[8..16].try_into().unwrap()) as usize;
    assert_eq!(bytes.len(), 16 + 96 * n);
    let points = bytes[16..16 + 64 * n]
        .chunks_exact(64)
        .map(point)
        .collect::<Vec<_>>();
    let words = bytes[16 + 64 * n..]
        .chunks_exact(32)
        .map(|b| {
            let words = core::array::from_fn(|i| {
                u64::from_le_bytes(b[i * 8..i * 8 + 8].try_into().unwrap())
            });
            assert!(Fr::from_canonical(words).is_some());
            words
        })
        .collect::<Vec<_>>();
    let expected_bytes = fs::read(&args[2]).unwrap();
    assert_eq!(&expected_bytes[..8], b"ACOLREF1");
    assert_eq!(
        u32::from_le_bytes(expected_bytes[8..12].try_into().unwrap()),
        21
    );
    assert_eq!(
        u32::from_le_bytes(expected_bytes[12..16].try_into().unwrap()),
        2048
    );
    assert_eq!(expected_bytes.len(), 16 + 21 * 2048 * 64);
    let expected = expected_bytes[16..]
        .chunks_exact(2048 * 64)
        .map(|w| w.chunks_exact(64).map(point).collect::<Vec<_>>())
        .collect::<Vec<_>>();
    let workers = args[3].parse::<usize>().unwrap();
    assert!([1, 16, 32].contains(&workers));
    let rounds = args[4].parse::<usize>().unwrap();
    assert!(rounds > 0);
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(workers)
        .stack_size(512 * 1024)
        .build()
        .unwrap();
    let run = || {
        pool.install(|| {
            let (buckets,entered)=zopro_core::g1_deferred_equality_probe(std::hint::black_box(&points),std::hint::black_box(&words),on);assert_eq!(entered,on,"candidate must enter deferred equality feeder");buckets
        })
    };
    for _ in 0..3 {
        assert_eq!(run(), expected);
    }
    let mut control = perf::Control::from_env().unwrap();
    if let Some(c) = control.as_mut() {
        c.enable().unwrap();
    }
    let before = perf::Usage::now().unwrap();
    let began = Instant::now();
    for _ in 0..rounds {
        let buckets = run();
        std::hint::black_box(&buckets);
        drop(buckets);
    }
    let elapsed = began.elapsed().as_nanos() as u64;
    let after = perf::Usage::now().unwrap();
    if let Some(c) = control.as_mut() {
        c.disable().unwrap();
    }
    assert_eq!(run(), expected);
    let receipt = serde_json::json!({"input_rows":n,"workers":workers,"ordinary_windows_per_pass":21,"timed_passes":rounds,"priming_passes":3,"postcheck_passes":1,"all_prime_and_post_buckets_match_independent_oracle":true,"candidate":on,"new_input_sized_buffers":0,"deferred_equal_x":on,"exception_fallback_inside_timer":true,"elapsed_ns":elapsed,"ns_per_complete_ordinary_fill_pass":elapsed as f64/rounds as f64,"timed_fills":rounds*21,"checked_bucket_outputs":4*21*2048,"allocation_and_drop_inside_timer":true,"usage":after.difference(&before),"new_proofs":0});
    println!("CALLER {receipt}");
    if let Some(path) = std::env::var_os("ZOPRO_CALLER_RECEIPT") {
        fs::write(
            Path::new(&path),
            serde_json::to_vec_pretty(&receipt).unwrap(),
        )
        .unwrap();
    }
}
