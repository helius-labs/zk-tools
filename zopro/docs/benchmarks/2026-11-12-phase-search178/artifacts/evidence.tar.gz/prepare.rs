use std::{collections::BTreeMap,fs,path::{Path,PathBuf}};
use serde_json::{json,Value};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/phase-search178";
const REPO:&str="/home/ubuntu/src/zk-tools/zopro";
const VENDOR:&str="/home/ubuntu/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rayon-core-1.13.0";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn cp(a:impl AsRef<Path>,b:impl AsRef<Path>){fs::create_dir_all(b.as_ref().parent().unwrap()).unwrap();fs::copy(a,b).unwrap();}
fn files(p:&Path,out:&mut Vec<PathBuf>){for e in fs::read_dir(p).unwrap(){let p=e.unwrap().path();if p.is_dir(){files(&p,out)}else{out.push(p)}}}
fn save(p:impl AsRef<Path>,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn replace(p:&Path,old:&str,new:&str){let text=fs::read_to_string(p).unwrap();assert_eq!(text.matches(old).count(),1,"{}",p.display());fs::write(p,text.replace(old,new)).unwrap();}
fn main(){let r=Path::new(R);let source=r.join("source");
if std::env::args().nth(1).as_deref()==Some("freeze") {
 let mut plan=read("/home/ubuntu/src/zopro-perf-work/bundle-sdk178/build-plan.json");
 plan=serde_json::from_str(&serde_json::to_string(&plan).unwrap().replace("/home/ubuntu/src/zopro-perf-work/bundle-sdk178",R)).unwrap();
 let steps=plan["steps"].as_array_mut().unwrap();
 steps.insert(0,json!({"kind":"command","name":"rayon-tests","argv":["cargo","test","--locked","--offline","--release","--manifest-path",source.join("Cargo.toml"),"-p","rayon-core","--lib","--tests","--","--test-threads=1"],"timeout_seconds":600}));
 // Test underlying scheduler and keep the coherent SDK library/link steps.
 save(r.join("build-plan.json"),&plan);
 let mut paths=vec![];files(&source,&mut paths);for f in["prepare.rs","registry_extension.rs","core_extension.rs","design.md","driver.rs","support/perf.rs","build-plan.json","source-audit.json"]{paths.push(r.join(f));}
 let pins=paths.into_iter().map(|p|(p.display().to_string(),hash(&p))).collect::<BTreeMap<_,_>>();save(r.join("build-pins.json"),&json!(pins));println!("Frozen {} build inputs",pins.len());return;
}
assert!(!source.exists());let manifest=read(Path::new(REPO).join("docs/benchmarks/2026-11-12-bundle-adoption178/artifacts/production-source-manifest.json"));
let originals=manifest["source_files_sha256"].as_object().unwrap();assert_eq!(originals.len(),177);
for(p,h)in originals{let a=Path::new(REPO).join(p);assert_eq!(hash(&a),h.as_str().unwrap());cp(a,source.join(p));}
let vendor=source.join("vendor/rayon-core");let mut paths=vec![];files(Path::new(VENDOR),&mut paths);let mut vendor_pins=BTreeMap::new();
for p in paths {let rel=p.strip_prefix(VENDOR).unwrap();vendor_pins.insert(rel.display().to_string(),hash(&p));cp(&p,vendor.join(rel));}
let mut root=fs::read_to_string(source.join("Cargo.toml")).unwrap().replace("members = [", "members = [\n    \"vendor/rayon-core\",");root.push_str("\n[patch.crates-io]\nrayon-core = { path = \"vendor/rayon-core\" }\n");fs::write(source.join("Cargo.toml"),root).unwrap();
replace(&source.join("crates/zopro-core/Cargo.toml"),"rayon = \"1.10\"","rayon = \"1.10\"\nrayon-core = \"1.13\"");
let reg=vendor.join("src/registry.rs");replace(&reg,"    sleep: Sleep,","    sleep: Sleep,\n    search_limit: AtomicUsize,\n    search_scopes: Mutex<usize>,");
replace(&reg,"            sleep: Sleep::new(n_threads),","            sleep: Sleep::new(n_threads),\n            search_limit: AtomicUsize::new(usize::MAX),\n            search_scopes: Mutex::new(0),");
replace(&reg,"    fn steal(&self) -> Option<JobRef> {","    fn steal(&self) -> Option<JobRef> {\n        if self.index >= self.registry.search_limit.load(Ordering::Acquire) { return None; }");
let mut text=fs::read_to_string(&reg).unwrap();text.push_str(&fs::read_to_string(r.join("registry_extension.rs")).unwrap());fs::write(&reg,text).unwrap();
let lib=vendor.join("src/lib.rs");let mut text=fs::read_to_string(&lib).unwrap();text.push_str("\n/// Private scoped search-participation diagnostic.\npub fn diagnostic_with_search_limit<F:FnOnce()->R,R>(limit:usize,f:F)->R {registry::with_search_limit(limit,f)}\n/// Private diagnostic state for transition checks.\npub fn diagnostic_search_state()->(usize,usize){registry::search_state()}\n");fs::write(lib,text).unwrap();
let core=source.join("crates/zopro-core/src/lib.rs");let needle="let solver::Solution{mut w,a,b,c}=plan.solve_in_with_slots(witness,self.domain,&folded.slots,materialize_c)?;";
replace(&core,needle,"let solver::Solution{mut w,a,b,c}=phase_search_probe::run(||plan.solve_in_with_slots(witness,self.domain,&folded.slots,materialize_c))?;");
let mut text=fs::read_to_string(&core).unwrap();text.push_str(&fs::read_to_string(r.join("core_extension.rs")).unwrap());fs::write(core,text).unwrap();
let old="/home/ubuntu/src/zopro-perf-work/bundle-sdk178";let mut driver=fs::read_to_string(format!("{old}/driver.rs")).unwrap();
driver=driver.replace("    let before = perf::Usage::now()?;","    let scope_before=zopro_core::phase_search_probe::snapshot();\n    assert_eq!((scope_before.1,scope_before.2),(usize::MAX,0));\n    let before = perf::Usage::now()?;")
.replace("    let after = perf::Usage::now()?;","    let after = perf::Usage::now()?;\n    let scope_after=zopro_core::phase_search_probe::snapshot();\n    assert_eq!((scope_after.1,scope_after.2),(usize::MAX,0));")
.replace("    summary[\"rounds\"] = rounds.into();","    summary[\"search_scopes\"]=(scope_after.0-scope_before.0).into();\n    summary[\"search_restored\"]=true.into();\n    summary[\"rounds\"] = rounds.into();");
fs::write(r.join("driver.rs"),driver).unwrap();cp(format!("{old}/support/perf.rs"),r.join("support/perf.rs"));
save(r.join("source-audit.json"),&json!({"originals":originals,"vendor_originals":vendor_pins,"modified_production":["Cargo.toml","Cargo.lock","crates/zopro-core/Cargo.toml","crates/zopro-core/src/lib.rs"],"modified_vendor":["src/lib.rs","src/registry.rs"],"private_only":true}));println!("Prepared current177-source isolated solver-phase diagnostic and private Rayon");}
