use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,collections::{BTreeMap,BTreeSet}};
const R:&str="/home/ubuntu/src/zopro-perf-work/phase-search178";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/borrowed-pair178";
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(n:&str,v:Value){assert!(!std::path::Path::new(&format!("{R}/{n}")).exists());fs::write(format!("{R}/{n}"),serde_json::to_vec_pretty(&v).unwrap()).unwrap()}
fn prepare(){
 assert_eq!(read(&format!("{R}/assessment.json"))["passed"],false);
 let old=read(&format!("{OLD}/diagnostic-plan.json"));let main=read(&format!("{R}/main-plan.json"));let jobs=read(&format!("{R}/main-jobs.json"));
 let case=jobs.as_array().unwrap().iter().find(|j|j["case"]["name"]=="1x2-w32").unwrap()["case"].clone();let mut steps=vec![];
 for panel in ["stat","cycles","decode"] {for arm in if panel=="cycles" {vec!["ON","OFF"]}else{vec!["OFF","ON"]} {
  for oldstep in old["steps"].as_array().unwrap().iter().filter(|s|{let n=s["name"].as_str().unwrap();n.ends_with("M0") && match panel{"stat"=>n.starts_with("stat-"),"cycles"=>n.starts_with("cycles-"),_=>!n.starts_with("stat-")&&!n.starts_with("cycles-")}}) {
   let mut step=oldstep.clone();step["name"]=json!(step["name"].as_str().unwrap().replace("M0",arm));
   let mut args=step["argv"].as_array().unwrap().iter().map(|v|v.as_str().unwrap().replace(OLD,R).replace("M0",arm)).collect::<Vec<_>>();
   if panel!="decode" {
    let source=main["steps"].as_array().unwrap().iter().find(|s|s["name"].as_str().unwrap()==format!("main-b0-c0-1x2-w32-{arm}")).unwrap();let mut env=source["environment"].clone();env["ZOPRO_BENCH_PERF_CTL"]=json!(format!("{R}/ctl"));env["ZOPRO_BENCH_PERF_ACK"]=json!(format!("{R}/ack"));
    let at=args.iter().position(|a|a=="perf").unwrap();let rest=args.split_off(at);args=vec!["sudo".into(),"-n".into(),"env".into()];for(k,v)in env.as_object().unwrap(){args.push(format!("{k}={}",v.as_str().unwrap()));}args.extend(rest);
    let at=args.iter().position(|a|a==&format!("{R}/bin/copy0")).unwrap();args.truncate(at);args.extend([format!("{R}/bin/FRESH0"),case["image"].as_str().unwrap().into(),case["request"].as_str().unwrap().into(),if panel=="stat"{"201".into()}else{"251".into()},format!("{R}/proofs/diagnostic-{panel}-{arm}")]);
   }
   step["argv"]=json!(args);steps.push(step);
  }
 }}
 let verifier="/home/ubuntu/src/zopro-perf-work/batch-local-steal/gnark/verify";
 for panel in ["stat","cycles"] {for arm in ["OFF","ON"] {let dir=format!("{R}/proofs/diagnostic-{panel}-{arm}");steps.push(json!({"kind":"command","name":format!("verify-{panel}-{arm}"),"argv":[verifier,case["image"].as_str().unwrap(),case["image_sha256"].as_str().unwrap(),&format!("{dir}/0.proof"),&format!("{dir}/0.public"),case["public_sha256"].as_str().unwrap()],"timeout_seconds":120}));}}
 for d in["stat","perf"]{fs::create_dir_all(format!("{R}/{d}")).unwrap();}
 let mut pins=read(&format!("{R}/capture-pins.json")).as_object().unwrap().clone();for p in[format!("{R}/diagnose.rs"),format!("{R}/diagnostic-protocol.md"),format!("{R}/proof-sha256-after-main.json"),"/home/ubuntu/src/zopro-perf-work/window-batch-proof-capture176/campaign".into()]{pins.insert(p.clone(),hash(&p).into());}
 save("diagnostic-case.json",case);save("diagnostic-pins.json",json!(pins));save("diagnostic-plan.json",json!({"version":1,"source_pins":format!("{R}/diagnostic-pins.json"),"steps":steps}));println!("Frozen4captures+10decode+4Gnark;916SDKcalls including primes");
}
fn analyze(){
 for(p,h)in read(&format!("{R}/diagnostic-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
 assert_eq!(read(&format!("{R}/diagnostic-run/result.json"))["status"],"complete");let plan=read(&format!("{R}/diagnostic-plan.json"));assert_eq!(plan["steps"].as_array().unwrap().len(),18);let mut summaries=BTreeMap::new();let mut seconds=0.;
 for s in plan["steps"].as_array().unwrap(){let name=s["name"].as_str().unwrap();let dir=format!("{R}/diagnostic-run/{name}");let e=read(&format!("{dir}/exit.json"));assert_eq!(e["success"],true);assert_eq!(e["returncode"],0);seconds+=e["elapsed_ms"].as_f64().unwrap()/1000.;let c=read(&format!("{dir}/command.json"));assert_eq!(&c["argv"].as_array().unwrap()[4..],s["argv"].as_array().unwrap());for stream in["stdout","stderr"]{assert_eq!(hash(&format!("{dir}/{stream}.log")),e[format!("{stream}_sha256")]);}
  if name.starts_with("stat-")||name.starts_with("cycles-"){let text=fs::read_to_string(format!("{dir}/stdout.log")).unwrap();let list=text.lines().filter_map(|l|l.strip_prefix("SUMMARY ")).collect::<Vec<_>>();assert_eq!(list.len(),1);let v:Value=serde_json::from_str(list[0]).unwrap();let n=if name.starts_with("stat-"){201}else{251};assert_eq!(v["rounds"],n);assert_eq!(v["priming"],3);assert_eq!(v["workers"],32);assert_eq!(v["search_scopes"],if name.ends_with("ON"){n}else{0});assert_eq!(v["search_restored"],true);assert_eq!(v["indexed_entries"],4*n);assert_eq!(v["placement_before"],v["placement_after"]);assert_eq!(text.lines().filter(|l|l.starts_with("SAMPLE ")).count(),n);summaries.insert(name.to_owned(),v);}
 }
 let mut quality=true;let mut stats=vec![];let mut profiles=vec![];
 for arm in["OFF","ON"] {
  let csv=fs::read_to_string(format!("{R}/stat/stat-1x2-B-w32-{arm}.csv")).unwrap();let mut counters=BTreeMap::new();for l in csv.lines().filter(|l|!l.is_empty()&&!l.starts_with('#')){let f=l.split(';').collect::<Vec<_>>();assert!(f.len()>=5);let v=f[0].parse::<u64>().unwrap();let running=f[4].parse::<f64>().unwrap();quality&=(100.0..=100.01).contains(&running);counters.insert(f[2],json!({"value":v,"per_proof":v as f64/201.,"running_percent":running}));}assert_eq!(counters.len(),4);stats.push(json!({"arm":arm,"counters":counters}));
  let name=format!("cycles-1x2-B-w32-{arm}");let summary=&summaries[&name];let workers=summary["placement_before"]["worker_rows"].as_array().unwrap().iter().map(|r|(r["tid"].as_u64().unwrap(),r["allowed"][0].as_u64().unwrap())).collect::<BTreeMap<_,_>>();assert_eq!(workers.len(),32);
  let path=|prefix:&str|format!("{R}/diagnostic-run/{prefix}{name}/stdout.log");let metadata=fs::read_to_string(path("metadata-")).unwrap();let events=fs::read_to_string(path("events-")).unwrap();assert!(events.contains("cycles:u")&&events.contains("16000000")&&events.contains("CPU|PERIOD")&&events.contains("exclude_kernel: 1")&&events.contains("inherit: 1"));let gate=fs::read_to_string(format!("{R}/diagnostic-run/{name}/stderr.log")).unwrap();assert_eq!(gate.lines().filter(|l|l.starts_with("Events ")).collect::<Vec<_>>(),vec!["Events disabled","Events enabled","Events disabled"]);
  let loss=read(&path("loss-"));let raw=fs::read_to_string(path("decode-")).unwrap();let(mut samples,mut unknown)=(0u64,0u64);let mut pids=BTreeSet::new();let mut tids=BTreeSet::new();let mut symbols=BTreeMap::<String,u64>::new();
  for l in raw.lines().filter(|l|!l.is_empty()&&!l.starts_with('#')){let f=l.split_whitespace().collect::<Vec<_>>();assert!(f.len()>=6);let(p,t)=f[0].split_once('/').unwrap();let pid=p.parse::<u64>().unwrap();let tid=t.parse::<u64>().unwrap();pids.insert(pid);tids.insert(tid);let cpu=f[1].trim_matches(&['[',']'][..]).parse::<u64>().unwrap();assert!(cpu<32);if tid!=pid{assert_eq!(workers.get(&tid),Some(&cpu));}assert_eq!(f[3].parse::<u64>().unwrap(),16000000);let symbol=f[5..].join(" ");unknown+=u64::from(symbol.contains("unknown"));*symbols.entry(format!("{:#}",rustc_demangle::demangle(&symbol))).or_default()+=1;samples+=1;}
  assert_eq!(pids.len(),1);let pid=*pids.first().unwrap();assert!(metadata.lines().any(|l|l.contains("PERF_RECORD_MMAP")&&l.contains(&format!("{pid}/{pid}"))&&l.contains(&format!("{R}/bin/FRESH0"))));for tid in tids{assert!(metadata.contains(&format!("{pid}/{tid}")));}
  let pass=samples>=1000&&unknown*100<=samples*5&&loss["zero_lost"]==true;quality&=pass;let mut ranks=symbols.into_iter().collect::<Vec<_>>();ranks.sort_by(|a,b|b.1.cmp(&a.1));profiles.push(json!({"arm":arm,"samples":samples,"unknown_samples":unknown,"zero_LOST":loss["zero_lost"],"quality_passed":pass,"symbols":ranks,"data_sha256":hash(&format!("{R}/perf/{name}.data"))}));
 }
 let mut ledger=read(&format!("{R}/proof-sha256-after-main.json")).as_array().unwrap().iter().map(|v|v.as_str().unwrap().to_string()).collect::<BTreeSet<_>>();assert_eq!(ledger.len(),55020);let case=read(&format!("{R}/diagnostic-case.json"));
 for panel in["stat","cycles"] {for arm in["OFF","ON"] {let dir=format!("{R}/proofs/diagnostic-{panel}-{arm}");let ph=hash(&format!("{dir}/0.proof"));assert!(ledger.insert(ph.clone()));assert_eq!(fs::metadata(format!("{dir}/0.proof")).unwrap().len(),164);let public=hash(&format!("{dir}/0.public"));assert_eq!(public,case["public_sha256"]);let text=fs::read_to_string(format!("{R}/diagnostic-run/verify-{panel}-{arm}/stdout.log")).unwrap();assert_eq!(text.lines().filter(|l|l.starts_with("VERIFIED ")).count(),1);for b in[format!("proof_sha256={ph}"),format!("public_sha256={public}"),format!("image_sha256={}",case["image_sha256"].as_str().unwrap())]{assert!(text.contains(&b));}}}
 save("proof-sha256-after-diagnostic.json",json!(ledger));save("diagnostic-analysis.json",json!({"quality_passed":quality,"stats":stats,"profiles":profiles,"summaries":summaries,"command_seconds":seconds,"new_Gnark_exports":4,"SDK_calls_including_primes":916,"canonical_count":55024,"canonical_sha256":hash(&format!("{R}/proof-sha256-after-diagnostic.json")),"screen_decision_unchanged":true}));println!("18receipts/4freshGnark/916SDK; profile quality={quality}");for s in stats{println!("{s}");}
}
fn main(){match std::env::args().nth(1).as_deref(){Some("prepare")=>prepare(),Some("analyze")=>analyze(),_=>panic!("prepare/analyze")}}
