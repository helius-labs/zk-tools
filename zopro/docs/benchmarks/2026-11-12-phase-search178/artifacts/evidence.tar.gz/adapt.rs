use std::fs;
const R:&str="/home/ubuntu/src/zopro-perf-work/phase-search178";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/bundle-sdk178";
fn main(){
 for file in ["freeze-capture.rs","review.rs"] {
  let mut s=fs::read_to_string(format!("{OLD}/{file}")).unwrap().replace(OLD,R)
   .replace("/home/ubuntu/src/zopro-perf-work/joint-frames178/proof-sha256-after-main.json","/home/ubuntu/src/zopro-perf-work/bundle-all178/proof-sha256-after-main.json")
   .replace("075b7efb0a64d9c00013d4286c93b1149a6469c404ca9db9c7feddfaee25aa8b","48e866327435bbc85f7c8d0433115337d7d903481594f307bab4373c39ec3119")
   .replace("54193","54927").replace("54205","54939");
  if file=="freeze-capture.rs" {
   let start=s.find("fn main(){let mode=").unwrap();let finish=s.find("assert_eq!(hash(PRIOR)").unwrap();s.replace_range(start..finish,"fn main(){");
   let start=s.find("let refs=read(").unwrap();let finish=s[start..].find("let candidate=").unwrap()+start;
   s.replace_range(start..finish,"let refpath=\"/home/ubuntu/src/zopro-perf-work/bundle-sdk178/build-run/candidate-sdk\";assert_eq!(hash(refpath),\"b646c7b8c1d8a26a0db45fb3f67c453dd616bd9f02e25c36192721ae02855abe\");");
   s=s.replace("let mut env=base_env.clone();","let mut env=base_env.clone();env[\"ZOPRO_CPU_INDEXED_TILE_BUNDLES\"]=json!(\"1\");")
    .replace("env[\"ZOPRO_CPU_INDEXED_TILE_BUNDLES\"]=json!(if arm==\"ON\"{\"1\"}else{\"0\"});","env[\"ZOPRO_DIAGNOSTIC_SEARCH_DIVISOR\"]=json!(if arm==\"ON\"{\"3\"}else{\"0\"});")
    .replace("\"observer.rs\"","\"core_extension.rs\",\"registry_extension.rs\"");
  } else {
   let start=s.find("if j[\"arm\"]!=\"REF\"{let expected=").unwrap();let finish=s[start..].find("let w=s[\"workers\"]").unwrap()+start;
   s.replace_range(start..finish,"if j[\"arm\"]!=\"REF\"{assert_eq!(s[\"indexed_entries\"].as_u64().unwrap()as usize,4*n);assert!(s[\"indexed_max_charge\"].as_u64().unwrap()>0);assert_eq!(s[\"search_scopes\"].as_u64().unwrap()as usize,if j[\"arm\"]==\"ON\"{n}else{0});assert_eq!(s[\"search_restored\"],true);}");
  }
  fs::write(format!("{R}/{file}"),s).unwrap();
 }
 println!("Adapted retained screen generator/reader to current baseline and ledger54927");
}
