{
  checks: [
    .summary[] as $s |
    ($s.comparisons[] as $c | $c.per_backing_medians | to_entries[] |
      {case:$s.case, comparison:$c.comparison, backing:.key, ratio:.value,
       kind:(if $s.case=="1x2-w32" then "gain" else "nonregression" end),
       passed:(if $s.case=="1x2-w32" then .value < 1 else .value <= 1.03 end)}),
    ([$s.arms[]|select(.arm=="REF")][0].rss_mib_max as $ref |
     [$s.arms[]|select(.arm=="ON")][0].rss_mib_max as $on |
     {case:$s.case,kind:"peak_rss",reference_mib:$ref,candidate_mib:$on,
      limit_mib:($ref*1.05+1),passed:($on<=($ref*1.05+1))})
  ]
} | . + {passed:([.checks[].passed]|all),screen_only:true}
