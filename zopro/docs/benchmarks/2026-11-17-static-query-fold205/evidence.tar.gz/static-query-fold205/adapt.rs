use std::fs;
fn replace(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replace(a,b);}
fn main(){let root="/home/ubuntu/src/zopro-perf-work/static-query-fold205";let mut s=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/static-query-fold204/capture.rs").unwrap();
 replace(&mut s,"const ROOT:&str=\"/home/ubuntu/src/zopro-perf-work/static-query-fold204\";",&format!("const ROOT:&str=\"{root}\";"));
 replace(&mut s,"const SEED:&str=\"/home/ubuntu/src/zopro-perf-work/accepted-c7a201/host-remote/proof-sha256.json\";","const SEED:&str=\"/home/ubuntu/src/zopro-perf-work/static-query-fold204/proof-sha256-after-main.json\";");
 replace(&mut s,"v[v.len()/2]}","if v.len()%2==1{v[v.len()/2]}else{(v[v.len()/2-1]+v[v.len()/2])/2.}}");
 replace(&mut s,"r.join(format!(\"{shape}.folded.image\"))","Path::new(if [\"1x2\",\"2x2\"].contains(&shape){\"/home/ubuntu/src/zopro-perf-work/static-query-fold204\"}else{ROOT}).join(format!(\"{shape}.folded.image\"))");
 replace(&mut s,"for shape in[\"1x2\",\"2x2\"]{for arm", "for shape in[\"1x2\",\"2x2\",\"4x2\",\"8x2\",\"12x2\",\"16x2\",\"24x2\",\"merge-24x1\",\"merge-54x1\"]{for arm");
 replace(&mut s,"for block in 0..3{let mut contexts=[(\"1x2\",16),(\"1x2\",32),(\"2x2\",32)];contexts.rotate_left(block%3);","for block in 0..30{let mut contexts=[(\"1x2\",16),(\"1x2\",32),(\"2x2\",32),(\"4x2\",32),(\"8x2\",32),(\"12x2\",32),(\"16x2\",32),(\"24x2\",32),(\"merge-24x1\",32),(\"merge-54x1\",32)];contexts.rotate_left(block%10);");
 replace(&mut s,"assert_eq!(jobs.len(),22);","assert_eq!(jobs.len(),618);");
 replace(&mut s,"for f in[\"capture.rs\",\"capture\",\"protocol.md\",\"convert.rs\",\"model.rs\",\"semantic.rs\",\"semantic-tests.rs\",\"backings.json\"]{let p=r.join(f);","for f in[\"capture.rs\",\"capture\",\"protocol.md\",\"finish.rs\",\"backings.json\"]{let p=r.join(f);");
 replace(&mut s,"Prepared4smokes+18mainprocesses/376SDKrequests; no capture yet","Prepared18preflights+600mainprocesses/12072SDKrequests; no capture yet");
 let a=s.find("fn finish(smoke:bool){").unwrap();let b=s[a..].find("fn main(){").unwrap()+a;s.replace_range(a..b,"include!(\"finish.rs\");\n");fs::write(format!("{root}/capture.rs"),s).unwrap();}
