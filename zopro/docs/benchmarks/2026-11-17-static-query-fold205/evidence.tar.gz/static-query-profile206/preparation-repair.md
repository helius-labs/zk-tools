# Preparation repair

The first manual profile-helper link omitted its existing rustc_demangle extern
and failed E0433 in sampling.rs. The following prepare invocation consequently
failed127 because the helper did not exist, and the workflow invocation failed1
before executing any step because plan.json had not been created. Its initial
workflow log is retained. No SDK/perf capture or proof ran in these failures.

Repair only the helper rustc invocation by supplying the existing demangler
library; source, protocol, requested events, samples and observer rules stay
unchanged. Do not replay a successful stage.
