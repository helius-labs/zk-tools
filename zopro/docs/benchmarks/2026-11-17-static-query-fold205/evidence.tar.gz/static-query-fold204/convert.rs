mod model;
use std::{collections::{BTreeMap,BTreeSet},fs,io::{BufWriter,Write},path::Path};
use serde_json::{json,Value};
use sha2::{Sha256,Digest};
use zopro_bn254::{Fr,Fq,Fq2,G1Affine,G1Projective,G2Affine,G2Projective};
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn u32at(b:&[u8],p:usize)->usize{u32::from_le_bytes(b[p..p+4].try_into().unwrap())as usize}
fn u64at(b:&[u8],p:usize)->usize{u64::from_le_bytes(b[p..p+8].try_into().unwrap())as usize}
fn align(n:usize)->usize{n.checked_add(63).unwrap()/64*64}
fn raw_fq(b:&[u8])->Fq{assert_eq!(b.len(),32);let w=std::array::from_fn(|i|u64::from_le_bytes(b[i*8..i*8+8].try_into().unwrap()));assert!(w.iter().rev().cmp(Fq::MODULUS.iter().rev()).is_lt());Fq::from_montgomery(w)}
fn g1(b:&[u8])->G1Affine{let p=G1Affine::new(raw_fq(&b[..32]),raw_fq(&b[32..]));assert!(p.is_on_curve());p}
fn g2(b:&[u8])->G2Affine{let p=G2Affine::new(Fq2::new(raw_fq(&b[..32]),raw_fq(&b[32..64])),Fq2::new(raw_fq(&b[64..96]),raw_fq(&b[96..])));assert!(p.is_on_curve()&&p.is_in_subgroup());p}
fn encode(fields:&[Fq])->Vec<u8>{fields.iter().flat_map(|f|f.0.into_iter().flat_map(u64::to_le_bytes)).collect()}
fn ratio(m:&Value)->Fr{let w=std::array::from_fn(|i|m["ratio_montgomery"][i].as_u64().unwrap());assert!(w.iter().rev().cmp(Fr::MODULUS.iter().rev()).is_lt());let v=Fr::from_montgomery(w);assert_ne!(v,Fr::ZERO);v}
struct Fold {removed:BTreeSet<usize>,patches:BTreeMap<usize,Vec<u8>>}
fn fold_points(input:&[u8],size:usize,cert:&Value,indices:&[u8])->Fold {
    let n=input.len()/size;assert_eq!(n,cert["original_points"].as_u64().unwrap()as usize);assert_eq!(indices.len(),n*4);
    let mut removed=cert["zero_rows"].as_array().unwrap().iter().map(|v|v.as_u64().unwrap()as usize).collect::<BTreeSet<_>>();
    let mut patches=BTreeMap::new();let mut covered=removed.clone();
    for c in cert["classes"].as_array().unwrap(){
        let rep=c["representative_row"].as_u64().unwrap()as usize;assert!(rep<n);let ms=c["members"].as_array().unwrap();assert!(ms.len()>1);assert_eq!(ms[0]["row"],rep);assert_eq!(ratio(&ms[0]),Fr::ONE);
        let mut p1=G1Projective::IDENTITY;let mut p2=G2Projective::IDENTITY;
        for m in ms {let row=m["row"].as_u64().unwrap()as usize;assert!(row>=rep&&row<n&&covered.insert(row));assert_eq!(u32at(indices,row*4),m["wire"].as_u64().unwrap()as usize);let p=&input[row*size..(row+1)*size];let scale=ratio(m);if size==64{p1+=g1(p)*scale;}else{assert_eq!(size,128);p2+=g2(p)*scale;}if row!=rep{assert!(removed.insert(row));}}
        let bytes=if size==64{let p=p1.to_affine();encode(&[p.x,p.y])}else{let p=p2.to_affine();encode(&[p.x.c0,p.x.c1,p.y.c0,p.y.c1])};assert_eq!(bytes.len(),size);assert!(patches.insert(rep,bytes).is_none());
    }
    assert!(removed.iter().all(|&i|i<n));Fold{removed,patches}
}
fn stream_points(out:&mut impl Write,input:&[u8],size:usize,fold:&Fold){for(i,p)in input.chunks_exact(size).enumerate(){if !fold.removed.contains(&i){out.write_all(fold.patches.get(&i).map_or(p,|b|&b[..])).unwrap();}}}
fn stream_indices(out:&mut impl Write,input:&[u8],fold:&Fold){for(i,p)in input.chunks_exact(4).enumerate(){if !fold.removed.contains(&i){out.write_all(p).unwrap();}}}
fn main(){
    let args=std::env::args().collect::<Vec<_>>();assert_eq!(args.len(),4,"convert INPUT_EULER_V2 OUTPUT_IMAGE RESULT_JSON");
    assert_ne!(Path::new(&args[1]),Path::new(&args[2]));let file=fs::File::open(&args[1]).unwrap();
    // SAFETY: the pinned input is trusted and remains immutable throughout.
    let image=unsafe{memmap2::Mmap::map(&file).unwrap()};let raw=&image[..];let original_sha=hash(raw);assert_eq!(&raw[..16],b"zopro-euler-v2\0\0");
    let hl=u64at(raw,16);let head=&raw[24..24+hl];assert_eq!(&head[..16],b"zopro-key\0\0\0\0\0\0\0");assert_eq!(u32at(head,16),3);
    let counts=std::array::from_fn::<_,5,_>(|i|u32at(head,32+4*i));assert_eq!(counts[1],counts[4]);let domain=counts[3]+1;
    let meta_at=align(24+hl);let meta=&raw[meta_at..meta_at+128];let ns=u64at(meta,0);let np=u64at(meta,8);let mut at=meta_at+128;
    let mut ranges=Vec::new();for(count,size)in[(counts[0],64),(counts[1],64),(counts[2]+ns,64),(domain,64),(counts[4],128),(np,64)]{let end=at.checked_add(count.checked_mul(size).unwrap()).unwrap();assert!(end<=raw.len());ranges.push((at,end));at=end;}
    let slots_at=at;at=align(at+ns*8);let solver_len_at=at;let sl=u64at(raw,at);at+=8;let solver=&raw[at..at+sl];assert_eq!(at+sl,raw.len());assert_eq!(u32at(solver,24),counts[0]);assert_eq!(u32at(solver,28),counts[1]);
    let analysis=model::census(solver).unwrap();let cert=&analysis["folding_certificate"];let ai=&solver[52..52+counts[0]*4];let bi=&solver[52+counts[0]*4..52+(counts[0]+counts[1])*4];
    let get=|i:usize|&raw[ranges[i].0..ranges[i].1];let a=fold_points(get(0),64,&cert["A"],ai);let b=fold_points(get(1),64,&cert["B"],bi);let b2=fold_points(get(4),128,&cert["B"],bi);assert_eq!(b.removed,b2.removed);
    let na=counts[0]-a.removed.len();let nb=counts[1]-b.removed.len();let mut new_head=head.to_vec();new_head[32..36].copy_from_slice(&(na as u32).to_le_bytes());new_head[36..40].copy_from_slice(&(nb as u32).to_le_bytes());new_head[48..52].copy_from_slice(&(nb as u32).to_le_bytes());
    let mut sh=solver[..52].to_vec();sh[24..28].copy_from_slice(&(na as u32).to_le_bytes());sh[28..32].copy_from_slice(&(nb as u32).to_le_bytes());let remainder=&solver[52+(counts[0]+counts[1])*4..];let new_sl=sl-4*(a.removed.len()+b.removed.len());
    let output=fs::OpenOptions::new().write(true).create_new(true).open(&args[2]).unwrap();let mut out=BufWriter::with_capacity(65536,output);
    out.write_all(&raw[..24]).unwrap();out.write_all(&new_head).unwrap();out.write_all(&raw[24+hl..ranges[0].0]).unwrap();stream_points(&mut out,get(0),64,&a);stream_points(&mut out,get(1),64,&b);out.write_all(get(2)).unwrap();out.write_all(get(3)).unwrap();stream_points(&mut out,get(4),128,&b2);out.write_all(get(5)).unwrap();out.write_all(&raw[slots_at..solver_len_at]).unwrap();out.write_all(&(new_sl as u64).to_le_bytes()).unwrap();out.write_all(&sh).unwrap();stream_indices(&mut out,ai,&a);stream_indices(&mut out,bi,&b);out.write_all(remainder).unwrap();out.flush().unwrap();drop(out);
    assert_eq!(hash(raw),original_sha);let new_size=fs::metadata(&args[2]).unwrap().len()as usize;let saved=64*a.removed.len()+192*b.removed.len()+4*(a.removed.len()+b.removed.len());assert_eq!(new_size+saved,raw.len());
    let patch_bytes=a.patches.values().chain(b.patches.values()).chain(b2.patches.values()).map(Vec::len).sum::<usize>();
    let result=json!({"source_image_sha256":original_sha,"source_solver_sha256":hash(solver),"source_bytes":raw.len(),"output_bytes":new_size,"saved_image_bytes":saved,"original_a":counts[0],"original_b":counts[1],"folded_a":na,"folded_b":nb,"removed_a":a.removed.len(),"removed_b":b.removed.len(),"patch_point_payload_bytes":patch_bytes,"analysis":analysis,"prover_binary_changed":false,"runtime_analysis_graph":false});
    fs::write(&args[3],serde_json::to_vec_pretty(&result).unwrap()).unwrap();println!("FOLDED A:{}->{na} B:{}->{nb} image_bytes:{}->{new_size} patch_payload={patch_bytes}",counts[0],counts[1],raw.len());
}

#[cfg(test)]mod tests{
    use super::*;
    #[test]fn group_folding_matches_independent_generator_coefficients(){
        for n in[2usize,3,7,8,9,31]{let ids=(0..n).flat_map(|i|(i as u32).to_le_bytes()).collect::<Vec<_>>();let ms=(0..n).map(|i|json!({"row":i,"wire":i,"ratio_montgomery":(if i==0{Fr::ONE}else if i%2==0{-Fr::from((i+2)as u64)}else{Fr::from((i+2)as u64)}).0})).collect::<Vec<_>>();let cert=json!({"original_points":n,"zero_rows":[],"classes":[{"representative_row":0,"members":ms}]});let coefficient=(0..n).fold(Fr::ZERO,|x,i|x+Fr::from((i+23)as u64)*ratio(&cert["classes"][0]["members"][i]));
            let p1=(0..n).flat_map(|i|{let p=(G1Projective::generator()*Fr::from((i+23)as u64)).to_affine();encode(&[p.x,p.y])}).collect::<Vec<_>>();let p2=(0..n).flat_map(|i|{let p=(G2Projective::generator()*Fr::from((i+23)as u64)).to_affine();encode(&[p.x.c0,p.x.c1,p.y.c0,p.y.c1])}).collect::<Vec<_>>();let f1=fold_points(&p1,64,&cert,&ids);let f2=fold_points(&p2,128,&cert,&ids);assert_eq!(g1(&f1.patches[&0]),(G1Projective::generator()*coefficient).to_affine());assert_eq!(g2(&f2.patches[&0]),(G2Projective::generator()*coefficient).to_affine());assert_eq!(f1.removed.len(),n-1);assert_eq!(f2.removed.len(),n-1);}
    }
}
