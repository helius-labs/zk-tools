use std::{fs,path::Path};
fn main(){let dst=Path::new("/home/ubuntu/src/zopro-perf-work/static-query-fold204");let old=Path::new("/home/ubuntu/src/zopro-perf-work/semantic-cse176");
 for f in["semantic.rs","semantic-tests.rs"]{fs::copy(old.join(f),dst.join(f)).unwrap();}
 let mut m=fs::read_to_string(old.join("model.rs")).unwrap();
 let anchor="    let semantic_queries=queries.iter().zip([\"A\",\"B\"]).map(|(q,name)|(name,query_classes(q,&state))).collect::<BTreeMap<_,_>>();";
 assert_eq!(m.matches(anchor).count(),1);m=m.replace(anchor,&format!("{anchor}\n    let folding=queries.iter().zip([\"A\",\"B\"]).map(|(q,name)|(name,folding_classes(q,&state))).collect::<BTreeMap<_,_>>();"));
 let anchor="\"semantic_query_classes\":semantic_queries,";assert_eq!(m.matches(anchor).count(),1);m=m.replace(anchor,"\"folding_certificate\":folding,\"semantic_query_classes\":semantic_queries,");fs::write(dst.join("model.rs"),m).unwrap();
}
