fn certify_folding(queries:&[Vec<usize>;2],values:&[Option<Lc>],cert:&Value){
    for (q,name) in queries.iter().zip(["A","B"]) {
        let c=&cert[name];assert_eq!(c["original_points"],q.len());let mut covered=BTreeSet::new();
        for row in c["zero_rows"].as_array().unwrap(){let i=row.as_u64().unwrap()as usize;assert!(i<q.len()&&covered.insert(i));assert_eq!(constant(values[q[i]].as_ref().unwrap()),Some(Fr::ZERO));}
        let mut removed=covered.len();
        for class in c["classes"].as_array().unwrap(){
            let rep=class["representative_row"].as_u64().unwrap()as usize;assert!(rep<q.len());let members=class["members"].as_array().unwrap();assert!(members.len()>1);assert_eq!(members[0]["row"],rep);let reference=values[q[rep]].as_ref().unwrap();assert_ne!(constant(reference),Some(Fr::ZERO));
            for (i,m) in members.iter().enumerate(){let row=m["row"].as_u64().unwrap()as usize;assert!(row>=rep&&row<q.len()&&covered.insert(row));assert_eq!(m["wire"],q[row]);let w=std::array::from_fn(|i|m["ratio_montgomery"][i].as_u64().unwrap());assert!(w.iter().rev().cmp(Fr::MODULUS.iter().rev()).is_lt());let factor=Fr::from_montgomery(w);assert_ne!(factor,Fr::ZERO);if i==0{assert_eq!(factor,Fr::ONE);}assert_eq!(scale(reference,factor),*values[q[row]].as_ref().unwrap(),"invalid structural proportional certificate for {name}/{row}");}
            removed+=members.len()-1;
        }
        assert_eq!(q.len()-removed,query(q,values)["proportional_nonzero_classes"].as_u64().unwrap()as usize);
    }
}
