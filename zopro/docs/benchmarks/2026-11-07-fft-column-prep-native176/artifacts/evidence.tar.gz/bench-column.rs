use zopro_bn254::{Fr,FrConfig,ifma::Ifma,ifma8::{Ifma8,PackedIfma8}};
type Quad=Ifma<FrConfig>;
type Pair=Ifma8<FrConfig>;
pub type PackedPair=PackedIfma8<FrConfig>;
fn broadcast(q:&Quad)->Pair{Pair::from_halves(q,q)}
trait PairStorage:Copy+Send+Sync{fn load(&self)->Pair;fn store(value:Pair)->Self;}
impl PairStorage for PackedPair{#[inline(always)]fn load(&self)->Pair{self.expand()}#[inline(always)]fn store(value:Pair)->Self{value.compact()}}
pub struct Twiddles{pub layers:Vec<Vec<Quad>>,pub columns:Vec<Vec<Quad>>}
pub fn fixture_field(mut seed:u64)->Fr{let mut bytes=[0u8;64];for chunk in bytes.chunks_mut(8){seed=seed.wrapping_add(0x9e3779b97f4a7c15);let mut v=seed;v=(v^(v>>30)).wrapping_mul(0xbf58476d1ce4e5b9);v=(v^(v>>27)).wrapping_mul(0x94d049bb133111eb);v^=v>>31;chunk.copy_from_slice(&v.to_le_bytes());}Fr::from_random_bytes(&bytes)}
impl Twiddles{pub fn fixture(q:usize,level:usize,seed:u64)->Self{assert!(q>0);let mut layers=Vec::new();for _ in 0..level{layers.push(vec![]);}for stage in 0..5{let roots=(0..(16>>stage)*q).map(|i|Quad::new(&core::array::from_fn(|lane|{let k=i*4+lane+stage*137;match k%37{0=>Fr::from(0u64),1=>Fr::from(1u64),2=>-Fr::from(1u64),_=>fixture_field(seed.wrapping_add(k as u64))}}))).collect();layers.push(roots);}let mut columns=vec![vec![];level+5];let mut cached=Vec::with_capacity(31*q);for col in 0..q{for stage in 0..5{let gap=16>>stage;for j in 0..gap{cached.push(layers[level+stage][j*q+col]);}}}assert_eq!(cached.len(),31*q);columns[level]=cached;Self{layers,columns}}}

pub fn dispatch(values:&mut[PackedPair;32],roots:&Twiddles,level:usize,q:usize,column:usize,forward:bool,cached:bool,on:bool){
    #[cfg(zopro_fft_factor)]if on{if forward{prepared_column_leaf::<PackedPair,true>(values.each_mut(),roots,level,q,column,cached);}else{prepared_column_leaf::<PackedPair,false>(values.each_mut(),roots,level,q,column,cached);}return;}
    assert!(!on);if forward{stored_column_leaf::<PackedPair,true>(values.each_mut(),roots,level,q,column,cached);}else{stored_column_leaf::<PackedPair,false>(values.each_mut(),roots,level,q,column,cached);}
}

fn column_kernel<const CACHED: bool, const FORWARD: bool>(
    local: &mut [Pair; 32],
    roots: &Twiddles,
    level: usize,
    q: usize,
    column: usize,
) {
    for order in 0..5 {
        let stage = if FORWARD { 4 - order } else { order };
        let gap = 16 >> stage;
        for block in (0..32).step_by(2 * gap) {
            for j in 0..gap {
                let low = block + j;
                let high = low + gap;
                let root = if CACHED {
                    broadcast(&roots.columns[level][31 * column + 32 - 2 * gap + j])
                } else {
                    broadcast(&roots.layers[level + stage][j * q + column])
                };
                let (a, b) = (local[low], local[high]);
                if FORWARD {
                    let product = b.mul(&root);
                    local[low] = a.add(&product);
                    local[high] = a.sub(&product);
                } else {
                    local[low] = a.add(&b);
                    local[high] = a.sub(&b).mul(&root);
                }
            }
        }
    }
}
#[inline(never)]
fn stored_column_leaf<S: PairStorage, const FORWARD: bool>(
    values: [&mut S; 32], roots: &Twiddles, level: usize, q: usize,
    column: usize, cached: bool,
) {
    let [v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25, v26, v27, v28, v29, v30, v31] = values;
    let mut local = [
        v0.load(),
        v1.load(),
        v2.load(),
        v3.load(),
        v4.load(),
        v5.load(),
        v6.load(),
        v7.load(),
        v8.load(),
        v9.load(),
        v10.load(),
        v11.load(),
        v12.load(),
        v13.load(),
        v14.load(),
        v15.load(),
        v16.load(),
        v17.load(),
        v18.load(),
        v19.load(),
        v20.load(),
        v21.load(),
        v22.load(),
        v23.load(),
        v24.load(),
        v25.load(),
        v26.load(),
        v27.load(),
        v28.load(),
        v29.load(),
        v30.load(),
        v31.load(),
    ];
    if cached {
        column_kernel::<true, FORWARD>(&mut local, roots, level, q, column);
    } else {
        column_kernel::<false, FORWARD>(&mut local, roots, level, q, column);
    }
    *v0 = S::store(local[0]);
    *v1 = S::store(local[1]);
    *v2 = S::store(local[2]);
    *v3 = S::store(local[3]);
    *v4 = S::store(local[4]);
    *v5 = S::store(local[5]);
    *v6 = S::store(local[6]);
    *v7 = S::store(local[7]);
    *v8 = S::store(local[8]);
    *v9 = S::store(local[9]);
    *v10 = S::store(local[10]);
    *v11 = S::store(local[11]);
    *v12 = S::store(local[12]);
    *v13 = S::store(local[13]);
    *v14 = S::store(local[14]);
    *v15 = S::store(local[15]);
    *v16 = S::store(local[16]);
    *v17 = S::store(local[17]);
    *v18 = S::store(local[18]);
    *v19 = S::store(local[19]);
    *v20 = S::store(local[20]);
    *v21 = S::store(local[21]);
    *v22 = S::store(local[22]);
    *v23 = S::store(local[23]);
    *v24 = S::store(local[24]);
    *v25 = S::store(local[25]);
    *v26 = S::store(local[26]);
    *v27 = S::store(local[27]);
    *v28 = S::store(local[28]);
    *v29 = S::store(local[29]);
    *v30 = S::store(local[30]);
    *v31 = S::store(local[31]);
}
#[cfg(zopro_fft_factor)]
fn prepared_column_kernel<const CACHED: bool, const FORWARD: bool>(
    local: &mut [Pair; 32],
    roots: &Twiddles,
    level: usize,
    q: usize,
    column: usize,
) {
    for order in 0..5 {
        let stage = if FORWARD { 4 - order } else { order };
        let gap = 16 >> stage;
        if stage==4 {
            let root=if CACHED {broadcast(&roots.columns[level][31*column+30])}else{broadcast(&roots.layers[level+4][column])};
            let factor=root.prepare_fft_factor();
            for low in (0..32).step_by(2){let high=low+1;let(a,b)=(local[low],local[high]);if FORWARD{let product=b.mul_fft_factor(&factor);local[low]=a.add(&product);local[high]=a.sub(&product);}else{local[low]=a.add(&b);local[high]=a.sub(&b).mul_fft_factor(&factor);}}
            continue;
        }
        for block in (0..32).step_by(2 * gap) {
            for j in 0..gap {
                let low = block + j;
                let high = low + gap;
                let root = if CACHED {
                    broadcast(&roots.columns[level][31 * column + 32 - 2 * gap + j])
                } else {
                    broadcast(&roots.layers[level + stage][j * q + column])
                };
                let (a, b) = (local[low], local[high]);
                if FORWARD {
                    let product = b.mul(&root);
                    local[low] = a.add(&product);
                    local[high] = a.sub(&product);
                } else {
                    local[low] = a.add(&b);
                    local[high] = a.sub(&b).mul(&root);
                }
            }
        }
    }
}
#[cfg(zopro_fft_factor)]
#[inline(never)]
fn prepared_column_leaf<S: PairStorage, const FORWARD: bool>(
    values: [&mut S; 32], roots: &Twiddles, level: usize, q: usize,
    column: usize, cached: bool,
) {
    let [v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25, v26, v27, v28, v29, v30, v31] = values;
    let mut local = [
        v0.load(),
        v1.load(),
        v2.load(),
        v3.load(),
        v4.load(),
        v5.load(),
        v6.load(),
        v7.load(),
        v8.load(),
        v9.load(),
        v10.load(),
        v11.load(),
        v12.load(),
        v13.load(),
        v14.load(),
        v15.load(),
        v16.load(),
        v17.load(),
        v18.load(),
        v19.load(),
        v20.load(),
        v21.load(),
        v22.load(),
        v23.load(),
        v24.load(),
        v25.load(),
        v26.load(),
        v27.load(),
        v28.load(),
        v29.load(),
        v30.load(),
        v31.load(),
    ];
    if cached {
        prepared_column_kernel::<true, FORWARD>(&mut local, roots, level, q, column);
    } else {
        prepared_column_kernel::<false, FORWARD>(&mut local, roots, level, q, column);
    }
    *v0 = S::store(local[0]);
    *v1 = S::store(local[1]);
    *v2 = S::store(local[2]);
    *v3 = S::store(local[3]);
    *v4 = S::store(local[4]);
    *v5 = S::store(local[5]);
    *v6 = S::store(local[6]);
    *v7 = S::store(local[7]);
    *v8 = S::store(local[8]);
    *v9 = S::store(local[9]);
    *v10 = S::store(local[10]);
    *v11 = S::store(local[11]);
    *v12 = S::store(local[12]);
    *v13 = S::store(local[13]);
    *v14 = S::store(local[14]);
    *v15 = S::store(local[15]);
    *v16 = S::store(local[16]);
    *v17 = S::store(local[17]);
    *v18 = S::store(local[18]);
    *v19 = S::store(local[19]);
    *v20 = S::store(local[20]);
    *v21 = S::store(local[21]);
    *v22 = S::store(local[22]);
    *v23 = S::store(local[23]);
    *v24 = S::store(local[24]);
    *v25 = S::store(local[25]);
    *v26 = S::store(local[26]);
    *v27 = S::store(local[27]);
    *v28 = S::store(local[28]);
    *v29 = S::store(local[29]);
    *v30 = S::store(local[30]);
    *v31 = S::store(local[31]);
}

impl Twiddles{
    pub fn fft_fixture(q:usize,forward:bool)->Self{
        assert!(q.is_power_of_two());let n=128*q;let mut generator=Fr::root_of_unity(n).unwrap();if !forward{generator=generator.inverse().unwrap();}
        let mut layers=Vec::new();for stage in 0..5{let step=generator.pow(&[1u64<<stage]);let mut value=Fr::from(1u64);let mut groups=Vec::with_capacity((16>>stage)*q);for _ in 0..(16>>stage)*q{let group=core::array::from_fn(|_|{let out=value;value*=step;out});groups.push(Quad::new(&group));}layers.push(groups);}
        let mut cached=Vec::with_capacity(31*q);for column in 0..q{for stage in 0..5{let gap=16>>stage;for j in 0..gap{cached.push(layers[stage][j*q+column]);}}}assert_eq!(cached.len(),31*q);
        Self{layers,columns:vec![cached]}
    }
    pub fn payload_bytes(&self)->usize{self.layers.iter().chain(&self.columns).map(|v|v.capacity()*std::mem::size_of::<Quad>()).sum()}
}
