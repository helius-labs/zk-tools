set -eu
root=/home/ubuntu/src/zopro-perf-work/fft-column-prep-native176
count=0
for receipt in "$root"/codegen/*/exit.json; do
    jq -e '.success == true and .returncode == 0' "$receipt" > /dev/null
    base=${receipt%/exit.json}
    for stream in stdout stderr; do
        expected=$(jq -r --arg k "${stream}_sha256" '.[$k]' "$receipt")
        actual=$(sha256sum "$base/$stream.log")
        test "${actual%% *}" = "$expected"
    done
    count=$((count+1))
done
test "$count" = 8
jq -n --argjson count "$count" '{passed:true,codegen_receipts_verified:$count,streams_sha256_verified:16,codegen_or_decoder_replayed:false}' > "$root/codegen-review.json"
