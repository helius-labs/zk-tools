use zopro_bn254::{Fr,FrConfig,ifma::Ifma,ifma8::{Ifma8,PackedIfma8}};
type Quad=Ifma<FrConfig>;
type Pair=Ifma8<FrConfig>;
pub type PackedPair=PackedIfma8<FrConfig>;
fn broadcast(q:&Quad)->Pair{Pair::from_halves(q,q)}
trait PairStorage:Copy+Send+Sync{fn load(&self)->Pair;fn store(value:Pair)->Self;}
impl PairStorage for PackedPair{#[inline(always)]fn load(&self)->Pair{self.expand()}#[inline(always)]fn store(value:Pair)->Self{value.compact()}}
pub struct Twiddles{pub layers:Vec<Vec<Quad>>,pub columns:Vec<Vec<Quad>>}
pub fn fixture_field(mut seed:u64)->Fr{let mut bytes=[0u8;64];for chunk in bytes.chunks_mut(8){seed=seed.wrapping_add(0x9e3779b97f4a7c15);let mut v=seed;v=(v^(v>>30)).wrapping_mul(0xbf58476d1ce4e5b9);v=(v^(v>>27)).wrapping_mul(0x94d049bb133111eb);v^=v>>31;chunk.copy_from_slice(&v.to_le_bytes());}Fr::from_random_bytes(&bytes)}
impl Twiddles{pub fn fixture(q:usize,level:usize,seed:u64)->Self{assert!(q>0);let mut layers=Vec::new();for _ in 0..level{layers.push(vec![]);}for stage in 0..5{let roots=(0..(16>>stage)*q).map(|i|Quad::new(&core::array::from_fn(|lane|{let k=i*4+lane+stage*137;match k%37{0=>Fr::from(0u64),1=>Fr::from(1u64),2=>-Fr::from(1u64),_=>fixture_field(seed.wrapping_add(k as u64))}}))).collect();layers.push(roots);}let mut columns=vec![vec![];level+5];let mut cached=Vec::with_capacity(31*q);for col in 0..q{for stage in 0..5{let gap=16>>stage;for j in 0..gap{cached.push(layers[level+stage][j*q+col]);}}}assert_eq!(cached.len(),31*q);columns[level]=cached;Self{layers,columns}}}

pub fn dispatch(values:&mut[PackedPair;32],roots:&Twiddles,level:usize,q:usize,column:usize,forward:bool,cached:bool,on:bool){
    #[cfg(zopro_fft_factor)]if on{if forward{prepared_column_leaf::<PackedPair,true>(values.each_mut(),roots,level,q,column,cached);}else{prepared_column_leaf::<PackedPair,false>(values.each_mut(),roots,level,q,column,cached);}return;}
    assert!(!on);if forward{stored_column_leaf::<PackedPair,true>(values.each_mut(),roots,level,q,column,cached);}else{stored_column_leaf::<PackedPair,false>(values.each_mut(),roots,level,q,column,cached);}
}
