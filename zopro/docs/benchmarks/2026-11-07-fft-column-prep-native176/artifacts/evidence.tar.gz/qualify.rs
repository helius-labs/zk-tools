use num_bigint::BigUint;use num_traits::{One,ToPrimitive,Zero};use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,mem::size_of};
use zopro_bn254::{Fp,FpConfig,FqConfig,FrConfig,ifma8::Ifma8};
mod column;
const R:&str="/home/ubuntu/src/zopro-perf-work/fft-column-prep-native176";
fn integer(words:&[u64],bits:usize)->BigUint{words.iter().rev().fold(BigUint::zero(),|n,&v|(n<<bits)+v)}
fn words(n:&BigUint)->[u64;4]{let v=n.to_u64_digits();assert!(v.len()<=4);core::array::from_fn(|i|v.get(i).copied().unwrap_or(0))}
fn from_big<C:FpConfig>(n:&BigUint)->Fp<C>{Fp::from_canonical(words(n)).unwrap()}
fn check<C:FpConfig>(name:&str,model:&Value)->Value{
    let p=integer(&C::P,64);let radix=BigUint::one()<<260;let expected_mu=&radix*&radix/&p;assert_eq!(integer(&Ifma8::<C,false>::fft_factor_mu(),52),expected_mu);
    assert_eq!(size_of::<zopro_bn254::ifma8::FftFactor8<C>>(),640);
    let row=model["rows"].as_array().unwrap().iter().find(|r|r["name"]==name).unwrap();let special=BigUint::parse_bytes(row["examples"][1]["b"].as_str().unwrap().as_bytes(),16).unwrap();
    let mut roots=vec![BigUint::zero(),BigUint::one(),BigUint::from(2u8),&p-1u8,&p-2u8,special];
    for bit in 0..254usize{let n=BigUint::one()<<bit;for delta in[-1i64,0,1]{if delta<0&&n.is_zero(){continue;}let value=if delta<0{&n-1u8}else{&n+delta as u64};if value<p{roots.push(value);}}}
    for i in 0..1024u64{let mut h=Sha256::new();h.update(b"native-new-FFT-factor176");h.update(name.as_bytes());h.update(i.to_le_bytes());roots.push(BigUint::from_bytes_le(&h.finalize())%&p);}
    let mut correction_lanes=0u64;let mut checked=0u64;let mut products=0u64;let mut digest=Sha256::new();
    for offset in (0..roots.len()).step_by(8){for lazy in[false,true]{let canonical:Vec<BigUint>=(0..8).map(|i|roots[(offset+i)%roots.len()].clone()).collect();let raw=core::array::from_fn(|i|{let mut v=&canonical[i]*&radix%&p;if lazy&&i%2==0{v+=&p;}words(&v)});
        let root=Ifma8::<C,false>::fft_factor_diagnostic_root(raw);let (factor,mask)=root.prepare_fft_factor_with_mask();let (b,c)=factor.diagnostic_words();correction_lanes+=mask.count_ones()as u64;
        for lane in 0..8{let bv=integer(&b.map(|row|row[lane]),52);let cv=integer(&c.map(|row|row[lane]),52);assert_eq!(bv,canonical[lane]);assert_eq!(cv,&canonical[lane]*&radix/&p);assert!(b.iter().chain(c.iter()).all(|row|row[lane]<(1<<52)));if canonical[lane]==roots[5]{assert_ne!(mask&(1<<lane),0,"rare correction must execute");}digest.update(cv.to_bytes_le());checked+=1;}
        let a: [Fp<C>;8]=core::array::from_fn(|i|from_big::<C>(&((&canonical[(i+3)%8]+17u8+offset)%&p)));
        let result=Ifma8::<C,false>::new(&a).mul_fft_factor(&factor);let rw=result.fft_factor_value_words();let out=result.get();
        let mixed=Ifma8::<C,true>::new(&a).mul_fft_factor(&factor);let mw=mixed.fft_factor_value_words();let mout=mixed.get();
        for lane in 0..8{let expected=integer(&a[lane].to_canonical(),64)*&canonical[lane]%&p;assert_eq!(integer(&out[lane].to_canonical(),64),expected);assert_eq!(integer(&mout[lane].to_canonical(),64),expected);for rawwords in[&rw,&mw]{assert!(rawwords.iter().all(|r|r[lane]<(1<<52)));assert!(integer(&rawwords.map(|r|r[lane]),52)<&p*2u8);}products+=2;}
    }}assert!(correction_lanes>0);json!({"field":name,"native_prepared_lanes":checked,"native_product_lanes":products,"correction_lanes":correction_lanes,"root_domain":"canonical and lazyR260 roots, ordinaryfactor quotient exact; variableoperandsR260/R256","digest":format!("{:x}",digest.finalize()),"passed":true})
}
fn scalar_column(mut input:[[zopro_bn254::Fr;8];32],roots:&column::Twiddles,level:usize,q:usize,col:usize,forward:bool,cached:bool)->[[zopro_bn254::Fr;8];32]{
    for step in 0..5{let stage=if forward{4-step}else{step};let bit=4-stage;for low in 0..32{if low&(1<<bit)!=0{continue;}let high=low|(1<<bit);let j=low&((1<<bit)-1);let root=if cached{roots.columns[level][31*col+32-2*(1<<bit)+j].get()}else{roots.layers[level+stage][j*q+col].get()};for lane in 0..8{let(a,b)=(input[low][lane],input[high][lane]);let w=root[lane%4];if forward{let bw=b*w;input[low][lane]=a+bw;input[high][lane]=a-bw;}else{input[low][lane]=a+b;input[high][lane]=(a-b)*w;}}}}
    input
}
fn columns()->Value{
    use zopro_bn254::{Fr,ifma8::Ifma8};let mut total=0usize;
    for workers in[1usize,16,32]{let jobs:Vec<_>=(0..workers).map(|worker|std::thread::Builder::new().stack_size(512*1024).spawn(move||{
        let mut checked=0usize;for q in[1usize,4,16]{for level in[0usize,2]{let roots=column::Twiddles::fixture(q,level,worker as u64+23);for col in[0,q/2,q-1]{for forward in[false,true]{for cached in[false,true]{for pattern in 0..3{let mut values:[[Fr;8];32]=core::array::from_fn(|i|core::array::from_fn(|lane|match pattern{0=>Fr::from(0u64),1=>if(i+lane)%3==0{-Fr::from(1u64)}else{Fr::from(((i+lane)%3)as u64)},_=>column::fixture_field(((worker+1)*65537+i*97+lane*101)as u64)}));for update in 0..2{let expected=scalar_column(values,&roots,level,q,col,forward,cached);let packed=values.map(|r|Ifma8::new(&r).compact());let mut old=packed;let mut new=packed;column::dispatch(&mut old,&roots,level,q,col,forward,cached,false);column::dispatch(&mut new,&roots,level,q,col,forward,cached,true);for i in 0..32{assert_eq!(old[i].expand().get(),expected[i]);assert_eq!(new[i].expand().get(),expected[i]);}checked+=32*8;values=expected;values[(worker+update)%32][worker%8]+=Fr::from(1u64);}}}}}}}checked
    }).unwrap()).collect();for j in jobs{total+=j.join().unwrap();}}
    json!({"passed":true,"canonical_output_comparisons_per_arm":total,"workers":[1,16,32],"configured_stack_bytes":512*1024,"directions":2,"layouts":2,"strides":[1,4,16],"level_offsets":[0,2],"patterns":3,"changing_updates":2})
}
fn main(){let path=format!("{R}/native-qualification.json");assert!(!std::path::Path::new(&path).exists());let model:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zopro-perf-work/fft-column-prep176/model-result.json").unwrap()).unwrap();let fields=[check::<FqConfig>("Fq",&model),check::<FrConfig>("Fr",&model)];let columns=columns();let out=json!({"passed":true,"fields":fields,"complete_columns":columns,"prepared_size_bytes":640,"old_field_tests_and_scalar_model_replayed":false,"new_proofs":0,"latency_measured":false});fs::write(path,serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("{}",serde_json::to_string(&out).unwrap());}
