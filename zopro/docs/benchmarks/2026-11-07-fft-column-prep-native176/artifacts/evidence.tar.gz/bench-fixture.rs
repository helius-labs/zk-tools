impl Twiddles{
    pub fn fft_fixture(q:usize,forward:bool)->Self{
        assert!(q.is_power_of_two());let n=128*q;let mut generator=Fr::root_of_unity(n).unwrap();if !forward{generator=generator.inverse().unwrap();}
        let mut layers=Vec::new();for stage in 0..5{let step=generator.pow(&[1u64<<stage]);let mut value=Fr::from(1u64);let mut groups=Vec::with_capacity((16>>stage)*q);for _ in 0..(16>>stage)*q{let group=core::array::from_fn(|_|{let out=value;value*=step;out});groups.push(Quad::new(&group));}layers.push(groups);}
        let mut cached=Vec::with_capacity(31*q);for column in 0..q{for stage in 0..5{let gap=16>>stage;for j in 0..gap{cached.push(layers[stage][j*q+column]);}}}assert_eq!(cached.len(),31*q);
        Self{layers,columns:vec![cached]}
    }
    pub fn payload_bytes(&self)->usize{self.layers.iter().chain(&self.columns).map(|v|v.capacity()*std::mem::size_of::<Quad>()).sum()}
}
