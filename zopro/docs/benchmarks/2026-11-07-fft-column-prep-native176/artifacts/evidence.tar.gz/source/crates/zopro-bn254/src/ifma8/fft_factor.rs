use super::*;

// Compile-time exact reciprocal; six radix-52 digits, no runtime table/build.
const fn reciprocal(p: [u64;4]) -> [u64;6] {
    assert!(p[3] >= 1u64<<61 && p[3] < 1u64<<62);
    let mut rem=[1u64,0,0,0];let mut q=[0u64;6];let mut bit=0;
    while bit<520 {let mut carry=0;let mut j=0;while j<4 {let next=rem[j]>>63;rem[j]=(rem[j]<<1)|carry;carry=next;j+=1;}assert!(carry==0);
        let mut ge=true;let mut j=4;while j>0{j-=1;if rem[j]!=p[j]{ge=rem[j]>p[j];break;}}
        if ge {let mut borrow=0u128;let mut j=0;while j<4 {let sub=p[j]as u128+borrow;let value=(1u128<<64)+rem[j]as u128-sub;rem[j]=value as u64;borrow=1-(value>>64);j+=1;}assert!(borrow==0);}
        let mut carry=ge as u64;let mut j=0;while j<6 {let value=(q[j]<<1)|carry;q[j]=value&MASK;carry=value>>52;j+=1;}assert!(carry==0);bit+=1;
    }q
}

#[derive(Clone,Copy)]
pub struct FftFactor8<C:FpConfig>{b:[__m512i;5],quotient:[__m512i;5],marker:PhantomData<C>}

impl<C:FpConfig> Ifma8<C,false> {
    #[inline(always)]
    pub fn prepare_fft_factor(&self)->FftFactor8<C>{self.prepare_fft_factor_with_mask().0}

    #[inline(always)]
    pub fn prepare_fft_factor_with_mask(&self)->(FftFactor8<C>,u8){
        // Existing REDC decodes the root's R260 numerical representation.
        // The canonical ordinary factor is confined to this opaque object.
        let decoded=self.mul(&Self::constant([1,0,0,0]));
        let b=Self::reduce(decoded.0,C::P).0;
        // SAFETY: this module is compiled under the original AVX512 guards.
        // Digits are normalized; every accumulator magnitude is below11*2^52.
        unsafe{
            let zero=Self::splat(0);let mask=Self::splat(MASK);
            let mu=const{reciprocal(C::P)}.map(Self::splat);
            let p=split(C::P).map(Self::splat);
            let mut high=[zero;7];
            for i in 0..5{for j in 0..6{let k=i+j;if k==3{high[0]=_mm512_madd52hi_epu64(high[0],b[i],mu[j]);}else if k>=4{high[k-4]=_mm512_madd52lo_epu64(high[k-4],b[i],mu[j]);high[k-3]=_mm512_madd52hi_epu64(high[k-3],b[i],mu[j]);}}}
            for j in 0..6{high[j+1]=_mm512_add_epi64(high[j+1],_mm512_srli_epi64::<52>(high[j]));high[j]=_mm512_and_si512(high[j],mask);}
            let mut quotient=[high[1],high[2],high[3],high[4],high[5]];
            let mut remainder=[zero;5];
            for i in 0..5{for j in 0..5-i{let k=i+j;remainder[k]=_mm512_sub_epi64(remainder[k],_mm512_madd52lo_epu64(zero,quotient[i],p[j]));if k<4{remainder[k+1]=_mm512_sub_epi64(remainder[k+1],_mm512_madd52hi_epu64(zero,quotient[i],p[j]));}}}
            let mut carry=zero;for value in &mut remainder{let v=_mm512_add_epi64(*value,carry);*value=_mm512_and_si512(v,mask);carry=_mm512_srai_epi64::<52>(v);}
            let mut borrow=zero;for j in 0..5{let v=_mm512_add_epi64(_mm512_sub_epi64(remainder[j],p[j]),borrow);borrow=_mm512_srai_epi64::<52>(v);}
            let correction=_mm512_cmpeq_epi64_mask(borrow,zero);
            let mut carry=_mm512_maskz_mov_epi64(correction,Self::splat(1));
            for value in &mut quotient{let v=_mm512_add_epi64(*value,carry);*value=_mm512_and_si512(v,mask);carry=_mm512_srli_epi64::<52>(v);}
            (FftFactor8{b,quotient,marker:PhantomData},correction)
        }
    }

    #[cfg(zopro_fft_factor_diagnostics)]
    pub fn fft_factor_diagnostic_root(raw:[[u64;4];8])->Self{
        let twice=crate::portable::add4(C::P,C::P).0;
        assert!(raw.iter().all(|v|crate::portable::less(*v,twice)));
        Self::raw(&raw)
    }

    #[cfg(zopro_fft_factor_diagnostics)]
    pub fn fft_factor_mu()->[u64;6]{const{reciprocal(C::P)}}
}

#[cfg(zopro_fft_factor_diagnostics)]
fn words(v:[__m512i;5])->[[u64;8];5]{
    // SAFETY: each destination row contains64 initialized bytes.
    unsafe{core::array::from_fn(|j|{let mut row=[0u64;8];_mm512_storeu_si512(row.as_mut_ptr().cast(),v[j]);row})}
}
#[cfg(zopro_fft_factor_diagnostics)]
impl<C:FpConfig> FftFactor8<C>{pub fn diagnostic_words(&self)->([[u64;8];5],[[u64;8];5]){(words(self.b),words(self.quotient))}}
#[cfg(zopro_fft_factor_diagnostics)]
impl<C:FpConfig,const MIXED:bool> Ifma8<C,MIXED>{pub fn fft_factor_value_words(&self)->[[u64;8];5]{words(self.0)}}

impl<C:FpConfig,const MIXED:bool> Ifma8<C,MIXED>{
    #[inline(always)]
    pub fn mul_fft_factor(&self, factor: &FftFactor8<C>) -> Self {
        unsafe {
            let zero = Self::splat(0);
            let mask = Self::splat(MASK);
            // Limb four and above of the product, with one guard limb.
            let mut high = [zero; 6];
            for i in 0..5 {
                for j in 0..5 {
                    let k = i + j;
                    if k == 3 {
                        high[0] = _mm512_madd52hi_epu64(high[0], self.0[i], factor.quotient[j]);
                    } else if k >= 4 {
                        high[k - 4] =
                            _mm512_madd52lo_epu64(high[k - 4], self.0[i], factor.quotient[j]);
                        high[k - 3] =
                            _mm512_madd52hi_epu64(high[k - 3], self.0[i], factor.quotient[j]);
                    }
                }
            }
            for j in 0..5 {
                high[j + 1] = _mm512_add_epi64(high[j + 1], _mm512_srli_epi64::<52>(high[j]));
                high[j] = _mm512_and_si512(high[j], mask);
            }
            let q = [high[1], high[2], high[3], high[4], high[5]];
            let p = split(C::P).map(Self::splat);
            let mut out = [zero; 5];
            for i in 0..5 {
                for j in 0..5 - i {
                    let k = i + j;
                    out[k] = _mm512_sub_epi64(
                        _mm512_madd52lo_epu64(out[k], self.0[i], factor.b[j]),
                        _mm512_madd52lo_epu64(zero, q[i], p[j]),
                    );
                    if k < 4 {
                        out[k + 1] = _mm512_sub_epi64(
                            _mm512_madd52hi_epu64(out[k + 1], self.0[i], factor.b[j]),
                            _mm512_madd52hi_epu64(zero, q[i], p[j]),
                        );
                    }
                }
            }
            // Coefficients have signed magnitude below 2^57. IFMA's
            // wrapping accumulator adds exactly in this signed range.
            let mut carry = zero;
            for digit in &mut out {
                let v = _mm512_add_epi64(*digit, carry);
                *digit = _mm512_and_si512(v, mask);
                carry = _mm512_srai_epi64::<52>(v);
            }
            // Low-product truncation discards high terms. The carry out
            // can be nonzero; the proved remainder modulo R is below2p.
            Self(out, PhantomData)
        }
    }
}
