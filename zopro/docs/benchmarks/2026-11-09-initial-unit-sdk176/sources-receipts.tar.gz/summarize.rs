use serde_json::{json,Value};use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/initial-unit-sdk176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(f:&str,v:Value){fs::write(format!("{R}/{f}"),serde_json::to_vec_pretty(&v).unwrap()).unwrap()}
fn main(){
 assert!(!Path::new(&format!("{R}/diagnostic-summary.json")).exists());let a=read(format!("{R}/analysis.json"));let review=read(format!("{R}/review-result.json"));assert_eq!(review["passed"],true);assert_eq!(a["gate_passed"],false);assert_eq!(a["failed_checks"].as_array().unwrap().len(),4);
 let symbols=read(format!("{R}/profile-symbols.json"));let mut rows=Vec::new();
 for case in["1x2-w32","1x2-w16","2x2-w32"]{
  let mut pmu=json!({});let mut shares=json!({});for arm in["REF","OFF","ON"]{
   pmu[arm]=a["counters"][format!("stat-{case}-{arm}-b00")]["per_proof"].clone();
   let name=format!("cycles-{case}-{arm}-b00");let selected=symbols[&name].as_array().unwrap().iter().filter(|v|{let s=v["symbol"].as_str().unwrap();["stream_g1_impl","g2_borrowed::apply","inverse::inverse","add_affine","initial_unit::add","crossbeam_epoch","reduce_layer","balanced::feed","take_local_job"].iter().any(|needle|s.contains(needle))}).cloned().collect::<Vec<_>>();shares[arm]=json!(selected);
  }
  let mut ratios=json!({});for den in["OFF","REF"]{let mut values=json!({});for event in["cycles:u","instructions:u","cache-misses:u","branch-misses:u"]{values[event]=json!(pmu["ON"][event].as_f64().unwrap()/pmu[den][event].as_f64().unwrap());}ratios[den]=values;}
  rows.push(json!({"case":case,"per_proof":pmu,"ON_control_ratios":ratios,"selected_flat_sample_shares":shares,"single_PMU_panel_not_replicated_CI":true,"flat_samples_not_wall_critical_path_or_exclusive_cause":true}));
 }
 let profiles=a["profiles"].as_object().unwrap();let total=profiles.values().map(|v|v["samples"].as_u64().unwrap()).sum::<u64>();assert_eq!(total,119775);
 let diagnostics=json!({"rows":rows,"profile_samples":total,"min_profile_samples":profiles.values().map(|v|v["samples"].as_u64().unwrap()).min().unwrap(),"max_unknown_share":profiles.values().map(|v|v["unknown_share"].as_f64().unwrap()).fold(0f64,f64::max),"all_profiles_qualified":profiles.values().all(|v|v["qualified"]==true),"all_zero_LOST":profiles.values().all(|v|v["zero_lost"]==true),"no_new_measurement_or_decode":true,"no_unique_stall_or_memory_cause_inferred":true});save("diagnostic-summary.json",diagnostics.clone());
 let cases=read(format!("{R}/measure-cases.json"));let mut comparison=Vec::new();
 for c in cases.as_array().unwrap().iter().filter(|v|v["workers"]==32&&v["shape"]!="merge-54x1"){
  let n=c["name"].as_str().unwrap();let cpu=c["reference"]["cpu_ms"].as_f64().unwrap();let metal=c["reference"]["metal_ms"].as_f64().unwrap();let get=|arm:&str|a["cells"][format!("{n}/{arm}")]["median_ms"].as_f64().unwrap();
  comparison.push(json!({"shape":c["shape"],"REF_CPU_ms":get("REF"),"OFF_CPU_ms":get("OFF"),"candidate_CPU_ms":get("ON"),"REF_peak_RSS_MiB":a["cells"][format!("{n}/REF")]["max_RSS_MiB"],"candidate_peak_RSS_MiB":a["cells"][format!("{n}/ON")]["max_RSS_MiB"],"M5_CPU_ms":cpu,"M5_Metal_ms":metal,"REF_CPU_speedup":cpu/get("REF"),"REF_Metal_speedup":metal/get("REF"),"candidate_CPU_speedup":cpu/get("ON"),"candidate_Metal_speedup":metal/get("ON"),"CPU_10x_target_ms":cpu/10.,"REF_target_met":get("REF")<=cpu/10.,"candidate_target_met":get("ON")<=cpu/10.}));
 }
 assert_eq!(comparison.len(),8);assert!(comparison.iter().all(|v|v["REF_target_met"]==false&&v["candidate_target_met"]==false));
 save("fresh-comparison.json",json!({"rows":comparison,"accepted_binary_unchanged":true,"candidate_adopted":false,"fresh_matched_campaign":true,"M5_references_supplied_not_remeasured":true,"CPU_10x_targets_met":0}));
 let checks=a["checks"].as_object().unwrap();let group=|suffix:&str|checks.iter().filter(|(k,_)|k.ends_with(suffix)).all(|(_,v)|v==&true);
 for suffix in["/calibration","/RSS","/nonregression","/PMU-quality","/profile-quality"]{assert!(group(suffix));}
 save("decision.json",json!({"adopted":false,"gate_passed":false,"passed_checks":75,"failed_checks":a["failed_checks"],"all11_control_calibrations_passed":true,"all22_RSS_checks_passed":true,"all22_nonregression_checks_passed":true,"all18_diagnostic_checks_passed":true,"close_exact_initial_unit_state_recipe":true,"no_unchanged_recapture_or_layout_threshold_curve_shape_worker_subset_rescue":true,"primary_component_ON_OFF_gain_retained":true,"primary_OFF_gain_does_not_establish_accepted_REF_gain":true,"production_unchanged":true,"selected_next":"Distinct bulk-work/dependency mechanism in dominant packed G1/G2 affine streams; initial-unit tagging and global unit-Z recipes remain closed","new_stage_SDK_requests":44210,"new_stage_unique_Gnark_exports":635,"canonical_proofs":43073,"goal_active":true,"goal_complete":false,"CPU_10x_targets_met":0}));
 for row in diagnostics["rows"].as_array().unwrap(){println!("{} ON/OFF {};ON/REF {}",row["case"],row["ON_control_ratios"]["OFF"],row["ON_control_ratios"]["REF"]);}println!("Profiles={total},min={},unknownmax={};decision4/79fail;canonical43073",diagnostics["min_profile_samples"],diagnostics["max_unknown_share"]);
}
