fn provenance_receipt(root:&Path,step:&Value,failed:bool){
 let dir=root.join(step["name"].as_str().unwrap());let exit=read(dir.join("exit.json"));assert_eq!(exit["returncode"],if failed{1}else{0});assert_eq!(exit["success"],!failed);
 let cmd=read(dir.join("command.json"));let a=cmd["argv"].as_array().unwrap();assert_eq!(a[0],"timeout");assert_eq!(a[1],"-k");assert_eq!(a[2],"5s");assert_eq!(a[3],format!("{}s",step["timeout_seconds"]));assert_eq!(&a[4..],step["argv"].as_array().unwrap());
 for(k,v)in step["environment"].as_object().into_iter().flatten(){if !k.starts_with("CARGO_"){assert_eq!(cmd["environment"][k],*v);}}
 for s in["stdout","stderr"]{assert_eq!(hash(dir.join(format!("{s}.log"))),exit[format!("{s}_sha256")]);}
}
fn source_provenance()->Value{
 const P:&str="/home/ubuntu/src/zopro-perf-work/initial-unit176";
 const Z:&str="/home/ubuntu/src/zk-tools/zopro";
 let accepted=read(format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json"));assert_eq!(accepted["adopted"],true);
 let q=read(format!("{P}/review-result.json"));assert_eq!(q["passed"],true);assert_eq!(q["native_OFF_tests_passed"],4);assert_eq!(q["native_ON_tests_passed"],4);assert_eq!(q["generic_ON_tests_passed"],3);assert_eq!(q["field_unchanged"],true);
 for file in["repair-pins.json","sdk-build-pins.json"]{for(p,h)in read(format!("{P}/{file}")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}}
 let old_pins=read(format!("{P}/pins.json"));for(p,h)in old_pins.as_object().unwrap(){let prefix=format!("{P}/");let rel=p.strip_prefix(&prefix).unwrap_or("");let old=["prepare.rs","source/crates/zopro-core/src/msm_affine/g2_borrowed.rs","source-audit.json"].contains(&rel);let file=if old{format!("{P}/before-test-type-fix/{rel}")}else{p.to_owned()};assert_eq!(hash(file),h.as_str().unwrap());}
 let audit=read(r("source-audit.json"));assert_eq!(audit,read(format!("{P}/source-audit.json")));assert_eq!(audit["originals"],accepted["source_files_sha256"]);let originals=audit["originals"].as_object().unwrap();assert_eq!(originals.len(),176);let mut exact=0;
 for(rel,h)in originals{assert_eq!(hash(format!("{Z}/{rel}")),h.as_str().unwrap());let path=format!("{P}/source/{rel}");let mut bytes=fs::read(path).unwrap();if let Some(e)=audit["edits"].as_array().unwrap().iter().find(|e|e["path"]==rel.as_str()){
  let mut text=String::from_utf8(bytes).unwrap();let suffix=e["suffix"].as_str().unwrap();if !suffix.is_empty(){assert!(text.ends_with(suffix));text.truncate(text.len()-suffix.len());}
  for change in e["replacements"].as_array().unwrap().iter().rev(){let after=change["after"].as_str().unwrap();assert_eq!(text.matches(after).count(),1);text=text.replace(after,change["before"].as_str().unwrap());}bytes=text.into_bytes();
 }else{exact+=1;}assert_eq!(format!("{:x}",Sha256::digest(bytes)),h.as_str().unwrap());}assert_eq!(exact,173);
 let extra=audit["extra"].as_str().unwrap();assert_eq!(hash(format!("{P}/source/{extra}")),hash(format!("{P}/initial_unit.rs")));
 let initial=read(format!("{P}/plan.json"));let steps=initial["steps"].as_array().unwrap();assert_eq!(steps.len(),8);for s in &steps[..2]{provenance_receipt(Path::new(&format!("{P}/runs")),s,false);}provenance_receipt(Path::new(&format!("{P}/runs")),&steps[2],true);
 let repaired=read(format!("{P}/repair-plan.json"));let fixed=repaired["steps"].as_array().unwrap();assert_eq!(fixed.len(),6);assert_eq!(read(format!("{P}/repaired-runs/result.json"))["status"],"complete");for s in fixed{provenance_receipt(Path::new(&format!("{P}/repaired-runs")),s,false);}
 let old="for p in &mut expected {p.x *= beta;}";let new="for p in &mut expected {p.x.c0 *= beta; p.x.c1 *= beta;}";
 let g2="source/crates/zopro-core/src/msm_affine/g2_borrowed.rs";let before=fs::read_to_string(format!("{P}/before-test-type-fix/{g2}")).unwrap();let after=fs::read_to_string(format!("{P}/{g2}")).unwrap();assert_eq!(before.replace(old,new),after);let test=after.find("#[cfg(test)]\nmod initial_unit_qualification").unwrap();assert!(!after[..test].contains(new));assert!(after[test..].contains(new));
 for arm in["OFF-test","ON-test","generic-ON-test"]{let log=format!("{P}/repaired-runs/qualify-{arm}/stdout.log");assert_eq!(hash(&log),q["qualification"][arm]["sha256"]);let t=fs::read_to_string(log).unwrap();assert!(t.contains("INITIAL_UNIT_INDEPENDENT checks=2048"));assert!(t.contains("INITIAL_UNIT_ENCODING checks=60"));assert!(t.contains("cases: 69"));assert!(t.contains("WORKERS=53 CONCURRENT_CALLERS=4"));}
 let links=read(r("link-review.json"));assert_eq!(links,read(format!("{P}/link-review.json")));assert_eq!(links["passed"],true);assert_eq!(links["coherent_native_artifacts"],8);assert_eq!(links["release_qualification_helpers_absent"],true);
 let sdk=read(format!("{P}/sdk-build-plan.json"));let downstream=sdk["steps"].as_array().unwrap();assert_eq!(downstream.len(),6);assert_eq!(read(format!("{P}/sdk-build-runs/result.json"))["status"],"complete");for s in downstream{provenance_receipt(Path::new(&format!("{P}/sdk-build-runs")),s,false);}
 let field="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/frozen/candidate/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib";
 for arm in["OFF","ON"]{
  let id=&links["identities"][arm];assert_eq!(id["binary"],format!("{P}/sdk-{arm}"));assert_eq!(hash(id["binary"].as_str().unwrap()),id["sha256"]);assert_eq!(id["field"],field);assert_eq!(hash(field),id["field_sha256"]);assert_eq!(q["identities"][arm]["field_sha256"],id["field_sha256"]);
  assert_eq!(hash(format!("{P}/{arm}.nm")),id["release_nm_sha256"]);assert_eq!(hash(r(format!("{arm}.nm"))),id["release_nm_sha256"]);let nm=fs::read_to_string(r(format!("{arm}.nm"))).unwrap();for bad in["initial_unit_qualification","busy_reset_qualification","unit_z_census"]{assert!(!nm.contains(bad));}
  for stem in["zopro_core","zopro_prover","zopro_zolana","sdk"]{
   let s=if stem=="zopro_core"{steps.iter().find(|s|s["name"]==format!("build-core-{arm}")).unwrap()}else{downstream.iter().find(|s|s["name"]==format!("{stem}-{arm}")).unwrap()};let args=s["argv"].as_array().unwrap();for f in["-O","target-cpu=native","codegen-units=1"]{assert!(args.iter().any(|v|v==f));}assert!(args.iter().any(|v|v==&format!("zopro_bn254={field}")));
   if stem=="zopro_core"{assert!(args.iter().any(|v|v=="zopro_dense_busy_reset"));assert_eq!(args.iter().any(|v|v=="zopro_initial_unit"),arm=="ON");}
   else if stem=="zopro_zolana"{assert!(args.iter().any(|v|v==&format!("zopro_prover={P}/libs/{arm}/libzopro_prover.rlib")));}
   else{assert!(args.iter().any(|v|v==&format!("zopro_core={P}/libs/{arm}/libzopro_core.rlib")));}
   if stem=="sdk"{assert!(args.iter().any(|v|v=="lto=fat"));assert!(args.iter().any(|v|v=="/home/ubuntu/src/zopro-perf-work/worker-placement-control176/driver.rs"));}else{let lib=&id["libraries"][stem];assert_eq!(hash(lib["path"].as_str().unwrap()),lib["sha256"]);}
   assert!(!args.iter().any(|v|v=="zopro_unit_z_mixed"||v=="zopro_unit_z_census"));
  }
 }
 assert_eq!(accepted["native_binary"],"/home/ubuntu/src/zopro-perf-work/busy-reset-sdk176/sdk-ON");assert_eq!(hash(accepted["native_binary"].as_str().unwrap()),accepted["native_binary_sha256"]);
 json!({"current_accepted176_recovered":true,"exact_originals":173,"private_added_module":1,"actual_native_OFF_ON_generic_ON_qualification_inherited":true,"coherent_eight_artifacts":true,"same_original_field1200_both_arms":true,"literal_OFF_original_state_path":true,"accepted_bitmap_REF_bound":true,"original_native_O3_fatLTO_oneCGU_driver":true,"release_test_helpers_absent":true,"test_only_repair_and_retained_failed_compile_verified":true})
}
