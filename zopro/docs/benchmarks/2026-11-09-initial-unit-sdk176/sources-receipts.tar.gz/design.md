# Measurement of qualified proof-owned state

Candidate implementation and unchanged original field are already qualified at
/home/ubuntu/src/zopro-perf-work/initial-unit176. This stage reuses its SDKs and
all prior successful source/curve/Window/generic/concurrency/build evidence.
It supplies a complete matched SDK experiment with the accepted production
artifact as REF, new original-state OFF and state-specialized ON. Sampling,
statistics, PMU/profile parsers and79 declared checks are inherited unchanged.
Only current provenance, artifact locations and canonical proof counts change.
The new source_provenance.rs checks three reversible edits plus the new helper,
initial two successful builds and failed test compile, six corrected test
commands and six downstream builds. The test-only type fix did not change the
already built runtime libraries. Native OFF/ON4+4 tests and generic ON3 tests,
345 Window executions and both-curve independent helper outputs are inherited,
not replayed. No speed or memory-peak claim precedes the new complete capture.
