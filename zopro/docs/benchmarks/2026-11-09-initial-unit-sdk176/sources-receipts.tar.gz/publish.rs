use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::{Path,PathBuf},process::Command,fmt::Write as _};
const R:&str="/home/ubuntu/src/zopro-perf-work/initial-unit-sdk176";
const D:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-initial-unit-sdk176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn walk(p:&Path,out:&mut Vec<PathBuf>){for e in fs::read_dir(p).unwrap(){let e=e.unwrap();if e.file_type().unwrap().is_dir(){walk(&e.path(),out);}else if e.file_type().unwrap().is_file(){out.push(e.path());}}}
fn pair(p:&Value)->String{format!("{:.6} [{:.6}, {:.6}]",p["paired_geomean"].as_f64().unwrap(),p["bootstrap95"][0].as_f64().unwrap(),p["bootstrap95"][1].as_f64().unwrap())}
fn main(){
 assert!(!Path::new(D).exists());let a=read(format!("{R}/analysis.json"));let q=read(format!("{R}/review-result.json"));let d=read(format!("{R}/diagnostic-summary.json"));let decision=read(format!("{R}/decision.json"));assert_eq!(q["passed"],true);assert_eq!(q["gate_passed"],false);assert_eq!(a["checks"].as_object().unwrap().len(),79);assert_eq!(a["failed_checks"].as_array().unwrap().len(),4);assert_eq!(decision["passed_checks"],75);assert_eq!(d["profile_samples"],119775);
 for(p,h)in read(format!("{R}/capture-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
 let ledger=format!("{R}/proof-sha256-after-capture.json");assert_eq!(read(&ledger).as_array().unwrap().len(),43073);let cases=read(format!("{R}/measure-cases.json"));let comparison=read(format!("{R}/fresh-comparison.json"));assert_eq!(comparison["rows"].as_array().unwrap().len(),8);
 fs::create_dir_all(format!("{D}/artifacts")).unwrap();for f in["analysis.json","review-result.json","preflight-review.json","prospective-review.json","proof-inventory.json","diagnostic-summary.json","decision.json","protocol.md","next.md","identities.json","fresh-comparison.json"]{fs::copy(format!("{R}/{f}"),format!("{D}/artifacts/{f}")).unwrap();}
 let mut report=String::from(r#"# Initial-affine accumulator state: complete-proof comparison

**The candidate is not adopted.** Primary 1×2 at 32 workers measures **7.803404 ms accepted REF, 7.848711 ms rebuilt OFF and 7.817299 ms ON**. ON improves over OFF by **0.492%**, with 24/31 paired wins, but has no verified gain over the accepted build: ON/REF is 1.001356, interval [0.999430, 1.003233], with 11/31 wins. Four of 79 declared checks fail. The accepted production source and SDK remain unchanged.

The [qualified candidate](../2026-11-09-initial-unit176/README.md) records initial nonidentity affine provenance in an existing exceptional-accumulator index. It consumes that state for one specialized update or finish join, then clears it. Both arms use the unchanged accepted field library. Three accepted core files contain reversible private edits and one private helper is added; all 176 originals recover, with 173 byte-exact. No Window fields, vector dimensions/capacities, table, key copy, plan, pool, allocator, forecast or memory policy changes. The previous global unit-Z recipe remains rejected.

Each sample includes solving, fresh randomized proving, internal verification and serialization. Loading, pool creation, three warm proofs and final export are outside latency. Case/arm order rotates and reverses under the frozen protocol. Primary 16/32 use 31 blocks of 151 requests; other conditions use 15 blocks of 31 requests, except primary solo uses 11 requests. Every observation is retained without repeated blocks or extensions.

|Case|REF ms|OFF ms|ON ms|ON/OFF paired ratio [95%]|Wins|ON/REF paired ratio [95%]|Wins|
|---|---:|---:|---:|---|---:|---|---:|
"#);
 for c in cases.as_array().unwrap(){let n=c["name"].as_str().unwrap();let get=|arm:&str|a["cells"][format!("{n}/{arm}")]["median_ms"].as_f64().unwrap();let blocks=if c["shape"]=="1x2"&&c["workers"]!=1{31}else{15};let off=&a["pairs"][format!("{n}/ON/OFF")];let rf=&a["pairs"][format!("{n}/ON/REF")];writeln!(report,"|{n}|{:.6}|{:.6}|{:.6}|{}|{}/{}|{}|{}/{}|",get("REF"),get("OFF"),get("ON"),pair(off),off["wins"],blocks,pair(rf),rf["wins"],blocks).unwrap();}
 report.push_str(r#"
Displayed times are medians of process means of integer-rounded emitted nanosecond samples. Paired ratios use 20,000 log-bootstrap resamples, so dividing displayed marginal medians need not reproduce the paired estimate. Intervals assume exchangeable blocks and have no simultaneous familywise guarantee. All-eight aggregates independently resample within each shape with equal log weight; the different block counts are not treated as synchronized across shapes.

The positive component signal is retained. Primary ON/OFF improves at 1, 16 and 32 workers; solo ON also beats REF by 0.539%, interval [0.253%, 0.804%]. At 32 workers, however, the rebuilt OFF is itself 0.631% slower than REF and ON does not establish an accepted-build improvement. All 11 declared calibration checks pass; the OFF/REF primary interval [1.004515, 1.008116] is within the declared range. No unique compiler, layout, cache or clock explanation is established for the difference.

All-eight ON/OFF is **1.000365 [0.998464, 1.002328]**: no overall gain. All-eight ON/REF is **1.006494 [1.004209, 1.008729]**, a 0.649% slowdown. The complete recipe is closed without adoption, unchanged recapture, compiler/inlining/layout/threshold changes or a favorable curve/shape/worker subset. This decision uses the failed complete gate; it does not discard the small positive estimates or impose a minimum gain floor.

All 11 calibration, 22 nonregression, 22 RSS and 18 diagnostic checks pass. The four failures are:

"#);
 for f in a["failed_checks"].as_array().unwrap(){writeln!(report,"- `{}`",f.as_str().unwrap()).unwrap();}
 report.push_str("\nMaximum observed whole-process RSS, including loading and warm proofs:\n\n|Case|REF MiB|OFF MiB|ON MiB|\n|---|---:|---:|---:|\n");
 for c in cases.as_array().unwrap(){let n=c["name"].as_str().unwrap();let get=|arm:&str|a["cells"][format!("{n}/{arm}")]["max_RSS_MiB"].as_f64().unwrap();writeln!(report,"|{n}|{:.2}|{:.2}|{:.2}|",get("REF"),get("OFF"),get("ON")).unwrap();}
 report.push_str(r#"
All declared 5% RSS guards pass. Primary ON reaches 134.50 MiB versus REF 132.50 MiB. These observations are neither minimum RAM nor memory-pressure, mobile or stack-peak measurements. Logical storage remains unchanged.

Nine PMU panels meet the required 99.9% running coverage. Nine fixed-period profiles qualify with **119,775 samples**, minimum 8,880, maximum unknown 2.088816%, zero LOST and checked executable/PID/TID/CPU ownership. Recording ends before offline decoding and Gnark verification. Absolute period coverage remains unvalidated; flat sample shares are not wall-time critical-path fractions.

The following single PMU panels have no replication confidence interval and do not isolate a memory, frequency or dependency cause:

|Diagnostic case|Instructions ON/OFF|Cycles ON/OFF|Cache misses ON/OFF|Branch misses ON/OFF|
|---|---:|---:|---:|---:|
"#);
 for row in d["rows"].as_array().unwrap(){let p=&row["ON_control_ratios"]["OFF"];writeln!(report,"|{}|{:.6}|{:.6}|{:.6}|{:.6}|",row["case"].as_str().unwrap(),p["instructions:u"].as_f64().unwrap(),p["cycles:u"].as_f64().unwrap(),p["cache-misses:u"].as_f64().unwrap(),p["branch-misses:u"].as_f64().unwrap()).unwrap();}
 report.push_str(r#"
The primary 32-worker panel reduces instructions by 0.651% and cycles by 1.072% against OFF. This is consistent with a small local work reduction; it does not override the repeated latency gate. The accepted profile still attributes 21.47% of flat samples to the packed G1 stream and 15.81% to borrowed G2 application. Further scalar-path tuning has not produced the required algorithmic improvement. The next mechanism should address bulk work or dependencies, while preserving the low-memory architecture and relevant prior negative results.

Four frozen helper builds, 52 preflight commands and 1,263 main commands complete on first execution in this measurement stage. Prior native qualification's test-only oracle correction is inherited from the linked report. No runtime/helper/reader/recording repair occurs here. The separate same-agent reader checks 451 capture pins, recovery of 176 original sources, coherent original-field/library bindings, every raw mean, receipt, placement, proof binding and all 79 decisions. Bootstrap and diagnostic parsers are shared unchanged; this is not an external audit. Manual preparation/analysis/publication helper invocations do not all have xtask receipts.

Preflights add 104 SDK requests and 26 fresh Gnark exports, then the main plan adds 44,106 requests and 609 exports. Total: **44,210 SDK requests and 635 fresh unique independently Gnark-verified exports**, advancing the canonical inventory **42,438 → 42,464 → 43,073**. All exported proofs are 164 bytes with checked image/public/freshness bindings. Requests are not distinct independently exported proofs.

Fresh REF observations below measure the unchanged accepted artifact. M5 CPU/Metal figures are supplied historical measurements on different hardware and were not remeasured. Candidate ON remains rejected.

|Shape|Accepted REF ms|Rejected ON ms|M5 CPU ms / REF speedup|M5 Metal ms / REF speedup|CPU 10× target ms|
|---|---:|---:|---:|---:|---:|
"#);
 for row in comparison["rows"].as_array().unwrap(){writeln!(report,"|{}|{:.6}|{:.6}|{} /{:.3}x|{} /{:.3}x|{}|",row["shape"].as_str().unwrap(),row["REF_CPU_ms"].as_f64().unwrap(),row["candidate_CPU_ms"].as_f64().unwrap(),row["M5_CPU_ms"],row["REF_CPU_speedup"].as_f64().unwrap(),row["M5_Metal_ms"],row["REF_Metal_speedup"].as_f64().unwrap(),row["CPU_10x_target_ms"]).unwrap();}
 report.push_str("\nThe full verified CPU 10× goal remains active and unmet, **0/8**. The accepted build was already below 8 ms; this experiment establishes no new speed milestone. No new AWS/Aeglos, ARM/mobile, huge-circuit, memory-pressure, swap, minimum-RAM or concurrent-throughput result is added.\n\n[Results](artifacts/analysis.json), [protocol](artifacts/protocol.md), [raw reader](artifacts/review-result.json), [prospective review](artifacts/prospective-review.json), [preflights](artifacts/preflight-review.json), [proof inventory](artifacts/proof-inventory.json), [diagnostics](artifacts/diagnostic-summary.json), [CPU/Metal comparison](artifacts/fresh-comparison.json), [decision](artifacts/decision.json), [continuation](artifacts/next.md), [sources and receipts](sources-receipts.tar.gz), [archive index](artifacts/archive-index.json), [checksums](SHA256SUMS).\n");
 fs::write(format!("{D}/README.md"),&report).unwrap();
 let pack=PathBuf::from(format!("{R}/publication-source"));fs::create_dir(&pack).unwrap();let mut files=Vec::new();
 for f in["adapt.rs","design.md","protocol.md","source_provenance.rs","preflight.rs","campaign.rs","review.rs","prospective.rs","sdk-analysis.rs","statistics.rs","sampling.rs","metadata.rs","counter.rs","summarize.rs","publish.rs","next.md","build-pins.json","sdk-build-plan.json","helper-plan.json","helper-pins.json","preflight-plan.json","preflight-pins.json","preflight-jobs.json","cases.json","capture-plan.json","capture-pins.json","jobs.json","measure-cases.json","identities.json","environment.json","source-audit.json","link-review.json","prospective-review.json","preflight-review.json","review-result.json","analysis.json","decision.json","diagnostic-summary.json","fresh-comparison.json","profile-symbols.json","rows.json","proof-inventory.json","preflight-checkpoint.rs"]{files.push(PathBuf::from(format!("{R}/{f}")));}
 for dir in["helper-run","preflight-run","runs","stat"]{walk(Path::new(&format!("{R}/{dir}")),&mut files);}
 files.sort();let mut members=Vec::new();let mut local=Vec::new();
 for p in files{let rel=p.strip_prefix(R).unwrap();let data=fs::read(&p).unwrap();if p.file_name().unwrap()=="stdout.log"&&(p.to_string_lossy().contains("/decode-cycles-")||p.to_string_lossy().contains("/metadata-cycles-")){local.push(json!({"path":p,"bytes":data.len(),"sha256":hash(&p)}));continue;}
  assert!(std::str::from_utf8(&data).is_ok(),"{}",p.display());let dest=pack.join(rel);fs::create_dir_all(dest.parent().unwrap()).unwrap();fs::write(&dest,&data).unwrap();members.push(json!({"path":rel,"bytes":data.len(),"sha256":hash(dest)}));
 }
 let archive=format!("{D}/sources-receipts.tar.gz");assert!(Command::new("tar").args(["-czf",&archive,"-C",pack.to_str().unwrap(),"."]).status().unwrap().success());let round=PathBuf::from(format!("{R}/publication-roundtrip"));fs::create_dir(&round).unwrap();assert!(Command::new("tar").args(["-xzf",&archive,"-C",round.to_str().unwrap(),"."]).status().unwrap().success());for m in&members{assert_eq!(hash(round.join(m["path"].as_str().unwrap())),m["sha256"]);}
 let index=json!({"archive_sha256":hash(&archive),"members":members,"local_decoded_logs":local,"canonical_proofs":43073,"proof_ledger_sha256":hash(ledger),"excluded":["binaries and rlibs","key/image/witness/proof bytes","raw perf data","full unchanged source snapshot","full historical proof ledger"],"native_source_and_qualification_report":"../2026-11-09-initial-unit176/README.md"});fs::write(format!("{D}/artifacts/archive-index.json"),serde_json::to_vec_pretty(&index).unwrap()).unwrap();
 fs::write(format!("{D}/SHA256SUMS"),"").unwrap();let mut links=0;for part in report.split("](").skip(1){let target=part.split(')').next().unwrap();assert!(Path::new(D).join(target).exists(),"{target}");links+=1;}
 let publication=json!({"passed":true,"archive_members":members.len(),"archive_roundtrip":true,"local_links":links,"raw_reader_passed":true,"failed_numeric_checks":4,"numeric_checks":79,"all11_calibrations_passed":true,"production_unchanged":true,"adopted":false,"SDK_requests":44210,"new_unique_Gnark_exports":635,"canonical_proofs":43073,"profile_samples":119775,"all8_CPU_Metal_rows":8,"goal_targets_met":0,"goal_complete":false,"goal_active":true});for p in[format!("{R}/publication.json"),format!("{D}/artifacts/publication.json")]{fs::write(p,serde_json::to_vec_pretty(&publication).unwrap()).unwrap();}
 let mut files=Vec::new();walk(Path::new(D),&mut files);files.sort();let mut sums=String::new();for p in files{if p.file_name().unwrap()=="SHA256SUMS"{continue;}writeln!(sums,"{}  {}",hash(&p),p.strip_prefix(D).unwrap().display()).unwrap();}fs::write(format!("{D}/SHA256SUMS"),&sums).unwrap();for line in sums.lines(){let(h,p)=line.split_once("  ").unwrap();assert_eq!(hash(Path::new(D).join(p)),h);}
 println!("INITIAL_UNIT_SDK_PUBLICATION_PASS{}members/{}links;gate4/79fail;635newGnarkexports;canonical43073;productionunchanged",members.len(),links);
}
