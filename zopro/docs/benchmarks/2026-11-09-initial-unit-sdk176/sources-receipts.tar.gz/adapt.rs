use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/initial-unit-sdk176";const OLD:&str="/home/ubuntu/src/zopro-perf-work/unit-z-sdk176";const P:&str="/home/ubuntu/src/zopro-perf-work/initial-unit176";
fn read(n:&str)->String{fs::read_to_string(format!("{OLD}/{n}")).unwrap().replace(OLD,R)}
fn write(n:&str,s:&str){assert!(!Path::new(&format!("{R}/{n}")).exists());fs::write(format!("{R}/{n}"),s).unwrap();}
fn replace(s:&mut String,before:&str,after:&str){assert_eq!(s.matches(before).count(),1,"{before}");*s=s.replace(before,after);}
fn counts(s:String)->String{s.replace("42438","43073").replace("41829","42464").replace("41803","42438")}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 for f in["statistics.rs","sampling.rs","metadata.rs","counter.rs"]{fs::copy(format!("{OLD}/{f}"),format!("{R}/{f}")).unwrap();}
 for f in["source-audit.json","link-review.json","OFF.nm","ON.nm"]{fs::copy(format!("{P}/{f}"),format!("{R}/{f}")).unwrap();}
 fs::copy(format!("{P}/sdk-build-plan.json"),format!("{R}/sdk-build-plan.json")).unwrap();
 let mut pre=counts(read("preflight.rs"));replace(&mut pre,"const PRIOR:&str=\"/home/ubuntu/src/zopro-perf-work/unit-z-census176/proof-sha256-after.json\";",&format!("const PRIOR:&str=\"{OLD}/proof-sha256-after-capture.json\";"));
 replace(&mut pre,"let binary=format!(\"{R}/sdk-{mode}\")",&format!("let binary=format!(\"{P}/sdk-{{mode}}\")"));
 pre=pre.replace("\"build-plan.json\"","\"sdk-build-plan.json\"").replace("\"remaining-plan.json\",\"remaining-pins.json\",\"link-review.json\",\"link-repair.json\"","\"link-review.json\"").replace("actualmethodnativegenericqualificationinherited","initialunitstate_nativeOFFON_genericON_inherited");write("preflight.rs",&pre);
 let mut campaign=counts(read("campaign.rs"));replace(&mut campaign,"for phase in[\"build\",\"remaining\",\"preflight\"]","for phase in[\"build\",\"preflight\"]");replace(&mut campaign,"r(format!(\"sdk-{arm}\"))",&format!("PathBuf::from(format!(\"{P}/sdk-{{arm}}\"))"));
 campaign=campaign.replace("\"remaining-plan.json\",\"remaining-pins.json\",\"link-review.json\",\"link-repair.json\"","\"sdk-build-plan.json\",\"link-review.json\"");write("campaign.rs",&campaign);
 write("sdk-analysis.rs",&counts(read("sdk-analysis.rs")));
 write("review.rs",&counts(read("review.rs")).replace("actual_method_native_generic_and_prior26exports_inherited","initial_unit_state_native_generic_and_prior26exports_inherited"));
 write("prospective.rs",&counts(read("prospective.rs")).replace("actual_method_native_generic_and_prior26Gnark_exports_inherited","initial_unit_state_native_generic_and_prior26Gnark_exports_inherited").replace("shared_unit_Z_actual_method_qualification_inherited","initial_unit_state_qualification_inherited").replace("qualified_fields_and_accepted_bitmap_REF_bound","same_original_field_and_accepted_bitmap_REF_bound"));
 let mut pins:BTreeMap<String,Value>=serde_json::from_slice(&fs::read(format!("{P}/sdk-build-pins.json")).unwrap()).unwrap();
 for(p,h)in &pins{assert_eq!(hash(p),h.as_str().unwrap());}
 for f in["review-result.json","link-review.json","source-audit.json","plan.json","repair-plan.json","pins.json","repair-pins.json","sdk-build-plan.json","sdk-build-pins.json","test-repair.json"]{let p=format!("{P}/{f}");pins.insert(p.clone(),json!(hash(p)));}
 for f in["source-audit.json","link-review.json","sdk-build-plan.json","OFF.nm","ON.nm"]{let p=format!("{R}/{f}");pins.insert(p.clone(),json!(hash(p)));}
 fs::write(format!("{R}/build-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
 let template:Value=serde_json::from_slice(&fs::read(format!("{OLD}/helper-plan.json")).unwrap()).unwrap();let mut steps=template["steps"].as_array().unwrap().clone();let mut helper_pins=BTreeMap::new();
 for s in&mut steps{for v in s["argv"].as_array_mut().unwrap(){*v=json!(v.as_str().unwrap().replace(OLD,R));}for v in s["argv"].as_array().unwrap(){let t=v.as_str().unwrap();let p=t.split_once('=').map_or(t,|(_,p)|p);if Path::new(p).is_file(){helper_pins.insert(p.to_string(),json!(hash(p)));}}}
 for f in["adapt.rs","adapt","protocol.md","design.md","source_provenance.rs","sdk-analysis.rs","statistics.rs","sampling.rs","metadata.rs","counter.rs","build-pins.json","sdk-build-plan.json","link-review.json"]{let p=format!("{R}/{f}");helper_pins.insert(p.clone(),json!(hash(p)));}
 for f in["statistics.rs","sampling.rs","metadata.rs","counter.rs"]{assert_eq!(hash(format!("{R}/{f}")),hash(format!("{OLD}/{f}")));}
 let plan=json!({"version":1,"source_pins":format!("{R}/helper-pins.json"),"steps":steps});fs::write(format!("{R}/helper-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();helper_pins.insert(format!("{R}/helper-plan.json"),json!(hash(format!("{R}/helper-plan.json"))));fs::write(format!("{R}/helper-pins.json"),serde_json::to_vec_pretty(&helper_pins).unwrap()).unwrap();println!("Prepared4frozenhelpers;qualifiedSDKsreused;canonical42438->42464->43073;79unchangedchecks;noSDKcalls");
}
