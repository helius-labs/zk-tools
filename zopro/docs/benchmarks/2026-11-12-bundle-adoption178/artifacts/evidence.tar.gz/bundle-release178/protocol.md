# Bounded G2 release checks after all-shape performance qualification

All33 prospective local performance/resource checks passed on b646c7b8; no
cleanup SDK is substituted. Preserve its exact runtime sources, including the
small atomic admission observer. Its unused query wrappers remain cfg-gated with
the measured module; removing observer/helper code is a separate candidate.
Native default selector emits indexed_tile_bundles and coalesce_probe alongside
the current native IFMA flags; generic/optout/ARM/wasm choices stay unchanged.
This adopts measured native runtime plus tested selector, not a freshly timed
Cargo release binary. No C7a/ARM performance inference.

Link one synthetic group-oracle concurrent caller to the exact retained native
libraries. Dense,zero,one,negative scalars; repeated/signed/identity points;1/4/16/32
pools with512KiB stacks; nested joins and4OS callers sharing4workers. Run admitted
and optional-ceiling-zero processes. Assert activation only outside concurrent
calls because the historical diagnostic wrapper resets global counters; actual
query results must match generator sums throughout. No throughput measurement.

Reuse exact child/field/native qualification bindings and completed all-shape
SDK fallback tests. Build selector before/after, compare10finite contexts and
preserve all existing cfg/GPU output. Actual native Cargo check must select both
new cfgs without explicit flags. Generic x86-64 no_ifma/no_asm core tests use new
source/selector and retain original fallback; no physicalARM execution claim.
No new proof exports; canonical54927 stays unchanged. Allcommands throughxtask.
Promote source only when every applicable check is accounted for and passes;
no benchmark replay or unrelated cleanup. Commit locally, do not push.
