use zopro_bn254::{Field,Fr,G2Affine,G2Projective};
use serde_json::json;
fn main(){
 let denied=std::env::var("ZOPRO_CPU_PREPARE_MAX_BYTES").ok().as_deref()==Some("0");
 let n=4099;let generator=G2Projective::generator();
 let bank=G2Projective::batch_to_affine(&(0..131).map(|i|generator*Fr::from(i as u64)).collect::<Vec<_>>());
 let mut weights=Vec::new();let bases:Vec<G2Affine>=(0..n).map(|i|{let w=if i%19==0{0}else{(i*37)%131};let sign=if i%7==0{-Fr::ONE}else{Fr::ONE};weights.push(Fr::from(w as u64)*sign);let mut p=bank[w];if sign==-Fr::ONE{p.y=-p.y;}p}).collect();
 let variants:Vec<_>=(0..4).map(|mode|{let mut total=Fr::ZERO;let words=(0..n).map(|i|{let s=match mode{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,_=>Fr::from(i as u64+731).pow(&[19])};total+=s*weights[i];s.to_canonical()}).collect::<Vec<_>>();(words,(generator*total).to_affine())}).collect();
 let run=|which:usize|{let(mut words,want)=variants[which].clone();let(p,_)=zopro_core::coalesce_query_probe::b(&bases,&mut words);assert_eq!(p.to_affine(),want);};
 let mut comparisons=0;let mut route_checks=vec![];
 for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();
  let(mut words,want)=variants[3].clone();let(p,m)=pool.install(||zopro_core::coalesce_query_probe::b(&bases,&mut words));assert_eq!(p.to_affine(),want);comparisons+=1;
  if denied{assert_eq!(m.route,0);assert_eq!(m.payload,0);}else{assert_eq!(m.route,314);assert!(m.classes>0&&m.payload>0);}
  route_checks.push(json!({"workers":workers,"route":m.route,"indexed_calls":m.classes,"max_charge":m.payload}));
  for mode in 0..4{pool.install(||run(mode));comparisons+=1;}
  pool.install(||rayon::join(||run(3),||run(2)));comparisons+=2;
 }
 let pool=rayon::ThreadPoolBuilder::new().num_threads(4).stack_size(512*1024).build().unwrap();
 std::thread::scope(|scope|{let mut handles=vec![];for caller in 0..4{let(pool,run)=(&pool,&run);handles.push(scope.spawn(move||{for round in 0..6{pool.install(||run((caller+round)%4));}}));}for h in handles{h.join().unwrap();}});comparisons+=24;
 println!("{}",json!({"passed":true,"generator_oracle_comparisons":comparisons,"routes":route_checks,"denied":denied,"nested_join_pools":4,"OS_callers":4,"shared_pool_workers":4,"throughput_claim":false,"new_proofs":0,"observer_metadata_not_asserted_during_concurrency":true}));
}
