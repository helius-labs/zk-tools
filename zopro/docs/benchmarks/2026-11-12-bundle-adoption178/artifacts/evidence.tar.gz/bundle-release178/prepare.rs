use std::{fs,collections::BTreeMap,path::Path};use serde_json::{Value,json};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/bundle-release178";const S:&str="/home/ubuntu/src/zopro-perf-work/bundle-sdk178";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(n:&str,v:Value){let p=format!("{R}/{n}");assert!(!Path::new(&p).exists());fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn main(){
 assert_eq!(read("/home/ubuntu/src/zopro-perf-work/bundle-all178/assessment.json")["checks_passed"],33);
 assert_eq!(read("/home/ubuntu/src/zopro-perf-work/bundle-all178/independent-main-review.json")["passed"],true);
 let originals=read("/home/ubuntu/src/zopro-perf-work/two-bank177/source-bindings.json");let mut pins=BTreeMap::new();let mut source=BTreeMap::new();
 let mut paths=originals.as_object().unwrap().keys().cloned().collect::<Vec<_>>();paths.push("crates/zopro-core/src/msm/indexed_tiles.rs".into());
 for rel in &paths {let from=format!("{S}/source/{rel}");let to=format!("{R}/source/{rel}");assert!(!Path::new(&to).exists());fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(&from,&to).unwrap();if let Some(h)=originals.get(rel){assert_eq!(hash(format!("/home/ubuntu/src/zk-tools/zopro/{rel}")),h.as_str().unwrap());}}
 let build=format!("{R}/source/crates/zopro-core/build.rs");let mut s=fs::read_to_string(&build).unwrap();let anchor="    // Select the measured native IFMA paths.\n";assert_eq!(s.matches(anchor).count(),1);s=s.replace(anchor,&format!("{anchor}    println!(\"cargo::rustc-check-cfg=cfg(zopro_indexed_tile_bundles)\");\n    println!(\"cargo::rustc-check-cfg=cfg(zopro_coalesce_probe)\");\n"));let anchor="        println!(\"cargo::rustc-cfg=zopro_phi_grain\");";assert_eq!(s.matches(anchor).count(),1);s=s.replace(anchor,&format!("{anchor}\n        // Preserve the qualified reducer and its measured admission counters.\n        println!(\"cargo::rustc-cfg=zopro_indexed_tile_bundles\");\n        println!(\"cargo::rustc-cfg=zopro_coalesce_probe\");"));fs::write(build,s).unwrap();
 for rel in &paths {let p=format!("{R}/source/{rel}");let h=hash(&p);source.insert(rel.clone(),h.clone());pins.insert(p,h);}
 save("source-review.json",json!({"originals":originals,"promotion_source_sha256":source,"runtime_source_snapshot":format!("{S}/source"),"runtime_files_exact_to_measured_SDK":true,"only_new_change":"native cfg registration/emission"}));
 let old="/home/ubuntu/src/zopro-perf-work/phi-grain-parent176";let mut review=fs::read_to_string(format!("{old}/selection-review.rs")).unwrap().replace(old,R).replace("zopro_phi_grain","zopro_indexed_tile_bundles");
 review=review.replace("!l.contains(\"zopro_indexed_tile_bundles\")","!l.contains(\"zopro_indexed_tile_bundles\")&&!l.contains(\"zopro_coalesce_probe\")");
 review=review.replace("assert_eq!(actual,usize::from(expected));","assert_eq!(actual,usize::from(expected));assert_eq!(new.lines().filter(|l|*l==\"cargo::rustc-cfg=zopro_coalesce_probe\").count(),usize::from(expected));");
 review=review.replace("selection-runs/actual-Cargo-native-default-selection","release-run/actual-Cargo-native-default-selection").replace("selection-plan.json","release-plan.json");
 review=review.replace("cmd[\"environment\"][\"CARGO_ENCODED_RUSTFLAGS\"]","cmd[\"environment\"][\"RUSTFLAGS\"]");
 review=review.replace("assert_eq!(matching,1);","assert_eq!(matching,1);assert!(events.iter().any(|v|v[\"reason\"]==\"build-script-executed\"&&v[\"package_id\"].as_str().unwrap_or(\"\").contains(\"zopro-core\")&&v[\"cfgs\"].as_array().is_some_and(|a|a.iter().any(|v|v==\"zopro_coalesce_probe\"))));");
 fs::write(format!("{R}/selection-review.rs"),review).unwrap();
 let tools="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin";let deps="/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
 let buildplan=read(format!("{S}/build-plan.json"));let env=buildplan["environment"].clone();
 let mut link=buildplan["steps"][1].clone();link["name"]=json!("concurrent");link["driver"]=json!(format!("{R}/concurrent.rs"));link["additional_sources"]=json!([]);
 let mut steps=vec![link];
 for (name,denied) in [("concurrent-admitted",false),("concurrent-denied",true)] {let mut e=env.clone();e["ZOPRO_CPU_INDEXED_TILE_BUNDLES"]=json!("1");if denied{e["ZOPRO_CPU_PREPARE_MAX_BYTES"]=json!("0");}steps.push(json!({"kind":"command","name":name,"argv":[format!("{R}/release-run/concurrent-sdk")],"environment":e,"timeout_seconds":300}));}
 for(arm,src)in[("before","/home/ubuntu/src/zk-tools/zopro/crates/zopro-core/build.rs".to_string()),("after",format!("{R}/source/crates/zopro-core/build.rs"))]{steps.push(json!({"kind":"command","name":format!("build-{arm}-selector"),"argv":[format!("{tools}/rustc"),"--edition=2021","-O",src,"-o",format!("{R}/selector-{arm}")]}));}
 steps.push(json!({"kind":"command","name":"build-selector-reader","argv":[format!("{tools}/rustc"),"--edition=2021","-O",format!("{R}/selection-review.rs"),"-L",format!("dependency={deps}"),"--extern",format!("serde_json={deps}/libserde_json-cdebb9338c2784ad.rlib"),"--extern",format!("sha2={deps}/libsha2-16b8f2c03bdf5faa.rlib"),"-o",format!("{R}/selection-review")]}));
 steps.push(json!({"kind":"command","name":"ten-selection-contexts","argv":[format!("{R}/selection-review"),"cases"]}));
 let flags=env["RUSTFLAGS"].as_str().unwrap().replace(" --cfg zopro_indexed_tile_bundles","").replace(" --cfg zopro_coalesce_probe","").replace(" --check-cfg=cfg(zopro_indexed_tile_bundles)","").replace(" --check-cfg=cfg(zopro_coalesce_probe)","");
 let mut native=env.clone();native["RUSTFLAGS"]=json!(flags);native["CARGO_TARGET_DIR"]=json!(format!("{R}/target-native"));
 steps.push(json!({"kind":"command","name":"actual-Cargo-native-default-selection","argv":[format!("{tools}/cargo"),"check","--locked","--offline","--manifest-path",format!("{R}/source/Cargo.toml"),"-p","zopro-core","--lib","--message-format=json"],"environment":native,"timeout_seconds":900}));
 steps.push(json!({"kind":"command","name":"review-actual-Cargo-selection","argv":[format!("{R}/selection-review"),"cargo"]}));
 let mut portable=env.clone();portable["RUSTFLAGS"]=json!("-C target-cpu=x86-64 --cfg no_ifma --cfg no_asm");portable["CARGO_TARGET_DIR"]=json!(format!("{R}/target-portable"));
 steps.push(json!({"kind":"command","name":"portable-core","argv":[format!("{tools}/cargo"),"test","--locked","--offline","--release","--manifest-path",format!("{R}/source/Cargo.toml"),"--target","x86_64-unknown-linux-gnu","-p","zopro-core","--lib","--","--test-threads=1"],"environment":portable,"timeout_seconds":900}));
 for (p,h) in read(format!("{S}/capture-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pins.insert(p.clone(),h.as_str().unwrap().into());}
 for f in["prepare.rs","concurrent.rs","protocol.md","selection-review.rs","source-review.json"]{let p=format!("{R}/{f}");pins.insert(p.clone(),hash(p));}
 save("release-plan.json",json!({"version":1,"environment":env,"source_pins":format!("{R}/release-pins.json"),"steps":steps}));pins.insert(format!("{R}/release-plan.json"),hash(format!("{R}/release-plan.json")));save("release-pins.json",json!(pins));
 println!("Prepared exact-library concurrency,10selector contexts,actualnative Cargo and generic tests; no production changes.");
}
