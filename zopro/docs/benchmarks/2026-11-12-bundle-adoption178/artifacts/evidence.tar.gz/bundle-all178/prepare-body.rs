fn prepare() {
    let ids = read("/home/ubuntu/src/zopro-perf-work/bundle-sdk178/runtime-consumers.json");
    check_copies(&ids);
    assert_eq!(ids["REF"]["sha256"], "c88a3528d5feb363732dd2557d1894c93e9161f4e3ec9e9d3c7e2564283bf2fe");
    assert_eq!(ids["ON"]["sha256"], "b646c7b8c1d8a26a0db45fb3f67c453dd616bd9f02e25c36192721ae02855abe");
    assert_eq!(hash(SEED), "a53b7f952c40444ab5dc5f88e38d1689716b2deb2e0cf465021784b8c7eadcf5");
    let seed: BTreeSet<String> = serde_json::from_value(read(SEED)).unwrap();
    assert_eq!(seed.len(), 54304);
    let mut pins = BTreeMap::<String,String>::new();
    // Recheck inherited source/build/capture bindings before using the old SDK.
    for file in ["build-pins.json", "capture-pins.json"] {
        for (p,h) in read(format!("/home/ubuntu/src/zopro-perf-work/bundle-sdk178/{file}")).as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap(), "{p}");
            pins.insert(p.clone(), h.as_str().unwrap().into());
        }
    }
    save(r("runtime-consumers.json"), &ids);
    let all = read("/home/ubuntu/src/zopro-perf-work/large-class-sdk176/measure-cases.json");
    let names = ["1x2-w16","1x2-w32","2x2-w32","4x2-w32","8x2-w32","12x2-w32","16x2-w32","24x2-w32","merge-24x1-w32","merge-54x1-w32"];
    let cases: Vec<Value> = names.iter().map(|n| all.as_array().unwrap().iter().find(|c|c["name"]==*n).unwrap().clone()).collect();
    for c in &cases { for k in ["image", "request"] {
        let p=c[k].as_str().unwrap(); let h=hash(p);
        if k=="image" {assert_eq!(h,c["image_sha256"]);}
        pins.insert(p.into(),h);
    }}
    let base=read("/home/ubuntu/src/zopro-perf-work/bundle-sdk178/main-plan.json")["steps"][0]["environment"].clone();
    assert!(base.get("ZOPRO_CPU_PREPARE_MAX_BYTES").is_none());
    for phase in ["preflight","main"] {
        let (mut jobs,mut steps)=(vec![],vec![]);
        if phase=="preflight" {
            for c in &cases {for arm in ["REF","ON"] {add(c,arm,0,phase,&base,&ids,&mut jobs,&mut steps);}}
            for name in ["1x2-w16","2x2-w32","merge-54x1-w32"] {
                let mut c=cases.iter().find(|c|c["name"]==name).unwrap().clone();
                c["name"]=json!(format!("{name}-denied")); c["denied"]=json!(true);
                add(&c,"ON",0,phase,&base,&ids,&mut jobs,&mut steps);
            }
        } else {
            for b in 0..30 {
                let mut order=(0..10).collect::<Vec<_>>(); order.rotate_left(b%10);
                if b%2==1 {order.reverse();}
                let arms=if (b/3)%2==0 {["REF","ON"]} else {["ON","REF"]};
                for i in order {for arm in arms {add(&cases[i],arm,b,phase,&base,&ids,&mut jobs,&mut steps);}}
            }
        }
        assert_eq!(jobs.len(),if phase=="preflight"{23}else{600});
        steps.extend(jobs.iter().map(verify));
        save(r(format!("{phase}-jobs.json")),&json!(jobs));
        save(r(format!("{phase}-plan.json")),&json!({"version":1,"source_pins":r("runtime-pins.json"),"steps":steps}));
    }
    let mut row=vec![1u64]; for _ in 0..30 {let mut next=vec![1;row.len()+1];for i in 1..row.len(){next[i]=row[i-1]+row[i];}row=next;}
    let mass:u64=row[10..=20].iter().sum();
    save(r("statistics-model.json"),&json!({"blocks":30,"lower_rank_zero_based":9,"upper_rank_zero_based":20,"marginal_coverage":mass as f64/(1u64<<30) as f64,"joint_confidence_claim":false}));
    for p in [SEED, VERIFY, "/usr/bin/taskset", "/home/ubuntu/src/zopro-perf-work/tool-target/release/xtask"] {pins.insert(p.into(),hash(p));}
    for arm in ["REF","ON"] {for c in ids[arm]["copies"].as_array().unwrap(){let p=c["path"].as_str().unwrap();pins.insert(p.into(),hash(p));}}
    for f in ["protocol.md","adapt.rs","prepare-body.rs","screen.rs","screen","independent.rs","independent","statistics-model.json","runtime-consumers.json","preflight-jobs.json","main-jobs.json","preflight-plan.json","main-plan.json"] {pins.insert(r(f).display().to_string(),hash(r(f)));}
    save(r("runtime-pins.json"),&json!(pins));
    println!("Frozen23preflight+600main; 92+12000calls; ledger54304; no new build/copies.");
}
