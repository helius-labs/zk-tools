use std::fs;
const R:&str="/home/ubuntu/src/zopro-perf-work/bundle-all178";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/g2-coordinate-leaf177";
fn replace(s:&mut String,a:&str,b:&str){assert!(s.contains(a),"missing {a}");*s=s.replace(a,b);}
fn main(){
 let mut s=fs::read_to_string(format!("{OLD}/screen.rs")).unwrap().replace(OLD,R);
 replace(&mut s,"/home/ubuntu/src/zopro-perf-work/ibs-backing177/proof-sha256-after-profile.json","/home/ubuntu/src/zopro-perf-work/bundle-profile178/proof-sha256-after-profile.json");
 let start=s.find("fn prepare() {").unwrap();let end=s.find("fn review(phase:").unwrap();
 s.replace_range(start..end,&fs::read_to_string(format!("{R}/prepare-body.rs")).unwrap());
 replace(&mut s,"} else if c[\"shape\"] == \"1x2\" {\n        101\n    } else {\n        31","} else {\n        17");
 replace(&mut s,"let dir = r(format!(\"proofs/{name}\"));","if arm==\"ON\" {env[\"ZOPRO_CPU_INDEXED_TILE_BUNDLES\"]=json!(\"1\");}\n    if c[\"denied\"]==true {env[\"ZOPRO_CPU_PREPARE_MAX_BYTES\"]=json!(\"0\");}\n    let dir = r(format!(\"proofs/{name}\"));");
 for(a,b)in[("52972","54304"),("52999","54327"),("53899","54927"),("40500","10200"),("{ 27 }","{ 23 }"),("[\"REF\", \"OFF\", \"ON\"]","[\"REF\", \"ON\"]"),("[\"REF\",\"OFF\",\"ON\"]","[\"REF\",\"ON\"]"),("[\"REF\", \"OFF\"]","[\"REF\"]"),("[\"REF\",\"OFF\"]","[\"REF\"]"),("distinct.len(),9","distinct.len(),6"),("context == \"1x2-w32\" && metric","context == \"1x2-w16\" && metric")]{replace(&mut s,a,b);}
 replace(&mut s,"assert_eq!(sum[\"workers\"], j[\"case\"][\"workers\"]);",r#"assert_eq!(sum["workers"], j["case"]["workers"]);
        if j["arm"]=="ON" {
            let entries=sum["indexed_entries"].as_u64().unwrap();
            let charge=sum["indexed_max_charge"].as_u64().unwrap();
            if j["case"]["denied"]==true {assert_eq!(entries,0);assert_eq!(charge,0);}
            else if ["1x2","2x2"].iter().any(|shape|j["case"]["shape"]==*shape) {assert_eq!(entries,4*rounds);assert!(charge>0);}
            else {assert_eq!(entries%rounds,0);if entries>0 {assert!(charge>0);}}
        }"#);
 replace(&mut s,"assert_eq!(gates.len(), 31);",r#"assert_eq!(gates.len(), 30);
    for copy in 0..3u64 {
        let mut ratios=vec![];
        for block in (0..30u64).filter(|b|b%3==copy) {
            let get=|arm:&str|rows.iter().find(|r|r["context"]=="1x2-w16"&&r["arm"]==arm&&r["block"]==block).unwrap()["ms"].as_f64().unwrap();
            ratios.push(get("ON")/get("REF"));
        }
        ratios.sort_by(f64::total_cmp);let median=(ratios[4]+ratios[5])/2.;
        gates.push(json!({"context":"1x2-w16","comparator":"REF","metric":"backing_median","copy":copy,"median":median,"passed":median<1.}));
    }
    assert_eq!(gates.len(),33);"#);
 replace(&mut s,"{passed}/31","{passed}/33");
 fs::write(format!("{R}/screen.rs"),s).unwrap();
 let mut s=fs::read_to_string(format!("{OLD}/independent.rs")).unwrap().replace(OLD,R);
 for(a,b)in[("{27}","{23}"),("{900}","{600}"),("900","600"),("108","92"),("43200","12000"),("40500","10200"),("53899","54927"),("cells.len(),90","cells.len(),60"),("[\"REF\",\"OFF\",\"ON\"]","[\"REF\",\"ON\"]"),("ctx==\"1x2-w32\"&&metric","ctx==\"1x2-w16\"&&metric"),("reproduced.len(),31","reproduced.len(),33"),("{pass}/31","{pass}/33"),("927exports/43308calls; all90copy","623exports/12092calls; all60copy")]{replace(&mut s,a,b);}
 replace(&mut s,"{1}else if n.starts_with(\"1x2-\"){101}else{31}","{1}else{17}");
 replace(&mut s,"let pass=if metric==\"peak_rss_kib\"",r#"let pass=if metric=="backing_median" {let copy=g["copy"].as_u64().unwrap();let v=on.iter().zip(&other).enumerate().filter(|(b,_)|*b as u64%3==copy).map(|(_, (a,b))|a.0/b.0).collect::<Vec<_>>();assert_eq!(v.len(),10);let m=(order(&v,4)+order(&v,5))/2.;near(m,g["median"].as_f64().unwrap());m<1.}else if metric=="peak_rss_kib""#);
 replace(&mut s,"assert_eq!(j[\"environment\"][\"RAYON_NUM_THREADS\"],case[\"workers\"].as_u64().unwrap().to_string());",r#"assert_eq!(j["environment"]["RAYON_NUM_THREADS"],case["workers"].as_u64().unwrap().to_string());
   if arm=="ON" {assert_eq!(j["environment"]["ZOPRO_CPU_INDEXED_TILE_BUNDLES"],"1");}
   if case["denied"]==true {assert_eq!(j["environment"]["ZOPRO_CPU_PREPARE_MAX_BYTES"],"0");}else{assert!(j["environment"].get("ZOPRO_CPU_PREPARE_MAX_BYTES").is_none());}"#);
 fs::write(format!("{R}/independent.rs"),s).unwrap();
}
