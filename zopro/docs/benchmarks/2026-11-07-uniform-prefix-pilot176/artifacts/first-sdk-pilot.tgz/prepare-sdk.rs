use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix-cfg176/sdk";
const O: &str = "/home/ubuntu/src/zopro-perf-work/borrowed-bucket-tree176/native";
const N: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix176/native";
const BEFORE:&str="/home/ubuntu/src/zopro-perf-work/borrowed-bucket-tree176/native/primary-pilot/proof-sha256-after-diagnostic.json";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: &Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn transform(s: &str) -> String {
    s.replace(&format!("{O}/sdk-isolated-build"),&format!("{N}/sdk-build")).replace(O,R).replace("/home/ubuntu/src/zopro-perf-work/scaled-norm-numerator176/native/primary-pilot/proof-sha256-after-diagnostic.json",BEFORE).replace("31621","__LEDGER_BEFORE__").replace("31648","__LEDGER_PREFLIGHT__").replace("31693","__LEDGER_LATENCY__").replace("31699","__LEDGER_DIAGNOSTIC__").replace("__LEDGER_BEFORE__","31699").replace("__LEDGER_PREFLIGHT__","31726").replace("__LEDGER_LATENCY__","31771").replace("__LEDGER_DIAGNOSTIC__","31777")
}
fn main() {
    let audit = load("/home/ubuntu/src/zopro-perf-work/uniform-prefix-cfg176/review.json");
    assert_eq!(audit["review_passed"], true);
    assert_eq!(audit["reconsideration_selected"], true);
    assert_eq!(
        load(format!("{N}/native-review.json"))["review_passed"],
        true
    );
    assert_eq!(
        load(format!("{N}/final-review.json"))["review_passed"],
        true
    );
    assert_eq!(
        load(format!("{N}/codegen-analysis.json"))["native_structure_gate_passed"],
        false
    );
    assert_eq!(load(BEFORE).as_array().unwrap().len(), 31699);
    let r = Path::new(R);
    assert!(!r.exists());
    fs::create_dir_all(r).unwrap();
    for file in [
        "review-preflight.rs",
        "pilot.rs",
        "review-pilot.rs",
        "preflight-plan.json",
        "preflight-jobs.json",
        "preflight-review-plan.json",
        "pilot-preparation-plan.json",
    ] {
        let s = fs::read_to_string(Path::new(O).join(file)).unwrap();
        fs::write(r.join(file), transform(&s)).unwrap();
    }
    let mut identities = load(format!("{O}/sdk-identities.json"));
    for arm in ["OFF", "ON"] {
        let a = load(format!("{N}/sdk-build/{arm}/artifacts.json"));
        let binary = a["binary"].as_str().unwrap();
        assert_eq!(hash(binary), a["binary_sha256"].as_str().unwrap());
        identities[arm] = json!({"binary":binary,"binary_sha256":hash(binary)});
    }
    assert_eq!(
        hash(identities["accepted"]["binary"].as_str().unwrap()),
        identities["accepted"]["binary_sha256"].as_str().unwrap()
    );
    save(r.join("sdk-identities.json"), &identities);
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(load(format!("{N}/sdk-build-pins.json"))).unwrap();
    let accepted=load("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");
    for (name, h) in accepted["source_files_sha256"].as_object().unwrap() {
        let p = format!("/home/ubuntu/src/zk-tools/zopro/{name}");
        assert_eq!(hash(&p), h.as_str().unwrap());
        pins.insert(p, h.as_str().unwrap().into());
    }
    let old_pins = load(format!("{O}/preflight-pins.json"));
    for (p, h) in old_pins.as_object().unwrap() {
        if p.contains("/sdk-control-copies/images/")
            || p.contains("/tools/zolana/fixtures/")
            || p.contains("/batch-local-steal/gnark/")
            || p.contains("/tool-target/release/deps/")
        {
            assert_eq!(hash(p), h.as_str().unwrap());
            pins.insert(p.clone(), h.as_str().unwrap().into());
        }
    }
    for arm in ["accepted", "OFF", "ON"] {
        let p = identities[arm]["binary"].as_str().unwrap();
        pins.insert(p.into(), hash(p));
    }
    for file in [
        "review-preflight.rs",
        "preflight-plan.json",
        "preflight-jobs.json",
        "sdk-identities.json",
    ] {
        let p = format!("{R}/{file}");
        pins.insert(p.clone(), hash(&p));
    }
    for p in [
        BEFORE,
        "/home/ubuntu/src/zopro-perf-work/uniform-prefix-cfg176/analysis.json",
        "/home/ubuntu/src/zopro-perf-work/uniform-prefix-cfg176/review.json",
        "/home/ubuntu/src/zopro-perf-work/uniform-prefix-cfg176/design.md",
        &format!("{N}/native-review.json"),
        &format!("{N}/final-review.json"),
        &format!("{N}/codegen-analysis.json"),
    ] {
        pins.insert(p.into(), hash(p));
    }
    for (p, h) in &pins {
        assert_eq!(&hash(p), h);
    }
    save(r.join("preflight-pins.json"), &json!(pins));
    let mut prep = load(r.join("pilot-preparation-plan.json"));
    prep["steps"]
        .as_array_mut()
        .unwrap()
        .retain(|s| s["name"] != "prepare-pilot");
    save(r.join("pilot-compilation-plan.json"), &prep);
    save(
        r.join("preparation.json"),
        &json!({"prospective_CFG_reconsideration_passed":true,"old_static_gate_still_failed":true,"no_new_native_implementation":true,"same_qualified_binaries":identities,"preflight_shapes":9,"preflight_arms":3,"preflight_requests":108,"preflight_Gnark_exports":27,"baseline_ledger_count":31699,"after_preflight":31726,"after_latency":31771,"after_diagnostic":31777,"old_successful_qualifications_not_replayed":true,"preflight_pins":pins.len(),"new_clocks_started":false}),
    );
    println!(
        "first whole-SDK preflight/measurement prepared; samequalifiedSDKs; no clocks started"
    );
}
