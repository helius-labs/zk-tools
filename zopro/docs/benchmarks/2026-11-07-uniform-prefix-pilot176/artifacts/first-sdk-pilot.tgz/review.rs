use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet, VecDeque},
    fs,
    path::Path,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix-cfg176";
const N: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix176/native";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn reached(succ: &[Vec<usize>], remove: Option<usize>) -> BTreeSet<usize> {
    let mut seen = BTreeSet::new();
    let mut q = VecDeque::from([0]);
    while let Some(b) = q.pop_front() {
        if Some(b) == remove || !seen.insert(b) {
            continue;
        }
        q.extend(succ[b].iter().copied());
    }
    seen
}
fn counts<'a>(lines: impl Iterator<Item = &'a String>) -> Value {
    let ls = lines.collect::<Vec<_>>();
    json!({"instructions":ls.len(),"IFMA_sites":ls.iter().filter(|l|l.starts_with("vpmadd52")).count(),"left4_shifts":ls.iter().filter(|l|l.starts_with("vpsllq")&&l.ends_with(",0x4")).count(),"right48_shifts":ls.iter().filter(|l|l.starts_with("vpsrlq")&&l.ends_with(",0x30")).count(),"ZMM_stack_operand_rows":ls.iter().filter(|l|l.contains("ZMMWORD PTR [rsp")||l.contains("ZMMWORD PTR [rbp")).count(),"calls":ls.iter().filter(|l|l.starts_with("call ")).map(|s|(*s).clone()).collect::<Vec<_>>()})
}
fn main() {
    let r = Path::new(R);
    let a = load(r.join("analysis.json"));
    assert_eq!(a["reconsideration_selected"], true);
    let mut pins = 0;
    for (p, h) in load(r.join("pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
        pins += 1;
    }
    let parent=load("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");
    for (p, h) in parent["source_files_sha256"].as_object().unwrap() {
        assert_eq!(
            hash(Path::new("/home/ubuntu/src/zk-tools/zopro").join(p)),
            h.as_str().unwrap()
        );
    }
    let plan = load(r.join("plan.json"));
    assert_eq!(load(r.join("runs/result.json"))["status"], "complete");
    for s in plan["steps"].as_array().unwrap() {
        let d = r.join("runs").join(s["name"].as_str().unwrap());
        let e = load(d.join("exit.json"));
        assert_eq!(e["success"], true);
        assert_eq!(e["returncode"], 0);
        let c = load(d.join("command.json"));
        let x = c["argv"].as_array().unwrap();
        let y = s["argv"].as_array().unwrap();
        assert_eq!(&x[x.len() - y.len()..], y);
        for stream in ["stdout", "stderr"] {
            assert_eq!(
                hash(d.join(format!("{stream}.log"))),
                e[format!("{stream}_sha256")].as_str().unwrap()
            );
        }
    }
    let mut loops_total = 0;
    let mut nodes = 0;
    let mut independent_dominators = 0;
    let mut roles = 0;
    for (_key, case) in a["consumers"].as_object().unwrap() {
        let j = &case["job"];
        let begin = j["address"].as_u64().unwrap();
        let end = begin + j["size_bytes"].as_u64().unwrap();
        let stream = Path::new(N).join(format!(
            "decode-runs/{}/stdout.log",
            j["name"].as_str().unwrap()
        ));
        assert_eq!(case["decode_sha256"], hash(&stream));
        let mut instructions = BTreeMap::new();
        for l in fs::read_to_string(stream).unwrap().lines() {
            if let Some((p, body)) = l.split_once(':') {
                if let Ok(ip) = u64::from_str_radix(p.trim(), 16) {
                    if (begin..end).contains(&ip) {
                        assert!(instructions.insert(ip, body.trim().to_owned()).is_none());
                    }
                }
            }
        }
        assert_eq!(counts(instructions.values()), case["all"]);
        let blocks = case["blocks"].as_array().unwrap();
        nodes += blocks.len();
        let starts = blocks
            .iter()
            .enumerate()
            .map(|(i, b)| (b["start_ip"].as_u64().unwrap(), i))
            .collect::<BTreeMap<_, _>>();
        let succ = blocks
            .iter()
            .map(|b| {
                b["succ"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|v| v.as_u64().unwrap() as usize)
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>();
        let mut all_ips = BTreeSet::new();
        for (i, b) in blocks.iter().enumerate() {
            assert_eq!(b["id"], i);
            let lo = b["start_ip"].as_u64().unwrap();
            let hi = b["last_ip"].as_u64().unwrap();
            let ips = instructions.range(lo..=hi).collect::<Vec<_>>();
            assert_eq!(ips.len(), b["instruction_count"].as_u64().unwrap() as usize);
            for (&ip, _) in &ips {
                assert!(all_ips.insert(ip));
            }
            let last = &instructions[&hi];
            let op = last.split_whitespace().next().unwrap();
            let mut expected = BTreeSet::new();
            if op.starts_with('j') {
                let target =
                    u64::from_str_radix(last.split_whitespace().nth(1).unwrap(), 16).unwrap();
                if (begin..end).contains(&target) {
                    expected.insert(starts[&target]);
                }
                if op != "jmp" && op != "jmpq" && i + 1 < blocks.len() {
                    expected.insert(i + 1);
                }
            } else if !matches!(op, "ret" | "retq" | "ud2") && i + 1 < blocks.len() {
                expected.insert(i + 1);
            }
            assert_eq!(expected, succ[i].iter().copied().collect());
        }
        assert_eq!(all_ips, instructions.keys().copied().collect());
        let reachable = reached(&succ, None);
        assert_eq!(
            reachable.len(),
            case["reachable_blocks"].as_u64().unwrap() as usize
        );
        // Independent dominators: deleting v disconnects exactly the reachable nodes v dominates.
        let mut dom = vec![BTreeSet::new(); blocks.len()];
        for &v in &reachable {
            let without = reached(&succ, Some(v));
            for &u in reachable.difference(&without) {
                dom[u].insert(v);
            }
            independent_dominators += 1;
        }
        for &v in &reachable {
            let reported = blocks[v]["dominators"]
                .as_array()
                .unwrap()
                .iter()
                .map(|n| n.as_u64().unwrap() as usize)
                .collect::<BTreeSet<_>>();
            assert_eq!(dom[v], reported);
        }
        let mut expected_latches = BTreeMap::<usize, BTreeSet<usize>>::new();
        for &u in &reachable {
            for &v in &succ[u] {
                if dom[u].contains(&v) {
                    expected_latches.entry(v).or_default().insert(u);
                }
            }
        }
        let loops = case["loops"].as_array().unwrap();
        assert_eq!(loops.len(), expected_latches.len());
        loops_total += loops.len();
        let mut union = BTreeSet::new();
        for l in loops {
            let head = l["header_block"].as_u64().unwrap() as usize;
            let latch = l["latches"]
                .as_array()
                .unwrap()
                .iter()
                .map(|v| v.as_u64().unwrap() as usize)
                .collect::<BTreeSet<_>>();
            assert_eq!(latch, expected_latches[&head]);
            let body = l["blocks"]
                .as_array()
                .unwrap()
                .iter()
                .map(|v| v.as_u64().unwrap() as usize)
                .collect::<BTreeSet<_>>();
            assert!(body.contains(&head));
            assert!(latch.is_subset(&body));
            assert!(body.iter().all(|b| dom[*b].contains(&head)));
            for &b in &body {
                if b != head {
                    for (p, successors) in succ.iter().enumerate() {
                        if successors.contains(&b) && reachable.contains(&p) {
                            assert!(body.contains(&p));
                        }
                    }
                }
            }
            let selected = body.iter().flat_map(|&b| {
                let lo = blocks[b]["start_ip"].as_u64().unwrap();
                let hi = blocks[b]["last_ip"].as_u64().unwrap();
                instructions.range(lo..=hi).map(|(_, v)| v)
            });
            assert_eq!(counts(selected), l["metrics"]);
            if !l["outer_vector_role"].is_null() {
                roles += 1;
                union.extend(body.iter().copied());
            }
        }
        let outside = blocks
            .iter()
            .enumerate()
            .filter(|(i, _)| !union.contains(i))
            .flat_map(|(_, b)| {
                instructions
                    .range(b["start_ip"].as_u64().unwrap()..=b["last_ip"].as_u64().unwrap())
                    .map(|(_, v)| v)
            });
        assert_eq!(counts(outside), case["outside_vector_loops"]);
        assert_eq!(case["complete_graph"], true);
        assert_eq!(case["laminar_loops"], true);
        assert!(case["unresolved"].as_array().unwrap().is_empty());
    }
    assert_eq!(a["comparisons"].as_array().unwrap().len(), 5);
    for c in a["comparisons"].as_array().unwrap() {
        let x = &c["OFF"];
        let y = &c["ON"];
        assert_eq!(x["IFMA_sites"], y["IFMA_sites"]);
        for k in ["instructions", "left4_shifts", "right48_shifts"] {
            assert!(y[k].as_u64().unwrap() < x[k].as_u64().unwrap());
        }
    }
    let out = json!({"review_passed":true,"pins":pins,"production_files_checked":176,"successful_command_receipts":2,"consumers":4,"basic_blocks":nodes,"dominator_deletion_searches":independent_dominators,"natural_loops":loops_total,"outer_vector_roles_both_arms":roles,"paired_vector_roles":5,"reconsideration_selected":true,"original_static_gate_remains_failed":true,"new_decodes":0,"new_timings":0,"new_Gnark_exports":0,"limits":"Independent node-deletion dominator and retained-assembly graph/count review, not a second disassembler, dynamic-frequency measurement, unwinding model, field oracle or speed estimate."});
    let dest = r.join("review.json");
    assert!(!dest.exists());
    fs::write(dest, serde_json::to_vec_pretty(&out).unwrap()).unwrap();
    println!("CFG/node-deletion/retained-text review PASS");
}
