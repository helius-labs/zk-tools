use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet, VecDeque},
    fs,
    path::Path,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix-cfg176";
const N: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix176/native";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
#[derive(Clone, Debug)]
struct Ins {
    ip: u64,
    text: String,
    op: String,
    target: Option<u64>,
}
fn metrics<'a>(ins: impl Iterator<Item = &'a Ins>) -> Value {
    let ins = ins.collect::<Vec<_>>();
    json!({"instructions":ins.len(),"IFMA_sites":ins.iter().filter(|i|i.op.starts_with("vpmadd52")).count(),"left4_shifts":ins.iter().filter(|i|i.op=="vpsllq"&&i.text.ends_with(",0x4")).count(),"right48_shifts":ins.iter().filter(|i|i.op=="vpsrlq"&&i.text.ends_with(",0x30")).count(),"ZMM_stack_operand_rows":ins.iter().filter(|i|i.text.contains("ZMMWORD PTR [rsp")||i.text.contains("ZMMWORD PTR [rbp")).count(),"calls":ins.iter().filter(|i|i.op=="call").map(|i|i.text.clone()).collect::<Vec<_>>()})
}
fn main() {
    let root = Path::new(R);
    let native = Path::new(N);
    let pins = load(root.join("pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let jobs = load(native.join("codegen-jobs.json"));
    let old = load(native.join("codegen-analysis.json"));
    let mut results = BTreeMap::new();
    for job in jobs.as_array().unwrap() {
        let name = job["name"].as_str().unwrap();
        let begin = job["address"].as_u64().unwrap();
        let end = begin + job["size_bytes"].as_u64().unwrap();
        let path = native.join(format!("decode-runs/{name}/stdout.log"));
        let raw = fs::read_to_string(&path).unwrap();
        let mut ins = vec![];
        for line in raw.lines() {
            if let Some((address, body)) = line.split_once(':') {
                if let Ok(ip) = u64::from_str_radix(address.trim(), 16) {
                    if (begin..end).contains(&ip) {
                        let text = body.trim().to_owned();
                        let op = text.split_whitespace().next().unwrap().to_owned();
                        let target = if op.starts_with('j') {
                            text.split_whitespace()
                                .nth(1)
                                .and_then(|s| u64::from_str_radix(s, 16).ok())
                        } else {
                            None
                        };
                        ins.push(Ins {
                            ip,
                            text,
                            op,
                            target,
                        });
                    }
                }
            }
        }
        assert_eq!(ins[0].ip, begin);
        let addresses = ins
            .iter()
            .enumerate()
            .map(|(i, v)| (v.ip, i))
            .collect::<BTreeMap<_, _>>();
        assert_eq!(addresses.len(), ins.len());
        let mut leaders = BTreeSet::from([0usize]);
        let mut unresolved = vec![];
        let mut external = vec![];
        for (i, v) in ins.iter().enumerate() {
            if v.op.starts_with('j') {
                if let Some(target) = v.target {
                    if (begin..end).contains(&target) {
                        if let Some(&t) = addresses.get(&target) {
                            leaders.insert(t);
                        } else {
                            unresolved.push(json!({"ip":v.ip,"target":target,"reason":"interior or missing instruction"}));
                        }
                    } else {
                        external.push(json!({"ip":v.ip,"target":target}));
                    }
                } else {
                    unresolved
                        .push(json!({"ip":v.ip,"instruction":v.text,"reason":"indirect branch"}));
                }
                if i + 1 < ins.len() {
                    leaders.insert(i + 1);
                }
            } else if matches!(v.op.as_str(), "ret" | "retq" | "ud2") {
                if i + 1 < ins.len() {
                    leaders.insert(i + 1);
                }
            }
        }
        let leaders = leaders.into_iter().collect::<Vec<_>>();
        let ranges = leaders
            .iter()
            .enumerate()
            .map(|(i, &a)| (a, leaders.get(i + 1).copied().unwrap_or(ins.len())))
            .collect::<Vec<_>>();
        let count = ranges.len();
        let mut block_for = vec![0; ins.len()];
        for (b, &(a, z)) in ranges.iter().enumerate() {
            for t in a..z {
                block_for[t] = b;
            }
        }
        let mut succ = vec![BTreeSet::new(); count];
        for (b, &(_, z)) in ranges.iter().enumerate() {
            let last = &ins[z - 1];
            if last.op.starts_with('j') {
                if let Some(target) = last.target {
                    if let Some(&ix) = addresses.get(&target) {
                        succ[b].insert(block_for[ix]);
                    }
                }
                if last.op != "jmp" && last.op != "jmpq" && b + 1 < count {
                    succ[b].insert(b + 1);
                }
            } else if !matches!(last.op.as_str(), "ret" | "retq" | "ud2") && b + 1 < count {
                succ[b].insert(b + 1);
            }
        }
        let mut pred = vec![BTreeSet::new(); count];
        for (b, s) in succ.iter().enumerate() {
            for &v in s {
                pred[v].insert(b);
            }
        }
        let mut reachable = BTreeSet::new();
        let mut queue = VecDeque::from([0]);
        while let Some(b) = queue.pop_front() {
            if reachable.insert(b) {
                queue.extend(succ[b].iter().copied());
            }
        }
        let mut dom = vec![reachable.clone(); count];
        dom[0] = BTreeSet::from([0]);
        let mut iterations = 0;
        loop {
            iterations += 1;
            let mut changed = false;
            for &b in &reachable {
                if b == 0 {
                    continue;
                }
                let inputs = pred[b]
                    .intersection(&reachable)
                    .copied()
                    .collect::<Vec<_>>();
                assert!(!inputs.is_empty());
                let mut d = dom[inputs[0]].clone();
                for &p in &inputs[1..] {
                    d = d.intersection(&dom[p]).copied().collect();
                }
                d.insert(b);
                if d != dom[b] {
                    dom[b] = d;
                    changed = true;
                }
            }
            if !changed {
                break;
            }
            assert!(iterations < count + 2);
        }
        let mut loops = BTreeMap::<usize, (BTreeSet<usize>, BTreeSet<usize>)>::new();
        let mut backedges = 0;
        for &tail in &reachable {
            for &head in &succ[tail] {
                if dom[tail].contains(&head) {
                    backedges += 1;
                    let mut body = BTreeSet::from([head, tail]);
                    let mut pending = if tail == head { vec![] } else { vec![tail] };
                    while let Some(b) = pending.pop() {
                        for &p in &pred[b] {
                            if reachable.contains(&p) && body.insert(p) && p != head {
                                pending.push(p);
                            }
                        }
                    }
                    assert!(body.iter().all(|b| dom[*b].contains(&head)));
                    let entry = loops.entry(head).or_default();
                    entry.0.extend(body);
                    entry.1.insert(tail);
                }
            }
        }
        let bodies = loops
            .iter()
            .map(|(&head, (body, tails))| {
                let selected = body.iter().flat_map(|&b| {
                    let (a, z) = ranges[b];
                    ins[a..z].iter()
                });
                (head, body.clone(), tails.clone(), metrics(selected))
            })
            .collect::<Vec<_>>();
        let mut laminar = true;
        for i in 0..bodies.len() {
            for j in i + 1..bodies.len() {
                let a = &bodies[i].1;
                let b = &bodies[j].1;
                if !a.is_disjoint(b) && !a.is_subset(b) && !b.is_subset(a) {
                    laminar = false;
                }
            }
        }
        let mut outer = vec![];
        for (i, (_, body, _, m)) in bodies.iter().enumerate() {
            if m["IFMA_sites"].as_u64().unwrap() > 0
                && !bodies.iter().enumerate().any(|(j, (_, other, _, om))| {
                    i != j
                        && body.is_subset(other)
                        && body != other
                        && om["IFMA_sites"].as_u64().unwrap() > 0
                })
            {
                outer.push(i);
            }
        }
        outer.sort_by_key(|&i| {
            (
                bodies[i].3["IFMA_sites"].as_u64().unwrap(),
                ins[ranges[bodies[i].0].0].ip,
            )
        });
        let union = outer
            .iter()
            .flat_map(|&i| bodies[i].1.iter().copied())
            .collect::<BTreeSet<_>>();
        let outside = metrics(
            ranges
                .iter()
                .enumerate()
                .filter(|(b, _)| !union.contains(b))
                .flat_map(|(_, &(a, z))| ins[a..z].iter()),
        );
        let loop_rows=bodies.iter().enumerate().map(|(i,(head,body,tails,m))|json!({"id":i,"header_block":head,"header_ip":ins[ranges[*head].0].ip,"blocks":body,"latches":tails,"metrics":m,"outer_vector_role":outer.iter().position(|v|*v==i)})).collect::<Vec<_>>();
        let key = format!(
            "{}-{}",
            job["kind"].as_str().unwrap(),
            job["arm"].as_str().unwrap()
        );
        let all = metrics(ins.iter());
        for key_metric in [
            "instructions",
            "IFMA_sites",
            "left4_shifts",
            "right48_shifts",
            "ZMM_stack_operand_rows",
        ] {
            assert_eq!(all[key_metric], old["rows"][&key][key_metric]);
        }
        assert_eq!(
            all["instructions"].as_u64().unwrap(),
            outside["instructions"].as_u64().unwrap()
                + metrics(union.iter().flat_map(|&b| {
                    let (a, z) = ranges[b];
                    ins[a..z].iter()
                }))["instructions"]
                    .as_u64()
                    .unwrap()
        );
        results.insert(key,json!({"job":job,"decode_sha256":hash(path),"complete_graph":unresolved.is_empty(),"unresolved":unresolved,"external_branch_exits":external,"laminar_loops":laminar,"dominator_iterations":iterations,"backedges":backedges,"reachable_blocks":reachable.len(),"all":all,"outside_vector_loops":outside,"outer_vector_roles":outer.iter().map(|&i|loop_rows[i].clone()).collect::<Vec<_>>(),"loops":loop_rows,"blocks":ranges.iter().enumerate().map(|(b,&(a,z))|json!({"id":b,"start_ip":ins[a].ip,"last_ip":ins[z-1].ip,"instruction_count":z-a,"reachable":reachable.contains(&b),"succ":succ[b],"pred":pred[b],"dominators":if reachable.contains(&b){dom[b].clone()}else{BTreeSet::new()}})).collect::<Vec<_>>()}));
    }
    let mut comparisons = vec![];
    let mut gate = true;
    for kind in ["G1", "G2"] {
        let off = &results[&format!("{kind}-OFF")];
        let on = &results[&format!("{kind}-ON")];
        gate &= off["complete_graph"] == true
            && on["complete_graph"] == true
            && off["laminar_loops"] == true
            && on["laminar_loops"] == true;
        let a = off["outer_vector_roles"].as_array().unwrap();
        let b = on["outer_vector_roles"].as_array().unwrap();
        let roles_equal = a.len() == b.len() && !a.is_empty();
        gate &= roles_equal;
        if roles_equal {
            for (i, (a, b)) in a.iter().zip(b).enumerate() {
                let a = &a["metrics"];
                let b = &b["metrics"];
                let same_ifma = a["IFMA_sites"] == b["IFMA_sites"];
                let less = ["instructions", "left4_shifts", "right48_shifts"]
                    .into_iter()
                    .all(|k| b[k].as_u64().unwrap() < a[k].as_u64().unwrap());
                gate &= same_ifma && less;
                comparisons.push(json!({"curve":kind,"role":i,"OFF":a,"ON":b,"same_IFMA":same_ifma,"less_instructions_and_packing":less}));
            }
        }
    }
    let out = json!({"audit_complete":true,"reconsideration_selected":gate,"original_whole_function_gate_still_failed":true,"new_runtime_implementation":false,"new_decodes":0,"new_timings":0,"new_Gnark_exports":0,"adopted":false,"comparisons":comparisons,"consumers":results,"limits":"Static natural-loop/control-flow evidence only. No measured iteration frequencies, dynamic instructions, latency, stall attribution or critical-path bound. Calls are inventoried and fall through; exceptional unwinding is not modeled. Failed original screen remains failed. No curve-only subset promotion."});
    let dest = root.join("analysis.json");
    assert!(!dest.exists());
    fs::write(dest, serde_json::to_vec_pretty(&out).unwrap()).unwrap();
    println!(
        "{}",
        json!({"reconsideration_selected":gate,"comparisons":out["comparisons"]})
    );
}
