use std::{fs,io::Read,path::Path};use serde_json::{json,Value};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/adopted-c7a239";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn save(p:impl AsRef<Path>,v:Value){assert!(!p.as_ref().exists());fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn replace(s:&mut String,old:&str,new:&str){assert_eq!(s.matches(old).count(),1,"anchor {old}");*s=s.replacen(old,new,1);}
fn main(){let r=Path::new(R);let local=r.join("local");let out=local.join("smoke-output");assert_eq!(read(out.join("complete.json"))["status"],"complete");assert_eq!(read(out.join("complete.json"))["canonical_count"],62191);assert_eq!(read(out.join("independent-finish.json"))["passed"],true);
    let bundle=r.join("bundle");fs::create_dir(&bundle).unwrap();for d in["bin","config","images","requests","keys","lib"]{fs::create_dir(bundle.join(d)).unwrap();for e in fs::read_dir(local.join(d)).unwrap(){let e=e.unwrap();assert!(e.file_type().unwrap().is_file());if d=="images"||d=="requests"{fs::hard_link(e.path(),bundle.join(d).join(e.file_name())).unwrap();}else{fs::copy(e.path(),bundle.join(d).join(e.file_name())).unwrap();}}}
    // Only the separate remote root receives the four new, independently checked proofs.
    fs::copy(out.join("proof-sha256.json"),bundle.join("config/seed.json")).unwrap();let mut cfg=read(bundle.join("config/config.json"));cfg["seed_count"]=json!(62191);fs::write(bundle.join("config/config.json"),serde_json::to_vec_pretty(&cfg).unwrap()).unwrap();
    fs::copy(out.join("complete.json"),bundle.join("config/local-complete.json")).unwrap();fs::copy(out.join("independent-finish.json"),bundle.join("config/local-review.json")).unwrap();
    let old="/home/ubuntu/src/zopro-perf-work/accepted-c7a201/cloud.rs";let mut cloud=fs::read_to_string(old).unwrap().replace("accepted-c7a201","adopted-c7a239").replace("accept201","adopt239");
    replace(&mut cloud,"assert_eq!(read(\"bundle/smoke-output/complete.json\")[\"status\"],\"complete\");","assert_eq!(read(\"local/smoke-output/complete.json\")[\"status\"],\"complete\"); assert_eq!(read(\"local/smoke-output/independent-finish.json\")[\"passed\"],true); assert_eq!(read(\"package-ready.json\")[\"passed\"],true); let expected=read(\"package-hashes.json\")[format!(\"{R}/bundle.tar.gz\")].as_str().unwrap().to_owned(); assert_eq!(format!(\"{:x}\",Sha256::digest(fs::read(root().join(\"bundle.tar.gz\")).unwrap())),expected);");
    replace(&mut cloud,"let active=aws(","assert_eq!(launch[\"InstanceInitiatedShutdownBehavior\"],\"terminate\"); assert_eq!(launch[\"InstanceType\"],\"c7a.24xlarge\"); assert_eq!(launch[\"MinCount\"],1); assert_eq!(launch[\"MaxCount\"],1); launch[\"CpuOptions\"]=json!({\"CoreCount\":96,\"ThreadsPerCore\":1});\n  let active=aws(");
    let start=cloud.find(" \"repair\"=>").unwrap();let end=cloud[start..].find(" \"measure\"|").unwrap()+start;cloud.replace_range(start..end,"");
    replace(&mut cloud,"\"measure\"|\"measure-v2\"=>{assert_eq!(poll(if op==\"measure\"{\"load\"}else{\"repair\"})[\"Status\"],\"Success\");let runner=if op==\"measure\"{\"runner\"}else{\"runner-v2\"};","\"measure\"=>{assert_eq!(poll(\"load\")[\"Status\"],\"Success\");let runner=\"runner\";");
    replace(&mut cloud,"-p MemoryMax=30G -p MemorySwapMax=0","-p CPUAccounting=yes -p MemoryAccounting=yes -p MemoryMax=30G -p MemorySwapMax=0");
    replace(&mut cloud,"\"upload\"|\"upload-v2\"=>{let v=poll(if op==\"upload\"{\"measure\"}else{\"measure-v2\"});","\"upload\"=>{let v=poll(\"measure\");");
    replace(&mut cloud,"let key=if op==\"upload\"{\"results.tar.gz\"}else{\"results-v2.tar.gz\"};","let key=\"results.tar.gz\";");
    cloud=cloud.replace("output/aeglos?","output/aeglos? /var/tmp/adopted-c7a239/output/parent?");
    // The preceding broad text replacement also touches the tar exclude; make that exact again.
    cloud=cloud.replace("--exclude='output/aeglos? /var/tmp/adopted-c7a239/output/parent?'","--exclude='output/aeglos?' --exclude='output/parent?'");
    replace(&mut cloud,"\"download\"|\"download-v2\"=>{let label=if op==\"download\"{\"upload\"}else{\"upload-v2\"};let key=if op==\"download\"{\"results.tar.gz\"}else{\"results-v2.tar.gz\"};","\"download\"=>{let label=\"upload\";let key=\"results.tar.gz\";");
    replace(&mut cloud,"save(if op==\"download\"{\"retrieved.json\"}else{\"retrieved-v2.json\"},","save(\"retrieved.json\",");
    replace(&mut cloud,"assert!(root().join(\"retrieved.json\").exists());for key in[\"bundle.tar.gz\",\"results.tar.gz\",\"runner-v2\",\"results-v2.tar.gz\"]","for key in[\"bundle.tar.gz\",\"results.tar.gz\"]");
    assert!(!cloud.contains("repair\"=>")&&!cloud.contains("measure-v2")&&!cloud.contains("runner-v2")&&!cloud.contains("upload-v2"));assert!(!r.join("cloud.rs").exists());fs::write(r.join("cloud.rs"),cloud).unwrap();
    save(r.join("cloud-provenance.json"),json!({"parent_source":old,"parent_sha256":hash(old),"new_source_sha256":hash(r.join("cloud.rs")),"local_source_pins_unchanged":hash(local.join("payload-pins.json")),"local_seed_unchanged":hash(local.join("config/seed.json")),"remote_seed":hash(bundle.join("config/seed.json")),"no_cloud_calls":true}));
    println!("Separate remote bundle seeded62191; local frozen seed/config/payload unchanged; isolated cloud lifecycle prepared, no AWS calls.");
}
