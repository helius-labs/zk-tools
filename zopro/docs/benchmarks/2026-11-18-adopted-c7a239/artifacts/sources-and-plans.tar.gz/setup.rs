use std::{collections::BTreeSet, fs, io::Read, path::Path};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/adopted-c7a239";
fn read(p: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(p).unwrap()).unwrap() }
fn hash(p: impl AsRef<Path>) -> String {
    let mut f = fs::File::open(p).unwrap(); let mut h = Sha256::new(); let mut b = [0;65536];
    loop { let n=f.read(&mut b).unwrap(); if n==0 {break} h.update(&b[..n]); } format!("{:x}",h.finalize())
}
fn save(p: impl AsRef<Path>, v: &Value) { assert!(!p.as_ref().exists()); fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap(); }
fn main() {
    let r=Path::new(ROOT); let local=r.join("local"); fs::create_dir(&local).unwrap();
    for d in ["bin","config","images","requests","keys","lib"] {fs::create_dir(local.join(d)).unwrap();}
    let prod=Path::new("/home/ubuntu/src/zk-tools/zopro");
    let manifest=read(prod.join("docs/benchmarks/2026-11-18-paired-weighted-adoption236/artifacts/production-source-manifest.json"));
    let sources=manifest["source_files_sha256"].as_object().unwrap(); assert_eq!(sources.len(),188);
    for (p,h) in sources {assert_eq!(hash(prod.join(p)),h.as_str().unwrap(),"source {p}");}
    save(r.join("production-manifest.json"),&manifest);
    let old=Path::new("/home/ubuntu/src/zopro-perf-work/accepted-c7a201/bundle");
    let mut cfg=read(old.join("config/config.json")); let current=read("/home/ubuntu/src/zopro-perf-work/paired-weighted-all234/main-jobs.json");
    for (shape,c) in cfg["cases"].as_object().unwrap() {
        let j=current.as_array().unwrap().iter().find(|j| j["arm"]=="ON" && j["case"]["shape"]==shape.as_str() && j["case"]["workers"]==32).unwrap();
        for k in ["image_sha256","public_sha256","reference"] {assert_eq!(j["case"][k],c[k],"{shape} {k}");}
        assert_eq!(hash(j["case"]["request"].as_str().unwrap()),c["request_sha256"].as_str().unwrap());
        assert_eq!(j["environment"],cfg["environment"]);
        for (field,sha) in [("image","image_sha256"),("request","request_sha256")] {
            let rel=c[field].as_str().unwrap(); assert_eq!(hash(old.join(rel)),c[sha].as_str().unwrap());
            fs::hard_link(old.join(rel),local.join(rel)).unwrap();
        }
    }
    for (src,dst,expected) in [
        ("/home/ubuntu/src/zopro-perf-work/paired-weighted233/native-ON/candidate-sdk","sdk","d523f49e8548620c4373a1ab4be2712d705709fdd7a590c5ed73e9aff97424e3"),
        ("/home/ubuntu/src/zopro-perf-work/certified-proof194/build-run-v2/candidate-sdk","parent","bcc8e0775bb5bc6c09ad86b1987ca45eebac62617340911266c84aa601fa05b1"),
        ("/home/ubuntu/src/zopro-perf-work/msm-c7a180/context/bins/aref0","aeglos","eab9fbfd4b94aeef9ced3ce3e3ede21a37ab70ad38b217720f1afd06fceba99b")
    ] {assert_eq!(hash(src),expected);fs::copy(src,local.join("bin").join(dst)).unwrap();cfg[format!("{dst}_sha256")]=json!(expected);}
    for rel in ["bin/verify","lib/libstdc++.so.6","keys/transfer_confidential_1_2.key"] {fs::copy(old.join(rel),local.join(rel)).unwrap();}
    for (src,dst) in [("/home/ubuntu/src/zk-tools/zopro/xtask/target/release/xtask","xtask"),("/home/ubuntu/src/zopro-perf-work/adopted-c7a239/runner","runner"),("/home/ubuntu/src/zopro-perf-work/adopted-c7a239/independent","independent")] {fs::copy(src,local.join("bin").join(dst)).unwrap();}
    let seed=Path::new("/home/ubuntu/src/zopro-perf-work/paired-weighted-profile235/proof-sha256-after-profile.json");
    assert_eq!(hash(seed),"38314450cd7201e88e527845db52c4de60479688cc2c7b8d0201c4d472596ff3");
    let inventory: BTreeSet<String>=serde_json::from_value(read(seed)).unwrap();assert_eq!(inventory.len(),62187);
    fs::copy(seed,local.join("config/seed.json")).unwrap(); cfg["seed_count"]=json!(62187);
    cfg["measured_sdk_scope"]=json!("Exact forced-cfg233 SDK; implementation adopted236, selector-only build.rs difference; no newly relinked normal-selector SDK claim");
    cfg["source_manifest_sha256"]=json!(hash(r.join("production-manifest.json")));
    cfg["aeglos_source"]=json!("0290613e8eeca17a4ce88f6f2d726e8e06a5385d");
    assert_eq!(hash(local.join("keys/transfer_confidential_1_2.key")),cfg["aeglos_key_sha256"].as_str().unwrap());
    save(local.join("config/config.json"),&cfg); fs::copy(r.join("protocol.md"),local.join("config/protocol.md")).unwrap();
    fs::copy(r.join("production-manifest.json"),local.join("config/production-manifest.json")).unwrap();
    for name in ["runner.rs","independent.rs","setup.rs"] {fs::copy(r.join(name),local.join("config").join(name)).unwrap();}
    println!("188 production sources; 9 current234 images/requests/public bindings and environments match retained201 fixtures. Separate local root prepared.");
}
