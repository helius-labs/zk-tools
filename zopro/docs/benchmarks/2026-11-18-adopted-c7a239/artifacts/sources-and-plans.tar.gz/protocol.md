# Current adopted CPU implementation on C7a239

Prior238turn PROGRESS: pairedfill nativequeryscreen negative/closed. Current
source188 atb164b9776b and exact233SDKd523 remainadopted;10xgoalACTIVE/unmet0/8.
Question:what actual C7a latency/scaling and memory does that exact SDK achieve
acrossall8 shapes+merge54? Old201C7ameasured194, not current field/reducer work.
No newoptimization/adoptionveto, no source/SDKrebuild orlocalbaseline timingreroll.
SDK d523f49e8548620c4373a1ab4be2712d705709fdd7a590c5ed73e9aff97424e3,
forced-cfg233sourceprovenance and selector-only236differenceexplicit. The normal
native-selector SDK is not silently relabeled as this measured binary.

All9ONshapes at32/96physicalworkers onONEc7a.24xlarge/noSMT. Primary adds
PARENT exact194bcc8e0775bb5bc6c09ad86b1987ca45eebac62617340911266c84aa601fa05b1
with same3optimizedoptins, and retained AeglosSortedeab9fbfd4b94aeef9ced3ce3e3ede21a37ab70ad38b217720f1afd06fceba99b
(source0290613e8eeca17a4ce88f6f2d726e8e06a5385d, NOTlatestbranch). No certificate-OFF
control: primaryPARENT measures aggregate194->233changes. Preserve201decisions.
ON/PARENT solve,quotient,randomblinding,construct,serialize,selfverify boundary;
Aeglos existingverified_ms boundary, sameprimaryrequest/public/VKbinding.

Nativehost execution, identicalallocatorpolicy, fixedprocessmasks andexisting
individualZoproworkerplacement/defaultstacks. Aeglos threadcountconfig retained.
One30GiB/no-swap systemdservice is infrastructureheadroom, not proverRAMcap.
Record unitandancestorCPU/memorylimits/events/readfailures andmount/cgroup scope;
do not infer unavailableCPUquota fields orphysicalpressure/phone/minRAM/throughput.
Source188/consumers/tools/config/inputfiles hashed and inspected, no giant LUT,
expandedkey/newpool/C/ASM/Python introduced bythismeasurement work.

Freeze runner/readers/config beforeANYnewlocalproof. Fourlocal4workerfunctional
smokes:primaryON/PARENT/Aeglos,merge54ON;3primes+1timed each. All4captures precede
their4freshGnarkverifiers. Independent plan/raw/binding reader mustpass before
packaging; no repeatedlocalGnarkforbookkeeping. Local directory immutable.
Separate remote bundle receives resulting inventory62191; no overwriting local
smokepins/config/seed. Startcanonical62187 SHA38314450cd7201e88e527845db52c4de60479688cc2c7b8d0201c4d472596ff3.

Remote22preflightcaptures(18ON+2primaryPARENT+2AEGLOS) then22Gnarkverifiers;
bothsemanticandseparatereaderPASSbeforeguardedmain. Nine matchedrotated/reversed
blocks x22contexts=198mainfreshprocesses,17timed+3prime each. Allmaincapture
beforelate198verifiers/offlineanalysis. No ownedCPUcojobduringANYSDKcapture;
onlypollconfirmedhandleuntilterminal. All3independentexecutablebackings per
enginefamilyparticipateblock%3; allobservationsretained. Noretry/exclusion/
extension/threshold/worker/layout/host rescue. Fourlocal+220remoteexports,
16local+4048remoteSDKcalls=4064,3392timedrecords. Expectedfinal62411canonical.
Remoteexports independently verified afterretrievalonhost; reverification adds
no distinctproof. Preservepartials; resumeonlydemonstrablymissingwork.

Report9blockpairedmedians andsortedranks1..7(nominal96.09375%marginalmedian
coverage under independentcontinuousblock assumptions,notfamilywise),allbackings,
CPU/RSS,and96/32scaling. Compareall8suppliedM5CPU/Metalreferences atBOTHcounts;
count10xtargetonlyifupperrank7<=CPUref/10 atpredeclaredcount. No merge54M5ref.
ON/PARENTprimaryupper<1 supportsgain,otherwiseinconclusive/slower. Aeglos
descriptiveequalworkerandbesteachdeclaredcount comparisons,notlatestengineclaim.
No minimumgainfloor or newadoptionveto onalreadyqualifiedlocal233.

AWSauthcurrentlyfails expiredSSO/refresh. Preparelocallywithoutquestions. No
publish/VMbeforevalididentity+>=110minremainingcredentials,correctaccount,
emptyownedbenchmark-instancequery,restrictednoingressSG andexactsource/payload
pins. OneownedVM only, idempotentClientToken,90minterminateTTL, SSM/noSSH,
privateserverencryptedtransferbucket. Boundedremotecommands. Retrieve/hash/
hostverify, thenremove/checkownedVM/EBS/temporarybucketobjects andsecretURLfiles.
No ECRneeded. No pushwithoutfreshapproval. Recordprep/wait/firstresultelapsed;
30min initialprep/firstresultallowance excludesexplicitwaitingforrequiredlogin.
Ifauthunavailable,retainconcretereviewablepreparedstate,do notclaimAWSrun.
