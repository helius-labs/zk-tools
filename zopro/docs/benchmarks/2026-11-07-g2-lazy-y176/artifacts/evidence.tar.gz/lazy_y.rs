// Private experiment: generated Ifma8 arithmetic is unchanged.
#[repr(transparent)]
#[derive(Clone, Copy, Debug)]
pub struct LazyFq([u64; 4]);
impl LazyFq {
    #[inline(always)]
    pub fn from_canonical(x: crate::Fq) -> Self { Self(x.0) }
    #[inline(always)]
    pub fn canonical(self) -> crate::Fq {
        crate::Fq::from_montgomery(crate::portable::reduce_once(self.0, crate::FqConfig::P))
    }
    #[inline(always)]
    pub fn is_zero(self) -> bool { self.0 == [0;4] || self.0 == crate::FqConfig::P }
    pub fn words(self) -> [u64;4] { self.0 }
    #[cfg(zopro_lazy_y_qualify)]
    pub fn qualification_from_words(w: [u64;4]) -> Self {
        assert!(crate::portable::less(w, crate::portable::add4(crate::FqConfig::P,crate::FqConfig::P).0));
        Self(w)
    }
}

#[derive(Clone, Copy)]
pub struct LazyY8(Ifma8<crate::FqConfig,true>);
impl LazyY8 {
    #[inline(always)]
    pub fn new(x: &[LazyFq;8]) -> Self { Self(Ifma8::raw(&x.map(|v|v.0))) }
    #[inline(always)]
    pub fn from_batch(x: Ifma8<crate::FqConfig,true>) -> Self { Self(x) }
    #[inline(always)]
    pub fn batch(self) -> Ifma8<crate::FqConfig,true> { self.0 }
    #[inline(always)]
    pub fn get(self) -> [LazyFq;8] {
        // Exact original mixed export packing and transpose, without reduce(p).
        // SAFETY: normalized numerical values <2p fit in four words; LazyFq
        // is transparent over those words. Four unaligned stores initialize
        // the entire eight-element array. Module guards supply AVX-512.
        unsafe {
            let [t0,t1,t2,t3,t4]=self.0.0;
            let w0=_mm512_or_si512(t0,_mm512_slli_epi64::<52>(t1));
            let w1=_mm512_or_si512(_mm512_srli_epi64::<12>(t1),_mm512_slli_epi64::<40>(t2));
            let w2=_mm512_or_si512(_mm512_srli_epi64::<24>(t2),_mm512_slli_epi64::<28>(t3));
            let w3=_mm512_or_si512(_mm512_srli_epi64::<36>(t3),_mm512_slli_epi64::<16>(t4));
            let a=_mm512_unpacklo_epi64(w0,w1);
            let b=_mm512_unpackhi_epi64(w0,w1);
            let c=_mm512_unpacklo_epi64(w2,w3);
            let d=_mm512_unpackhi_epi64(w2,w3);
            let low=_mm512_set_epi64(11,10,3,2,9,8,1,0);
            let high=_mm512_set_epi64(15,14,7,6,13,12,5,4);
            let even_lo=_mm512_permutex2var_epi64(a,low,c);
            let even_hi=_mm512_permutex2var_epi64(a,high,c);
            let odd_lo=_mm512_permutex2var_epi64(b,low,d);
            let odd_hi=_mm512_permutex2var_epi64(b,high,d);
            let mut out=core::mem::MaybeUninit::<[LazyFq;8]>::uninit();
            let p=out.as_mut_ptr().cast::<__m512i>();
            _mm512_storeu_si512(p,_mm512_shuffle_i64x2::<0x44>(even_lo,odd_lo));
            _mm512_storeu_si512(p.add(1),_mm512_shuffle_i64x2::<0xee>(even_lo,odd_lo));
            _mm512_storeu_si512(p.add(2),_mm512_shuffle_i64x2::<0x44>(even_hi,odd_hi));
            _mm512_storeu_si512(p.add(3),_mm512_shuffle_i64x2::<0xee>(even_hi,odd_hi));
            out.assume_init()
        }
    }
}

// Wide values never escape this helper into ordinary field methods.
struct Wide3(Ifma8<crate::FqConfig,true>);
impl Wide3 {
    #[inline(always)]
    fn delta(by: &Ifma8<crate::FqConfig,true>, ay: &LazyY8, negative:u8) -> Self {
        unsafe {
            type B=Ifma8<crate::FqConfig,true>;
            let p=crate::FqConfig::P;
            let twice=crate::portable::add4(p,p).0;
            let three=crate::portable::add4(twice,p).0;
            let two=split(twice);
            let three=split(three);
            let flip=_mm512_maskz_mov_epi64(negative,B::splat(MASK));
            let mut carry=_mm512_maskz_mov_epi64(negative,B::splat(1));
            let mut t=[B::splat(0);5];
            for j in 0..5 {
                let offset=_mm512_mask_blend_epi64(negative,B::splat(two[j]),B::splat(three[j]));
                let signed=_mm512_xor_si512(by.0[j],flip);
                let v=_mm512_add_epi64(_mm512_sub_epi64(_mm512_add_epi64(offset,signed),ay.0.0[j]),carry);
                t[j]=_mm512_and_si512(v,B::splat(MASK));
                carry=_mm512_srai_epi64::<52>(v);
            }
            Self(Ifma8(t,PhantomData))
        }
    }
    #[inline(always)]
    fn complement(self) -> Self {
        unsafe {
            type B=Ifma8<crate::FqConfig,true>;
            let twice=crate::portable::add4(crate::FqConfig::P,crate::FqConfig::P).0;
            let three=split(crate::portable::add4(twice,crate::FqConfig::P).0);
            let mut t=[B::splat(0);5];
            let mut carry=B::splat(0);
            for j in 0..5 {
                let v=_mm512_add_epi64(_mm512_sub_epi64(B::splat(three[j]),self.0.0[j]),carry);
                t[j]=_mm512_and_si512(v,B::splat(MASK));
                carry=_mm512_srai_epi64::<52>(v);
            }
            Self(Ifma8(t,PhantomData))
        }
    }
}

/// Canonical incoming Y, lazy bucket Y and ordinary canonical-X differences.
/// Return the conjugate numerator with the ordinary strict <2p contract.
#[inline(always)]
pub fn lazy_y_numerator(by:&[[crate::Fq;8];2],ay:&[LazyY8;2],dx:&[Ifma8<crate::FqConfig,true>;2],negative:u8)->[Ifma8<crate::FqConfig,true>;2] {
    let d0=Wide3::delta(&Ifma8::new(&by[0]),&ay[0],negative);
    let d1=Wide3::delta(&Ifma8::new(&by[1]),&ay[1],negative);
    let real=d0.0.product::<true>(&dx[0],&d1.0,&dx[1]);
    let imaginary=d1.0.product::<true>(&dx[0],&d0.complement().0,&dx[1]);
    [real,imaginary]
}

#[cfg(zopro_lazy_y_qualify)]
pub fn qualification_delta(by:&[crate::Fq;8],ay:&LazyY8,negative:u8)->[[u64;5];8] {
    let v=Wide3::delta(&Ifma8::new(by),ay,negative);
    let words:[[u64;8];5]=unsafe {v.0.0.map(|x|core::mem::transmute(x))};
    core::array::from_fn(|i|core::array::from_fn(|j|words[j][i]))
}
