use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::{Path,PathBuf},collections::BTreeMap,process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-lazy-y176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
const D:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-07-g2-lazy-y176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn compact(s:&str)->String{s.chars().filter(|c|!c.is_whitespace()).collect()}
fn write(p:impl AsRef<Path>,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn main(){
 assert!(!Path::new(D).exists());assert!(!Path::new(&format!("{R}/review.json")).exists());
 let pins=read(format!("{R}/normalization-pins.json"));for(p,h)in pins.as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
 let manifest=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
 let audit=read(format!("{R}/source-audit.json"));let suffix=audit["parent_suffix"].as_str().unwrap();
 for(n,h)in manifest["source_files_sha256"].as_object().unwrap(){assert_eq!(hash(format!("{Z}/{n}")),h.as_str().unwrap());let mut b=fs::read(format!("{R}/source/{n}")).unwrap();if n=="crates/zopro-bn254/src/ifma8.rs"{assert!(b.ends_with(suffix.as_bytes()));b.truncate(b.len()-suffix.len());}assert_eq!(format!("{:x}",Sha256::digest(b)),h.as_str().unwrap());}
 assert_eq!(fs::read(format!("{R}/lazy_y.rs")).unwrap(),fs::read(format!("{R}/source/crates/zopro-bn254/src/lazy_y.rs")).unwrap());
 let original=fs::read_to_string(format!("{R}/qualify.rs")).unwrap();assert_eq!(original.matches("v.invert().unwrap()").count(),1);assert_eq!(fs::read_to_string(format!("{R}/qualify2.rs")).unwrap(),original.replace("v.invert().unwrap()","v.inverse().unwrap()"));
 let original=compact(&fs::read_to_string(format!("{Z}/crates/zopro-bn254/src/ifma8.rs")).unwrap());
 let child=compact(&fs::read_to_string(format!("{R}/lazy_y.rs")).unwrap());
 let end="out.assume_init()";
 let extract=|s:&str,anchor:&str|{let a=s.find(anchor).unwrap();let b=a+s[a..].find(end).unwrap()+end.len();s[a..b].to_owned()};
 assert_eq!(extract(&original,"let[t0,t1,t2,t3,t4]=x.0"),extract(&child,"let[t0,t1,t2,t3,t4]=self.0.0").replace("self.0.0","x.0").replace("[LazyFq;8]","[Fp<C>;8]"));
 let mut commands=Vec::new();let mut successes=0;let mut failures=0;
 for(plan,run,names)in[("plan.json","runs",vec!["build-new-lazy-y-field","build-new-lazy-y-qualification"]),("plan2.json","runs2",vec!["build-corrected-lazy-y-qualification","qualify-lazy-y-ranges-and-point-lifetime"]),("normalization-plan.json","normalization-runs",vec!["build-safe-terminal-normalization","qualify-safe-terminal-allocation-reuse"]) ]{
  let plan=read(format!("{R}/{plan}"));for n in names{let base=format!("{R}/{run}/{n}");let exit=read(format!("{base}/exit.json"));let cmd=read(format!("{base}/command.json"));
   let step=plan["steps"].as_array().unwrap().iter().find(|s|s["name"]==n).unwrap();let argv=cmd["argv"].as_array().unwrap();assert_eq!(&argv[4..],step["argv"].as_array().unwrap().as_slice());assert_eq!(argv[0],"timeout");
   let expect=if n=="build-new-lazy-y-qualification"{failures+=1;1}else{successes+=1;0};assert_eq!(exit["returncode"],expect);assert_eq!(exit["success"],expect==0);
   for stream in["stdout","stderr"]{assert_eq!(exit[format!("{stream}_sha256")],hash(format!("{base}/{stream}.log")));}commands.push(json!({"directory":base,"command":cmd,"exit":exit}));
  }
 }
 assert_eq!((successes,failures),(5,1));
 let q=read(format!("{R}/qualification.json"));assert_eq!(q["passed"],true);assert_eq!(q["numerator_cases"],21320);assert_eq!(q["native_numerator_outputs"],42640);assert_eq!(q["scaled_numerator_outputs"],42640);assert_eq!(q["point_outputs"],512);assert_eq!(q["new_proofs"],0);assert_eq!(q["new_timings"],0);assert_eq!(q["bucket_bytes"],128);
 assert!(q["fused_2p_corrections"].as_u64().unwrap()>0&&q["inclusive_3p_deltas"].as_u64().unwrap()>0&&q["noncanonical_point_Y_components"].as_u64().unwrap()>0);
 let a=read(format!("{R}/normalization.json"));assert_eq!(a["passed"],true);assert_eq!(a["cases"],14);assert_eq!(a["rows"].as_array().unwrap().len(),14);for row in a["rows"].as_array().unwrap(){assert_eq!(row["allocations"],0);assert_eq!(row["reallocations"],0);assert_eq!(row["deallocations"],0);assert_eq!(row["pointer_preserved"],true);assert_eq!(row["input_capacity"],row["output_capacity"]);}
 let review=json!({"passed":true,"scope":"Pins, source recovery, exact original export packing, actual receipt argv/stream hashes, qualification counts and conversion allocation evidence. Successful qualifications are not rerun.","pins":pins.as_object().unwrap().len(),"original_sources":176,"source_recovery":true,"raw_packing_transpose_store_exact":true,"successful_workflow_commands":successes,"retained_failed_driver_compiles":failures,"commands":commands,"new_proofs":0,"new_timings":0,"production_adopted":false,"performance_qualification_pending":true,"complete_Window_qualification_pending":true,"goal_active":true,"targets_achieved":0});write(format!("{R}/review.json"),&review);
 let stage=PathBuf::from(format!("{R}/public-evidence"));assert!(!stage.exists());fs::create_dir(&stage).unwrap();
 let mut members=BTreeMap::new();
 let mut files=vec!["design.md","lazy_y.rs","qualify.rs","qualify2.rs","prepare.rs","repair-driver.rs","normalize.rs","prepare-normalize.rs","review-publish.rs","source-audit.json","qualification.json","normalization.json","pins.json","pins2.json","normalization-pins.json","plan.json","plan2.json","normalization-plan.json","review.json"].into_iter().map(str::to_owned).collect::<Vec<_>>();
 for command in review["commands"].as_array().unwrap(){let directory=command["directory"].as_str().unwrap().strip_prefix(&format!("{R}/")).unwrap();for leaf in["command.json","exit.json","stdout.log","stderr.log","tests.json"]{files.push(format!("{directory}/{leaf}"));}}
 for leaf in &files{let from=format!("{R}/{leaf}");let bytes=fs::read(&from).unwrap();assert!(std::str::from_utf8(&bytes).is_ok());let to=stage.join(leaf);fs::create_dir_all(to.parent().unwrap()).unwrap();fs::write(&to,&bytes).unwrap();assert_eq!(fs::read(&to).unwrap(),bytes);members.insert(leaf.clone(),hash(&to));}
 fs::write(stage.join("SHA256SUMS"),members.iter().map(|(n,h)|format!("{h}  {n}\n")).collect::<String>()).unwrap();files.push("SHA256SUMS".into());
 let ad=PathBuf::from(D).join("artifacts");fs::create_dir_all(&ad).unwrap();
 let archive=ad.join("evidence.tar.gz");let mut tar=Command::new("tar");tar.args(["-czf"]).arg(&archive).arg("-C").arg(&stage).args(&files);assert!(tar.status().unwrap().success());
 let listing=Command::new("tar").args(["-tzf"]).arg(&archive).output().unwrap();assert!(listing.status.success());let got=String::from_utf8(listing.stdout).unwrap().lines().map(str::to_owned).collect::<Vec<_>>();assert_eq!(got,files);
 assert!(Command::new("tar").args(["--compare","--gzip","--file"]).arg(&archive).arg("-C").arg(&stage).status().unwrap().success());
 let mut public=BTreeMap::new();for leaf in["design.md","qualification.json","normalization.json","source-audit.json","review.json"]{fs::copy(format!("{R}/{leaf}"),ad.join(leaf)).unwrap();public.insert(format!("artifacts/{leaf}"),hash(ad.join(leaf)));}public.insert("artifacts/evidence.tar.gz".into(),hash(&archive));
 fs::copy(format!("{R}/README.md"),Path::new(D).join("README.md")).unwrap();public.insert("README.md".into(),hash(Path::new(D).join("README.md")));
 let publication=json!({"passed":true,"archive_members":files,"archive_members_sha256":members,"archive_sha256":hash(&archive),"exact_tar_list_and_byte_comparison":true,"public_members_sha256":public,"excluded":"Compiled libraries/binaries/targets, original inherited sources, private keys/points/scalars/witnesses/proofs, old raw profiles and proof inventories","new_proofs":0,"new_timings":0});write(ad.join("publication.json"),&publication);public.insert("artifacts/publication.json".into(),hash(ad.join("publication.json")));
 fs::write(Path::new(D).join("SHA256SUMS"),public.iter().map(|(n,h)|format!("{h}  {n}\n")).collect::<String>()).unwrap();
 println!("PASS {} pins; 176 source recovery; exact raw packing; five successful commands plus one retained compile failure; {} safe-text archive members; no timing/adoption",pins.as_object().unwrap().len(),publication["archive_members"].as_array().unwrap().len());
}
