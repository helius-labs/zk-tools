use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-lazy-y176";
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 let original=fs::read_to_string(format!("{R}/qualify.rs")).unwrap();assert_eq!(original.matches("v.invert().unwrap()").count(),1);
 let dest=format!("{R}/qualify2.rs");assert!(!Path::new(&dest).exists());fs::write(&dest,original.replace("v.invert().unwrap()","v.inverse().unwrap()")).unwrap();
 let mut pins:Value=serde_json::from_slice(&fs::read(format!("{R}/pins.json")).unwrap()).unwrap();
 for leaf in ["qualify2.rs","repair-driver.rs","libzopro_bn254.rlib","plan.json","runs/build-new-lazy-y-field/command.json","runs/build-new-lazy-y-field/exit.json","runs/build-new-lazy-y-field/stderr.log","runs/build-new-lazy-y-field/stdout.log","runs/build-new-lazy-y-qualification/command.json","runs/build-new-lazy-y-qualification/exit.json","runs/build-new-lazy-y-qualification/stderr.log","runs/build-new-lazy-y-qualification/stdout.log"]{let p=format!("{R}/{leaf}");pins[p.clone()]=hash(&p).into();}
 let plan:Value=serde_json::from_slice(&fs::read(format!("{R}/plan.json")).unwrap()).unwrap();let mut build=plan["steps"][1].clone();build["name"]="build-corrected-lazy-y-qualification".into();for a in build["argv"].as_array_mut().unwrap(){if a.as_str()==Some(&format!("{R}/qualify.rs")){*a=dest.clone().into();}else if a.as_str()==Some(&format!("{R}/qualify")){*a=format!("{R}/qualify2").into();}}
 fs::write(format!("{R}/pins2.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
 let new=json!({"version":1,"source_pins":format!("{R}/pins2.json"),"steps":[build,{"kind":"command","name":"qualify-lazy-y-ranges-and-point-lifetime","argv":[format!("{R}/qualify2")],"timeout_seconds":180}]});
 fs::write(format!("{R}/plan2.json"),serde_json::to_vec_pretty(&new).unwrap()).unwrap();println!("Correct only driver method spelling; retain compiler failure and reuse successful native field build");
}
