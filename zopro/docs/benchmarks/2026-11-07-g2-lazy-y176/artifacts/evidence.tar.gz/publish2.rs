use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::{Path,PathBuf},collections::BTreeMap,process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-lazy-y176";
const D:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-07-g2-lazy-y176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert!(!Path::new(D).exists());let review=read(format!("{R}/review.json"));assert_eq!(review["passed"],true);
 // Consume the saved successful review; do not rerun it or qualifications.
 assert_eq!(fs::read(format!("{R}/review.json")).unwrap(),fs::read(format!("{R}/public-evidence/review.json")).unwrap());
 let stage=PathBuf::from(format!("{R}/public-evidence2"));assert!(!stage.exists());fs::create_dir(&stage).unwrap();
 let mut files=vec!["design.md","lazy_y.rs","qualify.rs","qualify2.rs","prepare.rs","repair-driver.rs","normalize.rs","prepare-normalize.rs","review-publish.rs","publish2.rs","publication-failure.json","source-audit.json","qualification.json","normalization.json","pins.json","pins2.json","normalization-pins.json","plan.json","plan2.json","normalization-plan.json","review.json"].into_iter().map(str::to_owned).collect::<Vec<_>>();
 for command in review["commands"].as_array().unwrap(){let directory=command["directory"].as_str().unwrap().strip_prefix(&format!("{R}/")).unwrap();for leaf in["command.json","exit.json","stdout.log","stderr.log"]{files.push(format!("{directory}/{leaf}"));}let tests=format!("{directory}/tests.json");if Path::new(&format!("{R}/{tests}")).exists(){files.push(tests);}else{assert_eq!(command["exit"]["success"],false);}}
 let mut members=BTreeMap::new();for leaf in &files{let from=format!("{R}/{leaf}");let bytes=fs::read(&from).unwrap();assert!(std::str::from_utf8(&bytes).is_ok());let to=stage.join(leaf);fs::create_dir_all(to.parent().unwrap()).unwrap();fs::write(&to,&bytes).unwrap();assert_eq!(fs::read(&to).unwrap(),bytes);members.insert(leaf.clone(),hash(&to));}
 fs::write(stage.join("SHA256SUMS"),members.iter().map(|(n,h)|format!("{h}  {n}\n")).collect::<String>()).unwrap();files.push("SHA256SUMS".into());
 let ad=PathBuf::from(D).join("artifacts");fs::create_dir_all(&ad).unwrap();let archive=ad.join("evidence.tar.gz");
 let mut tar=Command::new("tar");tar.arg("-czf").arg(&archive).arg("-C").arg(&stage).args(&files);assert!(tar.status().unwrap().success());
 let listing=Command::new("tar").arg("-tzf").arg(&archive).output().unwrap();assert!(listing.status.success());assert_eq!(String::from_utf8(listing.stdout).unwrap().lines().map(str::to_owned).collect::<Vec<_>>(),files);
 assert!(Command::new("tar").args(["--compare","--gzip","--file"]).arg(&archive).arg("-C").arg(&stage).status().unwrap().success());
 let mut public=BTreeMap::new();for leaf in["design.md","qualification.json","normalization.json","source-audit.json","review.json"]{fs::copy(format!("{R}/{leaf}"),ad.join(leaf)).unwrap();public.insert(format!("artifacts/{leaf}"),hash(ad.join(leaf)));}public.insert("artifacts/evidence.tar.gz".into(),hash(&archive));
 fs::copy(format!("{R}/README.md"),Path::new(D).join("README.md")).unwrap();public.insert("README.md".into(),hash(Path::new(D).join("README.md")));
 let publication=json!({"passed":true,"uses_cached_successful_review":true,"archive_members":files,"archive_members_sha256":members,"archive_sha256":hash(&archive),"exact_tar_list_and_byte_comparison":true,"public_members_sha256":public,"excluded":"Compiled libraries/binaries/targets, original inherited sources, private keys/points/scalars/witnesses/proofs, old raw profiles and proof inventories","retained_publication_failure":"publication-failure.json inside archive","new_proofs":0,"new_timings":0});fs::write(ad.join("publication.json"),serde_json::to_vec_pretty(&publication).unwrap()).unwrap();public.insert("artifacts/publication.json".into(),hash(ad.join("publication.json")));
 fs::write(Path::new(D).join("SHA256SUMS"),public.iter().map(|(n,h)|format!("{h}  {n}\n")).collect::<String>()).unwrap();
 println!("PASS cached review; {} exact safe-text archive members, sha256 {}; no qualification/review replay",publication["archive_members"].as_array().unwrap().len(),hash(&archive));
}
