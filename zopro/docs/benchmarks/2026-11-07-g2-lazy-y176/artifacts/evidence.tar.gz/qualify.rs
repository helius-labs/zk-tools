use num_bigint::BigUint as U;
use num_traits::{One,Zero,ToPrimitive};
use serde_json::json;
use zopro_bn254::{FpConfig,Fq,FqConfig,Fq2,Field,G2Affine,G2Projective,Fr};
use zopro_bn254::ifma8::{Ifma8,LazyFq,LazyY8,lazy_y_numerator,qualification_delta};
type B=Ifma8<FqConfig,true>;
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/g2-lazy-y176";
const MASK:u128=(1u128<<52)-1;
fn integer(w:[u64;4])->U{U::from_bytes_le(&w.into_iter().flat_map(u64::to_le_bytes).collect::<Vec<_>>())}
fn words(x:&U)->[u64;4]{let d=x.to_u64_digits();assert!(d.len()<=4);core::array::from_fn(|i|*d.get(i).unwrap_or(&0))}
fn digits(x:&U)->[u128;5]{core::array::from_fn(|i|((x>>(i*52))&U::from(MASK)).to_u128().unwrap())}
fn combine(x:&[u128])->U{x.iter().enumerate().map(|(i,v)|U::from(*v)<<(i*52)).sum()}
fn fq(x:&U,p:&U)->Fq{assert!(x<p);Fq::from_montgomery(words(x))}
fn lazy(x:&U)->LazyFq{LazyFq::qualification_from_words(words(x))}
fn random(seed:&mut u64,limit:&U)->U{let mut b=[0u8;32];for c in b.chunks_mut(8){*seed^=*seed<<13;*seed^=*seed>>7;*seed^=*seed<<17;c.copy_from_slice(&seed.to_le_bytes());}U::from_bytes_le(&b)%limit}

// Independent integer model of the accepted cancel-carry CIOS recurrence.
// Reuses its established mathematical algorithm, not an old test population.
fn cios(v:&[U;4],p:&U,ni:&U,max:&mut u128)->U{
    let pd=digits(p);let d=v.each_ref().map(digits);
    let inv=(ni&U::from(MASK)).to_u128().unwrap();let mut t=[0u128;6];
    for row in 0..5 {
        for j in 0..5 {for product in [d[0][j]*d[1][row],d[2][j]*d[3][row]] {t[j]+=product&MASK;t[j+1]+=product>>52;}}
        let width=if row==4{48}else{52};let rm=(1u128<<width)-1;
        let m=(t[0]*inv)&rm;
        let low=((t[0]+rm)>>width)+(((m<<(52-width))*pd[0])>>52);
        for j in 1..5 {let product=m*pd[j];t[j]+=product&MASK;t[j+1]+=product>>52;}
        for &x in &t {*max=(*max).max(x);assert!(x<(1u128<<64));}
        if width==52 {t[1]+=low;t=[t[1],t[2],t[3],t[4],t[5],0];}
        else {t=[low+((t[1]&rm)<<4),(t[1]>>48)+((t[2]&rm)<<4),(t[2]>>48)+((t[3]&rm)<<4),(t[3]>>48)+((t[4]&rm)<<4),(t[4]>>48)+(t[5]<<4),0];}
    }
    for j in 0..4{t[j+1]+=t[j]>>52;t[j]&=MASK;}
    assert!(t[..5].iter().all(|v|*v<=MASK));assert!(t[4]<(1u128<<48));
    combine(&t[..5])
}

#[derive(Clone)]
struct Row{by:[U;2],ay:[U;2],dx:[U;2],negative:bool}
fn main(){
    let output=format!("{ROOT}/qualification.json");assert!(!std::path::Path::new(&output).exists());
    let p=integer(FqConfig::P);let two=&p*2u32;let three=&p*3u32;let r=U::one()<<256;
    assert!(&p*4u32<r);assert!(&p*&p*12u32<&p*&r*3u32);
    let mut pi=U::one();for _ in 0..9 {pi=&pi*(&r+2u32-(&pi*&p)%&r)%&r;}
    assert_eq!(&pi*&p%&r,U::one());let ni=&r-pi;
    let rinv=r.modpow(&(&p-2u32),&p);
    let by_values=[U::zero(),U::one(),&p-1u32];
    let ay_values=[U::zero(),U::one(),&p-1u32,p.clone(),&p+1u32,&two-1u32];
    let dx_values=[U::zero(),U::one(),&p-1u32,p.clone(),&two-1u32];
    let boundary=3usize.pow(2)*6usize.pow(2)*5usize.pow(2)*2;
    assert_eq!(boundary,16200);
    let mut seed=0x913dc4b72985af16;
    let mut chain:[U;2]=[p.clone(),&two-1u32];
    let mut max_coefficient=0;let mut reductions=0usize;let mut endpoint_3p=0usize;
    let mut lazy_outputs=0usize;let mut cases=0usize;
    for start in (0..boundary+4096+1024).step_by(8){
        let rows:[Row;8]=core::array::from_fn(|lane|{
            let index=start+lane;
            if index<boundary {
                let mut t=index;let negative=t%2!=0;t/=2;
                let by=core::array::from_fn(|_|{let x=by_values[t%3].clone();t/=3;x});
                let ay=core::array::from_fn(|_|{let x=ay_values[t%6].clone();t/=6;x});
                let dx=core::array::from_fn(|_|{let x=dx_values[t%5].clone();t/=5;x});
                assert_eq!(t,0);Row{by,ay,dx,negative}
            }else{
                let by=core::array::from_fn(|_|random(&mut seed,&p));
                let ay=if index>=boundary+4096 {chain.clone()}else{core::array::from_fn(|_|random(&mut seed,&two))};
                let dx=core::array::from_fn(|_|random(&mut seed,&two));
                Row{by,ay,dx,negative:index%3!=0}
            }
        });
        let negative=rows.iter().enumerate().fold(0u8,|a,(i,v)|a|u8::from(v.negative)<<i);
        let by:[[Fq;8];2]=core::array::from_fn(|j|core::array::from_fn(|i|fq(&rows[i].by[j],&p)));
        let yvalues:[[LazyFq;8];2]=core::array::from_fn(|j|core::array::from_fn(|i|lazy(&rows[i].ay[j])));
        let ay=yvalues.map(|v|LazyY8::new(&v));
        let dx:[B;2]=core::array::from_fn(|j|LazyY8::new(&core::array::from_fn(|i|lazy(&rows[i].dx[j]))).batch());
        for j in 0..2{assert_eq!(ay[j].get().map(LazyFq::words),yvalues[j].map(LazyFq::words));for i in 0..8{assert_eq!(ay[j].get()[i].canonical(),fq(&(&rows[i].ay[j]%&p),&p));assert_eq!(yvalues[j][i].is_zero(),(&rows[i].ay[j]%&p).is_zero());}}
        let raw_delta:[[[u64;5];8];2]=core::array::from_fn(|j|qualification_delta(&by[j],&ay[j],negative));
        let numerator=lazy_y_numerator(&by,&ay,&dx,negative);
        let raw=numerator.map(|v|LazyY8::from_batch(v).get().map(|x|integer(x.words())));
        let factor:[Fq;8]=core::array::from_fn(|_|fq(&random(&mut seed,&p),&p));
        let scaled=numerator.map(|v|v.mul(&B::new(&factor)).get());
        for i in 0..8 {
            let row=&rows[i];
            let delta:[U;2]=core::array::from_fn(|j|if row.negative{&three-&row.by[j]-&row.ay[j]}else{&two+&row.by[j]-&row.ay[j]});
            for j in 0..2 {
                let actual=combine(&raw_delta[j][i].map(u128::from));
                assert!(raw_delta[j][i].iter().all(|d|*d<=MASK as u64));
                assert!(raw_delta[j][i][4]<(1u64<<48));
                assert_eq!(actual,delta[j]);assert!(actual<=three);
                endpoint_3p+=usize::from(actual==three);
            }
            let operands=[ [delta[0].clone(),row.dx[0].clone(),delta[1].clone(),row.dx[1].clone()], [delta[1].clone(),row.dx[0].clone(),&three-&delta[0],row.dx[1].clone()] ];
            let dy=Fq2::new(fq(&(&row.by[0]%&p),&p),fq(&(&row.by[1]%&p),&p));
            let old=Fq2::new(yvalues[0][i].canonical(),yvalues[1][i].canonical());
            let dx_ref=Fq2::new(fq(&(&row.dx[0]%&p),&p),fq(&(&row.dx[1]%&p),&p));
            let expected=((if row.negative{-dy}else{dy})-old)*dx_ref.conjugate();
            for j in 0..2 {
                let v=&operands[j];let t=&v[0]*&v[1]+&v[2]*&v[3];assert!(t<=&p*&p*12u32);
                let exact=(&t+((&t*&ni)%&r)*&p)>>256;
                assert_eq!((&t+((&t*&ni)%&r)*&p)%&r,U::zero());
                assert_eq!(cios(v,&p,&ni,&mut max_coefficient),exact);assert!(exact<&p*4u32);
                let corrected=if exact>=two{reductions+=1;exact-&two}else{exact};assert!(corrected<two);
                assert_eq!(raw[j][i],corrected);
                assert_eq!(&raw[j][i]%&p,(&t*&rinv)%&p);
                assert_eq!(fq(&(&raw[j][i]%&p),&p),if j==0{expected.c0}else{expected.c1});
                assert_eq!(scaled[j][i],(if j==0{expected.c0}else{expected.c1})*factor[i]);
                lazy_outputs+=usize::from(raw[j][i]>=p);
            }
            chain=[raw[0][i].clone(),raw[1][i].clone()];cases+=1;
        }
    }
    // Native formula chain over actual curve points. The first Y is lifted;
    // subsequent outputs stay lazy, so this checks the changed lifetime.
    let g=G2Projective::generator();
    let mut points:[G2Affine;8]=core::array::from_fn(|i|(g*Fr::from(9001+i as u64)).to_affine());
    let mut ys:[LazyY8;2]=core::array::from_fn(|j|LazyY8::new(&core::array::from_fn(|i|{let y=if j==0{points[i].y.c0}else{points[i].y.c1};lazy(&(integer(y.0)+&p))})));
    let incoming:[G2Affine;8]=core::array::from_fn(|i|(g*Fr::from(1234567+17*i as u64)).to_affine());
    let mut point_outputs=0usize;let mut lazy_point_outputs=0usize;
    for step in 0..64usize {
        let signs=(step as u8).wrapping_mul(73)^0xa5;
        let ax:[B;2]=core::array::from_fn(|j|B::new(&points.map(|q|if j==0{q.x.c0}else{q.x.c1})));
        let bx:[B;2]=core::array::from_fn(|j|B::new(&incoming.map(|q|if j==0{q.x.c0}else{q.x.c1})));
        let dx:[B;2]=core::array::from_fn(|j|bx[j].sub_canonical(&ax[j]));
        let norm=dx[0].sum2(&dx[0],&dx[1],&dx[1]).get();
        let inverse=B::new(&norm.map(|v|v.invert().unwrap()));
        let by=core::array::from_fn(|j|incoming.map(|q|if j==0{q.y.c0}else{q.y.c1}));
        let slope=lazy_y_numerator(&by,&ys,&dx,signs).map(|v|v.mul(&inverse));
        let square=[slope[0].difference2(&slope[0],&slope[1],&slope[1]),slope[0].sum2(&slope[1],&slope[0],&slope[1])];
        let x:[B;2]=core::array::from_fn(|j|square[j].sub(&ax[j].add_canonical(&bx[j])));
        let xdelta:[B;2]=core::array::from_fn(|j|ax[j].sub(&x[j]));
        let product=[slope[0].difference2(&xdelta[0],&slope[1],&xdelta[1]),slope[0].sum2(&xdelta[1],&slope[1],&xdelta[0])];
        ys=core::array::from_fn(|j|LazyY8::from_batch(product[j].sub(&ys[j].batch())));
        let x=x.map(|v|v.get());let y=ys.map(|v|v.get());
        for i in 0..8 {
            let signed=if signs>>i&1!=0{-incoming[i]}else{incoming[i]};
            assert_ne!(points[i].x,signed.x);
            let expected=(points[i]+signed).to_affine();
            let actual=G2Affine::new(Fq2::new(x[0][i],x[1][i]),Fq2::new(y[0][i].canonical(),y[1][i].canonical()));
            assert_eq!(actual,expected);
            for j in 0..2 {assert!(integer(y[j][i].words())<two);lazy_point_outputs+=usize::from(integer(y[j][i].words())>=p);}
            points[i]=actual;point_outputs+=1;
        }
    }
    assert_eq!(cases,boundary+4096+1024);assert!(reductions>0&&endpoint_3p>0&&lazy_outputs>0&&lazy_point_outputs>0);
    assert_eq!(std::mem::size_of::<LazyFq>(),32);assert_eq!(std::mem::align_of::<LazyFq>(),8);
    #[allow(dead_code)]struct Bucket{x:Fq2,y:[LazyFq;2]}
    assert_eq!(std::mem::size_of::<Bucket>(),std::mem::size_of::<G2Affine>());
    assert_eq!(std::mem::align_of::<Bucket>(),std::mem::align_of::<G2Affine>());
    let result=json!({"passed":true,"scope":"Actual native Fq R256 field boundary/numerator and full G2 point chains; no complete Window, tail, prefix batching or performance qualification", "boundary_cases":boundary,"random_cases":4096,"output_fed_cases":1024,"numerator_cases":cases,"native_numerator_outputs":2*cases,"scaled_numerator_outputs":2*cases,"inclusive_3p_deltas":endpoint_3p,"fused_2p_corrections":reductions,"noncanonical_numerator_outputs":lazy_outputs,"max_CIOS_coefficient":max_coefficient.to_string(),"point_outputs":point_outputs,"noncanonical_point_Y_components":lazy_point_outputs,"raw_export_roundtrip":true,"exact_CIOS_BigUint_REDC_native_representatives":true,"bucket_bytes":std::mem::size_of::<Bucket>(),"bucket_alignment":std::mem::align_of::<Bucket>(),"new_proofs":0,"SDK_requests":0,"new_timings":0,"production_adopted":false,"goal_active":true,"targets_achieved":0});
    std::fs::write(output,serde_json::to_vec_pretty(&result).unwrap()).unwrap();println!("{result}");
}
