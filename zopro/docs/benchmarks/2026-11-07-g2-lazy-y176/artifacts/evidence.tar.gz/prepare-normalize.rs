use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-lazy-y176";
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert!(!Path::new(&format!("{R}/normalization-plan.json")).exists());
 let mut pins:Value=serde_json::from_slice(&fs::read(format!("{R}/pins2.json")).unwrap()).unwrap();
 for leaf in ["qualification.json","normalize.rs","prepare-normalize.rs"]{let p=format!("{R}/{leaf}");pins[p.clone()]=hash(&p).into();}
 let original:Value=serde_json::from_slice(&fs::read(format!("{R}/plan.json")).unwrap()).unwrap();
 let flags:Vec<String>=original["steps"][0]["argv"].as_array().unwrap().iter().map(|v|v.as_str().unwrap().to_owned()).collect();
 let flags=&flags[flags.iter().position(|v|v=="target-cpu=native").unwrap()-1..];
 let mut argv=vec!["/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc".to_owned(),"--edition=2021".into(),format!("{R}/normalize.rs"),"-o".into(),format!("{R}/normalize"),"-C".into(),"opt-level=3".into(),"-C".into(),"lto=fat".into(),"-C".into(),"codegen-units=1".into(),"--extern".into(),format!("zopro_bn254={R}/libzopro_bn254.rlib")];argv.extend(flags.iter().cloned());
 fs::write(format!("{R}/normalization-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
 let plan=json!({"version":1,"source_pins":format!("{R}/normalization-pins.json"),"steps":[{"kind":"command","name":"build-safe-terminal-normalization","argv":argv,"timeout_seconds":180},{"kind":"command","name":"qualify-safe-terminal-allocation-reuse","argv":[format!("{R}/normalize")],"timeout_seconds":180}]});
 fs::write(format!("{R}/normalization-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();println!("Declared14 terminal conversion cases; no arithmetic/model replay or timing");
}
