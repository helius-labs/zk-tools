use std::{alloc::{GlobalAlloc,Layout,System},sync::atomic::{AtomicBool,AtomicUsize,Ordering},hint::black_box};
use zopro_bn254::{Fq,Fq2,FqConfig,FpConfig,G2Affine,G2Projective};
use zopro_bn254::ifma8::LazyFq;
struct Count;
static TRACK:AtomicBool=AtomicBool::new(false);
static ALLOCS:AtomicUsize=AtomicUsize::new(0);
static REALLOCS:AtomicUsize=AtomicUsize::new(0);
static DEALLOCS:AtomicUsize=AtomicUsize::new(0);
unsafe impl GlobalAlloc for Count {
 unsafe fn alloc(&self,l:Layout)->*mut u8 {if TRACK.load(Ordering::Relaxed){ALLOCS.fetch_add(1,Ordering::Relaxed);}unsafe{System.alloc(l)}}
 unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {if TRACK.load(Ordering::Relaxed){ALLOCS.fetch_add(1,Ordering::Relaxed);}unsafe{System.alloc_zeroed(l)}}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {if TRACK.load(Ordering::Relaxed){REALLOCS.fetch_add(1,Ordering::Relaxed);}unsafe{System.realloc(p,l,n)}}
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){if TRACK.load(Ordering::Relaxed){DEALLOCS.fetch_add(1,Ordering::Relaxed);}unsafe{System.dealloc(p,l)}}
}
#[global_allocator]static A:Count=Count;
#[repr(C)]#[derive(Clone,Copy)]struct Bucket{x:Fq2,y:[LazyFq;2]}
#[inline(never)]fn normalize(points:Vec<Bucket>)->Vec<G2Affine>{points.into_iter().map(|p|G2Affine::new(p.x,Fq2::new(p.y[0].canonical(),p.y[1].canonical()))).collect()}
fn lifted(y:Fq)->LazyFq {let mut carry=0u128;let words=core::array::from_fn(|i|{let v=y.0[i]as u128+FqConfig::P[i]as u128+carry;carry=v>>64;v as u64});assert_eq!(carry,0);LazyFq::qualification_from_words(words)}
fn main(){
 let output="/home/ubuntu/src/zopro-perf-work/g2-lazy-y176/normalization.json";assert!(!std::path::Path::new(output).exists());
 let g=G2Projective::generator().to_affine();let mut rows=Vec::new();
 assert_eq!(std::mem::size_of::<Bucket>(),128);assert_eq!(std::mem::align_of::<Bucket>(),8);
 for n in [0,1,7,8,127,2048,4096] {for extra in [0,37] {
  let mut input=Vec::with_capacity(n+extra);
  for i in 0..n{let y=if i%2==0{[lifted(g.y.c0),LazyFq::from_canonical(g.y.c1)]}else{[LazyFq::from_canonical(g.y.c0),lifted(g.y.c1)]};input.push(Bucket{x:g.x,y});}
  let pointer=input.as_ptr()as usize;let before=input.capacity();
  ALLOCS.store(0,Ordering::Relaxed);REALLOCS.store(0,Ordering::Relaxed);DEALLOCS.store(0,Ordering::Relaxed);
  TRACK.store(true,Ordering::SeqCst);let out=black_box(normalize(black_box(input)));TRACK.store(false,Ordering::SeqCst);
  let allocs=ALLOCS.load(Ordering::Relaxed);let reallocs=REALLOCS.load(Ordering::Relaxed);let deallocs=DEALLOCS.load(Ordering::Relaxed);
  let preserved=out.as_ptr()as usize==pointer;
  assert_eq!(allocs,0);assert_eq!(reallocs,0);if n!=0{assert!(preserved);assert_eq!(deallocs,0);assert_eq!(out.capacity(),before);}
  assert_eq!(out.len(),n);assert!(out.iter().all(|p|*p==g));
  rows.push(format!("{{\"length\":{n},\"input_capacity\":{before},\"output_capacity\":{},\"allocations\":{allocs},\"reallocations\":{reallocs},\"deallocations\":{deallocs},\"pointer_preserved\":{preserved}}}",out.capacity()));
 }}
 let result=format!("{{\"passed\":true,\"scope\":\"Pinned Rust 1.98.1 native fat-LTO safe terminal collect; not a portable allocation guarantee or complete Window peak\",\"bucket_bytes\":128,\"bucket_alignment\":8,\"cases\":{},\"rows\":[{}],\"new_timings\":0,\"new_proofs\":0}}",rows.len(),rows.join(","));
 std::fs::write(output,&result).unwrap();println!("{result}");
}
