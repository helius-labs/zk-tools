use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-lazy-y176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
const TC:&str="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
    assert!(!Path::new(&format!("{R}/source")).exists());
    let manifest=format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");
    let m:Value=serde_json::from_slice(&fs::read(&manifest).unwrap()).unwrap();
    let sources=m["source_files_sha256"].as_object().unwrap();assert_eq!(sources.len(),176);
    let mut pins=BTreeMap::new();pins.insert(manifest.clone(),hash(&manifest));
    for(n,h)in sources{let source=format!("{Z}/{n}");assert_eq!(hash(&source),h.as_str().unwrap());let dest=format!("{R}/source/{n}");fs::create_dir_all(Path::new(&dest).parent().unwrap()).unwrap();fs::copy(&source,&dest).unwrap();pins.insert(source, h.as_str().unwrap().to_string());}
    let path=format!("{R}/source/crates/zopro-bn254/src/ifma8.rs");
    let original=fs::read_to_string(&path).unwrap();
    let suffix="\n#[cfg(zopro_lazy_y)]\ninclude!(\"lazy_y.rs\");\n";
    fs::write(&path,format!("{original}{suffix}")).unwrap();
    assert_eq!(fs::read_to_string(&path).unwrap().strip_suffix(suffix).unwrap(),original);
    fs::copy(format!("{R}/lazy_y.rs"),format!("{R}/source/crates/zopro-bn254/src/lazy_y.rs")).unwrap();
    for(n,h)in sources{let path=format!("{R}/source/{n}");if n!="crates/zopro-bn254/src/ifma8.rs"{assert_eq!(hash(&path),h.as_str().unwrap());}pins.insert(path.clone(),hash(path));}
    let audit=json!({"accepted_sources":176,"originals_exact":175,"reverse_176_exact":true,"snapshot_files":177,"parent_suffix":suffix,"generated_arithmetic_unchanged":true,"production_changed":false,"new_native_child":format!("{R}/source/crates/zopro-bn254/src/lazy_y.rs"),"raw_export":"Original packing/transpose/store operations with LazyFq target instead of Fp; reduction omitted; new unsafe block requires original AVX guards and normalized <2p contract"});
    fs::write(format!("{R}/source-audit.json"),serde_json::to_vec_pretty(&audit).unwrap()).unwrap();
    for n in ["design.md","lazy_y.rs","qualify.rs","prepare.rs","source-audit.json","source/crates/zopro-bn254/src/lazy_y.rs"]{let p=format!("{R}/{n}");pins.insert(p.clone(),hash(p));}
    let mut flags:Vec<String>=m["rustflags"].as_str().unwrap().split_whitespace().map(str::to_owned).collect();
    flags.extend(["--cfg".into(),"zopro_lazy_y".into(),"--cfg".into(),"zopro_lazy_y_qualify".into()]);
    let mut build=vec![TC.to_owned(),"--edition=2021".into(),"--crate-name".into(),"zopro_bn254".into(),"--crate-type=rlib".into(),"--cfg".into(),"feature=\"fast-inverse\"".into(),format!("{R}/source/crates/zopro-bn254/src/lib.rs"),"-o".into(),format!("{R}/libzopro_bn254.rlib"),"-C".into(),"opt-level=3".into(),"-C".into(),"lto=fat".into(),"-C".into(),"codegen-units=1".into(),"-C".into(),"debug-assertions=yes".into(),"-C".into(),"overflow-checks=yes".into()];build.extend(flags.clone());
    let deps="/home/ubuntu/src/zopro-perf-work/euclid-float-quotient176/helper-target/release/deps";
    // No driver LTO is needed for correctness qualification. This permits
    // reuse of existing normal serde tooling, without rebuilding dependencies.
    let normal="/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
    let mut driver=vec![TC.to_owned(),"--edition=2021".into(),format!("{R}/qualify.rs"),"-o".into(),format!("{R}/qualify"),"-C".into(),"opt-level=3".into(),"-C".into(),"codegen-units=1".into(),"-C".into(),"debug-assertions=yes".into(),"-C".into(),"overflow-checks=yes".into(),"-L".into(),format!("dependency={deps}"),"-L".into(),format!("dependency={normal}"),"--extern".into(),format!("zopro_bn254={R}/libzopro_bn254.rlib")];
    for(name,p)in[("num_bigint",format!("{deps}/libnum_bigint-0c25dfbc6ef7e0e7.rlib")),("num_traits",format!("{deps}/libnum_traits-02c63f10aa014f38.rlib")),("serde_json",format!("{normal}/libserde_json-cdebb9338c2784ad.rlib"))]{assert!(Path::new(&p).exists(),"{p}");pins.insert(p.clone(),hash(&p));driver.extend(["--extern".into(),format!("{name}={p}")]);}
    driver.extend(flags);
    pins.insert(TC.into(),hash(TC));
    fs::write(format!("{R}/pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
    let plan=json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":[{"kind":"command","name":"build-new-lazy-y-field","argv":build,"timeout_seconds":180},{"kind":"command","name":"build-new-lazy-y-qualification","argv":driver,"timeout_seconds":180},{"kind":"command","name":"qualify-lazy-y-ranges-and-point-lifetime","argv":[format!("{R}/qualify")],"timeout_seconds":180}]});
    fs::write(format!("{R}/plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();println!("Prepared177-source private snapshot, 3 new commands, original generated arithmetic exact");
}
