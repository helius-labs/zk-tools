fn med(mut x: Vec<f64>) -> f64 {
    assert_eq!(x.len(), 21);
    assert!(x.iter().all(|x| x.is_finite()));
    x.sort_by(f64::total_cmp);
    x[10]
}
fn paired(values: &BTreeMap<(usize, String, usize), f64>, w: usize, a: &str, b: &str) -> Value {
    let mut ratios = Vec::new();
    let mut savings = Vec::new();
    for block in 0..21 {
        let n = values[&(w, a.into(), block)];
        let d = values[&(w, b.into(), block)];
        assert!(n.is_finite() && d.is_finite() && n > 0. && d > 0.);
        ratios.push(n / d);
        savings.push(d - n);
    }
    let wins = ratios.iter().filter(|&&r| r < 1.).count();
    ratios.sort_by(f64::total_cmp);
    json!({"workers":w,"ratio":format!("{a}/{b}"),"lower":ratios[5],"median":ratios[10],"upper":ratios[15],"wins":wins,"paired_median_saving":med(savings)})
}
fn statistics_models() {
    let mut equal = BTreeMap::new();
    let mut reverse = BTreeMap::new();
    for b in 0..21 {
        equal.insert((96, "A".into(), b), 2.);
        equal.insert((96, "B".into(), b), 2.);
        reverse.insert((96, "A".into(), b), (21 - b) as f64);
        reverse.insert((96, "B".into(), b), (b + 1) as f64);
    }
    let e = paired(&equal, 96, "A", "B");
    assert_eq!(
        (
            e["lower"].as_f64().unwrap(),
            e["median"].as_f64().unwrap(),
            e["upper"].as_f64().unwrap(),
            e["wins"].as_u64().unwrap()
        ),
        (1., 1., 1., 0)
    );
    let e = paired(&reverse, 96, "A", "B");
    assert_eq!(e["median"], 1.);
    assert!((e["lower"].as_f64().unwrap() - 6. / 16.).abs() < 1e-15);
    assert!((e["upper"].as_f64().unwrap() - 16. / 6.).abs() < 1e-15);
    assert_eq!(e["wins"], 10);
    let mut pascal = vec![1u64];
    for _ in 0..21 {
        let mut next = vec![1];
        for p in pascal.windows(2) {
            next.push(p[0] + p[1]);
        }
        next.push(1);
        pascal = next;
    }
    assert_eq!(pascal[..6].iter().sum::<u64>(), 27896);
    let coverage = 1. - 2. * 27896. / ((1u64 << 21) as f64);
    assert_eq!(coverage * 100., 97.339630126953125);
    println!("PASS equal-tie, nonproportional paired-order and exact-binomial interval models");
}
