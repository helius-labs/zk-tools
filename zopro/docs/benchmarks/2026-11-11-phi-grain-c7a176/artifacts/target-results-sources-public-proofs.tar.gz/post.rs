use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
const PRIOR: &str =
    "/home/ubuntu/src/zopro-perf-work/task-interval-c7a176/proof-sha256-after-capture.json";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn map(p: &str, local: bool) -> PathBuf {
    let r = Path::new(ROOT);
    if let Some(s) = p.strip_prefix("/output/") {
        return r
            .join(if local {
                "local-output"
            } else {
                "remote-results/output"
            })
            .join(s);
    }
    for (prefix, folder) in [
        ("/cr-basis/", "context/basis"),
        ("/usr/local/bin/", "context"),
        ("/cr/", "context"),
        ("/fixtures/", "context/fixtures"),
    ] {
        if let Some(s) = p.strip_prefix(prefix) {
            return r.join(folder).join(s);
        }
    }
    panic!("unsupported container input {p}")
}
include!("statistics.rs");
fn main() {
    let op = std::env::args().nth(1).unwrap();
    if op == "test" {
        statistics_models();
        return;
    }
    let local = op == "local";
    assert!(local || op == "remote");
    let r = Path::new(ROOT);
    let dir = r.join(if local {
        "local-output/preflight"
    } else {
        "remote-results/output/measure"
    });
    let complete = read(dir.join("complete.json"));
    assert_eq!(complete["status"], "complete");
    assert_eq!(
        complete["distinct_gnark_exports"],
        if local { 11 } else { 132 }
    );
    let mut ledger: BTreeSet<String> = serde_json::from_value(if local {
        read(PRIOR)
    } else {
        read(r.join("proof-sha256-after-preflight.json"))
    })
    .unwrap();
    assert_eq!(ledger.len(), if local { 50208 } else { 50219 });
    let before = ledger.clone();
    let pins: BTreeMap<String, String> =
        serde_json::from_value(read(dir.join("pins.json"))).unwrap();
    for (p, h) in &pins {
        assert_eq!(&hash(map(p, local)), h);
    }
    let jobs = read(dir.join("jobs.json"));
    let plan = read(dir.join("plan.json"));
    assert_eq!(
        plan["steps"].as_array().unwrap().len(),
        if local { 22 } else { 264 }
    );
    for s in plan["steps"].as_array().unwrap() {
        let d = dir.join("workflow").join(s["name"].as_str().unwrap());
        let e = read(d.join("exit.json"));
        assert_eq!(e["success"], true);
        assert_eq!(e["returncode"], 0);
        for (f, k) in [
            ("stdout.log", "stdout_sha256"),
            ("stderr.log", "stderr_sha256"),
        ] {
            assert_eq!(hash(d.join(f)), e[k]);
        }
        let command = read(d.join("command.json"));
        assert_eq!(
            &command["argv"].as_array().unwrap()[4..],
            s["argv"].as_array().unwrap()
        );
        assert_eq!(command["environment"], s["environment"]);
    }
    let producer = read(dir.join("rows.json"));
    let mut latency = BTreeMap::new();
    let mut cpu = BTreeMap::new();
    let mut rss = BTreeMap::<(usize, String), f64>::new();
    let mut timed = 0u64;
    let mut resources = vec![];
    for j in jobs.as_array().unwrap() {
        let name = j["name"].as_str().unwrap();
        let proof = map(j["proof_dir"].as_str().unwrap(), local);
        assert_eq!(fs::metadata(proof.join("0.proof")).unwrap().len(), 164);
        let ph = hash(proof.join("0.proof"));
        assert!(ledger.insert(ph.clone()));
        let public = hash(proof.join("0.public"));
        assert_eq!(public, j["case"]["public_sha256"]);
        let verify = fs::read_to_string(
            dir.join("workflow")
                .join(format!("verify-{name}"))
                .join("stdout.log"),
        )
        .unwrap();
        for binding in [
            format!("proof_sha256={ph}"),
            format!("public_sha256={public}"),
            format!(
                "image_sha256={}",
                j["case"]["image_sha256"].as_str().unwrap()
            ),
        ] {
            assert!(verify.contains(&binding));
        }
        let raw = fs::read_to_string(dir.join("workflow").join(name).join("stdout.log")).unwrap();
        let mut sum = 0u128;
        let mut n = 0;
        for line in raw.lines().filter_map(|l| l.strip_prefix("SAMPLE ")) {
            let v: Value = serde_json::from_str(line).unwrap();
            assert_eq!(v["round"], n);
            let ns = v["ns"]
                .as_u64()
                .unwrap_or_else(|| (v["ms"].as_f64().unwrap() * 1e6).round() as u64);
            assert!(ns > 0);
            sum += ns as u128;
            n += 1;
        }
        assert_eq!(n, j["rounds"]);
        timed += n;
        let mean = sum as f64 / n as f64;
        let p = producer
            .as_array()
            .unwrap()
            .iter()
            .find(|p| p["job"]["name"] == name)
            .unwrap();
        assert!((p["mean_ns"].as_f64().unwrap() - mean).abs() <= 1e-6);
        let u: Value = serde_json::from_str(
            raw.lines()
                .find_map(|l| l.strip_prefix("SUMMARY "))
                .unwrap(),
        )
        .unwrap();
        assert_eq!(u["priming"], 3);
        assert_eq!(u["rounds"], j["rounds"]);
        assert_eq!(u["workers"], j["workers"]);
        assert_eq!(u["placement_before"], u["placement_after"]);
        let placement = &u["placement_before"];
        assert_eq!(
            placement["tasks"].as_u64().unwrap(),
            j["workers"].as_u64().unwrap() + 1
        );
        assert_eq!(
            placement["worker_rows"].as_array().unwrap().len() as u64,
            j["workers"].as_u64().unwrap()
        );
        for (i, w) in placement["worker_rows"]
            .as_array()
            .unwrap()
            .iter()
            .enumerate()
        {
            assert_eq!(w["index"], i);
            assert_eq!(w["allowed"], json!([i]));
        }
        if j["panel"] == "latency" {
            let w = j["workers"].as_u64().unwrap() as usize;
            let arm = j["arm"].as_str().unwrap().to_owned();
            let block = j["block"].as_u64().unwrap() as usize;
            let key = (w, arm.clone(), block);
            let cpu_ms = (u["user_cpu_ms"].as_f64().unwrap()
                + u["system_cpu_ms"].as_f64().unwrap())
                / n as f64;
            let rss_mib = u["whole_process_maxrss_kib"].as_f64().unwrap() / 1024.;
            assert!(latency.insert(key.clone(), mean / 1e6).is_none());
            assert!(cpu.insert(key, cpu_ms).is_none());
            rss.entry((w, arm))
                .and_modify(|x| *x = x.max(rss_mib))
                .or_insert(rss_mib);
            resources.push(json!({"job":name,"workers":w,"arm":j["arm"],"block":block,"ms":mean/1e6,"cpu_ms":cpu_ms,"rss_mib":rss_mib,"minor_faults_per_request":u["minor_faults"].as_f64().unwrap()/n as f64,"major_faults_per_request":u["major_faults"].as_f64().unwrap()/n as f64}));
        }
        if !local {
            let d = r.join("transport-verification").join(name);
            fs::create_dir_all(&d).unwrap();
            assert!(!d.join("exit.json").exists());
            let source = map(j["case"]["image"].as_str().unwrap(), true);
            let argv = vec![
                r.join("context/interval-verify").display().to_string(),
                source.display().to_string(),
                j["case"]["image_sha256"].as_str().unwrap().into(),
                proof.join("0.proof").display().to_string(),
                proof.join("0.public").display().to_string(),
                public,
            ];
            let o = Command::new(&argv[0]).args(&argv[1..]).output().unwrap();
            fs::write(d.join("stdout.log"), o.stdout).unwrap();
            fs::write(d.join("stderr.log"), o.stderr).unwrap();
            save(d.join("command.json"), json!({"argv":argv}));
            save(
                d.join("exit.json"),
                json!({"success":o.status.success(),"exit_code":o.status.code(),"stdout_sha256":hash(d.join("stdout.log")),"stderr_sha256":hash(d.join("stderr.log"))}),
            );
            assert!(o.status.success());
        }
    }
    assert_eq!(ledger.len(), if local { 50219 } else { 50351 });
    assert_eq!(
        json!(ledger.difference(&before).collect::<Vec<_>>()),
        complete["new_proof_sha256"]
    );
    assert_eq!(timed, if local { 11 } else { 19032 });
    save(
        r.join(if local {
            "proof-sha256-after-preflight.json"
        } else {
            "proof-sha256-after-capture.json"
        }),
        json!(ledger),
    );
    if !local {
        assert_eq!(latency.len(), 126);
        let mut gates = vec![];
        let mut medians = vec![];
        for w in [32, 96] {
            for arm in ["REF", "OFF", "ON"] {
                medians.push(json!({"workers":w,"arm":arm,"ms":med((0..21).map(|b|latency[&(w,arm.into(),b)]).collect()),"cpu_ms":med((0..21).map(|b|cpu[&(w,arm.into(),b)]).collect()),"max_rss_mib":rss[&(w,arm.into())]}));
            }
            for (a, b) in [("OFF", "REF"), ("ON", "OFF"), ("ON", "REF")] {
                let mut g = paired(&latency, w, a, b);
                g["kind"] = "latency".into();
                let lo = g["lower"].as_f64().unwrap();
                let hi = g["upper"].as_f64().unwrap();
                g["pass"] = json!(if a == "OFF" {
                    lo >= 1. / 1.03 && hi <= 1.03
                } else if w == 96 {
                    hi < 1.
                } else {
                    hi <= 1.02
                });
                gates.push(g);
            }
            for b in ["OFF", "REF"] {
                let mut g = paired(&cpu, w, "ON", b);
                g["kind"] = "CPU".into();
                g["pass"] = json!(g["upper"].as_f64().unwrap() <= 1.02);
                gates.push(g);
            }
            let on = rss[&(w, "ON".into())];
            let limit = rss[&(w, "OFF".into())].max(rss[&(w, "REF".into())]) * 1.05 + 1.;
            gates.push(
                json!({"workers":w,"kind":"RSS","ON_mib":on,"limit_mib":limit,"pass":on<=limit}),
            );
        }
        save(
            r.join("target-analysis.json"),
            json!({"target_passed":gates.iter().all(|g|g["pass"]==true),"gates":gates,"medians":medians,"resources":resources,"production_adoption_requires_all_shape_qualification":true,"full10xgoal_achieved":false}),
        );
    }
    let result = json!({"status":"PASS","local":local,"new_export_count":jobs.as_array().unwrap().len(),"canonical_verified_exports":if local{50219}else{50351},"timed_samples_checked":timed,"transport_rechecks_add_new_proofs":0,"local_preflight_is_not_speedup_evidence":true});
    save(
        r.join(if local {
            "local-review.json"
        } else {
            "remote-review.json"
        }),
        result.clone(),
    );
    println!("{result}");
}
