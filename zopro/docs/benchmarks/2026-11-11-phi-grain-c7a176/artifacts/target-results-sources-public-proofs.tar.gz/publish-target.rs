use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
const DEST: &str = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-11-phi-grain-c7a176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn copy(p: &Path, q: &Path) {
    fs::create_dir_all(q.parent().unwrap()).unwrap();
    fs::copy(p, q).unwrap();
}
fn tree(p: &Path, q: &Path) {
    for e in fs::read_dir(p).unwrap() {
        let s = e.unwrap().path();
        let d = q.join(s.file_name().unwrap());
        if s.is_dir() {
            tree(&s, &d)
        } else {
            copy(&s, &d)
        }
    }
}
fn inventory(p: &Path, base: &Path, m: &mut BTreeMap<String, String>) {
    for e in fs::read_dir(p).unwrap() {
        let p = e.unwrap().path();
        if p.is_dir() {
            inventory(&p, base, m)
        } else {
            m.insert(p.strip_prefix(base).unwrap().display().to_string(), hash(p));
        }
    }
}
fn receipts(p: &Path) -> usize {
    let mut count = 0;
    for e in fs::read_dir(p).unwrap() {
        let d = e.unwrap().path();
        if !d.is_dir() {
            continue;
        }
        if d.join("exit.json").exists() {
            let e = read(d.join("exit.json"));
            assert_eq!(e["success"], true);
            assert_eq!(
                e.get("returncode").or_else(|| e.get("exit_code")).unwrap(),
                0
            );
            for (f, k) in [
                ("stdout.log", "stdout_sha256"),
                ("stderr.log", "stderr_sha256"),
            ] {
                assert_eq!(hash(d.join(f)), e[k]);
            }
            count += 1;
        } else {
            count += receipts(&d);
        }
    }
    count
}
fn main() {
    let r = Path::new(ROOT);
    let d = Path::new(DEST);
    let a = d.join("artifacts");
    assert!(!a.join("target-publication.json").exists());
    let review = read(r.join("remote-review.json"));
    assert_eq!(review["status"], "PASS");
    assert_eq!(review["canonical_verified_exports"], 50351);
    let analysis = read(r.join("target-analysis.json"));
    assert_eq!(analysis["target_passed"], true);
    assert_eq!(analysis["gates"].as_array().unwrap().len(), 12);
    let rows = read(r.join("remote-results/output/measure/rows.json"));
    let raw = rows.as_array().unwrap();
    let mut metrics = BTreeMap::<(usize, String, usize), (f64, f64, f64)>::new();
    let mut resources = vec![];
    for row in raw.iter().filter(|x| x["job"]["panel"] == "latency") {
        let j = &row["job"];
        let u = &row["usage"];
        let key = (
            j["workers"].as_u64().unwrap() as usize,
            j["arm"].as_str().unwrap().to_owned(),
            j["block"].as_u64().unwrap() as usize,
        );
        let n = j["rounds"].as_u64().unwrap();
        assert_eq!(n, 151);
        let ms = row["mean_ns"].as_f64().unwrap() / 1e6;
        let cpu =
            (u["user_cpu_ms"].as_f64().unwrap() + u["system_cpu_ms"].as_f64().unwrap()) / n as f64;
        let rss = u["whole_process_maxrss_kib"].as_f64().unwrap() / 1024.;
        assert!(metrics.insert(key, (ms, cpu, rss)).is_none());
        resources.push(json!({"job":j["name"],"workers":j["workers"],"arm":j["arm"],"block":j["block"],"ms":ms,"cpu_ms":cpu,"rss_mib":rss,"minor_faults_per_request":u["minor_faults"].as_f64().unwrap()/n as f64,"major_faults_per_request":u["major_faults"].as_f64().unwrap()/n as f64}));
    }
    assert_eq!(metrics.len(), 126);
    // Recompute ratios from producer summaries; the post reader used raw SDK samples.
    for gate in analysis["gates"].as_array().unwrap() {
        let w = gate["workers"].as_u64().unwrap() as usize;
        let metric = gate["kind"].as_str().unwrap();
        if metric == "RSS" {
            let get = |arm: &str| {
                (0..21)
                    .map(|b| metrics[&(w, arm.into(), b)].2)
                    .fold(0., f64::max)
            };
            let on = get("ON");
            let limit = get("OFF").max(get("REF")) * 1.05 + 1.;
            assert_eq!(gate["ON_mib"], on);
            assert_eq!(gate["limit_mib"], limit);
            assert_eq!(gate["pass"], on <= limit);
            continue;
        }
        let arms = gate["ratio"]
            .as_str()
            .unwrap()
            .split('/')
            .collect::<Vec<_>>();
        let mut v = (0..21)
            .map(|b| {
                let n = metrics[&(w, arms[0].into(), b)];
                let d = metrics[&(w, arms[1].into(), b)];
                if metric == "CPU" {
                    n.1 / d.1
                } else {
                    n.0 / d.0
                }
            })
            .collect::<Vec<_>>();
        v.sort_by(f64::total_cmp);
        for (k, i) in [("lower", 5), ("median", 10), ("upper", 15)] {
            assert!((gate[k].as_f64().unwrap() - v[i]).abs() < 1e-12);
        }
        let pass = if metric == "CPU" {
            v[15] <= 1.02
        } else if arms[0] == "OFF" {
            v[5] >= 1. / 1.03 && v[15] <= 1.03
        } else if w == 96 {
            v[15] < 1.
        } else {
            v[15] <= 1.02
        };
        assert_eq!(gate["pass"], pass);
    }
    let command_receipts = receipts(&r.join("remote-results/output/measure/workflow"));
    assert_eq!(command_receipts, 264);
    let transported = receipts(&r.join("transport-verification"));
    assert_eq!(transported, 132);
    assert_eq!(
        read(r.join("termination-observation.json"))["Reservations"][0]["Instances"][0]["State"]
            ["Name"],
        "terminated"
    );
    assert!(read(r.join("volume-observation.json"))["Volumes"]
        .as_array()
        .unwrap()
        .is_empty());
    assert!(read(r.join("ecr-cleanup.json"))["failures"]
        .as_array()
        .unwrap()
        .is_empty());
    assert!(read(r.join("ecr-absence.json"))
        .as_array()
        .unwrap()
        .is_empty());
    assert!(read(r.join("existing-benchmarks-after-cleanup.json"))
        .as_array()
        .unwrap()
        .is_empty());
    assert_eq!(
        read(r.join("bucket-cleanup.json"))["status"],
        "owned object removed; bucket deleted"
    );
    let cleanup = json!({"instance_id":"i-0e8ca2c57328ff6c2","state":"terminated","owned_volumes":0,"temporary_ECR_tag_absent":true,"private_S3_object_and_bucket_deleted":true,"live_temporary_benchmarks":0});
    save(r.join("cleanup.json"), &cleanup);
    let inspect = read(r.join("remote-results/container-inspect.json"));
    let inspect = &inspect[0];
    assert_eq!(inspect["State"]["ExitCode"], 0);
    let host = &inspect["HostConfig"];
    assert_eq!(host["NanoCpus"], 96000000000u64);
    assert_eq!(host["Memory"], 30u64 << 30);
    assert_eq!(host["MemorySwap"], 30u64 << 30);
    assert_eq!(host["NetworkMode"], "none");
    let quality = json!({"container_image":inspect["Config"]["Image"],"container_exit":inspect["State"]["ExitCode"],"host_config":{"NanoCpus":host["NanoCpus"],"Memory":host["Memory"],"MemorySwap":host["MemorySwap"],"PidsLimit":host["PidsLimit"],"CapDrop":host["CapDrop"],"SecurityOpt":host["SecurityOpt"],"NetworkMode":host["NetworkMode"]},"before":read(r.join("remote-results/output/measure/before.json")),"after":read(r.join("remote-results/output/measure/after.json")),"physical_host_exclusivity_established":false});
    save(r.join("target-quality.json"), &quality);
    save(r.join("resource-rows.json"), &json!(resources));
    let stage = r.join("target-publication-source");
    fs::create_dir(&stage).unwrap();
    for f in [
        "target-protocol.md",
        "design.md",
        "runner.rs",
        "post.rs",
        "statistics.rs",
        "publish-target.rs",
        "native-review.json",
        "local-review.json",
        "portable-review.json",
        "remote-review.json",
        "target-analysis.json",
        "resource-rows.json",
        "target-quality.json",
        "cleanup.json",
        "image-manifest.json",
        "run-id.txt",
        "launch.json",
        "launch-result.json",
        "boot-command.json",
        "boot-parameters.json",
        "boot-result.json",
        "pull-command.json",
        "pull-parameters.json",
        "pull-result.json",
        "measure-command.json",
        "measure-parameters.json",
        "measure-result.json",
        "package-command.json",
        "package-parameters.json",
        "package-result.json",
        "upload-command.json",
        "upload-parameters-redacted.json",
        "upload-result.json",
        "retrieval-complete.json",
        "termination-result.json",
        "termination-observation.json",
        "volume-observation.json",
        "ecr-cleanup.json",
        "ecr-absence.json",
        "bucket-cleanup.json",
        "existing-benchmarks-before-launch.json",
        "existing-benchmarks-after-cleanup.json",
        "network-check.json",
        "publish-resumed.stdout",
        "publish-resumed.stderr",
    ] {
        copy(&r.join(f), &stage.join(f));
    }
    tree(
        &r.join("remote-results/output/measure"),
        &stage.join("cloud"),
    );
    tree(
        &r.join("transport-verification"),
        &stage.join("transport-verification"),
    );
    for f in ["hardware.txt", "post-host-state.txt", "runner.log"] {
        copy(&r.join("remote-results").join(f), &stage.join(f));
    }
    let mut files = BTreeMap::new();
    inventory(&stage, &stage, &mut files);
    save(stage.join("manifest.json"), &json!(files));
    let archive = a.join("target-results-sources-public-proofs.tar.gz");
    assert!(Command::new("tar")
        .args([
            "--sort=name",
            "--mtime=2026-11-11 00:00:00Z",
            "--owner=0",
            "--group=0",
            "--numeric-owner",
            "-czf"
        ])
        .arg(&archive)
        .arg("-C")
        .arg(&stage)
        .arg(".")
        .status()
        .unwrap()
        .success());
    let round = r.join("target-publication-roundtrip");
    fs::create_dir(&round).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&round)
        .status()
        .unwrap()
        .success());
    for (p, h) in &files {
        assert_eq!(&hash(round.join(p)), h);
    }
    assert_eq!(read(round.join("manifest.json")), json!(files));
    for f in [
        "target-analysis.json",
        "remote-review.json",
        "resource-rows.json",
        "target-quality.json",
        "cleanup.json",
    ] {
        copy(&r.join(f), &a.join(f));
    }
    let publication = json!({"status":"PASS","target_passed":true,"target_checks_passed":12,"target_SDK_requests":19428,"target_timed_samples":19032,"new_target_Gnark_exports":132,"combined_preflight_and_target_exports":143,"canonical_verified_exports":50351,"canonical_ledger_sha256":hash(r.join("proof-sha256-after-capture.json")),"cloud_workflow_receipts_checked":command_receipts,"transport_verification_receipts_checked":transported,"independent_producer_ratio_recheck":true,"source_archive_members":files.len(),"source_archive_bytes":fs::metadata(&archive).unwrap().len(),"source_archive_sha256":hash(&archive),"cleanup":cleanup,"production_changed":false,"all_shape_adoption_qualification_pending":true,"full10xgoal_achieved":false});
    save(a.join("target-publication.json"), &publication);
    save(r.join("target-publication.json"), &publication);
    let mut text=String::from("# G2 scalar-grain candidate on C7a\n\nThe candidate improves 1×2 at **96 workers by 5.12% paired versus accepted**, winning all 21 blocks. Median process-mean latency is **12.820886 ms versus 13.426282 ms**; paired CPU use falls 12.62%. All twelve declared target checks pass. At 32 workers latency remains near parity. Production is unchanged pending clean-source/default and all-shape qualification.\n\nThis is a fresh comparison on one c7a.24xlarge, 96 physical cores without SMT. REF is the accepted Zen4 SDK, OFF is the newly built original iterator, and ON adds only `with_min_len(128)` to the existing in-place G2 `phi_split` iterator through an experimental compile-time cfg. The other 175 source files and all 176 production hashes remain unchanged. Arithmetic, ordering, eligibility, points, buckets, allocations and forecasts are retained; no runtime selector, new buffer, lookup table or worker pool is added.\n\n|Workers|Build|Proof ms|Whole-loop CPU ms/request|Maximum lifetime RSS MiB|\n|---:|:---|---:|---:|---:|\n");
    for row in analysis["medians"].as_array().unwrap() {
        text += &format!(
            "|{}|{}|{:.6}|{:.3}|{:.2}|\n",
            row["workers"],
            row["arm"].as_str().unwrap(),
            row["ms"].as_f64().unwrap(),
            row["cpu_ms"].as_f64().unwrap(),
            row["max_rss_mib"].as_f64().unwrap()
        );
    }
    text+="\nLatencies are medians of 21 process arithmetic means, each from 151 SDK requests after three primes. CPU sums user and system time across threads and includes ordinary loop work between SDK timers. RSS is the maximum across the 21 process lifetime peaks, including loading and primes; it is not minimum RAM. Timings include fresh assignment, solving, blinding, proving, SDK verification and serialization, excluding loading, primes and export/reader work. Fixed process and individual worker masks are checked before and after; default stacks and accepted allocation settings are retained. Physical-host exclusivity and frequency locking are not established.\n\n|Workers|Metric and paired comparison|Median ratio|Rank interval|Wins / 21|Pass|\n|---:|:---|---:|:---|---:|:---|\n";
    for gate in analysis["gates"].as_array().unwrap() {
        if gate["kind"] == "RSS" {
            continue;
        }
        text += &format!(
            "|{}|{} {}|{:.6}|[{:.6}, {:.6}]|{}|yes|\n",
            gate["workers"],
            gate["kind"].as_str().unwrap(),
            gate["ratio"].as_str().unwrap(),
            gate["median"].as_f64().unwrap(),
            gate["lower"].as_f64().unwrap(),
            gate["upper"].as_f64().unwrap(),
            gate["wins"]
        );
    }
    text+="\nComparisons pair the same worker count and block. Sorted ranks 5/15 of 21 ratios give nominal 97.339630126953125% marginal coverage under independent exchangeable blocks, with no familywise or stationarity guarantee. Fixed rotated/reversed order, counts and gates were frozen before the first container preflight. OFF/REF latency intervals must lie wholly within factor 1.03 at both counts. ON96 must have latency upper bounds below one against both controls; ON32 latency and both-count CPU upper bounds must be at most 1.02. Maximum ON RSS must be no more than max(REF, OFF)×1.05+1 MiB at each count; both guards pass. There is no gain floor, sample exclusion, extension or post-result threshold change. Paired ratios/savings and displayed median timings use different aggregation.\n\nThe 32-worker intervals cross one: this campaign does not establish a latency gain there. Among the two tested counts, 32 remains faster than 96; 64 is not remeasured. The result identifies a useful high-core improvement, not the complete explanation of scaling or a measured reduction in job counts. The earlier task observer failed its target overhead check; the present performance run uses no task tracing. The exact minimum-grain idea was previously near parity locally; this new target condition tests C7a with 96 physical cores.\n\nEarlier pinned Aeglos measured 7.902802 ms at 96 workers in the [previous all-shape AWS comparison](../2026-11-10-accepted-current-c7a176/README.md). No fresh Aeglos run is performed here, so that is historical context rather than a new matched comparison. This candidate has not demonstrated beating that result. The supplied M5 1×2 CPU/Metal references are 37/24 ms; ON32 is about 3.24×/2.10× faster respectively, still short of the CPU 10× target of 3.7 ms. The original all-eight objective remains active and unmet. This primary-only timing campaign supplies no fresh other-shape latency, phone/ARM/TEE, memory-pressure, minimum-RAM, huge-circuit or concurrent-throughput result.\n\nBoth fresh native builds pass 127 core, two prover and six cubic tests and coherently rebuild eight libraries with Rust 1.98.1, znver4, O3, fat LTO, one codegen unit and accepted manual flags including dense busy reset. Candidate generic x86-64/noIFMA/noASM validation passes 102 core and two prover tests; the Zolana test target compiles with zero tests enabled. Field source/qualification is inherited. Three independent reader models cover ties, nonproportional pairing and exact binomial coverage. Native SDK identities and frozen protocol remain unchanged after generic validation.\n\nLocal functional preflight covers all nine candidate shapes plus primary REF/OFF at four workers: 44 SDK calls and eleven fresh independently Gnark-verified 164-byte exports. Cloud preflight and main make 19,428 SDK calls and 132 fresh exports, all Gnark verified on the server. After SHA/size-bound transport, all 132 are verified once more locally without increasing the distinct count. The independent reader checks 19,032 timed samples, command argv/environment, stream hashes, fixed placement, means, bindings and freshness. A separate publication reader recomputes all ratio/RSS gates from producer summaries. The cumulative verified-export ledger advances **50,208 → 50,219 → 50,351**.\n\nAll major-fault counts are zero. Container CPU throttling, memory-pressure/OOM and swap-event deltas are zero. The 96-CPU/30 GiB/no-swap/network-disabled container is a benchmark setting, not a prover architectural RAM cap. Minor faults remain in the raw resource rows. During all preflight/recording only the confirmed live measurement handle is polled; no owned helper/build/hash/analysis/report overlaps captures. All main timings finish before main-export verifiers. No successful science is replayed.\n\nThe initial nested-xtask host-lock failure occurred before Cargo; its correction runs native workflows directly. Expired SSO initially stopped image publication before creating resources. After renewed login, the existing image and completed tests/proofs are reused, with the scientific protocol unchanged. One owned server is launched with a 90-minute termination timer. It is now terminated, its encrypted delete-on-termination volume and temporary ECR tag are absent, and the private transfer object/bucket are deleted; no temporary benchmark instance remains in the checked region.\n\n[Target analysis](artifacts/target-analysis.json), [all resource rows](artifacts/resource-rows.json), [quality](artifacts/target-quality.json), [independent proof/sample review](artifacts/remote-review.json), [protocol](artifacts/target-protocol.md), [cleanup](artifacts/cleanup.json), [target publication checks](artifacts/target-publication.json), [raw target results, sources and public proofs](artifacts/target-results-sources-public-proofs.tar.gz), [native review](artifacts/native-review.json), [generic review](artifacts/portable-review.json), [preparation sources and receipts](artifacts/preparation-sources-receipts-public-proofs.tar.gz), [generic sources and receipts](artifacts/portable-sources-receipts.tar.gz), [checksums](SHA256SUMS). Archives round-trip exact bytes and hashes. SDK executables, compiled libraries, production inputs and credential-bearing files are excluded. Reproduction requires pinned tools and private inputs.\n\nLocal experiment directory: `/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176`; executables: `sdk-control-znver4` and `sdk-candidate-znver4`.\n";
    fs::write(d.join("README.md"), text).unwrap();
    let mut sums = String::new();
    for e in fs::read_dir(&a).unwrap() {
        let p = e.unwrap().path();
        sums += &format!(
            "{}  artifacts/{}\n",
            hash(&p),
            p.file_name().unwrap().to_str().unwrap()
        );
    }
    sums += &format!("{}  README.md\n", hash(d.join("README.md")));
    fs::write(d.join("SHA256SUMS"), sums).unwrap();
    assert!(Command::new("sha256sum")
        .args(["-c", "SHA256SUMS"])
        .current_dir(d)
        .status()
        .unwrap()
        .success());
    println!("{publication}");
}
