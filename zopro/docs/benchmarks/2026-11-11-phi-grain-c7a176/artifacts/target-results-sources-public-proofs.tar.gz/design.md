# G2 scalar grain on the current C7a target

Full goal remains active/unmet: verified single-proof CPU AVX latency at least
10x the supplied M5 CPU timings for each of all eight shapes; report CPU and
Metal comparisons. This preparation does not change production or claim speed.

New evidence from task-job-families176 attributes99.848% of additional MSM
publications in the instrumented C7a32->96 graphs to the phi_split iterator.
Observer target overhead failed, so this is a lead, not uninstrumented evidence
or causal proof. Original raw recordings and all negative controls retained.

The EXACT min128 idea was already tested locally on source171 in October27:
primary32 near parity, no confirmed gain, no nonregression failures, overall
gate failed; noAWS. Sequential phi175 likewise failed locally. Do not repeat
those local timing campaigns or call this a new algorithm. New discriminant
is current-source C7a96physical, compared against32 and actual accepted build.

Prepare isolated exact176-source snapshot. Change only hb_raw's original
in-place phi_split iterator: compile-time cfg selects with_min_len128 on ON,
OFF contains original iterator verbatim. No runtime selector/env allocation,
new buffer/key table/point copy/plan/pool/architectural RAM cap, arithmetic,
input order, window/bucket geometry, query dependencies or eligibility change.
One original reversible edit,175originals exact. Production176hashes unchanged.

Rebuild coherent8libraries for freshOFF andON with Rust1.98.1/znver4/allaccepted
flags including densebusyreset; same original accepted SDK driver and allocator.
Native unfiltered core/prover correctness per arm before SDK use. Existing
independent phi decomposition/G2 oracles included in full core tests; no new
arithmetic test or full-field requalification claimed. Field source is exact,
old accepted native field qualification inherited. Freeze actual Cargo
artifacts including proc_macro shared objects; explicit rustc1.98.1 link,
avoid the old accepted-current wrong-path/default-rustc link failure.

This stage only builds/tests/links, no SDK calls or exported proofs; canonical
stays50208 until a later separately frozen functional/benchmark campaign.
Before any export freeze accepted/OFF/ON consumers, both readers, all inputs,
fixed target32/96schedule/counts/statistical+RAM gates and fresh-proof ledger.
Functional local all9preflight is not a rerun of local timing comparisons.
If AWS identifies a genuine full-proof gain, current all8+54 resource,
portable/concurrency/proof validation remains required before adoption.

Use serialized retained Rust xtask; no new tracing/profilecapture. No owned
build/helper/hash/report overlaps ANY SDK preflight or recording; only poll
exact confirmed live handle. No exclusions/extensions/threshold changes or
unchanged scientific replay. Commit AND push each finished experiment, keep
reports factual/polite, keep full goal active. No questions/subagents/Python/
C/ASM rewrite/LUT/expandedplan/newprodpool. AWS auth rechecked when package is
ready; old cached role expires00:01:44Z and SSO refresh previously failed.
