use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const R: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
const OLD: &str = "/home/ubuntu/src/zopro-perf-work/task-interval-c7a176";
const DEPS: &str = "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn compile(r: &Path, name: &str) {
    let argv = vec![
        "--edition=2021".to_owned(),
        "-O".into(),
        r.join(format!("{name}.rs")).display().to_string(),
        "-L".into(),
        format!("dependency={DEPS}"),
        "--extern".into(),
        format!("serde_json={DEPS}/libserde_json-cdebb9338c2784ad.rlib"),
        "--extern".into(),
        format!("sha2={DEPS}/libsha2-16b8f2c03bdf5faa.rlib"),
        "-o".into(),
        r.join(name).display().to_string(),
    ];
    let compiler = "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
    let o = Command::new(compiler).args(&argv).output().unwrap();
    fs::write(r.join(format!("{name}-build.stdout")), o.stdout).unwrap();
    fs::write(r.join(format!("{name}-build.stderr")), o.stderr).unwrap();
    save(
        r.join(format!("{name}-build.json")),
        json!({"compiler":compiler,"argv":argv,"success":o.status.success(),"exit_code":o.status.code()}),
    );
    assert!(o.status.success(), "{name} compile failed");
}
fn replace(s: &mut String, a: &str, b: &str) {
    assert_eq!(s.matches(a).count(), 1, "frozen runner replacement {a}");
    *s = s.replace(a, b);
}
fn main() {
    let r = Path::new(R);
    assert!(!r.join("context").exists());
    let native = read(r.join("native-review.json"));
    assert_eq!(native["status"], "PASS");
    let mut runner = fs::read_to_string(format!("{OLD}/runner.rs")).unwrap();
    runner = runner
        .replace("50208", "50351")
        .replace("50148", "50219")
        .replace("50137", "50208");
    replace(&mut runner,"if arm==\"REF\"{\"/usr/local/bin/cr-previous\"}else{\"/usr/local/bin/cr-current\"}","match arm{\"REF\"=>\"/usr/local/bin/cr-previous\",\"OFF\"=>\"/usr/local/bin/cr-control\",\"ON\"=>\"/usr/local/bin/cr-current\",_=>panic!(\"unknown arm\")}");
    replace(
        &mut runner,
        "env[\"ZOPRO_TASK_TRACE\"]=json!(if arm==\"ON\"{\"1\"}else{\"0\"});",
        "",
    );
    replace(
        &mut runner,
        "add(&dir,c,\"OFF\",4,1",
        "add(&dir,c,\"ON\",4,1",
    );
    replace(
        &mut runner,
        "for arm in[\"REF\",\"ON\"]",
        "for arm in[\"REF\",\"OFF\"]",
    );
    replace(&mut runner, "for block in 0..9", "for block in 0..21");
    replace(&mut runner, "arm,w,31,\"latency\"", "arm,w,151,\"latency\"");
    replace(
        &mut runner,
        "assert_eq!(jobs.len(),60)",
        "assert_eq!(jobs.len(),132)",
    );
    replace(&mut runner, "{44}else{1860}", "{44}else{19428}");
    replace(
        &mut runner,
        "\"observer_interpretation_requires_offline_target_screen\":true",
        "\"performance_requires_independent_target_gates\":true",
    );
    runner = runner.replace(
        "Frozen single-proof task-lifecycle experiment",
        "Frozen single-proof untraced G2 scalar-grain experiment",
    );
    fs::write(r.join("runner.rs"), runner).unwrap();
    compile(r, "runner");
    compile(r, "post");
    let context = r.join("context");
    fs::create_dir(&context).unwrap();
    for sub in ["basis", "fixtures"] {
        fs::create_dir(context.join(sub)).unwrap();
    }
    let mut m = read(format!("{OLD}/context/manifest.json"));
    let mut container = BTreeMap::<String, String>::new();
    let mut pins = BTreeMap::<String, String>::new();
    for c in m["cases"].as_array().unwrap() {
        for (field, folder) in [("image", "basis"), ("request", "fixtures")] {
            let path = c[field].as_str().unwrap();
            let name = Path::new(path).file_name().unwrap();
            let src = Path::new(OLD).join("context").join(folder).join(name);
            let dst = context.join(folder).join(name);
            fs::copy(&src, &dst).unwrap();
            let h = hash(&dst);
            assert_eq!(h, hash(src));
            if field == "image" {
                assert_eq!(h, c["image_sha256"]);
            }
            container.insert(path.into(), h);
        }
    }
    let previous = format!("{OLD}/context/cr-previous");
    assert_eq!(
        hash(&previous),
        "d5e1b2c981fb9bcab2beb69e3b2af5608d298d792c7e3814e87273b04509662e"
    );
    for (name, src) in [
        ("cr-previous", previous),
        (
            "cr-control",
            native["identities"]["control"]["path"]
                .as_str()
                .unwrap()
                .into(),
        ),
        (
            "cr-current",
            native["identities"]["candidate"]["path"]
                .as_str()
                .unwrap()
                .into(),
        ),
        ("aws-runner", r.join("runner").display().to_string()),
        (
            "cr-xtask",
            "/home/ubuntu/src/zopro-perf-work/tool-target/release/xtask".into(),
        ),
        ("interval-verify", format!("{OLD}/context/interval-verify")),
    ] {
        let d = context.join(name);
        fs::copy(&src, &d).unwrap();
        assert_eq!(hash(&d), hash(&src));
        container.insert(format!("/usr/local/bin/{name}"), hash(&d));
        pins.insert(src.clone(), hash(src));
    }
    let seed = format!("{OLD}/proof-sha256-after-capture.json");
    m["prior_proof_sha256"] = read(&seed);
    assert_eq!(m["prior_proof_sha256"].as_array().unwrap().len(), 50208);
    pins.insert(seed.clone(), hash(seed));
    m["container_pins"] = json!(container);
    m["mode_map"] = json!({"REF":"previous","OFF":"control","ON":"current"});
    m["scope"] = "untracedphi grain; primary32/96 REF/OFF/ON21blocks151requests".into();
    m["source_audit"] = read(r.join("source-audit.json"));
    m["native_review"] = native;
    m["helper_sha256"] = json!({});
    for f in [
        "runner.rs",
        "runner",
        "post.rs",
        "post",
        "statistics.rs",
        "design.md",
        "target-protocol.md",
        "prepare-package.rs",
    ] {
        m["helper_sha256"][f] = json!(hash(r.join(f)));
    }
    save(context.join("manifest.json"), m);
    let base =
        "558215002830.dkr.ecr.eu-north-1.amazonaws.com/zolana-prover:bench-pmu-c7a-20261027-123202";
    let o = Command::new("docker")
        .args(["image", "inspect", base, "--format", "{{.Id}}"])
        .output()
        .unwrap();
    assert!(o.status.success());
    assert_eq!(
        String::from_utf8(o.stdout).unwrap().trim(),
        "sha256:a24195e830e9becaa887ece0898c7c07b628edba3f365f439988e885c78bd1b5"
    );
    fs::write(context.join("Dockerfile"),format!("FROM {base}\nCOPY cr-previous cr-control cr-current aws-runner cr-xtask interval-verify /usr/local/bin/\nCOPY basis/ /cr-basis/\nCOPY fixtures/ /fixtures/\nCOPY manifest.json /cr/manifest.json\nENTRYPOINT [\"/usr/local/bin/aws-runner\"]\n")).unwrap();
    fn collect(p: &Path, out: &mut BTreeMap<String, String>) {
        for e in fs::read_dir(p).unwrap() {
            let p = e.unwrap().path();
            if p.is_dir() {
                collect(&p, out)
            } else {
                out.insert(p.display().to_string(), hash(p));
            }
        }
    }
    collect(&context, &mut pins);
    for f in [
        "prepare-package.rs",
        "prepare-package",
        "runner.rs",
        "runner",
        "post.rs",
        "post",
        "statistics.rs",
        "design.md",
        "target-protocol.md",
    ] {
        let p = r.join(f);
        pins.insert(p.display().to_string(), hash(p));
    }
    save(r.join("docker-pins.json"), json!(pins));
    save(
        r.join("docker-plan.json"),
        json!({"version":1,"source_pins":r.join("docker-pins.json"),"steps":[{"kind":"command","name":"reader-models","argv":[r.join("post"),"test"],"timeout_seconds":60},{"kind":"command","name":"build-preflight-image","argv":["docker","build","-t","zopro-phi-grain-c7a:preflight",context],"timeout_seconds":1200}]}),
    );
    println!(
        "Prepared3untracedSDKs, independentreader, frozen21blocktargetprotocol, beforeANYSDKcall"
    );
}
