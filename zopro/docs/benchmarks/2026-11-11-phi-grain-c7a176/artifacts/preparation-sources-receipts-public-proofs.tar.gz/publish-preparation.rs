use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
const DEST: &str = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-11-phi-grain-c7a176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn copy(src: &Path, dst: &Path) {
    fs::create_dir_all(dst.parent().unwrap()).unwrap();
    fs::copy(src, dst).unwrap();
}
fn tree(src: &Path, dst: &Path) {
    for e in fs::read_dir(src).unwrap() {
        let p = e.unwrap().path();
        if p.is_dir() {
            tree(&p, &dst.join(p.file_name().unwrap()))
        } else {
            copy(&p, &dst.join(p.file_name().unwrap()));
        }
    }
}
fn inventory(p: &Path, base: &Path, out: &mut BTreeMap<String, String>) {
    for e in fs::read_dir(p).unwrap() {
        let p = e.unwrap().path();
        if p.is_dir() {
            inventory(&p, base, out)
        } else {
            out.insert(p.strip_prefix(base).unwrap().display().to_string(), hash(p));
        }
    }
}
fn receipts(root: &Path, success: &mut usize, failed: &mut usize) {
    for e in fs::read_dir(root).unwrap() {
        let d = e.unwrap().path();
        if !d.is_dir() {
            continue;
        }
        if d.join("exit.json").exists() {
            let v = read(d.join("exit.json"));
            for (f, k) in [
                ("stdout.log", "stdout_sha256"),
                ("stderr.log", "stderr_sha256"),
            ] {
                assert_eq!(hash(d.join(f)), v[k]);
            }
            if v["success"] == true {
                *success += 1
            } else {
                *failed += 1
            }
        } else {
            receipts(&d, success, failed);
        }
    }
}
fn main() {
    let r = Path::new(ROOT);
    let d = Path::new(DEST);
    let a = d.join("artifacts");
    assert!(!a.exists());
    fs::create_dir_all(&a).unwrap();
    let native = read(r.join("native-review.json"));
    let local = read(r.join("local-review.json"));
    assert_eq!(native["status"], "PASS");
    assert_eq!(local["status"], "PASS");
    assert_eq!(local["canonical_verified_exports"], 50219);
    let manifest = read(r.join("image-manifest.json"));
    assert!(!manifest["pinned_image"].is_string());
    assert!(!r.join("instance-id.txt").exists());
    let error = fs::read_to_string(r.join("publish.stderr")).unwrap();
    assert!(error.contains("Token has expired and refresh failed"));
    assert_eq!(
        hash(r.join("proof-sha256-after-preflight.json")),
        "287a840843fcc114fac764bce8f56d74a6c4184288f5a44ee57dab8e16998d11"
    );
    let mut success = 0;
    let mut failed = 0;
    for dir in [
        "native-control",
        "native-candidate",
        "build-runs",
        "docker-runs",
        "preflight-runs",
        "final-runs",
        "local-output/preflight/workflow",
    ] {
        receipts(&r.join(dir), &mut success, &mut failed);
    }
    assert_eq!(success, 37);
    assert_eq!(failed, 1);
    let auth = json!({"publication_attempt_exit_code":101,"reason":"dev SSO token expired; refresh failed","image_published":false,"instance_launched":false,"new_AWS_resources":0,"no_permission_question":true});
    save(r.join("auth-block.json"), &auth);
    let stage = r.join("preparation-publication-source");
    fs::create_dir(&stage).unwrap();
    for f in [
        "design.md",
        "target-protocol.md",
        "prepare.rs",
        "native.rs",
        "close-native.rs",
        "native-review.json",
        "source-audit.json",
        "build-plan.json",
        "build-pins.json",
        "control-plan.json",
        "candidate-plan.json",
        "control-flags.txt",
        "candidate-flags.txt",
        "frozen-control.json",
        "frozen-candidate.json",
        "frozen-control-cargo.jsonl",
        "frozen-candidate-cargo.jsonl",
        "link-control.json",
        "link-candidate.json",
        "link-control.stdout",
        "link-control.stderr",
        "link-candidate.stdout",
        "link-candidate.stderr",
        "driver.rs",
        "runner.rs",
        "post.rs",
        "statistics.rs",
        "prepare-package.rs",
        "stage.rs",
        "prepare-cloud.rs",
        "cloud.rs",
        "transfer.rs",
        "sigv4.rs",
        "launch-template-resolved.json",
        "user-data-template.sh",
        "docker-plan.json",
        "docker-pins.json",
        "preflight-plan.json",
        "preflight-pins.json",
        "preflight-image.json",
        "final-plan.json",
        "final-pins.json",
        "image-manifest.json",
        "run-id.txt",
        "local-review.json",
        "auth-block.json",
        "publish.stdout",
        "publish.stderr",
        "publish-preparation.rs",
    ] {
        copy(&r.join(f), &stage.join(f));
    }
    for dir in [
        "source",
        "support",
        "native-control",
        "native-candidate",
        "build-runs",
        "docker-runs",
        "preflight-runs",
        "final-runs",
    ] {
        tree(&r.join(dir), &stage.join(dir));
    }
    for f in [
        "manifest.json",
        "preflight-complete.json",
        "Dockerfile",
        "Dockerfile.final",
    ] {
        copy(&r.join("context").join(f), &stage.join("context").join(f));
    }
    for f in [
        "jobs.json",
        "pins.json",
        "plan.json",
        "rows.json",
        "proof-inventory.json",
        "complete.json",
        "before.json",
        "after.json",
        "lscpu.txt",
        "topology.csv",
        "workflow.log",
    ] {
        copy(
            &r.join("local-output/preflight").join(f),
            &stage.join("local-preflight").join(f),
        );
    }
    tree(
        &r.join("local-output/preflight/workflow"),
        &stage.join("local-preflight/workflow"),
    );
    tree(
        &r.join("local-output/preflight/proofs"),
        &stage.join("public-proofs"),
    );
    let mut files = BTreeMap::new();
    inventory(&stage, &stage, &mut files);
    save(stage.join("manifest.json"), &json!(files));
    let archive = a.join("preparation-sources-receipts-public-proofs.tar.gz");
    assert!(Command::new("tar")
        .args([
            "--sort=name",
            "--mtime=2026-11-11 00:00:00Z",
            "--owner=0",
            "--group=0",
            "--numeric-owner",
            "-czf"
        ])
        .arg(&archive)
        .arg("-C")
        .arg(&stage)
        .arg(".")
        .status()
        .unwrap()
        .success());
    let round = r.join("preparation-roundtrip");
    fs::create_dir(&round).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&round)
        .status()
        .unwrap()
        .success());
    for (p, h) in &files {
        assert_eq!(&hash(round.join(p)), h);
    }
    assert_eq!(read(round.join("manifest.json")), json!(files));
    for f in [
        "native-review.json",
        "local-review.json",
        "target-protocol.md",
        "auth-block.json",
        "source-audit.json",
    ] {
        copy(&r.join(f), &a.join(f));
    }
    let review = json!({"status":"PASS","stage":"native and functional preparation only; AWS performance unmeasured","source_files":176,"unchanged_originals":175,"reversible_originals":1,"native_core_prover_cubic_tests_per_arm":135,"reader_models":3,"successful_workflow_receipts_checked":success,"failed_nested_host_lock_receipt_retained":failed,"new_SDK_requests":44,"new_distinct_Gnark_exports":11,"canonical_verified_exports":50219,"canonical_ledger_sha256":hash(r.join("proof-sha256-after-preflight.json")),"source_roundtrip_members":files.len(),"source_archive_bytes":fs::metadata(&archive).unwrap().len(),"source_archive_sha256":hash(&archive),"new_AWS_resources":0,"production_changed":false,"speedup_verified":false,"goal_achieved":false});
    save(a.join("publication.json"), &review);
    save(r.join("preparation-publication.json"), &review);
    let text="# G2 scalar-grain candidate: native and functional preparation\n\nThe current-source control and candidate both pass native qualification and fresh functional proof checks. **AWS performance has not been measured.** Publication stops before creating cloud resources because the dev SSO token has expired and refresh failed. No optimization is adopted.\n\nThe [captured C7a job-family analysis](../2026-11-10-task-job-families176/README.md) attributes 99.848% of additional instrumented MSM job publications at 96 versus 32 workers to G2 scalar decomposition. The observer failed its target overhead screen, so those counts do not establish uninstrumented costs or a speedup. The exact minimum-grain idea [already showed no confirmed gain locally](../2026-10-27-g2-scalar-grain/README.md); this preparation targets the previously unmeasured C7a condition with 96 physical cores. No old local timing comparison is repeated.\n\nOne reversible edit selects `with_min_len(128)` on the existing in-place `phi_split` iterator through an experimental compile-time cfg. OFF retains the original iterator verbatim. The other 175 original files and all 176 production file hashes are unchanged. Scalar arithmetic, ordering, eligibility, query dependencies, points, buckets, allocation policy and resource forecasts are retained. No runtime experimental selector, extra buffer, lookup table or worker pool is added.\n\n|Build|SDK SHA-256|Native tests|\n|:---|:---|:---|\n|Fresh OFF|`4ba7aad6d3e71104b971a0c44b9d7d8c5207e627e3e51331702e85adf069c2ef`|127 core, 2 prover, 6 cubic|\n|Candidate ON|`c88a3528d5feb363732dd2557d1894c93e9161f4e3ec9e9d3c7e2564283bf2fe`|127 core, 2 prover, 6 cubic|\n\nBoth builds coherently rebuild eight linked libraries with Rust 1.98.1, znver4 and the accepted manual flags including dense busy reset. The original accepted driver and allocator are retained. Libraries and proc-macro objects are frozen before explicit Rust 1.98.1 SDK linking. Native tests are unfiltered. Field source is exact and its accepted qualification is inherited; this stage claims no new full-field, generic, phone or concurrent-proof qualification.\n\nThree reader models pass before preflight: equal ratios and ties, nonproportional paired ordering, and exact binomial coverage for the declared interval. The independent reader then checks all command argv/environment and exit/stream hashes, worker placement, sample counts, proof/public/image bindings and freshness.\n\nLocal container preflight runs the candidate on all nine shapes and the accepted/fresh controls on 1×2, at four workers. Each process makes one measured request after three primes: **44 SDK calls and 11 distinct fresh 164-byte Gnark-verified exports**. The raw samples are functional evidence, not a performance comparison. The verified-export ledger advances **50,208 → 50,219**, SHA-256 `287a840843fcc114fac764bce8f56d74a6c4184288f5a44ee57dab8e16998d11`.\n\nThe [target protocol](artifacts/target-protocol.md), consumers and both readers are frozen before the first local SDK request. The prepared final image contains accepted REF, fresh OFF and candidate ON binaries plus the sealed preflight inventory. Planned cloud work is 21 matched blocks at 32/96 workers, 151 requests after three primes per process, with six functional preflights: 19,428 SDK calls and 132 new exports if completed. The proposed final ledger is 50,351; it has not been reached. Candidate96 must improve latency against both controls; calibration, 32-worker nonregression, CPU and RSS checks must also pass. All-shape qualification is still required before adoption.\n\nThe final image is built locally and pinned, but is **not published**, and no instance, volume or transfer bucket is created for this experiment. The owned-resource lifecycle helpers are prepared with a unique run ID, automatic termination and credential checks. A new valid dev SSO session is required before publication and launch. Completed builds, tests, preflight and final-image construction must be reused.\n\nAn initial outer workflow attempts to nest retained xtask workflows and fails its host lock before any Cargo command. The retained correction runs the two native plans directly; all successful science executes once. Thirty-seven successful command receipts and the one host-lock failure are hash checked. Direct preparation/compiler invocations and the authentication failure are outside that workflow count. No owned build/helper/hash/analysis overlaps any SDK preflight request.\n\nNo AWS latency, new Aeglos comparison or minimum-RAM/pressure/ARM/TEE result is supplied by this preparation. The original all-eight verified 10× M5 CPU objective remains active and unmet. Existing [accepted CPU and Metal comparisons](../2026-11-10-accepted-current-c7a176/README.md) remain separate historical context.\n\n[Native review](artifacts/native-review.json), [functional review](artifacts/local-review.json), [source edit](artifacts/source-audit.json), [authentication state](artifacts/auth-block.json), [publication checks](artifacts/publication.json), [sources, receipts and public proofs](artifacts/preparation-sources-receipts-public-proofs.tar.gz), [checksums](SHA256SUMS). The archive round-trips exact member bytes and hashes; SDK executables, compiled libraries, production proving inputs and credentials are excluded. Reproduction requires the pinned toolchain, verifier and private inputs.\n\nLocal experiment directory: `/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176`; executables: `sdk-control-znver4` and `sdk-candidate-znver4`.\n";
    fs::write(d.join("README.md"), text).unwrap();
    let mut sums = String::new();
    for e in fs::read_dir(&a).unwrap() {
        let p = e.unwrap().path();
        sums += &format!(
            "{}  artifacts/{}\n",
            hash(&p),
            p.file_name().unwrap().to_str().unwrap()
        );
    }
    sums += &format!("{}  README.md\n", hash(d.join("README.md")));
    fs::write(d.join("SHA256SUMS"), sums).unwrap();
    assert!(Command::new("sha256sum")
        .args(["-c", "SHA256SUMS"])
        .current_dir(d)
        .status()
        .unwrap()
        .success());
    println!("{review}");
}
