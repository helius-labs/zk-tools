use serde_json::json;
use std::{fs, path::Path, process::Command};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
const OLD: &str = "/home/ubuntu/src/zopro-perf-work/task-interval-c7a176";
fn main() {
    let r = Path::new(ROOT);
    let deps = "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
    for (source, dest) in [
        ("cloud-90m.rs", "cloud.rs"),
        ("transfer.rs", "transfer.rs"),
        ("sigv4.rs", "sigv4.rs"),
        (
            "launch-template-resolved.json",
            "launch-template-resolved.json",
        ),
        ("user-data-90m.sh", "user-data-template.sh"),
    ] {
        assert!(!r.join(dest).exists());
        let text = fs::read_to_string(Path::new(OLD).join(source))
            .unwrap()
            .replace(OLD, ROOT)
            .replace("zopro-task-interval-c7a", "zopro-phi-grain-c7a");
        fs::write(r.join(dest), text).unwrap();
    }
    for name in ["cloud", "transfer"] {
        let compiler = "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
        let argv = vec![
            "--edition=2021".to_owned(),
            "-O".into(),
            r.join(format!("{name}.rs")).display().to_string(),
            "-L".into(),
            format!("dependency={deps}"),
            "--extern".into(),
            format!("serde_json={deps}/libserde_json-cdebb9338c2784ad.rlib"),
            "--extern".into(),
            format!("sha2={deps}/libsha2-16b8f2c03bdf5faa.rlib"),
            "-o".into(),
            r.join(name).display().to_string(),
        ];
        let o = Command::new(compiler).args(&argv).output().unwrap();
        fs::write(r.join(format!("{name}-build.stdout")), o.stdout).unwrap();
        fs::write(r.join(format!("{name}-build.stderr")), o.stderr).unwrap();
        fs::write(r.join(format!("{name}-build.json")),serde_json::to_vec_pretty(&json!({"compiler":compiler,"argv":argv,"success":o.status.success(),"exit_code":o.status.code()})).unwrap()).unwrap();
        assert!(o.status.success());
    }
    println!("Preparedownedlifecycle90minTTL/110mincredentials/noingress/encrypteddeletevolume; noAWSresourcecreated");
}
