use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let r = Path::new("/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176");
    assert!(!r.join("native-review.json").exists());
    let audit = read(r.join("source-audit.json"));
    let originals = audit["originals"].as_object().unwrap();
    assert_eq!(originals.len(), 176);
    let edit = &audit["edits"][0];
    for (rel, expected) in originals {
        let p = r.join("source").join(rel);
        let actual = if edit["path"] == rel.as_str() {
            let s = fs::read_to_string(&p).unwrap();
            assert_eq!(s.matches(edit["after"].as_str().unwrap()).count(), 1);
            let recovered = s.replace(
                edit["after"].as_str().unwrap(),
                edit["before"].as_str().unwrap(),
            );
            format!("{:x}", Sha256::digest(recovered.as_bytes()))
        } else {
            hash(&p)
        };
        assert_eq!(actual, expected.as_str().unwrap());
        assert_eq!(
            hash(Path::new("/home/ubuntu/src/zk-tools/zopro").join(rel)),
            expected.as_str().unwrap()
        );
    }
    let control_flags = fs::read_to_string(r.join("control-flags.txt")).unwrap();
    let candidate_flags = fs::read_to_string(r.join("candidate-flags.txt")).unwrap();
    assert_eq!(
        candidate_flags
            .strip_suffix(" --cfg zopro_phi_grain")
            .unwrap(),
        control_flags
    );
    let mut identities = BTreeMap::new();
    let mut receipts = 0;
    for label in ["control", "candidate"] {
        let dir = r.join(format!("native-{label}"));
        assert_eq!(read(dir.join("result.json"))["status"], "complete");
        for stem in [
            format!("{label}-core"),
            format!("{label}-prover"),
            format!("libraries-{label}"),
            format!("freeze-{label}"),
            format!("link-{label}"),
        ] {
            let d = dir.join(stem);
            let e = read(d.join("exit.json"));
            assert_eq!(e["success"], true);
            for (f, k) in [
                ("stdout.log", "stdout_sha256"),
                ("stderr.log", "stderr_sha256"),
            ] {
                assert_eq!(hash(d.join(f)), e[k]);
            }
            receipts += 1;
        }
        let core = fs::read_to_string(dir.join(format!("{label}-core/stdout.log"))).unwrap();
        assert!(core.contains("127 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
        let prover = fs::read_to_string(dir.join(format!("{label}-prover/stdout.log"))).unwrap();
        for n in [2, 6] {
            assert!(prover.contains(&format!(
                "{n} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
            )));
        }
        let frozen = read(r.join(format!("frozen-{label}.json")));
        assert_eq!(frozen["libraries"].as_object().unwrap().len(), 8);
        for (p, h) in frozen["input_pins"].as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
        assert_eq!(read(r.join(format!("link-{label}.json")))["success"], true);
        identities.insert(label, json!({"path":r.join(format!("sdk-{label}-znver4")),"sha256":hash(r.join(format!("sdk-{label}-znver4"))),"frozen":frozen}));
    }
    let pins: BTreeMap<String, String> =
        serde_json::from_value(read(r.join("build-pins.json"))).unwrap();
    for (p, h) in &pins {
        assert_eq!(&hash(p), h);
    }
    let result = json!({"status":"PASS","source_originals":176,"unchanged_originals":175,"reversible_originals":1,"production_unchanged":true,"native_tests_per_arm":{"core":127,"prover":2,"cubic":6},"successful_workflow_receipts":receipts,"input_pins_checked":pins.len(),"identities":identities,"new_SDK_requests":0,"new_proofs":0,"canonical_ledger":50208,"performance_measured":false,"generic_portable_concurrency_qualification_not_new_here":true,"initial_nested_workflow_failed_before_Cargo":true});
    fs::write(
        r.join("native-review.json"),
        serde_json::to_vec_pretty(&result).unwrap(),
    )
    .unwrap();
    println!("PASS current176 OFF/ON both127core+2prover+6cubic/coherent8libs/nativeSDK; zeroSDKrequests, canonical50208");
}
