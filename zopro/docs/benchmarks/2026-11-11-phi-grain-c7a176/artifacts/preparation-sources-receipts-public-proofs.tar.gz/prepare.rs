use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const R: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
const A: &str = "/home/ubuntu/src/zopro-perf-work/accepted-current-c7a176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: &Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn main() {
    let r = Path::new(R);
    assert!(!r.join("source").exists());
    let manifest=read(Path::new(Z).join("docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json"));
    let orig = manifest["source_files_sha256"].as_object().unwrap();
    assert_eq!(orig.len(), 176);
    let mut pins = BTreeMap::<String, String>::new();
    for (rel, h) in orig {
        let p = Path::new(Z).join(rel);
        assert_eq!(hash(&p), h.as_str().unwrap());
        let d = r.join("source").join(rel);
        fs::create_dir_all(d.parent().unwrap()).unwrap();
        fs::copy(&p, &d).unwrap();
        pins.insert(p.display().to_string(), hash(p));
    }
    let rel = "crates/zopro-core/src/msm_affine/g2_phi.rs";
    let p = r.join("source").join(rel);
    let before = "    short.par_iter_mut().for_each(|s| *s = phi_split(*s));";
    let after="    #[cfg(zopro_phi_grain)]\n    short.par_iter_mut().with_min_len(128).for_each(|s| *s = phi_split(*s));\n    #[cfg(not(zopro_phi_grain))]\n    short.par_iter_mut().for_each(|s| *s = phi_split(*s));";
    let s = fs::read_to_string(&p).unwrap();
    assert_eq!(s.matches(before).count(), 1);
    fs::write(&p, s.replace(before, after)).unwrap();
    let recovered = fs::read_to_string(&p).unwrap().replace(after, before);
    assert_eq!(
        format!("{:x}", Sha256::digest(recovered.as_bytes())),
        orig[rel]
    );
    save(
        r.join("source-audit.json"),
        &json!({"originals":orig,"changed_originals":1,"unchanged_originals":175,"edits":[{"path":rel,"before":before,"after":after}],"inverse_recovery":true,"production_unchanged":true}),
    );
    fs::create_dir(r.join("support")).unwrap();
    for f in ["driver.rs", "support/perf.rs"] {
        fs::copy(Path::new(A).join(f), r.join(f)).unwrap();
    }
    let mut native = fs::read_to_string(Path::new(A).join("native.rs"))
        .unwrap()
        .replace(A, R)
        .replace("\"native-use\"", "\"native-candidate\"")
        .replace("\"native\"", "\"native-control\"");
    let at = "        Some(\"freeze\") => freeze(&a[2]),";
    assert_eq!(native.matches(at).count(), 1);
    native = native.replace(at, &format!("{at}\n        Some(\"link\") => link(&a[2]),"));
    native.push_str(r#"
fn link(label:&str){let f=read(r(format!("frozen-{label}.json")));let mut a=vec!["--edition=2021".to_owned(),"-O".into(),"-Clto=fat".into(),"-Ccodegen-units=1".into(),"-Cdebuginfo=1".into(),"-L".into(),format!("dependency={R}/frozen/{label}")];a.extend(fs::read_to_string(r(format!("{label}-flags.txt"))).unwrap().split_whitespace().map(str::to_owned));for(n,p)in f["libraries"].as_object().unwrap(){a.extend(["--extern".into(),format!("{n}={}",p.as_str().unwrap())]);}for(p,h)in f["input_pins"].as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}a.extend([format!("{R}/driver.rs"),"-o".into(),format!("{R}/sdk-{label}-znver4")]);let compiler="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";let o=std::process::Command::new(compiler).args(&a).output().unwrap();fs::write(r(format!("link-{label}.stdout")),&o.stdout).unwrap();fs::write(r(format!("link-{label}.stderr")),&o.stderr).unwrap();save(r(format!("link-{label}.json")),&serde_json::json!({"compiler":compiler,"argv":a,"success":o.status.success(),"exit_code":o.status.code(),"stdout_sha256":hash(r(format!("link-{label}.stdout"))),"stderr_sha256":hash(r(format!("link-{label}.stderr")))}));assert!(o.status.success(),"explicit1.98.1link failed; preserve receipts");println!("LINKED{label} coherent8libs:{}",hash(r(format!("sdk-{label}-znver4"))));}
"#);
    fs::write(r.join("native.rs"), native).unwrap();
    let deps = "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
    let compiler = "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
    let argv = vec![
        "--edition=2021".to_owned(),
        "-O".into(),
        r.join("native.rs").display().to_string(),
        "-L".into(),
        format!("dependency={deps}"),
        "--extern".into(),
        format!("serde_json={deps}/libserde_json-cdebb9338c2784ad.rlib"),
        "--extern".into(),
        format!("sha2={deps}/libsha2-16b8f2c03bdf5faa.rlib"),
        "-o".into(),
        r.join("native-helper").display().to_string(),
    ];
    let o = Command::new(compiler).args(&argv).output().unwrap();
    fs::write(r.join("native-helper.stdout"), &o.stdout).unwrap();
    fs::write(r.join("native-helper.stderr"), &o.stderr).unwrap();
    save(
        r.join("native-helper-build.json"),
        &json!({"argv":argv,"success":o.status.success(),"exit_code":o.status.code()}),
    );
    assert!(o.status.success());
    let template = fs::read_to_string(Path::new(A).join("build-plan-fixed2.json"))
        .unwrap()
        .replace(A, R);
    let old: Value = serde_json::from_str(&template).unwrap();
    let mut outer = vec![];
    for label in ["control", "candidate"] {
        let mut steps = vec![];
        for base in &old["steps"].as_array().unwrap()[1..5] {
            let mut step: Value = serde_json::from_str(
                &serde_json::to_string(base)
                    .unwrap()
                    .replace("control", label),
            )
            .unwrap();
            if let Some(env) = step.get_mut("environment") {
                let flags = env["RUSTFLAGS"].as_str().unwrap().to_owned()
                    + " --check-cfg=cfg(zopro_phi_grain)"
                    + if label == "candidate" {
                        " --cfg zopro_phi_grain"
                    } else {
                        ""
                    };
                assert!(
                    flags.contains("target-cpu=znver4")
                        && flags.contains("zopro_dense_busy_reset")
                        && !flags.contains("zopro_task_lifecycle")
                );
                env["RUSTFLAGS"] = json!(flags);
                env["PATH"]=json!("/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin");
                env["RUSTC"] = json!(compiler);
                env["CARGO_BUILD_JOBS"] = json!("12");
                fs::write(
                    r.join(format!("{label}-flags.txt")),
                    env["RUSTFLAGS"].as_str().unwrap(),
                )
                .unwrap();
            }
            steps.push(step);
        }
        steps.push(json!({"kind":"command","name":format!("link-{label}"),"argv":[r.join("native-helper"),"link",label],"timeout_seconds":900}));
        let plan = r.join(format!("{label}-plan.json"));
        save(
            &plan,
            &json!({"version":1,"source_pins":r.join("build-pins.json"),"steps":steps}),
        );
        outer.push(json!({"kind":"command","name":format!("native-{label}"),"argv":["/home/ubuntu/src/zopro-perf-work/tool-target/release/xtask","workflow",plan,r.join(format!("native-{label}"))],"timeout_seconds":3600}));
    }
    for rel in orig.keys() {
        let p = r.join("source").join(rel);
        pins.insert(p.display().to_string(), hash(&p));
    }
    for f in [
        "prepare.rs",
        "prepare",
        "design.md",
        "native.rs",
        "native-helper",
        "driver.rs",
        "support/perf.rs",
        "source-audit.json",
        "control-flags.txt",
        "candidate-flags.txt",
        "control-plan.json",
        "candidate-plan.json",
    ] {
        let p = r.join(f);
        pins.insert(p.display().to_string(), hash(p));
    }
    save(r.join("build-pins.json"), &json!(pins));
    save(
        r.join("build-plan.json"),
        &json!({"version":1,"source_pins":r.join("build-pins.json"),"steps":outer}),
    );
    println!("Preparedclean176sourceOFF/ON coherentZen4 nativecore/prover/libraries/freeze/explicitlink, noSDKcalls");
}
