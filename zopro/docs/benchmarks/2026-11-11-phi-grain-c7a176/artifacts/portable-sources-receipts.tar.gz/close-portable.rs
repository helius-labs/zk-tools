use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
const DEST: &str = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-11-phi-grain-c7a176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let r = Path::new(ROOT);
    let d = Path::new(DEST);
    let a = d.join("artifacts");
    assert!(!r.join("portable-review.json").exists());
    assert_eq!(
        read(r.join("portable-runs/result.json"))["status"],
        "complete"
    );
    let step = r.join("portable-runs/generic-core-prover-cubic");
    let exit = read(step.join("exit.json"));
    assert_eq!(exit["success"], true);
    assert_eq!(exit["returncode"], 0);
    for (f, k) in [
        ("stdout.log", "stdout_sha256"),
        ("stderr.log", "stderr_sha256"),
    ] {
        assert_eq!(hash(step.join(f)), exit[k]);
    }
    let command = read(step.join("command.json"));
    let flags = command["environment"]["RUSTFLAGS"].as_str().unwrap();
    for value in [
        "target-cpu=x86-64",
        "--cfg no_ifma",
        "--cfg no_asm",
        "--cfg zopro_phi_grain",
    ] {
        assert!(flags.contains(value));
    }
    assert!(!flags.contains("target-cpu=znver4"));
    let raw = fs::read_to_string(step.join("stdout.log")).unwrap();
    for count in [102, 2, 0] {
        assert!(raw.contains(&format!(
            "{count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
        )));
    }
    let mut fingerprints = vec![];
    let root = r.join("target-generic/x86_64-unknown-linux-gnu/release/.fingerprint");
    for e in fs::read_dir(&root).unwrap() {
        let p = e.unwrap().path().join("test-lib-zopro_core.json");
        if p.exists() {
            let f = read(&p);
            assert_eq!(
                f["rustflags"],
                json!(flags.split_whitespace().collect::<Vec<_>>())
            );
            fingerprints.push(json!({"path":p,"metadata":f}));
        }
    }
    assert_eq!(fingerprints.len(), 1);
    let pins: BTreeMap<String, String> =
        serde_json::from_value(read(r.join("portable-pins.json"))).unwrap();
    for (p, h) in &pins {
        assert_eq!(&hash(p), h);
    }
    assert_eq!(
        hash(r.join("proof-sha256-after-preflight.json")),
        "287a840843fcc114fac764bce8f56d74a6c4184288f5a44ee57dab8e16998d11"
    );
    let review = json!({"status":"PASS","scope":"current candidate generic x86-64/noIFMA/noASM correctness; no ARM execution or performance result","core_tests":102,"prover_tests":2,"zolana_tests":0,"zolana_test_target_compiled":true,"unfiltered_compiled_tests":true,"command_receipts":1,"input_pins_checked":pins.len(),"cargo_test_fingerprints":fingerprints,"field_suite_not_newly_run":true,"new_SDK_requests":0,"new_exported_proofs":0,"canonical_verified_exports":50219,"native_SDKs_and_target_protocol_unchanged":true});
    fs::write(
        r.join("portable-review.json"),
        serde_json::to_vec_pretty(&review).unwrap(),
    )
    .unwrap();
    fs::copy(
        r.join("portable-review.json"),
        a.join("portable-review.json"),
    )
    .unwrap();
    let stage = r.join("portable-publication");
    fs::create_dir(&stage).unwrap();
    for f in [
        "prepare-portable.rs",
        "portable-plan.json",
        "portable-pins.json",
        "portable-review.json",
        "close-portable.rs",
        "auth-recheck-2.stdout",
        "auth-recheck-2.stderr",
    ] {
        fs::copy(r.join(f), stage.join(f)).unwrap();
    }
    fs::create_dir(stage.join("workflow")).unwrap();
    for f in [
        "command.json",
        "exit.json",
        "stdout.log",
        "stderr.log",
        "tests.json",
    ] {
        fs::copy(step.join(f), stage.join("workflow").join(f)).unwrap();
    }
    let mut manifest = BTreeMap::new();
    for e in fs::read_dir(&stage).unwrap() {
        let p = e.unwrap().path();
        if p.is_file() {
            manifest.insert(
                p.file_name().unwrap().to_str().unwrap().to_owned(),
                hash(&p),
            );
        }
    }
    for e in fs::read_dir(stage.join("workflow")).unwrap() {
        let p = e.unwrap().path();
        manifest.insert(
            format!("workflow/{}", p.file_name().unwrap().to_str().unwrap()),
            hash(p),
        );
    }
    fs::write(
        stage.join("manifest.json"),
        serde_json::to_vec_pretty(&manifest).unwrap(),
    )
    .unwrap();
    let archive = a.join("portable-sources-receipts.tar.gz");
    assert!(Command::new("tar")
        .args([
            "--sort=name",
            "--mtime=2026-11-11 00:00:00Z",
            "--owner=0",
            "--group=0",
            "--numeric-owner",
            "-czf"
        ])
        .arg(&archive)
        .arg("-C")
        .arg(&stage)
        .arg(".")
        .status()
        .unwrap()
        .success());
    let round = r.join("portable-roundtrip");
    fs::create_dir(&round).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&round)
        .status()
        .unwrap()
        .success());
    for (p, h) in &manifest {
        assert_eq!(&hash(round.join(p)), h);
    }
    assert_eq!(read(round.join("manifest.json")), json!(manifest));
    let mut text = fs::read_to_string(d.join("README.md")).unwrap();
    let marker = "Three reader models pass before preflight:";
    assert_eq!(text.matches(marker).count(), 1);
    let addition="An additional generic x86-64 build with `no_ifma`, `no_asm` and the candidate cfg passes **102 core tests and two prover tests**. The Zolana test target compiles with zero tests enabled in this configuration. The suites are unfiltered within their compiled configuration; this does not mean every native-only test is available. Recorded Cargo fingerprint flags and all 367 input pins match. There are no new SDK calls or exported proofs, and no physical ARM, phone, speed or minimum-RAM result. The frozen native SDKs and AWS protocol are unchanged. [Generic review](artifacts/portable-review.json), [source and receipt archive](artifacts/portable-sources-receipts.tar.gz).\n\n";
    text = text.replace(marker, &format!("{addition}{marker}"));
    fs::write(d.join("README.md"), text).unwrap();
    let mut sums = String::new();
    for e in fs::read_dir(&a).unwrap() {
        let p = e.unwrap().path();
        sums += &format!(
            "{}  artifacts/{}\n",
            hash(&p),
            p.file_name().unwrap().to_str().unwrap()
        );
    }
    sums += &format!("{}  README.md\n", hash(d.join("README.md")));
    fs::write(d.join("SHA256SUMS"), sums).unwrap();
    assert!(Command::new("sha256sum")
        .args(["-c", "SHA256SUMS"])
        .current_dir(d)
        .status()
        .unwrap()
        .success());
    println!("Generic102core+2proverPASS; Zolana0tests/compiled; {}archive members roundtrip; zeroSDKexports; canonical50219",manifest.len());
}
