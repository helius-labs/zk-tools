use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let r = Path::new(ROOT);
    assert!(!r.join("portable-plan.json").exists());
    let native: Value =
        serde_json::from_slice(&fs::read(r.join("candidate-plan.json")).unwrap()).unwrap();
    let mut step = native["steps"][0].clone();
    step["name"] = "generic-core-prover-cubic".into();
    step["timeout_seconds"] = json!(1800);
    let args = step["argv"].as_array_mut().unwrap();
    let separator = args.iter().position(|a| a == "--").unwrap();
    args.splice(
        separator..separator,
        ["-p", "zopro-prover", "-p", "zopro-zolana"].map(|s| json!(s)),
    );
    let flags = step["environment"]["RUSTFLAGS"]
        .as_str()
        .unwrap()
        .replace("target-cpu=znver4", "target-cpu=x86-64")
        + " --cfg no_ifma --cfg no_asm";
    assert!(flags.contains("zopro_phi_grain") && !flags.contains("target-cpu=znver4"));
    step["environment"]["RUSTFLAGS"] = json!(flags);
    step["environment"]["CARGO_TARGET_DIR"] = json!(r.join("target-generic"));
    let mut pins: BTreeMap<String, String> =
        serde_json::from_slice(&fs::read(r.join("build-pins.json")).unwrap()).unwrap();
    for (p, h) in &pins {
        assert_eq!(&hash(p), h);
    }
    for f in [
        "prepare-portable.rs",
        "prepare-portable",
        "native-review.json",
    ] {
        let p = r.join(f);
        pins.insert(p.display().to_string(), hash(p));
    }
    fs::write(
        r.join("portable-pins.json"),
        serde_json::to_vec_pretty(&pins).unwrap(),
    )
    .unwrap();
    fs::write(
        r.join("portable-plan.json"),
        serde_json::to_vec_pretty(
            &json!({"version":1,"source_pins":r.join("portable-pins.json"),"steps":[step]}),
        )
        .unwrap(),
    )
    .unwrap();
    println!("Frozen distinct genericx86-64/noIFMA/noASM currentcandidate core/prover/cubic tests; noSDKlatency/export/ARMclaim");
}
