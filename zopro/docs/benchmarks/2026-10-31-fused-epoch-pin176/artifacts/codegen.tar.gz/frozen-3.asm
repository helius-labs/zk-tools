
/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000098ef0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#0}>:
   98ef0:	push   %rax
   98ef1:	call   990f0 <crossbeam_epoch::default::pin::{closure#0}>
   98ef6:	pop    %rcx
   98ef7:	ret
