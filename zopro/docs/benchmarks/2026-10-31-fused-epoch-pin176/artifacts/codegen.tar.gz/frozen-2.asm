
/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000119a10 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>>:
  119a10:	push   %r14
  119a12:	push   %rbx
  119a13:	push   %rax
  119a14:	mov    %fs:0x0,%rax
  119a1d:	lea    -0x30(%rax),%rax
  119a24:	cmpb   $0x1,0x8(%rax)
  119a28:	jne    119a91 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x81>
  119a2a:	mov    (%rax),%rbx
  119a2d:	mov    %rbx,(%rsp)
  119a31:	mov    0x818(%rbx),%rax
  119a38:	cmp    $0xffffffffffffffff,%rax
  119a3c:	je     119b38 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x128>
  119a42:	lea    0x1(%rax),%rcx
  119a46:	mov    %rcx,0x818(%rbx)
  119a4d:	test   %rax,%rax
  119a50:	jne    119a86 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  119a52:	mov    0x8(%rbx),%rax
  119a56:	mov    0x180(%rax),%rcx
  119a5d:	xor    %eax,%eax
  119a5f:	or     $0x1,%rcx
  119a63:	lock cmpxchg %rcx,0x880(%rbx)
  119a6c:	mov    0x828(%rbx),%rax
  119a73:	lea    0x1(%rax),%rcx
  119a77:	mov    %rcx,0x828(%rbx)
  119a7e:	test   $0x7f,%al
  119a80:	je     119b47 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x137>
  119a86:	mov    %rbx,%rax
  119a89:	add    $0x8,%rsp
  119a8d:	pop    %rbx
  119a8e:	pop    %r14
  119a90:	ret
  119a91:	mov    %rax,%rdi
  119a94:	xor    %esi,%esi
  119a96:	call   b5da0 <<std::sys::thread_local::native::lazy::Storage<crossbeam_epoch::collector::LocalHandle, ()>>::get_or_init_slow::<crossbeam_epoch::default::HANDLE::__rust_std_internal_init_fn>>
  119a9b:	test   %rax,%rax
  119a9e:	jne    119a2a <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1a>
  119aa0:	call   *0x118a12(%rip)        # 2324b8 <_DYNAMIC+0x610>
  119aa6:	mov    %rax,%rdi
  119aa9:	call   *0x118a11(%rip)        # 2324c0 <_DYNAMIC+0x618>
  119aaf:	mov    %rax,(%rsp)
  119ab3:	mov    %rax,%rbx
  119ab6:	mov    0x818(%rax),%rax
  119abd:	cmp    $0xffffffffffffffff,%rax
  119ac1:	je     119b5d <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x14d>
  119ac7:	lea    0x1(%rax),%rcx
  119acb:	mov    %rcx,0x818(%rbx)
  119ad2:	test   %rax,%rax
  119ad5:	jne    119b07 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0xf7>
  119ad7:	mov    0x8(%rbx),%rax
  119adb:	mov    0x180(%rax),%rcx
  119ae2:	xor    %eax,%eax
  119ae4:	or     $0x1,%rcx
  119ae8:	lock cmpxchg %rcx,0x880(%rbx)
  119af1:	mov    0x828(%rbx),%rax
  119af8:	lea    0x1(%rax),%rcx
  119afc:	mov    %rcx,0x828(%rbx)
  119b03:	test   $0x7f,%al
  119b05:	je     119b6c <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x15c>
  119b07:	mov    0x820(%rbx),%rax
  119b0e:	lea    -0x1(%rax),%rcx
  119b12:	xor    $0x1,%rax
  119b16:	mov    %rcx,0x820(%rbx)
  119b1d:	or     0x818(%rbx),%rax
  119b24:	jne    119a86 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  119b2a:	mov    %rbx,%rdi
  119b2d:	call   *0x1189b5(%rip)        # 2324e8 <_DYNAMIC+0x640>
  119b33:	jmp    119a86 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  119b38:	lea    0x115459(%rip),%rdi        # 22ef98 <__frame_dummy_init_array_entry+0x35e8>
  119b3f:	call   *0x1185b3(%rip)        # 2320f8 <_DYNAMIC+0x250>
  119b45:	jmp    119b6a <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x15a>
  119b47:	mov    0x8(%rbx),%rdi
  119b4b:	sub    $0xffffffffffffff80,%rdi
  119b4f:	mov    %rsp,%rsi
  119b52:	call   *0x118998(%rip)        # 2324f0 <_DYNAMIC+0x648>
  119b58:	jmp    119a86 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  119b5d:	lea    0x115434(%rip),%rdi        # 22ef98 <__frame_dummy_init_array_entry+0x35e8>
  119b64:	call   *0x11858e(%rip)        # 2320f8 <_DYNAMIC+0x250>
  119b6a:	ud2
  119b6c:	mov    0x8(%rbx),%rdi
  119b70:	sub    $0xffffffffffffff80,%rdi
  119b74:	mov    %rsp,%rsi
  119b77:	call   *0x118973(%rip)        # 2324f0 <_DYNAMIC+0x648>
  119b7d:	jmp    119b07 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0xf7>
  119b7f:	mov    %rax,%r14
  119b82:	mov    %rbx,%rdi
  119b85:	call   11e900 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
  119b8a:	mov    0x820(%rbx),%rax
  119b91:	lea    -0x1(%rax),%rcx
  119b95:	xor    $0x1,%rax
  119b99:	mov    %rcx,0x820(%rbx)
  119ba0:	or     0x818(%rbx),%rax
  119ba7:	jne    119bcb <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1bb>
  119ba9:	mov    %rbx,%rdi
  119bac:	call   *0x118936(%rip)        # 2324e8 <_DYNAMIC+0x640>
  119bb2:	jmp    119bcb <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1bb>
  119bb4:	call   *0x118546(%rip)        # 232100 <_DYNAMIC+0x258>
  119bba:	call   *0x118540(%rip)        # 232100 <_DYNAMIC+0x258>
  119bc0:	mov    %rax,%r14
  119bc3:	mov    %rbx,%rdi
  119bc6:	call   11e900 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
  119bcb:	mov    %r14,%rdi
  119bce:	call   22a930 <_Unwind_Resume@plt>
  119bd3:	call   *0x118527(%rip)        # 232100 <_DYNAMIC+0x258>
