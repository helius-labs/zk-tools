
/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000096ac0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>>:
   96ac0:	sub    $0x48,%rsp
   96ac4:	lea    0x196375(%rip),%rdi        # 22ce40 <__frame_dummy_init_array_entry+0x1490>
   96acb:	lea    0x1f(%rsp),%rsi
   96ad0:	call   79aa0 <<std::thread::local::LocalKey<crossbeam_epoch::collector::LocalHandle>>::try_with::<crossbeam_epoch::default::with_handle<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#0}, crossbeam_epoch::guard::Guard>>
   96ad5:	mov    %rdx,0x8(%rsp)
   96ada:	mov    %rax,0x10(%rsp)
   96adf:	jmp    96afb <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x3b>
   96ae1:	mov    0x38(%rsp),%rdi
   96ae6:	call   22a930 <_Unwind_Resume@plt>
   96aeb:	mov    %rax,%rcx
   96aee:	mov    %edx,%eax
   96af0:	mov    %rcx,0x38(%rsp)
   96af5:	mov    %eax,0x40(%rsp)
   96af9:	jmp    96ae1 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x21>
   96afb:	mov    0x8(%rsp),%rax
   96b00:	mov    0x10(%rsp),%rcx
   96b05:	mov    %rcx,0x28(%rsp)
   96b0a:	mov    %rax,0x30(%rsp)
   96b0f:	testq  $0x1,0x28(%rsp)
   96b18:	je     96b2a <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x6a>
   96b1a:	lea    0x1f(%rsp),%rdi
   96b1f:	call   98f00 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}>
   96b24:	mov    %rax,(%rsp)
   96b28:	jmp    96b3e <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x7e>
   96b2a:	mov    0x30(%rsp),%rax
   96b2f:	mov    %rax,0x20(%rsp)
   96b34:	mov    0x20(%rsp),%rax
   96b39:	add    $0x48,%rsp
   96b3d:	ret
   96b3e:	mov    (%rsp),%rax
   96b42:	mov    %rax,0x20(%rsp)
   96b47:	jmp    96b34 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x74>
