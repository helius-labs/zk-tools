
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000098de0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}>:
   98de0:	sub    $0x28,%rsp
   98de4:	mov    %rdi,(%rsp)
   98de8:	mov    0x1998f9(%rip),%rax        # 2326e8 <_DYNAMIC+0x610>
   98def:	call   *%rax
   98df1:	mov    %rax,%rdi
   98df4:	mov    0x1998f5(%rip),%rax        # 2326f0 <_DYNAMIC+0x618>
   98dfb:	call   *%rax
   98dfd:	mov    (%rsp),%rdi
   98e01:	mov    %rax,0x10(%rsp)
   98e06:	lea    0x10(%rsp),%rsi
   98e0b:	call   98fd0 <crossbeam_epoch::default::pin::{closure#0}>
   98e10:	mov    %rax,0x8(%rsp)
   98e15:	jmp    98e33 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}+0x53>
   98e17:	lea    0x10(%rsp),%rdi
   98e1c:	call   97dc0 <core::ptr::drop_glue::<crossbeam_epoch::collector::LocalHandle>>
   98e21:	jmp    98e4d <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}+0x6d>
   98e23:	mov    %rax,%rcx
   98e26:	mov    %edx,%eax
   98e28:	mov    %rcx,0x18(%rsp)
   98e2d:	mov    %eax,0x20(%rsp)
   98e31:	jmp    98e17 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}+0x37>
   98e33:	lea    0x10(%rsp),%rdi
   98e38:	call   97dc0 <core::ptr::drop_glue::<crossbeam_epoch::collector::LocalHandle>>
   98e3d:	mov    0x8(%rsp),%rax
   98e42:	add    $0x28,%rsp
   98e46:	ret
   98e47:	call   *0x1994e3(%rip)        # 232330 <_DYNAMIC+0x258>
   98e4d:	mov    0x18(%rsp),%rdi
   98e52:	call   22ab60 <_Unwind_Resume@plt>
