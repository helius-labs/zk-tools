
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000096830 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>>:
   96830:	sub    $0x48,%rsp
   96834:	lea    0x196835(%rip),%rdi        # 22d070 <__frame_dummy_init_array_entry+0x1490>
   9683b:	lea    0x1f(%rsp),%rsi
   96840:	call   79680 <<std::thread::local::LocalKey<crossbeam_epoch::collector::LocalHandle>>::try_with::<crossbeam_epoch::default::with_handle<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#0}, crossbeam_epoch::guard::Guard>>
   96845:	mov    %rdx,0x8(%rsp)
   9684a:	mov    %rax,0x10(%rsp)
   9684f:	jmp    9686b <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x3b>
   96851:	mov    0x38(%rsp),%rdi
   96856:	call   22ab60 <_Unwind_Resume@plt>
   9685b:	mov    %rax,%rcx
   9685e:	mov    %edx,%eax
   96860:	mov    %rcx,0x38(%rsp)
   96865:	mov    %eax,0x40(%rsp)
   96869:	jmp    96851 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x21>
   9686b:	mov    0x8(%rsp),%rax
   96870:	mov    0x10(%rsp),%rcx
   96875:	mov    %rcx,0x28(%rsp)
   9687a:	mov    %rax,0x30(%rsp)
   9687f:	testq  $0x1,0x28(%rsp)
   96888:	je     9689a <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x6a>
   9688a:	lea    0x1f(%rsp),%rdi
   9688f:	call   98de0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}>
   96894:	mov    %rax,(%rsp)
   96898:	jmp    968ae <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x7e>
   9689a:	mov    0x30(%rsp),%rax
   9689f:	mov    %rax,0x20(%rsp)
   968a4:	mov    0x20(%rsp),%rax
   968a9:	add    $0x48,%rsp
   968ad:	ret
   968ae:	mov    (%rsp),%rax
   968b2:	mov    %rax,0x20(%rsp)
   968b7:	jmp    968a4 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x74>
