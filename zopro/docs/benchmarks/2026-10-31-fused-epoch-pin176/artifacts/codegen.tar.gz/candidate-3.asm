
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001d9560 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal>:
  1d9560:	push   %r15
  1d9562:	push   %r14
  1d9564:	push   %r12
  1d9566:	push   %rbx
  1d9567:	push   %rax
  1d9568:	mov    (%rsi),%r12
  1d956b:	mov    %rdi,%r14
  1d956e:	mov    %fs:0x0,%rax
  1d9577:	lea    -0x30(%rax),%rax
  1d957e:	mov    0x100(%r12),%r15
  1d9586:	cmpb   $0x1,0x8(%rax)
  1d958a:	jne    1d96b8 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x158>
  1d9590:	mov    (%rax),%rbx
  1d9593:	cmpq   $0x0,0x818(%rbx)
  1d959b:	je     1d95ca <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x6a>
  1d959d:	lock orl $0x0,-0x40(%rsp)
  1d95a3:	mov    0x818(%rbx),%rax
  1d95aa:	mov    %rbx,(%rsp)
  1d95ae:	cmp    $0xffffffffffffffff,%rax
  1d95b2:	je     1d9714 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x1b4>
  1d95b8:	lea    0x1(%rax),%rcx
  1d95bc:	mov    %rcx,0x818(%rbx)
  1d95c3:	test   %rax,%rax
  1d95c6:	jne    1d960d <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xad>
  1d95c8:	jmp    1d95d9 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x79>
  1d95ca:	mov    %rbx,(%rsp)
  1d95ce:	movq   $0x1,0x818(%rbx)
  1d95d9:	mov    0x8(%rbx),%rax
  1d95dd:	mov    0x180(%rax),%rcx
  1d95e4:	xor    %eax,%eax
  1d95e6:	or     $0x1,%rcx
  1d95ea:	lock cmpxchg %rcx,0x880(%rbx)
  1d95f3:	mov    0x828(%rbx),%rax
  1d95fa:	lea    0x1(%rax),%rcx
  1d95fe:	mov    %rcx,0x828(%rbx)
  1d9605:	test   $0x7f,%al
  1d9607:	je     1d9726 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x1c6>
  1d960d:	mov    0x108(%r12),%rax
  1d9615:	sub    %r15,%rax
  1d9618:	test   %rax,%rax
  1d961b:	jle    1d9685 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x125>
  1d961d:	mov    0x80(%r12),%rax
  1d9625:	mov    %rax,%rcx
  1d9628:	and    $0xfffffffffffffff8,%rcx
  1d962c:	mov    (%rcx),%rsi
  1d962f:	mov    0x8(%rcx),%rcx
  1d9633:	dec    %rcx
  1d9636:	and    %r15,%rcx
  1d9639:	shl    $0x4,%rcx
  1d963d:	mov    (%rsi,%rcx,1),%rdx
  1d9641:	mov    0x8(%rsi,%rcx,1),%rsi
  1d9646:	mov    0x80(%r12),%rdi
  1d964e:	mov    $0x2,%ecx
  1d9653:	cmp    %rax,%rdi
  1d9656:	jne    1d9687 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x127>
  1d9658:	lea    0x1(%r15),%rdi
  1d965c:	mov    %r15,%rax
  1d965f:	lock cmpxchg %rdi,0x100(%r12)
  1d9669:	jne    1d9687 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x127>
  1d966b:	mov    %rdx,0x8(%r14)
  1d966f:	mov    %rsi,0x10(%r14)
  1d9673:	movq   $0x1,(%r14)
  1d967a:	decq   0x818(%rbx)
  1d9681:	je     1d9693 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x133>
  1d9683:	jmp    1d96ac <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x14c>
  1d9685:	xor    %ecx,%ecx
  1d9687:	mov    %rcx,(%r14)
  1d968a:	decq   0x818(%rbx)
  1d9691:	jne    1d96ac <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x14c>
  1d9693:	movq   $0x0,0x880(%rbx)
  1d969e:	cmpq   $0x0,0x820(%rbx)
  1d96a6:	je     1d973c <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x1dc>
  1d96ac:	add    $0x8,%rsp
  1d96b0:	pop    %rbx
  1d96b1:	pop    %r12
  1d96b3:	pop    %r14
  1d96b5:	pop    %r15
  1d96b7:	ret
  1d96b8:	mov    %rax,%rdi
  1d96bb:	xor    %esi,%esi
  1d96bd:	call   1d47e0 <<std::sys::thread_local::native::lazy::Storage<crossbeam_epoch::collector::LocalHandle, ()>>::get_or_init_slow::<crossbeam_epoch::default::HANDLE::__rust_std_internal_init_fn>>
  1d96c2:	test   %rax,%rax
  1d96c5:	jne    1d9590 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x30>
  1d96cb:	call   *0x59017(%rip)        # 2326e8 <_DYNAMIC+0x610>
  1d96d1:	mov    %rax,%rdi
  1d96d4:	call   *0x59016(%rip)        # 2326f0 <_DYNAMIC+0x618>
  1d96da:	cmpq   $0x0,0x818(%rax)
  1d96e2:	mov    %rax,%rbx
  1d96e5:	je     1d974a <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x1ea>
  1d96e7:	lock orl $0x0,-0x40(%rsp)
  1d96ed:	mov    0x818(%rbx),%rax
  1d96f4:	mov    %rbx,(%rsp)
  1d96f8:	cmp    $0xffffffffffffffff,%rax
  1d96fc:	je     1d97ba <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x25a>
  1d9702:	lea    0x1(%rax),%rcx
  1d9706:	mov    %rcx,0x818(%rbx)
  1d970d:	test   %rax,%rax
  1d9710:	jne    1d9789 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x229>
  1d9712:	jmp    1d9759 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x1f9>
  1d9714:	lea    0x562e5(%rip),%rdi        # 22fa00 <__frame_dummy_init_array_entry+0x3e20>
  1d971b:	call   *0x58c07(%rip)        # 232328 <_DYNAMIC+0x250>
  1d9721:	jmp    1d97c7 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x267>
  1d9726:	mov    0x8(%rbx),%rdi
  1d972a:	sub    $0xffffffffffffff80,%rdi
  1d972e:	mov    %rsp,%rsi
  1d9731:	call   *0x58fe9(%rip)        # 232720 <_DYNAMIC+0x648>
  1d9737:	jmp    1d960d <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xad>
  1d973c:	mov    %rbx,%rdi
  1d973f:	call   *0x58fd3(%rip)        # 232718 <_DYNAMIC+0x640>
  1d9745:	jmp    1d96ac <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x14c>
  1d974a:	mov    %rbx,(%rsp)
  1d974e:	movq   $0x1,0x818(%rbx)
  1d9759:	mov    0x8(%rbx),%rax
  1d975d:	mov    0x180(%rax),%rcx
  1d9764:	xor    %eax,%eax
  1d9766:	or     $0x1,%rcx
  1d976a:	lock cmpxchg %rcx,0x880(%rbx)
  1d9773:	mov    0x828(%rbx),%rax
  1d977a:	lea    0x1(%rax),%rcx
  1d977e:	mov    %rcx,0x828(%rbx)
  1d9785:	test   $0x7f,%al
  1d9787:	je     1d97c9 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x269>
  1d9789:	mov    0x820(%rbx),%rax
  1d9790:	lea    -0x1(%rax),%rcx
  1d9794:	xor    $0x1,%rax
  1d9798:	mov    %rcx,0x820(%rbx)
  1d979f:	or     0x818(%rbx),%rax
  1d97a6:	jne    1d960d <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xad>
  1d97ac:	mov    %rbx,%rdi
  1d97af:	call   *0x58f63(%rip)        # 232718 <_DYNAMIC+0x640>
  1d97b5:	jmp    1d960d <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xad>
  1d97ba:	lea    0x5623f(%rip),%rdi        # 22fa00 <__frame_dummy_init_array_entry+0x3e20>
  1d97c1:	call   *0x58b61(%rip)        # 232328 <_DYNAMIC+0x250>
  1d97c7:	ud2
  1d97c9:	mov    0x8(%rbx),%rdi
  1d97cd:	sub    $0xffffffffffffff80,%rdi
  1d97d1:	mov    %rsp,%rsi
  1d97d4:	call   *0x58f46(%rip)        # 232720 <_DYNAMIC+0x648>
  1d97da:	jmp    1d9789 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x229>
  1d97dc:	mov    %rax,%r14
  1d97df:	mov    %rbx,%rdi
  1d97e2:	call   1d6f50 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
  1d97e7:	mov    0x820(%rbx),%rax
  1d97ee:	lea    -0x1(%rax),%rcx
  1d97f2:	xor    $0x1,%rax
  1d97f6:	mov    %rcx,0x820(%rbx)
  1d97fd:	or     0x818(%rbx),%rax
  1d9804:	jne    1d9828 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x2c8>
  1d9806:	mov    %rbx,%rdi
  1d9809:	call   *0x58f09(%rip)        # 232718 <_DYNAMIC+0x640>
  1d980f:	jmp    1d9828 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x2c8>
  1d9811:	call   *0x58b19(%rip)        # 232330 <_DYNAMIC+0x258>
  1d9817:	call   *0x58b13(%rip)        # 232330 <_DYNAMIC+0x258>
  1d981d:	mov    %rax,%r14
  1d9820:	mov    %rbx,%rdi
  1d9823:	call   1d6f50 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
  1d9828:	mov    %r14,%rdi
  1d982b:	call   22ab60 <_Unwind_Resume@plt>
  1d9830:	call   *0x58afa(%rip)        # 232330 <_DYNAMIC+0x258>
