
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001d9380 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal>:
  1d9380:	push   %r15
  1d9382:	push   %r14
  1d9384:	push   %rbx
  1d9385:	mov    (%rsi),%r15
  1d9388:	mov    %rdi,%rbx
  1d938b:	mov    %fs:0x0,%rax
  1d9394:	lea    -0x30(%rax),%rax
  1d939b:	mov    0x100(%r15),%r14
  1d93a2:	cmpb   $0x1,0x8(%rax)
  1d93a6:	jne    1d9467 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xe7>
  1d93ac:	mov    (%rax),%rax
  1d93af:	mov    0x818(%rax),%rcx
  1d93b6:	test   %rcx,%rcx
  1d93b9:	je     1d93c1 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x41>
  1d93bb:	lock orl $0x0,-0x40(%rsp)
  1d93c1:	call   1d61a0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>>
  1d93c6:	mov    0x108(%r15),%rcx
  1d93cd:	mov    %rax,%rdi
  1d93d0:	sub    %r14,%rcx
  1d93d3:	test   %rcx,%rcx
  1d93d6:	jle    1d9439 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xb9>
  1d93d8:	mov    0x80(%r15),%rax
  1d93df:	mov    %rax,%rcx
  1d93e2:	and    $0xfffffffffffffff8,%rcx
  1d93e6:	mov    (%rcx),%rsi
  1d93e9:	mov    0x8(%rcx),%rcx
  1d93ed:	dec    %rcx
  1d93f0:	and    %r14,%rcx
  1d93f3:	shl    $0x4,%rcx
  1d93f7:	mov    (%rsi,%rcx,1),%rdx
  1d93fb:	mov    0x8(%rsi,%rcx,1),%rsi
  1d9400:	mov    0x80(%r15),%r8
  1d9407:	mov    $0x2,%ecx
  1d940c:	cmp    %rax,%r8
  1d940f:	jne    1d943b <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xbb>
  1d9411:	lea    0x1(%r14),%r8
  1d9415:	mov    %r14,%rax
  1d9418:	lock cmpxchg %r8,0x100(%r15)
  1d9421:	jne    1d943b <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xbb>
  1d9423:	mov    %rdx,0x8(%rbx)
  1d9427:	mov    %rsi,0x10(%rbx)
  1d942b:	movq   $0x1,(%rbx)
  1d9432:	test   %rdi,%rdi
  1d9435:	jne    1d9443 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xc3>
  1d9437:	jmp    1d9461 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xe1>
  1d9439:	xor    %ecx,%ecx
  1d943b:	mov    %rcx,(%rbx)
  1d943e:	test   %rdi,%rdi
  1d9441:	je     1d9461 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xe1>
  1d9443:	decq   0x818(%rdi)
  1d944a:	jne    1d9461 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xe1>
  1d944c:	movq   $0x0,0x880(%rdi)
  1d9457:	cmpq   $0x0,0x820(%rdi)
  1d945f:	je     1d94bd <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x13d>
  1d9461:	pop    %rbx
  1d9462:	pop    %r14
  1d9464:	pop    %r15
  1d9466:	ret
  1d9467:	mov    %rax,%rdi
  1d946a:	xor    %esi,%esi
  1d946c:	call   1d45d0 <<std::sys::thread_local::native::lazy::Storage<crossbeam_epoch::collector::LocalHandle, ()>>::get_or_init_slow::<crossbeam_epoch::default::HANDLE::__rust_std_internal_init_fn>>
  1d9471:	test   %rax,%rax
  1d9474:	jne    1d93ac <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x2c>
  1d947a:	call   *0x58ef8(%rip)        # 232378 <_DYNAMIC+0x610>
  1d9480:	mov    %rax,%rdi
  1d9483:	call   *0x58ef7(%rip)        # 232380 <_DYNAMIC+0x618>
  1d9489:	mov    0x820(%rax),%rdx
  1d9490:	mov    0x818(%rax),%rcx
  1d9497:	lea    -0x1(%rdx),%rsi
  1d949b:	xor    $0x1,%rdx
  1d949f:	or     %rcx,%rdx
  1d94a2:	mov    %rsi,0x820(%rax)
  1d94a9:	jne    1d93b6 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x36>
  1d94af:	mov    %rax,%rdi
  1d94b2:	call   *0x58ef0(%rip)        # 2323a8 <_DYNAMIC+0x640>
  1d94b8:	jmp    1d93c1 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x41>
  1d94bd:	pop    %rbx
  1d94be:	pop    %r14
  1d94c0:	pop    %r15
  1d94c2:	jmp    *0x58ee0(%rip)        # 2323a8 <_DYNAMIC+0x640>
