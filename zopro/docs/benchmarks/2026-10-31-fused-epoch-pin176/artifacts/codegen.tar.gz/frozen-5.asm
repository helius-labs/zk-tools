
/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001d94c0 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal>:
  1d94c0:	push   %r15
  1d94c2:	push   %r14
  1d94c4:	push   %rbx
  1d94c5:	mov    (%rsi),%r15
  1d94c8:	mov    %rdi,%rbx
  1d94cb:	mov    %fs:0x0,%rax
  1d94d4:	lea    -0x30(%rax),%rax
  1d94db:	mov    0x100(%r15),%r14
  1d94e2:	cmpb   $0x1,0x8(%rax)
  1d94e6:	jne    1d95a7 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xe7>
  1d94ec:	mov    (%rax),%rax
  1d94ef:	mov    0x818(%rax),%rcx
  1d94f6:	test   %rcx,%rcx
  1d94f9:	je     1d9501 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x41>
  1d94fb:	lock orl $0x0,-0x40(%rsp)
  1d9501:	call   1d62e0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>>
  1d9506:	mov    0x108(%r15),%rcx
  1d950d:	mov    %rax,%rdi
  1d9510:	sub    %r14,%rcx
  1d9513:	test   %rcx,%rcx
  1d9516:	jle    1d9579 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xb9>
  1d9518:	mov    0x80(%r15),%rax
  1d951f:	mov    %rax,%rcx
  1d9522:	and    $0xfffffffffffffff8,%rcx
  1d9526:	mov    (%rcx),%rsi
  1d9529:	mov    0x8(%rcx),%rcx
  1d952d:	dec    %rcx
  1d9530:	and    %r14,%rcx
  1d9533:	shl    $0x4,%rcx
  1d9537:	mov    (%rsi,%rcx,1),%rdx
  1d953b:	mov    0x8(%rsi,%rcx,1),%rsi
  1d9540:	mov    0x80(%r15),%r8
  1d9547:	mov    $0x2,%ecx
  1d954c:	cmp    %rax,%r8
  1d954f:	jne    1d957b <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xbb>
  1d9551:	lea    0x1(%r14),%r8
  1d9555:	mov    %r14,%rax
  1d9558:	lock cmpxchg %r8,0x100(%r15)
  1d9561:	jne    1d957b <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xbb>
  1d9563:	mov    %rdx,0x8(%rbx)
  1d9567:	mov    %rsi,0x10(%rbx)
  1d956b:	movq   $0x1,(%rbx)
  1d9572:	test   %rdi,%rdi
  1d9575:	jne    1d9583 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xc3>
  1d9577:	jmp    1d95a1 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xe1>
  1d9579:	xor    %ecx,%ecx
  1d957b:	mov    %rcx,(%rbx)
  1d957e:	test   %rdi,%rdi
  1d9581:	je     1d95a1 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xe1>
  1d9583:	decq   0x818(%rdi)
  1d958a:	jne    1d95a1 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0xe1>
  1d958c:	movq   $0x0,0x880(%rdi)
  1d9597:	cmpq   $0x0,0x820(%rdi)
  1d959f:	je     1d95fd <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x13d>
  1d95a1:	pop    %rbx
  1d95a2:	pop    %r14
  1d95a4:	pop    %r15
  1d95a6:	ret
  1d95a7:	mov    %rax,%rdi
  1d95aa:	xor    %esi,%esi
  1d95ac:	call   1d4710 <<std::sys::thread_local::native::lazy::Storage<crossbeam_epoch::collector::LocalHandle, ()>>::get_or_init_slow::<crossbeam_epoch::default::HANDLE::__rust_std_internal_init_fn>>
  1d95b1:	test   %rax,%rax
  1d95b4:	jne    1d94ec <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x2c>
  1d95ba:	call   *0x58ef8(%rip)        # 2324b8 <_DYNAMIC+0x610>
  1d95c0:	mov    %rax,%rdi
  1d95c3:	call   *0x58ef7(%rip)        # 2324c0 <_DYNAMIC+0x618>
  1d95c9:	mov    0x820(%rax),%rdx
  1d95d0:	mov    0x818(%rax),%rcx
  1d95d7:	lea    -0x1(%rdx),%rsi
  1d95db:	xor    $0x1,%rdx
  1d95df:	or     %rcx,%rdx
  1d95e2:	mov    %rsi,0x820(%rax)
  1d95e9:	jne    1d94f6 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x36>
  1d95ef:	mov    %rax,%rdi
  1d95f2:	call   *0x58ef0(%rip)        # 2324e8 <_DYNAMIC+0x640>
  1d95f8:	jmp    1d9501 <<crossbeam_deque::deque::Stealer<rayon_core::job::JobRef>>::steal+0x41>
  1d95fd:	pop    %rbx
  1d95fe:	pop    %r14
  1d9600:	pop    %r15
  1d9602:	jmp    *0x58ee0(%rip)        # 2324e8 <_DYNAMIC+0x640>
