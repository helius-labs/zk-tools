
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000098dc0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}>:
   98dc0:	sub    $0x28,%rsp
   98dc4:	mov    %rdi,(%rsp)
   98dc8:	mov    0x1995a9(%rip),%rax        # 232378 <_DYNAMIC+0x610>
   98dcf:	call   *%rax
   98dd1:	mov    %rax,%rdi
   98dd4:	mov    0x1995a5(%rip),%rax        # 232380 <_DYNAMIC+0x618>
   98ddb:	call   *%rax
   98ddd:	mov    (%rsp),%rdi
   98de1:	mov    %rax,0x10(%rsp)
   98de6:	lea    0x10(%rsp),%rsi
   98deb:	call   98fb0 <crossbeam_epoch::default::pin::{closure#0}>
   98df0:	mov    %rax,0x8(%rsp)
   98df5:	jmp    98e13 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}+0x53>
   98df7:	lea    0x10(%rsp),%rdi
   98dfc:	call   97da0 <core::ptr::drop_glue::<crossbeam_epoch::collector::LocalHandle>>
   98e01:	jmp    98e2d <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}+0x6d>
   98e03:	mov    %rax,%rcx
   98e06:	mov    %edx,%eax
   98e08:	mov    %rcx,0x18(%rsp)
   98e0d:	mov    %eax,0x20(%rsp)
   98e11:	jmp    98df7 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}+0x37>
   98e13:	lea    0x10(%rsp),%rdi
   98e18:	call   97da0 <core::ptr::drop_glue::<crossbeam_epoch::collector::LocalHandle>>
   98e1d:	mov    0x8(%rsp),%rax
   98e22:	add    $0x28,%rsp
   98e26:	ret
   98e27:	call   *0x199193(%rip)        # 231fc0 <_DYNAMIC+0x258>
   98e2d:	mov    0x18(%rsp),%rdi
   98e32:	call   22a7f0 <_Unwind_Resume@plt>
