
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000000bbf70 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>>:
   bbf70:	push   %r14
   bbf72:	push   %rbx
   bbf73:	push   %rax
   bbf74:	mov    %fs:0x0,%rax
   bbf7d:	lea    -0x30(%rax),%rax
   bbf84:	cmpb   $0x1,0x8(%rax)
   bbf88:	jne    bbff1 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x81>
   bbf8a:	mov    (%rax),%rbx
   bbf8d:	mov    %rbx,(%rsp)
   bbf91:	mov    0x818(%rbx),%rax
   bbf98:	cmp    $0xffffffffffffffff,%rax
   bbf9c:	je     bc098 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x128>
   bbfa2:	lea    0x1(%rax),%rcx
   bbfa6:	mov    %rcx,0x818(%rbx)
   bbfad:	test   %rax,%rax
   bbfb0:	jne    bbfe6 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
   bbfb2:	mov    0x8(%rbx),%rax
   bbfb6:	mov    0x180(%rax),%rcx
   bbfbd:	xor    %eax,%eax
   bbfbf:	or     $0x1,%rcx
   bbfc3:	lock cmpxchg %rcx,0x880(%rbx)
   bbfcc:	mov    0x828(%rbx),%rax
   bbfd3:	lea    0x1(%rax),%rcx
   bbfd7:	mov    %rcx,0x828(%rbx)
   bbfde:	test   $0x7f,%al
   bbfe0:	je     bc0a7 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x137>
   bbfe6:	mov    %rbx,%rax
   bbfe9:	add    $0x8,%rsp
   bbfed:	pop    %rbx
   bbfee:	pop    %r14
   bbff0:	ret
   bbff1:	mov    %rax,%rdi
   bbff4:	xor    %esi,%esi
   bbff6:	call   b5c60 <<std::sys::thread_local::native::lazy::Storage<crossbeam_epoch::collector::LocalHandle, ()>>::get_or_init_slow::<crossbeam_epoch::default::HANDLE::__rust_std_internal_init_fn>>
   bbffb:	test   %rax,%rax
   bbffe:	jne    bbf8a <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1a>
   bc000:	call   *0x176372(%rip)        # 232378 <_DYNAMIC+0x610>
   bc006:	mov    %rax,%rdi
   bc009:	call   *0x176371(%rip)        # 232380 <_DYNAMIC+0x618>
   bc00f:	mov    %rax,(%rsp)
   bc013:	mov    %rax,%rbx
   bc016:	mov    0x818(%rax),%rax
   bc01d:	cmp    $0xffffffffffffffff,%rax
   bc021:	je     bc0bd <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x14d>
   bc027:	lea    0x1(%rax),%rcx
   bc02b:	mov    %rcx,0x818(%rbx)
   bc032:	test   %rax,%rax
   bc035:	jne    bc067 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0xf7>
   bc037:	mov    0x8(%rbx),%rax
   bc03b:	mov    0x180(%rax),%rcx
   bc042:	xor    %eax,%eax
   bc044:	or     $0x1,%rcx
   bc048:	lock cmpxchg %rcx,0x880(%rbx)
   bc051:	mov    0x828(%rbx),%rax
   bc058:	lea    0x1(%rax),%rcx
   bc05c:	mov    %rcx,0x828(%rbx)
   bc063:	test   $0x7f,%al
   bc065:	je     bc0cc <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x15c>
   bc067:	mov    0x820(%rbx),%rax
   bc06e:	lea    -0x1(%rax),%rcx
   bc072:	xor    $0x1,%rax
   bc076:	mov    %rcx,0x820(%rbx)
   bc07d:	or     0x818(%rbx),%rax
   bc084:	jne    bbfe6 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
   bc08a:	mov    %rbx,%rdi
   bc08d:	call   *0x176315(%rip)        # 2323a8 <_DYNAMIC+0x640>
   bc093:	jmp    bbfe6 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
   bc098:	lea    0x172db9(%rip),%rdi        # 22ee58 <__frame_dummy_init_array_entry+0x35e8>
   bc09f:	call   *0x175f13(%rip)        # 231fb8 <_DYNAMIC+0x250>
   bc0a5:	jmp    bc0ca <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x15a>
   bc0a7:	mov    0x8(%rbx),%rdi
   bc0ab:	sub    $0xffffffffffffff80,%rdi
   bc0af:	mov    %rsp,%rsi
   bc0b2:	call   *0x1762f8(%rip)        # 2323b0 <_DYNAMIC+0x648>
   bc0b8:	jmp    bbfe6 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
   bc0bd:	lea    0x172d94(%rip),%rdi        # 22ee58 <__frame_dummy_init_array_entry+0x35e8>
   bc0c4:	call   *0x175eee(%rip)        # 231fb8 <_DYNAMIC+0x250>
   bc0ca:	ud2
   bc0cc:	mov    0x8(%rbx),%rdi
   bc0d0:	sub    $0xffffffffffffff80,%rdi
   bc0d4:	mov    %rsp,%rsi
   bc0d7:	call   *0x1762d3(%rip)        # 2323b0 <_DYNAMIC+0x648>
   bc0dd:	jmp    bc067 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0xf7>
   bc0df:	mov    %rax,%r14
   bc0e2:	mov    %rbx,%rdi
   bc0e5:	call   11e770 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
   bc0ea:	mov    0x820(%rbx),%rax
   bc0f1:	lea    -0x1(%rax),%rcx
   bc0f5:	xor    $0x1,%rax
   bc0f9:	mov    %rcx,0x820(%rbx)
   bc100:	or     0x818(%rbx),%rax
   bc107:	jne    bc12b <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1bb>
   bc109:	mov    %rbx,%rdi
   bc10c:	call   *0x176296(%rip)        # 2323a8 <_DYNAMIC+0x640>
   bc112:	jmp    bc12b <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1bb>
   bc114:	call   *0x175ea6(%rip)        # 231fc0 <_DYNAMIC+0x258>
   bc11a:	call   *0x175ea0(%rip)        # 231fc0 <_DYNAMIC+0x258>
   bc120:	mov    %rax,%r14
   bc123:	mov    %rbx,%rdi
   bc126:	call   11e770 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
   bc12b:	mov    %r14,%rdi
   bc12e:	call   22a7f0 <_Unwind_Resume@plt>
   bc133:	call   *0x175e87(%rip)        # 231fc0 <_DYNAMIC+0x258>
