
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000098db0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#0}>:
   98db0:	push   %rax
   98db1:	call   98fb0 <crossbeam_epoch::default::pin::{closure#0}>
   98db6:	pop    %rcx
   98db7:	ret
