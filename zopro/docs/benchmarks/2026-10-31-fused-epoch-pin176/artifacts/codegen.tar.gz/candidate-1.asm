
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000098dd0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#0}>:
   98dd0:	push   %rax
   98dd1:	call   98fd0 <crossbeam_epoch::default::pin::{closure#0}>
   98dd6:	pop    %rcx
   98dd7:	ret
