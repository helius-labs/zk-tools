
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000096810 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>>:
   96810:	sub    $0x48,%rsp
   96814:	lea    0x1964e5(%rip),%rdi        # 22cd00 <__frame_dummy_init_array_entry+0x1490>
   9681b:	lea    0x1f(%rsp),%rsi
   96820:	call   79660 <<std::thread::local::LocalKey<crossbeam_epoch::collector::LocalHandle>>::try_with::<crossbeam_epoch::default::with_handle<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#0}, crossbeam_epoch::guard::Guard>>
   96825:	mov    %rdx,0x8(%rsp)
   9682a:	mov    %rax,0x10(%rsp)
   9682f:	jmp    9684b <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x3b>
   96831:	mov    0x38(%rsp),%rdi
   96836:	call   22a7f0 <_Unwind_Resume@plt>
   9683b:	mov    %rax,%rcx
   9683e:	mov    %edx,%eax
   96840:	mov    %rcx,0x38(%rsp)
   96845:	mov    %eax,0x40(%rsp)
   96849:	jmp    96831 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x21>
   9684b:	mov    0x8(%rsp),%rax
   96850:	mov    0x10(%rsp),%rcx
   96855:	mov    %rcx,0x28(%rsp)
   9685a:	mov    %rax,0x30(%rsp)
   9685f:	testq  $0x1,0x28(%rsp)
   96868:	je     9687a <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x6a>
   9686a:	lea    0x1f(%rsp),%rdi
   9686f:	call   98dc0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}>
   96874:	mov    %rax,(%rsp)
   96878:	jmp    9688e <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x7e>
   9687a:	mov    0x30(%rsp),%rax
   9687f:	mov    %rax,0x20(%rsp)
   96884:	mov    0x20(%rsp),%rax
   96889:	add    $0x48,%rsp
   9688d:	ret
   9688e:	mov    (%rsp),%rax
   96892:	mov    %rax,0x20(%rsp)
   96897:	jmp    96884 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x74>
