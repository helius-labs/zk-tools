
/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001d62e0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>>:
  1d62e0:	push   %r14
  1d62e2:	push   %rbx
  1d62e3:	push   %rax
  1d62e4:	mov    %fs:0x0,%rax
  1d62ed:	lea    -0x30(%rax),%rax
  1d62f4:	cmpb   $0x1,0x8(%rax)
  1d62f8:	jne    1d6361 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x81>
  1d62fa:	mov    (%rax),%rbx
  1d62fd:	mov    %rbx,(%rsp)
  1d6301:	mov    0x818(%rbx),%rax
  1d6308:	cmp    $0xffffffffffffffff,%rax
  1d630c:	je     1d6408 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x128>
  1d6312:	lea    0x1(%rax),%rcx
  1d6316:	mov    %rcx,0x818(%rbx)
  1d631d:	test   %rax,%rax
  1d6320:	jne    1d6356 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  1d6322:	mov    0x8(%rbx),%rax
  1d6326:	mov    0x180(%rax),%rcx
  1d632d:	xor    %eax,%eax
  1d632f:	or     $0x1,%rcx
  1d6333:	lock cmpxchg %rcx,0x880(%rbx)
  1d633c:	mov    0x828(%rbx),%rax
  1d6343:	lea    0x1(%rax),%rcx
  1d6347:	mov    %rcx,0x828(%rbx)
  1d634e:	test   $0x7f,%al
  1d6350:	je     1d6417 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x137>
  1d6356:	mov    %rbx,%rax
  1d6359:	add    $0x8,%rsp
  1d635d:	pop    %rbx
  1d635e:	pop    %r14
  1d6360:	ret
  1d6361:	mov    %rax,%rdi
  1d6364:	xor    %esi,%esi
  1d6366:	call   1d4710 <<std::sys::thread_local::native::lazy::Storage<crossbeam_epoch::collector::LocalHandle, ()>>::get_or_init_slow::<crossbeam_epoch::default::HANDLE::__rust_std_internal_init_fn>>
  1d636b:	test   %rax,%rax
  1d636e:	jne    1d62fa <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1a>
  1d6370:	call   *0x5c142(%rip)        # 2324b8 <_DYNAMIC+0x610>
  1d6376:	mov    %rax,%rdi
  1d6379:	call   *0x5c141(%rip)        # 2324c0 <_DYNAMIC+0x618>
  1d637f:	mov    %rax,(%rsp)
  1d6383:	mov    %rax,%rbx
  1d6386:	mov    0x818(%rax),%rax
  1d638d:	cmp    $0xffffffffffffffff,%rax
  1d6391:	je     1d642d <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x14d>
  1d6397:	lea    0x1(%rax),%rcx
  1d639b:	mov    %rcx,0x818(%rbx)
  1d63a2:	test   %rax,%rax
  1d63a5:	jne    1d63d7 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0xf7>
  1d63a7:	mov    0x8(%rbx),%rax
  1d63ab:	mov    0x180(%rax),%rcx
  1d63b2:	xor    %eax,%eax
  1d63b4:	or     $0x1,%rcx
  1d63b8:	lock cmpxchg %rcx,0x880(%rbx)
  1d63c1:	mov    0x828(%rbx),%rax
  1d63c8:	lea    0x1(%rax),%rcx
  1d63cc:	mov    %rcx,0x828(%rbx)
  1d63d3:	test   $0x7f,%al
  1d63d5:	je     1d643c <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x15c>
  1d63d7:	mov    0x820(%rbx),%rax
  1d63de:	lea    -0x1(%rax),%rcx
  1d63e2:	xor    $0x1,%rax
  1d63e6:	mov    %rcx,0x820(%rbx)
  1d63ed:	or     0x818(%rbx),%rax
  1d63f4:	jne    1d6356 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  1d63fa:	mov    %rbx,%rdi
  1d63fd:	call   *0x5c0e5(%rip)        # 2324e8 <_DYNAMIC+0x640>
  1d6403:	jmp    1d6356 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  1d6408:	lea    0x593c1(%rip),%rdi        # 22f7d0 <__frame_dummy_init_array_entry+0x3e20>
  1d640f:	call   *0x5bce3(%rip)        # 2320f8 <_DYNAMIC+0x250>
  1d6415:	jmp    1d643a <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x15a>
  1d6417:	mov    0x8(%rbx),%rdi
  1d641b:	sub    $0xffffffffffffff80,%rdi
  1d641f:	mov    %rsp,%rsi
  1d6422:	call   *0x5c0c8(%rip)        # 2324f0 <_DYNAMIC+0x648>
  1d6428:	jmp    1d6356 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  1d642d:	lea    0x5939c(%rip),%rdi        # 22f7d0 <__frame_dummy_init_array_entry+0x3e20>
  1d6434:	call   *0x5bcbe(%rip)        # 2320f8 <_DYNAMIC+0x250>
  1d643a:	ud2
  1d643c:	mov    0x8(%rbx),%rdi
  1d6440:	sub    $0xffffffffffffff80,%rdi
  1d6444:	mov    %rsp,%rsi
  1d6447:	call   *0x5c0a3(%rip)        # 2324f0 <_DYNAMIC+0x648>
  1d644d:	jmp    1d63d7 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0xf7>
  1d644f:	mov    %rax,%r14
  1d6452:	mov    %rbx,%rdi
  1d6455:	call   1d75f0 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
  1d645a:	mov    0x820(%rbx),%rax
  1d6461:	lea    -0x1(%rax),%rcx
  1d6465:	xor    $0x1,%rax
  1d6469:	mov    %rcx,0x820(%rbx)
  1d6470:	or     0x818(%rbx),%rax
  1d6477:	jne    1d649b <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1bb>
  1d6479:	mov    %rbx,%rdi
  1d647c:	call   *0x5c066(%rip)        # 2324e8 <_DYNAMIC+0x640>
  1d6482:	jmp    1d649b <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1bb>
  1d6484:	call   *0x5bc76(%rip)        # 232100 <_DYNAMIC+0x258>
  1d648a:	call   *0x5bc70(%rip)        # 232100 <_DYNAMIC+0x258>
  1d6490:	mov    %rax,%r14
  1d6493:	mov    %rbx,%rdi
  1d6496:	call   1d75f0 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
  1d649b:	mov    %r14,%rdi
  1d649e:	call   22a930 <_Unwind_Resume@plt>
  1d64a3:	call   *0x5bc57(%rip)        # 232100 <_DYNAMIC+0x258>
