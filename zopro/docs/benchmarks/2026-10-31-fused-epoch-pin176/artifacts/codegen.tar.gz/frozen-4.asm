
/home/ubuntu/src/zopro-perf-work/coalesce-query176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000098f00 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}>:
   98f00:	sub    $0x28,%rsp
   98f04:	mov    %rdi,(%rsp)
   98f08:	mov    0x1995a9(%rip),%rax        # 2324b8 <_DYNAMIC+0x610>
   98f0f:	call   *%rax
   98f11:	mov    %rax,%rdi
   98f14:	mov    0x1995a5(%rip),%rax        # 2324c0 <_DYNAMIC+0x618>
   98f1b:	call   *%rax
   98f1d:	mov    (%rsp),%rdi
   98f21:	mov    %rax,0x10(%rsp)
   98f26:	lea    0x10(%rsp),%rsi
   98f2b:	call   990f0 <crossbeam_epoch::default::pin::{closure#0}>
   98f30:	mov    %rax,0x8(%rsp)
   98f35:	jmp    98f53 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}+0x53>
   98f37:	lea    0x10(%rsp),%rdi
   98f3c:	call   98320 <core::ptr::drop_glue::<crossbeam_epoch::collector::LocalHandle>>
   98f41:	jmp    98f6d <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}+0x6d>
   98f43:	mov    %rax,%rcx
   98f46:	mov    %edx,%eax
   98f48:	mov    %rcx,0x18(%rsp)
   98f4d:	mov    %eax,0x20(%rsp)
   98f51:	jmp    98f37 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>::{closure#1}+0x37>
   98f53:	lea    0x10(%rsp),%rdi
   98f58:	call   98320 <core::ptr::drop_glue::<crossbeam_epoch::collector::LocalHandle>>
   98f5d:	mov    0x8(%rsp),%rax
   98f62:	add    $0x28,%rsp
   98f66:	ret
   98f67:	call   *0x199193(%rip)        # 232100 <_DYNAMIC+0x258>
   98f6d:	mov    0x18(%rsp),%rdi
   98f72:	call   22a930 <_Unwind_Resume@plt>
