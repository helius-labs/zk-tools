
/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000001d61a0 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>>:
  1d61a0:	push   %r14
  1d61a2:	push   %rbx
  1d61a3:	push   %rax
  1d61a4:	mov    %fs:0x0,%rax
  1d61ad:	lea    -0x30(%rax),%rax
  1d61b4:	cmpb   $0x1,0x8(%rax)
  1d61b8:	jne    1d6221 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x81>
  1d61ba:	mov    (%rax),%rbx
  1d61bd:	mov    %rbx,(%rsp)
  1d61c1:	mov    0x818(%rbx),%rax
  1d61c8:	cmp    $0xffffffffffffffff,%rax
  1d61cc:	je     1d62c8 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x128>
  1d61d2:	lea    0x1(%rax),%rcx
  1d61d6:	mov    %rcx,0x818(%rbx)
  1d61dd:	test   %rax,%rax
  1d61e0:	jne    1d6216 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  1d61e2:	mov    0x8(%rbx),%rax
  1d61e6:	mov    0x180(%rax),%rcx
  1d61ed:	xor    %eax,%eax
  1d61ef:	or     $0x1,%rcx
  1d61f3:	lock cmpxchg %rcx,0x880(%rbx)
  1d61fc:	mov    0x828(%rbx),%rax
  1d6203:	lea    0x1(%rax),%rcx
  1d6207:	mov    %rcx,0x828(%rbx)
  1d620e:	test   $0x7f,%al
  1d6210:	je     1d62d7 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x137>
  1d6216:	mov    %rbx,%rax
  1d6219:	add    $0x8,%rsp
  1d621d:	pop    %rbx
  1d621e:	pop    %r14
  1d6220:	ret
  1d6221:	mov    %rax,%rdi
  1d6224:	xor    %esi,%esi
  1d6226:	call   1d45d0 <<std::sys::thread_local::native::lazy::Storage<crossbeam_epoch::collector::LocalHandle, ()>>::get_or_init_slow::<crossbeam_epoch::default::HANDLE::__rust_std_internal_init_fn>>
  1d622b:	test   %rax,%rax
  1d622e:	jne    1d61ba <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1a>
  1d6230:	call   *0x5c142(%rip)        # 232378 <_DYNAMIC+0x610>
  1d6236:	mov    %rax,%rdi
  1d6239:	call   *0x5c141(%rip)        # 232380 <_DYNAMIC+0x618>
  1d623f:	mov    %rax,(%rsp)
  1d6243:	mov    %rax,%rbx
  1d6246:	mov    0x818(%rax),%rax
  1d624d:	cmp    $0xffffffffffffffff,%rax
  1d6251:	je     1d62ed <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x14d>
  1d6257:	lea    0x1(%rax),%rcx
  1d625b:	mov    %rcx,0x818(%rbx)
  1d6262:	test   %rax,%rax
  1d6265:	jne    1d6297 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0xf7>
  1d6267:	mov    0x8(%rbx),%rax
  1d626b:	mov    0x180(%rax),%rcx
  1d6272:	xor    %eax,%eax
  1d6274:	or     $0x1,%rcx
  1d6278:	lock cmpxchg %rcx,0x880(%rbx)
  1d6281:	mov    0x828(%rbx),%rax
  1d6288:	lea    0x1(%rax),%rcx
  1d628c:	mov    %rcx,0x828(%rbx)
  1d6293:	test   $0x7f,%al
  1d6295:	je     1d62fc <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x15c>
  1d6297:	mov    0x820(%rbx),%rax
  1d629e:	lea    -0x1(%rax),%rcx
  1d62a2:	xor    $0x1,%rax
  1d62a6:	mov    %rcx,0x820(%rbx)
  1d62ad:	or     0x818(%rbx),%rax
  1d62b4:	jne    1d6216 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  1d62ba:	mov    %rbx,%rdi
  1d62bd:	call   *0x5c0e5(%rip)        # 2323a8 <_DYNAMIC+0x640>
  1d62c3:	jmp    1d6216 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  1d62c8:	lea    0x593c1(%rip),%rdi        # 22f690 <__frame_dummy_init_array_entry+0x3e20>
  1d62cf:	call   *0x5bce3(%rip)        # 231fb8 <_DYNAMIC+0x250>
  1d62d5:	jmp    1d62fa <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x15a>
  1d62d7:	mov    0x8(%rbx),%rdi
  1d62db:	sub    $0xffffffffffffff80,%rdi
  1d62df:	mov    %rsp,%rsi
  1d62e2:	call   *0x5c0c8(%rip)        # 2323b0 <_DYNAMIC+0x648>
  1d62e8:	jmp    1d6216 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x76>
  1d62ed:	lea    0x5939c(%rip),%rdi        # 22f690 <__frame_dummy_init_array_entry+0x3e20>
  1d62f4:	call   *0x5bcbe(%rip)        # 231fb8 <_DYNAMIC+0x250>
  1d62fa:	ud2
  1d62fc:	mov    0x8(%rbx),%rdi
  1d6300:	sub    $0xffffffffffffff80,%rdi
  1d6304:	mov    %rsp,%rsi
  1d6307:	call   *0x5c0a3(%rip)        # 2323b0 <_DYNAMIC+0x648>
  1d630d:	jmp    1d6297 <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0xf7>
  1d630f:	mov    %rax,%r14
  1d6312:	mov    %rbx,%rdi
  1d6315:	call   1d6f10 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
  1d631a:	mov    0x820(%rbx),%rax
  1d6321:	lea    -0x1(%rax),%rcx
  1d6325:	xor    $0x1,%rax
  1d6329:	mov    %rcx,0x820(%rbx)
  1d6330:	or     0x818(%rbx),%rax
  1d6337:	jne    1d635b <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1bb>
  1d6339:	mov    %rbx,%rdi
  1d633c:	call   *0x5c066(%rip)        # 2323a8 <_DYNAMIC+0x640>
  1d6342:	jmp    1d635b <crossbeam_epoch::default::with_handle::<crossbeam_epoch::default::pin::{closure#0}, crossbeam_epoch::guard::Guard>+0x1bb>
  1d6344:	call   *0x5bc76(%rip)        # 231fc0 <_DYNAMIC+0x258>
  1d634a:	call   *0x5bc70(%rip)        # 231fc0 <_DYNAMIC+0x258>
  1d6350:	mov    %rax,%r14
  1d6353:	mov    %rbx,%rdi
  1d6356:	call   1d6f10 <core::ptr::drop_glue::<crossbeam_epoch::guard::Guard>>
  1d635b:	mov    %r14,%rdi
  1d635e:	call   22a7f0 <_Unwind_Resume@plt>
  1d6363:	call   *0x5bc57(%rip)        # 231fc0 <_DYNAMIC+0x258>
