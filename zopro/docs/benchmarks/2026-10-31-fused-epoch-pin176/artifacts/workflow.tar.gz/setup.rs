use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";const C:&str="/home/ubuntu/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f";
fn r(s:impl AsRef<Path>)->PathBuf{Path::new(R).join(s)}fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn copytree(a:&Path,b:&Path){fs::create_dir_all(b).unwrap();for e in fs::read_dir(a).unwrap(){let e=e.unwrap();let from=e.path();let to=b.join(e.file_name());if from.is_dir(){copytree(&from,&to)}else{fs::copy(from,to).unwrap();}}}
fn walk(p:&Path,m:&mut BTreeMap<String,String>){for e in fs::read_dir(p).unwrap(){let p=e.unwrap().path();if p.is_dir(){walk(&p,m)}else{m.insert(p.display().to_string(),hash(p));}}}
fn replace(p:&Path,a:&str,b:&str){let s=fs::read_to_string(p).unwrap();assert_eq!(s.matches(a).count(),1,"{} missing {a}",p.display());fs::write(p,s.replace(a,b)).unwrap()}
fn main(){assert!(!r("source").exists());let manifest=read(Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));for(p,h)in manifest["source_files_sha256"].as_object().unwrap(){let from=Path::new(Z).join(p);assert_eq!(hash(&from),h.as_str().unwrap());let to=r("source").join(p);fs::create_dir_all(to.parent().unwrap()).unwrap();fs::copy(from,to).unwrap();}
 for(name,version)in[("crossbeam-epoch","0.9.21"),("crossbeam-deque","0.8.8")]{copytree(&Path::new(C).join(format!("{name}-{version}")),&r("source/vendor").join(name));}
 let patch="\n[patch.crates-io]\ncrossbeam-epoch = { path = \"vendor/crossbeam-epoch\" }\ncrossbeam-deque = { path = \"vendor/crossbeam-deque\" }\n";
 let root=r("source/Cargo.toml");let mut s=fs::read_to_string(&root).unwrap();s.push_str(patch);fs::write(root,s).unwrap();
 let root=r("source/Cargo.lock");let original=fs::read_to_string(&root).unwrap();let mut lock=String::new();let mut changed=0;
 for section in original.split_inclusive("[[package]]\n"){lock.push_str(section)}
 // Preserve every package and edge; only patched source/checksum fields disappear.
 let mut sections=original.split("[[package]]\n").map(str::to_string).collect::<Vec<_>>();for section in &mut sections{if section.starts_with("name = \"crossbeam-epoch\"\n")||section.starts_with("name = \"crossbeam-deque\"\n"){*section=section.lines().filter(|l|!l.starts_with("source = ")&&!l.starts_with("checksum = ")).map(|l|format!("{l}\n")).collect();changed+=1;}}
 assert_eq!(changed,2);lock=sections.join("[[package]]\n");fs::write(root,lock).unwrap();
 let file=r("source/vendor/crossbeam-epoch/src/default.rs");let mut s=fs::read_to_string(&file).unwrap();s.push_str(r#"
/// Pins after the same full fence used by a nested single-job steal.
#[cfg(zopro_fused_epoch_pin)]
#[inline]
pub fn pin_fenced() -> Guard {
    with_handle(|handle| {
        if handle.is_pinned() {
            crate::sync::atomic::fence(crate::sync::atomic::Ordering::SeqCst);
        }
        handle.pin()
    })
}

#[cfg(all(test,zopro_fused_epoch_pin))]
mod fenced_tests {
    use super::*;
    #[test]
    fn nested_and_unwound_pin_lifetimes() {
        std::thread::spawn(|| {
            assert!(!is_pinned());
            let first=pin_fenced();assert!(is_pinned());
            let second=pin_fenced();assert!(is_pinned());
            drop(first);assert!(is_pinned());drop(second);assert!(!is_pinned());
            let _=std::panic::catch_unwind(|| {let _guard=pin_fenced();assert!(is_pinned());panic!("intentional");});
            assert!(!is_pinned());
        }).join().unwrap();
    }
    #[test]
    fn fenced_pin_after_tls_handle_destruction() {
        static DROPS:std::sync::atomic::AtomicUsize=std::sync::atomic::AtomicUsize::new(0);
        struct OnDrop;
        impl Drop for OnDrop {fn drop(&mut self){let guard=pin_fenced();guard.flush();DROPS.fetch_add(1,std::sync::atomic::Ordering::SeqCst);}}
        std::thread_local! {static DROPPER:OnDrop=const{OnDrop};}
        std::thread::spawn(||{DROPPER.with(|_|());drop(pin_fenced());}).join().unwrap();
        assert_eq!(DROPS.load(std::sync::atomic::Ordering::SeqCst),1);
    }
}
"#);fs::write(file,s).unwrap();
 let file=r("source/vendor/crossbeam-epoch/src/lib.rs");let mut s=fs::read_to_string(&file).unwrap();s.push_str("\n#[cfg(all(feature=\"std\",zopro_fused_epoch_pin))]\npub use crate::default::pin_fenced;\n");fs::write(file,s).unwrap();
 let file=r("source/vendor/crossbeam-deque/src/deque.rs");let mut s=fs::read_to_string(&file).unwrap();let start=s.find("    pub fn steal(&self) -> Steal<T> {").unwrap();let a=start+s[start..].find("        if epoch::is_pinned() {").unwrap();let stop=a+s[a..].find("        let guard = &epoch::pin();").unwrap()+"        let guard = &epoch::pin();".len();let original=&s[a..stop];let extra=format!("        #[cfg(not(zopro_fused_epoch_pin))]\n        let guard = &{{\n{original}\n            // The original branch returns its original owned guard.\n            // Remove only the local reference binding in this compile-time branch.\n        }};");let _=extra;
 let off=original.replace("        let guard = &epoch::pin();","        epoch::pin()");let replacement=format!("        #[cfg(not(zopro_fused_epoch_pin))]\n        let guard = &{{\n{off}\n        }};\n        #[cfg(zopro_fused_epoch_pin)]\n        let guard = &epoch::pin_fenced();");s.replace_range(a..stop,&replacement);fs::write(file,s).unwrap();
 let file=r("source/crates/zopro-core/src/lib.rs");let mut s=fs::read_to_string(&file).unwrap();s.push_str("\n// BEGIN PRIVATE FUSED PIN QUERY PROBE\n");s.push_str(&fs::read_to_string("/home/ubuntu/src/zopro-perf-work/coalesce-query176/probe-export.rs").unwrap());fs::write(file,s).unwrap();
 let old=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/coalesce-query176/native.rs").unwrap().replace("/home/ubuntu/src/zopro-perf-work/coalesce-query176",R);fs::write(r("native.rs"),old).unwrap();
 let flags=manifest["rustflags"].as_str().unwrap().to_owned()+" --cfg zopro_coalesce_probe";fs::write(r("native-flags.txt"),&flags).unwrap();fs::write(r("candidate-flags.txt"),flags+" --cfg zopro_fused_epoch_pin").unwrap();
 for file in["driver.rs","perf_support.rs"]{fs::copy(Path::new("/home/ubuntu/src/zopro-perf-work/coalesce-query176").join(file),r(file)).unwrap();}
 let mut source=BTreeMap::new();walk(&r("source"),&mut source);fs::write(r("source-pins.json"),serde_json::to_vec_pretty(&source).unwrap()).unwrap();fs::write(r("source-audit.json"),serde_json::to_vec_pretty(&json!({"original176_pinned":true,"changed_originals":["Cargo.toml","Cargo.lock","crates/zopro-core/src/lib.rs"],"crypto_bodies_unchanged":true,"field_files_unchanged":true,"new_dependencies":false,"two_private_dependency_paths":true,"only_Stealer_steal_selected":true,"off_control_preserves_original_fence_and_pin_operations":true,"new_epoch_tests":2,"selected_from_actual_linked_duplicate_TLS":true})).unwrap()).unwrap();println!("Prepared private176-body snapshot and2exact-version dependency copies;2focused epoch tests; no production edits");
}
