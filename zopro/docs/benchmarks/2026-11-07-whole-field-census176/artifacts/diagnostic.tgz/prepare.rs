use serde_json::{json, Value};
use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/whole-field-census176";
const REPO:&str="/home/ubuntu/src/zk-tools/zopro";
const MANIFEST:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json";
fn load(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){assert!(!p.as_ref().exists());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 let manifest=load(MANIFEST);let files=manifest["source_files_sha256"].as_object().unwrap();assert_eq!(files.len(),176);
 let root=format!("{R}/source");assert!(!Path::new(&root).exists());
 for (name,expected)in files{let orig=format!("{REPO}/{name}");assert_eq!(hash(&orig),expected.as_str().unwrap());let dest=format!("{root}/{name}");fs::create_dir_all(Path::new(&dest).parent().unwrap()).unwrap();fs::copy(orig,dest).unwrap();}
 let mut edits=Vec::<Value>::new();
 let mut insert=|name:&str,needle:&str,hook:String|{
   let path=format!("{root}/crates/zopro-bn254/src/{name}");let s=fs::read_to_string(&path).unwrap();assert_eq!(s.matches(needle).count(),1,"{name}: {needle}");
   let replacement=format!("{needle}\n        #[cfg(zopro_field_census)]\n        {hook}");fs::write(path,s.replacen(needle,&replacement,1)).unwrap();edits.push(json!({"path":format!("crates/zopro-bn254/src/{name}"),"needle":needle,"replacement":replacement}));
 };
 let hook=|engine:usize,event:&str,mixed:&str|format!("crate::field_census::event(C::P,{engine},{mixed},{event});");
 for (needle,id)in [
  ("pub fn to_canonical(&self) -> [u64; 4] {",18),("pub fn square(&self) -> Self {",1),
  ("pub fn double(&self) -> Self {",9),("pub fn sum_of_products(a: &Self, b: &Self, c: &Self, d: &Self) -> Self {",2),
  ("pub fn inverse(&self) -> Option<Self> {",17),("fn add(self, other: Self) -> Self {",6),
  ("fn sub(self, other: Self) -> Self {",7),("fn mul(self, other: Self) -> Self {",0),("fn neg(self) -> Self {",8)
 ]{insert("fp.rs",needle,hook(0,&id.to_string(),"false"));}
 for (needle,id)in [
 ("pub fn add(a: [u64; 4], b: [u64; 4], p: [u64; 4]) -> [u64; 4] {",6),
 ("pub fn sub(a: [u64; 4], b: [u64; 4], p: [u64; 4]) -> [u64; 4] {",7),
 ("pub fn neg(a: [u64; 4], p: [u64; 4]) -> [u64; 4] {",8),
 ("pub fn multiply(a: [u64; 4], b: [u64; 4], p: [u64; 4], inv: u64) -> [u64; 4] {",0),
 ("pub fn sum2(a: [u64; 4], b: [u64; 4], c: [u64; 4], d: [u64; 4], p: [u64; 4], inv: u64) -> [u64; 4] {",2)
 ]{insert("x86_64.rs",needle,format!("crate::field_census::event(p,1,false,{id});"));}
 for (name,engine,width)in [("ifma.rs",2,4),("ifma8.rs",3,8)]{
  let raw=format!("fn raw(x: &[[u64; 4]; {width}]) -> Self {{");
  let new=format!("pub fn new(x: &[Fp<C>; {width}]) -> Self {{");
  let get=format!("pub fn get(&self) -> [Fp<C>; {width}] {{");
  for (needle,id)in [
   (raw.as_str(),14),(new.as_str(),10),(get.as_str(),11),
   ("pub fn zero() -> Self {",16),("pub fn one() -> Self {",15),
   ("pub fn mul(&self, b: &Self) -> Self {",0),("pub fn sum2(&self, b: &Self, c: &Self, d: &Self) -> Self {",2),
   ("pub fn difference2(&self, b: &Self, c: &Self, d: &Self) -> Self {",3),
   ("pub fn add(&self, b: &Self) -> Self {",6),("pub fn sub(&self, b: &Self) -> Self {",7),
   ("pub fn add_canonical(&self, b: &Self) -> Self {",28),("pub fn sub_canonical(&self, b: &Self) -> Self {",29),
   (if width==8{"pub fn signed_difference_scaled(&self, ay: &Self, scale: &Self, negative: u8) -> Self {"}else{"pub fn signed_difference_scaled(&self, ay:&Self, scale:&Self, negative:u8)->Self {"},4),
   (if width==8{"pub fn mul_u28(&self, factors: &[u64; LANES]) -> Self {"}else{"pub fn mul_u28(&self, factors:&[u64;LANES])->Self {"},5),
  ]{insert(name,needle,hook(engine,&id.to_string(),"MIXED"));}
  let pack=if width==8{"PackedIfma8"}else{"PackedIfma"};let unpack=if width==8{"Ifma8"}else{"Ifma"};
  insert(name,&format!("pub fn compact(&self) -> {pack}<C, MIXED> {{"),hook(engine,"12","MIXED"));
  insert(name,&format!("pub fn expand(&self) -> {unpack}<C, MIXED> {{"),hook(engine,"13","MIXED"));
  insert(name,"fn product<const FUSED: bool>(&self, b: &Self, c: &Self, d: &Self) -> Self {",hook(engine,"if FUSED {23} else {22}","MIXED"));
 }
 insert("ifma8.rs","pub fn from_halves(lo: &crate::ifma::Ifma<C, MIXED>, hi: &crate::ifma::Ifma<C, MIXED>) -> Self {",hook(3,"19","MIXED"));
 insert("ifma8.rs","pub fn halves(&self) -> (crate::ifma::Ifma<C, MIXED>, crate::ifma::Ifma<C, MIXED>) {",hook(3,"20","MIXED"));
 insert("ifma8.rs","pub fn horizontal_sum(&self) -> Fp<C> {",hook(3,"21","MIXED"));
 insert("inverse.rs","pub(crate) fn inverse<C: FpConfig>(x: &Fp<C>) -> Option<Fp<C>> {",hook(4,"17","false"));
 insert("inverse.rs","rounds += 1;",hook(4,"26","false"));
 insert("inverse.rs","let q = r0 / r1;",hook(4,"27","false"));
 insert("inverse.rs",") -> [u64; 4] {\n    let mut t = linear(a, f, b, g);",hook(4,"if SHIFT == 31 {24} else {25}","false"));
 // Module declaration is a separate reversible edit.
 let path=format!("{root}/crates/zopro-bn254/src/lib.rs");let old=fs::read_to_string(&path).unwrap();let decl="\n#[cfg(zopro_field_census)]\npub mod field_census;\n";fs::write(&path,format!("{old}{decl}")).unwrap();
 edits.push(json!({"path":"crates/zopro-bn254/src/lib.rs","needle":"","replacement":decl,"append":true}));
 fs::copy(format!("{R}/field_census.rs"),format!("{root}/crates/zopro-bn254/src/field_census.rs")).unwrap();
 save(format!("{R}/observer-edits.json"),&json!(edits));
 let mut pins=BTreeMap::new();for name in files.keys(){let p=format!("{root}/{name}");pins.insert(p.clone(),hash(p));}
 for name in ["field_census.rs","prepare.rs","driver.rs","design.md","observer-edits.json"]{let p=format!("{R}/{name}");pins.insert(p.clone(),hash(p));}
 let child=format!("{root}/crates/zopro-bn254/src/field_census.rs");pins.insert(child.clone(),hash(child));pins.insert(MANIFEST.into(),hash(MANIFEST));
 save(format!("{R}/source-pins.json"),&json!(pins));
 let flags=format!("{} --cfg zopro_field_census",manifest["rustflags"].as_str().unwrap());
 let env=json!({"RUSTC":"/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc","PATH":"/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin","CARGO_TARGET_DIR":format!("{R}/target"),"CARGO_BUILD_JOBS":"16","RUSTFLAGS":flags});
 let cargo="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/cargo";
 let plan=json!({"version":1,"source_pins":format!("{R}/source-pins.json"),"steps":[
  {"kind":"command","name":"new-counter-test","argv":[cargo,"test","--manifest-path",format!("{root}/Cargo.toml"),"--locked","--offline","--release","-p","zopro-bn254","--lib","field_census::tests::field_census_hooks_and_isolation","--","--exact","--test-threads=1"],"environment":env,"timeout_seconds":900},
  {"kind":"command","name":"libraries","argv":[cargo,"build","--manifest-path",format!("{root}/Cargo.toml"),"--locked","--offline","--release","-p","zopro-bench","--lib","--message-format=json"],"environment":env,"timeout_seconds":900},
  {"kind":"link-sdk","name":"census","artifacts":format!("{R}/native/libraries/stdout.log"),"driver":format!("{R}/driver.rs"),"timeout_seconds":900}
 ]});save(format!("{R}/native-plan.json"),&plan);
 println!("Prepared177sourcefiles;{}hookedparentedits;no arithmetic/source adoption",edits.len());
}
