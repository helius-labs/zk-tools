use serde_json::{json, Value};
use sha2::{Digest,Sha256};
use std::{collections::{BTreeMap,BTreeSet},fs,io::Read,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/whole-field-census176";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/byte-permute-pack176/pilot";
const LEDGER:&str="/home/ubuntu/src/zopro-perf-work/byte-permute-pack176/pilot/primary-pilot/proof-sha256-after-diagnostic.json";
const VERIFY:&str="/home/ubuntu/src/zopro-perf-work/batch-local-steal/gnark/verify";
fn load(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){assert!(!p.as_ref().exists(),"{} exists",p.as_ref().display());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn hash(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn step(name:&str,argv:Value,env:Value)->Value{json!({"kind":"command","name":name,"argv":argv,"environment":env,"timeout_seconds":900})}
fn receipt(root:&str,name:&str)->Value{
 let dir=format!("{root}/{name}");let exit=load(format!("{dir}/exit.json"));assert_eq!(exit["success"],true);assert_eq!(exit["returncode"],0);
 for stream in ["stdout","stderr"]{assert_eq!(hash(format!("{dir}/{stream}.log")),exit[format!("{stream}_sha256")].as_str().unwrap());}
 load(format!("{dir}/command.json"))
}
fn prepare(){
 let completed=load(format!("{R}/native/completed.json"));assert_eq!(completed.as_array().unwrap().len(),3);
 let test=fs::read_to_string(format!("{R}/native/new-counter-test/stdout.log")).unwrap();assert!(test.contains("1 passed; 0 failed"));assert!(test.contains("field_census::tests::field_census_hooks_and_isolation ... ok"));
 for name in ["new-counter-test","libraries","census"]{receipt(&format!("{R}/native"),name);}
 let command=load(format!("{R}/native/census/command.json"));let argv=command["argv"].as_array().unwrap().iter().map(|v|v.as_str().unwrap()).collect::<Vec<_>>();
 for required in ["-O","target-cpu=native","lto=fat","codegen-units=1"]{assert!(argv.contains(&required));}
 let link=load(format!("{R}/native/census/artifacts.json"));assert_eq!(link["libraries"].as_object().unwrap().len(),8);
 let binary=link["binary"].as_str().unwrap();assert_eq!(hash(binary),link["binary_sha256"].as_str().unwrap());
 for p in link["libraries"].as_object().unwrap().values(){assert!(p.as_str().unwrap().starts_with(&format!("{R}/target/release/deps/")));}
 let oldplan=load(format!("{OLD}/preflight-plan.json"));let oldjobs=load(format!("{OLD}/preflight-jobs.json"));
 let mut commands=vec![];let mut verifiers=vec![];let mut jobs=vec![];
 for job in oldjobs.as_array().unwrap().iter().filter(|j|j["arm"]=="accepted"){
  let shape=job["shape"].as_str().unwrap();let workers=if shape=="1x2"{vec![32,1]}else{vec![32]};
  for w in workers{let name=format!("count-{shape}-w{w}");let out=format!("{R}/proofs/{name}");let cpus=if w==1{"2"}else{"0-31"};
   let oldstep=oldplan["steps"].as_array().unwrap().iter().find(|s|s["name"]==job["name"]).unwrap();let mut env=oldstep["environment"].clone();env["RAYON_NUM_THREADS"]=w.to_string().into();
   commands.push(step(&name,json!(["taskset","-c",cpus,binary,job["image"],job["request"],out]),env));
   verifiers.push(step(&format!("verify-{name}"),json!([VERIFY,job["image"],job["image_sha256"],format!("{out}/0.proof"),format!("{out}/0.public"),job["public_sha256"]]),json!({})));
   let mut j=job.clone();j["name"]=name.into();j["workers"]=w.into();j["proof"]=format!("{out}/0.proof").into();j["public"]=format!("{out}/0.public").into();j["arm"]="diagnostic".into();jobs.push(j);
  }
 }
 assert_eq!(jobs.len(),10);commands.extend(verifiers);
 let mut pins:BTreeMap<String,String>=serde_json::from_value(load(format!("{R}/source-pins.json"))).unwrap();
 for(p,h)in link["input_pins"].as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pins.insert(p.clone(),h.as_str().unwrap().into());}
 pins.insert(binary.into(),hash(binary));for p in [LEDGER,VERIFY]{pins.insert(p.into(),hash(p));}
 for name in ["campaign.rs","campaign","native-plan.json"]{let p=format!("{R}/{name}");pins.insert(p.clone(),hash(p));}
 for j in &jobs{for k in ["image","request"]{let p=j[k].as_str().unwrap();pins.entry(p.into()).or_insert_with(||hash(p));}}
 let protocol=json!({"SDK_calls":50,"captured_requests":20,"fresh_exports":10,"canonical_before":LEDGER,"canonical_before_count":31903,"rounds":2,"primes":3,"binary":binary,"binary_sha256":hash(binary),"link_argv_checked_before_capture":argv,"all_nine_workers":32,"primary_control_workers":1,"instrumented_only":true,"no_latency_or_RSS_claim":true,"jobs":jobs});
 save(format!("{R}/protocol.json"),&protocol);save(format!("{R}/jobs.json"),&json!(jobs));pins.insert(format!("{R}/protocol.json"),hash(format!("{R}/protocol.json")));pins.insert(format!("{R}/jobs.json"),hash(format!("{R}/jobs.json")));
 save(format!("{R}/capture-pins.json"),&json!(pins));save(format!("{R}/capture-plan.json"),&json!({"version":1,"source_pins":format!("{R}/capture-pins.json"),"steps":commands}));
 println!("READY10processes/50SDKcalls/20observedrequests/10freshGnarkexports;actualnativefatLTO/CGU1linkchecked");
}
fn analyze(){
 assert_eq!(load(format!("{R}/capture/completed.json")).as_array().unwrap().len(),20);
 let jobs=load(format!("{R}/jobs.json"));let mut ledger:BTreeSet<String>=serde_json::from_value(load(LEDGER)).unwrap();assert_eq!(ledger.len(),31903);
 let mut rows=vec![];let mut proofhashes=vec![];
 for j in jobs.as_array().unwrap(){let name=j["name"].as_str().unwrap();let w=j["workers"].as_u64().unwrap() as usize;
  receipt(&format!("{R}/capture"),name);receipt(&format!("{R}/capture"),&format!("verify-{name}"));
  let proof=j["proof"].as_str().unwrap();assert_eq!(fs::metadata(proof).unwrap().len(),164);let ph=hash(proof);assert!(ledger.insert(ph.clone()));assert_eq!(hash(j["public"].as_str().unwrap()),j["public_sha256"].as_str().unwrap());
  proofhashes.push(json!({"name":name,"proof_sha256":ph,"public_sha256":j["public_sha256"]}));
  let text=fs::read_to_string(format!("{R}/capture/{name}/stdout.log")).unwrap();let counts=text.lines().filter_map(|s|s.strip_prefix("COUNTS ")).map(|s|serde_json::from_str::<Value>(s).unwrap()).collect::<Vec<_>>();assert_eq!(counts.len(),2);
  let summaries=text.lines().filter_map(|s|s.strip_prefix("SUMMARY ")).collect::<Vec<_>>();assert_eq!(summaries.len(),1);let summary:Value=serde_json::from_str(summaries[0]).unwrap();assert_eq!(summary["workers"],w);assert_eq!(summary["rounds"],2);assert_eq!(summary["priming"],3);assert_eq!(summary["slots"],960);
  for (rep,c)in counts.iter().enumerate(){assert_eq!(c["rep"],rep);let threads=c["threads"].as_array().unwrap();assert_eq!(threads.len(),w+1);let mut total=vec![0u64;960];
   for t in threads{let a=t.as_array().unwrap();assert_eq!(a.len(),960);for(i,v)in a.iter().enumerate(){total[i]=total[i].checked_add(v.as_u64().unwrap()).unwrap();}}
   let idx=|f:usize,e:usize,m:usize,id:usize|(((f*5+e)*2+m)*32)+id;
   for f in 0..3{for e in 0..5{for m in 0..2{for id in 0..32{if f==2||id>=30{assert_eq!(total[idx(f,e,m,id)],0);}}}}}
   for f in 0..2{let a=|id|total[idx(f,0,0,id)];let b=|id|total[idx(f,1,0,id)];assert_eq!(b(0),a(0)+a(1)+a(18));assert_eq!(b(6),a(6)+a(9));assert_eq!(b(7),a(7)+a(8));assert_eq!(b(2),a(2));assert_eq!(b(8),a(8));assert_eq!(total[idx(f,4,0,17)],a(17));
    for e in [2,3]{for m in 0..2{let v=|id|total[idx(f,e,m,id)];assert_eq!(v(22),v(0));assert_eq!(v(23),v(2)+v(3));assert!(v(4)<=v(0));}}
   }
   rows.push(json!({"name":name,"shape":j["shape"],"workers":w,"rep":rep,"totals":total,"source_conservation":"PASS"}));
  }
 }
 assert_eq!(ledger.len(),31913);
 let result=json!({"rows":rows,"fresh_proofs":proofhashes,"SDK_calls":50,"captured_requests":20,"fresh_exports":10,"canonical_before":31903,"canonical_after":31913,"semantic_counts_not_machine_cost":true,"source_conservation":"PASS"});
 save(format!("{R}/analysis.json"),&result);save(format!("{R}/proof-sha256-after.json"),&json!(ledger));println!("PASS20countpopulations/10freshGnarkexports/31913ledger;no performanceclaim");
}
fn main(){match std::env::args().nth(1).as_deref(){Some("prepare")=>prepare(),Some("analyze")=>analyze(),_=>panic!("prepare|analyze")}}
