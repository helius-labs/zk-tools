//! Independent read of raw diagnostic populations and reversible source hooks.
use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{collections::{BTreeMap,BTreeSet},fs,io::Read,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/whole-field-census176";
const REPO:&str="/home/ubuntu/src/zk-tools/zopro";
const M:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn digest(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut buf=[0;131072];loop{let n=f.read(&mut buf).unwrap();if n==0{break;}h.update(&buf[..n]);}format!("{:x}",h.finalize())}
fn digest_bytes(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn x(f:usize,e:usize,m:usize,n:usize)->usize{f*320+e*64+m*32+n}
fn main(){
 assert!(!Path::new(&format!("{R}/review.json")).exists());
 let mut pins=0;for(p,h)in read(format!("{R}/analysis-pins.json")).as_object().unwrap(){assert_eq!(digest(p),h.as_str().unwrap());pins+=1;}
 let mut commands=0;for (dir,plan)in [("native","native-plan.json"),("preparation","preparation-plan.json"),("capture","capture-plan.json"),("analysis","analysis-plan.json")]{
  let p=read(format!("{R}/{plan}"));assert_eq!(read(format!("{R}/{dir}/completed.json")).as_array().unwrap().len(),p["steps"].as_array().unwrap().len());
  for step in p["steps"].as_array().unwrap(){let name=step["name"].as_str().unwrap();let root=format!("{R}/{dir}/{name}");let exit=read(format!("{root}/exit.json"));assert_eq!(exit["success"],true);assert_eq!(exit["returncode"],0);
   for s in ["stdout","stderr"]{assert_eq!(digest(format!("{root}/{s}.log")),exit[format!("{s}_sha256")].as_str().unwrap());}
   if step["kind"]=="command"{let actual=read(format!("{root}/command.json"));let argv=actual["argv"].as_array().unwrap();let expected=step["argv"].as_array().unwrap();assert_eq!(&argv[argv.len()-expected.len()..],expected);}
   commands+=1;
  }
 }
 assert_eq!(commands,25);
 let source=read(M);let edits=read(format!("{R}/observer-edits.json"));let mut changed=BTreeMap::<String,usize>::new();let mut exact=0;
 for (name,expected)in source["source_files_sha256"].as_object().unwrap(){let path=format!("{R}/source/{name}");let mut bytes=fs::read(&path).unwrap();let orig=bytes.clone();
  for edit in edits.as_array().unwrap().iter().rev().filter(|e|e["path"]==name.as_str()){
   let replacement=edit["replacement"].as_str().unwrap();let needle=edit["needle"].as_str().unwrap();let mut text=String::from_utf8(bytes).unwrap();
   if edit["append"]==true{assert!(text.ends_with(replacement));text.truncate(text.len()-replacement.len());}else{assert_eq!(text.matches(replacement).count(),1);text=text.replacen(replacement,needle,1);}
   bytes=text.into_bytes();*changed.entry(name.clone()).or_default()+=1;
  }
  assert_eq!(digest_bytes(&bytes),expected.as_str().unwrap());assert_eq!(digest(format!("{REPO}/{name}")),expected.as_str().unwrap());if bytes==orig{exact+=1;}
 }
 assert_eq!(exact,170);assert_eq!(changed.len(),6);assert_eq!(changed.values().sum::<usize>(),56);
 assert_eq!(digest(format!("{R}/field_census.rs")),digest(format!("{R}/source/crates/zopro-bn254/src/field_census.rs")));
 let artifact=read(format!("{R}/native/census/artifacts.json"));assert_eq!(artifact["libraries"].as_object().unwrap().len(),8);for(p,h)in artifact["input_pins"].as_object().unwrap(){assert_eq!(digest(p),h.as_str().unwrap());}
 assert_eq!(digest(artifact["binary"].as_str().unwrap()),artifact["binary_sha256"].as_str().unwrap());
 let argv=read(format!("{R}/native/census/command.json"));for required in ["-O","target-cpu=native","lto=fat","codegen-units=1"]{assert!(argv["argv"].as_array().unwrap().iter().any(|s|s==required));}
 let protocol=read(format!("{R}/protocol.json"));let mut ledger:BTreeSet<String>=serde_json::from_value(read(protocol["canonical_before"].as_str().unwrap())).unwrap();assert_eq!(ledger.len(),31903);
 let analysis=read(format!("{R}/analysis.json"));let jobs=read(format!("{R}/jobs.json"));assert_eq!(jobs.as_array().unwrap().len(),10);assert_eq!(analysis["rows"].as_array().unwrap().len(),20);
 let mut table=vec![];let mut differences=vec![];
 for job in jobs.as_array().unwrap(){let name=job["name"].as_str().unwrap();let w=job["workers"].as_u64().unwrap() as usize;let text=fs::read_to_string(format!("{R}/capture/{name}/stdout.log")).unwrap();assert!(!text.contains("SAMPLE "));assert!(!text.contains("rss"));
  let observed=text.lines().filter_map(|l|l.strip_prefix("COUNTS ")).map(|l|serde_json::from_str::<Value>(l).unwrap()).collect::<Vec<_>>();assert_eq!(observed.len(),2);
  let mut rep_totals=vec![];
  for (rep,record)in observed.iter().enumerate(){assert_eq!(record["rep"],rep);let threads=record["threads"].as_array().unwrap();assert_eq!(threads.len(),w+1);
   let mut totals=vec![0u64;960];for thread in threads{let raw:Vec<u64>=serde_json::from_value(thread.clone()).unwrap();assert_eq!(raw.len(),960);for (sum,n)in totals.iter_mut().zip(raw){*sum=sum.checked_add(n).unwrap();}}
   let saved=analysis["rows"].as_array().unwrap().iter().find(|r|r["name"]==name&&r["rep"]==rep).unwrap();assert_eq!(serde_json::to_value(&totals).unwrap(),saved["totals"]);assert_eq!(saved["source_conservation"],"PASS");
   for (i,&n)in totals.iter().enumerate(){let field=i/320;let engine=(i%320)/64;let mixed=(i%64)/32;let event=i%32;
    let allowed=match engine{0=>[0,1,2,6,7,8,9,17,18].contains(&event)&&mixed==0,1=>[0,2,6,7,8].contains(&event)&&mixed==0,2|3=>[0,2,3,4,5,6,7,10,11,12,13,14,15,16,19,20,21,22,23,28,29].contains(&event),4=>[17,24,25,26,27].contains(&event)&&mixed==0,_=>false};
    if field==2||!allowed{assert_eq!(n,0,"{name} rep{rep} slot{i}");}
   }
   for field in 0..2{
    for(out,terms)in [(0,vec![0,1,18]),(2,vec![2]),(6,vec![6,9]),(7,vec![7,8]),(8,vec![8])]{assert_eq!(totals[x(field,1,0,out)],terms.iter().map(|&n|totals[x(field,0,0,n)]).sum::<u64>());}
    assert_eq!(totals[x(field,4,0,17)],totals[x(field,0,0,17)]);
    for engine in [2,3]{for mixed in 0..2{assert_eq!(totals[x(field,engine,mixed,22)],totals[x(field,engine,mixed,0)]);assert_eq!(totals[x(field,engine,mixed,23)],totals[x(field,engine,mixed,2)]+totals[x(field,engine,mixed,3)]);assert!(totals[x(field,engine,mixed,4)]<=totals[x(field,engine,mixed,0)]);}}
   }
   let vector=|field:usize,engine:usize|{let lanes=if engine==2{4}else{8};(0..2).map(|m|totals[x(field,engine,m,22)]+2*totals[x(field,engine,m,23)]).sum::<u64>()*lanes};
   let mut row=json!({"name":name,"rep":rep,"workers":w});for(field,label)in [(0,"Fq"),(1,"Fr")]{row[label]=json!({"API_mul":totals[x(field,0,0,0)],"API_square":totals[x(field,0,0,1)],"API_sum2":totals[x(field,0,0,2)],"backend_mul":totals[x(field,1,0,0)],"inverses":totals[x(field,0,0,17)],"SIMD4_elementary_lane_products":vector(field,2),"SIMD8_elementary_lane_products":vector(field,3),"gcd31_rounds":totals[x(field,4,0,26)],"euclid_divisions":totals[x(field,4,0,27)],"SIMD8_new":(0..2).map(|m|totals[x(field,3,m,10)]).sum::<u64>(),"SIMD8_get":(0..2).map(|m|totals[x(field,3,m,11)]).sum::<u64>()});}table.push(row);rep_totals.push(totals);
  }
  let deltas=(0..960).filter(|&i|rep_totals[0][i]!=rep_totals[1][i]).map(|i|json!({"slot":i,"rep0":rep_totals[0][i],"rep1":rep_totals[1][i]})).collect::<Vec<_>>();differences.push(json!({"name":name,"changed_slots_between_reps":deltas}));
  let proof=job["proof"].as_str().unwrap();let public=job["public"].as_str().unwrap();let ph=digest(proof);assert_eq!(fs::metadata(proof).unwrap().len(),164);assert_eq!(fs::metadata(public).unwrap().len(),44);assert!(ledger.insert(ph.clone()));assert_eq!(digest(public),job["public_sha256"].as_str().unwrap());
  let stdout=fs::read_to_string(format!("{R}/capture/verify-{name}/stdout.log")).unwrap();let lines=stdout.lines().filter(|l|l.starts_with("VERIFIED ")).collect::<Vec<_>>();assert_eq!(lines.len(),1);
  let attrs=lines[0].split_whitespace().skip(1).map(|w|w.split_once('=').unwrap()).collect::<BTreeMap<_,_>>();assert_eq!(attrs["proof_sha256"],ph);assert_eq!(attrs["public_sha256"],job["public_sha256"].as_str().unwrap());assert_eq!(attrs["image_sha256"],job["image_sha256"].as_str().unwrap());
  let oldname=format!("preflight-{}-w32-accepted",job["shape"].as_str().unwrap());let oldtext=fs::read_to_string(format!("/home/ubuntu/src/zopro-perf-work/byte-permute-pack176/pilot/preflight-runs/verify-{oldname}/stdout.log")).unwrap();assert!(oldtext.contains(&format!("vk_sha256={}",attrs["vk_sha256"])));
 }
 assert_eq!(ledger.len(),31913);assert_eq!(serde_json::to_value(ledger).unwrap(),read(format!("{R}/proof-sha256-after.json")));
 let output=json!({"passed":true,"checked_pins":pins,"checked_command_receipts":commands,"restored_original_source_files":176,"unchanged_original_files":170,"observer_parent_files":changed,"reversible_insertions":56,"captured_requests":20,"fresh_Gnark_exports":10,"SDK_calls_with_primes":50,"canonical_after":31913,"source_equations":"PASS","table":table,"repetition_differences":differences,"not_a_second_cryptographic_verifier_or_machine_instruction_counter":true});
 fs::write(format!("{R}/review.json"),serde_json::to_vec_pretty(&output).unwrap()).unwrap();println!("PASS independent source/receipt/counter/proofbindingreview;20populations/10freshproofs;no speedclaim");
}
