//! Exact evaluated field-call census; no latency/RSS output.
use std::{fs,path::Path,sync::Arc};
use zopro_bn254::field_census as census;
#[global_allocator]static ALLOCATOR:zopro_prover::zopro_core::alloc::Allocator=zopro_prover::zopro_core::alloc::Allocator;
fn reset(){census::enable(false);rayon::broadcast(|_|census::clear_thread());census::clear_thread();census::enable(true);}
fn snapshot()->Vec<Vec<u64>>{census::enable(false);let mut a=rayon::broadcast(|_|census::take_thread().to_vec());a.push(census::take_thread().to_vec());a}
fn main()->Result<(),Box<dyn std::error::Error>>{
 let args:Vec<_>=std::env::args_os().collect();assert_eq!(args.len(),4);
 let f=fs::File::open(&args[1])?;
 // SAFETY: pinned trusted input image remains immutable throughout capture.
 let map=unsafe{memmap2::Mmap::map(&f)?};drop(f);
 let mut sdk=zopro_zolana::Prover::new(zopro_prover::Prover::load_image(Arc::new(map))?)?;
 let request=fs::read_to_string(&args[2])?;
 for _ in 0..3{std::hint::black_box(sdk.prove(&request)?);}
 let mut last=None;
 for rep in 0..2 {reset();let proof=sdk.prove(&request)?;let counts=snapshot();
   assert_eq!(proof.proof.len(),164);assert_eq!(proof.public_inputs.len(),44);
   println!("COUNTS {}",serde_json::json!({"rep":rep,"threads":counts}));last=Some(proof);
 }
 let out=Path::new(&args[3]);fs::create_dir_all(out)?;let p=last.unwrap();
 fs::write(out.join("0.proof"),p.proof)?;fs::write(out.join("0.public"),p.public_inputs)?;
 println!("SUMMARY {}",serde_json::json!({"rounds":2,"priming":3,"workers":rayon::current_num_threads(),"slots":census::SLOTS,"names":census::NAMES}));Ok(())
}
