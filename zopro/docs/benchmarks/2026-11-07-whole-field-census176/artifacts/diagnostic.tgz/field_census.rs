//! Diagnostic-only evaluated field method entries; never a timing backend.
use crate::{FpConfig, FqConfig, FrConfig};
use std::cell::RefCell;
use std::sync::atomic::{AtomicBool, Ordering};

pub const EVENTS: usize = 32;
pub const ENGINES: usize = 5;
pub const SLOTS: usize = 3 * ENGINES * 2 * EVENTS;
pub type Counts = [u64; SLOTS];
pub const NAMES: [&str; EVENTS] = [
    "mul", "square", "sum2", "difference2", "signed_scaled", "small_mul",
    "add", "sub", "neg", "double", "new", "get", "compact", "expand",
    "raw", "one", "zero", "inverse", "to_canonical", "from_halves", "halves",
    "horizontal_sum", "product_unfused", "product_fused", "coefficient31",
    "coefficient62", "gcd31_round", "euclid_division", "add_canonical", "sub_canonical",
    "reserved30", "reserved31",
];
static ENABLED: AtomicBool = AtomicBool::new(false);
thread_local! { static COUNTS: RefCell<Counts> = const { RefCell::new([0; SLOTS]) }; }

#[inline(always)]
pub fn index(field: usize, engine: usize, mixed: bool, event: usize) -> usize {
    (((field * ENGINES + engine) * 2 + mixed as usize) * EVENTS) + event
}
#[inline(always)]
pub(crate) fn event(p: [u64; 4], engine: usize, mixed: bool, event: usize) {
    if ENABLED.load(Ordering::Relaxed) {
        let field = if p == FqConfig::P { 0 } else if p == FrConfig::P { 1 } else { 2 };
        COUNTS.with(|c| c.borrow_mut()[index(field, engine, mixed, event)] += 1);
    }
}
pub fn enable(value: bool) { ENABLED.store(value, Ordering::SeqCst); }
pub fn clear_thread() { COUNTS.with(|c| *c.borrow_mut() = [0; SLOTS]); }
pub fn take_thread() -> Counts { COUNTS.with(|c| std::mem::replace(&mut *c.borrow_mut(), [0; SLOTS])) }

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Fp, ifma::Ifma, ifma8::Ifma8};
    use ark_ff::{BigInteger, PrimeField};

    fn scalar<C: FpConfig, A: PrimeField>() {
        enable(false); clear_thread();
        let a = Fp::<C>::from(7); let b = Fp::<C>::from(11);
        enable(true);
        let product = a * b; let square = a.square();
        let sum = Fp::<C>::sum_of_products(&a, &b, &a, &a);
        let add = a + b; let sub = b - a; let neg = -a; let double = a.double();
        let canonical = product.to_canonical();
        enable(false); let counts = take_thread();
        let field = if C::P == FqConfig::P { 0 } else { 1 };
        for (id, n) in [(0,1),(1,1),(2,1),(6,1),(7,1),(8,1),(9,1),(18,1)] {
            assert_eq!(counts[index(field,0,false,id)], n);
        }
        for (id,n) in [(0,3),(2,1),(6,2),(7,2),(8,1)] {
            assert_eq!(counts[index(field,1,false,id)], n);
        }
        assert_eq!(counts.iter().sum::<u64>(), 17);
        for (v, expected) in [(product,77u64),(square,49),(sum,126),(add,18),(sub,4),(double,14)] {
            assert_eq!(A::from_le_bytes_mod_order(&v.to_le_bytes_for_test()), A::from(expected));
        }
        assert_eq!(neg + a, Fp::ZERO); assert_eq!(canonical, [77,0,0,0]);
        assert!(take_thread().iter().all(|&n|n==0));
    }
    trait CanonicalBytes { fn to_le_bytes_for_test(&self) -> Vec<u8>; }
    impl<C: FpConfig> CanonicalBytes for Fp<C> {
        fn to_le_bytes_for_test(&self)->Vec<u8> { self.to_canonical().iter().flat_map(|v|v.to_le_bytes()).collect() }
    }
    fn vectors<C: FpConfig, A: PrimeField, const MIXED: bool>() {
        enable(false); clear_thread();
        let a = std::array::from_fn::<_,8,_>(|i| Fp::<C>::from(7+i as u64));
        let b = std::array::from_fn::<_,8,_>(|i| Fp::<C>::from(17+i as u64));
        let x = Ifma8::<C,MIXED>::new(&a); let y = Ifma8::<C,MIXED>::new(&b);
        let x4 = Ifma::<C,MIXED>::new((&a[..4]).try_into().unwrap());
        let y4 = Ifma::<C,MIXED>::new((&b[..4]).try_into().unwrap());
        enable(true);
        let z = x.mul(&y).get(); let s = x.sum2(&y,&x,&x).get(); let d = x.difference2(&y,&x,&x).get();
        let z4 = x4.mul(&y4).get(); let s4 = x4.sum2(&y4,&x4,&x4).get(); let d4 = x4.difference2(&y4,&x4,&x4).get();
        enable(false); let counts=take_thread(); let field=if C::P==FqConfig::P{0}else{1};
        for engine in [2,3] {
            for (id,n) in [(0,1),(2,1),(3,1),(11,3),(22,1),(23,2)] { assert_eq!(counts[index(field,engine,MIXED,id)],n); }
        }
        assert_eq!(counts.iter().sum::<u64>(),18);
        for i in 0..8 {
            let aa=A::from(7+i as u64);let bb=A::from(17+i as u64);
            for (v,expected)in [(z[i],aa*bb),(s[i],aa*bb+aa*aa),(d[i],aa*bb-aa*aa)] {
                assert_eq!(A::from_le_bytes_mod_order(&v.to_le_bytes_for_test()),expected);
            }
            if i<4 { for (v,expected)in [(z4[i],aa*bb),(s4[i],aa*bb+aa*aa),(d4[i],aa*bb-aa*aa)] {
                assert_eq!(A::from_le_bytes_mod_order(&v.to_le_bytes_for_test()),expected);
            }}
        }
        let _ = A::from(1).into_bigint().to_bytes_le();
    }
    #[test]
    fn field_census_hooks_and_isolation() {
        scalar::<FqConfig,ark_ref::Fq>(); scalar::<FrConfig,ark_ref::Fr>();
        vectors::<FqConfig,ark_ref::Fq,false>(); vectors::<FqConfig,ark_ref::Fq,true>();
        vectors::<FrConfig,ark_ref::Fr,false>(); vectors::<FrConfig,ark_ref::Fr,true>();
        enable(false);clear_thread();enable(true);
        let t=std::thread::spawn(||{ for _ in 0..19 {event(FqConfig::P,0,false,0);} take_thread() });
        for _ in 0..7 {event(FrConfig::P,0,false,1);}
        assert_eq!(t.join().unwrap().iter().sum::<u64>(),19);
        assert_eq!(take_thread().iter().sum::<u64>(),7);
        enable(false);event(FqConfig::P,0,false,0);assert!(take_thread().iter().all(|&n|n==0));
        enable(true);event(FqConfig::P,0,false,0);clear_thread();enable(false);
        assert!(take_thread().iter().all(|&n|n==0));
    }
}
