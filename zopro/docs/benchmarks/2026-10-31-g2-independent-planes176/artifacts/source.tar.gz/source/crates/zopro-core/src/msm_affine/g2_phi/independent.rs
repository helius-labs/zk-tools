//! Private independent component/range fills, with phi after high-part merge.
use super::*;
use std::sync::atomic::{AtomicUsize, Ordering};
pub(crate) static ENTERED: AtomicUsize = AtomicUsize::new(0);

pub(super) fn try_raw(
    bases: &[G2Affine],
    short: &mut [[u64; 4]],
    allow: bool,
) -> Option<G2Projective> {
    assert_eq!(bases.len(), short.len());
    if !allow || !(MIN_QUERY..MAX_QUERY).contains(&bases.len())
        || !crate::msm::BatchAdd::<G2Config>::default().borrowed_g2_enabled()
    {
        return None;
    }
    let _reservation = crate::preparation::Reservation::analysis(
        super::super::workspace::independent_g2(bases.len(), rayon::current_num_threads()),
    )?;
    ENTERED.fetch_add(1, Ordering::Relaxed);
    short.par_iter_mut().for_each(|s| *s = phi_split(*s));
    Some(decomposed(bases, short))
}

fn decomposed(bases: &[G2Affine], short: &[[u64; 4]]) -> G2Projective {
    let bits = 12;
    let chunk = bases.len().div_ceil(2);
    let sums: Vec<_> = (0..127usize.div_ceil(bits)).into_par_iter().map(|w| {
        let mut planes: Vec<_> = (0..4).into_par_iter().map(|job| {
            let start = ((job % 2) * chunk).min(bases.len());
            let end = (start + chunk).min(bases.len());
            let (points, words) = (&bases[start..end], &short[start..end]);
            if w == 10 {
                hb_top_component(points, words, job < 2, w, bits, 6)
            } else {
                super::super::g2_borrowed::independent_component(points, words, job < 2, w, bits)
            }
        }).collect();
        let mut low1 = planes.pop().unwrap();
        let low0 = planes.pop().unwrap();
        let high1 = planes.pop().unwrap();
        let mut high0 = planes.pop().unwrap();
        merge_buckets(&mut high0, &high1);
        drop(high1);
        for p in &mut high0 {
            if !p.is_identity() { p.x = p.x.mul_by_fp(&BETA); }
        }
        merge_buckets(&mut low1, &low0);
        drop(low0);
        merge_buckets(&mut high0, &low1);
        drop(low1);
        crate::msm::weighted_affine(&high0)
    }).collect();
    let mut out = G2Projective::IDENTITY;
    for sum in sums.iter().rev() {
        for _ in 0..bits { out = out.double(); }
        out += sum;
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use zopro_bn254::Fr;

    #[test]
    fn complete_queries_match_independent_generator_sum() {
        for workers in [1, 4] {
            let pool = rayon::ThreadPoolBuilder::new().num_threads(workers).build().unwrap();
            for n in [1024, 1025, 4097, 8193] {
                let coefficients: Vec<_> = (0..n).map(|i| match i % 7 {
                    0 => Fr::ZERO, 1 | 2 => Fr::ONE, 3 => -Fr::ONE,
                    _ => Fr::from((i + 129) as u64),
                }).collect();
                let bases = G2Projective::batch_to_affine(&coefficients.iter()
                    .map(|s| G2Affine::GENERATOR * *s).collect::<Vec<_>>());
                for family in 0..3 {
                    let scalars: Vec<_> = (0..n).map(|i| match family {
                        0 => match i % 6 {0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,
                            3=>Fr::from(2048u64),4=>-Fr::from(2048u64),_=>Fr::from(1u64<<63)},
                        1 => Fr::from((i+987) as u64).pow(&[239]),
                        _ => Fr::from(2u64).pow(&[(i % 254) as u64]) - Fr::ONE,
                    }).collect();
                    let expected = G2Affine::GENERATOR * scalars.iter().zip(&coefficients)
                        .fold(Fr::ZERO, |a,(s,c)| a + *s * *c);
                    let mut words: Vec<_> = scalars.iter().map(Fr::to_canonical).collect();
                    let out = pool.install(|| try_raw(&bases, &mut words, true)).unwrap();
                    assert_eq!(out.to_affine(), expected.to_affine(), "workers={workers} n={n} family={family}");
                    assert_eq!(words, scalars.iter().map(|s| phi_split(s.to_canonical())).collect::<Vec<_>>());
                }
            }
        }
    }

    #[test]
    fn component_bucket_oracles_cover_signs_top_and_exceptions() {
        let n=1031;
        let coefficients: Vec<_> = (0..n).map(|i| match i%5 {0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,_=>Fr::from((i+9)as u64)}).collect();
        let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|s|G2Affine::GENERATOR**s).collect::<Vec<_>>());
        let words:Vec<_>=(0..n).map(|i|phi_split(Fr::from((i+77)as u64).pow(&[251]).to_canonical())).collect();
        for high in [false,true] { for w in [0,5,10] {
            let buckets=if w==10 {hb_top_component(&bases,&words,high,w,12,6)} else {super::super::super::g2_borrowed::independent_component(&bases,&words,high,w,12)};
            let mut expected=vec![Fr::ZERO;buckets.len()];
            for (i,s) in words.iter().enumerate() {
                let d=hb_digit(s,high,w,12);
                if d!=0 {let c=if d<0{-coefficients[i]}else{coefficients[i]};expected[d.unsigned_abs()as usize-1]+=c;}
            }
            for (b,s) in buckets.iter().zip(expected) {assert_eq!(*b,(G2Affine::GENERATOR*s).to_affine());}
        }}
    }

    #[test]
    fn denial_and_bounds_leave_inputs_unchanged() {
        let mut words=vec![[3,0,0,0];1024];
        let before=words.clone();
        assert!(try_raw(&vec![G2Affine::GENERATOR;1024],&mut words,false).is_none());
        assert_eq!(words,before);
        assert!(try_raw(&[],&mut [],true).is_none());
        let cost=super::super::super::workspace::independent_g2;
        assert!(cost(65536,4).is_none());
        assert!(cost(1024,0).is_none());
        assert!(cost(1024,usize::MAX).is_none());
        assert!(cost(4097,32).unwrap()>cost(1024,1).unwrap());
        assert!(cost(65535,32).is_some());
    }
}
