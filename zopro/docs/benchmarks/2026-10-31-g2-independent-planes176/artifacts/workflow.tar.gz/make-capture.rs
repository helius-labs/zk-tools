use std::{fs,path::Path};const R:&str="/home/ubuntu/src/zopro-perf-work/g2-independent-planes176";
fn once(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1)}
fn main(){let mut s=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176/capture.rs").unwrap().replace("/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176",R);
 once(&mut s,"assert_eq!(read(r(\"native-fixed/result.json\"))[\"status\"],\"complete\");assert_eq!(read(r(\"native/freeze-control/exit.json\"))[\"success\"],true);","assert_eq!(read(r(\"native/result.json\"))[\"status\"],\"complete\");assert_eq!(read(r(\"links/result.json\"))[\"status\"],\"complete\");");
 once(&mut s,"environment[\"RAYON_NUM_THREADS\"] = json!(workers.to_string());","environment[\"RAYON_NUM_THREADS\"] = json!(workers.to_string());environment[\"ZOPRO_CPU_INDEPENDENT_G2\"]=json!(if label==\"candidate\"{\"1\"}else{\"0\"});");
 once(&mut s,"let expected=0;","let expected=if j[\"variant\"]==\"candidate\"&&j[\"case\"][\"query\"]==\"B\"{1}else{0};");
 once(&mut s,"let gate = calibration&&contexts_frozen", "let b32=&cases[\"1x2-B-w32\"];let b_gain=[\"candidate_over_control\",\"candidate_over_frozen\"].iter().all(|key|b32[*key][\"upper\"].as_f64().unwrap()<1.&&b32[*key][\"wins\"].as_u64().unwrap()>=10);\n    let gate = b_gain&&calibration&&contexts_frozen");
 // Keep the inherited aggregate gain condition too, as prospectively declared below.
 once(&mut s,"        \"codegen-review.json\",","        \"codegen-review.json\",\n        \"link-review.json\",\n        \"review.rs\",\n        \"review-helper\",\n        \"make-review.rs\",\n        \"make-review\",\n        \"codegen-helper\",\n        \"make-capture\",");
 let p=Path::new(R);assert!(!p.join("capture.rs").exists());fs::write(p.join("capture.rs"),s).unwrap();for n in["counter.rs","sampling.rs"]{fs::copy(Path::new("/home/ubuntu/src/zopro-perf-work/fused-epoch-pin176").join(n),p.join(n)).unwrap();}
}
