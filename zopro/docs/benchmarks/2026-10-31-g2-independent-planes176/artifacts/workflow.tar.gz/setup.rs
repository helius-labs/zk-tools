use serde_json::{json,Value}; use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/g2-independent-planes176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
const TOOL:&str="/home/ubuntu/src/zopro-perf-work/sdk-link-flags176/tool-target/release/xtask";
fn r(p:impl AsRef<Path>)->PathBuf{Path::new(R).join(p)}
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn pin(m:&mut BTreeMap<String,String>,p:impl AsRef<Path>){m.insert(p.as_ref().display().to_string(),hash(&p));}
fn append(p:&str,s:&str){let p=r("source").join(p);let mut v=fs::read_to_string(&p).unwrap();v.push_str("\n// BEGIN PRIVATE INDEPENDENT G2 PLANES\n");v.push_str(s);fs::write(p,v).unwrap()}
fn main(){
 assert!(!r("source").exists());
 let m=read(Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
 let mut pins=BTreeMap::new();
 for(p,h)in m["source_files_sha256"].as_object().unwrap(){let from=Path::new(Z).join(p);assert_eq!(hash(&from),h.as_str().unwrap());let to=r("source").join(p);fs::create_dir_all(to.parent().unwrap()).unwrap();fs::copy(&from,to).unwrap();pin(&mut pins,&from);}
 fs::create_dir_all(r("source/crates/zopro-core/src/msm_affine/g2_phi")).unwrap();
 fs::copy(r("independent.rs"),r("source/crates/zopro-core/src/msm_affine/g2_phi/independent.rs")).unwrap();
 append("crates/zopro-core/src/msm_affine/g2_phi.rs", "#[cfg(zopro_independent_planes)] pub(super) mod independent;\n");
 let p=r("source/crates/zopro-core/src/msm_affine/g2_phi.rs");let mut s=fs::read_to_string(&p).unwrap();
 let a="    hb_raw(bases, words, 12, 2)";assert_eq!(s.matches(a).count(),1);
 s=s.replace(a,"    #[cfg(zopro_independent_planes)]\n    if std::env::var(\"ZOPRO_CPU_INDEPENDENT_G2\").ok().as_deref()==Some(\"1\") {\n        if let Some(out)=independent::try_raw(bases,words,true) {return out;}\n    }\n    hb_raw(bases, words, 12, 2)");fs::write(p,s).unwrap();
 append("crates/zopro-core/src/msm_affine/g2_borrowed.rs",r#"
#[cfg(zopro_independent_planes)]
pub(super) fn independent_component(bases:&[G2Affine],short:&[[u64;4]],high:bool,w:usize,bits:usize)->Vec<G2Affine>{
 let packed=BatchAdd::<G2Config>::default();assert!(packed.borrowed_g2_enabled());
 let size=batch_size(bits).max(32);let mut state=Window::new(1<<(bits-1),size,packed);
 state.feed(bases,short,high,w,bits,size);state.finish()
}
"#);
 append("crates/zopro-core/src/msm_affine/workspace.rs",r#"
#[cfg(zopro_independent_planes)]
pub(crate) fn independent_g2(n:usize,workers:usize)->Option<usize>{
 if !(1024..65536).contains(&n)||workers==0{return None;}
 let p=shape::<G2Config>(2048,11,4,batch_size(12).max(32))?;
 let t=top::<G2Config>(n.div_ceil(2),7)?;
 let extra=mul(vector::<zopro_bn254::G2Affine>(64,false)?,3)?;
 let held=add(p.held,mul(add(t.held,extra)?,4)?)?;
 add(held,mul(p.leaf.max(t.leaf),workers)?)
}
"#);
 append("crates/zopro-core/src/msm_affine.rs",r#"
#[cfg(zopro_independent_planes)]
pub(crate) fn independent_g2_calls()->usize{g2_phi::independent::ENTERED.load(std::sync::atomic::Ordering::Relaxed)}
"#);
 let probe=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/coalesce-query176/probe-export.rs").unwrap();
 let needle="(crate::msm_affine::g2_query_exclusive(bases,words),Metadata::default())";assert_eq!(probe.matches(needle).count(),1);
 let probe=probe.replace(needle,"{let before=crate::msm_affine::independent_g2_calls();let out=crate::msm_affine::g2_query_exclusive(bases,words);let calls=crate::msm_affine::independent_g2_calls()-before;(out,Metadata{route:calls as u32,..Metadata::default()})}");
 fs::write(r("probe-export.rs"),&probe).unwrap();append("crates/zopro-core/src/lib.rs",&probe);
 let mut exact=0;let mut files=BTreeMap::new();
 for(p,h)in m["source_files_sha256"].as_object().unwrap(){let path=r("source").join(p);let bytes=fs::read(&path).unwrap();let original=fs::read(Path::new(Z).join(p)).unwrap();let is_exact=hash(&path)==h.as_str().unwrap();if is_exact{exact+=1;}else{
 let marker=b"\n// BEGIN PRIVATE INDEPENDENT G2 PLANES\n";let at=bytes.windows(marker.len()).position(|v|v==marker).unwrap();let mut recovered=String::from_utf8(bytes[..at].to_vec()).unwrap();
 if p.ends_with("g2_phi.rs"){let a=recovered.find("    #[cfg(zopro_independent_planes)]\n").unwrap();let b=a+recovered[a..].find("    hb_raw(bases, words, 12, 2)").unwrap();recovered.replace_range(a..b,"");}
 assert_eq!(recovered.as_bytes(),original);}
 files.insert(p.clone(),json!({"original_sha256":h,"private_sha256":hash(path),"exact":is_exact,"recovered":true}));}
 assert_eq!(exact,171);save(r("source-audit.json"),&json!({"originals":176,"exact":exact,"changed_parents":5,"new_children":1,"all_originals_recover_exactly":true,"all_field_sources_exact":true,"files":files}));
 let flags=m["rustflags"].as_str().unwrap().to_owned()+" --cfg zopro_coalesce_probe --cfg zopro_independent_planes";
 fs::write(r("native-flags.txt"),&flags).unwrap();fs::write(r("candidate-flags.txt"),&flags).unwrap();
 let native=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/coalesce-query176/native.rs").unwrap().replace("/home/ubuntu/src/zopro-perf-work/coalesce-query176",R);
 fs::write(r("native.rs"),native).unwrap();
 // Bootstrap pins are finalized after the freezer/helper has been compiled.
 save(r("production-pins.json"),&json!(pins));pin(&mut pins,TOOL);
 println!("Prepared177privatefiles/171exactoriginals/5recoverableparents/1child;fields byteexact; no production edits");
}
