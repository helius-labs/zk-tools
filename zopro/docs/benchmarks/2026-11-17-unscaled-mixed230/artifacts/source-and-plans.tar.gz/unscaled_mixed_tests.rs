use super::*;
use ark_ec::{AdditiveGroup,AffineRepr,CurveGroup,PrimeGroup};
use ark_ff::{Field as _,PrimeField};
use ark_ref as ark;
fn next(s:&mut u64)->[u8;32]{let mut b=[0;32];for chunk in b.chunks_exact_mut(8){*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;chunk.copy_from_slice(&s.to_le_bytes());}b}
fn nf(x:ark::Fq)->Fq{Fq::from_montgomery(x.0.0)}
fn af(x:Fq)->ark::Fq{ark::Fq::new_unchecked(ark_ff::BigInt(x.0))}
fn point(p:ark::G1Affine)->G1Affine{if p.infinity{G1Affine::IDENTITY}else{G1Affine::new(nf(p.x),nf(p.y))}}
fn scaled(p:ark::G1Affine,z:ark::Fq)->G1Projective{if p.infinity{G1Projective::new(Fq::from(19),Fq::from(71),Fq::ZERO)}else{G1Projective::new(nf(p.x*z.square()),nf(p.y*z.square()*z),nf(z))}}
fn check(a:&G1Projective,b:&G1Affine,expected:ark::G1Affine){let before=(a.x,a.y,a.z,b.x,b.y);let got=a.add_affine(b);assert_eq!(got.to_affine(),point(expected));assert_eq!(before,(a.x,a.y,a.z,b.x,b.y));if !expected.infinity{let z=af(got.z);assert_ne!(z,ark::Fq::ZERO);assert_eq!(af(got.x),expected.x*z.square());assert_eq!(af(got.y),expected.y*z.square()*z);}else{assert!(got.is_identity());}if !a.is_identity()&&!b.is_identity(){let h=af(b.x)*af(a.z).square()-af(a.x);if h!=ark::Fq::ZERO{assert_eq!(af(got.z),af(a.z)*h,"unscaled ordinary output Z");}}}
#[test]
fn unscaled_mixed_fullwidth_and_projective_scales(){let g=ark::G1Projective::generator();let mut seed=0x7b37_12e9_2300_75d1;let(mut ordinary,mut equal,mut opposite)=(0,0,0);for i in 0..384{let sa=ark::Fr::from_le_bytes_mod_order(&next(&mut seed));let sb=ark::Fr::from_le_bytes_mod_order(&next(&mut seed));let aa=if i%17==0{ark::G1Projective::ZERO}else{g*sa};let bb=match i%11{0=>ark::G1Projective::ZERO,1=>{equal+=1;aa},2=>{opposite+=1;-aa},3=>g,_=>{ordinary+=1;g*sb}};let pa=aa.into_affine();let pb=bb.into_affine();let z=ark::Fq::from_le_bytes_mod_order(&next(&mut seed));let z=if z==ark::Fq::ZERO{ark::Fq::ONE}else{z};for scale in[ark::Fq::ONE,z,-z]{check(&scaled(pa,scale),&point(pb),(aa+bb).into_affine());}}assert!(ordinary>200&&equal>20&&opposite>20);}
#[test]
fn unscaled_mixed_changing_chains_with_cancellations(){let g=ark::G1Projective::generator();let mut seed=0x41e0_392a_0057_5230;for i in 0..64{let mut expected=g*ark::Fr::from_le_bytes_mod_order(&next(&mut seed));let mut z=ark::Fq::from_le_bytes_mod_order(&next(&mut seed));if z==ark::Fq::ZERO{z=ark::Fq::ONE;}let mut actual=scaled(expected.into_affine(),z);for step in 0..48{let delta=match step%13{0=>ark::G1Projective::ZERO,1=>-expected,2=>expected,_=>g*ark::Fr::from_le_bytes_mod_order(&next(&mut seed))};let input=point(delta.into_affine());let sum=expected+delta;check(&actual,&input,sum.into_affine());actual=actual.add_affine(&input);expected=sum;}assert_eq!(actual.to_affine(),point(expected.into_affine()),"chain{i}");}}
