# Exact generated-proof certificate profile

Reuse SDK194 bcc8e0775bb5bc6c09ad86b1987ca45eebac62617340911266c84aa601fa05b1,
no rebuild or new executable copies. Primary1x2,16 fixed workers0-15,3blocks,
OFF/ON and plain/stat/cycles panels,251timed fresh requests plus3primes each.
18processes,4572SDKcalls,18freshGnarkexports. Three existing backings balanced.
Both arms fusion/indexedON; only ON sets ZOPRO_BENCH_CERTIFIED_OUTPUT=1.
Capture FIFO excludes loading, certification, primes and export. Full warm SDK
boundary remains. All latency/PMU recording precedes decoding/verifying.
During capture only poll confirmed handle, no other owned analysis/build/hashing.

Reuse qualified192 observer/quality protocol: each arm's stat/plain andcycles/plain
median ratios inside factor1.05; each PMU counter scheduled>=99.9%; cycle captures
period16M,>=1000samples,unknown<=5%,zeroLOST,exactMMAP/PID/TID/CPU ownership.
These are observer/PMU guards, not performance gain claims. Keep all observations.
Mechanism: ON executes251 certified parses with no timed certificate scans;
OFF0. Each serial ON process has one cold key and one cold fixed-input scan,
reported separately. External parsing retains checks. If work reduction is absent
and full-proof benefit absent, close without all-shape campaign; if mechanism
survives, finish qualification of exact194 build without cosmetic changes.

Seed57392 at certified-proof194/proof-sha256.json SHA
f6425169716f853ffa71b4731b8dde5734c37b77d6aaf1dbe9f1107dc35cefb0.
Nextcanonical57410. No production change, AWS or push. Fullall8CPU10xunmet.
