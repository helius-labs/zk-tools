# Selection and inherited evidence

The fresh search rediscovered SRE(arxiv2610.27452), Hrabar's Waterloo thesis,
MQX(arxiv2509.12494), and power-of-two LFG sets(eprint2026/2750). SRE/Hrabar/LFG
already have local census and native experiments. The late-m3-query176 caller
was2.594x slower at32workers despite4.22% fewer genericadditions, so neither
literal huge tables nor the unchanged multiplier-plane variant is reopened.
MQX's proposed new hardware instructions are not available on these CPUs.
No paper's advertised speedup is imported into the prover results.

Primary-source links:
https://arxiv.org/abs/2610.27452
https://uwspace.uwaterloo.ca/items/43cc12b9-cb03-42bd-a01c-4b0ed5e12403
https://arxiv.org/abs/2509.12494
https://eprint.iacr.org/2026/2750
The last URL/PDF could not be reopened through the web tool; its retained local
Nov5 source/model studies are used for history, not a claim of a new PDF review.

The actionable finding is retained positive BUNDLE control evidence from
2026-11-09-paired-top-query176: primary32 pairedratio0.981912[0.971013,0.993222]
versusORIGINAL,22/31wins;0.971748[0.960628,0.983410]versusREF,24/31wins.
Nov8 standalone bundle's threaded gate remains failed/inconclusive; Nov9 BOTH
andPAIR also remain rejected. This is a new prospective full-proof question on
BUNDLE alone, not relabeling either historical gate or retesting the same query.
The playbook permits following useful positive evidence without a gainfloor.

Existing reducer removes inversion calls by batching independent unchanged pair
trees within a1024point leaf. Originaltopstructuralcount3295→468inversions,
9333→1621scalar-tailpairs,unchanged55165genericpairs. Those counts are inherited
and are not latency estimates. Less parallel work can offset the CPU saving;
shared full-proof load is precisely what this short SDK screen must resolve.

Exact child862a9ce3... and originalmsm recovery/18field-source hashes checked.
127native tests, complete Arkworksqueryoracles, chargeoverflow/denial and edge
coverage are inherited with that binding. Currentphi-grain remains in place.
No repeated native suite, solver extraction or microbenchmark is needed before
fresh SDKproof verification. No admission/phone/pressure release claim follows.
