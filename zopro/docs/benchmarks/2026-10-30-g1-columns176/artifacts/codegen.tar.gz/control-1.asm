
/home/ubuntu/src/zopro-perf-work/g1-columns176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000085de0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_>:
   85de0:	55                                              	push   rbp
   85de1:	48 89 e5                                        	mov    rbp,rsp
   85de4:	41 57                                           	push   r15
   85de6:	41 56                                           	push   r14
   85de8:	41 55                                           	push   r13
   85dea:	41 54                                           	push   r12
   85dec:	53                                              	push   rbx
   85ded:	48 83 e4 c0                                     	and    rsp,0xffffffffffffffc0
   85df1:	48 81 ec c0 0f 00 00                            	sub    rsp,0xfc0
   85df8:	48 c7 04 24 00 00 00 00                         	mov    QWORD PTR [rsp],0x0
   85e00:	48 81 ec 80 00 00 00                            	sub    rsp,0x80
   85e07:	c5 fd 6f 05 71 19 f8 ff                         	vmovdqa ymm0,YMMWORD PTR [rip+0xfffffffffff81971]        # 7780 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x7e0>
   85e0f:	48 b8 07 9a c1 77 0a 0e 00 00                   	movabs rax,0xe0a77c19a07
   85e19:	62 62 fd 48 59 25 85 0e f8 ff                   	vpbroadcastq zmm28,QWORD PTR [rip+0xfffffffffff80e85]        # 6ca8 <GCC_except_table711+0x1b8>
   85e23:	49 bb f8 ff ff ff ff ff ff 07                   	movabs r11,0x7fffffffffffff8
   85e2d:	49 c7 40 10 00 00 00 00                         	mov    QWORD PTR [r8+0x10],0x0
   85e35:	48 89 cb                                        	mov    rbx,rcx
   85e38:	48 c1 eb 03                                     	shr    rbx,0x3
   85e3c:	49 ba 31 e1 72 4e 64 30 00 00                   	movabs r10,0x30644e72e131
   85e46:	49 89 cf                                        	mov    r15,rcx
   85e49:	49 89 f4                                        	mov    r12,rsi
   85e4c:	49 89 fe                                        	mov    r14,rdi
   85e4f:	48 89 4c 24 38                                  	mov    QWORD PTR [rsp+0x38],rcx
   85e54:	48 89 b4 24 00 04 00 00                         	mov    QWORD PTR [rsp+0x400],rsi
   85e5c:	48 89 54 24 30                                  	mov    QWORD PTR [rsp+0x30],rdx
   85e61:	48 89 bc 24 c0 05 00 00                         	mov    QWORD PTR [rsp+0x5c0],rdi
   85e69:	4c 89 84 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],r8
   85e71:	49 21 cb                                        	and    r11,rcx
   85e74:	41 80 78 30 00                                  	cmp    BYTE PTR [r8+0x30],0x0
   85e79:	4c 89 9c 24 c0 07 00 00                         	mov    QWORD PTR [rsp+0x7c0],r11
   85e81:	c5 fe 7f 84 24 c0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xc0],ymm0
   85e8a:	48 89 84 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],rax
   85e92:	62 61 fd 48 7f 64 24 2e                         	vmovdqa64 ZMMWORD PTR [rsp+0xb80],zmm28
   85e9a:	62 62 fd 48 59 5c 24 19                         	vpbroadcastq zmm27,QWORD PTR [rsp+0xc8]
   85ea2:	62 62 fd 48 59 4c 24 1a                         	vpbroadcastq zmm25,QWORD PTR [rsp+0xd0]
   85eaa:	62 62 fd 48 59 44 24 1b                         	vpbroadcastq zmm24,QWORD PTR [rsp+0xd8]
   85eb2:	62 62 fd 48 59 54 24 1c                         	vpbroadcastq zmm26,QWORD PTR [rsp+0xe0]
   85eba:	62 61 fd 48 7f 5c 24 2f                         	vmovdqa64 ZMMWORD PTR [rsp+0xbc0],zmm27
   85ec2:	62 61 fd 48 7f 4c 24 30                         	vmovdqa64 ZMMWORD PTR [rsp+0xc00],zmm25
   85eca:	62 61 fd 48 7f 44 24 31                         	vmovdqa64 ZMMWORD PTR [rsp+0xc40],zmm24
   85ed2:	62 61 fd 48 7f 54 24 32                         	vmovdqa64 ZMMWORD PTR [rsp+0xc80],zmm26
   85eda:	0f 84 cf 10 00 00                               	je     86faf <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x11cf>
   85ee0:	49 3b 18                                        	cmp    rbx,QWORD PTR [r8]
   85ee3:	0f 87 eb 61 00 00                               	ja     8c0d4 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x62f4>
   85ee9:	48 85 db                                        	test   rbx,rbx
   85eec:	0f 84 98 24 00 00                               	je     8838a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x25aa>
   85ef2:	62 62 fd 48 59 25 ac 0d f8 ff                   	vpbroadcastq zmm28,QWORD PTR [rip+0xfffffffffff80dac]        # 6ca8 <GCC_except_table711+0x1b8>
   85efc:	62 f2 fd 48 59 15 3a 0d f8 ff                   	vpbroadcastq zmm2,QWORD PTR [rip+0xfffffffffff80d3a]        # 6c40 <GCC_except_table711+0x150>
   85f06:	c5 7d 6f 3d d2 18 f8 ff                         	vmovdqa ymm15,YMMWORD PTR [rip+0xfffffffffff818d2]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   85f0e:	62 f2 fd 48 59 25 58 0d f8 ff                   	vpbroadcastq zmm4,QWORD PTR [rip+0xfffffffffff80d58]        # 6c70 <GCC_except_table711+0x180>
   85f18:	41 bd 00 06 00 00                               	mov    r13d,0x600
   85f1e:	4d 03 68 08                                     	add    r13,QWORD PTR [r8+0x8]
   85f22:	49 89 d1                                        	mov    r9,rdx
   85f25:	48 89 9c 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],rbx
   85f2d:	31 d2                                           	xor    edx,edx
   85f2f:	31 ff                                           	xor    edi,edi
   85f31:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00    	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   85f40:	49 29 ff                                        	sub    r15,rdi
   85f43:	41 ba 00 00 00 00                               	mov    r10d,0x0
   85f49:	4d 0f 43 d7                                     	cmovae r10,r15
   85f4d:	0f 86 db 62 00 00                               	jbe    8c22e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x644e>
   85f53:	41 8b 09                                        	mov    ecx,DWORD PTR [r9]
   85f56:	81 e1 ff ff ff 7f                               	and    ecx,0x7fffffff
   85f5c:	49 39 cc                                        	cmp    r12,rcx
   85f5f:	0f 86 3d 63 00 00                               	jbe    8c2a2 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x64c2>
   85f65:	49 83 fa 01                                     	cmp    r10,0x1
   85f69:	0f 84 a4 62 00 00                               	je     8c213 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6433>
   85f6f:	41 8b 71 10                                     	mov    esi,DWORD PTR [r9+0x10]
   85f73:	81 e6 ff ff ff 7f                               	and    esi,0x7fffffff
   85f79:	49 39 f4                                        	cmp    r12,rsi
   85f7c:	0f 86 6e 62 00 00                               	jbe    8c1f0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6410>
   85f82:	49 83 fa 02                                     	cmp    r10,0x2
   85f86:	0f 84 8c 62 00 00                               	je     8c218 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6438>
   85f8c:	45 8b 71 20                                     	mov    r14d,DWORD PTR [r9+0x20]
   85f90:	41 81 e6 ff ff ff 7f                            	and    r14d,0x7fffffff
   85f97:	4d 39 f4                                        	cmp    r12,r14
   85f9a:	0f 86 33 62 00 00                               	jbe    8c1d3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63f3>
   85fa0:	49 83 fa 03                                     	cmp    r10,0x3
   85fa4:	0f 84 63 62 00 00                               	je     8c20d <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x642d>
   85faa:	45 8b 59 30                                     	mov    r11d,DWORD PTR [r9+0x30]
   85fae:	41 81 e3 ff ff ff 7f                            	and    r11d,0x7fffffff
   85fb5:	4d 39 dc                                        	cmp    r12,r11
   85fb8:	0f 86 f8 61 00 00                               	jbe    8c1b6 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63d6>
   85fbe:	49 83 fa 04                                     	cmp    r10,0x4
   85fc2:	0f 84 5c 62 00 00                               	je     8c224 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6444>
   85fc8:	45 8b 79 40                                     	mov    r15d,DWORD PTR [r9+0x40]
   85fcc:	41 81 e7 ff ff ff 7f                            	and    r15d,0x7fffffff
   85fd3:	4d 39 fc                                        	cmp    r12,r15
   85fd6:	0f 86 c3 62 00 00                               	jbe    8c29f <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x64bf>
   85fdc:	49 83 fa 05                                     	cmp    r10,0x5
   85fe0:	0f 84 44 62 00 00                               	je     8c22a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x644a>
   85fe6:	41 8b 59 50                                     	mov    ebx,DWORD PTR [r9+0x50]
   85fea:	81 e3 ff ff ff 7f                               	and    ebx,0x7fffffff
   85ff0:	49 39 dc                                        	cmp    r12,rbx
   85ff3:	0f 86 89 62 00 00                               	jbe    8c282 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x64a2>
   85ff9:	49 83 fa 06                                     	cmp    r10,0x6
   85ffd:	0f 84 1b 62 00 00                               	je     8c21e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x643e>
   86003:	45 8b 61 60                                     	mov    r12d,DWORD PTR [r9+0x60]
   86007:	41 81 e4 ff ff ff 7f                            	and    r12d,0x7fffffff
   8600e:	4c 39 a4 24 00 04 00 00                         	cmp    QWORD PTR [rsp+0x400],r12
   86016:	0f 86 49 62 00 00                               	jbe    8c265 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6485>
   8601c:	48 8d 47 07                                     	lea    rax,[rdi+0x7]
   86020:	49 83 fa 07                                     	cmp    r10,0x7
   86024:	0f 84 07 62 00 00                               	je     8c231 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6451>
   8602a:	45 8b 51 70                                     	mov    r10d,DWORD PTR [r9+0x70]
   8602e:	62 61 fd 48 7f 5c 24 0c                         	vmovdqa64 ZMMWORD PTR [rsp+0x300],zmm27
   86036:	62 61 fd 48 7f 4c 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm25
   8603e:	62 61 fd 48 7f 44 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm24
   86046:	62 61 fd 48 7f 54 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm26
   8604e:	41 81 e2 ff ff ff 7f                            	and    r10d,0x7fffffff
   86055:	4c 39 94 24 00 04 00 00                         	cmp    QWORD PTR [rsp+0x400],r10
   8605d:	0f 86 e5 61 00 00                               	jbe    8c248 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6468>
   86063:	49 89 d0                                        	mov    r8,rdx
   86066:	48 8b 94 24 c0 05 00 00                         	mov    rdx,QWORD PTR [rsp+0x5c0]
   8606e:	49 c1 e7 06                                     	shl    r15,0x6
   86072:	48 c1 e1 06                                     	shl    rcx,0x6
   86076:	49 c1 e6 06                                     	shl    r14,0x6
   8607a:	48 c1 e6 06                                     	shl    rsi,0x6
   8607e:	49 c1 e3 06                                     	shl    r11,0x6
   86082:	49 c1 e4 06                                     	shl    r12,0x6
   86086:	48 c1 e3 06                                     	shl    rbx,0x6
   8608a:	49 c1 e2 06                                     	shl    r10,0x6
   8608e:	62 f1 fd 48 6f 0d a8 14 f8 ff                   	vmovdqa64 zmm1,ZMMWORD PTR [rip+0xfffffffffff814a8]        # 7540 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x5a0>
   86098:	62 11 fd 48 6f f4                               	vmovdqa64 zmm14,zmm28
   8609e:	c4 41 7d 6f e7                                  	vmovdqa ymm12,ymm15
   860a3:	c4 a1 7c 10 44 3a 20                            	vmovups ymm0,YMMWORD PTR [rdx+r15*1+0x20]
   860aa:	c5 fe 6f 34 0a                                  	vmovdqu ymm6,YMMWORD PTR [rdx+rcx*1]
   860af:	62 21 fe 28 6f 14 3a                            	vmovdqu64 ymm26,YMMWORD PTR [rdx+r15*1]
   860b6:	4d 8b 79 08                                     	mov    r15,QWORD PTR [r9+0x8]
   860ba:	62 21 fe 28 6f 0c 32                            	vmovdqu64 ymm25,YMMWORD PTR [rdx+r14*1]
   860c1:	62 a1 fe 28 6f 44 32 01                         	vmovdqu64 ymm16,YMMWORD PTR [rdx+r14*1+0x20]
   860c9:	4d 8b 71 28                                     	mov    r14,QWORD PTR [r9+0x28]
   860cd:	62 e1 fe 28 6f 4c 32 01                         	vmovdqu64 ymm17,YMMWORD PTR [rdx+rsi*1+0x20]
   860d5:	62 a1 fe 28 6f 54 1a 01                         	vmovdqu64 ymm18,YMMWORD PTR [rdx+r11*1+0x20]
   860dd:	62 a1 fe 28 6f 1c 22                            	vmovdqu64 ymm19,YMMWORD PTR [rdx+r12*1]
   860e4:	c4 a1 7e 6f 6c 22 20                            	vmovdqu ymm5,YMMWORD PTR [rdx+r12*1+0x20]
   860eb:	62 61 fe 28 6f 44 0a 01                         	vmovdqu64 ymm24,YMMWORD PTR [rdx+rcx*1+0x20]
   860f3:	62 61 fe 28 6f 6c 1a 01                         	vmovdqu64 ymm29,YMMWORD PTR [rdx+rbx*1+0x20]
   860fb:	62 f3 cd 48 3a 34 32 01                         	vinserti64x4 zmm6,zmm6,YMMWORD PTR [rdx+rsi*1],0x1
   86103:	62 b3 b5 40 3a 3c 1a 01                         	vinserti64x4 zmm7,zmm25,YMMWORD PTR [rdx+r11*1],0x1
   8610b:	4d 8b 59 18                                     	mov    r11,QWORD PTR [r9+0x18]
   8610f:	49 8b 71 38                                     	mov    rsi,QWORD PTR [r9+0x38]
   86113:	62 73 ad 40 3a 04 1a 01                         	vinserti64x4 zmm8,zmm26,YMMWORD PTR [rdx+rbx*1],0x1
   8611b:	62 a3 e5 40 3a 1c 12 01                         	vinserti64x4 zmm19,zmm19,YMMWORD PTR [rdx+r10*1],0x1
   86123:	62 41 fe 28 6f 1f                               	vmovdqu64 ymm27,YMMWORD PTR [r15]
   86129:	62 c1 fe 28 6f 67 01                            	vmovdqu64 ymm20,YMMWORD PTR [r15+0x20]
   86130:	4d 8b 79 48                                     	mov    r15,QWORD PTR [r9+0x48]
   86134:	62 41 fe 28 6f 26                               	vmovdqu64 ymm28,YMMWORD PTR [r14]
   8613a:	62 c1 fe 28 6f 6e 01                            	vmovdqu64 ymm21,YMMWORD PTR [r14+0x20]
   86141:	4d 8b 71 68                                     	mov    r14,QWORD PTR [r9+0x68]
   86145:	62 41 fe 28 6f 4b 01                            	vmovdqu64 ymm25,YMMWORD PTR [r11+0x20]
   8614c:	62 53 a5 40 3a 0b 01                            	vinserti64x4 zmm9,zmm27,YMMWORD PTR [r11],0x1
   86153:	4d 8b 59 58                                     	mov    r11,QWORD PTR [r9+0x58]
   86157:	62 61 fe 28 6f 56 01                            	vmovdqu64 ymm26,YMMWORD PTR [rsi+0x20]
   8615e:	62 73 9d 40 3a 16 01                            	vinserti64x4 zmm10,zmm28,YMMWORD PTR [rsi],0x1
   86165:	49 8b 71 78                                     	mov    rsi,QWORD PTR [r9+0x78]
   86169:	62 f1 7c 48 29 44 24 0e                         	vmovaps ZMMWORD PTR [rsp+0x380],zmm0
   86171:	62 f1 fd 48 6f 05 85 13 f8 ff                   	vmovdqa64 zmm0,ZMMWORD PTR [rip+0xfffffffffff81385]        # 7500 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x560>
   8617b:	62 41 fe 28 6f 37                               	vmovdqu64 ymm30,YMMWORD PTR [r15]
   86181:	62 41 fe 28 6f 3e                               	vmovdqu64 ymm31,YMMWORD PTR [r14]
   86187:	62 c1 fe 28 6f 77 01                            	vmovdqu64 ymm22,YMMWORD PTR [r15+0x20]
   8618e:	62 c1 fe 28 6f 7e 01                            	vmovdqu64 ymm23,YMMWORD PTR [r14+0x20]
   86195:	4c 8b 7c 24 38                                  	mov    r15,QWORD PTR [rsp+0x38]
   8619a:	62 53 8d 40 3a 1b 01                            	vinserti64x4 zmm11,zmm30,YMMWORD PTR [r11],0x1
   861a1:	62 61 cd 48 6c f7                               	vpunpcklqdq zmm30,zmm6,zmm7
   861a7:	62 f1 cd 48 6d ff                               	vpunpckhqdq zmm7,zmm6,zmm7
   861ad:	62 f3 85 40 3a 1e 01                            	vinserti64x4 zmm3,zmm31,YMMWORD PTR [rsi],0x1
   861b4:	62 b1 bd 48 6c f3                               	vpunpcklqdq zmm6,zmm8,zmm19
   861ba:	62 31 bd 48 6d c3                               	vpunpckhqdq zmm8,zmm8,zmm19
   861c0:	62 61 fe 28 6f 66 01                            	vmovdqu64 ymm28,YMMWORD PTR [rsi+0x20]
   861c7:	62 41 fe 28 6f 5b 01                            	vmovdqu64 ymm27,YMMWORD PTR [r11+0x20]
   861ce:	48 8d 77 08                                     	lea    rsi,[rdi+0x8]
   861d2:	62 81 fd 48 6f de                               	vmovdqa64 zmm19,zmm30
   861d8:	62 61 fd 48 6f ff                               	vmovdqa64 zmm31,zmm7
   861de:	62 62 f5 48 7e f6                               	vpermt2q zmm30,zmm1,zmm6
   861e4:	62 d2 f5 48 7e f8                               	vpermt2q zmm7,zmm1,zmm8
   861ea:	62 e2 fd 48 7e de                               	vpermt2q zmm19,zmm0,zmm6
   861f0:	62 42 fd 48 7e f8                               	vpermt2q zmm31,zmm0,zmm8
   861f6:	62 b3 85 40 71 f3 0c                            	vpshldq zmm6,zmm31,zmm19,0xc
   861fd:	62 71 e5 40 db c2                               	vpandq zmm8,zmm19,zmm2
   86203:	62 83 c5 48 71 de 24                            	vpshldq zmm19,zmm7,zmm30,0x24
   8620a:	62 71 cd 48 db ea                               	vpandq zmm13,zmm6,zmm2
   86210:	62 93 8d 40 71 f7 18                            	vpshldq zmm6,zmm30,zmm31,0x18
   86217:	62 23 d5 48 3a 74 12 01 01                      	vinserti64x4 zmm30,zmm5,YMMWORD PTR [rdx+r10*1+0x20],0x1
   86220:	62 61 e5 40 db fa                               	vpandq zmm31,zmm19,zmm2
   86226:	62 f1 e5 40 73 d7 10                            	vpsrlq zmm19,zmm7,0x10
   8622d:	62 d1 b5 48 6c ea                               	vpunpcklqdq zmm5,zmm9,zmm10
   86233:	62 d1 b5 48 6d fa                               	vpunpckhqdq zmm7,zmm9,zmm10
   86239:	62 71 a5 48 6c cb                               	vpunpcklqdq zmm9,zmm11,zmm3
   8623f:	62 f1 a5 48 6d db                               	vpunpckhqdq zmm3,zmm11,zmm3
   86245:	62 51 fd 48 7f 45 e8                            	vmovdqa64 ZMMWORD PTR [r13-0x600],zmm8
   8624c:	49 ba 31 e1 72 4e 64 30 00 00                   	movabs r10,0x30644e72e131
   86256:	62 71 fd 48 6f d5                               	vmovdqa64 zmm10,zmm5
   8625c:	62 71 fd 48 6f df                               	vmovdqa64 zmm11,zmm7
   86262:	62 52 fd 48 7e d1                               	vpermt2q zmm10,zmm0,zmm9
   86268:	62 72 fd 48 7e db                               	vpermt2q zmm11,zmm0,zmm3
   8626e:	62 d2 f5 48 7e e9                               	vpermt2q zmm5,zmm1,zmm9
   86274:	62 f2 f5 48 7e fb                               	vpermt2q zmm7,zmm1,zmm3
   8627a:	62 51 fd 48 7f 6d e9                            	vmovdqa64 ZMMWORD PTR [r13-0x5c0],zmm13
   86281:	62 f1 cd 48 db f2                               	vpandq zmm6,zmm6,zmm2
   86287:	62 d1 fd 48 7f 75 ea                            	vmovdqa64 ZMMWORD PTR [r13-0x580],zmm6
   8628e:	62 41 fd 48 7f 7d eb                            	vmovdqa64 ZMMWORD PTR [r13-0x540],zmm31
   86295:	62 c1 fd 48 7f 5d ec                            	vmovdqa64 ZMMWORD PTR [r13-0x500],zmm19
   8629c:	c5 7e 7f bc 24 c0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xc0],ymm15
   862a5:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   862ad:	62 53 a5 48 71 ca 0c                            	vpshldq zmm9,zmm11,zmm10,0xc
   862b4:	62 f1 ad 48 db da                               	vpandq zmm3,zmm10,zmm2
   862ba:	62 53 d5 48 71 db 18                            	vpshldq zmm11,zmm5,zmm11,0x18
   862c1:	62 f3 c5 48 71 ed 24                            	vpshldq zmm5,zmm7,zmm5,0x24
   862c8:	62 f1 c5 48 73 d7 10                            	vpsrlq zmm7,zmm7,0x10
   862cf:	62 51 e5 48 fb f8                               	vpsubq zmm15,zmm3,zmm8
   862d5:	62 d1 e5 48 d4 d8                               	vpaddq zmm3,zmm3,zmm8
   862db:	62 71 a5 48 db d2                               	vpandq zmm10,zmm11,zmm2
   862e1:	62 71 d5 48 db da                               	vpandq zmm11,zmm5,zmm2
   862e7:	62 f1 85 48 d4 ec                               	vpaddq zmm5,zmm15,zmm4
   862ed:	62 71 b5 48 db ca                               	vpandq zmm9,zmm9,zmm2
   862f3:	62 f1 85 48 73 d3 34                            	vpsrlq zmm15,zmm3,0x34
   862fa:	62 f1 e5 48 db da                               	vpandq zmm3,zmm3,zmm2
   86300:	62 f1 bd 48 72 e5 34                            	vpsraq zmm8,zmm5,0x34
   86307:	62 71 bd 58 d4 44 24 19                         	vpaddq zmm8,zmm8,QWORD BCST [rsp+0xc8]
   8630f:	62 51 bd 48 d4 c1                               	vpaddq zmm8,zmm8,zmm9
   86315:	62 51 b5 48 d4 cd                               	vpaddq zmm9,zmm9,zmm13
   8631b:	62 51 bd 48 fb c5                               	vpsubq zmm8,zmm8,zmm13
   86321:	62 51 85 48 d4 c9                               	vpaddq zmm9,zmm15,zmm9
   86327:	62 d1 95 48 72 e0 34                            	vpsraq zmm13,zmm8,0x34
   8632e:	62 71 95 58 d4 6c 24 1a                         	vpaddq zmm13,zmm13,QWORD BCST [rsp+0xd0]
   86336:	62 51 95 48 d4 ea                               	vpaddq zmm13,zmm13,zmm10
   8633c:	62 71 95 48 fb ee                               	vpsubq zmm13,zmm13,zmm6
   86342:	62 f1 ad 48 d4 f6                               	vpaddq zmm6,zmm10,zmm6
   86348:	62 d1 ad 48 72 e5 34                            	vpsraq zmm10,zmm13,0x34
   8634f:	62 71 ad 58 d4 54 24 1b                         	vpaddq zmm10,zmm10,QWORD BCST [rsp+0xd8]
   86357:	62 51 ad 48 d4 d3                               	vpaddq zmm10,zmm10,zmm11
   8635d:	62 11 a5 48 d4 df                               	vpaddq zmm11,zmm11,zmm31
   86363:	62 11 ad 48 fb d7                               	vpsubq zmm10,zmm10,zmm31
   86369:	62 d1 85 40 72 e2 34                            	vpsraq zmm31,zmm10,0x34
   86370:	62 61 85 50 d4 7c 24 1c                         	vpaddq zmm31,zmm31,QWORD BCST [rsp+0xe0]
   86378:	62 d1 fd 48 7f 5d f2                            	vmovdqa64 ZMMWORD PTR [r13-0x380],zmm3
   8637f:	62 f1 b5 48 db da                               	vpandq zmm3,zmm9,zmm2
   86385:	62 d1 fd 48 7f 5d f3                            	vmovdqa64 ZMMWORD PTR [r13-0x340],zmm3
   8638c:	62 61 85 40 d4 ff                               	vpaddq zmm31,zmm31,zmm7
   86392:	62 b1 c5 48 d4 fb                               	vpaddq zmm7,zmm7,zmm19
   86398:	62 21 85 40 fb fb                               	vpsubq zmm31,zmm31,zmm19
   8639e:	62 d1 e5 40 73 d1 34                            	vpsrlq zmm19,zmm9,0x34
   863a5:	62 f1 e5 40 d4 f6                               	vpaddq zmm6,zmm19,zmm6
   863ab:	62 71 85 40 db fa                               	vpandq zmm15,zmm31,zmm2
   863b1:	62 f1 e5 40 73 d6 34                            	vpsrlq zmm19,zmm6,0x34
   863b8:	62 f1 cd 48 db da                               	vpandq zmm3,zmm6,zmm2
   863be:	62 b3 fd 40 3a f2 01                            	vinserti64x4 zmm6,zmm16,ymm18,0x1
   863c5:	62 e1 bd 48 db d2                               	vpandq zmm18,zmm8,zmm2
   863cb:	62 e1 ad 48 db c2                               	vpandq zmm16,zmm10,zmm2
   863d1:	62 51 e5 40 d4 db                               	vpaddq zmm11,zmm19,zmm11
   863d7:	62 d1 fd 48 7f 5d f4                            	vmovdqa64 ZMMWORD PTR [r13-0x300],zmm3
   863de:	62 d1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm11,0x34
   863e5:	62 f1 a5 48 db da                               	vpandq zmm3,zmm11,zmm2
   863eb:	62 f1 e5 40 d4 ff                               	vpaddq zmm7,zmm19,zmm7
   863f1:	62 d1 fd 48 7f 5d f5                            	vmovdqa64 ZMMWORD PTR [r13-0x2c0],zmm3
   863f8:	62 b3 bd 40 3a d9 01                            	vinserti64x4 zmm3,zmm24,ymm17,0x1
   863ff:	62 e1 d5 48 db da                               	vpandq zmm19,zmm5,zmm2
   86405:	62 e1 95 48 db ca                               	vpandq zmm17,zmm13,zmm2
   8640b:	62 d1 fd 48 7f 7d f6                            	vmovdqa64 ZMMWORD PTR [r13-0x280],zmm7
   86412:	62 f1 fd 48 6f 7c 24 0e                         	vmovdqa64 zmm7,ZMMWORD PTR [rsp+0x380]
   8641a:	62 c1 fd 48 7f 5d f7                            	vmovdqa64 ZMMWORD PTR [r13-0x240],zmm19
   86421:	62 c1 fd 48 7f 55 f8                            	vmovdqa64 ZMMWORD PTR [r13-0x200],zmm18
   86428:	62 c1 fd 48 7f 4d f9                            	vmovdqa64 ZMMWORD PTR [r13-0x1c0],zmm17
   8642f:	62 c1 fd 48 7f 45 fa                            	vmovdqa64 ZMMWORD PTR [r13-0x180],zmm16
   86436:	62 51 fd 48 7f 7d fb                            	vmovdqa64 ZMMWORD PTR [r13-0x140],zmm15
   8643d:	62 93 c5 48 3a ed 01                            	vinserti64x4 zmm5,zmm7,ymm29,0x1
   86444:	62 f1 e5 48 6c fe                               	vpunpcklqdq zmm7,zmm3,zmm6
   8644a:	62 f1 e5 48 6d de                               	vpunpckhqdq zmm3,zmm3,zmm6
   86450:	62 91 d5 48 6c f6                               	vpunpcklqdq zmm6,zmm5,zmm30
   86456:	62 91 d5 48 6d ee                               	vpunpckhqdq zmm5,zmm5,zmm30
   8645c:	62 71 fd 48 6f c7                               	vmovdqa64 zmm8,zmm7
   86462:	62 71 fd 48 6f cb                               	vmovdqa64 zmm9,zmm3
   86468:	62 72 fd 48 7e c6                               	vpermt2q zmm8,zmm0,zmm6
   8646e:	62 f2 f5 48 7e fe                               	vpermt2q zmm7,zmm1,zmm6
   86474:	62 f2 f5 48 7e dd                               	vpermt2q zmm3,zmm1,zmm5
   8647a:	62 72 fd 48 7e cd                               	vpermt2q zmm9,zmm0,zmm5
   86480:	62 61 bd 48 db fa                               	vpandq zmm31,zmm8,zmm2
   86486:	62 d3 b5 48 71 e8 0c                            	vpshldq zmm5,zmm9,zmm8,0xc
   8648d:	62 53 c5 48 71 c1 18                            	vpshldq zmm8,zmm7,zmm9,0x18
   86494:	62 f3 e5 48 71 f7 24                            	vpshldq zmm6,zmm3,zmm7,0x24
   8649b:	62 41 fd 48 7f 7d ed                            	vmovdqa64 ZMMWORD PTR [r13-0x4c0],zmm31
   864a2:	62 61 d5 48 db c2                               	vpandq zmm24,zmm5,zmm2
   864a8:	62 61 bd 48 db f2                               	vpandq zmm30,zmm8,zmm2
   864ae:	62 61 cd 48 db ea                               	vpandq zmm29,zmm6,zmm2
   864b4:	62 f1 d5 48 73 d3 10                            	vpsrlq zmm5,zmm3,0x10
   864bb:	62 41 fd 48 7f 45 ee                            	vmovdqa64 ZMMWORD PTR [r13-0x480],zmm24
   864c2:	62 41 fd 48 7f 75 ef                            	vmovdqa64 ZMMWORD PTR [r13-0x440],zmm30
   864c9:	62 41 fd 48 7f 6d f0                            	vmovdqa64 ZMMWORD PTR [r13-0x400],zmm29
   864d0:	62 d1 fd 48 7f 6d f1                            	vmovdqa64 ZMMWORD PTR [r13-0x3c0],zmm5
   864d7:	4c 39 f8                                        	cmp    rax,r15
   864da:	0f 83 d0 5b 00 00                               	jae    8c0b0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x62d0>
   864e0:	62 93 dd 40 3a d9 01                            	vinserti64x4 zmm3,zmm20,ymm25,0x1
   864e7:	62 93 d5 40 3a fa 01                            	vinserti64x4 zmm7,zmm21,ymm26,0x1
   864ee:	62 13 cd 40 3a cb 01                            	vinserti64x4 zmm9,zmm22,ymm27,0x1
   864f5:	62 13 c5 40 3a d4 01                            	vinserti64x4 zmm10,zmm23,ymm28,0x1
   864fc:	66 b8 11 11                                     	mov    ax,0x1111
   86500:	49 89 d6                                        	mov    r14,rdx
   86503:	4c 89 c2                                        	mov    rdx,r8
   86506:	48 ff c2                                        	inc    rdx
   86509:	48 89 f7                                        	mov    rdi,rsi
   8650c:	62 71 e5 48 6d c7                               	vpunpckhqdq zmm8,zmm3,zmm7
   86512:	62 f1 e5 48 6c df                               	vpunpcklqdq zmm3,zmm3,zmm7
   86518:	62 51 b5 48 6d da                               	vpunpckhqdq zmm11,zmm9,zmm10
   8651e:	62 d1 b5 48 6c fa                               	vpunpcklqdq zmm7,zmm9,zmm10
   86524:	c5 fb 92 c8                                     	kmovd  k1,eax
   86528:	62 51 fd 48 6f e8                               	vmovdqa64 zmm13,zmm8
   8652e:	62 71 fd 48 6f cb                               	vmovdqa64 zmm9,zmm3
   86534:	62 52 f5 48 7e eb                               	vpermt2q zmm13,zmm1,zmm11
   8653a:	62 72 f5 48 7e cf                               	vpermt2q zmm9,zmm1,zmm7
   86540:	62 52 fd 48 7e c3                               	vpermt2q zmm8,zmm0,zmm11
   86546:	62 f2 fd 48 7e df                               	vpermt2q zmm3,zmm0,zmm7
   8654c:	62 51 7e c9 6f 19                               	vmovdqu32 zmm11{k1}{z},ZMMWORD PTR [r9]
   86552:	c5 fd 6f 05 06 14 f8 ff                         	vmovdqa ymm0,YMMWORD PTR [rip+0xfffffffffff81406]        # 7960 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x9c0>
   8655a:	62 f2 fd 48 59 0d 14 07 f8 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff80714]        # 6c78 <GCC_except_table711+0x188>
   86564:	62 53 95 48 71 d1 24                            	vpshldq zmm10,zmm13,zmm9,0x24
   8656b:	62 53 b5 48 71 c8 18                            	vpshldq zmm9,zmm9,zmm8,0x18
   86572:	62 f3 bd 48 71 fb 0c                            	vpshldq zmm7,zmm8,zmm3,0xc
   86579:	62 51 7e c9 6f 41 01                            	vmovdqu32 zmm8{k1}{z},ZMMWORD PTR [r9+0x40]
   86580:	62 d1 cd 48 73 d5 10                            	vpsrlq zmm6,zmm13,0x10
   86587:	49 83 e9 80                                     	sub    r9,0xffffffffffffff80
   8658b:	62 52 7d 48 7e d8                               	vpermt2d zmm11,zmm0,zmm8
   86591:	c4 62 25 45 05 06 12 f8 ff                      	vpsrlvd ymm8,ymm11,YMMWORD PTR [rip+0xfffffffffff81206]        # 77a0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x800>
   8659a:	62 f2 fd 48 59 05 cc 07 f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff807cc]        # 6d70 <GCC_except_table711+0x280>
   865a4:	c5 3d db 05 b4 11 f8 ff                         	vpand  ymm8,ymm8,YMMWORD PTR [rip+0xfffffffffff811b4]        # 7760 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x7c0>
   865ac:	c4 43 7d 39 c3 01                               	vextracti128 xmm11,ymm8,0x1
   865b2:	c4 41 39 eb c3                                  	vpor   xmm8,xmm8,xmm11
   865b7:	c4 41 79 70 d8 ee                               	vpshufd xmm11,xmm8,0xee
   865bd:	c4 41 39 eb c3                                  	vpor   xmm8,xmm8,xmm11
   865c2:	c4 41 79 70 d8 55                               	vpshufd xmm11,xmm8,0x55
   865c8:	c4 41 39 eb c3                                  	vpor   xmm8,xmm8,xmm11
   865cd:	c5 79 7e c0                                     	vmovd  eax,xmm8
   865d1:	c5 fb 92 c8                                     	kmovd  k1,eax
   865d5:	62 72 dd 59 64 1d 49 07 f8 ff                   	vpblendmq zmm11{k1},zmm4,QWORD BCST [rip+0xfffffffffff80749]        # 6d28 <GCC_except_table711+0x238>
   865df:	62 f2 fd 59 64 05 7f 07 f8 ff                   	vpblendmq zmm0{k1},zmm0,QWORD BCST [rip+0xfffffffffff8077f]        # 6d68 <GCC_except_table711+0x278>
   865e9:	62 71 fd c9 6f c2                               	vmovdqa64 zmm8{k1}{z},zmm2
   865ef:	62 f3 bd 48 25 da 6c                            	vpternlogq zmm3,zmm8,zmm2,0x6c
   865f6:	62 72 fe 48 38 e9                               	vpmovm2q zmm13,k1
   865fc:	62 f3 bd 48 25 fa 6c                            	vpternlogq zmm7,zmm8,zmm2,0x6c
   86603:	62 73 bd 48 25 ca 6c                            	vpternlogq zmm9,zmm8,zmm2,0x6c
   8660a:	62 73 bd 48 25 d2 6c                            	vpternlogq zmm10,zmm8,zmm2,0x6c
   86611:	62 d1 cd 48 ef f0                               	vpxorq zmm6,zmm6,zmm8
   86617:	62 d1 e5 48 fb dd                               	vpsubq zmm3,zmm3,zmm13
   8661d:	62 72 fd 48 59 2d 31 07 f8 ff                   	vpbroadcastq zmm13,QWORD PTR [rip+0xfffffffffff80731]        # 6d58 <GCC_except_table711+0x268>
   86627:	62 91 e5 48 fb df                               	vpsubq zmm3,zmm3,zmm31
   8662d:	62 01 05 00 ef ff                               	vpxord xmm31,xmm31,xmm31
   86633:	62 d1 e5 48 d4 db                               	vpaddq zmm3,zmm3,zmm11
   86639:	62 51 fd 48 6f de                               	vmovdqa64 zmm11,zmm14
   8663f:	62 e1 e5 48 db f2                               	vpandq zmm22,zmm3,zmm2
   86645:	62 f1 e5 48 72 e3 34                            	vpsraq zmm3,zmm3,0x34
   8664c:	62 f1 c5 48 d4 db                               	vpaddq zmm3,zmm7,zmm3
   86652:	62 f2 f5 59 64 3d f4 06 f8 ff                   	vpblendmq zmm7{k1},zmm1,QWORD BCST [rip+0xfffffffffff806f4]        # 6d50 <GCC_except_table711+0x260>
   8665c:	62 91 e5 48 fb d8                               	vpsubq zmm3,zmm3,zmm24
   86662:	62 f1 e5 48 d4 d8                               	vpaddq zmm3,zmm3,zmm0
   86668:	62 f2 fd 48 59 05 46 06 f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff80646]        # 6cb8 <GCC_except_table711+0x1c8>
   86672:	62 61 e5 48 db c2                               	vpandq zmm24,zmm3,zmm2
   86678:	62 f1 e5 48 72 e3 34                            	vpsraq zmm3,zmm3,0x34
   8667f:	62 f1 b5 48 d4 db                               	vpaddq zmm3,zmm9,zmm3
   86685:	62 91 e5 48 fb de                               	vpsubq zmm3,zmm3,zmm30
   8668b:	62 01 0d 00 ef f6                               	vpxord xmm30,xmm30,xmm30
   86691:	62 42 bd 40 b5 f6                               	vpmadd52huq zmm30,zmm24,zmm14
   86697:	62 f1 e5 48 d4 df                               	vpaddq zmm3,zmm3,zmm7
   8669d:	62 61 e5 48 db d2                               	vpandq zmm26,zmm3,zmm2
   866a3:	62 f1 e5 48 72 e3 34                            	vpsraq zmm3,zmm3,0x34
   866aa:	62 f2 fd 59 64 3d 2c 06 f8 ff                   	vpblendmq zmm7{k1},zmm0,QWORD BCST [rip+0xfffffffffff8062c]        # 6ce0 <GCC_except_table711+0x1f0>
   866b4:	62 f2 fd 48 59 05 3a 06 f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff8063a]        # 6cf8 <GCC_except_table711+0x208>
   866be:	62 f1 ad 48 d4 db                               	vpaddq zmm3,zmm10,zmm3
   866c4:	62 42 ad 40 b4 f6                               	vpmadd52luq zmm30,zmm26,zmm14
   866ca:	62 91 e5 48 fb dd                               	vpsubq zmm3,zmm3,zmm29
   866d0:	62 01 15 00 ef ed                               	vpxord xmm29,xmm29,xmm29
   866d6:	62 f1 e5 48 d4 df                               	vpaddq zmm3,zmm3,zmm7
   866dc:	62 f2 fd 59 64 3d ba 05 f8 ff                   	vpblendmq zmm7{k1},zmm0,QWORD BCST [rip+0xfffffffffff805ba]        # 6ca0 <GCC_except_table711+0x1b0>
   866e6:	c5 7e 7f a4 24 c0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xc0],ymm12
   866ef:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   866f7:	62 71 fd 48 6f 64 24 0c                         	vmovdqa64 zmm12,ZMMWORD PTR [rsp+0x300]
   866ff:	62 f1 fd 48 6f 4c 24 0b                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x2c0]
   86707:	62 f1 fd 48 6f 44 24 09                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x240]
   8670f:	48 8b 84 24 c0 03 00 00                         	mov    rax,QWORD PTR [rsp+0x3c0]
   86717:	4c 8b 9c 24 c0 07 00 00                         	mov    r11,QWORD PTR [rsp+0x7c0]
   8671f:	4c 8b a4 24 00 04 00 00                         	mov    r12,QWORD PTR [rsp+0x400]
   86727:	62 61 e5 48 db da                               	vpandq zmm27,zmm3,zmm2
   8672d:	62 f1 e5 48 72 e3 34                            	vpsraq zmm3,zmm3,0x34
   86734:	62 e2 fd 48 59 6c 24 1b                         	vpbroadcastq zmm21,QWORD PTR [rsp+0xd8]
   8673c:	62 62 fd 48 59 4c 24 19                         	vpbroadcastq zmm25,QWORD PTR [rsp+0xc8]
   86744:	62 e2 fd 48 59 7c 24 1a                         	vpbroadcastq zmm23,QWORD PTR [rsp+0xd0]
   8674c:	62 e2 fd 48 59 64 24 1c                         	vpbroadcastq zmm20,QWORD PTR [rsp+0xe0]
   86754:	62 f1 cd 48 d4 db                               	vpaddq zmm3,zmm6,zmm3
   8675a:	62 42 a5 40 b5 fe                               	vpmadd52huq zmm31,zmm27,zmm14
   86760:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   86764:	62 d2 cd 40 b5 f6                               	vpmadd52huq zmm6,zmm22,zmm14
   8676a:	62 f1 e5 48 fb dd                               	vpsubq zmm3,zmm3,zmm5
   86770:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   86774:	62 d2 ad 40 b5 ee                               	vpmadd52huq zmm5,zmm26,zmm14
   8677a:	62 d2 bd 40 b4 f6                               	vpmadd52luq zmm6,zmm24,zmm14
   86780:	62 d2 a5 40 b4 ee                               	vpmadd52luq zmm5,zmm27,zmm14
   86786:	62 f1 e5 48 d4 df                               	vpaddq zmm3,zmm3,zmm7
   8678c:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   86790:	62 61 e5 48 db e2                               	vpandq zmm28,zmm3,zmm2
   86796:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   8679a:	62 d2 cd 40 b4 de                               	vpmadd52luq zmm3,zmm22,zmm14
   867a0:	62 42 9d 40 b4 fe                               	vpmadd52luq zmm31,zmm28,zmm14
   867a6:	62 42 9d 40 b5 ee                               	vpmadd52huq zmm29,zmm28,zmm14
   867ac:	62 71 fd 48 6f 74 24 0a                         	vmovdqa64 zmm14,ZMMWORD PTR [rsp+0x280]
   867b4:	62 d2 e5 48 b4 fd                               	vpmadd52luq zmm7,zmm3,zmm13
   867ba:	62 f1 e5 48 d4 da                               	vpaddq zmm3,zmm3,zmm2
   867c0:	62 f1 e5 48 73 d3 34                            	vpsrlq zmm3,zmm3,0x34
   867c7:	62 22 c5 48 b5 fd                               	vpmadd52huq zmm31,zmm7,zmm21
   867cd:	62 02 c5 48 b5 f1                               	vpmadd52huq zmm30,zmm7,zmm25
   867d3:	62 b2 c5 48 b5 ef                               	vpmadd52huq zmm5,zmm7,zmm23
   867d9:	62 f2 c5 48 b5 dc                               	vpmadd52huq zmm3,zmm7,zmm4
   867df:	62 92 c5 48 b4 f1                               	vpmadd52luq zmm6,zmm7,zmm25
   867e5:	62 22 c5 48 b5 ec                               	vpmadd52huq zmm29,zmm7,zmm20
   867eb:	62 22 c5 48 b4 fc                               	vpmadd52luq zmm31,zmm7,zmm20
   867f1:	62 f1 cd 48 d4 db                               	vpaddq zmm3,zmm6,zmm3
   867f7:	62 22 c5 48 b4 f7                               	vpmadd52luq zmm30,zmm7,zmm23
   867fd:	62 b2 c5 48 b4 ed                               	vpmadd52luq zmm5,zmm7,zmm21
   86803:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   86807:	62 42 a5 40 b5 ec                               	vpmadd52huq zmm29,zmm27,zmm12
   8680d:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   86811:	62 d2 cd 40 b4 dc                               	vpmadd52luq zmm3,zmm22,zmm12
   86817:	62 42 ad 40 b5 fc                               	vpmadd52huq zmm31,zmm26,zmm12
   8681d:	62 42 cd 40 b5 f4                               	vpmadd52huq zmm30,zmm22,zmm12
   86823:	62 d2 bd 40 b5 ec                               	vpmadd52huq zmm5,zmm24,zmm12
   86829:	62 42 9d 40 b4 ec                               	vpmadd52luq zmm29,zmm28,zmm12
   8682f:	62 d2 e5 48 b4 f5                               	vpmadd52luq zmm6,zmm3,zmm13
   86835:	62 f1 e5 48 d4 da                               	vpaddq zmm3,zmm3,zmm2
   8683b:	62 f1 e5 48 73 d3 34                            	vpsrlq zmm3,zmm3,0x34
   86842:	62 42 a5 40 b4 fc                               	vpmadd52luq zmm31,zmm27,zmm12
   86848:	62 42 bd 40 b4 f4                               	vpmadd52luq zmm30,zmm24,zmm12
   8684e:	62 d2 ad 40 b4 ec                               	vpmadd52luq zmm5,zmm26,zmm12
   86854:	62 f2 cd 48 b5 dc                               	vpmadd52huq zmm3,zmm6,zmm4
   8685a:	62 22 cd 48 b5 ed                               	vpmadd52huq zmm29,zmm6,zmm21
   86860:	62 22 cd 48 b5 ff                               	vpmadd52huq zmm31,zmm6,zmm23
   86866:	62 92 cd 48 b5 e9                               	vpmadd52huq zmm5,zmm6,zmm25
   8686c:	62 02 cd 48 b4 f1                               	vpmadd52luq zmm30,zmm6,zmm25
   86872:	62 22 cd 48 b4 ec                               	vpmadd52luq zmm29,zmm6,zmm20
   86878:	62 22 cd 48 b4 fd                               	vpmadd52luq zmm31,zmm6,zmm21
   8687e:	62 f1 8d 40 d4 db                               	vpaddq zmm3,zmm30,zmm3
   86884:	62 b2 cd 48 b4 ef                               	vpmadd52luq zmm5,zmm6,zmm23
   8688a:	62 01 0d 00 ef f6                               	vpxord xmm30,xmm30,xmm30
   86890:	62 42 9d 40 b5 f4                               	vpmadd52huq zmm30,zmm28,zmm12
   86896:	62 d2 cd 40 b4 de                               	vpmadd52luq zmm3,zmm22,zmm14
   8689c:	62 42 ad 40 b5 ee                               	vpmadd52huq zmm29,zmm26,zmm14
   868a2:	62 42 bd 40 b5 fe                               	vpmadd52huq zmm31,zmm24,zmm14
   868a8:	62 d2 cd 40 b5 ee                               	vpmadd52huq zmm5,zmm22,zmm14
   868ae:	62 22 cd 48 b5 f4                               	vpmadd52huq zmm30,zmm6,zmm20
   868b4:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   868b8:	62 d2 e5 48 b4 f5                               	vpmadd52luq zmm6,zmm3,zmm13
   868be:	62 f1 e5 48 d4 da                               	vpaddq zmm3,zmm3,zmm2
   868c4:	62 42 a5 40 b4 ee                               	vpmadd52luq zmm29,zmm27,zmm14
   868ca:	62 f1 e5 48 73 d3 34                            	vpsrlq zmm3,zmm3,0x34
   868d1:	62 42 ad 40 b4 fe                               	vpmadd52luq zmm31,zmm26,zmm14
   868d7:	62 d2 bd 40 b4 ee                               	vpmadd52luq zmm5,zmm24,zmm14
   868dd:	62 42 a5 40 b5 f6                               	vpmadd52huq zmm30,zmm27,zmm14
   868e3:	62 f2 cd 48 b5 dc                               	vpmadd52huq zmm3,zmm6,zmm4
   868e9:	62 22 cd 48 b5 ef                               	vpmadd52huq zmm29,zmm6,zmm23
   868ef:	62 02 cd 48 b5 f9                               	vpmadd52huq zmm31,zmm6,zmm25
   868f5:	62 92 cd 48 b4 e9                               	vpmadd52luq zmm5,zmm6,zmm25
   868fb:	62 42 9d 40 b4 f6                               	vpmadd52luq zmm30,zmm28,zmm14
   86901:	62 22 cd 48 b4 ed                               	vpmadd52luq zmm29,zmm6,zmm21
   86907:	62 22 cd 48 b4 ff                               	vpmadd52luq zmm31,zmm6,zmm23
   8690d:	62 f1 d5 48 d4 db                               	vpaddq zmm3,zmm5,zmm3
   86913:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   86917:	62 d2 9d 40 b5 ee                               	vpmadd52huq zmm5,zmm28,zmm14
   8691d:	62 22 cd 48 b5 f5                               	vpmadd52huq zmm30,zmm6,zmm21
   86923:	62 f2 cd 40 b4 d9                               	vpmadd52luq zmm3,zmm22,zmm1
   86929:	62 62 bd 40 b5 e9                               	vpmadd52huq zmm29,zmm24,zmm1
   8692f:	62 62 cd 40 b5 f9                               	vpmadd52huq zmm31,zmm22,zmm1
   86935:	62 22 cd 48 b4 f4                               	vpmadd52luq zmm30,zmm6,zmm20
   8693b:	62 b2 cd 48 b5 ec                               	vpmadd52huq zmm5,zmm6,zmm20
   86941:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   86945:	62 d2 e5 48 b4 f5                               	vpmadd52luq zmm6,zmm3,zmm13
   8694b:	62 f1 e5 48 d4 da                               	vpaddq zmm3,zmm3,zmm2
   86951:	62 62 ad 40 b4 e9                               	vpmadd52luq zmm29,zmm26,zmm1
   86957:	62 f1 e5 48 73 d3 34                            	vpsrlq zmm3,zmm3,0x34
   8695e:	62 62 bd 40 b4 f9                               	vpmadd52luq zmm31,zmm24,zmm1
   86964:	62 62 ad 40 b5 f1                               	vpmadd52huq zmm30,zmm26,zmm1
   8696a:	62 f2 a5 40 b5 e9                               	vpmadd52huq zmm5,zmm27,zmm1
   86970:	62 f2 cd 48 b5 dc                               	vpmadd52huq zmm3,zmm6,zmm4
   86976:	62 02 cd 48 b5 e9                               	vpmadd52huq zmm29,zmm6,zmm25
   8697c:	62 02 cd 48 b4 f9                               	vpmadd52luq zmm31,zmm6,zmm25
   86982:	62 62 a5 40 b4 f1                               	vpmadd52luq zmm30,zmm27,zmm1
   86988:	62 f2 9d 40 b4 e9                               	vpmadd52luq zmm5,zmm28,zmm1
   8698e:	62 22 cd 48 b4 ef                               	vpmadd52luq zmm29,zmm6,zmm23
   86994:	62 f1 85 40 d4 db                               	vpaddq zmm3,zmm31,zmm3
   8699a:	62 01 05 00 ef ff                               	vpxord xmm31,xmm31,xmm31
   869a0:	62 62 9d 40 b5 f9                               	vpmadd52huq zmm31,zmm28,zmm1
   869a6:	62 22 cd 48 b5 f7                               	vpmadd52huq zmm30,zmm6,zmm23
   869ac:	62 b2 cd 48 b5 ed                               	vpmadd52huq zmm5,zmm6,zmm21
   869b2:	62 f2 cd 40 b4 d8                               	vpmadd52luq zmm3,zmm22,zmm0
   869b8:	62 62 cd 40 b5 e8                               	vpmadd52huq zmm29,zmm22,zmm0
   869be:	62 22 cd 48 b5 fc                               	vpmadd52huq zmm31,zmm6,zmm20
   869c4:	62 22 cd 48 b4 f5                               	vpmadd52luq zmm30,zmm6,zmm21
   869ca:	62 b2 cd 48 b4 ec                               	vpmadd52luq zmm5,zmm6,zmm20
   869d0:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   869d4:	62 f2 9d 40 b5 f0                               	vpmadd52huq zmm6,zmm28,zmm0
   869da:	62 d2 e5 48 b4 fd                               	vpmadd52luq zmm7,zmm3,zmm13
   869e0:	62 62 bd 40 b4 e8                               	vpmadd52luq zmm29,zmm24,zmm0
   869e6:	62 62 a5 40 b5 f8                               	vpmadd52huq zmm31,zmm27,zmm0
   869ec:	62 62 bd 40 b5 f0                               	vpmadd52huq zmm30,zmm24,zmm0
   869f2:	62 f2 ad 40 b5 e8                               	vpmadd52huq zmm5,zmm26,zmm0
   869f8:	62 01 3d 00 ef c0                               	vpxord xmm24,xmm24,xmm24
   869fe:	62 22 fd 48 b5 c2                               	vpmadd52huq zmm24,zmm0,zmm18
   86a04:	62 f1 bd 48 73 f7 04                            	vpsllq zmm8,zmm7,0x4
   86a0b:	62 62 9d 40 b4 f8                               	vpmadd52luq zmm31,zmm28,zmm0
   86a11:	62 62 fd 48 59 25 2d 02 f8 ff                   	vpbroadcastq zmm28,QWORD PTR [rip+0xfffffffffff8022d]        # 6c48 <GCC_except_table711+0x158>
   86a1b:	62 62 ad 40 b4 f0                               	vpmadd52luq zmm30,zmm26,zmm0
   86a21:	62 f2 a5 40 b4 e8                               	vpmadd52luq zmm5,zmm27,zmm0
   86a27:	62 62 fd 48 59 1d cf 02 f8 ff                   	vpbroadcastq zmm27,QWORD PTR [rip+0xfffffffffff802cf]        # 6d00 <GCC_except_table711+0x210>
   86a31:	62 91 c5 48 db fc                               	vpandq zmm7,zmm7,zmm28
   86a37:	62 91 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm28
   86a3d:	62 02 c5 48 b5 f1                               	vpmadd52huq zmm30,zmm7,zmm25
   86a43:	62 b2 c5 48 b5 ef                               	vpmadd52huq zmm5,zmm7,zmm23
   86a49:	62 22 c5 48 b5 fd                               	vpmadd52huq zmm31,zmm7,zmm21
   86a4f:	62 02 c5 48 b4 e9                               	vpmadd52luq zmm29,zmm7,zmm25
   86a55:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   86a5c:	62 b2 c5 48 b5 f4                               	vpmadd52huq zmm6,zmm7,zmm20
   86a62:	62 01 35 00 ef c9                               	vpxord xmm25,xmm25,xmm25
   86a68:	62 22 f5 48 b5 cb                               	vpmadd52huq zmm25,zmm1,zmm19
   86a6e:	62 f2 bd 48 b5 dc                               	vpmadd52huq zmm3,zmm8,zmm4
   86a74:	62 22 c5 48 b4 f7                               	vpmadd52luq zmm30,zmm7,zmm23
   86a7a:	62 22 c5 48 b4 fc                               	vpmadd52luq zmm31,zmm7,zmm20
   86a80:	62 b2 c5 48 b4 ed                               	vpmadd52luq zmm5,zmm7,zmm21
   86a86:	62 91 c5 48 73 f5 04                            	vpsllq zmm7,zmm29,0x4
   86a8d:	62 f1 cd 48 73 f6 04                            	vpsllq zmm6,zmm6,0x4
   86a94:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   86a9a:	62 22 fd 48 b4 cb                               	vpmadd52luq zmm25,zmm0,zmm19
   86aa0:	62 a2 fd 48 b5 eb                               	vpmadd52huq zmm21,zmm0,zmm19
   86aa6:	62 91 c5 48 db fb                               	vpandq zmm7,zmm7,zmm27
   86aac:	62 f1 c5 48 d4 db                               	vpaddq zmm3,zmm7,zmm3
   86ab2:	62 91 c5 48 73 d5 30                            	vpsrlq zmm7,zmm29,0x30
   86ab9:	62 61 fd 28 6f 2d 1d 0d f8 ff                   	vmovdqa64 ymm29,YMMWORD PTR [rip+0xfffffffffff80d1d]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   86ac3:	62 91 bd 48 73 f6 04                            	vpsllq zmm8,zmm30,0x4
   86aca:	62 91 b5 48 73 d6 30                            	vpsrlq zmm9,zmm30,0x30
   86ad1:	62 f1 8d 40 73 d3 34                            	vpsrlq zmm30,zmm3,0x34
   86ad8:	62 f1 ad 48 73 f5 04                            	vpsllq zmm10,zmm5,0x4
   86adf:	62 91 cd 40 73 f7 04                            	vpsllq zmm22,zmm31,0x4
   86ae6:	62 f1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm5,0x30
   86aed:	62 91 dd 40 73 d7 30                            	vpsrlq zmm20,zmm31,0x30
   86af4:	62 f1 e5 48 db da                               	vpandq zmm3,zmm3,zmm2
   86afa:	62 11 bd 48 db c3                               	vpandq zmm8,zmm8,zmm27
   86b00:	62 f1 8d 40 d4 ff                               	vpaddq zmm7,zmm30,zmm7
   86b06:	62 11 ad 48 db d3                               	vpandq zmm10,zmm10,zmm27
   86b0c:	62 b1 cd 48 d4 f4                               	vpaddq zmm6,zmm6,zmm20
   86b12:	62 d1 fd 48 7f 5d fc                            	vmovdqa64 ZMMWORD PTR [r13-0x100],zmm3
   86b19:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   86b1d:	62 b2 a5 48 b4 db                               	vpmadd52luq zmm3,zmm11,zmm19
   86b23:	62 d1 c5 48 d4 f8                               	vpaddq zmm7,zmm7,zmm8
   86b29:	62 51 ad 48 d4 c9                               	vpaddq zmm9,zmm10,zmm9
   86b2f:	62 11 cd 40 db d3                               	vpandq zmm10,zmm22,zmm27
   86b35:	62 f1 bd 48 73 d7 34                            	vpsrlq zmm8,zmm7,0x34
   86b3c:	62 f1 ad 48 d4 ed                               	vpaddq zmm5,zmm10,zmm5
   86b42:	62 f1 c5 48 db fa                               	vpandq zmm7,zmm7,zmm2
   86b48:	62 51 bd 48 d4 c1                               	vpaddq zmm8,zmm8,zmm9
   86b4e:	62 d1 fd 48 7f 7d fd                            	vmovdqa64 ZMMWORD PTR [r13-0xc0],zmm7
   86b55:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   86b59:	62 b2 a5 48 b5 fb                               	vpmadd52huq zmm7,zmm11,zmm19
   86b5f:	62 d1 b5 48 73 d0 34                            	vpsrlq zmm9,zmm8,0x34
   86b66:	62 71 bd 48 db c2                               	vpandq zmm8,zmm8,zmm2
   86b6c:	62 f1 b5 48 d4 ed                               	vpaddq zmm5,zmm9,zmm5
   86b72:	62 51 fd 48 7f 45 fe                            	vmovdqa64 ZMMWORD PTR [r13-0x80],zmm8
   86b79:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   86b7e:	62 52 e5 48 b4 c5                               	vpmadd52luq zmm8,zmm3,zmm13
   86b84:	62 f1 e5 48 d4 da                               	vpaddq zmm3,zmm3,zmm2
   86b8a:	62 f1 b5 48 73 d5 34                            	vpsrlq zmm9,zmm5,0x34
   86b91:	62 f1 d5 48 db ea                               	vpandq zmm5,zmm5,zmm2
   86b97:	62 f1 e5 48 73 d3 34                            	vpsrlq zmm3,zmm3,0x34
   86b9e:	62 f1 b5 48 d4 f6                               	vpaddq zmm6,zmm9,zmm6
   86ba4:	62 d1 fd 48 7f 6d ff                            	vmovdqa64 ZMMWORD PTR [r13-0x40],zmm5
   86bab:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   86baf:	62 b2 8d 48 b5 eb                               	vpmadd52huq zmm5,zmm14,zmm19
   86bb5:	62 b2 9d 48 b4 fb                               	vpmadd52luq zmm7,zmm12,zmm19
   86bbb:	62 d1 fd 48 7f 75 00                            	vmovdqa64 ZMMWORD PTR [r13+0x0],zmm6
   86bc2:	62 61 fe 28 7f 6c 24 06                         	vmovdqu64 YMMWORD PTR [rsp+0xc0],ymm29
   86bca:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   86bd2:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   86bd6:	62 b2 9d 48 b5 f3                               	vpmadd52huq zmm6,zmm12,zmm19
   86bdc:	49 81 c5 40 06 00 00                            	add    r13,0x640
   86be3:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
   86be7:	62 e2 fd 48 59 64 24 1b                         	vpbroadcastq zmm20,QWORD PTR [rsp+0xd8]
   86bef:	62 e2 fd 48 59 74 24 1a                         	vpbroadcastq zmm22,QWORD PTR [rsp+0xd0]
   86bf7:	62 e2 fd 48 59 7c 24 19                         	vpbroadcastq zmm23,QWORD PTR [rsp+0xc8]
   86bff:	62 f2 bd 48 b5 dc                               	vpmadd52huq zmm3,zmm8,zmm4
   86c05:	62 b2 f5 48 b4 eb                               	vpmadd52luq zmm5,zmm1,zmm19
   86c0b:	62 b2 8d 48 b4 f3                               	vpmadd52luq zmm6,zmm14,zmm19
   86c11:	62 e2 fd 48 59 5c 24 1c                         	vpbroadcastq zmm19,QWORD PTR [rsp+0xe0]
   86c19:	62 22 bd 48 b5 cc                               	vpmadd52huq zmm25,zmm8,zmm20
   86c1f:	62 b2 bd 48 b5 ee                               	vpmadd52huq zmm5,zmm8,zmm22
   86c25:	62 b2 bd 48 b5 f7                               	vpmadd52huq zmm6,zmm8,zmm23
   86c2b:	62 b2 bd 48 b4 ff                               	vpmadd52luq zmm7,zmm8,zmm23
   86c31:	62 a2 bd 48 b5 eb                               	vpmadd52huq zmm21,zmm8,zmm19
   86c37:	62 22 bd 48 b4 cb                               	vpmadd52luq zmm25,zmm8,zmm19
   86c3d:	62 b2 bd 48 b4 ec                               	vpmadd52luq zmm5,zmm8,zmm20
   86c43:	62 b2 bd 48 b4 f6                               	vpmadd52luq zmm6,zmm8,zmm22
   86c49:	62 f1 c5 48 d4 db                               	vpaddq zmm3,zmm7,zmm3
   86c4f:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   86c53:	62 b2 a5 48 b4 da                               	vpmadd52luq zmm3,zmm11,zmm18
   86c59:	62 a2 f5 48 b5 ea                               	vpmadd52huq zmm21,zmm1,zmm18
   86c5f:	62 22 8d 48 b5 ca                               	vpmadd52huq zmm25,zmm14,zmm18
   86c65:	62 b2 9d 48 b5 ea                               	vpmadd52huq zmm5,zmm12,zmm18
   86c6b:	62 b2 a5 48 b5 f2                               	vpmadd52huq zmm6,zmm11,zmm18
   86c71:	62 d2 e5 48 b4 fd                               	vpmadd52luq zmm7,zmm3,zmm13
   86c77:	62 f1 e5 48 d4 da                               	vpaddq zmm3,zmm3,zmm2
   86c7d:	62 f1 e5 48 73 d3 34                            	vpsrlq zmm3,zmm3,0x34
   86c84:	62 a2 fd 48 b4 ea                               	vpmadd52luq zmm21,zmm0,zmm18
   86c8a:	62 22 f5 48 b4 ca                               	vpmadd52luq zmm25,zmm1,zmm18
   86c90:	62 b2 8d 48 b4 ea                               	vpmadd52luq zmm5,zmm14,zmm18
   86c96:	62 b2 9d 48 b4 f2                               	vpmadd52luq zmm6,zmm12,zmm18
   86c9c:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   86ca2:	62 a2 fd 48 b5 d1                               	vpmadd52huq zmm18,zmm0,zmm17
   86ca8:	62 f2 c5 48 b5 dc                               	vpmadd52huq zmm3,zmm7,zmm4
   86cae:	62 22 c5 48 b5 c3                               	vpmadd52huq zmm24,zmm7,zmm19
   86cb4:	62 a2 c5 48 b5 ec                               	vpmadd52huq zmm21,zmm7,zmm20
   86cba:	62 22 c5 48 b5 ce                               	vpmadd52huq zmm25,zmm7,zmm22
   86cc0:	62 b2 c5 48 b5 ef                               	vpmadd52huq zmm5,zmm7,zmm23
   86cc6:	62 b2 c5 48 b4 f7                               	vpmadd52luq zmm6,zmm7,zmm23
   86ccc:	62 22 f5 48 b5 c1                               	vpmadd52huq zmm24,zmm1,zmm17
   86cd2:	62 a2 c5 48 b4 eb                               	vpmadd52luq zmm21,zmm7,zmm19
   86cd8:	62 22 c5 48 b4 cc                               	vpmadd52luq zmm25,zmm7,zmm20
   86cde:	62 b2 c5 48 b4 ee                               	vpmadd52luq zmm5,zmm7,zmm22
   86ce4:	62 f1 cd 48 d4 db                               	vpaddq zmm3,zmm6,zmm3
   86cea:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   86cee:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   86cf2:	62 b2 a5 48 b4 d9                               	vpmadd52luq zmm3,zmm11,zmm17
   86cf8:	62 22 fd 48 b4 c1                               	vpmadd52luq zmm24,zmm0,zmm17
   86cfe:	62 a2 8d 48 b5 e9                               	vpmadd52huq zmm21,zmm14,zmm17
   86d04:	62 22 9d 48 b5 c9                               	vpmadd52huq zmm25,zmm12,zmm17
   86d0a:	62 b2 a5 48 b5 e9                               	vpmadd52huq zmm5,zmm11,zmm17
   86d10:	62 d2 e5 48 b4 f5                               	vpmadd52luq zmm6,zmm3,zmm13
   86d16:	62 f1 e5 48 d4 da                               	vpaddq zmm3,zmm3,zmm2
   86d1c:	62 f1 e5 48 73 d3 34                            	vpsrlq zmm3,zmm3,0x34
   86d23:	62 a2 f5 48 b4 e9                               	vpmadd52luq zmm21,zmm1,zmm17
   86d29:	62 22 8d 48 b4 c9                               	vpmadd52luq zmm25,zmm14,zmm17
   86d2f:	62 b2 9d 48 b4 e9                               	vpmadd52luq zmm5,zmm12,zmm17
   86d35:	62 22 cd 48 b5 c4                               	vpmadd52huq zmm24,zmm6,zmm20
   86d3b:	62 f2 cd 48 b5 dc                               	vpmadd52huq zmm3,zmm6,zmm4
   86d41:	62 a2 cd 48 b5 d3                               	vpmadd52huq zmm18,zmm6,zmm19
   86d47:	62 a2 cd 48 b5 ee                               	vpmadd52huq zmm21,zmm6,zmm22
   86d4d:	62 22 cd 48 b5 cf                               	vpmadd52huq zmm25,zmm6,zmm23
   86d53:	62 b2 cd 48 b4 ef                               	vpmadd52luq zmm5,zmm6,zmm23
   86d59:	62 22 cd 48 b4 c3                               	vpmadd52luq zmm24,zmm6,zmm19
   86d5f:	62 a2 f5 48 b5 d0                               	vpmadd52huq zmm18,zmm1,zmm16
   86d65:	62 a2 cd 48 b4 ec                               	vpmadd52luq zmm21,zmm6,zmm20
   86d6b:	62 22 cd 48 b4 ce                               	vpmadd52luq zmm25,zmm6,zmm22
   86d71:	62 f1 d5 48 d4 db                               	vpaddq zmm3,zmm5,zmm3
   86d77:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   86d7b:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   86d7f:	62 b2 fd 48 b5 e8                               	vpmadd52huq zmm5,zmm0,zmm16
   86d85:	62 b2 a5 48 b4 d8                               	vpmadd52luq zmm3,zmm11,zmm16
   86d8b:	62 22 8d 48 b5 c0                               	vpmadd52huq zmm24,zmm14,zmm16
   86d91:	62 a2 fd 48 b4 d0                               	vpmadd52luq zmm18,zmm0,zmm16
   86d97:	62 a2 9d 48 b5 e8                               	vpmadd52huq zmm21,zmm12,zmm16
   86d9d:	62 22 a5 48 b5 c8                               	vpmadd52huq zmm25,zmm11,zmm16
   86da3:	62 d2 e5 48 b4 f5                               	vpmadd52luq zmm6,zmm3,zmm13
   86da9:	62 22 f5 48 b4 c0                               	vpmadd52luq zmm24,zmm1,zmm16
   86daf:	62 f1 e5 48 d4 da                               	vpaddq zmm3,zmm3,zmm2
   86db5:	62 f1 e5 48 73 d3 34                            	vpsrlq zmm3,zmm3,0x34
   86dbc:	62 a2 8d 48 b4 e8                               	vpmadd52luq zmm21,zmm14,zmm16
   86dc2:	62 22 9d 48 b4 c8                               	vpmadd52luq zmm25,zmm12,zmm16
   86dc8:	62 a2 cd 48 b5 d4                               	vpmadd52huq zmm18,zmm6,zmm20
   86dce:	62 22 cd 48 b5 c6                               	vpmadd52huq zmm24,zmm6,zmm22
   86dd4:	62 f2 cd 48 b5 dc                               	vpmadd52huq zmm3,zmm6,zmm4
   86dda:	62 b2 cd 48 b5 eb                               	vpmadd52huq zmm5,zmm6,zmm19
   86de0:	62 a2 cd 48 b5 ef                               	vpmadd52huq zmm21,zmm6,zmm23
   86de6:	62 22 cd 48 b4 cf                               	vpmadd52luq zmm25,zmm6,zmm23
   86dec:	62 a2 cd 48 b4 d3                               	vpmadd52luq zmm18,zmm6,zmm19
   86df2:	62 22 cd 48 b4 c4                               	vpmadd52luq zmm24,zmm6,zmm20
   86df8:	62 d2 f5 48 b5 ef                               	vpmadd52huq zmm5,zmm1,zmm15
   86dfe:	62 a2 cd 48 b4 ee                               	vpmadd52luq zmm21,zmm6,zmm22
   86e04:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   86e08:	62 d2 fd 48 b5 f7                               	vpmadd52huq zmm6,zmm0,zmm15
   86e0e:	62 f1 b5 40 d4 db                               	vpaddq zmm3,zmm25,zmm3
   86e14:	62 d2 a5 48 b4 df                               	vpmadd52luq zmm3,zmm11,zmm15
   86e1a:	62 c2 8d 48 b5 d7                               	vpmadd52huq zmm18,zmm14,zmm15
   86e20:	62 42 9d 48 b5 c7                               	vpmadd52huq zmm24,zmm12,zmm15
   86e26:	62 d2 fd 48 b4 ef                               	vpmadd52luq zmm5,zmm0,zmm15
   86e2c:	62 c2 a5 48 b5 ef                               	vpmadd52huq zmm21,zmm11,zmm15
   86e32:	62 d2 e5 48 b4 fd                               	vpmadd52luq zmm7,zmm3,zmm13
   86e38:	62 c2 f5 48 b4 d7                               	vpmadd52luq zmm18,zmm1,zmm15
   86e3e:	62 42 8d 48 b4 c7                               	vpmadd52luq zmm24,zmm14,zmm15
   86e44:	62 91 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm28
   86e4a:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   86e51:	62 c2 9d 48 b4 ef                               	vpmadd52luq zmm21,zmm12,zmm15
   86e57:	62 11 fd 28 6f fd                               	vmovdqa64 ymm15,ymm29
   86e5d:	62 f1 bd 48 73 f7 04                            	vpsllq zmm8,zmm7,0x4
   86e64:	62 91 c5 48 db fc                               	vpandq zmm7,zmm7,zmm28
   86e6a:	62 a2 c5 48 b5 d6                               	vpmadd52huq zmm18,zmm7,zmm22
   86e70:	62 b2 c5 48 b5 ec                               	vpmadd52huq zmm5,zmm7,zmm20
   86e76:	62 22 c5 48 b5 c7                               	vpmadd52huq zmm24,zmm7,zmm23
   86e7c:	62 b2 c5 48 b5 f3                               	vpmadd52huq zmm6,zmm7,zmm19
   86e82:	62 f2 bd 48 b5 dc                               	vpmadd52huq zmm3,zmm8,zmm4
   86e88:	62 a2 c5 48 b4 ef                               	vpmadd52luq zmm21,zmm7,zmm23
   86e8e:	62 a2 c5 48 b4 d4                               	vpmadd52luq zmm18,zmm7,zmm20
   86e94:	62 b2 c5 48 b4 eb                               	vpmadd52luq zmm5,zmm7,zmm19
   86e9a:	62 22 c5 48 b4 c6                               	vpmadd52luq zmm24,zmm7,zmm22
   86ea0:	62 f1 cd 48 73 f6 04                            	vpsllq zmm6,zmm6,0x4
   86ea7:	62 b1 c5 48 73 f5 04                            	vpsllq zmm7,zmm21,0x4
   86eae:	62 b1 f5 48 73 d5 30                            	vpsrlq zmm1,zmm21,0x30
   86eb5:	62 91 c5 48 db fb                               	vpandq zmm7,zmm7,zmm27
   86ebb:	62 f1 c5 48 d4 db                               	vpaddq zmm3,zmm7,zmm3
   86ec1:	62 f1 b5 48 73 f5 04                            	vpsllq zmm9,zmm5,0x4
   86ec8:	62 b1 bd 48 73 f2 04                            	vpsllq zmm8,zmm18,0x4
   86ecf:	62 f1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm5,0x30
   86ed6:	62 91 c5 48 73 d0 30                            	vpsrlq zmm7,zmm24,0x30
   86edd:	62 b1 fd 48 73 d2 30                            	vpsrlq zmm0,zmm18,0x30
   86ee4:	62 61 e5 48 db e2                               	vpandq zmm28,zmm3,zmm2
   86eea:	62 11 bd 48 db c3                               	vpandq zmm8,zmm8,zmm27
   86ef0:	62 11 b5 48 db cb                               	vpandq zmm9,zmm9,zmm27
   86ef6:	62 f1 cd 48 d4 ed                               	vpaddq zmm5,zmm6,zmm5
   86efc:	62 f1 cd 48 73 d3 34                            	vpsrlq zmm6,zmm3,0x34
   86f03:	62 f1 bd 48 d4 ff                               	vpaddq zmm7,zmm8,zmm7
   86f09:	62 71 b5 48 d4 c0                               	vpaddq zmm8,zmm9,zmm0
   86f0f:	62 91 fd 48 73 f0 04                            	vpsllq zmm0,zmm24,0x4
   86f16:	62 f1 cd 48 d4 f1                               	vpaddq zmm6,zmm6,zmm1
   86f1c:	62 11 fd 48 db cb                               	vpandq zmm9,zmm0,zmm27
   86f22:	62 d1 cd 48 d4 f1                               	vpaddq zmm6,zmm6,zmm9
   86f28:	62 f1 b5 48 73 d6 34                            	vpsrlq zmm9,zmm6,0x34
   86f2f:	62 61 cd 48 db da                               	vpandq zmm27,zmm6,zmm2
   86f35:	62 f1 b5 48 d4 ff                               	vpaddq zmm7,zmm9,zmm7
   86f3b:	62 f1 b5 48 73 d7 34                            	vpsrlq zmm9,zmm7,0x34
   86f42:	62 61 c5 48 db ca                               	vpandq zmm25,zmm7,zmm2
   86f48:	62 51 b5 48 d4 c0                               	vpaddq zmm8,zmm9,zmm8
   86f4e:	62 d1 b5 48 73 d0 34                            	vpsrlq zmm9,zmm8,0x34
   86f55:	62 61 bd 48 db c2                               	vpandq zmm24,zmm8,zmm2
   86f5b:	62 61 b5 48 d4 d5                               	vpaddq zmm26,zmm9,zmm5
   86f61:	49 39 f3                                        	cmp    r11,rsi
   86f64:	0f 85 d6 ef ff ff                               	jne    85f40 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x160>
   86f6a:	49 89 d5                                        	mov    r13,rdx
   86f6d:	48 8b 54 24 30                                  	mov    rdx,QWORD PTR [rsp+0x30]
   86f72:	4c 8b 84 24 c0 03 00 00                         	mov    r8,QWORD PTR [rsp+0x3c0]
   86f7a:	48 8b 9c 24 88 00 00 00                         	mov    rbx,QWORD PTR [rsp+0x88]
   86f82:	62 61 fd 48 7f 64 24 2e                         	vmovdqa64 ZMMWORD PTR [rsp+0xb80],zmm28
   86f8a:	62 61 fd 48 7f 5c 24 2f                         	vmovdqa64 ZMMWORD PTR [rsp+0xbc0],zmm27
   86f92:	62 61 fd 48 7f 4c 24 30                         	vmovdqa64 ZMMWORD PTR [rsp+0xc00],zmm25
   86f9a:	62 61 fd 48 7f 44 24 31                         	vmovdqa64 ZMMWORD PTR [rsp+0xc40],zmm24
   86fa2:	62 61 fd 48 7f 54 24 32                         	vmovdqa64 ZMMWORD PTR [rsp+0xc80],zmm26
   86faa:	e9 de 13 00 00                                  	jmp    8838d <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x25ad>
   86faf:	49 3b 18                                        	cmp    rbx,QWORD PTR [r8]
   86fb2:	0f 97 c0                                        	seta   al
   86fb5:	41 80 78 31 00                                  	cmp    BYTE PTR [r8+0x31],0x0
   86fba:	75 02                                           	jne    86fbe <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x11de>
   86fbc:	31 c0                                           	xor    eax,eax
   86fbe:	84 c0                                           	test   al,al
   86fc0:	0f 85 80 51 00 00                               	jne    8c146 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6366>
   86fc6:	48 85 db                                        	test   rbx,rbx
   86fc9:	0f 84 bb 13 00 00                               	je     8838a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x25aa>
   86fcf:	62 62 fd 48 59 25 cf fc f7 ff                   	vpbroadcastq zmm28,QWORD PTR [rip+0xfffffffffff7fccf]        # 6ca8 <GCC_except_table711+0x1b8>
   86fd9:	62 62 fd 48 59 3d 5d fc f7 ff                   	vpbroadcastq zmm31,QWORD PTR [rip+0xfffffffffff7fc5d]        # 6c40 <GCC_except_table711+0x150>
   86fe3:	c5 7d 6f 2d f5 07 f8 ff                         	vmovdqa ymm13,YMMWORD PTR [rip+0xfffffffffff807f5]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   86feb:	48 89 9c 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],rbx
   86ff3:	31 ff                                           	xor    edi,edi
   86ff5:	49 89 d5                                        	mov    r13,rdx
   86ff8:	e9 e5 0c 00 00                                  	jmp    87ce2 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x1f02>
   86ffd:	0f 1f 00                                        	nop    DWORD PTR [rax]
   87000:	62 f1 fd 48 6f 44 24 23                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x8c0]
   87008:	62 f1 fd 48 6f 4c 24 21                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x840]
   87010:	62 f1 fd 48 6f 54 24 3f                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xfc0]
   87018:	62 f1 fd 48 6f 6c 24 16                         	vmovdqa64 zmm5,ZMMWORD PTR [rsp+0x580]
   87020:	62 71 fd 48 6f 15 d6 04 f8 ff                   	vmovdqa64 zmm10,ZMMWORD PTR [rip+0xfffffffffff804d6]        # 7500 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x560>
   8702a:	62 71 fd 48 6f 25 0c 05 f8 ff                   	vmovdqa64 zmm12,ZMMWORD PTR [rip+0xfffffffffff8050c]        # 7540 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x5a0>
   87034:	62 f1 fd 48 6f 74 24 25                         	vmovdqa64 zmm6,ZMMWORD PTR [rsp+0x940]
   8703c:	41 c1 ee 1e                                     	shr    r14d,0x1e
   87040:	41 c1 ed 1d                                     	shr    r13d,0x1d
   87044:	41 c1 e9 1f                                     	shr    r9d,0x1f
   87048:	c1 eb 1c                                        	shr    ebx,0x1c
   8704b:	41 c1 ef 1b                                     	shr    r15d,0x1b
   8704f:	c1 e8 1a                                        	shr    eax,0x1a
   87052:	c1 e9 19                                        	shr    ecx,0x19
   87055:	41 80 e4 80                                     	and    r12b,0x80
   87059:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8705e:	49 83 e8 80                                     	sub    r8,0xffffffffffffff80
   87062:	62 f3 fd 48 3a 44 24 30 01                      	vinserti64x4 zmm0,zmm0,YMMWORD PTR [rsp+0x600],0x1
   8706b:	62 f3 f5 48 3a 4c 24 52 01                      	vinserti64x4 zmm1,zmm1,YMMWORD PTR [rsp+0xa40],0x1
   87074:	62 f3 ed 48 3a 54 24 51 01                      	vinserti64x4 zmm2,zmm2,YMMWORD PTR [rsp+0xa20],0x1
   8707d:	41 80 e6 02                                     	and    r14b,0x2
   87081:	41 80 e5 04                                     	and    r13b,0x4
   87085:	80 e3 08                                        	and    bl,0x8
   87088:	41 80 e7 10                                     	and    r15b,0x10
   8708c:	80 e1 40                                        	and    cl,0x40
   8708f:	24 20                                           	and    al,0x20
   87091:	45 08 ce                                        	or     r14b,r9b
   87094:	41 08 cc                                        	or     r12b,cl
   87097:	48 69 ca 40 06 00 00                            	imul   rcx,rdx,0x640
   8709e:	48 ff c2                                        	inc    rdx
   870a1:	45 08 f5                                        	or     r13b,r14b
   870a4:	44 08 eb                                        	or     bl,r13b
   870a7:	4d 89 c5                                        	mov    r13,r8
   870aa:	41 08 df                                        	or     r15b,bl
   870ad:	44 08 f8                                        	or     al,r15b
   870b0:	41 08 c4                                        	or     r12b,al
   870b3:	c4 c1 7b 92 cc                                  	kmovd  k1,r12d
   870b8:	62 f1 fd 48 6c d9                               	vpunpcklqdq zmm3,zmm0,zmm1
   870be:	62 f1 fd 48 6d e1                               	vpunpckhqdq zmm4,zmm0,zmm1
   870c4:	62 f1 ed 48 6c c5                               	vpunpcklqdq zmm0,zmm2,zmm5
   870ca:	62 f1 ed 48 6d ed                               	vpunpckhqdq zmm5,zmm2,zmm5
   870d0:	62 f1 fd 48 6f d4                               	vmovdqa64 zmm2,zmm4
   870d6:	62 f2 ad 48 7e d5                               	vpermt2q zmm2,zmm10,zmm5
   870dc:	62 f2 9d 48 7e e5                               	vpermt2q zmm4,zmm12,zmm5
   870e2:	62 f3 cd 48 3a 6c 24 4f 01                      	vinserti64x4 zmm5,zmm6,YMMWORD PTR [rsp+0x9e0],0x1
   870eb:	62 f1 fd 48 6f 74 24 24                         	vmovdqa64 zmm6,ZMMWORD PTR [rsp+0x900]
   870f3:	62 f1 fd 48 6f cb                               	vmovdqa64 zmm1,zmm3
   870f9:	62 f2 ad 48 7e c8                               	vpermt2q zmm1,zmm10,zmm0
   870ff:	62 f2 9d 48 7e d8                               	vpermt2q zmm3,zmm12,zmm0
   87105:	62 f1 fd 48 6f 44 24 26                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x980]
   8710d:	62 f3 cd 48 3a 7c 24 1c 01                      	vinserti64x4 zmm7,zmm6,YMMWORD PTR [rsp+0x380],0x1
   87116:	62 f1 fd 48 6f 74 24 22                         	vmovdqa64 zmm6,ZMMWORD PTR [rsp+0x880]
   8711e:	62 f3 fd 48 3a 44 24 50 01                      	vinserti64x4 zmm0,zmm0,YMMWORD PTR [rsp+0xa00],0x1
   87127:	62 73 cd 48 3a 44 24 4e 01                      	vinserti64x4 zmm8,zmm6,YMMWORD PTR [rsp+0x9c0],0x1
   87130:	62 f1 fd 48 6d f5                               	vpunpckhqdq zmm6,zmm0,zmm5
   87136:	62 f1 fd 48 6c c5                               	vpunpcklqdq zmm0,zmm0,zmm5
   8713c:	62 51 c5 48 6d c8                               	vpunpckhqdq zmm9,zmm7,zmm8
   87142:	62 51 c5 48 6c c0                               	vpunpcklqdq zmm8,zmm7,zmm8
   87148:	62 f1 fd 48 6f ee                               	vmovdqa64 zmm5,zmm6
   8714e:	62 f1 fd 48 6f f8                               	vmovdqa64 zmm7,zmm0
   87154:	62 d2 ad 48 7e f1                               	vpermt2q zmm6,zmm10,zmm9
   8715a:	62 d2 ad 48 7e c0                               	vpermt2q zmm0,zmm10,zmm8
   87160:	62 d2 9d 48 7e e9                               	vpermt2q zmm5,zmm12,zmm9
   87166:	62 d2 9d 48 7e f8                               	vpermt2q zmm7,zmm12,zmm8
   8716c:	62 11 f5 48 db e7                               	vpandq zmm12,zmm1,zmm31
   87172:	62 11 fd c9 6f cf                               	vmovdqa64 zmm9{k1}{z},zmm31
   87178:	62 f3 ed 48 71 c9 0c                            	vpshldq zmm1,zmm2,zmm1,0xc
   8717f:	62 72 fe 48 38 d1                               	vpmovm2q zmm10,k1
   87185:	62 f3 e5 48 71 d2 18                            	vpshldq zmm2,zmm3,zmm2,0x18
   8718c:	62 f3 dd 48 71 db 24                            	vpshldq zmm3,zmm4,zmm3,0x24
   87193:	62 71 fd 48 7f 64 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm12
   8719b:	62 73 cd 48 71 c0 0c                            	vpshldq zmm8,zmm6,zmm0,0xc
   871a2:	62 93 b5 48 25 c7 6c                            	vpternlogq zmm0,zmm9,zmm31,0x6c
   871a9:	62 f3 c5 48 71 f6 18                            	vpshldq zmm6,zmm7,zmm6,0x18
   871b0:	62 f3 d5 48 71 ff 24                            	vpshldq zmm7,zmm5,zmm7,0x24
   871b7:	62 f1 d5 48 73 d5 10                            	vpsrlq zmm5,zmm5,0x10
   871be:	62 51 fd 48 fb d2                               	vpsubq zmm10,zmm0,zmm10
   871c4:	62 d1 fd 48 6f c3                               	vmovdqa64 zmm0,zmm11
   871ca:	62 72 a5 59 64 1d 54 fb f7 ff                   	vpblendmq zmm11{k1},zmm11,QWORD BCST [rip+0xfffffffffff7fb54]        # 6d28 <GCC_except_table711+0x238>
   871d4:	62 d1 d5 48 ef e9                               	vpxorq zmm5,zmm5,zmm9
   871da:	62 51 ad 48 fb d4                               	vpsubq zmm10,zmm10,zmm12
   871e0:	62 71 fd 48 6f e0                               	vmovdqa64 zmm12,zmm0
   871e6:	62 91 f5 48 db c7                               	vpandq zmm0,zmm1,zmm31
   871ec:	62 f2 fd 48 59 0d 7a fb f7 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff7fb7a]        # 6d70 <GCC_except_table711+0x280>
   871f6:	62 13 b5 48 25 c7 6c                            	vpternlogq zmm8,zmm9,zmm31,0x6c
   871fd:	62 93 b5 48 25 f7 6c                            	vpternlogq zmm6,zmm9,zmm31,0x6c
   87204:	62 93 b5 48 25 ff 6c                            	vpternlogq zmm7,zmm9,zmm31,0x6c
   8720b:	62 f1 fd 48 7f 44 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm0
   87213:	62 51 ad 48 d4 d3                               	vpaddq zmm10,zmm10,zmm11
   87219:	62 d1 a5 48 72 e2 34                            	vpsraq zmm11,zmm10,0x34
   87220:	62 51 bd 48 d4 c3                               	vpaddq zmm8,zmm8,zmm11
   87226:	62 72 f5 59 64 1d 38 fb f7 ff                   	vpblendmq zmm11{k1},zmm1,QWORD BCST [rip+0xfffffffffff7fb38]        # 6d68 <GCC_except_table711+0x278>
   87230:	62 f2 fd 48 59 0d 7e fa f7 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff7fa7e]        # 6cb8 <GCC_except_table711+0x1c8>
   8723a:	62 71 bd 48 fb c0                               	vpsubq zmm8,zmm8,zmm0
   87240:	62 91 ed 48 db c7                               	vpandq zmm0,zmm2,zmm31
   87246:	62 f2 fd 48 59 15 f8 f9 f7 ff                   	vpbroadcastq zmm2,QWORD PTR [rip+0xfffffffffff7f9f8]        # 6c48 <GCC_except_table711+0x158>
   87250:	62 f1 fd 48 7f 44 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm0
   87258:	62 51 bd 48 d4 c3                               	vpaddq zmm8,zmm8,zmm11
   8725e:	62 d1 a5 48 72 e0 34                            	vpsraq zmm11,zmm8,0x34
   87265:	62 11 bd 48 db c7                               	vpandq zmm8,zmm8,zmm31
   8726b:	62 d1 cd 48 d4 f3                               	vpaddq zmm6,zmm6,zmm11
   87271:	62 f1 cd 48 fb f0                               	vpsubq zmm6,zmm6,zmm0
   87277:	62 f2 fd 48 59 05 f7 f9 f7 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff7f9f7]        # 6c78 <GCC_except_table711+0x188>
   87281:	62 72 fd 59 64 1d c5 fa f7 ff                   	vpblendmq zmm11{k1},zmm0,QWORD BCST [rip+0xfffffffffff7fac5]        # 6d50 <GCC_except_table711+0x260>
   8728b:	62 91 e5 48 db c7                               	vpandq zmm0,zmm3,zmm31
   87291:	62 d1 fd 48 6f dc                               	vmovdqa64 zmm3,zmm12
   87297:	62 f1 fd 48 7f 44 24 0c                         	vmovdqa64 ZMMWORD PTR [rsp+0x300],zmm0
   8729f:	62 d1 cd 48 d4 f3                               	vpaddq zmm6,zmm6,zmm11
   872a5:	62 f1 a5 48 72 e6 34                            	vpsraq zmm11,zmm6,0x34
   872ac:	62 d1 c5 48 d4 fb                               	vpaddq zmm7,zmm7,zmm11
   872b2:	62 72 f5 59 64 1d 24 fa f7 ff                   	vpblendmq zmm11{k1},zmm1,QWORD BCST [rip+0xfffffffffff7fa24]        # 6ce0 <GCC_except_table711+0x1f0>
   872bc:	62 d1 fd 48 6f ce                               	vmovdqa64 zmm1,zmm14
   872c2:	62 f1 c5 48 fb f8                               	vpsubq zmm7,zmm7,zmm0
   872c8:	62 f1 fd 48 73 d4 10                            	vpsrlq zmm0,zmm4,0x10
   872cf:	62 f2 fd 48 59 25 7f fa f7 ff                   	vpbroadcastq zmm4,QWORD PTR [rip+0xfffffffffff7fa7f]        # 6d58 <GCC_except_table711+0x268>
   872d9:	62 f1 fd 48 7f 44 24 0e                         	vmovdqa64 ZMMWORD PTR [rsp+0x380],zmm0
   872e1:	62 d1 c5 48 d4 fb                               	vpaddq zmm7,zmm7,zmm11
   872e7:	62 11 ad 48 db df                               	vpandq zmm11,zmm10,zmm31
   872ed:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   872f2:	62 f1 b5 48 72 e7 34                            	vpsraq zmm9,zmm7,0x34
   872f9:	62 12 a5 48 b5 d4                               	vpmadd52huq zmm10,zmm11,zmm28
   872ff:	62 11 c5 48 db ef                               	vpandq zmm13,zmm7,zmm31
   87305:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   87309:	62 d1 d5 48 d4 e9                               	vpaddq zmm5,zmm5,zmm9
   8730f:	62 72 fd 48 59 0d df f9 f7 ff                   	vpbroadcastq zmm9,QWORD PTR [rip+0xfffffffffff7f9df]        # 6cf8 <GCC_except_table711+0x208>
   87319:	62 f1 d5 48 fb e8                               	vpsubq zmm5,zmm5,zmm0
   8731f:	62 12 bd 48 b4 d4                               	vpmadd52luq zmm10,zmm8,zmm28
   87325:	62 72 b5 59 64 0d 71 f9 f7 ff                   	vpblendmq zmm9{k1},zmm9,QWORD BCST [rip+0xfffffffffff7f971]        # 6ca0 <GCC_except_table711+0x1b0>
   8732f:	62 f1 fd 48 6f 44 24 14                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x500]
   87337:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
   8733b:	4c 8b 9c 24 c0 07 00 00                         	mov    r11,QWORD PTR [rsp+0x7c0]
   87343:	4c 8b 7c 24 38                                  	mov    r15,QWORD PTR [rsp+0x38]
   87348:	4c 8b a4 24 00 04 00 00                         	mov    r12,QWORD PTR [rsp+0x400]
   87350:	4c 8b b4 24 c0 05 00 00                         	mov    r14,QWORD PTR [rsp+0x5c0]
   87358:	62 d1 d5 48 d4 e9                               	vpaddq zmm5,zmm5,zmm9
   8735e:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   87363:	62 12 a5 48 b4 cc                               	vpmadd52luq zmm9,zmm11,zmm28
   87369:	62 72 b5 48 b4 fc                               	vpmadd52luq zmm15,zmm9,zmm4
   8736f:	62 11 b5 48 d4 cf                               	vpaddq zmm9,zmm9,zmm31
   87375:	62 d1 b5 48 73 d1 34                            	vpsrlq zmm9,zmm9,0x34
   8737c:	62 52 85 48 b5 cc                               	vpmadd52huq zmm9,zmm15,zmm12
   87382:	62 52 85 48 b4 d6                               	vpmadd52luq zmm10,zmm15,zmm14
   87388:	62 11 cd 48 db f7                               	vpandq zmm14,zmm6,zmm31
   8738e:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   87392:	62 92 bd 48 b5 f4                               	vpmadd52huq zmm6,zmm8,zmm28
   87398:	62 11 d5 48 db e7                               	vpandq zmm12,zmm5,zmm31
   8739e:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   873a2:	62 92 8d 48 b5 fc                               	vpmadd52huq zmm7,zmm14,zmm28
   873a8:	62 92 9d 48 b5 ec                               	vpmadd52huq zmm5,zmm12,zmm28
   873ae:	62 51 ad 48 d4 d1                               	vpaddq zmm10,zmm10,zmm9
   873b4:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   873b9:	62 12 95 48 b5 cc                               	vpmadd52huq zmm9,zmm13,zmm28
   873bf:	62 92 8d 48 b4 f4                               	vpmadd52luq zmm6,zmm14,zmm28
   873c5:	62 92 95 48 b4 fc                               	vpmadd52luq zmm7,zmm13,zmm28
   873cb:	62 12 a5 48 b4 d3                               	vpmadd52luq zmm10,zmm11,zmm27
   873d1:	62 b2 85 48 b5 ea                               	vpmadd52huq zmm5,zmm15,zmm18
   873d7:	62 12 9d 48 b4 cc                               	vpmadd52luq zmm9,zmm12,zmm28
   873dd:	62 f2 85 48 b5 f1                               	vpmadd52huq zmm6,zmm15,zmm1
   873e3:	62 f2 85 48 b5 f8                               	vpmadd52huq zmm7,zmm15,zmm0
   873e9:	62 92 95 48 b5 eb                               	vpmadd52huq zmm5,zmm13,zmm27
   873ef:	62 32 85 48 b5 cb                               	vpmadd52huq zmm9,zmm15,zmm19
   873f5:	62 f2 85 48 b4 f0                               	vpmadd52luq zmm6,zmm15,zmm0
   873fb:	62 b2 85 48 b4 fb                               	vpmadd52luq zmm7,zmm15,zmm19
   87401:	62 92 9d 48 b4 eb                               	vpmadd52luq zmm5,zmm12,zmm27
   87407:	62 32 85 48 b4 ca                               	vpmadd52luq zmm9,zmm15,zmm18
   8740d:	62 92 a5 48 b5 f3                               	vpmadd52huq zmm6,zmm11,zmm27
   87413:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   87418:	62 72 ad 48 b4 fc                               	vpmadd52luq zmm15,zmm10,zmm4
   8741e:	62 11 ad 48 d4 d7                               	vpaddq zmm10,zmm10,zmm31
   87424:	62 92 bd 48 b5 fb                               	vpmadd52huq zmm7,zmm8,zmm27
   8742a:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   87431:	62 12 8d 48 b5 cb                               	vpmadd52huq zmm9,zmm14,zmm27
   87437:	62 92 bd 48 b4 f3                               	vpmadd52luq zmm6,zmm8,zmm27
   8743d:	62 72 85 48 b5 d3                               	vpmadd52huq zmm10,zmm15,zmm3
   87443:	62 b2 85 48 b5 eb                               	vpmadd52huq zmm5,zmm15,zmm19
   87449:	62 92 8d 48 b4 fb                               	vpmadd52luq zmm7,zmm14,zmm27
   8744f:	62 12 95 48 b4 cb                               	vpmadd52luq zmm9,zmm13,zmm27
   87455:	62 f2 85 48 b4 f1                               	vpmadd52luq zmm6,zmm15,zmm1
   8745b:	62 b2 85 48 b4 ea                               	vpmadd52luq zmm5,zmm15,zmm18
   87461:	62 f2 85 48 b5 f9                               	vpmadd52huq zmm7,zmm15,zmm1
   87467:	62 72 85 48 b5 c8                               	vpmadd52huq zmm9,zmm15,zmm0
   8746d:	62 51 cd 48 d4 d2                               	vpaddq zmm10,zmm6,zmm10
   87473:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   87477:	62 92 9d 48 b5 f3                               	vpmadd52huq zmm6,zmm12,zmm27
   8747d:	62 92 8d 48 b5 e9                               	vpmadd52huq zmm5,zmm14,zmm25
   87483:	62 f2 85 48 b4 f8                               	vpmadd52luq zmm7,zmm15,zmm0
   87489:	62 12 a5 48 b4 d1                               	vpmadd52luq zmm10,zmm11,zmm25
   8748f:	62 32 85 48 b4 cb                               	vpmadd52luq zmm9,zmm15,zmm19
   87495:	62 b2 85 48 b5 f2                               	vpmadd52huq zmm6,zmm15,zmm18
   8749b:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   874a0:	62 92 95 48 b4 e9                               	vpmadd52luq zmm5,zmm13,zmm25
   874a6:	62 92 a5 48 b5 f9                               	vpmadd52huq zmm7,zmm11,zmm25
   874ac:	62 72 ad 48 b4 fc                               	vpmadd52luq zmm15,zmm10,zmm4
   874b2:	62 11 ad 48 d4 d7                               	vpaddq zmm10,zmm10,zmm31
   874b8:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   874bf:	62 12 bd 48 b5 c9                               	vpmadd52huq zmm9,zmm8,zmm25
   874c5:	62 92 95 48 b5 f1                               	vpmadd52huq zmm6,zmm13,zmm25
   874cb:	62 92 bd 48 b4 f9                               	vpmadd52luq zmm7,zmm8,zmm25
   874d1:	62 72 85 48 b5 d3                               	vpmadd52huq zmm10,zmm15,zmm3
   874d7:	62 f2 85 48 b5 e8                               	vpmadd52huq zmm5,zmm15,zmm0
   874dd:	62 12 8d 48 b4 c9                               	vpmadd52luq zmm9,zmm14,zmm25
   874e3:	62 92 9d 48 b4 f1                               	vpmadd52luq zmm6,zmm12,zmm25
   874e9:	62 f2 85 48 b4 f9                               	vpmadd52luq zmm7,zmm15,zmm1
   874ef:	62 b2 85 48 b4 eb                               	vpmadd52luq zmm5,zmm15,zmm19
   874f5:	62 72 85 48 b5 c9                               	vpmadd52huq zmm9,zmm15,zmm1
   874fb:	62 b2 85 48 b5 f3                               	vpmadd52huq zmm6,zmm15,zmm19
   87501:	62 51 c5 48 d4 d2                               	vpaddq zmm10,zmm7,zmm10
   87507:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   8750b:	62 92 9d 48 b5 f9                               	vpmadd52huq zmm7,zmm12,zmm25
   87511:	62 92 bd 48 b5 e8                               	vpmadd52huq zmm5,zmm8,zmm24
   87517:	62 12 a5 48 b4 d0                               	vpmadd52luq zmm10,zmm11,zmm24
   8751d:	62 72 85 48 b4 c8                               	vpmadd52luq zmm9,zmm15,zmm0
   87523:	62 b2 85 48 b4 f2                               	vpmadd52luq zmm6,zmm15,zmm18
   87529:	62 b2 85 48 b5 fa                               	vpmadd52huq zmm7,zmm15,zmm18
   8752f:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   87534:	62 92 8d 48 b4 e8                               	vpmadd52luq zmm5,zmm14,zmm24
   8753a:	62 72 ad 48 b4 fc                               	vpmadd52luq zmm15,zmm10,zmm4
   87540:	62 11 ad 48 d4 d7                               	vpaddq zmm10,zmm10,zmm31
   87546:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   8754d:	62 12 a5 48 b5 c8                               	vpmadd52huq zmm9,zmm11,zmm24
   87553:	62 92 8d 48 b5 f0                               	vpmadd52huq zmm6,zmm14,zmm24
   87559:	62 92 95 48 b5 f8                               	vpmadd52huq zmm7,zmm13,zmm24
   8755f:	62 72 85 48 b5 d3                               	vpmadd52huq zmm10,zmm15,zmm3
   87565:	62 f2 85 48 b5 e9                               	vpmadd52huq zmm5,zmm15,zmm1
   8756b:	62 12 bd 48 b4 c8                               	vpmadd52luq zmm9,zmm8,zmm24
   87571:	62 92 95 48 b4 f0                               	vpmadd52luq zmm6,zmm13,zmm24
   87577:	62 92 9d 48 b4 f8                               	vpmadd52luq zmm7,zmm12,zmm24
   8757d:	62 f2 85 48 b4 e8                               	vpmadd52luq zmm5,zmm15,zmm0
   87583:	62 72 85 48 b4 c9                               	vpmadd52luq zmm9,zmm15,zmm1
   87589:	62 f2 85 48 b5 f0                               	vpmadd52huq zmm6,zmm15,zmm0
   8758f:	62 b2 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm19
   87595:	62 92 a5 48 b5 ea                               	vpmadd52huq zmm5,zmm11,zmm26
   8759b:	62 51 b5 48 d4 d2                               	vpaddq zmm10,zmm9,zmm10
   875a1:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   875a6:	62 12 9d 48 b5 c8                               	vpmadd52huq zmm9,zmm12,zmm24
   875ac:	62 b2 85 48 b4 f3                               	vpmadd52luq zmm6,zmm15,zmm19
   875b2:	62 b2 85 48 b4 fa                               	vpmadd52luq zmm7,zmm15,zmm18
   875b8:	62 12 a5 48 b4 d2                               	vpmadd52luq zmm10,zmm11,zmm26
   875be:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   875c3:	62 12 9d 48 b5 da                               	vpmadd52huq zmm11,zmm12,zmm26
   875c9:	62 92 bd 48 b4 ea                               	vpmadd52luq zmm5,zmm8,zmm26
   875cf:	62 32 85 48 b5 ca                               	vpmadd52huq zmm9,zmm15,zmm18
   875d5:	62 92 bd 48 b5 f2                               	vpmadd52huq zmm6,zmm8,zmm26
   875db:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   875e0:	62 92 8d 48 b5 fa                               	vpmadd52huq zmm7,zmm14,zmm26
   875e6:	62 12 95 48 b5 ca                               	vpmadd52huq zmm9,zmm13,zmm26
   875ec:	62 92 8d 48 b4 f2                               	vpmadd52luq zmm6,zmm14,zmm26
   875f2:	c4 41 09 ef f6                                  	vpxor  xmm14,xmm14,xmm14
   875f7:	62 92 95 48 b4 fa                               	vpmadd52luq zmm7,zmm13,zmm26
   875fd:	c4 41 11 ef ed                                  	vpxor  xmm13,xmm13,xmm13
   87602:	62 12 9d 48 b4 ca                               	vpmadd52luq zmm9,zmm12,zmm26
   87608:	c4 41 19 ef e4                                  	vpxor  xmm12,xmm12,xmm12
   8760d:	62 72 ad 48 b4 e4                               	vpmadd52luq zmm12,zmm10,zmm4
   87613:	62 71 ad 48 d4 d2                               	vpaddq zmm10,zmm10,zmm2
   87619:	62 d1 ad 48 73 d2 30                            	vpsrlq zmm10,zmm10,0x30
   87620:	62 71 9d 48 db c2                               	vpandq zmm8,zmm12,zmm2
   87626:	62 d1 9d 48 73 f4 04                            	vpsllq zmm12,zmm12,0x4
   8762d:	62 f2 bd 48 b5 f1                               	vpmadd52huq zmm6,zmm8,zmm1
   87633:	62 f2 bd 48 b5 f8                               	vpmadd52huq zmm7,zmm8,zmm0
   87639:	62 32 bd 48 b5 cb                               	vpmadd52huq zmm9,zmm8,zmm19
   8763f:	62 f2 bd 48 b4 e9                               	vpmadd52luq zmm5,zmm8,zmm1
   87645:	62 32 bd 48 b5 da                               	vpmadd52huq zmm11,zmm8,zmm18
   8764b:	62 b1 fd 48 6f c8                               	vmovdqa64 zmm1,zmm16
   87651:	62 72 9d 48 b5 d3                               	vpmadd52huq zmm10,zmm12,zmm3
   87657:	62 f2 bd 48 b4 f0                               	vpmadd52luq zmm6,zmm8,zmm0
   8765d:	62 b2 bd 48 b4 fb                               	vpmadd52luq zmm7,zmm8,zmm19
   87663:	62 32 bd 48 b4 ca                               	vpmadd52luq zmm9,zmm8,zmm18
   87669:	62 11 f5 40 db c7                               	vpandq zmm8,zmm17,zmm31
   8766f:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   87675:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   8767b:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   87681:	62 b1 fd 48 6f c6                               	vmovdqa64 zmm0,zmm22
   87687:	62 f1 9d 48 73 f5 04                            	vpsllq zmm12,zmm5,0x4
   8768e:	62 f1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm5,0x30
   87695:	62 52 9d 40 b5 f0                               	vpmadd52huq zmm14,zmm28,zmm8
   8769b:	62 c2 a5 40 b5 d0                               	vpmadd52huq zmm18,zmm27,zmm8
   876a1:	62 52 9d 40 b4 e8                               	vpmadd52luq zmm13,zmm28,zmm8
   876a7:	62 c2 b5 40 b5 c8                               	vpmadd52huq zmm17,zmm25,zmm8
   876ad:	62 c2 bd 40 b5 d8                               	vpmadd52huq zmm19,zmm24,zmm8
   876b3:	62 72 95 48 b4 fc                               	vpmadd52luq zmm15,zmm13,zmm4
   876b9:	62 52 a5 40 b4 f0                               	vpmadd52luq zmm14,zmm27,zmm8
   876bf:	62 c2 b5 40 b4 d0                               	vpmadd52luq zmm18,zmm25,zmm8
   876c5:	62 c2 bd 40 b4 c8                               	vpmadd52luq zmm17,zmm24,zmm8
   876cb:	62 11 95 48 d4 ef                               	vpaddq zmm13,zmm13,zmm31
   876d1:	62 c2 ad 40 b4 d8                               	vpmadd52luq zmm19,zmm26,zmm8
   876d7:	62 d1 95 48 73 d5 34                            	vpsrlq zmm13,zmm13,0x34
   876de:	62 e2 85 48 b5 d1                               	vpmadd52huq zmm18,zmm15,zmm1
   876e4:	62 72 85 48 b5 eb                               	vpmadd52huq zmm13,zmm15,zmm3
   876ea:	62 32 85 48 b4 f0                               	vpmadd52luq zmm14,zmm15,zmm16
   876f0:	62 a2 85 48 b5 ce                               	vpmadd52huq zmm17,zmm15,zmm22
   876f6:	62 a2 85 48 b5 dd                               	vpmadd52huq zmm19,zmm15,zmm21
   876fc:	62 c1 8d 48 d4 c5                               	vpaddq zmm16,zmm14,zmm13
   87702:	c4 41 09 ef f6                                  	vpxor  xmm14,xmm14,xmm14
   87707:	62 52 ad 40 b5 f0                               	vpmadd52huq zmm14,zmm26,zmm8
   8770d:	62 a2 85 48 b4 d6                               	vpmadd52luq zmm18,zmm15,zmm22
   87713:	62 a2 85 48 b4 cd                               	vpmadd52luq zmm17,zmm15,zmm21
   87719:	62 11 8d 40 db ef                               	vpandq zmm13,zmm30,zmm31
   8771f:	62 a2 85 48 b4 dc                               	vpmadd52luq zmm19,zmm15,zmm20
   87725:	62 21 fd 48 6f f5                               	vmovdqa64 zmm30,zmm21
   8772b:	62 c2 9d 40 b4 c5                               	vpmadd52luq zmm16,zmm28,zmm13
   87731:	62 32 85 48 b5 f4                               	vpmadd52huq zmm14,zmm15,zmm20
   87737:	62 c2 9d 40 b5 d5                               	vpmadd52huq zmm18,zmm28,zmm13
   8773d:	62 c2 a5 40 b5 cd                               	vpmadd52huq zmm17,zmm27,zmm13
   87743:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   87748:	62 c2 b5 40 b5 dd                               	vpmadd52huq zmm19,zmm25,zmm13
   8774e:	62 72 fd 40 b4 fc                               	vpmadd52luq zmm15,zmm16,zmm4
   87754:	62 81 fd 40 d4 c7                               	vpaddq zmm16,zmm16,zmm31
   8775a:	62 b1 fd 40 73 d0 34                            	vpsrlq zmm16,zmm16,0x34
   87761:	62 c2 a5 40 b4 d5                               	vpmadd52luq zmm18,zmm27,zmm13
   87767:	62 52 bd 40 b5 f5                               	vpmadd52huq zmm14,zmm24,zmm13
   8776d:	62 c2 b5 40 b4 cd                               	vpmadd52luq zmm17,zmm25,zmm13
   87773:	62 c2 bd 40 b4 dd                               	vpmadd52luq zmm19,zmm24,zmm13
   87779:	62 e2 85 48 b5 c3                               	vpmadd52huq zmm16,zmm15,zmm3
   8777f:	62 e2 85 48 b4 d1                               	vpmadd52luq zmm18,zmm15,zmm1
   87785:	62 52 ad 40 b4 f5                               	vpmadd52luq zmm14,zmm26,zmm13
   8778b:	62 e2 85 48 b5 c9                               	vpmadd52huq zmm17,zmm15,zmm1
   87791:	62 a2 85 48 b5 de                               	vpmadd52huq zmm19,zmm15,zmm22
   87797:	62 32 85 48 b5 f5                               	vpmadd52huq zmm14,zmm15,zmm21
   8779d:	62 a1 ed 40 d4 d0                               	vpaddq zmm18,zmm18,zmm16
   877a3:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   877a9:	62 c2 ad 40 b5 c5                               	vpmadd52huq zmm16,zmm26,zmm13
   877af:	62 a2 85 48 b4 ce                               	vpmadd52luq zmm17,zmm15,zmm22
   877b5:	62 a2 85 48 b4 dd                               	vpmadd52luq zmm19,zmm15,zmm21
   877bb:	62 32 85 48 b4 f4                               	vpmadd52luq zmm14,zmm15,zmm20
   877c1:	62 a2 85 48 b5 c4                               	vpmadd52huq zmm16,zmm15,zmm20
   877c7:	62 11 95 40 db ff                               	vpandq zmm15,zmm29,zmm31
   877cd:	62 21 fd 48 6f ec                               	vmovdqa64 zmm29,zmm20
   877d3:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   877d9:	62 c2 9d 40 b5 cf                               	vpmadd52huq zmm17,zmm28,zmm15
   877df:	62 c2 9d 40 b4 d7                               	vpmadd52luq zmm18,zmm28,zmm15
   877e5:	62 c2 a5 40 b5 df                               	vpmadd52huq zmm19,zmm27,zmm15
   877eb:	62 52 b5 40 b5 f7                               	vpmadd52huq zmm14,zmm25,zmm15
   877f1:	62 c2 bd 40 b5 c7                               	vpmadd52huq zmm16,zmm24,zmm15
   877f7:	62 e2 ed 40 b4 e4                               	vpmadd52luq zmm20,zmm18,zmm4
   877fd:	62 c2 a5 40 b4 cf                               	vpmadd52luq zmm17,zmm27,zmm15
   87803:	62 81 ed 40 d4 d7                               	vpaddq zmm18,zmm18,zmm31
   87809:	62 c2 b5 40 b4 df                               	vpmadd52luq zmm19,zmm25,zmm15
   8780f:	62 b1 ed 40 73 d2 34                            	vpsrlq zmm18,zmm18,0x34
   87816:	62 52 bd 40 b4 f7                               	vpmadd52luq zmm14,zmm24,zmm15
   8781c:	62 c2 ad 40 b4 c7                               	vpmadd52luq zmm16,zmm26,zmm15
   87822:	62 e2 dd 40 b5 d3                               	vpmadd52huq zmm18,zmm20,zmm3
   87828:	62 e2 dd 40 b4 c9                               	vpmadd52luq zmm17,zmm20,zmm1
   8782e:	62 e2 dd 40 b5 d9                               	vpmadd52huq zmm19,zmm20,zmm1
   87834:	62 32 dd 40 b5 f6                               	vpmadd52huq zmm14,zmm20,zmm22
   8783a:	62 82 dd 40 b5 c6                               	vpmadd52huq zmm16,zmm20,zmm30
   87840:	62 a1 f5 40 d4 ea                               	vpaddq zmm21,zmm17,zmm18
   87846:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   8784c:	62 c2 ad 40 b5 d7                               	vpmadd52huq zmm18,zmm26,zmm15
   87852:	62 a2 dd 40 b4 de                               	vpmadd52luq zmm19,zmm20,zmm22
   87858:	62 81 c5 40 db cf                               	vpandq zmm17,zmm23,zmm31
   8785e:	62 a1 4d 00 ef f6                               	vpxord xmm22,xmm22,xmm22
   87864:	62 a2 9d 40 b4 e9                               	vpmadd52luq zmm21,zmm28,zmm17
   8786a:	62 a2 ad 40 b5 f1                               	vpmadd52huq zmm22,zmm26,zmm17
   87870:	62 12 dd 40 b4 f6                               	vpmadd52luq zmm14,zmm20,zmm30
   87876:	62 82 dd 40 b4 c5                               	vpmadd52luq zmm16,zmm20,zmm29
   8787c:	62 82 dd 40 b5 d5                               	vpmadd52huq zmm18,zmm20,zmm29
   87882:	62 a2 9d 40 b5 d9                               	vpmadd52huq zmm19,zmm28,zmm17
   87888:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   8788e:	62 e2 d5 40 b4 e4                               	vpmadd52luq zmm20,zmm21,zmm4
   87894:	62 81 d5 40 d4 ef                               	vpaddq zmm21,zmm21,zmm31
   8789a:	62 b1 d5 40 73 d5 34                            	vpsrlq zmm21,zmm21,0x34
   878a1:	62 32 a5 40 b5 f1                               	vpmadd52huq zmm14,zmm27,zmm17
   878a7:	62 a2 b5 40 b5 c1                               	vpmadd52huq zmm16,zmm25,zmm17
   878ad:	62 a2 bd 40 b5 d1                               	vpmadd52huq zmm18,zmm24,zmm17
   878b3:	62 a2 a5 40 b4 d9                               	vpmadd52luq zmm19,zmm27,zmm17
   878b9:	62 e2 dd 40 b5 eb                               	vpmadd52huq zmm21,zmm20,zmm3
   878bf:	62 82 dd 40 b5 f5                               	vpmadd52huq zmm22,zmm20,zmm29
   878c5:	62 32 b5 40 b4 f1                               	vpmadd52luq zmm14,zmm25,zmm17
   878cb:	62 a2 bd 40 b4 c1                               	vpmadd52luq zmm16,zmm24,zmm17
   878d1:	62 a2 ad 40 b4 d1                               	vpmadd52luq zmm18,zmm26,zmm17
   878d7:	62 e2 dd 40 b4 d9                               	vpmadd52luq zmm19,zmm20,zmm1
   878dd:	62 72 dd 40 b5 f1                               	vpmadd52huq zmm14,zmm20,zmm1
   878e3:	62 e2 dd 40 b5 c0                               	vpmadd52huq zmm16,zmm20,zmm0
   878e9:	62 82 dd 40 b5 d6                               	vpmadd52huq zmm18,zmm20,zmm30
   878ef:	62 a1 e5 40 d4 fd                               	vpaddq zmm23,zmm19,zmm21
   878f5:	62 f1 d5 40 73 54 24 19 10                      	vpsrlq zmm21,ZMMWORD PTR [rsp+0x640],0x10
   878fe:	62 e1 d5 40 d4 5c 24 20                         	vpaddq zmm19,zmm21,ZMMWORD PTR [rsp+0x800]
   87906:	62 72 dd 40 b4 f0                               	vpmadd52luq zmm14,zmm20,zmm0
   8790c:	62 82 dd 40 b4 c6                               	vpmadd52luq zmm16,zmm20,zmm30
   87912:	62 82 dd 40 b4 d5                               	vpmadd52luq zmm18,zmm20,zmm29
   87918:	62 f1 dd 40 73 54 24 1a 10                      	vpsrlq zmm20,ZMMWORD PTR [rsp+0x680],0x10
   87921:	62 a1 e5 40 fb dc                               	vpsubq zmm19,zmm19,zmm20
   87927:	62 a1 dd 40 d4 ed                               	vpaddq zmm21,zmm20,zmm21
   8792d:	62 81 e5 40 db df                               	vpandq zmm19,zmm19,zmm31
   87933:	62 32 9d 40 b5 f3                               	vpmadd52huq zmm14,zmm28,zmm19
   87939:	62 a2 a5 40 b5 c3                               	vpmadd52huq zmm16,zmm27,zmm19
   8793f:	62 a2 9d 40 b4 fb                               	vpmadd52luq zmm23,zmm28,zmm19
   87945:	62 a2 b5 40 b5 d3                               	vpmadd52huq zmm18,zmm25,zmm19
   8794b:	62 a2 bd 40 b5 f3                               	vpmadd52huq zmm22,zmm24,zmm19
   87951:	62 32 a5 40 b4 f3                               	vpmadd52luq zmm14,zmm27,zmm19
   87957:	62 a2 b5 40 b4 c3                               	vpmadd52luq zmm16,zmm25,zmm19
   8795d:	62 01 35 00 ef c9                               	vpxord xmm25,xmm25,xmm25
   87963:	62 62 c5 40 b4 cc                               	vpmadd52luq zmm25,zmm23,zmm4
   87969:	62 62 fd 48 59 1d 8d f3 f7 ff                   	vpbroadcastq zmm27,QWORD PTR [rip+0xfffffffffff7f38d]        # 6d00 <GCC_except_table711+0x210>
   87973:	62 a2 bd 40 b4 d3                               	vpmadd52luq zmm18,zmm24,zmm19
   87979:	62 a2 ad 40 b4 f3                               	vpmadd52luq zmm22,zmm26,zmm19
   8797f:	62 01 3d 00 ef c0                               	vpxord xmm24,xmm24,xmm24
   87985:	62 22 ad 40 b5 c3                               	vpmadd52huq zmm24,zmm26,zmm19
   8798b:	62 f1 dd 48 73 f7 04                            	vpsllq zmm4,zmm7,0x4
   87992:	62 f1 c5 48 73 d7 30                            	vpsrlq zmm7,zmm7,0x30
   87999:	62 61 b5 40 db d2                               	vpandq zmm26,zmm25,zmm2
   8799f:	62 e2 ad 40 b5 c1                               	vpmadd52huq zmm16,zmm26,zmm1
   879a5:	62 e2 ad 40 b5 d0                               	vpmadd52huq zmm18,zmm26,zmm0
   879ab:	62 82 ad 40 b5 f6                               	vpmadd52huq zmm22,zmm26,zmm30
   879b1:	62 72 ad 40 b4 f1                               	vpmadd52luq zmm14,zmm26,zmm1
   879b7:	62 02 ad 40 b5 c5                               	vpmadd52huq zmm24,zmm26,zmm29
   879bd:	62 f1 fd 48 6f 4c 24 12                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x480]
   879c5:	62 11 9d 48 db e3                               	vpandq zmm12,zmm12,zmm27
   879cb:	62 e2 ad 40 b4 c0                               	vpmadd52luq zmm16,zmm26,zmm0
   879d1:	62 51 9d 48 d4 d2                               	vpaddq zmm10,zmm12,zmm10
   879d7:	62 11 dd 48 db e3                               	vpandq zmm12,zmm4,zmm27
   879dd:	62 82 ad 40 b4 d6                               	vpmadd52luq zmm18,zmm26,zmm30
   879e3:	62 82 ad 40 b4 f5                               	vpmadd52luq zmm22,zmm26,zmm29
   879e9:	62 f1 ad 40 73 d6 30                            	vpsrlq zmm26,zmm6,0x30
   879f0:	62 d1 fd 48 73 f1 04                            	vpsllq zmm0,zmm9,0x4
   879f7:	62 d1 dd 48 73 d1 30                            	vpsrlq zmm4,zmm9,0x30
   879fe:	62 f1 cd 48 73 f6 04                            	vpsllq zmm6,zmm6,0x4
   87a05:	62 11 9d 48 d4 e2                               	vpaddq zmm12,zmm12,zmm26
   87a0b:	62 01 fd 48 db d3                               	vpandq zmm26,zmm0,zmm27
   87a11:	62 d1 fd 48 73 f3 04                            	vpsllq zmm0,zmm11,0x4
   87a18:	62 91 cd 48 db f3                               	vpandq zmm6,zmm6,zmm27
   87a1e:	62 71 dd 48 d4 d8                               	vpaddq zmm11,zmm4,zmm0
   87a24:	62 d1 fd 48 73 d2 34                            	vpsrlq zmm0,zmm10,0x34
   87a2b:	62 61 ad 40 d4 d7                               	vpaddq zmm26,zmm26,zmm7
   87a31:	62 f1 fd 48 d4 ed                               	vpaddq zmm5,zmm0,zmm5
   87a37:	62 f1 c5 40 d4 c2                               	vpaddq zmm0,zmm23,zmm2
   87a3d:	62 91 ed 48 73 f0 04                            	vpsllq zmm2,zmm24,0x4
   87a44:	62 f1 d5 48 d4 f6                               	vpaddq zmm6,zmm5,zmm6
   87a4a:	62 b1 c5 40 73 d0 30                            	vpsrlq zmm23,zmm16,0x30
   87a51:	62 b1 fd 40 73 f0 04                            	vpsllq zmm16,zmm16,0x4
   87a58:	62 f1 d5 48 73 d6 34                            	vpsrlq zmm5,zmm6,0x34
   87a5f:	62 81 fd 40 db c3                               	vpandq zmm16,zmm16,zmm27
   87a65:	62 d1 d5 48 d4 fc                               	vpaddq zmm7,zmm5,zmm12
   87a6b:	62 91 9d 48 73 f1 04                            	vpsllq zmm12,zmm25,0x4
   87a72:	62 f1 d5 48 73 d7 34                            	vpsrlq zmm5,zmm7,0x34
   87a79:	62 11 d5 48 d4 ca                               	vpaddq zmm9,zmm5,zmm26
   87a7f:	62 d1 d5 48 73 d1 34                            	vpsrlq zmm5,zmm9,0x34
   87a86:	62 d1 d5 48 d4 eb                               	vpaddq zmm5,zmm5,zmm11
   87a8c:	62 f1 a5 48 73 d0 30                            	vpsrlq zmm11,zmm0,0x30
   87a93:	62 b1 fd 48 73 f2 04                            	vpsllq zmm0,zmm18,0x4
   87a9a:	62 b1 ed 40 73 d2 30                            	vpsrlq zmm18,zmm18,0x30
   87aa1:	62 72 9d 48 b5 db                               	vpmadd52huq zmm11,zmm12,zmm3
   87aa7:	62 d1 9d 48 73 f6 04                            	vpsllq zmm12,zmm14,0x4
   87aae:	62 d1 8d 48 73 d6 30                            	vpsrlq zmm14,zmm14,0x30
   87ab5:	62 11 9d 48 db e3                               	vpandq zmm12,zmm12,zmm27
   87abb:	62 51 9d 48 d4 db                               	vpaddq zmm11,zmm12,zmm11
   87ac1:	62 11 fd 48 db e3                               	vpandq zmm12,zmm0,zmm27
   87ac7:	62 b1 fd 48 73 f6 04                            	vpsllq zmm0,zmm22,0x4
   87ace:	62 b1 cd 40 73 d6 30                            	vpsrlq zmm22,zmm22,0x30
   87ad5:	62 31 9d 48 d4 e7                               	vpaddq zmm12,zmm12,zmm23
   87adb:	62 81 fd 48 db fb                               	vpandq zmm23,zmm0,zmm27
   87ae1:	62 d1 fd 48 73 d3 34                            	vpsrlq zmm0,zmm11,0x34
   87ae8:	62 e1 cd 40 d4 f2                               	vpaddq zmm22,zmm22,zmm2
   87aee:	62 61 fd 48 6f 5c 24 1e                         	vmovdqa64 zmm27,ZMMWORD PTR [rsp+0x780]
   87af6:	62 f1 fd 48 6f 54 24 11                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0x440]
   87afe:	62 01 a5 48 db e7                               	vpandq zmm28,zmm11,zmm31
   87b04:	62 51 fd 48 d4 f6                               	vpaddq zmm14,zmm0,zmm14
   87b0a:	62 f1 fd 48 6f 44 24 13                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x4c0]
   87b12:	62 a1 c5 40 d4 d2                               	vpaddq zmm18,zmm23,zmm18
   87b18:	62 e1 ed 48 d4 7c 24 1c                         	vpaddq zmm23,zmm2,ZMMWORD PTR [rsp+0x700]
   87b20:	62 61 a5 40 d4 44 24 1b                         	vpaddq zmm24,zmm27,ZMMWORD PTR [rsp+0x6c0]
   87b28:	62 31 8d 48 d4 f0                               	vpaddq zmm14,zmm14,zmm16
   87b2e:	62 f1 fd 48 d4 5c 24 15                         	vpaddq zmm3,zmm0,ZMMWORD PTR [rsp+0x540]
   87b36:	62 d1 fd 40 73 d6 34                            	vpsrlq zmm16,zmm14,0x34
   87b3d:	62 51 fd 40 d4 e4                               	vpaddq zmm12,zmm16,zmm12
   87b43:	62 d1 fd 40 73 d4 34                            	vpsrlq zmm16,zmm12,0x34
   87b4a:	62 a1 fd 40 d4 c2                               	vpaddq zmm16,zmm16,zmm18
   87b50:	62 b1 ed 40 73 d0 34                            	vpsrlq zmm18,zmm16,0x34
   87b57:	62 21 ed 40 d4 d6                               	vpaddq zmm26,zmm18,zmm22
   87b5d:	62 e1 f5 48 d4 74 24 1d                         	vpaddq zmm22,zmm1,ZMMWORD PTR [rsp+0x740]
   87b65:	62 f1 fd 48 7f 04 08                            	vmovdqa64 ZMMWORD PTR [rax+rcx*1],zmm0
   87b6c:	62 f1 fd 48 7f 4c 08 01                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x40],zmm1
   87b74:	62 f1 7c 48 28 4c 24 09                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x240]
   87b7c:	62 f1 fd 48 7f 54 08 02                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x80],zmm2
   87b84:	62 61 fd 48 7f 5c 08 03                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0xc0],zmm27
   87b8c:	62 e1 fd 48 7f 64 08 04                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x100],zmm20
   87b94:	62 f1 7c 48 28 54 24 0b                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x2c0]
   87b9c:	62 91 ad 48 db c7                               	vpandq zmm0,zmm10,zmm31
   87ba2:	62 01 8d 48 db df                               	vpandq zmm27,zmm14,zmm31
   87ba8:	62 f1 b5 40 73 d3 34                            	vpsrlq zmm25,zmm3,0x34
   87baf:	62 a1 b5 40 d4 f6                               	vpaddq zmm22,zmm25,zmm22
   87bb5:	62 f1 7c 48 29 4c 08 05                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x140],zmm1
   87bbd:	62 f1 7c 48 28 4c 24 0a                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x280]
   87bc5:	62 f1 7c 48 29 54 08 06                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x180],zmm2
   87bcd:	62 f1 7c 48 28 54 24 0c                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x300]
   87bd5:	62 b1 b5 40 73 d6 34                            	vpsrlq zmm25,zmm22,0x34
   87bdc:	62 a1 b5 40 d4 ff                               	vpaddq zmm23,zmm25,zmm23
   87be2:	62 b1 b5 40 73 d7 34                            	vpsrlq zmm25,zmm23,0x34
   87be9:	62 01 b5 40 d4 c0                               	vpaddq zmm24,zmm25,zmm24
   87bef:	62 91 b5 40 73 d0 34                            	vpsrlq zmm25,zmm24,0x34
   87bf6:	62 a1 b5 40 d4 ed                               	vpaddq zmm21,zmm25,zmm21
   87bfc:	62 01 9d 48 db cf                               	vpandq zmm25,zmm12,zmm31
   87c02:	62 f1 7c 48 29 4c 08 07                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x1c0],zmm1
   87c0a:	62 f1 7c 48 28 4c 24 0e                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x380]
   87c12:	62 f1 7c 48 29 54 08 08                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x200],zmm2
   87c1a:	62 91 e5 48 db d7                               	vpandq zmm2,zmm3,zmm31
   87c20:	62 f1 7c 48 29 4c 08 09                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x240],zmm1
   87c28:	62 91 cd 40 db cf                               	vpandq zmm1,zmm22,zmm31
   87c2e:	62 f1 fd 48 7f 54 08 0a                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x280],zmm2
   87c36:	62 91 c5 40 db d7                               	vpandq zmm2,zmm23,zmm31
   87c3c:	62 f1 fd 48 7f 4c 08 0b                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x2c0],zmm1
   87c44:	62 91 bd 40 db cf                               	vpandq zmm1,zmm24,zmm31
   87c4a:	62 f1 fd 48 7f 54 08 0c                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x300],zmm2
   87c52:	62 01 fd 40 db c7                               	vpandq zmm24,zmm16,zmm31
   87c58:	62 f1 fd 48 7f 4c 08 0d                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x340],zmm1
   87c60:	62 e1 fd 48 7f 6c 08 0e                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x380],zmm21
   87c68:	62 71 fd 48 7f 44 08 0f                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x3c0],zmm8
   87c70:	62 71 fd 48 7f 6c 08 10                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x400],zmm13
   87c78:	c5 7d 6f 2d 60 fb f7 ff                         	vmovdqa ymm13,YMMWORD PTR [rip+0xfffffffffff7fb60]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   87c80:	62 71 fd 48 7f 7c 08 11                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x440],zmm15
   87c88:	62 e1 fd 48 7f 4c 08 12                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x480],zmm17
   87c90:	62 e1 fd 48 7f 5c 08 13                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x4c0],zmm19
   87c98:	62 f1 fd 48 7f 44 08 14                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x500],zmm0
   87ca0:	62 91 cd 48 db c7                               	vpandq zmm0,zmm6,zmm31
   87ca6:	62 f1 fd 48 7f 44 08 15                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x540],zmm0
   87cae:	62 91 c5 48 db c7                               	vpandq zmm0,zmm7,zmm31
   87cb4:	62 f1 fd 48 7f 44 08 16                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x580],zmm0
   87cbc:	62 91 b5 48 db c7                               	vpandq zmm0,zmm9,zmm31
   87cc2:	62 f1 fd 48 7f 44 08 17                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x5c0],zmm0
   87cca:	62 f1 fd 48 7f 6c 08 18                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x600],zmm5
   87cd2:	48 89 57 10                                     	mov    QWORD PTR [rdi+0x10],rdx
   87cd6:	48 89 f7                                        	mov    rdi,rsi
   87cd9:	49 39 f3                                        	cmp    r11,rsi
   87cdc:	0f 84 88 f2 ff ff                               	je     86f6a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x118a>
   87ce2:	4c 89 f8                                        	mov    rax,r15
   87ce5:	48 29 f8                                        	sub    rax,rdi
   87ce8:	be 00 00 00 00                                  	mov    esi,0x0
   87ced:	48 0f 43 f0                                     	cmovae rsi,rax
   87cf1:	0f 86 fe 45 00 00                               	jbe    8c2f5 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6515>
   87cf7:	41 8b 45 00                                     	mov    eax,DWORD PTR [r13+0x0]
   87cfb:	25 ff ff ff 7f                                  	and    eax,0x7fffffff
   87d00:	49 39 c4                                        	cmp    r12,rax
   87d03:	0f 86 7f 46 00 00                               	jbe    8c388 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x65a8>
   87d09:	48 83 fe 01                                     	cmp    rsi,0x1
   87d0d:	0f 84 df 45 00 00                               	je     8c2f2 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6512>
   87d13:	41 8b 55 10                                     	mov    edx,DWORD PTR [r13+0x10]
   87d17:	81 e2 ff ff ff 7f                               	and    edx,0x7fffffff
   87d1d:	49 39 d4                                        	cmp    r12,rdx
   87d20:	0f 86 ff 45 00 00                               	jbe    8c325 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6545>
   87d26:	48 83 fe 02                                     	cmp    rsi,0x2
   87d2a:	0f 84 bc 45 00 00                               	je     8c2ec <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x650c>
   87d30:	45 8b 45 20                                     	mov    r8d,DWORD PTR [r13+0x20]
   87d34:	41 81 e0 ff ff ff 7f                            	and    r8d,0x7fffffff
   87d3b:	4d 39 c4                                        	cmp    r12,r8
   87d3e:	0f 86 c9 45 00 00                               	jbe    8c30d <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x652d>
   87d44:	48 83 fe 03                                     	cmp    rsi,0x3
   87d48:	0f 84 98 45 00 00                               	je     8c2e6 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6506>
   87d4e:	45 8b 4d 30                                     	mov    r9d,DWORD PTR [r13+0x30]
   87d52:	41 81 e1 ff ff ff 7f                            	and    r9d,0x7fffffff
   87d59:	4d 39 cc                                        	cmp    r12,r9
   87d5c:	0f 86 60 45 00 00                               	jbe    8c2c2 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x64e2>
   87d62:	48 83 fe 04                                     	cmp    rsi,0x4
   87d66:	0f 84 74 45 00 00                               	je     8c2e0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6500>
   87d6c:	45 8b 55 40                                     	mov    r10d,DWORD PTR [r13+0x40]
   87d70:	41 81 e2 ff ff ff 7f                            	and    r10d,0x7fffffff
   87d77:	4d 39 d4                                        	cmp    r12,r10
   87d7a:	0f 86 05 46 00 00                               	jbe    8c385 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x65a5>
   87d80:	48 83 fe 05                                     	cmp    rsi,0x5
   87d84:	0f 84 50 45 00 00                               	je     8c2da <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x64fa>
   87d8a:	45 8b 5d 50                                     	mov    r11d,DWORD PTR [r13+0x50]
   87d8e:	41 81 e3 ff ff ff 7f                            	and    r11d,0x7fffffff
   87d95:	4d 39 dc                                        	cmp    r12,r11
   87d98:	0f 86 cf 45 00 00                               	jbe    8c36d <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x658d>
   87d9e:	48 83 fe 06                                     	cmp    rsi,0x6
   87da2:	0f 84 14 45 00 00                               	je     8c2bc <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x64dc>
   87da8:	41 8b 5d 60                                     	mov    ebx,DWORD PTR [r13+0x60]
   87dac:	81 e3 ff ff ff 7f                               	and    ebx,0x7fffffff
   87db2:	49 39 dc                                        	cmp    r12,rbx
   87db5:	0f 86 9a 45 00 00                               	jbe    8c355 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6575>
   87dbb:	48 8d 4f 07                                     	lea    rcx,[rdi+0x7]
   87dbf:	48 83 fe 07                                     	cmp    rsi,0x7
   87dc3:	0f 84 2f 45 00 00                               	je     8c2f8 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6518>
   87dc9:	41 8b 75 70                                     	mov    esi,DWORD PTR [r13+0x70]
   87dcd:	81 e6 ff ff ff 7f                               	and    esi,0x7fffffff
   87dd3:	49 39 f4                                        	cmp    r12,rsi
   87dd6:	0f 86 61 45 00 00                               	jbe    8c33d <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x655d>
   87ddc:	48 c1 e3 06                                     	shl    rbx,0x6
   87de0:	48 c1 e6 06                                     	shl    rsi,0x6
   87de4:	48 c1 e2 06                                     	shl    rdx,0x6
   87de8:	49 c1 e0 06                                     	shl    r8,0x6
   87dec:	48 c1 e0 06                                     	shl    rax,0x6
   87df0:	49 c1 e1 06                                     	shl    r9,0x6
   87df4:	49 c1 e2 06                                     	shl    r10,0x6
   87df8:	49 c1 e3 06                                     	shl    r11,0x6
   87dfc:	c4 c1 7e 6f 34 1e                               	vmovdqu ymm6,YMMWORD PTR [r14+rbx*1]
   87e02:	c4 c1 7c 10 7c 1e 20                            	vmovups ymm7,YMMWORD PTR [r14+rbx*1+0x20]
   87e09:	c4 c1 7e 6f 0c 16                               	vmovdqu ymm1,YMMWORD PTR [r14+rdx*1]
   87e0f:	62 c1 7c 28 10 5c 16 01                         	vmovups ymm19,YMMWORD PTR [r14+rdx*1+0x20]
   87e17:	49 8b 55 28                                     	mov    rdx,QWORD PTR [r13+0x28]
   87e1b:	c4 81 7e 6f 14 06                               	vmovdqu ymm2,YMMWORD PTR [r14+r8*1]
   87e21:	62 81 7c 28 10 64 06 01                         	vmovups ymm20,YMMWORD PTR [r14+r8*1+0x20]
   87e29:	4d 8b 45 08                                     	mov    r8,QWORD PTR [r13+0x8]
   87e2d:	c4 c1 7e 6f 04 06                               	vmovdqu ymm0,YMMWORD PTR [r14+rax*1]
   87e33:	62 c1 7c 28 10 4c 06 01                         	vmovups ymm17,YMMWORD PTR [r14+rax*1+0x20]
   87e3b:	c4 81 7e 6f 1c 0e                               	vmovdqu ymm3,YMMWORD PTR [r14+r9*1]
   87e41:	62 81 7c 28 10 6c 0e 01                         	vmovups ymm21,YMMWORD PTR [r14+r9*1+0x20]
   87e49:	c4 81 7e 6f 24 16                               	vmovdqu ymm4,YMMWORD PTR [r14+r10*1]
   87e4f:	62 81 7c 28 10 74 16 01                         	vmovups ymm22,YMMWORD PTR [r14+r10*1+0x20]
   87e57:	c4 81 7e 6f 2c 1e                               	vmovdqu ymm5,YMMWORD PTR [r14+r11*1]
   87e5d:	62 81 7c 28 10 7c 1e 01                         	vmovups ymm23,YMMWORD PTR [r14+r11*1+0x20]
   87e65:	49 ba 31 e1 72 4e 64 30 00 00                   	movabs r10,0x30644e72e131
   87e6f:	62 53 cd 48 3a 14 36 01                         	vinserti64x4 zmm10,zmm6,YMMWORD PTR [r14+rsi*1],0x1
   87e77:	62 d3 c5 48 1a 74 36 01 01                      	vinsertf64x4 zmm6,zmm7,YMMWORD PTR [r14+rsi*1+0x20],0x1
   87e80:	49 8b 75 18                                     	mov    rsi,QWORD PTR [r13+0x18]
   87e84:	c5 7e 6f 0a                                     	vmovdqu ymm9,YMMWORD PTR [rdx]
   87e88:	c5 7e 6f 7a 20                                  	vmovdqu ymm15,YMMWORD PTR [rdx+0x20]
   87e8d:	49 8b 55 68                                     	mov    rdx,QWORD PTR [r13+0x68]
   87e91:	c4 41 7e 6f 00                                  	vmovdqu ymm8,YMMWORD PTR [r8]
   87e96:	c4 41 7c 10 70 20                               	vmovups ymm14,YMMWORD PTR [r8+0x20]
   87e9c:	4d 8b 45 48                                     	mov    r8,QWORD PTR [r13+0x48]
   87ea0:	62 61 7c 28 10 6e 01                            	vmovups ymm29,YMMWORD PTR [rsi+0x20]
   87ea7:	62 f1 7c 48 29 74 24 16                         	vmovaps ZMMWORD PTR [rsp+0x580],zmm6
   87eaf:	62 f3 bd 48 3a 36 01                            	vinserti64x4 zmm6,zmm8,YMMWORD PTR [rsi],0x1
   87eb6:	49 8b 75 58                                     	mov    rsi,QWORD PTR [r13+0x58]
   87eba:	c5 7e 6f 22                                     	vmovdqu ymm12,YMMWORD PTR [rdx]
   87ebe:	62 e1 7c 28 10 52 01                            	vmovups ymm18,YMMWORD PTR [rdx+0x20]
   87ec5:	49 8b 55 38                                     	mov    rdx,QWORD PTR [r13+0x38]
   87ec9:	c4 41 7e 6f 18                                  	vmovdqu ymm11,YMMWORD PTR [r8]
   87ece:	62 c1 7c 28 10 40 01                            	vmovups ymm16,YMMWORD PTR [r8+0x20]
   87ed5:	c5 7c 10 46 20                                  	vmovups ymm8,YMMWORD PTR [rsi+0x20]
   87eda:	62 61 7c 28 10 72 01                            	vmovups ymm30,YMMWORD PTR [rdx+0x20]
   87ee1:	62 f3 b5 48 3a 3a 01                            	vinserti64x4 zmm7,zmm9,YMMWORD PTR [rdx],0x1
   87ee8:	49 8b 55 78                                     	mov    rdx,QWORD PTR [r13+0x78]
   87eec:	62 73 9d 48 3a 0a 01                            	vinserti64x4 zmm9,zmm12,YMMWORD PTR [rdx],0x1
   87ef3:	c5 7c 29 84 24 80 03 00 00                      	vmovaps YMMWORD PTR [rsp+0x380],ymm8
   87efc:	62 73 a5 48 3a 06 01                            	vinserti64x4 zmm8,zmm11,YMMWORD PTR [rsi],0x1
   87f03:	c5 7c 10 5a 20                                  	vmovups ymm11,YMMWORD PTR [rdx+0x20]
   87f08:	48 8d 77 08                                     	lea    rsi,[rdi+0x8]
   87f0c:	c5 7e 7f ac 24 c0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xc0],ymm13
   87f15:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   87f1d:	4c 39 f9                                        	cmp    rcx,r15
   87f20:	0f 83 9c 41 00 00                               	jae    8c0c2 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x62e2>
   87f26:	62 e1 7c 48 29 4c 24 23                         	vmovaps ZMMWORD PTR [rsp+0x8c0],zmm17
   87f2e:	62 e1 7c 48 29 44 24 24                         	vmovaps ZMMWORD PTR [rsp+0x900],zmm16
   87f36:	62 e1 fd 48 6f 0d c0 f5 f7 ff                   	vmovdqa64 zmm17,ZMMWORD PTR [rip+0xfffffffffff7f5c0]        # 7500 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x560>
   87f40:	62 e1 fd 48 6f 05 f6 f5 f7 ff                   	vmovdqa64 zmm16,ZMMWORD PTR [rip+0xfffffffffff7f5f6]        # 7540 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x5a0>
   87f4a:	62 f3 fd 48 3a c1 01                            	vinserti64x4 zmm0,zmm0,ymm1,0x1
   87f51:	62 f3 ed 48 3a cb 01                            	vinserti64x4 zmm1,zmm2,ymm3,0x1
   87f58:	62 f3 dd 48 3a d5 01                            	vinserti64x4 zmm2,zmm4,ymm5,0x1
   87f5f:	c5 7c 29 9c 24 c0 09 00 00                      	vmovaps YMMWORD PTR [rsp+0x9c0],ymm11
   87f68:	62 71 7c 48 29 74 24 26                         	vmovaps ZMMWORD PTR [rsp+0x980],zmm14
   87f70:	62 61 7c 28 29 74 24 4f                         	vmovaps YMMWORD PTR [rsp+0x9e0],ymm30
   87f78:	62 61 7c 28 29 6c 24 50                         	vmovaps YMMWORD PTR [rsp+0xa00],ymm29
   87f80:	62 e1 7c 28 29 7c 24 51                         	vmovaps YMMWORD PTR [rsp+0xa20],ymm23
   87f88:	48 8b bc 24 c0 03 00 00                         	mov    rdi,QWORD PTR [rsp+0x3c0]
   87f90:	62 e1 7c 28 29 5c 24 30                         	vmovaps YMMWORD PTR [rsp+0x600],ymm19
   87f98:	62 e1 7c 48 29 54 24 22                         	vmovaps ZMMWORD PTR [rsp+0x880],zmm18
   87fa0:	62 e1 7c 48 29 74 24 3f                         	vmovaps ZMMWORD PTR [rsp+0xfc0],zmm22
   87fa8:	62 e1 7c 28 29 6c 24 52                         	vmovaps YMMWORD PTR [rsp+0xa40],ymm21
   87fb0:	62 e1 7c 48 29 64 24 21                         	vmovaps ZMMWORD PTR [rsp+0x840],zmm20
   87fb8:	4d 89 e8                                        	mov    r8,r13
   87fbb:	45 8b 4d 00                                     	mov    r9d,DWORD PTR [r13+0x0]
   87fbf:	45 8b 75 10                                     	mov    r14d,DWORD PTR [r13+0x10]
   87fc3:	45 8b 6d 20                                     	mov    r13d,DWORD PTR [r13+0x20]
   87fc7:	41 8b 58 30                                     	mov    ebx,DWORD PTR [r8+0x30]
   87fcb:	45 8b 78 40                                     	mov    r15d,DWORD PTR [r8+0x40]
   87fcf:	41 8b 40 50                                     	mov    eax,DWORD PTR [r8+0x50]
   87fd3:	41 8b 48 60                                     	mov    ecx,DWORD PTR [r8+0x60]
   87fd7:	45 0f b6 60 73                                  	movzx  r12d,BYTE PTR [r8+0x73]
   87fdc:	62 71 fd 48 7f 7c 24 25                         	vmovdqa64 ZMMWORD PTR [rsp+0x940],zmm15
   87fe4:	62 71 fd 48 6d d9                               	vpunpckhqdq zmm11,zmm0,zmm1
   87fea:	62 f1 fd 48 6c d9                               	vpunpcklqdq zmm3,zmm0,zmm1
   87ff0:	62 d1 ed 48 6c c2                               	vpunpcklqdq zmm0,zmm2,zmm10
   87ff6:	62 d1 ed 48 6d ca                               	vpunpckhqdq zmm1,zmm2,zmm10
   87ffc:	62 f1 fd 48 6f d3                               	vmovdqa64 zmm2,zmm3
   88002:	62 d1 fd 48 6f e3                               	vmovdqa64 zmm4,zmm11
   88008:	48 8b 57 10                                     	mov    rdx,QWORD PTR [rdi+0x10]
   8800c:	62 f2 f5 40 7e d0                               	vpermt2q zmm2,zmm17,zmm0
   88012:	62 72 fd 40 7e d9                               	vpermt2q zmm11,zmm16,zmm1
   88018:	62 f2 f5 40 7e e1                               	vpermt2q zmm4,zmm17,zmm1
   8801e:	62 f2 fd 40 7e d8                               	vpermt2q zmm3,zmm16,zmm0
   88024:	62 91 ed 48 db ef                               	vpandq zmm5,zmm2,zmm31
   8802a:	62 f3 dd 48 71 c2 0c                            	vpshldq zmm0,zmm4,zmm2,0xc
   88031:	62 f3 e5 48 71 d4 18                            	vpshldq zmm2,zmm3,zmm4,0x18
   88038:	62 f3 a5 48 71 cb 24                            	vpshldq zmm1,zmm11,zmm3,0x24
   8803f:	62 71 fd 48 7f 5c 24 1a                         	vmovdqa64 ZMMWORD PTR [rsp+0x680],zmm11
   88047:	62 71 cd 48 6c df                               	vpunpcklqdq zmm11,zmm6,zmm7
   8804d:	62 f1 cd 48 6d f7                               	vpunpckhqdq zmm6,zmm6,zmm7
   88053:	62 d1 fd 48 6f db                               	vmovdqa64 zmm3,zmm11
   88059:	62 f1 fd 48 6f e6                               	vmovdqa64 zmm4,zmm6
   8805f:	62 f1 fd 48 7f 6c 24 13                         	vmovdqa64 ZMMWORD PTR [rsp+0x4c0],zmm5
   88067:	62 11 ed 48 db e7                               	vpandq zmm12,zmm2,zmm31
   8806d:	62 11 f5 48 db f7                               	vpandq zmm14,zmm1,zmm31
   88073:	62 d1 bd 48 6c c9                               	vpunpcklqdq zmm1,zmm8,zmm9
   88079:	62 d1 bd 48 6d d1                               	vpunpckhqdq zmm2,zmm8,zmm9
   8807f:	62 11 fd 48 db d7                               	vpandq zmm10,zmm0,zmm31
   88085:	62 f2 fd 40 7e f2                               	vpermt2q zmm6,zmm16,zmm2
   8808b:	62 72 fd 40 7e d9                               	vpermt2q zmm11,zmm16,zmm1
   88091:	62 f2 f5 40 7e d9                               	vpermt2q zmm3,zmm17,zmm1
   88097:	62 f2 f5 40 7e e2                               	vpermt2q zmm4,zmm17,zmm2
   8809d:	62 71 fd 48 7f 74 24 1e                         	vmovdqa64 ZMMWORD PTR [rsp+0x780],zmm14
   880a5:	62 71 fd 48 7f 54 24 12                         	vmovdqa64 ZMMWORD PTR [rsp+0x480],zmm10
   880ad:	62 71 fd 48 7f 64 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm12
   880b5:	62 f3 dd 48 71 cb 0c                            	vpshldq zmm1,zmm4,zmm3,0xc
   880bc:	62 f3 a5 48 71 e4 18                            	vpshldq zmm4,zmm11,zmm4,0x18
   880c3:	62 d3 cd 48 71 c3 24                            	vpshldq zmm0,zmm6,zmm11,0x24
   880ca:	62 72 fd 48 59 1d 9c eb f7 ff                   	vpbroadcastq zmm11,QWORD PTR [rip+0xfffffffffff7eb9c]        # 6c70 <GCC_except_table711+0x180>
   880d4:	62 91 e5 48 db d7                               	vpandq zmm2,zmm3,zmm31
   880da:	62 f1 fd 48 7f 74 24 19                         	vmovdqa64 ZMMWORD PTR [rsp+0x640],zmm6
   880e2:	62 f1 fd 48 7f 54 24 15                         	vmovdqa64 ZMMWORD PTR [rsp+0x540],zmm2
   880ea:	62 f1 ed 48 fb d5                               	vpsubq zmm2,zmm2,zmm5
   880f0:	62 91 f5 48 db df                               	vpandq zmm3,zmm1,zmm31
   880f6:	62 91 dd 48 db cf                               	vpandq zmm1,zmm4,zmm31
   880fc:	62 91 fd 48 db e7                               	vpandq zmm4,zmm0,zmm31
   88102:	62 f1 fd 48 7f 4c 24 1c                         	vmovdqa64 ZMMWORD PTR [rsp+0x700],zmm1
   8810a:	62 f1 fd 48 7f 5c 24 1d                         	vmovdqa64 ZMMWORD PTR [rsp+0x740],zmm3
   88112:	62 f1 fd 48 7f 64 24 1b                         	vmovdqa64 ZMMWORD PTR [rsp+0x6c0],zmm4
   8811a:	62 c1 ed 48 d4 cb                               	vpaddq zmm17,zmm2,zmm11
   88120:	62 b1 fd 48 72 e1 34                            	vpsraq zmm0,zmm17,0x34
   88127:	62 f1 fd 58 d4 44 24 19                         	vpaddq zmm0,zmm0,QWORD BCST [rsp+0xc8]
   8812f:	62 f1 fd 48 d4 c3                               	vpaddq zmm0,zmm0,zmm3
   88135:	62 41 fd 48 fb f2                               	vpsubq zmm30,zmm0,zmm10
   8813b:	62 91 fd 48 72 e6 34                            	vpsraq zmm0,zmm30,0x34
   88142:	62 f1 fd 58 d4 44 24 1a                         	vpaddq zmm0,zmm0,QWORD BCST [rsp+0xd0]
   8814a:	62 f1 fd 48 d4 c1                               	vpaddq zmm0,zmm0,zmm1
   88150:	62 41 fd 48 fb ec                               	vpsubq zmm29,zmm0,zmm12
   88156:	62 91 fd 48 72 e5 34                            	vpsraq zmm0,zmm29,0x34
   8815d:	62 f1 fd 58 d4 44 24 1b                         	vpaddq zmm0,zmm0,QWORD BCST [rsp+0xd8]
   88165:	62 f1 fd 48 d4 c4                               	vpaddq zmm0,zmm0,zmm4
   8816b:	62 c1 fd 48 fb fe                               	vpsubq zmm23,zmm0,zmm14
   88171:	62 b1 fd 48 72 e7 34                            	vpsraq zmm0,zmm23,0x34
   88178:	62 f1 fd 58 d4 44 24 1c                         	vpaddq zmm0,zmm0,QWORD BCST [rsp+0xe0]
   88180:	c5 7e 7f ac 24 c0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xc0],ymm13
   88189:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   88191:	62 f2 fd 48 19 4c 24 1a                         	vbroadcastsd zmm1,QWORD PTR [rsp+0xd0]
   88199:	62 72 fd 48 59 74 24 19                         	vpbroadcastq zmm14,QWORD PTR [rsp+0xc8]
   881a1:	62 e2 fd 48 59 5c 24 1b                         	vpbroadcastq zmm19,QWORD PTR [rsp+0xd8]
   881a9:	62 e2 fd 48 59 54 24 1c                         	vpbroadcastq zmm18,QWORD PTR [rsp+0xe0]
   881b1:	c5 7e 7f ac 24 c0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xc0],ymm13
   881ba:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   881c2:	62 e2 fd 48 59 44 24 19                         	vpbroadcastq zmm16,QWORD PTR [rsp+0xc8]
   881ca:	62 e2 fd 48 59 74 24 1a                         	vpbroadcastq zmm22,QWORD PTR [rsp+0xd0]
   881d2:	62 e2 fd 48 59 6c 24 1b                         	vpbroadcastq zmm21,QWORD PTR [rsp+0xd8]
   881da:	62 e2 fd 48 59 64 24 1c                         	vpbroadcastq zmm20,QWORD PTR [rsp+0xe0]
   881e2:	62 f1 fd 48 7f 44 24 20                         	vmovdqa64 ZMMWORD PTR [rsp+0x800],zmm0
   881ea:	62 f1 7c 48 29 4c 24 14                         	vmovaps ZMMWORD PTR [rsp+0x500],zmm1
   881f2:	48 3b 17                                        	cmp    rdx,QWORD PTR [rdi]
   881f5:	0f 85 05 ee ff ff                               	jne    87000 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x1220>
   881fb:	62 61 fd 48 7f 54 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm26
   88203:	62 61 fd 48 7f 44 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm24
   8820b:	62 61 fd 48 7f 4c 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm25
   88213:	62 61 fd 48 7f 5c 24 0c                         	vmovdqa64 ZMMWORD PTR [rsp+0x300],zmm27
   8821b:	48 89 94 24 78 03 00 00                         	mov    QWORD PTR [rsp+0x378],rdx
   88223:	62 61 fd 48 7f 64 24 3e                         	vmovdqa64 ZMMWORD PTR [rsp+0xf80],zmm28
   8822b:	48 89 b4 24 70 03 00 00                         	mov    QWORD PTR [rsp+0x370],rsi
   88233:	4c 89 84 24 68 03 00 00                         	mov    QWORD PTR [rsp+0x368],r8
   8823b:	62 e1 fd 48 7f 64 24 3d                         	vmovdqa64 ZMMWORD PTR [rsp+0xf40],zmm20
   88243:	62 e1 fd 48 7f 6c 24 3c                         	vmovdqa64 ZMMWORD PTR [rsp+0xf00],zmm21
   8824b:	62 e1 fd 48 7f 74 24 3b                         	vmovdqa64 ZMMWORD PTR [rsp+0xec0],zmm22
   88253:	62 e1 fd 48 7f 44 24 3a                         	vmovdqa64 ZMMWORD PTR [rsp+0xe80],zmm16
   8825b:	62 e1 fd 48 7f 7c 24 39                         	vmovdqa64 ZMMWORD PTR [rsp+0xe40],zmm23
   88263:	62 61 fd 48 7f 6c 24 38                         	vmovdqa64 ZMMWORD PTR [rsp+0xe00],zmm29
   8826b:	62 61 fd 48 7f 74 24 37                         	vmovdqa64 ZMMWORD PTR [rsp+0xdc0],zmm30
   88273:	62 e1 fd 48 7f 4c 24 36                         	vmovdqa64 ZMMWORD PTR [rsp+0xd80],zmm17
   8827b:	62 e1 fd 48 7f 54 24 35                         	vmovdqa64 ZMMWORD PTR [rsp+0xd40],zmm18
   88283:	62 e1 fd 48 7f 5c 24 34                         	vmovdqa64 ZMMWORD PTR [rsp+0xd00],zmm19
   8828b:	62 71 fd 48 7f 74 24 33                         	vmovdqa64 ZMMWORD PTR [rsp+0xcc0],zmm14
   88293:	89 84 24 9c 00 00 00                            	mov    DWORD PTR [rsp+0x9c],eax
   8829a:	89 8c 24 98 00 00 00                            	mov    DWORD PTR [rsp+0x98],ecx
   882a1:	44 89 8c 24 94 00 00 00                         	mov    DWORD PTR [rsp+0x94],r9d
   882a9:	c5 f8 77                                        	vzeroupper
   882ac:	e8 ff b8 00 00                                  	call   93bb0 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecNtNtCsHW5vo2gROj_10zopro_core3msm10FqAddGroupE8grow_oneBP_>
   882b1:	62 71 fd 48 6f 74 24 33                         	vmovdqa64 zmm14,ZMMWORD PTR [rsp+0xcc0]
   882b9:	62 e1 fd 48 6f 5c 24 34                         	vmovdqa64 zmm19,ZMMWORD PTR [rsp+0xd00]
   882c1:	62 e1 fd 48 6f 54 24 35                         	vmovdqa64 zmm18,ZMMWORD PTR [rsp+0xd40]
   882c9:	62 e1 fd 48 6f 4c 24 36                         	vmovdqa64 zmm17,ZMMWORD PTR [rsp+0xd80]
   882d1:	62 61 fd 48 6f 74 24 37                         	vmovdqa64 zmm30,ZMMWORD PTR [rsp+0xdc0]
   882d9:	62 61 fd 48 6f 6c 24 38                         	vmovdqa64 zmm29,ZMMWORD PTR [rsp+0xe00]
   882e1:	62 e1 fd 48 6f 7c 24 39                         	vmovdqa64 zmm23,ZMMWORD PTR [rsp+0xe40]
   882e9:	62 e1 fd 48 6f 44 24 3a                         	vmovdqa64 zmm16,ZMMWORD PTR [rsp+0xe80]
   882f1:	62 e1 fd 48 6f 74 24 3b                         	vmovdqa64 zmm22,ZMMWORD PTR [rsp+0xec0]
   882f9:	62 e1 fd 48 6f 6c 24 3c                         	vmovdqa64 zmm21,ZMMWORD PTR [rsp+0xf00]
   88301:	62 e1 fd 48 6f 64 24 3d                         	vmovdqa64 zmm20,ZMMWORD PTR [rsp+0xf40]
   88309:	62 72 fd 48 59 1d 5d e9 f7 ff                   	vpbroadcastq zmm11,QWORD PTR [rip+0xfffffffffff7e95d]        # 6c70 <GCC_except_table711+0x180>
   88313:	62 62 fd 48 59 3d 23 e9 f7 ff                   	vpbroadcastq zmm31,QWORD PTR [rip+0xfffffffffff7e923]        # 6c40 <GCC_except_table711+0x150>
   8831d:	62 61 fd 48 6f 64 24 3e                         	vmovdqa64 zmm28,ZMMWORD PTR [rsp+0xf80]
   88325:	62 61 fd 48 6f 5c 24 0c                         	vmovdqa64 zmm27,ZMMWORD PTR [rsp+0x300]
   8832d:	62 61 fd 48 6f 4c 24 0a                         	vmovdqa64 zmm25,ZMMWORD PTR [rsp+0x280]
   88335:	62 61 fd 48 6f 44 24 0b                         	vmovdqa64 zmm24,ZMMWORD PTR [rsp+0x2c0]
   8833d:	62 61 fd 48 6f 54 24 09                         	vmovdqa64 zmm26,ZMMWORD PTR [rsp+0x240]
   88345:	44 8b 8c 24 94 00 00 00                         	mov    r9d,DWORD PTR [rsp+0x94]
   8834d:	8b 8c 24 98 00 00 00                            	mov    ecx,DWORD PTR [rsp+0x98]
   88354:	8b 84 24 9c 00 00 00                            	mov    eax,DWORD PTR [rsp+0x9c]
   8835b:	4c 8b 84 24 68 03 00 00                         	mov    r8,QWORD PTR [rsp+0x368]
   88363:	48 8b b4 24 70 03 00 00                         	mov    rsi,QWORD PTR [rsp+0x370]
   8836b:	48 8b 94 24 78 03 00 00                         	mov    rdx,QWORD PTR [rsp+0x378]
   88373:	48 8b bc 24 c0 03 00 00                         	mov    rdi,QWORD PTR [rsp+0x3c0]
   8837b:	49 ba 31 e1 72 4e 64 30 00 00                   	movabs r10,0x30644e72e131
   88385:	e9 76 ec ff ff                                  	jmp    87000 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x1220>
   8838a:	45 31 ed                                        	xor    r13d,r13d
   8838d:	49 c7 40 28 00 00 00 00                         	mov    QWORD PTR [r8+0x28],0x0
   88395:	4d 39 fb                                        	cmp    r11,r15
   88398:	41 0f b6 40 32                                  	movzx  eax,BYTE PTR [r8+0x32]
   8839d:	0f 94 c1                                        	sete   cl
   883a0:	84 c1                                           	test   cl,al
   883a2:	74 5d                                           	je     88401 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x2621>
   883a4:	48 8d bc 24 c0 00 00 00                         	lea    rdi,[rsp+0xc0]
   883ac:	48 8d b4 24 80 0b 00 00                         	lea    rsi,[rsp+0xb80]
   883b4:	c5 f8 77                                        	vzeroupper
   883b7:	e8 64 b8 00 00                                  	call   93c20 <_RNvMs3_NtCsHW5vo2gROj_10zopro_core4simdNtB5_7FqBatch15inverse_nonzero>
   883bc:	62 71 fd 48 6f 54 24 03                         	vmovdqa64 zmm10,ZMMWORD PTR [rsp+0xc0]
   883c4:	62 71 fd 48 6f 5c 24 04                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x100]
   883cc:	62 71 fd 48 6f 6c 24 05                         	vmovdqa64 zmm13,ZMMWORD PTR [rsp+0x140]
   883d4:	62 71 fd 48 6f 74 24 06                         	vmovdqa64 zmm14,ZMMWORD PTR [rsp+0x180]
   883dc:	62 71 fd 48 6f 64 24 07                         	vmovdqa64 zmm12,ZMMWORD PTR [rsp+0x1c0]
   883e4:	4c 8b 4c 24 30                                  	mov    r9,QWORD PTR [rsp+0x30]
   883e9:	49 ba 31 e1 72 4e 64 30 00 00                   	movabs r10,0x30644e72e131
   883f3:	4d 85 ed                                        	test   r13,r13
   883f6:	0f 85 af 22 00 00                               	jne    8a6ab <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x48cb>
   883fc:	e9 9d 3c 00 00                                  	jmp    8c09e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x62be>
   88401:	c5 fc 28 05 d7 f3 f7 ff                         	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffff7f3d7]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   88409:	62 f1 9d 50 d4 25 05 e9 f7 ff                   	vpaddq zmm4,zmm28,QWORD BCST [rip+0xfffffffffff7e905]        # 6d18 <GCC_except_table711+0x228>
   88413:	62 f2 fd 48 59 35 23 e8 f7 ff                   	vpbroadcastq zmm6,QWORD PTR [rip+0xfffffffffff7e823]        # 6c40 <GCC_except_table711+0x150>
   8841d:	c5 fc 11 84 24 c0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xc0],ymm0
   88426:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   8842e:	62 f1 d5 48 72 e4 34                            	vpsraq zmm5,zmm4,0x34
   88435:	62 f1 a5 50 fb 44 24 19                         	vpsubq zmm0,zmm27,QWORD BCST [rsp+0xc8]
   8843d:	62 f1 b5 50 fb 4c 24 1a                         	vpsubq zmm1,zmm25,QWORD BCST [rsp+0xd0]
   88445:	62 f1 bd 50 fb 54 24 1b                         	vpsubq zmm2,zmm24,QWORD BCST [rsp+0xd8]
   8844d:	62 f1 ad 50 fb 5c 24 1c                         	vpsubq zmm3,zmm26,QWORD BCST [rsp+0xe0]
   88455:	62 f1 fd 48 d4 c5                               	vpaddq zmm0,zmm0,zmm5
   8845b:	62 f1 d5 48 72 e0 34                            	vpsraq zmm5,zmm0,0x34
   88462:	62 f1 f5 48 d4 cd                               	vpaddq zmm1,zmm1,zmm5
   88468:	62 f1 d5 48 72 e1 34                            	vpsraq zmm5,zmm1,0x34
   8846f:	62 f1 ed 48 d4 d5                               	vpaddq zmm2,zmm2,zmm5
   88475:	62 f1 d5 48 72 e2 34                            	vpsraq zmm5,zmm2,0x34
   8847c:	62 f1 e5 48 d4 dd                               	vpaddq zmm3,zmm3,zmm5
   88482:	62 f3 e5 58 1e 0d 0b e8 f7 ff 01                	vpcmpltuq k1,zmm3,QWORD BCST [rip+0xfffffffffff7e80b]        # 6c98 <GCC_except_table711+0x1a8>
   8848d:	62 61 fd 49 db de                               	vpandq zmm27{k1},zmm0,zmm6
   88493:	62 61 f5 49 db ce                               	vpandq zmm25{k1},zmm1,zmm6
   88499:	62 61 ed 49 db c6                               	vpandq zmm24{k1},zmm2,zmm6
   8849f:	62 61 dd 49 db e6                               	vpandq zmm28{k1},zmm4,zmm6
   884a5:	62 61 fd 49 6f d3                               	vmovdqa64 zmm26{k1},zmm3
   884ab:	62 f1 fd 48 6f 35 0b f1 f7 ff                   	vmovdqa64 zmm6,ZMMWORD PTR [rip+0xfffffffffff7f10b]        # 75c0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x620>
   884b5:	62 91 f5 48 73 d3 0c                            	vpsrlq zmm1,zmm27,0xc
   884bc:	62 91 ed 48 73 f1 28                            	vpsllq zmm2,zmm25,0x28
   884c3:	62 91 dd 48 73 d1 18                            	vpsrlq zmm4,zmm25,0x18
   884ca:	62 91 e5 48 73 f0 1c                            	vpsllq zmm3,zmm24,0x1c
   884d1:	62 91 fd 48 73 f3 34                            	vpsllq zmm0,zmm27,0x34
   884d8:	62 f1 ed 48 eb c9                               	vporq  zmm1,zmm2,zmm1
   884de:	62 f1 e5 48 eb d4                               	vporq  zmm2,zmm3,zmm4
   884e4:	62 91 e5 48 73 d0 24                            	vpsrlq zmm3,zmm24,0x24
   884eb:	62 91 dd 48 73 f2 10                            	vpsllq zmm4,zmm26,0x10
   884f2:	62 91 fd 48 eb c4                               	vporq  zmm0,zmm0,zmm28
   884f8:	62 f1 dd 48 eb db                               	vporq  zmm3,zmm4,zmm3
   884fe:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   88504:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   8850a:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   88510:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   88516:	62 f1 fd 48 6f 1d 60 f0 f7 ff                   	vmovdqa64 zmm3,ZMMWORD PTR [rip+0xfffffffffff7f060]        # 7580 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x5e0>
   88520:	62 f1 fd 48 6f ec                               	vmovdqa64 zmm5,zmm4
   88526:	62 f2 cd 48 7e e1                               	vpermt2q zmm4,zmm6,zmm1
   8852c:	62 f2 e5 48 7e e9                               	vpermt2q zmm5,zmm3,zmm1
   88532:	62 f2 fd 48 76 da                               	vpermi2q zmm3,zmm0,zmm2
   88538:	62 f2 cd 48 7e c2                               	vpermt2q zmm0,zmm6,zmm2
   8853e:	62 f3 d5 48 3a cb 01                            	vinserti64x4 zmm1,zmm5,ymm3,0x1
   88545:	62 f3 d5 48 43 d3 ee                            	vshufi64x2 zmm2,zmm5,zmm3,0xee
   8854c:	62 f3 dd 48 3a d8 01                            	vinserti64x4 zmm3,zmm4,ymm0,0x1
   88553:	62 f3 dd 48 43 c0 ee                            	vshufi64x2 zmm0,zmm4,zmm0,0xee
   8855a:	62 f1 fe 48 7f 4c 24 2a                         	vmovdqu64 ZMMWORD PTR [rsp+0xa80],zmm1
   88562:	62 f1 fe 48 7f 54 24 2b                         	vmovdqu64 ZMMWORD PTR [rsp+0xac0],zmm2
   8856a:	62 f1 fe 48 7f 5c 24 2c                         	vmovdqu64 ZMMWORD PTR [rsp+0xb00],zmm3
   88572:	62 f1 fe 48 7f 44 24 2d                         	vmovdqu64 ZMMWORD PTR [rsp+0xb40],zmm0
   8857a:	4d 39 fb                                        	cmp    r11,r15
   8857d:	75 25                                           	jne    885a4 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x27c4>
   8857f:	0f b6 d0                                        	movzx  edx,al
   88582:	48 8d bc 24 c0 00 00 00                         	lea    rdi,[rsp+0xc0]
   8858a:	48 8d b4 24 80 0a 00 00                         	lea    rsi,[rsp+0xa80]
   88592:	c5 f8 77                                        	vzeroupper
   88595:	e8 d6 d1 00 00                                  	call   95770 <_RNvNtCsHW5vo2gROj_10zopro_core3msm12invert_lanes>
   8859a:	4c 8b 4c 24 30                                  	mov    r9,QWORD PTR [rsp+0x30]
   8859f:	e9 4c 20 00 00                                  	jmp    8a5f0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x4810>
   885a4:	48 89 9c 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],rbx
   885ac:	48 c1 e3 07                                     	shl    rbx,0x7
   885b0:	48 8d 44 13 08                                  	lea    rax,[rbx+rdx*1+0x8]
   885b5:	e9 1d 0c 00 00                                  	jmp    891d7 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x33f7>
   885ba:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   885c0:	c5 fe 6f 41 20                                  	vmovdqu ymm0,YMMWORD PTR [rcx+0x20]
   885c5:	c5 fe 6f 0d 13 f3 f7 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff7f313]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   885cd:	45 31 d2                                        	xor    r10d,r10d
   885d0:	45 31 c9                                        	xor    r9d,r9d
   885d3:	31 d2                                           	xor    edx,edx
   885d5:	31 c0                                           	xor    eax,eax
   885d7:	4c 8d 74 24 60                                  	lea    r14,[rsp+0x60]
   885dc:	4c 8d bc 24 c0 00 00 00                         	lea    r15,[rsp+0xc0]
   885e4:	c5 fe 7f 44 24 60                               	vmovdqu YMMWORD PTR [rsp+0x60],ymm0
   885ea:	c5 fd 7f 8c 24 c0 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0xc0],ymm1
   885f3:	4d 2b 16                                        	sub    r10,QWORD PTR [r14]
   885f6:	4d 1b 4e 08                                     	sbb    r9,QWORD PTR [r14+0x8]
   885fa:	49 1b 56 10                                     	sbb    rdx,QWORD PTR [r14+0x10]
   885fe:	49 1b 46 18                                     	sbb    rax,QWORD PTR [r14+0x18]
   88602:	48 19 db                                        	sbb    rbx,rbx
   88605:	49 8b 0f                                        	mov    rcx,QWORD PTR [r15]
   88608:	49 8b 77 08                                     	mov    rsi,QWORD PTR [r15+0x8]
   8860c:	4d 8b 47 10                                     	mov    r8,QWORD PTR [r15+0x10]
   88610:	4d 8b 5f 18                                     	mov    r11,QWORD PTR [r15+0x18]
   88614:	48 21 d9                                        	and    rcx,rbx
   88617:	48 21 de                                        	and    rsi,rbx
   8861a:	49 21 d8                                        	and    r8,rbx
   8861d:	49 21 db                                        	and    r11,rbx
   88620:	49 01 ca                                        	add    r10,rcx
   88623:	49 11 f1                                        	adc    r9,rsi
   88626:	4c 11 c2                                        	adc    rdx,r8
   88629:	4c 11 d8                                        	adc    rax,r11
   8862c:	4c 89 94 24 00 05 00 00                         	mov    QWORD PTR [rsp+0x500],r10
   88634:	4c 89 8c 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],r9
   8863c:	48 89 94 24 c0 02 00 00                         	mov    QWORD PTR [rsp+0x2c0],rdx
   88644:	48 89 84 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],rax
   8864c:	48 8b 9c 24 40 07 00 00                         	mov    rbx,QWORD PTR [rsp+0x740]
   88654:	4c 8b 9c 24 40 05 00 00                         	mov    r11,QWORD PTR [rsp+0x540]
   8865c:	4c 8b 84 24 80 07 00 00                         	mov    r8,QWORD PTR [rsp+0x780]
   88664:	48 8b b4 24 40 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x440]
   8866c:	4c 8b b4 24 c0 05 00 00                         	mov    r14,QWORD PTR [rsp+0x5c0]
   88674:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8867a:	49 39 fc                                        	cmp    r12,rdi
   8867d:	0f 86 1a 3d 00 00                               	jbe    8c39d <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x65bd>
   88683:	48 c1 e7 06                                     	shl    rdi,0x6
   88687:	c5 fe 6f 0d 51 f2 f7 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff7f251]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   8868f:	4d 89 c4                                        	mov    r12,r8
   88692:	49 89 da                                        	mov    r10,rbx
   88695:	4c 8d 7c 24 60                                  	lea    r15,[rsp+0x60]
   8869a:	49 bd 89 63 86 e4 82 07 d2 87                   	movabs r13,0x87d20782e4866389
   886a4:	c4 c1 7c 10 44 3e 20                            	vmovups ymm0,YMMWORD PTR [r14+rdi*1+0x20]
   886ab:	49 8b 0c 3e                                     	mov    rcx,QWORD PTR [r14+rdi*1]
   886af:	49 8b 44 3e 08                                  	mov    rax,QWORD PTR [r14+rdi*1+0x8]
   886b4:	4d 8b 4c 3e 10                                  	mov    r9,QWORD PTR [r14+rdi*1+0x10]
   886b9:	49 8b 54 3e 18                                  	mov    rdx,QWORD PTR [r14+rdi*1+0x18]
   886be:	48 89 4c 24 60                                  	mov    QWORD PTR [rsp+0x60],rcx
   886c3:	48 89 44 24 68                                  	mov    QWORD PTR [rsp+0x68],rax
   886c8:	48 89 84 24 c0 06 00 00                         	mov    QWORD PTR [rsp+0x6c0],rax
   886d0:	4c 89 4c 24 70                                  	mov    QWORD PTR [rsp+0x70],r9
   886d5:	4c 89 8c 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],r9
   886dd:	48 89 8c 24 00 07 00 00                         	mov    QWORD PTR [rsp+0x700],rcx
   886e5:	48 89 94 24 40 06 00 00                         	mov    QWORD PTR [rsp+0x640],rdx
   886ed:	48 89 54 24 78                                  	mov    QWORD PTR [rsp+0x78],rdx
   886f2:	4c 89 d8                                        	mov    rax,r11
   886f5:	49 89 f1                                        	mov    r9,rsi
   886f8:	48 8d 94 24 c0 00 00 00                         	lea    rdx,[rsp+0xc0]
   88700:	c5 fd 7f 8c 24 c0 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0xc0],ymm1
   88709:	c5 fc 29 84 24 20 06 00 00                      	vmovaps YMMWORD PTR [rsp+0x620],ymm0
   88712:	4d 2b 0f                                        	sub    r9,QWORD PTR [r15]
   88715:	4d 1b 67 08                                     	sbb    r12,QWORD PTR [r15+0x8]
   88719:	49 1b 47 10                                     	sbb    rax,QWORD PTR [r15+0x10]
   8871d:	4d 1b 57 18                                     	sbb    r10,QWORD PTR [r15+0x18]
   88721:	48 19 db                                        	sbb    rbx,rbx
   88724:	48 8b 0a                                        	mov    rcx,QWORD PTR [rdx]
   88727:	48 8b 72 08                                     	mov    rsi,QWORD PTR [rdx+0x8]
   8872b:	4c 8b 42 10                                     	mov    r8,QWORD PTR [rdx+0x10]
   8872f:	4c 8b 5a 18                                     	mov    r11,QWORD PTR [rdx+0x18]
   88733:	48 21 d9                                        	and    rcx,rbx
   88736:	48 21 de                                        	and    rsi,rbx
   88739:	49 21 d8                                        	and    r8,rbx
   8873c:	49 21 db                                        	and    r11,rbx
   8873f:	49 01 c9                                        	add    r9,rcx
   88742:	49 11 f4                                        	adc    r12,rsi
   88745:	4c 11 c0                                        	adc    rax,r8
   88748:	4d 11 da                                        	adc    r10,r11
   8874b:	4c 89 8c 24 80 04 00 00                         	mov    QWORD PTR [rsp+0x480],r9
   88753:	4c 89 a4 24 c0 04 00 00                         	mov    QWORD PTR [rsp+0x4c0],r12
   8875b:	4c 89 94 24 80 05 00 00                         	mov    QWORD PTR [rsp+0x580],r10
   88763:	48 89 84 24 80 03 00 00                         	mov    QWORD PTR [rsp+0x380],rax
   8876b:	c5 fd 7f 8c 24 c0 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0xc0],ymm1
   88774:	4c 8d 64 24 60                                  	lea    r12,[rsp+0x60]
   88779:	4c 8d 8c 24 c0 00 00 00                         	lea    r9,[rsp+0xc0]
   88781:	c4 c1 7c 10 44 3e 20                            	vmovups ymm0,YMMWORD PTR [r14+rdi*1+0x20]
   88788:	48 8b 9c 24 40 02 00 00                         	mov    rbx,QWORD PTR [rsp+0x240]
   88790:	4c 8b b4 24 c0 02 00 00                         	mov    r14,QWORD PTR [rsp+0x2c0]
   88798:	4c 8b 94 24 80 02 00 00                         	mov    r10,QWORD PTR [rsp+0x280]
   887a0:	48 8b 84 24 00 05 00 00                         	mov    rax,QWORD PTR [rsp+0x500]
   887a8:	c5 fc 29 44 24 60                               	vmovaps YMMWORD PTR [rsp+0x60],ymm0
   887ae:	49 2b 07                                        	sub    rax,QWORD PTR [r15]
   887b1:	4d 1b 57 08                                     	sbb    r10,QWORD PTR [r15+0x8]
   887b5:	4d 1b 77 10                                     	sbb    r14,QWORD PTR [r15+0x10]
   887b9:	49 1b 5f 18                                     	sbb    rbx,QWORD PTR [r15+0x18]
   887bd:	4d 19 db                                        	sbb    r11,r11
   887c0:	48 8b 0a                                        	mov    rcx,QWORD PTR [rdx]
   887c3:	48 8b 72 08                                     	mov    rsi,QWORD PTR [rdx+0x8]
   887c7:	48 8b 7a 10                                     	mov    rdi,QWORD PTR [rdx+0x10]
   887cb:	4c 8b 42 18                                     	mov    r8,QWORD PTR [rdx+0x18]
   887cf:	4c 21 d9                                        	and    rcx,r11
   887d2:	4c 21 de                                        	and    rsi,r11
   887d5:	4c 21 df                                        	and    rdi,r11
   887d8:	4d 21 d8                                        	and    r8,r11
   887db:	48 01 c8                                        	add    rax,rcx
   887de:	49 11 f2                                        	adc    r10,rsi
   887e1:	49 11 fe                                        	adc    r14,rdi
   887e4:	4c 11 c3                                        	adc    rbx,r8
   887e7:	48 89 84 24 40 03 00 00                         	mov    QWORD PTR [rsp+0x340],rax
   887ef:	4c 89 94 24 48 03 00 00                         	mov    QWORD PTR [rsp+0x348],r10
   887f7:	4c 89 b4 24 50 03 00 00                         	mov    QWORD PTR [rsp+0x350],r14
   887ff:	48 89 9c 24 58 03 00 00                         	mov    QWORD PTR [rsp+0x358],rbx
   88807:	c5 fd 7f 8c 24 c0 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0xc0],ymm1
   88810:	4c 8d 9c 24 40 03 00 00                         	lea    r11,[rsp+0x340]
   88818:	48 8b bc 24 00 03 00 00                         	mov    rdi,QWORD PTR [rsp+0x300]
   88820:	83 e7 07                                        	and    edi,0x7
   88823:	c1 e7 05                                        	shl    edi,0x5
   88826:	c5 fc 10 84 3c 80 0a 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+rdi*1+0xa80]
   8882f:	c5 fc 29 44 24 60                               	vmovaps YMMWORD PTR [rsp+0x60],ymm0
   88835:	45 31 d2                                        	xor    r10d,r10d
   88838:	31 c0                                           	xor    eax,eax
   8883a:	45 31 ff                                        	xor    r15d,r15d
   8883d:	31 c9                                           	xor    ecx,ecx
   8883f:	45 31 f6                                        	xor    r14d,r14d
   88842:	49 8b 14 24                                     	mov    rdx,QWORD PTR [r12]
   88846:	31 db                                           	xor    ebx,ebx
   88848:	c4 42 cb f6 03                                  	mulx   r8,rsi,QWORD PTR [r11]
   8884d:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   88853:	f3 49 0f 38 f6 c0                               	adox   rax,r8
   88859:	c4 42 cb f6 43 08                               	mulx   r8,rsi,QWORD PTR [r11+0x8]
   8885f:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   88865:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   8886b:	c4 42 cb f6 43 10                               	mulx   r8,rsi,QWORD PTR [r11+0x10]
   88871:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   88877:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   8887d:	c4 42 cb f6 43 18                               	mulx   r8,rsi,QWORD PTR [r11+0x18]
   88883:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   88889:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   8888f:	66 4c 0f 38 f6 f3                               	adcx   r14,rbx
   88895:	4c 89 d2                                        	mov    rdx,r10
   88898:	49 0f af d5                                     	imul   rdx,r13
   8889c:	31 db                                           	xor    ebx,ebx
   8889e:	c4 42 cb f6 01                                  	mulx   r8,rsi,QWORD PTR [r9]
   888a3:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   888a9:	f3 49 0f 38 f6 c0                               	adox   rax,r8
   888af:	c4 42 cb f6 41 08                               	mulx   r8,rsi,QWORD PTR [r9+0x8]
   888b5:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   888bb:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   888c1:	c4 42 cb f6 41 10                               	mulx   r8,rsi,QWORD PTR [r9+0x10]
   888c7:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   888cd:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   888d3:	c4 42 cb f6 41 18                               	mulx   r8,rsi,QWORD PTR [r9+0x18]
   888d9:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   888df:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   888e5:	66 4c 0f 38 f6 f3                               	adcx   r14,rbx
   888eb:	49 8b 54 24 08                                  	mov    rdx,QWORD PTR [r12+0x8]
   888f0:	31 db                                           	xor    ebx,ebx
   888f2:	c4 42 cb f6 03                                  	mulx   r8,rsi,QWORD PTR [r11]
   888f7:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   888fd:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   88903:	c4 42 cb f6 43 08                               	mulx   r8,rsi,QWORD PTR [r11+0x8]
   88909:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   8890f:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   88915:	c4 42 cb f6 43 10                               	mulx   r8,rsi,QWORD PTR [r11+0x10]
   8891b:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   88921:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   88927:	c4 42 cb f6 43 18                               	mulx   r8,rsi,QWORD PTR [r11+0x18]
   8892d:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   88933:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   88939:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   8893f:	48 89 c2                                        	mov    rdx,rax
   88942:	49 0f af d5                                     	imul   rdx,r13
   88946:	31 db                                           	xor    ebx,ebx
   88948:	c4 42 cb f6 01                                  	mulx   r8,rsi,QWORD PTR [r9]
   8894d:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   88953:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   88959:	c4 42 cb f6 41 08                               	mulx   r8,rsi,QWORD PTR [r9+0x8]
   8895f:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   88965:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   8896b:	c4 42 cb f6 41 10                               	mulx   r8,rsi,QWORD PTR [r9+0x10]
   88971:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   88977:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   8897d:	c4 42 cb f6 41 18                               	mulx   r8,rsi,QWORD PTR [r9+0x18]
   88983:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   88989:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   8898f:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   88995:	49 8b 54 24 10                                  	mov    rdx,QWORD PTR [r12+0x10]
   8899a:	31 db                                           	xor    ebx,ebx
   8899c:	c4 42 cb f6 03                                  	mulx   r8,rsi,QWORD PTR [r11]
   889a1:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   889a7:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   889ad:	c4 42 cb f6 43 08                               	mulx   r8,rsi,QWORD PTR [r11+0x8]
   889b3:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   889b9:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   889bf:	c4 42 cb f6 43 10                               	mulx   r8,rsi,QWORD PTR [r11+0x10]
   889c5:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   889cb:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   889d1:	c4 42 cb f6 43 18                               	mulx   r8,rsi,QWORD PTR [r11+0x18]
   889d7:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   889dd:	f3 49 0f 38 f6 c0                               	adox   rax,r8
   889e3:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   889e9:	4c 89 fa                                        	mov    rdx,r15
   889ec:	49 0f af d5                                     	imul   rdx,r13
   889f0:	31 db                                           	xor    ebx,ebx
   889f2:	c4 42 cb f6 01                                  	mulx   r8,rsi,QWORD PTR [r9]
   889f7:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   889fd:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   88a03:	c4 42 cb f6 41 08                               	mulx   r8,rsi,QWORD PTR [r9+0x8]
   88a09:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   88a0f:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   88a15:	c4 42 cb f6 41 10                               	mulx   r8,rsi,QWORD PTR [r9+0x10]
   88a1b:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   88a21:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   88a27:	c4 42 cb f6 41 18                               	mulx   r8,rsi,QWORD PTR [r9+0x18]
   88a2d:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   88a33:	f3 49 0f 38 f6 c0                               	adox   rax,r8
   88a39:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   88a3f:	49 8b 54 24 18                                  	mov    rdx,QWORD PTR [r12+0x18]
   88a44:	31 db                                           	xor    ebx,ebx
   88a46:	c4 42 cb f6 03                                  	mulx   r8,rsi,QWORD PTR [r11]
   88a4b:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   88a51:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   88a57:	c4 42 cb f6 43 08                               	mulx   r8,rsi,QWORD PTR [r11+0x8]
   88a5d:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   88a63:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   88a69:	c4 42 cb f6 43 10                               	mulx   r8,rsi,QWORD PTR [r11+0x10]
   88a6f:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   88a75:	f3 49 0f 38 f6 c0                               	adox   rax,r8
   88a7b:	c4 42 cb f6 43 18                               	mulx   r8,rsi,QWORD PTR [r11+0x18]
   88a81:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   88a87:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   88a8d:	66 4c 0f 38 f6 fb                               	adcx   r15,rbx
   88a93:	48 89 ca                                        	mov    rdx,rcx
   88a96:	49 0f af d5                                     	imul   rdx,r13
   88a9a:	31 db                                           	xor    ebx,ebx
   88a9c:	c4 42 cb f6 01                                  	mulx   r8,rsi,QWORD PTR [r9]
   88aa1:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   88aa7:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   88aad:	c4 42 cb f6 41 08                               	mulx   r8,rsi,QWORD PTR [r9+0x8]
   88ab3:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   88ab9:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   88abf:	c4 42 cb f6 41 10                               	mulx   r8,rsi,QWORD PTR [r9+0x10]
   88ac5:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   88acb:	f3 49 0f 38 f6 c0                               	adox   rax,r8
   88ad1:	c4 42 cb f6 41 18                               	mulx   r8,rsi,QWORD PTR [r9+0x18]
   88ad7:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   88add:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   88ae3:	66 4c 0f 38 f6 fb                               	adcx   r15,rbx
   88ae9:	48 b9 47 fd 7c d8 16 8c 20 3c                   	movabs rcx,0x3c208c16d87cfd47
   88af3:	48 89 84 24 40 09 00 00                         	mov    QWORD PTR [rsp+0x940],rax
   88afb:	4c 89 bc 24 00 09 00 00                         	mov    QWORD PTR [rsp+0x900],r15
   88b03:	4c 89 b4 24 00 05 00 00                         	mov    QWORD PTR [rsp+0x500],r14
   88b0b:	4c 89 94 24 80 09 00 00                         	mov    QWORD PTR [rsp+0x980],r10
   88b13:	c5 fd 7f 8c 24 c0 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0xc0],ymm1
   88b1c:	4c 8d 8c 24 c0 00 00 00                         	lea    r9,[rsp+0xc0]
   88b24:	49 39 ce                                        	cmp    r14,rcx
   88b27:	48 b9 73 35 8e 97 6e 95 7e 68                   	movabs rcx,0x687e956e978e3573
   88b31:	48 8b b4 24 c0 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x4c0]
   88b39:	c5 fc 10 84 3c 80 0a 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+rdi*1+0xa80]
   88b42:	49 8d 14 0a                                     	lea    rdx,[r10+rcx*1]
   88b46:	48 83 da 00                                     	sbb    rdx,0x0
   88b4a:	48 89 94 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],rdx
   88b52:	48 ba 8d ca 71 68 91 6a 81 97                   	movabs rdx,0x97816a916871ca8d
   88b5c:	0f 92 c1                                        	setb   cl
   88b5f:	49 39 d2                                        	cmp    r10,rdx
   88b62:	4c 8d 54 24 60                                  	lea    r10,[rsp+0x60]
   88b67:	0f 92 c2                                        	setb   dl
   88b6a:	08 ca                                           	or     dl,cl
   88b6c:	0f b6 ca                                        	movzx  ecx,dl
   88b6f:	48 ba a3 a7 7e 7e 49 ba af 47                   	movabs rdx,0x47afba497e7ea7a3
   88b79:	48 01 c2                                        	add    rdx,rax
   88b7c:	c5 fc 29 84 24 40 03 00 00                      	vmovaps YMMWORD PTR [rsp+0x340],ymm0
   88b85:	48 29 ca                                        	sub    rdx,rcx
   88b88:	48 89 94 24 c0 02 00 00                         	mov    QWORD PTR [rsp+0x2c0],rdx
   88b90:	48 ba 5d 58 81 81 b6 45 50 b8                   	movabs rdx,0xb85045b68181585d
   88b9a:	0f 92 c1                                        	setb   cl
   88b9d:	48 39 d0                                        	cmp    rax,rdx
   88ba0:	0f 92 c2                                        	setb   dl
   88ba3:	08 ca                                           	or     dl,cl
   88ba5:	0f b6 ca                                        	movzx  ecx,dl
   88ba8:	48 ba d7 5f ce 1e 8d b1 9b cf                   	movabs rdx,0xcf9bb18d1ece5fd7
   88bb2:	49 8d 04 17                                     	lea    rax,[r15+rdx*1]
   88bb6:	48 29 c8                                        	sub    rax,rcx
   88bb9:	48 8b 8c 24 80 04 00 00                         	mov    rcx,QWORD PTR [rsp+0x480]
   88bc1:	48 89 84 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],rax
   88bc9:	0f 92 84 24 80 08 00 00                         	setb   BYTE PTR [rsp+0x880]
   88bd1:	48 89 4c 24 60                                  	mov    QWORD PTR [rsp+0x60],rcx
   88bd6:	48 8b 8c 24 80 03 00 00                         	mov    rcx,QWORD PTR [rsp+0x380]
   88bde:	48 89 74 24 68                                  	mov    QWORD PTR [rsp+0x68],rsi
   88be3:	48 89 4c 24 70                                  	mov    QWORD PTR [rsp+0x70],rcx
   88be8:	48 8b 8c 24 80 05 00 00                         	mov    rcx,QWORD PTR [rsp+0x580]
   88bf0:	48 89 4c 24 78                                  	mov    QWORD PTR [rsp+0x78],rcx
   88bf5:	48 8d 8c 24 40 03 00 00                         	lea    rcx,[rsp+0x340]
   88bfd:	31 f6                                           	xor    esi,esi
   88bff:	45 31 c0                                        	xor    r8d,r8d
   88c02:	45 31 db                                        	xor    r11d,r11d
   88c05:	31 db                                           	xor    ebx,ebx
   88c07:	31 c0                                           	xor    eax,eax
   88c09:	49 8b 12                                        	mov    rdx,QWORD PTR [r10]
   88c0c:	45 31 ff                                        	xor    r15d,r15d
   88c0f:	c4 62 8b f6 21                                  	mulx   r12,r14,QWORD PTR [rcx]
   88c14:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   88c1a:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   88c20:	c4 62 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [rcx+0x8]
   88c26:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   88c2c:	f3 4d 0f 38 f6 dc                               	adox   r11,r12
   88c32:	c4 62 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [rcx+0x10]
   88c38:	66 4d 0f 38 f6 de                               	adcx   r11,r14
   88c3e:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   88c44:	c4 62 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [rcx+0x18]
   88c4a:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   88c50:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   88c56:	66 49 0f 38 f6 c7                               	adcx   rax,r15
   88c5c:	48 89 f2                                        	mov    rdx,rsi
   88c5f:	49 0f af d5                                     	imul   rdx,r13
   88c63:	45 31 ff                                        	xor    r15d,r15d
   88c66:	c4 42 8b f6 21                                  	mulx   r12,r14,QWORD PTR [r9]
   88c6b:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   88c71:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   88c77:	c4 42 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [r9+0x8]
   88c7d:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   88c83:	f3 4d 0f 38 f6 dc                               	adox   r11,r12
   88c89:	c4 42 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [r9+0x10]
   88c8f:	66 4d 0f 38 f6 de                               	adcx   r11,r14
   88c95:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   88c9b:	c4 42 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [r9+0x18]
   88ca1:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   88ca7:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   88cad:	66 49 0f 38 f6 c7                               	adcx   rax,r15
   88cb3:	49 8b 52 08                                     	mov    rdx,QWORD PTR [r10+0x8]
   88cb7:	45 31 ff                                        	xor    r15d,r15d
   88cba:	c4 62 8b f6 21                                  	mulx   r12,r14,QWORD PTR [rcx]
   88cbf:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   88cc5:	f3 4d 0f 38 f6 dc                               	adox   r11,r12
   88ccb:	c4 62 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [rcx+0x8]
   88cd1:	66 4d 0f 38 f6 de                               	adcx   r11,r14
   88cd7:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   88cdd:	c4 62 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [rcx+0x10]
   88ce3:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   88ce9:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   88cef:	c4 62 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [rcx+0x18]
   88cf5:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   88cfb:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   88d01:	66 49 0f 38 f6 f7                               	adcx   rsi,r15
   88d07:	4c 89 c2                                        	mov    rdx,r8
   88d0a:	49 0f af d5                                     	imul   rdx,r13
   88d0e:	45 31 ff                                        	xor    r15d,r15d
   88d11:	c4 42 8b f6 21                                  	mulx   r12,r14,QWORD PTR [r9]
   88d16:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   88d1c:	f3 4d 0f 38 f6 dc                               	adox   r11,r12
   88d22:	c4 42 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [r9+0x8]
   88d28:	66 4d 0f 38 f6 de                               	adcx   r11,r14
   88d2e:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   88d34:	c4 42 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [r9+0x10]
   88d3a:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   88d40:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   88d46:	c4 42 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [r9+0x18]
   88d4c:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   88d52:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   88d58:	66 49 0f 38 f6 f7                               	adcx   rsi,r15
   88d5e:	49 8b 52 10                                     	mov    rdx,QWORD PTR [r10+0x10]
   88d62:	45 31 ff                                        	xor    r15d,r15d
   88d65:	c4 62 8b f6 21                                  	mulx   r12,r14,QWORD PTR [rcx]
   88d6a:	66 4d 0f 38 f6 de                               	adcx   r11,r14
   88d70:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   88d76:	c4 62 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [rcx+0x8]
   88d7c:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   88d82:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   88d88:	c4 62 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [rcx+0x10]
   88d8e:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   88d94:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   88d9a:	c4 62 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [rcx+0x18]
   88da0:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   88da6:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   88dac:	66 4d 0f 38 f6 c7                               	adcx   r8,r15
   88db2:	4c 89 da                                        	mov    rdx,r11
   88db5:	49 0f af d5                                     	imul   rdx,r13
   88db9:	45 31 ff                                        	xor    r15d,r15d
   88dbc:	c4 42 8b f6 21                                  	mulx   r12,r14,QWORD PTR [r9]
   88dc1:	66 4d 0f 38 f6 de                               	adcx   r11,r14
   88dc7:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   88dcd:	c4 42 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [r9+0x8]
   88dd3:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   88dd9:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   88ddf:	c4 42 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [r9+0x10]
   88de5:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   88deb:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   88df1:	c4 42 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [r9+0x18]
   88df7:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   88dfd:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   88e03:	66 4d 0f 38 f6 c7                               	adcx   r8,r15
   88e09:	49 8b 52 18                                     	mov    rdx,QWORD PTR [r10+0x18]
   88e0d:	45 31 ff                                        	xor    r15d,r15d
   88e10:	c4 62 8b f6 21                                  	mulx   r12,r14,QWORD PTR [rcx]
   88e15:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   88e1b:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   88e21:	c4 62 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [rcx+0x8]
   88e27:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   88e2d:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   88e33:	c4 62 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [rcx+0x10]
   88e39:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   88e3f:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   88e45:	c4 62 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [rcx+0x18]
   88e4b:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   88e51:	f3 4d 0f 38 f6 dc                               	adox   r11,r12
   88e57:	66 4d 0f 38 f6 df                               	adcx   r11,r15
   88e5d:	48 89 da                                        	mov    rdx,rbx
   88e60:	49 0f af d5                                     	imul   rdx,r13
   88e64:	45 31 ff                                        	xor    r15d,r15d
   88e67:	c4 42 8b f6 21                                  	mulx   r12,r14,QWORD PTR [r9]
   88e6c:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   88e72:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   88e78:	c4 42 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [r9+0x8]
   88e7e:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   88e84:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   88e8a:	c4 42 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [r9+0x10]
   88e90:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   88e96:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   88e9c:	c4 42 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [r9+0x18]
   88ea2:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   88ea8:	f3 4d 0f 38 f6 dc                               	adox   r11,r12
   88eae:	66 4d 0f 38 f6 df                               	adcx   r11,r15
   88eb4:	48 ba 47 fd 7c d8 16 8c 20 3c                   	movabs rdx,0x3c208c16d87cfd47
   88ebe:	48 b9 73 35 8e 97 6e 95 7e 68                   	movabs rcx,0x687e956e978e3573
   88ec8:	4c 89 84 24 40 08 00 00                         	mov    QWORD PTR [rsp+0x840],r8
   88ed0:	4c 89 9c 24 00 06 00 00                         	mov    QWORD PTR [rsp+0x600],r11
   88ed8:	48 89 b4 24 c0 08 00 00                         	mov    QWORD PTR [rsp+0x8c0],rsi
   88ee0:	49 b9 29 a0 31 e1 72 4e 64 30                   	movabs r9,0x30644e72e131a029
   88eea:	49 b8 b9 02 83 27 e9 73 df c3                   	movabs r8,0xc3df73e9278302b9
   88ef4:	c5 fd 7f 8c 24 c0 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0xc0],ymm1
   88efd:	48 39 d0                                        	cmp    rax,rdx
   88f00:	48 8d 14 0e                                     	lea    rdx,[rsi+rcx*1]
   88f04:	48 b9 8d ca 71 68 91 6a 81 97                   	movabs rcx,0x97816a916871ca8d
   88f0e:	4c 8b ac 24 00 06 00 00                         	mov    r13,QWORD PTR [rsp+0x600]
   88f16:	4c 8b 94 24 00 09 00 00                         	mov    r10,QWORD PTR [rsp+0x900]
   88f1e:	4c 8b 9c 24 c0 02 00 00                         	mov    r11,QWORD PTR [rsp+0x2c0]
   88f26:	48 83 da 00                                     	sbb    rdx,0x0
   88f2a:	0f 92 c3                                        	setb   bl
   88f2d:	48 39 ce                                        	cmp    rsi,rcx
   88f30:	48 8b 8c 24 40 08 00 00                         	mov    rcx,QWORD PTR [rsp+0x840]
   88f38:	48 be a3 a7 7e 7e 49 ba af 47                   	movabs rsi,0x47afba497e7ea7a3
   88f42:	41 0f 92 c6                                     	setb   r14b
   88f46:	41 08 de                                        	or     r14b,bl
   88f49:	41 0f b6 de                                     	movzx  ebx,r14b
   88f4d:	4c 8d 34 31                                     	lea    r14,[rcx+rsi*1]
   88f51:	48 be 5d 58 81 81 b6 45 50 b8                   	movabs rsi,0xb85045b68181585d
   88f5b:	49 29 de                                        	sub    r14,rbx
   88f5e:	0f 92 c3                                        	setb   bl
   88f61:	48 39 f1                                        	cmp    rcx,rsi
   88f64:	48 be d7 5f ce 1e 8d b1 9b cf                   	movabs rsi,0xcf9bb18d1ece5fd7
   88f6e:	41 0f 92 c7                                     	setb   r15b
   88f72:	4d 8d 64 35 00                                  	lea    r12,[r13+rsi*1+0x0]
   88f77:	48 8b b4 24 40 02 00 00                         	mov    rsi,QWORD PTR [rsp+0x240]
   88f7f:	41 08 df                                        	or     r15b,bl
   88f82:	41 0f b6 df                                     	movzx  ebx,r15b
   88f86:	49 29 dc                                        	sub    r12,rbx
   88f89:	0f 92 c3                                        	setb   bl
   88f8c:	4d 39 cd                                        	cmp    r13,r9
   88f8f:	41 0f 92 c7                                     	setb   r15b
   88f93:	41 08 df                                        	or     r15b,bl
   88f96:	4d 39 ca                                        	cmp    r10,r9
   88f99:	0f 92 c3                                        	setb   bl
   88f9c:	0a 9c 24 80 08 00 00                            	or     bl,BYTE PTR [rsp+0x880]
   88fa3:	48 8b 9c 24 00 05 00 00                         	mov    rbx,QWORD PTR [rsp+0x500]
   88fab:	48 0f 45 b4 24 80 09 00 00                      	cmovne rsi,QWORD PTR [rsp+0x980]
   88fb4:	4c 0f 45 9c 24 40 09 00 00                      	cmovne r11,QWORD PTR [rsp+0x940]
   88fbd:	4e 8d 0c 03                                     	lea    r9,[rbx+r8*1]
   88fc1:	4c 0f 45 cb                                     	cmovne r9,rbx
   88fc5:	48 8b 9c 24 80 06 00 00                         	mov    rbx,QWORD PTR [rsp+0x680]
   88fcd:	4c 89 8c 24 00 05 00 00                         	mov    QWORD PTR [rsp+0x500],r9
   88fd5:	4c 8b 8c 24 80 02 00 00                         	mov    r9,QWORD PTR [rsp+0x280]
   88fdd:	48 89 b4 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],rsi
   88fe5:	48 89 c6                                        	mov    rsi,rax
   88fe8:	4a 8d 04 00                                     	lea    rax,[rax+r8*1]
   88fec:	4c 89 9c 24 c0 02 00 00                         	mov    QWORD PTR [rsp+0x2c0],r11
   88ff4:	4c 8b 9c 24 40 06 00 00                         	mov    r11,QWORD PTR [rsp+0x640]
   88ffc:	4c 8b 84 24 c0 06 00 00                         	mov    r8,QWORD PTR [rsp+0x6c0]
   89004:	4d 0f 45 ca                                     	cmovne r9,r10
   89008:	45 84 ff                                        	test   r15b,r15b
   8900b:	4c 8b 94 24 80 07 00 00                         	mov    r10,QWORD PTR [rsp+0x780]
   89013:	4c 89 8c 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],r9
   8901b:	4c 8b 8c 24 40 04 00 00                         	mov    r9,QWORD PTR [rsp+0x440]
   89023:	48 0f 45 94 24 c0 08 00 00                      	cmovne rdx,QWORD PTR [rsp+0x8c0]
   8902c:	48 0f 45 c6                                     	cmovne rax,rsi
   89030:	4d 0f 45 e5                                     	cmovne r12,r13
   89034:	4c 0f 45 f1                                     	cmovne r14,rcx
   89038:	48 89 84 3c 80 0a 00 00                         	mov    QWORD PTR [rsp+rdi*1+0xa80],rax
   89040:	48 8b 84 24 40 07 00 00                         	mov    rax,QWORD PTR [rsp+0x740]
   89048:	4d 89 dd                                        	mov    r13,r11
   8904b:	4c 89 4c 24 60                                  	mov    QWORD PTR [rsp+0x60],r9
   89050:	4c 8b 8c 24 40 05 00 00                         	mov    r9,QWORD PTR [rsp+0x540]
   89058:	48 89 94 3c 88 0a 00 00                         	mov    QWORD PTR [rsp+rdi*1+0xa88],rdx
   89060:	4c 89 b4 3c 90 0a 00 00                         	mov    QWORD PTR [rsp+rdi*1+0xa90],r14
   89068:	4c 89 a4 3c 98 0a 00 00                         	mov    QWORD PTR [rsp+rdi*1+0xa98],r12
   89070:	48 8b bc 24 00 07 00 00                         	mov    rdi,QWORD PTR [rsp+0x700]
   89078:	4c 89 54 24 68                                  	mov    QWORD PTR [rsp+0x68],r10
   8907d:	4d 89 c4                                        	mov    r12,r8
   89080:	4c 8d 94 24 c0 00 00 00                         	lea    r10,[rsp+0xc0]
   89088:	4c 8d 74 24 60                                  	lea    r14,[rsp+0x60]
   8908d:	4c 89 4c 24 70                                  	mov    QWORD PTR [rsp+0x70],r9
   89092:	48 89 44 24 78                                  	mov    QWORD PTR [rsp+0x78],rax
   89097:	49 89 ff                                        	mov    r15,rdi
   8909a:	49 89 d9                                        	mov    r9,rbx
   8909d:	4d 03 3e                                        	add    r15,QWORD PTR [r14]
   890a0:	4d 13 66 08                                     	adc    r12,QWORD PTR [r14+0x8]
   890a4:	49 13 5e 10                                     	adc    rbx,QWORD PTR [r14+0x10]
   890a8:	4d 13 6e 18                                     	adc    r13,QWORD PTR [r14+0x18]
   890ac:	4c 89 f8                                        	mov    rax,r15
   890af:	4c 89 e1                                        	mov    rcx,r12
   890b2:	48 89 da                                        	mov    rdx,rbx
   890b5:	4c 89 ee                                        	mov    rsi,r13
   890b8:	49 2b 02                                        	sub    rax,QWORD PTR [r10]
   890bb:	49 1b 4a 08                                     	sbb    rcx,QWORD PTR [r10+0x8]
   890bf:	49 1b 52 10                                     	sbb    rdx,QWORD PTR [r10+0x10]
   890c3:	49 1b 72 18                                     	sbb    rsi,QWORD PTR [r10+0x18]
   890c7:	4c 0f 43 f8                                     	cmovae r15,rax
   890cb:	4c 0f 43 e1                                     	cmovae r12,rcx
   890cf:	48 0f 43 da                                     	cmovae rbx,rdx
   890d3:	4c 0f 43 ee                                     	cmovae r13,rsi
   890d7:	48 8b 94 24 c0 03 00 00                         	mov    rdx,QWORD PTR [rsp+0x3c0]
   890df:	4c 8b 72 28                                     	mov    r14,QWORD PTR [rdx+0x28]
   890e3:	4c 3b 72 18                                     	cmp    r14,QWORD PTR [rdx+0x18]
   890e7:	0f 84 83 01 00 00                               	je     89270 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x3490>
   890ed:	48 8b 4a 20                                     	mov    rcx,QWORD PTR [rdx+0x20]
   890f1:	4b 8d 04 b6                                     	lea    rax,[r14+r14*4]
   890f5:	48 8b b4 24 80 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x480]
   890fd:	49 ff c6                                        	inc    r14
   89100:	48 c1 e0 05                                     	shl    rax,0x5
   89104:	48 89 3c 01                                     	mov    QWORD PTR [rcx+rax*1],rdi
   89108:	4c 89 44 01 08                                  	mov    QWORD PTR [rcx+rax*1+0x8],r8
   8910d:	4c 89 4c 01 10                                  	mov    QWORD PTR [rcx+rax*1+0x10],r9
   89112:	4c 89 5c 01 18                                  	mov    QWORD PTR [rcx+rax*1+0x18],r11
   89117:	48 8b bc 24 c0 04 00 00                         	mov    rdi,QWORD PTR [rsp+0x4c0]
   8911f:	4c 8b 84 24 80 03 00 00                         	mov    r8,QWORD PTR [rsp+0x380]
   89127:	4c 8b 9c 24 00 03 00 00                         	mov    r11,QWORD PTR [rsp+0x300]
   8912f:	c5 fd 6f 84 24 20 06 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x620]
   89138:	49 ff c3                                        	inc    r11
   8913b:	c5 fe 7f 44 01 20                               	vmovdqu YMMWORD PTR [rcx+rax*1+0x20],ymm0
   89141:	4c 89 7c 01 40                                  	mov    QWORD PTR [rcx+rax*1+0x40],r15
   89146:	4c 89 64 01 48                                  	mov    QWORD PTR [rcx+rax*1+0x48],r12
   8914b:	48 89 5c 01 50                                  	mov    QWORD PTR [rcx+rax*1+0x50],rbx
   89150:	4c 89 6c 01 58                                  	mov    QWORD PTR [rcx+rax*1+0x58],r13
   89155:	48 89 74 01 60                                  	mov    QWORD PTR [rcx+rax*1+0x60],rsi
   8915a:	48 89 7c 01 68                                  	mov    QWORD PTR [rcx+rax*1+0x68],rdi
   8915f:	48 8b bc 24 80 05 00 00                         	mov    rdi,QWORD PTR [rsp+0x580]
   89167:	4c 89 44 01 70                                  	mov    QWORD PTR [rcx+rax*1+0x70],r8
   8916c:	4c 8b 84 24 00 05 00 00                         	mov    r8,QWORD PTR [rsp+0x500]
   89174:	48 8b 5c 24 38                                  	mov    rbx,QWORD PTR [rsp+0x38]
   89179:	4c 8b a4 24 00 04 00 00                         	mov    r12,QWORD PTR [rsp+0x400]
   89181:	48 89 7c 01 78                                  	mov    QWORD PTR [rcx+rax*1+0x78],rdi
   89186:	48 8b bc 24 40 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x240]
   8918e:	4c 89 84 01 80 00 00 00                         	mov    QWORD PTR [rcx+rax*1+0x80],r8
   89196:	4c 8b 84 24 c0 02 00 00                         	mov    r8,QWORD PTR [rsp+0x2c0]
   8919e:	48 89 bc 01 88 00 00 00                         	mov    QWORD PTR [rcx+rax*1+0x88],rdi
   891a6:	48 8b bc 24 80 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x280]
   891ae:	4c 89 84 01 90 00 00 00                         	mov    QWORD PTR [rcx+rax*1+0x90],r8
   891b6:	48 89 bc 01 98 00 00 00                         	mov    QWORD PTR [rcx+rax*1+0x98],rdi
   891be:	48 8b 84 24 00 08 00 00                         	mov    rax,QWORD PTR [rsp+0x800]
   891c6:	4c 89 72 28                                     	mov    QWORD PTR [rdx+0x28],r14
   891ca:	48 83 c0 10                                     	add    rax,0x10
   891ce:	49 39 db                                        	cmp    r11,rbx
   891d1:	0f 83 d2 00 00 00                               	jae    892a9 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x34c9>
   891d7:	48 8b 08                                        	mov    rcx,QWORD PTR [rax]
   891da:	4c 89 9c 24 00 03 00 00                         	mov    QWORD PTR [rsp+0x300],r11
   891e2:	8b 78 f8                                        	mov    edi,DWORD PTR [rax-0x8]
   891e5:	48 89 84 24 00 08 00 00                         	mov    QWORD PTR [rsp+0x800],rax
   891ed:	48 8b 31                                        	mov    rsi,QWORD PTR [rcx]
   891f0:	4c 8b 41 08                                     	mov    r8,QWORD PTR [rcx+0x8]
   891f4:	4c 8b 59 10                                     	mov    r11,QWORD PTR [rcx+0x10]
   891f8:	48 8b 59 18                                     	mov    rbx,QWORD PTR [rcx+0x18]
   891fc:	48 89 b4 24 40 04 00 00                         	mov    QWORD PTR [rsp+0x440],rsi
   89204:	4c 89 84 24 80 07 00 00                         	mov    QWORD PTR [rsp+0x780],r8
   8920c:	4c 89 9c 24 40 05 00 00                         	mov    QWORD PTR [rsp+0x540],r11
   89214:	48 89 9c 24 40 07 00 00                         	mov    QWORD PTR [rsp+0x740],rbx
   8921c:	85 ff                                           	test   edi,edi
   8921e:	0f 88 9c f3 ff ff                               	js     885c0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x27e0>
   89224:	48 8b 41 38                                     	mov    rax,QWORD PTR [rcx+0x38]
   89228:	4c 8b 49 30                                     	mov    r9,QWORD PTR [rcx+0x30]
   8922c:	48 8b 51 28                                     	mov    rdx,QWORD PTR [rcx+0x28]
   89230:	48 8b 49 20                                     	mov    rcx,QWORD PTR [rcx+0x20]
   89234:	48 89 84 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],rax
   8923c:	4c 89 8c 24 c0 02 00 00                         	mov    QWORD PTR [rsp+0x2c0],r9
   89244:	48 89 94 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],rdx
   8924c:	48 89 8c 24 00 05 00 00                         	mov    QWORD PTR [rsp+0x500],rcx
   89254:	4c 8b b4 24 c0 05 00 00                         	mov    r14,QWORD PTR [rsp+0x5c0]
   8925c:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   89262:	49 39 fc                                        	cmp    r12,rdi
   89265:	0f 87 18 f4 ff ff                               	ja     88683 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x28a3>
   8926b:	e9 2d 31 00 00                                  	jmp    8c39d <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x65bd>
   89270:	48 8d 7a 18                                     	lea    rdi,[rdx+0x18]
   89274:	c5 f8 77                                        	vzeroupper
   89277:	e8 a4 d4 00 00                                  	call   96720 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecAINtNtCsgHCcee0nhgM_11zopro_bn2542fp2FpNtBR_8FqConfigEj5_E8grow_oneCsHW5vo2gROj_10zopro_core>
   8927c:	4c 8b 9c 24 40 06 00 00                         	mov    r11,QWORD PTR [rsp+0x640]
   89284:	4c 8b 8c 24 80 06 00 00                         	mov    r9,QWORD PTR [rsp+0x680]
   8928c:	4c 8b 84 24 c0 06 00 00                         	mov    r8,QWORD PTR [rsp+0x6c0]
   89294:	48 8b bc 24 00 07 00 00                         	mov    rdi,QWORD PTR [rsp+0x700]
   8929c:	48 8b 94 24 c0 03 00 00                         	mov    rdx,QWORD PTR [rsp+0x3c0]
   892a4:	e9 44 fe ff ff                                  	jmp    890ed <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x330d>
   892a9:	0f b6 52 32                                     	movzx  edx,BYTE PTR [rdx+0x32]
   892ad:	48 8d bc 24 c0 00 00 00                         	lea    rdi,[rsp+0xc0]
   892b5:	48 8d b4 24 80 0a 00 00                         	lea    rsi,[rsp+0xa80]
   892bd:	c5 f8 77                                        	vzeroupper
   892c0:	e8 ab c4 00 00                                  	call   95770 <_RNvNtCsHW5vo2gROj_10zopro_core3msm12invert_lanes>
   892c5:	48 8b 4c 24 30                                  	mov    rcx,QWORD PTR [rsp+0x30]
   892ca:	48 89 d8                                        	mov    rax,rbx
   892cd:	48 c1 e0 04                                     	shl    rax,0x4
   892d1:	c5 fe 6f 15 07 e6 f7 ff                         	vmovdqu ymm2,YMMWORD PTR [rip+0xfffffffffff7e607]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   892d9:	48 8d 53 ff                                     	lea    rdx,[rbx-0x1]
   892dd:	4c 8d 54 08 f0                                  	lea    r10,[rax+rcx*1-0x10]
   892e2:	48 8b 8c 24 88 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x88]
   892ea:	48 8d 04 cd 00 00 00 00                         	lea    rax,[rcx*8+0x0]
   892f2:	48 c1 e1 08                                     	shl    rcx,0x8
   892f6:	48 f7 d8                                        	neg    rax
   892f9:	48 89 84 24 00 08 00 00                         	mov    QWORD PTR [rsp+0x800],rax
   89301:	48 89 d8                                        	mov    rax,rbx
   89304:	48 c1 e0 05                                     	shl    rax,0x5
   89308:	4c 8d 04 80                                     	lea    r8,[rax+rax*4]
   8930c:	48 8d 04 89                                     	lea    rax,[rcx+rcx*4]
   89310:	49 29 c0                                        	sub    r8,rax
   89313:	48 8b 84 24 c0 07 00 00                         	mov    rax,QWORD PTR [rsp+0x7c0]
   8931b:	49 81 c0 68 ff ff ff                            	add    r8,0xffffffffffffff68
   89322:	48 f7 d8                                        	neg    rax
   89325:	48 8d 44 03 ff                                  	lea    rax,[rbx+rax*1-0x1]
   8932a:	48 c1 e0 05                                     	shl    rax,0x5
   8932e:	4c 8d 1c 80                                     	lea    r11,[rax+rax*4]
   89332:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   89340:	48 8b 8c 24 c0 03 00 00                         	mov    rcx,QWORD PTR [rsp+0x3c0]
   89348:	48 8b 84 24 00 08 00 00                         	mov    rax,QWORD PTR [rsp+0x800]
   89350:	4c 89 94 24 80 03 00 00                         	mov    QWORD PTR [rsp+0x380],r10
   89358:	48 8b 71 28                                     	mov    rsi,QWORD PTR [rcx+0x28]
   8935c:	48 01 d0                                        	add    rax,rdx
   8935f:	48 39 f0                                        	cmp    rax,rsi
   89362:	0f 83 75 30 00 00                               	jae    8c3dd <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x65fd>
   89368:	48 8b 41 20                                     	mov    rax,QWORD PTR [rcx+0x20]
   8936c:	89 d6                                           	mov    esi,edx
   8936e:	83 e6 07                                        	and    esi,0x7
   89371:	4c 89 9c 24 c0 06 00 00                         	mov    QWORD PTR [rsp+0x6c0],r11
   89379:	4c 89 84 24 00 07 00 00                         	mov    QWORD PTR [rsp+0x700],r8
   89381:	48 89 94 24 80 05 00 00                         	mov    QWORD PTR [rsp+0x580],rdx
   89389:	4c 8d 74 24 40                                  	lea    r14,[rsp+0x40]
   8938e:	4c 8d bc 24 20 02 00 00                         	lea    r15,[rsp+0x220]
   89396:	49 bc 89 63 86 e4 82 07 d2 87                   	movabs r12,0x87d20782e4866389
   893a0:	c1 e6 05                                        	shl    esi,0x5
   893a3:	c5 fc 10 8c 34 c0 00 00 00                      	vmovups ymm1,YMMWORD PTR [rsp+rsi*1+0xc0]
   893ac:	4a 8b 0c 18                                     	mov    rcx,QWORD PTR [rax+r11*1]
   893b0:	c4 a1 7c 10 44 00 18                            	vmovups ymm0,YMMWORD PTR [rax+r8*1+0x18]
   893b7:	4c 8d 9c 24 a0 00 00 00                         	lea    r11,[rsp+0xa0]
   893bf:	48 89 8c 24 c0 04 00 00                         	mov    QWORD PTR [rsp+0x4c0],rcx
   893c7:	4a 8b 0c 00                                     	mov    rcx,QWORD PTR [rax+r8*1]
   893cb:	48 89 8c 24 80 04 00 00                         	mov    QWORD PTR [rsp+0x480],rcx
   893d3:	4a 8b 4c 00 08                                  	mov    rcx,QWORD PTR [rax+r8*1+0x8]
   893d8:	48 89 8c 24 40 04 00 00                         	mov    QWORD PTR [rsp+0x440],rcx
   893e0:	4a 8b 4c 00 10                                  	mov    rcx,QWORD PTR [rax+r8*1+0x10]
   893e5:	c5 fc 29 84 24 60 0a 00 00                      	vmovaps YMMWORD PTR [rsp+0xa60],ymm0
   893ee:	c4 a1 7c 10 44 00 38                            	vmovups ymm0,YMMWORD PTR [rax+r8*1+0x38]
   893f5:	48 89 8c 24 80 07 00 00                         	mov    QWORD PTR [rsp+0x780],rcx
   893fd:	c5 fc 29 84 24 20 06 00 00                      	vmovaps YMMWORD PTR [rsp+0x620],ymm0
   89406:	c4 a1 7c 10 44 00 58                            	vmovups ymm0,YMMWORD PTR [rax+r8*1+0x58]
   8940d:	c5 fc 29 84 24 40 03 00 00                      	vmovaps YMMWORD PTR [rsp+0x340],ymm0
   89416:	c4 a1 7c 10 44 00 78                            	vmovups ymm0,YMMWORD PTR [rax+r8*1+0x78]
   8941d:	c5 fc 29 4c 24 40                               	vmovaps YMMWORD PTR [rsp+0x40],ymm1
   89423:	c5 fd 7f 94 24 20 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x220],ymm2
   8942c:	c5 fc 29 44 24 60                               	vmovaps YMMWORD PTR [rsp+0x60],ymm0
   89432:	c5 fc 29 84 24 a0 00 00 00                      	vmovaps YMMWORD PTR [rsp+0xa0],ymm0
   8943b:	45 31 d2                                        	xor    r10d,r10d
   8943e:	45 31 c9                                        	xor    r9d,r9d
   89441:	31 db                                           	xor    ebx,ebx
   89443:	31 c0                                           	xor    eax,eax
   89445:	45 31 ed                                        	xor    r13d,r13d
   89448:	49 8b 16                                        	mov    rdx,QWORD PTR [r14]
   8944b:	45 31 c0                                        	xor    r8d,r8d
   8944e:	c4 c2 f3 f6 3b                                  	mulx   rdi,rcx,QWORD PTR [r11]
   89453:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   89459:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   8945f:	c4 c2 f3 f6 7b 08                               	mulx   rdi,rcx,QWORD PTR [r11+0x8]
   89465:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   8946b:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   89471:	c4 c2 f3 f6 7b 10                               	mulx   rdi,rcx,QWORD PTR [r11+0x10]
   89477:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   8947d:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   89483:	c4 c2 f3 f6 7b 18                               	mulx   rdi,rcx,QWORD PTR [r11+0x18]
   89489:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   8948f:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   89495:	66 4d 0f 38 f6 e8                               	adcx   r13,r8
   8949b:	4c 89 d2                                        	mov    rdx,r10
   8949e:	49 0f af d4                                     	imul   rdx,r12
   894a2:	45 31 c0                                        	xor    r8d,r8d
   894a5:	c4 c2 f3 f6 3f                                  	mulx   rdi,rcx,QWORD PTR [r15]
   894aa:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   894b0:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   894b6:	c4 c2 f3 f6 7f 08                               	mulx   rdi,rcx,QWORD PTR [r15+0x8]
   894bc:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   894c2:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   894c8:	c4 c2 f3 f6 7f 10                               	mulx   rdi,rcx,QWORD PTR [r15+0x10]
   894ce:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   894d4:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   894da:	c4 c2 f3 f6 7f 18                               	mulx   rdi,rcx,QWORD PTR [r15+0x18]
   894e0:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   894e6:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   894ec:	66 4d 0f 38 f6 e8                               	adcx   r13,r8
   894f2:	49 8b 56 08                                     	mov    rdx,QWORD PTR [r14+0x8]
   894f6:	45 31 c0                                        	xor    r8d,r8d
   894f9:	c4 c2 f3 f6 3b                                  	mulx   rdi,rcx,QWORD PTR [r11]
   894fe:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   89504:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   8950a:	c4 c2 f3 f6 7b 08                               	mulx   rdi,rcx,QWORD PTR [r11+0x8]
   89510:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   89516:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   8951c:	c4 c2 f3 f6 7b 10                               	mulx   rdi,rcx,QWORD PTR [r11+0x10]
   89522:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   89528:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   8952e:	c4 c2 f3 f6 7b 18                               	mulx   rdi,rcx,QWORD PTR [r11+0x18]
   89534:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   8953a:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   89540:	66 4d 0f 38 f6 d0                               	adcx   r10,r8
   89546:	4c 89 ca                                        	mov    rdx,r9
   89549:	49 0f af d4                                     	imul   rdx,r12
   8954d:	45 31 c0                                        	xor    r8d,r8d
   89550:	c4 c2 f3 f6 3f                                  	mulx   rdi,rcx,QWORD PTR [r15]
   89555:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   8955b:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   89561:	c4 c2 f3 f6 7f 08                               	mulx   rdi,rcx,QWORD PTR [r15+0x8]
   89567:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   8956d:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   89573:	c4 c2 f3 f6 7f 10                               	mulx   rdi,rcx,QWORD PTR [r15+0x10]
   89579:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   8957f:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   89585:	c4 c2 f3 f6 7f 18                               	mulx   rdi,rcx,QWORD PTR [r15+0x18]
   8958b:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   89591:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   89597:	66 4d 0f 38 f6 d0                               	adcx   r10,r8
   8959d:	49 8b 56 10                                     	mov    rdx,QWORD PTR [r14+0x10]
   895a1:	45 31 c0                                        	xor    r8d,r8d
   895a4:	c4 c2 f3 f6 3b                                  	mulx   rdi,rcx,QWORD PTR [r11]
   895a9:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   895af:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   895b5:	c4 c2 f3 f6 7b 08                               	mulx   rdi,rcx,QWORD PTR [r11+0x8]
   895bb:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   895c1:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   895c7:	c4 c2 f3 f6 7b 10                               	mulx   rdi,rcx,QWORD PTR [r11+0x10]
   895cd:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   895d3:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   895d9:	c4 c2 f3 f6 7b 18                               	mulx   rdi,rcx,QWORD PTR [r11+0x18]
   895df:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   895e5:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   895eb:	66 4d 0f 38 f6 c8                               	adcx   r9,r8
   895f1:	48 89 da                                        	mov    rdx,rbx
   895f4:	49 0f af d4                                     	imul   rdx,r12
   895f8:	45 31 c0                                        	xor    r8d,r8d
   895fb:	c4 c2 f3 f6 3f                                  	mulx   rdi,rcx,QWORD PTR [r15]
   89600:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   89606:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   8960c:	c4 c2 f3 f6 7f 08                               	mulx   rdi,rcx,QWORD PTR [r15+0x8]
   89612:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   89618:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   8961e:	c4 c2 f3 f6 7f 10                               	mulx   rdi,rcx,QWORD PTR [r15+0x10]
   89624:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   8962a:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   89630:	c4 c2 f3 f6 7f 18                               	mulx   rdi,rcx,QWORD PTR [r15+0x18]
   89636:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   8963c:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   89642:	66 4d 0f 38 f6 c8                               	adcx   r9,r8
   89648:	49 8b 56 18                                     	mov    rdx,QWORD PTR [r14+0x18]
   8964c:	45 31 c0                                        	xor    r8d,r8d
   8964f:	c4 c2 f3 f6 3b                                  	mulx   rdi,rcx,QWORD PTR [r11]
   89654:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   8965a:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   89660:	c4 c2 f3 f6 7b 08                               	mulx   rdi,rcx,QWORD PTR [r11+0x8]
   89666:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   8966c:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   89672:	c4 c2 f3 f6 7b 10                               	mulx   rdi,rcx,QWORD PTR [r11+0x10]
   89678:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   8967e:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   89684:	c4 c2 f3 f6 7b 18                               	mulx   rdi,rcx,QWORD PTR [r11+0x18]
   8968a:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   89690:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   89696:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   8969c:	48 89 c2                                        	mov    rdx,rax
   8969f:	49 0f af d4                                     	imul   rdx,r12
   896a3:	45 31 c0                                        	xor    r8d,r8d
   896a6:	c4 c2 f3 f6 3f                                  	mulx   rdi,rcx,QWORD PTR [r15]
   896ab:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   896b1:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   896b7:	c4 c2 f3 f6 7f 08                               	mulx   rdi,rcx,QWORD PTR [r15+0x8]
   896bd:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   896c3:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   896c9:	c4 c2 f3 f6 7f 10                               	mulx   rdi,rcx,QWORD PTR [r15+0x10]
   896cf:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   896d5:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   896db:	c4 c2 f3 f6 7f 18                               	mulx   rdi,rcx,QWORD PTR [r15+0x18]
   896e1:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   896e7:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   896ed:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   896f3:	48 b8 73 35 8e 97 6e 95 7e 68                   	movabs rax,0x687e956e978e3573
   896fd:	4c 89 8c 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],r9
   89705:	48 89 9c 24 40 07 00 00                         	mov    QWORD PTR [rsp+0x740],rbx
   8970d:	4c 89 ac 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],r13
   89715:	4c 89 94 24 40 06 00 00                         	mov    QWORD PTR [rsp+0x640],r10
   8971d:	c5 fd 7f 94 24 20 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x220],ymm2
   89726:	4c 8d 74 24 40                                  	lea    r14,[rsp+0x40]
   8972b:	49 bb 89 63 86 e4 82 07 d2 87                   	movabs r11,0x87d20782e4866389
   89735:	49 8d 0c 02                                     	lea    rcx,[r10+rax*1]
   89739:	48 b8 47 fd 7c d8 16 8c 20 3c                   	movabs rax,0x3c208c16d87cfd47
   89743:	c5 fc 10 84 34 c0 00 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+rsi*1+0xc0]
   8974c:	c5 fd 6f 8c 24 40 03 00 00                      	vmovdqa ymm1,YMMWORD PTR [rsp+0x340]
   89755:	49 39 c5                                        	cmp    r13,rax
   89758:	4c 8d ac 24 a0 00 00 00                         	lea    r13,[rsp+0xa0]
   89760:	48 83 d9 00                                     	sbb    rcx,0x0
   89764:	48 89 8c 24 c0 02 00 00                         	mov    QWORD PTR [rsp+0x2c0],rcx
   8976c:	48 b9 8d ca 71 68 91 6a 81 97                   	movabs rcx,0x97816a916871ca8d
   89776:	0f 92 c0                                        	setb   al
   89779:	49 39 ca                                        	cmp    r10,rcx
   8977c:	0f 92 c1                                        	setb   cl
   8977f:	08 c1                                           	or     cl,al
   89781:	48 b8 a3 a7 7e 7e 49 ba af 47                   	movabs rax,0x47afba497e7ea7a3
   8978b:	49 8d 14 01                                     	lea    rdx,[r9+rax*1]
   8978f:	0f b6 c1                                        	movzx  eax,cl
   89792:	48 b9 5d 58 81 81 b6 45 50 b8                   	movabs rcx,0xb85045b68181585d
   8979c:	48 29 c2                                        	sub    rdx,rax
   8979f:	c5 fc 29 84 24 a0 00 00 00                      	vmovaps YMMWORD PTR [rsp+0xa0],ymm0
   897a8:	c5 fd 7f 4c 24 40                               	vmovdqa YMMWORD PTR [rsp+0x40],ymm1
   897ae:	0f 92 c0                                        	setb   al
   897b1:	49 39 c9                                        	cmp    r9,rcx
   897b4:	49 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs r9,0xcf9bb18d1ece5fd7
   897be:	48 89 94 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],rdx
   897c6:	0f 92 c1                                        	setb   cl
   897c9:	4a 8d 14 0b                                     	lea    rdx,[rbx+r9*1]
   897cd:	4c 8d 8c 24 20 02 00 00                         	lea    r9,[rsp+0x220]
   897d5:	08 c1                                           	or     cl,al
   897d7:	0f b6 c1                                        	movzx  eax,cl
   897da:	48 29 c2                                        	sub    rdx,rax
   897dd:	48 89 94 24 00 03 00 00                         	mov    QWORD PTR [rsp+0x300],rdx
   897e5:	0f 92 84 24 40 05 00 00                         	setb   BYTE PTR [rsp+0x540]
   897ed:	31 db                                           	xor    ebx,ebx
   897ef:	31 ff                                           	xor    edi,edi
   897f1:	45 31 ff                                        	xor    r15d,r15d
   897f4:	31 c9                                           	xor    ecx,ecx
   897f6:	31 c0                                           	xor    eax,eax
   897f8:	49 8b 16                                        	mov    rdx,QWORD PTR [r14]
   897fb:	45 31 e4                                        	xor    r12d,r12d
   897fe:	c4 42 bb f6 55 00                               	mulx   r10,r8,QWORD PTR [r13+0x0]
   89804:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   8980a:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   89810:	c4 42 bb f6 55 08                               	mulx   r10,r8,QWORD PTR [r13+0x8]
   89816:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   8981c:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   89822:	c4 42 bb f6 55 10                               	mulx   r10,r8,QWORD PTR [r13+0x10]
   89828:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   8982e:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   89834:	c4 42 bb f6 55 18                               	mulx   r10,r8,QWORD PTR [r13+0x18]
   8983a:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89840:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   89846:	66 49 0f 38 f6 c4                               	adcx   rax,r12
   8984c:	48 89 da                                        	mov    rdx,rbx
   8984f:	49 0f af d3                                     	imul   rdx,r11
   89853:	45 31 e4                                        	xor    r12d,r12d
   89856:	c4 42 bb f6 11                                  	mulx   r10,r8,QWORD PTR [r9]
   8985b:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   89861:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   89867:	c4 42 bb f6 51 08                               	mulx   r10,r8,QWORD PTR [r9+0x8]
   8986d:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   89873:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   89879:	c4 42 bb f6 51 10                               	mulx   r10,r8,QWORD PTR [r9+0x10]
   8987f:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   89885:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   8988b:	c4 42 bb f6 51 18                               	mulx   r10,r8,QWORD PTR [r9+0x18]
   89891:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89897:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   8989d:	66 49 0f 38 f6 c4                               	adcx   rax,r12
   898a3:	49 8b 56 08                                     	mov    rdx,QWORD PTR [r14+0x8]
   898a7:	45 31 e4                                        	xor    r12d,r12d
   898aa:	c4 42 bb f6 55 00                               	mulx   r10,r8,QWORD PTR [r13+0x0]
   898b0:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   898b6:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   898bc:	c4 42 bb f6 55 08                               	mulx   r10,r8,QWORD PTR [r13+0x8]
   898c2:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   898c8:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   898ce:	c4 42 bb f6 55 10                               	mulx   r10,r8,QWORD PTR [r13+0x10]
   898d4:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   898da:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   898e0:	c4 42 bb f6 55 18                               	mulx   r10,r8,QWORD PTR [r13+0x18]
   898e6:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   898ec:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   898f2:	66 49 0f 38 f6 dc                               	adcx   rbx,r12
   898f8:	48 89 fa                                        	mov    rdx,rdi
   898fb:	49 0f af d3                                     	imul   rdx,r11
   898ff:	45 31 e4                                        	xor    r12d,r12d
   89902:	c4 42 bb f6 11                                  	mulx   r10,r8,QWORD PTR [r9]
   89907:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   8990d:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   89913:	c4 42 bb f6 51 08                               	mulx   r10,r8,QWORD PTR [r9+0x8]
   89919:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   8991f:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   89925:	c4 42 bb f6 51 10                               	mulx   r10,r8,QWORD PTR [r9+0x10]
   8992b:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89931:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   89937:	c4 42 bb f6 51 18                               	mulx   r10,r8,QWORD PTR [r9+0x18]
   8993d:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89943:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   89949:	66 49 0f 38 f6 dc                               	adcx   rbx,r12
   8994f:	49 8b 56 10                                     	mov    rdx,QWORD PTR [r14+0x10]
   89953:	45 31 e4                                        	xor    r12d,r12d
   89956:	c4 42 bb f6 55 00                               	mulx   r10,r8,QWORD PTR [r13+0x0]
   8995c:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   89962:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   89968:	c4 42 bb f6 55 08                               	mulx   r10,r8,QWORD PTR [r13+0x8]
   8996e:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89974:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   8997a:	c4 42 bb f6 55 10                               	mulx   r10,r8,QWORD PTR [r13+0x10]
   89980:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89986:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   8998c:	c4 42 bb f6 55 18                               	mulx   r10,r8,QWORD PTR [r13+0x18]
   89992:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   89998:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   8999e:	66 49 0f 38 f6 fc                               	adcx   rdi,r12
   899a4:	4c 89 fa                                        	mov    rdx,r15
   899a7:	49 0f af d3                                     	imul   rdx,r11
   899ab:	45 31 e4                                        	xor    r12d,r12d
   899ae:	c4 42 bb f6 11                                  	mulx   r10,r8,QWORD PTR [r9]
   899b3:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   899b9:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   899bf:	c4 42 bb f6 51 08                               	mulx   r10,r8,QWORD PTR [r9+0x8]
   899c5:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   899cb:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   899d1:	c4 42 bb f6 51 10                               	mulx   r10,r8,QWORD PTR [r9+0x10]
   899d7:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   899dd:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   899e3:	c4 42 bb f6 51 18                               	mulx   r10,r8,QWORD PTR [r9+0x18]
   899e9:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   899ef:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   899f5:	66 49 0f 38 f6 fc                               	adcx   rdi,r12
   899fb:	49 8b 56 18                                     	mov    rdx,QWORD PTR [r14+0x18]
   899ff:	45 31 e4                                        	xor    r12d,r12d
   89a02:	c4 42 bb f6 55 00                               	mulx   r10,r8,QWORD PTR [r13+0x0]
   89a08:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89a0e:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   89a14:	c4 42 bb f6 55 08                               	mulx   r10,r8,QWORD PTR [r13+0x8]
   89a1a:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89a20:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   89a26:	c4 42 bb f6 55 10                               	mulx   r10,r8,QWORD PTR [r13+0x10]
   89a2c:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   89a32:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   89a38:	c4 42 bb f6 55 18                               	mulx   r10,r8,QWORD PTR [r13+0x18]
   89a3e:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   89a44:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   89a4a:	66 4d 0f 38 f6 fc                               	adcx   r15,r12
   89a50:	48 89 ca                                        	mov    rdx,rcx
   89a53:	49 0f af d3                                     	imul   rdx,r11
   89a57:	45 31 e4                                        	xor    r12d,r12d
   89a5a:	c4 42 bb f6 11                                  	mulx   r10,r8,QWORD PTR [r9]
   89a5f:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89a65:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   89a6b:	c4 42 bb f6 51 08                               	mulx   r10,r8,QWORD PTR [r9+0x8]
   89a71:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89a77:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   89a7d:	c4 42 bb f6 51 10                               	mulx   r10,r8,QWORD PTR [r9+0x10]
   89a83:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   89a89:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   89a8f:	c4 42 bb f6 51 18                               	mulx   r10,r8,QWORD PTR [r9+0x18]
   89a95:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   89a9b:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   89aa1:	66 4d 0f 38 f6 fc                               	adcx   r15,r12
   89aa7:	49 89 c3                                        	mov    r11,rax
   89aaa:	48 b8 47 fd 7c d8 16 8c 20 3c                   	movabs rax,0x3c208c16d87cfd47
   89ab4:	48 b9 73 35 8e 97 6e 95 7e 68                   	movabs rcx,0x687e956e978e3573
   89abe:	4d 89 fd                                        	mov    r13,r15
   89ac1:	49 b9 29 a0 31 e1 72 4e 64 30                   	movabs r9,0x30644e72e131a029
   89acb:	49 89 ff                                        	mov    r15,rdi
   89ace:	49 39 c3                                        	cmp    r11,rax
   89ad1:	48 8d 14 0b                                     	lea    rdx,[rbx+rcx*1]
   89ad5:	48 b8 8d ca 71 68 91 6a 81 97                   	movabs rax,0x97816a916871ca8d
   89adf:	48 83 da 00                                     	sbb    rdx,0x0
   89ae3:	0f 92 c1                                        	setb   cl
   89ae6:	48 39 c3                                        	cmp    rbx,rax
   89ae9:	48 b8 a3 a7 7e 7e 49 ba af 47                   	movabs rax,0x47afba497e7ea7a3
   89af3:	41 0f 92 c0                                     	setb   r8b
   89af7:	4c 8d 14 07                                     	lea    r10,[rdi+rax*1]
   89afb:	48 8b 84 24 40 07 00 00                         	mov    rax,QWORD PTR [rsp+0x740]
   89b03:	41 08 c8                                        	or     r8b,cl
   89b06:	41 0f b6 c8                                     	movzx  ecx,r8b
   89b0a:	49 b8 5d 58 81 81 b6 45 50 b8                   	movabs r8,0xb85045b68181585d
   89b14:	49 29 ca                                        	sub    r10,rcx
   89b17:	0f 92 c1                                        	setb   cl
   89b1a:	4c 39 c7                                        	cmp    rdi,r8
   89b1d:	41 0f 92 c0                                     	setb   r8b
   89b21:	41 08 c8                                        	or     r8b,cl
   89b24:	48 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs rcx,0xcf9bb18d1ece5fd7
   89b2e:	45 0f b6 c0                                     	movzx  r8d,r8b
   89b32:	4c 01 e9                                        	add    rcx,r13
   89b35:	4c 29 c1                                        	sub    rcx,r8
   89b38:	41 0f 92 c0                                     	setb   r8b
   89b3c:	4d 39 cd                                        	cmp    r13,r9
   89b3f:	41 0f 92 c4                                     	setb   r12b
   89b43:	4c 39 c8                                        	cmp    rax,r9
   89b46:	41 0f 92 c1                                     	setb   r9b
   89b4a:	44 0a 8c 24 40 05 00 00                         	or     r9b,BYTE PTR [rsp+0x540]
   89b52:	75 2c                                           	jne    89b80 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x3da0>
   89b54:	48 8b 84 24 40 02 00 00                         	mov    rax,QWORD PTR [rsp+0x240]
   89b5c:	49 b9 b9 02 83 27 e9 73 df c3                   	movabs r9,0xc3df73e9278302b9
   89b66:	4c 01 c8                                        	add    rax,r9
   89b69:	49 89 c1                                        	mov    r9,rax
   89b6c:	45 08 c4                                        	or     r12b,r8b
   89b6f:	74 44                                           	je     89bb5 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x3dd5>
   89b71:	48 89 da                                        	mov    rdx,rbx
   89b74:	4d 89 fa                                        	mov    r10,r15
   89b77:	4c 89 e9                                        	mov    rcx,r13
   89b7a:	eb 46                                           	jmp    89bc2 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x3de2>
   89b7c:	0f 1f 40 00                                     	nop    DWORD PTR [rax+0x0]
   89b80:	4c 8b 8c 24 40 06 00 00                         	mov    r9,QWORD PTR [rsp+0x640]
   89b88:	48 8b bc 24 80 06 00 00                         	mov    rdi,QWORD PTR [rsp+0x680]
   89b90:	48 89 84 24 00 03 00 00                         	mov    QWORD PTR [rsp+0x300],rax
   89b98:	4c 89 8c 24 c0 02 00 00                         	mov    QWORD PTR [rsp+0x2c0],r9
   89ba0:	4c 8b 8c 24 40 02 00 00                         	mov    r9,QWORD PTR [rsp+0x240]
   89ba8:	48 89 bc 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],rdi
   89bb0:	45 08 c4                                        	or     r12b,r8b
   89bb3:	75 bc                                           	jne    89b71 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x3d91>
   89bb5:	48 b8 b9 02 83 27 e9 73 df c3                   	movabs rax,0xc3df73e9278302b9
   89bbf:	49 01 c3                                        	add    r11,rax
   89bc2:	4c 89 9c 34 c0 00 00 00                         	mov    QWORD PTR [rsp+rsi*1+0xc0],r11
   89bca:	48 89 94 34 c8 00 00 00                         	mov    QWORD PTR [rsp+rsi*1+0xc8],rdx
   89bd2:	4c 89 94 34 d0 00 00 00                         	mov    QWORD PTR [rsp+rsi*1+0xd0],r10
   89bda:	48 89 8c 34 d8 00 00 00                         	mov    QWORD PTR [rsp+rsi*1+0xd8],rcx
   89be2:	48 8b 84 24 c0 02 00 00                         	mov    rax,QWORD PTR [rsp+0x2c0]
   89bea:	48 8b 8c 24 80 02 00 00                         	mov    rcx,QWORD PTR [rsp+0x280]
   89bf2:	48 8b 94 24 00 03 00 00                         	mov    rdx,QWORD PTR [rsp+0x300]
   89bfa:	4c 89 8c 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],r9
   89c02:	4c 89 4c 24 40                                  	mov    QWORD PTR [rsp+0x40],r9
   89c07:	c5 fd 7f 94 24 20 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x220],ymm2
   89c10:	4d 89 cd                                        	mov    r13,r9
   89c13:	4c 8d 9c 24 a0 00 00 00                         	lea    r11,[rsp+0xa0]
   89c1b:	48 8d 5c 24 40                                  	lea    rbx,[rsp+0x40]
   89c20:	4c 8d bc 24 20 02 00 00                         	lea    r15,[rsp+0x220]
   89c28:	49 bc 89 63 86 e4 82 07 d2 87                   	movabs r12,0x87d20782e4866389
   89c32:	48 89 84 24 a8 00 00 00                         	mov    QWORD PTR [rsp+0xa8],rax
   89c3a:	48 89 8c 24 b0 00 00 00                         	mov    QWORD PTR [rsp+0xb0],rcx
   89c42:	48 89 44 24 48                                  	mov    QWORD PTR [rsp+0x48],rax
   89c47:	48 89 4c 24 50                                  	mov    QWORD PTR [rsp+0x50],rcx
   89c4c:	48 89 94 24 b8 00 00 00                         	mov    QWORD PTR [rsp+0xb8],rdx
   89c54:	48 89 54 24 58                                  	mov    QWORD PTR [rsp+0x58],rdx
   89c59:	31 ff                                           	xor    edi,edi
   89c5b:	31 c9                                           	xor    ecx,ecx
   89c5d:	31 c0                                           	xor    eax,eax
   89c5f:	31 f6                                           	xor    esi,esi
   89c61:	45 31 f6                                        	xor    r14d,r14d
   89c64:	49 8b 13                                        	mov    rdx,QWORD PTR [r11]
   89c67:	45 31 d2                                        	xor    r10d,r10d
   89c6a:	c4 62 bb f6 0b                                  	mulx   r9,r8,QWORD PTR [rbx]
   89c6f:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   89c75:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   89c7b:	c4 62 bb f6 4b 08                               	mulx   r9,r8,QWORD PTR [rbx+0x8]
   89c81:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89c87:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   89c8d:	c4 62 bb f6 4b 10                               	mulx   r9,r8,QWORD PTR [rbx+0x10]
   89c93:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89c99:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   89c9f:	c4 62 bb f6 4b 18                               	mulx   r9,r8,QWORD PTR [rbx+0x18]
   89ca5:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   89cab:	f3 4d 0f 38 f6 f1                               	adox   r14,r9
   89cb1:	66 4d 0f 38 f6 f2                               	adcx   r14,r10
   89cb7:	48 89 fa                                        	mov    rdx,rdi
   89cba:	49 0f af d4                                     	imul   rdx,r12
   89cbe:	45 31 d2                                        	xor    r10d,r10d
   89cc1:	c4 42 bb f6 0f                                  	mulx   r9,r8,QWORD PTR [r15]
   89cc6:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   89ccc:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   89cd2:	c4 42 bb f6 4f 08                               	mulx   r9,r8,QWORD PTR [r15+0x8]
   89cd8:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89cde:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   89ce4:	c4 42 bb f6 4f 10                               	mulx   r9,r8,QWORD PTR [r15+0x10]
   89cea:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89cf0:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   89cf6:	c4 42 bb f6 4f 18                               	mulx   r9,r8,QWORD PTR [r15+0x18]
   89cfc:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   89d02:	f3 4d 0f 38 f6 f1                               	adox   r14,r9
   89d08:	66 4d 0f 38 f6 f2                               	adcx   r14,r10
   89d0e:	49 8b 53 08                                     	mov    rdx,QWORD PTR [r11+0x8]
   89d12:	45 31 d2                                        	xor    r10d,r10d
   89d15:	c4 62 bb f6 0b                                  	mulx   r9,r8,QWORD PTR [rbx]
   89d1a:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89d20:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   89d26:	c4 62 bb f6 4b 08                               	mulx   r9,r8,QWORD PTR [rbx+0x8]
   89d2c:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89d32:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   89d38:	c4 62 bb f6 4b 10                               	mulx   r9,r8,QWORD PTR [rbx+0x10]
   89d3e:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   89d44:	f3 4d 0f 38 f6 f1                               	adox   r14,r9
   89d4a:	c4 62 bb f6 4b 18                               	mulx   r9,r8,QWORD PTR [rbx+0x18]
   89d50:	66 4d 0f 38 f6 f0                               	adcx   r14,r8
   89d56:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   89d5c:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   89d62:	48 89 ca                                        	mov    rdx,rcx
   89d65:	49 0f af d4                                     	imul   rdx,r12
   89d69:	45 31 d2                                        	xor    r10d,r10d
   89d6c:	c4 42 bb f6 0f                                  	mulx   r9,r8,QWORD PTR [r15]
   89d71:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89d77:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   89d7d:	c4 42 bb f6 4f 08                               	mulx   r9,r8,QWORD PTR [r15+0x8]
   89d83:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89d89:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   89d8f:	c4 42 bb f6 4f 10                               	mulx   r9,r8,QWORD PTR [r15+0x10]
   89d95:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   89d9b:	f3 4d 0f 38 f6 f1                               	adox   r14,r9
   89da1:	c4 42 bb f6 4f 18                               	mulx   r9,r8,QWORD PTR [r15+0x18]
   89da7:	66 4d 0f 38 f6 f0                               	adcx   r14,r8
   89dad:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   89db3:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   89db9:	49 8b 53 10                                     	mov    rdx,QWORD PTR [r11+0x10]
   89dbd:	45 31 d2                                        	xor    r10d,r10d
   89dc0:	c4 62 bb f6 0b                                  	mulx   r9,r8,QWORD PTR [rbx]
   89dc5:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89dcb:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   89dd1:	c4 62 bb f6 4b 08                               	mulx   r9,r8,QWORD PTR [rbx+0x8]
   89dd7:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   89ddd:	f3 4d 0f 38 f6 f1                               	adox   r14,r9
   89de3:	c4 62 bb f6 4b 10                               	mulx   r9,r8,QWORD PTR [rbx+0x10]
   89de9:	66 4d 0f 38 f6 f0                               	adcx   r14,r8
   89def:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   89df5:	c4 62 bb f6 4b 18                               	mulx   r9,r8,QWORD PTR [rbx+0x18]
   89dfb:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   89e01:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   89e07:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   89e0d:	48 89 c2                                        	mov    rdx,rax
   89e10:	49 0f af d4                                     	imul   rdx,r12
   89e14:	45 31 d2                                        	xor    r10d,r10d
   89e17:	c4 42 bb f6 0f                                  	mulx   r9,r8,QWORD PTR [r15]
   89e1c:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   89e22:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   89e28:	c4 42 bb f6 4f 08                               	mulx   r9,r8,QWORD PTR [r15+0x8]
   89e2e:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   89e34:	f3 4d 0f 38 f6 f1                               	adox   r14,r9
   89e3a:	c4 42 bb f6 4f 10                               	mulx   r9,r8,QWORD PTR [r15+0x10]
   89e40:	66 4d 0f 38 f6 f0                               	adcx   r14,r8
   89e46:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   89e4c:	c4 42 bb f6 4f 18                               	mulx   r9,r8,QWORD PTR [r15+0x18]
   89e52:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   89e58:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   89e5e:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   89e64:	49 8b 53 18                                     	mov    rdx,QWORD PTR [r11+0x18]
   89e68:	45 31 d2                                        	xor    r10d,r10d
   89e6b:	c4 62 bb f6 0b                                  	mulx   r9,r8,QWORD PTR [rbx]
   89e70:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   89e76:	f3 4d 0f 38 f6 f1                               	adox   r14,r9
   89e7c:	c4 62 bb f6 4b 08                               	mulx   r9,r8,QWORD PTR [rbx+0x8]
   89e82:	66 4d 0f 38 f6 f0                               	adcx   r14,r8
   89e88:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   89e8e:	c4 62 bb f6 4b 10                               	mulx   r9,r8,QWORD PTR [rbx+0x10]
   89e94:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   89e9a:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   89ea0:	c4 62 bb f6 4b 18                               	mulx   r9,r8,QWORD PTR [rbx+0x18]
   89ea6:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89eac:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   89eb2:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   89eb8:	48 89 f2                                        	mov    rdx,rsi
   89ebb:	49 0f af d4                                     	imul   rdx,r12
   89ebf:	45 31 d2                                        	xor    r10d,r10d
   89ec2:	c4 42 bb f6 0f                                  	mulx   r9,r8,QWORD PTR [r15]
   89ec7:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   89ecd:	f3 4d 0f 38 f6 f1                               	adox   r14,r9
   89ed3:	c4 42 bb f6 4f 08                               	mulx   r9,r8,QWORD PTR [r15+0x8]
   89ed9:	66 4d 0f 38 f6 f0                               	adcx   r14,r8
   89edf:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   89ee5:	c4 42 bb f6 4f 10                               	mulx   r9,r8,QWORD PTR [r15+0x10]
   89eeb:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   89ef1:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   89ef7:	c4 42 bb f6 4f 18                               	mulx   r9,r8,QWORD PTR [r15+0x18]
   89efd:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   89f03:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   89f09:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   89f0f:	48 ba 73 35 8e 97 6e 95 7e 68                   	movabs rdx,0x687e956e978e3573
   89f19:	49 b8 8d ca 71 68 91 6a 81 97                   	movabs r8,0x97816a916871ca8d
   89f23:	4d 89 f4                                        	mov    r12,r14
   89f26:	4c 89 ac 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],r13
   89f2e:	48 8d 34 17                                     	lea    rsi,[rdi+rdx*1]
   89f32:	48 ba 47 fd 7c d8 16 8c 20 3c                   	movabs rdx,0x3c208c16d87cfd47
   89f3c:	49 39 d6                                        	cmp    r14,rdx
   89f3f:	48 83 de 00                                     	sbb    rsi,0x0
   89f43:	0f 92 c2                                        	setb   dl
   89f46:	4c 39 c7                                        	cmp    rdi,r8
   89f49:	41 0f 92 c0                                     	setb   r8b
   89f4d:	41 08 d0                                        	or     r8b,dl
   89f50:	48 ba a3 a7 7e 7e 49 ba af 47                   	movabs rdx,0x47afba497e7ea7a3
   89f5a:	4c 8d 0c 11                                     	lea    r9,[rcx+rdx*1]
   89f5e:	41 0f b6 d0                                     	movzx  edx,r8b
   89f62:	49 b8 5d 58 81 81 b6 45 50 b8                   	movabs r8,0xb85045b68181585d
   89f6c:	49 29 d1                                        	sub    r9,rdx
   89f6f:	0f 92 c2                                        	setb   dl
   89f72:	4c 39 c1                                        	cmp    rcx,r8
   89f75:	41 0f 92 c0                                     	setb   r8b
   89f79:	41 08 d0                                        	or     r8b,dl
   89f7c:	48 ba d7 5f ce 1e 8d b1 9b cf                   	movabs rdx,0xcf9bb18d1ece5fd7
   89f86:	48 8d 1c 10                                     	lea    rbx,[rax+rdx*1]
   89f8a:	41 0f b6 d0                                     	movzx  edx,r8b
   89f8e:	49 b8 29 a0 31 e1 72 4e 64 30                   	movabs r8,0x30644e72e131a029
   89f98:	48 29 d3                                        	sub    rbx,rdx
   89f9b:	0f 92 c2                                        	setb   dl
   89f9e:	4c 39 c0                                        	cmp    rax,r8
   89fa1:	41 0f 92 c0                                     	setb   r8b
   89fa5:	41 08 d0                                        	or     r8b,dl
   89fa8:	75 16                                           	jne    89fc0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x41e0>
   89faa:	48 b8 b9 02 83 27 e9 73 df c3                   	movabs rax,0xc3df73e9278302b9
   89fb4:	49 01 c4                                        	add    r12,rax
   89fb7:	eb 10                                           	jmp    89fc9 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x41e9>
   89fb9:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   89fc0:	48 89 fe                                        	mov    rsi,rdi
   89fc3:	49 89 c9                                        	mov    r9,rcx
   89fc6:	48 89 c3                                        	mov    rbx,rax
   89fc9:	c5 fc 28 84 24 20 06 00 00                      	vmovaps ymm0,YMMWORD PTR [rsp+0x620]
   89fd2:	c5 fd 7f 94 24 20 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x220],ymm2
   89fdb:	4c 8b ac 24 c0 04 00 00                         	mov    r13,QWORD PTR [rsp+0x4c0]
   89fe3:	4c 8b 94 24 80 04 00 00                         	mov    r10,QWORD PTR [rsp+0x480]
   89feb:	4c 8b b4 24 40 04 00 00                         	mov    r14,QWORD PTR [rsp+0x440]
   89ff3:	4c 8d 5c 24 40                                  	lea    r11,[rsp+0x40]
   89ff8:	4c 8d bc 24 20 02 00 00                         	lea    r15,[rsp+0x220]
   8a000:	c5 fc 29 44 24 40                               	vmovaps YMMWORD PTR [rsp+0x40],ymm0
   8a006:	4d 2b 23                                        	sub    r12,QWORD PTR [r11]
   8a009:	49 1b 73 08                                     	sbb    rsi,QWORD PTR [r11+0x8]
   8a00d:	4d 1b 4b 10                                     	sbb    r9,QWORD PTR [r11+0x10]
   8a011:	49 1b 5b 18                                     	sbb    rbx,QWORD PTR [r11+0x18]
   8a015:	4d 19 c0                                        	sbb    r8,r8
   8a018:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
   8a01b:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
   8a01f:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
   8a023:	49 8b 7f 18                                     	mov    rdi,QWORD PTR [r15+0x18]
   8a027:	4c 21 c0                                        	and    rax,r8
   8a02a:	4c 21 c1                                        	and    rcx,r8
   8a02d:	4c 21 c2                                        	and    rdx,r8
   8a030:	4c 21 c7                                        	and    rdi,r8
   8a033:	49 01 c4                                        	add    r12,rax
   8a036:	48 11 ce                                        	adc    rsi,rcx
   8a039:	49 11 d1                                        	adc    r9,rdx
   8a03c:	48 11 fb                                        	adc    rbx,rdi
   8a03f:	4c 89 64 24 40                                  	mov    QWORD PTR [rsp+0x40],r12
   8a044:	4c 89 a4 24 c0 04 00 00                         	mov    QWORD PTR [rsp+0x4c0],r12
   8a04c:	48 89 74 24 48                                  	mov    QWORD PTR [rsp+0x48],rsi
   8a051:	48 89 b4 24 80 04 00 00                         	mov    QWORD PTR [rsp+0x480],rsi
   8a059:	4c 89 4c 24 50                                  	mov    QWORD PTR [rsp+0x50],r9
   8a05e:	4c 89 8c 24 40 04 00 00                         	mov    QWORD PTR [rsp+0x440],r9
   8a066:	48 89 9c 24 40 05 00 00                         	mov    QWORD PTR [rsp+0x540],rbx
   8a06e:	48 89 5c 24 58                                  	mov    QWORD PTR [rsp+0x58],rbx
   8a073:	c5 fd 7f 94 24 20 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x220],ymm2
   8a07c:	4c 8d 9c 24 20 02 00 00                         	lea    r11,[rsp+0x220]
   8a084:	48 8d 74 24 40                                  	lea    rsi,[rsp+0x40]
   8a089:	4c 8d a4 24 a0 00 00 00                         	lea    r12,[rsp+0xa0]
   8a091:	4c 8b 8c 24 80 07 00 00                         	mov    r9,QWORD PTR [rsp+0x780]
   8a099:	4c 2b 2e                                        	sub    r13,QWORD PTR [rsi]
   8a09c:	4c 1b 56 08                                     	sbb    r10,QWORD PTR [rsi+0x8]
   8a0a0:	4c 1b 76 10                                     	sbb    r14,QWORD PTR [rsi+0x10]
   8a0a4:	4c 1b 4e 18                                     	sbb    r9,QWORD PTR [rsi+0x18]
   8a0a8:	4d 19 c0                                        	sbb    r8,r8
   8a0ab:	49 8b 03                                        	mov    rax,QWORD PTR [r11]
   8a0ae:	49 8b 4b 08                                     	mov    rcx,QWORD PTR [r11+0x8]
   8a0b2:	49 8b 53 10                                     	mov    rdx,QWORD PTR [r11+0x10]
   8a0b6:	49 8b 7b 18                                     	mov    rdi,QWORD PTR [r11+0x18]
   8a0ba:	4c 21 c0                                        	and    rax,r8
   8a0bd:	4c 21 c1                                        	and    rcx,r8
   8a0c0:	4c 21 c2                                        	and    rdx,r8
   8a0c3:	4c 21 c7                                        	and    rdi,r8
   8a0c6:	49 01 c5                                        	add    r13,rax
   8a0c9:	49 11 ca                                        	adc    r10,rcx
   8a0cc:	49 11 d6                                        	adc    r14,rdx
   8a0cf:	49 11 f9                                        	adc    r9,rdi
   8a0d2:	4c 89 6c 24 40                                  	mov    QWORD PTR [rsp+0x40],r13
   8a0d7:	4c 89 54 24 48                                  	mov    QWORD PTR [rsp+0x48],r10
   8a0dc:	4c 89 74 24 50                                  	mov    QWORD PTR [rsp+0x50],r14
   8a0e1:	4c 89 4c 24 58                                  	mov    QWORD PTR [rsp+0x58],r9
   8a0e6:	c5 fd 7f 94 24 20 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x220],ymm2
   8a0ef:	49 bd 89 63 86 e4 82 07 d2 87                   	movabs r13,0x87d20782e4866389
   8a0f9:	48 8b 84 24 40 02 00 00                         	mov    rax,QWORD PTR [rsp+0x240]
   8a101:	48 8b 8c 24 c0 02 00 00                         	mov    rcx,QWORD PTR [rsp+0x2c0]
   8a109:	48 8b bc 24 80 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x280]
   8a111:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   8a119:	48 89 8c 24 a8 00 00 00                         	mov    QWORD PTR [rsp+0xa8],rcx
   8a121:	48 8b 8c 24 00 03 00 00                         	mov    rcx,QWORD PTR [rsp+0x300]
   8a129:	48 89 bc 24 b0 00 00 00                         	mov    QWORD PTR [rsp+0xb0],rdi
   8a131:	48 89 8c 24 b8 00 00 00                         	mov    QWORD PTR [rsp+0xb8],rcx
   8a139:	31 ff                                           	xor    edi,edi
   8a13b:	31 c9                                           	xor    ecx,ecx
   8a13d:	31 c0                                           	xor    eax,eax
   8a13f:	45 31 c9                                        	xor    r9d,r9d
   8a142:	45 31 c0                                        	xor    r8d,r8d
   8a145:	48 8b 16                                        	mov    rdx,QWORD PTR [rsi]
   8a148:	45 31 ff                                        	xor    r15d,r15d
   8a14b:	c4 42 ab f6 34 24                               	mulx   r14,r10,QWORD PTR [r12]
   8a151:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   8a157:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   8a15d:	c4 42 ab f6 74 24 08                            	mulx   r14,r10,QWORD PTR [r12+0x8]
   8a164:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   8a16a:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   8a170:	c4 42 ab f6 74 24 10                            	mulx   r14,r10,QWORD PTR [r12+0x10]
   8a177:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   8a17d:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   8a183:	c4 42 ab f6 74 24 18                            	mulx   r14,r10,QWORD PTR [r12+0x18]
   8a18a:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   8a190:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   8a196:	66 4d 0f 38 f6 c7                               	adcx   r8,r15
   8a19c:	48 89 fa                                        	mov    rdx,rdi
   8a19f:	49 0f af d5                                     	imul   rdx,r13
   8a1a3:	45 31 ff                                        	xor    r15d,r15d
   8a1a6:	c4 42 ab f6 33                                  	mulx   r14,r10,QWORD PTR [r11]
   8a1ab:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   8a1b1:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   8a1b7:	c4 42 ab f6 73 08                               	mulx   r14,r10,QWORD PTR [r11+0x8]
   8a1bd:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   8a1c3:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   8a1c9:	c4 42 ab f6 73 10                               	mulx   r14,r10,QWORD PTR [r11+0x10]
   8a1cf:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   8a1d5:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   8a1db:	c4 42 ab f6 73 18                               	mulx   r14,r10,QWORD PTR [r11+0x18]
   8a1e1:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   8a1e7:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   8a1ed:	66 4d 0f 38 f6 c7                               	adcx   r8,r15
   8a1f3:	48 8b 56 08                                     	mov    rdx,QWORD PTR [rsi+0x8]
   8a1f7:	45 31 ff                                        	xor    r15d,r15d
   8a1fa:	c4 42 ab f6 34 24                               	mulx   r14,r10,QWORD PTR [r12]
   8a200:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   8a206:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   8a20c:	c4 42 ab f6 74 24 08                            	mulx   r14,r10,QWORD PTR [r12+0x8]
   8a213:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   8a219:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   8a21f:	c4 42 ab f6 74 24 10                            	mulx   r14,r10,QWORD PTR [r12+0x10]
   8a226:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   8a22c:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   8a232:	c4 42 ab f6 74 24 18                            	mulx   r14,r10,QWORD PTR [r12+0x18]
   8a239:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   8a23f:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   8a245:	66 49 0f 38 f6 ff                               	adcx   rdi,r15
   8a24b:	48 89 ca                                        	mov    rdx,rcx
   8a24e:	49 0f af d5                                     	imul   rdx,r13
   8a252:	45 31 ff                                        	xor    r15d,r15d
   8a255:	c4 42 ab f6 33                                  	mulx   r14,r10,QWORD PTR [r11]
   8a25a:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   8a260:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   8a266:	c4 42 ab f6 73 08                               	mulx   r14,r10,QWORD PTR [r11+0x8]
   8a26c:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   8a272:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   8a278:	c4 42 ab f6 73 10                               	mulx   r14,r10,QWORD PTR [r11+0x10]
   8a27e:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   8a284:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   8a28a:	c4 42 ab f6 73 18                               	mulx   r14,r10,QWORD PTR [r11+0x18]
   8a290:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   8a296:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   8a29c:	66 49 0f 38 f6 ff                               	adcx   rdi,r15
   8a2a2:	48 8b 56 10                                     	mov    rdx,QWORD PTR [rsi+0x10]
   8a2a6:	45 31 ff                                        	xor    r15d,r15d
   8a2a9:	c4 42 ab f6 34 24                               	mulx   r14,r10,QWORD PTR [r12]
   8a2af:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   8a2b5:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   8a2bb:	c4 42 ab f6 74 24 08                            	mulx   r14,r10,QWORD PTR [r12+0x8]
   8a2c2:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   8a2c8:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   8a2ce:	c4 42 ab f6 74 24 10                            	mulx   r14,r10,QWORD PTR [r12+0x10]
   8a2d5:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   8a2db:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   8a2e1:	c4 42 ab f6 74 24 18                            	mulx   r14,r10,QWORD PTR [r12+0x18]
   8a2e8:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   8a2ee:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   8a2f4:	66 49 0f 38 f6 cf                               	adcx   rcx,r15
   8a2fa:	48 89 c2                                        	mov    rdx,rax
   8a2fd:	49 0f af d5                                     	imul   rdx,r13
   8a301:	45 31 ff                                        	xor    r15d,r15d
   8a304:	c4 42 ab f6 33                                  	mulx   r14,r10,QWORD PTR [r11]
   8a309:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   8a30f:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   8a315:	c4 42 ab f6 73 08                               	mulx   r14,r10,QWORD PTR [r11+0x8]
   8a31b:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   8a321:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   8a327:	c4 42 ab f6 73 10                               	mulx   r14,r10,QWORD PTR [r11+0x10]
   8a32d:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   8a333:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   8a339:	c4 42 ab f6 73 18                               	mulx   r14,r10,QWORD PTR [r11+0x18]
   8a33f:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   8a345:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   8a34b:	66 49 0f 38 f6 cf                               	adcx   rcx,r15
   8a351:	48 8b 56 18                                     	mov    rdx,QWORD PTR [rsi+0x18]
   8a355:	45 31 ff                                        	xor    r15d,r15d
   8a358:	c4 42 ab f6 34 24                               	mulx   r14,r10,QWORD PTR [r12]
   8a35e:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   8a364:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   8a36a:	c4 42 ab f6 74 24 08                            	mulx   r14,r10,QWORD PTR [r12+0x8]
   8a371:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   8a377:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   8a37d:	c4 42 ab f6 74 24 10                            	mulx   r14,r10,QWORD PTR [r12+0x10]
   8a384:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   8a38a:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   8a390:	c4 42 ab f6 74 24 18                            	mulx   r14,r10,QWORD PTR [r12+0x18]
   8a397:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   8a39d:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   8a3a3:	66 49 0f 38 f6 c7                               	adcx   rax,r15
   8a3a9:	4c 89 ca                                        	mov    rdx,r9
   8a3ac:	49 0f af d5                                     	imul   rdx,r13
   8a3b0:	45 31 ff                                        	xor    r15d,r15d
   8a3b3:	c4 42 ab f6 33                                  	mulx   r14,r10,QWORD PTR [r11]
   8a3b8:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   8a3be:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   8a3c4:	c4 42 ab f6 73 08                               	mulx   r14,r10,QWORD PTR [r11+0x8]
   8a3ca:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   8a3d0:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   8a3d6:	c4 42 ab f6 73 10                               	mulx   r14,r10,QWORD PTR [r11+0x10]
   8a3dc:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   8a3e2:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   8a3e8:	c4 42 ab f6 73 18                               	mulx   r14,r10,QWORD PTR [r11+0x18]
   8a3ee:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   8a3f4:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   8a3fa:	66 49 0f 38 f6 c7                               	adcx   rax,r15
   8a400:	48 ba 73 35 8e 97 6e 95 7e 68                   	movabs rdx,0x687e956e978e3573
   8a40a:	49 b9 47 fd 7c d8 16 8c 20 3c                   	movabs r9,0x3c208c16d87cfd47
   8a414:	49 ba 8d ca 71 68 91 6a 81 97                   	movabs r10,0x97816a916871ca8d
   8a41e:	48 01 fa                                        	add    rdx,rdi
   8a421:	4d 39 c8                                        	cmp    r8,r9
   8a424:	48 83 da 00                                     	sbb    rdx,0x0
   8a428:	41 0f 92 c1                                     	setb   r9b
   8a42c:	4c 39 d7                                        	cmp    rdi,r10
   8a42f:	41 0f 92 c2                                     	setb   r10b
   8a433:	45 08 ca                                        	or     r10b,r9b
   8a436:	49 b9 a3 a7 7e 7e 49 ba af 47                   	movabs r9,0x47afba497e7ea7a3
   8a440:	4e 8d 34 09                                     	lea    r14,[rcx+r9*1]
   8a444:	45 0f b6 ca                                     	movzx  r9d,r10b
   8a448:	49 ba 5d 58 81 81 b6 45 50 b8                   	movabs r10,0xb85045b68181585d
   8a452:	4d 29 ce                                        	sub    r14,r9
   8a455:	41 0f 92 c1                                     	setb   r9b
   8a459:	4c 39 d1                                        	cmp    rcx,r10
   8a45c:	41 0f 92 c2                                     	setb   r10b
   8a460:	45 08 ca                                        	or     r10b,r9b
   8a463:	49 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs r9,0xcf9bb18d1ece5fd7
   8a46d:	4e 8d 3c 08                                     	lea    r15,[rax+r9*1]
   8a471:	45 0f b6 ca                                     	movzx  r9d,r10b
   8a475:	49 ba 29 a0 31 e1 72 4e 64 30                   	movabs r10,0x30644e72e131a029
   8a47f:	4d 29 cf                                        	sub    r15,r9
   8a482:	41 0f 92 c1                                     	setb   r9b
   8a486:	4c 39 d0                                        	cmp    rax,r10
   8a489:	41 0f 92 c2                                     	setb   r10b
   8a48d:	45 08 ca                                        	or     r10b,r9b
   8a490:	75 1e                                           	jne    8a4b0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x46d0>
   8a492:	48 b8 b9 02 83 27 e9 73 df c3                   	movabs rax,0xc3df73e9278302b9
   8a49c:	49 01 c0                                        	add    r8,rax
   8a49f:	eb 18                                           	jmp    8a4b9 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x46d9>
   8a4a1:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00    	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   8a4b0:	48 89 fa                                        	mov    rdx,rdi
   8a4b3:	49 89 ce                                        	mov    r14,rcx
   8a4b6:	49 89 c7                                        	mov    r15,rax
   8a4b9:	c5 fd 6f 84 24 60 0a 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0xa60]
   8a4c2:	c5 fd 7f 94 24 20 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x220],ymm2
   8a4cb:	4c 8d 64 24 40                                  	lea    r12,[rsp+0x40]
   8a4d0:	4c 8d ac 24 20 02 00 00                         	lea    r13,[rsp+0x220]
   8a4d8:	c5 fd 7f 44 24 40                               	vmovdqa YMMWORD PTR [rsp+0x40],ymm0
   8a4de:	4d 2b 04 24                                     	sub    r8,QWORD PTR [r12]
   8a4e2:	49 1b 54 24 08                                  	sbb    rdx,QWORD PTR [r12+0x8]
   8a4e7:	4d 1b 74 24 10                                  	sbb    r14,QWORD PTR [r12+0x10]
   8a4ec:	4d 1b 7c 24 18                                  	sbb    r15,QWORD PTR [r12+0x18]
   8a4f1:	4d 19 d2                                        	sbb    r10,r10
   8a4f4:	49 8b 45 00                                     	mov    rax,QWORD PTR [r13+0x0]
   8a4f8:	49 8b 4d 08                                     	mov    rcx,QWORD PTR [r13+0x8]
   8a4fc:	49 8b 7d 10                                     	mov    rdi,QWORD PTR [r13+0x10]
   8a500:	4d 8b 4d 18                                     	mov    r9,QWORD PTR [r13+0x18]
   8a504:	4c 21 d0                                        	and    rax,r10
   8a507:	4c 21 d1                                        	and    rcx,r10
   8a50a:	4c 21 d7                                        	and    rdi,r10
   8a50d:	4d 21 d1                                        	and    r9,r10
   8a510:	49 01 c0                                        	add    r8,rax
   8a513:	48 11 ca                                        	adc    rdx,rcx
   8a516:	49 11 fe                                        	adc    r14,rdi
   8a519:	4d 11 cf                                        	adc    r15,r9
   8a51c:	48 8b bc 24 80 05 00 00                         	mov    rdi,QWORD PTR [rsp+0x580]
   8a524:	48 3b 7c 24 38                                  	cmp    rdi,QWORD PTR [rsp+0x38]
   8a529:	0f 83 9a 1e 00 00                               	jae    8c3c9 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x65e9>
   8a52f:	4c 8b 94 24 80 03 00 00                         	mov    r10,QWORD PTR [rsp+0x380]
   8a537:	4c 8b a4 24 00 04 00 00                         	mov    r12,QWORD PTR [rsp+0x400]
   8a53f:	4c 8b 4c 24 30                                  	mov    r9,QWORD PTR [rsp+0x30]
   8a544:	41 8b 02                                        	mov    eax,DWORD PTR [r10]
   8a547:	25 ff ff ff 7f                                  	and    eax,0x7fffffff
   8a54c:	49 39 c4                                        	cmp    r12,rax
   8a54f:	0f 86 5f 1e 00 00                               	jbe    8c3b4 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x65d4>
   8a555:	48 8b 8c 24 c0 05 00 00                         	mov    rcx,QWORD PTR [rsp+0x5c0]
   8a55d:	48 8b b4 24 c0 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x4c0]
   8a565:	4c 8b 9c 24 80 04 00 00                         	mov    r11,QWORD PTR [rsp+0x480]
   8a56d:	48 c1 e0 06                                     	shl    rax,0x6
   8a571:	48 8b 9c 24 40 04 00 00                         	mov    rbx,QWORD PTR [rsp+0x440]
   8a579:	49 83 c2 f0                                     	add    r10,0xfffffffffffffff0
   8a57d:	48 89 34 01                                     	mov    QWORD PTR [rcx+rax*1],rsi
   8a581:	4c 89 5c 01 08                                  	mov    QWORD PTR [rcx+rax*1+0x8],r11
   8a586:	4c 8b 9c 24 40 05 00 00                         	mov    r11,QWORD PTR [rsp+0x540]
   8a58e:	48 89 5c 01 10                                  	mov    QWORD PTR [rcx+rax*1+0x10],rbx
   8a593:	4c 89 5c 01 18                                  	mov    QWORD PTR [rcx+rax*1+0x18],r11
   8a598:	4c 89 44 01 20                                  	mov    QWORD PTR [rcx+rax*1+0x20],r8
   8a59d:	4c 8b 84 24 00 07 00 00                         	mov    r8,QWORD PTR [rsp+0x700]
   8a5a5:	4c 8b 9c 24 c0 06 00 00                         	mov    r11,QWORD PTR [rsp+0x6c0]
   8a5ad:	48 89 54 01 28                                  	mov    QWORD PTR [rcx+rax*1+0x28],rdx
   8a5b2:	48 8d 57 ff                                     	lea    rdx,[rdi-0x1]
   8a5b6:	4c 89 74 01 30                                  	mov    QWORD PTR [rcx+rax*1+0x30],r14
   8a5bb:	4c 89 7c 01 38                                  	mov    QWORD PTR [rcx+rax*1+0x38],r15
   8a5c0:	49 81 c0 60 ff ff ff                            	add    r8,0xffffffffffffff60
   8a5c7:	49 81 c3 60 ff ff ff                            	add    r11,0xffffffffffffff60
   8a5ce:	48 39 bc 24 c0 07 00 00                         	cmp    QWORD PTR [rsp+0x7c0],rdi
   8a5d6:	0f 82 64 ed ff ff                               	jb     89340 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x3560>
   8a5dc:	48 8b 84 24 c0 03 00 00                         	mov    rax,QWORD PTR [rsp+0x3c0]
   8a5e4:	4c 8b 7c 24 38                                  	mov    r15,QWORD PTR [rsp+0x38]
   8a5e9:	49 89 ce                                        	mov    r14,rcx
   8a5ec:	4c 8b 68 10                                     	mov    r13,QWORD PTR [rax+0x10]
   8a5f0:	62 f1 fe 48 6f 44 24 03                         	vmovdqu64 zmm0,ZMMWORD PTR [rsp+0xc0]
   8a5f8:	62 f1 fe 48 6f 4c 24 04                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x100]
   8a600:	62 f1 fe 48 6f 54 24 05                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x140]
   8a608:	62 f1 fe 48 6f 5c 24 06                         	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x180]
   8a610:	62 f1 fd 48 6f 3d e6 ce f7 ff                   	vmovdqa64 zmm7,ZMMWORD PTR [rip+0xfffffffffff7cee6]        # 7500 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x560>
   8a61a:	62 f1 fd 48 6f 35 1c cf f7 ff                   	vmovdqa64 zmm6,ZMMWORD PTR [rip+0xfffffffffff7cf1c]        # 7540 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x5a0>
   8a624:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   8a62a:	62 71 ed 48 6c c3                               	vpunpcklqdq zmm8,zmm2,zmm3
   8a630:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   8a636:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   8a63c:	62 f1 fd 48 6f ec                               	vmovdqa64 zmm5,zmm4
   8a642:	62 d2 c5 48 7e e8                               	vpermt2q zmm5,zmm7,zmm8
   8a648:	62 f2 fd 48 76 fa                               	vpermi2q zmm7,zmm0,zmm2
   8a64e:	62 f2 cd 48 7e c2                               	vpermt2q zmm0,zmm6,zmm2
   8a654:	62 d2 cd 48 7e e0                               	vpermt2q zmm4,zmm6,zmm8
   8a65a:	62 f2 fd 48 59 35 dc c5 f7 ff                   	vpbroadcastq zmm6,QWORD PTR [rip+0xfffffffffff7c5dc]        # 6c40 <GCC_except_table711+0x150>
   8a664:	62 f3 c5 48 71 cd 0c                            	vpshldq zmm1,zmm7,zmm5,0xc
   8a66b:	62 f3 fd 48 71 dc 24                            	vpshldq zmm3,zmm0,zmm4,0x24
   8a672:	62 f1 9d 48 73 d0 10                            	vpsrlq zmm12,zmm0,0x10
   8a679:	62 71 d5 48 db d6                               	vpandq zmm10,zmm5,zmm6
   8a67f:	62 f3 dd 48 71 ef 18                            	vpshldq zmm5,zmm4,zmm7,0x18
   8a686:	62 71 f5 48 db de                               	vpandq zmm11,zmm1,zmm6
   8a68c:	62 71 e5 48 db f6                               	vpandq zmm14,zmm3,zmm6
   8a692:	62 71 d5 48 db ee                               	vpandq zmm13,zmm5,zmm6
   8a698:	49 ba 31 e1 72 4e 64 30 00 00                   	movabs r10,0x30644e72e131
   8a6a2:	4d 85 ed                                        	test   r13,r13
   8a6a5:	0f 84 f3 19 00 00                               	je     8c09e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x62be>
   8a6ab:	48 8b 84 24 c0 03 00 00                         	mov    rax,QWORD PTR [rsp+0x3c0]
   8a6b3:	62 62 fd 48 59 15 9b c6 f7 ff                   	vpbroadcastq zmm26,QWORD PTR [rip+0xfffffffffff7c69b]        # 6d58 <GCC_except_table711+0x268>
   8a6bd:	62 f2 fd 48 59 15 79 c5 f7 ff                   	vpbroadcastq zmm2,QWORD PTR [rip+0xfffffffffff7c579]        # 6c40 <GCC_except_table711+0x150>
   8a6c7:	62 62 fd 48 59 1d 9f c5 f7 ff                   	vpbroadcastq zmm27,QWORD PTR [rip+0xfffffffffff7c59f]        # 6c70 <GCC_except_table711+0x180>
   8a6d1:	62 e2 fd 48 59 35 6d c5 f7 ff                   	vpbroadcastq zmm22,QWORD PTR [rip+0xfffffffffff7c56d]        # 6c48 <GCC_except_table711+0x158>
   8a6db:	62 62 fd 48 59 25 1b c6 f7 ff                   	vpbroadcastq zmm28,QWORD PTR [rip+0xfffffffffff7c61b]        # 6d00 <GCC_except_table711+0x210>
   8a6e5:	49 69 f5 40 06 00 00                            	imul   rsi,r13,0x640
   8a6ec:	48 ba 63 c2 e5 9c c8 60 00 00                   	movabs rdx,0x60c89ce5c263
   8a6f6:	49 b8 48 e1 7a 14 ae 47 e1 7a                   	movabs r8,0x7ae147ae147ae148
   8a700:	48 81 c6 c0 f9 ff ff                            	add    rsi,0xfffffffffffff9c0
   8a707:	48 8b 48 08                                     	mov    rcx,QWORD PTR [rax+0x8]
   8a70b:	0f 1f 44 00 00                                  	nop    DWORD PTR [rax+rax*1+0x0]
   8a710:	62 e1 fd 28 6f 3d c6 d0 f7 ff                   	vmovdqa64 ymm23,YMMWORD PTR [rip+0xfffffffffff7d0c6]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   8a71a:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   8a720:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   8a726:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   8a72c:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   8a732:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   8a738:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   8a73e:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   8a742:	48 89 f0                                        	mov    rax,rsi
   8a745:	48 c1 e8 06                                     	shr    rax,0x6
   8a749:	49 0f af c0                                     	imul   rax,r8
   8a74d:	62 e1 fe 28 7f 7c 24 06                         	vmovdqu64 YMMWORD PTR [rsp+0xc0],ymm23
   8a755:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   8a75d:	62 f1 fd 48 6f 4c 31 14                         	vmovdqa64 zmm1,ZMMWORD PTR [rcx+rsi*1+0x500]
   8a765:	62 71 fd 48 6f 7c 31 17                         	vmovdqa64 zmm15,ZMMWORD PTR [rcx+rsi*1+0x5c0]
   8a76d:	62 f1 fd 48 6f 7c 31 16                         	vmovdqa64 zmm7,ZMMWORD PTR [rcx+rsi*1+0x580]
   8a775:	62 f1 fd 48 6f 6c 31 15                         	vmovdqa64 zmm5,ZMMWORD PTR [rcx+rsi*1+0x540]
   8a77d:	62 f1 fd 48 6f 5c 31 18                         	vmovdqa64 zmm3,ZMMWORD PTR [rcx+rsi*1+0x600]
   8a785:	62 72 fd 48 59 44 24 1b                         	vpbroadcastq zmm8,QWORD PTR [rsp+0xd8]
   8a78d:	62 72 fd 48 59 4c 24 1a                         	vpbroadcastq zmm9,QWORD PTR [rsp+0xd0]
   8a795:	62 f2 fd 48 59 44 24 19                         	vpbroadcastq zmm0,QWORD PTR [rsp+0xc8]
   8a79d:	62 f2 fd 48 59 74 24 1c                         	vpbroadcastq zmm6,QWORD PTR [rsp+0xe0]
   8a7a5:	62 e1 fe 28 7f 7c 24 06                         	vmovdqu64 YMMWORD PTR [rsp+0xc0],ymm23
   8a7ad:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   8a7b5:	62 c2 85 48 b5 ca                               	vpmadd52huq zmm17,zmm15,zmm10
   8a7bb:	62 c2 f5 48 b4 c2                               	vpmadd52luq zmm16,zmm1,zmm10
   8a7c1:	62 c2 c5 48 b5 da                               	vpmadd52huq zmm19,zmm7,zmm10
   8a7c7:	62 c2 d5 48 b5 d2                               	vpmadd52huq zmm18,zmm5,zmm10
   8a7cd:	62 c2 f5 48 b5 e2                               	vpmadd52huq zmm20,zmm1,zmm10
   8a7d3:	62 d2 e5 48 b5 e2                               	vpmadd52huq zmm4,zmm3,zmm10
   8a7d9:	62 82 fd 40 b4 ea                               	vpmadd52luq zmm21,zmm16,zmm26
   8a7df:	62 c2 e5 48 b4 ca                               	vpmadd52luq zmm17,zmm3,zmm10
   8a7e5:	62 c2 85 48 b4 da                               	vpmadd52luq zmm19,zmm15,zmm10
   8a7eb:	62 c2 c5 48 b4 d2                               	vpmadd52luq zmm18,zmm7,zmm10
   8a7f1:	62 c2 d5 48 b4 e2                               	vpmadd52luq zmm20,zmm5,zmm10
   8a7f7:	62 e1 fd 40 d4 c2                               	vpaddq zmm16,zmm16,zmm2
   8a7fd:	62 b1 fd 40 73 d0 34                            	vpsrlq zmm16,zmm16,0x34
   8a804:	62 c2 d5 40 b5 c8                               	vpmadd52huq zmm17,zmm21,zmm8
   8a80a:	62 c2 d5 40 b5 d9                               	vpmadd52huq zmm19,zmm21,zmm9
   8a810:	62 e2 d5 40 b5 d0                               	vpmadd52huq zmm18,zmm21,zmm0
   8a816:	62 82 d5 40 b5 c3                               	vpmadd52huq zmm16,zmm21,zmm27
   8a81c:	62 e2 d5 40 b4 e0                               	vpmadd52luq zmm20,zmm21,zmm0
   8a822:	62 f2 d5 40 b5 e6                               	vpmadd52huq zmm4,zmm21,zmm6
   8a828:	62 e2 d5 40 b4 ce                               	vpmadd52luq zmm17,zmm21,zmm6
   8a82e:	62 c2 d5 40 b4 d8                               	vpmadd52luq zmm19,zmm21,zmm8
   8a834:	62 c2 d5 40 b4 d1                               	vpmadd52luq zmm18,zmm21,zmm9
   8a83a:	62 a1 dd 40 d4 e0                               	vpaddq zmm20,zmm20,zmm16
   8a840:	62 d2 85 48 b5 e3                               	vpmadd52huq zmm4,zmm15,zmm11
   8a846:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   8a84c:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   8a852:	62 c2 e5 48 b5 c3                               	vpmadd52huq zmm16,zmm3,zmm11
   8a858:	62 c2 f5 48 b4 e3                               	vpmadd52luq zmm20,zmm1,zmm11
   8a85e:	62 c2 c5 48 b5 cb                               	vpmadd52huq zmm17,zmm7,zmm11
   8a864:	62 c2 d5 48 b5 db                               	vpmadd52huq zmm19,zmm5,zmm11
   8a86a:	62 c2 f5 48 b5 d3                               	vpmadd52huq zmm18,zmm1,zmm11
   8a870:	62 d2 e5 48 b4 e3                               	vpmadd52luq zmm4,zmm3,zmm11
   8a876:	62 82 dd 40 b4 ea                               	vpmadd52luq zmm21,zmm20,zmm26
   8a87c:	62 e1 dd 40 d4 e2                               	vpaddq zmm20,zmm20,zmm2
   8a882:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   8a889:	62 c2 85 48 b4 cb                               	vpmadd52luq zmm17,zmm15,zmm11
   8a88f:	62 c2 c5 48 b4 db                               	vpmadd52luq zmm19,zmm7,zmm11
   8a895:	62 c2 d5 48 b4 d3                               	vpmadd52luq zmm18,zmm5,zmm11
   8a89b:	62 d2 d5 40 b5 e0                               	vpmadd52huq zmm4,zmm21,zmm8
   8a8a1:	62 82 d5 40 b5 e3                               	vpmadd52huq zmm20,zmm21,zmm27
   8a8a7:	62 e2 d5 40 b5 c6                               	vpmadd52huq zmm16,zmm21,zmm6
   8a8ad:	62 c2 d5 40 b5 c9                               	vpmadd52huq zmm17,zmm21,zmm9
   8a8b3:	62 e2 d5 40 b5 d8                               	vpmadd52huq zmm19,zmm21,zmm0
   8a8b9:	62 e2 d5 40 b4 d0                               	vpmadd52luq zmm18,zmm21,zmm0
   8a8bf:	62 f2 d5 40 b4 e6                               	vpmadd52luq zmm4,zmm21,zmm6
   8a8c5:	62 c2 85 48 b5 c5                               	vpmadd52huq zmm16,zmm15,zmm13
   8a8cb:	62 c2 d5 40 b4 c8                               	vpmadd52luq zmm17,zmm21,zmm8
   8a8d1:	62 c2 d5 40 b4 d9                               	vpmadd52luq zmm19,zmm21,zmm9
   8a8d7:	62 a1 ed 40 d4 e4                               	vpaddq zmm20,zmm18,zmm20
   8a8dd:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   8a8e3:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   8a8e9:	62 c2 e5 48 b5 d5                               	vpmadd52huq zmm18,zmm3,zmm13
   8a8ef:	62 c2 f5 48 b4 e5                               	vpmadd52luq zmm20,zmm1,zmm13
   8a8f5:	62 d2 c5 48 b5 e5                               	vpmadd52huq zmm4,zmm7,zmm13
   8a8fb:	62 c2 e5 48 b4 c5                               	vpmadd52luq zmm16,zmm3,zmm13
   8a901:	62 c2 d5 48 b5 cd                               	vpmadd52huq zmm17,zmm5,zmm13
   8a907:	62 c2 f5 48 b5 dd                               	vpmadd52huq zmm19,zmm1,zmm13
   8a90d:	62 82 dd 40 b4 ea                               	vpmadd52luq zmm21,zmm20,zmm26
   8a913:	62 d2 85 48 b4 e5                               	vpmadd52luq zmm4,zmm15,zmm13
   8a919:	62 e1 dd 40 d4 e2                               	vpaddq zmm20,zmm20,zmm2
   8a91f:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   8a926:	62 c2 c5 48 b4 cd                               	vpmadd52luq zmm17,zmm7,zmm13
   8a92c:	62 c2 d5 48 b4 dd                               	vpmadd52luq zmm19,zmm5,zmm13
   8a932:	62 c2 d5 40 b5 c0                               	vpmadd52huq zmm16,zmm21,zmm8
   8a938:	62 d2 d5 40 b5 e1                               	vpmadd52huq zmm4,zmm21,zmm9
   8a93e:	62 82 d5 40 b5 e3                               	vpmadd52huq zmm20,zmm21,zmm27
   8a944:	62 e2 d5 40 b5 d6                               	vpmadd52huq zmm18,zmm21,zmm6
   8a94a:	62 e2 d5 40 b5 c8                               	vpmadd52huq zmm17,zmm21,zmm0
   8a950:	62 e2 d5 40 b4 d8                               	vpmadd52luq zmm19,zmm21,zmm0
   8a956:	62 e2 d5 40 b4 c6                               	vpmadd52luq zmm16,zmm21,zmm6
   8a95c:	62 d2 d5 40 b4 e0                               	vpmadd52luq zmm4,zmm21,zmm8
   8a962:	62 c2 85 48 b5 d6                               	vpmadd52huq zmm18,zmm15,zmm14
   8a968:	62 c2 d5 40 b4 c9                               	vpmadd52luq zmm17,zmm21,zmm9
   8a96e:	62 a1 e5 40 d4 e4                               	vpaddq zmm20,zmm19,zmm20
   8a974:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   8a97a:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   8a980:	62 c2 e5 48 b5 de                               	vpmadd52huq zmm19,zmm3,zmm14
   8a986:	62 c2 f5 48 b4 e6                               	vpmadd52luq zmm20,zmm1,zmm14
   8a98c:	62 c2 c5 48 b5 c6                               	vpmadd52huq zmm16,zmm7,zmm14
   8a992:	62 d2 d5 48 b5 e6                               	vpmadd52huq zmm4,zmm5,zmm14
   8a998:	62 c2 e5 48 b4 d6                               	vpmadd52luq zmm18,zmm3,zmm14
   8a99e:	62 c2 f5 48 b5 ce                               	vpmadd52huq zmm17,zmm1,zmm14
   8a9a4:	62 82 dd 40 b4 ea                               	vpmadd52luq zmm21,zmm20,zmm26
   8a9aa:	62 c2 85 48 b4 c6                               	vpmadd52luq zmm16,zmm15,zmm14
   8a9b0:	62 d2 c5 48 b4 e6                               	vpmadd52luq zmm4,zmm7,zmm14
   8a9b6:	62 e1 dd 40 d4 e2                               	vpaddq zmm20,zmm20,zmm2
   8a9bc:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   8a9c3:	62 c2 d5 48 b4 ce                               	vpmadd52luq zmm17,zmm5,zmm14
   8a9c9:	62 c2 d5 40 b5 d0                               	vpmadd52huq zmm18,zmm21,zmm8
   8a9cf:	62 c2 d5 40 b5 c1                               	vpmadd52huq zmm16,zmm21,zmm9
   8a9d5:	62 f2 d5 40 b5 e0                               	vpmadd52huq zmm4,zmm21,zmm0
   8a9db:	62 82 d5 40 b5 e3                               	vpmadd52huq zmm20,zmm21,zmm27
   8a9e1:	62 e2 d5 40 b5 de                               	vpmadd52huq zmm19,zmm21,zmm6
   8a9e7:	62 e2 d5 40 b4 c8                               	vpmadd52luq zmm17,zmm21,zmm0
   8a9ed:	62 e2 d5 40 b4 d6                               	vpmadd52luq zmm18,zmm21,zmm6
   8a9f3:	62 c2 d5 40 b4 c0                               	vpmadd52luq zmm16,zmm21,zmm8
   8a9f9:	62 d2 d5 40 b4 e1                               	vpmadd52luq zmm4,zmm21,zmm9
   8a9ff:	62 c2 85 48 b5 dc                               	vpmadd52huq zmm19,zmm15,zmm12
   8aa05:	62 81 fd 48 6f ea                               	vmovdqa64 zmm21,zmm26
   8aa0b:	62 a1 f5 40 d4 cc                               	vpaddq zmm17,zmm17,zmm20
   8aa11:	62 c2 f5 48 b4 cc                               	vpmadd52luq zmm17,zmm1,zmm12
   8aa17:	62 c2 c5 48 b5 d4                               	vpmadd52huq zmm18,zmm7,zmm12
   8aa1d:	62 c2 d5 48 b5 c4                               	vpmadd52huq zmm16,zmm5,zmm12
   8aa23:	62 d2 f5 48 b5 e4                               	vpmadd52huq zmm4,zmm1,zmm12
   8aa29:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8aa2d:	62 c2 e5 48 b4 dc                               	vpmadd52luq zmm19,zmm3,zmm12
   8aa33:	62 d2 e5 48 b5 cc                               	vpmadd52huq zmm1,zmm3,zmm12
   8aa39:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   8aa3d:	62 92 f5 40 b4 da                               	vpmadd52luq zmm3,zmm17,zmm26
   8aa43:	62 c2 85 48 b4 d4                               	vpmadd52luq zmm18,zmm15,zmm12
   8aa49:	62 c2 c5 48 b4 c4                               	vpmadd52luq zmm16,zmm7,zmm12
   8aa4f:	62 d2 d5 48 b4 e4                               	vpmadd52luq zmm4,zmm5,zmm12
   8aa55:	62 b1 f5 40 d4 fe                               	vpaddq zmm7,zmm17,zmm22
   8aa5b:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8aa60:	62 f1 c5 48 73 d7 30                            	vpsrlq zmm7,zmm7,0x30
   8aa67:	62 b1 e5 48 db ee                               	vpandq zmm5,zmm3,zmm22
   8aa6d:	62 f1 e5 48 73 f3 04                            	vpsllq zmm3,zmm3,0x4
   8aa74:	62 81 fd 48 6f f3                               	vmovdqa64 zmm22,zmm27
   8aa7a:	62 c2 d5 48 b5 d1                               	vpmadd52huq zmm18,zmm5,zmm9
   8aa80:	62 c2 d5 48 b5 d8                               	vpmadd52huq zmm19,zmm5,zmm8
   8aa86:	62 e2 d5 48 b5 c0                               	vpmadd52huq zmm16,zmm5,zmm0
   8aa8c:	62 f2 d5 48 b4 e0                               	vpmadd52luq zmm4,zmm5,zmm0
   8aa92:	62 92 e5 48 b5 fb                               	vpmadd52huq zmm7,zmm3,zmm27
   8aa98:	62 f2 d5 48 b5 ce                               	vpmadd52huq zmm1,zmm5,zmm6
   8aa9e:	62 c2 d5 48 b4 d0                               	vpmadd52luq zmm18,zmm5,zmm8
   8aaa4:	62 e2 d5 48 b4 de                               	vpmadd52luq zmm19,zmm5,zmm6
   8aaaa:	62 c2 d5 48 b4 c1                               	vpmadd52luq zmm16,zmm5,zmm9
   8aab0:	62 f1 fd 48 73 f4 04                            	vpsllq zmm0,zmm4,0x4
   8aab7:	62 f1 f5 48 73 f1 04                            	vpsllq zmm1,zmm1,0x4
   8aabe:	62 f1 e5 48 73 d4 30                            	vpsrlq zmm3,zmm4,0x30
   8aac5:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   8aaca:	62 91 fd 48 db c4                               	vpandq zmm0,zmm0,zmm28
   8aad0:	62 f1 fd 48 d4 c7                               	vpaddq zmm0,zmm0,zmm7
   8aad6:	62 b1 cd 48 73 f2 04                            	vpsllq zmm6,zmm18,0x4
   8aadd:	62 b1 c5 48 73 f3 04                            	vpsllq zmm7,zmm19,0x4
   8aae4:	62 b1 d5 48 73 d0 30                            	vpsrlq zmm5,zmm16,0x30
   8aaeb:	62 b1 bd 48 73 d2 30                            	vpsrlq zmm8,zmm18,0x30
   8aaf2:	62 b1 dd 48 73 f0 04                            	vpsllq zmm4,zmm16,0x4
   8aaf9:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   8aaff:	62 91 cd 48 db f4                               	vpandq zmm6,zmm6,zmm28
   8ab05:	62 91 c5 48 db fc                               	vpandq zmm7,zmm7,zmm28
   8ab0b:	62 91 dd 48 db e4                               	vpandq zmm4,zmm4,zmm28
   8ab11:	62 61 fd 48 db e2                               	vpandq zmm28,zmm0,zmm2
   8ab17:	62 f1 cd 48 d4 ed                               	vpaddq zmm5,zmm6,zmm5
   8ab1d:	62 d1 c5 48 d4 f0                               	vpaddq zmm6,zmm7,zmm8
   8ab23:	62 b1 c5 48 73 d3 30                            	vpsrlq zmm7,zmm19,0x30
   8ab2a:	62 12 9d 40 b5 fc                               	vpmadd52huq zmm15,zmm28,zmm28
   8ab30:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   8ab36:	62 f1 f5 48 d4 cf                               	vpaddq zmm1,zmm1,zmm7
   8ab3c:	62 f1 c5 48 73 d0 34                            	vpsrlq zmm7,zmm0,0x34
   8ab43:	62 f1 c5 48 d4 db                               	vpaddq zmm3,zmm7,zmm3
   8ab49:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   8ab4d:	62 f1 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm4
   8ab53:	62 f2 fd 48 19 64 24 1a                         	vbroadcastsd zmm4,QWORD PTR [rsp+0xd0]
   8ab5b:	62 f1 fd 48 73 d3 34                            	vpsrlq zmm0,zmm3,0x34
   8ab62:	62 61 e5 48 db da                               	vpandq zmm27,zmm3,zmm2
   8ab68:	62 f1 fd 48 d4 c5                               	vpaddq zmm0,zmm0,zmm5
   8ab6e:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   8ab72:	62 92 a5 40 b5 ec                               	vpmadd52huq zmm5,zmm27,zmm28
   8ab78:	62 12 a5 40 b4 fc                               	vpmadd52luq zmm15,zmm27,zmm28
   8ab7e:	62 f1 e5 48 73 d0 34                            	vpsrlq zmm3,zmm0,0x34
   8ab85:	62 61 fd 48 db d2                               	vpandq zmm26,zmm0,zmm2
   8ab8b:	62 f1 e5 48 d4 de                               	vpaddq zmm3,zmm3,zmm6
   8ab91:	62 f2 fd 48 19 74 24 19                         	vbroadcastsd zmm6,QWORD PTR [rsp+0xc8]
   8ab99:	62 92 ad 40 b5 fc                               	vpmadd52huq zmm7,zmm26,zmm28
   8ab9f:	62 f1 fd 48 73 d3 34                            	vpsrlq zmm0,zmm3,0x34
   8aba6:	62 61 e5 48 db ca                               	vpandq zmm25,zmm3,zmm2
   8abac:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   8abb0:	62 61 fd 48 d4 c1                               	vpaddq zmm24,zmm0,zmm1
   8abb6:	62 b1 fd 28 6f cf                               	vmovdqa64 ymm1,ymm23
   8abbc:	62 e1 fd 48 6f 7c 31 0f                         	vmovdqa64 zmm23,ZMMWORD PTR [rcx+rsi*1+0x3c0]
   8abc4:	62 92 b5 40 b5 dc                               	vpmadd52huq zmm3,zmm25,zmm28
   8abca:	62 e1 fd 28 6f d1                               	vmovdqa64 ymm18,ymm1
   8abd0:	62 92 ad 40 b4 ec                               	vpmadd52luq zmm5,zmm26,zmm28
   8abd6:	62 12 bd 40 b5 cc                               	vpmadd52huq zmm9,zmm24,zmm28
   8abdc:	62 f1 7c 48 29 64 24 0b                         	vmovaps ZMMWORD PTR [rsp+0x2c0],zmm4
   8abe4:	62 f2 fd 48 19 64 24 1c                         	vbroadcastsd zmm4,QWORD PTR [rsp+0xe0]
   8abec:	62 92 b5 40 b4 fc                               	vpmadd52luq zmm7,zmm25,zmm28
   8abf2:	62 92 bd 40 b4 dc                               	vpmadd52luq zmm3,zmm24,zmm28
   8abf8:	62 f1 7c 48 29 74 24 0a                         	vmovaps ZMMWORD PTR [rsp+0x280],zmm6
   8ac00:	62 f2 fd 48 19 74 24 1b                         	vbroadcastsd zmm6,QWORD PTR [rsp+0xd8]
   8ac08:	62 f1 7c 48 29 64 24 17                         	vmovaps ZMMWORD PTR [rsp+0x5c0],zmm4
   8ac10:	62 f1 7c 48 28 64 31 11                         	vmovaps zmm4,ZMMWORD PTR [rcx+rsi*1+0x440]
   8ac18:	62 f1 7c 48 29 74 24 09                         	vmovaps ZMMWORD PTR [rsp+0x240],zmm6
   8ac20:	62 f1 7c 48 28 74 31 10                         	vmovaps zmm6,ZMMWORD PTR [rcx+rsi*1+0x400]
   8ac28:	62 f1 7c 48 29 64 24 0e                         	vmovaps ZMMWORD PTR [rsp+0x380],zmm4
   8ac30:	62 f1 7c 48 28 64 31 13                         	vmovaps zmm4,ZMMWORD PTR [rcx+rsi*1+0x4c0]
   8ac38:	62 f1 7c 48 29 74 24 16                         	vmovaps ZMMWORD PTR [rsp+0x580],zmm6
   8ac40:	62 f1 7c 48 28 74 31 12                         	vmovaps zmm6,ZMMWORD PTR [rcx+rsi*1+0x480]
   8ac48:	c5 fe 7f 8c 24 c0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xc0],ymm1
   8ac51:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   8ac59:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8ac5d:	62 92 9d 40 b4 cc                               	vpmadd52luq zmm1,zmm28,zmm28
   8ac63:	62 e2 fd 48 59 64 24 1b                         	vpbroadcastq zmm20,QWORD PTR [rsp+0xd8]
   8ac6b:	62 72 fd 48 59 44 24 1a                         	vpbroadcastq zmm8,QWORD PTR [rsp+0xd0]
   8ac73:	62 f1 7c 48 29 64 24 1f                         	vmovaps ZMMWORD PTR [rsp+0x7c0],zmm4
   8ac7b:	62 f2 fd 48 59 64 24 19                         	vpbroadcastq zmm4,QWORD PTR [rsp+0xc8]
   8ac83:	62 a2 f5 48 b4 c5                               	vpmadd52luq zmm16,zmm1,zmm21
   8ac89:	62 f1 f5 48 d4 ca                               	vpaddq zmm1,zmm1,zmm2
   8ac8f:	62 f1 f5 48 73 d1 34                            	vpsrlq zmm1,zmm1,0x34
   8ac96:	62 f1 7c 48 29 74 24 0c                         	vmovaps ZMMWORD PTR [rsp+0x300],zmm6
   8ac9e:	62 f2 fd 48 59 74 24 1c                         	vpbroadcastq zmm6,QWORD PTR [rsp+0xe0]
   8aca6:	62 b2 fd 40 b5 ce                               	vpmadd52huq zmm1,zmm16,zmm22
   8acac:	62 b2 fd 40 b5 dc                               	vpmadd52huq zmm3,zmm16,zmm20
   8acb2:	62 d2 fd 40 b5 f8                               	vpmadd52huq zmm7,zmm16,zmm8
   8acb8:	62 72 fd 40 b4 fc                               	vpmadd52luq zmm15,zmm16,zmm4
   8acbe:	62 f2 fd 40 b5 ec                               	vpmadd52huq zmm5,zmm16,zmm4
   8acc4:	62 b2 fd 40 b4 fc                               	vpmadd52luq zmm7,zmm16,zmm20
   8acca:	62 f2 fd 40 b4 de                               	vpmadd52luq zmm3,zmm16,zmm6
   8acd0:	62 71 85 48 d4 f9                               	vpaddq zmm15,zmm15,zmm1
   8acd6:	62 d2 fd 40 b4 e8                               	vpmadd52luq zmm5,zmm16,zmm8
   8acdc:	62 72 fd 40 b5 ce                               	vpmadd52huq zmm9,zmm16,zmm6
   8ace2:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   8ace8:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8acec:	62 92 bd 40 b5 cb                               	vpmadd52huq zmm1,zmm24,zmm27
   8acf2:	62 12 9d 40 b4 fb                               	vpmadd52luq zmm15,zmm28,zmm27
   8acf8:	62 92 a5 40 b5 fb                               	vpmadd52huq zmm7,zmm27,zmm27
   8acfe:	62 92 ad 40 b5 db                               	vpmadd52huq zmm3,zmm26,zmm27
   8ad04:	62 92 9d 40 b5 eb                               	vpmadd52huq zmm5,zmm28,zmm27
   8ad0a:	62 12 b5 40 b5 cb                               	vpmadd52huq zmm9,zmm25,zmm27
   8ad10:	62 a2 85 48 b4 c5                               	vpmadd52luq zmm16,zmm15,zmm21
   8ad16:	62 92 ad 40 b4 fb                               	vpmadd52luq zmm7,zmm26,zmm27
   8ad1c:	62 71 85 48 d4 fa                               	vpaddq zmm15,zmm15,zmm2
   8ad22:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   8ad29:	62 92 b5 40 b4 db                               	vpmadd52luq zmm3,zmm25,zmm27
   8ad2f:	62 92 a5 40 b4 eb                               	vpmadd52luq zmm5,zmm27,zmm27
   8ad35:	62 12 bd 40 b4 cb                               	vpmadd52luq zmm9,zmm24,zmm27
   8ad3b:	62 f2 fd 40 b5 fc                               	vpmadd52huq zmm7,zmm16,zmm4
   8ad41:	62 32 fd 40 b5 fe                               	vpmadd52huq zmm15,zmm16,zmm22
   8ad47:	62 f2 fd 40 b5 ce                               	vpmadd52huq zmm1,zmm16,zmm6
   8ad4d:	62 d2 fd 40 b5 d8                               	vpmadd52huq zmm3,zmm16,zmm8
   8ad53:	62 f2 fd 40 b4 ec                               	vpmadd52luq zmm5,zmm16,zmm4
   8ad59:	62 32 fd 40 b5 cc                               	vpmadd52huq zmm9,zmm16,zmm20
   8ad5f:	62 d2 fd 40 b4 f8                               	vpmadd52luq zmm7,zmm16,zmm8
   8ad65:	62 92 b5 40 b5 ca                               	vpmadd52huq zmm1,zmm25,zmm26
   8ad6b:	62 b2 fd 40 b4 dc                               	vpmadd52luq zmm3,zmm16,zmm20
   8ad71:	62 51 d5 48 d4 ff                               	vpaddq zmm15,zmm5,zmm15
   8ad77:	62 72 fd 40 b4 ce                               	vpmadd52luq zmm9,zmm16,zmm6
   8ad7d:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   8ad83:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   8ad87:	62 92 bd 40 b5 ea                               	vpmadd52huq zmm5,zmm24,zmm26
   8ad8d:	62 12 9d 40 b4 fa                               	vpmadd52luq zmm15,zmm28,zmm26
   8ad93:	62 92 9d 40 b5 fa                               	vpmadd52huq zmm7,zmm28,zmm26
   8ad99:	62 92 bd 40 b4 ca                               	vpmadd52luq zmm1,zmm24,zmm26
   8ad9f:	62 92 a5 40 b5 da                               	vpmadd52huq zmm3,zmm27,zmm26
   8ada5:	62 12 ad 40 b5 ca                               	vpmadd52huq zmm9,zmm26,zmm26
   8adab:	62 a2 85 48 b4 c5                               	vpmadd52luq zmm16,zmm15,zmm21
   8adb1:	62 92 a5 40 b4 fa                               	vpmadd52luq zmm7,zmm27,zmm26
   8adb7:	62 71 85 48 d4 fa                               	vpaddq zmm15,zmm15,zmm2
   8adbd:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   8adc4:	62 92 ad 40 b4 da                               	vpmadd52luq zmm3,zmm26,zmm26
   8adca:	62 12 b5 40 b4 ca                               	vpmadd52luq zmm9,zmm25,zmm26
   8add0:	62 32 fd 40 b5 fe                               	vpmadd52huq zmm15,zmm16,zmm22
   8add6:	62 f2 fd 40 b4 fc                               	vpmadd52luq zmm7,zmm16,zmm4
   8addc:	62 b2 fd 40 b5 cc                               	vpmadd52huq zmm1,zmm16,zmm20
   8ade2:	62 f2 fd 40 b5 ee                               	vpmadd52huq zmm5,zmm16,zmm6
   8ade8:	62 f2 fd 40 b5 dc                               	vpmadd52huq zmm3,zmm16,zmm4
   8adee:	62 52 fd 40 b5 c8                               	vpmadd52huq zmm9,zmm16,zmm8
   8adf4:	62 51 c5 48 d4 ff                               	vpaddq zmm15,zmm7,zmm15
   8adfa:	62 f2 fd 40 b4 ce                               	vpmadd52luq zmm1,zmm16,zmm6
   8ae00:	62 92 b5 40 b5 e9                               	vpmadd52huq zmm5,zmm25,zmm25
   8ae06:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   8ae0a:	62 92 bd 40 b5 f9                               	vpmadd52huq zmm7,zmm24,zmm25
   8ae10:	62 12 9d 40 b4 f9                               	vpmadd52luq zmm15,zmm28,zmm25
   8ae16:	62 d2 fd 40 b4 d8                               	vpmadd52luq zmm3,zmm16,zmm8
   8ae1c:	62 32 fd 40 b4 cc                               	vpmadd52luq zmm9,zmm16,zmm20
   8ae22:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   8ae28:	62 92 ad 40 b5 c9                               	vpmadd52huq zmm1,zmm26,zmm25
   8ae2e:	62 92 bd 40 b4 e9                               	vpmadd52luq zmm5,zmm24,zmm25
   8ae34:	62 a2 85 48 b4 c5                               	vpmadd52luq zmm16,zmm15,zmm21
   8ae3a:	62 71 85 48 d4 fa                               	vpaddq zmm15,zmm15,zmm2
   8ae40:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   8ae47:	62 92 9d 40 b5 d9                               	vpmadd52huq zmm3,zmm28,zmm25
   8ae4d:	62 12 a5 40 b5 c9                               	vpmadd52huq zmm9,zmm27,zmm25
   8ae53:	62 92 b5 40 b4 c9                               	vpmadd52luq zmm1,zmm25,zmm25
   8ae59:	62 32 fd 40 b5 fe                               	vpmadd52huq zmm15,zmm16,zmm22
   8ae5f:	62 b2 fd 40 b5 ec                               	vpmadd52huq zmm5,zmm16,zmm20
   8ae65:	62 f2 fd 40 b5 fe                               	vpmadd52huq zmm7,zmm16,zmm6
   8ae6b:	62 92 a5 40 b4 d9                               	vpmadd52luq zmm3,zmm27,zmm25
   8ae71:	62 12 ad 40 b4 c9                               	vpmadd52luq zmm9,zmm26,zmm25
   8ae77:	62 d2 fd 40 b5 c8                               	vpmadd52huq zmm1,zmm16,zmm8
   8ae7d:	62 f2 fd 40 b4 ee                               	vpmadd52luq zmm5,zmm16,zmm6
   8ae83:	62 92 b5 40 b5 f8                               	vpmadd52huq zmm7,zmm25,zmm24
   8ae89:	62 f2 fd 40 b4 dc                               	vpmadd52luq zmm3,zmm16,zmm4
   8ae8f:	62 72 fd 40 b5 cc                               	vpmadd52huq zmm9,zmm16,zmm4
   8ae95:	62 b2 fd 40 b4 cc                               	vpmadd52luq zmm1,zmm16,zmm20
   8ae9b:	62 92 ad 40 b5 e8                               	vpmadd52huq zmm5,zmm26,zmm24
   8aea1:	62 92 bd 40 b4 f8                               	vpmadd52luq zmm7,zmm24,zmm24
   8aea7:	62 d1 e5 48 d4 df                               	vpaddq zmm3,zmm3,zmm15
   8aead:	62 52 fd 40 b4 c8                               	vpmadd52luq zmm9,zmm16,zmm8
   8aeb3:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   8aeb9:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8aebe:	62 12 bd 40 b5 f8                               	vpmadd52huq zmm15,zmm24,zmm24
   8aec4:	62 92 9d 40 b4 d8                               	vpmadd52luq zmm3,zmm28,zmm24
   8aeca:	62 92 a5 40 b5 c8                               	vpmadd52huq zmm1,zmm27,zmm24
   8aed0:	62 92 b5 40 b4 e8                               	vpmadd52luq zmm5,zmm25,zmm24
   8aed6:	62 12 9d 40 b5 c8                               	vpmadd52huq zmm9,zmm28,zmm24
   8aedc:	62 a2 e5 48 b4 c5                               	vpmadd52luq zmm16,zmm3,zmm21
   8aee2:	62 e1 fd 50 db 0d 5c bd f7 ff                   	vpandq zmm17,zmm16,QWORD BCST [rip+0xfffffffffff7bd5c]        # 6c48 <GCC_except_table711+0x158>
   8aeec:	62 92 ad 40 b4 c8                               	vpmadd52luq zmm1,zmm26,zmm24
   8aef2:	62 f1 e5 58 d4 1d 4c bd f7 ff                   	vpaddq zmm3,zmm3,QWORD BCST [rip+0xfffffffffff7bd4c]        # 6c48 <GCC_except_table711+0x158>
   8aefc:	62 12 a5 40 b4 c8                               	vpmadd52luq zmm9,zmm27,zmm24
   8af02:	62 b1 fd 40 73 f0 04                            	vpsllq zmm16,zmm16,0x4
   8af09:	62 d2 f5 40 b5 e8                               	vpmadd52huq zmm5,zmm17,zmm8
   8af0f:	62 b2 f5 40 b5 fc                               	vpmadd52huq zmm7,zmm17,zmm20
   8af15:	62 f2 f5 40 b5 cc                               	vpmadd52huq zmm1,zmm17,zmm4
   8af1b:	62 72 f5 40 b5 fe                               	vpmadd52huq zmm15,zmm17,zmm6
   8af21:	62 72 f5 40 b4 cc                               	vpmadd52luq zmm9,zmm17,zmm4
   8af27:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   8af2e:	62 b2 fd 40 b5 de                               	vpmadd52huq zmm3,zmm16,zmm22
   8af34:	62 b2 f5 40 b4 ec                               	vpmadd52luq zmm5,zmm17,zmm20
   8af3a:	62 f2 f5 40 b4 fe                               	vpmadd52luq zmm7,zmm17,zmm6
   8af40:	62 d2 f5 40 b4 c8                               	vpmadd52luq zmm1,zmm17,zmm8
   8af46:	62 d1 fd 48 73 f1 04                            	vpsllq zmm0,zmm9,0x4
   8af4d:	62 f1 fd 58 db 05 a9 bd f7 ff                   	vpandq zmm0,zmm0,QWORD BCST [rip+0xfffffffffff7bda9]        # 6d00 <GCC_except_table711+0x210>
   8af57:	c5 7c 28 05 c1 c9 f7 ff                         	vmovaps ymm8,YMMWORD PTR [rip+0xfffffffffff7c9c1]        # 7920 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x980>
   8af5f:	62 f1 cd 48 73 f5 04                            	vpsllq zmm6,zmm5,0x4
   8af66:	62 f1 cd 58 db 35 90 bd f7 ff                   	vpandq zmm6,zmm6,QWORD BCST [rip+0xfffffffffff7bd90]        # 6d00 <GCC_except_table711+0x210>
   8af70:	62 f1 dd 48 73 f1 04                            	vpsllq zmm4,zmm1,0x4
   8af77:	62 f1 f5 48 73 d1 30                            	vpsrlq zmm1,zmm1,0x30
   8af7e:	62 f1 fd 40 73 f7 04                            	vpsllq zmm16,zmm7,0x4
   8af85:	62 f1 dd 58 db 25 71 bd f7 ff                   	vpandq zmm4,zmm4,QWORD BCST [rip+0xfffffffffff7bd71]        # 6d00 <GCC_except_table711+0x210>
   8af8f:	62 f1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm5,0x30
   8af96:	62 f1 fd 48 d4 c3                               	vpaddq zmm0,zmm0,zmm3
   8af9c:	62 d1 e5 48 73 d1 30                            	vpsrlq zmm3,zmm9,0x30
   8afa3:	62 f1 b5 48 73 d7 30                            	vpsrlq zmm9,zmm7,0x30
   8afaa:	62 d1 c5 48 73 f7 04                            	vpsllq zmm7,zmm15,0x4
   8afb1:	c5 7c 11 84 24 c0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xc0],ymm8
   8afba:	48 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],rdx
   8afc2:	62 72 fd 48 59 3d cc bc f7 ff                   	vpbroadcastq zmm15,QWORD PTR [rip+0xfffffffffff7bccc]        # 6c98 <GCC_except_table711+0x1a8>
   8afcc:	62 f1 cd 48 d4 c9                               	vpaddq zmm1,zmm6,zmm1
   8afd2:	62 f1 fd 50 db 35 24 bd f7 ff                   	vpandq zmm6,zmm16,QWORD BCST [rip+0xfffffffffff7bd24]        # 6d00 <GCC_except_table711+0x210>
   8afdc:	62 e2 fd 48 59 05 42 bd f7 ff                   	vpbroadcastq zmm16,QWORD PTR [rip+0xfffffffffff7bd42]        # 6d28 <GCC_except_table711+0x238>
   8afe6:	62 f1 cd 48 d4 ed                               	vpaddq zmm5,zmm6,zmm5
   8afec:	62 d1 c5 48 d4 f1                               	vpaddq zmm6,zmm7,zmm9
   8aff2:	62 f1 c5 48 73 d0 34                            	vpsrlq zmm7,zmm0,0x34
   8aff9:	62 f1 fd 48 db c2                               	vpandq zmm0,zmm0,zmm2
   8afff:	62 f1 fd 48 fb 44 31 0a                         	vpsubq zmm0,zmm0,ZMMWORD PTR [rcx+rsi*1+0x280]
   8b007:	62 f1 c5 48 d4 db                               	vpaddq zmm3,zmm7,zmm3
   8b00d:	62 f1 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm4
   8b013:	62 f1 dd 48 73 d3 34                            	vpsrlq zmm4,zmm3,0x34
   8b01a:	62 f1 e5 48 db da                               	vpandq zmm3,zmm3,zmm2
   8b020:	62 f1 e5 48 fb 5c 31 0b                         	vpsubq zmm3,zmm3,ZMMWORD PTR [rcx+rsi*1+0x2c0]
   8b028:	62 f1 dd 48 d4 c9                               	vpaddq zmm1,zmm4,zmm1
   8b02e:	62 f1 dd 48 73 d1 34                            	vpsrlq zmm4,zmm1,0x34
   8b035:	62 f1 f5 48 db ca                               	vpandq zmm1,zmm1,zmm2
   8b03b:	62 f1 f5 48 fb 4c 31 0c                         	vpsubq zmm1,zmm1,ZMMWORD PTR [rcx+rsi*1+0x300]
   8b043:	62 f1 dd 48 d4 e5                               	vpaddq zmm4,zmm4,zmm5
   8b049:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   8b050:	62 f1 dd 48 db e2                               	vpandq zmm4,zmm4,zmm2
   8b056:	62 f1 dd 48 fb 64 31 0d                         	vpsubq zmm4,zmm4,ZMMWORD PTR [rcx+rsi*1+0x340]
   8b05e:	62 f1 d5 48 d4 ee                               	vpaddq zmm5,zmm5,zmm6
   8b064:	62 f1 d5 48 fb 6c 31 0e                         	vpsubq zmm5,zmm5,ZMMWORD PTR [rcx+rsi*1+0x380]
   8b06c:	62 f1 fd 48 db fa                               	vpandq zmm7,zmm0,zmm2
   8b072:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   8b079:	62 f2 fd 48 59 74 24 1c                         	vpbroadcastq zmm6,QWORD PTR [rsp+0xe0]
   8b081:	62 f1 e5 48 d4 c0                               	vpaddq zmm0,zmm3,zmm0
   8b087:	62 f1 fd 48 db da                               	vpandq zmm3,zmm0,zmm2
   8b08d:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   8b094:	62 f1 f5 48 d4 c0                               	vpaddq zmm0,zmm1,zmm0
   8b09a:	62 f1 fd 48 db ca                               	vpandq zmm1,zmm0,zmm2
   8b0a0:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   8b0a7:	62 e1 f5 58 d4 4c 24 1a                         	vpaddq zmm17,zmm1,QWORD BCST [rsp+0xd0]
   8b0af:	62 f1 dd 48 d4 c0                               	vpaddq zmm0,zmm4,zmm0
   8b0b5:	62 f1 fd 48 db e2                               	vpandq zmm4,zmm0,zmm2
   8b0bb:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   8b0c2:	62 71 dd 58 d4 4c 24 1b                         	vpaddq zmm9,zmm4,QWORD BCST [rsp+0xd8]
   8b0ca:	62 f1 d5 48 d4 c0                               	vpaddq zmm0,zmm5,zmm0
   8b0d0:	62 b1 c5 48 d4 e8                               	vpaddq zmm5,zmm7,zmm16
   8b0d6:	62 d3 fd 48 1e cf 01                            	vpcmpltuq k1,zmm0,zmm15
   8b0dd:	62 f1 fd 49 6f ef                               	vmovdqa64 zmm5{k1},zmm7
   8b0e3:	62 f1 e5 58 d4 7c 24 19                         	vpaddq zmm7,zmm3,QWORD BCST [rsp+0xc8]
   8b0eb:	62 61 d5 48 db ea                               	vpandq zmm29,zmm5,zmm2
   8b0f1:	c5 7c 11 84 24 c0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xc0],ymm8
   8b0fa:	48 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],rdx
   8b102:	62 d1 fd 49 6f f7                               	vmovdqa64 zmm6{k1},zmm15
   8b108:	62 f1 cd 48 d4 c0                               	vpaddq zmm0,zmm6,zmm0
   8b10e:	62 71 fd 48 6f 44 31 01                         	vmovdqa64 zmm8,ZMMWORD PTR [rcx+rsi*1+0x40]
   8b116:	62 e1 fd 49 6f c9                               	vmovdqa64 zmm17{k1},zmm1
   8b11c:	62 71 fd 49 6f cc                               	vmovdqa64 zmm9{k1},zmm4
   8b122:	62 f1 dd 48 73 d5 34                            	vpsrlq zmm4,zmm5,0x34
   8b129:	62 f1 fd 49 6f fb                               	vmovdqa64 zmm7{k1},zmm3
   8b12f:	62 f1 dd 48 d4 e7                               	vpaddq zmm4,zmm4,zmm7
   8b135:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   8b13c:	62 61 dd 48 db fa                               	vpandq zmm31,zmm4,zmm2
   8b142:	62 b1 d5 48 d4 d9                               	vpaddq zmm3,zmm5,zmm17
   8b148:	62 f1 fd 48 6f 6c 31 03                         	vmovdqa64 zmm5,ZMMWORD PTR [rcx+rsi*1+0xc0]
   8b150:	62 f1 dd 48 73 d3 34                            	vpsrlq zmm4,zmm3,0x34
   8b157:	62 d1 dd 48 d4 c9                               	vpaddq zmm1,zmm4,zmm9
   8b15d:	62 71 e5 48 db ca                               	vpandq zmm9,zmm3,zmm2
   8b163:	62 f1 fd 48 6f 64 31 02                         	vmovdqa64 zmm4,ZMMWORD PTR [rcx+rsi*1+0x80]
   8b16b:	62 f1 e5 48 73 d1 34                            	vpsrlq zmm3,zmm1,0x34
   8b172:	62 f1 f5 48 db f2                               	vpandq zmm6,zmm1,zmm2
   8b178:	62 f1 fd 48 6f 0c 31                            	vmovdqa64 zmm1,ZMMWORD PTR [rcx+rsi*1]
   8b17f:	62 61 e5 48 d4 f0                               	vpaddq zmm30,zmm3,zmm0
   8b185:	62 91 bd 48 fb df                               	vpsubq zmm3,zmm8,zmm31
   8b18b:	62 71 fd 48 6f 44 31 04                         	vmovdqa64 zmm8,ZMMWORD PTR [rcx+rsi*1+0x100]
   8b193:	62 f2 fd 48 59 44 24 1c                         	vpbroadcastq zmm0,QWORD PTR [rsp+0xe0]
   8b19b:	62 e1 8d 40 db ca                               	vpandq zmm17,zmm30,zmm2
   8b1a1:	62 e1 fd 48 7f 4c 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm17
   8b1a9:	62 f1 d5 48 fb ee                               	vpsubq zmm5,zmm5,zmm6
   8b1af:	62 d1 dd 48 fb e1                               	vpsubq zmm4,zmm4,zmm9
   8b1b5:	62 91 f5 48 fb cd                               	vpsubq zmm1,zmm1,zmm29
   8b1bb:	62 f1 f5 48 db fa                               	vpandq zmm7,zmm1,zmm2
   8b1c1:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   8b1c8:	62 31 bd 48 fb c1                               	vpsubq zmm8,zmm8,zmm17
   8b1ce:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   8b1d4:	62 f1 e5 48 d4 c9                               	vpaddq zmm1,zmm3,zmm1
   8b1da:	62 f1 f5 48 db da                               	vpandq zmm3,zmm1,zmm2
   8b1e0:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   8b1e7:	62 f1 dd 48 d4 c9                               	vpaddq zmm1,zmm4,zmm1
   8b1ed:	62 f1 f5 48 db e2                               	vpandq zmm4,zmm1,zmm2
   8b1f3:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   8b1fa:	62 f1 d5 48 d4 c9                               	vpaddq zmm1,zmm5,zmm1
   8b200:	62 f1 f5 48 db ea                               	vpandq zmm5,zmm1,zmm2
   8b206:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   8b20d:	62 f1 bd 48 d4 c9                               	vpaddq zmm1,zmm8,zmm1
   8b213:	62 31 c5 48 d4 c0                               	vpaddq zmm8,zmm7,zmm16
   8b219:	62 e1 dd 58 d4 44 24 1a                         	vpaddq zmm16,zmm4,QWORD BCST [rsp+0xd0]
   8b221:	62 d3 f5 48 1e cf 01                            	vpcmpltuq k1,zmm1,zmm15
   8b228:	62 71 fd 49 6f c7                               	vmovdqa64 zmm8{k1},zmm7
   8b22e:	62 f1 e5 58 d4 7c 24 19                         	vpaddq zmm7,zmm3,QWORD BCST [rsp+0xc8]
   8b236:	62 d1 fd 49 6f c7                               	vmovdqa64 zmm0{k1},zmm15
   8b23c:	62 f1 fd 48 d4 c1                               	vpaddq zmm0,zmm0,zmm1
   8b242:	62 d1 f5 48 73 d0 34                            	vpsrlq zmm1,zmm8,0x34
   8b249:	62 e1 fd 49 6f c4                               	vmovdqa64 zmm16{k1},zmm4
   8b24f:	62 f1 d5 58 d4 64 24 1b                         	vpaddq zmm4,zmm5,QWORD BCST [rsp+0xd8]
   8b257:	62 e1 fe 28 7f 54 24 06                         	vmovdqu64 YMMWORD PTR [rsp+0xc0],ymm18
   8b25f:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   8b267:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   8b26d:	62 f1 fd 49 6f fb                               	vmovdqa64 zmm7{k1},zmm3
   8b273:	62 71 f5 48 d4 ff                               	vpaddq zmm15,zmm1,zmm7
   8b279:	62 f1 bd 48 db ca                               	vpandq zmm1,zmm8,zmm2
   8b27f:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   8b283:	62 e2 a5 40 b5 d1                               	vpmadd52huq zmm18,zmm27,zmm1
   8b289:	62 e2 ad 40 b5 c9                               	vpmadd52huq zmm17,zmm26,zmm1
   8b28f:	62 f2 b5 40 b5 f9                               	vpmadd52huq zmm7,zmm25,zmm1
   8b295:	62 e2 ad 40 b4 d1                               	vpmadd52luq zmm18,zmm26,zmm1
   8b29b:	62 e2 b5 40 b4 c9                               	vpmadd52luq zmm17,zmm25,zmm1
   8b2a1:	62 f2 bd 40 b4 f9                               	vpmadd52luq zmm7,zmm24,zmm1
   8b2a7:	62 f1 fd 49 6f e5                               	vmovdqa64 zmm4{k1},zmm5
   8b2ad:	62 d1 d5 48 73 d7 34                            	vpsrlq zmm5,zmm15,0x34
   8b2b4:	62 a1 d5 48 d4 c0                               	vpaddq zmm16,zmm5,zmm16
   8b2ba:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   8b2be:	62 f2 9d 40 b5 e9                               	vpmadd52huq zmm5,zmm28,zmm1
   8b2c4:	62 b1 e5 48 73 d0 34                            	vpsrlq zmm3,zmm16,0x34
   8b2cb:	62 71 e5 48 d4 c4                               	vpaddq zmm8,zmm3,zmm4
   8b2d1:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   8b2d5:	62 f2 bd 40 b5 e1                               	vpmadd52huq zmm4,zmm24,zmm1
   8b2db:	62 d1 e5 48 73 d0 34                            	vpsrlq zmm3,zmm8,0x34
   8b2e2:	62 f1 e5 48 d4 c0                               	vpaddq zmm0,zmm3,zmm0
   8b2e8:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   8b2ec:	62 f2 9d 40 b4 d9                               	vpmadd52luq zmm3,zmm28,zmm1
   8b2f2:	62 f2 a5 40 b4 e9                               	vpmadd52luq zmm5,zmm27,zmm1
   8b2f8:	62 f1 fd 48 7f 44 24 0f                         	vmovdqa64 ZMMWORD PTR [rsp+0x3c0],zmm0
   8b300:	62 f2 fd 48 59 44 24 19                         	vpbroadcastq zmm0,QWORD PTR [rsp+0xc8]
   8b308:	62 a2 e5 48 b4 dd                               	vpmadd52luq zmm19,zmm3,zmm21
   8b30e:	62 f1 e5 48 d4 ca                               	vpaddq zmm1,zmm3,zmm2
   8b314:	62 f2 fd 48 59 5c 24 1c                         	vpbroadcastq zmm3,QWORD PTR [rsp+0xe0]
   8b31c:	62 f1 f5 48 73 d1 34                            	vpsrlq zmm1,zmm1,0x34
   8b323:	62 b2 e5 40 b5 ce                               	vpmadd52huq zmm1,zmm19,zmm22
   8b329:	62 f2 e5 40 b4 e8                               	vpmadd52luq zmm5,zmm19,zmm0
   8b32f:	62 e2 e5 40 b5 d0                               	vpmadd52huq zmm18,zmm19,zmm0
   8b335:	62 f2 e5 40 b5 e3                               	vpmadd52huq zmm4,zmm19,zmm3
   8b33b:	62 e1 d5 48 d4 e1                               	vpaddq zmm20,zmm5,zmm1
   8b341:	62 f2 fd 48 59 6c 24 1a                         	vpbroadcastq zmm5,QWORD PTR [rsp+0xd0]
   8b349:	62 f2 fd 48 59 4c 24 1b                         	vpbroadcastq zmm1,QWORD PTR [rsp+0xd8]
   8b351:	62 e2 e5 40 b5 cd                               	vpmadd52huq zmm17,zmm19,zmm5
   8b357:	62 f2 e5 40 b5 f9                               	vpmadd52huq zmm7,zmm19,zmm1
   8b35d:	62 e2 e5 40 b4 d5                               	vpmadd52luq zmm18,zmm19,zmm5
   8b363:	62 e2 e5 40 b4 c9                               	vpmadd52luq zmm17,zmm19,zmm1
   8b369:	62 f2 e5 40 b4 fb                               	vpmadd52luq zmm7,zmm19,zmm3
   8b36f:	62 e1 85 48 db da                               	vpandq zmm19,zmm15,zmm2
   8b375:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8b37a:	62 a2 9d 40 b5 d3                               	vpmadd52huq zmm18,zmm28,zmm19
   8b380:	62 b2 b5 40 b5 e3                               	vpmadd52huq zmm4,zmm25,zmm19
   8b386:	62 a2 9d 40 b4 e3                               	vpmadd52luq zmm20,zmm28,zmm19
   8b38c:	62 32 bd 40 b5 fb                               	vpmadd52huq zmm15,zmm24,zmm19
   8b392:	62 a2 a5 40 b5 cb                               	vpmadd52huq zmm17,zmm27,zmm19
   8b398:	62 b2 ad 40 b5 fb                               	vpmadd52huq zmm7,zmm26,zmm19
   8b39e:	62 a2 a5 40 b4 d3                               	vpmadd52luq zmm18,zmm27,zmm19
   8b3a4:	62 b2 bd 40 b4 e3                               	vpmadd52luq zmm4,zmm24,zmm19
   8b3aa:	62 a2 ad 40 b4 cb                               	vpmadd52luq zmm17,zmm26,zmm19
   8b3b0:	62 b2 b5 40 b4 fb                               	vpmadd52luq zmm7,zmm25,zmm19
   8b3b6:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   8b3bc:	62 a2 dd 40 b4 dd                               	vpmadd52luq zmm19,zmm20,zmm21
   8b3c2:	62 e1 dd 40 d4 e2                               	vpaddq zmm20,zmm20,zmm2
   8b3c8:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   8b3cf:	62 e2 e5 40 b5 c8                               	vpmadd52huq zmm17,zmm19,zmm0
   8b3d5:	62 f2 e5 40 b5 fd                               	vpmadd52huq zmm7,zmm19,zmm5
   8b3db:	62 f2 e5 40 b5 e1                               	vpmadd52huq zmm4,zmm19,zmm1
   8b3e1:	62 a2 e5 40 b5 e6                               	vpmadd52huq zmm20,zmm19,zmm22
   8b3e7:	62 e2 e5 40 b4 d0                               	vpmadd52luq zmm18,zmm19,zmm0
   8b3ed:	62 72 e5 40 b5 fb                               	vpmadd52huq zmm15,zmm19,zmm3
   8b3f3:	62 e2 e5 40 b4 cd                               	vpmadd52luq zmm17,zmm19,zmm5
   8b3f9:	62 f2 e5 40 b4 f9                               	vpmadd52luq zmm7,zmm19,zmm1
   8b3ff:	62 f2 e5 40 b4 e3                               	vpmadd52luq zmm4,zmm19,zmm3
   8b405:	62 e1 fd 40 db da                               	vpandq zmm19,zmm16,zmm2
   8b40b:	62 a1 ed 40 d4 d4                               	vpaddq zmm18,zmm18,zmm20
   8b411:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   8b417:	62 32 b5 40 b5 fb                               	vpmadd52huq zmm15,zmm25,zmm19
   8b41d:	62 a2 9d 40 b4 d3                               	vpmadd52luq zmm18,zmm28,zmm19
   8b423:	62 a2 bd 40 b5 c3                               	vpmadd52huq zmm16,zmm24,zmm19
   8b429:	62 a2 9d 40 b5 cb                               	vpmadd52huq zmm17,zmm28,zmm19
   8b42f:	62 b2 a5 40 b5 fb                               	vpmadd52huq zmm7,zmm27,zmm19
   8b435:	62 b2 ad 40 b5 e3                               	vpmadd52huq zmm4,zmm26,zmm19
   8b43b:	62 32 bd 40 b4 fb                               	vpmadd52luq zmm15,zmm24,zmm19
   8b441:	62 a2 a5 40 b4 cb                               	vpmadd52luq zmm17,zmm27,zmm19
   8b447:	62 b2 ad 40 b4 fb                               	vpmadd52luq zmm7,zmm26,zmm19
   8b44d:	62 b2 b5 40 b4 e3                               	vpmadd52luq zmm4,zmm25,zmm19
   8b453:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   8b459:	62 a2 ed 40 b4 dd                               	vpmadd52luq zmm19,zmm18,zmm21
   8b45f:	62 e1 ed 40 d4 d2                               	vpaddq zmm18,zmm18,zmm2
   8b465:	62 b1 ed 40 73 d2 34                            	vpsrlq zmm18,zmm18,0x34
   8b46c:	62 f2 e5 40 b5 f8                               	vpmadd52huq zmm7,zmm19,zmm0
   8b472:	62 f2 e5 40 b5 e5                               	vpmadd52huq zmm4,zmm19,zmm5
   8b478:	62 72 e5 40 b5 f9                               	vpmadd52huq zmm15,zmm19,zmm1
   8b47e:	62 a2 e5 40 b5 d6                               	vpmadd52huq zmm18,zmm19,zmm22
   8b484:	62 e2 e5 40 b4 c8                               	vpmadd52luq zmm17,zmm19,zmm0
   8b48a:	62 e2 e5 40 b5 c3                               	vpmadd52huq zmm16,zmm19,zmm3
   8b490:	62 f2 e5 40 b4 fd                               	vpmadd52luq zmm7,zmm19,zmm5
   8b496:	62 f2 e5 40 b4 e1                               	vpmadd52luq zmm4,zmm19,zmm1
   8b49c:	62 72 e5 40 b4 fb                               	vpmadd52luq zmm15,zmm19,zmm3
   8b4a2:	62 a1 f5 40 d4 ca                               	vpaddq zmm17,zmm17,zmm18
   8b4a8:	62 e1 bd 48 db d2                               	vpandq zmm18,zmm8,zmm2
   8b4ae:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   8b4b3:	62 a2 b5 40 b5 c2                               	vpmadd52huq zmm16,zmm25,zmm18
   8b4b9:	62 a2 9d 40 b4 ca                               	vpmadd52luq zmm17,zmm28,zmm18
   8b4bf:	62 32 bd 40 b5 c2                               	vpmadd52huq zmm8,zmm24,zmm18
   8b4c5:	62 b2 9d 40 b5 fa                               	vpmadd52huq zmm7,zmm28,zmm18
   8b4cb:	62 b2 a5 40 b5 e2                               	vpmadd52huq zmm4,zmm27,zmm18
   8b4d1:	62 32 ad 40 b5 fa                               	vpmadd52huq zmm15,zmm26,zmm18
   8b4d7:	62 a2 bd 40 b4 c2                               	vpmadd52luq zmm16,zmm24,zmm18
   8b4dd:	62 b2 a5 40 b4 fa                               	vpmadd52luq zmm7,zmm27,zmm18
   8b4e3:	62 b2 ad 40 b4 e2                               	vpmadd52luq zmm4,zmm26,zmm18
   8b4e9:	62 32 b5 40 b4 fa                               	vpmadd52luq zmm15,zmm25,zmm18
   8b4ef:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   8b4f5:	62 a2 f5 40 b4 d5                               	vpmadd52luq zmm18,zmm17,zmm21
   8b4fb:	62 e1 f5 40 d4 ca                               	vpaddq zmm17,zmm17,zmm2
   8b501:	62 b1 f5 40 73 d1 34                            	vpsrlq zmm17,zmm17,0x34
   8b508:	62 a2 ed 40 b5 ce                               	vpmadd52huq zmm17,zmm18,zmm22
   8b50e:	62 f2 ed 40 b4 f8                               	vpmadd52luq zmm7,zmm18,zmm0
   8b514:	62 f2 ed 40 b5 e0                               	vpmadd52huq zmm4,zmm18,zmm0
   8b51a:	62 72 ed 40 b5 fd                               	vpmadd52huq zmm15,zmm18,zmm5
   8b520:	62 e2 ed 40 b5 c1                               	vpmadd52huq zmm16,zmm18,zmm1
   8b526:	62 72 ed 40 b5 c3                               	vpmadd52huq zmm8,zmm18,zmm3
   8b52c:	62 b1 c5 48 d4 f9                               	vpaddq zmm7,zmm7,zmm17
   8b532:	62 e1 ed 48 db 4c 24 0f                         	vpandq zmm17,zmm2,ZMMWORD PTR [rsp+0x3c0]
   8b53a:	62 f2 ed 40 b4 e5                               	vpmadd52luq zmm4,zmm18,zmm5
   8b540:	62 72 ed 40 b4 f9                               	vpmadd52luq zmm15,zmm18,zmm1
   8b546:	62 e2 ed 40 b4 c3                               	vpmadd52luq zmm16,zmm18,zmm3
   8b54c:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   8b552:	62 b2 9d 40 b5 e1                               	vpmadd52huq zmm4,zmm28,zmm17
   8b558:	62 32 a5 40 b5 f9                               	vpmadd52huq zmm15,zmm27,zmm17
   8b55e:	62 a2 ad 40 b5 c1                               	vpmadd52huq zmm16,zmm26,zmm17
   8b564:	62 32 b5 40 b5 c1                               	vpmadd52huq zmm8,zmm25,zmm17
   8b56a:	62 b2 9d 40 b4 f9                               	vpmadd52luq zmm7,zmm28,zmm17
   8b570:	62 a2 bd 40 b5 d1                               	vpmadd52huq zmm18,zmm24,zmm17
   8b576:	62 62 fd 48 59 25 80 b7 f7 ff                   	vpbroadcastq zmm28,QWORD PTR [rip+0xfffffffffff7b780]        # 6d00 <GCC_except_table711+0x210>
   8b580:	62 b2 a5 40 b4 e1                               	vpmadd52luq zmm4,zmm27,zmm17
   8b586:	62 21 fd 48 6f de                               	vmovdqa64 zmm27,zmm22
   8b58c:	62 e2 fd 48 59 35 b2 b6 f7 ff                   	vpbroadcastq zmm22,QWORD PTR [rip+0xfffffffffff7b6b2]        # 6c48 <GCC_except_table711+0x158>
   8b596:	62 32 ad 40 b4 f9                               	vpmadd52luq zmm15,zmm26,zmm17
   8b59c:	62 a2 b5 40 b4 c1                               	vpmadd52luq zmm16,zmm25,zmm17
   8b5a2:	62 32 bd 40 b4 c1                               	vpmadd52luq zmm8,zmm24,zmm17
   8b5a8:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   8b5ae:	62 a2 c5 48 b4 cd                               	vpmadd52luq zmm17,zmm7,zmm21
   8b5b4:	62 a1 f5 40 db de                               	vpandq zmm19,zmm17,zmm22
   8b5ba:	62 b1 c5 48 d4 fe                               	vpaddq zmm7,zmm7,zmm22
   8b5c0:	62 b1 f5 40 73 f1 04                            	vpsllq zmm17,zmm17,0x4
   8b5c7:	62 e2 e5 40 b5 c5                               	vpmadd52huq zmm16,zmm19,zmm5
   8b5cd:	62 72 e5 40 b5 c1                               	vpmadd52huq zmm8,zmm19,zmm1
   8b5d3:	62 72 e5 40 b5 f8                               	vpmadd52huq zmm15,zmm19,zmm0
   8b5d9:	62 f2 e5 40 b4 e0                               	vpmadd52luq zmm4,zmm19,zmm0
   8b5df:	62 f1 c5 48 73 d7 30                            	vpsrlq zmm7,zmm7,0x30
   8b5e6:	62 e2 e5 40 b5 d3                               	vpmadd52huq zmm18,zmm19,zmm3
   8b5ec:	62 92 f5 40 b5 fb                               	vpmadd52huq zmm7,zmm17,zmm27
   8b5f2:	62 e2 e5 40 b4 c1                               	vpmadd52luq zmm16,zmm19,zmm1
   8b5f8:	62 72 e5 40 b4 c3                               	vpmadd52luq zmm8,zmm19,zmm3
   8b5fe:	62 72 e5 40 b4 fd                               	vpmadd52luq zmm15,zmm19,zmm5
   8b604:	62 f1 fd 48 73 f4 04                            	vpsllq zmm0,zmm4,0x4
   8b60b:	62 f1 f5 48 73 d4 30                            	vpsrlq zmm1,zmm4,0x30
   8b612:	62 e1 fd 28 6f 1d c4 c1 f7 ff                   	vmovdqa64 ymm19,YMMWORD PTR [rip+0xfffffffffff7c1c4]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   8b61c:	62 91 fd 48 db c4                               	vpandq zmm0,zmm0,zmm28
   8b622:	62 f1 fd 48 d4 c7                               	vpaddq zmm0,zmm0,zmm7
   8b628:	62 d1 c5 48 73 f0 04                            	vpsllq zmm7,zmm8,0x4
   8b62f:	62 b1 d5 48 73 f0 04                            	vpsllq zmm5,zmm16,0x4
   8b636:	62 d1 e5 48 73 f7 04                            	vpsllq zmm3,zmm15,0x4
   8b63d:	62 d1 dd 48 73 d7 30                            	vpsrlq zmm4,zmm15,0x30
   8b644:	62 b1 85 48 73 d0 30                            	vpsrlq zmm15,zmm16,0x30
   8b64b:	62 d1 bd 48 73 d0 30                            	vpsrlq zmm8,zmm8,0x30
   8b652:	62 b1 fd 40 73 f2 04                            	vpsllq zmm16,zmm18,0x4
   8b659:	62 91 d5 48 db ec                               	vpandq zmm5,zmm5,zmm28
   8b65f:	62 91 c5 48 db fc                               	vpandq zmm7,zmm7,zmm28
   8b665:	62 91 e5 48 db dc                               	vpandq zmm3,zmm3,zmm28
   8b66b:	62 f1 d5 48 d4 e4                               	vpaddq zmm4,zmm5,zmm4
   8b671:	62 d1 c5 48 d4 ef                               	vpaddq zmm5,zmm7,zmm15
   8b677:	62 f1 85 48 73 d0 34                            	vpsrlq zmm15,zmm0,0x34
   8b67e:	62 b1 bd 48 d4 f8                               	vpaddq zmm7,zmm8,zmm16
   8b684:	62 f1 fd 48 db c2                               	vpandq zmm0,zmm0,zmm2
   8b68a:	62 f1 85 48 d4 c9                               	vpaddq zmm1,zmm15,zmm1
   8b690:	62 f1 f5 48 d4 cb                               	vpaddq zmm1,zmm1,zmm3
   8b696:	62 f1 e5 48 73 d1 34                            	vpsrlq zmm3,zmm1,0x34
   8b69d:	62 f1 f5 48 db ca                               	vpandq zmm1,zmm1,zmm2
   8b6a3:	62 f1 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm4
   8b6a9:	62 f1 dd 48 73 d3 34                            	vpsrlq zmm4,zmm3,0x34
   8b6b0:	62 f1 e5 48 db da                               	vpandq zmm3,zmm3,zmm2
   8b6b6:	62 f1 dd 48 d4 e5                               	vpaddq zmm4,zmm4,zmm5
   8b6bc:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   8b6c3:	62 e1 dd 48 db c2                               	vpandq zmm16,zmm4,zmm2
   8b6c9:	62 f1 d5 48 d4 ef                               	vpaddq zmm5,zmm5,zmm7
   8b6cf:	c5 fc 28 3d 49 c2 f7 ff                         	vmovaps ymm7,YMMWORD PTR [rip+0xfffffffffff7c249]        # 7920 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x980>
   8b6d7:	c5 fc 11 bc 24 c0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xc0],ymm7
   8b6e0:	48 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],rdx
   8b6e8:	62 61 fd 48 fb 44 31 05                         	vpsubq zmm24,zmm0,ZMMWORD PTR [rcx+rsi*1+0x140]
   8b6f0:	62 e1 fd 40 fb 4c 31 08                         	vpsubq zmm17,zmm16,ZMMWORD PTR [rcx+rsi*1+0x200]
   8b6f8:	62 72 fd 48 59 7c 24 19                         	vpbroadcastq zmm15,QWORD PTR [rsp+0xc8]
   8b700:	62 72 fd 48 59 44 24 1a                         	vpbroadcastq zmm8,QWORD PTR [rsp+0xd0]
   8b708:	62 f2 fd 48 59 7c 24 1b                         	vpbroadcastq zmm7,QWORD PTR [rsp+0xd8]
   8b710:	62 f2 fd 48 59 64 24 1c                         	vpbroadcastq zmm4,QWORD PTR [rsp+0xe0]
   8b718:	62 61 f5 48 fb 4c 31 06                         	vpsubq zmm25,zmm1,ZMMWORD PTR [rcx+rsi*1+0x180]
   8b720:	62 e1 e5 48 fb 54 31 07                         	vpsubq zmm18,zmm3,ZMMWORD PTR [rcx+rsi*1+0x1c0]
   8b728:	62 e1 d5 48 fb 44 31 09                         	vpsubq zmm16,zmm5,ZMMWORD PTR [rcx+rsi*1+0x240]
   8b730:	62 e1 fe 28 7f 5c 24 06                         	vmovdqu64 YMMWORD PTR [rsp+0xc0],ymm19
   8b738:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   8b740:	62 f1 fd 48 6f 44 24 10                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x400]
   8b748:	62 f1 85 50 fb 6c 24 19                         	vpsubq zmm5,zmm31,QWORD BCST [rsp+0xc8]
   8b750:	62 f1 b5 58 fb 5c 24 1a                         	vpsubq zmm3,zmm9,QWORD BCST [rsp+0xd0]
   8b758:	62 f1 cd 58 fb 4c 24 1b                         	vpsubq zmm1,zmm6,QWORD BCST [rsp+0xd8]
   8b760:	62 f1 fd 58 fb 44 24 1c                         	vpsubq zmm0,zmm0,QWORD BCST [rsp+0xe0]
   8b768:	62 e1 fe 28 7f 5c 24 06                         	vmovdqu64 YMMWORD PTR [rsp+0xc0],ymm19
   8b770:	4c 89 94 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],r10
   8b778:	4c 39 f8                                        	cmp    rax,r15
   8b77b:	0f 83 20 0a 00 00                               	jae    8c1a1 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63c1>
   8b781:	48 89 c7                                        	mov    rdi,rax
   8b784:	48 c1 e7 04                                     	shl    rdi,0x4
   8b788:	41 8b 3c 39                                     	mov    edi,DWORD PTR [r9+rdi*1]
   8b78c:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8b792:	49 39 fc                                        	cmp    r12,rdi
   8b795:	0f 86 99 09 00 00                               	jbe    8c134 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6354>
   8b79b:	62 91 dd 40 72 e0 34                            	vpsraq zmm20,zmm24,0x34
   8b7a2:	62 21 fd 48 6f d5                               	vmovdqa64 zmm26,zmm21
   8b7a8:	62 e2 fd 48 59 2d e6 b4 f7 ff                   	vpbroadcastq zmm21,QWORD PTR [rip+0xfffffffffff7b4e6]        # 6c98 <GCC_except_table711+0x1a8>
   8b7b2:	62 e1 bd 40 db da                               	vpandq zmm19,zmm24,zmm2
   8b7b8:	48 c1 e7 06                                     	shl    rdi,0x6
   8b7bc:	62 a1 b5 40 d4 e4                               	vpaddq zmm20,zmm25,zmm20
   8b7c2:	62 61 e5 50 d4 0d 5c b5 f7 ff                   	vpaddq zmm25,zmm19,QWORD BCST [rip+0xfffffffffff7b55c]        # 6d28 <GCC_except_table711+0x238>
   8b7cc:	62 61 dd 40 db c2                               	vpandq zmm24,zmm20,zmm2
   8b7d2:	62 b1 dd 40 72 e4 34                            	vpsraq zmm20,zmm20,0x34
   8b7d9:	62 a1 ed 40 d4 d4                               	vpaddq zmm18,zmm18,zmm20
   8b7df:	62 51 bd 40 d4 ff                               	vpaddq zmm15,zmm24,zmm15
   8b7e5:	62 e1 ed 40 db e2                               	vpandq zmm20,zmm18,zmm2
   8b7eb:	62 b1 ed 40 72 e2 34                            	vpsraq zmm18,zmm18,0x34
   8b7f2:	62 a1 f5 40 d4 ca                               	vpaddq zmm17,zmm17,zmm18
   8b7f8:	62 51 dd 40 d4 c0                               	vpaddq zmm8,zmm20,zmm8
   8b7fe:	62 e1 f5 40 db d2                               	vpandq zmm18,zmm17,zmm2
   8b804:	62 b1 f5 40 72 e1 34                            	vpsraq zmm17,zmm17,0x34
   8b80b:	62 a1 fd 40 d4 c1                               	vpaddq zmm16,zmm16,zmm17
   8b811:	62 f1 ed 40 d4 ff                               	vpaddq zmm7,zmm18,zmm7
   8b817:	62 b3 fd 40 1e cd 01                            	vpcmpltuq k1,zmm16,zmm21
   8b81e:	62 11 fd 49 6f f8                               	vmovdqa64 zmm15{k1},zmm24
   8b824:	62 62 fd 48 59 05 ea b4 f7 ff                   	vpbroadcastq zmm24,QWORD PTR [rip+0xfffffffffff7b4ea]        # 6d18 <GCC_except_table711+0x228>
   8b82e:	62 21 fd 49 6f cb                               	vmovdqa64 zmm25{k1},zmm19
   8b834:	62 b1 fd 49 6f fa                               	vmovdqa64 zmm7{k1},zmm18
   8b83a:	62 b1 fd 49 6f e5                               	vmovdqa64 zmm4{k1},zmm21
   8b840:	62 a1 dd 48 d4 d0                               	vpaddq zmm18,zmm4,zmm16
   8b846:	62 91 dd 48 73 d1 34                            	vpsrlq zmm4,zmm25,0x34
   8b84d:	62 31 fd 49 6f c4                               	vmovdqa64 zmm8{k1},zmm20
   8b853:	62 51 dd 48 d4 ff                               	vpaddq zmm15,zmm4,zmm15
   8b859:	62 f1 b5 40 db e2                               	vpandq zmm4,zmm25,zmm2
   8b85f:	62 d1 fd 40 73 d7 34                            	vpsrlq zmm16,zmm15,0x34
   8b866:	62 51 fd 40 d4 c0                               	vpaddq zmm8,zmm16,zmm8
   8b86c:	62 e1 85 48 db c2                               	vpandq zmm16,zmm15,zmm2
   8b872:	62 d1 85 48 73 d0 34                            	vpsrlq zmm15,zmm8,0x34
   8b879:	62 e1 bd 48 db ca                               	vpandq zmm17,zmm8,zmm2
   8b87f:	62 f1 85 48 d4 ff                               	vpaddq zmm7,zmm15,zmm7
   8b885:	62 f1 bd 48 73 d7 34                            	vpsrlq zmm8,zmm7,0x34
   8b88c:	62 31 bd 48 d4 fa                               	vpaddq zmm15,zmm8,zmm18
   8b892:	62 e1 c5 48 db d2                               	vpandq zmm18,zmm7,zmm2
   8b898:	62 81 95 40 d4 e0                               	vpaddq zmm20,zmm29,zmm24
   8b89e:	62 e1 85 48 db da                               	vpandq zmm19,zmm15,zmm2
   8b8a4:	62 01 dd 48 d4 c0                               	vpaddq zmm24,zmm4,zmm24
   8b8aa:	62 e1 e5 50 fb 5c 24 1c                         	vpsubq zmm19,zmm19,QWORD BCST [rsp+0xe0]
   8b8b2:	62 b1 bd 48 72 e4 34                            	vpsraq zmm8,zmm20,0x34
   8b8b9:	62 91 b5 40 72 e0 34                            	vpsraq zmm25,zmm24,0x34
   8b8c0:	62 d1 d5 48 d4 e8                               	vpaddq zmm5,zmm5,zmm8
   8b8c6:	62 f1 bd 48 72 e5 34                            	vpsraq zmm8,zmm5,0x34
   8b8cd:	62 d1 e5 48 d4 d8                               	vpaddq zmm3,zmm3,zmm8
   8b8d3:	62 f1 bd 48 72 e3 34                            	vpsraq zmm8,zmm3,0x34
   8b8da:	62 d1 f5 48 d4 c8                               	vpaddq zmm1,zmm1,zmm8
   8b8e0:	62 f1 bd 48 72 e1 34                            	vpsraq zmm8,zmm1,0x34
   8b8e7:	62 d1 fd 48 d4 c0                               	vpaddq zmm0,zmm0,zmm8
   8b8ed:	62 b3 fd 48 1e cd 01                            	vpcmpltuq k1,zmm0,zmm21
   8b8f4:	62 61 d5 49 db fa                               	vpandq zmm31{k1},zmm5,zmm2
   8b8fa:	62 61 dd 41 db ea                               	vpandq zmm29{k1},zmm20,zmm2
   8b900:	62 61 fd 49 6f f0                               	vmovdqa64 zmm30{k1},zmm0
   8b906:	62 71 e5 49 db ca                               	vpandq zmm9{k1},zmm3,zmm2
   8b90c:	62 f1 f5 49 db f2                               	vpandq zmm6{k1},zmm1,zmm2
   8b912:	62 e1 ed 50 fb 64 24 1b                         	vpsubq zmm20,zmm18,QWORD BCST [rsp+0xd8]
   8b91a:	62 91 fd 48 73 f7 34                            	vpsllq zmm0,zmm31,0x34
   8b921:	62 d1 f5 48 73 f1 28                            	vpsllq zmm1,zmm9,0x28
   8b928:	62 91 e5 48 73 d7 0c                            	vpsrlq zmm3,zmm31,0xc
   8b92f:	62 f1 bd 48 73 f6 1c                            	vpsllq zmm8,zmm6,0x1c
   8b936:	62 91 fd 48 eb ed                               	vporq  zmm5,zmm0,zmm29
   8b93c:	62 61 fd 50 fb 6c 24 19                         	vpsubq zmm29,zmm16,QWORD BCST [rsp+0xc8]
   8b944:	62 d1 fd 48 73 d1 18                            	vpsrlq zmm0,zmm9,0x18
   8b94b:	62 71 f5 50 fb 4c 24 1a                         	vpsubq zmm9,zmm17,QWORD BCST [rsp+0xd0]
   8b953:	62 f1 f5 48 eb fb                               	vporq  zmm7,zmm1,zmm3
   8b959:	62 91 e5 48 73 f6 10                            	vpsllq zmm3,zmm30,0x10
   8b960:	62 71 bd 48 eb c0                               	vporq  zmm8,zmm8,zmm0
   8b966:	62 f1 fd 48 73 d6 24                            	vpsrlq zmm0,zmm6,0x24
   8b96d:	62 f1 e5 48 eb f0                               	vporq  zmm6,zmm3,zmm0
   8b973:	62 f1 d5 48 6c df                               	vpunpcklqdq zmm3,zmm5,zmm7
   8b979:	62 f1 bd 48 6c c6                               	vpunpcklqdq zmm0,zmm8,zmm6
   8b97f:	62 91 95 40 d4 c9                               	vpaddq zmm1,zmm29,zmm25
   8b985:	62 f1 b5 40 72 e1 34                            	vpsraq zmm25,zmm1,0x34
   8b98c:	62 11 b5 48 d4 c9                               	vpaddq zmm9,zmm9,zmm25
   8b992:	62 d1 b5 40 72 e1 34                            	vpsraq zmm25,zmm9,0x34
   8b999:	62 81 dd 40 d4 e1                               	vpaddq zmm20,zmm20,zmm25
   8b99f:	62 b1 b5 40 72 e4 34                            	vpsraq zmm25,zmm20,0x34
   8b9a6:	62 81 e5 40 d4 d9                               	vpaddq zmm19,zmm19,zmm25
   8b9ac:	62 b3 e5 40 1e cd 01                            	vpcmpltuq k1,zmm19,zmm21
   8b9b3:	62 e1 f5 49 db c2                               	vpandq zmm16{k1},zmm1,zmm2
   8b9b9:	62 f1 bd 41 db e2                               	vpandq zmm4{k1},zmm24,zmm2
   8b9bf:	62 e1 b5 49 db ca                               	vpandq zmm17{k1},zmm9,zmm2
   8b9c5:	62 e1 dd 41 db d2                               	vpandq zmm18{k1},zmm20,zmm2
   8b9cb:	62 31 fd 49 6f fb                               	vmovdqa64 zmm15{k1},zmm19
   8b9d1:	62 d1 85 48 73 f7 10                            	vpsllq zmm15,zmm15,0x10
   8b9d8:	62 b1 f5 48 73 f0 34                            	vpsllq zmm1,zmm16,0x34
   8b9df:	62 71 f5 48 eb cc                               	vporq  zmm9,zmm1,zmm4
   8b9e5:	62 b1 f5 48 73 d0 0c                            	vpsrlq zmm1,zmm16,0xc
   8b9ec:	62 b1 fd 40 73 f1 28                            	vpsllq zmm16,zmm17,0x28
   8b9f3:	62 e1 fd 40 eb c1                               	vporq  zmm16,zmm16,zmm1
   8b9f9:	62 b1 f5 48 73 d1 18                            	vpsrlq zmm1,zmm17,0x18
   8ba00:	62 b1 f5 40 73 f2 1c                            	vpsllq zmm17,zmm18,0x1c
   8ba07:	62 e1 f5 40 eb c9                               	vporq  zmm17,zmm17,zmm1
   8ba0d:	62 b1 f5 48 73 d2 24                            	vpsrlq zmm1,zmm18,0x24
   8ba14:	62 b1 b5 48 6c e0                               	vpunpcklqdq zmm4,zmm9,zmm16
   8ba1a:	62 e3 65 28 38 d0 01                            	vinserti32x4 ymm18,ymm3,xmm0,0x1
   8ba21:	62 71 85 48 eb f9                               	vporq  zmm15,zmm15,zmm1
   8ba27:	62 c1 fe 28 7f 14 3e                            	vmovdqu64 YMMWORD PTR [r14+rdi*1],ymm18
   8ba2e:	62 d1 f5 40 6c cf                               	vpunpcklqdq zmm1,zmm17,zmm15
   8ba34:	62 e3 5d 28 38 d9 01                            	vinserti32x4 ymm19,ymm4,xmm1,0x1
   8ba3b:	62 c1 fe 28 7f 5c 3e 01                         	vmovdqu64 YMMWORD PTR [r14+rdi*1+0x20],ymm19
   8ba43:	48 89 c7                                        	mov    rdi,rax
   8ba46:	48 83 cf 01                                     	or     rdi,0x1
   8ba4a:	4c 39 ff                                        	cmp    rdi,r15
   8ba4d:	0f 83 4b 07 00 00                               	jae    8c19e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63be>
   8ba53:	48 c1 e7 04                                     	shl    rdi,0x4
   8ba57:	41 8b 3c 39                                     	mov    edi,DWORD PTR [r9+rdi*1]
   8ba5b:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8ba61:	49 39 fc                                        	cmp    r12,rdi
   8ba64:	0f 86 ca 06 00 00                               	jbe    8c134 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6354>
   8ba6a:	62 f1 d5 48 6d ff                               	vpunpckhqdq zmm7,zmm5,zmm7
   8ba70:	62 f1 bd 48 6d f6                               	vpunpckhqdq zmm6,zmm8,zmm6
   8ba76:	62 b1 b5 48 6d e8                               	vpunpckhqdq zmm5,zmm9,zmm16
   8ba7c:	62 51 f5 40 6d cf                               	vpunpckhqdq zmm9,zmm17,zmm15
   8ba82:	48 c1 e7 06                                     	shl    rdi,0x6
   8ba86:	c4 63 45 38 c6 01                               	vinserti128 ymm8,ymm7,xmm6,0x1
   8ba8c:	c4 43 55 38 f9 01                               	vinserti128 ymm15,ymm5,xmm9,0x1
   8ba92:	c4 41 7e 7f 04 3e                               	vmovdqu YMMWORD PTR [r14+rdi*1],ymm8
   8ba98:	c4 41 7e 7f 7c 3e 20                            	vmovdqu YMMWORD PTR [r14+rdi*1+0x20],ymm15
   8ba9f:	48 89 c7                                        	mov    rdi,rax
   8baa2:	48 83 cf 02                                     	or     rdi,0x2
   8baa6:	4c 39 ff                                        	cmp    rdi,r15
   8baa9:	0f 83 ef 06 00 00                               	jae    8c19e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63be>
   8baaf:	48 c1 e7 04                                     	shl    rdi,0x4
   8bab3:	41 8b 3c 39                                     	mov    edi,DWORD PTR [r9+rdi*1]
   8bab7:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8babd:	49 39 fc                                        	cmp    r12,rdi
   8bac0:	0f 86 6e 06 00 00                               	jbe    8c134 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6354>
   8bac6:	c4 63 65 46 c0 31                               	vperm2i128 ymm8,ymm3,ymm0,0x31
   8bacc:	c4 63 5d 46 f9 31                               	vperm2i128 ymm15,ymm4,ymm1,0x31
   8bad2:	48 c1 e7 06                                     	shl    rdi,0x6
   8bad6:	c4 41 7e 7f 04 3e                               	vmovdqu YMMWORD PTR [r14+rdi*1],ymm8
   8badc:	c4 41 7e 7f 7c 3e 20                            	vmovdqu YMMWORD PTR [r14+rdi*1+0x20],ymm15
   8bae3:	48 89 c7                                        	mov    rdi,rax
   8bae6:	48 83 cf 03                                     	or     rdi,0x3
   8baea:	4c 39 ff                                        	cmp    rdi,r15
   8baed:	0f 83 ab 06 00 00                               	jae    8c19e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63be>
   8baf3:	48 c1 e7 04                                     	shl    rdi,0x4
   8baf7:	41 8b 3c 39                                     	mov    edi,DWORD PTR [r9+rdi*1]
   8bafb:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8bb01:	49 39 fc                                        	cmp    r12,rdi
   8bb04:	0f 86 2a 06 00 00                               	jbe    8c134 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6354>
   8bb0a:	c4 63 45 46 c6 31                               	vperm2i128 ymm8,ymm7,ymm6,0x31
   8bb10:	c4 43 55 46 f9 31                               	vperm2i128 ymm15,ymm5,ymm9,0x31
   8bb16:	48 c1 e7 06                                     	shl    rdi,0x6
   8bb1a:	c4 41 7e 7f 04 3e                               	vmovdqu YMMWORD PTR [r14+rdi*1],ymm8
   8bb20:	c4 41 7e 7f 7c 3e 20                            	vmovdqu YMMWORD PTR [r14+rdi*1+0x20],ymm15
   8bb27:	48 89 c7                                        	mov    rdi,rax
   8bb2a:	48 83 cf 04                                     	or     rdi,0x4
   8bb2e:	4c 39 ff                                        	cmp    rdi,r15
   8bb31:	0f 83 67 06 00 00                               	jae    8c19e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63be>
   8bb37:	48 c1 e7 04                                     	shl    rdi,0x4
   8bb3b:	41 8b 3c 39                                     	mov    edi,DWORD PTR [r9+rdi*1]
   8bb3f:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8bb45:	49 39 fc                                        	cmp    r12,rdi
   8bb48:	0f 86 e6 05 00 00                               	jbe    8c134 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6354>
   8bb4e:	62 d3 7d 48 39 c0 02                            	vextracti32x4 xmm8,zmm0,0x2
   8bb55:	62 f3 fd 48 3b db 01                            	vextracti64x4 ymm3,zmm3,0x1
   8bb5c:	62 d3 7d 48 39 cf 02                            	vextracti32x4 xmm15,zmm1,0x2
   8bb63:	62 f3 fd 48 3b e4 01                            	vextracti64x4 ymm4,zmm4,0x1
   8bb6a:	48 c1 e7 06                                     	shl    rdi,0x6
   8bb6e:	c4 43 65 38 c0 01                               	vinserti128 ymm8,ymm3,xmm8,0x1
   8bb74:	c4 43 5d 38 ff 01                               	vinserti128 ymm15,ymm4,xmm15,0x1
   8bb7a:	c4 41 7e 7f 04 3e                               	vmovdqu YMMWORD PTR [r14+rdi*1],ymm8
   8bb80:	c4 41 7e 7f 7c 3e 20                            	vmovdqu YMMWORD PTR [r14+rdi*1+0x20],ymm15
   8bb87:	48 89 c7                                        	mov    rdi,rax
   8bb8a:	48 83 cf 05                                     	or     rdi,0x5
   8bb8e:	4c 39 ff                                        	cmp    rdi,r15
   8bb91:	0f 83 07 06 00 00                               	jae    8c19e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63be>
   8bb97:	48 c1 e7 04                                     	shl    rdi,0x4
   8bb9b:	41 8b 3c 39                                     	mov    edi,DWORD PTR [r9+rdi*1]
   8bb9f:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8bba5:	49 39 fc                                        	cmp    r12,rdi
   8bba8:	0f 86 86 05 00 00                               	jbe    8c134 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6354>
   8bbae:	62 d3 7d 48 39 f7 02                            	vextracti32x4 xmm15,zmm6,0x2
   8bbb5:	62 d3 fd 48 3b f8 01                            	vextracti64x4 ymm8,zmm7,0x1
   8bbbc:	62 33 7d 48 39 c8 02                            	vextracti32x4 xmm16,zmm9,0x2
   8bbc3:	62 93 fd 48 3b e8 01                            	vextracti64x4 ymm24,zmm5,0x1
   8bbca:	48 c1 e7 06                                     	shl    rdi,0x6
   8bbce:	c4 c3 3d 38 ff 01                               	vinserti128 ymm7,ymm8,xmm15,0x1
   8bbd4:	62 b3 3d 20 38 e8 01                            	vinserti32x4 ymm5,ymm24,xmm16,0x1
   8bbdb:	c4 c1 7e 7f 3c 3e                               	vmovdqu YMMWORD PTR [r14+rdi*1],ymm7
   8bbe1:	c4 c1 7e 7f 6c 3e 20                            	vmovdqu YMMWORD PTR [r14+rdi*1+0x20],ymm5
   8bbe8:	48 89 c7                                        	mov    rdi,rax
   8bbeb:	48 83 cf 06                                     	or     rdi,0x6
   8bbef:	4c 39 ff                                        	cmp    rdi,r15
   8bbf2:	0f 83 a6 05 00 00                               	jae    8c19e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63be>
   8bbf8:	48 c1 e7 04                                     	shl    rdi,0x4
   8bbfc:	41 8b 3c 39                                     	mov    edi,DWORD PTR [r9+rdi*1]
   8bc00:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8bc06:	49 39 fc                                        	cmp    r12,rdi
   8bc09:	0f 86 25 05 00 00                               	jbe    8c134 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6354>
   8bc0f:	62 f3 fd 48 3b c0 01                            	vextracti64x4 ymm0,zmm0,0x1
   8bc16:	62 f3 fd 48 3b c9 01                            	vextracti64x4 ymm1,zmm1,0x1
   8bc1d:	48 c1 e7 06                                     	shl    rdi,0x6
   8bc21:	48 83 c8 07                                     	or     rax,0x7
   8bc25:	c4 e3 65 46 c0 31                               	vperm2i128 ymm0,ymm3,ymm0,0x31
   8bc2b:	c4 e3 5d 46 c9 31                               	vperm2i128 ymm1,ymm4,ymm1,0x31
   8bc31:	c4 c1 7e 7f 04 3e                               	vmovdqu YMMWORD PTR [r14+rdi*1],ymm0
   8bc37:	c4 c1 7e 7f 4c 3e 20                            	vmovdqu YMMWORD PTR [r14+rdi*1+0x20],ymm1
   8bc3e:	4c 39 f8                                        	cmp    rax,r15
   8bc41:	0f 83 5a 05 00 00                               	jae    8c1a1 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x63c1>
   8bc47:	48 c1 e0 04                                     	shl    rax,0x4
   8bc4b:	41 8b 3c 01                                     	mov    edi,DWORD PTR [r9+rax*1]
   8bc4f:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8bc55:	49 39 fc                                        	cmp    r12,rdi
   8bc58:	0f 86 d6 04 00 00                               	jbe    8c134 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6354>
   8bc5e:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8bc62:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   8bc66:	62 b2 a5 48 b5 e7                               	vpmadd52huq zmm4,zmm11,zmm23
   8bc6c:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   8bc70:	62 b2 95 48 b5 ef                               	vpmadd52huq zmm5,zmm13,zmm23
   8bc76:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   8bc7a:	62 b2 8d 48 b5 df                               	vpmadd52huq zmm3,zmm14,zmm23
   8bc80:	62 b2 ad 48 b4 cf                               	vpmadd52luq zmm1,zmm10,zmm23
   8bc86:	62 e1 fd 48 6f 5c 24 0a                         	vmovdqa64 zmm19,ZMMWORD PTR [rsp+0x280]
   8bc8e:	62 e1 fd 48 6f 54 24 0b                         	vmovdqa64 zmm18,ZMMWORD PTR [rsp+0x2c0]
   8bc96:	62 e1 fd 48 6f 4c 24 09                         	vmovdqa64 zmm17,ZMMWORD PTR [rsp+0x240]
   8bc9e:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   8bca2:	62 b2 ad 48 b5 ff                               	vpmadd52huq zmm7,zmm10,zmm23
   8bca8:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8bcad:	62 e1 fd 48 6f 44 24 17                         	vmovdqa64 zmm16,ZMMWORD PTR [rsp+0x5c0]
   8bcb5:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   8bcb9:	62 b2 9d 48 b5 c7                               	vpmadd52huq zmm0,zmm12,zmm23
   8bcbf:	62 e1 fd 48 6f 64 24 1f                         	vmovdqa64 zmm20,ZMMWORD PTR [rsp+0x7c0]
   8bcc7:	48 c1 e7 06                                     	shl    rdi,0x6
   8bccb:	48 81 c6 c0 f9 ff ff                            	add    rsi,0xfffffffffffff9c0
   8bcd2:	62 12 f5 48 b4 fa                               	vpmadd52luq zmm15,zmm1,zmm26
   8bcd8:	62 b2 95 48 b4 e7                               	vpmadd52luq zmm4,zmm13,zmm23
   8bcde:	62 b2 8d 48 b4 ef                               	vpmadd52luq zmm5,zmm14,zmm23
   8bce4:	62 b2 9d 48 b4 df                               	vpmadd52luq zmm3,zmm12,zmm23
   8bcea:	62 b2 a5 48 b4 ff                               	vpmadd52luq zmm7,zmm11,zmm23
   8bcf0:	62 f1 f5 48 d4 ca                               	vpaddq zmm1,zmm1,zmm2
   8bcf6:	62 f1 f5 48 73 d1 34                            	vpsrlq zmm1,zmm1,0x34
   8bcfd:	62 b2 85 48 b5 e3                               	vpmadd52huq zmm4,zmm15,zmm19
   8bd03:	62 b2 85 48 b5 ea                               	vpmadd52huq zmm5,zmm15,zmm18
   8bd09:	62 b2 85 48 b5 d9                               	vpmadd52huq zmm3,zmm15,zmm17
   8bd0f:	62 92 85 48 b5 cb                               	vpmadd52huq zmm1,zmm15,zmm27
   8bd15:	62 b2 85 48 b4 fb                               	vpmadd52luq zmm7,zmm15,zmm19
   8bd1b:	62 b2 85 48 b5 c0                               	vpmadd52huq zmm0,zmm15,zmm16
   8bd21:	62 b2 85 48 b4 e2                               	vpmadd52luq zmm4,zmm15,zmm18
   8bd27:	62 b2 85 48 b4 e9                               	vpmadd52luq zmm5,zmm15,zmm17
   8bd2d:	62 b2 85 48 b4 d8                               	vpmadd52luq zmm3,zmm15,zmm16
   8bd33:	62 71 fd 48 6f 7c 24 16                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x580]
   8bd3b:	62 f1 c5 48 d4 f9                               	vpaddq zmm7,zmm7,zmm1
   8bd41:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8bd45:	62 d2 ad 48 b5 e7                               	vpmadd52huq zmm4,zmm10,zmm15
   8bd4b:	62 d2 a5 48 b5 ef                               	vpmadd52huq zmm5,zmm11,zmm15
   8bd51:	62 d2 95 48 b5 df                               	vpmadd52huq zmm3,zmm13,zmm15
   8bd57:	62 d2 8d 48 b5 c7                               	vpmadd52huq zmm0,zmm14,zmm15
   8bd5d:	62 d2 ad 48 b4 ff                               	vpmadd52luq zmm7,zmm10,zmm15
   8bd63:	62 d2 9d 48 b5 cf                               	vpmadd52huq zmm1,zmm12,zmm15
   8bd69:	62 d2 a5 48 b4 e7                               	vpmadd52luq zmm4,zmm11,zmm15
   8bd6f:	62 d2 95 48 b4 ef                               	vpmadd52luq zmm5,zmm13,zmm15
   8bd75:	62 d2 8d 48 b4 df                               	vpmadd52luq zmm3,zmm14,zmm15
   8bd7b:	62 d2 9d 48 b4 c7                               	vpmadd52luq zmm0,zmm12,zmm15
   8bd81:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8bd86:	62 12 c5 48 b4 fa                               	vpmadd52luq zmm15,zmm7,zmm26
   8bd8c:	62 f1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm2
   8bd92:	62 f1 c5 48 73 d7 34                            	vpsrlq zmm7,zmm7,0x34
   8bd99:	62 b2 85 48 b5 eb                               	vpmadd52huq zmm5,zmm15,zmm19
   8bd9f:	62 b2 85 48 b5 da                               	vpmadd52huq zmm3,zmm15,zmm18
   8bda5:	62 b2 85 48 b5 c1                               	vpmadd52huq zmm0,zmm15,zmm17
   8bdab:	62 92 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm27
   8bdb1:	62 b2 85 48 b4 e3                               	vpmadd52luq zmm4,zmm15,zmm19
   8bdb7:	62 b2 85 48 b5 c8                               	vpmadd52huq zmm1,zmm15,zmm16
   8bdbd:	62 b2 85 48 b4 ea                               	vpmadd52luq zmm5,zmm15,zmm18
   8bdc3:	62 b2 85 48 b4 d9                               	vpmadd52luq zmm3,zmm15,zmm17
   8bdc9:	62 b2 85 48 b4 c0                               	vpmadd52luq zmm0,zmm15,zmm16
   8bdcf:	62 71 fd 48 6f 7c 24 0e                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x380]
   8bdd7:	62 f1 dd 48 d4 ff                               	vpaddq zmm7,zmm4,zmm7
   8bddd:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   8bde1:	62 d2 ad 48 b5 ef                               	vpmadd52huq zmm5,zmm10,zmm15
   8bde7:	62 d2 a5 48 b5 df                               	vpmadd52huq zmm3,zmm11,zmm15
   8bded:	62 d2 95 48 b5 c7                               	vpmadd52huq zmm0,zmm13,zmm15
   8bdf3:	62 d2 8d 48 b5 cf                               	vpmadd52huq zmm1,zmm14,zmm15
   8bdf9:	62 d2 ad 48 b4 ff                               	vpmadd52luq zmm7,zmm10,zmm15
   8bdff:	62 d2 9d 48 b5 e7                               	vpmadd52huq zmm4,zmm12,zmm15
   8be05:	62 d2 a5 48 b4 ef                               	vpmadd52luq zmm5,zmm11,zmm15
   8be0b:	62 d2 95 48 b4 df                               	vpmadd52luq zmm3,zmm13,zmm15
   8be11:	62 d2 8d 48 b4 c7                               	vpmadd52luq zmm0,zmm14,zmm15
   8be17:	62 d2 9d 48 b4 cf                               	vpmadd52luq zmm1,zmm12,zmm15
   8be1d:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8be22:	62 12 c5 48 b4 fa                               	vpmadd52luq zmm15,zmm7,zmm26
   8be28:	62 f1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm2
   8be2e:	62 f1 c5 48 73 d7 34                            	vpsrlq zmm7,zmm7,0x34
   8be35:	62 b2 85 48 b5 db                               	vpmadd52huq zmm3,zmm15,zmm19
   8be3b:	62 b2 85 48 b5 c2                               	vpmadd52huq zmm0,zmm15,zmm18
   8be41:	62 b2 85 48 b5 c9                               	vpmadd52huq zmm1,zmm15,zmm17
   8be47:	62 92 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm27
   8be4d:	62 b2 85 48 b4 eb                               	vpmadd52luq zmm5,zmm15,zmm19
   8be53:	62 b2 85 48 b5 e0                               	vpmadd52huq zmm4,zmm15,zmm16
   8be59:	62 b2 85 48 b4 da                               	vpmadd52luq zmm3,zmm15,zmm18
   8be5f:	62 b2 85 48 b4 c1                               	vpmadd52luq zmm0,zmm15,zmm17
   8be65:	62 b2 85 48 b4 c8                               	vpmadd52luq zmm1,zmm15,zmm16
   8be6b:	62 71 fd 48 6f 7c 24 0c                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x300]
   8be73:	62 f1 d5 48 d4 ff                               	vpaddq zmm7,zmm5,zmm7
   8be79:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   8be7d:	62 d2 ad 48 b5 df                               	vpmadd52huq zmm3,zmm10,zmm15
   8be83:	62 d2 a5 48 b5 c7                               	vpmadd52huq zmm0,zmm11,zmm15
   8be89:	62 d2 95 48 b5 cf                               	vpmadd52huq zmm1,zmm13,zmm15
   8be8f:	62 d2 8d 48 b5 e7                               	vpmadd52huq zmm4,zmm14,zmm15
   8be95:	62 d2 ad 48 b4 ff                               	vpmadd52luq zmm7,zmm10,zmm15
   8be9b:	62 d2 9d 48 b5 ef                               	vpmadd52huq zmm5,zmm12,zmm15
   8bea1:	62 d2 a5 48 b4 df                               	vpmadd52luq zmm3,zmm11,zmm15
   8bea7:	62 d2 95 48 b4 c7                               	vpmadd52luq zmm0,zmm13,zmm15
   8bead:	62 d2 8d 48 b4 cf                               	vpmadd52luq zmm1,zmm14,zmm15
   8beb3:	62 d2 9d 48 b4 e7                               	vpmadd52luq zmm4,zmm12,zmm15
   8beb9:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8bebe:	62 12 c5 48 b4 fa                               	vpmadd52luq zmm15,zmm7,zmm26
   8bec4:	62 f1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm2
   8beca:	62 f1 c5 48 73 d7 34                            	vpsrlq zmm7,zmm7,0x34
   8bed1:	62 b2 85 48 b5 e1                               	vpmadd52huq zmm4,zmm15,zmm17
   8bed7:	62 b2 85 48 b5 ca                               	vpmadd52huq zmm1,zmm15,zmm18
   8bedd:	62 92 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm27
   8bee3:	62 b2 85 48 b4 db                               	vpmadd52luq zmm3,zmm15,zmm19
   8bee9:	62 b2 85 48 b5 c3                               	vpmadd52huq zmm0,zmm15,zmm19
   8beef:	62 b2 85 48 b5 e8                               	vpmadd52huq zmm5,zmm15,zmm16
   8bef5:	62 b2 85 48 b4 e0                               	vpmadd52luq zmm4,zmm15,zmm16
   8befb:	62 b2 85 48 b4 c9                               	vpmadd52luq zmm1,zmm15,zmm17
   8bf01:	62 f1 e5 48 d4 df                               	vpaddq zmm3,zmm3,zmm7
   8bf07:	62 b2 85 48 b4 c2                               	vpmadd52luq zmm0,zmm15,zmm18
   8bf0d:	62 b2 8d 48 b5 ec                               	vpmadd52huq zmm5,zmm14,zmm20
   8bf13:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   8bf17:	62 b2 9d 48 b5 fc                               	vpmadd52huq zmm7,zmm12,zmm20
   8bf1d:	62 b2 ad 48 b4 dc                               	vpmadd52luq zmm3,zmm10,zmm20
   8bf23:	62 b2 95 48 b5 e4                               	vpmadd52huq zmm4,zmm13,zmm20
   8bf29:	62 b2 a5 48 b5 cc                               	vpmadd52huq zmm1,zmm11,zmm20
   8bf2f:	62 b2 ad 48 b5 c4                               	vpmadd52huq zmm0,zmm10,zmm20
   8bf35:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   8bf3a:	62 b2 9d 48 b4 ec                               	vpmadd52luq zmm5,zmm12,zmm20
   8bf40:	62 12 e5 48 b4 d2                               	vpmadd52luq zmm10,zmm3,zmm26
   8bf46:	62 b1 e5 48 d4 de                               	vpaddq zmm3,zmm3,zmm22
   8bf4c:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   8bf53:	62 b2 8d 48 b4 e4                               	vpmadd52luq zmm4,zmm14,zmm20
   8bf59:	62 b2 95 48 b4 cc                               	vpmadd52luq zmm1,zmm13,zmm20
   8bf5f:	62 b2 a5 48 b4 c4                               	vpmadd52luq zmm0,zmm11,zmm20
   8bf65:	62 31 ad 48 db de                               	vpandq zmm11,zmm10,zmm22
   8bf6b:	62 d1 ad 48 73 f2 04                            	vpsllq zmm10,zmm10,0x4
   8bf72:	62 b2 a5 48 b5 e9                               	vpmadd52huq zmm5,zmm11,zmm17
   8bf78:	62 92 ad 48 b5 db                               	vpmadd52huq zmm3,zmm10,zmm27
   8bf7e:	62 b2 a5 48 b5 f8                               	vpmadd52huq zmm7,zmm11,zmm16
   8bf84:	62 b2 a5 48 b5 e2                               	vpmadd52huq zmm4,zmm11,zmm18
   8bf8a:	62 b2 a5 48 b5 cb                               	vpmadd52huq zmm1,zmm11,zmm19
   8bf90:	62 b2 a5 48 b4 c3                               	vpmadd52luq zmm0,zmm11,zmm19
   8bf96:	62 b2 a5 48 b4 e8                               	vpmadd52luq zmm5,zmm11,zmm16
   8bf9c:	62 f1 c5 48 73 f7 04                            	vpsllq zmm7,zmm7,0x4
   8bfa3:	62 b2 a5 48 b4 e1                               	vpmadd52luq zmm4,zmm11,zmm17
   8bfa9:	62 b2 a5 48 b4 ca                               	vpmadd52luq zmm1,zmm11,zmm18
   8bfaf:	62 f1 ad 48 73 f0 04                            	vpsllq zmm10,zmm0,0x4
   8bfb6:	62 f1 fd 48 73 d0 30                            	vpsrlq zmm0,zmm0,0x30
   8bfbd:	62 11 ad 48 db d4                               	vpandq zmm10,zmm10,zmm28
   8bfc3:	62 f1 ad 48 d4 db                               	vpaddq zmm3,zmm10,zmm3
   8bfc9:	62 f1 9d 48 73 f5 04                            	vpsllq zmm12,zmm5,0x4
   8bfd0:	62 f1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm5,0x30
   8bfd7:	62 f1 c5 48 d4 ed                               	vpaddq zmm5,zmm7,zmm5
   8bfdd:	62 f1 a5 48 73 f4 04                            	vpsllq zmm11,zmm4,0x4
   8bfe4:	62 f1 ad 48 73 f1 04                            	vpsllq zmm10,zmm1,0x4
   8bfeb:	62 f1 f5 48 73 d1 30                            	vpsrlq zmm1,zmm1,0x30
   8bff2:	62 f1 dd 48 73 d4 30                            	vpsrlq zmm4,zmm4,0x30
   8bff9:	62 11 a5 48 db dc                               	vpandq zmm11,zmm11,zmm28
   8bfff:	62 11 ad 48 db d4                               	vpandq zmm10,zmm10,zmm28
   8c005:	62 f1 a5 48 d4 c9                               	vpaddq zmm1,zmm11,zmm1
   8c00b:	62 11 9d 48 db dc                               	vpandq zmm11,zmm12,zmm28
   8c011:	62 f1 a5 48 d4 e4                               	vpaddq zmm4,zmm11,zmm4
   8c017:	62 f1 a5 48 73 d3 34                            	vpsrlq zmm11,zmm3,0x34
   8c01e:	62 f1 a5 48 d4 c0                               	vpaddq zmm0,zmm11,zmm0
   8c024:	62 d1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm10
   8c02a:	62 71 e5 48 db d2                               	vpandq zmm10,zmm3,zmm2
   8c030:	62 f1 e5 48 73 d0 34                            	vpsrlq zmm3,zmm0,0x34
   8c037:	62 71 fd 48 db da                               	vpandq zmm11,zmm0,zmm2
   8c03d:	62 f1 e5 48 d4 c9                               	vpaddq zmm1,zmm3,zmm1
   8c043:	62 f1 fd 48 73 d1 34                            	vpsrlq zmm0,zmm1,0x34
   8c04a:	62 71 f5 48 db ea                               	vpandq zmm13,zmm1,zmm2
   8c050:	62 f1 fd 48 d4 c4                               	vpaddq zmm0,zmm0,zmm4
   8c056:	62 f1 f5 48 73 d0 34                            	vpsrlq zmm1,zmm0,0x34
   8c05d:	62 71 fd 48 db f2                               	vpandq zmm14,zmm0,zmm2
   8c063:	62 f3 fd 48 3b f0 01                            	vextracti64x4 ymm0,zmm6,0x1
   8c06a:	62 71 f5 48 d4 e5                               	vpaddq zmm12,zmm1,zmm5
   8c070:	62 73 fd 48 3b c9 01                            	vextracti64x4 ymm1,zmm9,0x1
   8c077:	c4 e3 3d 46 c0 31                               	vperm2i128 ymm0,ymm8,ymm0,0x31
   8c07d:	62 f3 bd 20 43 c9 03                            	vshufi64x2 ymm1,ymm24,ymm1,0x3
   8c084:	c4 c1 7e 7f 04 3e                               	vmovdqu YMMWORD PTR [r14+rdi*1],ymm0
   8c08a:	c4 c1 7e 7f 4c 3e 20                            	vmovdqu YMMWORD PTR [r14+rdi*1+0x20],ymm1
   8c091:	48 81 fe c0 f9 ff ff                            	cmp    rsi,0xfffffffffffff9c0
   8c098:	0f 85 72 e6 ff ff                               	jne    8a710 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x4930>
   8c09e:	48 8d 65 d8                                     	lea    rsp,[rbp-0x28]
   8c0a2:	5b                                              	pop    rbx
   8c0a3:	41 5c                                           	pop    r12
   8c0a5:	41 5d                                           	pop    r13
   8c0a7:	41 5e                                           	pop    r14
   8c0a9:	41 5f                                           	pop    r15
   8c0ab:	5d                                              	pop    rbp
   8c0ac:	c5 f8 77                                        	vzeroupper
   8c0af:	c3                                              	ret
   8c0b0:	48 8d 0d 31 e2 00 00                            	lea    rcx,[rip+0xe231]        # 9a2e8 <__frame_dummy_init_array_entry+0x2498>
   8c0b7:	4c 89 fa                                        	mov    rdx,r15
   8c0ba:	c5 f8 77                                        	vzeroupper
   8c0bd:	e8 ae 4e fa ff                                  	call   30f70 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
   8c0c2:	48 8d 0d 77 e1 00 00                            	lea    rcx,[rip+0xe177]        # 9a240 <__frame_dummy_init_array_entry+0x23f0>
   8c0c9:	4c 89 fa                                        	mov    rdx,r15
   8c0cc:	c5 f8 77                                        	vzeroupper
   8c0cf:	e8 9c 4e fa ff                                  	call   30f70 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
   8c0d4:	4c 89 c7                                        	mov    rdi,r8
   8c0d7:	48 89 de                                        	mov    rsi,rbx
   8c0da:	62 61 fd 48 7f 54 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm26
   8c0e2:	62 61 fd 48 7f 44 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm24
   8c0ea:	62 61 fd 48 7f 4c 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm25
   8c0f2:	62 61 fd 48 7f 5c 24 0c                         	vmovdqa64 ZMMWORD PTR [rsp+0x300],zmm27
   8c0fa:	c5 f8 77                                        	vzeroupper
   8c0fd:	e8 4e 7a 00 00                                  	call   93b50 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
   8c102:	62 61 fd 48 6f 5c 24 0c                         	vmovdqa64 zmm27,ZMMWORD PTR [rsp+0x300]
   8c10a:	62 61 fd 48 6f 4c 24 0a                         	vmovdqa64 zmm25,ZMMWORD PTR [rsp+0x280]
   8c112:	62 61 fd 48 6f 44 24 0b                         	vmovdqa64 zmm24,ZMMWORD PTR [rsp+0x2c0]
   8c11a:	62 61 fd 48 6f 54 24 09                         	vmovdqa64 zmm26,ZMMWORD PTR [rsp+0x240]
   8c122:	4c 8b 84 24 c0 03 00 00                         	mov    r8,QWORD PTR [rsp+0x3c0]
   8c12a:	48 8b 54 24 30                                  	mov    rdx,QWORD PTR [rsp+0x30]
   8c12f:	e9 be 9d ff ff                                  	jmp    85ef2 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x112>
   8c134:	48 8d 15 35 e1 00 00                            	lea    rdx,[rip+0xe135]        # 9a270 <__frame_dummy_init_array_entry+0x2420>
   8c13b:	4c 89 e6                                        	mov    rsi,r12
   8c13e:	c5 f8 77                                        	vzeroupper
   8c141:	e8 2e 41 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c146:	4c 89 c7                                        	mov    rdi,r8
   8c149:	48 89 de                                        	mov    rsi,rbx
   8c14c:	62 61 fd 48 7f 54 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm26
   8c154:	62 61 fd 48 7f 44 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm24
   8c15c:	62 61 fd 48 7f 4c 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm25
   8c164:	62 61 fd 48 7f 5c 24 0c                         	vmovdqa64 ZMMWORD PTR [rsp+0x300],zmm27
   8c16c:	c5 f8 77                                        	vzeroupper
   8c16f:	e8 dc 79 00 00                                  	call   93b50 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
   8c174:	62 61 fd 48 6f 5c 24 0c                         	vmovdqa64 zmm27,ZMMWORD PTR [rsp+0x300]
   8c17c:	62 61 fd 48 6f 4c 24 0a                         	vmovdqa64 zmm25,ZMMWORD PTR [rsp+0x280]
   8c184:	62 61 fd 48 6f 44 24 0b                         	vmovdqa64 zmm24,ZMMWORD PTR [rsp+0x2c0]
   8c18c:	62 61 fd 48 6f 54 24 09                         	vmovdqa64 zmm26,ZMMWORD PTR [rsp+0x240]
   8c194:	48 8b 54 24 30                                  	mov    rdx,QWORD PTR [rsp+0x30]
   8c199:	e9 31 ae ff ff                                  	jmp    86fcf <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x11ef>
   8c19e:	48 89 f8                                        	mov    rax,rdi
   8c1a1:	48 8d 15 b0 e0 00 00                            	lea    rdx,[rip+0xe0b0]        # 9a258 <__frame_dummy_init_array_entry+0x2408>
   8c1a8:	48 89 c7                                        	mov    rdi,rax
   8c1ab:	4c 89 fe                                        	mov    rsi,r15
   8c1ae:	c5 f8 77                                        	vzeroupper
   8c1b1:	e8 be 40 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c1b6:	4c 89 d9                                        	mov    rcx,r11
   8c1b9:	48 8b b4 24 00 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x400]
   8c1c1:	48 8d 15 80 e1 00 00                            	lea    rdx,[rip+0xe180]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   8c1c8:	48 89 cf                                        	mov    rdi,rcx
   8c1cb:	c5 f8 77                                        	vzeroupper
   8c1ce:	e8 a1 40 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c1d3:	4c 89 f1                                        	mov    rcx,r14
   8c1d6:	48 8b b4 24 00 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x400]
   8c1de:	48 8d 15 63 e1 00 00                            	lea    rdx,[rip+0xe163]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   8c1e5:	48 89 cf                                        	mov    rdi,rcx
   8c1e8:	c5 f8 77                                        	vzeroupper
   8c1eb:	e8 84 40 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c1f0:	48 89 f1                                        	mov    rcx,rsi
   8c1f3:	48 8b b4 24 00 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x400]
   8c1fb:	48 8d 15 46 e1 00 00                            	lea    rdx,[rip+0xe146]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   8c202:	48 89 cf                                        	mov    rdi,rcx
   8c205:	c5 f8 77                                        	vzeroupper
   8c208:	e8 67 40 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c20d:	48 83 c7 03                                     	add    rdi,0x3
   8c211:	eb 1b                                           	jmp    8c22e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x644e>
   8c213:	48 ff c7                                        	inc    rdi
   8c216:	eb 16                                           	jmp    8c22e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x644e>
   8c218:	48 83 c7 02                                     	add    rdi,0x2
   8c21c:	eb 10                                           	jmp    8c22e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x644e>
   8c21e:	48 83 c7 06                                     	add    rdi,0x6
   8c222:	eb 0a                                           	jmp    8c22e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x644e>
   8c224:	48 83 c7 04                                     	add    rdi,0x4
   8c228:	eb 04                                           	jmp    8c22e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x644e>
   8c22a:	48 83 c7 05                                     	add    rdi,0x5
   8c22e:	48 89 f8                                        	mov    rax,rdi
   8c231:	48 8b 74 24 38                                  	mov    rsi,QWORD PTR [rsp+0x38]
   8c236:	48 8d 15 f3 e0 00 00                            	lea    rdx,[rip+0xe0f3]        # 9a330 <__frame_dummy_init_array_entry+0x24e0>
   8c23d:	48 89 c7                                        	mov    rdi,rax
   8c240:	c5 f8 77                                        	vzeroupper
   8c243:	e8 2c 40 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c248:	4c 89 d1                                        	mov    rcx,r10
   8c24b:	48 8b b4 24 00 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x400]
   8c253:	48 8d 15 ee e0 00 00                            	lea    rdx,[rip+0xe0ee]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   8c25a:	48 89 cf                                        	mov    rdi,rcx
   8c25d:	c5 f8 77                                        	vzeroupper
   8c260:	e8 0f 40 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c265:	4c 89 e1                                        	mov    rcx,r12
   8c268:	48 8b b4 24 00 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x400]
   8c270:	48 8d 15 d1 e0 00 00                            	lea    rdx,[rip+0xe0d1]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   8c277:	48 89 cf                                        	mov    rdi,rcx
   8c27a:	c5 f8 77                                        	vzeroupper
   8c27d:	e8 f2 3f fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c282:	48 89 d9                                        	mov    rcx,rbx
   8c285:	48 8b b4 24 00 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x400]
   8c28d:	48 8d 15 b4 e0 00 00                            	lea    rdx,[rip+0xe0b4]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   8c294:	48 89 cf                                        	mov    rdi,rcx
   8c297:	c5 f8 77                                        	vzeroupper
   8c29a:	e8 d5 3f fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c29f:	4c 89 f9                                        	mov    rcx,r15
   8c2a2:	48 8b b4 24 00 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x400]
   8c2aa:	48 8d 15 97 e0 00 00                            	lea    rdx,[rip+0xe097]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   8c2b1:	48 89 cf                                        	mov    rdi,rcx
   8c2b4:	c5 f8 77                                        	vzeroupper
   8c2b7:	e8 b8 3f fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c2bc:	48 83 c7 06                                     	add    rdi,0x6
   8c2c0:	eb 33                                           	jmp    8c2f5 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6515>
   8c2c2:	4c 89 c8                                        	mov    rax,r9
   8c2c5:	48 8d 15 ac e0 00 00                            	lea    rdx,[rip+0xe0ac]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   8c2cc:	48 89 c7                                        	mov    rdi,rax
   8c2cf:	4c 89 e6                                        	mov    rsi,r12
   8c2d2:	c5 f8 77                                        	vzeroupper
   8c2d5:	e8 9a 3f fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c2da:	48 83 c7 05                                     	add    rdi,0x5
   8c2de:	eb 15                                           	jmp    8c2f5 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6515>
   8c2e0:	48 83 c7 04                                     	add    rdi,0x4
   8c2e4:	eb 0f                                           	jmp    8c2f5 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6515>
   8c2e6:	48 83 c7 03                                     	add    rdi,0x3
   8c2ea:	eb 09                                           	jmp    8c2f5 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6515>
   8c2ec:	48 83 c7 02                                     	add    rdi,0x2
   8c2f0:	eb 03                                           	jmp    8c2f5 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_+0x6515>
   8c2f2:	48 ff c7                                        	inc    rdi
   8c2f5:	48 89 f9                                        	mov    rcx,rdi
   8c2f8:	48 8d 15 61 e0 00 00                            	lea    rdx,[rip+0xe061]        # 9a360 <__frame_dummy_init_array_entry+0x2510>
   8c2ff:	48 89 cf                                        	mov    rdi,rcx
   8c302:	4c 89 fe                                        	mov    rsi,r15
   8c305:	c5 f8 77                                        	vzeroupper
   8c308:	e8 67 3f fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c30d:	4c 89 c0                                        	mov    rax,r8
   8c310:	48 8d 15 61 e0 00 00                            	lea    rdx,[rip+0xe061]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   8c317:	48 89 c7                                        	mov    rdi,rax
   8c31a:	4c 89 e6                                        	mov    rsi,r12
   8c31d:	c5 f8 77                                        	vzeroupper
   8c320:	e8 4f 3f fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c325:	48 89 d0                                        	mov    rax,rdx
   8c328:	48 8d 15 49 e0 00 00                            	lea    rdx,[rip+0xe049]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   8c32f:	48 89 c7                                        	mov    rdi,rax
   8c332:	4c 89 e6                                        	mov    rsi,r12
   8c335:	c5 f8 77                                        	vzeroupper
   8c338:	e8 37 3f fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c33d:	48 89 f0                                        	mov    rax,rsi
   8c340:	48 8d 15 31 e0 00 00                            	lea    rdx,[rip+0xe031]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   8c347:	48 89 c7                                        	mov    rdi,rax
   8c34a:	4c 89 e6                                        	mov    rsi,r12
   8c34d:	c5 f8 77                                        	vzeroupper
   8c350:	e8 1f 3f fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c355:	48 89 d8                                        	mov    rax,rbx
   8c358:	48 8d 15 19 e0 00 00                            	lea    rdx,[rip+0xe019]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   8c35f:	48 89 c7                                        	mov    rdi,rax
   8c362:	4c 89 e6                                        	mov    rsi,r12
   8c365:	c5 f8 77                                        	vzeroupper
   8c368:	e8 07 3f fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c36d:	4c 89 d8                                        	mov    rax,r11
   8c370:	48 8d 15 01 e0 00 00                            	lea    rdx,[rip+0xe001]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   8c377:	48 89 c7                                        	mov    rdi,rax
   8c37a:	4c 89 e6                                        	mov    rsi,r12
   8c37d:	c5 f8 77                                        	vzeroupper
   8c380:	e8 ef 3e fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c385:	4c 89 d0                                        	mov    rax,r10
   8c388:	48 8d 15 e9 df 00 00                            	lea    rdx,[rip+0xdfe9]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   8c38f:	48 89 c7                                        	mov    rdi,rax
   8c392:	4c 89 e6                                        	mov    rsi,r12
   8c395:	c5 f8 77                                        	vzeroupper
   8c398:	e8 d7 3e fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c39d:	48 8b b4 24 00 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x400]
   8c3a5:	48 8d 15 24 df 00 00                            	lea    rdx,[rip+0xdf24]        # 9a2d0 <__frame_dummy_init_array_entry+0x2480>
   8c3ac:	c5 f8 77                                        	vzeroupper
   8c3af:	e8 c0 3e fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c3b4:	48 8d 15 fd de 00 00                            	lea    rdx,[rip+0xdefd]        # 9a2b8 <__frame_dummy_init_array_entry+0x2468>
   8c3bb:	48 89 c7                                        	mov    rdi,rax
   8c3be:	4c 89 e6                                        	mov    rsi,r12
   8c3c1:	c5 f8 77                                        	vzeroupper
   8c3c4:	e8 ab 3e fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c3c9:	48 8b 74 24 38                                  	mov    rsi,QWORD PTR [rsp+0x38]
   8c3ce:	48 8d 15 cb de 00 00                            	lea    rdx,[rip+0xdecb]        # 9a2a0 <__frame_dummy_init_array_entry+0x2450>
   8c3d5:	c5 f8 77                                        	vzeroupper
   8c3d8:	e8 97 3e fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8c3dd:	48 8d 15 a4 de 00 00                            	lea    rdx,[rip+0xdea4]        # 9a288 <__frame_dummy_init_array_entry+0x2438>
   8c3e4:	48 89 c7                                        	mov    rdi,rax
   8c3e7:	c5 f8 77                                        	vzeroupper
   8c3ea:	e8 85 3e fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
