
/home/ubuntu/src/zopro-perf-work/g1-columns176/consumers/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

000000000007e7b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill>:
   7e7b0:	55                                              	push   rbp
   7e7b1:	48 89 e5                                        	mov    rbp,rsp
   7e7b4:	41 57                                           	push   r15
   7e7b6:	41 56                                           	push   r14
   7e7b8:	41 55                                           	push   r13
   7e7ba:	41 54                                           	push   r12
   7e7bc:	53                                              	push   rbx
   7e7bd:	48 83 e4 c0                                     	and    rsp,0xffffffffffffffc0
   7e7c1:	48 81 ec c0 0f 00 00                            	sub    rsp,0xfc0
   7e7c8:	48 c7 04 24 00 00 00 00                         	mov    QWORD PTR [rsp],0x0
   7e7d0:	48 81 ec 00 04 00 00                            	sub    rsp,0x400
   7e7d7:	48 89 94 24 78 06 00 00                         	mov    QWORD PTR [rsp+0x678],rdx
   7e7df:	4c 89 84 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],r8
   7e7e7:	4c 39 c2                                        	cmp    rdx,r8
   7e7ea:	0f 85 d5 62 00 00                               	jne    84ac5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6315>
   7e7f0:	48 89 d0                                        	mov    rax,rdx
   7e7f3:	48 c1 e8 1f                                     	shr    rax,0x1f
   7e7f7:	48 89 d3                                        	mov    rbx,rdx
   7e7fa:	0f 85 e3 62 00 00                               	jne    84ae3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6333>
   7e800:	4d 89 cf                                        	mov    r15,r9
   7e803:	49 83 f9 16                                     	cmp    r9,0x16
   7e807:	0f 83 ee 62 00 00                               	jae    84afb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x634b>
   7e80d:	49 89 cc                                        	mov    r12,rcx
   7e810:	48 89 74 24 50                                  	mov    QWORD PTR [rsp+0x50],rsi
   7e815:	48 89 bc 24 88 01 00 00                         	mov    QWORD PTR [rsp+0x188],rdi
   7e81d:	bf 00 40 00 00                                  	mov    edi,0x4000
   7e822:	be 01 00 00 00                                  	mov    esi,0x1
   7e827:	ff 15 db e5 01 00                               	call   QWORD PTR [rip+0x1e5db]        # 9ce08 <calloc@GLIBC_2.2.5>
   7e82d:	48 89 44 24 38                                  	mov    QWORD PTR [rsp+0x38],rax
   7e832:	48 85 c0                                        	test   rax,rax
   7e835:	0f 84 69 64 00 00                               	je     84ca4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x64f4>
   7e83b:	48 85 db                                        	test   rbx,rbx
   7e83e:	0f 84 02 01 00 00                               	je     7e946 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x196>
   7e844:	4a 8d 04 bd 00 00 00 00                         	lea    rax,[r15*4+0x0]
   7e84c:	4c 8b 4c 24 50                                  	mov    r9,QWORD PTR [rsp+0x50]
   7e851:	48 8d 34 40                                     	lea    rsi,[rax+rax*2]
   7e855:	48 8d 44 40 ff                                  	lea    rax,[rax+rax*2-0x1]
   7e85a:	48 89 c7                                        	mov    rdi,rax
   7e85d:	83 e0 3f                                        	and    eax,0x3f
   7e860:	48 c1 ef 06                                     	shr    rdi,0x6
   7e864:	48 83 f8 34                                     	cmp    rax,0x34
   7e868:	0f 93 c2                                        	setae  dl
   7e86b:	49 83 ff 11                                     	cmp    r15,0x11
   7e86f:	0f 92 c1                                        	setb   cl
   7e872:	45 31 c0                                        	xor    r8d,r8d
   7e875:	20 d1                                           	and    cl,dl
   7e877:	ba 01 00 00 00                                  	mov    edx,0x1
   7e87c:	29 f2                                           	sub    edx,esi
   7e87e:	49 8d 74 fc 08                                  	lea    rsi,[r12+rdi*8+0x8]
   7e883:	48 89 df                                        	mov    rdi,rbx
   7e886:	48 c1 e7 05                                     	shl    rdi,0x5
   7e88a:	83 e2 3d                                        	and    edx,0x3d
   7e88d:	eb 12                                           	jmp    7e8a1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xf1>
   7e88f:	90                                              	nop
   7e890:	49 83 c0 20                                     	add    r8,0x20
   7e894:	49 83 c1 40                                     	add    r9,0x40
   7e898:	4c 39 c7                                        	cmp    rdi,r8
   7e89b:	0f 84 a5 00 00 00                               	je     7e946 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x196>
   7e8a1:	4d 85 ff                                        	test   r15,r15
   7e8a4:	74 3a                                           	je     7e8e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x130>
   7e8a6:	c4 22 fb f7 54 06 f8                            	shrx   r10,QWORD PTR [rsi+r8*1-0x8],rax
   7e8ad:	84 c9                                           	test   cl,cl
   7e8af:	74 09                                           	je     7e8ba <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x10a>
   7e8b1:	c4 22 e9 f7 1c 06                               	shlx   r11,QWORD PTR [rsi+r8*1],rdx
   7e8b7:	4d 09 da                                        	or     r10,r11
   7e8ba:	45 89 d3                                        	mov    r11d,r10d
   7e8bd:	41 81 e3 ff 1f 00 00                            	and    r11d,0x1fff
   7e8c4:	41 ff c3                                        	inc    r11d
   7e8c7:	41 d1 eb                                        	shr    r11d,1
   7e8ca:	41 81 e2 00 10 00 00                            	and    r10d,0x1000
   7e8d1:	4d 39 d3                                        	cmp    r11,r10
   7e8d4:	74 ba                                           	je     7e890 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe0>
   7e8d6:	eb 23                                           	jmp    7e8fb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x14b>
   7e8d8:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   7e8e0:	4f 8b 1c 04                                     	mov    r11,QWORD PTR [r12+r8*1]
   7e8e4:	41 81 e3 ff 0f 00 00                            	and    r11d,0xfff
   7e8eb:	47 8d 14 1b                                     	lea    r10d,[r11+r11*1]
   7e8ef:	41 81 e2 00 10 00 00                            	and    r10d,0x1000
   7e8f6:	4d 39 d3                                        	cmp    r11,r10
   7e8f9:	74 95                                           	je     7e890 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe0>
   7e8fb:	c4 c1 7e 6f 01                                  	vmovdqu ymm0,YMMWORD PTR [r9]
   7e900:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7e905:	75 11                                           	jne    7e918 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x168>
   7e907:	c4 c1 7e 6f 41 20                               	vmovdqu ymm0,YMMWORD PTR [r9+0x20]
   7e90d:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7e912:	0f 84 78 ff ff ff                               	je     7e890 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe0>
   7e918:	45 29 d3                                        	sub    r11d,r10d
   7e91b:	45 89 da                                        	mov    r10d,r11d
   7e91e:	66 41 f7 da                                     	neg    r10w
   7e922:	66 45 0f 48 d3                                  	cmovs  r10w,r11w
   7e927:	45 0f b7 d2                                     	movzx  r10d,r10w
   7e92b:	66 41 81 fa 00 08                               	cmp    r10w,0x800
   7e931:	0f 87 83 62 00 00                               	ja     84bba <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x640a>
   7e937:	4c 8b 5c 24 38                                  	mov    r11,QWORD PTR [rsp+0x38]
   7e93c:	4b ff 44 d3 f8                                  	inc    QWORD PTR [r11+r10*8-0x8]
   7e941:	e9 4a ff ff ff                                  	jmp    7e890 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe0>
   7e946:	48 8b 74 24 38                                  	mov    rsi,QWORD PTR [rsp+0x38]
   7e94b:	48 8d bc 24 28 02 00 00                         	lea    rdi,[rsp+0x228]
   7e953:	ba 00 08 00 00                                  	mov    edx,0x800
   7e958:	c5 f8 77                                        	vzeroupper
   7e95b:	e8 30 6a 00 00                                  	call   85390 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns14prefix_offsets>
   7e960:	4c 8b ac 24 38 02 00 00                         	mov    r13,QWORD PTR [rsp+0x238]
   7e968:	49 81 fd ff 07 00 00                            	cmp    r13,0x7ff
   7e96f:	0f 86 35 61 00 00                               	jbe    84aaa <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62fa>
   7e975:	4c 8b b4 24 30 02 00 00                         	mov    r14,QWORD PTR [rsp+0x230]
   7e97d:	bf 00 40 00 00                                  	mov    edi,0x4000
   7e982:	ff 15 50 e4 01 00                               	call   QWORD PTR [rip+0x1e450]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7e988:	48 85 c0                                        	test   rax,rax
   7e98b:	0f 84 22 63 00 00                               	je     84cb3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6503>
   7e991:	ba 00 40 00 00                                  	mov    edx,0x4000
   7e996:	48 89 84 24 c8 00 00 00                         	mov    QWORD PTR [rsp+0xc8],rax
   7e99e:	48 89 c7                                        	mov    rdi,rax
   7e9a1:	4c 89 f6                                        	mov    rsi,r14
   7e9a4:	ff 15 36 e4 01 00                               	call   QWORD PTR [rip+0x1e436]        # 9cde0 <memcpy@GLIBC_2.14>
   7e9aa:	49 81 fd 00 08 00 00                            	cmp    r13,0x800
   7e9b1:	0f 84 10 63 00 00                               	je     84cc7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6517>
   7e9b7:	49 8b 96 00 40 00 00                            	mov    rdx,QWORD PTR [r14+0x4000]
   7e9be:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7e9c8:	4c 89 f6                                        	mov    rsi,r14
   7e9cb:	4c 8d 71 03                                     	lea    r14,[rcx+0x3]
   7e9cf:	4c 8d 2c 95 00 00 00 00                         	lea    r13,[rdx*4+0x0]
   7e9d7:	48 89 d0                                        	mov    rax,rdx
   7e9da:	48 c1 e8 3e                                     	shr    rax,0x3e
   7e9de:	0f 95 c0                                        	setne  al
   7e9e1:	4d 39 f5                                        	cmp    r13,r14
   7e9e4:	0f 97 c1                                        	seta   cl
   7e9e7:	08 c1                                           	or     cl,al
   7e9e9:	74 12                                           	je     7e9fd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x24d>
   7e9eb:	31 db                                           	xor    ebx,ebx
   7e9ed:	48 89 df                                        	mov    rdi,rbx
   7e9f0:	4c 89 ee                                        	mov    rsi,r13
   7e9f3:	e8 e9 0d fb ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7e9f8:	e9 20 64 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   7e9fd:	48 89 b4 24 c0 06 00 00                         	mov    QWORD PTR [rsp+0x6c0],rsi
   7ea05:	48 89 54 24 60                                  	mov    QWORD PTR [rsp+0x60],rdx
   7ea0a:	48 89 5c 24 20                                  	mov    QWORD PTR [rsp+0x20],rbx
   7ea0f:	4d 85 ed                                        	test   r13,r13
   7ea12:	74 49                                           	je     7ea5d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2ad>
   7ea14:	49 81 fd 00 00 02 00                            	cmp    r13,0x20000
   7ea1b:	72 60                                           	jb     7ea7d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2cd>
   7ea1d:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7ea27:	4c 89 ef                                        	mov    rdi,r13
   7ea2a:	48 83 cf 01                                     	or     rdi,0x1
   7ea2e:	bb 04 00 00 00                                  	mov    ebx,0x4
   7ea33:	48 83 c0 04                                     	add    rax,0x4
   7ea37:	48 39 c7                                        	cmp    rdi,rax
   7ea3a:	73 b1                                           	jae    7e9ed <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x23d>
   7ea3c:	be 01 00 00 00                                  	mov    esi,0x1
   7ea41:	ff 15 c1 e3 01 00                               	call   QWORD PTR [rip+0x1e3c1]        # 9ce08 <calloc@GLIBC_2.2.5>
   7ea47:	48 85 c0                                        	test   rax,rax
   7ea4a:	74 a1                                           	je     7e9ed <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x23d>
   7ea4c:	48 8b 5c 24 20                                  	mov    rbx,QWORD PTR [rsp+0x20]
   7ea51:	48 89 44 24 30                                  	mov    QWORD PTR [rsp+0x30],rax
   7ea56:	42 c6 04 28 00                                  	mov    BYTE PTR [rax+r13*1],0x0
   7ea5b:	eb 3c                                           	jmp    7ea99 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2e9>
   7ea5d:	b8 04 00 00 00                                  	mov    eax,0x4
   7ea62:	48 c7 84 24 b8 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xb8],0x0
   7ea6e:	48 89 44 24 30                                  	mov    QWORD PTR [rsp+0x30],rax
   7ea73:	48 85 db                                        	test   rbx,rbx
   7ea76:	75 37                                           	jne    7eaaf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2ff>
   7ea78:	e9 72 01 00 00                                  	jmp    7ebef <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x43f>
   7ea7d:	be 01 00 00 00                                  	mov    esi,0x1
   7ea82:	4c 89 ef                                        	mov    rdi,r13
   7ea85:	ff 15 7d e3 01 00                               	call   QWORD PTR [rip+0x1e37d]        # 9ce08 <calloc@GLIBC_2.2.5>
   7ea8b:	48 89 44 24 30                                  	mov    QWORD PTR [rsp+0x30],rax
   7ea90:	48 85 c0                                        	test   rax,rax
   7ea93:	0f 84 d2 62 00 00                               	je     84d6b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65bb>
   7ea99:	48 8b 44 24 60                                  	mov    rax,QWORD PTR [rsp+0x60]
   7ea9e:	48 89 84 24 b8 00 00 00                         	mov    QWORD PTR [rsp+0xb8],rax
   7eaa6:	48 85 db                                        	test   rbx,rbx
   7eaa9:	0f 84 40 01 00 00                               	je     7ebef <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x43f>
   7eaaf:	4a 8d 04 bd 00 00 00 00                         	lea    rax,[r15*4+0x0]
   7eab7:	4c 8b 5c 24 50                                  	mov    r11,QWORD PTR [rsp+0x50]
   7eabc:	4c 8b 8c 24 c8 00 00 00                         	mov    r9,QWORD PTR [rsp+0xc8]
   7eac4:	ba 01 00 00 00                                  	mov    edx,0x1
   7eac9:	4c 8d 04 40                                     	lea    r8,[rax+rax*2]
   7eacd:	48 8d 44 40 ff                                  	lea    rax,[rax+rax*2-0x1]
   7ead2:	48 89 c1                                        	mov    rcx,rax
   7ead5:	83 e0 3f                                        	and    eax,0x3f
   7ead8:	48 c1 e9 06                                     	shr    rcx,0x6
   7eadc:	48 83 f8 34                                     	cmp    rax,0x34
   7eae0:	40 0f 93 c7                                     	setae  dil
   7eae4:	49 83 ff 11                                     	cmp    r15,0x11
   7eae8:	40 0f 92 c6                                     	setb   sil
   7eaec:	44 29 c2                                        	sub    edx,r8d
   7eaef:	4c 8d 05 32 df 01 00                            	lea    r8,[rip+0x1df32]        # 9ca28 <__frame_dummy_init_array_entry+0x29c8>
   7eaf6:	45 31 d2                                        	xor    r10d,r10d
   7eaf9:	40 20 fe                                        	and    sil,dil
   7eafc:	83 e2 3d                                        	and    edx,0x3d
   7eaff:	4c 89 84 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],r8
   7eb07:	eb 3e                                           	jmp    7eb47 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x397>
   7eb09:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   7eb10:	48 c1 eb 3f                                     	shr    rbx,0x3f
   7eb14:	45 89 d5                                        	mov    r13d,r10d
   7eb17:	c1 e3 1f                                        	shl    ebx,0x1f
   7eb1a:	41 09 dd                                        	or     r13d,ebx
   7eb1d:	48 8b 5c 24 30                                  	mov    rbx,QWORD PTR [rsp+0x30]
   7eb22:	44 89 2c bb                                     	mov    DWORD PTR [rbx+rdi*4],r13d
   7eb26:	48 ff c7                                        	inc    rdi
   7eb29:	4b 89 7c f1 f8                                  	mov    QWORD PTR [r9+r14*8-0x8],rdi
   7eb2e:	4d 89 c6                                        	mov    r14,r8
   7eb31:	49 ff c2                                        	inc    r10
   7eb34:	49 83 c4 20                                     	add    r12,0x20
   7eb38:	49 83 c3 40                                     	add    r11,0x40
   7eb3c:	4c 39 54 24 20                                  	cmp    QWORD PTR [rsp+0x20],r10
   7eb41:	0f 84 a8 00 00 00                               	je     7ebef <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x43f>
   7eb47:	4d 85 ff                                        	test   r15,r15
   7eb4a:	74 34                                           	je     7eb80 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3d0>
   7eb4c:	c4 c2 fb f7 3c cc                               	shrx   rdi,QWORD PTR [r12+rcx*8],rax
   7eb52:	40 84 f6                                        	test   sil,sil
   7eb55:	74 0a                                           	je     7eb61 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3b1>
   7eb57:	c4 c2 e9 f7 5c cc 08                            	shlx   rbx,QWORD PTR [r12+rcx*8+0x8],rdx
   7eb5e:	48 09 df                                        	or     rdi,rbx
   7eb61:	89 fb                                           	mov    ebx,edi
   7eb63:	81 e3 ff 1f 00 00                               	and    ebx,0x1fff
   7eb69:	ff c3                                           	inc    ebx
   7eb6b:	d1 eb                                           	shr    ebx,1
   7eb6d:	81 e7 00 10 00 00                               	and    edi,0x1000
   7eb73:	48 29 fb                                        	sub    rbx,rdi
   7eb76:	74 b9                                           	je     7eb31 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x381>
   7eb78:	eb 1e                                           	jmp    7eb98 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3e8>
   7eb7a:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   7eb80:	49 8b 1c 24                                     	mov    rbx,QWORD PTR [r12]
   7eb84:	81 e3 ff 0f 00 00                               	and    ebx,0xfff
   7eb8a:	8d 3c 1b                                        	lea    edi,[rbx+rbx*1]
   7eb8d:	81 e7 00 10 00 00                               	and    edi,0x1000
   7eb93:	48 29 fb                                        	sub    rbx,rdi
   7eb96:	74 99                                           	je     7eb31 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x381>
   7eb98:	c4 c1 7e 6f 03                                  	vmovdqu ymm0,YMMWORD PTR [r11]
   7eb9d:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7eba2:	75 0d                                           	jne    7ebb1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x401>
   7eba4:	c4 c1 7e 6f 43 20                               	vmovdqu ymm0,YMMWORD PTR [r11+0x20]
   7ebaa:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ebaf:	74 80                                           	je     7eb31 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x381>
   7ebb1:	4d 89 f0                                        	mov    r8,r14
   7ebb4:	49 89 de                                        	mov    r14,rbx
   7ebb7:	49 f7 de                                        	neg    r14
   7ebba:	4c 0f 48 f3                                     	cmovs  r14,rbx
   7ebbe:	49 81 fe 00 08 00 00                            	cmp    r14,0x800
   7ebc5:	0f 87 4f 60 00 00                               	ja     84c1a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x646a>
   7ebcb:	4b 8b 7c f1 f8                                  	mov    rdi,QWORD PTR [r9+r14*8-0x8]
   7ebd0:	48 3b 7c 24 60                                  	cmp    rdi,QWORD PTR [rsp+0x60]
   7ebd5:	0f 82 35 ff ff ff                               	jb     7eb10 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x360>
   7ebdb:	48 8d 05 5e de 01 00                            	lea    rax,[rip+0x1de5e]        # 9ca40 <__frame_dummy_init_array_entry+0x29e0>
   7ebe2:	48 89 84 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],rax
   7ebea:	e9 3b 60 00 00                                  	jmp    84c2a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x647a>
   7ebef:	48 8b bc 24 c8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc8]
   7ebf7:	c5 f8 77                                        	vzeroupper
   7ebfa:	ff 15 c0 e1 01 00                               	call   QWORD PTR [rip+0x1e1c0]        # 9cdc0 <free@GLIBC_2.2.5>
   7ec00:	bf 00 40 00 00                                  	mov    edi,0x4000
   7ec05:	ff 15 cd e1 01 00                               	call   QWORD PTR [rip+0x1e1cd]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7ec0b:	48 89 44 24 70                                  	mov    QWORD PTR [rsp+0x70],rax
   7ec10:	48 85 c0                                        	test   rax,rax
   7ec13:	0f 84 ea 60 00 00                               	je     84d03 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6553>
   7ec19:	62 f2 fd 48 59 05 1d 89 f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff8891d]        # 7540 <GCC_except_table746+0x1cc>
   7ec23:	4c 8b 7c 24 38                                  	mov    r15,QWORD PTR [rsp+0x38]
   7ec28:	48 8b 74 24 70                                  	mov    rsi,QWORD PTR [rsp+0x70]
   7ec2d:	b8 38 00 00 00                                  	mov    eax,0x38
   7ec32:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7ec40:	62 d1 fe 48 6f 4c c7 f9                         	vmovdqu64 zmm1,ZMMWORD PTR [r15+rax*8-0x1c0]
   7ec48:	62 d1 fe 48 6f 54 c7 fa                         	vmovdqu64 zmm2,ZMMWORD PTR [r15+rax*8-0x180]
   7ec50:	62 d1 fe 48 6f 5c c7 fb                         	vmovdqu64 zmm3,ZMMWORD PTR [r15+rax*8-0x140]
   7ec58:	62 d1 fe 48 6f 64 c7 fc                         	vmovdqu64 zmm4,ZMMWORD PTR [r15+rax*8-0x100]
   7ec60:	62 51 fe 48 6f 4c c7 fd                         	vmovdqu64 zmm9,ZMMWORD PTR [r15+rax*8-0xc0]
   7ec68:	62 f1 d5 48 73 d1 03                            	vpsrlq zmm5,zmm1,0x3
   7ec6f:	62 f2 f5 48 27 c0                               	vptestmq k0,zmm1,zmm0
   7ec75:	62 f1 cd 48 73 d2 03                            	vpsrlq zmm6,zmm2,0x3
   7ec7c:	62 f2 ed 48 27 c8                               	vptestmq k1,zmm2,zmm0
   7ec82:	62 f1 c5 48 73 d3 03                            	vpsrlq zmm7,zmm3,0x3
   7ec89:	62 f2 e5 48 27 d0                               	vptestmq k2,zmm3,zmm0
   7ec8f:	62 f1 bd 48 73 d4 03                            	vpsrlq zmm8,zmm4,0x3
   7ec96:	62 f2 dd 48 27 d8                               	vptestmq k3,zmm4,zmm0
   7ec9c:	62 f2 fe 48 38 c8                               	vpmovm2q zmm1,k0
   7eca2:	62 f1 d5 48 fb c9                               	vpsubq zmm1,zmm5,zmm1
   7eca8:	62 f2 fe 48 38 d1                               	vpmovm2q zmm2,k1
   7ecae:	62 f2 fe 48 38 da                               	vpmovm2q zmm3,k2
   7ecb4:	62 f2 fe 48 38 e3                               	vpmovm2q zmm4,k3
   7ecba:	62 f1 cd 48 fb d2                               	vpsubq zmm2,zmm6,zmm2
   7ecc0:	62 f1 c5 48 fb db                               	vpsubq zmm3,zmm7,zmm3
   7ecc6:	62 f1 bd 48 fb e4                               	vpsubq zmm4,zmm8,zmm4
   7eccc:	62 d1 d5 48 73 d1 03                            	vpsrlq zmm5,zmm9,0x3
   7ecd3:	62 f2 b5 48 27 c0                               	vptestmq k0,zmm9,zmm0
   7ecd9:	62 f1 fe 48 7f 4c c6 f9                         	vmovdqu64 ZMMWORD PTR [rsi+rax*8-0x1c0],zmm1
   7ece1:	62 f1 fe 48 7f 54 c6 fa                         	vmovdqu64 ZMMWORD PTR [rsi+rax*8-0x180],zmm2
   7ece9:	62 f1 fe 48 7f 5c c6 fb                         	vmovdqu64 ZMMWORD PTR [rsi+rax*8-0x140],zmm3
   7ecf1:	62 d1 fe 48 6f 54 c7 fe                         	vmovdqu64 zmm2,ZMMWORD PTR [r15+rax*8-0x80]
   7ecf9:	62 d1 fe 48 6f 5c c7 ff                         	vmovdqu64 zmm3,ZMMWORD PTR [r15+rax*8-0x40]
   7ed01:	62 f1 fe 48 7f 64 c6 fc                         	vmovdqu64 ZMMWORD PTR [rsi+rax*8-0x100],zmm4
   7ed09:	62 d1 fe 48 6f 24 c7                            	vmovdqu64 zmm4,ZMMWORD PTR [r15+rax*8]
   7ed10:	62 f2 fe 48 38 c8                               	vpmovm2q zmm1,k0
   7ed16:	62 f1 d5 48 fb c9                               	vpsubq zmm1,zmm5,zmm1
   7ed1c:	62 f1 fe 48 7f 4c c6 fd                         	vmovdqu64 ZMMWORD PTR [rsi+rax*8-0xc0],zmm1
   7ed24:	62 f1 cd 48 73 d2 03                            	vpsrlq zmm6,zmm2,0x3
   7ed2b:	62 f2 ed 48 27 c8                               	vptestmq k1,zmm2,zmm0
   7ed31:	62 f1 c5 48 73 d3 03                            	vpsrlq zmm7,zmm3,0x3
   7ed38:	62 f2 e5 48 27 d0                               	vptestmq k2,zmm3,zmm0
   7ed3e:	62 f1 bd 48 73 d4 03                            	vpsrlq zmm8,zmm4,0x3
   7ed45:	62 f2 dd 48 27 d8                               	vptestmq k3,zmm4,zmm0
   7ed4b:	62 f2 fe 48 38 d1                               	vpmovm2q zmm2,k1
   7ed51:	62 f2 fe 48 38 da                               	vpmovm2q zmm3,k2
   7ed57:	62 f2 fe 48 38 e3                               	vpmovm2q zmm4,k3
   7ed5d:	62 f1 cd 48 fb d2                               	vpsubq zmm2,zmm6,zmm2
   7ed63:	62 f1 c5 48 fb db                               	vpsubq zmm3,zmm7,zmm3
   7ed69:	62 f1 bd 48 fb e4                               	vpsubq zmm4,zmm8,zmm4
   7ed6f:	62 f1 fe 48 7f 54 c6 fe                         	vmovdqu64 ZMMWORD PTR [rsi+rax*8-0x80],zmm2
   7ed77:	62 f1 fe 48 7f 5c c6 ff                         	vmovdqu64 ZMMWORD PTR [rsi+rax*8-0x40],zmm3
   7ed7f:	62 f1 fe 48 7f 24 c6                            	vmovdqu64 ZMMWORD PTR [rsi+rax*8],zmm4
   7ed86:	48 83 c0 40                                     	add    rax,0x40
   7ed8a:	48 3d 38 08 00 00                               	cmp    rax,0x838
   7ed90:	0f 85 aa fe ff ff                               	jne    7ec40 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x490>
   7ed96:	48 8d bc 24 90 01 00 00                         	lea    rdi,[rsp+0x190]
   7ed9e:	ba 00 08 00 00                                  	mov    edx,0x800
   7eda3:	c5 f8 77                                        	vzeroupper
   7eda6:	e8 e5 65 00 00                                  	call   85390 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns14prefix_offsets>
   7edab:	48 8b b4 24 a0 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x1a0]
   7edb3:	48 81 fe 01 08 00 00                            	cmp    rsi,0x801
   7edba:	0f 82 5a 5f 00 00                               	jb     84d1a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x656a>
   7edc0:	4c 8b bc 24 98 01 00 00                         	mov    r15,QWORD PTR [rsp+0x198]
   7edc8:	49 8b 97 00 40 00 00                            	mov    rdx,QWORD PTR [r15+0x4000]
   7edcf:	48 85 d2                                        	test   rdx,rdx
   7edd2:	74 41                                           	je     7ee15 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x665>
   7edd4:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7edde:	4c 8d 3c d5 00 00 00 00                         	lea    r15,[rdx*8+0x0]
   7ede6:	48 89 d0                                        	mov    rax,rdx
   7ede9:	48 c1 e8 3d                                     	shr    rax,0x3d
   7eded:	48 8d 59 ff                                     	lea    rbx,[rcx-0x1]
   7edf1:	0f 95 c0                                        	setne  al
   7edf4:	49 39 df                                        	cmp    r15,rbx
   7edf7:	0f 97 c1                                        	seta   cl
   7edfa:	08 c1                                           	or     cl,al
   7edfc:	0f 84 ca 01 00 00                               	je     7efcc <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x81c>
   7ee02:	45 31 e4                                        	xor    r12d,r12d
   7ee05:	4c 89 fe                                        	mov    rsi,r15
   7ee08:	4c 89 e7                                        	mov    rdi,r12
   7ee0b:	e8 d1 09 fb ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7ee10:	e9 08 60 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   7ee15:	bf 01 00 02 00                                  	mov    edi,0x20001
   7ee1a:	ff 15 b8 df 01 00                               	call   QWORD PTR [rip+0x1dfb8]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7ee20:	48 85 c0                                        	test   rax,rax
   7ee23:	0f 84 1b 5f 00 00                               	je     84d44 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6594>
   7ee29:	48 8b bc 24 88 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x188]
   7ee31:	4c 8b b4 24 c0 06 00 00                         	mov    r14,QWORD PTR [rsp+0x6c0]
   7ee39:	b9 c0 01 00 00                                  	mov    ecx,0x1c0
   7ee3e:	48 8d 94 24 60 02 00 00                         	lea    rdx,[rsp+0x260]
   7ee46:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7ee4a:	c6 80 00 00 02 00 00                            	mov    BYTE PTR [rax+0x20000],0x0
   7ee51:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00    	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7ee60:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ee64:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   7ee6d:	48 8d 34 08                                     	lea    rsi,[rax+rcx*1]
   7ee71:	62 f1 7c 48 10 4c 24 09                         	vmovups zmm1,ZMMWORD PTR [rsp+0x240]
   7ee79:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ee7d:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   7ee86:	62 f1 7c 48 10 5c 24 09                         	vmovups zmm3,ZMMWORD PTR [rsp+0x240]
   7ee8e:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ee92:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   7ee9b:	62 f1 7c 48 10 54 24 09                         	vmovups zmm2,ZMMWORD PTR [rsp+0x240]
   7eea3:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7eea7:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   7eeb0:	62 f1 7c 48 11 4c 08 f9                         	vmovups ZMMWORD PTR [rax+rcx*1-0x1c0],zmm1
   7eeb8:	62 f1 7c 48 11 5c 08 fa                         	vmovups ZMMWORD PTR [rax+rcx*1-0x180],zmm3
   7eec0:	62 f1 7c 48 10 5c 24 09                         	vmovups zmm3,ZMMWORD PTR [rsp+0x240]
   7eec8:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7eecc:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   7eed5:	62 f1 7c 48 11 54 08 fb                         	vmovups ZMMWORD PTR [rax+rcx*1-0x140],zmm2
   7eedd:	62 f1 7c 48 10 54 24 09                         	vmovups zmm2,ZMMWORD PTR [rsp+0x240]
   7eee5:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7eee9:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   7eef2:	62 f1 7c 48 11 5c 08 fc                         	vmovups ZMMWORD PTR [rax+rcx*1-0x100],zmm3
   7eefa:	62 f1 fe 48 6f 5c 24 09                         	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x240]
   7ef02:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ef06:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   7ef0f:	62 f1 7c 48 11 54 08 fd                         	vmovups ZMMWORD PTR [rax+rcx*1-0xc0],zmm2
   7ef17:	62 f1 fe 48 6f 54 24 09                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x240]
   7ef1f:	62 f1 fe 48 7f 5c 08 fe                         	vmovdqu64 ZMMWORD PTR [rax+rcx*1-0x80],zmm3
   7ef27:	62 f1 fe 48 7f 54 08 ff                         	vmovdqu64 ZMMWORD PTR [rax+rcx*1-0x40],zmm2
   7ef2f:	48 81 f9 c0 ff 01 00                            	cmp    rcx,0x1ffc0
   7ef36:	74 27                                           	je     7ef5f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x7af>
   7ef38:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ef3c:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   7ef45:	48 81 c1 00 02 00 00                            	add    rcx,0x200
   7ef4c:	62 f1 fe 48 6f 4c 24 09                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x240]
   7ef54:	62 f1 fe 48 7f 0e                               	vmovdqu64 ZMMWORD PTR [rsi],zmm1
   7ef5a:	e9 01 ff ff ff                                  	jmp    7ee60 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b0>
   7ef5f:	48 c7 07 00 08 00 00                            	mov    QWORD PTR [rdi],0x800
   7ef66:	48 89 47 08                                     	mov    QWORD PTR [rdi+0x8],rax
   7ef6a:	48 8b 84 24 90 01 00 00                         	mov    rax,QWORD PTR [rsp+0x190]
   7ef72:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7ef76:	62 f1 fe 48 7f 06                               	vmovdqu64 ZMMWORD PTR [rsi],zmm0
   7ef7c:	48 c7 47 10 00 08 00 00                         	mov    QWORD PTR [rdi+0x10],0x800
   7ef84:	48 85 c0                                        	test   rax,rax
   7ef87:	0f 84 b8 00 00 00                               	je     7f045 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x895>
   7ef8d:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7ef93:	0f 86 9e 00 00 00                               	jbe    7f037 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x887>
   7ef99:	48 c1 e0 03                                     	shl    rax,0x3
   7ef9d:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7efa7:	48 89 c6                                        	mov    rsi,rax
   7efaa:	48 83 ce 01                                     	or     rsi,0x1
   7efae:	48 39 ce                                        	cmp    rsi,rcx
   7efb1:	0f 83 ed 5d 00 00                               	jae    84da4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65f4>
   7efb7:	41 80 3c 07 01                                  	cmp    BYTE PTR [r15+rax*1],0x1
   7efbc:	75 7b                                           	jne    7f039 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x889>
   7efbe:	4c 89 ff                                        	mov    rdi,r15
   7efc1:	c5 f8 77                                        	vzeroupper
   7efc4:	ff 15 ee dd 01 00                               	call   QWORD PTR [rip+0x1ddee]        # 9cdb8 <munmap@GLIBC_2.2.5>
   7efca:	eb 79                                           	jmp    7f045 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x895>
   7efcc:	48 89 54 24 18                                  	mov    QWORD PTR [rsp+0x18],rdx
   7efd1:	4c 89 b4 24 c0 0b 00 00                         	mov    QWORD PTR [rsp+0xbc0],r14
   7efd9:	49 81 ff ff ff 01 00                            	cmp    r15,0x1ffff
   7efe0:	76 3e                                           	jbe    7f020 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x870>
   7efe2:	4c 89 ff                                        	mov    rdi,r15
   7efe5:	48 83 cf 01                                     	or     rdi,0x1
   7efe9:	41 bc 08 00 00 00                               	mov    r12d,0x8
   7efef:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7eff9:	48 39 c7                                        	cmp    rdi,rax
   7effc:	0f 83 03 fe ff ff                               	jae    7ee05 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x655>
   7f002:	ff 15 d0 dd 01 00                               	call   QWORD PTR [rip+0x1ddd0]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7f008:	48 85 c0                                        	test   rax,rax
   7f00b:	0f 84 f4 fd ff ff                               	je     7ee05 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x655>
   7f011:	4c 8b 74 24 18                                  	mov    r14,QWORD PTR [rsp+0x18]
   7f016:	42 c6 04 38 00                                  	mov    BYTE PTR [rax+r15*1],0x0
   7f01b:	e9 3f 01 00 00                                  	jmp    7f15f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x9af>
   7f020:	4d 85 ff                                        	test   r15,r15
   7f023:	0f 84 ef 00 00 00                               	je     7f118 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x968>
   7f029:	4c 89 ff                                        	mov    rdi,r15
   7f02c:	ff 15 a6 dd 01 00                               	call   QWORD PTR [rip+0x1dda6]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7f032:	e9 1a 01 00 00                                  	jmp    7f151 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x9a1>
   7f037:	eb 00                                           	jmp    7f039 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x889>
   7f039:	4c 89 ff                                        	mov    rdi,r15
   7f03c:	c5 f8 77                                        	vzeroupper
   7f03f:	ff 15 7b dd 01 00                               	call   QWORD PTR [rip+0x1dd7b]        # 9cdc0 <free@GLIBC_2.2.5>
   7f045:	48 8b 7c 24 70                                  	mov    rdi,QWORD PTR [rsp+0x70]
   7f04a:	c5 f8 77                                        	vzeroupper
   7f04d:	ff 15 6d dd 01 00                               	call   QWORD PTR [rip+0x1dd6d]        # 9cdc0 <free@GLIBC_2.2.5>
   7f053:	48 8b 8c 24 b8 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xb8]
   7f05b:	48 8b 5c 24 38                                  	mov    rbx,QWORD PTR [rsp+0x38]
   7f060:	48 85 c9                                        	test   rcx,rcx
   7f063:	74 4b                                           	je     7f0b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x900>
   7f065:	48 81 f9 ff 7f 00 00                            	cmp    rcx,0x7fff
   7f06c:	76 35                                           	jbe    7f0a3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8f3>
   7f06e:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7f078:	48 c1 e1 02                                     	shl    rcx,0x2
   7f07c:	48 89 ce                                        	mov    rsi,rcx
   7f07f:	48 83 ce 01                                     	or     rsi,0x1
   7f083:	48 83 c0 04                                     	add    rax,0x4
   7f087:	48 39 c6                                        	cmp    rsi,rax
   7f08a:	0f 83 1c 5d 00 00                               	jae    84dac <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65fc>
   7f090:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   7f095:	80 3c 0f 01                                     	cmp    BYTE PTR [rdi+rcx*1],0x1
   7f099:	75 0f                                           	jne    7f0aa <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8fa>
   7f09b:	ff 15 17 dd 01 00                               	call   QWORD PTR [rip+0x1dd17]        # 9cdb8 <munmap@GLIBC_2.2.5>
   7f0a1:	eb 0d                                           	jmp    7f0b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x900>
   7f0a3:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   7f0a8:	eb 00                                           	jmp    7f0aa <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8fa>
   7f0aa:	ff 15 10 dd 01 00                               	call   QWORD PTR [rip+0x1dd10]        # 9cdc0 <free@GLIBC_2.2.5>
   7f0b0:	48 8b 84 24 28 02 00 00                         	mov    rax,QWORD PTR [rsp+0x228]
   7f0b8:	48 85 c0                                        	test   rax,rax
   7f0bb:	74 43                                           	je     7f100 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x950>
   7f0bd:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7f0c3:	76 30                                           	jbe    7f0f5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x945>
   7f0c5:	48 c1 e0 03                                     	shl    rax,0x3
   7f0c9:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7f0d3:	48 89 c6                                        	mov    rsi,rax
   7f0d6:	48 83 ce 01                                     	or     rsi,0x1
   7f0da:	48 39 ce                                        	cmp    rsi,rcx
   7f0dd:	0f 83 ce 5c 00 00                               	jae    84db1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6601>
   7f0e3:	41 80 3c 06 01                                  	cmp    BYTE PTR [r14+rax*1],0x1
   7f0e8:	75 0d                                           	jne    7f0f7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x947>
   7f0ea:	4c 89 f7                                        	mov    rdi,r14
   7f0ed:	ff 15 c5 dc 01 00                               	call   QWORD PTR [rip+0x1dcc5]        # 9cdb8 <munmap@GLIBC_2.2.5>
   7f0f3:	eb 0b                                           	jmp    7f100 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x950>
   7f0f5:	eb 00                                           	jmp    7f0f7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x947>
   7f0f7:	4c 89 f7                                        	mov    rdi,r14
   7f0fa:	ff 15 c0 dc 01 00                               	call   QWORD PTR [rip+0x1dcc0]        # 9cdc0 <free@GLIBC_2.2.5>
   7f100:	48 89 df                                        	mov    rdi,rbx
   7f103:	ff 15 b7 dc 01 00                               	call   QWORD PTR [rip+0x1dcb7]        # 9cdc0 <free@GLIBC_2.2.5>
   7f109:	48 8d 65 d8                                     	lea    rsp,[rbp-0x28]
   7f10d:	5b                                              	pop    rbx
   7f10e:	41 5c                                           	pop    r12
   7f110:	41 5d                                           	pop    r13
   7f112:	41 5e                                           	pop    r14
   7f114:	41 5f                                           	pop    r15
   7f116:	5d                                              	pop    rbp
   7f117:	c3                                              	ret
   7f118:	48 c7 84 24 40 02 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x240],0x0
   7f124:	48 8d bc 24 40 02 00 00                         	lea    rdi,[rsp+0x240]
   7f12c:	be 08 00 00 00                                  	mov    esi,0x8
   7f131:	31 d2                                           	xor    edx,edx
   7f133:	41 bc 08 00 00 00                               	mov    r12d,0x8
   7f139:	ff 15 c1 dc 01 00                               	call   QWORD PTR [rip+0x1dcc1]        # 9ce00 <posix_memalign@GLIBC_2.2.5>
   7f13f:	31 f6                                           	xor    esi,esi
   7f141:	85 c0                                           	test   eax,eax
   7f143:	0f 85 bf fc ff ff                               	jne    7ee08 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x658>
   7f149:	48 8b 84 24 40 02 00 00                         	mov    rax,QWORD PTR [rsp+0x240]
   7f151:	4c 8b 74 24 18                                  	mov    r14,QWORD PTR [rsp+0x18]
   7f156:	48 85 c0                                        	test   rax,rax
   7f159:	0f 84 3a 5c 00 00                               	je     84d99 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65e9>
   7f15f:	4c 89 b4 24 d0 00 00 00                         	mov    QWORD PTR [rsp+0xd0],r14
   7f167:	48 89 84 24 d8 00 00 00                         	mov    QWORD PTR [rsp+0xd8],rax
   7f16f:	48 89 9c 24 00 0c 00 00                         	mov    QWORD PTR [rsp+0xc00],rbx
   7f177:	48 89 84 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],rax
   7f17f:	48 c7 84 24 e0 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xe0],0x0
   7f18b:	49 81 fe 00 00 02 00                            	cmp    r14,0x20000
   7f192:	72 1f                                           	jb     7f1b3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa03>
   7f194:	49 8d 7e 01                                     	lea    rdi,[r14+0x1]
   7f198:	ff 15 3a dc 01 00                               	call   QWORD PTR [rip+0x1dc3a]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7f19e:	48 8b 5c 24 38                                  	mov    rbx,QWORD PTR [rsp+0x38]
   7f1a3:	48 85 c0                                        	test   rax,rax
   7f1a6:	0f 84 c9 5b 00 00                               	je     84d75 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65c5>
   7f1ac:	42 c6 04 30 00                                  	mov    BYTE PTR [rax+r14*1],0x0
   7f1b1:	eb 17                                           	jmp    7f1ca <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa1a>
   7f1b3:	4c 89 f7                                        	mov    rdi,r14
   7f1b6:	ff 15 1c dc 01 00                               	call   QWORD PTR [rip+0x1dc1c]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7f1bc:	48 8b 5c 24 38                                  	mov    rbx,QWORD PTR [rsp+0x38]
   7f1c1:	48 85 c0                                        	test   rax,rax
   7f1c4:	0f 84 ab 5b 00 00                               	je     84d75 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65c5>
   7f1ca:	4c 89 74 24 78                                  	mov    QWORD PTR [rsp+0x78],r14
   7f1cf:	48 89 84 24 80 00 00 00                         	mov    QWORD PTR [rsp+0x80],rax
   7f1d7:	31 c9                                           	xor    ecx,ecx
   7f1d9:	48 c7 84 24 88 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x88],0x0
   7f1e5:	48 c7 84 24 00 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x100],0x0
   7f1f1:	eb 22                                           	jmp    7f215 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa65>
   7f1f3:	66 66 66 66 2e 0f 1f 84 00 00 00 00 00          	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7f200:	48 8b 5c 24 38                                  	mov    rbx,QWORD PTR [rsp+0x38]
   7f205:	48 ff c1                                        	inc    rcx
   7f208:	48 81 f9 00 08 00 00                            	cmp    rcx,0x800
   7f20f:	0f 84 eb 00 00 00                               	je     7f300 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xb50>
   7f215:	4c 8b 34 cb                                     	mov    r14,QWORD PTR [rbx+rcx*8]
   7f219:	4d 85 f6                                        	test   r14,r14
   7f21c:	74 e2                                           	je     7f200 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa50>
   7f21e:	44 89 f0                                        	mov    eax,r14d
   7f221:	83 e0 07                                        	and    eax,0x7
   7f224:	4d 89 f4                                        	mov    r12,r14
   7f227:	49 c1 ec 03                                     	shr    r12,0x3
   7f22b:	48 89 4c 24 08                                  	mov    QWORD PTR [rsp+0x8],rcx
   7f230:	48 83 f8 01                                     	cmp    rax,0x1
   7f234:	49 83 dc ff                                     	sbb    r12,0xffffffffffffffff
   7f238:	45 31 ed                                        	xor    r13d,r13d
   7f23b:	eb 2f                                           	jmp    7f26c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xabc>
   7f23d:	0f 1f 00                                        	nop    DWORD PTR [rax]
   7f240:	48 8b 84 24 80 00 00 00                         	mov    rax,QWORD PTR [rsp+0x80]
   7f248:	48 8b 4c 24 08                                  	mov    rcx,QWORD PTR [rsp+0x8]
   7f24d:	49 ff cc                                        	dec    r12
   7f250:	49 83 c6 f8                                     	add    r14,0xfffffffffffffff8
   7f254:	49 83 c5 08                                     	add    r13,0x8
   7f258:	42 88 1c 38                                     	mov    BYTE PTR [rax+r15*1],bl
   7f25c:	49 ff c7                                        	inc    r15
   7f25f:	4c 89 bc 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],r15
   7f267:	4d 85 e4                                        	test   r12,r12
   7f26a:	74 94                                           	je     7f200 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa50>
   7f26c:	48 8b 84 24 c0 06 00 00                         	mov    rax,QWORD PTR [rsp+0x6c0]
   7f274:	4c 8b 3c c8                                     	mov    r15,QWORD PTR [rax+rcx*8]
   7f278:	48 8b 84 24 00 01 00 00                         	mov    rax,QWORD PTR [rsp+0x100]
   7f280:	4d 01 ef                                        	add    r15,r13
   7f283:	48 3b 84 24 d0 00 00 00                         	cmp    rax,QWORD PTR [rsp+0xd0]
   7f28b:	48 8b 84 24 80 06 00 00                         	mov    rax,QWORD PTR [rsp+0x680]
   7f293:	75 15                                           	jne    7f2aa <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xafa>
   7f295:	48 8d bc 24 d0 00 00 00                         	lea    rdi,[rsp+0xd0]
   7f29d:	e8 de 74 fb ff                                  	call   36780 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCsii3nOZuAKF_15crossbeam_utils>
   7f2a2:	48 8b 84 24 d8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xd8]
   7f2aa:	48 8b 8c 24 00 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x100]
   7f2b2:	bb 08 00 00 00                                  	mov    ebx,0x8
   7f2b7:	48 89 84 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],rax
   7f2bf:	4c 89 3c c8                                     	mov    QWORD PTR [rax+rcx*8],r15
   7f2c3:	48 ff c1                                        	inc    rcx
   7f2c6:	49 83 fe 08                                     	cmp    r14,0x8
   7f2ca:	4c 8b bc 24 88 00 00 00                         	mov    r15,QWORD PTR [rsp+0x88]
   7f2d2:	49 0f 42 de                                     	cmovb  rbx,r14
   7f2d6:	48 89 8c 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],rcx
   7f2de:	48 89 8c 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],rcx
   7f2e6:	4c 3b 7c 24 78                                  	cmp    r15,QWORD PTR [rsp+0x78]
   7f2eb:	0f 85 4f ff ff ff                               	jne    7f240 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa90>
   7f2f1:	48 8d 7c 24 78                                  	lea    rdi,[rsp+0x78]
   7f2f6:	e8 65 08 fb ff                                  	call   2fb60 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
   7f2fb:	e9 40 ff ff ff                                  	jmp    7f240 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa90>
   7f300:	48 8b 84 24 28 02 00 00                         	mov    rax,QWORD PTR [rsp+0x228]
   7f308:	48 85 c0                                        	test   rax,rax
   7f30b:	74 4c                                           	je     7f359 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xba9>
   7f30d:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7f313:	76 34                                           	jbe    7f349 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xb99>
   7f315:	48 8b bc 24 c0 06 00 00                         	mov    rdi,QWORD PTR [rsp+0x6c0]
   7f31d:	48 c1 e0 03                                     	shl    rax,0x3
   7f321:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7f32b:	48 89 c6                                        	mov    rsi,rax
   7f32e:	48 83 ce 01                                     	or     rsi,0x1
   7f332:	48 39 ce                                        	cmp    rsi,rcx
   7f335:	0f 83 7b 5a 00 00                               	jae    84db6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6606>
   7f33b:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7f33f:	75 12                                           	jne    7f353 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xba3>
   7f341:	ff 15 71 da 01 00                               	call   QWORD PTR [rip+0x1da71]        # 9cdb8 <munmap@GLIBC_2.2.5>
   7f347:	eb 10                                           	jmp    7f359 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xba9>
   7f349:	48 8b bc 24 c0 06 00 00                         	mov    rdi,QWORD PTR [rsp+0x6c0]
   7f351:	eb 00                                           	jmp    7f353 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xba3>
   7f353:	ff 15 67 da 01 00                               	call   QWORD PTR [rip+0x1da67]        # 9cdc0 <free@GLIBC_2.2.5>
   7f359:	48 89 df                                        	mov    rdi,rbx
   7f35c:	ff 15 5e da 01 00                               	call   QWORD PTR [rip+0x1da5e]        # 9cdc0 <free@GLIBC_2.2.5>
   7f362:	44 8b 74 24 18                                  	mov    r14d,DWORD PTR [rsp+0x18]
   7f367:	4a 8d 04 b5 00 00 00 00                         	lea    rax,[r14*4+0x0]
   7f36f:	4c 89 74 24 48                                  	mov    QWORD PTR [rsp+0x48],r14
   7f374:	48 89 84 24 b0 00 00 00                         	mov    QWORD PTR [rsp+0xb0],rax
   7f37c:	4d 85 f6                                        	test   r14,r14
   7f37f:	0f 84 d1 00 00 00                               	je     7f456 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xca6>
   7f385:	41 81 fe 00 80 00 00                            	cmp    r14d,0x8000
   7f38c:	0f 82 d8 00 00 00                               	jb     7f46a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xcba>
   7f392:	4a 8d 1c b5 00 00 00 00                         	lea    rbx,[r14*4+0x0]
   7f39a:	48 89 df                                        	mov    rdi,rbx
   7f39d:	48 83 cf 01                                     	or     rdi,0x1
   7f3a1:	ff 15 31 da 01 00                               	call   QWORD PTR [rip+0x1da31]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7f3a7:	48 85 c0                                        	test   rax,rax
   7f3aa:	0f 84 d7 59 00 00                               	je     84d87 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65d7>
   7f3b0:	c6 04 18 00                                     	mov    BYTE PTR [rax+rbx*1],0x0
   7f3b4:	48 8b 5c 24 20                                  	mov    rbx,QWORD PTR [rsp+0x20]
   7f3b9:	48 89 44 24 40                                  	mov    QWORD PTR [rsp+0x40],rax
   7f3be:	62 f1 fd 48 6f 05 38 88 f8 ff                   	vmovdqa64 zmm0,ZMMWORD PTR [rip+0xfffffffffff88838]        # 7c00 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x480>
   7f3c8:	62 f2 7d 48 58 0d b6 8e f8 ff                   	vpbroadcastd zmm1,DWORD PTR [rip+0xfffffffffff88eb6]        # 8288 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb08>
   7f3d2:	62 f2 7d 48 58 15 c4 8e f8 ff                   	vpbroadcastd zmm2,DWORD PTR [rip+0xfffffffffff88ec4]        # 82a0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb20>
   7f3dc:	62 f2 7d 48 58 1d ca 8e f8 ff                   	vpbroadcastd zmm3,DWORD PTR [rip+0xfffffffffff88eca]        # 82b0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb30>
   7f3e6:	62 f2 7d 48 58 25 d0 8e f8 ff                   	vpbroadcastd zmm4,DWORD PTR [rip+0xfffffffffff88ed0]        # 82c0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb40>
   7f3f0:	48 8b 54 24 40                                  	mov    rdx,QWORD PTR [rsp+0x40]
   7f3f5:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
   7f3fa:	83 e0 c0                                        	and    eax,0xffffffc0
   7f3fd:	31 c9                                           	xor    ecx,ecx
   7f3ff:	90                                              	nop
   7f400:	62 f1 7d 48 fe e9                               	vpaddd zmm5,zmm0,zmm1
   7f406:	62 f1 7d 48 fe f2                               	vpaddd zmm6,zmm0,zmm2
   7f40c:	62 f1 7d 48 fe fb                               	vpaddd zmm7,zmm0,zmm3
   7f412:	62 f1 fe 48 7f 04 8a                            	vmovdqu64 ZMMWORD PTR [rdx+rcx*4],zmm0
   7f419:	62 f1 7d 48 fe c4                               	vpaddd zmm0,zmm0,zmm4
   7f41f:	62 f1 fe 48 7f 6c 8a 01                         	vmovdqu64 ZMMWORD PTR [rdx+rcx*4+0x40],zmm5
   7f427:	62 f1 fe 48 7f 74 8a 02                         	vmovdqu64 ZMMWORD PTR [rdx+rcx*4+0x80],zmm6
   7f42f:	62 f1 fe 48 7f 7c 8a 03                         	vmovdqu64 ZMMWORD PTR [rdx+rcx*4+0xc0],zmm7
   7f437:	48 83 c1 40                                     	add    rcx,0x40
   7f43b:	48 39 c8                                        	cmp    rax,rcx
   7f43e:	75 c0                                           	jne    7f400 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xc50>
   7f440:	39 44 24 48                                     	cmp    DWORD PTR [rsp+0x48],eax
   7f444:	0f 84 ae 00 00 00                               	je     7f4f8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd48>
   7f44a:	f6 44 24 18 38                                  	test   BYTE PTR [rsp+0x18],0x38
   7f44f:	75 5b                                           	jne    7f4ac <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xcfc>
   7f451:	e9 e9 00 00 00                                  	jmp    7f53f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd8f>
   7f456:	48 8b 5c 24 20                                  	mov    rbx,QWORD PTR [rsp+0x20]
   7f45b:	b8 04 00 00 00                                  	mov    eax,0x4
   7f460:	48 89 44 24 40                                  	mov    QWORD PTR [rsp+0x40],rax
   7f465:	e9 13 01 00 00                                  	jmp    7f57d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xdcd>
   7f46a:	4a 8d 1c b5 00 00 00 00                         	lea    rbx,[r14*4+0x0]
   7f472:	48 89 df                                        	mov    rdi,rbx
   7f475:	ff 15 5d d9 01 00                               	call   QWORD PTR [rip+0x1d95d]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7f47b:	48 85 c0                                        	test   rax,rax
   7f47e:	0f 84 03 59 00 00                               	je     84d87 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65d7>
   7f484:	48 89 44 24 40                                  	mov    QWORD PTR [rsp+0x40],rax
   7f489:	41 83 fe 08                                     	cmp    r14d,0x8
   7f48d:	73 0c                                           	jae    7f49b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xceb>
   7f48f:	48 8b 5c 24 20                                  	mov    rbx,QWORD PTR [rsp+0x20]
   7f494:	31 c0                                           	xor    eax,eax
   7f496:	e9 a4 00 00 00                                  	jmp    7f53f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd8f>
   7f49b:	48 8b 5c 24 20                                  	mov    rbx,QWORD PTR [rsp+0x20]
   7f4a0:	41 83 fe 40                                     	cmp    r14d,0x40
   7f4a4:	0f 83 14 ff ff ff                               	jae    7f3be <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xc0e>
   7f4aa:	31 c0                                           	xor    eax,eax
   7f4ac:	48 89 c1                                        	mov    rcx,rax
   7f4af:	62 f2 7d 28 7c c1                               	vpbroadcastd ymm0,ecx
   7f4b5:	c5 fd eb 05 e3 8a f8 ff                         	vpor   ymm0,ymm0,YMMWORD PTR [rip+0xfffffffffff88ae3]        # 7fa0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x820>
   7f4bd:	c4 e2 7d 58 0d de 8d f8 ff                      	vpbroadcastd ymm1,DWORD PTR [rip+0xfffffffffff88dde]        # 82a4 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb24>
   7f4c6:	48 8b 54 24 40                                  	mov    rdx,QWORD PTR [rsp+0x40]
   7f4cb:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
   7f4d0:	83 e0 f8                                        	and    eax,0xfffffff8
   7f4d3:	66 66 66 66 2e 0f 1f 84 00 00 00 00 00          	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7f4e0:	c5 fe 7f 04 8a                                  	vmovdqu YMMWORD PTR [rdx+rcx*4],ymm0
   7f4e5:	48 83 c1 08                                     	add    rcx,0x8
   7f4e9:	c5 fd fe c1                                     	vpaddd ymm0,ymm0,ymm1
   7f4ed:	48 39 c8                                        	cmp    rax,rcx
   7f4f0:	75 ee                                           	jne    7f4e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd30>
   7f4f2:	39 44 24 48                                     	cmp    DWORD PTR [rsp+0x48],eax
   7f4f6:	75 47                                           	jne    7f53f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd8f>
   7f4f8:	48 8d 44 24 78                                  	lea    rax,[rsp+0x78]
   7f4fd:	48 8d 8c 24 40 04 00 00                         	lea    rcx,[rsp+0x440]
   7f505:	48 89 84 24 40 04 00 00                         	mov    QWORD PTR [rsp+0x440],rax
   7f50d:	48 89 8c 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],rcx
   7f515:	48 8b 74 24 48                                  	mov    rsi,QWORD PTR [rsp+0x48]
   7f51a:	83 fe 15                                        	cmp    esi,0x15
   7f51d:	0f 83 7d 56 00 00                               	jae    84ba0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63f0>
   7f523:	48 8b 7c 24 40                                  	mov    rdi,QWORD PTR [rsp+0x40]
   7f528:	48 8d 8c 24 40 04 00 00                         	lea    rcx,[rsp+0x440]
   7f530:	ba 01 00 00 00                                  	mov    edx,0x1
   7f535:	c5 f8 77                                        	vzeroupper
   7f538:	e8 a3 ee ff ff                                  	call   7e3e0 <_RINvNtNtNtNtCsgxBkk5gSRhY_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftmNCINvMB8_Sm20sort_unstable_by_keyTINtNtBa_3cmp7ReversehEmENCNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fills_0E0EB2t_>
   7f53d:	eb 3e                                           	jmp    7f57d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xdcd>
   7f53f:	48 8b 4c 24 48                                  	mov    rcx,QWORD PTR [rsp+0x48]
   7f544:	48 8b 54 24 40                                  	mov    rdx,QWORD PTR [rsp+0x40]
   7f549:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   7f550:	89 04 82                                        	mov    DWORD PTR [rdx+rax*4],eax
   7f553:	48 ff c0                                        	inc    rax
   7f556:	48 39 c1                                        	cmp    rcx,rax
   7f559:	75 f5                                           	jne    7f550 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xda0>
   7f55b:	48 8d 44 24 78                                  	lea    rax,[rsp+0x78]
   7f560:	48 8d 94 24 40 04 00 00                         	lea    rdx,[rsp+0x440]
   7f568:	48 89 84 24 40 04 00 00                         	mov    QWORD PTR [rsp+0x440],rax
   7f570:	48 89 94 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],rdx
   7f578:	83 f9 01                                        	cmp    ecx,0x1
   7f57b:	75 98                                           	jne    7f515 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd65>
   7f57d:	48 8b 4c 24 18                                  	mov    rcx,QWORD PTR [rsp+0x18]
   7f582:	48 b8 58 74 d1 45 17 5d 74 01                   	movabs rax,0x1745d1745d17458
   7f58c:	48 39 c1                                        	cmp    rcx,rax
   7f58f:	76 16                                           	jbe    7f5a7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xdf7>
   7f591:	45 31 e4                                        	xor    r12d,r12d
   7f594:	4c 89 e7                                        	mov    rdi,r12
   7f597:	4c 89 f6                                        	mov    rsi,r14
   7f59a:	c5 f8 77                                        	vzeroupper
   7f59d:	e8 3f 02 fb ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7f5a2:	e9 76 58 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   7f5a7:	4c 8d 79 07                                     	lea    r15,[rcx+0x7]
   7f5ab:	4d 89 fd                                        	mov    r13,r15
   7f5ae:	49 c1 ed 03                                     	shr    r13,0x3
   7f5b2:	4d 69 f5 c0 02 00 00                            	imul   r14,r13,0x2c0
   7f5b9:	4d 85 f6                                        	test   r14,r14
   7f5bc:	74 6e                                           	je     7f62c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe7c>
   7f5be:	49 81 fe ff ff 01 00                            	cmp    r14,0x1ffff
   7f5c5:	76 6e                                           	jbe    7f635 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe85>
   7f5c7:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7f5d1:	4c 89 f2                                        	mov    rdx,r14
   7f5d4:	48 83 ca 01                                     	or     rdx,0x1
   7f5d8:	48 83 c0 c8                                     	add    rax,0xffffffffffffffc8
   7f5dc:	48 39 c2                                        	cmp    rdx,rax
   7f5df:	0f 83 e5 57 00 00                               	jae    84dca <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x661a>
   7f5e5:	48 c7 84 24 40 02 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x240],0x0
   7f5f1:	48 8d bc 24 40 02 00 00                         	lea    rdi,[rsp+0x240]
   7f5f9:	be 40 00 00 00                                  	mov    esi,0x40
   7f5fe:	41 bc 40 00 00 00                               	mov    r12d,0x40
   7f604:	c5 f8 77                                        	vzeroupper
   7f607:	ff 15 f3 d7 01 00                               	call   QWORD PTR [rip+0x1d7f3]        # 9ce00 <posix_memalign@GLIBC_2.2.5>
   7f60d:	85 c0                                           	test   eax,eax
   7f60f:	75 83                                           	jne    7f594 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xde4>
   7f611:	48 8b 84 24 40 02 00 00                         	mov    rax,QWORD PTR [rsp+0x240]
   7f619:	48 85 c0                                        	test   rax,rax
   7f61c:	0f 84 72 ff ff ff                               	je     7f594 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xde4>
   7f622:	48 89 c1                                        	mov    rcx,rax
   7f625:	42 c6 04 30 00                                  	mov    BYTE PTR [rax+r14*1],0x0
   7f62a:	eb 50                                           	jmp    7f67c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xecc>
   7f62c:	b9 40 00 00 00                                  	mov    ecx,0x40
   7f631:	31 c0                                           	xor    eax,eax
   7f633:	eb 4a                                           	jmp    7f67f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xecf>
   7f635:	48 c7 84 24 40 02 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x240],0x0
   7f641:	48 8d bc 24 40 02 00 00                         	lea    rdi,[rsp+0x240]
   7f649:	be 40 00 00 00                                  	mov    esi,0x40
   7f64e:	4c 89 f2                                        	mov    rdx,r14
   7f651:	41 bc 40 00 00 00                               	mov    r12d,0x40
   7f657:	c5 f8 77                                        	vzeroupper
   7f65a:	ff 15 a0 d7 01 00                               	call   QWORD PTR [rip+0x1d7a0]        # 9ce00 <posix_memalign@GLIBC_2.2.5>
   7f660:	85 c0                                           	test   eax,eax
   7f662:	0f 85 2c ff ff ff                               	jne    7f594 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xde4>
   7f668:	48 8b 84 24 40 02 00 00                         	mov    rax,QWORD PTR [rsp+0x240]
   7f670:	48 89 c1                                        	mov    rcx,rax
   7f673:	48 85 c0                                        	test   rax,rax
   7f676:	0f 84 18 ff ff ff                               	je     7f594 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xde4>
   7f67c:	4c 89 e8                                        	mov    rax,r13
   7f67f:	48 ba f8 ff ff ff ff ff ff 03                   	movabs rdx,0x3fffffffffffff8
   7f689:	48 89 84 24 90 00 00 00                         	mov    QWORD PTR [rsp+0x90],rax
   7f691:	48 89 8c 24 98 00 00 00                         	mov    QWORD PTR [rsp+0x98],rcx
   7f699:	48 c7 84 24 a0 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xa0],0x0
   7f6a5:	48 89 8c 24 40 09 00 00                         	mov    QWORD PTR [rsp+0x940],rcx
   7f6ad:	49 21 d7                                        	and    r15,rdx
   7f6b0:	74 2c                                           	je     7f6de <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xf2e>
   7f6b2:	49 81 ff 00 00 02 00                            	cmp    r15,0x20000
   7f6b9:	72 2e                                           	jb     7f6e9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xf39>
   7f6bb:	4c 89 ff                                        	mov    rdi,r15
   7f6be:	48 83 cf 01                                     	or     rdi,0x1
   7f6c2:	c5 f8 77                                        	vzeroupper
   7f6c5:	ff 15 0d d7 01 00                               	call   QWORD PTR [rip+0x1d70d]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7f6cb:	48 85 c0                                        	test   rax,rax
   7f6ce:	0f 84 e7 56 00 00                               	je     84dbb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x660b>
   7f6d4:	49 89 c6                                        	mov    r14,rax
   7f6d7:	42 c6 04 38 00                                  	mov    BYTE PTR [rax+r15*1],0x0
   7f6dc:	eb 23                                           	jmp    7f701 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xf51>
   7f6de:	41 be 08 00 00 00                               	mov    r14d,0x8
   7f6e4:	45 31 ed                                        	xor    r13d,r13d
   7f6e7:	eb 18                                           	jmp    7f701 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xf51>
   7f6e9:	4c 89 ff                                        	mov    rdi,r15
   7f6ec:	c5 f8 77                                        	vzeroupper
   7f6ef:	ff 15 e3 d6 01 00                               	call   QWORD PTR [rip+0x1d6e3]        # 9cdd8 <malloc@GLIBC_2.2.5>
   7f6f5:	49 89 c6                                        	mov    r14,rax
   7f6f8:	48 85 c0                                        	test   rax,rax
   7f6fb:	0f 84 ba 56 00 00                               	je     84dbb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x660b>
   7f701:	48 8b 44 24 48                                  	mov    rax,QWORD PTR [rsp+0x48]
   7f706:	4c 8b 7c 24 60                                  	mov    r15,QWORD PTR [rsp+0x60]
   7f70b:	4c 89 ac 24 50 01 00 00                         	mov    QWORD PTR [rsp+0x150],r13
   7f713:	4c 89 b4 24 58 01 00 00                         	mov    QWORD PTR [rsp+0x158],r14
   7f71b:	48 c7 84 24 60 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x160],0x0
   7f727:	48 85 c0                                        	test   rax,rax
   7f72a:	0f 84 e0 09 00 00                               	je     80110 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1960>
   7f730:	4c 8b 64 24 40                                  	mov    r12,QWORD PTR [rsp+0x40]
   7f735:	41 be ff ff ff ff                               	mov    r14d,0xffffffff
   7f73b:	48 89 c6                                        	mov    rsi,rax
   7f73e:	48 c7 84 24 c0 06 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x6c0],0x0
   7f74a:	eb 3a                                           	jmp    7f786 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xfd6>
   7f74c:	0f 1f 40 00                                     	nop    DWORD PTR [rax+0x0]
   7f750:	48 8b 84 24 58 01 00 00                         	mov    rax,QWORD PTR [rsp+0x158]
   7f758:	4e 89 34 e0                                     	mov    QWORD PTR [rax+r12*8],r14
   7f75c:	49 ff c4                                        	inc    r12
   7f75f:	48 8b 84 24 00 09 00 00                         	mov    rax,QWORD PTR [rsp+0x900]
   7f767:	41 be ff ff ff ff                               	mov    r14d,0xffffffff
   7f76d:	4c 89 a4 24 60 01 00 00                         	mov    QWORD PTR [rsp+0x160],r12
   7f775:	4c 8b 64 24 28                                  	mov    r12,QWORD PTR [rsp+0x28]
   7f77a:	48 89 c6                                        	mov    rsi,rax
   7f77d:	48 85 c0                                        	test   rax,rax
   7f780:	0f 84 28 09 00 00                               	je     800ae <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x18fe>
   7f786:	48 83 fe 08                                     	cmp    rsi,0x8
   7f78a:	b8 08 00 00 00                                  	mov    eax,0x8
   7f78f:	48 89 74 24 08                                  	mov    QWORD PTR [rsp+0x8],rsi
   7f794:	48 0f 42 c6                                     	cmovb  rax,rsi
   7f798:	48 89 84 24 c0 01 00 00                         	mov    QWORD PTR [rsp+0x1c0],rax
   7f7a0:	89 c1                                           	mov    ecx,eax
   7f7a2:	b8 ff ff ff ff                                  	mov    eax,0xffffffff
   7f7a7:	48 83 fe 01                                     	cmp    rsi,0x1
   7f7ab:	75 23                                           	jne    7f7d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1020>
   7f7ad:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7f7b3:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   7f7b9:	41 b9 ff ff ff ff                               	mov    r9d,0xffffffff
   7f7bf:	bf ff ff ff ff                                  	mov    edi,0xffffffff
   7f7c4:	be ff ff ff ff                                  	mov    esi,0xffffffff
   7f7c9:	ba ff ff ff ff                                  	mov    edx,0xffffffff
   7f7ce:	eb 4c                                           	jmp    7f81c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x106c>
   7f7d0:	41 8b 54 24 04                                  	mov    edx,DWORD PTR [r12+0x4]
   7f7d5:	48 83 fe 03                                     	cmp    rsi,0x3
   7f7d9:	72 25                                           	jb     7f800 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1050>
   7f7db:	41 8b 74 24 08                                  	mov    esi,DWORD PTR [r12+0x8]
   7f7e0:	0f 85 5f 08 00 00                               	jne    80045 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1895>
   7f7e6:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7f7ec:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   7f7f2:	41 b9 ff ff ff ff                               	mov    r9d,0xffffffff
   7f7f8:	bf ff ff ff ff                                  	mov    edi,0xffffffff
   7f7fd:	eb 1d                                           	jmp    7f81c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x106c>
   7f7ff:	90                                              	nop
   7f800:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7f806:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   7f80c:	41 b9 ff ff ff ff                               	mov    r9d,0xffffffff
   7f812:	bf ff ff ff ff                                  	mov    edi,0xffffffff
   7f817:	be ff ff ff ff                                  	mov    esi,0xffffffff
   7f81c:	45 8b 1c 24                                     	mov    r11d,DWORD PTR [r12]
   7f820:	49 8d 0c 8c                                     	lea    rcx,[r12+rcx*4]
   7f824:	48 89 4c 24 28                                  	mov    QWORD PTR [rsp+0x28],rcx
   7f829:	48 8b 4c 24 08                                  	mov    rcx,QWORD PTR [rsp+0x8]
   7f82e:	48 2b 8c 24 c0 01 00 00                         	sub    rcx,QWORD PTR [rsp+0x1c0]
   7f836:	44 89 9c 24 00 07 00 00                         	mov    DWORD PTR [rsp+0x700],r11d
   7f83e:	89 94 24 04 07 00 00                            	mov    DWORD PTR [rsp+0x704],edx
   7f845:	89 b4 24 08 07 00 00                            	mov    DWORD PTR [rsp+0x708],esi
   7f84c:	89 bc 24 0c 07 00 00                            	mov    DWORD PTR [rsp+0x70c],edi
   7f853:	44 89 8c 24 10 07 00 00                         	mov    DWORD PTR [rsp+0x710],r9d
   7f85b:	44 89 94 24 14 07 00 00                         	mov    DWORD PTR [rsp+0x714],r10d
   7f863:	44 89 84 24 18 07 00 00                         	mov    DWORD PTR [rsp+0x718],r8d
   7f86b:	89 84 24 1c 07 00 00                            	mov    DWORD PTR [rsp+0x71c],eax
   7f872:	48 8b 84 24 d8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xd8]
   7f87a:	48 8b b4 24 e0 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xe0]
   7f882:	31 d2                                           	xor    edx,edx
   7f884:	48 89 8c 24 00 09 00 00                         	mov    QWORD PTR [rsp+0x900],rcx
   7f88c:	48 8d 8c 24 60 02 00 00                         	lea    rcx,[rsp+0x260]
   7f894:	48 89 b4 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],rsi
   7f89c:	48 89 84 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],rax
   7f8a4:	eb 43                                           	jmp    7f8e9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1139>
   7f8a6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   7f8b0:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7f8b4:	c5 fd 7f 84 24 80 09 00 00                      	vmovdqa YMMWORD PTR [rsp+0x980],ymm0
   7f8bd:	c5 fd 6f 8c 24 80 09 00 00                      	vmovdqa ymm1,YMMWORD PTR [rsp+0x980]
   7f8c6:	48 ff c2                                        	inc    rdx
   7f8c9:	c5 fe 7f 49 e0                                  	vmovdqu YMMWORD PTR [rcx-0x20],ymm1
   7f8ce:	c5 fe 7f 01                                     	vmovdqu YMMWORD PTR [rcx],ymm0
   7f8d2:	48 83 c1 40                                     	add    rcx,0x40
   7f8d6:	c5 fd 7f 8c 24 40 04 00 00                      	vmovdqa YMMWORD PTR [rsp+0x440],ymm1
   7f8df:	48 83 fa 08                                     	cmp    rdx,0x8
   7f8e3:	0f 84 37 01 00 00                               	je     7fa20 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1270>
   7f8e9:	8b bc 94 00 07 00 00                            	mov    edi,DWORD PTR [rsp+rdx*4+0x700]
   7f8f0:	4c 39 f7                                        	cmp    rdi,r14
   7f8f3:	74 bb                                           	je     7f8b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1100>
   7f8f5:	48 39 fe                                        	cmp    rsi,rdi
   7f8f8:	0f 86 77 52 00 00                               	jbe    84b75 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63c5>
   7f8fe:	48 8b 3c f8                                     	mov    rdi,QWORD PTR [rax+rdi*8]
   7f902:	4c 39 ff                                        	cmp    rdi,r15
   7f905:	0f 83 5e 52 00 00                               	jae    84b69 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63b9>
   7f90b:	4c 8b 44 24 30                                  	mov    r8,QWORD PTR [rsp+0x30]
   7f910:	45 8b 04 b8                                     	mov    r8d,DWORD PTR [r8+rdi*4]
   7f914:	44 89 c7                                        	mov    edi,r8d
   7f917:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7f91d:	48 39 fb                                        	cmp    rbx,rdi
   7f920:	0f 86 58 52 00 00                               	jbe    84b7e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63ce>
   7f926:	4c 8b 4c 24 50                                  	mov    r9,QWORD PTR [rsp+0x50]
   7f92b:	48 c1 e7 06                                     	shl    rdi,0x6
   7f92f:	c4 c1 7c 10 04 39                               	vmovups ymm0,YMMWORD PTR [r9+rdi*1]
   7f935:	c5 fc 29 84 24 80 09 00 00                      	vmovaps YMMWORD PTR [rsp+0x980],ymm0
   7f93e:	45 85 c0                                        	test   r8d,r8d
   7f941:	78 0d                                           	js     7f950 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x11a0>
   7f943:	c4 c1 7e 6f 44 39 20                            	vmovdqu ymm0,YMMWORD PTR [r9+rdi*1+0x20]
   7f94a:	e9 6e ff ff ff                                  	jmp    7f8bd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x110d>
   7f94f:	90                                              	nop
   7f950:	49 8d 7c 39 20                                  	lea    rdi,[r9+rdi*1+0x20]
   7f955:	45 31 c0                                        	xor    r8d,r8d
   7f958:	45 31 c9                                        	xor    r9d,r9d
   7f95b:	45 31 d2                                        	xor    r10d,r10d
   7f95e:	4c 8d ac 24 c0 0c 00 00                         	lea    r13,[rsp+0xcc0]
   7f966:	48 8d 84 24 40 04 00 00                         	lea    rax,[rsp+0x440]
   7f96e:	4c 89 e6                                        	mov    rsi,r12
   7f971:	c5 fc 10 07                                     	vmovups ymm0,YMMWORD PTR [rdi]
   7f975:	31 ff                                           	xor    edi,edi
   7f977:	c5 fc 29 84 24 c0 0c 00 00                      	vmovaps YMMWORD PTR [rsp+0xcc0],ymm0
   7f980:	c5 fc 10 05 58 87 f8 ff                         	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffff88758]        # 80e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x960>
   7f988:	c5 fc 29 84 24 40 04 00 00                      	vmovaps YMMWORD PTR [rsp+0x440],ymm0
   7f991:	4d 2b 45 00                                     	sub    r8,QWORD PTR [r13+0x0]
   7f995:	4d 1b 4d 08                                     	sbb    r9,QWORD PTR [r13+0x8]
   7f999:	4d 1b 55 10                                     	sbb    r10,QWORD PTR [r13+0x10]
   7f99d:	49 1b 7d 18                                     	sbb    rdi,QWORD PTR [r13+0x18]
   7f9a1:	4d 19 ff                                        	sbb    r15,r15
   7f9a4:	4c 8b 18                                        	mov    r11,QWORD PTR [rax]
   7f9a7:	4c 8b 70 08                                     	mov    r14,QWORD PTR [rax+0x8]
   7f9ab:	4c 8b 60 10                                     	mov    r12,QWORD PTR [rax+0x10]
   7f9af:	48 8b 58 18                                     	mov    rbx,QWORD PTR [rax+0x18]
   7f9b3:	4d 21 fb                                        	and    r11,r15
   7f9b6:	4d 21 fe                                        	and    r14,r15
   7f9b9:	4d 21 fc                                        	and    r12,r15
   7f9bc:	4c 21 fb                                        	and    rbx,r15
   7f9bf:	4d 01 d8                                        	add    r8,r11
   7f9c2:	4d 11 f1                                        	adc    r9,r14
   7f9c5:	4d 11 e2                                        	adc    r10,r12
   7f9c8:	48 11 df                                        	adc    rdi,rbx
   7f9cb:	49 89 f4                                        	mov    r12,rsi
   7f9ce:	c4 e1 f9 6e c7                                  	vmovq  xmm0,rdi
   7f9d3:	c4 c1 f9 6e ca                                  	vmovq  xmm1,r10
   7f9d8:	c4 c1 f9 6e d0                                  	vmovq  xmm2,r8
   7f9dd:	41 be ff ff ff ff                               	mov    r14d,0xffffffff
   7f9e3:	48 8b 84 24 80 06 00 00                         	mov    rax,QWORD PTR [rsp+0x680]
   7f9eb:	48 8b b4 24 00 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x100]
   7f9f3:	4c 8b 7c 24 60                                  	mov    r15,QWORD PTR [rsp+0x60]
   7f9f8:	48 8b 5c 24 20                                  	mov    rbx,QWORD PTR [rsp+0x20]
   7f9fd:	c5 f1 6c c0                                     	vpunpcklqdq xmm0,xmm1,xmm0
   7fa01:	c4 c1 f9 6e c9                                  	vmovq  xmm1,r9
   7fa06:	c5 e9 6c c9                                     	vpunpcklqdq xmm1,xmm2,xmm1
   7fa0a:	c4 e3 75 38 c0 01                               	vinserti128 ymm0,ymm1,xmm0,0x1
   7fa10:	e9 a8 fe ff ff                                  	jmp    7f8bd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x110d>
   7fa15:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   7fa20:	62 f1 7c 48 10 44 24 10                         	vmovups zmm0,ZMMWORD PTR [rsp+0x400]
   7fa28:	62 f1 7c 48 10 4c 24 0f                         	vmovups zmm1,ZMMWORD PTR [rsp+0x3c0]
   7fa30:	62 f1 7c 48 10 54 24 0e                         	vmovups zmm2,ZMMWORD PTR [rsp+0x380]
   7fa38:	62 f1 7c 48 10 5c 24 0c                         	vmovups zmm3,ZMMWORD PTR [rsp+0x300]
   7fa40:	62 f1 7c 48 29 44 24 18                         	vmovaps ZMMWORD PTR [rsp+0x600],zmm0
   7fa48:	62 f1 7c 48 10 44 24 09                         	vmovups zmm0,ZMMWORD PTR [rsp+0x240]
   7fa50:	62 f1 7c 48 29 4c 24 17                         	vmovaps ZMMWORD PTR [rsp+0x5c0],zmm1
   7fa58:	62 f1 7c 48 10 4c 24 0d                         	vmovups zmm1,ZMMWORD PTR [rsp+0x340]
   7fa60:	62 f1 7c 48 29 54 24 16                         	vmovaps ZMMWORD PTR [rsp+0x580],zmm2
   7fa68:	62 f1 7c 48 10 54 24 0b                         	vmovups zmm2,ZMMWORD PTR [rsp+0x2c0]
   7fa70:	62 f1 7c 48 29 5c 24 14                         	vmovaps ZMMWORD PTR [rsp+0x500],zmm3
   7fa78:	62 f1 7c 48 29 44 24 11                         	vmovaps ZMMWORD PTR [rsp+0x440],zmm0
   7fa80:	62 f1 7c 48 29 4c 24 15                         	vmovaps ZMMWORD PTR [rsp+0x540],zmm1
   7fa88:	62 f1 7c 48 10 4c 24 0a                         	vmovups zmm1,ZMMWORD PTR [rsp+0x280]
   7fa90:	62 f1 7c 48 29 54 24 13                         	vmovaps ZMMWORD PTR [rsp+0x4c0],zmm2
   7fa98:	c5 fd 6f 84 24 40 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x440]
   7faa1:	62 f1 7c 48 29 4c 24 12                         	vmovaps ZMMWORD PTR [rsp+0x480],zmm1
   7faa9:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7faae:	0f 84 1c 04 00 00                               	je     7fed0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1720>
   7fab4:	45 31 f6                                        	xor    r14d,r14d
   7fab7:	c5 fd 6f 84 24 80 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x480]
   7fac0:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7fac5:	0f 84 2b 04 00 00                               	je     7fef6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1746>
   7facb:	c5 fd 6f 84 24 c0 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x4c0]
   7fad4:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7fad9:	0f 84 49 04 00 00                               	je     7ff28 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1778>
   7fadf:	c5 fd 6f 84 24 00 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x500]
   7fae8:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7faed:	0f 84 67 04 00 00                               	je     7ff5a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x17aa>
   7faf3:	c5 fd 6f 84 24 40 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x540]
   7fafc:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7fb01:	0f 84 85 04 00 00                               	je     7ff8c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x17dc>
   7fb07:	c5 fd 6f 84 24 80 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x580]
   7fb10:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7fb15:	0f 84 a3 04 00 00                               	je     7ffbe <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x180e>
   7fb1b:	c5 fd 6f 84 24 c0 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x5c0]
   7fb24:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7fb29:	0f 84 c1 04 00 00                               	je     7fff0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1840>
   7fb2f:	c5 fd 6f 84 24 00 06 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x600]
   7fb38:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7fb3d:	0f 84 df 04 00 00                               	je     80022 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1872>
   7fb43:	62 f1 7c 48 28 4c 24 13                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x4c0]
   7fb4b:	62 f1 7c 48 28 54 24 15                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x540]
   7fb53:	62 f1 7c 48 28 5c 24 17                         	vmovaps zmm3,ZMMWORD PTR [rsp+0x5c0]
   7fb5b:	62 f1 7c 48 28 44 24 11                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x440]
   7fb63:	62 f1 fe 48 6f a4 24 60 04 00 00                	vmovdqu64 zmm4,ZMMWORD PTR [rsp+0x460]
   7fb6e:	48 8b 84 24 c0 06 00 00                         	mov    rax,QWORD PTR [rsp+0x6c0]
   7fb76:	62 f3 f5 48 1a 4c 24 28 01                      	vinsertf64x4 zmm1,zmm1,YMMWORD PTR [rsp+0x500],0x1
   7fb7f:	62 f3 ed 48 1a 54 24 2c 01                      	vinsertf64x4 zmm2,zmm2,YMMWORD PTR [rsp+0x580],0x1
   7fb88:	62 f3 fd 48 1a 44 24 24 01                      	vinsertf64x4 zmm0,zmm0,YMMWORD PTR [rsp+0x480],0x1
   7fb91:	62 f1 7c 48 29 4c 24 32                         	vmovaps ZMMWORD PTR [rsp+0xc80],zmm1
   7fb99:	62 f3 e5 48 1a 4c 24 30 01                      	vinsertf64x4 zmm1,zmm3,YMMWORD PTR [rsp+0x600],0x1
   7fba2:	62 f1 7c 48 29 54 24 20                         	vmovaps ZMMWORD PTR [rsp+0x800],zmm2
   7fbaa:	62 f1 fe 48 6f 94 24 60 05 00 00                	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x560]
   7fbb5:	62 f1 fe 48 6f 9c 24 e0 05 00 00                	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x5e0]
   7fbc0:	62 f1 7c 48 29 44 24 21                         	vmovaps ZMMWORD PTR [rsp+0x840],zmm0
   7fbc8:	62 f3 dd 48 3a 44 24 25 01                      	vinserti64x4 zmm0,zmm4,YMMWORD PTR [rsp+0x4a0],0x1
   7fbd1:	62 f3 ed 48 3a 64 24 2d 01                      	vinserti64x4 zmm4,zmm2,YMMWORD PTR [rsp+0x5a0],0x1
   7fbda:	62 f3 e5 48 3a 54 24 31 01                      	vinserti64x4 zmm2,zmm3,YMMWORD PTR [rsp+0x620],0x1
   7fbe3:	62 f1 7c 48 29 4c 24 31                         	vmovaps ZMMWORD PTR [rsp+0xc40],zmm1
   7fbeb:	62 f1 fe 48 6f 8c 24 e0 04 00 00                	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x4e0]
   7fbf6:	62 f1 fd 48 7f 44 24 04                         	vmovdqa64 ZMMWORD PTR [rsp+0x100],zmm0
   7fbfe:	62 f3 f5 48 3a 6c 24 29 01                      	vinserti64x4 zmm5,zmm1,YMMWORD PTR [rsp+0x520],0x1
   7fc07:	c5 fe 6f 8c 24 00 07 00 00                      	vmovdqu ymm1,YMMWORD PTR [rsp+0x700]
   7fc10:	62 f1 fd 48 7f 64 24 1a                         	vmovdqa64 ZMMWORD PTR [rsp+0x680],zmm4
   7fc18:	62 f1 fd 48 7f 54 24 22                         	vmovdqa64 ZMMWORD PTR [rsp+0x880],zmm2
   7fc20:	62 f1 fd 48 7f 6c 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm5
   7fc28:	c5 fd 7f 8c 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm1
   7fc31:	48 3b 84 24 90 00 00 00                         	cmp    rax,QWORD PTR [rsp+0x90]
   7fc39:	75 20                                           	jne    7fc5b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x14ab>
   7fc3b:	48 8d bc 24 90 00 00 00                         	lea    rdi,[rsp+0x90]
   7fc43:	c5 f8 77                                        	vzeroupper
   7fc46:	e8 c5 d7 00 00                                  	call   8d410 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecNtNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns6ColumnE8grow_oneBT_>
   7fc4b:	48 8b 84 24 98 00 00 00                         	mov    rax,QWORD PTR [rsp+0x98]
   7fc53:	48 89 84 24 40 09 00 00                         	mov    QWORD PTR [rsp+0x940],rax
   7fc5b:	62 f1 fd 48 6f 4c 24 21                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x840]
   7fc63:	62 f1 fd 48 6f 54 24 32                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xc80]
   7fc6b:	62 f1 fd 48 6f 5c 24 20                         	vmovdqa64 zmm3,ZMMWORD PTR [rsp+0x800]
   7fc73:	62 f1 fd 48 6f 64 24 31                         	vmovdqa64 zmm4,ZMMWORD PTR [rsp+0xc40]
   7fc7b:	62 f1 fd 48 6f 74 24 04                         	vmovdqa64 zmm6,ZMMWORD PTR [rsp+0x100]
   7fc83:	62 f1 fd 48 6f 7c 24 23                         	vmovdqa64 zmm7,ZMMWORD PTR [rsp+0x8c0]
   7fc8b:	62 71 fd 48 6f 44 24 1a                         	vmovdqa64 zmm8,ZMMWORD PTR [rsp+0x680]
   7fc93:	62 71 fd 48 6f 4c 24 22                         	vmovdqa64 zmm9,ZMMWORD PTR [rsp+0x880]
   7fc9b:	62 71 fd 48 6f 1d 9b 7f f8 ff                   	vmovdqa64 zmm11,ZMMWORD PTR [rip+0xfffffffffff87f9b]        # 7c40 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4c0>
   7fca5:	62 71 fd 48 6f 25 d1 7f f8 ff                   	vmovdqa64 zmm12,ZMMWORD PTR [rip+0xfffffffffff87fd1]        # 7c80 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x500>
   7fcaf:	62 72 fd 48 59 2d 47 77 f8 ff                   	vpbroadcastq zmm13,QWORD PTR [rip+0xfffffffffff87747]        # 7400 <GCC_except_table746+0x8c>
   7fcb9:	48 8b 94 24 c0 06 00 00                         	mov    rdx,QWORD PTR [rsp+0x6c0]
   7fcc1:	48 8b 8c 24 40 09 00 00                         	mov    rcx,QWORD PTR [rsp+0x940]
   7fcc9:	48 69 c2 c0 02 00 00                            	imul   rax,rdx,0x2c0
   7fcd0:	48 ff c2                                        	inc    rdx
   7fcd3:	48 89 94 24 c0 06 00 00                         	mov    QWORD PTR [rsp+0x6c0],rdx
   7fcdb:	62 f1 f5 48 6c c2                               	vpunpcklqdq zmm0,zmm1,zmm2
   7fce1:	62 f1 f5 48 6d ca                               	vpunpckhqdq zmm1,zmm1,zmm2
   7fce7:	62 f1 e5 48 6c d4                               	vpunpcklqdq zmm2,zmm3,zmm4
   7fced:	62 f1 e5 48 6d dc                               	vpunpckhqdq zmm3,zmm3,zmm4
   7fcf3:	62 71 cd 48 6c f7                               	vpunpcklqdq zmm14,zmm6,zmm7
   7fcf9:	62 f1 cd 48 6d f7                               	vpunpckhqdq zmm6,zmm6,zmm7
   7fcff:	62 d1 bd 48 6c f9                               	vpunpcklqdq zmm7,zmm8,zmm9
   7fd05:	62 51 bd 48 6d c1                               	vpunpckhqdq zmm8,zmm8,zmm9
   7fd0b:	62 f1 fd 48 6f e0                               	vmovdqa64 zmm4,zmm0
   7fd11:	62 f1 fd 48 6f e9                               	vmovdqa64 zmm5,zmm1
   7fd17:	62 51 fd 48 6f ce                               	vmovdqa64 zmm9,zmm14
   7fd1d:	62 71 fd 48 6f d6                               	vmovdqa64 zmm10,zmm6
   7fd23:	62 f2 a5 48 7e e2                               	vpermt2q zmm4,zmm11,zmm2
   7fd29:	62 f2 9d 48 7e c2                               	vpermt2q zmm0,zmm12,zmm2
   7fd2f:	62 f2 a5 48 7e eb                               	vpermt2q zmm5,zmm11,zmm3
   7fd35:	62 f2 9d 48 7e cb                               	vpermt2q zmm1,zmm12,zmm3
   7fd3b:	62 72 a5 48 7e cf                               	vpermt2q zmm9,zmm11,zmm7
   7fd41:	62 72 9d 48 7e f7                               	vpermt2q zmm14,zmm12,zmm7
   7fd47:	62 52 a5 48 7e d0                               	vpermt2q zmm10,zmm11,zmm8
   7fd4d:	62 d2 9d 48 7e f0                               	vpermt2q zmm6,zmm12,zmm8
   7fd53:	62 f3 d5 48 71 dc 0c                            	vpshldq zmm3,zmm5,zmm4,0xc
   7fd5a:	62 d1 dd 48 db d5                               	vpandq zmm2,zmm4,zmm13
   7fd60:	62 f3 fd 48 71 e5 18                            	vpshldq zmm4,zmm0,zmm5,0x18
   7fd67:	62 f3 f5 48 71 c0 24                            	vpshldq zmm0,zmm1,zmm0,0x24
   7fd6e:	62 d3 cd 48 71 ee 24                            	vpshldq zmm5,zmm6,zmm14,0x24
   7fd75:	62 53 ad 48 71 c1 0c                            	vpshldq zmm8,zmm10,zmm9,0xc
   7fd7c:	62 d1 b5 48 db fd                               	vpandq zmm7,zmm9,zmm13
   7fd82:	62 53 8d 48 71 ca 18                            	vpshldq zmm9,zmm14,zmm10,0x18
   7fd89:	62 f1 f5 48 73 d1 10                            	vpsrlq zmm1,zmm1,0x10
   7fd90:	62 f1 cd 48 73 d6 10                            	vpsrlq zmm6,zmm6,0x10
   7fd97:	62 f1 fd 48 7f 14 01                            	vmovdqa64 ZMMWORD PTR [rcx+rax*1],zmm2
   7fd9e:	62 d1 e5 48 db dd                               	vpandq zmm3,zmm3,zmm13
   7fda4:	62 d1 dd 48 db e5                               	vpandq zmm4,zmm4,zmm13
   7fdaa:	62 d1 fd 48 db c5                               	vpandq zmm0,zmm0,zmm13
   7fdb0:	62 51 bd 48 db c5                               	vpandq zmm8,zmm8,zmm13
   7fdb6:	62 51 b5 48 db cd                               	vpandq zmm9,zmm9,zmm13
   7fdbc:	62 d1 d5 48 db ed                               	vpandq zmm5,zmm5,zmm13
   7fdc2:	62 f1 fd 48 7f 5c 01 01                         	vmovdqa64 ZMMWORD PTR [rcx+rax*1+0x40],zmm3
   7fdca:	62 f1 fd 48 7f 64 01 02                         	vmovdqa64 ZMMWORD PTR [rcx+rax*1+0x80],zmm4
   7fdd2:	62 f1 fd 48 7f 44 01 03                         	vmovdqa64 ZMMWORD PTR [rcx+rax*1+0xc0],zmm0
   7fdda:	62 f1 fd 48 7f 4c 01 04                         	vmovdqa64 ZMMWORD PTR [rcx+rax*1+0x100],zmm1
   7fde2:	62 f1 fd 48 7f 7c 01 05                         	vmovdqa64 ZMMWORD PTR [rcx+rax*1+0x140],zmm7
   7fdea:	62 71 fd 48 7f 44 01 06                         	vmovdqa64 ZMMWORD PTR [rcx+rax*1+0x180],zmm8
   7fdf2:	62 71 fd 48 7f 4c 01 07                         	vmovdqa64 ZMMWORD PTR [rcx+rax*1+0x1c0],zmm9
   7fdfa:	62 f1 fd 48 7f 6c 01 08                         	vmovdqa64 ZMMWORD PTR [rcx+rax*1+0x200],zmm5
   7fe02:	62 f1 fd 48 7f 74 01 09                         	vmovdqa64 ZMMWORD PTR [rcx+rax*1+0x240],zmm6
   7fe0a:	c5 fd 6f 84 24 40 02 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x240]
   7fe13:	c5 fd 7f 84 01 80 02 00 00                      	vmovdqa YMMWORD PTR [rcx+rax*1+0x280],ymm0
   7fe1c:	c6 84 01 a0 02 00 00 01                         	mov    BYTE PTR [rcx+rax*1+0x2a0],0x1
   7fe24:	44 88 b4 01 a1 02 00 00                         	mov    BYTE PTR [rcx+rax*1+0x2a1],r14b
   7fe2c:	48 89 94 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rdx
   7fe34:	41 8b 3c 24                                     	mov    edi,DWORD PTR [r12]
   7fe38:	48 8b b4 24 88 00 00 00                         	mov    rsi,QWORD PTR [rsp+0x88]
   7fe40:	48 39 fe                                        	cmp    rsi,rdi
   7fe43:	0f 86 41 4d 00 00                               	jbe    84b8a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63da>
   7fe49:	48 8b 84 24 80 00 00 00                         	mov    rax,QWORD PTR [rsp+0x80]
   7fe51:	44 0f b6 34 38                                  	movzx  r14d,BYTE PTR [rax+rdi*1]
   7fe56:	49 ff ce                                        	dec    r14
   7fe59:	48 83 7c 24 08 01                               	cmp    QWORD PTR [rsp+0x8],0x1
   7fe5f:	74 43                                           	je     7fea4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x16f4>
   7fe61:	48 8b 94 24 c0 01 00 00                         	mov    rdx,QWORD PTR [rsp+0x1c0]
   7fe69:	48 b9 ff ff ff ff ff ff ff 3f                   	movabs rcx,0x3fffffffffffffff
   7fe73:	48 01 ca                                        	add    rdx,rcx
   7fe76:	b1 3e                                           	mov    cl,0x3e
   7fe78:	c4 e2 f0 f5 ca                                  	bzhi   rcx,rdx,rcx
   7fe7d:	31 d2                                           	xor    edx,edx
   7fe7f:	90                                              	nop
   7fe80:	41 8b 7c 94 04                                  	mov    edi,DWORD PTR [r12+rdx*4+0x4]
   7fe85:	48 39 fe                                        	cmp    rsi,rdi
   7fe88:	0f 86 fc 4c 00 00                               	jbe    84b8a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63da>
   7fe8e:	0f b6 3c 38                                     	movzx  edi,BYTE PTR [rax+rdi*1]
   7fe92:	48 ff cf                                        	dec    rdi
   7fe95:	49 39 fe                                        	cmp    r14,rdi
   7fe98:	4c 0f 46 f7                                     	cmovbe r14,rdi
   7fe9c:	48 ff c2                                        	inc    rdx
   7fe9f:	48 39 d1                                        	cmp    rcx,rdx
   7fea2:	75 dc                                           	jne    7fe80 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x16d0>
   7fea4:	4c 8b a4 24 60 01 00 00                         	mov    r12,QWORD PTR [rsp+0x160]
   7feac:	4c 3b a4 24 50 01 00 00                         	cmp    r12,QWORD PTR [rsp+0x150]
   7feb4:	0f 85 96 f8 ff ff                               	jne    7f750 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xfa0>
   7feba:	48 8d bc 24 50 01 00 00                         	lea    rdi,[rsp+0x150]
   7fec2:	c5 f8 77                                        	vzeroupper
   7fec5:	e8 b6 68 fb ff                                  	call   36780 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCsii3nOZuAKF_15crossbeam_utils>
   7feca:	e9 81 f8 ff ff                                  	jmp    7f750 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xfa0>
   7fecf:	90                                              	nop
   7fed0:	c5 fd 6f 84 24 60 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x460]
   7fed9:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7fede:	41 0f 94 c6                                     	sete   r14b
   7fee2:	c5 fd 6f 84 24 80 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x480]
   7feeb:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7fef0:	0f 85 d5 fb ff ff                               	jne    7facb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x131b>
   7fef6:	c5 fd 6f 84 24 a0 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x4a0]
   7feff:	41 8d 46 02                                     	lea    eax,[r14+0x2]
   7ff03:	41 0f b6 ce                                     	movzx  ecx,r14b
   7ff07:	44 0f b6 f0                                     	movzx  r14d,al
   7ff0b:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ff10:	44 0f 45 f1                                     	cmovne r14d,ecx
   7ff14:	c5 fd 6f 84 24 c0 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x4c0]
   7ff1d:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ff22:	0f 85 b7 fb ff ff                               	jne    7fadf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x132f>
   7ff28:	c5 fd 6f 84 24 e0 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x4e0]
   7ff31:	41 8d 46 04                                     	lea    eax,[r14+0x4]
   7ff35:	41 0f b6 ce                                     	movzx  ecx,r14b
   7ff39:	44 0f b6 f0                                     	movzx  r14d,al
   7ff3d:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ff42:	44 0f 45 f1                                     	cmovne r14d,ecx
   7ff46:	c5 fd 6f 84 24 00 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x500]
   7ff4f:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ff54:	0f 85 99 fb ff ff                               	jne    7faf3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1343>
   7ff5a:	c5 fd 6f 84 24 20 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x520]
   7ff63:	41 8d 46 08                                     	lea    eax,[r14+0x8]
   7ff67:	41 0f b6 ce                                     	movzx  ecx,r14b
   7ff6b:	44 0f b6 f0                                     	movzx  r14d,al
   7ff6f:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ff74:	44 0f 45 f1                                     	cmovne r14d,ecx
   7ff78:	c5 fd 6f 84 24 40 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x540]
   7ff81:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ff86:	0f 85 7b fb ff ff                               	jne    7fb07 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1357>
   7ff8c:	c5 fd 6f 84 24 60 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x560]
   7ff95:	41 8d 46 10                                     	lea    eax,[r14+0x10]
   7ff99:	41 0f b6 ce                                     	movzx  ecx,r14b
   7ff9d:	44 0f b6 f0                                     	movzx  r14d,al
   7ffa1:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ffa6:	44 0f 45 f1                                     	cmovne r14d,ecx
   7ffaa:	c5 fd 6f 84 24 80 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x580]
   7ffb3:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ffb8:	0f 85 5d fb ff ff                               	jne    7fb1b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x136b>
   7ffbe:	c5 fd 6f 84 24 a0 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x5a0]
   7ffc7:	41 8d 46 20                                     	lea    eax,[r14+0x20]
   7ffcb:	41 0f b6 ce                                     	movzx  ecx,r14b
   7ffcf:	44 0f b6 f0                                     	movzx  r14d,al
   7ffd3:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ffd8:	44 0f 45 f1                                     	cmovne r14d,ecx
   7ffdc:	c5 fd 6f 84 24 c0 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x5c0]
   7ffe5:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7ffea:	0f 85 3f fb ff ff                               	jne    7fb2f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x137f>
   7fff0:	c5 fd 6f 84 24 e0 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x5e0]
   7fff9:	41 8d 46 40                                     	lea    eax,[r14+0x40]
   7fffd:	41 0f b6 ce                                     	movzx  ecx,r14b
   80001:	44 0f b6 f0                                     	movzx  r14d,al
   80005:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   8000a:	44 0f 45 f1                                     	cmovne r14d,ecx
   8000e:	c5 fd 6f 84 24 00 06 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x600]
   80017:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   8001c:	0f 85 21 fb ff ff                               	jne    7fb43 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1393>
   80022:	c5 fd 6f 84 24 20 06 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x620]
   8002b:	41 8d 46 80                                     	lea    eax,[r14-0x80]
   8002f:	41 0f b6 ce                                     	movzx  ecx,r14b
   80033:	44 0f b6 f0                                     	movzx  r14d,al
   80037:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   8003c:	44 0f 45 f1                                     	cmovne r14d,ecx
   80040:	e9 fe fa ff ff                                  	jmp    7fb43 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1393>
   80045:	41 8b 7c 24 0c                                  	mov    edi,DWORD PTR [r12+0xc]
   8004a:	48 83 7c 24 08 05                               	cmp    QWORD PTR [rsp+0x8],0x5
   80050:	72 18                                           	jb     8006a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x18ba>
   80052:	45 8b 4c 24 10                                  	mov    r9d,DWORD PTR [r12+0x10]
   80057:	75 28                                           	jne    80081 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x18d1>
   80059:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   8005f:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   80065:	e9 b2 f7 ff ff                                  	jmp    7f81c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x106c>
   8006a:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   80070:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   80076:	41 b9 ff ff ff ff                               	mov    r9d,0xffffffff
   8007c:	e9 9b f7 ff ff                                  	jmp    7f81c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x106c>
   80081:	45 8b 54 24 14                                  	mov    r10d,DWORD PTR [r12+0x14]
   80086:	48 83 7c 24 08 07                               	cmp    QWORD PTR [rsp+0x8],0x7
   8008c:	72 15                                           	jb     800a3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x18f3>
   8008e:	45 8b 44 24 18                                  	mov    r8d,DWORD PTR [r12+0x18]
   80093:	0f 84 83 f7 ff ff                               	je     7f81c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x106c>
   80099:	41 8b 44 24 1c                                  	mov    eax,DWORD PTR [r12+0x1c]
   8009e:	e9 79 f7 ff ff                                  	jmp    7f81c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x106c>
   800a3:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   800a9:	e9 6e f7 ff ff                                  	jmp    7f81c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x106c>
   800ae:	48 8b 44 24 48                                  	mov    rax,QWORD PTR [rsp+0x48]
   800b3:	3d ff 7f 00 00                                  	cmp    eax,0x7fff
   800b8:	76 22                                           	jbe    800dc <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x192c>
   800ba:	48 8b 7c 24 40                                  	mov    rdi,QWORD PTR [rsp+0x40]
   800bf:	48 8d 34 85 00 00 00 00                         	lea    rsi,[rax*4+0x0]
   800c7:	80 3c 37 01                                     	cmp    BYTE PTR [rdi+rsi*1],0x1
   800cb:	75 16                                           	jne    800e3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1933>
   800cd:	48 83 ce 01                                     	or     rsi,0x1
   800d1:	c5 f8 77                                        	vzeroupper
   800d4:	ff 15 de cc 01 00                               	call   QWORD PTR [rip+0x1ccde]        # 9cdb8 <munmap@GLIBC_2.2.5>
   800da:	eb 10                                           	jmp    800ec <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x193c>
   800dc:	48 8b 7c 24 40                                  	mov    rdi,QWORD PTR [rsp+0x40]
   800e1:	eb 00                                           	jmp    800e3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1933>
   800e3:	c5 f8 77                                        	vzeroupper
   800e6:	ff 15 d4 cc 01 00                               	call   QWORD PTR [rip+0x1ccd4]        # 9cdc0 <free@GLIBC_2.2.5>
   800ec:	4c 8b b4 24 58 01 00 00                         	mov    r14,QWORD PTR [rsp+0x158]
   800f4:	48 8b 84 24 60 01 00 00                         	mov    rax,QWORD PTR [rsp+0x160]
   800fc:	48 85 c0                                        	test   rax,rax
   800ff:	74 0f                                           	je     80110 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1960>
   80101:	48 83 f8 04                                     	cmp    rax,0x4
   80105:	73 15                                           	jae    8011c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x196c>
   80107:	31 c9                                           	xor    ecx,ecx
   80109:	31 db                                           	xor    ebx,ebx
   8010b:	e9 00 01 00 00                                  	jmp    80210 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a60>
   80110:	45 31 e4                                        	xor    r12d,r12d
   80113:	31 f6                                           	xor    esi,esi
   80115:	31 db                                           	xor    ebx,ebx
   80117:	e9 5d 02 00 00                                  	jmp    80379 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1bc9>
   8011c:	48 83 f8 20                                     	cmp    rax,0x20
   80120:	73 09                                           	jae    8012b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x197b>
   80122:	31 c9                                           	xor    ecx,ecx
   80124:	31 db                                           	xor    ebx,ebx
   80126:	e9 8d 00 00 00                                  	jmp    801b8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a08>
   8012b:	48 89 c1                                        	mov    rcx,rax
   8012e:	48 83 e1 e0                                     	and    rcx,0xffffffffffffffe0
   80132:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   80136:	31 d2                                           	xor    edx,edx
   80138:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8013c:	c5 e9 ef d2                                     	vpxor  xmm2,xmm2,xmm2
   80140:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   80144:	66 66 66 2e 0f 1f 84 00 00 00 00 00             	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   80150:	62 d1 fd 48 d4 04 d6                            	vpaddq zmm0,zmm0,ZMMWORD PTR [r14+rdx*8]
   80157:	62 d1 f5 48 d4 4c d6 01                         	vpaddq zmm1,zmm1,ZMMWORD PTR [r14+rdx*8+0x40]
   8015f:	62 d1 ed 48 d4 54 d6 02                         	vpaddq zmm2,zmm2,ZMMWORD PTR [r14+rdx*8+0x80]
   80167:	62 d1 e5 48 d4 5c d6 03                         	vpaddq zmm3,zmm3,ZMMWORD PTR [r14+rdx*8+0xc0]
   8016f:	48 83 c2 20                                     	add    rdx,0x20
   80173:	48 39 d1                                        	cmp    rcx,rdx
   80176:	75 d8                                           	jne    80150 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x19a0>
   80178:	62 f1 f5 48 d4 c0                               	vpaddq zmm0,zmm1,zmm0
   8017e:	62 f1 e5 48 d4 d2                               	vpaddq zmm2,zmm3,zmm2
   80184:	62 f1 ed 48 d4 c0                               	vpaddq zmm0,zmm2,zmm0
   8018a:	62 f3 fd 48 3b c1 01                            	vextracti64x4 ymm1,zmm0,0x1
   80191:	62 f1 fd 48 d4 c1                               	vpaddq zmm0,zmm0,zmm1
   80197:	c4 e3 7d 39 c1 01                               	vextracti128 xmm1,ymm0,0x1
   8019d:	c5 f9 d4 c1                                     	vpaddq xmm0,xmm0,xmm1
   801a1:	c5 f9 70 c8 ee                                  	vpshufd xmm1,xmm0,0xee
   801a6:	c5 f9 d4 c1                                     	vpaddq xmm0,xmm0,xmm1
   801aa:	c4 e1 f9 7e c3                                  	vmovq  rbx,xmm0
   801af:	48 39 c8                                        	cmp    rax,rcx
   801b2:	74 48                                           	je     801fc <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a4c>
   801b4:	a8 1c                                           	test   al,0x1c
   801b6:	74 58                                           	je     80210 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a60>
   801b8:	48 89 ca                                        	mov    rdx,rcx
   801bb:	48 89 c1                                        	mov    rcx,rax
   801be:	48 83 e1 fc                                     	and    rcx,0xfffffffffffffffc
   801c2:	c4 e1 f9 6e c3                                  	vmovq  xmm0,rbx
   801c7:	66 0f 1f 84 00 00 00 00 00                      	nop    WORD PTR [rax+rax*1+0x0]
   801d0:	c4 c1 7d d4 04 d6                               	vpaddq ymm0,ymm0,YMMWORD PTR [r14+rdx*8]
   801d6:	48 83 c2 04                                     	add    rdx,0x4
   801da:	48 39 d1                                        	cmp    rcx,rdx
   801dd:	75 f1                                           	jne    801d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a20>
   801df:	c4 e3 7d 39 c1 01                               	vextracti128 xmm1,ymm0,0x1
   801e5:	c5 f9 d4 c1                                     	vpaddq xmm0,xmm0,xmm1
   801e9:	c5 f9 70 c8 ee                                  	vpshufd xmm1,xmm0,0xee
   801ee:	c5 f9 d4 c1                                     	vpaddq xmm0,xmm0,xmm1
   801f2:	c4 e1 f9 7e c3                                  	vmovq  rbx,xmm0
   801f7:	48 39 c8                                        	cmp    rax,rcx
   801fa:	75 14                                           	jne    80210 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a60>
   801fc:	49 8b 36                                        	mov    rsi,QWORD PTR [r14]
   801ff:	eb 2e                                           	jmp    8022f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a7f>
   80201:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00    	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   80210:	49 03 1c ce                                     	add    rbx,QWORD PTR [r14+rcx*8]
   80214:	48 ff c1                                        	inc    rcx
   80217:	48 39 c8                                        	cmp    rax,rcx
   8021a:	75 f4                                           	jne    80210 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a60>
   8021c:	49 8b 36                                        	mov    rsi,QWORD PTR [r14]
   8021f:	41 bc 01 00 00 00                               	mov    r12d,0x1
   80225:	48 83 f8 01                                     	cmp    rax,0x1
   80229:	0f 84 4a 01 00 00                               	je     80379 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1bc9>
   8022f:	49 8d 4e 08                                     	lea    rcx,[r14+0x8]
   80233:	48 ba ff ff ff ff ff ff ff 1f                   	movabs rdx,0x1fffffffffffffff
   8023d:	4c 8d 04 10                                     	lea    r8,[rax+rdx*1]
   80241:	b2 3d                                           	mov    dl,0x3d
   80243:	c4 c2 e8 f5 d0                                  	bzhi   rdx,r8,rdx
   80248:	48 83 fa 04                                     	cmp    rdx,0x4
   8024c:	73 07                                           	jae    80255 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1aa5>
   8024e:	31 ff                                           	xor    edi,edi
   80250:	e9 0b 01 00 00                                  	jmp    80360 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1bb0>
   80255:	48 83 fa 20                                     	cmp    rdx,0x20
   80259:	73 07                                           	jae    80262 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1ab2>
   8025b:	31 ff                                           	xor    edi,edi
   8025d:	e9 9d 00 00 00                                  	jmp    802ff <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1b4f>
   80262:	48 bf ff ff ff ff ff ff ff 1f                   	movabs rdi,0x1fffffffffffffff
   8026c:	62 f2 fd 48 7c c6                               	vpbroadcastq zmm0,rsi
   80272:	31 f6                                           	xor    esi,esi
   80274:	48 83 c7 e1                                     	add    rdi,0xffffffffffffffe1
   80278:	62 f1 fd 48 6f c8                               	vmovdqa64 zmm1,zmm0
   8027e:	62 f1 fd 48 6f d0                               	vmovdqa64 zmm2,zmm0
   80284:	62 f1 fd 48 6f d8                               	vmovdqa64 zmm3,zmm0
   8028a:	4c 21 c7                                        	and    rdi,r8
   8028d:	62 f2 fd 48 3f 04 f1                            	vpmaxuq zmm0,zmm0,ZMMWORD PTR [rcx+rsi*8]
   80294:	62 f2 f5 48 3f 4c f1 01                         	vpmaxuq zmm1,zmm1,ZMMWORD PTR [rcx+rsi*8+0x40]
   8029c:	62 f2 ed 48 3f 54 f1 02                         	vpmaxuq zmm2,zmm2,ZMMWORD PTR [rcx+rsi*8+0x80]
   802a4:	62 f2 e5 48 3f 5c f1 03                         	vpmaxuq zmm3,zmm3,ZMMWORD PTR [rcx+rsi*8+0xc0]
   802ac:	48 83 c6 20                                     	add    rsi,0x20
   802b0:	48 39 f7                                        	cmp    rdi,rsi
   802b3:	75 d8                                           	jne    8028d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1add>
   802b5:	62 f2 fd 48 3f c1                               	vpmaxuq zmm0,zmm0,zmm1
   802bb:	62 f2 ed 48 3f d3                               	vpmaxuq zmm2,zmm2,zmm3
   802c1:	62 f2 fd 48 3f c2                               	vpmaxuq zmm0,zmm0,zmm2
   802c7:	62 f3 fd 48 3b c1 01                            	vextracti64x4 ymm1,zmm0,0x1
   802ce:	62 f2 fd 48 3f c1                               	vpmaxuq zmm0,zmm0,zmm1
   802d4:	c4 e3 7d 39 c1 01                               	vextracti128 xmm1,ymm0,0x1
   802da:	62 f2 fd 08 3f c1                               	vpmaxuq xmm0,xmm0,xmm1
   802e0:	c5 f9 70 c8 ee                                  	vpshufd xmm1,xmm0,0xee
   802e5:	62 f2 fd 08 3f c1                               	vpmaxuq xmm0,xmm0,xmm1
   802eb:	c4 e1 f9 7e c6                                  	vmovq  rsi,xmm0
   802f0:	48 39 fa                                        	cmp    rdx,rdi
   802f3:	0f 84 7d 00 00 00                               	je     80376 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1bc6>
   802f9:	41 f6 c0 1c                                     	test   r8b,0x1c
   802fd:	74 61                                           	je     80360 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1bb0>
   802ff:	49 b9 ff ff ff ff ff ff ff 1f                   	movabs r9,0x1fffffffffffffff
   80309:	62 f2 fd 28 7c c6                               	vpbroadcastq ymm0,rsi
   8030f:	49 83 c1 fd                                     	add    r9,0xfffffffffffffffd
   80313:	4d 21 c8                                        	and    r8,r9
   80316:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   80320:	62 f2 fd 28 3f 04 f9                            	vpmaxuq ymm0,ymm0,YMMWORD PTR [rcx+rdi*8]
   80327:	48 83 c7 04                                     	add    rdi,0x4
   8032b:	49 39 f8                                        	cmp    r8,rdi
   8032e:	75 f0                                           	jne    80320 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1b70>
   80330:	c4 e3 7d 39 c1 01                               	vextracti128 xmm1,ymm0,0x1
   80336:	4c 89 c7                                        	mov    rdi,r8
   80339:	62 f2 fd 08 3f c1                               	vpmaxuq xmm0,xmm0,xmm1
   8033f:	c5 f9 70 c8 ee                                  	vpshufd xmm1,xmm0,0xee
   80344:	62 f2 fd 08 3f c1                               	vpmaxuq xmm0,xmm0,xmm1
   8034a:	c4 e1 f9 7e c6                                  	vmovq  rsi,xmm0
   8034f:	4c 39 c2                                        	cmp    rdx,r8
   80352:	74 22                                           	je     80376 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1bc6>
   80354:	66 66 66 2e 0f 1f 84 00 00 00 00 00             	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   80360:	49 89 f0                                        	mov    r8,rsi
   80363:	48 8b 34 f9                                     	mov    rsi,QWORD PTR [rcx+rdi*8]
   80367:	49 39 f0                                        	cmp    r8,rsi
   8036a:	49 0f 47 f0                                     	cmova  rsi,r8
   8036e:	48 ff c7                                        	inc    rdi
   80371:	48 39 fa                                        	cmp    rdx,rdi
   80374:	75 ea                                           	jne    80360 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1bb0>
   80376:	49 89 c4                                        	mov    r12,rax
   80379:	48 b8 15 ae 47 e1 7a 14 ae 47                   	movabs rax,0x47ae147ae147ae15
   80383:	48 89 da                                        	mov    rdx,rbx
   80386:	48 bf 29 5c 8f c2 f5 28 5c 8f                   	movabs rdi,0x8f5c28f5c28f5c29
   80390:	48 89 d9                                        	mov    rcx,rbx
   80393:	45 31 c0                                        	xor    r8d,r8d
   80396:	c4 e2 fb f6 c0                                  	mulx   rax,rax,rax
   8039b:	48 0f af fb                                     	imul   rdi,rbx
   8039f:	48 ba 70 3d 0a d7 a3 70 3d 0a                   	movabs rdx,0xa3d70a3d70a3d70
   803a9:	48 29 c1                                        	sub    rcx,rax
   803ac:	48 d1 e9                                        	shr    rcx,1
   803af:	48 01 c1                                        	add    rcx,rax
   803b2:	48 b8 ff ff ff ff ff ff ff 1f                   	movabs rax,0x1fffffffffffffff
   803bc:	48 c1 e9 04                                     	shr    rcx,0x4
   803c0:	48 39 d7                                        	cmp    rdi,rdx
   803c3:	41 0f 97 c0                                     	seta   r8b
   803c7:	49 01 c8                                        	add    r8,rcx
   803ca:	49 39 f0                                        	cmp    r8,rsi
   803cd:	4c 0f 46 c6                                     	cmovbe r8,rsi
   803d1:	49 39 c0                                        	cmp    r8,rax
   803d4:	4a 8d 3c c5 00 00 00 00                         	lea    rdi,[r8*8+0x0]
   803dc:	4c 89 44 24 28                                  	mov    QWORD PTR [rsp+0x28],r8
   803e1:	0f 97 c0                                        	seta   al
   803e4:	48 3b bc 24 00 0c 00 00                         	cmp    rdi,QWORD PTR [rsp+0xc00]
   803ec:	48 89 bc 24 78 01 00 00                         	mov    QWORD PTR [rsp+0x178],rdi
   803f4:	0f 97 c1                                        	seta   cl
   803f7:	08 c1                                           	or     cl,al
   803f9:	74 19                                           	je     80414 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1c64>
   803fb:	31 ff                                           	xor    edi,edi
   803fd:	31 db                                           	xor    ebx,ebx
   803ff:	48 8b b4 24 78 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x178]
   80407:	c5 f8 77                                        	vzeroupper
   8040a:	e8 d2 f3 fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   8040f:	e9 09 4a 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   80414:	48 85 ff                                        	test   rdi,rdi
   80417:	74 50                                           	je     80469 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1cb9>
   80419:	48 81 ff 00 00 02 00                            	cmp    rdi,0x20000
   80420:	72 5f                                           	jb     80481 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1cd1>
   80422:	48 83 cf 01                                     	or     rdi,0x1
   80426:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   80430:	48 39 c7                                        	cmp    rdi,rax
   80433:	0f 83 9c 49 00 00                               	jae    84dd5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6625>
   80439:	be 01 00 00 00                                  	mov    esi,0x1
   8043e:	c5 f8 77                                        	vzeroupper
   80441:	ff 15 c1 c9 01 00                               	call   QWORD PTR [rip+0x1c9c1]        # 9ce08 <calloc@GLIBC_2.2.5>
   80447:	bf 08 00 00 00                                  	mov    edi,0x8
   8044c:	48 85 c0                                        	test   rax,rax
   8044f:	74 ac                                           	je     803fd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1c4d>
   80451:	48 8b 54 24 28                                  	mov    rdx,QWORD PTR [rsp+0x28]
   80456:	48 89 44 24 08                                  	mov    QWORD PTR [rsp+0x8],rax
   8045b:	48 8d 0c d5 00 00 00 00                         	lea    rcx,[rdx*8+0x0]
   80463:	c6 04 08 00                                     	mov    BYTE PTR [rax+rcx*1],0x0
   80467:	eb 39                                           	jmp    804a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1cf2>
   80469:	b8 08 00 00 00                                  	mov    eax,0x8
   8046e:	48 c7 84 24 70 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x170],0x0
   8047a:	48 89 44 24 08                                  	mov    QWORD PTR [rsp+0x8],rax
   8047f:	eb 29                                           	jmp    804aa <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1cfa>
   80481:	be 01 00 00 00                                  	mov    esi,0x1
   80486:	c5 f8 77                                        	vzeroupper
   80489:	ff 15 79 c9 01 00                               	call   QWORD PTR [rip+0x1c979]        # 9ce08 <calloc@GLIBC_2.2.5>
   8048f:	48 8b 54 24 28                                  	mov    rdx,QWORD PTR [rsp+0x28]
   80494:	48 89 44 24 08                                  	mov    QWORD PTR [rsp+0x8],rax
   80499:	48 85 c0                                        	test   rax,rax
   8049c:	0f 84 33 49 00 00                               	je     84dd5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6625>
   804a2:	48 89 94 24 70 01 00 00                         	mov    QWORD PTR [rsp+0x170],rdx
   804aa:	4f 8d 2c e6                                     	lea    r13,[r14+r12*8]
   804ae:	4c 89 a4 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],r12
   804b6:	4d 85 e4                                        	test   r12,r12
   804b9:	0f 84 45 02 00 00                               	je     80704 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f54>
   804bf:	48 83 7c 24 28 00                               	cmp    QWORD PTR [rsp+0x28],0x0
   804c5:	0f 84 0f 02 00 00                               	je     806da <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f2a>
   804cb:	4c 8b 54 24 28                                  	mov    r10,QWORD PTR [rsp+0x28]
   804d0:	31 f6                                           	xor    esi,esi
   804d2:	4c 89 f7                                        	mov    rdi,r14
   804d5:	eb 16                                           	jmp    804ed <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d3d>
   804d7:	66 0f 1f 84 00 00 00 00 00                      	nop    WORD PTR [rax+rax*1+0x0]
   804e0:	48 83 c7 08                                     	add    rdi,0x8
   804e4:	4c 39 ef                                        	cmp    rdi,r13
   804e7:	0f 84 17 02 00 00                               	je     80704 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f54>
   804ed:	4c 8b 07                                        	mov    r8,QWORD PTR [rdi]
   804f0:	4d 85 c0                                        	test   r8,r8
   804f3:	74 eb                                           	je     804e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d30>
   804f5:	4d 89 c1                                        	mov    r9,r8
   804f8:	49 83 e1 07                                     	and    r9,0x7
   804fc:	48 89 f1                                        	mov    rcx,rsi
   804ff:	75 38                                           	jne    80539 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d89>
   80501:	4c 01 c6                                        	add    rsi,r8
   80504:	49 83 f8 08                                     	cmp    r8,0x8
   80508:	72 d6                                           	jb     804e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d30>
   8050a:	49 89 f0                                        	mov    r8,rsi
   8050d:	49 f7 d8                                        	neg    r8
   80510:	48 83 c1 07                                     	add    rcx,0x7
   80514:	eb 5e                                           	jmp    80574 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1dc4>
   80516:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   80520:	48 89 c8                                        	mov    rax,rcx
   80523:	31 d2                                           	xor    edx,edx
   80525:	49 f7 f2                                        	div    r10
   80528:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   8052d:	48 ff c1                                        	inc    rcx
   80530:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   80534:	49 ff c9                                        	dec    r9
   80537:	74 c8                                           	je     80501 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d51>
   80539:	48 89 c8                                        	mov    rax,rcx
   8053c:	4c 09 d0                                        	or     rax,r10
   8053f:	48 c1 e8 20                                     	shr    rax,0x20
   80543:	75 db                                           	jne    80520 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d70>
   80545:	89 c8                                           	mov    eax,ecx
   80547:	31 d2                                           	xor    edx,edx
   80549:	41 f7 f2                                        	div    r10d
   8054c:	eb da                                           	jmp    80528 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d78>
   8054e:	66 90                                           	xchg   ax,ax
   80550:	48 89 c8                                        	mov    rax,rcx
   80553:	31 d2                                           	xor    edx,edx
   80555:	49 f7 f1                                        	div    r9
   80558:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   8055d:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   80561:	49 8d 44 08 08                                  	lea    rax,[r8+rcx*1+0x8]
   80566:	48 83 c1 08                                     	add    rcx,0x8
   8056a:	48 83 f8 07                                     	cmp    rax,0x7
   8056e:	0f 84 6c ff ff ff                               	je     804e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d30>
   80574:	4c 8b 4c 24 28                                  	mov    r9,QWORD PTR [rsp+0x28]
   80579:	48 8d 41 f9                                     	lea    rax,[rcx-0x7]
   8057d:	48 89 c2                                        	mov    rdx,rax
   80580:	4c 09 ca                                        	or     rdx,r9
   80583:	48 c1 ea 20                                     	shr    rdx,0x20
   80587:	74 07                                           	je     80590 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1de0>
   80589:	31 d2                                           	xor    edx,edx
   8058b:	49 f7 f1                                        	div    r9
   8058e:	eb 05                                           	jmp    80595 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1de5>
   80590:	31 d2                                           	xor    edx,edx
   80592:	41 f7 f1                                        	div    r9d
   80595:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   8059a:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   8059e:	48 8d 41 fa                                     	lea    rax,[rcx-0x6]
   805a2:	48 89 c2                                        	mov    rdx,rax
   805a5:	4c 09 ca                                        	or     rdx,r9
   805a8:	48 c1 ea 20                                     	shr    rdx,0x20
   805ac:	74 12                                           	je     805c0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1e10>
   805ae:	31 d2                                           	xor    edx,edx
   805b0:	49 f7 f1                                        	div    r9
   805b3:	eb 10                                           	jmp    805c5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1e15>
   805b5:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   805c0:	31 d2                                           	xor    edx,edx
   805c2:	41 f7 f1                                        	div    r9d
   805c5:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   805ca:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   805ce:	48 8d 41 fb                                     	lea    rax,[rcx-0x5]
   805d2:	48 89 c2                                        	mov    rdx,rax
   805d5:	4c 09 ca                                        	or     rdx,r9
   805d8:	48 c1 ea 20                                     	shr    rdx,0x20
   805dc:	74 12                                           	je     805f0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1e40>
   805de:	31 d2                                           	xor    edx,edx
   805e0:	49 f7 f1                                        	div    r9
   805e3:	eb 10                                           	jmp    805f5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1e45>
   805e5:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   805f0:	31 d2                                           	xor    edx,edx
   805f2:	41 f7 f1                                        	div    r9d
   805f5:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   805fa:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   805fe:	48 8d 41 fc                                     	lea    rax,[rcx-0x4]
   80602:	48 89 c2                                        	mov    rdx,rax
   80605:	4c 09 ca                                        	or     rdx,r9
   80608:	48 c1 ea 20                                     	shr    rdx,0x20
   8060c:	74 12                                           	je     80620 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1e70>
   8060e:	31 d2                                           	xor    edx,edx
   80610:	49 f7 f1                                        	div    r9
   80613:	eb 10                                           	jmp    80625 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1e75>
   80615:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   80620:	31 d2                                           	xor    edx,edx
   80622:	41 f7 f1                                        	div    r9d
   80625:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   8062a:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   8062e:	48 8d 41 fd                                     	lea    rax,[rcx-0x3]
   80632:	48 89 c2                                        	mov    rdx,rax
   80635:	4c 09 ca                                        	or     rdx,r9
   80638:	48 c1 ea 20                                     	shr    rdx,0x20
   8063c:	74 12                                           	je     80650 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1ea0>
   8063e:	31 d2                                           	xor    edx,edx
   80640:	49 f7 f1                                        	div    r9
   80643:	eb 10                                           	jmp    80655 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1ea5>
   80645:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   80650:	31 d2                                           	xor    edx,edx
   80652:	41 f7 f1                                        	div    r9d
   80655:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   8065a:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   8065e:	48 8d 41 fe                                     	lea    rax,[rcx-0x2]
   80662:	48 89 c2                                        	mov    rdx,rax
   80665:	4c 09 ca                                        	or     rdx,r9
   80668:	48 c1 ea 20                                     	shr    rdx,0x20
   8066c:	74 12                                           	je     80680 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1ed0>
   8066e:	31 d2                                           	xor    edx,edx
   80670:	49 f7 f1                                        	div    r9
   80673:	eb 10                                           	jmp    80685 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1ed5>
   80675:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   80680:	31 d2                                           	xor    edx,edx
   80682:	41 f7 f1                                        	div    r9d
   80685:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   8068a:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   8068e:	48 8d 41 ff                                     	lea    rax,[rcx-0x1]
   80692:	48 89 c2                                        	mov    rdx,rax
   80695:	4c 09 ca                                        	or     rdx,r9
   80698:	48 c1 ea 20                                     	shr    rdx,0x20
   8069c:	74 12                                           	je     806b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f00>
   8069e:	31 d2                                           	xor    edx,edx
   806a0:	49 f7 f1                                        	div    r9
   806a3:	eb 10                                           	jmp    806b5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f05>
   806a5:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   806b0:	31 d2                                           	xor    edx,edx
   806b2:	41 f7 f1                                        	div    r9d
   806b5:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   806ba:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   806be:	48 89 c8                                        	mov    rax,rcx
   806c1:	4c 09 c8                                        	or     rax,r9
   806c4:	48 c1 e8 20                                     	shr    rax,0x20
   806c8:	0f 85 82 fe ff ff                               	jne    80550 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1da0>
   806ce:	89 c8                                           	mov    eax,ecx
   806d0:	31 d2                                           	xor    edx,edx
   806d2:	41 f7 f1                                        	div    r9d
   806d5:	e9 7e fe ff ff                                  	jmp    80558 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1da8>
   806da:	48 8b 84 24 00 01 00 00                         	mov    rax,QWORD PTR [rsp+0x100]
   806e2:	31 c9                                           	xor    ecx,ecx
   806e4:	48 8d 04 c5 00 00 00 00                         	lea    rax,[rax*8+0x0]
   806ec:	0f 1f 40 00                                     	nop    DWORD PTR [rax+0x0]
   806f0:	49 83 3c 0e 00                                  	cmp    QWORD PTR [r14+rcx*1],0x0
   806f5:	0f 85 35 46 00 00                               	jne    84d30 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6580>
   806fb:	48 83 c1 08                                     	add    rcx,0x8
   806ff:	48 39 c8                                        	cmp    rax,rcx
   80702:	75 ec                                           	jne    806f0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f40>
   80704:	31 c0                                           	xor    eax,eax
   80706:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   80710:	48 8b 4c 24 28                                  	mov    rcx,QWORD PTR [rsp+0x28]
   80715:	48 8d 0c cd 00 00 00 00                         	lea    rcx,[rcx*8+0x0]
   8071d:	48 39 c1                                        	cmp    rcx,rax
   80720:	74 30                                           	je     80752 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1fa2>
   80722:	48 8b 4c 24 08                                  	mov    rcx,QWORD PTR [rsp+0x8]
   80727:	48 83 3c 01 1a                                  	cmp    QWORD PTR [rcx+rax*1],0x1a
   8072c:	48 8d 40 08                                     	lea    rax,[rax+0x8]
   80730:	72 de                                           	jb     80710 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f60>
   80732:	48 8d 3d 31 28 f9 ff                            	lea    rdi,[rip+0xfffffffffff92831]        # 12f6a <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x46aa>
   80739:	48 8d 15 f8 c1 01 00                            	lea    rdx,[rip+0x1c1f8]        # 9c938 <__frame_dummy_init_array_entry+0x28d8>
   80740:	be 36 00 00 00                                  	mov    esi,0x36
   80745:	c5 f8 77                                        	vzeroupper
   80748:	e8 d3 19 fb ff                                  	call   32120 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
   8074d:	e9 cb 46 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   80752:	4c 8b 64 24 28                                  	mov    r12,QWORD PTR [rsp+0x28]
   80757:	48 8b 74 24 08                                  	mov    rsi,QWORD PTR [rsp+0x8]
   8075c:	48 8d bc 24 a8 01 00 00                         	lea    rdi,[rsp+0x1a8]
   80764:	4c 89 e2                                        	mov    rdx,r12
   80767:	c5 f8 77                                        	vzeroupper
   8076a:	e8 21 4c 00 00                                  	call   85390 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns14prefix_offsets>
   8076f:	48 8b 94 24 b8 01 00 00                         	mov    rdx,QWORD PTR [rsp+0x1b8]
   80777:	49 39 d4                                        	cmp    r12,rdx
   8077a:	0f 87 d3 43 00 00                               	ja     84b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63a3>
   80780:	4c 89 e0                                        	mov    rax,r12
   80783:	48 c1 e8 3c                                     	shr    rax,0x3c
   80787:	74 1a                                           	je     807a3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1ff3>
   80789:	4c 8b a4 24 78 01 00 00                         	mov    r12,QWORD PTR [rsp+0x178]
   80791:	31 db                                           	xor    ebx,ebx
   80793:	48 89 df                                        	mov    rdi,rbx
   80796:	4c 89 e6                                        	mov    rsi,r12
   80799:	e8 43 f0 fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   8079e:	e9 7a 46 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   807a3:	48 89 9c 24 80 01 00 00                         	mov    QWORD PTR [rsp+0x180],rbx
   807ab:	4d 85 e4                                        	test   r12,r12
   807ae:	74 57                                           	je     80807 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2057>
   807b0:	48 8b 84 24 b0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1b0]
   807b8:	48 89 84 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],rax
   807c0:	4e 8d 24 e5 00 00 00 00                         	lea    r12,[r12*8+0x0]
   807c8:	bf 08 00 00 00                                  	mov    edi,0x8
   807cd:	bb 08 00 00 00                                  	mov    ebx,0x8
   807d2:	31 d2                                           	xor    edx,edx
   807d4:	4c 89 e6                                        	mov    rsi,r12
   807d7:	e8 e4 83 01 00                                  	call   98bc0 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
   807dc:	48 85 c0                                        	test   rax,rax
   807df:	74 b2                                           	je     80793 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1fe3>
   807e1:	48 8b b4 24 80 06 00 00                         	mov    rsi,QWORD PTR [rsp+0x680]
   807e9:	48 89 84 24 c0 00 00 00                         	mov    QWORD PTR [rsp+0xc0],rax
   807f1:	48 89 c7                                        	mov    rdi,rax
   807f4:	4c 89 e2                                        	mov    rdx,r12
   807f7:	ff 15 e3 c5 01 00                               	call   QWORD PTR [rip+0x1c5e3]        # 9cde0 <memcpy@GLIBC_2.14>
   807fd:	48 8b 9c 24 80 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x180]
   80805:	eb 0d                                           	jmp    80814 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2064>
   80807:	b8 08 00 00 00                                  	mov    eax,0x8
   8080c:	48 89 84 24 c0 00 00 00                         	mov    QWORD PTR [rsp+0xc0],rax
   80814:	48 b8 ff ff ff ff ff ff ff 3f                   	movabs rax,0x3fffffffffffffff
   8081e:	4c 8d 24 9d 00 00 00 00                         	lea    r12,[rbx*4+0x0]
   80826:	48 39 c3                                        	cmp    rbx,rax
   80829:	0f 97 c0                                        	seta   al
   8082c:	4c 3b a4 24 c0 0b 00 00                         	cmp    r12,QWORD PTR [rsp+0xbc0]
   80834:	0f 97 c1                                        	seta   cl
   80837:	08 c1                                           	or     cl,al
   80839:	74 12                                           	je     8084d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x209d>
   8083b:	31 db                                           	xor    ebx,ebx
   8083d:	48 89 df                                        	mov    rdi,rbx
   80840:	4c 89 e6                                        	mov    rsi,r12
   80843:	e8 99 ef fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   80848:	e9 d0 45 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   8084d:	4d 85 e4                                        	test   r12,r12
   80850:	74 31                                           	je     80883 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x20d3>
   80852:	bf 04 00 00 00                                  	mov    edi,0x4
   80857:	ba 01 00 00 00                                  	mov    edx,0x1
   8085c:	4c 89 e6                                        	mov    rsi,r12
   8085f:	bb 04 00 00 00                                  	mov    ebx,0x4
   80864:	e8 57 83 01 00                                  	call   98bc0 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
   80869:	48 85 c0                                        	test   rax,rax
   8086c:	74 cf                                           	je     8083d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x208d>
   8086e:	48 8b 9c 24 80 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x180]
   80876:	49 89 c4                                        	mov    r12,rax
   80879:	48 89 9c 24 68 01 00 00                         	mov    QWORD PTR [rsp+0x168],rbx
   80881:	eb 12                                           	jmp    80895 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x20e5>
   80883:	41 bc 04 00 00 00                               	mov    r12d,0x4
   80889:	48 c7 84 24 68 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x168],0x0
   80895:	48 83 bc 24 00 01 00 00 00                      	cmp    QWORD PTR [rsp+0x100],0x0
   8089e:	0f 84 a8 00 00 00                               	je     8094c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x219c>
   808a4:	31 c9                                           	xor    ecx,ecx
   808a6:	4c 89 f6                                        	mov    rsi,r14
   808a9:	45 31 c0                                        	xor    r8d,r8d
   808ac:	eb 13                                           	jmp    808c1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2111>
   808ae:	4c 89 d1                                        	mov    rcx,r10
   808b1:	48 83 c6 08                                     	add    rsi,0x8
   808b5:	41 ff c0                                        	inc    r8d
   808b8:	4c 39 ee                                        	cmp    rsi,r13
   808bb:	0f 84 8b 00 00 00                               	je     8094c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x219c>
   808c1:	4c 8b 0e                                        	mov    r9,QWORD PTR [rsi]
   808c4:	4c 3b 4c 24 28                                  	cmp    r9,QWORD PTR [rsp+0x28]
   808c9:	0f 87 60 42 00 00                               	ja     84b2f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x637f>
   808cf:	4d 85 c9                                        	test   r9,r9
   808d2:	74 dd                                           	je     808b1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2101>
   808d4:	4e 8d 14 09                                     	lea    r10,[rcx+r9*1]
   808d8:	eb 2d                                           	jmp    80907 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2157>
   808da:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   808e0:	89 c8                                           	mov    eax,ecx
   808e2:	31 d2                                           	xor    edx,edx
   808e4:	f7 f7                                           	div    edi
   808e6:	48 8b 84 24 c0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xc0]
   808ee:	48 8b 3c d0                                     	mov    rdi,QWORD PTR [rax+rdx*8]
   808f2:	48 39 df                                        	cmp    rdi,rbx
   808f5:	73 3a                                           	jae    80931 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2181>
   808f7:	45 89 04 bc                                     	mov    DWORD PTR [r12+rdi*4],r8d
   808fb:	48 ff 04 d0                                     	inc    QWORD PTR [rax+rdx*8]
   808ff:	48 ff c1                                        	inc    rcx
   80902:	49 ff c9                                        	dec    r9
   80905:	74 a7                                           	je     808ae <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x20fe>
   80907:	48 8b 7c 24 28                                  	mov    rdi,QWORD PTR [rsp+0x28]
   8090c:	48 89 c8                                        	mov    rax,rcx
   8090f:	48 09 f8                                        	or     rax,rdi
   80912:	48 c1 e8 20                                     	shr    rax,0x20
   80916:	74 c8                                           	je     808e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2130>
   80918:	48 89 c8                                        	mov    rax,rcx
   8091b:	31 d2                                           	xor    edx,edx
   8091d:	48 f7 f7                                        	div    rdi
   80920:	48 8b 84 24 c0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xc0]
   80928:	48 8b 3c d0                                     	mov    rdi,QWORD PTR [rax+rdx*8]
   8092c:	48 39 df                                        	cmp    rdi,rbx
   8092f:	72 c6                                           	jb     808f7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2147>
   80931:	48 89 de                                        	mov    rsi,rbx
   80934:	b3 01                                           	mov    bl,0x1
   80936:	4c 8b 7c 24 28                                  	mov    r15,QWORD PTR [rsp+0x28]
   8093b:	48 8d 15 b6 c0 01 00                            	lea    rdx,[rip+0x1c0b6]        # 9c9f8 <__frame_dummy_init_array_entry+0x2998>
   80942:	e8 0d 0a fb ff                                  	call   31354 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   80947:	e9 d1 44 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   8094c:	48 8b b4 24 50 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x150]
   80954:	48 85 f6                                        	test   rsi,rsi
   80957:	74 11                                           	je     8096a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x21ba>
   80959:	48 c1 e6 03                                     	shl    rsi,0x3
   8095d:	ba 08 00 00 00                                  	mov    edx,0x8
   80962:	4c 89 f7                                        	mov    rdi,r14
   80965:	e8 b6 2b fa ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   8096a:	48 8b 84 24 70 01 00 00                         	mov    rax,QWORD PTR [rsp+0x170]
   80972:	48 85 c0                                        	test   rax,rax
   80975:	74 17                                           	je     8098e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x21de>
   80977:	48 8d 34 c5 00 00 00 00                         	lea    rsi,[rax*8+0x0]
   8097f:	48 8b 7c 24 08                                  	mov    rdi,QWORD PTR [rsp+0x8]
   80984:	ba 08 00 00 00                                  	mov    edx,0x8
   80989:	e8 92 2b fa ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   8098e:	48 8b 44 24 28                                  	mov    rax,QWORD PTR [rsp+0x28]
   80993:	48 85 c0                                        	test   rax,rax
   80996:	74 1a                                           	je     809b2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2202>
   80998:	48 8b bc 24 c0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc0]
   809a0:	48 8d 34 c5 00 00 00 00                         	lea    rsi,[rax*8+0x0]
   809a8:	ba 08 00 00 00                                  	mov    edx,0x8
   809ad:	e8 6e 2b fa ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   809b2:	4c 89 64 24 58                                  	mov    QWORD PTR [rsp+0x58],r12
   809b7:	48 c7 84 24 40 02 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x240],0x0
   809c3:	48 8d bc 24 40 02 00 00                         	lea    rdi,[rsp+0x240]
   809cb:	be 40 00 00 00                                  	mov    esi,0x40
   809d0:	ba 00 64 00 00                                  	mov    edx,0x6400
   809d5:	ff 15 25 c4 01 00                               	call   QWORD PTR [rip+0x1c425]        # 9ce00 <posix_memalign@GLIBC_2.2.5>
   809db:	85 c0                                           	test   eax,eax
   809dd:	0f 85 fc 43 00 00                               	jne    84ddf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x662f>
   809e3:	48 8b bc 24 40 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x240]
   809eb:	48 85 ff                                        	test   rdi,rdi
   809ee:	0f 84 eb 43 00 00                               	je     84ddf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x662f>
   809f4:	c5 fd 6f 05 84 75 f8 ff                         	vmovdqa ymm0,YMMWORD PTR [rip+0xfffffffffff87584]        # 7f80 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x800>
   809fc:	48 83 7c 24 28 00                               	cmp    QWORD PTR [rsp+0x28],0x0
   80a02:	49 bc 31 e1 72 4e 64 30 00 00                   	movabs r12,0x30644e72e131
   80a0c:	48 b8 07 9a c1 77 0a 0e 00 00                   	movabs rax,0xe0a77c19a07
   80a16:	48 c7 84 24 e8 00 00 00 19 00 00 00             	mov    QWORD PTR [rsp+0xe8],0x19
   80a22:	48 89 bc 24 f0 00 00 00                         	mov    QWORD PTR [rsp+0xf0],rdi
   80a2a:	48 c7 84 24 f8 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xf8],0x0
   80a36:	c5 fe 7f 84 24 40 02 00 00                      	vmovdqu YMMWORD PTR [rsp+0x240],ymm0
   80a3f:	48 89 84 24 60 02 00 00                         	mov    QWORD PTR [rsp+0x260],rax
   80a47:	0f 84 b6 36 00 00                               	je     84103 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5953>
   80a4d:	62 f2 fd 48 19 4c 24 4a                         	vbroadcastsd zmm1,QWORD PTR [rsp+0x250]
   80a55:	62 f2 fd 48 59 44 24 49                         	vpbroadcastq zmm0,QWORD PTR [rsp+0x248]
   80a5d:	62 f2 fd 48 59 54 24 4b                         	vpbroadcastq zmm2,QWORD PTR [rsp+0x258]
   80a65:	48 8d 05 fc be 01 00                            	lea    rax,[rip+0x1befc]        # 9c968 <__frame_dummy_init_array_entry+0x2908>
   80a6c:	4c 8d b4 24 80 02 00 00                         	lea    r14,[rsp+0x280]
   80a74:	41 bd ff ff ff ff                               	mov    r13d,0xffffffff
   80a7a:	31 d2                                           	xor    edx,edx
   80a7c:	48 89 84 24 a8 00 00 00                         	mov    QWORD PTR [rsp+0xa8],rax
   80a84:	48 8d 05 f5 bc 01 00                            	lea    rax,[rip+0x1bcf5]        # 9c780 <__frame_dummy_init_array_entry+0x2720>
   80a8b:	48 89 44 24 10                                  	mov    QWORD PTR [rsp+0x10],rax
   80a90:	62 f1 7c 48 29 4c 24 2d                         	vmovaps ZMMWORD PTR [rsp+0xb40],zmm1
   80a98:	62 f2 fd 48 59 4c 24 4c                         	vpbroadcastq zmm1,QWORD PTR [rsp+0x260]
   80aa0:	62 f1 fd 48 7f 44 24 2e                         	vmovdqa64 ZMMWORD PTR [rsp+0xb80],zmm0
   80aa8:	62 f1 fd 48 7f 54 24 2c                         	vmovdqa64 ZMMWORD PTR [rsp+0xb00],zmm2
   80ab0:	62 f1 fd 48 7f 4c 24 2b                         	vmovdqa64 ZMMWORD PTR [rsp+0xac0],zmm1
   80ab8:	eb 2e                                           	jmp    80ae8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2338>
   80aba:	62 71 fd 48 7f 5c 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm11
   80ac2:	62 71 fd 48 7f 54 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm10
   80aca:	62 f1 fd 48 7f 74 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm6
   80ad2:	48 8b 84 24 68 06 00 00                         	mov    rax,QWORD PTR [rsp+0x668]
   80ada:	48 89 c2                                        	mov    rdx,rax
   80add:	48 3b 44 24 28                                  	cmp    rax,QWORD PTR [rsp+0x28]
   80ae2:	0f 84 00 36 00 00                               	je     840e8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5938>
   80ae8:	62 f2 fd 48 59 05 8e 69 f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff8698e]        # 7480 <GCC_except_table746+0x10c>
   80af2:	62 f1 7c 48 28 54 24 2e                         	vmovaps zmm2,ZMMWORD PTR [rsp+0xb80]
   80afa:	62 f1 7c 48 28 4c 24 2d                         	vmovaps zmm1,ZMMWORD PTR [rsp+0xb40]
   80b02:	48 8b b4 24 b8 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x1b8]
   80b0a:	48 c7 84 24 f8 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xf8],0x0
   80b16:	62 f1 fd 48 7f 44 24 33                         	vmovdqa64 ZMMWORD PTR [rsp+0xcc0],zmm0
   80b1e:	62 f1 7c 48 29 54 24 34                         	vmovaps ZMMWORD PTR [rsp+0xd00],zmm2
   80b26:	62 f1 7c 48 29 4c 24 35                         	vmovaps ZMMWORD PTR [rsp+0xd40],zmm1
   80b2e:	62 f1 fd 48 6f 54 24 2c                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xb00]
   80b36:	62 f1 fd 48 6f 4c 24 2b                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0xac0]
   80b3e:	62 f1 fd 48 7f 54 24 36                         	vmovdqa64 ZMMWORD PTR [rsp+0xd80],zmm2
   80b46:	62 f1 fd 48 7f 4c 24 37                         	vmovdqa64 ZMMWORD PTR [rsp+0xdc0],zmm1
   80b4e:	48 39 f2                                        	cmp    rdx,rsi
   80b51:	0f 83 0c 42 00 00                               	jae    84d63 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65b3>
   80b57:	48 8d 4a 01                                     	lea    rcx,[rdx+0x1]
   80b5b:	48 39 f1                                        	cmp    rcx,rsi
   80b5e:	0f 83 f0 41 00 00                               	jae    84d54 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x65a4>
   80b64:	48 8b 84 24 b0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1b0]
   80b6c:	48 89 8c 24 68 06 00 00                         	mov    QWORD PTR [rsp+0x668],rcx
   80b74:	48 8b 3c d0                                     	mov    rdi,QWORD PTR [rax+rdx*8]
   80b78:	48 8b 34 c8                                     	mov    rsi,QWORD PTR [rax+rcx*8]
   80b7c:	48 39 fe                                        	cmp    rsi,rdi
   80b7f:	0f 82 8e 3f 00 00                               	jb     84b13 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6363>
   80b85:	48 39 de                                        	cmp    rsi,rbx
   80b88:	0f 87 85 3f 00 00                               	ja     84b13 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6363>
   80b8e:	48 39 f7                                        	cmp    rdi,rsi
   80b91:	0f 85 04 17 00 00                               	jne    8229b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3aeb>
   80b97:	48 8d bc 24 40 02 00 00                         	lea    rdi,[rsp+0x240]
   80b9f:	48 8d b4 24 c0 0c 00 00                         	lea    rsi,[rsp+0xcc0]
   80ba7:	c5 f8 77                                        	vzeroupper
   80baa:	e8 c1 4a 00 00                                  	call   85670 <_RNvMs3_NtCsHW5vo2gROj_10zopro_core4simdNtB5_7FqBatch15inverse_nonzero>
   80baf:	48 8b 84 24 f8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xf8]
   80bb7:	48 8b 9c 24 80 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x180]
   80bbf:	48 85 c0                                        	test   rax,rax
   80bc2:	0f 84 0a ff ff ff                               	je     80ad2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2322>
   80bc8:	62 71 fd 48 6f 5c 24 09                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x240]
   80bd0:	62 71 fd 48 6f 54 24 0a                         	vmovdqa64 zmm10,ZMMWORD PTR [rsp+0x280]
   80bd8:	62 f1 fd 48 6f 74 24 0b                         	vmovdqa64 zmm6,ZMMWORD PTR [rsp+0x2c0]
   80be0:	62 f1 fd 48 6f 7c 24 0c                         	vmovdqa64 zmm7,ZMMWORD PTR [rsp+0x300]
   80be8:	62 f1 fd 48 6f 44 24 0d                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x340]
   80bf0:	48 8b 8c 24 f0 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xf0]
   80bf8:	48 8b 94 24 98 00 00 00                         	mov    rdx,QWORD PTR [rsp+0x98]
   80c00:	48 8b b4 24 a0 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xa0]
   80c08:	48 c1 e0 0a                                     	shl    rax,0xa
   80c0c:	0f 1f 40 00                                     	nop    DWORD PTR [rax+0x0]
   80c10:	8b 7c 01 c0                                     	mov    edi,DWORD PTR [rcx+rax*1-0x40]
   80c14:	48 39 fe                                        	cmp    rsi,rdi
   80c17:	0f 86 2a 40 00 00                               	jbe    84c47 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6497>
   80c1d:	62 61 fd 28 6f 0d b9 73 f8 ff                   	vmovdqa64 ymm25,YMMWORD PTR [rip+0xfffffffffff873b9]        # 7fe0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x860>
   80c27:	62 62 fd 48 59 35 07 69 f8 ff                   	vpbroadcastq zmm30,QWORD PTR [rip+0xfffffffffff86907]        # 7538 <GCC_except_table746+0x1c4>
   80c31:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   80c36:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   80c3c:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   80c42:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   80c48:	62 62 fd 48 59 3d ae 67 f8 ff                   	vpbroadcastq zmm31,QWORD PTR [rip+0xfffffffffff867ae]        # 7400 <GCC_except_table746+0x8c>
   80c52:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   80c58:	62 62 fd 48 59 05 d6 67 f8 ff                   	vpbroadcastq zmm24,QWORD PTR [rip+0xfffffffffff867d6]        # 7438 <GCC_except_table746+0xc4>
   80c62:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   80c68:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   80c6c:	62 62 fd 48 59 15 92 67 f8 ff                   	vpbroadcastq zmm26,QWORD PTR [rip+0xfffffffffff86792]        # 7408 <GCC_except_table746+0x94>
   80c76:	62 62 fd 48 59 1d 60 68 f8 ff                   	vpbroadcastq zmm27,QWORD PTR [rip+0xfffffffffff86860]        # 74e0 <GCC_except_table746+0x16c>
   80c80:	62 a1 4d 00 ef f6                               	vpxord xmm22,xmm22,xmm22
   80c86:	62 a1 45 00 ef ff                               	vpxord xmm23,xmm23,xmm23
   80c8c:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   80c92:	49 b8 63 c2 e5 9c c8 60 00 00                   	movabs r8,0x60c89ce5c263
   80c9c:	48 69 ff c0 02 00 00                            	imul   rdi,rdi,0x2c0
   80ca3:	62 01 1d 00 ef e4                               	vpxord xmm28,xmm28,xmm28
   80ca9:	62 01 15 00 ef ed                               	vpxord xmm29,xmm29,xmm29
   80caf:	62 61 fe 28 7f 4c 24 22                         	vmovdqu64 YMMWORD PTR [rsp+0x440],ymm25
   80cb7:	4c 89 a4 24 60 04 00 00                         	mov    QWORD PTR [rsp+0x460],r12
   80cbf:	62 71 fd 48 6f 6c 01 f5                         	vmovdqa64 zmm13,ZMMWORD PTR [rcx+rax*1-0x2c0]
   80cc7:	62 71 fd 48 6f 64 01 f6                         	vmovdqa64 zmm12,ZMMWORD PTR [rcx+rax*1-0x280]
   80ccf:	62 71 fd 48 6f 4c 01 f7                         	vmovdqa64 zmm9,ZMMWORD PTR [rcx+rax*1-0x240]
   80cd7:	62 71 fd 48 6f 44 01 f8                         	vmovdqa64 zmm8,ZMMWORD PTR [rcx+rax*1-0x200]
   80cdf:	62 71 fd 48 6f 74 01 f9                         	vmovdqa64 zmm14,ZMMWORD PTR [rcx+rax*1-0x1c0]
   80ce7:	62 f2 fd 48 59 a4 24 48 04 00 00                	vpbroadcastq zmm4,QWORD PTR [rsp+0x448]
   80cf2:	62 f2 fd 48 59 9c 24 50 04 00 00                	vpbroadcastq zmm3,QWORD PTR [rsp+0x450]
   80cfd:	62 f2 fd 48 59 94 24 58 04 00 00                	vpbroadcastq zmm2,QWORD PTR [rsp+0x458]
   80d08:	62 f2 fd 48 59 8c 24 60 04 00 00                	vpbroadcastq zmm1,QWORD PTR [rsp+0x460]
   80d13:	62 61 fe 28 7f 4c 24 22                         	vmovdqu64 YMMWORD PTR [rsp+0x440],ymm25
   80d1b:	4c 89 a4 24 60 04 00 00                         	mov    QWORD PTR [rsp+0x460],r12
   80d23:	62 c2 9d 48 b5 cb                               	vpmadd52huq zmm17,zmm12,zmm11
   80d29:	62 c2 b5 48 b5 d3                               	vpmadd52huq zmm18,zmm9,zmm11
   80d2f:	62 c2 bd 48 b5 c3                               	vpmadd52huq zmm16,zmm8,zmm11
   80d35:	62 52 95 48 b4 fb                               	vpmadd52luq zmm15,zmm13,zmm11
   80d3b:	62 c2 95 48 b5 db                               	vpmadd52huq zmm19,zmm13,zmm11
   80d41:	62 d2 8d 48 b5 eb                               	vpmadd52huq zmm5,zmm14,zmm11
   80d47:	62 82 85 48 b4 e6                               	vpmadd52luq zmm20,zmm15,zmm30
   80d4d:	62 c2 b5 48 b4 cb                               	vpmadd52luq zmm17,zmm9,zmm11
   80d53:	62 c2 bd 48 b4 d3                               	vpmadd52luq zmm18,zmm8,zmm11
   80d59:	62 c2 8d 48 b4 c3                               	vpmadd52luq zmm16,zmm14,zmm11
   80d5f:	62 c2 9d 48 b4 db                               	vpmadd52luq zmm19,zmm12,zmm11
   80d65:	62 11 85 48 d4 ff                               	vpaddq zmm15,zmm15,zmm31
   80d6b:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   80d72:	62 e2 dd 40 b5 cc                               	vpmadd52huq zmm17,zmm20,zmm4
   80d78:	62 e2 dd 40 b5 d3                               	vpmadd52huq zmm18,zmm20,zmm3
   80d7e:	62 e2 dd 40 b5 c2                               	vpmadd52huq zmm16,zmm20,zmm2
   80d84:	62 12 dd 40 b5 f8                               	vpmadd52huq zmm15,zmm20,zmm24
   80d8a:	62 e2 dd 40 b4 dc                               	vpmadd52luq zmm19,zmm20,zmm4
   80d90:	62 f2 dd 40 b5 e9                               	vpmadd52huq zmm5,zmm20,zmm1
   80d96:	62 e2 dd 40 b4 cb                               	vpmadd52luq zmm17,zmm20,zmm3
   80d9c:	62 e2 dd 40 b4 d2                               	vpmadd52luq zmm18,zmm20,zmm2
   80da2:	62 e2 dd 40 b4 c1                               	vpmadd52luq zmm16,zmm20,zmm1
   80da8:	62 c1 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm15
   80dae:	62 d2 bd 48 b5 ea                               	vpmadd52huq zmm5,zmm8,zmm10
   80db4:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   80dba:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   80dbf:	62 52 8d 48 b5 fa                               	vpmadd52huq zmm15,zmm14,zmm10
   80dc5:	62 c2 95 48 b4 da                               	vpmadd52luq zmm19,zmm13,zmm10
   80dcb:	62 c2 95 48 b5 ca                               	vpmadd52huq zmm17,zmm13,zmm10
   80dd1:	62 c2 9d 48 b5 d2                               	vpmadd52huq zmm18,zmm12,zmm10
   80dd7:	62 c2 b5 48 b5 c2                               	vpmadd52huq zmm16,zmm9,zmm10
   80ddd:	62 d2 8d 48 b4 ea                               	vpmadd52luq zmm5,zmm14,zmm10
   80de3:	62 82 e5 40 b4 e6                               	vpmadd52luq zmm20,zmm19,zmm30
   80de9:	62 81 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm31
   80def:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   80df6:	62 c2 9d 48 b4 ca                               	vpmadd52luq zmm17,zmm12,zmm10
   80dfc:	62 c2 b5 48 b4 d2                               	vpmadd52luq zmm18,zmm9,zmm10
   80e02:	62 c2 bd 48 b4 c2                               	vpmadd52luq zmm16,zmm8,zmm10
   80e08:	62 82 dd 40 b5 d8                               	vpmadd52huq zmm19,zmm20,zmm24
   80e0e:	62 f2 dd 40 b5 ea                               	vpmadd52huq zmm5,zmm20,zmm2
   80e14:	62 72 dd 40 b5 f9                               	vpmadd52huq zmm15,zmm20,zmm1
   80e1a:	62 e2 dd 40 b5 d4                               	vpmadd52huq zmm18,zmm20,zmm4
   80e20:	62 e2 dd 40 b5 c3                               	vpmadd52huq zmm16,zmm20,zmm3
   80e26:	62 e2 dd 40 b4 cc                               	vpmadd52luq zmm17,zmm20,zmm4
   80e2c:	62 f2 dd 40 b4 e9                               	vpmadd52luq zmm5,zmm20,zmm1
   80e32:	62 72 bd 48 b5 fe                               	vpmadd52huq zmm15,zmm8,zmm6
   80e38:	62 a1 f5 40 d4 db                               	vpaddq zmm19,zmm17,zmm19
   80e3e:	62 e2 dd 40 b4 d3                               	vpmadd52luq zmm18,zmm20,zmm3
   80e44:	62 e2 dd 40 b4 c2                               	vpmadd52luq zmm16,zmm20,zmm2
   80e4a:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   80e50:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   80e56:	62 e2 8d 48 b5 ce                               	vpmadd52huq zmm17,zmm14,zmm6
   80e5c:	62 e2 95 48 b4 de                               	vpmadd52luq zmm19,zmm13,zmm6
   80e62:	62 f2 b5 48 b5 ee                               	vpmadd52huq zmm5,zmm9,zmm6
   80e68:	62 72 8d 48 b4 fe                               	vpmadd52luq zmm15,zmm14,zmm6
   80e6e:	62 e2 95 48 b5 d6                               	vpmadd52huq zmm18,zmm13,zmm6
   80e74:	62 e2 9d 48 b5 c6                               	vpmadd52huq zmm16,zmm12,zmm6
   80e7a:	62 82 e5 40 b4 e6                               	vpmadd52luq zmm20,zmm19,zmm30
   80e80:	62 f2 bd 48 b4 ee                               	vpmadd52luq zmm5,zmm8,zmm6
   80e86:	62 81 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm31
   80e8c:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   80e93:	62 e2 9d 48 b4 d6                               	vpmadd52luq zmm18,zmm12,zmm6
   80e99:	62 e2 b5 48 b4 c6                               	vpmadd52luq zmm16,zmm9,zmm6
   80e9f:	62 72 dd 40 b5 fa                               	vpmadd52huq zmm15,zmm20,zmm2
   80ea5:	62 82 dd 40 b5 d8                               	vpmadd52huq zmm19,zmm20,zmm24
   80eab:	62 f2 dd 40 b5 eb                               	vpmadd52huq zmm5,zmm20,zmm3
   80eb1:	62 e2 dd 40 b5 c9                               	vpmadd52huq zmm17,zmm20,zmm1
   80eb7:	62 e2 dd 40 b5 c4                               	vpmadd52huq zmm16,zmm20,zmm4
   80ebd:	62 e2 dd 40 b4 d4                               	vpmadd52luq zmm18,zmm20,zmm4
   80ec3:	62 72 dd 40 b4 f9                               	vpmadd52luq zmm15,zmm20,zmm1
   80ec9:	62 f2 dd 40 b4 ea                               	vpmadd52luq zmm5,zmm20,zmm2
   80ecf:	62 e2 bd 48 b5 cf                               	vpmadd52huq zmm17,zmm8,zmm7
   80ed5:	62 a1 ed 40 d4 db                               	vpaddq zmm19,zmm18,zmm19
   80edb:	62 e2 dd 40 b4 c3                               	vpmadd52luq zmm16,zmm20,zmm3
   80ee1:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   80ee7:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   80eed:	62 e2 8d 48 b5 d7                               	vpmadd52huq zmm18,zmm14,zmm7
   80ef3:	62 72 b5 48 b5 ff                               	vpmadd52huq zmm15,zmm9,zmm7
   80ef9:	62 e2 95 48 b4 df                               	vpmadd52luq zmm19,zmm13,zmm7
   80eff:	62 f2 9d 48 b5 ef                               	vpmadd52huq zmm5,zmm12,zmm7
   80f05:	62 e2 8d 48 b4 cf                               	vpmadd52luq zmm17,zmm14,zmm7
   80f0b:	62 e2 95 48 b5 c7                               	vpmadd52huq zmm16,zmm13,zmm7
   80f11:	62 82 e5 40 b4 e6                               	vpmadd52luq zmm20,zmm19,zmm30
   80f17:	62 72 bd 48 b4 ff                               	vpmadd52luq zmm15,zmm8,zmm7
   80f1d:	62 f2 b5 48 b4 ef                               	vpmadd52luq zmm5,zmm9,zmm7
   80f23:	62 81 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm31
   80f29:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   80f30:	62 e2 9d 48 b4 c7                               	vpmadd52luq zmm16,zmm12,zmm7
   80f36:	62 72 dd 40 b5 fb                               	vpmadd52huq zmm15,zmm20,zmm3
   80f3c:	62 e2 dd 40 b5 ca                               	vpmadd52huq zmm17,zmm20,zmm2
   80f42:	62 82 dd 40 b5 d8                               	vpmadd52huq zmm19,zmm20,zmm24
   80f48:	62 f2 dd 40 b5 ec                               	vpmadd52huq zmm5,zmm20,zmm4
   80f4e:	62 e2 dd 40 b5 d1                               	vpmadd52huq zmm18,zmm20,zmm1
   80f54:	62 e2 dd 40 b4 c4                               	vpmadd52luq zmm16,zmm20,zmm4
   80f5a:	62 72 dd 40 b4 fa                               	vpmadd52luq zmm15,zmm20,zmm2
   80f60:	62 e2 dd 40 b4 c9                               	vpmadd52luq zmm17,zmm20,zmm1
   80f66:	62 f2 dd 40 b4 eb                               	vpmadd52luq zmm5,zmm20,zmm3
   80f6c:	62 e2 bd 48 b5 d0                               	vpmadd52huq zmm18,zmm8,zmm0
   80f72:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   80f78:	62 a1 fd 40 d4 c3                               	vpaddq zmm16,zmm16,zmm19
   80f7e:	62 e1 fd 48 6f 5c 01 f2                         	vmovdqa64 zmm19,ZMMWORD PTR [rcx+rax*1-0x380]
   80f86:	62 72 9d 48 b5 f8                               	vpmadd52huq zmm15,zmm12,zmm0
   80f8c:	62 e2 95 48 b4 c0                               	vpmadd52luq zmm16,zmm13,zmm0
   80f92:	62 e2 b5 48 b5 c8                               	vpmadd52huq zmm17,zmm9,zmm0
   80f98:	62 f2 95 48 b5 e8                               	vpmadd52huq zmm5,zmm13,zmm0
   80f9e:	62 e2 8d 48 b4 d0                               	vpmadd52luq zmm18,zmm14,zmm0
   80fa4:	62 72 b5 48 b4 f8                               	vpmadd52luq zmm15,zmm9,zmm0
   80faa:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80faf:	62 12 fd 40 b4 ce                               	vpmadd52luq zmm9,zmm16,zmm30
   80fb5:	62 e2 bd 48 b4 c8                               	vpmadd52luq zmm17,zmm8,zmm0
   80fbb:	62 f2 9d 48 b4 e8                               	vpmadd52luq zmm5,zmm12,zmm0
   80fc1:	62 11 fd 40 d4 ea                               	vpaddq zmm13,zmm16,zmm26
   80fc7:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   80fcc:	62 72 8d 48 b5 c0                               	vpmadd52huq zmm8,zmm14,zmm0
   80fd2:	c4 41 09 ef f6                                  	vpxor  xmm14,xmm14,xmm14
   80fd7:	62 e1 fd 48 6f 44 01 f3                         	vmovdqa64 zmm16,ZMMWORD PTR [rcx+rax*1-0x340]
   80fdf:	62 d1 95 48 73 d5 30                            	vpsrlq zmm13,zmm13,0x30
   80fe6:	62 11 b5 48 db e2                               	vpandq zmm12,zmm9,zmm26
   80fec:	62 d1 b5 48 73 f1 04                            	vpsllq zmm9,zmm9,0x4
   80ff3:	62 72 9d 48 b5 fc                               	vpmadd52huq zmm15,zmm12,zmm4
   80ff9:	62 e2 9d 48 b5 d2                               	vpmadd52huq zmm18,zmm12,zmm2
   80fff:	62 e2 9d 48 b5 cb                               	vpmadd52huq zmm17,zmm12,zmm3
   81005:	62 f2 9d 48 b4 ec                               	vpmadd52luq zmm5,zmm12,zmm4
   8100b:	62 12 b5 48 b5 e8                               	vpmadd52huq zmm13,zmm9,zmm24
   81011:	62 72 9d 48 b5 c1                               	vpmadd52huq zmm8,zmm12,zmm1
   81017:	62 72 9d 48 b4 fb                               	vpmadd52luq zmm15,zmm12,zmm3
   8101d:	62 e2 9d 48 b4 d1                               	vpmadd52luq zmm18,zmm12,zmm1
   81023:	62 e2 9d 48 b4 ca                               	vpmadd52luq zmm17,zmm12,zmm2
   81029:	62 f1 f5 48 73 f5 04                            	vpsllq zmm1,zmm5,0x4
   81030:	62 f1 ed 48 73 d5 30                            	vpsrlq zmm2,zmm5,0x30
   81037:	62 d1 bd 48 73 f0 04                            	vpsllq zmm8,zmm8,0x4
   8103e:	62 91 f5 48 db cb                               	vpandq zmm1,zmm1,zmm27
   81044:	62 d1 f5 48 d4 cd                               	vpaddq zmm1,zmm1,zmm13
   8104a:	62 d1 e5 48 73 f7 04                            	vpsllq zmm3,zmm15,0x4
   81051:	62 b1 b5 48 73 f2 04                            	vpsllq zmm9,zmm18,0x4
   81058:	62 d1 dd 48 73 d7 30                            	vpsrlq zmm4,zmm15,0x30
   8105f:	62 71 fd 48 6f 7c 01 f0                         	vmovdqa64 zmm15,ZMMWORD PTR [rcx+rax*1-0x400]
   81067:	62 b1 9d 48 73 d1 30                            	vpsrlq zmm12,zmm17,0x30
   8106e:	62 b1 d5 48 73 f1 04                            	vpsllq zmm5,zmm17,0x4
   81075:	62 b1 95 48 73 d2 30                            	vpsrlq zmm13,zmm18,0x30
   8107c:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   81082:	62 e1 fd 48 6f 54 01 f1                         	vmovdqa64 zmm18,ZMMWORD PTR [rcx+rax*1-0x3c0]
   8108a:	62 11 b5 48 db cb                               	vpandq zmm9,zmm9,zmm27
   81090:	62 91 e5 48 db db                               	vpandq zmm3,zmm3,zmm27
   81096:	62 91 d5 48 db eb                               	vpandq zmm5,zmm5,zmm27
   8109c:	62 51 bd 48 d4 c5                               	vpaddq zmm8,zmm8,zmm13
   810a2:	62 72 fd 48 59 ac 24 48 04 00 00                	vpbroadcastq zmm13,QWORD PTR [rsp+0x448]
   810ad:	62 51 b5 48 d4 cc                               	vpaddq zmm9,zmm9,zmm12
   810b3:	62 f1 9d 48 73 d1 34                            	vpsrlq zmm12,zmm1,0x34
   810ba:	62 f1 d5 48 d4 e4                               	vpaddq zmm4,zmm5,zmm4
   810c0:	62 91 f5 48 db ef                               	vpandq zmm5,zmm1,zmm31
   810c6:	62 f1 9d 48 d4 d2                               	vpaddq zmm2,zmm12,zmm2
   810cc:	62 72 fd 48 59 a4 24 50 04 00 00                	vpbroadcastq zmm12,QWORD PTR [rsp+0x450]
   810d7:	62 f1 ed 48 d4 d3                               	vpaddq zmm2,zmm2,zmm3
   810dd:	62 f1 f5 48 73 d2 34                            	vpsrlq zmm1,zmm2,0x34
   810e4:	62 f1 f5 48 d4 cc                               	vpaddq zmm1,zmm1,zmm4
   810ea:	62 91 ed 48 db e7                               	vpandq zmm4,zmm2,zmm31
   810f0:	62 f1 ed 48 73 d1 34                            	vpsrlq zmm2,zmm1,0x34
   810f7:	62 91 f5 48 db df                               	vpandq zmm3,zmm1,zmm31
   810fd:	62 d1 ed 48 d4 d1                               	vpaddq zmm2,zmm2,zmm9
   81103:	62 c2 a5 48 b5 ff                               	vpmadd52huq zmm23,zmm11,zmm15
   81109:	62 c2 ad 48 b5 ef                               	vpmadd52huq zmm21,zmm10,zmm15
   8110f:	62 c2 cd 48 b5 e7                               	vpmadd52huq zmm20,zmm6,zmm15
   81115:	62 c2 c5 48 b5 cf                               	vpmadd52huq zmm17,zmm7,zmm15
   8111b:	62 72 fd 48 59 8c 24 58 04 00 00                	vpbroadcastq zmm9,QWORD PTR [rsp+0x458]
   81126:	62 c2 a5 48 b4 f7                               	vpmadd52luq zmm22,zmm11,zmm15
   8112c:	62 52 fd 48 b5 f7                               	vpmadd52huq zmm14,zmm0,zmm15
   81132:	62 f1 f5 48 73 d2 34                            	vpsrlq zmm1,zmm2,0x34
   81139:	62 91 ed 48 db d7                               	vpandq zmm2,zmm2,zmm31
   8113f:	62 d1 f5 48 d4 c8                               	vpaddq zmm1,zmm1,zmm8
   81145:	62 72 fd 48 59 84 24 60 04 00 00                	vpbroadcastq zmm8,QWORD PTR [rsp+0x460]
   81150:	62 c2 ad 48 b4 ff                               	vpmadd52luq zmm23,zmm10,zmm15
   81156:	62 c2 cd 48 b4 ef                               	vpmadd52luq zmm21,zmm6,zmm15
   8115c:	62 c2 c5 48 b4 e7                               	vpmadd52luq zmm20,zmm7,zmm15
   81162:	62 c2 fd 48 b4 cf                               	vpmadd52luq zmm17,zmm0,zmm15
   81168:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8116d:	62 12 cd 40 b4 fe                               	vpmadd52luq zmm15,zmm22,zmm30
   81173:	62 81 cd 40 d4 f7                               	vpaddq zmm22,zmm22,zmm31
   81179:	62 b1 cd 40 73 d6 34                            	vpsrlq zmm22,zmm22,0x34
   81180:	62 c2 85 48 b5 ed                               	vpmadd52huq zmm21,zmm15,zmm13
   81186:	62 c2 85 48 b5 e4                               	vpmadd52huq zmm20,zmm15,zmm12
   8118c:	62 c2 85 48 b5 c9                               	vpmadd52huq zmm17,zmm15,zmm9
   81192:	62 82 85 48 b5 f0                               	vpmadd52huq zmm22,zmm15,zmm24
   81198:	62 c2 85 48 b4 fd                               	vpmadd52luq zmm23,zmm15,zmm13
   8119e:	62 52 85 48 b5 f0                               	vpmadd52huq zmm14,zmm15,zmm8
   811a4:	62 c2 85 48 b4 ec                               	vpmadd52luq zmm21,zmm15,zmm12
   811aa:	62 c2 85 48 b4 e1                               	vpmadd52luq zmm20,zmm15,zmm9
   811b0:	62 c2 85 48 b4 c8                               	vpmadd52luq zmm17,zmm15,zmm8
   811b6:	62 a1 c5 40 d4 f6                               	vpaddq zmm22,zmm23,zmm22
   811bc:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   811c1:	62 32 fd 48 b5 fa                               	vpmadd52huq zmm15,zmm0,zmm18
   811c7:	62 e1 7c 28 28 3d 4f 6f f8 ff                   	vmovaps ymm23,YMMWORD PTR [rip+0xfffffffffff86f4f]        # 8120 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x9a0>
   811d1:	62 a2 a5 48 b4 f2                               	vpmadd52luq zmm22,zmm11,zmm18
   811d7:	62 32 c5 48 b5 f2                               	vpmadd52huq zmm14,zmm7,zmm18
   811dd:	62 a2 a5 48 b5 ea                               	vpmadd52huq zmm21,zmm11,zmm18
   811e3:	62 a2 ad 48 b5 e2                               	vpmadd52huq zmm20,zmm10,zmm18
   811e9:	62 a2 cd 48 b5 ca                               	vpmadd52huq zmm17,zmm6,zmm18
   811ef:	62 32 fd 48 b4 f2                               	vpmadd52luq zmm14,zmm0,zmm18
   811f5:	62 a2 ad 48 b4 ea                               	vpmadd52luq zmm21,zmm10,zmm18
   811fb:	62 a2 cd 48 b4 e2                               	vpmadd52luq zmm20,zmm6,zmm18
   81201:	62 a2 c5 48 b4 ca                               	vpmadd52luq zmm17,zmm7,zmm18
   81207:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   8120d:	62 82 cd 40 b4 d6                               	vpmadd52luq zmm18,zmm22,zmm30
   81213:	62 81 cd 40 d4 f7                               	vpaddq zmm22,zmm22,zmm31
   81219:	62 b1 cd 40 73 d6 34                            	vpsrlq zmm22,zmm22,0x34
   81220:	62 c2 ed 40 b5 e5                               	vpmadd52huq zmm20,zmm18,zmm13
   81226:	62 c2 ed 40 b5 cc                               	vpmadd52huq zmm17,zmm18,zmm12
   8122c:	62 52 ed 40 b5 f1                               	vpmadd52huq zmm14,zmm18,zmm9
   81232:	62 82 ed 40 b5 f0                               	vpmadd52huq zmm22,zmm18,zmm24
   81238:	62 c2 ed 40 b4 ed                               	vpmadd52luq zmm21,zmm18,zmm13
   8123e:	62 52 ed 40 b5 f8                               	vpmadd52huq zmm15,zmm18,zmm8
   81244:	62 c2 ed 40 b4 e4                               	vpmadd52luq zmm20,zmm18,zmm12
   8124a:	62 c2 ed 40 b4 c9                               	vpmadd52luq zmm17,zmm18,zmm9
   81250:	62 52 ed 40 b4 f0                               	vpmadd52luq zmm14,zmm18,zmm8
   81256:	62 a1 d5 40 d4 ee                               	vpaddq zmm21,zmm21,zmm22
   8125c:	62 32 c5 48 b5 fb                               	vpmadd52huq zmm15,zmm7,zmm19
   81262:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   81268:	62 a2 fd 48 b5 d3                               	vpmadd52huq zmm18,zmm0,zmm19
   8126e:	62 a1 4d 00 ef f6                               	vpxord xmm22,xmm22,xmm22
   81274:	62 a2 a5 48 b4 eb                               	vpmadd52luq zmm21,zmm11,zmm19
   8127a:	62 a2 a5 48 b5 e3                               	vpmadd52huq zmm20,zmm11,zmm19
   81280:	62 a2 ad 48 b5 cb                               	vpmadd52huq zmm17,zmm10,zmm19
   81286:	62 32 cd 48 b5 f3                               	vpmadd52huq zmm14,zmm6,zmm19
   8128c:	62 32 fd 48 b4 fb                               	vpmadd52luq zmm15,zmm0,zmm19
   81292:	62 a2 ad 48 b4 e3                               	vpmadd52luq zmm20,zmm10,zmm19
   81298:	62 a2 cd 48 b4 cb                               	vpmadd52luq zmm17,zmm6,zmm19
   8129e:	62 32 c5 48 b4 f3                               	vpmadd52luq zmm14,zmm7,zmm19
   812a4:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   812aa:	62 82 d5 40 b4 de                               	vpmadd52luq zmm19,zmm21,zmm30
   812b0:	62 81 d5 40 d4 ef                               	vpaddq zmm21,zmm21,zmm31
   812b6:	62 b1 d5 40 73 d5 34                            	vpsrlq zmm21,zmm21,0x34
   812bd:	62 c2 e5 40 b5 cd                               	vpmadd52huq zmm17,zmm19,zmm13
   812c3:	62 52 e5 40 b5 f4                               	vpmadd52huq zmm14,zmm19,zmm12
   812c9:	62 52 e5 40 b5 f9                               	vpmadd52huq zmm15,zmm19,zmm9
   812cf:	62 82 e5 40 b5 e8                               	vpmadd52huq zmm21,zmm19,zmm24
   812d5:	62 c2 e5 40 b4 e5                               	vpmadd52luq zmm20,zmm19,zmm13
   812db:	62 c2 e5 40 b5 d0                               	vpmadd52huq zmm18,zmm19,zmm8
   812e1:	62 c2 e5 40 b4 cc                               	vpmadd52luq zmm17,zmm19,zmm12
   812e7:	62 52 e5 40 b4 f1                               	vpmadd52luq zmm14,zmm19,zmm9
   812ed:	62 52 e5 40 b4 f8                               	vpmadd52luq zmm15,zmm19,zmm8
   812f3:	62 a1 dd 40 d4 e5                               	vpaddq zmm20,zmm20,zmm21
   812f9:	62 a2 c5 48 b5 d0                               	vpmadd52huq zmm18,zmm7,zmm16
   812ff:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   81305:	62 a2 fd 48 b5 d8                               	vpmadd52huq zmm19,zmm0,zmm16
   8130b:	62 a2 a5 48 b4 e0                               	vpmadd52luq zmm20,zmm11,zmm16
   81311:	62 a2 a5 48 b5 c8                               	vpmadd52huq zmm17,zmm11,zmm16
   81317:	62 32 ad 48 b5 f0                               	vpmadd52huq zmm14,zmm10,zmm16
   8131d:	62 32 cd 48 b5 f8                               	vpmadd52huq zmm15,zmm6,zmm16
   81323:	62 a2 fd 48 b4 d0                               	vpmadd52luq zmm18,zmm0,zmm16
   81329:	62 a2 ad 48 b4 c8                               	vpmadd52luq zmm17,zmm10,zmm16
   8132f:	62 32 cd 48 b4 f0                               	vpmadd52luq zmm14,zmm6,zmm16
   81335:	62 32 c5 48 b4 f8                               	vpmadd52luq zmm15,zmm7,zmm16
   8133b:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   81341:	62 82 dd 40 b4 c6                               	vpmadd52luq zmm16,zmm20,zmm30
   81347:	62 81 dd 40 d4 e7                               	vpaddq zmm20,zmm20,zmm31
   8134d:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   81354:	62 52 fd 40 b5 f5                               	vpmadd52huq zmm14,zmm16,zmm13
   8135a:	62 52 fd 40 b5 fc                               	vpmadd52huq zmm15,zmm16,zmm12
   81360:	62 c2 fd 40 b5 d1                               	vpmadd52huq zmm18,zmm16,zmm9
   81366:	62 82 fd 40 b5 e0                               	vpmadd52huq zmm20,zmm16,zmm24
   8136c:	62 c2 fd 40 b4 cd                               	vpmadd52luq zmm17,zmm16,zmm13
   81372:	62 c2 fd 40 b5 d8                               	vpmadd52huq zmm19,zmm16,zmm8
   81378:	62 52 fd 40 b4 f4                               	vpmadd52luq zmm14,zmm16,zmm12
   8137e:	62 52 fd 40 b4 f9                               	vpmadd52luq zmm15,zmm16,zmm9
   81384:	62 c2 fd 40 b4 d0                               	vpmadd52luq zmm18,zmm16,zmm8
   8138a:	62 e1 fd 48 6f 44 01 f4                         	vmovdqa64 zmm16,ZMMWORD PTR [rcx+rax*1-0x300]
   81392:	62 a1 f5 40 d4 cc                               	vpaddq zmm17,zmm17,zmm20
   81398:	62 61 fe 28 7f 4c 24 22                         	vmovdqu64 YMMWORD PTR [rsp+0x440],ymm25
   813a0:	4c 89 a4 24 60 04 00 00                         	mov    QWORD PTR [rsp+0x460],r12
   813a8:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   813ae:	62 a2 cd 48 b5 d0                               	vpmadd52huq zmm18,zmm6,zmm16
   813b4:	62 a2 c5 48 b5 d8                               	vpmadd52huq zmm19,zmm7,zmm16
   813ba:	62 a2 a5 48 b4 c8                               	vpmadd52luq zmm17,zmm11,zmm16
   813c0:	62 32 ad 48 b5 f8                               	vpmadd52huq zmm15,zmm10,zmm16
   813c6:	62 32 a5 48 b5 f0                               	vpmadd52huq zmm14,zmm11,zmm16
   813cc:	62 a2 c5 48 b4 d0                               	vpmadd52luq zmm18,zmm7,zmm16
   813d2:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   813d6:	62 a2 fd 48 b4 d8                               	vpmadd52luq zmm19,zmm0,zmm16
   813dc:	62 b2 fd 48 b5 f8                               	vpmadd52huq zmm7,zmm0,zmm16
   813e2:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   813e6:	62 92 f5 40 b4 c6                               	vpmadd52luq zmm0,zmm17,zmm30
   813ec:	62 32 cd 48 b4 f8                               	vpmadd52luq zmm15,zmm6,zmm16
   813f2:	62 32 ad 48 b4 f0                               	vpmadd52luq zmm14,zmm10,zmm16
   813f8:	62 11 f5 40 d4 d2                               	vpaddq zmm10,zmm17,zmm26
   813fe:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   81404:	62 e2 ed 48 b5 c5                               	vpmadd52huq zmm16,zmm2,zmm5
   8140a:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   81410:	62 e2 dd 48 b5 cd                               	vpmadd52huq zmm17,zmm4,zmm5
   81416:	62 d1 ad 48 73 d2 30                            	vpsrlq zmm10,zmm10,0x30
   8141d:	62 91 fd 48 db f2                               	vpandq zmm6,zmm0,zmm26
   81423:	62 f1 fd 48 73 f0 04                            	vpsllq zmm0,zmm0,0x4
   8142a:	62 e2 f5 48 b4 c5                               	vpmadd52luq zmm16,zmm1,zmm5
   81430:	62 e2 e5 48 b4 cd                               	vpmadd52luq zmm17,zmm3,zmm5
   81436:	62 52 cd 48 b5 fd                               	vpmadd52huq zmm15,zmm6,zmm13
   8143c:	62 c2 cd 48 b5 d4                               	vpmadd52huq zmm18,zmm6,zmm12
   81442:	62 c2 cd 48 b5 d9                               	vpmadd52huq zmm19,zmm6,zmm9
   81448:	62 52 cd 48 b4 f5                               	vpmadd52luq zmm14,zmm6,zmm13
   8144e:	62 12 fd 48 b5 d0                               	vpmadd52huq zmm10,zmm0,zmm24
   81454:	62 d2 cd 48 b5 f8                               	vpmadd52huq zmm7,zmm6,zmm8
   8145a:	62 72 fd 48 59 ac 24 48 04 00 00                	vpbroadcastq zmm13,QWORD PTR [rsp+0x448]
   81465:	62 c2 cd 48 b4 d8                               	vpmadd52luq zmm19,zmm6,zmm8
   8146b:	62 52 cd 48 b4 fc                               	vpmadd52luq zmm15,zmm6,zmm12
   81471:	62 c2 cd 48 b4 d1                               	vpmadd52luq zmm18,zmm6,zmm9
   81477:	62 d1 fd 48 73 f6 04                            	vpsllq zmm0,zmm14,0x4
   8147e:	62 f1 c5 48 73 f7 04                            	vpsllq zmm7,zmm7,0x4
   81485:	62 91 fd 48 db c3                               	vpandq zmm0,zmm0,zmm27
   8148b:	62 d1 fd 48 d4 f2                               	vpaddq zmm6,zmm0,zmm10
   81491:	62 d1 fd 48 73 d6 30                            	vpsrlq zmm0,zmm14,0x30
   81498:	c4 41 09 ef f6                                  	vpxor  xmm14,xmm14,xmm14
   8149d:	62 72 f5 48 b5 f5                               	vpmadd52huq zmm14,zmm1,zmm5
   814a3:	62 f1 fd 48 7f 74 24 04                         	vmovdqa64 ZMMWORD PTR [rsp+0x100],zmm6
   814ab:	62 f1 cd 48 73 d6 34                            	vpsrlq zmm6,zmm6,0x34
   814b2:	62 d1 bd 48 73 f7 04                            	vpsllq zmm8,zmm15,0x4
   814b9:	62 b1 ad 48 73 f2 04                            	vpsllq zmm10,zmm18,0x4
   814c0:	62 b1 a5 48 73 f3 04                            	vpsllq zmm11,zmm19,0x4
   814c7:	62 d1 b5 48 73 d7 30                            	vpsrlq zmm9,zmm15,0x30
   814ce:	62 b1 9d 48 73 d2 30                            	vpsrlq zmm12,zmm18,0x30
   814d5:	62 f1 cd 48 d4 c0                               	vpaddq zmm0,zmm6,zmm0
   814db:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   814e0:	62 72 d5 48 b4 fd                               	vpmadd52luq zmm15,zmm5,zmm5
   814e6:	62 f2 fd 48 59 b4 24 58 04 00 00                	vpbroadcastq zmm6,QWORD PTR [rsp+0x458]
   814f1:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   814f7:	62 e2 e5 48 b5 d5                               	vpmadd52huq zmm18,zmm3,zmm5
   814fd:	62 11 bd 48 db c3                               	vpandq zmm8,zmm8,zmm27
   81503:	62 11 ad 48 db d3                               	vpandq zmm10,zmm10,zmm27
   81509:	62 11 a5 48 db db                               	vpandq zmm11,zmm11,zmm27
   8150f:	62 d1 fd 48 d4 c0                               	vpaddq zmm0,zmm0,zmm8
   81515:	62 51 ad 48 d4 c9                               	vpaddq zmm9,zmm10,zmm9
   8151b:	62 51 a5 48 d4 d4                               	vpaddq zmm10,zmm11,zmm12
   81521:	62 b1 9d 48 73 d3 30                            	vpsrlq zmm12,zmm19,0x30
   81528:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   8152e:	62 e2 d5 48 b5 dd                               	vpmadd52huq zmm19,zmm5,zmm5
   81534:	62 72 fd 48 59 05 ca 5f f8 ff                   	vpbroadcastq zmm8,QWORD PTR [rip+0xfffffffffff85fca]        # 7508 <GCC_except_table746+0x194>
   8153e:	62 51 c5 48 d4 dc                               	vpaddq zmm11,zmm7,zmm12
   81544:	62 f1 fd 48 7f 44 24 1a                         	vmovdqa64 ZMMWORD PTR [rsp+0x680],zmm0
   8154c:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   81553:	62 72 fd 48 59 a4 24 50 04 00 00                	vpbroadcastq zmm12,QWORD PTR [rsp+0x450]
   8155e:	62 91 fd 48 6f f8                               	vmovdqa64 zmm7,zmm24
   81564:	62 d1 fd 48 d4 c1                               	vpaddq zmm0,zmm0,zmm9
   8156a:	62 82 85 48 b4 e6                               	vpmadd52luq zmm20,zmm15,zmm30
   81570:	62 e2 ed 48 b4 d5                               	vpmadd52luq zmm18,zmm2,zmm5
   81576:	62 11 85 48 d4 ff                               	vpaddq zmm15,zmm15,zmm31
   8157c:	62 11 fd 48 6f cb                               	vmovdqa64 zmm9,zmm27
   81582:	62 f1 fd 48 7f 44 24 1b                         	vmovdqa64 ZMMWORD PTR [rsp+0x6c0],zmm0
   8158a:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   81591:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   81598:	62 d1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm10
   8159e:	62 72 fd 48 59 94 24 60 04 00 00                	vpbroadcastq zmm10,QWORD PTR [rsp+0x460]
   815a9:	62 e2 dd 48 b4 dd                               	vpmadd52luq zmm19,zmm4,zmm5
   815af:	62 e1 7c 28 11 7c 24 22                         	vmovups YMMWORD PTR [rsp+0x440],ymm23
   815b7:	4c 89 84 24 60 04 00 00                         	mov    QWORD PTR [rsp+0x460],r8
   815bf:	62 f1 fd 48 7f 44 24 07                         	vmovdqa64 ZMMWORD PTR [rsp+0x1c0],zmm0
   815c7:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   815ce:	62 e2 dd 40 b5 c6                               	vpmadd52huq zmm16,zmm20,zmm6
   815d4:	62 c2 dd 40 b5 cd                               	vpmadd52huq zmm17,zmm20,zmm13
   815da:	62 12 dd 40 b5 f8                               	vpmadd52huq zmm15,zmm20,zmm24
   815e0:	62 d1 fd 48 d4 c3                               	vpaddq zmm0,zmm0,zmm11
   815e6:	62 c2 dd 40 b4 dd                               	vpmadd52luq zmm19,zmm20,zmm13
   815ec:	62 c2 dd 40 b5 d4                               	vpmadd52huq zmm18,zmm20,zmm12
   815f2:	62 c2 dd 40 b4 cc                               	vpmadd52luq zmm17,zmm20,zmm12
   815f8:	62 c2 dd 40 b4 c2                               	vpmadd52luq zmm16,zmm20,zmm10
   815fe:	62 52 dd 40 b5 f2                               	vpmadd52huq zmm14,zmm20,zmm10
   81604:	62 c1 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm15
   8160a:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8160f:	62 72 f5 48 b5 fc                               	vpmadd52huq zmm15,zmm1,zmm4
   81615:	62 e2 dd 40 b4 d6                               	vpmadd52luq zmm18,zmm20,zmm6
   8161b:	62 e2 d5 48 b4 dc                               	vpmadd52luq zmm19,zmm5,zmm4
   81621:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   81627:	62 e2 d5 48 b5 cc                               	vpmadd52huq zmm17,zmm5,zmm4
   8162d:	62 e2 e5 48 b5 c4                               	vpmadd52huq zmm16,zmm3,zmm4
   81633:	62 72 ed 48 b5 f4                               	vpmadd52huq zmm14,zmm2,zmm4
   81639:	62 e2 dd 48 b5 d4                               	vpmadd52huq zmm18,zmm4,zmm4
   8163f:	62 82 e5 40 b4 e6                               	vpmadd52luq zmm20,zmm19,zmm30
   81645:	62 81 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm31
   8164b:	62 e2 dd 48 b4 cc                               	vpmadd52luq zmm17,zmm4,zmm4
   81651:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   81658:	62 e2 ed 48 b4 c4                               	vpmadd52luq zmm16,zmm2,zmm4
   8165e:	62 72 f5 48 b4 f4                               	vpmadd52luq zmm14,zmm1,zmm4
   81664:	62 e2 e5 48 b4 d4                               	vpmadd52luq zmm18,zmm3,zmm4
   8166a:	62 82 dd 40 b5 d8                               	vpmadd52huq zmm19,zmm20,zmm24
   81670:	62 52 dd 40 b5 fa                               	vpmadd52huq zmm15,zmm20,zmm10
   81676:	62 c2 dd 40 b4 cd                               	vpmadd52luq zmm17,zmm20,zmm13
   8167c:	62 c2 dd 40 b5 c4                               	vpmadd52huq zmm16,zmm20,zmm12
   81682:	62 72 dd 40 b5 f6                               	vpmadd52huq zmm14,zmm20,zmm6
   81688:	62 c2 dd 40 b5 d5                               	vpmadd52huq zmm18,zmm20,zmm13
   8168e:	62 72 ed 48 b5 fb                               	vpmadd52huq zmm15,zmm2,zmm3
   81694:	62 a1 f5 40 d4 db                               	vpaddq zmm19,zmm17,zmm19
   8169a:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   816a0:	62 e2 f5 48 b5 cb                               	vpmadd52huq zmm17,zmm1,zmm3
   816a6:	62 e2 d5 48 b4 db                               	vpmadd52luq zmm19,zmm5,zmm3
   816ac:	62 e2 dd 40 b4 c6                               	vpmadd52luq zmm16,zmm20,zmm6
   816b2:	62 52 dd 40 b4 f2                               	vpmadd52luq zmm14,zmm20,zmm10
   816b8:	62 c2 dd 40 b4 d4                               	vpmadd52luq zmm18,zmm20,zmm12
   816be:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   816c4:	62 72 f5 48 b4 fb                               	vpmadd52luq zmm15,zmm1,zmm3
   816ca:	62 82 e5 40 b4 e6                               	vpmadd52luq zmm20,zmm19,zmm30
   816d0:	62 81 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm31
   816d6:	62 e2 dd 48 b5 c3                               	vpmadd52huq zmm16,zmm4,zmm3
   816dc:	62 72 e5 48 b5 f3                               	vpmadd52huq zmm14,zmm3,zmm3
   816e2:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   816e9:	62 e2 d5 48 b5 d3                               	vpmadd52huq zmm18,zmm5,zmm3
   816ef:	62 72 dd 40 b5 fe                               	vpmadd52huq zmm15,zmm20,zmm6
   816f5:	62 82 dd 40 b5 d8                               	vpmadd52huq zmm19,zmm20,zmm24
   816fb:	62 c2 dd 40 b5 ca                               	vpmadd52huq zmm17,zmm20,zmm10
   81701:	62 e2 e5 48 b4 c3                               	vpmadd52luq zmm16,zmm3,zmm3
   81707:	62 72 ed 48 b4 f3                               	vpmadd52luq zmm14,zmm2,zmm3
   8170d:	62 e2 dd 48 b4 d3                               	vpmadd52luq zmm18,zmm4,zmm3
   81713:	62 52 dd 40 b4 fa                               	vpmadd52luq zmm15,zmm20,zmm10
   81719:	62 e2 ed 48 b5 ca                               	vpmadd52huq zmm17,zmm2,zmm2
   8171f:	62 c2 dd 40 b5 c5                               	vpmadd52huq zmm16,zmm20,zmm13
   81725:	62 52 dd 40 b5 f4                               	vpmadd52huq zmm14,zmm20,zmm12
   8172b:	62 c2 dd 40 b4 d5                               	vpmadd52luq zmm18,zmm20,zmm13
   81731:	62 72 e5 48 b5 fa                               	vpmadd52huq zmm15,zmm3,zmm2
   81737:	62 e2 f5 48 b4 ca                               	vpmadd52luq zmm17,zmm1,zmm2
   8173d:	62 c2 dd 40 b4 c4                               	vpmadd52luq zmm16,zmm20,zmm12
   81743:	62 72 dd 40 b4 f6                               	vpmadd52luq zmm14,zmm20,zmm6
   81749:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   8174f:	62 a1 ed 40 d4 db                               	vpaddq zmm19,zmm18,zmm19
   81755:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   8175b:	62 e2 f5 48 b5 d2                               	vpmadd52huq zmm18,zmm1,zmm2
   81761:	62 e2 d5 48 b4 da                               	vpmadd52luq zmm19,zmm5,zmm2
   81767:	62 72 ed 48 b4 fa                               	vpmadd52luq zmm15,zmm2,zmm2
   8176d:	62 e2 d5 48 b5 c2                               	vpmadd52huq zmm16,zmm5,zmm2
   81773:	62 72 dd 48 b5 f2                               	vpmadd52huq zmm14,zmm4,zmm2
   81779:	62 82 e5 40 b4 e6                               	vpmadd52luq zmm20,zmm19,zmm30
   8177f:	62 81 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm31
   81785:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   8178c:	62 e2 dd 48 b4 c2                               	vpmadd52luq zmm16,zmm4,zmm2
   81792:	62 72 e5 48 b4 f2                               	vpmadd52luq zmm14,zmm3,zmm2
   81798:	62 52 dd 40 b5 fc                               	vpmadd52huq zmm15,zmm20,zmm12
   8179e:	62 e2 dd 40 b5 ce                               	vpmadd52huq zmm17,zmm20,zmm6
   817a4:	62 82 dd 40 b5 d8                               	vpmadd52huq zmm19,zmm20,zmm24
   817aa:	62 c2 dd 40 b5 d2                               	vpmadd52huq zmm18,zmm20,zmm10
   817b0:	62 c2 dd 40 b4 c5                               	vpmadd52luq zmm16,zmm20,zmm13
   817b6:	62 52 dd 40 b5 f5                               	vpmadd52huq zmm14,zmm20,zmm13
   817bc:	62 72 dd 40 b4 fe                               	vpmadd52luq zmm15,zmm20,zmm6
   817c2:	62 c2 dd 40 b4 ca                               	vpmadd52luq zmm17,zmm20,zmm10
   817c8:	62 e2 ed 48 b5 d1                               	vpmadd52huq zmm18,zmm2,zmm1
   817ce:	62 a1 fd 40 d4 c3                               	vpaddq zmm16,zmm16,zmm19
   817d4:	62 52 dd 40 b4 f4                               	vpmadd52luq zmm14,zmm20,zmm12
   817da:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   817e0:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   817e6:	62 e2 f5 48 b5 d9                               	vpmadd52huq zmm19,zmm1,zmm1
   817ec:	62 e2 d5 48 b4 c1                               	vpmadd52luq zmm16,zmm5,zmm1
   817f2:	62 72 dd 48 b5 f9                               	vpmadd52huq zmm15,zmm4,zmm1
   817f8:	62 e2 e5 48 b5 c9                               	vpmadd52huq zmm17,zmm3,zmm1
   817fe:	62 e2 f5 48 b4 d1                               	vpmadd52luq zmm18,zmm1,zmm1
   81804:	62 72 d5 48 b5 f1                               	vpmadd52huq zmm14,zmm5,zmm1
   8180a:	62 82 fd 40 b4 e6                               	vpmadd52luq zmm20,zmm16,zmm30
   81810:	62 81 fd 40 d4 c2                               	vpaddq zmm16,zmm16,zmm26
   81816:	62 72 e5 48 b4 f9                               	vpmadd52luq zmm15,zmm3,zmm1
   8181c:	62 e2 ed 48 b4 c9                               	vpmadd52luq zmm17,zmm2,zmm1
   81822:	62 b1 fd 40 73 d0 30                            	vpsrlq zmm16,zmm16,0x30
   81829:	62 72 dd 48 b4 f1                               	vpmadd52luq zmm14,zmm4,zmm1
   8182f:	62 81 dd 40 db ea                               	vpandq zmm21,zmm20,zmm26
   81835:	62 b1 dd 40 73 f4 04                            	vpsllq zmm20,zmm20,0x4
   8183c:	62 52 d5 40 b5 fd                               	vpmadd52huq zmm15,zmm21,zmm13
   81842:	62 c2 d5 40 b5 cc                               	vpmadd52huq zmm17,zmm21,zmm12
   81848:	62 e2 d5 40 b5 d6                               	vpmadd52huq zmm18,zmm21,zmm6
   8184e:	62 82 dd 40 b5 c0                               	vpmadd52huq zmm16,zmm20,zmm24
   81854:	62 c2 d5 40 b5 da                               	vpmadd52huq zmm19,zmm21,zmm10
   8185a:	62 52 d5 40 b4 f5                               	vpmadd52luq zmm14,zmm21,zmm13
   81860:	62 52 d5 40 b4 fc                               	vpmadd52luq zmm15,zmm21,zmm12
   81866:	62 e2 d5 40 b4 ce                               	vpmadd52luq zmm17,zmm21,zmm6
   8186c:	62 c2 d5 40 b4 d2                               	vpmadd52luq zmm18,zmm21,zmm10
   81872:	62 d1 ad 48 73 f6 04                            	vpsllq zmm10,zmm14,0x4
   81879:	62 d1 a5 48 73 d6 30                            	vpsrlq zmm11,zmm14,0x30
   81880:	62 11 ad 48 db d3                               	vpandq zmm10,zmm10,zmm27
   81886:	62 d1 9d 48 73 f7 04                            	vpsllq zmm12,zmm15,0x4
   8188d:	62 b1 8d 48 73 f1 04                            	vpsllq zmm14,zmm17,0x4
   81894:	62 d1 95 48 73 d7 30                            	vpsrlq zmm13,zmm15,0x30
   8189b:	62 b1 85 48 73 f2 04                            	vpsllq zmm15,zmm18,0x4
   818a2:	62 b1 cd 48 73 d1 30                            	vpsrlq zmm6,zmm17,0x30
   818a9:	62 31 ad 48 d4 d0                               	vpaddq zmm10,zmm10,zmm16
   818af:	62 b1 fd 40 73 f3 04                            	vpsllq zmm16,zmm19,0x4
   818b6:	62 11 8d 48 db f3                               	vpandq zmm14,zmm14,zmm27
   818bc:	62 11 85 48 db fb                               	vpandq zmm15,zmm15,zmm27
   818c2:	62 11 9d 48 db e3                               	vpandq zmm12,zmm12,zmm27
   818c8:	62 01 25 00 ef db                               	vpxord xmm27,xmm27,xmm27
   818ce:	62 51 8d 48 d4 ed                               	vpaddq zmm13,zmm14,zmm13
   818d4:	62 71 85 48 d4 f6                               	vpaddq zmm14,zmm15,zmm6
   818da:	62 b1 85 48 73 d2 30                            	vpsrlq zmm15,zmm18,0x30
   818e1:	62 f2 fd 48 59 35 85 5b f8 ff                   	vpbroadcastq zmm6,QWORD PTR [rip+0xfffffffffff85b85]        # 7470 <GCC_except_table746+0xfc>
   818eb:	62 51 fd 40 d4 ff                               	vpaddq zmm15,zmm16,zmm15
   818f1:	62 d1 fd 40 73 d2 34                            	vpsrlq zmm16,zmm10,0x34
   818f8:	62 11 ad 48 db d7                               	vpandq zmm10,zmm10,zmm31
   818fe:	62 71 ad 48 fb 54 01 fa                         	vpsubq zmm10,zmm10,ZMMWORD PTR [rcx+rax*1-0x180]
   81906:	62 51 fd 40 d4 db                               	vpaddq zmm11,zmm16,zmm11
   8190c:	62 51 a5 48 d4 dc                               	vpaddq zmm11,zmm11,zmm12
   81912:	62 d1 9d 48 73 d3 34                            	vpsrlq zmm12,zmm11,0x34
   81919:	62 11 a5 48 db df                               	vpandq zmm11,zmm11,zmm31
   8191f:	62 71 a5 48 fb 5c 01 fb                         	vpsubq zmm11,zmm11,ZMMWORD PTR [rcx+rax*1-0x140]
   81927:	62 51 9d 48 d4 e5                               	vpaddq zmm12,zmm12,zmm13
   8192d:	62 d1 95 48 73 d4 34                            	vpsrlq zmm13,zmm12,0x34
   81934:	62 11 9d 48 db e7                               	vpandq zmm12,zmm12,zmm31
   8193a:	62 71 9d 48 fb 64 01 fc                         	vpsubq zmm12,zmm12,ZMMWORD PTR [rcx+rax*1-0x100]
   81942:	62 51 95 48 d4 ee                               	vpaddq zmm13,zmm13,zmm14
   81948:	62 d1 8d 48 73 d5 34                            	vpsrlq zmm14,zmm13,0x34
   8194f:	62 11 95 48 db ef                               	vpandq zmm13,zmm13,zmm31
   81955:	62 71 95 48 fb 6c 01 fd                         	vpsubq zmm13,zmm13,ZMMWORD PTR [rcx+rax*1-0xc0]
   8195d:	62 51 8d 48 d4 f7                               	vpaddq zmm14,zmm14,zmm15
   81963:	62 71 8d 48 fb 74 01 fe                         	vpsubq zmm14,zmm14,ZMMWORD PTR [rcx+rax*1-0x80]
   8196b:	62 81 ad 48 db c7                               	vpandq zmm16,zmm10,zmm31
   81971:	62 d1 ad 48 72 e2 34                            	vpsraq zmm10,zmm10,0x34
   81978:	62 72 fd 48 59 bc 24 60 04 00 00                	vpbroadcastq zmm15,QWORD PTR [rsp+0x460]
   81983:	62 51 a5 48 d4 d2                               	vpaddq zmm10,zmm11,zmm10
   81989:	62 11 ad 48 db df                               	vpandq zmm11,zmm10,zmm31
   8198f:	62 d1 ad 48 72 e2 34                            	vpsraq zmm10,zmm10,0x34
   81996:	62 e1 a5 58 d4 ac 24 48 04 00 00                	vpaddq zmm21,zmm11,QWORD BCST [rsp+0x448]
   819a1:	62 51 9d 48 d4 d2                               	vpaddq zmm10,zmm12,zmm10
   819a7:	62 11 ad 48 db e7                               	vpandq zmm12,zmm10,zmm31
   819ad:	62 d1 ad 48 72 e2 34                            	vpsraq zmm10,zmm10,0x34
   819b4:	62 e1 9d 58 d4 a4 24 50 04 00 00                	vpaddq zmm20,zmm12,QWORD BCST [rsp+0x450]
   819bf:	62 51 95 48 d4 d2                               	vpaddq zmm10,zmm13,zmm10
   819c5:	62 11 ad 48 db ef                               	vpandq zmm13,zmm10,zmm31
   819cb:	62 d1 ad 48 72 e2 34                            	vpsraq zmm10,zmm10,0x34
   819d2:	62 e1 95 58 d4 9c 24 58 04 00 00                	vpaddq zmm19,zmm13,QWORD BCST [rsp+0x458]
   819dd:	62 e1 7c 28 11 7c 24 22                         	vmovups YMMWORD PTR [rsp+0x440],ymm23
   819e5:	4c 89 84 24 60 04 00 00                         	mov    QWORD PTR [rsp+0x460],r8
   819ed:	62 51 8d 48 d4 d2                               	vpaddq zmm10,zmm14,zmm10
   819f3:	62 51 fd 40 d4 f0                               	vpaddq zmm14,zmm16,zmm8
   819f9:	62 e1 fd 48 6f 4c 3a 01                         	vmovdqa64 zmm17,ZMMWORD PTR [rdx+rdi*1+0x40]
   81a01:	62 f3 ad 48 1e ce 01                            	vpcmpltuq k1,zmm10,zmm6
   81a08:	62 71 fd 49 6f fe                               	vmovdqa64 zmm15{k1},zmm6
   81a0e:	62 31 fd 49 6f f0                               	vmovdqa64 zmm14{k1},zmm16
   81a14:	62 c1 85 48 d4 d2                               	vpaddq zmm18,zmm15,zmm10
   81a1a:	62 d1 85 48 73 d6 34                            	vpsrlq zmm15,zmm14,0x34
   81a21:	62 11 8d 48 db d7                               	vpandq zmm10,zmm14,zmm31
   81a27:	62 c1 fd 49 6f eb                               	vmovdqa64 zmm21{k1},zmm11
   81a2d:	62 31 85 48 d4 fd                               	vpaddq zmm15,zmm15,zmm21
   81a33:	62 e1 fd 48 6f 6c 3a 04                         	vmovdqa64 zmm21,ZMMWORD PTR [rdx+rdi*1+0x100]
   81a3b:	62 d1 8d 48 73 d7 34                            	vpsrlq zmm14,zmm15,0x34
   81a42:	62 11 85 48 db df                               	vpandq zmm11,zmm15,zmm31
   81a48:	62 c1 fd 49 6f e4                               	vmovdqa64 zmm20{k1},zmm12
   81a4e:	62 31 8d 48 d4 f4                               	vpaddq zmm14,zmm14,zmm20
   81a54:	62 e1 fd 48 6f 24 3a                            	vmovdqa64 zmm20,ZMMWORD PTR [rdx+rdi*1]
   81a5b:	62 d1 85 48 73 d6 34                            	vpsrlq zmm15,zmm14,0x34
   81a62:	62 11 8d 48 db e7                               	vpandq zmm12,zmm14,zmm31
   81a68:	62 c1 fd 49 6f dd                               	vmovdqa64 zmm19{k1},zmm13
   81a6e:	62 31 85 48 d4 fb                               	vpaddq zmm15,zmm15,zmm19
   81a74:	62 e1 fd 48 6f 5c 3a 03                         	vmovdqa64 zmm19,ZMMWORD PTR [rdx+rdi*1+0xc0]
   81a7c:	62 d1 8d 48 73 d7 34                            	vpsrlq zmm14,zmm15,0x34
   81a83:	62 c1 f5 40 fb cb                               	vpsubq zmm17,zmm17,zmm11
   81a89:	62 11 85 48 db ef                               	vpandq zmm13,zmm15,zmm31
   81a8f:	62 72 fd 48 59 bc 24 60 04 00 00                	vpbroadcastq zmm15,QWORD PTR [rsp+0x460]
   81a9a:	62 31 8d 48 d4 f2                               	vpaddq zmm14,zmm14,zmm18
   81aa0:	62 e1 fd 48 6f 54 3a 02                         	vmovdqa64 zmm18,ZMMWORD PTR [rdx+rdi*1+0x80]
   81aa8:	62 11 8d 48 db f7                               	vpandq zmm14,zmm14,zmm31
   81aae:	62 c1 d5 40 fb ee                               	vpsubq zmm21,zmm21,zmm14
   81ab4:	62 c1 dd 40 fb c2                               	vpsubq zmm16,zmm20,zmm10
   81aba:	62 81 fd 40 db e7                               	vpandq zmm20,zmm16,zmm31
   81ac0:	62 b1 fd 40 72 e0 34                            	vpsraq zmm16,zmm16,0x34
   81ac7:	62 a1 f5 40 d4 c0                               	vpaddq zmm16,zmm17,zmm16
   81acd:	62 c1 e5 40 fb dd                               	vpsubq zmm19,zmm19,zmm13
   81ad3:	62 81 fd 40 db cf                               	vpandq zmm17,zmm16,zmm31
   81ad9:	62 b1 fd 40 72 e0 34                            	vpsraq zmm16,zmm16,0x34
   81ae0:	62 61 f5 50 d4 84 24 48 04 00 00                	vpaddq zmm24,zmm17,QWORD BCST [rsp+0x448]
   81aeb:	62 c1 ed 40 fb d4                               	vpsubq zmm18,zmm18,zmm12
   81af1:	62 a1 ed 40 d4 c0                               	vpaddq zmm16,zmm18,zmm16
   81af7:	62 81 fd 40 db d7                               	vpandq zmm18,zmm16,zmm31
   81afd:	62 e1 ed 50 d4 bc 24 50 04 00 00                	vpaddq zmm23,zmm18,QWORD BCST [rsp+0x450]
   81b08:	62 b1 fd 40 72 e0 34                            	vpsraq zmm16,zmm16,0x34
   81b0f:	62 a1 e5 40 d4 c0                               	vpaddq zmm16,zmm19,zmm16
   81b15:	62 81 fd 40 db df                               	vpandq zmm19,zmm16,zmm31
   81b1b:	62 b1 fd 40 72 e0 34                            	vpsraq zmm16,zmm16,0x34
   81b22:	62 a1 d5 40 d4 c0                               	vpaddq zmm16,zmm21,zmm16
   81b28:	62 c1 dd 40 d4 e8                               	vpaddq zmm21,zmm20,zmm8
   81b2e:	62 f3 fd 40 1e ce 01                            	vpcmpltuq k1,zmm16,zmm6
   81b35:	62 a1 fd 49 6f ec                               	vmovdqa64 zmm21{k1},zmm20
   81b3b:	62 71 fd 49 6f fe                               	vmovdqa64 zmm15{k1},zmm6
   81b41:	62 31 85 48 d4 f8                               	vpaddq zmm15,zmm15,zmm16
   81b47:	62 21 fd 49 6f c1                               	vmovdqa64 zmm24{k1},zmm17
   81b4d:	62 b1 fd 40 73 d5 34                            	vpsrlq zmm16,zmm21,0x34
   81b54:	62 81 fd 40 d4 c0                               	vpaddq zmm16,zmm16,zmm24
   81b5a:	62 b1 dd 40 73 d0 34                            	vpsrlq zmm20,zmm16,0x34
   81b61:	62 01 fd 40 db d7                               	vpandq zmm26,zmm16,zmm31
   81b67:	62 a1 fd 49 6f fa                               	vmovdqa64 zmm23{k1},zmm18
   81b6d:	62 e1 e5 50 d4 94 24 58 04 00 00                	vpaddq zmm18,zmm19,QWORD BCST [rsp+0x458]
   81b78:	62 61 fe 28 7f 4c 24 22                         	vmovdqu64 YMMWORD PTR [rsp+0x440],ymm25
   81b80:	4c 89 a4 24 60 04 00 00                         	mov    QWORD PTR [rsp+0x460],r12
   81b88:	62 01 35 00 ef c9                               	vpxord xmm25,xmm25,xmm25
   81b8e:	62 21 dd 40 d4 c7                               	vpaddq zmm24,zmm20,zmm23
   81b94:	62 e2 fd 48 59 8c 24 48 04 00 00                	vpbroadcastq zmm17,QWORD PTR [rsp+0x448]
   81b9f:	62 91 fd 40 73 d0 34                            	vpsrlq zmm16,zmm24,0x34
   81ba6:	62 a1 fd 49 6f d3                               	vmovdqa64 zmm18{k1},zmm19
   81bac:	62 81 d5 40 db df                               	vpandq zmm19,zmm21,zmm31
   81bb2:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   81bb8:	62 a1 fd 40 d4 fa                               	vpaddq zmm23,zmm16,zmm18
   81bbe:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   81bc4:	62 22 d5 48 b5 e3                               	vpmadd52huq zmm28,zmm5,zmm19
   81bca:	62 a2 d5 48 b4 eb                               	vpmadd52luq zmm21,zmm5,zmm19
   81bd0:	62 22 dd 48 b5 db                               	vpmadd52huq zmm27,zmm4,zmm19
   81bd6:	62 22 e5 48 b5 cb                               	vpmadd52huq zmm25,zmm3,zmm19
   81bdc:	62 a2 ed 48 b5 f3                               	vpmadd52huq zmm22,zmm2,zmm19
   81be2:	62 a2 f5 48 b5 d3                               	vpmadd52huq zmm18,zmm1,zmm19
   81be8:	62 b1 fd 40 73 d7 34                            	vpsrlq zmm16,zmm23,0x34
   81bef:	62 c1 fd 40 d4 e7                               	vpaddq zmm20,zmm16,zmm15
   81bf5:	62 e2 fd 48 59 84 24 50 04 00 00                	vpbroadcastq zmm16,QWORD PTR [rsp+0x450]
   81c00:	62 72 fd 48 59 bc 24 58 04 00 00                	vpbroadcastq zmm15,QWORD PTR [rsp+0x458]
   81c0b:	62 81 dd 40 db e7                               	vpandq zmm20,zmm20,zmm31
   81c11:	62 22 dd 48 b4 e3                               	vpmadd52luq zmm28,zmm4,zmm19
   81c17:	62 02 d5 40 b4 ee                               	vpmadd52luq zmm29,zmm21,zmm30
   81c1d:	62 22 e5 48 b4 db                               	vpmadd52luq zmm27,zmm3,zmm19
   81c23:	62 22 ed 48 b4 cb                               	vpmadd52luq zmm25,zmm2,zmm19
   81c29:	62 a2 f5 48 b4 f3                               	vpmadd52luq zmm22,zmm1,zmm19
   81c2f:	62 81 d5 40 d4 df                               	vpaddq zmm19,zmm21,zmm31
   81c35:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   81c3b:	62 82 f5 48 b5 ea                               	vpmadd52huq zmm21,zmm1,zmm26
   81c41:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   81c48:	62 e2 95 40 b5 df                               	vpmadd52huq zmm19,zmm29,zmm7
   81c4e:	62 22 95 40 b4 e1                               	vpmadd52luq zmm28,zmm29,zmm17
   81c54:	62 22 95 40 b5 d9                               	vpmadd52huq zmm27,zmm29,zmm17
   81c5a:	62 22 95 40 b5 c8                               	vpmadd52huq zmm25,zmm29,zmm16
   81c60:	62 c2 95 40 b5 f7                               	vpmadd52huq zmm22,zmm29,zmm15
   81c66:	62 21 9d 40 d4 e3                               	vpaddq zmm28,zmm28,zmm19
   81c6c:	62 e2 fd 48 59 9c 24 60 04 00 00                	vpbroadcastq zmm19,QWORD PTR [rsp+0x460]
   81c77:	62 22 95 40 b4 d8                               	vpmadd52luq zmm27,zmm29,zmm16
   81c7d:	62 42 95 40 b4 cf                               	vpmadd52luq zmm25,zmm29,zmm15
   81c83:	62 02 d5 48 b4 e2                               	vpmadd52luq zmm28,zmm5,zmm26
   81c89:	62 02 d5 48 b5 da                               	vpmadd52huq zmm27,zmm5,zmm26
   81c8f:	62 02 dd 48 b5 ca                               	vpmadd52huq zmm25,zmm4,zmm26
   81c95:	62 a2 95 40 b4 f3                               	vpmadd52luq zmm22,zmm29,zmm19
   81c9b:	62 a2 95 40 b5 d3                               	vpmadd52huq zmm18,zmm29,zmm19
   81ca1:	62 02 dd 48 b4 da                               	vpmadd52luq zmm27,zmm4,zmm26
   81ca7:	62 02 e5 48 b4 ca                               	vpmadd52luq zmm25,zmm3,zmm26
   81cad:	62 82 e5 48 b5 f2                               	vpmadd52huq zmm22,zmm3,zmm26
   81cb3:	62 82 ed 48 b5 d2                               	vpmadd52huq zmm18,zmm2,zmm26
   81cb9:	62 82 ed 48 b4 f2                               	vpmadd52luq zmm22,zmm2,zmm26
   81cbf:	62 82 f5 48 b4 d2                               	vpmadd52luq zmm18,zmm1,zmm26
   81cc5:	62 01 2d 00 ef d2                               	vpxord xmm26,xmm26,xmm26
   81ccb:	62 02 9d 40 b4 d6                               	vpmadd52luq zmm26,zmm28,zmm30
   81cd1:	62 01 9d 40 d4 e7                               	vpaddq zmm28,zmm28,zmm31
   81cd7:	62 91 9d 40 73 d4 34                            	vpsrlq zmm28,zmm28,0x34
   81cde:	62 c2 ad 40 b5 d7                               	vpmadd52huq zmm18,zmm26,zmm15
   81ce4:	62 22 ad 40 b5 c9                               	vpmadd52huq zmm25,zmm26,zmm17
   81cea:	62 62 ad 40 b5 e7                               	vpmadd52huq zmm28,zmm26,zmm7
   81cf0:	62 22 ad 40 b4 d9                               	vpmadd52luq zmm27,zmm26,zmm17
   81cf6:	62 a2 ad 40 b5 eb                               	vpmadd52huq zmm21,zmm26,zmm19
   81cfc:	62 a2 ad 40 b5 f0                               	vpmadd52huq zmm22,zmm26,zmm16
   81d02:	62 a2 ad 40 b4 d3                               	vpmadd52luq zmm18,zmm26,zmm19
   81d08:	62 01 a5 40 d4 dc                               	vpaddq zmm27,zmm27,zmm28
   81d0e:	62 01 bd 40 db e7                               	vpandq zmm28,zmm24,zmm31
   81d14:	62 22 ad 40 b4 c8                               	vpmadd52luq zmm25,zmm26,zmm16
   81d1a:	62 c2 ad 40 b4 f7                               	vpmadd52luq zmm22,zmm26,zmm15
   81d20:	62 01 2d 00 ef d2                               	vpxord xmm26,xmm26,xmm26
   81d26:	62 01 3d 00 ef c0                               	vpxord xmm24,xmm24,xmm24
   81d2c:	62 82 ed 48 b5 ec                               	vpmadd52huq zmm21,zmm2,zmm28
   81d32:	62 02 d5 48 b4 dc                               	vpmadd52luq zmm27,zmm5,zmm28
   81d38:	62 02 f5 48 b5 c4                               	vpmadd52huq zmm24,zmm1,zmm28
   81d3e:	62 82 e5 48 b5 d4                               	vpmadd52huq zmm18,zmm3,zmm28
   81d44:	62 02 d5 48 b5 cc                               	vpmadd52huq zmm25,zmm5,zmm28
   81d4a:	62 82 dd 48 b5 f4                               	vpmadd52huq zmm22,zmm4,zmm28
   81d50:	62 02 a5 40 b4 d6                               	vpmadd52luq zmm26,zmm27,zmm30
   81d56:	62 82 f5 48 b4 ec                               	vpmadd52luq zmm21,zmm1,zmm28
   81d5c:	62 01 a5 40 d4 df                               	vpaddq zmm27,zmm27,zmm31
   81d62:	62 91 a5 40 73 d3 34                            	vpsrlq zmm27,zmm27,0x34
   81d69:	62 82 ed 48 b4 d4                               	vpmadd52luq zmm18,zmm2,zmm28
   81d6f:	62 02 dd 48 b4 cc                               	vpmadd52luq zmm25,zmm4,zmm28
   81d75:	62 82 e5 48 b4 f4                               	vpmadd52luq zmm22,zmm3,zmm28
   81d7b:	62 c2 ad 40 b5 ef                               	vpmadd52huq zmm21,zmm26,zmm15
   81d81:	62 62 ad 40 b5 df                               	vpmadd52huq zmm27,zmm26,zmm7
   81d87:	62 22 ad 40 b5 c3                               	vpmadd52huq zmm24,zmm26,zmm19
   81d8d:	62 a2 ad 40 b5 d0                               	vpmadd52huq zmm18,zmm26,zmm16
   81d93:	62 22 ad 40 b4 c9                               	vpmadd52luq zmm25,zmm26,zmm17
   81d99:	62 a2 ad 40 b5 f1                               	vpmadd52huq zmm22,zmm26,zmm17
   81d9f:	62 a2 ad 40 b4 eb                               	vpmadd52luq zmm21,zmm26,zmm19
   81da5:	62 c2 ad 40 b4 d7                               	vpmadd52luq zmm18,zmm26,zmm15
   81dab:	62 01 b5 40 d4 cb                               	vpaddq zmm25,zmm25,zmm27
   81db1:	62 01 c5 40 db df                               	vpandq zmm27,zmm23,zmm31
   81db7:	62 a2 ad 40 b4 f0                               	vpmadd52luq zmm22,zmm26,zmm16
   81dbd:	62 01 2d 00 ef d2                               	vpxord xmm26,xmm26,xmm26
   81dc3:	62 a1 45 00 ef ff                               	vpxord xmm23,xmm23,xmm23
   81dc9:	62 82 e5 48 b5 eb                               	vpmadd52huq zmm21,zmm3,zmm27
   81dcf:	62 02 ed 48 b5 c3                               	vpmadd52huq zmm24,zmm2,zmm27
   81dd5:	62 02 d5 48 b4 cb                               	vpmadd52luq zmm25,zmm5,zmm27
   81ddb:	62 82 f5 48 b5 fb                               	vpmadd52huq zmm23,zmm1,zmm27
   81de1:	62 82 dd 48 b5 d3                               	vpmadd52huq zmm18,zmm4,zmm27
   81de7:	62 82 d5 48 b5 f3                               	vpmadd52huq zmm22,zmm5,zmm27
   81ded:	62 02 b5 40 b4 d6                               	vpmadd52luq zmm26,zmm25,zmm30
   81df3:	62 82 ed 48 b4 eb                               	vpmadd52luq zmm21,zmm2,zmm27
   81df9:	62 02 f5 48 b4 c3                               	vpmadd52luq zmm24,zmm1,zmm27
   81dff:	62 01 b5 40 d4 cf                               	vpaddq zmm25,zmm25,zmm31
   81e05:	62 91 b5 40 73 d1 34                            	vpsrlq zmm25,zmm25,0x34
   81e0c:	62 82 e5 48 b4 d3                               	vpmadd52luq zmm18,zmm3,zmm27
   81e12:	62 82 dd 48 b4 f3                               	vpmadd52luq zmm22,zmm4,zmm27
   81e18:	62 a2 ad 40 b5 e8                               	vpmadd52huq zmm21,zmm26,zmm16
   81e1e:	62 42 ad 40 b5 c7                               	vpmadd52huq zmm24,zmm26,zmm15
   81e24:	62 a2 ad 40 b5 fb                               	vpmadd52huq zmm23,zmm26,zmm19
   81e2a:	62 62 ad 40 b5 cf                               	vpmadd52huq zmm25,zmm26,zmm7
   81e30:	62 a2 ad 40 b5 d1                               	vpmadd52huq zmm18,zmm26,zmm17
   81e36:	62 a2 ad 40 b4 f1                               	vpmadd52luq zmm22,zmm26,zmm17
   81e3c:	62 c2 ad 40 b4 ef                               	vpmadd52luq zmm21,zmm26,zmm15
   81e42:	62 22 ad 40 b4 c3                               	vpmadd52luq zmm24,zmm26,zmm19
   81e48:	62 a2 ed 48 b5 fc                               	vpmadd52huq zmm23,zmm2,zmm20
   81e4e:	62 a2 ad 40 b4 d0                               	vpmadd52luq zmm18,zmm26,zmm16
   81e54:	62 81 cd 40 d4 f1                               	vpaddq zmm22,zmm22,zmm25
   81e5a:	62 a2 dd 48 b5 ec                               	vpmadd52huq zmm21,zmm4,zmm20
   81e60:	62 22 e5 48 b5 c4                               	vpmadd52huq zmm24,zmm3,zmm20
   81e66:	62 a2 d5 48 b4 f4                               	vpmadd52luq zmm22,zmm5,zmm20
   81e6c:	62 a2 f5 48 b4 fc                               	vpmadd52luq zmm23,zmm1,zmm20
   81e72:	62 a2 d5 48 b5 d4                               	vpmadd52huq zmm18,zmm5,zmm20
   81e78:	62 22 ed 48 b4 c4                               	vpmadd52luq zmm24,zmm2,zmm20
   81e7e:	c5 e9 ef d2                                     	vpxor  xmm2,xmm2,xmm2
   81e82:	62 b2 f5 48 b5 d4                               	vpmadd52huq zmm2,zmm1,zmm20
   81e88:	62 a2 e5 48 b4 ec                               	vpmadd52luq zmm21,zmm3,zmm20
   81e8e:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   81e92:	62 92 cd 40 b4 ce                               	vpmadd52luq zmm1,zmm22,zmm30
   81e98:	62 a2 dd 48 b4 d4                               	vpmadd52luq zmm18,zmm4,zmm20
   81e9e:	62 e2 fd 48 59 25 60 55 f8 ff                   	vpbroadcastq zmm20,QWORD PTR [rip+0xfffffffffff85560]        # 7408 <GCC_except_table746+0x94>
   81ea8:	62 f1 dd 48 73 f1 04                            	vpsllq zmm4,zmm1,0x4
   81eaf:	62 b1 f5 48 db cc                               	vpandq zmm1,zmm1,zmm20
   81eb5:	62 b1 cd 40 d4 dc                               	vpaddq zmm3,zmm22,zmm20
   81ebb:	62 e2 fd 48 59 35 d3 55 f8 ff                   	vpbroadcastq zmm22,QWORD PTR [rip+0xfffffffffff855d3]        # 7498 <GCC_except_table746+0x124>
   81ec5:	62 a2 f5 48 b5 e9                               	vpmadd52huq zmm21,zmm1,zmm17
   81ecb:	62 22 f5 48 b5 c0                               	vpmadd52huq zmm24,zmm1,zmm16
   81ed1:	62 c2 f5 48 b5 ff                               	vpmadd52huq zmm23,zmm1,zmm15
   81ed7:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   81ede:	62 a2 f5 48 b4 d1                               	vpmadd52luq zmm18,zmm1,zmm17
   81ee4:	62 b2 f5 48 b5 d3                               	vpmadd52huq zmm2,zmm1,zmm19
   81eea:	62 f2 dd 48 b5 df                               	vpmadd52huq zmm3,zmm4,zmm7
   81ef0:	c5 fc 28 3d 28 62 f8 ff                         	vmovaps ymm7,YMMWORD PTR [rip+0xfffffffffff86228]        # 8120 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x9a0>
   81ef8:	62 42 f5 48 b4 c7                               	vpmadd52luq zmm24,zmm1,zmm15
   81efe:	62 a2 f5 48 b4 e8                               	vpmadd52luq zmm21,zmm1,zmm16
   81f04:	62 a2 f5 48 b4 fb                               	vpmadd52luq zmm23,zmm1,zmm19
   81f0a:	62 b1 f5 48 73 f2 04                            	vpsllq zmm1,zmm18,0x4
   81f11:	62 f1 ed 48 73 f2 04                            	vpsllq zmm2,zmm2,0x4
   81f18:	62 d1 f5 48 db c9                               	vpandq zmm1,zmm1,zmm9
   81f1e:	62 f1 f5 48 d4 cb                               	vpaddq zmm1,zmm1,zmm3
   81f24:	62 b1 e5 48 73 d2 30                            	vpsrlq zmm3,zmm18,0x30
   81f2b:	62 a1 95 48 d4 de                               	vpaddq zmm19,zmm13,zmm22
   81f31:	62 b1 dd 48 73 f5 04                            	vpsllq zmm4,zmm21,0x4
   81f38:	62 91 85 48 73 f0 04                            	vpsllq zmm15,zmm24,0x4
   81f3f:	62 b1 fd 40 73 f7 04                            	vpsllq zmm16,zmm23,0x4
   81f46:	62 b1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm21,0x30
   81f4d:	62 91 f5 40 73 d0 30                            	vpsrlq zmm17,zmm24,0x30
   81f54:	62 e2 fd 48 59 2d 1a 55 f8 ff                   	vpbroadcastq zmm21,QWORD PTR [rip+0xfffffffffff8551a]        # 7478 <GCC_except_table746+0x104>
   81f5e:	62 51 85 48 db f9                               	vpandq zmm15,zmm15,zmm9
   81f64:	62 d1 dd 48 db e1                               	vpandq zmm4,zmm4,zmm9
   81f6a:	62 c1 fd 40 db c1                               	vpandq zmm16,zmm16,zmm9
   81f70:	62 f1 b5 48 73 d1 34                            	vpsrlq zmm9,zmm1,0x34
   81f77:	c5 fc 11 bc 24 40 04 00 00                      	vmovups YMMWORD PTR [rsp+0x440],ymm7
   81f80:	4c 89 84 24 60 04 00 00                         	mov    QWORD PTR [rsp+0x460],r8
   81f88:	62 91 f5 48 db cf                               	vpandq zmm1,zmm1,zmm31
   81f8e:	62 f1 b5 48 d4 db                               	vpaddq zmm3,zmm9,zmm3
   81f94:	62 f1 f5 48 fb 4c 3a 05                         	vpsubq zmm1,zmm1,ZMMWORD PTR [rdx+rdi*1+0x140]
   81f9c:	62 f1 85 48 d4 ed                               	vpaddq zmm5,zmm15,zmm5
   81fa2:	62 31 fd 40 d4 f9                               	vpaddq zmm15,zmm16,zmm17
   81fa8:	62 b1 f5 40 73 d7 30                            	vpsrlq zmm17,zmm23,0x30
   81faf:	62 e2 fd 48 59 3d 57 54 f8 ff                   	vpbroadcastq zmm23,QWORD PTR [rip+0xfffffffffff85457]        # 7410 <GCC_except_table746+0x9c>
   81fb9:	62 f1 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm4
   81fbf:	62 b1 ed 48 d4 d1                               	vpaddq zmm2,zmm2,zmm17
   81fc5:	62 f1 dd 48 73 d3 34                            	vpsrlq zmm4,zmm3,0x34
   81fcc:	62 91 e5 48 db df                               	vpandq zmm3,zmm3,zmm31
   81fd2:	62 f1 e5 48 fb 5c 3a 06                         	vpsubq zmm3,zmm3,ZMMWORD PTR [rdx+rdi*1+0x180]
   81fda:	62 f1 dd 48 d4 e5                               	vpaddq zmm4,zmm4,zmm5
   81fe0:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   81fe7:	62 91 dd 48 db e7                               	vpandq zmm4,zmm4,zmm31
   81fed:	62 f1 dd 48 fb 64 3a 07                         	vpsubq zmm4,zmm4,ZMMWORD PTR [rdx+rdi*1+0x1c0]
   81ff5:	62 d1 d5 48 d4 ef                               	vpaddq zmm5,zmm5,zmm15
   81ffb:	62 f1 85 48 73 d5 34                            	vpsrlq zmm15,zmm5,0x34
   82002:	62 91 d5 48 db ef                               	vpandq zmm5,zmm5,zmm31
   82008:	62 f1 d5 48 fb 6c 3a 08                         	vpsubq zmm5,zmm5,ZMMWORD PTR [rdx+rdi*1+0x200]
   82010:	62 a1 9d 48 d4 d5                               	vpaddq zmm18,zmm12,zmm21
   82016:	62 f1 85 48 d4 d2                               	vpaddq zmm2,zmm15,zmm2
   8201c:	62 f1 ed 48 fb 54 3a 09                         	vpsubq zmm2,zmm2,ZMMWORD PTR [rdx+rdi*1+0x240]
   82024:	62 72 fd 48 59 bc 24 60 04 00 00                	vpbroadcastq zmm15,QWORD PTR [rsp+0x460]
   8202f:	62 81 f5 48 db c7                               	vpandq zmm16,zmm1,zmm31
   82035:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   8203c:	62 a1 8d 48 d4 e7                               	vpaddq zmm20,zmm14,zmm23
   82042:	62 f1 e5 48 d4 c9                               	vpaddq zmm1,zmm3,zmm1
   82048:	62 91 f5 48 db df                               	vpandq zmm3,zmm1,zmm31
   8204e:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   82055:	62 e1 e5 58 d4 8c 24 48 04 00 00                	vpaddq zmm17,zmm3,QWORD BCST [rsp+0x448]
   82060:	62 f1 dd 48 d4 c9                               	vpaddq zmm1,zmm4,zmm1
   82066:	62 91 f5 48 db e7                               	vpandq zmm4,zmm1,zmm31
   8206c:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   82073:	62 71 dd 58 d4 8c 24 50 04 00 00                	vpaddq zmm9,zmm4,QWORD BCST [rsp+0x450]
   8207e:	62 f1 d5 48 d4 c9                               	vpaddq zmm1,zmm5,zmm1
   82084:	62 91 f5 48 db ef                               	vpandq zmm5,zmm1,zmm31
   8208a:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   82091:	62 f1 ed 48 d4 c9                               	vpaddq zmm1,zmm2,zmm1
   82097:	62 d1 fd 40 d4 d0                               	vpaddq zmm2,zmm16,zmm8
   8209d:	62 71 d5 58 d4 84 24 58 04 00 00                	vpaddq zmm8,zmm5,QWORD BCST [rsp+0x458]
   820a8:	62 f3 f5 48 1e ce 01                            	vpcmpltuq k1,zmm1,zmm6
   820af:	62 b1 fd 49 6f d0                               	vmovdqa64 zmm2{k1},zmm16
   820b5:	62 f1 c5 48 73 d2 34                            	vpsrlq zmm7,zmm2,0x34
   820bc:	62 71 fd 49 6f fe                               	vmovdqa64 zmm15{k1},zmm6
   820c2:	62 f1 85 48 d4 c9                               	vpaddq zmm1,zmm15,zmm1
   820c8:	62 91 ed 48 db d7                               	vpandq zmm2,zmm2,zmm31
   820ce:	62 e1 fd 49 6f cb                               	vmovdqa64 zmm17{k1},zmm3
   820d4:	62 71 fd 49 6f cc                               	vmovdqa64 zmm9{k1},zmm4
   820da:	62 71 fd 49 6f c5                               	vmovdqa64 zmm8{k1},zmm5
   820e0:	62 b1 c5 48 d4 e9                               	vpaddq zmm5,zmm7,zmm17
   820e6:	62 f2 fd 48 59 3d 08 54 f8 ff                   	vpbroadcastq zmm7,QWORD PTR [rip+0xfffffffffff85408]        # 74f8 <GCC_except_table746+0x184>
   820f0:	62 f1 85 48 73 d5 34                            	vpsrlq zmm15,zmm5,0x34
   820f7:	62 91 d5 48 db ef                               	vpandq zmm5,zmm5,zmm31
   820fd:	62 d1 85 48 d4 d9                               	vpaddq zmm3,zmm15,zmm9
   82103:	62 f1 85 48 73 d3 34                            	vpsrlq zmm15,zmm3,0x34
   8210a:	62 91 e5 48 db df                               	vpandq zmm3,zmm3,zmm31
   82110:	62 d1 85 48 d4 e0                               	vpaddq zmm4,zmm15,zmm8
   82116:	62 72 fd 48 59 05 30 53 f8 ff                   	vpbroadcastq zmm8,QWORD PTR [rip+0xfffffffffff85330]        # 7450 <GCC_except_table746+0xdc>
   82120:	62 f1 85 48 73 d4 34                            	vpsrlq zmm15,zmm4,0x34
   82127:	62 91 dd 48 db e7                               	vpandq zmm4,zmm4,zmm31
   8212d:	62 f1 85 48 d4 c9                               	vpaddq zmm1,zmm15,zmm1
   82133:	62 91 f5 48 db cf                               	vpandq zmm1,zmm1,zmm31
   82139:	62 71 ad 48 d4 cf                               	vpaddq zmm9,zmm10,zmm7
   8213f:	62 f1 ed 48 d4 ff                               	vpaddq zmm7,zmm2,zmm7
   82145:	62 31 f5 48 d4 ff                               	vpaddq zmm15,zmm1,zmm23
   8214b:	62 d1 fd 40 72 e1 34                            	vpsraq zmm16,zmm9,0x34
   82152:	62 a1 a5 48 d4 c0                               	vpaddq zmm16,zmm11,zmm16
   82158:	62 c1 fd 40 d4 c0                               	vpaddq zmm16,zmm16,zmm8
   8215e:	62 b1 f5 40 72 e0 34                            	vpsraq zmm17,zmm16,0x34
   82165:	62 a1 ed 40 d4 c9                               	vpaddq zmm17,zmm18,zmm17
   8216b:	62 b1 ed 40 72 e1 34                            	vpsraq zmm18,zmm17,0x34
   82172:	62 a1 e5 40 d4 d2                               	vpaddq zmm18,zmm19,zmm18
   82178:	62 b1 e5 40 72 e2 34                            	vpsraq zmm19,zmm18,0x34
   8217f:	62 a1 dd 40 d4 db                               	vpaddq zmm19,zmm20,zmm19
   82185:	62 f3 e5 40 1e ce 01                            	vpcmpltuq k1,zmm19,zmm6
   8218c:	62 11 b5 49 db d7                               	vpandq zmm10{k1},zmm9,zmm31
   82192:	62 11 fd 41 db df                               	vpandq zmm11{k1},zmm16,zmm31
   82198:	62 11 f5 41 db e7                               	vpandq zmm12{k1},zmm17,zmm31
   8219e:	62 11 ed 41 db ef                               	vpandq zmm13{k1},zmm18,zmm31
   821a4:	62 11 e5 41 db f7                               	vpandq zmm14{k1},zmm19,zmm31
   821aa:	c5 f9 90 4c 01 c4                               	kmovb  k1,BYTE PTR [rcx+rax*1-0x3c]
   821b0:	48 05 00 fc ff ff                               	add    rax,0xfffffffffffffc00
   821b6:	62 71 fd 49 7f 14 3a                            	vmovdqa64 ZMMWORD PTR [rdx+rdi*1]{k1},zmm10
   821bd:	62 71 fd 49 7f 5c 3a 01                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x40]{k1},zmm11
   821c5:	62 f1 a5 48 72 e7 34                            	vpsraq zmm11,zmm7,0x34
   821cc:	62 71 fd 49 7f 64 3a 02                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x80]{k1},zmm12
   821d4:	62 71 fd 49 7f 6c 3a 03                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0xc0]{k1},zmm13
   821dc:	62 31 e5 48 d4 ed                               	vpaddq zmm13,zmm3,zmm21
   821e2:	62 71 fd 49 7f 74 3a 04                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x100]{k1},zmm14
   821ea:	62 31 dd 48 d4 f6                               	vpaddq zmm14,zmm4,zmm22
   821f0:	62 71 85 40 db 54 24 1a                         	vpandq zmm10,zmm31,ZMMWORD PTR [rsp+0x680]
   821f8:	62 51 d5 48 d4 db                               	vpaddq zmm11,zmm5,zmm11
   821fe:	62 51 a5 48 d4 d8                               	vpaddq zmm11,zmm11,zmm8
   82204:	62 d1 9d 48 72 e3 34                            	vpsraq zmm12,zmm11,0x34
   8220b:	62 51 95 48 d4 e4                               	vpaddq zmm12,zmm13,zmm12
   82211:	62 d1 95 48 72 e4 34                            	vpsraq zmm13,zmm12,0x34
   82218:	62 51 8d 48 d4 ed                               	vpaddq zmm13,zmm14,zmm13
   8221e:	62 d1 8d 48 72 e5 34                            	vpsraq zmm14,zmm13,0x34
   82225:	62 51 85 48 d4 f6                               	vpaddq zmm14,zmm15,zmm14
   8222b:	62 f3 8d 48 1e d6 01                            	vpcmpltuq k2,zmm14,zmm6
   82232:	62 f1 85 40 db 74 24 1b                         	vpandq zmm6,zmm31,ZMMWORD PTR [rsp+0x6c0]
   8223a:	62 91 c5 4a db d7                               	vpandq zmm2{k2},zmm7,zmm31
   82240:	62 91 a5 4a db ef                               	vpandq zmm5{k2},zmm11,zmm31
   82246:	62 71 85 40 db 5c 24 04                         	vpandq zmm11,zmm31,ZMMWORD PTR [rsp+0x100]
   8224e:	62 f1 85 40 db 7c 24 07                         	vpandq zmm7,zmm31,ZMMWORD PTR [rsp+0x1c0]
   82256:	62 91 9d 4a db df                               	vpandq zmm3{k2},zmm12,zmm31
   8225c:	62 91 95 4a db e7                               	vpandq zmm4{k2},zmm13,zmm31
   82262:	62 91 8d 4a db cf                               	vpandq zmm1{k2},zmm14,zmm31
   82268:	62 f1 fd 49 7f 54 3a 05                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x140]{k1},zmm2
   82270:	62 f1 fd 49 7f 6c 3a 06                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x180]{k1},zmm5
   82278:	62 f1 fd 49 7f 5c 3a 07                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x1c0]{k1},zmm3
   82280:	62 f1 fd 49 7f 64 3a 08                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x200]{k1},zmm4
   82288:	62 f1 fd 49 7f 4c 3a 09                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x240]{k1},zmm1
   82290:	0f 85 7a e9 ff ff                               	jne    80c10 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2460>
   82296:	e9 1f e8 ff ff                                  	jmp    80aba <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x230a>
   8229b:	62 f1 7c 48 28 54 24 2e                         	vmovaps zmm2,ZMMWORD PTR [rsp+0xb80]
   822a3:	62 f1 7c 48 28 4c 24 2d                         	vmovaps zmm1,ZMMWORD PTR [rsp+0xb40]
   822ab:	62 f2 fd 48 59 05 cb 51 f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff851cb]        # 7480 <GCC_except_table746+0x10c>
   822b5:	48 8b 44 24 58                                  	mov    rax,QWORD PTR [rsp+0x58]
   822ba:	48 8d 0c b0                                     	lea    rcx,[rax+rsi*4]
   822be:	48 8d 04 b8                                     	lea    rax,[rax+rdi*4]
   822c2:	48 89 8c 24 70 06 00 00                         	mov    QWORD PTR [rsp+0x670],rcx
   822ca:	62 f1 7c 48 29 54 24 21                         	vmovaps ZMMWORD PTR [rsp+0x840],zmm2
   822d2:	62 f1 7c 48 29 4c 24 22                         	vmovaps ZMMWORD PTR [rsp+0x880],zmm1
   822da:	62 f1 fd 48 6f 54 24 2c                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xb00]
   822e2:	62 f1 fd 48 6f 4c 24 2b                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0xac0]
   822ea:	62 f1 fd 48 7f 44 24 20                         	vmovdqa64 ZMMWORD PTR [rsp+0x800],zmm0
   822f2:	62 f1 fd 48 7f 54 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm2
   822fa:	62 f1 fd 48 7f 4c 24 24                         	vmovdqa64 ZMMWORD PTR [rsp+0x900],zmm1
   82302:	e9 13 02 00 00                                  	jmp    8251a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3d6a>
   82307:	66 0f 1f 84 00 00 00 00 00                      	nop    WORD PTR [rax+rax*1+0x0]
   82310:	62 f1 fe 48 6f 44 24 26                         	vmovdqu64 zmm0,ZMMWORD PTR [rsp+0x980]
   82318:	62 f1 fe 48 6f 4c 24 27                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x9c0]
   82320:	62 f1 fe 48 6f 54 24 28                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0xa00]
   82328:	62 f1 fe 48 6f 5c 24 29                         	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0xa40]
   82330:	62 f1 fd 48 6f 3d 06 59 f8 ff                   	vmovdqa64 zmm7,ZMMWORD PTR [rip+0xfffffffffff85906]        # 7c40 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4c0>
   8233a:	62 71 fd 48 6f 05 3c 59 f8 ff                   	vmovdqa64 zmm8,ZMMWORD PTR [rip+0xfffffffffff8593c]        # 7c80 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x500>
   82344:	62 f2 fd 48 59 35 b2 50 f8 ff                   	vpbroadcastq zmm6,QWORD PTR [rip+0xfffffffffff850b2]        # 7400 <GCC_except_table746+0x8c>
   8234e:	49 bc 31 e1 72 4e 64 30 00 00                   	movabs r12,0x30644e72e131
   82358:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   8235e:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   82364:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   8236a:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   82370:	62 f1 fd 48 6f dc                               	vmovdqa64 zmm3,zmm4
   82376:	62 f1 fd 48 6f e8                               	vmovdqa64 zmm5,zmm0
   8237c:	62 f2 c5 48 7e d9                               	vpermt2q zmm3,zmm7,zmm1
   82382:	62 f2 bd 48 7e e1                               	vpermt2q zmm4,zmm8,zmm1
   82388:	62 f2 c5 48 7e ea                               	vpermt2q zmm5,zmm7,zmm2
   8238e:	62 f2 bd 48 7e c2                               	vpermt2q zmm0,zmm8,zmm2
   82394:	62 f3 d5 48 71 d3 0c                            	vpshldq zmm2,zmm5,zmm3,0xc
   8239b:	62 f1 e5 48 db ce                               	vpandq zmm1,zmm3,zmm6
   823a1:	62 f3 dd 48 71 dd 18                            	vpshldq zmm3,zmm4,zmm5,0x18
   823a8:	62 f3 fd 48 71 e4 24                            	vpshldq zmm4,zmm0,zmm4,0x24
   823af:	62 f1 fd 48 73 d0 10                            	vpsrlq zmm0,zmm0,0x10
   823b6:	62 d1 fd 48 7f 0e                               	vmovdqa64 ZMMWORD PTR [r14],zmm1
   823bc:	62 f1 ed 48 db d6                               	vpandq zmm2,zmm2,zmm6
   823c2:	62 f1 e5 48 db de                               	vpandq zmm3,zmm3,zmm6
   823c8:	62 f1 dd 48 db e6                               	vpandq zmm4,zmm4,zmm6
   823ce:	62 d1 fd 48 7f 56 01                            	vmovdqa64 ZMMWORD PTR [r14+0x40],zmm2
   823d5:	62 d1 fd 48 7f 5e 02                            	vmovdqa64 ZMMWORD PTR [r14+0x80],zmm3
   823dc:	62 d1 fd 48 7f 66 03                            	vmovdqa64 ZMMWORD PTR [r14+0xc0],zmm4
   823e3:	62 d1 fd 48 7f 46 04                            	vmovdqa64 ZMMWORD PTR [r14+0x100],zmm0
   823ea:	62 f1 fe 48 6f 44 24 09                         	vmovdqu64 zmm0,ZMMWORD PTR [rsp+0x240]
   823f2:	62 f1 fe 48 6f 4c 24 0a                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x280]
   823fa:	62 f1 fe 48 6f 54 24 0b                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x2c0]
   82402:	62 f1 fe 48 6f 5c 24 0c                         	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x300]
   8240a:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   82410:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   82416:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   8241c:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   82422:	62 f1 fd 48 6f dc                               	vmovdqa64 zmm3,zmm4
   82428:	62 f1 fd 48 6f e8                               	vmovdqa64 zmm5,zmm0
   8242e:	62 f2 c5 48 7e d9                               	vpermt2q zmm3,zmm7,zmm1
   82434:	62 f2 bd 48 7e e1                               	vpermt2q zmm4,zmm8,zmm1
   8243a:	62 f2 c5 48 7e ea                               	vpermt2q zmm5,zmm7,zmm2
   82440:	62 f2 bd 48 7e c2                               	vpermt2q zmm0,zmm8,zmm2
   82446:	62 f3 d5 48 71 d3 0c                            	vpshldq zmm2,zmm5,zmm3,0xc
   8244d:	62 f1 e5 48 db ce                               	vpandq zmm1,zmm3,zmm6
   82453:	62 f3 dd 48 71 dd 18                            	vpshldq zmm3,zmm4,zmm5,0x18
   8245a:	62 f3 fd 48 71 e4 24                            	vpshldq zmm4,zmm0,zmm4,0x24
   82461:	62 f1 fd 48 73 d0 10                            	vpsrlq zmm0,zmm0,0x10
   82468:	62 d1 fd 48 7f 4e 05                            	vmovdqa64 ZMMWORD PTR [r14+0x140],zmm1
   8246f:	62 f1 ed 48 db d6                               	vpandq zmm2,zmm2,zmm6
   82475:	62 f1 e5 48 db de                               	vpandq zmm3,zmm3,zmm6
   8247b:	62 f1 dd 48 db e6                               	vpandq zmm4,zmm4,zmm6
   82481:	62 d1 fd 48 7f 56 06                            	vmovdqa64 ZMMWORD PTR [r14+0x180],zmm2
   82488:	62 d1 fd 48 7f 5e 07                            	vmovdqa64 ZMMWORD PTR [r14+0x1c0],zmm3
   8248f:	62 d1 fd 48 7f 66 08                            	vmovdqa64 ZMMWORD PTR [r14+0x200],zmm4
   82496:	62 d1 fd 48 7f 46 09                            	vmovdqa64 ZMMWORD PTR [r14+0x240],zmm0
   8249d:	62 f1 7c 48 28 54 24 3a                         	vmovaps zmm2,ZMMWORD PTR [rsp+0xe80]
   824a5:	62 f1 7c 48 28 4c 24 39                         	vmovaps zmm1,ZMMWORD PTR [rsp+0xe40]
   824ad:	62 f1 fd 48 6f 44 24 3b                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0xec0]
   824b5:	48 8b 84 24 80 0c 00 00                         	mov    rax,QWORD PTR [rsp+0xc80]
   824bd:	4c 8b 7c 24 60                                  	mov    r15,QWORD PTR [rsp+0x60]
   824c2:	4c 8d b4 24 80 02 00 00                         	lea    r14,[rsp+0x280]
   824ca:	41 bd ff ff ff ff                               	mov    r13d,0xffffffff
   824d0:	48 83 c0 04                                     	add    rax,0x4
   824d4:	62 f1 7c 48 29 54 24 21                         	vmovaps ZMMWORD PTR [rsp+0x840],zmm2
   824dc:	62 f1 7c 48 29 4c 24 22                         	vmovaps ZMMWORD PTR [rsp+0x880],zmm1
   824e4:	62 f1 fd 48 6f 54 24 38                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xe00]
   824ec:	62 f1 fd 48 6f 4c 24 3c                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0xf00]
   824f4:	62 f1 fd 48 7f 44 24 20                         	vmovdqa64 ZMMWORD PTR [rsp+0x800],zmm0
   824fc:	62 f1 fd 48 7f 54 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm2
   82504:	62 f1 fd 48 7f 4c 24 24                         	vmovdqa64 ZMMWORD PTR [rsp+0x900],zmm1
   8250c:	48 3b 84 24 70 06 00 00                         	cmp    rax,QWORD PTR [rsp+0x670]
   82514:	0f 84 7d e6 ff ff                               	je     80b97 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x23e7>
   8251a:	8b 18                                           	mov    ebx,DWORD PTR [rax]
   8251c:	48 8b b4 24 a0 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xa0]
   82524:	48 89 84 24 80 0c 00 00                         	mov    QWORD PTR [rsp+0xc80],rax
   8252c:	48 39 de                                        	cmp    rsi,rbx
   8252f:	0f 86 43 27 00 00                               	jbe    84c78 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x64c8>
   82535:	48 8b bc 24 98 00 00 00                         	mov    rdi,QWORD PTR [rsp+0x98]
   8253d:	4c 69 c3 c0 02 00 00                            	imul   r8,rbx,0x2c0
   82544:	48 8b 94 24 80 00 00 00                         	mov    rdx,QWORD PTR [rsp+0x80]
   8254c:	48 8b b4 24 88 00 00 00                         	mov    rsi,QWORD PTR [rsp+0x88]
   82554:	48 8b 8c 24 d8 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xd8]
   8255c:	4a 8d 04 07                                     	lea    rax,[rdi+r8*1]
   82560:	42 8b bc 07 80 02 00 00                         	mov    edi,DWORD PTR [rdi+r8*1+0x280]
   82568:	48 89 84 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],rax
   82570:	48 8b 84 24 e0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xe0]
   82578:	4c 39 ef                                        	cmp    rdi,r13
   8257b:	0f 84 7f 00 00 00                               	je     82600 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3e50>
   82581:	48 39 fe                                        	cmp    rsi,rdi
   82584:	0f 86 79 26 00 00                               	jbe    84c03 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6453>
   8258a:	4c 8b 84 24 00 01 00 00                         	mov    r8,QWORD PTR [rsp+0x100]
   82592:	45 0f b6 80 a0 02 00 00                         	movzx  r8d,BYTE PTR [r8+0x2a0]
   8259a:	44 3a 04 3a                                     	cmp    r8b,BYTE PTR [rdx+rdi*1]
   8259e:	73 60                                           	jae    82600 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3e50>
   825a0:	48 39 f8                                        	cmp    rax,rdi
   825a3:	0f 86 3c 26 00 00                               	jbe    84be5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6435>
   825a9:	4c 03 04 f9                                     	add    r8,QWORD PTR [rcx+rdi*8]
   825ad:	4d 39 f8                                        	cmp    r8,r15
   825b0:	0f 83 3b 26 00 00                               	jae    84bf1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6441>
   825b6:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   825bb:	46 8b 04 87                                     	mov    r8d,DWORD PTR [rdi+r8*4]
   825bf:	44 89 c7                                        	mov    edi,r8d
   825c2:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   825c8:	48 39 7c 24 20                                  	cmp    QWORD PTR [rsp+0x20],rdi
   825cd:	0f 86 04 26 00 00                               	jbe    84bd7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6427>
   825d3:	4c 8b 54 24 50                                  	mov    r10,QWORD PTR [rsp+0x50]
   825d8:	48 c1 e7 06                                     	shl    rdi,0x6
   825dc:	41 c1 e8 1f                                     	shr    r8d,0x1f
   825e0:	4d 89 c1                                        	mov    r9,r8
   825e3:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   825ea:	40 b7 01                                        	mov    dil,0x1
   825ed:	89 bc 24 c0 01 00 00                            	mov    DWORD PTR [rsp+0x1c0],edi
   825f4:	62 f1 fd 48 7f 44 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm0
   825fc:	eb 1c                                           	jmp    8261a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3e6a>
   825fe:	66 90                                           	xchg   ax,ax
   82600:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   82604:	62 f1 fd 48 7f 44 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm0
   8260c:	45 31 c9                                        	xor    r9d,r9d
   8260f:	c7 84 24 c0 01 00 00 00 00 00 00                	mov    DWORD PTR [rsp+0x1c0],0x0
   8261a:	62 f1 fd 48 6f 44 24 11                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x440]
   82622:	48 8b bc 24 00 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x100]
   8262a:	62 f1 fd 48 7f 44 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm0
   82632:	8b bf 84 02 00 00                               	mov    edi,DWORD PTR [rdi+0x284]
   82638:	4c 39 ef                                        	cmp    rdi,r13
   8263b:	0f 84 8f 00 00 00                               	je     826d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3f20>
   82641:	48 39 fe                                        	cmp    rsi,rdi
   82644:	0f 86 b9 25 00 00                               	jbe    84c03 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6453>
   8264a:	4c 8b 84 24 00 01 00 00                         	mov    r8,QWORD PTR [rsp+0x100]
   82652:	45 0f b6 80 a0 02 00 00                         	movzx  r8d,BYTE PTR [r8+0x2a0]
   8265a:	44 3a 04 3a                                     	cmp    r8b,BYTE PTR [rdx+rdi*1]
   8265e:	73 70                                           	jae    826d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3f20>
   82660:	48 39 f8                                        	cmp    rax,rdi
   82663:	0f 86 7c 25 00 00                               	jbe    84be5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6435>
   82669:	4c 03 04 f9                                     	add    r8,QWORD PTR [rcx+rdi*8]
   8266d:	4d 39 f8                                        	cmp    r8,r15
   82670:	0f 83 7b 25 00 00                               	jae    84bf1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6441>
   82676:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   8267b:	46 8b 04 87                                     	mov    r8d,DWORD PTR [rdi+r8*4]
   8267f:	44 89 c7                                        	mov    edi,r8d
   82682:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   82688:	48 39 7c 24 20                                  	cmp    QWORD PTR [rsp+0x20],rdi
   8268d:	0f 86 44 25 00 00                               	jbe    84bd7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6427>
   82693:	44 8b 94 24 c0 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x1c0]
   8269b:	48 c1 e7 06                                     	shl    rdi,0x6
   8269f:	41 c1 e8 1e                                     	shr    r8d,0x1e
   826a3:	41 80 e0 02                                     	and    r8b,0x2
   826a7:	45 08 c8                                        	or     r8b,r9b
   826aa:	45 89 c1                                        	mov    r9d,r8d
   826ad:	41 80 ca 02                                     	or     r10b,0x2
   826b1:	44 89 94 24 c0 01 00 00                         	mov    DWORD PTR [rsp+0x1c0],r10d
   826b9:	4c 8b 54 24 50                                  	mov    r10,QWORD PTR [rsp+0x50]
   826be:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   826c5:	eb 0d                                           	jmp    826d4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3f24>
   826c7:	66 0f 1f 84 00 00 00 00 00                      	nop    WORD PTR [rax+rax*1+0x0]
   826d0:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   826d4:	62 f1 fd 48 7f 44 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm0
   826dc:	62 f1 fd 48 6f 44 24 11                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x440]
   826e4:	48 8b bc 24 00 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x100]
   826ec:	62 f1 fd 48 7f 44 24 26                         	vmovdqa64 ZMMWORD PTR [rsp+0x980],zmm0
   826f4:	62 d1 fe 48 7f 06                               	vmovdqu64 ZMMWORD PTR [r14],zmm0
   826fa:	8b bf 88 02 00 00                               	mov    edi,DWORD PTR [rdi+0x288]
   82700:	4c 39 ef                                        	cmp    rdi,r13
   82703:	0f 84 87 00 00 00                               	je     82790 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3fe0>
   82709:	48 39 fe                                        	cmp    rsi,rdi
   8270c:	0f 86 f1 24 00 00                               	jbe    84c03 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6453>
   82712:	4c 8b 84 24 00 01 00 00                         	mov    r8,QWORD PTR [rsp+0x100]
   8271a:	45 0f b6 80 a0 02 00 00                         	movzx  r8d,BYTE PTR [r8+0x2a0]
   82722:	44 3a 04 3a                                     	cmp    r8b,BYTE PTR [rdx+rdi*1]
   82726:	73 68                                           	jae    82790 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3fe0>
   82728:	48 39 f8                                        	cmp    rax,rdi
   8272b:	0f 86 b4 24 00 00                               	jbe    84be5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6435>
   82731:	4c 03 04 f9                                     	add    r8,QWORD PTR [rcx+rdi*8]
   82735:	4d 39 f8                                        	cmp    r8,r15
   82738:	0f 83 b3 24 00 00                               	jae    84bf1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6441>
   8273e:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   82743:	46 8b 04 87                                     	mov    r8d,DWORD PTR [rdi+r8*4]
   82747:	44 89 c7                                        	mov    edi,r8d
   8274a:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   82750:	48 39 7c 24 20                                  	cmp    QWORD PTR [rsp+0x20],rdi
   82755:	0f 86 7c 24 00 00                               	jbe    84bd7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6427>
   8275b:	44 8b 94 24 c0 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x1c0]
   82763:	48 c1 e7 06                                     	shl    rdi,0x6
   82767:	41 c1 e8 1d                                     	shr    r8d,0x1d
   8276b:	41 80 e0 04                                     	and    r8b,0x4
   8276f:	45 08 c8                                        	or     r8b,r9b
   82772:	45 89 c1                                        	mov    r9d,r8d
   82775:	41 80 ca 04                                     	or     r10b,0x4
   82779:	44 89 94 24 c0 01 00 00                         	mov    DWORD PTR [rsp+0x1c0],r10d
   82781:	4c 8b 54 24 50                                  	mov    r10,QWORD PTR [rsp+0x50]
   82786:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   8278d:	eb 05                                           	jmp    82794 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3fe4>
   8278f:	90                                              	nop
   82790:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   82794:	62 f1 fd 48 7f 44 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm0
   8279c:	62 f1 fd 48 6f 44 24 11                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x440]
   827a4:	48 8b bc 24 00 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x100]
   827ac:	62 f1 fd 48 7f 44 24 26                         	vmovdqa64 ZMMWORD PTR [rsp+0x980],zmm0
   827b4:	62 d1 fe 48 7f 46 01                            	vmovdqu64 ZMMWORD PTR [r14+0x40],zmm0
   827bb:	8b bf 8c 02 00 00                               	mov    edi,DWORD PTR [rdi+0x28c]
   827c1:	4c 39 ef                                        	cmp    rdi,r13
   827c4:	0f 84 86 00 00 00                               	je     82850 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x40a0>
   827ca:	48 39 fe                                        	cmp    rsi,rdi
   827cd:	0f 86 30 24 00 00                               	jbe    84c03 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6453>
   827d3:	4c 8b 84 24 00 01 00 00                         	mov    r8,QWORD PTR [rsp+0x100]
   827db:	45 0f b6 80 a0 02 00 00                         	movzx  r8d,BYTE PTR [r8+0x2a0]
   827e3:	44 3a 04 3a                                     	cmp    r8b,BYTE PTR [rdx+rdi*1]
   827e7:	73 67                                           	jae    82850 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x40a0>
   827e9:	48 39 f8                                        	cmp    rax,rdi
   827ec:	0f 86 f3 23 00 00                               	jbe    84be5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6435>
   827f2:	4c 03 04 f9                                     	add    r8,QWORD PTR [rcx+rdi*8]
   827f6:	4d 39 f8                                        	cmp    r8,r15
   827f9:	0f 83 f2 23 00 00                               	jae    84bf1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6441>
   827ff:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   82804:	46 8b 04 87                                     	mov    r8d,DWORD PTR [rdi+r8*4]
   82808:	44 89 c7                                        	mov    edi,r8d
   8280b:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   82811:	48 39 7c 24 20                                  	cmp    QWORD PTR [rsp+0x20],rdi
   82816:	0f 86 bb 23 00 00                               	jbe    84bd7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6427>
   8281c:	44 8b 94 24 c0 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x1c0]
   82824:	48 c1 e7 06                                     	shl    rdi,0x6
   82828:	41 c1 e8 1c                                     	shr    r8d,0x1c
   8282c:	41 80 e0 08                                     	and    r8b,0x8
   82830:	45 08 c8                                        	or     r8b,r9b
   82833:	45 89 c1                                        	mov    r9d,r8d
   82836:	41 80 ca 08                                     	or     r10b,0x8
   8283a:	44 89 94 24 c0 01 00 00                         	mov    DWORD PTR [rsp+0x1c0],r10d
   82842:	4c 8b 54 24 50                                  	mov    r10,QWORD PTR [rsp+0x50]
   82847:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   8284e:	eb 04                                           	jmp    82854 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x40a4>
   82850:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   82854:	62 f1 fd 48 7f 44 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm0
   8285c:	62 f1 fd 48 6f 44 24 11                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x440]
   82864:	48 8b bc 24 00 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x100]
   8286c:	62 f1 fd 48 7f 44 24 26                         	vmovdqa64 ZMMWORD PTR [rsp+0x980],zmm0
   82874:	62 d1 fe 48 7f 46 02                            	vmovdqu64 ZMMWORD PTR [r14+0x80],zmm0
   8287b:	8b bf 90 02 00 00                               	mov    edi,DWORD PTR [rdi+0x290]
   82881:	4c 39 ef                                        	cmp    rdi,r13
   82884:	0f 84 86 00 00 00                               	je     82910 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x4160>
   8288a:	48 39 fe                                        	cmp    rsi,rdi
   8288d:	0f 86 70 23 00 00                               	jbe    84c03 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6453>
   82893:	4c 8b 84 24 00 01 00 00                         	mov    r8,QWORD PTR [rsp+0x100]
   8289b:	45 0f b6 80 a0 02 00 00                         	movzx  r8d,BYTE PTR [r8+0x2a0]
   828a3:	44 3a 04 3a                                     	cmp    r8b,BYTE PTR [rdx+rdi*1]
   828a7:	73 67                                           	jae    82910 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x4160>
   828a9:	48 39 f8                                        	cmp    rax,rdi
   828ac:	0f 86 33 23 00 00                               	jbe    84be5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6435>
   828b2:	4c 03 04 f9                                     	add    r8,QWORD PTR [rcx+rdi*8]
   828b6:	4d 39 f8                                        	cmp    r8,r15
   828b9:	0f 83 32 23 00 00                               	jae    84bf1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6441>
   828bf:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   828c4:	46 8b 04 87                                     	mov    r8d,DWORD PTR [rdi+r8*4]
   828c8:	44 89 c7                                        	mov    edi,r8d
   828cb:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   828d1:	48 39 7c 24 20                                  	cmp    QWORD PTR [rsp+0x20],rdi
   828d6:	0f 86 fb 22 00 00                               	jbe    84bd7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6427>
   828dc:	44 8b 94 24 c0 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x1c0]
   828e4:	48 c1 e7 06                                     	shl    rdi,0x6
   828e8:	41 c1 e8 1b                                     	shr    r8d,0x1b
   828ec:	41 80 e0 10                                     	and    r8b,0x10
   828f0:	45 08 c8                                        	or     r8b,r9b
   828f3:	45 89 c1                                        	mov    r9d,r8d
   828f6:	41 80 ca 10                                     	or     r10b,0x10
   828fa:	44 89 94 24 c0 01 00 00                         	mov    DWORD PTR [rsp+0x1c0],r10d
   82902:	4c 8b 54 24 50                                  	mov    r10,QWORD PTR [rsp+0x50]
   82907:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   8290e:	eb 04                                           	jmp    82914 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x4164>
   82910:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   82914:	62 f1 fd 48 7f 44 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm0
   8291c:	62 f1 fd 48 6f 44 24 11                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x440]
   82924:	48 8b bc 24 00 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x100]
   8292c:	62 f1 fd 48 7f 44 24 26                         	vmovdqa64 ZMMWORD PTR [rsp+0x980],zmm0
   82934:	62 d1 fe 48 7f 46 03                            	vmovdqu64 ZMMWORD PTR [r14+0xc0],zmm0
   8293b:	8b bf 94 02 00 00                               	mov    edi,DWORD PTR [rdi+0x294]
   82941:	4c 39 ef                                        	cmp    rdi,r13
   82944:	0f 84 86 00 00 00                               	je     829d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x4220>
   8294a:	48 39 fe                                        	cmp    rsi,rdi
   8294d:	0f 86 b0 22 00 00                               	jbe    84c03 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6453>
   82953:	4c 8b 84 24 00 01 00 00                         	mov    r8,QWORD PTR [rsp+0x100]
   8295b:	45 0f b6 80 a0 02 00 00                         	movzx  r8d,BYTE PTR [r8+0x2a0]
   82963:	44 3a 04 3a                                     	cmp    r8b,BYTE PTR [rdx+rdi*1]
   82967:	73 67                                           	jae    829d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x4220>
   82969:	48 39 f8                                        	cmp    rax,rdi
   8296c:	0f 86 73 22 00 00                               	jbe    84be5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6435>
   82972:	4c 03 04 f9                                     	add    r8,QWORD PTR [rcx+rdi*8]
   82976:	4d 39 f8                                        	cmp    r8,r15
   82979:	0f 83 72 22 00 00                               	jae    84bf1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6441>
   8297f:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   82984:	46 8b 04 87                                     	mov    r8d,DWORD PTR [rdi+r8*4]
   82988:	44 89 c7                                        	mov    edi,r8d
   8298b:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   82991:	48 39 7c 24 20                                  	cmp    QWORD PTR [rsp+0x20],rdi
   82996:	0f 86 3b 22 00 00                               	jbe    84bd7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6427>
   8299c:	44 8b 94 24 c0 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x1c0]
   829a4:	48 c1 e7 06                                     	shl    rdi,0x6
   829a8:	41 c1 e8 1a                                     	shr    r8d,0x1a
   829ac:	41 80 e0 20                                     	and    r8b,0x20
   829b0:	45 08 c8                                        	or     r8b,r9b
   829b3:	45 89 c1                                        	mov    r9d,r8d
   829b6:	41 80 ca 20                                     	or     r10b,0x20
   829ba:	44 89 94 24 c0 01 00 00                         	mov    DWORD PTR [rsp+0x1c0],r10d
   829c2:	4c 8b 54 24 50                                  	mov    r10,QWORD PTR [rsp+0x50]
   829c7:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   829ce:	eb 04                                           	jmp    829d4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x4224>
   829d0:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   829d4:	62 f1 fd 48 7f 44 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm0
   829dc:	62 f1 fd 48 6f 44 24 11                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x440]
   829e4:	48 8b bc 24 00 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x100]
   829ec:	62 f1 fd 48 7f 44 24 26                         	vmovdqa64 ZMMWORD PTR [rsp+0x980],zmm0
   829f4:	62 d1 fe 48 7f 46 04                            	vmovdqu64 ZMMWORD PTR [r14+0x100],zmm0
   829fb:	8b bf 98 02 00 00                               	mov    edi,DWORD PTR [rdi+0x298]
   82a01:	4c 39 ef                                        	cmp    rdi,r13
   82a04:	0f 84 86 00 00 00                               	je     82a90 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x42e0>
   82a0a:	48 39 fe                                        	cmp    rsi,rdi
   82a0d:	0f 86 f0 21 00 00                               	jbe    84c03 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6453>
   82a13:	4c 8b 84 24 00 01 00 00                         	mov    r8,QWORD PTR [rsp+0x100]
   82a1b:	45 0f b6 80 a0 02 00 00                         	movzx  r8d,BYTE PTR [r8+0x2a0]
   82a23:	44 3a 04 3a                                     	cmp    r8b,BYTE PTR [rdx+rdi*1]
   82a27:	73 67                                           	jae    82a90 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x42e0>
   82a29:	48 39 f8                                        	cmp    rax,rdi
   82a2c:	0f 86 b3 21 00 00                               	jbe    84be5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6435>
   82a32:	4c 03 04 f9                                     	add    r8,QWORD PTR [rcx+rdi*8]
   82a36:	4d 39 f8                                        	cmp    r8,r15
   82a39:	0f 83 b2 21 00 00                               	jae    84bf1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6441>
   82a3f:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   82a44:	46 8b 04 87                                     	mov    r8d,DWORD PTR [rdi+r8*4]
   82a48:	44 89 c7                                        	mov    edi,r8d
   82a4b:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   82a51:	48 39 7c 24 20                                  	cmp    QWORD PTR [rsp+0x20],rdi
   82a56:	0f 86 7b 21 00 00                               	jbe    84bd7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6427>
   82a5c:	44 8b 94 24 c0 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x1c0]
   82a64:	48 c1 e7 06                                     	shl    rdi,0x6
   82a68:	41 c1 e8 19                                     	shr    r8d,0x19
   82a6c:	41 80 e0 40                                     	and    r8b,0x40
   82a70:	45 08 c8                                        	or     r8b,r9b
   82a73:	45 89 c1                                        	mov    r9d,r8d
   82a76:	41 80 ca 40                                     	or     r10b,0x40
   82a7a:	44 89 94 24 c0 01 00 00                         	mov    DWORD PTR [rsp+0x1c0],r10d
   82a82:	4c 8b 54 24 50                                  	mov    r10,QWORD PTR [rsp+0x50]
   82a87:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   82a8e:	eb 04                                           	jmp    82a94 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x42e4>
   82a90:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   82a94:	62 f1 fd 48 7f 44 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm0
   82a9c:	62 f1 fd 48 6f 44 24 11                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x440]
   82aa4:	4c 8b 84 24 00 01 00 00                         	mov    r8,QWORD PTR [rsp+0x100]
   82aac:	62 f1 fd 48 7f 44 24 26                         	vmovdqa64 ZMMWORD PTR [rsp+0x980],zmm0
   82ab4:	62 d1 fe 48 7f 46 05                            	vmovdqu64 ZMMWORD PTR [r14+0x140],zmm0
   82abb:	41 8b b8 9c 02 00 00                            	mov    edi,DWORD PTR [r8+0x29c]
   82ac2:	4c 39 ef                                        	cmp    rdi,r13
   82ac5:	0f 84 85 00 00 00                               	je     82b50 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x43a0>
   82acb:	48 39 fe                                        	cmp    rsi,rdi
   82ace:	0f 86 2f 21 00 00                               	jbe    84c03 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6453>
   82ad4:	48 8b b4 24 00 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x100]
   82adc:	0f b6 b6 a0 02 00 00                            	movzx  esi,BYTE PTR [rsi+0x2a0]
   82ae3:	40 3a 34 3a                                     	cmp    sil,BYTE PTR [rdx+rdi*1]
   82ae7:	73 6f                                           	jae    82b58 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x43a8>
   82ae9:	48 39 f8                                        	cmp    rax,rdi
   82aec:	0f 86 f3 20 00 00                               	jbe    84be5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6435>
   82af2:	40 0f b6 c6                                     	movzx  eax,sil
   82af6:	48 03 04 f9                                     	add    rax,QWORD PTR [rcx+rdi*8]
   82afa:	4c 39 f8                                        	cmp    rax,r15
   82afd:	0f 83 f8 21 00 00                               	jae    84cfb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x654b>
   82b03:	48 8b 4c 24 30                                  	mov    rcx,QWORD PTR [rsp+0x30]
   82b08:	8b 04 81                                        	mov    eax,DWORD PTR [rcx+rax*4]
   82b0b:	89 c7                                           	mov    edi,eax
   82b0d:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   82b13:	48 39 7c 24 20                                  	cmp    QWORD PTR [rsp+0x20],rdi
   82b18:	0f 86 b9 20 00 00                               	jbe    84bd7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6427>
   82b1e:	48 8b 54 24 50                                  	mov    rdx,QWORD PTR [rsp+0x50]
   82b23:	48 c1 e7 06                                     	shl    rdi,0x6
   82b27:	8b 8c 24 c0 01 00 00                            	mov    ecx,DWORD PTR [rsp+0x1c0]
   82b2e:	c1 e8 18                                        	shr    eax,0x18
   82b31:	24 80                                           	and    al,0x80
   82b33:	44 08 c8                                        	or     al,r9b
   82b36:	41 89 c1                                        	mov    r9d,eax
   82b39:	62 f1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [rdx+rdi*1]
   82b40:	80 c9 80                                        	or     cl,0x80
   82b43:	89 8c 24 c0 01 00 00                            	mov    DWORD PTR [rsp+0x1c0],ecx
   82b4a:	eb 10                                           	jmp    82b5c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x43ac>
   82b4c:	0f 1f 40 00                                     	nop    DWORD PTR [rax+0x0]
   82b50:	41 0f b6 b0 a0 02 00 00                         	movzx  esi,BYTE PTR [r8+0x2a0]
   82b58:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   82b5c:	62 f1 fd 48 7f 44 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm0
   82b64:	62 f1 7c 48 28 44 24 11                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x440]
   82b6c:	40 fe c6                                        	inc    sil
   82b6f:	62 71 fd 48 6f 1d c7 50 f8 ff                   	vmovdqa64 zmm11,ZMMWORD PTR [rip+0xfffffffffff850c7]        # 7c40 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4c0>
   82b79:	62 71 fd 48 6f 25 fd 50 f8 ff                   	vmovdqa64 zmm12,ZMMWORD PTR [rip+0xfffffffffff850fd]        # 7c80 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x500>
   82b83:	62 e2 fd 48 59 0d 73 48 f8 ff                   	vpbroadcastq zmm17,QWORD PTR [rip+0xfffffffffff84873]        # 7400 <GCC_except_table746+0x8c>
   82b8d:	62 e1 fd 28 6f 05 49 54 f8 ff                   	vmovdqa64 ymm16,YMMWORD PTR [rip+0xfffffffffff85449]        # 7fe0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x860>
   82b97:	62 e2 fd 48 59 15 97 48 f8 ff                   	vpbroadcastq zmm18,QWORD PTR [rip+0xfffffffffff84897]        # 7438 <GCC_except_table746+0xc4>
   82ba1:	4c 89 8c 24 c0 06 00 00                         	mov    QWORD PTR [rsp+0x6c0],r9
   82ba9:	62 d1 7c 48 11 46 06                            	vmovups ZMMWORD PTR [r14+0x180],zmm0
   82bb0:	62 f1 7c 48 29 44 24 26                         	vmovaps ZMMWORD PTR [rsp+0x980],zmm0
   82bb8:	4c 8b b4 24 00 01 00 00                         	mov    r14,QWORD PTR [rsp+0x100]
   82bc0:	62 f1 7c 48 28 4c 24 0a                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x280]
   82bc8:	62 f1 7c 48 28 54 24 0b                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x2c0]
   82bd0:	62 f1 7c 48 28 44 24 09                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x240]
   82bd8:	62 f1 7c 48 28 5c 24 0c                         	vmovaps zmm3,ZMMWORD PTR [rsp+0x300]
   82be0:	62 f1 7c 48 29 4c 24 12                         	vmovaps ZMMWORD PTR [rsp+0x480],zmm1
   82be8:	62 f1 7c 48 29 54 24 13                         	vmovaps ZMMWORD PTR [rsp+0x4c0],zmm2
   82bf0:	62 f1 7c 48 28 54 24 0d                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x340]
   82bf8:	62 f1 7c 48 28 4c 24 0e                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x380]
   82c00:	62 f1 7c 48 29 44 24 11                         	vmovaps ZMMWORD PTR [rsp+0x440],zmm0
   82c08:	62 f1 7c 48 29 5c 24 14                         	vmovaps ZMMWORD PTR [rsp+0x500],zmm3
   82c10:	62 f1 7c 48 29 54 24 15                         	vmovaps ZMMWORD PTR [rsp+0x540],zmm2
   82c18:	62 f1 7c 48 29 4c 24 16                         	vmovaps ZMMWORD PTR [rsp+0x580],zmm1
   82c20:	62 f1 7c 48 28 54 24 0f                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x3c0]
   82c28:	62 f1 7c 48 28 4c 24 10                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x400]
   82c30:	62 f1 7c 48 29 54 24 17                         	vmovaps ZMMWORD PTR [rsp+0x5c0],zmm2
   82c38:	62 f1 7c 48 29 4c 24 18                         	vmovaps ZMMWORD PTR [rsp+0x600],zmm1
   82c40:	41 88 b6 a0 02 00 00                            	mov    BYTE PTR [r14+0x2a0],sil
   82c47:	62 f1 fd 48 6f 44 24 11                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x440]
   82c4f:	62 f1 fd 48 6f 4c 24 13                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x4c0]
   82c57:	62 f1 fd 48 6f 54 24 15                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0x540]
   82c5f:	62 f1 fd 48 6f 5c 24 17                         	vmovdqa64 zmm3,ZMMWORD PTR [rsp+0x5c0]
   82c67:	62 f1 fe 48 6f b4 24 e0 04 00 00                	vmovdqu64 zmm6,ZMMWORD PTR [rsp+0x4e0]
   82c72:	62 f1 fe 48 6f bc 24 60 05 00 00                	vmovdqu64 zmm7,ZMMWORD PTR [rsp+0x560]
   82c7d:	62 71 fe 48 6f 84 24 e0 05 00 00                	vmovdqu64 zmm8,ZMMWORD PTR [rsp+0x5e0]
   82c88:	62 51 fd 48 6f 6e 03                            	vmovdqa64 zmm13,ZMMWORD PTR [r14+0xc0]
   82c8f:	62 51 fd 48 6f 76 04                            	vmovdqa64 zmm14,ZMMWORD PTR [r14+0x100]
   82c96:	62 f3 fd 48 3a 44 24 24 01                      	vinserti64x4 zmm0,zmm0,YMMWORD PTR [rsp+0x480],0x1
   82c9f:	62 f3 f5 48 3a 4c 24 28 01                      	vinserti64x4 zmm1,zmm1,YMMWORD PTR [rsp+0x500],0x1
   82ca8:	62 f3 ed 48 3a 54 24 2c 01                      	vinserti64x4 zmm2,zmm2,YMMWORD PTR [rsp+0x580],0x1
   82cb1:	62 f3 e5 48 3a 5c 24 30 01                      	vinserti64x4 zmm3,zmm3,YMMWORD PTR [rsp+0x600],0x1
   82cba:	62 f3 cd 48 3a 74 24 29 01                      	vinserti64x4 zmm6,zmm6,YMMWORD PTR [rsp+0x520],0x1
   82cc3:	62 f3 c5 48 3a 7c 24 2d 01                      	vinserti64x4 zmm7,zmm7,YMMWORD PTR [rsp+0x5a0],0x1
   82ccc:	62 73 bd 48 3a 44 24 31 01                      	vinserti64x4 zmm8,zmm8,YMMWORD PTR [rsp+0x620],0x1
   82cd5:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   82cdb:	62 f1 fd 48 6d e9                               	vpunpckhqdq zmm5,zmm0,zmm1
   82ce1:	62 f1 ed 48 6c c3                               	vpunpcklqdq zmm0,zmm2,zmm3
   82ce7:	62 f1 ed 48 6d cb                               	vpunpckhqdq zmm1,zmm2,zmm3
   82ced:	62 f1 fd 48 6f d4                               	vmovdqa64 zmm2,zmm4
   82cf3:	62 f1 fd 48 6f dd                               	vmovdqa64 zmm3,zmm5
   82cf9:	62 f2 a5 48 7e d0                               	vpermt2q zmm2,zmm11,zmm0
   82cff:	62 f2 9d 48 7e e0                               	vpermt2q zmm4,zmm12,zmm0
   82d05:	62 f2 a5 48 7e d9                               	vpermt2q zmm3,zmm11,zmm1
   82d0b:	62 f2 9d 48 7e e9                               	vpermt2q zmm5,zmm12,zmm1
   82d11:	62 f3 e5 48 71 ca 0c                            	vpshldq zmm1,zmm3,zmm2,0xc
   82d18:	62 b1 ed 48 db c1                               	vpandq zmm0,zmm2,zmm17
   82d1e:	62 f3 dd 48 71 d3 18                            	vpshldq zmm2,zmm4,zmm3,0x18
   82d25:	62 f3 d5 48 71 e4 24                            	vpshldq zmm4,zmm5,zmm4,0x24
   82d2c:	62 b1 dd 48 db d9                               	vpandq zmm3,zmm4,zmm17
   82d32:	62 f1 dd 48 73 d5 10                            	vpsrlq zmm4,zmm5,0x10
   82d39:	62 f1 fe 48 6f ac 24 60 04 00 00                	vmovdqu64 zmm5,ZMMWORD PTR [rsp+0x460]
   82d44:	62 b1 f5 48 db c9                               	vpandq zmm1,zmm1,zmm17
   82d4a:	62 b1 ed 48 db d1                               	vpandq zmm2,zmm2,zmm17
   82d50:	62 f3 d5 48 3a 6c 24 25 01                      	vinserti64x4 zmm5,zmm5,YMMWORD PTR [rsp+0x4a0],0x1
   82d59:	62 71 d5 48 6c ce                               	vpunpcklqdq zmm9,zmm5,zmm6
   82d5f:	62 f1 d5 48 6d ee                               	vpunpckhqdq zmm5,zmm5,zmm6
   82d65:	62 d1 c5 48 6c f0                               	vpunpcklqdq zmm6,zmm7,zmm8
   82d6b:	62 d1 c5 48 6d f8                               	vpunpckhqdq zmm7,zmm7,zmm8
   82d71:	62 51 fd 48 6f c1                               	vmovdqa64 zmm8,zmm9
   82d77:	62 71 fd 48 6f d5                               	vmovdqa64 zmm10,zmm5
   82d7d:	62 72 a5 48 7e c6                               	vpermt2q zmm8,zmm11,zmm6
   82d83:	62 72 a5 48 7e d7                               	vpermt2q zmm10,zmm11,zmm7
   82d89:	62 f2 9d 48 7e ef                               	vpermt2q zmm5,zmm12,zmm7
   82d8f:	62 72 9d 48 7e ce                               	vpermt2q zmm9,zmm12,zmm6
   82d95:	62 51 fd 48 6f 5e 01                            	vmovdqa64 zmm11,ZMMWORD PTR [r14+0x40]
   82d9c:	62 51 fd 48 6f 66 02                            	vmovdqa64 zmm12,ZMMWORD PTR [r14+0x80]
   82da3:	62 d3 ad 48 71 f8 0c                            	vpshldq zmm7,zmm10,zmm8,0xc
   82daa:	62 d3 d5 48 71 f1 24                            	vpshldq zmm6,zmm5,zmm9,0x24
   82db1:	62 53 b5 48 71 d2 18                            	vpshldq zmm10,zmm9,zmm10,0x18
   82db8:	62 51 fd 48 6f 0e                               	vmovdqa64 zmm9,ZMMWORD PTR [r14]
   82dbe:	62 f1 d5 48 73 d5 10                            	vpsrlq zmm5,zmm5,0x10
   82dc5:	62 d2 fd 48 29 c9                               	vpcmpeqq k1,zmm0,zmm9
   82dcb:	62 51 fd 48 fb c9                               	vpsubq zmm9,zmm0,zmm9
   82dd1:	62 f2 a5 49 29 c9                               	vpcmpeqq k1{k1},zmm11,zmm1
   82dd7:	62 31 b5 48 d4 ca                               	vpaddq zmm9,zmm9,zmm18
   82ddd:	62 f2 9d 49 29 ca                               	vpcmpeqq k1{k1},zmm12,zmm2
   82de3:	62 d1 85 48 72 e1 34                            	vpsraq zmm15,zmm9,0x34
   82dea:	62 a1 b5 48 db d9                               	vpandq zmm19,zmm9,zmm17
   82df0:	62 f2 95 49 29 cb                               	vpcmpeqq k1{k1},zmm13,zmm3
   82df6:	62 f2 8d 49 29 c4                               	vpcmpeqq k0{k1},zmm14,zmm4
   82dfc:	c4 c1 7b 92 c9                                  	kmovd  k1,r9d
   82e01:	c5 fb 93 c0                                     	kmovd  eax,k0
   82e05:	41 0a 86 a1 02 00 00                            	or     al,BYTE PTR [r14+0x2a1]
   82e0c:	62 e1 fe 28 7f 44 24 12                         	vmovdqu64 YMMWORD PTR [rsp+0x240],ymm16
   82e14:	4c 89 a4 24 60 02 00 00                         	mov    QWORD PTR [rsp+0x260],r12
   82e1c:	62 71 85 58 d4 7c 24 49                         	vpaddq zmm15,zmm15,QWORD BCST [rsp+0x248]
   82e24:	41 89 c5                                        	mov    r13d,eax
   82e27:	41 f6 d5                                        	not    r13b
   82e2a:	62 71 85 48 d4 f9                               	vpaddq zmm15,zmm15,zmm1
   82e30:	62 51 85 48 fb db                               	vpsubq zmm11,zmm15,zmm11
   82e36:	62 d1 85 48 72 e3 34                            	vpsraq zmm15,zmm11,0x34
   82e3d:	62 71 85 58 d4 7c 24 4a                         	vpaddq zmm15,zmm15,QWORD BCST [rsp+0x250]
   82e45:	62 a1 a5 48 db e1                               	vpandq zmm20,zmm11,zmm17
   82e4b:	62 71 85 48 d4 fa                               	vpaddq zmm15,zmm15,zmm2
   82e51:	62 51 85 48 fb e4                               	vpsubq zmm12,zmm15,zmm12
   82e57:	62 d1 85 48 72 e4 34                            	vpsraq zmm15,zmm12,0x34
   82e5e:	62 71 85 58 d4 7c 24 4b                         	vpaddq zmm15,zmm15,QWORD BCST [rsp+0x258]
   82e66:	62 a1 9d 48 db e9                               	vpandq zmm21,zmm12,zmm17
   82e6c:	62 72 fe 48 38 e1                               	vpmovm2q zmm12,k1
   82e72:	62 71 85 48 d4 fb                               	vpaddq zmm15,zmm15,zmm3
   82e78:	62 51 85 48 fb ed                               	vpsubq zmm13,zmm15,zmm13
   82e7e:	62 d1 85 48 72 e5 34                            	vpsraq zmm15,zmm13,0x34
   82e85:	62 71 85 58 d4 7c 24 4c                         	vpaddq zmm15,zmm15,QWORD BCST [rsp+0x260]
   82e8d:	62 72 ed 51 64 1d 71 46 f8 ff                   	vpblendmq zmm11{k1},zmm18,QWORD BCST [rip+0xfffffffffff84671]        # 7508 <GCC_except_table746+0x194>
   82e97:	62 a1 95 48 db f1                               	vpandq zmm22,zmm13,zmm17
   82e9d:	62 71 85 48 d4 cc                               	vpaddq zmm9,zmm15,zmm4
   82ea3:	62 51 b5 48 fb ce                               	vpsubq zmm9,zmm9,zmm14
   82ea9:	62 a1 b5 48 db f9                               	vpandq zmm23,zmm9,zmm17
   82eaf:	62 31 fd c9 6f c9                               	vmovdqa64 zmm9{k1}{z},zmm17
   82eb5:	62 33 b5 48 25 c1 6c                            	vpternlogq zmm8,zmm9,zmm17,0x6c
   82ebc:	62 b3 b5 48 25 f9 6c                            	vpternlogq zmm7,zmm9,zmm17,0x6c
   82ec3:	62 33 b5 48 25 d1 6c                            	vpternlogq zmm10,zmm9,zmm17,0x6c
   82eca:	62 b3 b5 48 25 f1 6c                            	vpternlogq zmm6,zmm9,zmm17,0x6c
   82ed1:	62 d1 d5 48 ef e9                               	vpxorq zmm5,zmm5,zmm9
   82ed7:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   82edc:	62 51 bd 48 fb c4                               	vpsubq zmm8,zmm8,zmm12
   82ee2:	62 51 bd 48 fb 46 05                            	vpsubq zmm8,zmm8,ZMMWORD PTR [r14+0x140]
   82ee9:	62 72 fd 48 59 25 65 46 f8 ff                   	vpbroadcastq zmm12,QWORD PTR [rip+0xfffffffffff84665]        # 7558 <GCC_except_table746+0x1e4>
   82ef3:	62 51 bd 48 d4 c3                               	vpaddq zmm8,zmm8,zmm11
   82ef9:	62 71 fd 48 7f 44 24 41                         	vmovdqa64 ZMMWORD PTR [rsp+0x1040],zmm8
   82f01:	62 d1 bd 48 72 e0 34                            	vpsraq zmm8,zmm8,0x34
   82f08:	62 d1 c5 48 d4 f8                               	vpaddq zmm7,zmm7,zmm8
   82f0e:	62 72 9d 59 64 1d 38 46 f8 ff                   	vpblendmq zmm11{k1},zmm12,QWORD BCST [rip+0xfffffffffff84638]        # 7550 <GCC_except_table746+0x1dc>
   82f18:	62 d1 c5 48 fb 7e 06                            	vpsubq zmm7,zmm7,ZMMWORD PTR [r14+0x180]
   82f1f:	62 72 fd 48 59 05 17 45 f8 ff                   	vpbroadcastq zmm8,QWORD PTR [rip+0xfffffffffff84517]        # 7440 <GCC_except_table746+0xcc>
   82f29:	62 d1 c5 48 d4 fb                               	vpaddq zmm7,zmm7,zmm11
   82f2f:	62 f1 fd 48 7f 7c 24 40                         	vmovdqa64 ZMMWORD PTR [rsp+0x1000],zmm7
   82f37:	62 f1 c5 48 72 e7 34                            	vpsraq zmm7,zmm7,0x34
   82f3e:	62 72 bd 59 64 05 e8 45 f8 ff                   	vpblendmq zmm8{k1},zmm8,QWORD BCST [rip+0xfffffffffff845e8]        # 7530 <GCC_except_table746+0x1bc>
   82f48:	62 f1 ad 48 d4 ff                               	vpaddq zmm7,zmm10,zmm7
   82f4e:	62 d1 c5 48 fb 7e 07                            	vpsubq zmm7,zmm7,ZMMWORD PTR [r14+0x1c0]
   82f55:	c5 f8 91 4c 24 6e                               	kmovw  WORD PTR [rsp+0x6e],k1
   82f5b:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   82f60:	62 d1 c5 48 d4 f8                               	vpaddq zmm7,zmm7,zmm8
   82f66:	62 72 fd 48 59 05 20 45 f8 ff                   	vpbroadcastq zmm8,QWORD PTR [rip+0xfffffffffff84520]        # 7490 <GCC_except_table746+0x11c>
   82f70:	62 f1 fd 48 7f 7c 24 3f                         	vmovdqa64 ZMMWORD PTR [rsp+0xfc0],zmm7
   82f78:	62 f1 c5 48 72 e7 34                            	vpsraq zmm7,zmm7,0x34
   82f7f:	62 f1 cd 48 d4 f7                               	vpaddq zmm6,zmm6,zmm7
   82f85:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   82f89:	62 72 bd 59 64 05 2d 45 f8 ff                   	vpblendmq zmm8{k1},zmm8,QWORD BCST [rip+0xfffffffffff8452d]        # 74c0 <GCC_except_table746+0x14c>
   82f93:	62 d1 cd 48 fb 76 08                            	vpsubq zmm6,zmm6,ZMMWORD PTR [r14+0x200]
   82f9a:	44 22 ac 24 c0 01 00 00                         	and    r13b,BYTE PTR [rsp+0x1c0]
   82fa2:	89 84 24 80 06 00 00                            	mov    DWORD PTR [rsp+0x680],eax
   82fa9:	62 61 fd 48 6f 44 24 20                         	vmovdqa64 zmm24,ZMMWORD PTR [rsp+0x800]
   82fb1:	62 71 fd 48 6f 6c 24 23                         	vmovdqa64 zmm13,ZMMWORD PTR [rsp+0x8c0]
   82fb9:	62 71 fd 48 6f 74 24 22                         	vmovdqa64 zmm14,ZMMWORD PTR [rsp+0x880]
   82fc1:	62 71 fd 48 6f 7c 24 21                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x840]
   82fc9:	62 71 fd 48 6f 64 24 24                         	vmovdqa64 zmm12,ZMMWORD PTR [rsp+0x900]
   82fd1:	4c 8b bc 24 f8 00 00 00                         	mov    r15,QWORD PTR [rsp+0xf8]
   82fd9:	44 89 e8                                        	mov    eax,r13d
   82fdc:	f6 d0                                           	not    al
   82fde:	c5 fb 92 c8                                     	kmovd  k1,eax
   82fe2:	62 d1 cd 48 d4 f0                               	vpaddq zmm6,zmm6,zmm8
   82fe8:	62 e2 fd 49 59 1d 8e 44 f8 ff                   	vpbroadcastq zmm19{k1},QWORD PTR [rip+0xfffffffffff8448e]        # 7480 <GCC_except_table746+0x10c>
   82ff2:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   82ff7:	62 e1 fd 49 6f 64 24 2e                         	vmovdqa64 zmm20{k1},ZMMWORD PTR [rsp+0xb80]
   82fff:	62 e1 fd 49 6f 6c 24 2d                         	vmovdqa64 zmm21{k1},ZMMWORD PTR [rsp+0xb40]
   83007:	62 e1 fd 49 6f 74 24 2c                         	vmovdqa64 zmm22{k1},ZMMWORD PTR [rsp+0xb00]
   8300f:	62 e1 fd 49 6f 7c 24 2b                         	vmovdqa64 zmm23{k1},ZMMWORD PTR [rsp+0xac0]
   83017:	62 f1 fd 48 7f 74 24 3e                         	vmovdqa64 ZMMWORD PTR [rsp+0xf80],zmm6
   8301f:	62 f1 cd 48 72 e6 34                            	vpsraq zmm6,zmm6,0x34
   83026:	62 f1 d5 48 d4 ee                               	vpaddq zmm5,zmm5,zmm6
   8302c:	62 d1 d5 48 fb 6e 09                            	vpsubq zmm5,zmm5,ZMMWORD PTR [r14+0x240]
   83033:	62 e1 fe 28 7f 44 24 12                         	vmovdqu64 YMMWORD PTR [rsp+0x240],ymm16
   8303b:	4c 89 a4 24 60 02 00 00                         	mov    QWORD PTR [rsp+0x260],r12
   83043:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   83047:	62 51 f5 48 d4 5e 01                            	vpaddq zmm11,zmm1,ZMMWORD PTR [r14+0x40]
   8304e:	62 d1 ed 48 d4 4e 02                            	vpaddq zmm1,zmm2,ZMMWORD PTR [r14+0x80]
   83055:	62 d1 e5 48 d4 56 03                            	vpaddq zmm2,zmm3,ZMMWORD PTR [r14+0xc0]
   8305c:	62 d1 fd 48 d4 06                               	vpaddq zmm0,zmm0,ZMMWORD PTR [r14]
   83062:	62 b2 95 48 b5 f3                               	vpmadd52huq zmm6,zmm13,zmm19
   83068:	62 32 8d 48 b5 c3                               	vpmadd52huq zmm8,zmm14,zmm19
   8306e:	62 b2 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm19
   83074:	62 32 bd 40 b5 cb                               	vpmadd52huq zmm9,zmm24,zmm19
   8307a:	62 e1 fd 48 7f 5c 24 31                         	vmovdqa64 ZMMWORD PTR [rsp+0xc40],zmm19
   83082:	62 e1 fd 48 7f 64 24 25                         	vmovdqa64 ZMMWORD PTR [rsp+0x940],zmm20
   8308a:	62 e1 fd 48 7f 6c 24 30                         	vmovdqa64 ZMMWORD PTR [rsp+0xc00],zmm21
   83092:	62 e1 fd 48 7f 74 24 2f                         	vmovdqa64 ZMMWORD PTR [rsp+0xbc0],zmm22
   8309a:	62 e1 fd 48 7f 7c 24 4b                         	vmovdqa64 ZMMWORD PTR [rsp+0x12c0],zmm23
   830a2:	62 f1 fd 48 7f 6c 24 3d                         	vmovdqa64 ZMMWORD PTR [rsp+0xf40],zmm5
   830aa:	62 f2 fd 48 19 6c 24 49                         	vbroadcastsd zmm5,QWORD PTR [rsp+0x248]
   830b2:	62 f1 fd 48 7f 4c 24 47                         	vmovdqa64 ZMMWORD PTR [rsp+0x11c0],zmm1
   830ba:	62 d1 dd 48 d4 4e 04                            	vpaddq zmm1,zmm4,ZMMWORD PTR [r14+0x100]
   830c1:	62 71 fd 48 7f 5c 24 46                         	vmovdqa64 ZMMWORD PTR [rsp+0x1180],zmm11
   830c9:	62 72 fd 48 59 1d 65 44 f8 ff                   	vpbroadcastq zmm11,QWORD PTR [rip+0xfffffffffff84465]        # 7538 <GCC_except_table746+0x1c4>
   830d3:	62 f1 fd 48 7f 54 24 48                         	vmovdqa64 ZMMWORD PTR [rsp+0x1200],zmm2
   830db:	62 f1 fd 48 7f 44 24 4a                         	vmovdqa64 ZMMWORD PTR [rsp+0x1280],zmm0
   830e3:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   830e7:	62 b2 9d 48 b5 e3                               	vpmadd52huq zmm4,zmm12,zmm19
   830ed:	62 b2 9d 48 b4 f3                               	vpmadd52luq zmm6,zmm12,zmm19
   830f3:	62 32 95 48 b4 c3                               	vpmadd52luq zmm8,zmm13,zmm19
   830f9:	62 b2 8d 48 b4 fb                               	vpmadd52luq zmm7,zmm14,zmm19
   830ff:	62 32 85 48 b4 cb                               	vpmadd52luq zmm9,zmm15,zmm19
   83105:	62 f1 7c 48 29 6c 24 42                         	vmovaps ZMMWORD PTR [rsp+0x1080],zmm5
   8310d:	62 f2 fd 48 19 6c 24 4a                         	vbroadcastsd zmm5,QWORD PTR [rsp+0x250]
   83115:	62 f1 fd 48 7f 4c 24 49                         	vmovdqa64 ZMMWORD PTR [rsp+0x1240],zmm1
   8311d:	62 f1 7c 48 29 6c 24 43                         	vmovaps ZMMWORD PTR [rsp+0x10c0],zmm5
   83125:	62 f2 fd 48 19 6c 24 4b                         	vbroadcastsd zmm5,QWORD PTR [rsp+0x258]
   8312d:	62 f1 7c 48 29 6c 24 44                         	vmovaps ZMMWORD PTR [rsp+0x1100],zmm5
   83135:	62 f2 fd 48 59 6c 24 4c                         	vpbroadcastq zmm5,QWORD PTR [rsp+0x260]
   8313d:	62 e1 fe 28 7f 44 24 12                         	vmovdqu64 YMMWORD PTR [rsp+0x240],ymm16
   83145:	4c 89 a4 24 60 02 00 00                         	mov    QWORD PTR [rsp+0x260],r12
   8314d:	62 f2 fd 48 59 4c 24 4b                         	vpbroadcastq zmm1,QWORD PTR [rsp+0x258]
   83155:	62 f2 fd 48 59 54 24 4a                         	vpbroadcastq zmm2,QWORD PTR [rsp+0x250]
   8315d:	62 f2 fd 48 59 5c 24 49                         	vpbroadcastq zmm3,QWORD PTR [rsp+0x248]
   83165:	62 f2 fd 48 59 44 24 4c                         	vpbroadcastq zmm0,QWORD PTR [rsp+0x260]
   8316d:	62 f1 fd 48 7f 6c 24 45                         	vmovdqa64 ZMMWORD PTR [rsp+0x1140],zmm5
   83175:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   83179:	62 b2 bd 40 b4 eb                               	vpmadd52luq zmm5,zmm24,zmm19
   8317f:	62 e2 fd 48 59 1d 7f 42 f8 ff                   	vpbroadcastq zmm19,QWORD PTR [rip+0xfffffffffff8427f]        # 7408 <GCC_except_table746+0x94>
   83189:	62 52 d5 48 b4 d3                               	vpmadd52luq zmm10,zmm5,zmm11
   8318f:	62 b1 d5 48 d4 e9                               	vpaddq zmm5,zmm5,zmm17
   83195:	62 f1 d5 48 73 d5 34                            	vpsrlq zmm5,zmm5,0x34
   8319c:	62 f2 ad 48 b5 f1                               	vpmadd52huq zmm6,zmm10,zmm1
   831a2:	62 72 ad 48 b5 c2                               	vpmadd52huq zmm8,zmm10,zmm2
   831a8:	62 f2 ad 48 b5 fb                               	vpmadd52huq zmm7,zmm10,zmm3
   831ae:	62 b2 ad 48 b5 ea                               	vpmadd52huq zmm5,zmm10,zmm18
   831b4:	62 72 ad 48 b4 cb                               	vpmadd52luq zmm9,zmm10,zmm3
   831ba:	62 f2 ad 48 b5 e0                               	vpmadd52huq zmm4,zmm10,zmm0
   831c0:	62 f2 ad 48 b4 f0                               	vpmadd52luq zmm6,zmm10,zmm0
   831c6:	62 72 ad 48 b4 c1                               	vpmadd52luq zmm8,zmm10,zmm1
   831cc:	62 f2 ad 48 b4 fa                               	vpmadd52luq zmm7,zmm10,zmm2
   831d2:	62 71 b5 48 d4 cd                               	vpaddq zmm9,zmm9,zmm5
   831d8:	62 b2 95 48 b5 e4                               	vpmadd52huq zmm4,zmm13,zmm20
   831de:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   831e3:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   831e7:	62 b2 9d 48 b5 ec                               	vpmadd52huq zmm5,zmm12,zmm20
   831ed:	62 32 bd 40 b4 cc                               	vpmadd52luq zmm9,zmm24,zmm20
   831f3:	62 b2 8d 48 b5 f4                               	vpmadd52huq zmm6,zmm14,zmm20
   831f9:	62 32 85 48 b5 c4                               	vpmadd52huq zmm8,zmm15,zmm20
   831ff:	62 b2 bd 40 b5 fc                               	vpmadd52huq zmm7,zmm24,zmm20
   83205:	62 b2 9d 48 b4 e4                               	vpmadd52luq zmm4,zmm12,zmm20
   8320b:	62 52 b5 48 b4 d3                               	vpmadd52luq zmm10,zmm9,zmm11
   83211:	62 31 b5 48 d4 c9                               	vpaddq zmm9,zmm9,zmm17
   83217:	62 d1 b5 48 73 d1 34                            	vpsrlq zmm9,zmm9,0x34
   8321e:	62 b2 95 48 b4 f4                               	vpmadd52luq zmm6,zmm13,zmm20
   83224:	62 32 8d 48 b4 c4                               	vpmadd52luq zmm8,zmm14,zmm20
   8322a:	62 b2 85 48 b4 fc                               	vpmadd52luq zmm7,zmm15,zmm20
   83230:	62 f2 ad 48 b5 e1                               	vpmadd52huq zmm4,zmm10,zmm1
   83236:	62 32 ad 48 b5 ca                               	vpmadd52huq zmm9,zmm10,zmm18
   8323c:	62 f2 ad 48 b5 e8                               	vpmadd52huq zmm5,zmm10,zmm0
   83242:	62 f2 ad 48 b5 f2                               	vpmadd52huq zmm6,zmm10,zmm2
   83248:	62 72 ad 48 b5 c3                               	vpmadd52huq zmm8,zmm10,zmm3
   8324e:	62 f2 ad 48 b4 fb                               	vpmadd52luq zmm7,zmm10,zmm3
   83254:	62 f2 ad 48 b4 e0                               	vpmadd52luq zmm4,zmm10,zmm0
   8325a:	62 b2 95 48 b5 ed                               	vpmadd52huq zmm5,zmm13,zmm21
   83260:	62 f2 ad 48 b4 f1                               	vpmadd52luq zmm6,zmm10,zmm1
   83266:	62 72 ad 48 b4 c2                               	vpmadd52luq zmm8,zmm10,zmm2
   8326c:	62 51 c5 48 d4 c9                               	vpaddq zmm9,zmm7,zmm9
   83272:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   83277:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   8327b:	62 b2 9d 48 b5 fd                               	vpmadd52huq zmm7,zmm12,zmm21
   83281:	62 32 bd 40 b4 cd                               	vpmadd52luq zmm9,zmm24,zmm21
   83287:	62 b2 8d 48 b5 e5                               	vpmadd52huq zmm4,zmm14,zmm21
   8328d:	62 b2 9d 48 b4 ed                               	vpmadd52luq zmm5,zmm12,zmm21
   83293:	62 b2 85 48 b5 f5                               	vpmadd52huq zmm6,zmm15,zmm21
   83299:	62 32 bd 40 b5 c5                               	vpmadd52huq zmm8,zmm24,zmm21
   8329f:	62 52 b5 48 b4 d3                               	vpmadd52luq zmm10,zmm9,zmm11
   832a5:	62 b2 95 48 b4 e5                               	vpmadd52luq zmm4,zmm13,zmm21
   832ab:	62 31 b5 48 d4 c9                               	vpaddq zmm9,zmm9,zmm17
   832b1:	62 d1 b5 48 73 d1 34                            	vpsrlq zmm9,zmm9,0x34
   832b8:	62 b2 8d 48 b4 f5                               	vpmadd52luq zmm6,zmm14,zmm21
   832be:	62 32 85 48 b4 c5                               	vpmadd52luq zmm8,zmm15,zmm21
   832c4:	62 f2 ad 48 b5 e9                               	vpmadd52huq zmm5,zmm10,zmm1
   832ca:	62 32 ad 48 b5 ca                               	vpmadd52huq zmm9,zmm10,zmm18
   832d0:	62 f2 ad 48 b5 e2                               	vpmadd52huq zmm4,zmm10,zmm2
   832d6:	62 f2 ad 48 b5 f8                               	vpmadd52huq zmm7,zmm10,zmm0
   832dc:	62 f2 ad 48 b5 f3                               	vpmadd52huq zmm6,zmm10,zmm3
   832e2:	62 72 ad 48 b4 c3                               	vpmadd52luq zmm8,zmm10,zmm3
   832e8:	62 f2 ad 48 b4 e8                               	vpmadd52luq zmm5,zmm10,zmm0
   832ee:	62 f2 ad 48 b4 e1                               	vpmadd52luq zmm4,zmm10,zmm1
   832f4:	62 b2 95 48 b5 fe                               	vpmadd52huq zmm7,zmm13,zmm22
   832fa:	62 f2 ad 48 b4 f2                               	vpmadd52luq zmm6,zmm10,zmm2
   83300:	62 51 bd 48 d4 c9                               	vpaddq zmm9,zmm8,zmm9
   83306:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   8330b:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   83310:	62 32 9d 48 b5 c6                               	vpmadd52huq zmm8,zmm12,zmm22
   83316:	62 32 bd 40 b4 ce                               	vpmadd52luq zmm9,zmm24,zmm22
   8331c:	62 b2 8d 48 b5 ee                               	vpmadd52huq zmm5,zmm14,zmm22
   83322:	62 b2 85 48 b5 e6                               	vpmadd52huq zmm4,zmm15,zmm22
   83328:	62 b2 9d 48 b4 fe                               	vpmadd52luq zmm7,zmm12,zmm22
   8332e:	62 b2 bd 40 b5 f6                               	vpmadd52huq zmm6,zmm24,zmm22
   83334:	62 52 b5 48 b4 d3                               	vpmadd52luq zmm10,zmm9,zmm11
   8333a:	62 b2 95 48 b4 ee                               	vpmadd52luq zmm5,zmm13,zmm22
   83340:	62 b2 8d 48 b4 e6                               	vpmadd52luq zmm4,zmm14,zmm22
   83346:	62 31 b5 48 d4 c9                               	vpaddq zmm9,zmm9,zmm17
   8334c:	62 d1 b5 48 73 d1 34                            	vpsrlq zmm9,zmm9,0x34
   83353:	62 b2 85 48 b4 f6                               	vpmadd52luq zmm6,zmm15,zmm22
   83359:	62 f2 ad 48 b5 f9                               	vpmadd52huq zmm7,zmm10,zmm1
   8335f:	62 f2 ad 48 b5 ea                               	vpmadd52huq zmm5,zmm10,zmm2
   83365:	62 32 ad 48 b5 ca                               	vpmadd52huq zmm9,zmm10,zmm18
   8336b:	62 f2 ad 48 b5 e3                               	vpmadd52huq zmm4,zmm10,zmm3
   83371:	62 72 ad 48 b5 c0                               	vpmadd52huq zmm8,zmm10,zmm0
   83377:	62 f2 ad 48 b4 f3                               	vpmadd52luq zmm6,zmm10,zmm3
   8337d:	62 f2 ad 48 b4 f8                               	vpmadd52luq zmm7,zmm10,zmm0
   83383:	62 f2 ad 48 b4 e9                               	vpmadd52luq zmm5,zmm10,zmm1
   83389:	62 f2 ad 48 b4 e2                               	vpmadd52luq zmm4,zmm10,zmm2
   8338f:	62 32 95 48 b5 c7                               	vpmadd52huq zmm8,zmm13,zmm23
   83395:	62 d1 cd 48 d4 f1                               	vpaddq zmm6,zmm6,zmm9
   8339b:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   833a0:	62 b2 bd 40 b4 f7                               	vpmadd52luq zmm6,zmm24,zmm23
   833a6:	62 b2 8d 48 b5 ff                               	vpmadd52huq zmm7,zmm14,zmm23
   833ac:	62 b2 85 48 b5 ef                               	vpmadd52huq zmm5,zmm15,zmm23
   833b2:	62 b2 bd 40 b5 e7                               	vpmadd52huq zmm4,zmm24,zmm23
   833b8:	62 32 9d 48 b4 c7                               	vpmadd52luq zmm8,zmm12,zmm23
   833be:	62 52 cd 48 b4 cb                               	vpmadd52luq zmm9,zmm6,zmm11
   833c4:	62 b2 95 48 b4 ff                               	vpmadd52luq zmm7,zmm13,zmm23
   833ca:	62 b2 8d 48 b4 ef                               	vpmadd52luq zmm5,zmm14,zmm23
   833d0:	62 b1 cd 48 d4 f3                               	vpaddq zmm6,zmm6,zmm19
   833d6:	62 b2 85 48 b4 e7                               	vpmadd52luq zmm4,zmm15,zmm23
   833dc:	62 f1 cd 48 73 d6 30                            	vpsrlq zmm6,zmm6,0x30
   833e3:	62 d1 ad 48 73 f1 04                            	vpsllq zmm10,zmm9,0x4
   833ea:	62 31 b5 48 db cb                               	vpandq zmm9,zmm9,zmm19
   833f0:	62 f2 b5 48 b5 fa                               	vpmadd52huq zmm7,zmm9,zmm2
   833f6:	62 f2 b5 48 b5 eb                               	vpmadd52huq zmm5,zmm9,zmm3
   833fc:	62 b2 ad 48 b5 f2                               	vpmadd52huq zmm6,zmm10,zmm18
   83402:	62 72 fd 48 59 15 d4 40 f8 ff                   	vpbroadcastq zmm10,QWORD PTR [rip+0xfffffffffff840d4]        # 74e0 <GCC_except_table746+0x16c>
   8340c:	62 72 b5 48 b5 c1                               	vpmadd52huq zmm8,zmm9,zmm1
   83412:	62 f2 b5 48 b4 e3                               	vpmadd52luq zmm4,zmm9,zmm3
   83418:	62 f2 b5 48 b4 f9                               	vpmadd52luq zmm7,zmm9,zmm1
   8341e:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   83422:	62 b2 9d 48 b5 cf                               	vpmadd52huq zmm1,zmm12,zmm23
   83428:	62 f2 b5 48 b4 ea                               	vpmadd52luq zmm5,zmm9,zmm2
   8342e:	62 72 b5 48 b4 c0                               	vpmadd52luq zmm8,zmm9,zmm0
   83434:	62 f2 b5 48 b5 c8                               	vpmadd52huq zmm1,zmm9,zmm0
   8343a:	62 f1 fd 48 73 f4 04                            	vpsllq zmm0,zmm4,0x4
   83441:	62 f1 e5 48 73 f7 04                            	vpsllq zmm3,zmm7,0x4
   83448:	62 f1 ed 48 73 d5 30                            	vpsrlq zmm2,zmm5,0x30
   8344f:	62 f1 d5 48 73 f5 04                            	vpsllq zmm5,zmm5,0x4
   83456:	62 f1 dd 48 73 d4 30                            	vpsrlq zmm4,zmm4,0x30
   8345d:	62 d1 fd 48 db c2                               	vpandq zmm0,zmm0,zmm10
   83463:	62 d1 e5 48 db da                               	vpandq zmm3,zmm3,zmm10
   83469:	62 d1 d5 48 db ea                               	vpandq zmm5,zmm5,zmm10
   8346f:	62 f1 e5 48 d4 d2                               	vpaddq zmm2,zmm3,zmm2
   83475:	62 f1 e5 48 73 d7 30                            	vpsrlq zmm3,zmm7,0x30
   8347c:	62 d1 c5 48 73 f0 04                            	vpsllq zmm7,zmm8,0x4
   83483:	62 f1 fd 48 d4 c6                               	vpaddq zmm0,zmm0,zmm6
   83489:	62 d1 bd 48 73 d0 30                            	vpsrlq zmm8,zmm8,0x30
   83490:	62 d1 c5 48 db f2                               	vpandq zmm6,zmm7,zmm10
   83496:	62 f1 c5 48 73 d0 34                            	vpsrlq zmm7,zmm0,0x34
   8349d:	62 b1 fd 48 db c1                               	vpandq zmm0,zmm0,zmm17
   834a3:	62 f1 c5 48 d4 e4                               	vpaddq zmm4,zmm7,zmm4
   834a9:	62 f1 cd 48 d4 db                               	vpaddq zmm3,zmm6,zmm3
   834af:	62 f1 f5 48 73 f1 04                            	vpsllq zmm1,zmm1,0x4
   834b6:	62 f1 fd 48 7f 44 24 3b                         	vmovdqa64 ZMMWORD PTR [rsp+0xec0],zmm0
   834be:	62 f1 fd 48 7f 44 24 33                         	vmovdqa64 ZMMWORD PTR [rsp+0xcc0],zmm0
   834c6:	62 f1 dd 48 d4 e5                               	vpaddq zmm4,zmm4,zmm5
   834cc:	62 f1 bd 48 d4 c9                               	vpaddq zmm1,zmm8,zmm1
   834d2:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   834d9:	62 b1 dd 48 db e1                               	vpandq zmm4,zmm4,zmm17
   834df:	62 f1 d5 48 d4 d2                               	vpaddq zmm2,zmm5,zmm2
   834e5:	62 f1 fd 48 7f 64 24 3a                         	vmovdqa64 ZMMWORD PTR [rsp+0xe80],zmm4
   834ed:	62 f1 fd 48 7f 64 24 34                         	vmovdqa64 ZMMWORD PTR [rsp+0xd00],zmm4
   834f5:	62 f1 d5 48 73 d2 34                            	vpsrlq zmm5,zmm2,0x34
   834fc:	62 b1 ed 48 db d1                               	vpandq zmm2,zmm2,zmm17
   83502:	62 f1 d5 48 d4 db                               	vpaddq zmm3,zmm5,zmm3
   83508:	62 f1 fd 48 7f 54 24 39                         	vmovdqa64 ZMMWORD PTR [rsp+0xe40],zmm2
   83510:	62 f1 fd 48 7f 54 24 35                         	vmovdqa64 ZMMWORD PTR [rsp+0xd40],zmm2
   83518:	62 f1 d5 48 73 d3 34                            	vpsrlq zmm5,zmm3,0x34
   8351f:	62 b1 e5 48 db d9                               	vpandq zmm3,zmm3,zmm17
   83525:	62 f1 d5 48 d4 c9                               	vpaddq zmm1,zmm5,zmm1
   8352b:	62 f1 fd 48 7f 5c 24 36                         	vmovdqa64 ZMMWORD PTR [rsp+0xd80],zmm3
   83533:	62 f1 fd 48 7f 5c 24 38                         	vmovdqa64 ZMMWORD PTR [rsp+0xe00],zmm3
   8353b:	62 f1 fd 48 7f 4c 24 3c                         	vmovdqa64 ZMMWORD PTR [rsp+0xf00],zmm1
   83543:	62 f1 fd 48 7f 4c 24 37                         	vmovdqa64 ZMMWORD PTR [rsp+0xdc0],zmm1
   8354b:	4c 3b bc 24 e8 00 00 00                         	cmp    r15,QWORD PTR [rsp+0xe8]
   83553:	75 10                                           	jne    83565 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x4db5>
   83555:	48 8d bc 24 e8 00 00 00                         	lea    rdi,[rsp+0xe8]
   8355d:	c5 f8 77                                        	vzeroupper
   83560:	e8 5b 3c 00 00                                  	call   871c0 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecNtNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns6RecordE8grow_oneBT_>
   83565:	62 f2 fd 48 59 05 69 3f f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff83f69]        # 74d8 <GCC_except_table746+0x164>
   8356f:	62 72 fd 48 59 2d 87 3e f8 ff                   	vpbroadcastq zmm13,QWORD PTR [rip+0xfffffffffff83e87]        # 7400 <GCC_except_table746+0x8c>
   83579:	c5 f8 90 4c 24 6e                               	kmovw  k1,WORD PTR [rsp+0x6e]
   8357f:	62 72 fd 48 59 25 af 3f f8 ff                   	vpbroadcastq zmm12,QWORD PTR [rip+0xfffffffffff83faf]        # 7538 <GCC_except_table746+0x1c4>
   83589:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   8358d:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   83592:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   83597:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   8359c:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   835a0:	62 72 fd 48 59 35 8e 3e f8 ff                   	vpbroadcastq zmm14,QWORD PTR [rip+0xfffffffffff83e8e]        # 7438 <GCC_except_table746+0xc4>
   835aa:	4c 89 f9                                        	mov    rcx,r15
   835ad:	48 c1 e1 0a                                     	shl    rcx,0xa
   835b1:	49 ff c7                                        	inc    r15
   835b4:	62 f1 95 48 db 6c 24 41                         	vpandq zmm5,zmm13,ZMMWORD PTR [rsp+0x1040]
   835bc:	62 f1 95 48 db 64 24 40                         	vpandq zmm4,zmm13,ZMMWORD PTR [rsp+0x1000]
   835c4:	62 f1 95 48 db 5c 24 3f                         	vpandq zmm3,zmm13,ZMMWORD PTR [rsp+0xfc0]
   835cc:	62 f1 95 48 db 54 24 3e                         	vpandq zmm2,zmm13,ZMMWORD PTR [rsp+0xf80]
   835d4:	62 f2 fd 59 64 05 8a 3e f8 ff                   	vpblendmq zmm0{k1},zmm0,QWORD BCST [rip+0xfffffffffff83e8a]        # 7468 <GCC_except_table746+0xf4>
   835de:	62 71 fd 48 6f 5c 24 20                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x800]
   835e6:	62 e1 fd 48 6f 54 24 42                         	vmovdqa64 zmm18,ZMMWORD PTR [rsp+0x1080]
   835ee:	62 e1 fd 48 6f 4c 24 43                         	vmovdqa64 zmm17,ZMMWORD PTR [rsp+0x10c0]
   835f6:	62 e1 fd 48 6f 44 24 44                         	vmovdqa64 zmm16,ZMMWORD PTR [rsp+0x1100]
   835fe:	62 71 fd 48 6f 7c 24 45                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x1140]
   83606:	48 8b 84 24 f0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xf0]
   8360e:	62 f1 fd 48 d4 44 24 3d                         	vpaddq zmm0,zmm0,ZMMWORD PTR [rsp+0xf40]
   83616:	62 52 d5 48 b5 d3                               	vpmadd52huq zmm10,zmm5,zmm11
   8361c:	62 52 dd 48 b5 c3                               	vpmadd52huq zmm8,zmm4,zmm11
   83622:	62 52 e5 48 b5 cb                               	vpmadd52huq zmm9,zmm3,zmm11
   83628:	62 d2 d5 48 b4 f3                               	vpmadd52luq zmm6,zmm5,zmm11
   8362e:	62 d2 ed 48 b5 fb                               	vpmadd52huq zmm7,zmm2,zmm11
   83634:	62 d1 fd 48 db cd                               	vpandq zmm1,zmm0,zmm13
   8363a:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   8363e:	62 d2 f5 48 b5 c3                               	vpmadd52huq zmm0,zmm1,zmm11
   83644:	62 52 dd 48 b4 d3                               	vpmadd52luq zmm10,zmm4,zmm11
   8364a:	62 52 e5 48 b4 c3                               	vpmadd52luq zmm8,zmm3,zmm11
   83650:	62 52 ed 48 b4 cb                               	vpmadd52luq zmm9,zmm2,zmm11
   83656:	62 d2 f5 48 b4 fb                               	vpmadd52luq zmm7,zmm1,zmm11
   8365c:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   83661:	62 52 cd 48 b4 dc                               	vpmadd52luq zmm11,zmm6,zmm12
   83667:	62 d1 cd 48 d4 f5                               	vpaddq zmm6,zmm6,zmm13
   8366d:	62 f1 cd 48 73 d6 34                            	vpsrlq zmm6,zmm6,0x34
   83674:	62 32 a5 48 b5 c2                               	vpmadd52huq zmm8,zmm11,zmm18
   8367a:	62 32 a5 48 b5 c9                               	vpmadd52huq zmm9,zmm11,zmm17
   83680:	62 b2 a5 48 b5 f8                               	vpmadd52huq zmm7,zmm11,zmm16
   83686:	62 d2 a5 48 b5 f6                               	vpmadd52huq zmm6,zmm11,zmm14
   8368c:	62 32 a5 48 b4 d2                               	vpmadd52luq zmm10,zmm11,zmm18
   83692:	62 d2 a5 48 b5 c7                               	vpmadd52huq zmm0,zmm11,zmm15
   83698:	62 32 a5 48 b4 c1                               	vpmadd52luq zmm8,zmm11,zmm17
   8369e:	62 32 a5 48 b4 c8                               	vpmadd52luq zmm9,zmm11,zmm16
   836a4:	62 d2 a5 48 b4 ff                               	vpmadd52luq zmm7,zmm11,zmm15
   836aa:	62 71 fd 48 6f 5c 24 21                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x840]
   836b2:	62 71 ad 48 d4 d6                               	vpaddq zmm10,zmm10,zmm6
   836b8:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   836bc:	62 52 d5 48 b5 c3                               	vpmadd52huq zmm8,zmm5,zmm11
   836c2:	62 52 dd 48 b5 cb                               	vpmadd52huq zmm9,zmm4,zmm11
   836c8:	62 d2 e5 48 b5 fb                               	vpmadd52huq zmm7,zmm3,zmm11
   836ce:	62 d2 ed 48 b5 c3                               	vpmadd52huq zmm0,zmm2,zmm11
   836d4:	62 52 d5 48 b4 d3                               	vpmadd52luq zmm10,zmm5,zmm11
   836da:	62 d2 f5 48 b5 f3                               	vpmadd52huq zmm6,zmm1,zmm11
   836e0:	62 52 dd 48 b4 c3                               	vpmadd52luq zmm8,zmm4,zmm11
   836e6:	62 52 e5 48 b4 cb                               	vpmadd52luq zmm9,zmm3,zmm11
   836ec:	62 d2 ed 48 b4 fb                               	vpmadd52luq zmm7,zmm2,zmm11
   836f2:	62 d2 f5 48 b4 c3                               	vpmadd52luq zmm0,zmm1,zmm11
   836f8:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   836fd:	62 52 ad 48 b4 dc                               	vpmadd52luq zmm11,zmm10,zmm12
   83703:	62 51 ad 48 d4 d5                               	vpaddq zmm10,zmm10,zmm13
   83709:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   83710:	62 32 a5 48 b5 ca                               	vpmadd52huq zmm9,zmm11,zmm18
   83716:	62 b2 a5 48 b5 f9                               	vpmadd52huq zmm7,zmm11,zmm17
   8371c:	62 b2 a5 48 b5 c0                               	vpmadd52huq zmm0,zmm11,zmm16
   83722:	62 52 a5 48 b5 d6                               	vpmadd52huq zmm10,zmm11,zmm14
   83728:	62 32 a5 48 b4 c2                               	vpmadd52luq zmm8,zmm11,zmm18
   8372e:	62 d2 a5 48 b5 f7                               	vpmadd52huq zmm6,zmm11,zmm15
   83734:	62 32 a5 48 b4 c9                               	vpmadd52luq zmm9,zmm11,zmm17
   8373a:	62 b2 a5 48 b4 f8                               	vpmadd52luq zmm7,zmm11,zmm16
   83740:	62 d2 a5 48 b4 c7                               	vpmadd52luq zmm0,zmm11,zmm15
   83746:	62 71 fd 48 6f 5c 24 22                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x880]
   8374e:	62 51 bd 48 d4 d2                               	vpaddq zmm10,zmm8,zmm10
   83754:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   83759:	62 52 d5 48 b5 cb                               	vpmadd52huq zmm9,zmm5,zmm11
   8375f:	62 d2 dd 48 b5 fb                               	vpmadd52huq zmm7,zmm4,zmm11
   83765:	62 d2 e5 48 b5 c3                               	vpmadd52huq zmm0,zmm3,zmm11
   8376b:	62 d2 ed 48 b5 f3                               	vpmadd52huq zmm6,zmm2,zmm11
   83771:	62 52 d5 48 b4 d3                               	vpmadd52luq zmm10,zmm5,zmm11
   83777:	62 52 f5 48 b5 c3                               	vpmadd52huq zmm8,zmm1,zmm11
   8377d:	62 52 dd 48 b4 cb                               	vpmadd52luq zmm9,zmm4,zmm11
   83783:	62 d2 e5 48 b4 fb                               	vpmadd52luq zmm7,zmm3,zmm11
   83789:	62 d2 ed 48 b4 c3                               	vpmadd52luq zmm0,zmm2,zmm11
   8378f:	62 d2 f5 48 b4 f3                               	vpmadd52luq zmm6,zmm1,zmm11
   83795:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   8379a:	62 52 ad 48 b4 dc                               	vpmadd52luq zmm11,zmm10,zmm12
   837a0:	62 51 ad 48 d4 d5                               	vpaddq zmm10,zmm10,zmm13
   837a6:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   837ad:	62 b2 a5 48 b5 fa                               	vpmadd52huq zmm7,zmm11,zmm18
   837b3:	62 b2 a5 48 b5 c1                               	vpmadd52huq zmm0,zmm11,zmm17
   837b9:	62 b2 a5 48 b5 f0                               	vpmadd52huq zmm6,zmm11,zmm16
   837bf:	62 52 a5 48 b5 d6                               	vpmadd52huq zmm10,zmm11,zmm14
   837c5:	62 32 a5 48 b4 ca                               	vpmadd52luq zmm9,zmm11,zmm18
   837cb:	62 52 a5 48 b5 c7                               	vpmadd52huq zmm8,zmm11,zmm15
   837d1:	62 b2 a5 48 b4 f9                               	vpmadd52luq zmm7,zmm11,zmm17
   837d7:	62 b2 a5 48 b4 c0                               	vpmadd52luq zmm0,zmm11,zmm16
   837dd:	62 d2 a5 48 b4 f7                               	vpmadd52luq zmm6,zmm11,zmm15
   837e3:	62 71 fd 48 6f 5c 24 23                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x8c0]
   837eb:	62 51 b5 48 d4 d2                               	vpaddq zmm10,zmm9,zmm10
   837f1:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   837f6:	62 d2 d5 48 b5 fb                               	vpmadd52huq zmm7,zmm5,zmm11
   837fc:	62 d2 dd 48 b5 c3                               	vpmadd52huq zmm0,zmm4,zmm11
   83802:	62 d2 e5 48 b5 f3                               	vpmadd52huq zmm6,zmm3,zmm11
   83808:	62 52 ed 48 b5 c3                               	vpmadd52huq zmm8,zmm2,zmm11
   8380e:	62 52 d5 48 b4 d3                               	vpmadd52luq zmm10,zmm5,zmm11
   83814:	62 52 f5 48 b5 cb                               	vpmadd52huq zmm9,zmm1,zmm11
   8381a:	62 d2 dd 48 b4 fb                               	vpmadd52luq zmm7,zmm4,zmm11
   83820:	62 d2 e5 48 b4 c3                               	vpmadd52luq zmm0,zmm3,zmm11
   83826:	62 d2 ed 48 b4 f3                               	vpmadd52luq zmm6,zmm2,zmm11
   8382c:	62 52 f5 48 b4 c3                               	vpmadd52luq zmm8,zmm1,zmm11
   83832:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   83837:	62 52 ad 48 b4 dc                               	vpmadd52luq zmm11,zmm10,zmm12
   8383d:	62 51 ad 48 d4 d5                               	vpaddq zmm10,zmm10,zmm13
   83843:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   8384a:	62 b2 a5 48 b5 c2                               	vpmadd52huq zmm0,zmm11,zmm18
   83850:	62 b2 a5 48 b5 f1                               	vpmadd52huq zmm6,zmm11,zmm17
   83856:	62 32 a5 48 b5 c0                               	vpmadd52huq zmm8,zmm11,zmm16
   8385c:	62 52 a5 48 b5 d6                               	vpmadd52huq zmm10,zmm11,zmm14
   83862:	62 b2 a5 48 b4 fa                               	vpmadd52luq zmm7,zmm11,zmm18
   83868:	62 52 a5 48 b5 cf                               	vpmadd52huq zmm9,zmm11,zmm15
   8386e:	62 b2 a5 48 b4 c1                               	vpmadd52luq zmm0,zmm11,zmm17
   83874:	62 b2 a5 48 b4 f0                               	vpmadd52luq zmm6,zmm11,zmm16
   8387a:	62 52 a5 48 b4 c7                               	vpmadd52luq zmm8,zmm11,zmm15
   83880:	62 71 fd 48 6f 5c 24 24                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x900]
   83888:	62 d1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm10
   8388e:	62 71 fd 48 6f 54 24 4a                         	vmovdqa64 zmm10,ZMMWORD PTR [rsp+0x1280]
   83896:	62 d2 d5 48 b5 c3                               	vpmadd52huq zmm0,zmm5,zmm11
   8389c:	62 52 e5 48 b5 c3                               	vpmadd52huq zmm8,zmm3,zmm11
   838a2:	62 52 ed 48 b5 cb                               	vpmadd52huq zmm9,zmm2,zmm11
   838a8:	62 d2 d5 48 b4 fb                               	vpmadd52luq zmm7,zmm5,zmm11
   838ae:	62 f2 fd 48 59 2d 50 3b f8 ff                   	vpbroadcastq zmm5,QWORD PTR [rip+0xfffffffffff83b50]        # 7408 <GCC_except_table746+0x94>
   838b8:	62 d2 dd 48 b5 f3                               	vpmadd52huq zmm6,zmm4,zmm11
   838be:	62 52 ed 48 b4 c3                               	vpmadd52luq zmm8,zmm2,zmm11
   838c4:	c5 e9 ef d2                                     	vpxor  xmm2,xmm2,xmm2
   838c8:	62 52 f5 48 b4 cb                               	vpmadd52luq zmm9,zmm1,zmm11
   838ce:	62 d2 f5 48 b5 d3                               	vpmadd52huq zmm2,zmm1,zmm11
   838d4:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   838d8:	62 d2 c5 48 b4 cc                               	vpmadd52luq zmm1,zmm7,zmm12
   838de:	62 d2 e5 48 b4 f3                               	vpmadd52luq zmm6,zmm3,zmm11
   838e4:	62 d2 dd 48 b4 c3                               	vpmadd52luq zmm0,zmm4,zmm11
   838ea:	62 71 7c 48 28 5c 24 31                         	vmovaps zmm11,ZMMWORD PTR [rsp+0xc40]
   838f2:	62 71 7c 48 28 64 24 25                         	vmovaps zmm12,ZMMWORD PTR [rsp+0x940]
   838fa:	62 f1 dd 48 73 f1 04                            	vpsllq zmm4,zmm1,0x4
   83901:	62 f1 f5 48 db cd                               	vpandq zmm1,zmm1,zmm5
   83907:	62 f1 c5 48 d4 dd                               	vpaddq zmm3,zmm7,zmm5
   8390d:	62 f2 fd 48 59 3d c9 3b f8 ff                   	vpbroadcastq zmm7,QWORD PTR [rip+0xfffffffffff83bc9]        # 74e0 <GCC_except_table746+0x16c>
   83917:	62 32 f5 48 b5 c1                               	vpmadd52huq zmm8,zmm1,zmm17
   8391d:	62 32 f5 48 b5 c8                               	vpmadd52huq zmm9,zmm1,zmm16
   83923:	62 b2 f5 48 b5 f2                               	vpmadd52huq zmm6,zmm1,zmm18
   83929:	62 b2 f5 48 b4 c2                               	vpmadd52luq zmm0,zmm1,zmm18
   8392f:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   83936:	62 d2 f5 48 b5 d7                               	vpmadd52huq zmm2,zmm1,zmm15
   8393c:	62 d2 dd 48 b5 de                               	vpmadd52huq zmm3,zmm4,zmm14
   83942:	62 71 7c 48 29 1c 08                            	vmovaps ZMMWORD PTR [rax+rcx*1],zmm11
   83949:	62 71 7c 48 28 5c 24 30                         	vmovaps zmm11,ZMMWORD PTR [rsp+0xc00]
   83951:	62 71 7c 48 29 64 08 01                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x40],zmm12
   83959:	62 71 fd 48 6f 64 24 2f                         	vmovdqa64 zmm12,ZMMWORD PTR [rsp+0xbc0]
   83961:	62 32 f5 48 b4 c0                               	vpmadd52luq zmm8,zmm1,zmm16
   83967:	62 52 f5 48 b4 cf                               	vpmadd52luq zmm9,zmm1,zmm15
   8396d:	62 b2 f5 48 b4 f1                               	vpmadd52luq zmm6,zmm1,zmm17
   83973:	62 f1 f5 48 73 f0 04                            	vpsllq zmm1,zmm0,0x4
   8397a:	62 f1 fd 48 73 d0 30                            	vpsrlq zmm0,zmm0,0x30
   83981:	62 f1 ed 48 73 f2 04                            	vpsllq zmm2,zmm2,0x4
   83988:	62 f1 f5 48 db cf                               	vpandq zmm1,zmm1,zmm7
   8398e:	62 d1 dd 48 73 f0 04                            	vpsllq zmm4,zmm8,0x4
   83995:	62 d1 d5 48 73 f1 04                            	vpsllq zmm5,zmm9,0x4
   8399c:	62 f1 f5 48 d4 cb                               	vpaddq zmm1,zmm1,zmm3
   839a2:	62 f1 e5 48 73 d6 30                            	vpsrlq zmm3,zmm6,0x30
   839a9:	62 d1 bd 48 73 d0 30                            	vpsrlq zmm8,zmm8,0x30
   839b0:	62 f1 dd 48 db e7                               	vpandq zmm4,zmm4,zmm7
   839b6:	62 f1 d5 48 db ef                               	vpandq zmm5,zmm5,zmm7
   839bc:	62 f1 dd 48 d4 db                               	vpaddq zmm3,zmm4,zmm3
   839c2:	62 d1 d5 48 d4 e0                               	vpaddq zmm4,zmm5,zmm8
   839c8:	62 f1 d5 48 73 d1 34                            	vpsrlq zmm5,zmm1,0x34
   839cf:	62 d1 bd 48 73 d1 30                            	vpsrlq zmm8,zmm9,0x30
   839d6:	62 d1 f5 48 db cd                               	vpandq zmm1,zmm1,zmm13
   839dc:	62 f1 d5 48 d4 c0                               	vpaddq zmm0,zmm5,zmm0
   839e2:	62 f1 d5 48 73 f6 04                            	vpsllq zmm5,zmm6,0x4
   839e9:	62 f1 bd 48 d4 d2                               	vpaddq zmm2,zmm8,zmm2
   839ef:	62 71 7c 48 29 5c 08 02                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x80],zmm11
   839f7:	62 71 fd 48 6f 5c 24 4b                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x12c0]
   839ff:	62 71 fd 48 7f 64 08 03                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0xc0],zmm12
   83a07:	62 f1 d5 48 db ef                               	vpandq zmm5,zmm5,zmm7
   83a0d:	62 f1 fd 48 d4 c5                               	vpaddq zmm0,zmm0,zmm5
   83a13:	62 f1 d5 48 73 d0 34                            	vpsrlq zmm5,zmm0,0x34
   83a1a:	62 d1 fd 48 db c5                               	vpandq zmm0,zmm0,zmm13
   83a20:	62 f1 d5 48 d4 db                               	vpaddq zmm3,zmm5,zmm3
   83a26:	62 f1 d5 48 73 d3 34                            	vpsrlq zmm5,zmm3,0x34
   83a2d:	62 d1 e5 48 db dd                               	vpandq zmm3,zmm3,zmm13
   83a33:	62 f1 d5 48 d4 e4                               	vpaddq zmm4,zmm5,zmm4
   83a39:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   83a40:	62 f1 d5 48 d4 d2                               	vpaddq zmm2,zmm5,zmm2
   83a46:	62 d1 d5 48 73 d2 34                            	vpsrlq zmm5,zmm10,0x34
   83a4d:	62 f1 d5 48 d4 6c 24 46                         	vpaddq zmm5,zmm5,ZMMWORD PTR [rsp+0x1180]
   83a55:	62 71 fd 48 7f 5c 08 04                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x100],zmm11
   83a5d:	62 f1 fd 48 7f 4c 08 05                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x140],zmm1
   83a65:	62 d1 dd 48 db cd                               	vpandq zmm1,zmm4,zmm13
   83a6b:	62 f1 fd 48 7f 44 08 06                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x180],zmm0
   83a73:	62 f1 fd 48 7f 5c 08 07                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x1c0],zmm3
   83a7b:	62 f1 fd 48 7f 4c 08 08                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x200],zmm1
   83a83:	62 f1 fd 48 7f 54 08 09                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x240],zmm2
   83a8b:	62 d1 ad 48 db d5                               	vpandq zmm2,zmm10,zmm13
   83a91:	62 f1 fd 48 7f 54 08 0a                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x280],zmm2
   83a99:	62 f1 cd 48 73 d5 34                            	vpsrlq zmm6,zmm5,0x34
   83aa0:	62 f1 cd 48 d4 74 24 47                         	vpaddq zmm6,zmm6,ZMMWORD PTR [rsp+0x11c0]
   83aa8:	62 d1 d5 48 db cd                               	vpandq zmm1,zmm5,zmm13
   83aae:	62 f1 fd 48 7f 4c 08 0b                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x2c0],zmm1
   83ab6:	62 f1 c5 48 73 d6 34                            	vpsrlq zmm7,zmm6,0x34
   83abd:	62 f1 c5 48 d4 7c 24 48                         	vpaddq zmm7,zmm7,ZMMWORD PTR [rsp+0x1200]
   83ac5:	62 d1 cd 48 db d5                               	vpandq zmm2,zmm6,zmm13
   83acb:	62 f1 fd 48 7f 54 08 0c                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x300],zmm2
   83ad3:	62 f1 bd 48 73 d7 34                            	vpsrlq zmm8,zmm7,0x34
   83ada:	62 71 bd 48 d4 44 24 49                         	vpaddq zmm8,zmm8,ZMMWORD PTR [rsp+0x1240]
   83ae2:	62 d1 c5 48 db cd                               	vpandq zmm1,zmm7,zmm13
   83ae8:	62 f1 fd 48 7f 4c 08 0d                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x340],zmm1
   83af0:	62 71 fd 48 7f 44 08 0e                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x380],zmm8
   83af8:	89 9c 08 c0 03 00 00                            	mov    DWORD PTR [rax+rcx*1+0x3c0],ebx
   83aff:	44 88 ac 08 c4 03 00 00                         	mov    BYTE PTR [rax+rcx*1+0x3c4],r13b
   83b07:	8b 84 24 80 06 00 00                            	mov    eax,DWORD PTR [rsp+0x680]
   83b0e:	4c 89 bc 24 f8 00 00 00                         	mov    QWORD PTR [rsp+0xf8],r15
   83b16:	22 84 24 c0 01 00 00                            	and    al,BYTE PTR [rsp+0x1c0]
   83b1d:	89 84 24 80 06 00 00                            	mov    DWORD PTR [rsp+0x680],eax
   83b24:	0f 84 73 e9 ff ff                               	je     8249d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3ced>
   83b2a:	c5 7d 6f 1d ae 44 f8 ff                         	vmovdqa ymm11,YMMWORD PTR [rip+0xfffffffffff844ae]        # 7fe0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x860>
   83b32:	62 d1 fd 48 6f 06                               	vmovdqa64 zmm0,ZMMWORD PTR [r14]
   83b38:	62 72 fd 48 59 35 b6 39 f8 ff                   	vpbroadcastq zmm14,QWORD PTR [rip+0xfffffffffff839b6]        # 74f8 <GCC_except_table746+0x184>
   83b42:	62 d1 fd 48 6f 4e 01                            	vmovdqa64 zmm1,ZMMWORD PTR [r14+0x40]
   83b49:	62 d1 fd 48 6f 56 02                            	vmovdqa64 zmm2,ZMMWORD PTR [r14+0x80]
   83b50:	62 d1 fd 48 6f 5e 03                            	vmovdqa64 zmm3,ZMMWORD PTR [r14+0xc0]
   83b57:	62 d1 fd 48 6f 66 04                            	vmovdqa64 zmm4,ZMMWORD PTR [r14+0x100]
   83b5e:	62 72 fd 48 59 25 08 39 f8 ff                   	vpbroadcastq zmm12,QWORD PTR [rip+0xfffffffffff83908]        # 7470 <GCC_except_table746+0xfc>
   83b68:	62 71 fd 48 6f 3d 4e 41 f8 ff                   	vmovdqa64 zmm15,ZMMWORD PTR [rip+0xfffffffffff8414e]        # 7cc0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x540>
   83b72:	62 e1 fd 48 6f 05 84 41 f8 ff                   	vmovdqa64 zmm16,ZMMWORD PTR [rip+0xfffffffffff84184]        # 7d00 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x580>
   83b7c:	45 31 ff                                        	xor    r15d,r15d
   83b7f:	45 31 ed                                        	xor    r13d,r13d
   83b82:	c5 7e 7f 9c 24 40 02 00 00                      	vmovdqu YMMWORD PTR [rsp+0x240],ymm11
   83b8b:	4c 89 a4 24 60 02 00 00                         	mov    QWORD PTR [rsp+0x260],r12
   83b93:	62 51 fd 48 d4 ce                               	vpaddq zmm9,zmm0,zmm14
   83b99:	62 f1 f5 58 fb 6c 24 49                         	vpsubq zmm5,zmm1,QWORD BCST [rsp+0x248]
   83ba1:	62 f1 ed 58 fb 74 24 4a                         	vpsubq zmm6,zmm2,QWORD BCST [rsp+0x250]
   83ba9:	62 f1 e5 58 fb 7c 24 4b                         	vpsubq zmm7,zmm3,QWORD BCST [rsp+0x258]
   83bb1:	62 71 dd 58 fb 44 24 4c                         	vpsubq zmm8,zmm4,QWORD BCST [rsp+0x260]
   83bb9:	62 d1 ad 48 72 e1 34                            	vpsraq zmm10,zmm9,0x34
   83bc0:	62 d1 d5 48 d4 ea                               	vpaddq zmm5,zmm5,zmm10
   83bc6:	62 f1 ad 48 72 e5 34                            	vpsraq zmm10,zmm5,0x34
   83bcd:	62 d1 cd 48 d4 f2                               	vpaddq zmm6,zmm6,zmm10
   83bd3:	62 f1 ad 48 72 e6 34                            	vpsraq zmm10,zmm6,0x34
   83bda:	62 d1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm10
   83be0:	62 f1 ad 48 72 e7 34                            	vpsraq zmm10,zmm7,0x34
   83be7:	62 51 bd 48 d4 c2                               	vpaddq zmm8,zmm8,zmm10
   83bed:	62 d3 bd 48 1e cc 01                            	vpcmpltuq k1,zmm8,zmm12
   83bf4:	62 d1 d5 49 db cd                               	vpandq zmm1{k1},zmm5,zmm13
   83bfa:	62 d1 cd 49 db d5                               	vpandq zmm2{k1},zmm6,zmm13
   83c00:	62 d1 c5 49 db dd                               	vpandq zmm3{k1},zmm7,zmm13
   83c06:	62 d1 fd 49 6f e0                               	vmovdqa64 zmm4{k1},zmm8
   83c0c:	62 d1 b5 49 db c5                               	vpandq zmm0{k1},zmm9,zmm13
   83c12:	62 f1 dd 48 73 f4 10                            	vpsllq zmm4,zmm4,0x10
   83c19:	62 f1 d5 48 73 f1 34                            	vpsllq zmm5,zmm1,0x34
   83c20:	62 f1 c5 48 73 f2 28                            	vpsllq zmm7,zmm2,0x28
   83c27:	62 f1 f5 48 73 d1 0c                            	vpsrlq zmm1,zmm1,0xc
   83c2e:	62 f1 cd 48 73 f3 1c                            	vpsllq zmm6,zmm3,0x1c
   83c35:	62 f1 ed 48 73 d2 18                            	vpsrlq zmm2,zmm2,0x18
   83c3c:	62 f1 e5 48 73 d3 24                            	vpsrlq zmm3,zmm3,0x24
   83c43:	62 f1 d5 48 eb c0                               	vporq  zmm0,zmm5,zmm0
   83c49:	62 f1 c5 48 eb c9                               	vporq  zmm1,zmm7,zmm1
   83c4f:	62 f1 dd 48 eb db                               	vporq  zmm3,zmm4,zmm3
   83c55:	62 f1 cd 48 eb d2                               	vporq  zmm2,zmm6,zmm2
   83c5b:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   83c61:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   83c67:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   83c6d:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   83c73:	62 f1 fd 48 6f dc                               	vmovdqa64 zmm3,zmm4
   83c79:	62 f2 85 48 7e d9                               	vpermt2q zmm3,zmm15,zmm1
   83c7f:	62 f2 fd 40 7e e1                               	vpermt2q zmm4,zmm16,zmm1
   83c85:	62 f1 fd 48 6f c8                               	vmovdqa64 zmm1,zmm0
   83c8b:	62 f2 85 48 7e ca                               	vpermt2q zmm1,zmm15,zmm2
   83c91:	62 f2 fd 40 7e c2                               	vpermt2q zmm0,zmm16,zmm2
   83c97:	62 f3 e5 48 3a d1 01                            	vinserti64x4 zmm2,zmm3,ymm1,0x1
   83c9e:	62 f3 e5 48 43 c9 ee                            	vshufi64x2 zmm1,zmm3,zmm1,0xee
   83ca5:	62 f3 dd 48 3a d8 01                            	vinserti64x4 zmm3,zmm4,ymm0,0x1
   83cac:	62 f3 dd 48 43 c0 ee                            	vshufi64x2 zmm0,zmm4,zmm0,0xee
   83cb3:	62 f1 fe 48 7f 54 24 26                         	vmovdqu64 ZMMWORD PTR [rsp+0x980],zmm2
   83cbb:	62 f1 fe 48 7f 4c 24 27                         	vmovdqu64 ZMMWORD PTR [rsp+0x9c0],zmm1
   83cc3:	62 f1 fe 48 7f 5c 24 28                         	vmovdqu64 ZMMWORD PTR [rsp+0xa00],zmm3
   83ccb:	62 f1 fe 48 7f 44 24 29                         	vmovdqu64 ZMMWORD PTR [rsp+0xa40],zmm0
   83cd3:	62 d1 fd 48 6f 46 05                            	vmovdqa64 zmm0,ZMMWORD PTR [r14+0x140]
   83cda:	62 d1 fd 48 6f 4e 06                            	vmovdqa64 zmm1,ZMMWORD PTR [r14+0x180]
   83ce1:	62 d1 fd 48 6f 56 07                            	vmovdqa64 zmm2,ZMMWORD PTR [r14+0x1c0]
   83ce8:	62 d1 fd 48 6f 5e 08                            	vmovdqa64 zmm3,ZMMWORD PTR [r14+0x200]
   83cef:	62 d1 fd 48 6f 66 09                            	vmovdqa64 zmm4,ZMMWORD PTR [r14+0x240]
   83cf6:	c5 7e 7f 9c 24 40 02 00 00                      	vmovdqu YMMWORD PTR [rsp+0x240],ymm11
   83cff:	4c 89 a4 24 60 02 00 00                         	mov    QWORD PTR [rsp+0x260],r12
   83d07:	62 f1 f5 58 fb 6c 24 49                         	vpsubq zmm5,zmm1,QWORD BCST [rsp+0x248]
   83d0f:	62 f1 ed 58 fb 74 24 4a                         	vpsubq zmm6,zmm2,QWORD BCST [rsp+0x250]
   83d17:	62 f1 e5 58 fb 7c 24 4b                         	vpsubq zmm7,zmm3,QWORD BCST [rsp+0x258]
   83d1f:	62 71 dd 58 fb 44 24 4c                         	vpsubq zmm8,zmm4,QWORD BCST [rsp+0x260]
   83d27:	62 51 fd 48 d4 ce                               	vpaddq zmm9,zmm0,zmm14
   83d2d:	62 d1 ad 48 72 e1 34                            	vpsraq zmm10,zmm9,0x34
   83d34:	62 d1 d5 48 d4 ea                               	vpaddq zmm5,zmm5,zmm10
   83d3a:	62 f1 ad 48 72 e5 34                            	vpsraq zmm10,zmm5,0x34
   83d41:	62 d1 cd 48 d4 f2                               	vpaddq zmm6,zmm6,zmm10
   83d47:	62 f1 ad 48 72 e6 34                            	vpsraq zmm10,zmm6,0x34
   83d4e:	62 d1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm10
   83d54:	62 f1 ad 48 72 e7 34                            	vpsraq zmm10,zmm7,0x34
   83d5b:	62 51 bd 48 d4 c2                               	vpaddq zmm8,zmm8,zmm10
   83d61:	62 d3 bd 48 1e cc 01                            	vpcmpltuq k1,zmm8,zmm12
   83d68:	62 d1 d5 49 db cd                               	vpandq zmm1{k1},zmm5,zmm13
   83d6e:	62 d1 cd 49 db d5                               	vpandq zmm2{k1},zmm6,zmm13
   83d74:	62 d1 c5 49 db dd                               	vpandq zmm3{k1},zmm7,zmm13
   83d7a:	62 d1 fd 49 6f e0                               	vmovdqa64 zmm4{k1},zmm8
   83d80:	62 d1 b5 49 db c5                               	vpandq zmm0{k1},zmm9,zmm13
   83d86:	62 f1 dd 48 73 f4 10                            	vpsllq zmm4,zmm4,0x10
   83d8d:	62 f1 d5 48 73 f1 34                            	vpsllq zmm5,zmm1,0x34
   83d94:	62 f1 c5 48 73 f2 28                            	vpsllq zmm7,zmm2,0x28
   83d9b:	62 f1 f5 48 73 d1 0c                            	vpsrlq zmm1,zmm1,0xc
   83da2:	62 f1 cd 48 73 f3 1c                            	vpsllq zmm6,zmm3,0x1c
   83da9:	62 f1 ed 48 73 d2 18                            	vpsrlq zmm2,zmm2,0x18
   83db0:	62 f1 e5 48 73 d3 24                            	vpsrlq zmm3,zmm3,0x24
   83db7:	62 f1 d5 48 eb c0                               	vporq  zmm0,zmm5,zmm0
   83dbd:	62 f1 c5 48 eb c9                               	vporq  zmm1,zmm7,zmm1
   83dc3:	62 f1 dd 48 eb db                               	vporq  zmm3,zmm4,zmm3
   83dc9:	62 f1 cd 48 eb d2                               	vporq  zmm2,zmm6,zmm2
   83dcf:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   83dd5:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   83ddb:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   83de1:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   83de7:	62 f1 fd 48 6f dc                               	vmovdqa64 zmm3,zmm4
   83ded:	62 f2 85 48 7e d9                               	vpermt2q zmm3,zmm15,zmm1
   83df3:	62 f2 fd 40 7e e1                               	vpermt2q zmm4,zmm16,zmm1
   83df9:	62 f1 fd 48 6f c8                               	vmovdqa64 zmm1,zmm0
   83dff:	62 f2 85 48 7e ca                               	vpermt2q zmm1,zmm15,zmm2
   83e05:	62 f2 fd 40 7e c2                               	vpermt2q zmm0,zmm16,zmm2
   83e0b:	62 f3 e5 48 3a d1 01                            	vinserti64x4 zmm2,zmm3,ymm1,0x1
   83e12:	62 f3 e5 48 43 c9 ee                            	vshufi64x2 zmm1,zmm3,zmm1,0xee
   83e19:	62 f3 dd 48 3a d8 01                            	vinserti64x4 zmm3,zmm4,ymm0,0x1
   83e20:	62 f3 dd 48 43 c0 ee                            	vshufi64x2 zmm0,zmm4,zmm0,0xee
   83e27:	62 f1 fe 48 7f 54 24 09                         	vmovdqu64 ZMMWORD PTR [rsp+0x240],zmm2
   83e2f:	62 f1 fe 48 7f 4c 24 0a                         	vmovdqu64 ZMMWORD PTR [rsp+0x280],zmm1
   83e37:	62 f1 fe 48 7f 5c 24 0b                         	vmovdqu64 ZMMWORD PTR [rsp+0x2c0],zmm3
   83e3f:	62 f1 fe 48 7f 44 24 0c                         	vmovdqu64 ZMMWORD PTR [rsp+0x300],zmm0
   83e47:	eb 2e                                           	jmp    83e77 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x56c7>
   83e49:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   83e50:	31 c0                                           	xor    eax,eax
   83e52:	41 f6 d4                                        	not    r12b
   83e55:	45 22 a6 a1 02 00 00                            	and    r12b,BYTE PTR [r14+0x2a1]
   83e5c:	41 08 c4                                        	or     r12b,al
   83e5f:	45 88 a6 a1 02 00 00                            	mov    BYTE PTR [r14+0x2a1],r12b
   83e66:	49 ff c5                                        	inc    r13
   83e69:	49 83 c7 20                                     	add    r15,0x20
   83e6d:	49 83 fd 08                                     	cmp    r13,0x8
   83e71:	0f 84 99 e4 ff ff                               	je     82310 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3b60>
   83e77:	0f b6 84 24 80 06 00 00                         	movzx  eax,BYTE PTR [rsp+0x680]
   83e7f:	41 b4 01                                        	mov    r12b,0x1
   83e82:	44 89 e9                                        	mov    ecx,r13d
   83e85:	41 d2 e4                                        	shl    r12b,cl
   83e88:	44 0f a3 e8                                     	bt     eax,r13d
   83e8c:	73 d8                                           	jae    83e66 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x56b6>
   83e8e:	45 84 a6 a1 02 00 00                            	test   BYTE PTR [r14+0x2a1],r12b
   83e95:	0f 84 e5 00 00 00                               	je     83f80 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x57d0>
   83e9b:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   83e9f:	62 f1 fd 48 7f 44 24 1e                         	vmovdqa64 ZMMWORD PTR [rsp+0x780],zmm0
   83ea7:	4a 8d 84 7c 40 04 00 00                         	lea    rax,[rsp+r15*2+0x440]
   83eaf:	44 84 a4 24 c0 06 00 00                         	test   BYTE PTR [rsp+0x6c0],r12b
   83eb7:	0f 84 02 01 00 00                               	je     83fbf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x580f>
   83ebd:	c5 fc 10 00                                     	vmovups ymm0,YMMWORD PTR [rax]
   83ec1:	c4 a1 7e 6f 94 7c 60 04 00 00                   	vmovdqu ymm2,YMMWORD PTR [rsp+r15*2+0x460]
   83ecb:	c5 fe 6f 0d 0d 42 f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff8420d]        # 80e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x960>
   83ed3:	31 c0                                           	xor    eax,eax
   83ed5:	31 c9                                           	xor    ecx,ecx
   83ed7:	31 d2                                           	xor    edx,edx
   83ed9:	31 f6                                           	xor    esi,esi
   83edb:	4c 8d b4 24 20 13 00 00                         	lea    r14,[rsp+0x1320]
   83ee3:	48 8d 9c 24 00 07 00 00                         	lea    rbx,[rsp+0x700]
   83eeb:	c5 fc 29 84 24 c0 07 00 00                      	vmovaps YMMWORD PTR [rsp+0x7c0],ymm0
   83ef4:	c5 fd 7f 94 24 20 13 00 00                      	vmovdqa YMMWORD PTR [rsp+0x1320],ymm2
   83efd:	c5 fd 7f 8c 24 00 07 00 00                      	vmovdqa YMMWORD PTR [rsp+0x700],ymm1
   83f06:	49 2b 06                                        	sub    rax,QWORD PTR [r14]
   83f09:	49 1b 4e 08                                     	sbb    rcx,QWORD PTR [r14+0x8]
   83f0d:	49 1b 56 10                                     	sbb    rdx,QWORD PTR [r14+0x10]
   83f11:	49 1b 76 18                                     	sbb    rsi,QWORD PTR [r14+0x18]
   83f15:	4d 19 db                                        	sbb    r11,r11
   83f18:	48 8b 3b                                        	mov    rdi,QWORD PTR [rbx]
   83f1b:	4c 8b 43 08                                     	mov    r8,QWORD PTR [rbx+0x8]
   83f1f:	4c 8b 4b 10                                     	mov    r9,QWORD PTR [rbx+0x10]
   83f23:	4c 8b 53 18                                     	mov    r10,QWORD PTR [rbx+0x18]
   83f27:	4c 21 df                                        	and    rdi,r11
   83f2a:	4d 21 d8                                        	and    r8,r11
   83f2d:	4d 21 d9                                        	and    r9,r11
   83f30:	4d 21 da                                        	and    r10,r11
   83f33:	48 01 f8                                        	add    rax,rdi
   83f36:	4c 11 c1                                        	adc    rcx,r8
   83f39:	4c 11 ca                                        	adc    rdx,r9
   83f3c:	4c 11 d6                                        	adc    rsi,r10
   83f3f:	48 89 84 24 e0 07 00 00                         	mov    QWORD PTR [rsp+0x7e0],rax
   83f47:	48 89 8c 24 e8 07 00 00                         	mov    QWORD PTR [rsp+0x7e8],rcx
   83f4f:	48 89 94 24 f0 07 00 00                         	mov    QWORD PTR [rsp+0x7f0],rdx
   83f57:	48 89 b4 24 f8 07 00 00                         	mov    QWORD PTR [rsp+0x7f8],rsi
   83f5f:	c5 fd 6f 84 24 80 07 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x780]
   83f68:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   83f6d:	0f 85 7e 00 00 00                               	jne    83ff1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5841>
   83f73:	eb 68                                           	jmp    83fdd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x582d>
   83f75:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   83f80:	c4 a1 7e 6f 84 3c 80 09 00 00                   	vmovdqu ymm0,YMMWORD PTR [rsp+r15*1+0x980]
   83f8a:	c4 a1 7e 6f 8c 3c 40 02 00 00                   	vmovdqu ymm1,YMMWORD PTR [rsp+r15*1+0x240]
   83f94:	48 8d 84 24 a0 07 00 00                         	lea    rax,[rsp+0x7a0]
   83f9c:	c5 fd 7f 84 24 80 07 00 00                      	vmovdqa YMMWORD PTR [rsp+0x780],ymm0
   83fa5:	c5 fe 7f 08                                     	vmovdqu YMMWORD PTR [rax],ymm1
   83fa9:	4a 8d 84 7c 40 04 00 00                         	lea    rax,[rsp+r15*2+0x440]
   83fb1:	44 84 a4 24 c0 06 00 00                         	test   BYTE PTR [rsp+0x6c0],r12b
   83fb9:	0f 85 fe fe ff ff                               	jne    83ebd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x570d>
   83fbf:	62 f1 7c 48 10 00                               	vmovups zmm0,ZMMWORD PTR [rax]
   83fc5:	62 f1 7c 48 29 44 24 1f                         	vmovaps ZMMWORD PTR [rsp+0x7c0],zmm0
   83fcd:	c5 fd 6f 84 24 80 07 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x780]
   83fd6:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   83fdb:	75 14                                           	jne    83ff1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5841>
   83fdd:	c5 fd 6f 84 24 a0 07 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x7a0]
   83fe6:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   83feb:	0f 84 cb 00 00 00                               	je     840bc <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x590c>
   83ff1:	48 8d 84 24 a0 07 00 00                         	lea    rax,[rsp+0x7a0]
   83ff9:	c5 fd 6f 94 24 80 07 00 00                      	vmovdqa ymm2,YMMWORD PTR [rsp+0x780]
   84002:	c5 fe 6f 0d 96 40 f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff84096]        # 80a0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x920>
   8400a:	c5 fe 6f 00                                     	vmovdqu ymm0,YMMWORD PTR [rax]
   8400e:	48 8d 84 24 20 07 00 00                         	lea    rax,[rsp+0x720]
   84016:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   8401a:	c5 fd 7f 94 24 00 07 00 00                      	vmovdqa YMMWORD PTR [rsp+0x700],ymm2
   84023:	c5 fe 7f 48 20                                  	vmovdqu YMMWORD PTR [rax+0x20],ymm1
   84028:	4c 8d b4 24 20 13 00 00                         	lea    r14,[rsp+0x1320]
   84030:	48 8d b4 24 00 07 00 00                         	lea    rsi,[rsp+0x700]
   84038:	48 8d 94 24 c0 07 00 00                         	lea    rdx,[rsp+0x7c0]
   84040:	4c 89 f7                                        	mov    rdi,r14
   84043:	c5 f8 77                                        	vzeroupper
   84046:	e8 e5 31 00 00                                  	call   87230 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE10add_affineCsHW5vo2gROj_10zopro_core>
   8404b:	48 8d bc 24 80 0a 00 00                         	lea    rdi,[rsp+0xa80]
   84053:	4c 89 f6                                        	mov    rsi,r14
   84056:	e8 45 84 00 00                                  	call   8c4a0 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE9to_affineCsHW5vo2gROj_10zopro_core>
   8405b:	c5 fc 10 84 24 80 0a 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+0xa80]
   84064:	48 8d 84 24 a0 0a 00 00                         	lea    rax,[rsp+0xaa0]
   8406c:	4c 8b b4 24 00 01 00 00                         	mov    r14,QWORD PTR [rsp+0x100]
   84074:	c4 a1 7c 11 84 3c 80 09 00 00                   	vmovups YMMWORD PTR [rsp+r15*1+0x980],ymm0
   8407e:	c5 fc 10 00                                     	vmovups ymm0,YMMWORD PTR [rax]
   84082:	c4 a1 7c 11 84 3c 40 02 00 00                   	vmovups YMMWORD PTR [rsp+r15*1+0x240],ymm0
   8408c:	c5 fe 6f 84 24 80 0a 00 00                      	vmovdqu ymm0,YMMWORD PTR [rsp+0xa80]
   84095:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   8409a:	0f 85 b0 fd ff ff                               	jne    83e50 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x56a0>
   840a0:	c5 fe 6f 84 24 a0 0a 00 00                      	vmovdqu ymm0,YMMWORD PTR [rsp+0xaa0]
   840a9:	44 89 e0                                        	mov    eax,r12d
   840ac:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   840b1:	0f 85 99 fd ff ff                               	jne    83e50 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x56a0>
   840b7:	e9 96 fd ff ff                                  	jmp    83e52 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x56a2>
   840bc:	62 f1 fe 48 6f 05 a2 ed f8 ff                   	vmovdqu64 zmm0,ZMMWORD PTR [rip+0xfffffffffff8eda2]        # 12e68 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x45a8>
   840c6:	62 f1 fe 48 6f 0d 78 ed f8 ff                   	vmovdqu64 zmm1,ZMMWORD PTR [rip+0xfffffffffff8ed78]        # 12e48 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x4588>
   840d0:	62 f1 fe 48 7f 84 24 20 07 00 00                	vmovdqu64 ZMMWORD PTR [rsp+0x720],zmm0
   840db:	62 f1 fd 48 7f 4c 24 1c                         	vmovdqa64 ZMMWORD PTR [rsp+0x700],zmm1
   840e3:	e9 40 ff ff ff                                  	jmp    84028 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5878>
   840e8:	48 8b b4 24 e8 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xe8]
   840f0:	48 85 f6                                        	test   rsi,rsi
   840f3:	74 20                                           	je     84115 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5965>
   840f5:	48 8b bc 24 f0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xf0]
   840fd:	48 c1 e6 0a                                     	shl    rsi,0xa
   84101:	eb 05                                           	jmp    84108 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5958>
   84103:	be 00 64 00 00                                  	mov    esi,0x6400
   84108:	ba 40 00 00 00                                  	mov    edx,0x40
   8410d:	c5 f8 77                                        	vzeroupper
   84110:	e8 0b f4 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84115:	48 8b 84 24 b8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xb8]
   8411d:	48 85 c0                                        	test   rax,rax
   84120:	74 1a                                           	je     8413c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x598c>
   84122:	48 8d 34 85 00 00 00 00                         	lea    rsi,[rax*4+0x0]
   8412a:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   8412f:	ba 04 00 00 00                                  	mov    edx,0x4
   84134:	c5 f8 77                                        	vzeroupper
   84137:	e8 e4 f3 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   8413c:	48 8b b4 24 d0 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xd0]
   84144:	48 85 f6                                        	test   rsi,rsi
   84147:	74 19                                           	je     84162 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x59b2>
   84149:	48 8b bc 24 d8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xd8]
   84151:	48 c1 e6 03                                     	shl    rsi,0x3
   84155:	ba 08 00 00 00                                  	mov    edx,0x8
   8415a:	c5 f8 77                                        	vzeroupper
   8415d:	e8 be f3 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84162:	48 8b 74 24 78                                  	mov    rsi,QWORD PTR [rsp+0x78]
   84167:	48 85 f6                                        	test   rsi,rsi
   8416a:	74 15                                           	je     84181 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x59d1>
   8416c:	48 8b bc 24 80 00 00 00                         	mov    rdi,QWORD PTR [rsp+0x80]
   84174:	ba 01 00 00 00                                  	mov    edx,0x1
   84179:	c5 f8 77                                        	vzeroupper
   8417c:	e8 9f f3 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84181:	48 8b b4 24 68 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x168]
   84189:	48 85 f6                                        	test   rsi,rsi
   8418c:	74 16                                           	je     841a4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x59f4>
   8418e:	48 c1 e6 02                                     	shl    rsi,0x2
   84192:	48 8b 7c 24 58                                  	mov    rdi,QWORD PTR [rsp+0x58]
   84197:	ba 04 00 00 00                                  	mov    edx,0x4
   8419c:	c5 f8 77                                        	vzeroupper
   8419f:	e8 7c f3 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   841a4:	48 8b b4 24 a8 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x1a8]
   841ac:	48 85 f6                                        	test   rsi,rsi
   841af:	74 19                                           	je     841ca <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5a1a>
   841b1:	48 8b bc 24 b0 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x1b0]
   841b9:	48 c1 e6 03                                     	shl    rsi,0x3
   841bd:	ba 08 00 00 00                                  	mov    edx,0x8
   841c2:	c5 f8 77                                        	vzeroupper
   841c5:	e8 56 f3 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   841ca:	48 8b 5c 24 18                                  	mov    rbx,QWORD PTR [rsp+0x18]
   841cf:	49 89 de                                        	mov    r14,rbx
   841d2:	49 c1 e6 06                                     	shl    r14,0x6
   841d6:	bf 08 00 00 00                                  	mov    edi,0x8
   841db:	4c 89 f6                                        	mov    rsi,r14
   841de:	31 d2                                           	xor    edx,edx
   841e0:	c5 f8 77                                        	vzeroupper
   841e3:	e8 d8 49 01 00                                  	call   98bc0 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
   841e8:	48 85 c0                                        	test   rax,rax
   841eb:	0f 84 0b 0c 00 00                               	je     84dfc <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x664c>
   841f1:	49 89 c7                                        	mov    r15,rax
   841f4:	48 89 c2                                        	mov    rdx,rax
   841f7:	48 83 fb 01                                     	cmp    rbx,0x1
   841fb:	0f 84 4f 01 00 00                               	je     84350 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ba0>
   84201:	48 8b 4c 24 18                                  	mov    rcx,QWORD PTR [rsp+0x18]
   84206:	48 8d 84 24 60 02 00 00                         	lea    rax,[rsp+0x260]
   8420e:	4c 89 fa                                        	mov    rdx,r15
   84211:	48 8d 71 ff                                     	lea    rsi,[rcx-0x1]
   84215:	48 8d 79 fe                                     	lea    rdi,[rcx-0x2]
   84219:	89 f1                                           	mov    ecx,esi
   8421b:	83 e1 07                                        	and    ecx,0x7
   8421e:	48 83 ff 07                                     	cmp    rdi,0x7
   84222:	0f 82 00 01 00 00                               	jb     84328 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5b78>
   84228:	48 83 e6 f8                                     	and    rsi,0xfffffffffffffff8
   8422c:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   84230:	4c 89 fa                                        	mov    rdx,r15
   84233:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   84237:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   84240:	62 f1 fe 48 6f 4c 24 09                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x240]
   84248:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   8424c:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   84255:	62 f1 7c 48 10 54 24 09                         	vmovups zmm2,ZMMWORD PTR [rsp+0x240]
   8425d:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   84261:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   8426a:	62 f1 7c 48 10 5c 24 09                         	vmovups zmm3,ZMMWORD PTR [rsp+0x240]
   84272:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   84276:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   8427f:	62 f1 fe 48 7f 0a                               	vmovdqu64 ZMMWORD PTR [rdx],zmm1
   84285:	62 f1 7c 48 11 52 01                            	vmovups ZMMWORD PTR [rdx+0x40],zmm2
   8428c:	62 f1 7c 48 10 54 24 09                         	vmovups zmm2,ZMMWORD PTR [rsp+0x240]
   84294:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   84298:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   842a1:	62 f1 7c 48 11 5a 02                            	vmovups ZMMWORD PTR [rdx+0x80],zmm3
   842a8:	62 f1 7c 48 10 5c 24 09                         	vmovups zmm3,ZMMWORD PTR [rsp+0x240]
   842b0:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   842b4:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   842bd:	62 f1 7c 48 11 52 03                            	vmovups ZMMWORD PTR [rdx+0xc0],zmm2
   842c4:	62 f1 7c 48 10 54 24 09                         	vmovups zmm2,ZMMWORD PTR [rsp+0x240]
   842cc:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   842d0:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   842d9:	62 f1 7c 48 11 5a 04                            	vmovups ZMMWORD PTR [rdx+0x100],zmm3
   842e0:	62 f1 fe 48 6f 5c 24 09                         	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x240]
   842e8:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   842ec:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   842f5:	62 f1 7c 48 11 52 05                            	vmovups ZMMWORD PTR [rdx+0x140],zmm2
   842fc:	62 f1 fe 48 6f 54 24 09                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x240]
   84304:	62 f1 fe 48 7f 5a 06                            	vmovdqu64 ZMMWORD PTR [rdx+0x180],zmm3
   8430b:	62 f1 fe 48 7f 52 07                            	vmovdqu64 ZMMWORD PTR [rdx+0x1c0],zmm2
   84312:	48 81 c2 00 02 00 00                            	add    rdx,0x200
   84319:	48 83 c6 f8                                     	add    rsi,0xfffffffffffffff8
   8431d:	0f 85 10 ff ff ff                               	jne    84233 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5a83>
   84323:	48 85 c9                                        	test   rcx,rcx
   84326:	74 28                                           	je     84350 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ba0>
   84328:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   8432c:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   84330:	c5 fd 7f 84 24 40 02 00 00                      	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
   84339:	62 f1 fe 48 6f 4c 24 09                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x240]
   84341:	62 f1 fe 48 7f 0a                               	vmovdqu64 ZMMWORD PTR [rdx],zmm1
   84347:	48 83 c2 40                                     	add    rdx,0x40
   8434b:	48 ff c9                                        	dec    rcx
   8434e:	75 dc                                           	jne    8432c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5b7c>
   84350:	48 8b 8c 24 a0 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xa0]
   84358:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   8435c:	62 f1 fe 48 7f 02                               	vmovdqu64 ZMMWORD PTR [rdx],zmm0
   84362:	48 85 c9                                        	test   rcx,rcx
   84365:	0f 84 4d 05 00 00                               	je     848b8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6108>
   8436b:	c5 fd 6f 05 6d 3c f8 ff                         	vmovdqa ymm0,YMMWORD PTR [rip+0xfffffffffff83c6d]        # 7fe0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x860>
   84373:	62 f2 fd 48 59 0d 7b 31 f8 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff8317b]        # 74f8 <GCC_except_table746+0x184>
   8437d:	62 f2 fd 48 59 15 79 30 f8 ff                   	vpbroadcastq zmm2,QWORD PTR [rip+0xfffffffffff83079]        # 7400 <GCC_except_table746+0x8c>
   84387:	62 f2 fd 48 59 1d df 30 f8 ff                   	vpbroadcastq zmm3,QWORD PTR [rip+0xfffffffffff830df]        # 7470 <GCC_except_table746+0xfc>
   84391:	48 8b 84 24 98 00 00 00                         	mov    rax,QWORD PTR [rsp+0x98]
   84399:	48 69 c9 c0 02 00 00                            	imul   rcx,rcx,0x2c0
   843a0:	ba ff ff ff ff                                  	mov    edx,0xffffffff
   843a5:	48 01 c1                                        	add    rcx,rax
   843a8:	48 05 a1 02 00 00                               	add    rax,0x2a1
   843ae:	eb 34                                           	jmp    843e4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c34>
   843b0:	62 f3 fd 48 3b f4 01                            	vextracti64x4 ymm4,zmm6,0x1
   843b7:	c4 e3 35 46 e4 31                               	vperm2i128 ymm4,ymm9,ymm4,0x31
   843bd:	48 c1 e7 06                                     	shl    rdi,0x6
   843c1:	c4 c1 7e 7f 2c 3f                               	vmovdqu YMMWORD PTR [r15+rdi*1],ymm5
   843c7:	c4 c1 7e 7f 64 3f 20                            	vmovdqu YMMWORD PTR [r15+rdi*1+0x20],ymm4
   843ce:	48 05 c0 02 00 00                               	add    rax,0x2c0
   843d4:	48 81 c6 c0 02 00 00                            	add    rsi,0x2c0
   843db:	48 39 ce                                        	cmp    rsi,rcx
   843de:	0f 84 d4 04 00 00                               	je     848b8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6108>
   843e4:	62 f1 fd 48 6f a0 5f fd ff ff                   	vmovdqa64 zmm4,ZMMWORD PTR [rax-0x2a1]
   843ee:	62 f1 fd 48 6f a8 9f fd ff ff                   	vmovdqa64 zmm5,ZMMWORD PTR [rax-0x261]
   843f8:	62 71 fd 48 6f 80 df fd ff ff                   	vmovdqa64 zmm8,ZMMWORD PTR [rax-0x221]
   84402:	62 71 fd 48 6f 88 1f fe ff ff                   	vmovdqa64 zmm9,ZMMWORD PTR [rax-0x1e1]
   8440c:	62 71 fd 48 6f 90 5f fe ff ff                   	vmovdqa64 zmm10,ZMMWORD PTR [rax-0x1a1]
   84416:	c5 fe 7f 84 24 40 02 00 00                      	vmovdqu YMMWORD PTR [rsp+0x240],ymm0
   8441f:	4c 89 a4 24 60 02 00 00                         	mov    QWORD PTR [rsp+0x260],r12
   84427:	62 f1 d5 58 fb 74 24 49                         	vpsubq zmm6,zmm5,QWORD BCST [rsp+0x248]
   8442f:	62 f1 bd 58 fb 7c 24 4a                         	vpsubq zmm7,zmm8,QWORD BCST [rsp+0x250]
   84437:	62 71 b5 58 fb 5c 24 4b                         	vpsubq zmm11,zmm9,QWORD BCST [rsp+0x258]
   8443f:	62 71 ad 58 fb 64 24 4c                         	vpsubq zmm12,zmm10,QWORD BCST [rsp+0x260]
   84447:	62 e1 fd 48 6f a8 9f fe ff ff                   	vmovdqa64 zmm21,ZMMWORD PTR [rax-0x161]
   84451:	62 e1 fd 48 6f 80 5f ff ff ff                   	vmovdqa64 zmm16,ZMMWORD PTR [rax-0xa1]
   8445b:	62 e1 fd 48 6f 88 9f ff ff ff                   	vmovdqa64 zmm17,ZMMWORD PTR [rax-0x61]
   84465:	62 71 dd 48 d4 e9                               	vpaddq zmm13,zmm4,zmm1
   8446b:	62 d1 8d 48 72 e5 34                            	vpsraq zmm14,zmm13,0x34
   84472:	62 e1 d5 40 d4 d9                               	vpaddq zmm19,zmm21,zmm1
   84478:	62 d1 cd 48 d4 f6                               	vpaddq zmm6,zmm6,zmm14
   8447e:	62 b1 dd 40 72 e3 34                            	vpsraq zmm20,zmm19,0x34
   84485:	62 f1 8d 48 72 e6 34                            	vpsraq zmm14,zmm6,0x34
   8448c:	62 d1 c5 48 d4 fe                               	vpaddq zmm7,zmm7,zmm14
   84492:	62 f1 8d 48 72 e7 34                            	vpsraq zmm14,zmm7,0x34
   84499:	62 51 a5 48 d4 de                               	vpaddq zmm11,zmm11,zmm14
   8449f:	62 d1 8d 48 72 e3 34                            	vpsraq zmm14,zmm11,0x34
   844a6:	62 51 9d 48 d4 e6                               	vpaddq zmm12,zmm12,zmm14
   844ac:	62 f3 9d 48 1e cb 01                            	vpcmpltuq k1,zmm12,zmm3
   844b3:	62 f1 cd 49 db ea                               	vpandq zmm5{k1},zmm6,zmm2
   844b9:	62 71 c5 49 db c2                               	vpandq zmm8{k1},zmm7,zmm2
   844bf:	62 71 a5 49 db ca                               	vpandq zmm9{k1},zmm11,zmm2
   844c5:	62 f1 95 49 db e2                               	vpandq zmm4{k1},zmm13,zmm2
   844cb:	62 51 fd 49 6f d4                               	vmovdqa64 zmm10{k1},zmm12
   844d1:	62 f1 cd 48 73 f5 34                            	vpsllq zmm6,zmm5,0x34
   844d8:	62 d1 a5 48 73 f1 1c                            	vpsllq zmm11,zmm9,0x1c
   844df:	62 d1 c5 48 73 f0 28                            	vpsllq zmm7,zmm8,0x28
   844e6:	62 f1 d5 48 73 d5 0c                            	vpsrlq zmm5,zmm5,0xc
   844ed:	62 f1 cd 48 eb f4                               	vporq  zmm6,zmm6,zmm4
   844f3:	62 d1 dd 48 73 d0 18                            	vpsrlq zmm4,zmm8,0x18
   844fa:	62 d1 bd 48 73 f2 10                            	vpsllq zmm8,zmm10,0x10
   84501:	62 71 fd 48 6f 90 1f ff ff ff                   	vmovdqa64 zmm10,ZMMWORD PTR [rax-0xe1]
   8450b:	62 f1 c5 48 eb fd                               	vporq  zmm7,zmm7,zmm5
   84511:	62 71 a5 48 eb dc                               	vporq  zmm11,zmm11,zmm4
   84517:	62 d1 dd 48 73 d1 24                            	vpsrlq zmm4,zmm9,0x24
   8451e:	62 71 fd 48 6f 88 df fe ff ff                   	vmovdqa64 zmm9,ZMMWORD PTR [rax-0x121]
   84528:	c5 fe 7f 84 24 40 02 00 00                      	vmovdqu YMMWORD PTR [rsp+0x240],ymm0
   84531:	4c 89 a4 24 60 02 00 00                         	mov    QWORD PTR [rsp+0x260],r12
   84539:	62 71 b5 58 fb 6c 24 49                         	vpsubq zmm13,zmm9,QWORD BCST [rsp+0x248]
   84541:	62 71 ad 58 fb 74 24 4a                         	vpsubq zmm14,zmm10,QWORD BCST [rsp+0x250]
   84549:	62 71 fd 50 fb 7c 24 4b                         	vpsubq zmm15,zmm16,QWORD BCST [rsp+0x258]
   84551:	62 e1 f5 50 fb 54 24 4c                         	vpsubq zmm18,zmm17,QWORD BCST [rsp+0x260]
   84559:	8b 78 df                                        	mov    edi,DWORD PTR [rax-0x21]
   8455c:	62 71 bd 48 eb e4                               	vporq  zmm12,zmm8,zmm4
   84562:	62 71 cd 48 6c c7                               	vpunpcklqdq zmm8,zmm6,zmm7
   84568:	62 d1 a5 48 6c e4                               	vpunpcklqdq zmm4,zmm11,zmm12
   8456e:	62 31 95 48 d4 ec                               	vpaddq zmm13,zmm13,zmm20
   84574:	62 d1 dd 40 72 e5 34                            	vpsraq zmm20,zmm13,0x34
   8457b:	62 31 8d 48 d4 f4                               	vpaddq zmm14,zmm14,zmm20
   84581:	62 d1 dd 40 72 e6 34                            	vpsraq zmm20,zmm14,0x34
   84588:	62 31 85 48 d4 fc                               	vpaddq zmm15,zmm15,zmm20
   8458e:	62 d1 dd 40 72 e7 34                            	vpsraq zmm20,zmm15,0x34
   84595:	62 a1 ed 40 d4 d4                               	vpaddq zmm18,zmm18,zmm20
   8459b:	62 f3 ed 40 1e cb 01                            	vpcmpltuq k1,zmm18,zmm3
   845a2:	62 71 8d 49 db d2                               	vpandq zmm10{k1},zmm14,zmm2
   845a8:	62 e1 85 49 db c2                               	vpandq zmm16{k1},zmm15,zmm2
   845ae:	62 71 95 49 db ca                               	vpandq zmm9{k1},zmm13,zmm2
   845b4:	62 e1 e5 41 db ea                               	vpandq zmm21{k1},zmm19,zmm2
   845ba:	62 a1 fd 49 6f ca                               	vmovdqa64 zmm17{k1},zmm18
   845c0:	62 d1 d5 48 73 d2 18                            	vpsrlq zmm5,zmm10,0x18
   845c7:	62 b1 85 48 73 f0 1c                            	vpsllq zmm15,zmm16,0x1c
   845ce:	62 d1 95 48 73 f1 34                            	vpsllq zmm13,zmm9,0x34
   845d5:	62 d1 8d 48 73 f2 28                            	vpsllq zmm14,zmm10,0x28
   845dc:	62 d1 b5 48 73 d1 0c                            	vpsrlq zmm9,zmm9,0xc
   845e3:	62 b1 ad 48 73 f1 10                            	vpsllq zmm10,zmm17,0x10
   845ea:	62 71 85 48 eb fd                               	vporq  zmm15,zmm15,zmm5
   845f0:	62 b1 d5 48 73 d0 24                            	vpsrlq zmm5,zmm16,0x24
   845f7:	62 31 95 48 eb ed                               	vporq  zmm13,zmm13,zmm21
   845fd:	62 51 8d 48 eb f1                               	vporq  zmm14,zmm14,zmm9
   84603:	62 e1 ad 48 eb c5                               	vporq  zmm16,zmm10,zmm5
   84609:	62 51 95 48 6c ce                               	vpunpcklqdq zmm9,zmm13,zmm14
   8460f:	62 b1 85 48 6c e8                               	vpunpcklqdq zmm5,zmm15,zmm16
   84615:	48 39 d7                                        	cmp    rdi,rdx
   84618:	74 40                                           	je     8465a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5eaa>
   8461a:	48 39 7c 24 18                                  	cmp    QWORD PTR [rsp+0x18],rdi
   8461f:	0f 86 bd 06 00 00                               	jbe    84ce2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6532>
   84625:	f6 00 01                                        	test   BYTE PTR [rax],0x1
   84628:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   8462d:	74 0a                                           	je     84639 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e89>
   8462f:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   84635:	74 0b                                           	je     84642 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e92>
   84637:	eb 0f                                           	jmp    84648 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e98>
   84639:	62 e3 3d 28 38 cc 01                            	vinserti32x4 ymm17,ymm8,xmm4,0x1
   84640:	75 06                                           	jne    84648 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e98>
   84642:	c4 63 35 38 d5 01                               	vinserti128 ymm10,ymm9,xmm5,0x1
   84648:	48 c1 e7 06                                     	shl    rdi,0x6
   8464c:	62 c1 fe 28 7f 0c 3f                            	vmovdqu64 YMMWORD PTR [r15+rdi*1],ymm17
   84653:	c4 41 7e 7f 54 3f 20                            	vmovdqu YMMWORD PTR [r15+rdi*1+0x20],ymm10
   8465a:	48 8d b0 5f fd ff ff                            	lea    rsi,[rax-0x2a1]
   84661:	62 71 cd 48 6d d7                               	vpunpckhqdq zmm10,zmm6,zmm7
   84667:	62 d1 a5 48 6d fc                               	vpunpckhqdq zmm7,zmm11,zmm12
   8466d:	62 51 95 48 6d de                               	vpunpckhqdq zmm11,zmm13,zmm14
   84673:	62 b1 85 48 6d f0                               	vpunpckhqdq zmm6,zmm15,zmm16
   84679:	8b be 84 02 00 00                               	mov    edi,DWORD PTR [rsi+0x284]
   8467f:	48 39 d7                                        	cmp    rdi,rdx
   84682:	74 3d                                           	je     846c1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f11>
   84684:	48 39 7c 24 18                                  	cmp    QWORD PTR [rsp+0x18],rdi
   84689:	0f 86 53 06 00 00                               	jbe    84ce2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6532>
   8468f:	f6 00 02                                        	test   BYTE PTR [rax],0x2
   84692:	c4 41 19 ef e4                                  	vpxor  xmm12,xmm12,xmm12
   84697:	74 09                                           	je     846a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ef2>
   84699:	c4 41 11 ef ed                                  	vpxor  xmm13,xmm13,xmm13
   8469e:	74 0a                                           	je     846aa <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5efa>
   846a0:	eb 0e                                           	jmp    846b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f00>
   846a2:	c4 63 2d 38 ef 01                               	vinserti128 ymm13,ymm10,xmm7,0x1
   846a8:	75 06                                           	jne    846b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f00>
   846aa:	c4 63 25 38 e6 01                               	vinserti128 ymm12,ymm11,xmm6,0x1
   846b0:	48 c1 e7 06                                     	shl    rdi,0x6
   846b4:	c4 41 7e 7f 2c 3f                               	vmovdqu YMMWORD PTR [r15+rdi*1],ymm13
   846ba:	c4 41 7e 7f 64 3f 20                            	vmovdqu YMMWORD PTR [r15+rdi*1+0x20],ymm12
   846c1:	8b be 88 02 00 00                               	mov    edi,DWORD PTR [rsi+0x288]
   846c7:	48 39 d7                                        	cmp    rdi,rdx
   846ca:	74 3d                                           	je     84709 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f59>
   846cc:	48 39 7c 24 18                                  	cmp    QWORD PTR [rsp+0x18],rdi
   846d1:	0f 86 0b 06 00 00                               	jbe    84ce2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6532>
   846d7:	f6 00 04                                        	test   BYTE PTR [rax],0x4
   846da:	c4 41 19 ef e4                                  	vpxor  xmm12,xmm12,xmm12
   846df:	74 09                                           	je     846ea <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f3a>
   846e1:	c4 41 11 ef ed                                  	vpxor  xmm13,xmm13,xmm13
   846e6:	74 0a                                           	je     846f2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f42>
   846e8:	eb 0e                                           	jmp    846f8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f48>
   846ea:	c4 63 3d 46 ec 31                               	vperm2i128 ymm13,ymm8,ymm4,0x31
   846f0:	75 06                                           	jne    846f8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f48>
   846f2:	c4 63 35 46 e5 31                               	vperm2i128 ymm12,ymm9,ymm5,0x31
   846f8:	48 c1 e7 06                                     	shl    rdi,0x6
   846fc:	c4 41 7e 7f 2c 3f                               	vmovdqu YMMWORD PTR [r15+rdi*1],ymm13
   84702:	c4 41 7e 7f 64 3f 20                            	vmovdqu YMMWORD PTR [r15+rdi*1+0x20],ymm12
   84709:	8b be 8c 02 00 00                               	mov    edi,DWORD PTR [rsi+0x28c]
   8470f:	48 39 d7                                        	cmp    rdi,rdx
   84712:	74 3d                                           	je     84751 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5fa1>
   84714:	48 39 7c 24 18                                  	cmp    QWORD PTR [rsp+0x18],rdi
   84719:	0f 86 c3 05 00 00                               	jbe    84ce2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6532>
   8471f:	f6 00 08                                        	test   BYTE PTR [rax],0x8
   84722:	c4 41 19 ef e4                                  	vpxor  xmm12,xmm12,xmm12
   84727:	74 09                                           	je     84732 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f82>
   84729:	c4 41 11 ef ed                                  	vpxor  xmm13,xmm13,xmm13
   8472e:	74 0a                                           	je     8473a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f8a>
   84730:	eb 0e                                           	jmp    84740 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f90>
   84732:	c4 63 2d 46 ef 31                               	vperm2i128 ymm13,ymm10,ymm7,0x31
   84738:	75 06                                           	jne    84740 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f90>
   8473a:	c4 63 25 46 e6 31                               	vperm2i128 ymm12,ymm11,ymm6,0x31
   84740:	48 c1 e7 06                                     	shl    rdi,0x6
   84744:	c4 41 7e 7f 2c 3f                               	vmovdqu YMMWORD PTR [r15+rdi*1],ymm13
   8474a:	c4 41 7e 7f 64 3f 20                            	vmovdqu YMMWORD PTR [r15+rdi*1+0x20],ymm12
   84751:	8b be 90 02 00 00                               	mov    edi,DWORD PTR [rsi+0x290]
   84757:	62 53 fd 48 3b c4 01                            	vextracti64x4 ymm12,zmm8,0x1
   8475e:	62 53 fd 48 3b c8 01                            	vextracti64x4 ymm8,zmm9,0x1
   84765:	48 39 d7                                        	cmp    rdi,rdx
   84768:	74 4b                                           	je     847b5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6005>
   8476a:	48 39 7c 24 18                                  	cmp    QWORD PTR [rsp+0x18],rdi
   8476f:	0f 86 6d 05 00 00                               	jbe    84ce2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6532>
   84775:	f6 00 10                                        	test   BYTE PTR [rax],0x10
   84778:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   8477d:	74 09                                           	je     84788 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5fd8>
   8477f:	c4 41 11 ef ed                                  	vpxor  xmm13,xmm13,xmm13
   84784:	74 11                                           	je     84797 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5fe7>
   84786:	eb 1c                                           	jmp    847a4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ff4>
   84788:	62 d3 7d 48 39 e5 02                            	vextracti32x4 xmm13,zmm4,0x2
   8478f:	c4 43 1d 38 ed 01                               	vinserti128 ymm13,ymm12,xmm13,0x1
   84795:	75 0d                                           	jne    847a4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ff4>
   84797:	62 d3 7d 48 39 e9 02                            	vextracti32x4 xmm9,zmm5,0x2
   8479e:	c4 43 3d 38 c9 01                               	vinserti128 ymm9,ymm8,xmm9,0x1
   847a4:	48 c1 e7 06                                     	shl    rdi,0x6
   847a8:	c4 41 7e 7f 2c 3f                               	vmovdqu YMMWORD PTR [r15+rdi*1],ymm13
   847ae:	c4 41 7e 7f 4c 3f 20                            	vmovdqu YMMWORD PTR [r15+rdi*1+0x20],ymm9
   847b5:	8b be 94 02 00 00                               	mov    edi,DWORD PTR [rsi+0x294]
   847bb:	62 53 fd 48 3b d2 01                            	vextracti64x4 ymm10,zmm10,0x1
   847c2:	62 53 fd 48 3b d9 01                            	vextracti64x4 ymm9,zmm11,0x1
   847c9:	48 39 d7                                        	cmp    rdi,rdx
   847cc:	74 4b                                           	je     84819 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6069>
   847ce:	48 39 7c 24 18                                  	cmp    QWORD PTR [rsp+0x18],rdi
   847d3:	0f 86 09 05 00 00                               	jbe    84ce2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6532>
   847d9:	f6 00 20                                        	test   BYTE PTR [rax],0x20
   847dc:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   847e1:	74 09                                           	je     847ec <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x603c>
   847e3:	c4 41 11 ef ed                                  	vpxor  xmm13,xmm13,xmm13
   847e8:	74 11                                           	je     847fb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x604b>
   847ea:	eb 1c                                           	jmp    84808 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6058>
   847ec:	62 d3 7d 48 39 fd 02                            	vextracti32x4 xmm13,zmm7,0x2
   847f3:	c4 43 2d 38 ed 01                               	vinserti128 ymm13,ymm10,xmm13,0x1
   847f9:	75 0d                                           	jne    84808 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6058>
   847fb:	62 d3 7d 48 39 f3 02                            	vextracti32x4 xmm11,zmm6,0x2
   84802:	c4 43 35 38 db 01                               	vinserti128 ymm11,ymm9,xmm11,0x1
   84808:	48 c1 e7 06                                     	shl    rdi,0x6
   8480c:	c4 41 7e 7f 2c 3f                               	vmovdqu YMMWORD PTR [r15+rdi*1],ymm13
   84812:	c4 41 7e 7f 5c 3f 20                            	vmovdqu YMMWORD PTR [r15+rdi*1+0x20],ymm11
   84819:	8b be 98 02 00 00                               	mov    edi,DWORD PTR [rsi+0x298]
   8481f:	48 39 d7                                        	cmp    rdi,rdx
   84822:	74 4a                                           	je     8486e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60be>
   84824:	48 39 7c 24 18                                  	cmp    QWORD PTR [rsp+0x18],rdi
   84829:	0f 86 b3 04 00 00                               	jbe    84ce2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6532>
   8482f:	f6 00 40                                        	test   BYTE PTR [rax],0x40
   84832:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   84837:	74 08                                           	je     84841 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6091>
   84839:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   8483d:	74 11                                           	je     84850 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60a0>
   8483f:	eb 1c                                           	jmp    8485d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60ad>
   84841:	62 f3 fd 48 3b e4 01                            	vextracti64x4 ymm4,zmm4,0x1
   84848:	c4 e3 1d 46 e4 31                               	vperm2i128 ymm4,ymm12,ymm4,0x31
   8484e:	75 0d                                           	jne    8485d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60ad>
   84850:	62 f3 fd 48 3b ed 01                            	vextracti64x4 ymm5,zmm5,0x1
   84857:	c4 63 3d 46 dd 31                               	vperm2i128 ymm11,ymm8,ymm5,0x31
   8485d:	48 c1 e7 06                                     	shl    rdi,0x6
   84861:	c4 c1 7e 7f 24 3f                               	vmovdqu YMMWORD PTR [r15+rdi*1],ymm4
   84867:	c4 41 7e 7f 5c 3f 20                            	vmovdqu YMMWORD PTR [r15+rdi*1+0x20],ymm11
   8486e:	8b be 9c 02 00 00                               	mov    edi,DWORD PTR [rsi+0x29c]
   84874:	48 39 d7                                        	cmp    rdi,rdx
   84877:	0f 84 51 fb ff ff                               	je     843ce <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c1e>
   8487d:	48 39 7c 24 18                                  	cmp    QWORD PTR [rsp+0x18],rdi
   84882:	0f 86 5a 04 00 00                               	jbe    84ce2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6532>
   84888:	80 38 00                                        	cmp    BYTE PTR [rax],0x0
   8488b:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   8488f:	79 0f                                           	jns    848a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60f0>
   84891:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   84895:	0f 88 22 fb ff ff                               	js     843bd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c0d>
   8489b:	e9 10 fb ff ff                                  	jmp    843b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c00>
   848a0:	62 f3 fd 48 3b fd 01                            	vextracti64x4 ymm5,zmm7,0x1
   848a7:	c4 e3 2d 46 ed 31                               	vperm2i128 ymm5,ymm10,ymm5,0x31
   848ad:	0f 88 0a fb ff ff                               	js     843bd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c0d>
   848b3:	e9 f8 fa ff ff                                  	jmp    843b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c00>
   848b8:	48 8b 84 24 90 00 00 00                         	mov    rax,QWORD PTR [rsp+0x90]
   848c0:	48 85 c0                                        	test   rax,rax
   848c3:	74 1c                                           	je     848e1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6131>
   848c5:	48 8b bc 24 98 00 00 00                         	mov    rdi,QWORD PTR [rsp+0x98]
   848cd:	48 69 f0 c0 02 00 00                            	imul   rsi,rax,0x2c0
   848d4:	ba 40 00 00 00                                  	mov    edx,0x40
   848d9:	c5 f8 77                                        	vzeroupper
   848dc:	e8 3f ec f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   848e1:	48 8b 5c 24 48                                  	mov    rbx,QWORD PTR [rsp+0x48]
   848e6:	4c 89 b4 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],r14
   848ee:	48 85 db                                        	test   rbx,rbx
   848f1:	74 37                                           	je     8492a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x617a>
   848f3:	48 8d 34 9d 00 00 00 00                         	lea    rsi,[rbx*4+0x0]
   848fb:	bf 04 00 00 00                                  	mov    edi,0x4
   84900:	31 d2                                           	xor    edx,edx
   84902:	c5 f8 77                                        	vzeroupper
   84905:	e8 b6 42 01 00                                  	call   98bc0 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
   8490a:	48 85 c0                                        	test   rax,rax
   8490d:	0f 84 f8 04 00 00                               	je     84e0b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x665b>
   84913:	48 8b bc 24 88 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x188]
   8491b:	49 89 c6                                        	mov    r14,rax
   8491e:	83 fb 08                                        	cmp    ebx,0x8
   84921:	73 1a                                           	jae    8493d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x618d>
   84923:	31 c0                                           	xor    eax,eax
   84925:	e9 e3 00 00 00                                  	jmp    84a0d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x625d>
   8492a:	48 8b bc 24 88 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x188]
   84932:	41 be 04 00 00 00                               	mov    r14d,0x4
   84938:	e9 e1 00 00 00                                  	jmp    84a1e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x626e>
   8493d:	83 fb 40                                        	cmp    ebx,0x40
   84940:	73 07                                           	jae    84949 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6199>
   84942:	31 c0                                           	xor    eax,eax
   84944:	e9 89 00 00 00                                  	jmp    849d2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6222>
   84949:	62 f1 fd 48 6f 05 ad 32 f8 ff                   	vmovdqa64 zmm0,ZMMWORD PTR [rip+0xfffffffffff832ad]        # 7c00 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x480>
   84953:	62 f2 7d 48 58 0d 2b 39 f8 ff                   	vpbroadcastd zmm1,DWORD PTR [rip+0xfffffffffff8392b]        # 8288 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb08>
   8495d:	62 f2 7d 48 58 15 39 39 f8 ff                   	vpbroadcastd zmm2,DWORD PTR [rip+0xfffffffffff83939]        # 82a0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb20>
   84967:	62 f2 7d 48 58 1d 3f 39 f8 ff                   	vpbroadcastd zmm3,DWORD PTR [rip+0xfffffffffff8393f]        # 82b0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb30>
   84971:	62 f2 7d 48 58 25 45 39 f8 ff                   	vpbroadcastd zmm4,DWORD PTR [rip+0xfffffffffff83945]        # 82c0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb40>
   8497b:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
   84980:	83 e0 c0                                        	and    eax,0xffffffc0
   84983:	31 c9                                           	xor    ecx,ecx
   84985:	62 f1 7d 48 fe e9                               	vpaddd zmm5,zmm0,zmm1
   8498b:	62 f1 7d 48 fe f2                               	vpaddd zmm6,zmm0,zmm2
   84991:	62 f1 7d 48 fe fb                               	vpaddd zmm7,zmm0,zmm3
   84997:	62 d1 fe 48 7f 04 8e                            	vmovdqu64 ZMMWORD PTR [r14+rcx*4],zmm0
   8499e:	62 f1 7d 48 fe c4                               	vpaddd zmm0,zmm0,zmm4
   849a4:	62 d1 fe 48 7f 6c 8e 01                         	vmovdqu64 ZMMWORD PTR [r14+rcx*4+0x40],zmm5
   849ac:	62 d1 fe 48 7f 74 8e 02                         	vmovdqu64 ZMMWORD PTR [r14+rcx*4+0x80],zmm6
   849b4:	62 d1 fe 48 7f 7c 8e 03                         	vmovdqu64 ZMMWORD PTR [r14+rcx*4+0xc0],zmm7
   849bc:	48 83 c1 40                                     	add    rcx,0x40
   849c0:	48 39 c8                                        	cmp    rax,rcx
   849c3:	75 c0                                           	jne    84985 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x61d5>
   849c5:	39 44 24 48                                     	cmp    DWORD PTR [rsp+0x48],eax
   849c9:	74 53                                           	je     84a1e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x626e>
   849cb:	f6 44 24 18 38                                  	test   BYTE PTR [rsp+0x18],0x38
   849d0:	74 3b                                           	je     84a0d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x625d>
   849d2:	48 89 c1                                        	mov    rcx,rax
   849d5:	62 f2 7d 28 7c c1                               	vpbroadcastd ymm0,ecx
   849db:	c5 fd eb 05 bd 35 f8 ff                         	vpor   ymm0,ymm0,YMMWORD PTR [rip+0xfffffffffff835bd]        # 7fa0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x820>
   849e3:	c4 e2 7d 58 0d b8 38 f8 ff                      	vpbroadcastd ymm1,DWORD PTR [rip+0xfffffffffff838b8]        # 82a4 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb24>
   849ec:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
   849f1:	83 e0 f8                                        	and    eax,0xfffffff8
   849f4:	c4 c1 7e 7f 04 8e                               	vmovdqu YMMWORD PTR [r14+rcx*4],ymm0
   849fa:	48 83 c1 08                                     	add    rcx,0x8
   849fe:	c5 fd fe c1                                     	vpaddd ymm0,ymm0,ymm1
   84a02:	48 39 c8                                        	cmp    rax,rcx
   84a05:	75 ed                                           	jne    849f4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6244>
   84a07:	39 44 24 48                                     	cmp    DWORD PTR [rsp+0x48],eax
   84a0b:	74 11                                           	je     84a1e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x626e>
   84a0d:	48 8b 4c 24 48                                  	mov    rcx,QWORD PTR [rsp+0x48]
   84a12:	41 89 04 86                                     	mov    DWORD PTR [r14+rax*4],eax
   84a16:	48 ff c0                                        	inc    rax
   84a19:	48 39 c1                                        	cmp    rcx,rax
   84a1c:	75 f4                                           	jne    84a12 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6262>
   84a1e:	4c 8b a4 24 98 01 00 00                         	mov    r12,QWORD PTR [rsp+0x198]
   84a26:	48 8b 5c 24 48                                  	mov    rbx,QWORD PTR [rsp+0x48]
   84a2b:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
   84a30:	4c 89 fe                                        	mov    rsi,r15
   84a33:	4c 89 f1                                        	mov    rcx,r14
   84a36:	4d 89 e1                                        	mov    r9,r12
   84a39:	49 89 d8                                        	mov    r8,rbx
   84a3c:	ff 74 24 70                                     	push   QWORD PTR [rsp+0x70]
   84a40:	ff b4 24 a8 01 00 00                            	push   QWORD PTR [rsp+0x1a8]
   84a47:	c5 f8 77                                        	vzeroupper
   84a4a:	e8 c1 0a 00 00                                  	call   85510 <_RINvNtCsHW5vo2gROj_10zopro_core3msm12group_affineNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEB4_>
   84a4f:	48 83 c4 10                                     	add    rsp,0x10
   84a53:	48 85 db                                        	test   rbx,rbx
   84a56:	74 15                                           	je     84a6d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62bd>
   84a58:	48 8b b4 24 b0 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xb0]
   84a60:	ba 04 00 00 00                                  	mov    edx,0x4
   84a65:	4c 89 f7                                        	mov    rdi,r14
   84a68:	e8 b3 ea f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84a6d:	48 8b b4 24 00 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x100]
   84a75:	ba 08 00 00 00                                  	mov    edx,0x8
   84a7a:	4c 89 ff                                        	mov    rdi,r15
   84a7d:	e8 9e ea f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84a82:	48 8b b4 24 90 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x190]
   84a8a:	48 85 f6                                        	test   rsi,rsi
   84a8d:	74 11                                           	je     84aa0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62f0>
   84a8f:	48 c1 e6 03                                     	shl    rsi,0x3
   84a93:	ba 08 00 00 00                                  	mov    edx,0x8
   84a98:	4c 89 e7                                        	mov    rdi,r12
   84a9b:	e8 80 ea f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84aa0:	48 8b 7c 24 70                                  	mov    rdi,QWORD PTR [rsp+0x70]
   84aa5:	e9 59 a6 ff ff                                  	jmp    7f103 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x953>
   84aaa:	48 8d 0d a7 7f 01 00                            	lea    rcx,[rip+0x17fa7]        # 9ca58 <__frame_dummy_init_array_entry+0x29f8>
   84ab1:	be 00 08 00 00                                  	mov    esi,0x800
   84ab6:	31 ff                                           	xor    edi,edi
   84ab8:	4c 89 ea                                        	mov    rdx,r13
   84abb:	e8 90 d5 fa ff                                  	call   32050 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
   84ac0:	e9 58 03 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84ac5:	48 8d 0d dc 7d 01 00                            	lea    rcx,[rip+0x17ddc]        # 9c8a8 <__frame_dummy_init_array_entry+0x2848>
   84acc:	48 8d bc 24 78 06 00 00                         	lea    rdi,[rsp+0x678]
   84ad4:	48 8d b4 24 40 02 00 00                         	lea    rsi,[rsp+0x240]
   84adc:	31 d2                                           	xor    edx,edx
   84ade:	e8 5f cc fa ff                                  	call   31742 <_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedjjEB4_>
   84ae3:	48 8d 3d 3b e4 f8 ff                            	lea    rdi,[rip+0xfffffffffff8e43b]        # 12f25 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x4665>
   84aea:	48 8d 15 cf 7d 01 00                            	lea    rdx,[rip+0x17dcf]        # 9c8c0 <__frame_dummy_init_array_entry+0x2860>
   84af1:	be 2d 00 00 00                                  	mov    esi,0x2d
   84af6:	e8 25 d6 fa ff                                  	call   32120 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
   84afb:	48 8d 3d 50 e4 f8 ff                            	lea    rdi,[rip+0xfffffffffff8e450]        # 12f52 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x4692>
   84b02:	48 8d 15 cf 7d 01 00                            	lea    rdx,[rip+0x17dcf]        # 9c8d8 <__frame_dummy_init_array_entry+0x2878>
   84b09:	be 18 00 00 00                                  	mov    esi,0x18
   84b0e:	e8 0d d6 fa ff                                  	call   32120 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
   84b13:	4c 8b 64 24 58                                  	mov    r12,QWORD PTR [rsp+0x58]
   84b18:	48 8d 0d a9 7e 01 00                            	lea    rcx,[rip+0x17ea9]        # 9c9c8 <__frame_dummy_init_array_entry+0x2968>
   84b1f:	48 89 da                                        	mov    rdx,rbx
   84b22:	c5 f8 77                                        	vzeroupper
   84b25:	e8 26 d5 fa ff                                  	call   32050 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
   84b2a:	e9 ee 02 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84b2f:	b3 01                                           	mov    bl,0x1
   84b31:	4c 8b 7c 24 28                                  	mov    r15,QWORD PTR [rsp+0x28]
   84b36:	48 8d 3d 63 e4 f8 ff                            	lea    rdi,[rip+0xfffffffffff8e463]        # 12fa0 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x46e0>
   84b3d:	48 8d 15 9c 7e 01 00                            	lea    rdx,[rip+0x17e9c]        # 9c9e0 <__frame_dummy_init_array_entry+0x2980>
   84b44:	be 1c 00 00 00                                  	mov    esi,0x1c
   84b49:	e8 d2 d5 fa ff                                  	call   32120 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
   84b4e:	e9 ca 02 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84b53:	48 8d 0d b6 7e 01 00                            	lea    rcx,[rip+0x17eb6]        # 9ca10 <__frame_dummy_init_array_entry+0x29b0>
   84b5a:	31 ff                                           	xor    edi,edi
   84b5c:	4c 89 e6                                        	mov    rsi,r12
   84b5f:	e8 ec d4 fa ff                                  	call   32050 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
   84b64:	e9 b4 02 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84b69:	4c 89 fe                                        	mov    rsi,r15
   84b6c:	48 8d 15 dd 7b 01 00                            	lea    rdx,[rip+0x17bdd]        # 9c750 <__frame_dummy_init_array_entry+0x26f0>
   84b73:	eb 1c                                           	jmp    84b91 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63e1>
   84b75:	48 8d 15 bc 7b 01 00                            	lea    rdx,[rip+0x17bbc]        # 9c738 <__frame_dummy_init_array_entry+0x26d8>
   84b7c:	eb 13                                           	jmp    84b91 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63e1>
   84b7e:	48 89 de                                        	mov    rsi,rbx
   84b81:	48 8d 15 98 7b 01 00                            	lea    rdx,[rip+0x17b98]        # 9c720 <__frame_dummy_init_array_entry+0x26c0>
   84b88:	eb 07                                           	jmp    84b91 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63e1>
   84b8a:	48 8d 15 d7 7b 01 00                            	lea    rdx,[rip+0x17bd7]        # 9c768 <__frame_dummy_init_array_entry+0x2708>
   84b91:	b3 01                                           	mov    bl,0x1
   84b93:	c5 f8 77                                        	vzeroupper
   84b96:	e8 b9 c7 fa ff                                  	call   31354 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   84b9b:	e9 7d 02 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84ba0:	48 8b 7c 24 40                                  	mov    rdi,QWORD PTR [rsp+0x40]
   84ba5:	48 8d 94 24 40 02 00 00                         	lea    rdx,[rsp+0x240]
   84bad:	c5 f8 77                                        	vzeroupper
   84bb0:	e8 db 71 ff ff                                  	call   7bd90 <_RINvNtNtNtCsgxBkk5gSRhY_4core5slice4sort8unstable7ipnsortmNCINvMB6_Sm20sort_unstable_by_keyTINtNtB8_3cmp7ReversehEmENCNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fills_0E0EB20_>
   84bb5:	e9 c3 a9 ff ff                                  	jmp    7f57d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xdcd>
   84bba:	49 8d 7a ff                                     	lea    rdi,[r10-0x1]
   84bbe:	48 8d 15 ab 7e 01 00                            	lea    rdx,[rip+0x17eab]        # 9ca70 <__frame_dummy_init_array_entry+0x2a10>
   84bc5:	be 00 08 00 00                                  	mov    esi,0x800
   84bca:	c5 f8 77                                        	vzeroupper
   84bcd:	e8 82 c7 fa ff                                  	call   31354 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   84bd2:	e9 46 02 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84bd7:	48 8b 74 24 20                                  	mov    rsi,QWORD PTR [rsp+0x20]
   84bdc:	48 8d 05 e5 7b 01 00                            	lea    rax,[rip+0x17be5]        # 9c7c8 <__frame_dummy_init_array_entry+0x2768>
   84be3:	eb 19                                           	jmp    84bfe <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x644e>
   84be5:	48 89 c6                                        	mov    rsi,rax
   84be8:	48 8d 05 a9 7b 01 00                            	lea    rax,[rip+0x17ba9]        # 9c798 <__frame_dummy_init_array_entry+0x2738>
   84bef:	eb 0d                                           	jmp    84bfe <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x644e>
   84bf1:	4c 89 c7                                        	mov    rdi,r8
   84bf4:	4c 89 fe                                        	mov    rsi,r15
   84bf7:	48 8d 05 b2 7b 01 00                            	lea    rax,[rip+0x17bb2]        # 9c7b0 <__frame_dummy_init_array_entry+0x2750>
   84bfe:	48 89 44 24 10                                  	mov    QWORD PTR [rsp+0x10],rax
   84c03:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
   84c08:	4c 8b 64 24 58                                  	mov    r12,QWORD PTR [rsp+0x58]
   84c0d:	c5 f8 77                                        	vzeroupper
   84c10:	e8 3f c7 fa ff                                  	call   31354 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   84c15:	e9 03 02 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84c1a:	49 ff ce                                        	dec    r14
   84c1d:	b8 00 08 00 00                                  	mov    eax,0x800
   84c22:	48 89 44 24 60                                  	mov    QWORD PTR [rsp+0x60],rax
   84c27:	4c 89 f7                                        	mov    rdi,r14
   84c2a:	41 b6 01                                        	mov    r14b,0x1
   84c2d:	48 8b 74 24 60                                  	mov    rsi,QWORD PTR [rsp+0x60]
   84c32:	48 8b 94 24 00 01 00 00                         	mov    rdx,QWORD PTR [rsp+0x100]
   84c3a:	c5 f8 77                                        	vzeroupper
   84c3d:	e8 12 c7 fa ff                                  	call   31354 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   84c42:	e9 d6 01 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84c47:	48 8d 05 62 7d 01 00                            	lea    rax,[rip+0x17d62]        # 9c9b0 <__frame_dummy_init_array_entry+0x2950>
   84c4e:	62 71 fd 48 7f 5c 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm11
   84c56:	62 71 fd 48 7f 54 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm10
   84c5e:	62 f1 fd 48 7f 74 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm6
   84c66:	62 f1 fd 48 7f 7c 24 0c                         	vmovdqa64 ZMMWORD PTR [rsp+0x300],zmm7
   84c6e:	62 f1 fd 48 7f 44 24 0d                         	vmovdqa64 ZMMWORD PTR [rsp+0x340],zmm0
   84c76:	eb 0a                                           	jmp    84c82 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x64d2>
   84c78:	48 89 df                                        	mov    rdi,rbx
   84c7b:	48 8d 05 16 7d 01 00                            	lea    rax,[rip+0x17d16]        # 9c998 <__frame_dummy_init_array_entry+0x2938>
   84c82:	48 89 84 24 a8 00 00 00                         	mov    QWORD PTR [rsp+0xa8],rax
   84c8a:	48 8b 94 24 a8 00 00 00                         	mov    rdx,QWORD PTR [rsp+0xa8]
   84c92:	4c 8b 64 24 58                                  	mov    r12,QWORD PTR [rsp+0x58]
   84c97:	c5 f8 77                                        	vzeroupper
   84c9a:	e8 b5 c6 fa ff                                  	call   31354 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   84c9f:	e9 79 01 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84ca4:	bf 08 00 00 00                                  	mov    edi,0x8
   84ca9:	be 00 40 00 00                                  	mov    esi,0x4000
   84cae:	e8 2e ab fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   84cb3:	bf 08 00 00 00                                  	mov    edi,0x8
   84cb8:	be 00 40 00 00                                  	mov    esi,0x4000
   84cbd:	e8 1f ab fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   84cc2:	e9 56 01 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84cc7:	48 8d 15 22 7c 01 00                            	lea    rdx,[rip+0x17c22]        # 9c8f0 <__frame_dummy_init_array_entry+0x2890>
   84cce:	bf 00 08 00 00                                  	mov    edi,0x800
   84cd3:	be 00 08 00 00                                  	mov    esi,0x800
   84cd8:	e8 77 c6 fa ff                                  	call   31354 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   84cdd:	e9 3b 01 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84ce2:	48 8b 74 24 18                                  	mov    rsi,QWORD PTR [rsp+0x18]
   84ce7:	48 8d 15 62 7c 01 00                            	lea    rdx,[rip+0x17c62]        # 9c950 <__frame_dummy_init_array_entry+0x28f0>
   84cee:	c5 f8 77                                        	vzeroupper
   84cf1:	e8 5e c6 fa ff                                  	call   31354 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   84cf6:	e9 22 01 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84cfb:	48 89 c7                                        	mov    rdi,rax
   84cfe:	e9 f1 fe ff ff                                  	jmp    84bf4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6444>
   84d03:	45 31 f6                                        	xor    r14d,r14d
   84d06:	bf 08 00 00 00                                  	mov    edi,0x8
   84d0b:	be 00 40 00 00                                  	mov    esi,0x4000
   84d10:	e8 cc aa fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   84d15:	e9 03 01 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84d1a:	48 8d 15 e7 7b 01 00                            	lea    rdx,[rip+0x17be7]        # 9c908 <__frame_dummy_init_array_entry+0x28a8>
   84d21:	bf 00 08 00 00                                  	mov    edi,0x800
   84d26:	e8 29 c6 fa ff                                  	call   31354 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   84d2b:	e9 ed 00 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84d30:	48 8d 3d e9 7b 01 00                            	lea    rdi,[rip+0x17be9]        # 9c920 <__frame_dummy_init_array_entry+0x28c0>
   84d37:	c5 f8 77                                        	vzeroupper
   84d3a:	e8 a1 e9 fa ff                                  	call   336e0 <_RNvNtNtCsgxBkk5gSRhY_4core9panicking11panic_const23panic_const_rem_by_zero>
   84d3f:	e9 d9 00 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84d44:	be 00 00 02 00                                  	mov    esi,0x20000
   84d49:	41 bc 08 00 00 00                               	mov    r12d,0x8
   84d4f:	e9 b4 a0 ff ff                                  	jmp    7ee08 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x658>
   84d54:	48 89 cf                                        	mov    rdi,rcx
   84d57:	48 8d 05 22 7c 01 00                            	lea    rax,[rip+0x17c22]        # 9c980 <__frame_dummy_init_array_entry+0x2920>
   84d5e:	e9 1f ff ff ff                                  	jmp    84c82 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x64d2>
   84d63:	48 89 d7                                        	mov    rdi,rdx
   84d66:	e9 1f ff ff ff                                  	jmp    84c8a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x64da>
   84d6b:	bb 04 00 00 00                                  	mov    ebx,0x4
   84d70:	e9 78 9c ff ff                                  	jmp    7e9ed <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x23d>
   84d75:	bf 01 00 00 00                                  	mov    edi,0x1
   84d7a:	4c 89 f6                                        	mov    rsi,r14
   84d7d:	e8 5f aa fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   84d82:	e9 96 00 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84d87:	bf 04 00 00 00                                  	mov    edi,0x4
   84d8c:	48 89 de                                        	mov    rsi,rbx
   84d8f:	e8 4d aa fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   84d94:	e9 84 00 00 00                                  	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84d99:	41 bc 08 00 00 00                               	mov    r12d,0x8
   84d9f:	e9 61 a0 ff ff                                  	jmp    7ee05 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x655>
   84da4:	c5 f8 77                                        	vzeroupper
   84da7:	e8 b4 4c fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   84dac:	e8 af 4c fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   84db1:	e8 aa 4c fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   84db6:	e8 a5 4c fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   84dbb:	bf 08 00 00 00                                  	mov    edi,0x8
   84dc0:	4c 89 fe                                        	mov    rsi,r15
   84dc3:	e8 19 aa fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   84dc8:	eb 53                                           	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84dca:	41 bc 40 00 00 00                               	mov    r12d,0x40
   84dd0:	e9 bf a7 ff ff                                  	jmp    7f594 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xde4>
   84dd5:	bf 08 00 00 00                                  	mov    edi,0x8
   84dda:	e9 1e b6 ff ff                                  	jmp    803fd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1c4d>
   84ddf:	31 db                                           	xor    ebx,ebx
   84de1:	4c 8b 7c 24 28                                  	mov    r15,QWORD PTR [rsp+0x28]
   84de6:	4c 8b 64 24 58                                  	mov    r12,QWORD PTR [rsp+0x58]
   84deb:	bf 40 00 00 00                                  	mov    edi,0x40
   84df0:	be 00 64 00 00                                  	mov    esi,0x6400
   84df5:	e8 e7 a9 fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   84dfa:	eb 21                                           	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84dfc:	bf 08 00 00 00                                  	mov    edi,0x8
   84e01:	4c 89 f6                                        	mov    rsi,r14
   84e04:	e8 d8 a9 fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   84e09:	eb 12                                           	jmp    84e1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x666d>
   84e0b:	48 8b b4 24 b0 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xb0]
   84e13:	bf 04 00 00 00                                  	mov    edi,0x4
   84e18:	e8 c4 a9 fa ff                                  	call   2f7e1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   84e1d:	0f 0b                                           	ud2
   84e1f:	49 89 c5                                        	mov    r13,rax
   84e22:	eb 1d                                           	jmp    84e41 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6691>
   84e24:	49 89 c5                                        	mov    r13,rax
   84e27:	48 85 db                                        	test   rbx,rbx
   84e2a:	74 15                                           	je     84e41 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6691>
   84e2c:	48 8b b4 24 b0 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xb0]
   84e34:	ba 04 00 00 00                                  	mov    edx,0x4
   84e39:	4c 89 f7                                        	mov    rdi,r14
   84e3c:	e8 df e6 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84e41:	48 8b b4 24 00 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x100]
   84e49:	ba 08 00 00 00                                  	mov    edx,0x8
   84e4e:	4c 89 ff                                        	mov    rdi,r15
   84e51:	e8 ca e6 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84e56:	45 31 ff                                        	xor    r15d,r15d
   84e59:	31 db                                           	xor    ebx,ebx
   84e5b:	e9 bb 03 00 00                                  	jmp    8521b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a6b>
   84e60:	49 89 c5                                        	mov    r13,rax
   84e63:	eb 62                                           	jmp    84ec7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6717>
   84e65:	49 89 c5                                        	mov    r13,rax
   84e68:	41 b6 01                                        	mov    r14b,0x1
   84e6b:	b3 01                                           	mov    bl,0x1
   84e6d:	e9 2e 02 00 00                                  	jmp    850a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x68f0>
   84e72:	49 89 c5                                        	mov    r13,rax
   84e75:	31 db                                           	xor    ebx,ebx
   84e77:	e9 de 02 00 00                                  	jmp    8515a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x69aa>
   84e7c:	49 89 c5                                        	mov    r13,rax
   84e7f:	b3 01                                           	mov    bl,0x1
   84e81:	48 8b 84 24 d0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xd0]
   84e89:	41 b7 01                                        	mov    r15b,0x1
   84e8c:	48 85 c0                                        	test   rax,rax
   84e8f:	0f 85 0e 03 00 00                               	jne    851a3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x69f3>
   84e95:	e9 81 03 00 00                                  	jmp    8521b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a6b>
   84e9a:	eb 62                                           	jmp    84efe <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x674e>
   84e9c:	49 89 c5                                        	mov    r13,rax
   84e9f:	48 8b 7c 24 70                                  	mov    rdi,QWORD PTR [rsp+0x70]
   84ea4:	ff 15 16 7f 01 00                               	call   QWORD PTR [rip+0x17f16]        # 9cdc0 <free@GLIBC_2.2.5>
   84eaa:	b3 01                                           	mov    bl,0x1
   84eac:	45 31 f6                                        	xor    r14d,r14d
   84eaf:	e9 ce 03 00 00                                  	jmp    85282 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6ad2>
   84eb4:	49 89 c5                                        	mov    r13,rax
   84eb7:	ba 08 00 00 00                                  	mov    edx,0x8
   84ebc:	4c 89 ff                                        	mov    rdi,r15
   84ebf:	4c 89 f6                                        	mov    rsi,r14
   84ec2:	e8 59 e6 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84ec7:	45 31 f6                                        	xor    r14d,r14d
   84eca:	31 db                                           	xor    ebx,ebx
   84ecc:	e9 cf 01 00 00                                  	jmp    850a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x68f0>
   84ed1:	eb 2b                                           	jmp    84efe <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x674e>
   84ed3:	4c 8b 74 24 08                                  	mov    r14,QWORD PTR [rsp+0x8]
   84ed8:	49 89 c5                                        	mov    r13,rax
   84edb:	e9 e8 00 00 00                                  	jmp    84fc8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6818>
   84ee0:	b3 01                                           	mov    bl,0x1
   84ee2:	e9 68 01 00 00                                  	jmp    8504f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x689f>
   84ee7:	49 89 c5                                        	mov    r13,rax
   84eea:	b3 01                                           	mov    bl,0x1
   84eec:	e9 8c 03 00 00                                  	jmp    8527d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6acd>
   84ef1:	4c 8b 7c 24 38                                  	mov    r15,QWORD PTR [rsp+0x38]
   84ef6:	49 89 c5                                        	mov    r13,rax
   84ef9:	e9 79 04 00 00                                  	jmp    85377 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bc7>
   84efe:	4c 8b 64 24 58                                  	mov    r12,QWORD PTR [rsp+0x58]
   84f03:	eb 14                                           	jmp    84f19 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6769>
   84f05:	b3 01                                           	mov    bl,0x1
   84f07:	49 89 c5                                        	mov    r13,rax
   84f0a:	e9 4b 02 00 00                                  	jmp    8515a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x69aa>
   84f0f:	4c 8b 74 24 08                                  	mov    r14,QWORD PTR [rsp+0x8]
   84f14:	49 89 c5                                        	mov    r13,rax
   84f17:	eb 32                                           	jmp    84f4b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x679b>
   84f19:	49 89 c5                                        	mov    r13,rax
   84f1c:	48 8b b4 24 e8 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xe8]
   84f24:	4c 8b 74 24 08                                  	mov    r14,QWORD PTR [rsp+0x8]
   84f29:	4c 8b 7c 24 28                                  	mov    r15,QWORD PTR [rsp+0x28]
   84f2e:	48 85 f6                                        	test   rsi,rsi
   84f31:	74 16                                           	je     84f49 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6799>
   84f33:	48 8b bc 24 f0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xf0]
   84f3b:	48 c1 e6 0a                                     	shl    rsi,0xa
   84f3f:	ba 40 00 00 00                                  	mov    edx,0x40
   84f44:	e8 d7 e5 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84f49:	31 db                                           	xor    ebx,ebx
   84f4b:	48 8b b4 24 68 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x168]
   84f53:	48 85 f6                                        	test   rsi,rsi
   84f56:	74 11                                           	je     84f69 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x67b9>
   84f58:	48 c1 e6 02                                     	shl    rsi,0x2
   84f5c:	ba 04 00 00 00                                  	mov    edx,0x4
   84f61:	4c 89 e7                                        	mov    rdi,r12
   84f64:	e8 b7 e5 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84f69:	84 db                                           	test   bl,bl
   84f6b:	75 3f                                           	jne    84fac <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x67fc>
   84f6d:	31 db                                           	xor    ebx,ebx
   84f6f:	48 8b b4 24 a8 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x1a8]
   84f77:	48 85 f6                                        	test   rsi,rsi
   84f7a:	74 44                                           	je     84fc0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6810>
   84f7c:	e9 ad 00 00 00                                  	jmp    8502e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x687e>
   84f81:	4c 8b 7c 24 38                                  	mov    r15,QWORD PTR [rsp+0x38]
   84f86:	49 89 c5                                        	mov    r13,rax
   84f89:	48 8b 84 24 28 02 00 00                         	mov    rax,QWORD PTR [rsp+0x228]
   84f91:	48 85 c0                                        	test   rax,rax
   84f94:	0f 85 9f 03 00 00                               	jne    85339 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b89>
   84f9a:	e9 d8 03 00 00                                  	jmp    85377 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bc7>
   84f9f:	4c 8b 74 24 08                                  	mov    r14,QWORD PTR [rsp+0x8]
   84fa4:	4c 8b 7c 24 28                                  	mov    r15,QWORD PTR [rsp+0x28]
   84fa9:	49 89 c5                                        	mov    r13,rax
   84fac:	b3 01                                           	mov    bl,0x1
   84fae:	4d 85 ff                                        	test   r15,r15
   84fb1:	75 3b                                           	jne    84fee <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x683e>
   84fb3:	48 8b b4 24 a8 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x1a8]
   84fbb:	48 85 f6                                        	test   rsi,rsi
   84fbe:	75 6e                                           	jne    8502e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x687e>
   84fc0:	84 db                                           	test   bl,bl
   84fc2:	0f 84 80 00 00 00                               	je     85048 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6898>
   84fc8:	48 8b b4 24 70 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x170]
   84fd0:	48 85 f6                                        	test   rsi,rsi
   84fd3:	75 04                                           	jne    84fd9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6829>
   84fd5:	31 db                                           	xor    ebx,ebx
   84fd7:	eb 79                                           	jmp    85052 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x68a2>
   84fd9:	48 c1 e6 03                                     	shl    rsi,0x3
   84fdd:	ba 08 00 00 00                                  	mov    edx,0x8
   84fe2:	4c 89 f7                                        	mov    rdi,r14
   84fe5:	e8 36 e5 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   84fea:	31 db                                           	xor    ebx,ebx
   84fec:	eb 64                                           	jmp    85052 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x68a2>
   84fee:	48 8b bc 24 c0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc0]
   84ff6:	48 8b b4 24 78 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x178]
   84ffe:	ba 08 00 00 00                                  	mov    edx,0x8
   85003:	e8 18 e5 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   85008:	48 8b b4 24 a8 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x1a8]
   85010:	48 85 f6                                        	test   rsi,rsi
   85013:	74 ab                                           	je     84fc0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6810>
   85015:	eb 17                                           	jmp    8502e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x687e>
   85017:	4c 8b 74 24 08                                  	mov    r14,QWORD PTR [rsp+0x8]
   8501c:	49 89 c5                                        	mov    r13,rax
   8501f:	b3 01                                           	mov    bl,0x1
   85021:	48 8b b4 24 a8 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x1a8]
   85029:	48 85 f6                                        	test   rsi,rsi
   8502c:	74 92                                           	je     84fc0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6810>
   8502e:	48 8b bc 24 b0 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x1b0]
   85036:	48 c1 e6 03                                     	shl    rsi,0x3
   8503a:	ba 08 00 00 00                                  	mov    edx,0x8
   8503f:	e8 dc e4 f9 ff                                  	call   23520 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   85044:	84 db                                           	test   bl,bl
   85046:	75 80                                           	jne    84fc8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6818>
   85048:	41 b6 01                                        	mov    r14b,0x1
   8504b:	31 db                                           	xor    ebx,ebx
   8504d:	eb 51                                           	jmp    850a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x68f0>
   8504f:	49 89 c5                                        	mov    r13,rax
   85052:	48 8b 84 24 50 01 00 00                         	mov    rax,QWORD PTR [rsp+0x150]
   8505a:	41 b6 01                                        	mov    r14b,0x1
   8505d:	48 85 c0                                        	test   rax,rax
   85060:	74 3e                                           	je     850a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x68f0>
   85062:	48 8b bc 24 58 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x158]
   8506a:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   85070:	76 28                                           	jbe    8509a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x68ea>
   85072:	48 c1 e0 03                                     	shl    rax,0x3
   85076:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   85080:	48 89 c6                                        	mov    rsi,rax
   85083:	48 83 ce 01                                     	or     rsi,0x1
   85087:	48 39 ce                                        	cmp    rsi,rcx
   8508a:	73 71                                           	jae    850fd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x694d>
   8508c:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   85090:	75 72                                           	jne    85104 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6954>
   85092:	ff 15 20 7d 01 00                               	call   QWORD PTR [rip+0x17d20]        # 9cdb8 <munmap@GLIBC_2.2.5>
   85098:	eb 06                                           	jmp    850a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x68f0>
   8509a:	ff 15 20 7d 01 00                               	call   QWORD PTR [rip+0x17d20]        # 9cdc0 <free@GLIBC_2.2.5>
   850a0:	48 8b 84 24 90 00 00 00                         	mov    rax,QWORD PTR [rsp+0x90]
   850a8:	48 85 c0                                        	test   rax,rax
   850ab:	74 45                                           	je     850f2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6942>
   850ad:	48 8b bc 24 98 00 00 00                         	mov    rdi,QWORD PTR [rsp+0x98]
   850b5:	48 3d ba 00 00 00                               	cmp    rax,0xba
   850bb:	76 2f                                           	jbe    850ec <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x693c>
   850bd:	48 69 c0 c0 02 00 00                            	imul   rax,rax,0x2c0
   850c4:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   850ce:	48 83 c1 c8                                     	add    rcx,0xffffffffffffffc8
   850d2:	48 89 c6                                        	mov    rsi,rax
   850d5:	48 83 ce 01                                     	or     rsi,0x1
   850d9:	48 39 ce                                        	cmp    rsi,rcx
   850dc:	73 1a                                           	jae    850f8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6948>
   850de:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   850e2:	75 1e                                           	jne    85102 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6952>
   850e4:	ff 15 ce 7c 01 00                               	call   QWORD PTR [rip+0x17cce]        # 9cdb8 <munmap@GLIBC_2.2.5>
   850ea:	eb 06                                           	jmp    850f2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6942>
   850ec:	ff 15 ce 7c 01 00                               	call   QWORD PTR [rip+0x17cce]        # 9cdc0 <free@GLIBC_2.2.5>
   850f2:	84 db                                           	test   bl,bl
   850f4:	75 16                                           	jne    8510c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x695c>
   850f6:	eb 51                                           	jmp    85149 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6999>
   850f8:	e8 63 49 fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   850fd:	e8 5e 49 fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   85102:	eb e8                                           	jmp    850ec <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x693c>
   85104:	eb 94                                           	jmp    8509a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x68ea>
   85106:	49 89 c5                                        	mov    r13,rax
   85109:	41 b6 01                                        	mov    r14b,0x1
   8510c:	48 8b 44 24 48                                  	mov    rax,QWORD PTR [rsp+0x48]
   85111:	48 85 c0                                        	test   rax,rax
   85114:	74 33                                           	je     85149 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6999>
   85116:	3d ff 7f 00 00                                  	cmp    eax,0x7fff
   8511b:	76 1f                                           	jbe    8513c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x698c>
   8511d:	48 8b b4 24 b0 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xb0]
   85125:	48 8b 7c 24 40                                  	mov    rdi,QWORD PTR [rsp+0x40]
   8512a:	80 3c 37 01                                     	cmp    BYTE PTR [rdi+rsi*1],0x1
   8512e:	75 13                                           	jne    85143 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6993>
   85130:	48 83 ce 01                                     	or     rsi,0x1
   85134:	ff 15 7e 7c 01 00                               	call   QWORD PTR [rip+0x17c7e]        # 9cdb8 <munmap@GLIBC_2.2.5>
   8513a:	eb 0d                                           	jmp    85149 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6999>
   8513c:	48 8b 7c 24 40                                  	mov    rdi,QWORD PTR [rsp+0x40]
   85141:	eb 00                                           	jmp    85143 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6993>
   85143:	ff 15 77 7c 01 00                               	call   QWORD PTR [rip+0x17c77]        # 9cdc0 <free@GLIBC_2.2.5>
   85149:	bb 00 00 00 00                                  	mov    ebx,0x0
   8514e:	45 31 ff                                        	xor    r15d,r15d
   85151:	45 84 f6                                        	test   r14b,r14b
   85154:	0f 84 c1 00 00 00                               	je     8521b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a6b>
   8515a:	48 8b 74 24 78                                  	mov    rsi,QWORD PTR [rsp+0x78]
   8515f:	48 85 f6                                        	test   rsi,rsi
   85162:	74 2f                                           	je     85193 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x69e3>
   85164:	48 8b bc 24 80 00 00 00                         	mov    rdi,QWORD PTR [rsp+0x80]
   8516c:	48 81 fe ff ff 01 00                            	cmp    rsi,0x1ffff
   85173:	76 18                                           	jbe    8518d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x69dd>
   85175:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   8517f:	48 83 c0 06                                     	add    rax,0x6
   85183:	48 39 c6                                        	cmp    rsi,rax
   85186:	72 5b                                           	jb     851e3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a33>
   85188:	e8 d3 48 fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   8518d:	ff 15 2d 7c 01 00                               	call   QWORD PTR [rip+0x17c2d]        # 9cdc0 <free@GLIBC_2.2.5>
   85193:	48 8b 84 24 d0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xd0]
   8519b:	41 b7 01                                        	mov    r15b,0x1
   8519e:	48 85 c0                                        	test   rax,rax
   851a1:	74 78                                           	je     8521b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a6b>
   851a3:	48 8b bc 24 d8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xd8]
   851ab:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   851b1:	76 28                                           	jbe    851db <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a2b>
   851b3:	48 c1 e0 03                                     	shl    rax,0x3
   851b7:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   851c1:	48 89 c6                                        	mov    rsi,rax
   851c4:	48 83 ce 01                                     	or     rsi,0x1
   851c8:	48 39 ce                                        	cmp    rsi,rcx
   851cb:	73 37                                           	jae    85204 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a54>
   851cd:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   851d1:	75 38                                           	jne    8520b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a5b>
   851d3:	ff 15 df 7b 01 00                               	call   QWORD PTR [rip+0x17bdf]        # 9cdb8 <munmap@GLIBC_2.2.5>
   851d9:	eb 40                                           	jmp    8521b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a6b>
   851db:	ff 15 df 7b 01 00                               	call   QWORD PTR [rip+0x17bdf]        # 9cdc0 <free@GLIBC_2.2.5>
   851e1:	eb 38                                           	jmp    8521b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a6b>
   851e3:	80 3c 37 01                                     	cmp    BYTE PTR [rdi+rsi*1],0x1
   851e7:	75 20                                           	jne    85209 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a59>
   851e9:	48 ff c6                                        	inc    rsi
   851ec:	ff 15 c6 7b 01 00                               	call   QWORD PTR [rip+0x17bc6]        # 9cdb8 <munmap@GLIBC_2.2.5>
   851f2:	48 8b 84 24 d0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xd0]
   851fa:	41 b7 01                                        	mov    r15b,0x1
   851fd:	48 85 c0                                        	test   rax,rax
   85200:	75 a1                                           	jne    851a3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x69f3>
   85202:	eb 17                                           	jmp    8521b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a6b>
   85204:	e8 57 48 fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   85209:	eb 82                                           	jmp    8518d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x69dd>
   8520b:	ff 15 af 7b 01 00                               	call   QWORD PTR [rip+0x17baf]        # 9cdc0 <free@GLIBC_2.2.5>
   85211:	eb 08                                           	jmp    8521b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6a6b>
   85213:	41 b7 01                                        	mov    r15b,0x1
   85216:	b3 01                                           	mov    bl,0x1
   85218:	49 89 c5                                        	mov    r13,rax
   8521b:	48 8b 84 24 90 01 00 00                         	mov    rax,QWORD PTR [rsp+0x190]
   85223:	48 85 c0                                        	test   rax,rax
   85226:	74 42                                           	je     8526a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6aba>
   85228:	48 8b bc 24 98 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x198]
   85230:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   85236:	76 2c                                           	jbe    85264 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6ab4>
   85238:	48 c1 e0 03                                     	shl    rax,0x3
   8523c:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   85246:	48 89 c6                                        	mov    rsi,rax
   85249:	48 83 ce 01                                     	or     rsi,0x1
   8524d:	48 39 ce                                        	cmp    rsi,rcx
   85250:	73 7e                                           	jae    852d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b20>
   85252:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   85256:	0f 85 ae 00 00 00                               	jne    8530a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b5a>
   8525c:	ff 15 56 7b 01 00                               	call   QWORD PTR [rip+0x17b56]        # 9cdb8 <munmap@GLIBC_2.2.5>
   85262:	eb 06                                           	jmp    8526a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6aba>
   85264:	ff 15 56 7b 01 00                               	call   QWORD PTR [rip+0x17b56]        # 9cdc0 <free@GLIBC_2.2.5>
   8526a:	48 8b 7c 24 70                                  	mov    rdi,QWORD PTR [rsp+0x70]
   8526f:	ff 15 4b 7b 01 00                               	call   QWORD PTR [rip+0x17b4b]        # 9cdc0 <free@GLIBC_2.2.5>
   85275:	45 84 ff                                        	test   r15b,r15b
   85278:	74 4f                                           	je     852c9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b19>
   8527a:	45 31 f6                                        	xor    r14d,r14d
   8527d:	4c 8b 7c 24 38                                  	mov    r15,QWORD PTR [rsp+0x38]
   85282:	48 8b 8c 24 b8 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xb8]
   8528a:	48 85 c9                                        	test   rcx,rcx
   8528d:	74 51                                           	je     852e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b30>
   8528f:	48 81 f9 ff 7f 00 00                            	cmp    rcx,0x7fff
   85296:	76 3d                                           	jbe    852d5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b25>
   85298:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   852a2:	48 c1 e1 02                                     	shl    rcx,0x2
   852a6:	48 89 ce                                        	mov    rsi,rcx
   852a9:	48 83 ce 01                                     	or     rsi,0x1
   852ad:	48 83 c0 04                                     	add    rax,0x4
   852b1:	48 39 c6                                        	cmp    rsi,rax
   852b4:	73 59                                           	jae    8530f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b5f>
   852b6:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   852bb:	80 3c 0f 01                                     	cmp    BYTE PTR [rdi+rcx*1],0x1
   852bf:	75 53                                           	jne    85314 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b64>
   852c1:	ff 15 f1 7a 01 00                               	call   QWORD PTR [rip+0x17af1]        # 9cdb8 <munmap@GLIBC_2.2.5>
   852c7:	eb 17                                           	jmp    852e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b30>
   852c9:	4c 8b 7c 24 38                                  	mov    r15,QWORD PTR [rsp+0x38]
   852ce:	eb 23                                           	jmp    852f3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b43>
   852d0:	e8 8b 47 fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   852d5:	48 8b 7c 24 30                                  	mov    rdi,QWORD PTR [rsp+0x30]
   852da:	ff 15 e0 7a 01 00                               	call   QWORD PTR [rip+0x17ae0]        # 9cdc0 <free@GLIBC_2.2.5>
   852e0:	45 84 f6                                        	test   r14b,r14b
   852e3:	74 0e                                           	je     852f3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b43>
   852e5:	48 8b bc 24 c8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc8]
   852ed:	ff 15 cd 7a 01 00                               	call   QWORD PTR [rip+0x17acd]        # 9cdc0 <free@GLIBC_2.2.5>
   852f3:	84 db                                           	test   bl,bl
   852f5:	0f 84 85 00 00 00                               	je     85380 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bd0>
   852fb:	48 8b 84 24 28 02 00 00                         	mov    rax,QWORD PTR [rsp+0x228]
   85303:	48 85 c0                                        	test   rax,rax
   85306:	75 31                                           	jne    85339 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b89>
   85308:	eb 6d                                           	jmp    85377 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bc7>
   8530a:	e9 55 ff ff ff                                  	jmp    85264 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6ab4>
   8530f:	e8 4c 47 fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   85314:	eb c4                                           	jmp    852da <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6b2a>
   85316:	49 89 c5                                        	mov    r13,rax
   85319:	48 8b bc 24 c8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc8]
   85321:	ff 15 99 7a 01 00                               	call   QWORD PTR [rip+0x17a99]        # 9cdc0 <free@GLIBC_2.2.5>
   85327:	4c 8b 7c 24 38                                  	mov    r15,QWORD PTR [rsp+0x38]
   8532c:	48 8b 84 24 28 02 00 00                         	mov    rax,QWORD PTR [rsp+0x228]
   85334:	48 85 c0                                        	test   rax,rax
   85337:	74 3e                                           	je     85377 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bc7>
   85339:	48 8b bc 24 30 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x230]
   85341:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   85347:	76 28                                           	jbe    85371 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bc1>
   85349:	48 c1 e0 03                                     	shl    rax,0x3
   8534d:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   85357:	48 89 c6                                        	mov    rsi,rax
   8535a:	48 83 ce 01                                     	or     rsi,0x1
   8535e:	48 39 ce                                        	cmp    rsi,rcx
   85361:	73 25                                           	jae    85388 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bd8>
   85363:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   85367:	75 24                                           	jne    8538d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bdd>
   85369:	ff 15 49 7a 01 00                               	call   QWORD PTR [rip+0x17a49]        # 9cdb8 <munmap@GLIBC_2.2.5>
   8536f:	eb 06                                           	jmp    85377 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bc7>
   85371:	ff 15 49 7a 01 00                               	call   QWORD PTR [rip+0x17a49]        # 9cdc0 <free@GLIBC_2.2.5>
   85377:	4c 89 ff                                        	mov    rdi,r15
   8537a:	ff 15 40 7a 01 00                               	call   QWORD PTR [rip+0x17a40]        # 9cdc0 <free@GLIBC_2.2.5>
   85380:	4c 89 ef                                        	mov    rdi,r13
   85383:	e8 88 3c 01 00                                  	call   99010 <_Unwind_Resume@plt>
   85388:	e8 d3 46 fc ff                                  	call   49a60 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   8538d:	eb e2                                           	jmp    85371 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6bc1>
