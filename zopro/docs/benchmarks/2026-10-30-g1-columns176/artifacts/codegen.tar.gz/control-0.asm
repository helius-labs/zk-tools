
/home/ubuntu/src/zopro-perf-work/g1-columns176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

000000000007f4e0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_>:
   7f4e0:	55                                              	push   rbp
   7f4e1:	48 89 e5                                        	mov    rbp,rsp
   7f4e4:	41 57                                           	push   r15
   7f4e6:	41 56                                           	push   r14
   7f4e8:	41 55                                           	push   r13
   7f4ea:	41 54                                           	push   r12
   7f4ec:	53                                              	push   rbx
   7f4ed:	48 83 e4 c0                                     	and    rsp,0xffffffffffffffc0
   7f4f1:	48 81 ec c0 0f 00 00                            	sub    rsp,0xfc0
   7f4f8:	48 c7 04 24 00 00 00 00                         	mov    QWORD PTR [rsp],0x0
   7f500:	48 81 ec 00 03 00 00                            	sub    rsp,0x300
   7f507:	c5 fd 6f 05 71 82 f8 ff                         	vmovdqa ymm0,YMMWORD PTR [rip+0xfffffffffff88271]        # 7780 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x7e0>
   7f50f:	48 b8 07 9a c1 77 0a 0e 00 00                   	movabs rax,0xe0a77c19a07
   7f519:	62 62 fd 48 59 05 85 77 f8 ff                   	vpbroadcastq zmm24,QWORD PTR [rip+0xfffffffffff87785]        # 6ca8 <GCC_except_table711+0x1b8>
   7f523:	49 ba f8 ff ff ff ff ff ff 07                   	movabs r10,0x7fffffffffffff8
   7f52d:	49 c7 40 10 00 00 00 00                         	mov    QWORD PTR [r8+0x10],0x0
   7f535:	48 89 cb                                        	mov    rbx,rcx
   7f538:	48 c1 eb 03                                     	shr    rbx,0x3
   7f53c:	49 89 cd                                        	mov    r13,rcx
   7f53f:	49 89 f4                                        	mov    r12,rsi
   7f542:	48 89 bc 24 40 05 00 00                         	mov    QWORD PTR [rsp+0x540],rdi
   7f54a:	48 89 8c 24 80 05 00 00                         	mov    QWORD PTR [rsp+0x580],rcx
   7f552:	48 89 74 24 10                                  	mov    QWORD PTR [rsp+0x10],rsi
   7f557:	48 89 54 24 18                                  	mov    QWORD PTR [rsp+0x18],rdx
   7f55c:	4c 89 84 24 40 04 00 00                         	mov    QWORD PTR [rsp+0x440],r8
   7f564:	49 21 ca                                        	and    r10,rcx
   7f567:	41 80 78 30 00                                  	cmp    BYTE PTR [r8+0x30],0x0
   7f56c:	4c 89 94 24 40 07 00 00                         	mov    QWORD PTR [rsp+0x740],r10
   7f574:	c5 fe 7f 84 24 80 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0x80],ymm0
   7f57d:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   7f585:	62 61 fd 48 7f 44 24 2f                         	vmovdqa64 ZMMWORD PTR [rsp+0xbc0],zmm24
   7f58d:	62 e2 fd 48 59 74 24 11                         	vpbroadcastq zmm22,QWORD PTR [rsp+0x88]
   7f595:	62 e2 fd 48 59 6c 24 12                         	vpbroadcastq zmm21,QWORD PTR [rsp+0x90]
   7f59d:	62 e2 fd 48 59 64 24 13                         	vpbroadcastq zmm20,QWORD PTR [rsp+0x98]
   7f5a5:	62 62 fd 48 59 4c 24 14                         	vpbroadcastq zmm25,QWORD PTR [rsp+0xa0]
   7f5ad:	62 e1 fd 48 7f 74 24 30                         	vmovdqa64 ZMMWORD PTR [rsp+0xc00],zmm22
   7f5b5:	62 e1 fd 48 7f 6c 24 31                         	vmovdqa64 ZMMWORD PTR [rsp+0xc40],zmm21
   7f5bd:	62 e1 fd 48 7f 64 24 32                         	vmovdqa64 ZMMWORD PTR [rsp+0xc80],zmm20
   7f5c5:	62 61 fd 48 7f 4c 24 33                         	vmovdqa64 ZMMWORD PTR [rsp+0xcc0],zmm25
   7f5cd:	0f 84 1e 12 00 00                               	je     807f1 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x1311>
   7f5d3:	49 3b 18                                        	cmp    rbx,QWORD PTR [r8]
   7f5d6:	0f 87 02 65 00 00                               	ja     85ade <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x65fe>
   7f5dc:	48 85 db                                        	test   rbx,rbx
   7f5df:	0f 84 7e 27 00 00                               	je     81d63 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x2883>
   7f5e5:	62 62 fd 48 59 05 b9 76 f8 ff                   	vpbroadcastq zmm24,QWORD PTR [rip+0xfffffffffff876b9]        # 6ca8 <GCC_except_table711+0x1b8>
   7f5ef:	62 e1 fd 48 6f 05 07 7e f8 ff                   	vmovdqa64 zmm16,ZMMWORD PTR [rip+0xfffffffffff87e07]        # 7400 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x460>
   7f5f9:	62 e1 fd 48 6f 15 3d 7e f8 ff                   	vmovdqa64 zmm18,ZMMWORD PTR [rip+0xfffffffffff87e3d]        # 7440 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4a0>
   7f603:	62 f2 fd 48 59 15 33 76 f8 ff                   	vpbroadcastq zmm2,QWORD PTR [rip+0xfffffffffff87633]        # 6c40 <GCC_except_table711+0x150>
   7f60d:	ba 00 06 00 00                                  	mov    edx,0x600
   7f612:	49 03 50 08                                     	add    rdx,QWORD PTR [r8+0x8]
   7f616:	4c 8b 4c 24 18                                  	mov    r9,QWORD PTR [rsp+0x18]
   7f61b:	48 89 5c 24 68                                  	mov    QWORD PTR [rsp+0x68],rbx
   7f620:	45 31 db                                        	xor    r11d,r11d
   7f623:	31 ff                                           	xor    edi,edi
   7f625:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   7f630:	4c 89 e8                                        	mov    rax,r13
   7f633:	48 29 f8                                        	sub    rax,rdi
   7f636:	41 ba 00 00 00 00                               	mov    r10d,0x0
   7f63c:	4c 0f 43 d0                                     	cmovae r10,rax
   7f640:	0f 86 e4 65 00 00                               	jbe    85c2a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x674a>
   7f646:	41 8b 09                                        	mov    ecx,DWORD PTR [r9]
   7f649:	81 e1 ff ff ff 7f                               	and    ecx,0x7fffffff
   7f64f:	49 39 cc                                        	cmp    r12,rcx
   7f652:	0f 86 3b 66 00 00                               	jbe    85c93 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x67b3>
   7f658:	49 83 fa 01                                     	cmp    r10,0x1
   7f65c:	0f 84 ad 65 00 00                               	je     85c0f <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x672f>
   7f662:	41 8b 71 10                                     	mov    esi,DWORD PTR [r9+0x10]
   7f666:	81 e6 ff ff ff 7f                               	and    esi,0x7fffffff
   7f66c:	49 39 f4                                        	cmp    r12,rsi
   7f66f:	0f 86 7a 65 00 00                               	jbe    85bef <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x670f>
   7f675:	49 83 fa 02                                     	cmp    r10,0x2
   7f679:	0f 84 95 65 00 00                               	je     85c14 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6734>
   7f67f:	45 8b 71 20                                     	mov    r14d,DWORD PTR [r9+0x20]
   7f683:	41 81 e6 ff ff ff 7f                            	and    r14d,0x7fffffff
   7f68a:	4d 39 f4                                        	cmp    r12,r14
   7f68d:	0f 86 42 65 00 00                               	jbe    85bd5 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66f5>
   7f693:	4c 89 9c 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],r11
   7f69b:	49 83 fa 03                                     	cmp    r10,0x3
   7f69f:	0f 84 64 65 00 00                               	je     85c09 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6729>
   7f6a5:	45 8b 59 30                                     	mov    r11d,DWORD PTR [r9+0x30]
   7f6a9:	41 81 e3 ff ff ff 7f                            	and    r11d,0x7fffffff
   7f6b0:	4d 39 dc                                        	cmp    r12,r11
   7f6b3:	0f 86 02 65 00 00                               	jbe    85bbb <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66db>
   7f6b9:	49 83 fa 04                                     	cmp    r10,0x4
   7f6bd:	0f 84 5d 65 00 00                               	je     85c20 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6740>
   7f6c3:	45 8b 79 40                                     	mov    r15d,DWORD PTR [r9+0x40]
   7f6c7:	41 81 e7 ff ff ff 7f                            	and    r15d,0x7fffffff
   7f6ce:	4d 39 fc                                        	cmp    r12,r15
   7f6d1:	0f 86 b9 65 00 00                               	jbe    85c90 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x67b0>
   7f6d7:	49 83 fa 05                                     	cmp    r10,0x5
   7f6db:	0f 84 45 65 00 00                               	je     85c26 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6746>
   7f6e1:	41 8b 59 50                                     	mov    ebx,DWORD PTR [r9+0x50]
   7f6e5:	81 e3 ff ff ff 7f                               	and    ebx,0x7fffffff
   7f6eb:	49 39 dc                                        	cmp    r12,rbx
   7f6ee:	0f 86 82 65 00 00                               	jbe    85c76 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6796>
   7f6f4:	49 83 fa 06                                     	cmp    r10,0x6
   7f6f8:	0f 84 1c 65 00 00                               	je     85c1a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x673a>
   7f6fe:	45 8b 61 60                                     	mov    r12d,DWORD PTR [r9+0x60]
   7f702:	41 81 e4 ff ff ff 7f                            	and    r12d,0x7fffffff
   7f709:	4c 39 64 24 10                                  	cmp    QWORD PTR [rsp+0x10],r12
   7f70e:	0f 86 48 65 00 00                               	jbe    85c5c <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x677c>
   7f714:	48 8d 47 07                                     	lea    rax,[rdi+0x7]
   7f718:	49 83 fa 07                                     	cmp    r10,0x7
   7f71c:	0f 84 0b 65 00 00                               	je     85c2d <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x674d>
   7f722:	45 8b 51 70                                     	mov    r10d,DWORD PTR [r9+0x70]
   7f726:	62 61 fd 48 7f 44 24 13                         	vmovdqa64 ZMMWORD PTR [rsp+0x4c0],zmm24
   7f72e:	62 e1 fd 48 7f 74 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm22
   7f736:	62 e1 fd 48 7f 6c 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm21
   7f73e:	62 e1 fd 48 7f 64 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm20
   7f746:	62 61 fd 48 7f 4c 24 08                         	vmovdqa64 ZMMWORD PTR [rsp+0x200],zmm25
   7f74e:	41 81 e2 ff ff ff 7f                            	and    r10d,0x7fffffff
   7f755:	4c 39 54 24 10                                  	cmp    QWORD PTR [rsp+0x10],r10
   7f75a:	0f 86 e2 64 00 00                               	jbe    85c42 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6762>
   7f760:	4c 8b 84 24 40 05 00 00                         	mov    r8,QWORD PTR [rsp+0x540]
   7f768:	48 c1 e1 06                                     	shl    rcx,0x6
   7f76c:	49 c1 e7 06                                     	shl    r15,0x6
   7f770:	49 c1 e6 06                                     	shl    r14,0x6
   7f774:	49 c1 e3 06                                     	shl    r11,0x6
   7f778:	49 c1 e4 06                                     	shl    r12,0x6
   7f77c:	48 c1 e6 06                                     	shl    rsi,0x6
   7f780:	48 c1 e3 06                                     	shl    rbx,0x6
   7f784:	49 c1 e2 06                                     	shl    r10,0x6
   7f788:	62 e1 7c 28 28 1d 8e 81 f8 ff                   	vmovaps ymm19,YMMWORD PTR [rip+0xfffffffffff8818e]        # 7920 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x980>
   7f792:	62 62 fd 48 59 0d fc 74 f8 ff                   	vpbroadcastq zmm25,QWORD PTR [rip+0xfffffffffff874fc]        # 6c98 <GCC_except_table711+0x1a8>
   7f79c:	62 21 fd 48 6f e2                               	vmovdqa64 zmm28,zmm18
   7f7a2:	c4 c1 7c 10 44 08 20                            	vmovups ymm0,YMMWORD PTR [r8+rcx*1+0x20]
   7f7a9:	c4 c1 7e 6f 1c 08                               	vmovdqu ymm3,YMMWORD PTR [r8+rcx*1]
   7f7af:	49 8b 49 08                                     	mov    rcx,QWORD PTR [r9+0x8]
   7f7b3:	c4 81 7e 6f 24 30                               	vmovdqu ymm4,YMMWORD PTR [r8+r14*1]
   7f7b9:	62 81 fe 28 6f 74 18 01                         	vmovdqu64 ymm22,YMMWORD PTR [r8+r11*1+0x20]
   7f7c1:	c4 01 7e 6f 04 20                               	vmovdqu ymm8,YMMWORD PTR [r8+r12*1]
   7f7c7:	c4 81 7e 6f 2c 38                               	vmovdqu ymm5,YMMWORD PTR [r8+r15*1]
   7f7cd:	62 c1 fe 28 6f 6c 30 01                         	vmovdqu64 ymm21,YMMWORD PTR [r8+rsi*1+0x20]
   7f7d5:	62 81 fe 28 6f 64 30 01                         	vmovdqu64 ymm20,YMMWORD PTR [r8+r14*1+0x20]
   7f7dd:	4d 8b 71 68                                     	mov    r14,QWORD PTR [r9+0x68]
   7f7e1:	c4 81 7e 6f 7c 20 20                            	vmovdqu ymm7,YMMWORD PTR [r8+r12*1+0x20]
   7f7e8:	62 93 dd 48 3a 24 18 01                         	vinserti64x4 zmm4,zmm4,YMMWORD PTR [r8+r11*1],0x1
   7f7f0:	4d 8b 59 18                                     	mov    r11,QWORD PTR [r9+0x18]
   7f7f4:	62 d3 e5 48 3a 1c 30 01                         	vinserti64x4 zmm3,zmm3,YMMWORD PTR [r8+rsi*1],0x1
   7f7fc:	62 53 d5 48 3a 34 18 01                         	vinserti64x4 zmm14,zmm5,YMMWORD PTR [r8+rbx*1],0x1
   7f804:	62 13 bd 48 3a 04 10 01                         	vinserti64x4 zmm8,zmm8,YMMWORD PTR [r8+r10*1],0x1
   7f80c:	49 8b 71 38                                     	mov    rsi,QWORD PTR [r9+0x38]
   7f810:	62 93 c5 48 3a 7c 10 01 01                      	vinserti64x4 zmm7,zmm7,YMMWORD PTR [r8+r10*1+0x20],0x1
   7f819:	c5 7e 6f 09                                     	vmovdqu ymm9,YMMWORD PTR [rcx]
   7f81d:	c4 41 7e 6f 2e                                  	vmovdqu ymm13,YMMWORD PTR [r14]
   7f822:	62 41 fe 28 6f 5e 01                            	vmovdqu64 ymm27,YMMWORD PTR [r14+0x20]
   7f829:	62 41 fe 28 6f 6b 01                            	vmovdqu64 ymm29,YMMWORD PTR [r11+0x20]
   7f830:	62 53 b5 48 3a 3b 01                            	vinserti64x4 zmm15,zmm9,YMMWORD PTR [r11],0x1
   7f837:	4d 8b 59 58                                     	mov    r11,QWORD PTR [r9+0x58]
   7f83b:	62 61 fe 28 6f 76 01                            	vmovdqu64 ymm30,YMMWORD PTR [rsi+0x20]
   7f842:	62 f1 7c 48 29 44 24 10                         	vmovaps ZMMWORD PTR [rsp+0x400],zmm0
   7f84a:	c4 81 7c 10 44 38 20                            	vmovups ymm0,YMMWORD PTR [r8+r15*1+0x20]
   7f851:	4d 8b 79 48                                     	mov    r15,QWORD PTR [r9+0x48]
   7f855:	62 41 fe 28 6f 7b 01                            	vmovdqu64 ymm31,YMMWORD PTR [r11+0x20]
   7f85c:	c4 41 7e 6f 27                                  	vmovdqu ymm12,YMMWORD PTR [r15]
   7f861:	62 41 fe 28 6f 57 01                            	vmovdqu64 ymm26,YMMWORD PTR [r15+0x20]
   7f868:	62 c3 9d 48 3a 0b 01                            	vinserti64x4 zmm17,zmm12,YMMWORD PTR [r11],0x1
   7f86f:	62 71 e5 48 6c e4                               	vpunpcklqdq zmm12,zmm3,zmm4
   7f875:	62 f1 e5 48 6d dc                               	vpunpckhqdq zmm3,zmm3,zmm4
   7f87b:	62 d1 8d 48 6c e0                               	vpunpcklqdq zmm4,zmm14,zmm8
   7f881:	62 51 8d 48 6d c0                               	vpunpckhqdq zmm8,zmm14,zmm8
   7f887:	62 51 fd 48 6f cc                               	vmovdqa64 zmm9,zmm12
   7f88d:	62 72 fd 40 7e cc                               	vpermt2q zmm9,zmm16,zmm4
   7f893:	62 72 ed 40 7e e4                               	vpermt2q zmm12,zmm18,zmm4
   7f899:	62 f1 7c 48 29 44 24 0e                         	vmovaps ZMMWORD PTR [rsp+0x380],zmm0
   7f8a1:	c5 fc 10 41 20                                  	vmovups ymm0,YMMWORD PTR [rcx+0x20]
   7f8a6:	49 8b 49 28                                     	mov    rcx,QWORD PTR [r9+0x28]
   7f8aa:	c5 7e 6f 19                                     	vmovdqu ymm11,YMMWORD PTR [rcx]
   7f8ae:	62 e3 a5 48 3a 3e 01                            	vinserti64x4 zmm23,zmm11,YMMWORD PTR [rsi],0x1
   7f8b5:	49 8b 71 78                                     	mov    rsi,QWORD PTR [r9+0x78]
   7f8b9:	62 71 fd 48 6f db                               	vmovdqa64 zmm11,zmm3
   7f8bf:	62 52 fd 40 7e d8                               	vpermt2q zmm11,zmm16,zmm8
   7f8c5:	62 d2 ed 40 7e d8                               	vpermt2q zmm3,zmm18,zmm8
   7f8cb:	62 71 b5 48 db c2                               	vpandq zmm8,zmm9,zmm2
   7f8d1:	62 f1 7c 48 29 44 24 14                         	vmovaps ZMMWORD PTR [rsp+0x500],zmm0
   7f8d9:	c5 fc 10 41 20                                  	vmovups ymm0,YMMWORD PTR [rcx+0x20]
   7f8de:	48 b9 63 c2 e5 9c c8 60 00 00                   	movabs rcx,0x60c89ce5c263
   7f8e8:	62 d3 a5 48 71 e1 0c                            	vpshldq zmm4,zmm11,zmm9,0xc
   7f8ef:	c5 fe 6f 6e 20                                  	vmovdqu ymm5,YMMWORD PTR [rsi+0x20]
   7f8f4:	62 71 dd 48 db ca                               	vpandq zmm9,zmm4,zmm2
   7f8fa:	62 d3 9d 48 71 e3 18                            	vpshldq zmm4,zmm12,zmm11,0x18
   7f901:	62 71 dd 48 db da                               	vpandq zmm11,zmm4,zmm2
   7f907:	62 d3 e5 48 71 e4 24                            	vpshldq zmm4,zmm3,zmm12,0x24
   7f90e:	62 f1 7c 48 29 44 24 12                         	vmovaps ZMMWORD PTR [rsp+0x480],zmm0
   7f916:	c4 c1 7c 10 44 18 20                            	vmovups ymm0,YMMWORD PTR [r8+rbx*1+0x20]
   7f91d:	62 71 dd 48 db e2                               	vpandq zmm12,zmm4,zmm2
   7f923:	62 b1 85 48 6d e7                               	vpunpckhqdq zmm4,zmm15,zmm23
   7f929:	c5 fc 29 84 24 40 03 00 00                      	vmovaps YMMWORD PTR [rsp+0x340],ymm0
   7f932:	62 f3 95 48 3a 06 01                            	vinserti64x4 zmm0,zmm13,YMMWORD PTR [rsi],0x1
   7f939:	62 f1 95 48 73 d3 10                            	vpsrlq zmm13,zmm3,0x10
   7f940:	62 b1 85 48 6c df                               	vpunpcklqdq zmm3,zmm15,zmm23
   7f946:	62 71 fd 48 7f 42 e8                            	vmovdqa64 ZMMWORD PTR [rdx-0x600],zmm8
   7f94d:	62 71 fd 48 7f 4a e9                            	vmovdqa64 ZMMWORD PTR [rdx-0x5c0],zmm9
   7f954:	62 71 fd 48 7f 5a ea                            	vmovdqa64 ZMMWORD PTR [rdx-0x580],zmm11
   7f95b:	62 71 fd 48 7f 62 eb                            	vmovdqa64 ZMMWORD PTR [rdx-0x540],zmm12
   7f962:	48 8d 77 08                                     	lea    rsi,[rdi+0x8]
   7f966:	62 71 fd 48 6f fb                               	vmovdqa64 zmm15,zmm3
   7f96c:	62 71 fd 48 7f 6a ec                            	vmovdqa64 ZMMWORD PTR [rdx-0x500],zmm13
   7f973:	62 e1 7c 28 11 5c 24 04                         	vmovups YMMWORD PTR [rsp+0x80],ymm19
   7f97b:	48 89 8c 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rcx
   7f983:	62 71 f5 40 6c f0                               	vpunpcklqdq zmm14,zmm17,zmm0
   7f989:	62 f1 f5 40 6d c0                               	vpunpckhqdq zmm0,zmm17,zmm0
   7f98f:	62 e1 fd 48 6f cc                               	vmovdqa64 zmm17,zmm4
   7f995:	62 52 fd 40 7e fe                               	vpermt2q zmm15,zmm16,zmm14
   7f99b:	62 e2 fd 40 7e c8                               	vpermt2q zmm17,zmm16,zmm0
   7f9a1:	62 d2 ed 40 7e de                               	vpermt2q zmm3,zmm18,zmm14
   7f9a7:	62 f2 ed 40 7e e0                               	vpermt2q zmm4,zmm18,zmm0
   7f9ad:	62 53 f5 40 71 f7 0c                            	vpshldq zmm14,zmm17,zmm15,0xc
   7f9b4:	62 b3 e5 48 71 f1 18                            	vpshldq zmm6,zmm3,zmm17,0x18
   7f9bb:	62 f1 85 48 db c2                               	vpandq zmm0,zmm15,zmm2
   7f9c1:	62 f3 dd 48 71 db 24                            	vpshldq zmm3,zmm4,zmm3,0x24
   7f9c8:	62 41 fd 48 fb c0                               	vpsubq zmm24,zmm0,zmm8
   7f9ce:	62 d1 fd 48 d4 c0                               	vpaddq zmm0,zmm0,zmm8
   7f9d4:	62 f1 8d 48 db ca                               	vpandq zmm1,zmm14,zmm2
   7f9da:	62 e1 cd 48 db ca                               	vpandq zmm17,zmm6,zmm2
   7f9e0:	62 b1 fd 48 6f f0                               	vmovdqa64 zmm6,zmm16
   7f9e6:	62 f1 fd 40 73 d4 10                            	vpsrlq zmm16,zmm4,0x10
   7f9ed:	62 91 dd 48 72 e0 34                            	vpsraq zmm4,zmm24,0x34
   7f9f4:	62 e1 e5 48 db d2                               	vpandq zmm18,zmm3,zmm2
   7f9fa:	62 f1 bd 40 db da                               	vpandq zmm3,zmm24,zmm2
   7fa00:	62 51 f5 48 fb f1                               	vpsubq zmm14,zmm1,zmm9
   7fa06:	62 51 f5 40 fb fb                               	vpsubq zmm15,zmm17,zmm11
   7fa0c:	62 c1 ed 40 fb fc                               	vpsubq zmm23,zmm18,zmm12
   7fa12:	62 d1 f5 48 d4 c9                               	vpaddq zmm1,zmm1,zmm9
   7fa18:	62 51 f5 40 d4 c3                               	vpaddq zmm8,zmm17,zmm11
   7fa1e:	62 f1 a5 48 73 d0 34                            	vpsrlq zmm11,zmm0,0x34
   7fa25:	62 51 ed 40 d4 cc                               	vpaddq zmm9,zmm18,zmm12
   7fa2b:	62 f1 fd 48 db c2                               	vpandq zmm0,zmm0,zmm2
   7fa31:	62 e1 fd 58 d4 0d d5 72 f8 ff                   	vpaddq zmm17,zmm0,QWORD BCST [rip+0xfffffffffff872d5]        # 6d10 <GCC_except_table711+0x220>
   7fa3b:	62 51 fd 40 d4 e5                               	vpaddq zmm12,zmm16,zmm13
   7fa41:	62 f1 8d 48 d4 e4                               	vpaddq zmm4,zmm14,zmm4
   7fa47:	62 f1 a5 48 d4 c9                               	vpaddq zmm1,zmm11,zmm1
   7fa4d:	62 71 dd 48 db f2                               	vpandq zmm14,zmm4,zmm2
   7fa53:	62 f1 dd 48 72 e4 34                            	vpsraq zmm4,zmm4,0x34
   7fa5a:	62 f1 a5 48 73 d1 34                            	vpsrlq zmm11,zmm1,0x34
   7fa61:	62 f1 f5 48 db ca                               	vpandq zmm1,zmm1,zmm2
   7fa67:	62 f1 85 48 d4 e4                               	vpaddq zmm4,zmm15,zmm4
   7fa6d:	62 51 a5 48 d4 c0                               	vpaddq zmm8,zmm11,zmm8
   7fa73:	62 71 dd 48 db fa                               	vpandq zmm15,zmm4,zmm2
   7fa79:	62 61 85 58 d4 44 24 12                         	vpaddq zmm24,zmm15,QWORD BCST [rsp+0x90]
   7fa81:	62 f1 dd 48 72 e4 34                            	vpsraq zmm4,zmm4,0x34
   7fa88:	62 d1 a5 48 73 d0 34                            	vpsrlq zmm11,zmm8,0x34
   7fa8f:	62 71 bd 48 db c2                               	vpandq zmm8,zmm8,zmm2
   7fa95:	62 f1 c5 40 d4 e4                               	vpaddq zmm4,zmm23,zmm4
   7fa9b:	62 c1 fd 40 fb fd                               	vpsubq zmm23,zmm16,zmm13
   7faa1:	62 51 a5 48 d4 c9                               	vpaddq zmm9,zmm11,zmm9
   7faa7:	62 71 dd 48 db d2                               	vpandq zmm10,zmm4,zmm2
   7faad:	62 f1 dd 48 72 e4 34                            	vpsraq zmm4,zmm4,0x34
   7fab4:	62 d1 a5 48 73 d1 34                            	vpsrlq zmm11,zmm9,0x34
   7fabb:	62 71 b5 48 db ca                               	vpandq zmm9,zmm9,zmm2
   7fac1:	62 f1 c5 40 d4 e4                               	vpaddq zmm4,zmm23,zmm4
   7fac7:	62 e1 e5 58 d4 3d 57 72 f8 ff                   	vpaddq zmm23,zmm3,QWORD BCST [rip+0xfffffffffff87257]        # 6d28 <GCC_except_table711+0x238>
   7fad1:	62 93 dd 48 1e c9 01                            	vpcmpltuq k1,zmm4,zmm25
   7fad8:	62 b1 ed 40 72 e1 34                            	vpsraq zmm18,zmm17,0x34
   7fadf:	62 41 fd 49 6f c7                               	vmovdqa64 zmm24{k1},zmm15
   7fae5:	62 71 ad 58 d4 7c 24 13                         	vpaddq zmm15,zmm10,QWORD BCST [rsp+0x98]
   7faed:	62 e1 fd 49 6f fb                               	vmovdqa64 zmm23{k1},zmm3
   7faf3:	62 f1 8d 58 d4 5c 24 11                         	vpaddq zmm3,zmm14,QWORD BCST [rsp+0x88]
   7fafb:	62 51 fd 49 6f fa                               	vmovdqa64 zmm15{k1},zmm10
   7fb01:	62 72 fd 48 59 54 24 14                         	vpbroadcastq zmm10,QWORD PTR [rsp+0xa0]
   7fb09:	62 e1 7c 28 11 5c 24 04                         	vmovups YMMWORD PTR [rsp+0x80],ymm19
   7fb11:	48 89 8c 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rcx
   7fb19:	62 e1 f5 58 fb 5c 24 11                         	vpsubq zmm19,zmm1,QWORD BCST [rsp+0x88]
   7fb21:	62 71 b5 58 fb 6c 24 13                         	vpsubq zmm13,zmm9,QWORD BCST [rsp+0x98]
   7fb29:	62 d1 fd 49 6f de                               	vmovdqa64 zmm3{k1},zmm14
   7fb2f:	62 b1 8d 48 73 d7 34                            	vpsrlq zmm14,zmm23,0x34
   7fb36:	62 e1 c5 40 db fa                               	vpandq zmm23,zmm23,zmm2
   7fb3c:	62 71 8d 48 d4 f3                               	vpaddq zmm14,zmm14,zmm3
   7fb42:	62 d1 e5 48 73 d6 34                            	vpsrlq zmm3,zmm14,0x34
   7fb49:	62 91 e5 48 d4 d8                               	vpaddq zmm3,zmm3,zmm24
   7fb4f:	62 11 fd 49 6f d1                               	vmovdqa64 zmm10{k1},zmm25
   7fb55:	62 f1 ad 48 d4 e4                               	vpaddq zmm4,zmm10,zmm4
   7fb5b:	62 f1 ad 48 73 d3 34                            	vpsrlq zmm10,zmm3,0x34
   7fb62:	62 51 ad 48 d4 ff                               	vpaddq zmm15,zmm10,zmm15
   7fb68:	62 d1 ad 48 73 d7 34                            	vpsrlq zmm10,zmm15,0x34
   7fb6f:	62 f1 ad 48 d4 e4                               	vpaddq zmm4,zmm10,zmm4
   7fb75:	62 51 a5 48 d4 d4                               	vpaddq zmm10,zmm11,zmm12
   7fb7b:	62 71 bd 58 fb 64 24 12                         	vpsubq zmm12,zmm8,QWORD BCST [rsp+0x90]
   7fb83:	62 e1 ad 58 fb 44 24 14                         	vpsubq zmm16,zmm10,QWORD BCST [rsp+0xa0]
   7fb8b:	62 31 e5 40 d4 da                               	vpaddq zmm11,zmm19,zmm18
   7fb91:	62 d1 ed 40 72 e3 34                            	vpsraq zmm18,zmm11,0x34
   7fb98:	62 e1 dd 48 db da                               	vpandq zmm19,zmm4,zmm2
   7fb9e:	62 f1 fd 48 6f 64 24 0e                         	vmovdqa64 zmm4,ZMMWORD PTR [rsp+0x380]
   7fba6:	62 31 9d 48 d4 e2                               	vpaddq zmm12,zmm12,zmm18
   7fbac:	62 d1 ed 40 72 e4 34                            	vpsraq zmm18,zmm12,0x34
   7fbb3:	62 31 95 48 d4 ea                               	vpaddq zmm13,zmm13,zmm18
   7fbb9:	62 d1 ed 40 72 e5 34                            	vpsraq zmm18,zmm13,0x34
   7fbc0:	62 a1 fd 40 d4 c2                               	vpaddq zmm16,zmm16,zmm18
   7fbc6:	62 93 fd 40 1e c9 01                            	vpcmpltuq k1,zmm16,zmm25
   7fbcd:	62 f1 f5 41 db c2                               	vpandq zmm0{k1},zmm17,zmm2
   7fbd3:	62 f1 a5 49 db ca                               	vpandq zmm1{k1},zmm11,zmm2
   7fbd9:	62 71 fd 41 db d2                               	vpandq zmm10{k1},zmm16,zmm2
   7fbdf:	62 e1 fd 48 6f c6                               	vmovdqa64 zmm16,zmm6
   7fbe5:	62 71 9d 49 db c2                               	vpandq zmm8{k1},zmm12,zmm2
   7fbeb:	62 71 95 49 db ca                               	vpandq zmm9{k1},zmm13,zmm2
   7fbf1:	62 f1 fd 48 7f 42 f2                            	vmovdqa64 ZMMWORD PTR [rdx-0x380],zmm0
   7fbf8:	62 f1 fd 48 7f 4a f3                            	vmovdqa64 ZMMWORD PTR [rdx-0x340],zmm1
   7fbff:	62 f1 fd 48 6f 4c 24 10                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x400]
   7fc07:	62 71 fd 48 7f 42 f4                            	vmovdqa64 ZMMWORD PTR [rdx-0x300],zmm8
   7fc0e:	62 71 fd 48 7f 4a f5                            	vmovdqa64 ZMMWORD PTR [rdx-0x2c0],zmm9
   7fc15:	62 71 fd 48 7f 52 f6                            	vmovdqa64 ZMMWORD PTR [rdx-0x280],zmm10
   7fc1c:	62 e1 fd 48 7f 7a f7                            	vmovdqa64 ZMMWORD PTR [rdx-0x240],zmm23
   7fc23:	62 b3 f5 48 3a c5 01                            	vinserti64x4 zmm0,zmm1,ymm21,0x1
   7fc2a:	62 e1 e5 48 db ea                               	vpandq zmm21,zmm3,zmm2
   7fc30:	62 f3 dd 48 3a 5c 24 1a 01                      	vinserti64x4 zmm3,zmm4,YMMWORD PTR [rsp+0x340],0x1
   7fc39:	62 b3 dd 40 3a ce 01                            	vinserti64x4 zmm1,zmm20,ymm22,0x1
   7fc40:	62 e1 8d 48 db f2                               	vpandq zmm22,zmm14,zmm2
   7fc46:	62 e1 85 48 db e2                               	vpandq zmm20,zmm15,zmm2
   7fc4c:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   7fc52:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   7fc58:	62 e1 fd 48 7f 72 f8                            	vmovdqa64 ZMMWORD PTR [rdx-0x200],zmm22
   7fc5f:	62 e1 fd 48 7f 6a f9                            	vmovdqa64 ZMMWORD PTR [rdx-0x1c0],zmm21
   7fc66:	62 e1 fd 48 7f 62 fa                            	vmovdqa64 ZMMWORD PTR [rdx-0x180],zmm20
   7fc6d:	62 e1 fd 48 7f 5a fb                            	vmovdqa64 ZMMWORD PTR [rdx-0x140],zmm19
   7fc74:	62 f1 fd 48 6f f4                               	vmovdqa64 zmm6,zmm4
   7fc7a:	62 f1 e5 48 6c cf                               	vpunpcklqdq zmm1,zmm3,zmm7
   7fc80:	62 f1 e5 48 6d df                               	vpunpckhqdq zmm3,zmm3,zmm7
   7fc86:	62 f2 fd 40 7e f1                               	vpermt2q zmm6,zmm16,zmm1
   7fc8c:	62 f2 9d 40 7e e1                               	vpermt2q zmm4,zmm28,zmm1
   7fc92:	62 f1 fd 48 6f c8                               	vmovdqa64 zmm1,zmm0
   7fc98:	62 f2 9d 40 7e c3                               	vpermt2q zmm0,zmm28,zmm3
   7fc9e:	62 f2 fd 40 7e cb                               	vpermt2q zmm1,zmm16,zmm3
   7fca4:	62 f1 cd 48 db da                               	vpandq zmm3,zmm6,zmm2
   7fcaa:	62 f3 f5 48 71 f6 0c                            	vpshldq zmm6,zmm1,zmm6,0xc
   7fcb1:	62 f3 dd 48 71 c9 18                            	vpshldq zmm1,zmm4,zmm1,0x18
   7fcb8:	62 f3 fd 48 71 e4 24                            	vpshldq zmm4,zmm0,zmm4,0x24
   7fcbf:	62 f1 c5 48 73 d0 10                            	vpsrlq zmm7,zmm0,0x10
   7fcc6:	62 f1 fd 48 7f 5a ed                            	vmovdqa64 ZMMWORD PTR [rdx-0x4c0],zmm3
   7fccd:	62 71 cd 48 db ca                               	vpandq zmm9,zmm6,zmm2
   7fcd3:	62 71 f5 48 db c2                               	vpandq zmm8,zmm1,zmm2
   7fcd9:	62 f1 dd 48 db f2                               	vpandq zmm6,zmm4,zmm2
   7fcdf:	62 71 fd 48 7f 4a ee                            	vmovdqa64 ZMMWORD PTR [rdx-0x480],zmm9
   7fce6:	62 71 fd 48 7f 42 ef                            	vmovdqa64 ZMMWORD PTR [rdx-0x440],zmm8
   7fced:	62 f1 fd 48 7f 72 f0                            	vmovdqa64 ZMMWORD PTR [rdx-0x400],zmm6
   7fcf4:	62 f1 fd 48 7f 7a f1                            	vmovdqa64 ZMMWORD PTR [rdx-0x3c0],zmm7
   7fcfb:	4c 39 e8                                        	cmp    rax,r13
   7fcfe:	0f 83 b6 5d 00 00                               	jae    85aba <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x65da>
   7fd04:	62 f1 fd 48 6f 44 24 14                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x500]
   7fd0c:	62 f1 fd 48 6f 4c 24 12                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x480]
   7fd14:	62 13 ad 40 3a df 01                            	vinserti64x4 zmm11,zmm26,ymm31,0x1
   7fd1b:	62 f3 a5 40 3a ed 01                            	vinserti64x4 zmm5,zmm27,ymm5,0x1
   7fd22:	66 b8 11 11                                     	mov    ax,0x1111
   7fd26:	62 62 fd 48 59 3d 40 6f f8 ff                   	vpbroadcastq zmm31,QWORD PTR [rip+0xfffffffffff86f40]        # 6c70 <GCC_except_table711+0x180>
   7fd30:	62 81 fd 48 6f d4                               	vmovdqa64 zmm18,zmm28
   7fd36:	62 e1 7c 28 28 0d a0 7a f8 ff                   	vmovaps ymm17,YMMWORD PTR [rip+0xfffffffffff87aa0]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   7fd40:	62 72 fd 48 59 3d 0e 70 f8 ff                   	vpbroadcastq zmm15,QWORD PTR [rip+0xfffffffffff8700e]        # 6d58 <GCC_except_table711+0x268>
   7fd4a:	48 89 f7                                        	mov    rdi,rsi
   7fd4d:	62 71 a5 48 6d e5                               	vpunpckhqdq zmm12,zmm11,zmm5
   7fd53:	c5 fb 92 c8                                     	kmovd  k1,eax
   7fd57:	62 93 fd 48 3a c5 01                            	vinserti64x4 zmm0,zmm0,ymm29,0x1
   7fd5e:	62 93 f5 48 3a ce 01                            	vinserti64x4 zmm1,zmm1,ymm30,0x1
   7fd65:	62 71 fd 48 6d d1                               	vpunpckhqdq zmm10,zmm0,zmm1
   7fd6b:	62 f1 fd 48 6c c1                               	vpunpcklqdq zmm0,zmm0,zmm1
   7fd71:	62 f1 a5 48 6c cd                               	vpunpcklqdq zmm1,zmm11,zmm5
   7fd77:	62 51 fd 48 6f ea                               	vmovdqa64 zmm13,zmm10
   7fd7d:	62 f1 fd 48 6f e8                               	vmovdqa64 zmm5,zmm0
   7fd83:	62 52 9d 40 7e ec                               	vpermt2q zmm13,zmm28,zmm12
   7fd89:	62 f2 9d 40 7e e9                               	vpermt2q zmm5,zmm28,zmm1
   7fd8f:	62 52 fd 40 7e d4                               	vpermt2q zmm10,zmm16,zmm12
   7fd95:	62 f2 fd 40 7e c1                               	vpermt2q zmm0,zmm16,zmm1
   7fd9b:	62 51 7e c9 6f 21                               	vmovdqu32 zmm12{k1}{z},ZMMWORD PTR [r9]
   7fda1:	62 73 95 48 71 dd 24                            	vpshldq zmm11,zmm13,zmm5,0x24
   7fda8:	62 d1 dd 48 73 d5 10                            	vpsrlq zmm4,zmm13,0x10
   7fdaf:	62 d3 d5 48 71 ea 18                            	vpshldq zmm5,zmm5,zmm10,0x18
   7fdb6:	62 f3 ad 48 71 c8 0c                            	vpshldq zmm1,zmm10,zmm0,0xc
   7fdbd:	62 51 7e c9 6f 51 01                            	vmovdqu32 zmm10{k1}{z},ZMMWORD PTR [r9+0x40]
   7fdc4:	c5 7d 6f 2d 94 7b f8 ff                         	vmovdqa ymm13,YMMWORD PTR [rip+0xfffffffffff87b94]        # 7960 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x9c0>
   7fdcc:	49 83 e9 80                                     	sub    r9,0xffffffffffffff80
   7fdd0:	62 52 15 48 7e e2                               	vpermt2d zmm12,zmm13,zmm10
   7fdd6:	c4 62 1d 45 15 c1 79 f8 ff                      	vpsrlvd ymm10,ymm12,YMMWORD PTR [rip+0xfffffffffff879c1]        # 77a0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x800>
   7fddf:	c5 2d db 15 79 79 f8 ff                         	vpand  ymm10,ymm10,YMMWORD PTR [rip+0xfffffffffff87979]        # 7760 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x7c0>
   7fde7:	c4 43 7d 39 d4 01                               	vextracti128 xmm12,ymm10,0x1
   7fded:	c4 41 29 eb d4                                  	vpor   xmm10,xmm10,xmm12
   7fdf2:	c4 41 79 70 e2 ee                               	vpshufd xmm12,xmm10,0xee
   7fdf8:	c4 41 29 eb d4                                  	vpor   xmm10,xmm10,xmm12
   7fdfd:	c4 41 79 70 e2 55                               	vpshufd xmm12,xmm10,0x55
   7fe03:	c4 41 29 eb d4                                  	vpor   xmm10,xmm10,xmm12
   7fe08:	c5 79 7e d0                                     	vmovd  eax,xmm10
   7fe0c:	c5 fb 92 c8                                     	kmovd  k1,eax
   7fe10:	62 72 85 51 64 25 0e 6f f8 ff                   	vpblendmq zmm12{k1},zmm31,QWORD BCST [rip+0xfffffffffff86f0e]        # 6d28 <GCC_except_table711+0x238>
   7fe1a:	48 b8 31 e1 72 4e 64 30 00 00                   	movabs rax,0x30644e72e131
   7fe24:	62 71 fd c9 6f d2                               	vmovdqa64 zmm10{k1}{z},zmm2
   7fe2a:	62 f3 ad 48 25 c2 6c                            	vpternlogq zmm0,zmm10,zmm2,0x6c
   7fe31:	62 72 fe 48 38 e9                               	vpmovm2q zmm13,k1
   7fe37:	62 f3 ad 48 25 ca 6c                            	vpternlogq zmm1,zmm10,zmm2,0x6c
   7fe3e:	62 f3 ad 48 25 ea 6c                            	vpternlogq zmm5,zmm10,zmm2,0x6c
   7fe45:	62 73 ad 48 25 da 6c                            	vpternlogq zmm11,zmm10,zmm2,0x6c
   7fe4c:	62 d1 fd 48 fb c5                               	vpsubq zmm0,zmm0,zmm13
   7fe52:	62 f1 fd 48 fb c3                               	vpsubq zmm0,zmm0,zmm3
   7fe58:	62 f2 fd 48 59 1d 0e 6f f8 ff                   	vpbroadcastq zmm3,QWORD PTR [rip+0xfffffffffff86f0e]        # 6d70 <GCC_except_table711+0x280>
   7fe62:	62 d1 fd 48 d4 c4                               	vpaddq zmm0,zmm0,zmm12
   7fe68:	62 61 fd 48 db d2                               	vpandq zmm26,zmm0,zmm2
   7fe6e:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   7fe75:	62 f1 f5 48 d4 c0                               	vpaddq zmm0,zmm1,zmm0
   7fe7b:	62 f2 fd 48 59 0d f3 6d f8 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff86df3]        # 6c78 <GCC_except_table711+0x188>
   7fe85:	62 f2 e5 59 64 1d d9 6e f8 ff                   	vpblendmq zmm3{k1},zmm3,QWORD BCST [rip+0xfffffffffff86ed9]        # 6d68 <GCC_except_table711+0x278>
   7fe8f:	62 d1 fd 48 fb c1                               	vpsubq zmm0,zmm0,zmm9
   7fe95:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   7fe9a:	62 f2 f5 59 64 0d ac 6e f8 ff                   	vpblendmq zmm1{k1},zmm1,QWORD BCST [rip+0xfffffffffff86eac]        # 6d50 <GCC_except_table711+0x260>
   7fea4:	62 f1 fd 48 d4 c3                               	vpaddq zmm0,zmm0,zmm3
   7feaa:	62 d1 dd 48 ef da                               	vpxorq zmm3,zmm4,zmm10
   7feb0:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   7feb4:	62 61 fd 48 db e2                               	vpandq zmm28,zmm0,zmm2
   7feba:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   7fec1:	62 f1 d5 48 d4 c0                               	vpaddq zmm0,zmm5,zmm0
   7fec7:	62 d1 fd 48 fb c0                               	vpsubq zmm0,zmm0,zmm8
   7fecd:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   7fed2:	62 f1 fd 48 d4 c1                               	vpaddq zmm0,zmm0,zmm1
   7fed8:	62 f2 fd 48 59 0d d6 6d f8 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff86dd6]        # 6cb8 <GCC_except_table711+0x1c8>
   7fee2:	62 f1 fd 48 db ea                               	vpandq zmm5,zmm0,zmm2
   7fee8:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   7feef:	62 f1 a5 48 d4 c0                               	vpaddq zmm0,zmm11,zmm0
   7fef5:	62 f1 fd 48 fb c6                               	vpsubq zmm0,zmm0,zmm6
   7fefb:	62 f2 f5 59 64 0d db 6d f8 ff                   	vpblendmq zmm1{k1},zmm1,QWORD BCST [rip+0xfffffffffff86ddb]        # 6ce0 <GCC_except_table711+0x1f0>
   7ff05:	62 f1 fd 48 d4 c1                               	vpaddq zmm0,zmm0,zmm1
   7ff0b:	62 f2 fd 48 59 0d e3 6d f8 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff86de3]        # 6cf8 <GCC_except_table711+0x208>
   7ff15:	62 f1 fd 48 db f2                               	vpandq zmm6,zmm0,zmm2
   7ff1b:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   7ff22:	62 f1 e5 48 d4 c0                               	vpaddq zmm0,zmm3,zmm0
   7ff28:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   7ff2c:	62 f1 fd 48 fb c7                               	vpsubq zmm0,zmm0,zmm7
   7ff32:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   7ff36:	62 f2 f5 59 64 0d 60 6d f8 ff                   	vpblendmq zmm1{k1},zmm1,QWORD BCST [rip+0xfffffffffff86d60]        # 6ca0 <GCC_except_table711+0x1b0>
   7ff40:	62 71 fd 48 6f 74 24 13                         	vmovdqa64 zmm14,ZMMWORD PTR [rsp+0x4c0]
   7ff48:	62 e1 7c 28 11 4c 24 04                         	vmovups YMMWORD PTR [rsp+0x80],ymm17
   7ff50:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   7ff58:	62 71 fd 48 6f 6c 24 0b                         	vmovdqa64 zmm13,ZMMWORD PTR [rsp+0x2c0]
   7ff60:	62 81 fd 48 6f cf                               	vmovdqa64 zmm17,zmm31
   7ff66:	62 71 fd 48 6f 64 24 09                         	vmovdqa64 zmm12,ZMMWORD PTR [rsp+0x240]
   7ff6e:	62 71 fd 48 6f 5c 24 0a                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x280]
   7ff76:	62 71 fd 48 6f 54 24 08                         	vmovdqa64 zmm10,ZMMWORD PTR [rsp+0x200]
   7ff7e:	4c 8b 9c 24 c0 03 00 00                         	mov    r11,QWORD PTR [rsp+0x3c0]
   7ff86:	4c 8b 84 24 40 04 00 00                         	mov    r8,QWORD PTR [rsp+0x440]
   7ff8e:	4c 8b 94 24 40 07 00 00                         	mov    r10,QWORD PTR [rsp+0x740]
   7ff96:	4c 8b 64 24 10                                  	mov    r12,QWORD PTR [rsp+0x10]
   7ff9b:	62 62 fd 48 59 4c 24 13                         	vpbroadcastq zmm25,QWORD PTR [rsp+0x98]
   7ffa3:	62 62 fd 48 59 6c 24 11                         	vpbroadcastq zmm29,QWORD PTR [rsp+0x88]
   7ffab:	62 62 fd 48 59 5c 24 12                         	vpbroadcastq zmm27,QWORD PTR [rsp+0x90]
   7ffb3:	62 62 fd 48 59 44 24 14                         	vpbroadcastq zmm24,QWORD PTR [rsp+0xa0]
   7ffbb:	49 ff c3                                        	inc    r11
   7ffbe:	62 f1 fd 48 d4 c1                               	vpaddq zmm0,zmm0,zmm1
   7ffc4:	62 52 cd 48 b5 c6                               	vpmadd52huq zmm8,zmm6,zmm14
   7ffca:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   7ffce:	62 d2 ad 40 b5 ce                               	vpmadd52huq zmm1,zmm26,zmm14
   7ffd4:	62 d2 9d 40 b5 de                               	vpmadd52huq zmm3,zmm28,zmm14
   7ffda:	62 52 d5 48 b5 ce                               	vpmadd52huq zmm9,zmm5,zmm14
   7ffe0:	62 61 fd 48 db f2                               	vpandq zmm30,zmm0,zmm2
   7ffe6:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7ffea:	62 d2 ad 40 b4 c6                               	vpmadd52luq zmm0,zmm26,zmm14
   7fff0:	62 d2 8d 40 b5 fd                               	vpmadd52huq zmm7,zmm30,zmm13
   7fff6:	62 52 8d 40 b4 c6                               	vpmadd52luq zmm8,zmm30,zmm14
   7fffc:	62 d2 9d 40 b4 ce                               	vpmadd52luq zmm1,zmm28,zmm14
   80002:	62 d2 d5 48 b4 de                               	vpmadd52luq zmm3,zmm5,zmm14
   80008:	62 52 cd 48 b4 ce                               	vpmadd52luq zmm9,zmm6,zmm14
   8000e:	62 d2 fd 48 b4 e7                               	vpmadd52luq zmm4,zmm0,zmm15
   80014:	62 f1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm2
   8001a:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   80021:	62 12 dd 48 b5 c1                               	vpmadd52huq zmm8,zmm4,zmm25
   80027:	62 92 dd 48 b5 dd                               	vpmadd52huq zmm3,zmm4,zmm29
   8002d:	62 12 dd 48 b5 cb                               	vpmadd52huq zmm9,zmm4,zmm27
   80033:	62 92 dd 48 b5 c7                               	vpmadd52huq zmm0,zmm4,zmm31
   80039:	62 92 dd 48 b4 cd                               	vpmadd52luq zmm1,zmm4,zmm29
   8003f:	62 01 05 00 ef ff                               	vpxord xmm31,xmm31,xmm31
   80045:	62 42 8d 40 b5 fe                               	vpmadd52huq zmm31,zmm30,zmm14
   8004b:	62 12 dd 48 b4 c0                               	vpmadd52luq zmm8,zmm4,zmm24
   80051:	62 f1 f5 48 d4 c0                               	vpaddq zmm0,zmm1,zmm0
   80057:	62 92 dd 48 b4 db                               	vpmadd52luq zmm3,zmm4,zmm27
   8005d:	62 12 dd 48 b4 c9                               	vpmadd52luq zmm9,zmm4,zmm25
   80063:	62 02 dd 48 b5 f8                               	vpmadd52huq zmm31,zmm4,zmm24
   80069:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8006d:	62 d2 ad 40 b4 c5                               	vpmadd52luq zmm0,zmm26,zmm13
   80073:	62 52 d5 48 b5 c5                               	vpmadd52huq zmm8,zmm5,zmm13
   80079:	62 d2 ad 40 b5 dd                               	vpmadd52huq zmm3,zmm26,zmm13
   8007f:	62 52 9d 40 b5 cd                               	vpmadd52huq zmm9,zmm28,zmm13
   80085:	62 42 cd 48 b5 fd                               	vpmadd52huq zmm31,zmm6,zmm13
   8008b:	62 d2 fd 48 b4 cf                               	vpmadd52luq zmm1,zmm0,zmm15
   80091:	62 f1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm2
   80097:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   8009e:	62 52 cd 48 b4 c5                               	vpmadd52luq zmm8,zmm6,zmm13
   800a4:	62 d2 9d 40 b4 dd                               	vpmadd52luq zmm3,zmm28,zmm13
   800aa:	62 52 d5 48 b4 cd                               	vpmadd52luq zmm9,zmm5,zmm13
   800b0:	62 42 8d 40 b4 fd                               	vpmadd52luq zmm31,zmm30,zmm13
   800b6:	62 b2 f5 48 b5 c1                               	vpmadd52huq zmm0,zmm1,zmm17
   800bc:	62 92 f5 48 b5 f8                               	vpmadd52huq zmm7,zmm1,zmm24
   800c2:	62 12 f5 48 b5 c3                               	vpmadd52huq zmm8,zmm1,zmm27
   800c8:	62 12 f5 48 b5 cd                               	vpmadd52huq zmm9,zmm1,zmm29
   800ce:	62 92 f5 48 b4 dd                               	vpmadd52luq zmm3,zmm1,zmm29
   800d4:	62 02 f5 48 b5 f9                               	vpmadd52huq zmm31,zmm1,zmm25
   800da:	62 d2 cd 48 b5 fc                               	vpmadd52huq zmm7,zmm6,zmm12
   800e0:	62 12 f5 48 b4 c1                               	vpmadd52luq zmm8,zmm1,zmm25
   800e6:	62 f1 e5 48 d4 c0                               	vpaddq zmm0,zmm3,zmm0
   800ec:	62 12 f5 48 b4 cb                               	vpmadd52luq zmm9,zmm1,zmm27
   800f2:	62 02 f5 48 b4 f8                               	vpmadd52luq zmm31,zmm1,zmm24
   800f8:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   800fc:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   80100:	62 d2 ad 40 b4 c4                               	vpmadd52luq zmm0,zmm26,zmm12
   80106:	62 d2 8d 40 b4 fc                               	vpmadd52luq zmm7,zmm30,zmm12
   8010c:	62 52 9d 40 b5 c4                               	vpmadd52huq zmm8,zmm28,zmm12
   80112:	62 52 ad 40 b5 cc                               	vpmadd52huq zmm9,zmm26,zmm12
   80118:	62 42 d5 48 b5 fc                               	vpmadd52huq zmm31,zmm5,zmm12
   8011e:	62 d2 fd 48 b4 cf                               	vpmadd52luq zmm1,zmm0,zmm15
   80124:	62 f1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm2
   8012a:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   80131:	62 52 d5 48 b4 c4                               	vpmadd52luq zmm8,zmm5,zmm12
   80137:	62 52 9d 40 b4 cc                               	vpmadd52luq zmm9,zmm28,zmm12
   8013d:	62 42 cd 48 b4 fc                               	vpmadd52luq zmm31,zmm6,zmm12
   80143:	62 b2 f5 48 b5 c1                               	vpmadd52huq zmm0,zmm1,zmm17
   80149:	62 92 f5 48 b5 f9                               	vpmadd52huq zmm7,zmm1,zmm25
   8014f:	62 12 f5 48 b5 c5                               	vpmadd52huq zmm8,zmm1,zmm29
   80155:	62 12 f5 48 b4 cd                               	vpmadd52luq zmm9,zmm1,zmm29
   8015b:	62 02 f5 48 b5 fb                               	vpmadd52huq zmm31,zmm1,zmm27
   80161:	62 92 f5 48 b4 f8                               	vpmadd52luq zmm7,zmm1,zmm24
   80167:	62 12 f5 48 b4 c3                               	vpmadd52luq zmm8,zmm1,zmm27
   8016d:	62 f1 b5 48 d4 c0                               	vpaddq zmm0,zmm9,zmm0
   80173:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80178:	62 52 8d 40 b5 cc                               	vpmadd52huq zmm9,zmm30,zmm12
   8017e:	62 02 f5 48 b4 f9                               	vpmadd52luq zmm31,zmm1,zmm25
   80184:	62 d2 ad 40 b4 c3                               	vpmadd52luq zmm0,zmm26,zmm11
   8018a:	62 d2 d5 48 b5 fb                               	vpmadd52huq zmm7,zmm5,zmm11
   80190:	62 52 ad 40 b5 c3                               	vpmadd52huq zmm8,zmm26,zmm11
   80196:	62 12 f5 48 b5 c8                               	vpmadd52huq zmm9,zmm1,zmm24
   8019c:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   801a0:	62 42 9d 40 b5 fb                               	vpmadd52huq zmm31,zmm28,zmm11
   801a6:	62 d2 fd 48 b4 cf                               	vpmadd52luq zmm1,zmm0,zmm15
   801ac:	62 f1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm2
   801b2:	62 d2 cd 48 b4 fb                               	vpmadd52luq zmm7,zmm6,zmm11
   801b8:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   801bf:	62 52 9d 40 b4 c3                               	vpmadd52luq zmm8,zmm28,zmm11
   801c5:	62 52 cd 48 b5 cb                               	vpmadd52huq zmm9,zmm6,zmm11
   801cb:	62 42 d5 48 b4 fb                               	vpmadd52luq zmm31,zmm5,zmm11
   801d1:	62 b2 f5 48 b5 c1                               	vpmadd52huq zmm0,zmm1,zmm17
   801d7:	62 92 f5 48 b5 fb                               	vpmadd52huq zmm7,zmm1,zmm27
   801dd:	62 12 f5 48 b4 c5                               	vpmadd52luq zmm8,zmm1,zmm29
   801e3:	62 52 8d 40 b4 cb                               	vpmadd52luq zmm9,zmm30,zmm11
   801e9:	62 02 f5 48 b5 fd                               	vpmadd52huq zmm31,zmm1,zmm29
   801ef:	62 92 f5 48 b4 f9                               	vpmadd52luq zmm7,zmm1,zmm25
   801f5:	62 f1 bd 48 d4 c0                               	vpaddq zmm0,zmm8,zmm0
   801fb:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   80200:	62 52 8d 40 b5 c3                               	vpmadd52huq zmm8,zmm30,zmm11
   80206:	62 12 f5 48 b5 c9                               	vpmadd52huq zmm9,zmm1,zmm25
   8020c:	62 02 f5 48 b4 fb                               	vpmadd52luq zmm31,zmm1,zmm27
   80212:	62 d2 ad 40 b4 c2                               	vpmadd52luq zmm0,zmm26,zmm10
   80218:	62 d2 9d 40 b5 fa                               	vpmadd52huq zmm7,zmm28,zmm10
   8021e:	62 12 f5 48 b5 c0                               	vpmadd52huq zmm8,zmm1,zmm24
   80224:	62 12 f5 48 b4 c8                               	vpmadd52luq zmm9,zmm1,zmm24
   8022a:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8022e:	62 d2 8d 40 b5 ca                               	vpmadd52huq zmm1,zmm30,zmm10
   80234:	62 42 ad 40 b5 fa                               	vpmadd52huq zmm31,zmm26,zmm10
   8023a:	62 01 2d 00 ef d2                               	vpxord xmm26,xmm26,xmm26
   80240:	62 22 ad 48 b5 d6                               	vpmadd52huq zmm26,zmm10,zmm22
   80246:	62 d2 fd 48 b4 df                               	vpmadd52luq zmm3,zmm0,zmm15
   8024c:	62 d2 d5 48 b4 fa                               	vpmadd52luq zmm7,zmm5,zmm10
   80252:	62 52 cd 48 b5 c2                               	vpmadd52huq zmm8,zmm6,zmm10
   80258:	62 52 d5 48 b5 ca                               	vpmadd52huq zmm9,zmm5,zmm10
   8025e:	62 42 9d 40 b4 fa                               	vpmadd52luq zmm31,zmm28,zmm10
   80264:	62 f1 dd 48 73 f3 04                            	vpsllq zmm4,zmm3,0x4
   8026b:	62 52 8d 40 b4 c2                               	vpmadd52luq zmm8,zmm30,zmm10
   80271:	62 62 fd 48 59 35 cd 69 f8 ff                   	vpbroadcastq zmm30,QWORD PTR [rip+0xfffffffffff869cd]        # 6c48 <GCC_except_table711+0x158>
   8027b:	62 52 cd 48 b4 ca                               	vpmadd52luq zmm9,zmm6,zmm10
   80281:	62 91 e5 48 db de                               	vpandq zmm3,zmm3,zmm30
   80287:	62 91 fd 48 d4 c6                               	vpaddq zmm0,zmm0,zmm30
   8028d:	62 92 e5 48 b5 fd                               	vpmadd52huq zmm7,zmm3,zmm29
   80293:	62 12 e5 48 b5 cb                               	vpmadd52huq zmm9,zmm3,zmm27
   80299:	62 12 e5 48 b5 c1                               	vpmadd52huq zmm8,zmm3,zmm25
   8029f:	62 02 e5 48 b4 fd                               	vpmadd52luq zmm31,zmm3,zmm29
   802a5:	62 62 fd 48 59 2d 51 6a f8 ff                   	vpbroadcastq zmm29,QWORD PTR [rip+0xfffffffffff86a51]        # 6d00 <GCC_except_table711+0x210>
   802af:	62 f1 fd 48 73 d0 30                            	vpsrlq zmm0,zmm0,0x30
   802b6:	62 92 e5 48 b5 c8                               	vpmadd52huq zmm1,zmm3,zmm24
   802bc:	62 b2 dd 48 b5 c1                               	vpmadd52huq zmm0,zmm4,zmm17
   802c2:	62 92 e5 48 b4 fb                               	vpmadd52luq zmm7,zmm3,zmm27
   802c8:	62 12 e5 48 b4 c9                               	vpmadd52luq zmm9,zmm3,zmm25
   802ce:	62 12 e5 48 b4 c0                               	vpmadd52luq zmm8,zmm3,zmm24
   802d4:	62 91 e5 48 73 f7 04                            	vpsllq zmm3,zmm31,0x4
   802db:	62 f1 f5 48 73 f1 04                            	vpsllq zmm1,zmm1,0x4
   802e2:	62 01 35 00 ef c9                               	vpxord xmm25,xmm25,xmm25
   802e8:	62 22 ad 48 b5 cf                               	vpmadd52huq zmm25,zmm10,zmm23
   802ee:	62 f1 dd 48 73 f7 04                            	vpsllq zmm4,zmm7,0x4
   802f5:	62 d1 cd 48 73 f1 04                            	vpsllq zmm6,zmm9,0x4
   802fc:	62 91 e5 48 db dd                               	vpandq zmm3,zmm3,zmm29
   80302:	62 f1 d5 48 73 d7 30                            	vpsrlq zmm5,zmm7,0x30
   80309:	62 d1 c5 48 73 f0 04                            	vpsllq zmm7,zmm8,0x4
   80310:	62 d1 bd 40 73 d1 30                            	vpsrlq zmm24,zmm9,0x30
   80317:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   8031c:	62 32 9d 48 b5 cf                               	vpmadd52huq zmm9,zmm12,zmm23
   80322:	62 f1 e5 48 d4 c0                               	vpaddq zmm0,zmm3,zmm0
   80328:	62 91 cd 48 db f5                               	vpandq zmm6,zmm6,zmm29
   8032e:	62 91 c5 48 db fd                               	vpandq zmm7,zmm7,zmm29
   80334:	62 91 e5 48 73 d7 30                            	vpsrlq zmm3,zmm31,0x30
   8033b:	62 91 dd 48 db e5                               	vpandq zmm4,zmm4,zmm29
   80341:	62 f1 cd 48 d4 ed                               	vpaddq zmm5,zmm6,zmm5
   80347:	62 91 c5 48 d4 f0                               	vpaddq zmm6,zmm7,zmm24
   8034d:	62 f1 c5 48 73 d0 34                            	vpsrlq zmm7,zmm0,0x34
   80354:	62 f1 fd 48 db c2                               	vpandq zmm0,zmm0,zmm2
   8035a:	62 d1 bd 40 73 d0 30                            	vpsrlq zmm24,zmm8,0x30
   80361:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   80366:	62 32 ad 48 b5 c5                               	vpmadd52huq zmm8,zmm10,zmm21
   8036c:	62 f1 c5 48 d4 db                               	vpaddq zmm3,zmm7,zmm3
   80372:	62 f1 fd 48 7f 42 fc                            	vmovdqa64 ZMMWORD PTR [rdx-0x100],zmm0
   80379:	c5 fd 6f 05 5f 74 f8 ff                         	vmovdqa ymm0,YMMWORD PTR [rip+0xfffffffffff8745f]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   80381:	62 91 f5 48 d4 c8                               	vpaddq zmm1,zmm1,zmm24
   80387:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   8038b:	62 b2 a5 48 b5 ff                               	vpmadd52huq zmm7,zmm11,zmm23
   80391:	62 f1 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm4
   80397:	62 32 a5 48 b4 cf                               	vpmadd52luq zmm9,zmm11,zmm23
   8039d:	62 f1 dd 48 73 d3 34                            	vpsrlq zmm4,zmm3,0x34
   803a4:	62 f1 e5 48 db da                               	vpandq zmm3,zmm3,zmm2
   803aa:	62 f1 dd 48 d4 e5                               	vpaddq zmm4,zmm4,zmm5
   803b0:	62 f1 fd 48 7f 5a fd                            	vmovdqa64 ZMMWORD PTR [rdx-0xc0],zmm3
   803b7:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   803bb:	62 b2 95 48 b5 df                               	vpmadd52huq zmm3,zmm13,zmm23
   803c1:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   803c8:	62 f1 dd 48 db e2                               	vpandq zmm4,zmm4,zmm2
   803ce:	62 b2 ad 48 b4 ff                               	vpmadd52luq zmm7,zmm10,zmm23
   803d4:	62 f1 d5 48 d4 ee                               	vpaddq zmm5,zmm5,zmm6
   803da:	62 f1 fd 48 7f 62 fe                            	vmovdqa64 ZMMWORD PTR [rdx-0x80],zmm4
   803e1:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   803e5:	62 f1 cd 48 73 d5 34                            	vpsrlq zmm6,zmm5,0x34
   803ec:	62 f1 d5 48 db ea                               	vpandq zmm5,zmm5,zmm2
   803f2:	62 f1 cd 48 d4 c9                               	vpaddq zmm1,zmm6,zmm1
   803f8:	62 f1 fd 48 7f 6a ff                            	vmovdqa64 ZMMWORD PTR [rdx-0x40],zmm5
   803ff:	62 b2 9d 48 b4 df                               	vpmadd52luq zmm3,zmm12,zmm23
   80405:	62 f1 fd 48 7f 0a                               	vmovdqa64 ZMMWORD PTR [rdx],zmm1
   8040b:	c5 fe 7f 84 24 80 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0x80],ymm0
   80414:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   8041c:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   80420:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   80424:	62 b2 8d 48 b5 cf                               	vpmadd52huq zmm1,zmm14,zmm23
   8042a:	62 b2 8d 48 b4 c7                               	vpmadd52luq zmm0,zmm14,zmm23
   80430:	48 81 c2 40 06 00 00                            	add    rdx,0x640
   80437:	4d 89 58 10                                     	mov    QWORD PTR [r8+0x10],r11
   8043b:	62 62 fd 48 59 44 24 13                         	vpbroadcastq zmm24,QWORD PTR [rsp+0x98]
   80443:	62 f2 fd 48 59 6c 24 12                         	vpbroadcastq zmm5,QWORD PTR [rsp+0x90]
   8044b:	62 f2 fd 48 59 74 24 11                         	vpbroadcastq zmm6,QWORD PTR [rsp+0x88]
   80453:	62 d2 fd 48 b4 e7                               	vpmadd52luq zmm4,zmm0,zmm15
   80459:	62 b2 95 48 b4 cf                               	vpmadd52luq zmm1,zmm13,zmm23
   8045f:	62 e2 fd 48 59 7c 24 14                         	vpbroadcastq zmm23,QWORD PTR [rsp+0xa0]
   80467:	62 f1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm2
   8046d:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   80474:	62 b2 dd 48 b5 c1                               	vpmadd52huq zmm0,zmm4,zmm17
   8047a:	62 92 dd 48 b5 f8                               	vpmadd52huq zmm7,zmm4,zmm24
   80480:	62 72 dd 48 b5 cd                               	vpmadd52huq zmm9,zmm4,zmm5
   80486:	62 f2 dd 48 b5 de                               	vpmadd52huq zmm3,zmm4,zmm6
   8048c:	62 f2 dd 48 b4 ce                               	vpmadd52luq zmm1,zmm4,zmm6
   80492:	62 22 dd 48 b5 cf                               	vpmadd52huq zmm25,zmm4,zmm23
   80498:	62 b2 dd 48 b4 ff                               	vpmadd52luq zmm7,zmm4,zmm23
   8049e:	62 12 dd 48 b4 c8                               	vpmadd52luq zmm9,zmm4,zmm24
   804a4:	62 f2 dd 48 b4 dd                               	vpmadd52luq zmm3,zmm4,zmm5
   804aa:	62 f1 f5 48 d4 c0                               	vpaddq zmm0,zmm1,zmm0
   804b0:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   804b4:	62 b2 8d 48 b4 c6                               	vpmadd52luq zmm0,zmm14,zmm22
   804ba:	62 22 a5 48 b5 ce                               	vpmadd52huq zmm25,zmm11,zmm22
   804c0:	62 b2 9d 48 b5 fe                               	vpmadd52huq zmm7,zmm12,zmm22
   804c6:	62 32 95 48 b5 ce                               	vpmadd52huq zmm9,zmm13,zmm22
   804cc:	62 b2 8d 48 b5 de                               	vpmadd52huq zmm3,zmm14,zmm22
   804d2:	62 d2 fd 48 b4 cf                               	vpmadd52luq zmm1,zmm0,zmm15
   804d8:	62 f1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm2
   804de:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   804e5:	62 22 ad 48 b4 ce                               	vpmadd52luq zmm25,zmm10,zmm22
   804eb:	62 b2 a5 48 b4 fe                               	vpmadd52luq zmm7,zmm11,zmm22
   804f1:	62 32 9d 48 b4 ce                               	vpmadd52luq zmm9,zmm12,zmm22
   804f7:	62 b2 95 48 b4 de                               	vpmadd52luq zmm3,zmm13,zmm22
   804fd:	62 b2 f5 48 b5 c1                               	vpmadd52huq zmm0,zmm1,zmm17
   80503:	62 22 f5 48 b5 d7                               	vpmadd52huq zmm26,zmm1,zmm23
   80509:	62 02 f5 48 b5 c8                               	vpmadd52huq zmm25,zmm1,zmm24
   8050f:	62 f2 f5 48 b5 fd                               	vpmadd52huq zmm7,zmm1,zmm5
   80515:	62 72 f5 48 b5 ce                               	vpmadd52huq zmm9,zmm1,zmm6
   8051b:	62 f2 f5 48 b4 de                               	vpmadd52luq zmm3,zmm1,zmm6
   80521:	62 22 a5 48 b5 d5                               	vpmadd52huq zmm26,zmm11,zmm21
   80527:	62 22 f5 48 b4 cf                               	vpmadd52luq zmm25,zmm1,zmm23
   8052d:	62 92 f5 48 b4 f8                               	vpmadd52luq zmm7,zmm1,zmm24
   80533:	62 72 f5 48 b4 cd                               	vpmadd52luq zmm9,zmm1,zmm5
   80539:	62 f1 e5 48 d4 c0                               	vpaddq zmm0,zmm3,zmm0
   8053f:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   80543:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   80547:	62 b2 8d 48 b4 c5                               	vpmadd52luq zmm0,zmm14,zmm21
   8054d:	62 22 ad 48 b4 d5                               	vpmadd52luq zmm26,zmm10,zmm21
   80553:	62 22 9d 48 b5 cd                               	vpmadd52huq zmm25,zmm12,zmm21
   80559:	62 b2 95 48 b5 fd                               	vpmadd52huq zmm7,zmm13,zmm21
   8055f:	62 32 8d 48 b5 cd                               	vpmadd52huq zmm9,zmm14,zmm21
   80565:	62 d2 fd 48 b4 cf                               	vpmadd52luq zmm1,zmm0,zmm15
   8056b:	62 f1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm2
   80571:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   80578:	62 22 a5 48 b4 cd                               	vpmadd52luq zmm25,zmm11,zmm21
   8057e:	62 b2 9d 48 b4 fd                               	vpmadd52luq zmm7,zmm12,zmm21
   80584:	62 32 95 48 b4 cd                               	vpmadd52luq zmm9,zmm13,zmm21
   8058a:	62 02 f5 48 b5 d0                               	vpmadd52huq zmm26,zmm1,zmm24
   80590:	62 b2 f5 48 b5 c1                               	vpmadd52huq zmm0,zmm1,zmm17
   80596:	62 32 f5 48 b5 c7                               	vpmadd52huq zmm8,zmm1,zmm23
   8059c:	62 62 f5 48 b5 cd                               	vpmadd52huq zmm25,zmm1,zmm5
   805a2:	62 f2 f5 48 b5 fe                               	vpmadd52huq zmm7,zmm1,zmm6
   805a8:	62 72 f5 48 b4 ce                               	vpmadd52luq zmm9,zmm1,zmm6
   805ae:	62 22 f5 48 b4 d7                               	vpmadd52luq zmm26,zmm1,zmm23
   805b4:	62 32 a5 48 b5 c4                               	vpmadd52huq zmm8,zmm11,zmm20
   805ba:	62 02 f5 48 b4 c8                               	vpmadd52luq zmm25,zmm1,zmm24
   805c0:	62 f2 f5 48 b4 fd                               	vpmadd52luq zmm7,zmm1,zmm5
   805c6:	62 f1 b5 48 d4 c0                               	vpaddq zmm0,zmm9,zmm0
   805cc:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   805d0:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   805d5:	62 32 ad 48 b5 cc                               	vpmadd52huq zmm9,zmm10,zmm20
   805db:	62 b2 8d 48 b4 c4                               	vpmadd52luq zmm0,zmm14,zmm20
   805e1:	62 22 9d 48 b5 d4                               	vpmadd52huq zmm26,zmm12,zmm20
   805e7:	62 32 ad 48 b4 c4                               	vpmadd52luq zmm8,zmm10,zmm20
   805ed:	62 22 95 48 b5 cc                               	vpmadd52huq zmm25,zmm13,zmm20
   805f3:	62 b2 8d 48 b5 fc                               	vpmadd52huq zmm7,zmm14,zmm20
   805f9:	62 d2 fd 48 b4 cf                               	vpmadd52luq zmm1,zmm0,zmm15
   805ff:	62 22 a5 48 b4 d4                               	vpmadd52luq zmm26,zmm11,zmm20
   80605:	62 f1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm2
   8060b:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   80612:	62 22 9d 48 b4 cc                               	vpmadd52luq zmm25,zmm12,zmm20
   80618:	62 b2 95 48 b4 fc                               	vpmadd52luq zmm7,zmm13,zmm20
   8061e:	62 12 f5 48 b5 c0                               	vpmadd52huq zmm8,zmm1,zmm24
   80624:	62 62 f5 48 b5 d5                               	vpmadd52huq zmm26,zmm1,zmm5
   8062a:	62 b2 f5 48 b5 c1                               	vpmadd52huq zmm0,zmm1,zmm17
   80630:	62 32 f5 48 b5 cf                               	vpmadd52huq zmm9,zmm1,zmm23
   80636:	62 62 f5 48 b5 ce                               	vpmadd52huq zmm25,zmm1,zmm6
   8063c:	62 f2 f5 48 b4 fe                               	vpmadd52luq zmm7,zmm1,zmm6
   80642:	62 32 f5 48 b4 c7                               	vpmadd52luq zmm8,zmm1,zmm23
   80648:	62 02 f5 48 b4 d0                               	vpmadd52luq zmm26,zmm1,zmm24
   8064e:	62 32 a5 48 b5 cb                               	vpmadd52huq zmm9,zmm11,zmm19
   80654:	62 62 f5 48 b4 cd                               	vpmadd52luq zmm25,zmm1,zmm5
   8065a:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8065e:	62 b2 ad 48 b5 cb                               	vpmadd52huq zmm1,zmm10,zmm19
   80664:	62 f1 c5 48 d4 c0                               	vpaddq zmm0,zmm7,zmm0
   8066a:	62 b2 8d 48 b4 c3                               	vpmadd52luq zmm0,zmm14,zmm19
   80670:	62 32 9d 48 b5 c3                               	vpmadd52huq zmm8,zmm12,zmm19
   80676:	62 22 95 48 b5 d3                               	vpmadd52huq zmm26,zmm13,zmm19
   8067c:	62 32 ad 48 b4 cb                               	vpmadd52luq zmm9,zmm10,zmm19
   80682:	62 22 8d 48 b5 cb                               	vpmadd52huq zmm25,zmm14,zmm19
   80688:	62 d2 fd 48 b4 df                               	vpmadd52luq zmm3,zmm0,zmm15
   8068e:	62 32 a5 48 b4 c3                               	vpmadd52luq zmm8,zmm11,zmm19
   80694:	62 22 9d 48 b4 d3                               	vpmadd52luq zmm26,zmm12,zmm19
   8069a:	62 91 fd 48 d4 c6                               	vpaddq zmm0,zmm0,zmm30
   806a0:	62 f1 fd 48 73 d0 30                            	vpsrlq zmm0,zmm0,0x30
   806a7:	62 22 95 48 b4 cb                               	vpmadd52luq zmm25,zmm13,zmm19
   806ad:	62 f1 dd 48 73 f3 04                            	vpsllq zmm4,zmm3,0x4
   806b4:	62 91 e5 48 db de                               	vpandq zmm3,zmm3,zmm30
   806ba:	62 72 e5 48 b5 c5                               	vpmadd52huq zmm8,zmm3,zmm5
   806c0:	62 12 e5 48 b5 c8                               	vpmadd52huq zmm9,zmm3,zmm24
   806c6:	62 62 e5 48 b5 d6                               	vpmadd52huq zmm26,zmm3,zmm6
   806cc:	62 b2 dd 48 b5 c1                               	vpmadd52huq zmm0,zmm4,zmm17
   806d2:	62 b2 e5 48 b5 cf                               	vpmadd52huq zmm1,zmm3,zmm23
   806d8:	62 62 e5 48 b4 ce                               	vpmadd52luq zmm25,zmm3,zmm6
   806de:	62 12 e5 48 b4 c0                               	vpmadd52luq zmm8,zmm3,zmm24
   806e4:	62 32 e5 48 b4 cf                               	vpmadd52luq zmm9,zmm3,zmm23
   806ea:	62 62 e5 48 b4 d5                               	vpmadd52luq zmm26,zmm3,zmm5
   806f0:	62 f1 f5 48 73 f1 04                            	vpsllq zmm1,zmm1,0x4
   806f7:	62 91 e5 48 73 f1 04                            	vpsllq zmm3,zmm25,0x4
   806fe:	62 91 c5 48 73 d1 30                            	vpsrlq zmm7,zmm25,0x30
   80705:	62 91 e5 48 db dd                               	vpandq zmm3,zmm3,zmm29
   8070b:	62 f1 e5 48 d4 c0                               	vpaddq zmm0,zmm3,zmm0
   80711:	62 d1 dd 48 73 f0 04                            	vpsllq zmm4,zmm8,0x4
   80718:	62 d1 d5 48 73 f1 04                            	vpsllq zmm5,zmm9,0x4
   8071f:	62 91 e5 48 73 d2 30                            	vpsrlq zmm3,zmm26,0x30
   80726:	62 d1 cd 48 73 d0 30                            	vpsrlq zmm6,zmm8,0x30
   8072d:	62 61 fd 48 db c2                               	vpandq zmm24,zmm0,zmm2
   80733:	62 91 dd 48 db e5                               	vpandq zmm4,zmm4,zmm29
   80739:	62 91 d5 48 db ed                               	vpandq zmm5,zmm5,zmm29
   8073f:	62 f1 dd 48 d4 db                               	vpaddq zmm3,zmm4,zmm3
   80745:	62 f1 d5 48 d4 e6                               	vpaddq zmm4,zmm5,zmm6
   8074b:	62 d1 cd 48 73 d1 30                            	vpsrlq zmm6,zmm9,0x30
   80752:	62 f1 f5 48 d4 ce                               	vpaddq zmm1,zmm1,zmm6
   80758:	62 f1 cd 48 73 d0 34                            	vpsrlq zmm6,zmm0,0x34
   8075f:	62 f1 cd 48 d4 ef                               	vpaddq zmm5,zmm6,zmm7
   80765:	62 91 c5 48 73 f2 04                            	vpsllq zmm7,zmm26,0x4
   8076c:	62 91 c5 48 db f5                               	vpandq zmm6,zmm7,zmm29
   80772:	62 f1 d5 48 d4 ee                               	vpaddq zmm5,zmm5,zmm6
   80778:	62 f1 cd 48 73 d5 34                            	vpsrlq zmm6,zmm5,0x34
   8077f:	62 e1 d5 48 db f2                               	vpandq zmm22,zmm5,zmm2
   80785:	62 f1 cd 48 d4 db                               	vpaddq zmm3,zmm6,zmm3
   8078b:	62 f1 cd 48 73 d3 34                            	vpsrlq zmm6,zmm3,0x34
   80792:	62 e1 e5 48 db ea                               	vpandq zmm21,zmm3,zmm2
   80798:	62 f1 cd 48 d4 e4                               	vpaddq zmm4,zmm6,zmm4
   8079e:	62 f1 cd 48 73 d4 34                            	vpsrlq zmm6,zmm4,0x34
   807a5:	62 e1 dd 48 db e2                               	vpandq zmm20,zmm4,zmm2
   807ab:	62 61 cd 48 d4 c9                               	vpaddq zmm25,zmm6,zmm1
   807b1:	49 39 f2                                        	cmp    r10,rsi
   807b4:	0f 85 76 ee ff ff                               	jne    7f630 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x150>
   807ba:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
   807bf:	48 8b 5c 24 68                                  	mov    rbx,QWORD PTR [rsp+0x68]
   807c4:	62 61 fd 48 7f 44 24 2f                         	vmovdqa64 ZMMWORD PTR [rsp+0xbc0],zmm24
   807cc:	62 e1 fd 48 7f 74 24 30                         	vmovdqa64 ZMMWORD PTR [rsp+0xc00],zmm22
   807d4:	62 e1 fd 48 7f 6c 24 31                         	vmovdqa64 ZMMWORD PTR [rsp+0xc40],zmm21
   807dc:	62 e1 fd 48 7f 64 24 32                         	vmovdqa64 ZMMWORD PTR [rsp+0xc80],zmm20
   807e4:	62 61 fd 48 7f 4c 24 33                         	vmovdqa64 ZMMWORD PTR [rsp+0xcc0],zmm25
   807ec:	e9 7a 15 00 00                                  	jmp    81d6b <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x288b>
   807f1:	49 3b 18                                        	cmp    rbx,QWORD PTR [r8]
   807f4:	0f 97 c0                                        	seta   al
   807f7:	41 80 78 31 00                                  	cmp    BYTE PTR [r8+0x31],0x0
   807fc:	75 02                                           	jne    80800 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x1320>
   807fe:	31 c0                                           	xor    eax,eax
   80800:	84 c0                                           	test   al,al
   80802:	0f 85 43 53 00 00                               	jne    85b4b <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x666b>
   80808:	48 85 db                                        	test   rbx,rbx
   8080b:	0f 84 57 15 00 00                               	je     81d68 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x2888>
   80811:	62 62 fd 48 59 05 8d 64 f8 ff                   	vpbroadcastq zmm24,QWORD PTR [rip+0xfffffffffff8648d]        # 6ca8 <GCC_except_table711+0x1b8>
   8081b:	62 62 fd 48 59 3d 1b 64 f8 ff                   	vpbroadcastq zmm31,QWORD PTR [rip+0xfffffffffff8641b]        # 6c40 <GCC_except_table711+0x150>
   80825:	c5 7d 6f 2d f3 70 f8 ff                         	vmovdqa ymm13,YMMWORD PTR [rip+0xfffffffffff870f3]        # 7920 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x980>
   8082d:	48 89 5c 24 68                                  	mov    QWORD PTR [rsp+0x68],rbx
   80832:	31 ff                                           	xor    edi,edi
   80834:	49 89 d7                                        	mov    r15,rdx
   80837:	e9 aa 0d 00 00                                  	jmp    815e6 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x2106>
   8083c:	0f 1f 40 00                                     	nop    DWORD PTR [rax+0x0]
   80840:	62 f1 fd 48 6f 44 24 3f                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0xfc0]
   80848:	62 f1 fd 48 6f 4c 24 3e                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0xf80]
   80850:	62 f1 fd 48 6f 54 24 3d                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xf40]
   80858:	62 f1 fd 48 6f 6c 24 0d                         	vmovdqa64 zmm5,ZMMWORD PTR [rsp+0x340]
   80860:	62 71 fd 48 6f 15 96 6b f8 ff                   	vmovdqa64 zmm10,ZMMWORD PTR [rip+0xfffffffffff86b96]        # 7400 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x460>
   8086a:	62 71 fd 48 6f 1d cc 6b f8 ff                   	vmovdqa64 zmm11,ZMMWORD PTR [rip+0xfffffffffff86bcc]        # 7440 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4a0>
   80874:	62 f1 fd 48 6f 74 24 41                         	vmovdqa64 zmm6,ZMMWORD PTR [rsp+0x1040]
   8087c:	62 73 95 40 3a 4c 24 53 01                      	vinserti64x4 zmm9,zmm29,YMMWORD PTR [rsp+0xa60],0x1
   80885:	41 c1 ee 1e                                     	shr    r14d,0x1e
   80889:	62 62 fd 48 59 2d dd 63 f8 ff                   	vpbroadcastq zmm29,QWORD PTR [rip+0xfffffffffff863dd]        # 6c70 <GCC_except_table711+0x180>
   80893:	41 c1 ed 1d                                     	shr    r13d,0x1d
   80897:	41 c1 ea 1f                                     	shr    r10d,0x1f
   8089b:	c1 eb 1c                                        	shr    ebx,0x1c
   8089e:	41 c1 ef 1b                                     	shr    r15d,0x1b
   808a2:	c1 ef 1a                                        	shr    edi,0x1a
   808a5:	41 c1 e9 19                                     	shr    r9d,0x19
   808a9:	41 80 e4 80                                     	and    r12b,0x80
   808ad:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   808b2:	49 69 cb 40 06 00 00                            	imul   rcx,r11,0x640
   808b9:	49 ff c3                                        	inc    r11
   808bc:	48 83 ea 80                                     	sub    rdx,0xffffffffffffff80
   808c0:	62 f3 fd 48 3a 44 24 50 01                      	vinserti64x4 zmm0,zmm0,YMMWORD PTR [rsp+0xa00],0x1
   808c9:	62 f3 f5 48 3a 4c 24 4f 01                      	vinserti64x4 zmm1,zmm1,YMMWORD PTR [rsp+0x9e0],0x1
   808d2:	62 f3 ed 48 3a 54 24 20 01                      	vinserti64x4 zmm2,zmm2,YMMWORD PTR [rsp+0x400],0x1
   808db:	62 f3 cd 48 3a 7c 24 52 01                      	vinserti64x4 zmm7,zmm6,YMMWORD PTR [rsp+0xa40],0x1
   808e4:	62 f1 fd 48 6f 74 24 40                         	vmovdqa64 zmm6,ZMMWORD PTR [rsp+0x1000]
   808ec:	41 80 e6 02                                     	and    r14b,0x2
   808f0:	41 80 e5 04                                     	and    r13b,0x4
   808f4:	80 e3 08                                        	and    bl,0x8
   808f7:	41 80 e7 10                                     	and    r15b,0x10
   808fb:	41 80 e1 40                                     	and    r9b,0x40
   808ff:	40 80 e7 20                                     	and    dil,0x20
   80903:	62 73 cd 48 3a 44 24 51 01                      	vinserti64x4 zmm8,zmm6,YMMWORD PTR [rsp+0xa20],0x1
   8090c:	45 08 d6                                        	or     r14b,r10b
   8090f:	45 08 cc                                        	or     r12b,r9b
   80912:	45 08 f5                                        	or     r13b,r14b
   80915:	44 08 eb                                        	or     bl,r13b
   80918:	41 08 df                                        	or     r15b,bl
   8091b:	44 08 ff                                        	or     dil,r15b
   8091e:	49 89 d7                                        	mov    r15,rdx
   80921:	41 08 fc                                        	or     r12b,dil
   80924:	48 89 f7                                        	mov    rdi,rsi
   80927:	c4 c1 7b 92 cc                                  	kmovd  k1,r12d
   8092c:	62 f1 fd 48 6c d9                               	vpunpcklqdq zmm3,zmm0,zmm1
   80932:	62 f1 fd 48 6d e1                               	vpunpckhqdq zmm4,zmm0,zmm1
   80938:	62 f1 ed 48 6c c5                               	vpunpcklqdq zmm0,zmm2,zmm5
   8093e:	62 f1 ed 48 6d ed                               	vpunpckhqdq zmm5,zmm2,zmm5
   80944:	62 f1 fd 48 6f cb                               	vmovdqa64 zmm1,zmm3
   8094a:	62 f2 ad 48 7e c8                               	vpermt2q zmm1,zmm10,zmm0
   80950:	62 f2 a5 48 7e d8                               	vpermt2q zmm3,zmm11,zmm0
   80956:	62 f3 ad 40 3a 44 24 54 01                      	vinserti64x4 zmm0,zmm26,YMMWORD PTR [rsp+0xa80],0x1
   8095f:	62 f1 fd 48 6f d4                               	vmovdqa64 zmm2,zmm4
   80965:	62 f2 ad 48 7e d5                               	vpermt2q zmm2,zmm10,zmm5
   8096b:	62 f2 a5 48 7e e5                               	vpermt2q zmm4,zmm11,zmm5
   80971:	62 21 fd 48 6f d3                               	vmovdqa64 zmm26,zmm19
   80977:	62 11 f5 48 db e7                               	vpandq zmm12,zmm1,zmm31
   8097d:	62 f3 ed 48 71 c9 0c                            	vpshldq zmm1,zmm2,zmm1,0xc
   80984:	62 f3 e5 48 71 d2 18                            	vpshldq zmm2,zmm3,zmm2,0x18
   8098b:	62 f3 dd 48 71 db 24                            	vpshldq zmm3,zmm4,zmm3,0x24
   80992:	62 71 fd 48 7f 64 24 08                         	vmovdqa64 ZMMWORD PTR [rsp+0x200],zmm12
   8099a:	62 d1 fd 48 6d f1                               	vpunpckhqdq zmm6,zmm0,zmm9
   809a0:	62 d1 fd 48 6c c1                               	vpunpcklqdq zmm0,zmm0,zmm9
   809a6:	62 51 c5 48 6d c8                               	vpunpckhqdq zmm9,zmm7,zmm8
   809ac:	62 51 c5 48 6c c0                               	vpunpcklqdq zmm8,zmm7,zmm8
   809b2:	62 f1 fd 48 6f ee                               	vmovdqa64 zmm5,zmm6
   809b8:	62 f1 fd 48 6f f8                               	vmovdqa64 zmm7,zmm0
   809be:	62 d2 a5 48 7e e9                               	vpermt2q zmm5,zmm11,zmm9
   809c4:	62 d2 ad 48 7e f1                               	vpermt2q zmm6,zmm10,zmm9
   809ca:	62 d2 a5 48 7e f8                               	vpermt2q zmm7,zmm11,zmm8
   809d0:	62 d2 ad 48 7e c0                               	vpermt2q zmm0,zmm10,zmm8
   809d6:	62 72 95 51 64 1d 48 63 f8 ff                   	vpblendmq zmm11{k1},zmm29,QWORD BCST [rip+0xfffffffffff86348]        # 6d28 <GCC_except_table711+0x238>
   809e0:	62 11 fd c9 6f cf                               	vmovdqa64 zmm9{k1}{z},zmm31
   809e6:	62 72 fe 48 38 d1                               	vpmovm2q zmm10,k1
   809ec:	62 73 cd 48 71 c0 0c                            	vpshldq zmm8,zmm6,zmm0,0xc
   809f3:	62 93 b5 48 25 c7 6c                            	vpternlogq zmm0,zmm9,zmm31,0x6c
   809fa:	62 f3 c5 48 71 f6 18                            	vpshldq zmm6,zmm7,zmm6,0x18
   80a01:	62 f3 d5 48 71 ff 24                            	vpshldq zmm7,zmm5,zmm7,0x24
   80a08:	62 f1 d5 48 73 d5 10                            	vpsrlq zmm5,zmm5,0x10
   80a0f:	62 51 fd 48 fb d2                               	vpsubq zmm10,zmm0,zmm10
   80a15:	62 91 f5 48 db c7                               	vpandq zmm0,zmm1,zmm31
   80a1b:	62 f2 fd 48 59 0d 53 62 f8 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff86253]        # 6c78 <GCC_except_table711+0x188>
   80a25:	62 d1 d5 48 ef e9                               	vpxorq zmm5,zmm5,zmm9
   80a2b:	62 51 ad 48 fb d4                               	vpsubq zmm10,zmm10,zmm12
   80a31:	62 13 b5 48 25 c7 6c                            	vpternlogq zmm8,zmm9,zmm31,0x6c
   80a38:	62 f1 fd 48 7f 44 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm0
   80a40:	62 93 b5 48 25 f7 6c                            	vpternlogq zmm6,zmm9,zmm31,0x6c
   80a47:	62 93 b5 48 25 ff 6c                            	vpternlogq zmm7,zmm9,zmm31,0x6c
   80a4e:	62 51 ad 48 d4 d3                               	vpaddq zmm10,zmm10,zmm11
   80a54:	62 d1 a5 48 72 e2 34                            	vpsraq zmm11,zmm10,0x34
   80a5b:	62 51 bd 48 d4 c3                               	vpaddq zmm8,zmm8,zmm11
   80a61:	62 72 fd 48 59 1d 05 63 f8 ff                   	vpbroadcastq zmm11,QWORD PTR [rip+0xfffffffffff86305]        # 6d70 <GCC_except_table711+0x280>
   80a6b:	62 71 bd 48 fb c0                               	vpsubq zmm8,zmm8,zmm0
   80a71:	62 91 ed 48 db c7                               	vpandq zmm0,zmm2,zmm31
   80a77:	62 f2 fd 48 59 15 37 62 f8 ff                   	vpbroadcastq zmm2,QWORD PTR [rip+0xfffffffffff86237]        # 6cb8 <GCC_except_table711+0x1c8>
   80a81:	62 72 a5 59 64 1d dd 62 f8 ff                   	vpblendmq zmm11{k1},zmm11,QWORD BCST [rip+0xfffffffffff862dd]        # 6d68 <GCC_except_table711+0x278>
   80a8b:	62 f1 fd 48 7f 44 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm0
   80a93:	62 51 bd 48 d4 c3                               	vpaddq zmm8,zmm8,zmm11
   80a99:	62 d1 a5 48 72 e0 34                            	vpsraq zmm11,zmm8,0x34
   80aa0:	62 11 bd 48 db c7                               	vpandq zmm8,zmm8,zmm31
   80aa6:	62 d1 cd 48 d4 f3                               	vpaddq zmm6,zmm6,zmm11
   80aac:	62 72 f5 59 64 1d 9a 62 f8 ff                   	vpblendmq zmm11{k1},zmm1,QWORD BCST [rip+0xfffffffffff8629a]        # 6d50 <GCC_except_table711+0x260>
   80ab6:	62 f2 fd 48 59 0d 38 62 f8 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff86238]        # 6cf8 <GCC_except_table711+0x208>
   80ac0:	62 f1 cd 48 fb f0                               	vpsubq zmm6,zmm6,zmm0
   80ac6:	62 91 e5 48 db c7                               	vpandq zmm0,zmm3,zmm31
   80acc:	62 f2 fd 48 59 1d 82 62 f8 ff                   	vpbroadcastq zmm3,QWORD PTR [rip+0xfffffffffff86282]        # 6d58 <GCC_except_table711+0x268>
   80ad6:	62 f1 fd 48 7f 44 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm0
   80ade:	62 d1 cd 48 d4 f3                               	vpaddq zmm6,zmm6,zmm11
   80ae4:	62 f1 a5 48 72 e6 34                            	vpsraq zmm11,zmm6,0x34
   80aeb:	62 11 cd 48 db f7                               	vpandq zmm14,zmm6,zmm31
   80af1:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   80af5:	62 92 bd 48 b5 f0                               	vpmadd52huq zmm6,zmm8,zmm24
   80afb:	62 d1 c5 48 d4 fb                               	vpaddq zmm7,zmm7,zmm11
   80b01:	62 72 ed 59 64 1d d5 61 f8 ff                   	vpblendmq zmm11{k1},zmm2,QWORD BCST [rip+0xfffffffffff861d5]        # 6ce0 <GCC_except_table711+0x1f0>
   80b0b:	62 f2 fd 48 59 15 83 61 f8 ff                   	vpbroadcastq zmm2,QWORD PTR [rip+0xfffffffffff86183]        # 6c98 <GCC_except_table711+0x1a8>
   80b15:	62 f1 c5 48 fb f8                               	vpsubq zmm7,zmm7,zmm0
   80b1b:	62 f1 fd 48 73 d4 10                            	vpsrlq zmm0,zmm4,0x10
   80b22:	62 f2 fd 48 59 25 1c 61 f8 ff                   	vpbroadcastq zmm4,QWORD PTR [rip+0xfffffffffff8611c]        # 6c48 <GCC_except_table711+0x158>
   80b2c:	62 f1 fd 48 7f 44 24 0f                         	vmovdqa64 ZMMWORD PTR [rsp+0x3c0],zmm0
   80b34:	62 92 8d 48 b4 f0                               	vpmadd52luq zmm6,zmm14,zmm24
   80b3a:	62 d1 c5 48 d4 fb                               	vpaddq zmm7,zmm7,zmm11
   80b40:	62 11 ad 48 db df                               	vpandq zmm11,zmm10,zmm31
   80b46:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   80b4b:	62 f1 b5 48 72 e7 34                            	vpsraq zmm9,zmm7,0x34
   80b52:	62 12 a5 48 b5 d0                               	vpmadd52huq zmm10,zmm11,zmm24
   80b58:	62 11 c5 48 db ef                               	vpandq zmm13,zmm7,zmm31
   80b5e:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   80b62:	62 92 8d 48 b5 f8                               	vpmadd52huq zmm7,zmm14,zmm24
   80b68:	62 d1 d5 48 d4 e9                               	vpaddq zmm5,zmm5,zmm9
   80b6e:	62 72 f5 59 64 0d 28 61 f8 ff                   	vpblendmq zmm9{k1},zmm1,QWORD BCST [rip+0xfffffffffff86128]        # 6ca0 <GCC_except_table711+0x1b0>
   80b78:	62 f1 fd 48 6f 4c 24 43                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x10c0]
   80b80:	49 8b 40 08                                     	mov    rax,QWORD PTR [r8+0x8]
   80b84:	4c 8b 94 24 40 07 00 00                         	mov    r10,QWORD PTR [rsp+0x740]
   80b8c:	4c 8b ac 24 80 05 00 00                         	mov    r13,QWORD PTR [rsp+0x580]
   80b94:	4c 8b 64 24 10                                  	mov    r12,QWORD PTR [rsp+0x10]
   80b99:	62 f1 d5 48 fb e8                               	vpsubq zmm5,zmm5,zmm0
   80b9f:	62 f1 fd 48 6f 44 24 44                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x1100]
   80ba7:	62 12 bd 48 b4 d0                               	vpmadd52luq zmm10,zmm8,zmm24
   80bad:	62 92 95 48 b4 f8                               	vpmadd52luq zmm7,zmm13,zmm24
   80bb3:	62 d1 d5 48 d4 e9                               	vpaddq zmm5,zmm5,zmm9
   80bb9:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80bbe:	62 12 a5 48 b4 c8                               	vpmadd52luq zmm9,zmm11,zmm24
   80bc4:	62 11 d5 48 db e7                               	vpandq zmm12,zmm5,zmm31
   80bca:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   80bce:	62 92 9d 48 b5 e8                               	vpmadd52huq zmm5,zmm12,zmm24
   80bd4:	62 72 b5 48 b4 fb                               	vpmadd52luq zmm15,zmm9,zmm3
   80bda:	62 11 b5 48 d4 cf                               	vpaddq zmm9,zmm9,zmm31
   80be0:	62 d1 b5 48 73 d1 34                            	vpsrlq zmm9,zmm9,0x34
   80be7:	62 12 85 48 b5 cd                               	vpmadd52huq zmm9,zmm15,zmm29
   80bed:	62 32 85 48 b4 d3                               	vpmadd52luq zmm10,zmm15,zmm19
   80bf3:	62 b2 85 48 b5 f3                               	vpmadd52huq zmm6,zmm15,zmm19
   80bf9:	62 e1 fd 48 6f 5c 24 42                         	vmovdqa64 zmm19,ZMMWORD PTR [rsp+0x1080]
   80c01:	62 f2 85 48 b5 e8                               	vpmadd52huq zmm5,zmm15,zmm0
   80c07:	62 51 ad 48 d4 d1                               	vpaddq zmm10,zmm10,zmm9
   80c0d:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80c12:	62 12 95 48 b5 c8                               	vpmadd52huq zmm9,zmm13,zmm24
   80c18:	62 b2 95 48 b5 ee                               	vpmadd52huq zmm5,zmm13,zmm22
   80c1e:	62 32 a5 48 b4 d6                               	vpmadd52luq zmm10,zmm11,zmm22
   80c24:	62 12 9d 48 b4 c8                               	vpmadd52luq zmm9,zmm12,zmm24
   80c2a:	62 b2 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm19
   80c30:	62 b2 85 48 b4 f3                               	vpmadd52luq zmm6,zmm15,zmm19
   80c36:	62 b2 9d 48 b4 ee                               	vpmadd52luq zmm5,zmm12,zmm22
   80c3c:	62 72 85 48 b5 c9                               	vpmadd52huq zmm9,zmm15,zmm1
   80c42:	62 f2 85 48 b4 f9                               	vpmadd52luq zmm7,zmm15,zmm1
   80c48:	62 b2 a5 48 b5 f6                               	vpmadd52huq zmm6,zmm11,zmm22
   80c4e:	62 72 85 48 b4 c8                               	vpmadd52luq zmm9,zmm15,zmm0
   80c54:	62 b2 bd 48 b5 fe                               	vpmadd52huq zmm7,zmm8,zmm22
   80c5a:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   80c5f:	62 72 ad 48 b4 fb                               	vpmadd52luq zmm15,zmm10,zmm3
   80c65:	62 b2 bd 48 b4 f6                               	vpmadd52luq zmm6,zmm8,zmm22
   80c6b:	62 11 ad 48 d4 d7                               	vpaddq zmm10,zmm10,zmm31
   80c71:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   80c78:	62 32 8d 48 b5 ce                               	vpmadd52huq zmm9,zmm14,zmm22
   80c7e:	62 b2 8d 48 b4 fe                               	vpmadd52luq zmm7,zmm14,zmm22
   80c84:	62 12 85 48 b5 d5                               	vpmadd52huq zmm10,zmm15,zmm29
   80c8a:	62 92 85 48 b4 f2                               	vpmadd52luq zmm6,zmm15,zmm26
   80c90:	62 f2 85 48 b5 e9                               	vpmadd52huq zmm5,zmm15,zmm1
   80c96:	62 32 95 48 b4 ce                               	vpmadd52luq zmm9,zmm13,zmm22
   80c9c:	62 92 85 48 b5 fa                               	vpmadd52huq zmm7,zmm15,zmm26
   80ca2:	62 51 cd 48 d4 d2                               	vpaddq zmm10,zmm6,zmm10
   80ca8:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   80cac:	62 b2 9d 48 b5 f6                               	vpmadd52huq zmm6,zmm12,zmm22
   80cb2:	62 f2 85 48 b4 e8                               	vpmadd52luq zmm5,zmm15,zmm0
   80cb8:	62 32 a5 48 b4 d5                               	vpmadd52luq zmm10,zmm11,zmm21
   80cbe:	62 32 85 48 b5 cb                               	vpmadd52huq zmm9,zmm15,zmm19
   80cc4:	62 b2 85 48 b4 fb                               	vpmadd52luq zmm7,zmm15,zmm19
   80cca:	62 f2 85 48 b5 f0                               	vpmadd52huq zmm6,zmm15,zmm0
   80cd0:	62 b2 8d 48 b5 ed                               	vpmadd52huq zmm5,zmm14,zmm21
   80cd6:	62 72 85 48 b4 c9                               	vpmadd52luq zmm9,zmm15,zmm1
   80cdc:	62 b2 a5 48 b5 fd                               	vpmadd52huq zmm7,zmm11,zmm21
   80ce2:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   80ce7:	62 72 ad 48 b4 fb                               	vpmadd52luq zmm15,zmm10,zmm3
   80ced:	62 b2 95 48 b5 f5                               	vpmadd52huq zmm6,zmm13,zmm21
   80cf3:	62 11 ad 48 d4 d7                               	vpaddq zmm10,zmm10,zmm31
   80cf9:	62 b2 95 48 b4 ed                               	vpmadd52luq zmm5,zmm13,zmm21
   80cff:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   80d06:	62 32 bd 48 b5 cd                               	vpmadd52huq zmm9,zmm8,zmm21
   80d0c:	62 b2 bd 48 b4 fd                               	vpmadd52luq zmm7,zmm8,zmm21
   80d12:	62 12 85 48 b5 d5                               	vpmadd52huq zmm10,zmm15,zmm29
   80d18:	62 b2 9d 48 b4 f5                               	vpmadd52luq zmm6,zmm12,zmm21
   80d1e:	62 b2 85 48 b5 eb                               	vpmadd52huq zmm5,zmm15,zmm19
   80d24:	62 32 8d 48 b4 cd                               	vpmadd52luq zmm9,zmm14,zmm21
   80d2a:	62 92 85 48 b4 fa                               	vpmadd52luq zmm7,zmm15,zmm26
   80d30:	62 f2 85 48 b5 f1                               	vpmadd52huq zmm6,zmm15,zmm1
   80d36:	62 f2 85 48 b4 e9                               	vpmadd52luq zmm5,zmm15,zmm1
   80d3c:	62 12 85 48 b5 ca                               	vpmadd52huq zmm9,zmm15,zmm26
   80d42:	62 51 c5 48 d4 d2                               	vpaddq zmm10,zmm7,zmm10
   80d48:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   80d4c:	62 b2 9d 48 b5 fd                               	vpmadd52huq zmm7,zmm12,zmm21
   80d52:	62 f2 85 48 b4 f0                               	vpmadd52luq zmm6,zmm15,zmm0
   80d58:	62 b2 bd 48 b5 ec                               	vpmadd52huq zmm5,zmm8,zmm20
   80d5e:	62 32 a5 48 b4 d4                               	vpmadd52luq zmm10,zmm11,zmm20
   80d64:	62 32 85 48 b4 cb                               	vpmadd52luq zmm9,zmm15,zmm19
   80d6a:	62 f2 85 48 b5 f8                               	vpmadd52huq zmm7,zmm15,zmm0
   80d70:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   80d75:	62 b2 8d 48 b5 f4                               	vpmadd52huq zmm6,zmm14,zmm20
   80d7b:	62 b2 8d 48 b4 ec                               	vpmadd52luq zmm5,zmm14,zmm20
   80d81:	62 72 ad 48 b4 fb                               	vpmadd52luq zmm15,zmm10,zmm3
   80d87:	62 11 ad 48 d4 d7                               	vpaddq zmm10,zmm10,zmm31
   80d8d:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   80d94:	62 32 a5 48 b5 cc                               	vpmadd52huq zmm9,zmm11,zmm20
   80d9a:	62 b2 95 48 b5 fc                               	vpmadd52huq zmm7,zmm13,zmm20
   80da0:	62 b2 95 48 b4 f4                               	vpmadd52luq zmm6,zmm13,zmm20
   80da6:	62 12 85 48 b5 d5                               	vpmadd52huq zmm10,zmm15,zmm29
   80dac:	62 92 85 48 b5 ea                               	vpmadd52huq zmm5,zmm15,zmm26
   80db2:	62 32 bd 48 b4 cc                               	vpmadd52luq zmm9,zmm8,zmm20
   80db8:	62 b2 9d 48 b4 fc                               	vpmadd52luq zmm7,zmm12,zmm20
   80dbe:	62 b2 85 48 b5 f3                               	vpmadd52huq zmm6,zmm15,zmm19
   80dc4:	62 b2 85 48 b4 eb                               	vpmadd52luq zmm5,zmm15,zmm19
   80dca:	62 12 85 48 b4 ca                               	vpmadd52luq zmm9,zmm15,zmm26
   80dd0:	62 f2 85 48 b5 f9                               	vpmadd52huq zmm7,zmm15,zmm1
   80dd6:	62 f2 85 48 b4 f1                               	vpmadd52luq zmm6,zmm15,zmm1
   80ddc:	62 92 a5 48 b5 e9                               	vpmadd52huq zmm5,zmm11,zmm25
   80de2:	62 51 b5 48 d4 d2                               	vpaddq zmm10,zmm9,zmm10
   80de8:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80ded:	62 32 9d 48 b5 cc                               	vpmadd52huq zmm9,zmm12,zmm20
   80df3:	62 f2 85 48 b4 f8                               	vpmadd52luq zmm7,zmm15,zmm0
   80df9:	62 92 bd 48 b5 f1                               	vpmadd52huq zmm6,zmm8,zmm25
   80dff:	62 12 a5 48 b4 d1                               	vpmadd52luq zmm10,zmm11,zmm25
   80e05:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   80e0a:	62 12 9d 48 b5 d9                               	vpmadd52huq zmm11,zmm12,zmm25
   80e10:	62 92 bd 48 b4 e9                               	vpmadd52luq zmm5,zmm8,zmm25
   80e16:	62 72 85 48 b5 c8                               	vpmadd52huq zmm9,zmm15,zmm0
   80e1c:	62 92 8d 48 b5 f9                               	vpmadd52huq zmm7,zmm14,zmm25
   80e22:	62 92 8d 48 b4 f1                               	vpmadd52luq zmm6,zmm14,zmm25
   80e28:	62 12 95 48 b5 c9                               	vpmadd52huq zmm9,zmm13,zmm25
   80e2e:	62 92 95 48 b4 f9                               	vpmadd52luq zmm7,zmm13,zmm25
   80e34:	62 31 ed 40 fb e8                               	vpsubq zmm13,zmm18,zmm16
   80e3a:	62 12 9d 48 b4 c9                               	vpmadd52luq zmm9,zmm12,zmm25
   80e40:	c4 41 19 ef e4                                  	vpxor  xmm12,xmm12,xmm12
   80e45:	62 72 ad 48 b4 e3                               	vpmadd52luq zmm12,zmm10,zmm3
   80e4b:	62 71 ad 48 d4 d4                               	vpaddq zmm10,zmm10,zmm4
   80e51:	62 d1 ad 48 73 d2 30                            	vpsrlq zmm10,zmm10,0x30
   80e58:	62 71 9d 48 db c4                               	vpandq zmm8,zmm12,zmm4
   80e5e:	62 d1 9d 48 73 f4 04                            	vpsllq zmm12,zmm12,0x4
   80e65:	62 72 bd 48 b5 c9                               	vpmadd52huq zmm9,zmm8,zmm1
   80e6b:	62 72 bd 48 b5 d8                               	vpmadd52huq zmm11,zmm8,zmm0
   80e71:	62 92 bd 48 b5 f2                               	vpmadd52huq zmm6,zmm8,zmm26
   80e77:	62 b2 bd 48 b5 fb                               	vpmadd52huq zmm7,zmm8,zmm19
   80e7d:	62 92 bd 48 b4 ea                               	vpmadd52luq zmm5,zmm8,zmm26
   80e83:	62 61 fd 48 6f 54 24 21                         	vmovdqa64 zmm26,ZMMWORD PTR [rsp+0x840]
   80e8b:	62 12 9d 48 b5 d5                               	vpmadd52huq zmm10,zmm12,zmm29
   80e91:	62 72 bd 48 b4 c8                               	vpmadd52luq zmm9,zmm8,zmm0
   80e97:	62 f1 fd 48 72 64 24 45 34                      	vpsraq zmm0,ZMMWORD PTR [rsp+0x1140],0x34
   80ea0:	62 b2 bd 48 b4 f3                               	vpmadd52luq zmm6,zmm8,zmm19
   80ea6:	62 f2 bd 48 b4 f9                               	vpmadd52luq zmm7,zmm8,zmm1
   80eac:	62 f1 fd 48 6f 4c 24 47                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x11c0]
   80eb4:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   80eba:	62 f1 9d 48 73 f5 04                            	vpsllq zmm12,zmm5,0x4
   80ec1:	62 f1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm5,0x30
   80ec8:	62 71 95 48 d4 c0                               	vpaddq zmm8,zmm13,zmm0
   80ece:	62 f1 85 40 db 44 24 20                         	vpandq zmm0,zmm31,ZMMWORD PTR [rsp+0x800]
   80ed6:	62 71 fd 58 d4 35 48 5e f8 ff                   	vpaddq zmm14,zmm0,QWORD BCST [rip+0xfffffffffff85e48]        # 6d28 <GCC_except_table711+0x238>
   80ee0:	62 f3 bd 48 1e ca 01                            	vpcmpltuq k1,zmm8,zmm2
   80ee7:	62 61 fd 49 6f 64 24 46                         	vmovdqa64 zmm28{k1},ZMMWORD PTR [rsp+0x1180]
   80eef:	62 91 fd 49 6f cb                               	vmovdqa64 zmm1{k1},zmm27
   80ef5:	62 e1 fd 49 6f ca                               	vmovdqa64 zmm17{k1},zmm2
   80efb:	62 51 f5 40 d4 c0                               	vpaddq zmm8,zmm17,zmm8
   80f01:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   80f07:	62 21 fd 48 6f dd                               	vmovdqa64 zmm27,zmm21
   80f0d:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   80f13:	62 91 fd 48 6f d6                               	vmovdqa64 zmm2,zmm30
   80f19:	62 71 fd 49 6f f0                               	vmovdqa64 zmm14{k1},zmm0
   80f1f:	62 f1 fd 48 6f 44 24 49                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x1240]
   80f27:	62 d1 95 48 73 d6 34                            	vpsrlq zmm13,zmm14,0x34
   80f2e:	62 71 95 48 d4 e9                               	vpaddq zmm13,zmm13,zmm1
   80f34:	62 91 fd 48 6f c8                               	vmovdqa64 zmm1,zmm24
   80f3a:	62 d1 85 48 73 d5 34                            	vpsrlq zmm15,zmm13,0x34
   80f41:	62 11 95 48 db ef                               	vpandq zmm13,zmm13,zmm31
   80f47:	62 f1 fd 49 6f 44 24 48                         	vmovdqa64 zmm0{k1},ZMMWORD PTR [rsp+0x1200]
   80f4f:	62 71 85 48 d4 f8                               	vpaddq zmm15,zmm15,zmm0
   80f55:	62 b1 fd 48 6f c7                               	vmovdqa64 zmm0,zmm23
   80f5b:	62 d1 fd 40 73 d7 34                            	vpsrlq zmm16,zmm15,0x34
   80f62:	62 11 85 48 db ff                               	vpandq zmm15,zmm15,zmm31
   80f68:	62 81 fd 40 d4 d4                               	vpaddq zmm18,zmm16,zmm28
   80f6e:	62 21 fd 48 6f e6                               	vmovdqa64 zmm28,zmm22
   80f74:	62 b1 fd 40 73 d2 34                            	vpsrlq zmm16,zmm18,0x34
   80f7b:	62 81 ed 40 db d7                               	vpandq zmm18,zmm18,zmm31
   80f81:	62 c1 fd 40 d4 c0                               	vpaddq zmm16,zmm16,zmm8
   80f87:	62 11 8d 48 db c7                               	vpandq zmm8,zmm14,zmm31
   80f8d:	c4 41 09 ef f6                                  	vpxor  xmm14,xmm14,xmm14
   80f92:	62 c2 bd 40 b5 c8                               	vpmadd52huq zmm17,zmm24,zmm8
   80f98:	62 52 bd 40 b4 f0                               	vpmadd52luq zmm14,zmm24,zmm8
   80f9e:	62 c2 a5 40 b5 d8                               	vpmadd52huq zmm19,zmm27,zmm8
   80fa4:	62 21 fd 48 6f c4                               	vmovdqa64 zmm24,zmm20
   80faa:	62 81 fd 40 db c7                               	vpandq zmm16,zmm16,zmm31
   80fb0:	62 c2 cd 40 b4 c8                               	vpmadd52luq zmm17,zmm22,zmm8
   80fb6:	62 a1 4d 00 ef f6                               	vpxord xmm22,xmm22,xmm22
   80fbc:	62 c2 9d 40 b5 f0                               	vpmadd52huq zmm22,zmm28,zmm8
   80fc2:	62 e2 8d 48 b4 eb                               	vpmadd52luq zmm21,zmm14,zmm3
   80fc8:	62 c2 dd 40 b4 d8                               	vpmadd52luq zmm19,zmm20,zmm8
   80fce:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   80fd4:	62 c2 bd 40 b5 e0                               	vpmadd52huq zmm20,zmm24,zmm8
   80fda:	62 11 8d 48 d4 f7                               	vpaddq zmm14,zmm14,zmm31
   80fe0:	62 d1 8d 48 73 d6 34                            	vpsrlq zmm14,zmm14,0x34
   80fe7:	62 c2 a5 40 b4 f0                               	vpmadd52luq zmm22,zmm27,zmm8
   80fed:	62 82 d5 40 b5 de                               	vpmadd52huq zmm19,zmm21,zmm30
   80ff3:	62 c2 b5 40 b4 e0                               	vpmadd52luq zmm20,zmm25,zmm8
   80ff9:	62 12 d5 40 b5 f5                               	vpmadd52huq zmm14,zmm21,zmm29
   80fff:	62 82 d5 40 b4 ca                               	vpmadd52luq zmm17,zmm21,zmm26
   81005:	62 82 d5 40 b5 f2                               	vpmadd52huq zmm22,zmm21,zmm26
   8100b:	62 c1 f5 40 d4 ce                               	vpaddq zmm17,zmm17,zmm14
   81011:	c4 41 09 ef f6                                  	vpxor  xmm14,xmm14,xmm14
   81016:	62 52 b5 40 b5 f0                               	vpmadd52huq zmm14,zmm25,zmm8
   8101c:	62 c2 f5 48 b4 cd                               	vpmadd52luq zmm17,zmm1,zmm13
   81022:	62 82 d5 40 b4 f6                               	vpmadd52luq zmm22,zmm21,zmm30
   81028:	62 61 fd 48 6f 74 24 22                         	vmovdqa64 zmm30,ZMMWORD PTR [rsp+0x880]
   81030:	62 32 d5 40 b5 f7                               	vpmadd52huq zmm14,zmm21,zmm23
   81036:	62 c2 f5 48 b5 f5                               	vpmadd52huq zmm22,zmm1,zmm13
   8103c:	62 52 bd 40 b5 f5                               	vpmadd52huq zmm14,zmm24,zmm13
   81042:	62 82 d5 40 b5 e6                               	vpmadd52huq zmm20,zmm21,zmm30
   81048:	62 82 d5 40 b4 de                               	vpmadd52luq zmm19,zmm21,zmm30
   8104e:	62 c2 9d 40 b4 f5                               	vpmadd52luq zmm22,zmm28,zmm13
   81054:	62 52 b5 40 b4 f5                               	vpmadd52luq zmm14,zmm25,zmm13
   8105a:	62 a2 d5 40 b4 e7                               	vpmadd52luq zmm20,zmm21,zmm23
   81060:	62 c2 9d 40 b5 dd                               	vpmadd52huq zmm19,zmm28,zmm13
   81066:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   8106c:	62 e2 f5 40 b4 eb                               	vpmadd52luq zmm21,zmm17,zmm3
   81072:	62 81 f5 40 d4 cf                               	vpaddq zmm17,zmm17,zmm31
   81078:	62 b1 f5 40 73 d1 34                            	vpsrlq zmm17,zmm17,0x34
   8107f:	62 c2 a5 40 b5 e5                               	vpmadd52huq zmm20,zmm27,zmm13
   81085:	62 c2 a5 40 b4 dd                               	vpmadd52luq zmm19,zmm27,zmm13
   8108b:	62 82 d5 40 b5 cd                               	vpmadd52huq zmm17,zmm21,zmm29
   81091:	62 82 d5 40 b4 f2                               	vpmadd52luq zmm22,zmm21,zmm26
   81097:	62 12 d5 40 b5 f6                               	vpmadd52huq zmm14,zmm21,zmm30
   8109d:	62 c2 bd 40 b4 e5                               	vpmadd52luq zmm20,zmm24,zmm13
   810a3:	62 82 d5 40 b5 da                               	vpmadd52huq zmm19,zmm21,zmm26
   810a9:	62 a1 cd 40 d4 f1                               	vpaddq zmm22,zmm22,zmm17
   810af:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   810b5:	62 c2 b5 40 b5 cd                               	vpmadd52huq zmm17,zmm25,zmm13
   810bb:	62 32 d5 40 b4 f7                               	vpmadd52luq zmm14,zmm21,zmm23
   810c1:	62 c2 f5 48 b4 f7                               	vpmadd52luq zmm22,zmm1,zmm15
   810c7:	62 e2 d5 40 b5 e2                               	vpmadd52huq zmm20,zmm21,zmm2
   810cd:	62 e2 d5 40 b4 da                               	vpmadd52luq zmm19,zmm21,zmm2
   810d3:	62 a2 d5 40 b5 cf                               	vpmadd52huq zmm17,zmm21,zmm23
   810d9:	62 52 a5 40 b5 f7                               	vpmadd52huq zmm14,zmm27,zmm15
   810df:	62 82 d5 40 b4 e6                               	vpmadd52luq zmm20,zmm21,zmm30
   810e5:	62 c2 f5 48 b5 df                               	vpmadd52huq zmm19,zmm1,zmm15
   810eb:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   810f1:	62 c2 bd 40 b5 cf                               	vpmadd52huq zmm17,zmm24,zmm15
   810f7:	62 e2 cd 40 b4 eb                               	vpmadd52luq zmm21,zmm22,zmm3
   810fd:	62 81 cd 40 d4 f7                               	vpaddq zmm22,zmm22,zmm31
   81103:	62 52 bd 40 b4 f7                               	vpmadd52luq zmm14,zmm24,zmm15
   81109:	62 b1 cd 40 73 d6 34                            	vpsrlq zmm22,zmm22,0x34
   81110:	62 c2 9d 40 b5 e7                               	vpmadd52huq zmm20,zmm28,zmm15
   81116:	62 c2 9d 40 b4 df                               	vpmadd52luq zmm19,zmm28,zmm15
   8111c:	62 c2 b5 40 b4 cf                               	vpmadd52luq zmm17,zmm25,zmm15
   81122:	62 82 d5 40 b5 f5                               	vpmadd52huq zmm22,zmm21,zmm29
   81128:	62 72 d5 40 b5 f2                               	vpmadd52huq zmm14,zmm21,zmm2
   8112e:	62 c2 a5 40 b4 e7                               	vpmadd52luq zmm20,zmm27,zmm15
   81134:	62 82 d5 40 b4 da                               	vpmadd52luq zmm19,zmm21,zmm26
   8113a:	62 82 d5 40 b5 ce                               	vpmadd52huq zmm17,zmm21,zmm30
   81140:	62 12 d5 40 b4 f6                               	vpmadd52luq zmm14,zmm21,zmm30
   81146:	62 82 d5 40 b5 e2                               	vpmadd52huq zmm20,zmm21,zmm26
   8114c:	62 a1 e5 40 d4 f6                               	vpaddq zmm22,zmm19,zmm22
   81152:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   81158:	62 c2 b5 40 b5 df                               	vpmadd52huq zmm19,zmm25,zmm15
   8115e:	62 a2 d5 40 b4 cf                               	vpmadd52luq zmm17,zmm21,zmm23
   81164:	62 32 9d 40 b5 f2                               	vpmadd52huq zmm14,zmm28,zmm18
   8116a:	62 a2 f5 48 b4 f2                               	vpmadd52luq zmm22,zmm1,zmm18
   81170:	62 e2 d5 40 b4 e2                               	vpmadd52luq zmm20,zmm21,zmm2
   81176:	62 a2 d5 40 b5 df                               	vpmadd52huq zmm19,zmm21,zmm23
   8117c:	62 a1 45 00 ef ff                               	vpxord xmm23,xmm23,xmm23
   81182:	62 a2 a5 40 b5 ca                               	vpmadd52huq zmm17,zmm27,zmm18
   81188:	62 32 a5 40 b4 f2                               	vpmadd52luq zmm14,zmm27,zmm18
   8118e:	62 e2 cd 40 b4 fb                               	vpmadd52luq zmm23,zmm22,zmm3
   81194:	62 81 cd 40 d4 ef                               	vpaddq zmm21,zmm22,zmm31
   8119a:	62 a1 4d 00 ef f6                               	vpxord xmm22,xmm22,xmm22
   811a0:	62 a2 b5 40 b5 f0                               	vpmadd52huq zmm22,zmm25,zmm16
   811a6:	62 b1 d5 40 73 d5 34                            	vpsrlq zmm21,zmm21,0x34
   811ad:	62 a2 f5 48 b5 e2                               	vpmadd52huq zmm20,zmm1,zmm18
   811b3:	62 a2 bd 40 b5 da                               	vpmadd52huq zmm19,zmm24,zmm18
   811b9:	62 a2 bd 40 b4 ca                               	vpmadd52luq zmm17,zmm24,zmm18
   811bf:	62 82 c5 40 b5 ed                               	vpmadd52huq zmm21,zmm23,zmm29
   811c5:	62 12 c5 40 b5 f2                               	vpmadd52huq zmm14,zmm23,zmm26
   811cb:	62 a2 9d 40 b4 e2                               	vpmadd52luq zmm20,zmm28,zmm18
   811d1:	62 a2 b5 40 b4 da                               	vpmadd52luq zmm19,zmm25,zmm18
   811d7:	62 e2 c5 40 b5 ca                               	vpmadd52huq zmm17,zmm23,zmm2
   811dd:	62 72 c5 40 b4 f2                               	vpmadd52luq zmm14,zmm23,zmm2
   811e3:	62 82 c5 40 b4 e2                               	vpmadd52luq zmm20,zmm23,zmm26
   811e9:	62 82 c5 40 b5 de                               	vpmadd52huq zmm19,zmm23,zmm30
   811ef:	62 82 c5 40 b4 ce                               	vpmadd52luq zmm17,zmm23,zmm30
   811f5:	62 32 f5 48 b5 f0                               	vpmadd52huq zmm14,zmm1,zmm16
   811fb:	62 a1 dd 40 d4 ed                               	vpaddq zmm21,zmm20,zmm21
   81201:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   81207:	62 a2 b5 40 b5 e2                               	vpmadd52huq zmm20,zmm25,zmm18
   8120d:	62 e2 c5 40 b4 d8                               	vpmadd52luq zmm19,zmm23,zmm0
   81213:	62 a2 9d 40 b5 c8                               	vpmadd52huq zmm17,zmm28,zmm16
   81219:	62 a2 f5 48 b4 e8                               	vpmadd52luq zmm21,zmm1,zmm16
   8121f:	62 f2 fd 48 59 0d d7 5a f8 ff                   	vpbroadcastq zmm1,QWORD PTR [rip+0xfffffffffff85ad7]        # 6d00 <GCC_except_table711+0x210>
   81229:	62 32 9d 40 b4 f0                               	vpmadd52luq zmm14,zmm28,zmm16
   8122f:	62 e2 c5 40 b5 e0                               	vpmadd52huq zmm20,zmm23,zmm0
   81235:	62 a2 a5 40 b5 d8                               	vpmadd52huq zmm19,zmm27,zmm16
   8123b:	62 a1 45 00 ef ff                               	vpxord xmm23,xmm23,xmm23
   81241:	62 a2 a5 40 b4 c8                               	vpmadd52luq zmm17,zmm27,zmm16
   81247:	62 e2 d5 40 b4 fb                               	vpmadd52luq zmm23,zmm21,zmm3
   8124d:	62 f1 fd 48 6f 5c 24 1f                         	vmovdqa64 zmm3,ZMMWORD PTR [rsp+0x7c0]
   81255:	62 a2 bd 40 b5 e0                               	vpmadd52huq zmm20,zmm24,zmm16
   8125b:	62 a2 bd 40 b4 d8                               	vpmadd52luq zmm19,zmm24,zmm16
   81261:	62 61 c5 40 db c4                               	vpandq zmm24,zmm23,zmm4
   81267:	62 71 9d 48 db e1                               	vpandq zmm12,zmm12,zmm1
   8126d:	62 82 bd 40 b5 ca                               	vpmadd52huq zmm17,zmm24,zmm26
   81273:	62 51 9d 48 d4 d2                               	vpaddq zmm10,zmm12,zmm10
   81279:	62 f1 9d 48 73 f7 04                            	vpsllq zmm12,zmm7,0x4
   81280:	62 e2 bd 40 b5 f0                               	vpmadd52huq zmm22,zmm24,zmm0
   81286:	62 12 bd 40 b4 f2                               	vpmadd52luq zmm14,zmm24,zmm26
   8128c:	62 f1 c5 48 73 d7 30                            	vpsrlq zmm7,zmm7,0x30
   81293:	62 71 9d 48 db e1                               	vpandq zmm12,zmm12,zmm1
   81299:	62 a2 b5 40 b4 e0                               	vpmadd52luq zmm20,zmm25,zmm16
   8129f:	62 e2 bd 40 b5 da                               	vpmadd52huq zmm19,zmm24,zmm2
   812a5:	62 e2 bd 40 b4 ca                               	vpmadd52luq zmm17,zmm24,zmm2
   812ab:	62 f1 ed 48 73 d6 30                            	vpsrlq zmm2,zmm6,0x30
   812b2:	62 f1 cd 48 73 f6 04                            	vpsllq zmm6,zmm6,0x4
   812b9:	62 71 9d 48 d4 e2                               	vpaddq zmm12,zmm12,zmm2
   812bf:	62 d1 ed 48 73 d1 30                            	vpsrlq zmm2,zmm9,0x30
   812c6:	62 f1 cd 48 db f1                               	vpandq zmm6,zmm6,zmm1
   812cc:	62 82 bd 40 b5 e6                               	vpmadd52huq zmm20,zmm24,zmm30
   812d2:	62 82 bd 40 b4 de                               	vpmadd52luq zmm19,zmm24,zmm30
   812d8:	62 e2 bd 40 b4 e0                               	vpmadd52luq zmm20,zmm24,zmm0
   812de:	62 d1 fd 48 73 f1 04                            	vpsllq zmm0,zmm9,0x4
   812e5:	62 61 fd 48 db c1                               	vpandq zmm24,zmm0,zmm1
   812eb:	62 d1 fd 48 73 f3 04                            	vpsllq zmm0,zmm11,0x4
   812f2:	62 71 ed 48 d4 d8                               	vpaddq zmm11,zmm2,zmm0
   812f8:	62 d1 fd 48 73 d2 34                            	vpsrlq zmm0,zmm10,0x34
   812ff:	62 61 bd 40 d4 c7                               	vpaddq zmm24,zmm24,zmm7
   81305:	62 b1 ed 48 73 f6 04                            	vpsllq zmm2,zmm22,0x4
   8130c:	62 f1 fd 48 d4 ed                               	vpaddq zmm5,zmm0,zmm5
   81312:	62 f1 d5 40 d4 c4                               	vpaddq zmm0,zmm21,zmm4
   81318:	62 b1 d5 40 73 d1 30                            	vpsrlq zmm21,zmm17,0x30
   8131f:	62 b1 f5 40 73 f1 04                            	vpsllq zmm17,zmm17,0x4
   81326:	62 f1 85 40 db 64 24 26                         	vpandq zmm4,zmm31,ZMMWORD PTR [rsp+0x980]
   8132e:	62 f1 d5 48 d4 f6                               	vpaddq zmm6,zmm5,zmm6
   81334:	62 e1 f5 40 db c9                               	vpandq zmm17,zmm17,zmm1
   8133a:	62 f1 d5 48 73 d6 34                            	vpsrlq zmm5,zmm6,0x34
   81341:	62 d1 d5 48 d4 fc                               	vpaddq zmm7,zmm5,zmm12
   81347:	62 b1 9d 48 73 f7 04                            	vpsllq zmm12,zmm23,0x4
   8134e:	62 f1 d5 48 73 d7 34                            	vpsrlq zmm5,zmm7,0x34
   81355:	62 11 d5 48 d4 c8                               	vpaddq zmm9,zmm5,zmm24
   8135b:	62 d1 d5 48 73 d1 34                            	vpsrlq zmm5,zmm9,0x34
   81362:	62 d1 d5 48 d4 eb                               	vpaddq zmm5,zmm5,zmm11
   81368:	62 f1 a5 48 73 d0 30                            	vpsrlq zmm11,zmm0,0x30
   8136f:	62 b1 fd 48 73 f3 04                            	vpsllq zmm0,zmm19,0x4
   81376:	62 b1 e5 40 73 d3 30                            	vpsrlq zmm19,zmm19,0x30
   8137d:	62 12 9d 48 b5 dd                               	vpmadd52huq zmm11,zmm12,zmm29
   81383:	62 d1 9d 48 73 f6 04                            	vpsllq zmm12,zmm14,0x4
   8138a:	62 d1 8d 48 73 d6 30                            	vpsrlq zmm14,zmm14,0x30
   81391:	62 71 9d 48 db e1                               	vpandq zmm12,zmm12,zmm1
   81397:	62 51 9d 48 d4 db                               	vpaddq zmm11,zmm12,zmm11
   8139d:	62 71 fd 48 db e1                               	vpandq zmm12,zmm0,zmm1
   813a3:	62 b1 fd 48 73 f4 04                            	vpsllq zmm0,zmm20,0x4
   813aa:	62 b1 dd 40 73 d4 30                            	vpsrlq zmm20,zmm20,0x30
   813b1:	62 31 9d 48 d4 e5                               	vpaddq zmm12,zmm12,zmm21
   813b7:	62 e1 fd 48 db e9                               	vpandq zmm21,zmm0,zmm1
   813bd:	62 d1 fd 48 73 d3 34                            	vpsrlq zmm0,zmm11,0x34
   813c4:	62 e1 dd 40 d4 e2                               	vpaddq zmm20,zmm20,zmm2
   813ca:	62 f1 fd 48 6f 4c 24 1a                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x680]
   813d2:	62 f1 fd 48 6f 54 24 19                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0x640]
   813da:	62 51 fd 48 d4 f6                               	vpaddq zmm14,zmm0,zmm14
   813e0:	62 f1 7c 48 28 44 24 14                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x500]
   813e8:	62 a1 d5 40 d4 db                               	vpaddq zmm19,zmm21,zmm19
   813ee:	62 31 8d 48 d4 f1                               	vpaddq zmm14,zmm14,zmm17
   813f4:	62 d1 f5 40 73 d6 34                            	vpsrlq zmm17,zmm14,0x34
   813fb:	62 51 f5 40 d4 e4                               	vpaddq zmm12,zmm17,zmm12
   81401:	62 d1 f5 40 73 d4 34                            	vpsrlq zmm17,zmm12,0x34
   81408:	62 a1 f5 40 d4 cb                               	vpaddq zmm17,zmm17,zmm19
   8140e:	62 b1 e5 40 73 d1 34                            	vpsrlq zmm19,zmm17,0x34
   81415:	62 21 e5 40 d4 cc                               	vpaddq zmm25,zmm19,zmm20
   8141b:	62 e1 dd 58 d4 25 eb 58 f8 ff                   	vpaddq zmm20,zmm4,QWORD BCST [rip+0xfffffffffff858eb]        # 6d10 <GCC_except_table711+0x220>
   81425:	62 f1 7c 48 29 04 08                            	vmovaps ZMMWORD PTR [rax+rcx*1],zmm0
   8142c:	62 f1 7c 48 28 44 24 12                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x480]
   81434:	62 b1 d5 40 72 e4 34                            	vpsraq zmm21,zmm20,0x34
   8143b:	62 e1 d5 40 d4 6c 24 23                         	vpaddq zmm21,zmm21,ZMMWORD PTR [rsp+0x8c0]
   81443:	62 f1 7c 48 29 44 08 01                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x40],zmm0
   8144b:	62 f1 7c 48 28 44 24 1c                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x700]
   81453:	62 b1 cd 40 72 e5 34                            	vpsraq zmm22,zmm21,0x34
   8145a:	62 e1 cd 40 d4 74 24 24                         	vpaddq zmm22,zmm22,ZMMWORD PTR [rsp+0x900]
   81462:	62 f1 7c 48 29 44 08 02                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x80],zmm0
   8146a:	62 f1 7c 48 28 44 24 1b                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x6c0]
   81472:	62 b1 c5 40 72 e6 34                            	vpsraq zmm23,zmm22,0x34
   81479:	62 e1 c5 40 d4 7c 24 25                         	vpaddq zmm23,zmm23,ZMMWORD PTR [rsp+0x940]
   81481:	62 f1 7c 48 29 44 08 03                         	vmovaps ZMMWORD PTR [rax+rcx*1+0xc0],zmm0
   81489:	62 f1 7c 48 28 44 24 0e                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x380]
   81491:	62 b1 bd 40 72 e7 34                            	vpsraq zmm24,zmm23,0x34
   81498:	62 61 bd 40 d4 44 24 1e                         	vpaddq zmm24,zmm24,ZMMWORD PTR [rsp+0x780]
   814a0:	62 f1 7c 48 29 44 08 04                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x100],zmm0
   814a8:	62 f1 7c 48 28 44 24 08                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x200]
   814b0:	62 f3 bd 50 1e 0d dd 57 f8 ff 01                	vpcmpltuq k1,zmm24,QWORD BCST [rip+0xfffffffffff857dd]        # 6c98 <GCC_except_table711+0x1a8>
   814bb:	62 f1 7c 48 29 44 08 05                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x140],zmm0
   814c3:	62 f1 7c 48 28 44 24 0a                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x280]
   814cb:	62 91 dd 41 db e7                               	vpandq zmm4{k1},zmm20,zmm31
   814d1:	62 e1 fd 48 6f 64 24 18                         	vmovdqa64 zmm20,ZMMWORD PTR [rsp+0x600]
   814d9:	62 91 d5 41 db cf                               	vpandq zmm1{k1},zmm21,zmm31
   814df:	62 91 cd 41 db d7                               	vpandq zmm2{k1},zmm22,zmm31
   814e5:	62 91 c5 41 db df                               	vpandq zmm3{k1},zmm23,zmm31
   814eb:	62 81 8d 48 db f7                               	vpandq zmm22,zmm14,zmm31
   814f1:	62 81 9d 48 db ef                               	vpandq zmm21,zmm12,zmm31
   814f7:	62 f1 7c 48 29 44 08 06                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x180],zmm0
   814ff:	62 f1 7c 48 28 44 24 09                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x240]
   81507:	62 81 bd 41 db e7                               	vpandq zmm20{k1},zmm24,zmm31
   8150d:	62 01 a5 48 db c7                               	vpandq zmm24,zmm11,zmm31
   81513:	62 f1 7c 48 29 44 08 07                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x1c0],zmm0
   8151b:	62 f1 7c 48 28 44 24 0b                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x2c0]
   81523:	62 f1 7c 48 29 44 08 08                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x200],zmm0
   8152b:	62 f1 7c 48 28 44 24 0f                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x3c0]
   81533:	62 f1 7c 48 29 44 08 09                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x240],zmm0
   8153b:	62 f1 fd 48 7f 64 08 0a                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x280],zmm4
   81543:	62 f1 fd 48 7f 4c 08 0b                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x2c0],zmm1
   8154b:	62 f1 fd 48 7f 54 08 0c                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x300],zmm2
   81553:	62 f1 fd 48 7f 5c 08 0d                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x340],zmm3
   8155b:	62 e1 fd 48 7f 64 08 0e                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x380],zmm20
   81563:	62 71 fd 48 7f 44 08 0f                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x3c0],zmm8
   8156b:	62 71 fd 48 7f 6c 08 10                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x400],zmm13
   81573:	c5 7d 6f 2d a5 63 f8 ff                         	vmovdqa ymm13,YMMWORD PTR [rip+0xfffffffffff863a5]        # 7920 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x980>
   8157b:	62 91 ad 48 db c7                               	vpandq zmm0,zmm10,zmm31
   81581:	62 71 fd 48 7f 7c 08 11                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x440],zmm15
   81589:	62 e1 fd 48 7f 54 08 12                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x480],zmm18
   81591:	62 e1 fd 48 7f 44 08 13                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x4c0],zmm16
   81599:	62 81 f5 40 db e7                               	vpandq zmm20,zmm17,zmm31
   8159f:	62 f1 fd 48 7f 44 08 14                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x500],zmm0
   815a7:	62 91 cd 48 db c7                               	vpandq zmm0,zmm6,zmm31
   815ad:	62 f1 fd 48 7f 44 08 15                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x540],zmm0
   815b5:	62 91 c5 48 db c7                               	vpandq zmm0,zmm7,zmm31
   815bb:	62 f1 fd 48 7f 44 08 16                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x580],zmm0
   815c3:	62 91 b5 48 db c7                               	vpandq zmm0,zmm9,zmm31
   815c9:	62 f1 fd 48 7f 44 08 17                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x5c0],zmm0
   815d1:	62 f1 fd 48 7f 6c 08 18                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x600],zmm5
   815d9:	4d 89 58 10                                     	mov    QWORD PTR [r8+0x10],r11
   815dd:	49 39 f2                                        	cmp    r10,rsi
   815e0:	0f 84 d4 f1 ff ff                               	je     807ba <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x12da>
   815e6:	4c 89 e8                                        	mov    rax,r13
   815e9:	48 29 f8                                        	sub    rax,rdi
   815ec:	be 00 00 00 00                                  	mov    esi,0x0
   815f1:	48 0f 43 f0                                     	cmovae rsi,rax
   815f5:	0f 86 e8 46 00 00                               	jbe    85ce3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6803>
   815fb:	41 8b 07                                        	mov    eax,DWORD PTR [r15]
   815fe:	25 ff ff ff 7f                                  	and    eax,0x7fffffff
   81603:	49 39 c4                                        	cmp    r12,rax
   81606:	0f 86 6a 47 00 00                               	jbe    85d76 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6896>
   8160c:	48 83 fe 01                                     	cmp    rsi,0x1
   81610:	0f 84 ca 46 00 00                               	je     85ce0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6800>
   81616:	41 8b 57 10                                     	mov    edx,DWORD PTR [r15+0x10]
   8161a:	81 e2 ff ff ff 7f                               	and    edx,0x7fffffff
   81620:	49 39 d4                                        	cmp    r12,rdx
   81623:	0f 86 ea 46 00 00                               	jbe    85d13 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6833>
   81629:	48 83 fe 02                                     	cmp    rsi,0x2
   8162d:	0f 84 a7 46 00 00                               	je     85cda <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x67fa>
   81633:	45 8b 47 20                                     	mov    r8d,DWORD PTR [r15+0x20]
   81637:	41 81 e0 ff ff ff 7f                            	and    r8d,0x7fffffff
   8163e:	4d 39 c4                                        	cmp    r12,r8
   81641:	0f 86 b4 46 00 00                               	jbe    85cfb <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x681b>
   81647:	48 83 fe 03                                     	cmp    rsi,0x3
   8164b:	0f 84 83 46 00 00                               	je     85cd4 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x67f4>
   81651:	45 8b 4f 30                                     	mov    r9d,DWORD PTR [r15+0x30]
   81655:	41 81 e1 ff ff ff 7f                            	and    r9d,0x7fffffff
   8165c:	4d 39 cc                                        	cmp    r12,r9
   8165f:	0f 86 4b 46 00 00                               	jbe    85cb0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x67d0>
   81665:	48 83 fe 04                                     	cmp    rsi,0x4
   81669:	0f 84 5f 46 00 00                               	je     85cce <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x67ee>
   8166f:	45 8b 57 40                                     	mov    r10d,DWORD PTR [r15+0x40]
   81673:	41 81 e2 ff ff ff 7f                            	and    r10d,0x7fffffff
   8167a:	4d 39 d4                                        	cmp    r12,r10
   8167d:	0f 86 f0 46 00 00                               	jbe    85d73 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6893>
   81683:	48 83 fe 05                                     	cmp    rsi,0x5
   81687:	0f 84 3b 46 00 00                               	je     85cc8 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x67e8>
   8168d:	45 8b 5f 50                                     	mov    r11d,DWORD PTR [r15+0x50]
   81691:	41 81 e3 ff ff ff 7f                            	and    r11d,0x7fffffff
   81698:	4d 39 dc                                        	cmp    r12,r11
   8169b:	0f 86 ba 46 00 00                               	jbe    85d5b <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x687b>
   816a1:	48 83 fe 06                                     	cmp    rsi,0x6
   816a5:	0f 84 ff 45 00 00                               	je     85caa <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x67ca>
   816ab:	41 8b 5f 60                                     	mov    ebx,DWORD PTR [r15+0x60]
   816af:	81 e3 ff ff ff 7f                               	and    ebx,0x7fffffff
   816b5:	49 39 dc                                        	cmp    r12,rbx
   816b8:	0f 86 85 46 00 00                               	jbe    85d43 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6863>
   816be:	48 8d 4f 07                                     	lea    rcx,[rdi+0x7]
   816c2:	48 83 fe 07                                     	cmp    rsi,0x7
   816c6:	0f 84 1a 46 00 00                               	je     85ce6 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6806>
   816cc:	41 8b 77 70                                     	mov    esi,DWORD PTR [r15+0x70]
   816d0:	81 e6 ff ff ff 7f                               	and    esi,0x7fffffff
   816d6:	49 39 f4                                        	cmp    r12,rsi
   816d9:	0f 86 4c 46 00 00                               	jbe    85d2b <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x684b>
   816df:	4c 8b b4 24 40 05 00 00                         	mov    r14,QWORD PTR [rsp+0x540]
   816e7:	49 c1 e3 06                                     	shl    r11,0x6
   816eb:	48 c1 e2 06                                     	shl    rdx,0x6
   816ef:	48 c1 e3 06                                     	shl    rbx,0x6
   816f3:	48 c1 e6 06                                     	shl    rsi,0x6
   816f7:	49 c1 e0 06                                     	shl    r8,0x6
   816fb:	48 c1 e0 06                                     	shl    rax,0x6
   816ff:	49 c1 e1 06                                     	shl    r9,0x6
   81703:	49 c1 e2 06                                     	shl    r10,0x6
   81707:	c4 81 7c 10 74 1e 20                            	vmovups ymm6,YMMWORD PTR [r14+r11*1+0x20]
   8170e:	c4 c1 7e 6f 0c 16                               	vmovdqu ymm1,YMMWORD PTR [r14+rdx*1]
   81714:	62 c1 7c 28 10 7c 16 01                         	vmovups ymm23,YMMWORD PTR [r14+rdx*1+0x20]
   8171c:	49 8b 57 28                                     	mov    rdx,QWORD PTR [r15+0x28]
   81720:	c4 c1 7c 10 7c 1e 20                            	vmovups ymm7,YMMWORD PTR [r14+rbx*1+0x20]
   81727:	c4 81 7e 6f 14 06                               	vmovdqu ymm2,YMMWORD PTR [r14+r8*1]
   8172d:	62 01 7c 28 10 5c 06 01                         	vmovups ymm27,YMMWORD PTR [r14+r8*1+0x20]
   81735:	4d 8b 47 08                                     	mov    r8,QWORD PTR [r15+0x8]
   81739:	c4 c1 7e 6f 04 06                               	vmovdqu ymm0,YMMWORD PTR [r14+rax*1]
   8173f:	62 c1 7c 28 10 5c 06 01                         	vmovups ymm19,YMMWORD PTR [r14+rax*1+0x20]
   81747:	c4 81 7e 6f 1c 0e                               	vmovdqu ymm3,YMMWORD PTR [r14+r9*1]
   8174d:	62 01 7c 28 10 64 0e 01                         	vmovups ymm28,YMMWORD PTR [r14+r9*1+0x20]
   81755:	c4 81 7e 6f 24 16                               	vmovdqu ymm4,YMMWORD PTR [r14+r10*1]
   8175b:	62 01 7c 28 10 74 16 01                         	vmovups ymm30,YMMWORD PTR [r14+r10*1+0x20]
   81763:	c4 81 7e 6f 2c 1e                               	vmovdqu ymm5,YMMWORD PTR [r14+r11*1]
   81769:	48 b8 63 c2 e5 9c c8 60 00 00                   	movabs rax,0x60c89ce5c263
   81773:	c5 7e 6f 0a                                     	vmovdqu ymm9,YMMWORD PTR [rdx]
   81777:	62 61 fe 28 6f 6a 01                            	vmovdqu64 ymm29,YMMWORD PTR [rdx+0x20]
   8177e:	49 8b 57 68                                     	mov    rdx,QWORD PTR [r15+0x68]
   81782:	c4 41 7e 6f 00                                  	vmovdqu ymm8,YMMWORD PTR [r8]
   81787:	62 41 fe 28 6f 50 01                            	vmovdqu64 ymm26,YMMWORD PTR [r8+0x20]
   8178e:	4d 8b 47 48                                     	mov    r8,QWORD PTR [r15+0x48]
   81792:	c5 fc 29 b4 24 00 04 00 00                      	vmovaps YMMWORD PTR [rsp+0x400],ymm6
   8179b:	c4 c1 7e 6f 34 1e                               	vmovdqu ymm6,YMMWORD PTR [r14+rbx*1]
   817a1:	62 53 cd 48 3a 14 36 01                         	vinserti64x4 zmm10,zmm6,YMMWORD PTR [r14+rsi*1],0x1
   817a9:	62 d3 c5 48 1a 74 36 01 01                      	vinsertf64x4 zmm6,zmm7,YMMWORD PTR [r14+rsi*1+0x20],0x1
   817b2:	49 8b 77 18                                     	mov    rsi,QWORD PTR [r15+0x18]
   817b6:	c5 7e 6f 22                                     	vmovdqu ymm12,YMMWORD PTR [rdx]
   817ba:	c5 7c 10 7a 20                                  	vmovups ymm15,YMMWORD PTR [rdx+0x20]
   817bf:	49 8b 57 38                                     	mov    rdx,QWORD PTR [r15+0x38]
   817c3:	c4 41 7e 6f 18                                  	vmovdqu ymm11,YMMWORD PTR [r8]
   817c8:	c4 41 7c 10 70 20                               	vmovups ymm14,YMMWORD PTR [r8+0x20]
   817ce:	62 e1 7c 28 10 46 01                            	vmovups ymm16,YMMWORD PTR [rsi+0x20]
   817d5:	62 e1 7c 28 10 4a 01                            	vmovups ymm17,YMMWORD PTR [rdx+0x20]
   817dc:	62 f3 b5 48 3a 3a 01                            	vinserti64x4 zmm7,zmm9,YMMWORD PTR [rdx],0x1
   817e3:	49 8b 57 78                                     	mov    rdx,QWORD PTR [r15+0x78]
   817e7:	62 f1 7c 48 29 74 24 0d                         	vmovaps ZMMWORD PTR [rsp+0x340],zmm6
   817ef:	62 f3 bd 48 3a 36 01                            	vinserti64x4 zmm6,zmm8,YMMWORD PTR [rsi],0x1
   817f6:	49 8b 77 58                                     	mov    rsi,QWORD PTR [r15+0x58]
   817fa:	62 73 9d 48 3a 0a 01                            	vinserti64x4 zmm9,zmm12,YMMWORD PTR [rdx],0x1
   81801:	62 73 a5 48 3a 06 01                            	vinserti64x4 zmm8,zmm11,YMMWORD PTR [rsi],0x1
   81808:	62 e1 7c 28 10 56 01                            	vmovups ymm18,YMMWORD PTR [rsi+0x20]
   8180f:	c5 7c 10 5a 20                                  	vmovups ymm11,YMMWORD PTR [rdx+0x20]
   81814:	48 8d 77 08                                     	lea    rsi,[rdi+0x8]
   81818:	c5 7e 7f ac 24 80 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0x80],ymm13
   81821:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   81829:	4c 39 e9                                        	cmp    rcx,r13
   8182c:	0f 83 9a 42 00 00                               	jae    85acc <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x65ec>
   81832:	62 e1 7c 28 29 4c 24 53                         	vmovaps YMMWORD PTR [rsp+0xa60],ymm17
   8183a:	62 e1 fd 48 6f 0d fc 5b f8 ff                   	vmovdqa64 zmm17,ZMMWORD PTR [rip+0xfffffffffff85bfc]        # 7440 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4a0>
   81844:	62 e1 7c 28 29 54 24 52                         	vmovaps YMMWORD PTR [rsp+0xa40],ymm18
   8184c:	62 e1 fd 48 6f 15 aa 5b f8 ff                   	vmovdqa64 zmm18,ZMMWORD PTR [rip+0xfffffffffff85baa]        # 7400 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x460>
   81856:	62 73 ed 48 3a e3 01                            	vinserti64x4 zmm12,zmm2,ymm3,0x1
   8185d:	62 f3 fd 48 3a c1 01                            	vinserti64x4 zmm0,zmm0,ymm1,0x1
   81864:	62 f3 dd 48 3a d5 01                            	vinserti64x4 zmm2,zmm4,ymm5,0x1
   8186b:	c5 7c 29 9c 24 20 0a 00 00                      	vmovaps YMMWORD PTR [rsp+0xa20],ymm11
   81874:	62 e1 7c 28 29 44 24 54                         	vmovaps YMMWORD PTR [rsp+0xa80],ymm16
   8187c:	62 71 7c 48 29 7c 24 40                         	vmovaps ZMMWORD PTR [rsp+0x1000],zmm15
   81884:	62 71 7c 48 29 74 24 41                         	vmovaps ZMMWORD PTR [rsp+0x1040],zmm14
   8188c:	62 61 7c 48 29 5c 24 3e                         	vmovaps ZMMWORD PTR [rsp+0xf80],zmm27
   81894:	48 b9 31 e1 72 4e 64 30 00 00                   	movabs rcx,0x30644e72e131
   8189e:	62 61 7c 28 29 64 24 4f                         	vmovaps YMMWORD PTR [rsp+0x9e0],ymm28
   818a6:	62 e1 7c 48 29 5c 24 3f                         	vmovaps ZMMWORD PTR [rsp+0xfc0],zmm19
   818ae:	4c 8b 84 24 40 04 00 00                         	mov    r8,QWORD PTR [rsp+0x440]
   818b6:	62 61 7c 48 29 74 24 3d                         	vmovaps ZMMWORD PTR [rsp+0xf40],zmm30
   818be:	62 e1 7c 28 29 7c 24 50                         	vmovaps YMMWORD PTR [rsp+0xa00],ymm23
   818c6:	4c 89 fa                                        	mov    rdx,r15
   818c9:	45 8b 17                                        	mov    r10d,DWORD PTR [r15]
   818cc:	45 8b 77 10                                     	mov    r14d,DWORD PTR [r15+0x10]
   818d0:	45 8b 6f 20                                     	mov    r13d,DWORD PTR [r15+0x20]
   818d4:	41 8b 5f 30                                     	mov    ebx,DWORD PTR [r15+0x30]
   818d8:	45 8b 7f 40                                     	mov    r15d,DWORD PTR [r15+0x40]
   818dc:	8b 7a 50                                        	mov    edi,DWORD PTR [rdx+0x50]
   818df:	44 8b 4a 60                                     	mov    r9d,DWORD PTR [rdx+0x60]
   818e3:	44 0f b6 62 73                                  	movzx  r12d,BYTE PTR [rdx+0x73]
   818e8:	62 d1 fd 48 6c dc                               	vpunpcklqdq zmm3,zmm0,zmm12
   818ee:	62 d1 fd 48 6d c4                               	vpunpckhqdq zmm0,zmm0,zmm12
   818f4:	62 51 ed 48 6c da                               	vpunpcklqdq zmm11,zmm2,zmm10
   818fa:	62 d1 ed 48 6d d2                               	vpunpckhqdq zmm2,zmm2,zmm10
   81900:	62 f1 fd 48 6f e3                               	vmovdqa64 zmm4,zmm3
   81906:	62 f1 fd 48 6f e8                               	vmovdqa64 zmm5,zmm0
   8190c:	4d 8b 58 10                                     	mov    r11,QWORD PTR [r8+0x10]
   81910:	62 f2 f5 40 7e c2                               	vpermt2q zmm0,zmm17,zmm2
   81916:	62 d2 f5 40 7e db                               	vpermt2q zmm3,zmm17,zmm11
   8191c:	62 d2 ed 40 7e e3                               	vpermt2q zmm4,zmm18,zmm11
   81922:	62 f2 ed 40 7e ea                               	vpermt2q zmm5,zmm18,zmm2
   81928:	62 f3 fd 48 71 d3 24                            	vpshldq zmm2,zmm0,zmm3,0x24
   8192f:	62 11 dd 48 db df                               	vpandq zmm11,zmm4,zmm31
   81935:	62 f3 d5 48 71 cc 0c                            	vpshldq zmm1,zmm5,zmm4,0xc
   8193c:	62 f3 e5 48 71 e5 18                            	vpshldq zmm4,zmm3,zmm5,0x18
   81943:	62 f1 fd 40 73 d0 10                            	vpsrlq zmm16,zmm0,0x10
   8194a:	62 f1 cd 48 6c c7                               	vpunpcklqdq zmm0,zmm6,zmm7
   81950:	62 f1 cd 48 6d f7                               	vpunpckhqdq zmm6,zmm6,zmm7
   81956:	62 d1 bd 48 6d d9                               	vpunpckhqdq zmm3,zmm8,zmm9
   8195c:	62 f1 fd 48 6f ee                               	vmovdqa64 zmm5,zmm6
   81962:	62 f2 ed 40 7e eb                               	vpermt2q zmm5,zmm18,zmm3
   81968:	62 f2 f5 40 7e f3                               	vpermt2q zmm6,zmm17,zmm3
   8196e:	62 71 fd 48 7f 5c 24 14                         	vmovdqa64 ZMMWORD PTR [rsp+0x500],zmm11
   81976:	62 e1 fd 48 7f 44 24 0e                         	vmovdqa64 ZMMWORD PTR [rsp+0x380],zmm16
   8197e:	62 11 ed 48 db ff                               	vpandq zmm15,zmm2,zmm31
   81984:	62 d1 bd 48 6c d1                               	vpunpcklqdq zmm2,zmm8,zmm9
   8198a:	62 11 dd 48 db f7                               	vpandq zmm14,zmm4,zmm31
   81990:	62 f1 fd 48 6f e0                               	vmovdqa64 zmm4,zmm0
   81996:	c5 7c 28 05 42 5e f8 ff                         	vmovaps ymm8,YMMWORD PTR [rip+0xfffffffffff85e42]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   8199e:	62 11 f5 48 db e7                               	vpandq zmm12,zmm1,zmm31
   819a4:	62 f2 ed 40 7e e2                               	vpermt2q zmm4,zmm18,zmm2
   819aa:	62 f2 f5 40 7e c2                               	vpermt2q zmm0,zmm17,zmm2
   819b0:	62 e2 fd 48 59 4c 24 14                         	vpbroadcastq zmm17,QWORD PTR [rsp+0xa0]
   819b8:	62 71 fd 48 7f 64 24 12                         	vmovdqa64 ZMMWORD PTR [rsp+0x480],zmm12
   819c0:	62 71 fd 48 7f 74 24 1c                         	vmovdqa64 ZMMWORD PTR [rsp+0x700],zmm14
   819c8:	62 71 fd 48 7f 7c 24 1b                         	vmovdqa64 ZMMWORD PTR [rsp+0x6c0],zmm15
   819d0:	62 f1 ed 40 73 d6 10                            	vpsrlq zmm18,zmm6,0x10
   819d7:	62 f3 d5 48 71 dc 0c                            	vpshldq zmm3,zmm5,zmm4,0xc
   819de:	62 91 dd 48 db d7                               	vpandq zmm2,zmm4,zmm31
   819e4:	62 f3 fd 48 71 e5 18                            	vpshldq zmm4,zmm0,zmm5,0x18
   819eb:	62 f3 cd 48 71 c0 24                            	vpshldq zmm0,zmm6,zmm0,0x24
   819f2:	62 d1 ed 48 fb cb                               	vpsubq zmm1,zmm2,zmm11
   819f8:	62 91 e5 48 db df                               	vpandq zmm3,zmm3,zmm31
   819fe:	62 f1 fd 48 7f 4c 24 20                         	vmovdqa64 ZMMWORD PTR [rsp+0x800],zmm1
   81a06:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   81a0d:	62 91 dd 48 db e7                               	vpandq zmm4,zmm4,zmm31
   81a13:	62 91 fd 48 db c7                               	vpandq zmm0,zmm0,zmm31
   81a19:	62 d1 e5 48 fb ec                               	vpsubq zmm5,zmm3,zmm12
   81a1f:	62 f1 d5 48 d4 c9                               	vpaddq zmm1,zmm5,zmm1
   81a25:	62 d1 dd 48 fb ee                               	vpsubq zmm5,zmm4,zmm14
   81a2b:	62 01 f5 48 db df                               	vpandq zmm27,zmm1,zmm31
   81a31:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   81a38:	62 f1 a5 50 d4 7c 24 11                         	vpaddq zmm7,zmm27,QWORD BCST [rsp+0x88]
   81a40:	62 f1 d5 48 d4 c9                               	vpaddq zmm1,zmm5,zmm1
   81a46:	62 d1 fd 48 fb ef                               	vpsubq zmm5,zmm0,zmm15
   81a4c:	62 f1 85 48 d4 c0                               	vpaddq zmm0,zmm15,zmm0
   81a52:	62 91 f5 48 db f7                               	vpandq zmm6,zmm1,zmm31
   81a58:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   81a5f:	62 71 cd 58 d4 4c 24 12                         	vpaddq zmm9,zmm6,QWORD BCST [rsp+0x90]
   81a67:	62 f1 d5 48 d4 c9                               	vpaddq zmm1,zmm5,zmm1
   81a6d:	62 f1 fd 48 7f 74 24 48                         	vmovdqa64 ZMMWORD PTR [rsp+0x1200],zmm6
   81a75:	62 91 f5 48 db ef                               	vpandq zmm5,zmm1,zmm31
   81a7b:	62 61 d5 58 d4 64 24 13                         	vpaddq zmm28,zmm5,QWORD BCST [rsp+0x98]
   81a83:	c5 7c 11 84 24 80 00 00 00                      	vmovups YMMWORD PTR [rsp+0x80],ymm8
   81a8c:	48 89 8c 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rcx
   81a94:	62 f1 fd 48 7f 4c 24 45                         	vmovdqa64 ZMMWORD PTR [rsp+0x1140],zmm1
   81a9c:	62 f1 fd 48 7f 6c 24 46                         	vmovdqa64 ZMMWORD PTR [rsp+0x1180],zmm5
   81aa4:	62 f2 fd 48 19 6c 24 12                         	vbroadcastsd zmm5,QWORD PTR [rsp+0x90]
   81aac:	62 f2 fd 48 19 74 24 14                         	vbroadcastsd zmm6,QWORD PTR [rsp+0xa0]
   81ab4:	62 e2 fd 48 59 5c 24 11                         	vpbroadcastq zmm19,QWORD PTR [rsp+0x88]
   81abc:	62 f1 fd 48 7f 7c 24 47                         	vmovdqa64 ZMMWORD PTR [rsp+0x11c0],zmm7
   81ac4:	62 f2 fd 48 19 7c 24 13                         	vbroadcastsd zmm7,QWORD PTR [rsp+0x98]
   81acc:	c5 7c 11 84 24 80 00 00 00                      	vmovups YMMWORD PTR [rsp+0x80],ymm8
   81ad5:	48 89 8c 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rcx
   81add:	62 f2 fd 48 19 4c 24 11                         	vbroadcastsd zmm1,QWORD PTR [rsp+0x88]
   81ae5:	62 62 fd 48 59 74 24 12                         	vpbroadcastq zmm30,QWORD PTR [rsp+0x90]
   81aed:	62 e2 fd 48 59 7c 24 14                         	vpbroadcastq zmm23,QWORD PTR [rsp+0xa0]
   81af5:	62 71 fd 48 7f 4c 24 49                         	vmovdqa64 ZMMWORD PTR [rsp+0x1240],zmm9
   81afd:	62 f1 7c 48 29 6c 24 42                         	vmovaps ZMMWORD PTR [rsp+0x1080],zmm5
   81b05:	62 f2 fd 48 19 6c 24 13                         	vbroadcastsd zmm5,QWORD PTR [rsp+0x98]
   81b0d:	62 f1 7c 48 29 74 24 44                         	vmovaps ZMMWORD PTR [rsp+0x1100],zmm6
   81b15:	62 f1 9d 48 d4 f3                               	vpaddq zmm6,zmm12,zmm3
   81b1b:	62 b1 fd 40 d4 da                               	vpaddq zmm3,zmm16,zmm18
   81b21:	c5 7e 7f ac 24 80 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0x80],ymm13
   81b2a:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   81b32:	62 f1 7c 48 29 7c 24 43                         	vmovaps ZMMWORD PTR [rsp+0x10c0],zmm7
   81b3a:	62 f1 7c 48 29 4c 24 21                         	vmovaps ZMMWORD PTR [rsp+0x840],zmm1
   81b42:	62 f1 7c 48 29 6c 24 22                         	vmovaps ZMMWORD PTR [rsp+0x880],zmm5
   81b4a:	62 f1 a5 48 d4 ea                               	vpaddq zmm5,zmm11,zmm2
   81b50:	62 f1 8d 48 d4 d4                               	vpaddq zmm2,zmm14,zmm4
   81b56:	62 f1 dd 48 73 d5 34                            	vpsrlq zmm4,zmm5,0x34
   81b5d:	62 f1 fd 48 7f 6c 24 26                         	vmovdqa64 ZMMWORD PTR [rsp+0x980],zmm5
   81b65:	62 f1 dd 48 d4 ce                               	vpaddq zmm1,zmm4,zmm6
   81b6b:	62 f1 dd 48 73 d1 34                            	vpsrlq zmm4,zmm1,0x34
   81b72:	62 f1 dd 48 d4 d2                               	vpaddq zmm2,zmm4,zmm2
   81b78:	62 91 f5 48 db e7                               	vpandq zmm4,zmm1,zmm31
   81b7e:	62 f1 f5 48 73 d2 34                            	vpsrlq zmm1,zmm2,0x34
   81b85:	62 91 ed 48 db d7                               	vpandq zmm2,zmm2,zmm31
   81b8b:	62 f1 fd 48 7f 64 24 1a                         	vmovdqa64 ZMMWORD PTR [rsp+0x680],zmm4
   81b93:	62 f1 f5 48 d4 c0                               	vpaddq zmm0,zmm1,zmm0
   81b99:	62 f1 fd 48 7f 54 24 19                         	vmovdqa64 ZMMWORD PTR [rsp+0x640],zmm2
   81ba1:	62 f1 ed 58 fb 54 24 12                         	vpsubq zmm2,zmm2,QWORD BCST [rsp+0x90]
   81ba9:	62 f1 f5 48 73 d0 34                            	vpsrlq zmm1,zmm0,0x34
   81bb0:	62 91 fd 48 db c7                               	vpandq zmm0,zmm0,zmm31
   81bb6:	62 f1 f5 48 d4 cb                               	vpaddq zmm1,zmm1,zmm3
   81bbc:	62 f1 dd 58 fb 5c 24 11                         	vpsubq zmm3,zmm4,QWORD BCST [rsp+0x88]
   81bc4:	62 f1 fd 48 7f 44 24 1f                         	vmovdqa64 ZMMWORD PTR [rsp+0x7c0],zmm0
   81bcc:	62 f1 fd 58 fb 44 24 13                         	vpsubq zmm0,zmm0,QWORD BCST [rsp+0x98]
   81bd4:	62 f1 fd 48 7f 4c 24 18                         	vmovdqa64 ZMMWORD PTR [rsp+0x600],zmm1
   81bdc:	62 f1 f5 58 fb 4c 24 14                         	vpsubq zmm1,zmm1,QWORD BCST [rsp+0xa0]
   81be4:	62 f1 fd 48 7f 54 24 24                         	vmovdqa64 ZMMWORD PTR [rsp+0x900],zmm2
   81bec:	62 f1 fd 48 7f 5c 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm3
   81bf4:	62 f1 fd 48 7f 44 24 25                         	vmovdqa64 ZMMWORD PTR [rsp+0x940],zmm0
   81bfc:	62 f1 fd 48 7f 4c 24 1e                         	vmovdqa64 ZMMWORD PTR [rsp+0x780],zmm1
   81c04:	4d 3b 18                                        	cmp    r11,QWORD PTR [r8]
   81c07:	0f 85 33 ec ff ff                               	jne    80840 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x1360>
   81c0d:	89 7c 24 7c                                     	mov    DWORD PTR [rsp+0x7c],edi
   81c11:	4c 89 c7                                        	mov    rdi,r8
   81c14:	62 61 fd 48 7f 4c 24 08                         	vmovdqa64 ZMMWORD PTR [rsp+0x200],zmm25
   81c1c:	62 e1 fd 48 7f 64 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm20
   81c24:	62 e1 fd 48 7f 6c 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm21
   81c2c:	62 e1 fd 48 7f 74 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm22
   81c34:	62 61 fd 48 7f 44 24 13                         	vmovdqa64 ZMMWORD PTR [rsp+0x4c0],zmm24
   81c3c:	4c 89 9c 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],r11
   81c44:	48 89 b4 24 38 03 00 00                         	mov    QWORD PTR [rsp+0x338],rsi
   81c4c:	48 89 94 24 30 03 00 00                         	mov    QWORD PTR [rsp+0x330],rdx
   81c54:	62 e1 fd 48 7f 7c 24 3c                         	vmovdqa64 ZMMWORD PTR [rsp+0xf00],zmm23
   81c5c:	62 61 fd 48 7f 74 24 3b                         	vmovdqa64 ZMMWORD PTR [rsp+0xec0],zmm30
   81c64:	62 e1 fd 48 7f 4c 24 3a                         	vmovdqa64 ZMMWORD PTR [rsp+0xe80],zmm17
   81c6c:	62 e1 fd 48 7f 54 24 39                         	vmovdqa64 ZMMWORD PTR [rsp+0xe40],zmm18
   81c74:	62 61 fd 48 7f 5c 24 38                         	vmovdqa64 ZMMWORD PTR [rsp+0xe00],zmm27
   81c7c:	62 61 fd 48 7f 64 24 37                         	vmovdqa64 ZMMWORD PTR [rsp+0xdc0],zmm28
   81c84:	62 e1 fd 48 7f 5c 24 36                         	vmovdqa64 ZMMWORD PTR [rsp+0xd80],zmm19
   81c8c:	62 61 fd 48 7f 54 24 35                         	vmovdqa64 ZMMWORD PTR [rsp+0xd40],zmm26
   81c94:	62 61 fd 48 7f 6c 24 34                         	vmovdqa64 ZMMWORD PTR [rsp+0xd00],zmm29
   81c9c:	44 89 4c 24 78                                  	mov    DWORD PTR [rsp+0x78],r9d
   81ca1:	44 89 54 24 74                                  	mov    DWORD PTR [rsp+0x74],r10d
   81ca6:	c5 f8 77                                        	vzeroupper
   81ca9:	e8 02 1f 01 00                                  	call   93bb0 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecNtNtCsHW5vo2gROj_10zopro_core3msm10FqAddGroupE8grow_oneBP_>
   81cae:	62 61 fd 48 6f 6c 24 34                         	vmovdqa64 zmm29,ZMMWORD PTR [rsp+0xd00]
   81cb6:	62 61 fd 48 6f 54 24 35                         	vmovdqa64 zmm26,ZMMWORD PTR [rsp+0xd40]
   81cbe:	62 e1 fd 48 6f 5c 24 36                         	vmovdqa64 zmm19,ZMMWORD PTR [rsp+0xd80]
   81cc6:	62 61 fd 48 6f 64 24 37                         	vmovdqa64 zmm28,ZMMWORD PTR [rsp+0xdc0]
   81cce:	62 61 fd 48 6f 5c 24 38                         	vmovdqa64 zmm27,ZMMWORD PTR [rsp+0xe00]
   81cd6:	62 e1 fd 48 6f 54 24 39                         	vmovdqa64 zmm18,ZMMWORD PTR [rsp+0xe40]
   81cde:	62 e1 fd 48 6f 4c 24 3a                         	vmovdqa64 zmm17,ZMMWORD PTR [rsp+0xe80]
   81ce6:	62 61 fd 48 6f 74 24 3b                         	vmovdqa64 zmm30,ZMMWORD PTR [rsp+0xec0]
   81cee:	62 e1 fd 48 6f 7c 24 3c                         	vmovdqa64 zmm23,ZMMWORD PTR [rsp+0xf00]
   81cf6:	62 e1 fd 48 6f 44 24 0e                         	vmovdqa64 zmm16,ZMMWORD PTR [rsp+0x380]
   81cfe:	62 62 fd 48 59 3d 38 4f f8 ff                   	vpbroadcastq zmm31,QWORD PTR [rip+0xfffffffffff84f38]        # 6c40 <GCC_except_table711+0x150>
   81d08:	62 61 fd 48 6f 44 24 13                         	vmovdqa64 zmm24,ZMMWORD PTR [rsp+0x4c0]
   81d10:	62 e1 fd 48 6f 74 24 0b                         	vmovdqa64 zmm22,ZMMWORD PTR [rsp+0x2c0]
   81d18:	62 e1 fd 48 6f 6c 24 09                         	vmovdqa64 zmm21,ZMMWORD PTR [rsp+0x240]
   81d20:	62 e1 fd 48 6f 64 24 0a                         	vmovdqa64 zmm20,ZMMWORD PTR [rsp+0x280]
   81d28:	62 61 fd 48 6f 4c 24 08                         	vmovdqa64 zmm25,ZMMWORD PTR [rsp+0x200]
   81d30:	44 8b 54 24 74                                  	mov    r10d,DWORD PTR [rsp+0x74]
   81d35:	44 8b 4c 24 78                                  	mov    r9d,DWORD PTR [rsp+0x78]
   81d3a:	8b 7c 24 7c                                     	mov    edi,DWORD PTR [rsp+0x7c]
   81d3e:	48 8b 94 24 30 03 00 00                         	mov    rdx,QWORD PTR [rsp+0x330]
   81d46:	48 8b b4 24 38 03 00 00                         	mov    rsi,QWORD PTR [rsp+0x338]
   81d4e:	4c 8b 9c 24 c0 03 00 00                         	mov    r11,QWORD PTR [rsp+0x3c0]
   81d56:	4c 8b 84 24 40 04 00 00                         	mov    r8,QWORD PTR [rsp+0x440]
   81d5e:	e9 dd ea ff ff                                  	jmp    80840 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x1360>
   81d63:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
   81d68:	45 31 db                                        	xor    r11d,r11d
   81d6b:	49 c7 40 28 00 00 00 00                         	mov    QWORD PTR [r8+0x28],0x0
   81d73:	4d 39 ea                                        	cmp    r10,r13
   81d76:	41 0f b6 40 32                                  	movzx  eax,BYTE PTR [r8+0x32]
   81d7b:	0f 94 c1                                        	sete   cl
   81d7e:	84 c1                                           	test   cl,al
   81d80:	74 6b                                           	je     81ded <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x290d>
   81d82:	48 8d bc 24 80 00 00 00                         	lea    rdi,[rsp+0x80]
   81d8a:	48 8d b4 24 c0 0b 00 00                         	lea    rsi,[rsp+0xbc0]
   81d92:	4c 89 db                                        	mov    rbx,r11
   81d95:	c5 f8 77                                        	vzeroupper
   81d98:	e8 83 1e 01 00                                  	call   93c20 <_RNvMs3_NtCsHW5vo2gROj_10zopro_core4simdNtB5_7FqBatch15inverse_nonzero>
   81d9d:	62 71 fd 48 6f 54 24 02                         	vmovdqa64 zmm10,ZMMWORD PTR [rsp+0x80]
   81da5:	62 71 fd 48 6f 5c 24 03                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0xc0]
   81dad:	62 71 fd 48 6f 6c 24 04                         	vmovdqa64 zmm13,ZMMWORD PTR [rsp+0x100]
   81db5:	62 71 fd 48 6f 74 24 05                         	vmovdqa64 zmm14,ZMMWORD PTR [rsp+0x140]
   81dbd:	62 71 fd 48 6f 64 24 06                         	vmovdqa64 zmm12,ZMMWORD PTR [rsp+0x180]
   81dc5:	4c 8b 8c 24 40 05 00 00                         	mov    r9,QWORD PTR [rsp+0x540]
   81dcd:	49 ba 63 c2 e5 9c c8 60 00 00                   	movabs r10,0x60c89ce5c263
   81dd7:	48 89 da                                        	mov    rdx,rbx
   81dda:	4c 8b 44 24 18                                  	mov    r8,QWORD PTR [rsp+0x18]
   81ddf:	48 85 d2                                        	test   rdx,rdx
   81de2:	0f 85 c9 22 00 00                               	jne    840b1 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x4bd1>
   81de8:	e9 bb 3c 00 00                                  	jmp    85aa8 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x65c8>
   81ded:	c5 fc 28 05 eb 59 f8 ff                         	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffff859eb]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   81df5:	48 b9 31 e1 72 4e 64 30 00 00                   	movabs rcx,0x30644e72e131
   81dff:	62 f1 bd 50 d4 25 0f 4f f8 ff                   	vpaddq zmm4,zmm24,QWORD BCST [rip+0xfffffffffff84f0f]        # 6d18 <GCC_except_table711+0x228>
   81e09:	62 f2 fd 48 59 35 2d 4e f8 ff                   	vpbroadcastq zmm6,QWORD PTR [rip+0xfffffffffff84e2d]        # 6c40 <GCC_except_table711+0x150>
   81e13:	c5 fc 11 84 24 80 00 00 00                      	vmovups YMMWORD PTR [rsp+0x80],ymm0
   81e1c:	48 89 8c 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rcx
   81e24:	62 f1 d5 48 72 e4 34                            	vpsraq zmm5,zmm4,0x34
   81e2b:	62 f1 cd 50 fb 44 24 11                         	vpsubq zmm0,zmm22,QWORD BCST [rsp+0x88]
   81e33:	62 f1 d5 50 fb 4c 24 12                         	vpsubq zmm1,zmm21,QWORD BCST [rsp+0x90]
   81e3b:	62 f1 dd 50 fb 54 24 13                         	vpsubq zmm2,zmm20,QWORD BCST [rsp+0x98]
   81e43:	62 f1 b5 50 fb 5c 24 14                         	vpsubq zmm3,zmm25,QWORD BCST [rsp+0xa0]
   81e4b:	62 f1 fd 48 d4 c5                               	vpaddq zmm0,zmm0,zmm5
   81e51:	62 f1 d5 48 72 e0 34                            	vpsraq zmm5,zmm0,0x34
   81e58:	62 f1 f5 48 d4 cd                               	vpaddq zmm1,zmm1,zmm5
   81e5e:	62 f1 d5 48 72 e1 34                            	vpsraq zmm5,zmm1,0x34
   81e65:	62 f1 ed 48 d4 d5                               	vpaddq zmm2,zmm2,zmm5
   81e6b:	62 f1 d5 48 72 e2 34                            	vpsraq zmm5,zmm2,0x34
   81e72:	62 f1 e5 48 d4 dd                               	vpaddq zmm3,zmm3,zmm5
   81e78:	62 f3 e5 58 1e 0d 15 4e f8 ff 01                	vpcmpltuq k1,zmm3,QWORD BCST [rip+0xfffffffffff84e15]        # 6c98 <GCC_except_table711+0x1a8>
   81e83:	62 e1 fd 49 db f6                               	vpandq zmm22{k1},zmm0,zmm6
   81e89:	62 e1 f5 49 db ee                               	vpandq zmm21{k1},zmm1,zmm6
   81e8f:	62 e1 ed 49 db e6                               	vpandq zmm20{k1},zmm2,zmm6
   81e95:	62 61 dd 49 db c6                               	vpandq zmm24{k1},zmm4,zmm6
   81e9b:	62 61 fd 49 6f cb                               	vmovdqa64 zmm25{k1},zmm3
   81ea1:	62 f1 fd 48 6f 35 15 56 f8 ff                   	vmovdqa64 zmm6,ZMMWORD PTR [rip+0xfffffffffff85615]        # 74c0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x520>
   81eab:	62 b1 f5 48 73 d6 0c                            	vpsrlq zmm1,zmm22,0xc
   81eb2:	62 b1 ed 48 73 f5 28                            	vpsllq zmm2,zmm21,0x28
   81eb9:	62 b1 dd 48 73 d5 18                            	vpsrlq zmm4,zmm21,0x18
   81ec0:	62 b1 e5 48 73 f4 1c                            	vpsllq zmm3,zmm20,0x1c
   81ec7:	62 b1 fd 48 73 f6 34                            	vpsllq zmm0,zmm22,0x34
   81ece:	62 f1 ed 48 eb c9                               	vporq  zmm1,zmm2,zmm1
   81ed4:	62 f1 e5 48 eb d4                               	vporq  zmm2,zmm3,zmm4
   81eda:	62 b1 e5 48 73 d4 24                            	vpsrlq zmm3,zmm20,0x24
   81ee1:	62 91 dd 48 73 f1 10                            	vpsllq zmm4,zmm25,0x10
   81ee8:	62 91 fd 48 eb c0                               	vporq  zmm0,zmm0,zmm24
   81eee:	62 f1 dd 48 eb db                               	vporq  zmm3,zmm4,zmm3
   81ef4:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   81efa:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   81f00:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   81f06:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   81f0c:	62 f1 fd 48 6f 1d 6a 55 f8 ff                   	vmovdqa64 zmm3,ZMMWORD PTR [rip+0xfffffffffff8556a]        # 7480 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4e0>
   81f16:	62 f1 fd 48 6f ec                               	vmovdqa64 zmm5,zmm4
   81f1c:	62 f2 cd 48 7e e1                               	vpermt2q zmm4,zmm6,zmm1
   81f22:	62 f2 e5 48 7e e9                               	vpermt2q zmm5,zmm3,zmm1
   81f28:	62 f2 fd 48 76 da                               	vpermi2q zmm3,zmm0,zmm2
   81f2e:	62 f2 cd 48 7e c2                               	vpermt2q zmm0,zmm6,zmm2
   81f34:	62 f3 d5 48 3a cb 01                            	vinserti64x4 zmm1,zmm5,ymm3,0x1
   81f3b:	62 f3 d5 48 43 d3 ee                            	vshufi64x2 zmm2,zmm5,zmm3,0xee
   81f42:	62 f3 dd 48 3a d8 01                            	vinserti64x4 zmm3,zmm4,ymm0,0x1
   81f49:	62 f3 dd 48 43 c0 ee                            	vshufi64x2 zmm0,zmm4,zmm0,0xee
   81f50:	62 f1 fe 48 7f 4c 24 2b                         	vmovdqu64 ZMMWORD PTR [rsp+0xac0],zmm1
   81f58:	62 f1 fe 48 7f 54 24 2c                         	vmovdqu64 ZMMWORD PTR [rsp+0xb00],zmm2
   81f60:	62 f1 fe 48 7f 5c 24 2d                         	vmovdqu64 ZMMWORD PTR [rsp+0xb40],zmm3
   81f68:	62 f1 fe 48 7f 44 24 2e                         	vmovdqu64 ZMMWORD PTR [rsp+0xb80],zmm0
   81f70:	4d 39 ea                                        	cmp    r10,r13
   81f73:	75 38                                           	jne    81fad <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x2acd>
   81f75:	0f b6 d0                                        	movzx  edx,al
   81f78:	48 8d bc 24 80 00 00 00                         	lea    rdi,[rsp+0x80]
   81f80:	48 8d b4 24 c0 0a 00 00                         	lea    rsi,[rsp+0xac0]
   81f88:	4c 89 db                                        	mov    rbx,r11
   81f8b:	c5 f8 77                                        	vzeroupper
   81f8e:	e8 dd 37 01 00                                  	call   95770 <_RNvNtCsHW5vo2gROj_10zopro_core3msm12invert_lanes>
   81f93:	4c 8b 8c 24 40 05 00 00                         	mov    r9,QWORD PTR [rsp+0x540]
   81f9b:	48 89 da                                        	mov    rdx,rbx
   81f9e:	49 ba 63 c2 e5 9c c8 60 00 00                   	movabs r10,0x60c89ce5c263
   81fa8:	e9 4e 20 00 00                                  	jmp    83ffb <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x4b1b>
   81fad:	48 89 5c 24 68                                  	mov    QWORD PTR [rsp+0x68],rbx
   81fb2:	48 c1 e3 07                                     	shl    rbx,0x7
   81fb6:	48 8d 44 13 08                                  	lea    rax,[rbx+rdx*1+0x8]
   81fbb:	e9 41 0c 00 00                                  	jmp    82c01 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x3721>
   81fc0:	c5 fe 6f 41 20                                  	vmovdqu ymm0,YMMWORD PTR [rcx+0x20]
   81fc5:	c5 fe 6f 0d 13 59 f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff85913]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   81fcd:	31 c0                                           	xor    eax,eax
   81fcf:	45 31 d2                                        	xor    r10d,r10d
   81fd2:	45 31 c9                                        	xor    r9d,r9d
   81fd5:	31 d2                                           	xor    edx,edx
   81fd7:	4c 8d 74 24 40                                  	lea    r14,[rsp+0x40]
   81fdc:	4c 8d bc 24 80 00 00 00                         	lea    r15,[rsp+0x80]
   81fe4:	49 89 dc                                        	mov    r12,rbx
   81fe7:	c5 fe 7f 44 24 40                               	vmovdqu YMMWORD PTR [rsp+0x40],ymm0
   81fed:	c5 fd 7f 8c 24 80 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0x80],ymm1
   81ff6:	4d 2b 16                                        	sub    r10,QWORD PTR [r14]
   81ff9:	4d 1b 4e 08                                     	sbb    r9,QWORD PTR [r14+0x8]
   81ffd:	49 1b 56 10                                     	sbb    rdx,QWORD PTR [r14+0x10]
   82001:	49 1b 46 18                                     	sbb    rax,QWORD PTR [r14+0x18]
   82005:	48 19 db                                        	sbb    rbx,rbx
   82008:	49 8b 0f                                        	mov    rcx,QWORD PTR [r15]
   8200b:	49 8b 77 08                                     	mov    rsi,QWORD PTR [r15+0x8]
   8200f:	4d 8b 47 10                                     	mov    r8,QWORD PTR [r15+0x10]
   82013:	4d 8b 5f 18                                     	mov    r11,QWORD PTR [r15+0x18]
   82017:	48 21 d9                                        	and    rcx,rbx
   8201a:	48 21 de                                        	and    rsi,rbx
   8201d:	49 21 d8                                        	and    r8,rbx
   82020:	49 21 db                                        	and    r11,rbx
   82023:	49 01 ca                                        	add    r10,rcx
   82026:	49 11 f1                                        	adc    r9,rsi
   82029:	4c 11 c2                                        	adc    rdx,r8
   8202c:	4c 11 d8                                        	adc    rax,r11
   8202f:	4c 89 e3                                        	mov    rbx,r12
   82032:	4c 89 94 24 40 03 00 00                         	mov    QWORD PTR [rsp+0x340],r10
   8203a:	4c 89 8c 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],r9
   82042:	48 89 94 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],rdx
   8204a:	48 89 84 24 00 02 00 00                         	mov    QWORD PTR [rsp+0x200],rax
   82052:	4c 8b 9c 24 00 07 00 00                         	mov    r11,QWORD PTR [rsp+0x700]
   8205a:	4c 8b 84 24 80 04 00 00                         	mov    r8,QWORD PTR [rsp+0x480]
   82062:	48 8b b4 24 00 05 00 00                         	mov    rsi,QWORD PTR [rsp+0x500]
   8206a:	4c 8b 64 24 10                                  	mov    r12,QWORD PTR [rsp+0x10]
   8206f:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   82075:	49 39 fc                                        	cmp    r12,rdi
   82078:	0f 86 0d 3d 00 00                               	jbe    85d8b <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x68ab>
   8207e:	4c 8b b4 24 40 05 00 00                         	mov    r14,QWORD PTR [rsp+0x540]
   82086:	48 c1 e7 06                                     	shl    rdi,0x6
   8208a:	c5 fe 6f 0d 4e 58 f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff8584e]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   82092:	48 89 9c 24 80 09 00 00                         	mov    QWORD PTR [rsp+0x980],rbx
   8209a:	49 89 f2                                        	mov    r10,rsi
   8209d:	4d 89 c4                                        	mov    r12,r8
   820a0:	49 89 df                                        	mov    r15,rbx
   820a3:	4c 8d 6c 24 40                                  	lea    r13,[rsp+0x40]
   820a8:	c4 c1 7c 10 44 3e 20                            	vmovups ymm0,YMMWORD PTR [r14+rdi*1+0x20]
   820af:	49 8b 0c 3e                                     	mov    rcx,QWORD PTR [r14+rdi*1]
   820b3:	49 8b 44 3e 08                                  	mov    rax,QWORD PTR [r14+rdi*1+0x8]
   820b8:	4d 8b 4c 3e 10                                  	mov    r9,QWORD PTR [r14+rdi*1+0x10]
   820bd:	49 8b 54 3e 18                                  	mov    rdx,QWORD PTR [r14+rdi*1+0x18]
   820c2:	c5 fd 7f 8c 24 80 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0x80],ymm1
   820cb:	48 89 4c 24 40                                  	mov    QWORD PTR [rsp+0x40],rcx
   820d0:	48 89 44 24 48                                  	mov    QWORD PTR [rsp+0x48],rax
   820d5:	48 89 84 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],rax
   820dd:	4c 89 4c 24 50                                  	mov    QWORD PTR [rsp+0x50],r9
   820e2:	4c 89 8c 24 40 06 00 00                         	mov    QWORD PTR [rsp+0x640],r9
   820ea:	48 89 8c 24 c0 06 00 00                         	mov    QWORD PTR [rsp+0x6c0],rcx
   820f2:	48 89 94 24 00 06 00 00                         	mov    QWORD PTR [rsp+0x600],rdx
   820fa:	48 89 54 24 58                                  	mov    QWORD PTR [rsp+0x58],rdx
   820ff:	4c 89 d8                                        	mov    rax,r11
   82102:	4c 8d 4c 24 40                                  	lea    r9,[rsp+0x40]
   82107:	48 8d 94 24 80 00 00 00                         	lea    rdx,[rsp+0x80]
   8210f:	c5 fc 29 84 24 e0 05 00 00                      	vmovaps YMMWORD PTR [rsp+0x5e0],ymm0
   82118:	4d 2b 11                                        	sub    r10,QWORD PTR [r9]
   8211b:	4d 1b 61 08                                     	sbb    r12,QWORD PTR [r9+0x8]
   8211f:	49 1b 41 10                                     	sbb    rax,QWORD PTR [r9+0x10]
   82123:	4d 1b 79 18                                     	sbb    r15,QWORD PTR [r9+0x18]
   82127:	48 19 db                                        	sbb    rbx,rbx
   8212a:	48 8b 0a                                        	mov    rcx,QWORD PTR [rdx]
   8212d:	48 8b 72 08                                     	mov    rsi,QWORD PTR [rdx+0x8]
   82131:	4c 8b 42 10                                     	mov    r8,QWORD PTR [rdx+0x10]
   82135:	4c 8b 5a 18                                     	mov    r11,QWORD PTR [rdx+0x18]
   82139:	48 21 d9                                        	and    rcx,rbx
   8213c:	48 21 de                                        	and    rsi,rbx
   8213f:	49 21 d8                                        	and    r8,rbx
   82142:	49 21 db                                        	and    r11,rbx
   82145:	49 01 ca                                        	add    r10,rcx
   82148:	49 11 f4                                        	adc    r12,rsi
   8214b:	4c 11 c0                                        	adc    rax,r8
   8214e:	4d 11 df                                        	adc    r15,r11
   82151:	4c 89 a4 24 00 04 00 00                         	mov    QWORD PTR [rsp+0x400],r12
   82159:	4c 89 94 24 c0 04 00 00                         	mov    QWORD PTR [rsp+0x4c0],r10
   82161:	48 89 84 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],rax
   82169:	4c 89 bc 24 80 03 00 00                         	mov    QWORD PTR [rsp+0x380],r15
   82171:	c5 fd 7f 8c 24 80 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0x80],ymm1
   8217a:	4c 8d a4 24 80 00 00 00                         	lea    r12,[rsp+0x80]
   82182:	c4 c1 7c 10 44 3e 20                            	vmovups ymm0,YMMWORD PTR [r14+rdi*1+0x20]
   82189:	48 8b 9c 24 00 02 00 00                         	mov    rbx,QWORD PTR [rsp+0x200]
   82191:	4c 8b b4 24 80 02 00 00                         	mov    r14,QWORD PTR [rsp+0x280]
   82199:	4c 8b 94 24 40 02 00 00                         	mov    r10,QWORD PTR [rsp+0x240]
   821a1:	48 8b 84 24 40 03 00 00                         	mov    rax,QWORD PTR [rsp+0x340]
   821a9:	c5 fc 29 44 24 40                               	vmovaps YMMWORD PTR [rsp+0x40],ymm0
   821af:	49 2b 01                                        	sub    rax,QWORD PTR [r9]
   821b2:	4d 1b 51 08                                     	sbb    r10,QWORD PTR [r9+0x8]
   821b6:	4d 1b 71 10                                     	sbb    r14,QWORD PTR [r9+0x10]
   821ba:	49 1b 59 18                                     	sbb    rbx,QWORD PTR [r9+0x18]
   821be:	4d 19 db                                        	sbb    r11,r11
   821c1:	48 8b 0a                                        	mov    rcx,QWORD PTR [rdx]
   821c4:	48 8b 72 08                                     	mov    rsi,QWORD PTR [rdx+0x8]
   821c8:	48 8b 7a 10                                     	mov    rdi,QWORD PTR [rdx+0x10]
   821cc:	4c 8b 42 18                                     	mov    r8,QWORD PTR [rdx+0x18]
   821d0:	4c 21 d9                                        	and    rcx,r11
   821d3:	4c 21 de                                        	and    rsi,r11
   821d6:	4c 21 df                                        	and    rdi,r11
   821d9:	4d 21 d8                                        	and    r8,r11
   821dc:	48 01 c8                                        	add    rax,rcx
   821df:	49 11 f2                                        	adc    r10,rsi
   821e2:	49 11 fe                                        	adc    r14,rdi
   821e5:	4c 11 c3                                        	adc    rbx,r8
   821e8:	48 89 84 24 00 03 00 00                         	mov    QWORD PTR [rsp+0x300],rax
   821f0:	4c 89 94 24 08 03 00 00                         	mov    QWORD PTR [rsp+0x308],r10
   821f8:	4c 89 b4 24 10 03 00 00                         	mov    QWORD PTR [rsp+0x310],r14
   82200:	48 89 9c 24 18 03 00 00                         	mov    QWORD PTR [rsp+0x318],rbx
   82208:	c5 fd 7f 8c 24 80 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0x80],ymm1
   82211:	4c 8d 9c 24 00 03 00 00                         	lea    r11,[rsp+0x300]
   82219:	48 b8 89 63 86 e4 82 07 d2 87                   	movabs rax,0x87d20782e4866389
   82223:	48 8b bc 24 c0 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x2c0]
   8222b:	83 e7 07                                        	and    edi,0x7
   8222e:	c1 e7 05                                        	shl    edi,0x5
   82231:	c5 fc 10 84 3c c0 0a 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+rdi*1+0xac0]
   8223a:	c5 fc 29 44 24 40                               	vmovaps YMMWORD PTR [rsp+0x40],ymm0
   82240:	45 31 f6                                        	xor    r14d,r14d
   82243:	45 31 ff                                        	xor    r15d,r15d
   82246:	45 31 d2                                        	xor    r10d,r10d
   82249:	31 c9                                           	xor    ecx,ecx
   8224b:	45 31 c9                                        	xor    r9d,r9d
   8224e:	49 8b 55 00                                     	mov    rdx,QWORD PTR [r13+0x0]
   82252:	31 db                                           	xor    ebx,ebx
   82254:	c4 42 cb f6 03                                  	mulx   r8,rsi,QWORD PTR [r11]
   82259:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   8225f:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   82265:	c4 42 cb f6 43 08                               	mulx   r8,rsi,QWORD PTR [r11+0x8]
   8226b:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   82271:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   82277:	c4 42 cb f6 43 10                               	mulx   r8,rsi,QWORD PTR [r11+0x10]
   8227d:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   82283:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   82289:	c4 42 cb f6 43 18                               	mulx   r8,rsi,QWORD PTR [r11+0x18]
   8228f:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   82295:	f3 4d 0f 38 f6 c8                               	adox   r9,r8
   8229b:	66 4c 0f 38 f6 cb                               	adcx   r9,rbx
   822a1:	4c 89 f2                                        	mov    rdx,r14
   822a4:	48 0f af d0                                     	imul   rdx,rax
   822a8:	31 db                                           	xor    ebx,ebx
   822aa:	c4 42 cb f6 04 24                               	mulx   r8,rsi,QWORD PTR [r12]
   822b0:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   822b6:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   822bc:	c4 42 cb f6 44 24 08                            	mulx   r8,rsi,QWORD PTR [r12+0x8]
   822c3:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   822c9:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   822cf:	c4 42 cb f6 44 24 10                            	mulx   r8,rsi,QWORD PTR [r12+0x10]
   822d6:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   822dc:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   822e2:	c4 42 cb f6 44 24 18                            	mulx   r8,rsi,QWORD PTR [r12+0x18]
   822e9:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   822ef:	f3 4d 0f 38 f6 c8                               	adox   r9,r8
   822f5:	66 4c 0f 38 f6 cb                               	adcx   r9,rbx
   822fb:	49 8b 55 08                                     	mov    rdx,QWORD PTR [r13+0x8]
   822ff:	31 db                                           	xor    ebx,ebx
   82301:	c4 42 cb f6 03                                  	mulx   r8,rsi,QWORD PTR [r11]
   82306:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   8230c:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   82312:	c4 42 cb f6 43 08                               	mulx   r8,rsi,QWORD PTR [r11+0x8]
   82318:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   8231e:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   82324:	c4 42 cb f6 43 10                               	mulx   r8,rsi,QWORD PTR [r11+0x10]
   8232a:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   82330:	f3 4d 0f 38 f6 c8                               	adox   r9,r8
   82336:	c4 42 cb f6 43 18                               	mulx   r8,rsi,QWORD PTR [r11+0x18]
   8233c:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   82342:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   82348:	66 4c 0f 38 f6 f3                               	adcx   r14,rbx
   8234e:	4c 89 fa                                        	mov    rdx,r15
   82351:	48 0f af d0                                     	imul   rdx,rax
   82355:	31 db                                           	xor    ebx,ebx
   82357:	c4 42 cb f6 04 24                               	mulx   r8,rsi,QWORD PTR [r12]
   8235d:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   82363:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   82369:	c4 42 cb f6 44 24 08                            	mulx   r8,rsi,QWORD PTR [r12+0x8]
   82370:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   82376:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   8237c:	c4 42 cb f6 44 24 10                            	mulx   r8,rsi,QWORD PTR [r12+0x10]
   82383:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   82389:	f3 4d 0f 38 f6 c8                               	adox   r9,r8
   8238f:	c4 42 cb f6 44 24 18                            	mulx   r8,rsi,QWORD PTR [r12+0x18]
   82396:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   8239c:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   823a2:	66 4c 0f 38 f6 f3                               	adcx   r14,rbx
   823a8:	49 8b 55 10                                     	mov    rdx,QWORD PTR [r13+0x10]
   823ac:	31 db                                           	xor    ebx,ebx
   823ae:	c4 42 cb f6 03                                  	mulx   r8,rsi,QWORD PTR [r11]
   823b3:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   823b9:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   823bf:	c4 42 cb f6 43 08                               	mulx   r8,rsi,QWORD PTR [r11+0x8]
   823c5:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   823cb:	f3 4d 0f 38 f6 c8                               	adox   r9,r8
   823d1:	c4 42 cb f6 43 10                               	mulx   r8,rsi,QWORD PTR [r11+0x10]
   823d7:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   823dd:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   823e3:	c4 42 cb f6 43 18                               	mulx   r8,rsi,QWORD PTR [r11+0x18]
   823e9:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   823ef:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   823f5:	66 4c 0f 38 f6 fb                               	adcx   r15,rbx
   823fb:	4c 89 d2                                        	mov    rdx,r10
   823fe:	48 0f af d0                                     	imul   rdx,rax
   82402:	31 db                                           	xor    ebx,ebx
   82404:	c4 42 cb f6 04 24                               	mulx   r8,rsi,QWORD PTR [r12]
   8240a:	66 4c 0f 38 f6 d6                               	adcx   r10,rsi
   82410:	f3 49 0f 38 f6 c8                               	adox   rcx,r8
   82416:	c4 42 cb f6 44 24 08                            	mulx   r8,rsi,QWORD PTR [r12+0x8]
   8241d:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   82423:	f3 4d 0f 38 f6 c8                               	adox   r9,r8
   82429:	c4 42 cb f6 44 24 10                            	mulx   r8,rsi,QWORD PTR [r12+0x10]
   82430:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   82436:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   8243c:	c4 42 cb f6 44 24 18                            	mulx   r8,rsi,QWORD PTR [r12+0x18]
   82443:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   82449:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   8244f:	66 4c 0f 38 f6 fb                               	adcx   r15,rbx
   82455:	49 8b 55 18                                     	mov    rdx,QWORD PTR [r13+0x18]
   82459:	31 db                                           	xor    ebx,ebx
   8245b:	c4 42 cb f6 03                                  	mulx   r8,rsi,QWORD PTR [r11]
   82460:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   82466:	f3 4d 0f 38 f6 c8                               	adox   r9,r8
   8246c:	c4 42 cb f6 43 08                               	mulx   r8,rsi,QWORD PTR [r11+0x8]
   82472:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   82478:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   8247e:	c4 42 cb f6 43 10                               	mulx   r8,rsi,QWORD PTR [r11+0x10]
   82484:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   8248a:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   82490:	c4 42 cb f6 43 18                               	mulx   r8,rsi,QWORD PTR [r11+0x18]
   82496:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   8249c:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   824a2:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   824a8:	48 89 ca                                        	mov    rdx,rcx
   824ab:	48 0f af d0                                     	imul   rdx,rax
   824af:	31 db                                           	xor    ebx,ebx
   824b1:	c4 42 cb f6 04 24                               	mulx   r8,rsi,QWORD PTR [r12]
   824b7:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   824bd:	f3 4d 0f 38 f6 c8                               	adox   r9,r8
   824c3:	c4 42 cb f6 44 24 08                            	mulx   r8,rsi,QWORD PTR [r12+0x8]
   824ca:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   824d0:	f3 4d 0f 38 f6 f0                               	adox   r14,r8
   824d6:	c4 42 cb f6 44 24 10                            	mulx   r8,rsi,QWORD PTR [r12+0x10]
   824dd:	66 4c 0f 38 f6 f6                               	adcx   r14,rsi
   824e3:	f3 4d 0f 38 f6 f8                               	adox   r15,r8
   824e9:	c4 42 cb f6 44 24 18                            	mulx   r8,rsi,QWORD PTR [r12+0x18]
   824f0:	66 4c 0f 38 f6 fe                               	adcx   r15,rsi
   824f6:	f3 4d 0f 38 f6 d0                               	adox   r10,r8
   824fc:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   82502:	48 b9 47 fd 7c d8 16 8c 20 3c                   	movabs rcx,0x3c208c16d87cfd47
   8250c:	48 ba 8d ca 71 68 91 6a 81 97                   	movabs rdx,0x97816a916871ca8d
   82516:	4c 89 94 24 c0 08 00 00                         	mov    QWORD PTR [rsp+0x8c0],r10
   8251e:	4c 89 8c 24 80 07 00 00                         	mov    QWORD PTR [rsp+0x780],r9
   82526:	4c 89 b4 24 40 09 00 00                         	mov    QWORD PTR [rsp+0x940],r14
   8252e:	4c 89 bc 24 00 09 00 00                         	mov    QWORD PTR [rsp+0x900],r15
   82536:	c5 fd 7f 8c 24 80 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0x80],ymm1
   8253f:	4c 8d 6c 24 40                                  	lea    r13,[rsp+0x40]
   82544:	49 bb 89 63 86 e4 82 07 d2 87                   	movabs r11,0x87d20782e4866389
   8254e:	49 39 c9                                        	cmp    r9,rcx
   82551:	48 b9 73 35 8e 97 6e 95 7e 68                   	movabs rcx,0x687e956e978e3573
   8255b:	48 8b b4 24 00 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x400]
   82563:	c5 fc 10 84 3c c0 0a 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+rdi*1+0xac0]
   8256c:	4c 8d 8c 24 80 00 00 00                         	lea    r9,[rsp+0x80]
   82574:	49 8d 04 0e                                     	lea    rax,[r14+rcx*1]
   82578:	48 83 d8 00                                     	sbb    rax,0x0
   8257c:	0f 92 c1                                        	setb   cl
   8257f:	49 39 d6                                        	cmp    r14,rdx
   82582:	48 89 84 24 00 02 00 00                         	mov    QWORD PTR [rsp+0x200],rax
   8258a:	0f 92 c2                                        	setb   dl
   8258d:	08 ca                                           	or     dl,cl
   8258f:	0f b6 ca                                        	movzx  ecx,dl
   82592:	48 ba a3 a7 7e 7e 49 ba af 47                   	movabs rdx,0x47afba497e7ea7a3
   8259c:	4c 01 fa                                        	add    rdx,r15
   8259f:	48 29 ca                                        	sub    rdx,rcx
   825a2:	c5 fc 29 84 24 00 03 00 00                      	vmovaps YMMWORD PTR [rsp+0x300],ymm0
   825ab:	48 89 94 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],rdx
   825b3:	48 ba 5d 58 81 81 b6 45 50 b8                   	movabs rdx,0xb85045b68181585d
   825bd:	0f 92 c1                                        	setb   cl
   825c0:	49 39 d7                                        	cmp    r15,rdx
   825c3:	0f 92 c2                                        	setb   dl
   825c6:	08 ca                                           	or     dl,cl
   825c8:	0f b6 ca                                        	movzx  ecx,dl
   825cb:	48 ba d7 5f ce 1e 8d b1 9b cf                   	movabs rdx,0xcf9bb18d1ece5fd7
   825d5:	49 8d 04 12                                     	lea    rax,[r10+rdx*1]
   825d9:	4c 8d 94 24 00 03 00 00                         	lea    r10,[rsp+0x300]
   825e1:	48 29 c8                                        	sub    rax,rcx
   825e4:	48 8b 8c 24 c0 04 00 00                         	mov    rcx,QWORD PTR [rsp+0x4c0]
   825ec:	48 89 84 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],rax
   825f4:	0f 92 84 24 40 08 00 00                         	setb   BYTE PTR [rsp+0x840]
   825fc:	48 89 4c 24 40                                  	mov    QWORD PTR [rsp+0x40],rcx
   82601:	48 8b 8c 24 c0 03 00 00                         	mov    rcx,QWORD PTR [rsp+0x3c0]
   82609:	48 89 74 24 48                                  	mov    QWORD PTR [rsp+0x48],rsi
   8260e:	48 89 4c 24 50                                  	mov    QWORD PTR [rsp+0x50],rcx
   82613:	48 8b 8c 24 80 03 00 00                         	mov    rcx,QWORD PTR [rsp+0x380]
   8261b:	48 89 4c 24 58                                  	mov    QWORD PTR [rsp+0x58],rcx
   82620:	31 c9                                           	xor    ecx,ecx
   82622:	31 f6                                           	xor    esi,esi
   82624:	45 31 c0                                        	xor    r8d,r8d
   82627:	31 db                                           	xor    ebx,ebx
   82629:	31 c0                                           	xor    eax,eax
   8262b:	49 8b 55 00                                     	mov    rdx,QWORD PTR [r13+0x0]
   8262f:	45 31 ff                                        	xor    r15d,r15d
   82632:	c4 42 8b f6 22                                  	mulx   r12,r14,QWORD PTR [r10]
   82637:	66 49 0f 38 f6 ce                               	adcx   rcx,r14
   8263d:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   82643:	c4 42 8b f6 62 08                               	mulx   r12,r14,QWORD PTR [r10+0x8]
   82649:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   8264f:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   82655:	c4 42 8b f6 62 10                               	mulx   r12,r14,QWORD PTR [r10+0x10]
   8265b:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   82661:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   82667:	c4 42 8b f6 62 18                               	mulx   r12,r14,QWORD PTR [r10+0x18]
   8266d:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   82673:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   82679:	66 49 0f 38 f6 c7                               	adcx   rax,r15
   8267f:	48 89 ca                                        	mov    rdx,rcx
   82682:	49 0f af d3                                     	imul   rdx,r11
   82686:	45 31 ff                                        	xor    r15d,r15d
   82689:	c4 42 8b f6 21                                  	mulx   r12,r14,QWORD PTR [r9]
   8268e:	66 49 0f 38 f6 ce                               	adcx   rcx,r14
   82694:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   8269a:	c4 42 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [r9+0x8]
   826a0:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   826a6:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   826ac:	c4 42 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [r9+0x10]
   826b2:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   826b8:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   826be:	c4 42 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [r9+0x18]
   826c4:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   826ca:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   826d0:	66 49 0f 38 f6 c7                               	adcx   rax,r15
   826d6:	49 8b 55 08                                     	mov    rdx,QWORD PTR [r13+0x8]
   826da:	45 31 ff                                        	xor    r15d,r15d
   826dd:	c4 42 8b f6 22                                  	mulx   r12,r14,QWORD PTR [r10]
   826e2:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   826e8:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   826ee:	c4 42 8b f6 62 08                               	mulx   r12,r14,QWORD PTR [r10+0x8]
   826f4:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   826fa:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   82700:	c4 42 8b f6 62 10                               	mulx   r12,r14,QWORD PTR [r10+0x10]
   82706:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   8270c:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   82712:	c4 42 8b f6 62 18                               	mulx   r12,r14,QWORD PTR [r10+0x18]
   82718:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   8271e:	f3 49 0f 38 f6 cc                               	adox   rcx,r12
   82724:	66 49 0f 38 f6 cf                               	adcx   rcx,r15
   8272a:	48 89 f2                                        	mov    rdx,rsi
   8272d:	49 0f af d3                                     	imul   rdx,r11
   82731:	45 31 ff                                        	xor    r15d,r15d
   82734:	c4 42 8b f6 21                                  	mulx   r12,r14,QWORD PTR [r9]
   82739:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   8273f:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   82745:	c4 42 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [r9+0x8]
   8274b:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   82751:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   82757:	c4 42 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [r9+0x10]
   8275d:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   82763:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   82769:	c4 42 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [r9+0x18]
   8276f:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   82775:	f3 49 0f 38 f6 cc                               	adox   rcx,r12
   8277b:	66 49 0f 38 f6 cf                               	adcx   rcx,r15
   82781:	49 8b 55 10                                     	mov    rdx,QWORD PTR [r13+0x10]
   82785:	45 31 ff                                        	xor    r15d,r15d
   82788:	c4 42 8b f6 22                                  	mulx   r12,r14,QWORD PTR [r10]
   8278d:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   82793:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   82799:	c4 42 8b f6 62 08                               	mulx   r12,r14,QWORD PTR [r10+0x8]
   8279f:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   827a5:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   827ab:	c4 42 8b f6 62 10                               	mulx   r12,r14,QWORD PTR [r10+0x10]
   827b1:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   827b7:	f3 49 0f 38 f6 cc                               	adox   rcx,r12
   827bd:	c4 42 8b f6 62 18                               	mulx   r12,r14,QWORD PTR [r10+0x18]
   827c3:	66 49 0f 38 f6 ce                               	adcx   rcx,r14
   827c9:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   827cf:	66 49 0f 38 f6 f7                               	adcx   rsi,r15
   827d5:	4c 89 c2                                        	mov    rdx,r8
   827d8:	49 0f af d3                                     	imul   rdx,r11
   827dc:	45 31 ff                                        	xor    r15d,r15d
   827df:	c4 42 8b f6 21                                  	mulx   r12,r14,QWORD PTR [r9]
   827e4:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   827ea:	f3 49 0f 38 f6 dc                               	adox   rbx,r12
   827f0:	c4 42 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [r9+0x8]
   827f6:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   827fc:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   82802:	c4 42 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [r9+0x10]
   82808:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   8280e:	f3 49 0f 38 f6 cc                               	adox   rcx,r12
   82814:	c4 42 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [r9+0x18]
   8281a:	66 49 0f 38 f6 ce                               	adcx   rcx,r14
   82820:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   82826:	66 49 0f 38 f6 f7                               	adcx   rsi,r15
   8282c:	49 8b 55 18                                     	mov    rdx,QWORD PTR [r13+0x18]
   82830:	45 31 ff                                        	xor    r15d,r15d
   82833:	c4 42 8b f6 22                                  	mulx   r12,r14,QWORD PTR [r10]
   82838:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   8283e:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   82844:	c4 42 8b f6 62 08                               	mulx   r12,r14,QWORD PTR [r10+0x8]
   8284a:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   82850:	f3 49 0f 38 f6 cc                               	adox   rcx,r12
   82856:	c4 42 8b f6 62 10                               	mulx   r12,r14,QWORD PTR [r10+0x10]
   8285c:	66 49 0f 38 f6 ce                               	adcx   rcx,r14
   82862:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   82868:	c4 42 8b f6 62 18                               	mulx   r12,r14,QWORD PTR [r10+0x18]
   8286e:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   82874:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   8287a:	66 4d 0f 38 f6 c7                               	adcx   r8,r15
   82880:	48 89 da                                        	mov    rdx,rbx
   82883:	49 0f af d3                                     	imul   rdx,r11
   82887:	45 31 ff                                        	xor    r15d,r15d
   8288a:	c4 42 8b f6 21                                  	mulx   r12,r14,QWORD PTR [r9]
   8288f:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   82895:	f3 49 0f 38 f6 c4                               	adox   rax,r12
   8289b:	c4 42 8b f6 61 08                               	mulx   r12,r14,QWORD PTR [r9+0x8]
   828a1:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   828a7:	f3 49 0f 38 f6 cc                               	adox   rcx,r12
   828ad:	c4 42 8b f6 61 10                               	mulx   r12,r14,QWORD PTR [r9+0x10]
   828b3:	66 49 0f 38 f6 ce                               	adcx   rcx,r14
   828b9:	f3 49 0f 38 f6 f4                               	adox   rsi,r12
   828bf:	c4 42 8b f6 61 18                               	mulx   r12,r14,QWORD PTR [r9+0x18]
   828c5:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   828cb:	f3 4d 0f 38 f6 c4                               	adox   r8,r12
   828d1:	66 4d 0f 38 f6 c7                               	adcx   r8,r15
   828d7:	48 ba 47 fd 7c d8 16 8c 20 3c                   	movabs rdx,0x3c208c16d87cfd47
   828e1:	48 89 b4 24 00 08 00 00                         	mov    QWORD PTR [rsp+0x800],rsi
   828e9:	48 89 84 24 80 08 00 00                         	mov    QWORD PTR [rsp+0x880],rax
   828f1:	4c 89 84 24 40 03 00 00                         	mov    QWORD PTR [rsp+0x340],r8
   828f9:	49 89 ca                                        	mov    r10,rcx
   828fc:	49 b9 29 a0 31 e1 72 4e 64 30                   	movabs r9,0x30644e72e131a029
   82906:	c5 fd 7f 8c 24 80 00 00 00                      	vmovdqa YMMWORD PTR [rsp+0x80],ymm1
   8290f:	48 39 d0                                        	cmp    rax,rdx
   82912:	48 b8 73 35 8e 97 6e 95 7e 68                   	movabs rax,0x687e956e978e3573
   8291c:	4c 8b 9c 24 00 08 00 00                         	mov    r11,QWORD PTR [rsp+0x800]
   82924:	4c 8b 84 24 40 03 00 00                         	mov    r8,QWORD PTR [rsp+0x340]
   8292c:	48 8d 14 01                                     	lea    rdx,[rcx+rax*1]
   82930:	48 b8 8d ca 71 68 91 6a 81 97                   	movabs rax,0x97816a916871ca8d
   8293a:	48 83 da 00                                     	sbb    rdx,0x0
   8293e:	0f 92 c3                                        	setb   bl
   82941:	48 39 c1                                        	cmp    rcx,rax
   82944:	48 b8 a3 a7 7e 7e 49 ba af 47                   	movabs rax,0x47afba497e7ea7a3
   8294e:	48 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs rcx,0xcf9bb18d1ece5fd7
   82958:	41 0f 92 c6                                     	setb   r14b
   8295c:	41 08 de                                        	or     r14b,bl
   8295f:	4d 8d 24 08                                     	lea    r12,[r8+rcx*1]
   82963:	48 8b 8c 24 00 02 00 00                         	mov    rcx,QWORD PTR [rsp+0x200]
   8296b:	41 0f b6 de                                     	movzx  ebx,r14b
   8296f:	4d 8d 34 03                                     	lea    r14,[r11+rax*1]
   82973:	48 b8 5d 58 81 81 b6 45 50 b8                   	movabs rax,0xb85045b68181585d
   8297d:	49 29 de                                        	sub    r14,rbx
   82980:	0f 92 c3                                        	setb   bl
   82983:	49 39 c3                                        	cmp    r11,rax
   82986:	48 8b 84 24 c0 08 00 00                         	mov    rax,QWORD PTR [rsp+0x8c0]
   8298e:	41 0f 92 c7                                     	setb   r15b
   82992:	41 08 df                                        	or     r15b,bl
   82995:	41 0f b6 df                                     	movzx  ebx,r15b
   82999:	49 29 dc                                        	sub    r12,rbx
   8299c:	0f 92 c3                                        	setb   bl
   8299f:	4d 39 c8                                        	cmp    r8,r9
   829a2:	4c 8b 84 24 40 02 00 00                         	mov    r8,QWORD PTR [rsp+0x240]
   829aa:	41 0f 92 c7                                     	setb   r15b
   829ae:	41 08 df                                        	or     r15b,bl
   829b1:	4c 39 c8                                        	cmp    rax,r9
   829b4:	4c 8b 8c 24 80 07 00 00                         	mov    r9,QWORD PTR [rsp+0x780]
   829bc:	0f 92 c3                                        	setb   bl
   829bf:	0a 9c 24 40 08 00 00                            	or     bl,BYTE PTR [rsp+0x840]
   829c6:	48 bb b9 02 83 27 e9 73 df c3                   	movabs rbx,0xc3df73e9278302b9
   829d0:	48 0f 45 8c 24 40 09 00 00                      	cmovne rcx,QWORD PTR [rsp+0x940]
   829d9:	4d 8d 2c 19                                     	lea    r13,[r9+rbx*1]
   829dd:	4c 0f 45 c0                                     	cmovne r8,rax
   829e1:	4d 0f 45 e9                                     	cmovne r13,r9
   829e5:	4c 8b 8c 24 80 02 00 00                         	mov    r9,QWORD PTR [rsp+0x280]
   829ed:	4c 89 84 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],r8
   829f5:	4c 8b 84 24 80 06 00 00                         	mov    r8,QWORD PTR [rsp+0x680]
   829fd:	4c 0f 45 8c 24 00 09 00 00                      	cmovne r9,QWORD PTR [rsp+0x900]
   82a06:	45 84 ff                                        	test   r15b,r15b
   82a09:	4c 89 ac 24 80 07 00 00                         	mov    QWORD PTR [rsp+0x780],r13
   82a11:	4c 8b ac 24 40 06 00 00                         	mov    r13,QWORD PTR [rsp+0x640]
   82a19:	49 0f 45 d2                                     	cmovne rdx,r10
   82a1d:	4c 8b 94 24 00 05 00 00                         	mov    r10,QWORD PTR [rsp+0x500]
   82a25:	4c 0f 45 a4 24 40 03 00 00                      	cmovne r12,QWORD PTR [rsp+0x340]
   82a2e:	4d 0f 45 f3                                     	cmovne r14,r11
   82a32:	4c 8b 9c 24 80 04 00 00                         	mov    r11,QWORD PTR [rsp+0x480]
   82a3a:	48 89 8c 24 00 02 00 00                         	mov    QWORD PTR [rsp+0x200],rcx
   82a42:	48 8b 8c 24 80 08 00 00                         	mov    rcx,QWORD PTR [rsp+0x880]
   82a4a:	4c 89 8c 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],r9
   82a52:	4c 8b 8c 24 00 06 00 00                         	mov    r9,QWORD PTR [rsp+0x600]
   82a5a:	4c 89 54 24 40                                  	mov    QWORD PTR [rsp+0x40],r10
   82a5f:	4c 8b 94 24 00 07 00 00                         	mov    r10,QWORD PTR [rsp+0x700]
   82a67:	4c 89 5c 24 48                                  	mov    QWORD PTR [rsp+0x48],r11
   82a6c:	4d 89 eb                                        	mov    r11,r13
   82a6f:	48 8d 04 19                                     	lea    rax,[rcx+rbx*1]
   82a73:	4c 89 c3                                        	mov    rbx,r8
   82a76:	48 0f 45 c1                                     	cmovne rax,rcx
   82a7a:	48 89 84 3c c0 0a 00 00                         	mov    QWORD PTR [rsp+rdi*1+0xac0],rax
   82a82:	48 8b 84 24 80 09 00 00                         	mov    rax,QWORD PTR [rsp+0x980]
   82a8a:	48 89 94 3c c8 0a 00 00                         	mov    QWORD PTR [rsp+rdi*1+0xac8],rdx
   82a92:	4c 89 b4 3c d0 0a 00 00                         	mov    QWORD PTR [rsp+rdi*1+0xad0],r14
   82a9a:	4c 89 a4 3c d8 0a 00 00                         	mov    QWORD PTR [rsp+rdi*1+0xad8],r12
   82aa2:	48 8b bc 24 c0 06 00 00                         	mov    rdi,QWORD PTR [rsp+0x6c0]
   82aaa:	4d 89 cc                                        	mov    r12,r9
   82aad:	4c 8d b4 24 80 00 00 00                         	lea    r14,[rsp+0x80]
   82ab5:	4c 89 54 24 50                                  	mov    QWORD PTR [rsp+0x50],r10
   82aba:	4c 8d 54 24 40                                  	lea    r10,[rsp+0x40]
   82abf:	48 89 44 24 58                                  	mov    QWORD PTR [rsp+0x58],rax
   82ac4:	49 89 ff                                        	mov    r15,rdi
   82ac7:	4d 03 3a                                        	add    r15,QWORD PTR [r10]
   82aca:	49 13 5a 08                                     	adc    rbx,QWORD PTR [r10+0x8]
   82ace:	4d 13 6a 10                                     	adc    r13,QWORD PTR [r10+0x10]
   82ad2:	4d 13 62 18                                     	adc    r12,QWORD PTR [r10+0x18]
   82ad6:	4c 89 f8                                        	mov    rax,r15
   82ad9:	48 89 d9                                        	mov    rcx,rbx
   82adc:	4c 89 ea                                        	mov    rdx,r13
   82adf:	4c 89 e6                                        	mov    rsi,r12
   82ae2:	49 2b 06                                        	sub    rax,QWORD PTR [r14]
   82ae5:	49 1b 4e 08                                     	sbb    rcx,QWORD PTR [r14+0x8]
   82ae9:	49 1b 56 10                                     	sbb    rdx,QWORD PTR [r14+0x10]
   82aed:	49 1b 76 18                                     	sbb    rsi,QWORD PTR [r14+0x18]
   82af1:	4c 0f 43 f8                                     	cmovae r15,rax
   82af5:	48 0f 43 d9                                     	cmovae rbx,rcx
   82af9:	4c 0f 43 ea                                     	cmovae r13,rdx
   82afd:	4c 0f 43 e6                                     	cmovae r12,rsi
   82b01:	48 8b 94 24 40 04 00 00                         	mov    rdx,QWORD PTR [rsp+0x440]
   82b09:	4c 8b 72 28                                     	mov    r14,QWORD PTR [rdx+0x28]
   82b0d:	4c 3b 72 18                                     	cmp    r14,QWORD PTR [rdx+0x18]
   82b11:	0f 84 73 01 00 00                               	je     82c8a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x37aa>
   82b17:	48 8b 4a 20                                     	mov    rcx,QWORD PTR [rdx+0x20]
   82b1b:	4b 8d 04 b6                                     	lea    rax,[r14+r14*4]
   82b1f:	48 8b b4 24 c0 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x4c0]
   82b27:	4c 8b 94 24 c0 02 00 00                         	mov    r10,QWORD PTR [rsp+0x2c0]
   82b2f:	49 ff c6                                        	inc    r14
   82b32:	48 c1 e0 05                                     	shl    rax,0x5
   82b36:	48 89 3c 01                                     	mov    QWORD PTR [rcx+rax*1],rdi
   82b3a:	4c 89 44 01 08                                  	mov    QWORD PTR [rcx+rax*1+0x8],r8
   82b3f:	4c 89 5c 01 10                                  	mov    QWORD PTR [rcx+rax*1+0x10],r11
   82b44:	4c 89 4c 01 18                                  	mov    QWORD PTR [rcx+rax*1+0x18],r9
   82b49:	48 8b bc 24 00 04 00 00                         	mov    rdi,QWORD PTR [rsp+0x400]
   82b51:	4c 8b 84 24 c0 03 00 00                         	mov    r8,QWORD PTR [rsp+0x3c0]
   82b59:	49 ff c2                                        	inc    r10
   82b5c:	c5 fd 6f 84 24 e0 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x5e0]
   82b65:	c5 fe 7f 44 01 20                               	vmovdqu YMMWORD PTR [rcx+rax*1+0x20],ymm0
   82b6b:	4c 89 7c 01 40                                  	mov    QWORD PTR [rcx+rax*1+0x40],r15
   82b70:	48 89 5c 01 48                                  	mov    QWORD PTR [rcx+rax*1+0x48],rbx
   82b75:	4c 89 6c 01 50                                  	mov    QWORD PTR [rcx+rax*1+0x50],r13
   82b7a:	4c 89 64 01 58                                  	mov    QWORD PTR [rcx+rax*1+0x58],r12
   82b7f:	48 89 74 01 60                                  	mov    QWORD PTR [rcx+rax*1+0x60],rsi
   82b84:	48 89 7c 01 68                                  	mov    QWORD PTR [rcx+rax*1+0x68],rdi
   82b89:	48 8b bc 24 80 03 00 00                         	mov    rdi,QWORD PTR [rsp+0x380]
   82b91:	4c 89 44 01 70                                  	mov    QWORD PTR [rcx+rax*1+0x70],r8
   82b96:	4c 8b 84 24 80 07 00 00                         	mov    r8,QWORD PTR [rsp+0x780]
   82b9e:	48 8b 9c 24 80 05 00 00                         	mov    rbx,QWORD PTR [rsp+0x580]
   82ba6:	4c 8b 64 24 10                                  	mov    r12,QWORD PTR [rsp+0x10]
   82bab:	48 89 7c 01 78                                  	mov    QWORD PTR [rcx+rax*1+0x78],rdi
   82bb0:	48 8b bc 24 00 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x200]
   82bb8:	4c 89 84 01 80 00 00 00                         	mov    QWORD PTR [rcx+rax*1+0x80],r8
   82bc0:	4c 8b 84 24 80 02 00 00                         	mov    r8,QWORD PTR [rsp+0x280]
   82bc8:	48 89 bc 01 88 00 00 00                         	mov    QWORD PTR [rcx+rax*1+0x88],rdi
   82bd0:	48 8b bc 24 40 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x240]
   82bd8:	4c 89 84 01 90 00 00 00                         	mov    QWORD PTR [rcx+rax*1+0x90],r8
   82be0:	48 89 bc 01 98 00 00 00                         	mov    QWORD PTR [rcx+rax*1+0x98],rdi
   82be8:	48 8b 84 24 c0 07 00 00                         	mov    rax,QWORD PTR [rsp+0x7c0]
   82bf0:	4c 89 72 28                                     	mov    QWORD PTR [rdx+0x28],r14
   82bf4:	48 83 c0 10                                     	add    rax,0x10
   82bf8:	49 39 da                                        	cmp    r10,rbx
   82bfb:	0f 83 c2 00 00 00                               	jae    82cc3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x37e3>
   82c01:	48 8b 08                                        	mov    rcx,QWORD PTR [rax]
   82c04:	8b 78 f8                                        	mov    edi,DWORD PTR [rax-0x8]
   82c07:	4c 89 94 24 c0 02 00 00                         	mov    QWORD PTR [rsp+0x2c0],r10
   82c0f:	48 89 84 24 c0 07 00 00                         	mov    QWORD PTR [rsp+0x7c0],rax
   82c17:	48 8b 31                                        	mov    rsi,QWORD PTR [rcx]
   82c1a:	4c 8b 41 08                                     	mov    r8,QWORD PTR [rcx+0x8]
   82c1e:	4c 8b 59 10                                     	mov    r11,QWORD PTR [rcx+0x10]
   82c22:	48 8b 59 18                                     	mov    rbx,QWORD PTR [rcx+0x18]
   82c26:	48 89 b4 24 00 05 00 00                         	mov    QWORD PTR [rsp+0x500],rsi
   82c2e:	4c 89 84 24 80 04 00 00                         	mov    QWORD PTR [rsp+0x480],r8
   82c36:	4c 89 9c 24 00 07 00 00                         	mov    QWORD PTR [rsp+0x700],r11
   82c3e:	85 ff                                           	test   edi,edi
   82c40:	0f 88 7a f3 ff ff                               	js     81fc0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x2ae0>
   82c46:	48 8b 41 38                                     	mov    rax,QWORD PTR [rcx+0x38]
   82c4a:	4c 8b 49 30                                     	mov    r9,QWORD PTR [rcx+0x30]
   82c4e:	48 8b 51 28                                     	mov    rdx,QWORD PTR [rcx+0x28]
   82c52:	48 8b 49 20                                     	mov    rcx,QWORD PTR [rcx+0x20]
   82c56:	48 89 84 24 00 02 00 00                         	mov    QWORD PTR [rsp+0x200],rax
   82c5e:	4c 89 8c 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],r9
   82c66:	48 89 94 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],rdx
   82c6e:	48 89 8c 24 40 03 00 00                         	mov    QWORD PTR [rsp+0x340],rcx
   82c76:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   82c7c:	49 39 fc                                        	cmp    r12,rdi
   82c7f:	0f 87 f9 f3 ff ff                               	ja     8207e <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x2b9e>
   82c85:	e9 01 31 00 00                                  	jmp    85d8b <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x68ab>
   82c8a:	48 8d 7a 18                                     	lea    rdi,[rdx+0x18]
   82c8e:	c5 f8 77                                        	vzeroupper
   82c91:	e8 8a 3a 01 00                                  	call   96720 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecAINtNtCsgHCcee0nhgM_11zopro_bn2542fp2FpNtBR_8FqConfigEj5_E8grow_oneCsHW5vo2gROj_10zopro_core>
   82c96:	4c 8b 8c 24 00 06 00 00                         	mov    r9,QWORD PTR [rsp+0x600]
   82c9e:	4c 8b 9c 24 40 06 00 00                         	mov    r11,QWORD PTR [rsp+0x640]
   82ca6:	4c 8b 84 24 80 06 00 00                         	mov    r8,QWORD PTR [rsp+0x680]
   82cae:	48 8b bc 24 c0 06 00 00                         	mov    rdi,QWORD PTR [rsp+0x6c0]
   82cb6:	48 8b 94 24 40 04 00 00                         	mov    rdx,QWORD PTR [rsp+0x440]
   82cbe:	e9 54 fe ff ff                                  	jmp    82b17 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x3637>
   82cc3:	0f b6 52 32                                     	movzx  edx,BYTE PTR [rdx+0x32]
   82cc7:	48 8d bc 24 80 00 00 00                         	lea    rdi,[rsp+0x80]
   82ccf:	48 8d b4 24 c0 0a 00 00                         	lea    rsi,[rsp+0xac0]
   82cd7:	c5 f8 77                                        	vzeroupper
   82cda:	e8 91 2a 01 00                                  	call   95770 <_RNvNtCsHW5vo2gROj_10zopro_core3msm12invert_lanes>
   82cdf:	48 8b 4c 24 18                                  	mov    rcx,QWORD PTR [rsp+0x18]
   82ce4:	48 89 d8                                        	mov    rax,rbx
   82ce7:	48 c1 e0 04                                     	shl    rax,0x4
   82ceb:	c5 fe 6f 15 ed 4b f8 ff                         	vmovdqu ymm2,YMMWORD PTR [rip+0xfffffffffff84bed]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   82cf3:	4c 8b a4 24 40 04 00 00                         	mov    r12,QWORD PTR [rsp+0x440]
   82cfb:	48 8d 53 ff                                     	lea    rdx,[rbx-0x1]
   82cff:	4c 8d 54 08 f0                                  	lea    r10,[rax+rcx*1-0x10]
   82d04:	48 8b 4c 24 68                                  	mov    rcx,QWORD PTR [rsp+0x68]
   82d09:	48 8d 04 cd 00 00 00 00                         	lea    rax,[rcx*8+0x0]
   82d11:	48 c1 e1 08                                     	shl    rcx,0x8
   82d15:	48 f7 d8                                        	neg    rax
   82d18:	48 89 84 24 c0 07 00 00                         	mov    QWORD PTR [rsp+0x7c0],rax
   82d20:	48 89 d8                                        	mov    rax,rbx
   82d23:	48 c1 e0 05                                     	shl    rax,0x5
   82d27:	4c 8d 04 80                                     	lea    r8,[rax+rax*4]
   82d2b:	48 8d 04 89                                     	lea    rax,[rcx+rcx*4]
   82d2f:	48 89 d1                                        	mov    rcx,rdx
   82d32:	49 29 c0                                        	sub    r8,rax
   82d35:	48 8b 84 24 40 07 00 00                         	mov    rax,QWORD PTR [rsp+0x740]
   82d3d:	49 81 c0 68 ff ff ff                            	add    r8,0xffffffffffffff68
   82d44:	48 f7 d8                                        	neg    rax
   82d47:	48 8d 44 03 ff                                  	lea    rax,[rbx+rax*1-0x1]
   82d4c:	48 c1 e0 05                                     	shl    rax,0x5
   82d50:	48 8d 14 80                                     	lea    rdx,[rax+rax*4]
   82d54:	66 66 66 2e 0f 1f 84 00 00 00 00 00             	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   82d60:	48 8b 84 24 c0 07 00 00                         	mov    rax,QWORD PTR [rsp+0x7c0]
   82d68:	49 8b 74 24 28                                  	mov    rsi,QWORD PTR [r12+0x28]
   82d6d:	4c 89 94 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],r10
   82d75:	48 01 c8                                        	add    rax,rcx
   82d78:	48 39 f0                                        	cmp    rax,rsi
   82d7b:	0f 83 47 30 00 00                               	jae    85dc8 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x68e8>
   82d81:	49 8b 44 24 20                                  	mov    rax,QWORD PTR [r12+0x20]
   82d86:	48 89 94 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],rdx
   82d8e:	89 ce                                           	mov    esi,ecx
   82d90:	83 e6 07                                        	and    esi,0x7
   82d93:	4c 89 84 24 c0 06 00 00                         	mov    QWORD PTR [rsp+0x6c0],r8
   82d9b:	48 89 8c 24 c0 04 00 00                         	mov    QWORD PTR [rsp+0x4c0],rcx
   82da3:	4c 8d 9c 24 c0 01 00 00                         	lea    r11,[rsp+0x1c0]
   82dab:	4c 8d 74 24 20                                  	lea    r14,[rsp+0x20]
   82db0:	4c 8d bc 24 e0 01 00 00                         	lea    r15,[rsp+0x1e0]
   82db8:	49 bc 89 63 86 e4 82 07 d2 87                   	movabs r12,0x87d20782e4866389
   82dc2:	c1 e6 05                                        	shl    esi,0x5
   82dc5:	c5 fc 10 8c 34 80 00 00 00                      	vmovups ymm1,YMMWORD PTR [rsp+rsi*1+0x80]
   82dce:	48 8b 14 10                                     	mov    rdx,QWORD PTR [rax+rdx*1]
   82dd2:	c4 a1 7c 10 44 00 18                            	vmovups ymm0,YMMWORD PTR [rax+r8*1+0x18]
   82dd9:	48 89 94 24 80 03 00 00                         	mov    QWORD PTR [rsp+0x380],rdx
   82de1:	4a 8b 14 00                                     	mov    rdx,QWORD PTR [rax+r8*1]
   82de5:	48 89 94 24 00 04 00 00                         	mov    QWORD PTR [rsp+0x400],rdx
   82ded:	4a 8b 54 00 08                                  	mov    rdx,QWORD PTR [rax+r8*1+0x8]
   82df2:	48 89 94 24 40 03 00 00                         	mov    QWORD PTR [rsp+0x340],rdx
   82dfa:	4a 8b 54 00 10                                  	mov    rdx,QWORD PTR [rax+r8*1+0x10]
   82dff:	c5 fc 29 84 24 a0 0a 00 00                      	vmovaps YMMWORD PTR [rsp+0xaa0],ymm0
   82e08:	c4 a1 7c 10 44 00 38                            	vmovups ymm0,YMMWORD PTR [rax+r8*1+0x38]
   82e0f:	48 89 94 24 00 05 00 00                         	mov    QWORD PTR [rsp+0x500],rdx
   82e17:	c5 fc 29 84 24 e0 05 00 00                      	vmovaps YMMWORD PTR [rsp+0x5e0],ymm0
   82e20:	c4 a1 7c 10 44 00 58                            	vmovups ymm0,YMMWORD PTR [rax+r8*1+0x58]
   82e27:	c5 fc 29 84 24 00 03 00 00                      	vmovaps YMMWORD PTR [rsp+0x300],ymm0
   82e30:	c4 a1 7c 10 44 00 78                            	vmovups ymm0,YMMWORD PTR [rax+r8*1+0x78]
   82e37:	c5 fc 29 4c 24 20                               	vmovaps YMMWORD PTR [rsp+0x20],ymm1
   82e3d:	c5 fd 7f 94 24 e0 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm2
   82e46:	c5 fc 29 44 24 40                               	vmovaps YMMWORD PTR [rsp+0x40],ymm0
   82e4c:	c5 fc 29 84 24 c0 01 00 00                      	vmovaps YMMWORD PTR [rsp+0x1c0],ymm0
   82e55:	45 31 d2                                        	xor    r10d,r10d
   82e58:	45 31 c9                                        	xor    r9d,r9d
   82e5b:	45 31 ed                                        	xor    r13d,r13d
   82e5e:	31 c0                                           	xor    eax,eax
   82e60:	31 db                                           	xor    ebx,ebx
   82e62:	49 8b 16                                        	mov    rdx,QWORD PTR [r14]
   82e65:	45 31 c0                                        	xor    r8d,r8d
   82e68:	c4 c2 f3 f6 3b                                  	mulx   rdi,rcx,QWORD PTR [r11]
   82e6d:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   82e73:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   82e79:	c4 c2 f3 f6 7b 08                               	mulx   rdi,rcx,QWORD PTR [r11+0x8]
   82e7f:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   82e85:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   82e8b:	c4 c2 f3 f6 7b 10                               	mulx   rdi,rcx,QWORD PTR [r11+0x10]
   82e91:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   82e97:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   82e9d:	c4 c2 f3 f6 7b 18                               	mulx   rdi,rcx,QWORD PTR [r11+0x18]
   82ea3:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   82ea9:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   82eaf:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   82eb5:	4c 89 d2                                        	mov    rdx,r10
   82eb8:	49 0f af d4                                     	imul   rdx,r12
   82ebc:	45 31 c0                                        	xor    r8d,r8d
   82ebf:	c4 c2 f3 f6 3f                                  	mulx   rdi,rcx,QWORD PTR [r15]
   82ec4:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   82eca:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   82ed0:	c4 c2 f3 f6 7f 08                               	mulx   rdi,rcx,QWORD PTR [r15+0x8]
   82ed6:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   82edc:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   82ee2:	c4 c2 f3 f6 7f 10                               	mulx   rdi,rcx,QWORD PTR [r15+0x10]
   82ee8:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   82eee:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   82ef4:	c4 c2 f3 f6 7f 18                               	mulx   rdi,rcx,QWORD PTR [r15+0x18]
   82efa:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   82f00:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   82f06:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   82f0c:	49 8b 56 08                                     	mov    rdx,QWORD PTR [r14+0x8]
   82f10:	45 31 c0                                        	xor    r8d,r8d
   82f13:	c4 c2 f3 f6 3b                                  	mulx   rdi,rcx,QWORD PTR [r11]
   82f18:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   82f1e:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   82f24:	c4 c2 f3 f6 7b 08                               	mulx   rdi,rcx,QWORD PTR [r11+0x8]
   82f2a:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   82f30:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   82f36:	c4 c2 f3 f6 7b 10                               	mulx   rdi,rcx,QWORD PTR [r11+0x10]
   82f3c:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   82f42:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   82f48:	c4 c2 f3 f6 7b 18                               	mulx   rdi,rcx,QWORD PTR [r11+0x18]
   82f4e:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   82f54:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   82f5a:	66 4d 0f 38 f6 d0                               	adcx   r10,r8
   82f60:	4c 89 ca                                        	mov    rdx,r9
   82f63:	49 0f af d4                                     	imul   rdx,r12
   82f67:	45 31 c0                                        	xor    r8d,r8d
   82f6a:	c4 c2 f3 f6 3f                                  	mulx   rdi,rcx,QWORD PTR [r15]
   82f6f:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   82f75:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   82f7b:	c4 c2 f3 f6 7f 08                               	mulx   rdi,rcx,QWORD PTR [r15+0x8]
   82f81:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   82f87:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   82f8d:	c4 c2 f3 f6 7f 10                               	mulx   rdi,rcx,QWORD PTR [r15+0x10]
   82f93:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   82f99:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   82f9f:	c4 c2 f3 f6 7f 18                               	mulx   rdi,rcx,QWORD PTR [r15+0x18]
   82fa5:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   82fab:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   82fb1:	66 4d 0f 38 f6 d0                               	adcx   r10,r8
   82fb7:	49 8b 56 10                                     	mov    rdx,QWORD PTR [r14+0x10]
   82fbb:	45 31 c0                                        	xor    r8d,r8d
   82fbe:	c4 c2 f3 f6 3b                                  	mulx   rdi,rcx,QWORD PTR [r11]
   82fc3:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   82fc9:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   82fcf:	c4 c2 f3 f6 7b 08                               	mulx   rdi,rcx,QWORD PTR [r11+0x8]
   82fd5:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   82fdb:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   82fe1:	c4 c2 f3 f6 7b 10                               	mulx   rdi,rcx,QWORD PTR [r11+0x10]
   82fe7:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   82fed:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   82ff3:	c4 c2 f3 f6 7b 18                               	mulx   rdi,rcx,QWORD PTR [r11+0x18]
   82ff9:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   82fff:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   83005:	66 4d 0f 38 f6 c8                               	adcx   r9,r8
   8300b:	4c 89 ea                                        	mov    rdx,r13
   8300e:	49 0f af d4                                     	imul   rdx,r12
   83012:	45 31 c0                                        	xor    r8d,r8d
   83015:	c4 c2 f3 f6 3f                                  	mulx   rdi,rcx,QWORD PTR [r15]
   8301a:	66 4c 0f 38 f6 e9                               	adcx   r13,rcx
   83020:	f3 48 0f 38 f6 c7                               	adox   rax,rdi
   83026:	c4 c2 f3 f6 7f 08                               	mulx   rdi,rcx,QWORD PTR [r15+0x8]
   8302c:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   83032:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   83038:	c4 c2 f3 f6 7f 10                               	mulx   rdi,rcx,QWORD PTR [r15+0x10]
   8303e:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   83044:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   8304a:	c4 c2 f3 f6 7f 18                               	mulx   rdi,rcx,QWORD PTR [r15+0x18]
   83050:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   83056:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   8305c:	66 4d 0f 38 f6 c8                               	adcx   r9,r8
   83062:	49 8b 56 18                                     	mov    rdx,QWORD PTR [r14+0x18]
   83066:	45 31 c0                                        	xor    r8d,r8d
   83069:	c4 c2 f3 f6 3b                                  	mulx   rdi,rcx,QWORD PTR [r11]
   8306e:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   83074:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   8307a:	c4 c2 f3 f6 7b 08                               	mulx   rdi,rcx,QWORD PTR [r11+0x8]
   83080:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   83086:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   8308c:	c4 c2 f3 f6 7b 10                               	mulx   rdi,rcx,QWORD PTR [r11+0x10]
   83092:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   83098:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   8309e:	c4 c2 f3 f6 7b 18                               	mulx   rdi,rcx,QWORD PTR [r11+0x18]
   830a4:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   830aa:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   830b0:	66 4d 0f 38 f6 e8                               	adcx   r13,r8
   830b6:	48 89 c2                                        	mov    rdx,rax
   830b9:	49 0f af d4                                     	imul   rdx,r12
   830bd:	45 31 c0                                        	xor    r8d,r8d
   830c0:	c4 c2 f3 f6 3f                                  	mulx   rdi,rcx,QWORD PTR [r15]
   830c5:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   830cb:	f3 48 0f 38 f6 df                               	adox   rbx,rdi
   830d1:	c4 c2 f3 f6 7f 08                               	mulx   rdi,rcx,QWORD PTR [r15+0x8]
   830d7:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   830dd:	f3 4c 0f 38 f6 d7                               	adox   r10,rdi
   830e3:	c4 c2 f3 f6 7f 10                               	mulx   rdi,rcx,QWORD PTR [r15+0x10]
   830e9:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   830ef:	f3 4c 0f 38 f6 cf                               	adox   r9,rdi
   830f5:	c4 c2 f3 f6 7f 18                               	mulx   rdi,rcx,QWORD PTR [r15+0x18]
   830fb:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   83101:	f3 4c 0f 38 f6 ef                               	adox   r13,rdi
   83107:	66 4d 0f 38 f6 e8                               	adcx   r13,r8
   8310d:	48 b8 73 35 8e 97 6e 95 7e 68                   	movabs rax,0x687e956e978e3573
   83117:	4c 89 8c 24 40 06 00 00                         	mov    QWORD PTR [rsp+0x640],r9
   8311f:	4c 89 ac 24 00 07 00 00                         	mov    QWORD PTR [rsp+0x700],r13
   83127:	48 89 9c 24 00 02 00 00                         	mov    QWORD PTR [rsp+0x200],rbx
   8312f:	4c 89 94 24 00 06 00 00                         	mov    QWORD PTR [rsp+0x600],r10
   83137:	c5 fd 7f 94 24 e0 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm2
   83140:	4c 8d 74 24 20                                  	lea    r14,[rsp+0x20]
   83145:	49 bb 89 63 86 e4 82 07 d2 87                   	movabs r11,0x87d20782e4866389
   8314f:	49 8d 0c 02                                     	lea    rcx,[r10+rax*1]
   83153:	48 b8 47 fd 7c d8 16 8c 20 3c                   	movabs rax,0x3c208c16d87cfd47
   8315d:	c5 fc 10 84 34 80 00 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+rsi*1+0x80]
   83166:	c5 fd 6f 8c 24 00 03 00 00                      	vmovdqa ymm1,YMMWORD PTR [rsp+0x300]
   8316f:	48 39 c3                                        	cmp    rbx,rax
   83172:	48 83 d9 00                                     	sbb    rcx,0x0
   83176:	48 89 8c 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],rcx
   8317e:	48 b9 8d ca 71 68 91 6a 81 97                   	movabs rcx,0x97816a916871ca8d
   83188:	0f 92 c0                                        	setb   al
   8318b:	49 39 ca                                        	cmp    r10,rcx
   8318e:	0f 92 c1                                        	setb   cl
   83191:	08 c1                                           	or     cl,al
   83193:	48 b8 a3 a7 7e 7e 49 ba af 47                   	movabs rax,0x47afba497e7ea7a3
   8319d:	49 8d 14 01                                     	lea    rdx,[r9+rax*1]
   831a1:	0f b6 c1                                        	movzx  eax,cl
   831a4:	48 b9 5d 58 81 81 b6 45 50 b8                   	movabs rcx,0xb85045b68181585d
   831ae:	48 29 c2                                        	sub    rdx,rax
   831b1:	c5 fc 29 84 24 c0 01 00 00                      	vmovaps YMMWORD PTR [rsp+0x1c0],ymm0
   831ba:	c5 fd 7f 4c 24 20                               	vmovdqa YMMWORD PTR [rsp+0x20],ymm1
   831c0:	0f 92 c0                                        	setb   al
   831c3:	49 39 c9                                        	cmp    r9,rcx
   831c6:	49 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs r9,0xcf9bb18d1ece5fd7
   831d0:	48 89 94 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],rdx
   831d8:	0f 92 c1                                        	setb   cl
   831db:	4b 8d 54 0d 00                                  	lea    rdx,[r13+r9*1+0x0]
   831e0:	4c 8d 8c 24 e0 01 00 00                         	lea    r9,[rsp+0x1e0]
   831e8:	4c 8d ac 24 c0 01 00 00                         	lea    r13,[rsp+0x1c0]
   831f0:	08 c1                                           	or     cl,al
   831f2:	0f b6 c1                                        	movzx  eax,cl
   831f5:	48 29 c2                                        	sub    rdx,rax
   831f8:	48 89 94 24 c0 02 00 00                         	mov    QWORD PTR [rsp+0x2c0],rdx
   83200:	0f 92 84 24 80 04 00 00                         	setb   BYTE PTR [rsp+0x480]
   83208:	31 db                                           	xor    ebx,ebx
   8320a:	31 ff                                           	xor    edi,edi
   8320c:	45 31 ff                                        	xor    r15d,r15d
   8320f:	31 c9                                           	xor    ecx,ecx
   83211:	31 c0                                           	xor    eax,eax
   83213:	49 8b 16                                        	mov    rdx,QWORD PTR [r14]
   83216:	45 31 e4                                        	xor    r12d,r12d
   83219:	c4 42 bb f6 55 00                               	mulx   r10,r8,QWORD PTR [r13+0x0]
   8321f:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   83225:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   8322b:	c4 42 bb f6 55 08                               	mulx   r10,r8,QWORD PTR [r13+0x8]
   83231:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   83237:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   8323d:	c4 42 bb f6 55 10                               	mulx   r10,r8,QWORD PTR [r13+0x10]
   83243:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   83249:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   8324f:	c4 42 bb f6 55 18                               	mulx   r10,r8,QWORD PTR [r13+0x18]
   83255:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   8325b:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   83261:	66 49 0f 38 f6 c4                               	adcx   rax,r12
   83267:	48 89 da                                        	mov    rdx,rbx
   8326a:	49 0f af d3                                     	imul   rdx,r11
   8326e:	45 31 e4                                        	xor    r12d,r12d
   83271:	c4 42 bb f6 11                                  	mulx   r10,r8,QWORD PTR [r9]
   83276:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   8327c:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   83282:	c4 42 bb f6 51 08                               	mulx   r10,r8,QWORD PTR [r9+0x8]
   83288:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   8328e:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   83294:	c4 42 bb f6 51 10                               	mulx   r10,r8,QWORD PTR [r9+0x10]
   8329a:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   832a0:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   832a6:	c4 42 bb f6 51 18                               	mulx   r10,r8,QWORD PTR [r9+0x18]
   832ac:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   832b2:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   832b8:	66 49 0f 38 f6 c4                               	adcx   rax,r12
   832be:	49 8b 56 08                                     	mov    rdx,QWORD PTR [r14+0x8]
   832c2:	45 31 e4                                        	xor    r12d,r12d
   832c5:	c4 42 bb f6 55 00                               	mulx   r10,r8,QWORD PTR [r13+0x0]
   832cb:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   832d1:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   832d7:	c4 42 bb f6 55 08                               	mulx   r10,r8,QWORD PTR [r13+0x8]
   832dd:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   832e3:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   832e9:	c4 42 bb f6 55 10                               	mulx   r10,r8,QWORD PTR [r13+0x10]
   832ef:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   832f5:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   832fb:	c4 42 bb f6 55 18                               	mulx   r10,r8,QWORD PTR [r13+0x18]
   83301:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   83307:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   8330d:	66 49 0f 38 f6 dc                               	adcx   rbx,r12
   83313:	48 89 fa                                        	mov    rdx,rdi
   83316:	49 0f af d3                                     	imul   rdx,r11
   8331a:	45 31 e4                                        	xor    r12d,r12d
   8331d:	c4 42 bb f6 11                                  	mulx   r10,r8,QWORD PTR [r9]
   83322:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   83328:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   8332e:	c4 42 bb f6 51 08                               	mulx   r10,r8,QWORD PTR [r9+0x8]
   83334:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   8333a:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   83340:	c4 42 bb f6 51 10                               	mulx   r10,r8,QWORD PTR [r9+0x10]
   83346:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   8334c:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   83352:	c4 42 bb f6 51 18                               	mulx   r10,r8,QWORD PTR [r9+0x18]
   83358:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   8335e:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   83364:	66 49 0f 38 f6 dc                               	adcx   rbx,r12
   8336a:	49 8b 56 10                                     	mov    rdx,QWORD PTR [r14+0x10]
   8336e:	45 31 e4                                        	xor    r12d,r12d
   83371:	c4 42 bb f6 55 00                               	mulx   r10,r8,QWORD PTR [r13+0x0]
   83377:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   8337d:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   83383:	c4 42 bb f6 55 08                               	mulx   r10,r8,QWORD PTR [r13+0x8]
   83389:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   8338f:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   83395:	c4 42 bb f6 55 10                               	mulx   r10,r8,QWORD PTR [r13+0x10]
   8339b:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   833a1:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   833a7:	c4 42 bb f6 55 18                               	mulx   r10,r8,QWORD PTR [r13+0x18]
   833ad:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   833b3:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   833b9:	66 49 0f 38 f6 fc                               	adcx   rdi,r12
   833bf:	4c 89 fa                                        	mov    rdx,r15
   833c2:	49 0f af d3                                     	imul   rdx,r11
   833c6:	45 31 e4                                        	xor    r12d,r12d
   833c9:	c4 42 bb f6 11                                  	mulx   r10,r8,QWORD PTR [r9]
   833ce:	66 4d 0f 38 f6 f8                               	adcx   r15,r8
   833d4:	f3 49 0f 38 f6 ca                               	adox   rcx,r10
   833da:	c4 42 bb f6 51 08                               	mulx   r10,r8,QWORD PTR [r9+0x8]
   833e0:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   833e6:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   833ec:	c4 42 bb f6 51 10                               	mulx   r10,r8,QWORD PTR [r9+0x10]
   833f2:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   833f8:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   833fe:	c4 42 bb f6 51 18                               	mulx   r10,r8,QWORD PTR [r9+0x18]
   83404:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   8340a:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   83410:	66 49 0f 38 f6 fc                               	adcx   rdi,r12
   83416:	49 8b 56 18                                     	mov    rdx,QWORD PTR [r14+0x18]
   8341a:	45 31 e4                                        	xor    r12d,r12d
   8341d:	c4 42 bb f6 55 00                               	mulx   r10,r8,QWORD PTR [r13+0x0]
   83423:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   83429:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   8342f:	c4 42 bb f6 55 08                               	mulx   r10,r8,QWORD PTR [r13+0x8]
   83435:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   8343b:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   83441:	c4 42 bb f6 55 10                               	mulx   r10,r8,QWORD PTR [r13+0x10]
   83447:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   8344d:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   83453:	c4 42 bb f6 55 18                               	mulx   r10,r8,QWORD PTR [r13+0x18]
   83459:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   8345f:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   83465:	66 4d 0f 38 f6 fc                               	adcx   r15,r12
   8346b:	48 89 ca                                        	mov    rdx,rcx
   8346e:	49 0f af d3                                     	imul   rdx,r11
   83472:	45 31 e4                                        	xor    r12d,r12d
   83475:	c4 42 bb f6 11                                  	mulx   r10,r8,QWORD PTR [r9]
   8347a:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   83480:	f3 49 0f 38 f6 c2                               	adox   rax,r10
   83486:	c4 42 bb f6 51 08                               	mulx   r10,r8,QWORD PTR [r9+0x8]
   8348c:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   83492:	f3 49 0f 38 f6 da                               	adox   rbx,r10
   83498:	c4 42 bb f6 51 10                               	mulx   r10,r8,QWORD PTR [r9+0x10]
   8349e:	66 49 0f 38 f6 d8                               	adcx   rbx,r8
   834a4:	f3 49 0f 38 f6 fa                               	adox   rdi,r10
   834aa:	c4 42 bb f6 51 18                               	mulx   r10,r8,QWORD PTR [r9+0x18]
   834b0:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   834b6:	f3 4d 0f 38 f6 fa                               	adox   r15,r10
   834bc:	66 4d 0f 38 f6 fc                               	adcx   r15,r12
   834c2:	48 b9 47 fd 7c d8 16 8c 20 3c                   	movabs rcx,0x3c208c16d87cfd47
   834cc:	49 89 c3                                        	mov    r11,rax
   834cf:	49 b8 8d ca 71 68 91 6a 81 97                   	movabs r8,0x97816a916871ca8d
   834d9:	4c 89 f8                                        	mov    rax,r15
   834dc:	49 89 ff                                        	mov    r15,rdi
   834df:	48 89 df                                        	mov    rdi,rbx
   834e2:	49 b9 29 a0 31 e1 72 4e 64 30                   	movabs r9,0x30644e72e131a029
   834ec:	49 39 cb                                        	cmp    r11,rcx
   834ef:	48 b9 73 35 8e 97 6e 95 7e 68                   	movabs rcx,0x687e956e978e3573
   834f9:	48 8d 14 0b                                     	lea    rdx,[rbx+rcx*1]
   834fd:	48 83 da 00                                     	sbb    rdx,0x0
   83501:	0f 92 c1                                        	setb   cl
   83504:	4c 39 c3                                        	cmp    rbx,r8
   83507:	48 8b 9c 24 00 07 00 00                         	mov    rbx,QWORD PTR [rsp+0x700]
   8350f:	41 0f 92 c0                                     	setb   r8b
   83513:	41 08 c8                                        	or     r8b,cl
   83516:	41 0f b6 c8                                     	movzx  ecx,r8b
   8351a:	49 b8 a3 a7 7e 7e 49 ba af 47                   	movabs r8,0x47afba497e7ea7a3
   83524:	4f 8d 14 07                                     	lea    r10,[r15+r8*1]
   83528:	49 b8 5d 58 81 81 b6 45 50 b8                   	movabs r8,0xb85045b68181585d
   83532:	49 29 ca                                        	sub    r10,rcx
   83535:	0f 92 c1                                        	setb   cl
   83538:	4d 39 c7                                        	cmp    r15,r8
   8353b:	41 0f 92 c0                                     	setb   r8b
   8353f:	41 08 c8                                        	or     r8b,cl
   83542:	48 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs rcx,0xcf9bb18d1ece5fd7
   8354c:	45 0f b6 c0                                     	movzx  r8d,r8b
   83550:	48 01 c1                                        	add    rcx,rax
   83553:	4c 29 c1                                        	sub    rcx,r8
   83556:	41 0f 92 c0                                     	setb   r8b
   8355a:	4c 39 c8                                        	cmp    rax,r9
   8355d:	41 0f 92 c4                                     	setb   r12b
   83561:	4c 39 cb                                        	cmp    rbx,r9
   83564:	41 0f 92 c1                                     	setb   r9b
   83568:	44 0a 8c 24 80 04 00 00                         	or     r9b,BYTE PTR [rsp+0x480]
   83570:	75 2e                                           	jne    835a0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x40c0>
   83572:	48 8b 9c 24 00 02 00 00                         	mov    rbx,QWORD PTR [rsp+0x200]
   8357a:	4c 8b ac 24 40 02 00 00                         	mov    r13,QWORD PTR [rsp+0x240]
   83582:	49 b9 b9 02 83 27 e9 73 df c3                   	movabs r9,0xc3df73e9278302b9
   8358c:	4c 01 cb                                        	add    rbx,r9
   8358f:	45 08 c4                                        	or     r12b,r8b
   83592:	74 3c                                           	je     835d0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x40f0>
   83594:	48 89 fa                                        	mov    rdx,rdi
   83597:	4d 89 fa                                        	mov    r10,r15
   8359a:	48 89 c1                                        	mov    rcx,rax
   8359d:	eb 3e                                           	jmp    835dd <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x40fd>
   8359f:	90                                              	nop
   835a0:	4c 8b 8c 24 00 06 00 00                         	mov    r9,QWORD PTR [rsp+0x600]
   835a8:	49 89 de                                        	mov    r14,rbx
   835ab:	48 8b 9c 24 00 02 00 00                         	mov    rbx,QWORD PTR [rsp+0x200]
   835b3:	4c 8b ac 24 40 06 00 00                         	mov    r13,QWORD PTR [rsp+0x640]
   835bb:	4c 89 b4 24 c0 02 00 00                         	mov    QWORD PTR [rsp+0x2c0],r14
   835c3:	4c 89 8c 24 80 02 00 00                         	mov    QWORD PTR [rsp+0x280],r9
   835cb:	45 08 c4                                        	or     r12b,r8b
   835ce:	75 c4                                           	jne    83594 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x40b4>
   835d0:	48 b8 b9 02 83 27 e9 73 df c3                   	movabs rax,0xc3df73e9278302b9
   835da:	49 01 c3                                        	add    r11,rax
   835dd:	4c 89 9c 34 80 00 00 00                         	mov    QWORD PTR [rsp+rsi*1+0x80],r11
   835e5:	48 89 94 34 88 00 00 00                         	mov    QWORD PTR [rsp+rsi*1+0x88],rdx
   835ed:	4c 89 94 34 90 00 00 00                         	mov    QWORD PTR [rsp+rsi*1+0x90],r10
   835f5:	48 89 8c 34 98 00 00 00                         	mov    QWORD PTR [rsp+rsi*1+0x98],rcx
   835fd:	48 8b 84 24 80 02 00 00                         	mov    rax,QWORD PTR [rsp+0x280]
   83605:	48 8b 8c 24 c0 02 00 00                         	mov    rcx,QWORD PTR [rsp+0x2c0]
   8360d:	48 89 9c 24 c0 01 00 00                         	mov    QWORD PTR [rsp+0x1c0],rbx
   83615:	48 89 5c 24 20                                  	mov    QWORD PTR [rsp+0x20],rbx
   8361a:	48 89 9c 24 00 02 00 00                         	mov    QWORD PTR [rsp+0x200],rbx
   83622:	c5 fd 7f 94 24 e0 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm2
   8362b:	4c 89 ac 24 40 02 00 00                         	mov    QWORD PTR [rsp+0x240],r13
   83633:	4c 8d 9c 24 c0 01 00 00                         	lea    r11,[rsp+0x1c0]
   8363b:	48 8d 5c 24 20                                  	lea    rbx,[rsp+0x20]
   83640:	4c 8d b4 24 e0 01 00 00                         	lea    r14,[rsp+0x1e0]
   83648:	49 bf 89 63 86 e4 82 07 d2 87                   	movabs r15,0x87d20782e4866389
   83652:	48 89 84 24 c8 01 00 00                         	mov    QWORD PTR [rsp+0x1c8],rax
   8365a:	4c 89 ac 24 d0 01 00 00                         	mov    QWORD PTR [rsp+0x1d0],r13
   83662:	48 89 44 24 28                                  	mov    QWORD PTR [rsp+0x28],rax
   83667:	4c 89 6c 24 30                                  	mov    QWORD PTR [rsp+0x30],r13
   8366c:	48 89 8c 24 d8 01 00 00                         	mov    QWORD PTR [rsp+0x1d8],rcx
   83674:	48 89 4c 24 38                                  	mov    QWORD PTR [rsp+0x38],rcx
   83679:	31 ff                                           	xor    edi,edi
   8367b:	31 c9                                           	xor    ecx,ecx
   8367d:	31 c0                                           	xor    eax,eax
   8367f:	31 f6                                           	xor    esi,esi
   83681:	45 31 e4                                        	xor    r12d,r12d
   83684:	49 8b 13                                        	mov    rdx,QWORD PTR [r11]
   83687:	45 31 d2                                        	xor    r10d,r10d
   8368a:	c4 62 bb f6 0b                                  	mulx   r9,r8,QWORD PTR [rbx]
   8368f:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   83695:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   8369b:	c4 62 bb f6 4b 08                               	mulx   r9,r8,QWORD PTR [rbx+0x8]
   836a1:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   836a7:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   836ad:	c4 62 bb f6 4b 10                               	mulx   r9,r8,QWORD PTR [rbx+0x10]
   836b3:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   836b9:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   836bf:	c4 62 bb f6 4b 18                               	mulx   r9,r8,QWORD PTR [rbx+0x18]
   836c5:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   836cb:	f3 4d 0f 38 f6 e1                               	adox   r12,r9
   836d1:	66 4d 0f 38 f6 e2                               	adcx   r12,r10
   836d7:	48 89 fa                                        	mov    rdx,rdi
   836da:	49 0f af d7                                     	imul   rdx,r15
   836de:	45 31 d2                                        	xor    r10d,r10d
   836e1:	c4 42 bb f6 0e                                  	mulx   r9,r8,QWORD PTR [r14]
   836e6:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   836ec:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   836f2:	c4 42 bb f6 4e 08                               	mulx   r9,r8,QWORD PTR [r14+0x8]
   836f8:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   836fe:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   83704:	c4 42 bb f6 4e 10                               	mulx   r9,r8,QWORD PTR [r14+0x10]
   8370a:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   83710:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   83716:	c4 42 bb f6 4e 18                               	mulx   r9,r8,QWORD PTR [r14+0x18]
   8371c:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   83722:	f3 4d 0f 38 f6 e1                               	adox   r12,r9
   83728:	66 4d 0f 38 f6 e2                               	adcx   r12,r10
   8372e:	49 8b 53 08                                     	mov    rdx,QWORD PTR [r11+0x8]
   83732:	45 31 d2                                        	xor    r10d,r10d
   83735:	c4 62 bb f6 0b                                  	mulx   r9,r8,QWORD PTR [rbx]
   8373a:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   83740:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   83746:	c4 62 bb f6 4b 08                               	mulx   r9,r8,QWORD PTR [rbx+0x8]
   8374c:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   83752:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   83758:	c4 62 bb f6 4b 10                               	mulx   r9,r8,QWORD PTR [rbx+0x10]
   8375e:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   83764:	f3 4d 0f 38 f6 e1                               	adox   r12,r9
   8376a:	c4 62 bb f6 4b 18                               	mulx   r9,r8,QWORD PTR [rbx+0x18]
   83770:	66 4d 0f 38 f6 e0                               	adcx   r12,r8
   83776:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   8377c:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   83782:	48 89 ca                                        	mov    rdx,rcx
   83785:	49 0f af d7                                     	imul   rdx,r15
   83789:	45 31 d2                                        	xor    r10d,r10d
   8378c:	c4 42 bb f6 0e                                  	mulx   r9,r8,QWORD PTR [r14]
   83791:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   83797:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   8379d:	c4 42 bb f6 4e 08                               	mulx   r9,r8,QWORD PTR [r14+0x8]
   837a3:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   837a9:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   837af:	c4 42 bb f6 4e 10                               	mulx   r9,r8,QWORD PTR [r14+0x10]
   837b5:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   837bb:	f3 4d 0f 38 f6 e1                               	adox   r12,r9
   837c1:	c4 42 bb f6 4e 18                               	mulx   r9,r8,QWORD PTR [r14+0x18]
   837c7:	66 4d 0f 38 f6 e0                               	adcx   r12,r8
   837cd:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   837d3:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   837d9:	49 8b 53 10                                     	mov    rdx,QWORD PTR [r11+0x10]
   837dd:	45 31 d2                                        	xor    r10d,r10d
   837e0:	c4 62 bb f6 0b                                  	mulx   r9,r8,QWORD PTR [rbx]
   837e5:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   837eb:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   837f1:	c4 62 bb f6 4b 08                               	mulx   r9,r8,QWORD PTR [rbx+0x8]
   837f7:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   837fd:	f3 4d 0f 38 f6 e1                               	adox   r12,r9
   83803:	c4 62 bb f6 4b 10                               	mulx   r9,r8,QWORD PTR [rbx+0x10]
   83809:	66 4d 0f 38 f6 e0                               	adcx   r12,r8
   8380f:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   83815:	c4 62 bb f6 4b 18                               	mulx   r9,r8,QWORD PTR [rbx+0x18]
   8381b:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   83821:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   83827:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   8382d:	48 89 c2                                        	mov    rdx,rax
   83830:	49 0f af d7                                     	imul   rdx,r15
   83834:	45 31 d2                                        	xor    r10d,r10d
   83837:	c4 42 bb f6 0e                                  	mulx   r9,r8,QWORD PTR [r14]
   8383c:	66 49 0f 38 f6 c0                               	adcx   rax,r8
   83842:	f3 49 0f 38 f6 f1                               	adox   rsi,r9
   83848:	c4 42 bb f6 4e 08                               	mulx   r9,r8,QWORD PTR [r14+0x8]
   8384e:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   83854:	f3 4d 0f 38 f6 e1                               	adox   r12,r9
   8385a:	c4 42 bb f6 4e 10                               	mulx   r9,r8,QWORD PTR [r14+0x10]
   83860:	66 4d 0f 38 f6 e0                               	adcx   r12,r8
   83866:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   8386c:	c4 42 bb f6 4e 18                               	mulx   r9,r8,QWORD PTR [r14+0x18]
   83872:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   83878:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   8387e:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   83884:	49 8b 53 18                                     	mov    rdx,QWORD PTR [r11+0x18]
   83888:	45 31 d2                                        	xor    r10d,r10d
   8388b:	c4 62 bb f6 0b                                  	mulx   r9,r8,QWORD PTR [rbx]
   83890:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   83896:	f3 4d 0f 38 f6 e1                               	adox   r12,r9
   8389c:	c4 62 bb f6 4b 08                               	mulx   r9,r8,QWORD PTR [rbx+0x8]
   838a2:	66 4d 0f 38 f6 e0                               	adcx   r12,r8
   838a8:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   838ae:	c4 62 bb f6 4b 10                               	mulx   r9,r8,QWORD PTR [rbx+0x10]
   838b4:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   838ba:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   838c0:	c4 62 bb f6 4b 18                               	mulx   r9,r8,QWORD PTR [rbx+0x18]
   838c6:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   838cc:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   838d2:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   838d8:	48 89 f2                                        	mov    rdx,rsi
   838db:	49 0f af d7                                     	imul   rdx,r15
   838df:	45 31 d2                                        	xor    r10d,r10d
   838e2:	c4 42 bb f6 0e                                  	mulx   r9,r8,QWORD PTR [r14]
   838e7:	66 49 0f 38 f6 f0                               	adcx   rsi,r8
   838ed:	f3 4d 0f 38 f6 e1                               	adox   r12,r9
   838f3:	c4 42 bb f6 4e 08                               	mulx   r9,r8,QWORD PTR [r14+0x8]
   838f9:	66 4d 0f 38 f6 e0                               	adcx   r12,r8
   838ff:	f3 49 0f 38 f6 f9                               	adox   rdi,r9
   83905:	c4 42 bb f6 4e 10                               	mulx   r9,r8,QWORD PTR [r14+0x10]
   8390b:	66 49 0f 38 f6 f8                               	adcx   rdi,r8
   83911:	f3 49 0f 38 f6 c9                               	adox   rcx,r9
   83917:	c4 42 bb f6 4e 18                               	mulx   r9,r8,QWORD PTR [r14+0x18]
   8391d:	66 49 0f 38 f6 c8                               	adcx   rcx,r8
   83923:	f3 49 0f 38 f6 c1                               	adox   rax,r9
   83929:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   8392f:	48 ba 73 35 8e 97 6e 95 7e 68                   	movabs rdx,0x687e956e978e3573
   83939:	49 b8 8d ca 71 68 91 6a 81 97                   	movabs r8,0x97816a916871ca8d
   83943:	48 8d 34 17                                     	lea    rsi,[rdi+rdx*1]
   83947:	48 ba 47 fd 7c d8 16 8c 20 3c                   	movabs rdx,0x3c208c16d87cfd47
   83951:	49 39 d4                                        	cmp    r12,rdx
   83954:	48 83 de 00                                     	sbb    rsi,0x0
   83958:	0f 92 c2                                        	setb   dl
   8395b:	4c 39 c7                                        	cmp    rdi,r8
   8395e:	41 0f 92 c0                                     	setb   r8b
   83962:	41 08 d0                                        	or     r8b,dl
   83965:	48 ba a3 a7 7e 7e 49 ba af 47                   	movabs rdx,0x47afba497e7ea7a3
   8396f:	4c 8d 0c 11                                     	lea    r9,[rcx+rdx*1]
   83973:	41 0f b6 d0                                     	movzx  edx,r8b
   83977:	49 b8 5d 58 81 81 b6 45 50 b8                   	movabs r8,0xb85045b68181585d
   83981:	49 29 d1                                        	sub    r9,rdx
   83984:	0f 92 c2                                        	setb   dl
   83987:	4c 39 c1                                        	cmp    rcx,r8
   8398a:	41 0f 92 c0                                     	setb   r8b
   8398e:	41 08 d0                                        	or     r8b,dl
   83991:	48 ba d7 5f ce 1e 8d b1 9b cf                   	movabs rdx,0xcf9bb18d1ece5fd7
   8399b:	4c 8d 34 10                                     	lea    r14,[rax+rdx*1]
   8399f:	41 0f b6 d0                                     	movzx  edx,r8b
   839a3:	49 b8 29 a0 31 e1 72 4e 64 30                   	movabs r8,0x30644e72e131a029
   839ad:	49 29 d6                                        	sub    r14,rdx
   839b0:	0f 92 c2                                        	setb   dl
   839b3:	4c 39 c0                                        	cmp    rax,r8
   839b6:	41 0f 92 c0                                     	setb   r8b
   839ba:	41 08 d0                                        	or     r8b,dl
   839bd:	75 11                                           	jne    839d0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x44f0>
   839bf:	48 b8 b9 02 83 27 e9 73 df c3                   	movabs rax,0xc3df73e9278302b9
   839c9:	49 01 c4                                        	add    r12,rax
   839cc:	eb 0b                                           	jmp    839d9 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x44f9>
   839ce:	66 90                                           	xchg   ax,ax
   839d0:	48 89 fe                                        	mov    rsi,rdi
   839d3:	49 89 c9                                        	mov    r9,rcx
   839d6:	49 89 c6                                        	mov    r14,rax
   839d9:	c5 fc 28 84 24 e0 05 00 00                      	vmovaps ymm0,YMMWORD PTR [rsp+0x5e0]
   839e2:	c5 fd 7f 94 24 e0 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm2
   839eb:	4c 8b bc 24 80 03 00 00                         	mov    r15,QWORD PTR [rsp+0x380]
   839f3:	48 8b 9c 24 00 04 00 00                         	mov    rbx,QWORD PTR [rsp+0x400]
   839fb:	4c 8b 94 24 40 03 00 00                         	mov    r10,QWORD PTR [rsp+0x340]
   83a03:	4c 8d 6c 24 20                                  	lea    r13,[rsp+0x20]
   83a08:	4c 8d 9c 24 e0 01 00 00                         	lea    r11,[rsp+0x1e0]
   83a10:	c5 fc 29 44 24 20                               	vmovaps YMMWORD PTR [rsp+0x20],ymm0
   83a16:	4d 2b 65 00                                     	sub    r12,QWORD PTR [r13+0x0]
   83a1a:	49 1b 75 08                                     	sbb    rsi,QWORD PTR [r13+0x8]
   83a1e:	4d 1b 4d 10                                     	sbb    r9,QWORD PTR [r13+0x10]
   83a22:	4d 1b 75 18                                     	sbb    r14,QWORD PTR [r13+0x18]
   83a26:	4d 19 c0                                        	sbb    r8,r8
   83a29:	49 8b 03                                        	mov    rax,QWORD PTR [r11]
   83a2c:	49 8b 4b 08                                     	mov    rcx,QWORD PTR [r11+0x8]
   83a30:	49 8b 53 10                                     	mov    rdx,QWORD PTR [r11+0x10]
   83a34:	49 8b 7b 18                                     	mov    rdi,QWORD PTR [r11+0x18]
   83a38:	4c 21 c0                                        	and    rax,r8
   83a3b:	4c 21 c1                                        	and    rcx,r8
   83a3e:	4c 21 c2                                        	and    rdx,r8
   83a41:	4c 21 c7                                        	and    rdi,r8
   83a44:	49 01 c4                                        	add    r12,rax
   83a47:	48 11 ce                                        	adc    rsi,rcx
   83a4a:	49 11 d1                                        	adc    r9,rdx
   83a4d:	49 11 fe                                        	adc    r14,rdi
   83a50:	4c 89 64 24 20                                  	mov    QWORD PTR [rsp+0x20],r12
   83a55:	4c 89 a4 24 80 03 00 00                         	mov    QWORD PTR [rsp+0x380],r12
   83a5d:	48 89 74 24 28                                  	mov    QWORD PTR [rsp+0x28],rsi
   83a62:	48 89 b4 24 00 04 00 00                         	mov    QWORD PTR [rsp+0x400],rsi
   83a6a:	4c 89 4c 24 30                                  	mov    QWORD PTR [rsp+0x30],r9
   83a6f:	4c 89 8c 24 40 03 00 00                         	mov    QWORD PTR [rsp+0x340],r9
   83a77:	4c 89 b4 24 80 04 00 00                         	mov    QWORD PTR [rsp+0x480],r14
   83a7f:	4c 89 74 24 38                                  	mov    QWORD PTR [rsp+0x38],r14
   83a84:	c5 fd 7f 94 24 e0 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm2
   83a8d:	4c 8d ac 24 e0 01 00 00                         	lea    r13,[rsp+0x1e0]
   83a95:	48 8d 74 24 20                                  	lea    rsi,[rsp+0x20]
   83a9a:	49 bc 89 63 86 e4 82 07 d2 87                   	movabs r12,0x87d20782e4866389
   83aa4:	4c 8d 5c 24 20                                  	lea    r11,[rsp+0x20]
   83aa9:	4c 8b 8c 24 00 05 00 00                         	mov    r9,QWORD PTR [rsp+0x500]
   83ab1:	4c 2b 3e                                        	sub    r15,QWORD PTR [rsi]
   83ab4:	48 1b 5e 08                                     	sbb    rbx,QWORD PTR [rsi+0x8]
   83ab8:	4c 1b 56 10                                     	sbb    r10,QWORD PTR [rsi+0x10]
   83abc:	4c 1b 4e 18                                     	sbb    r9,QWORD PTR [rsi+0x18]
   83ac0:	4d 19 c0                                        	sbb    r8,r8
   83ac3:	49 8b 45 00                                     	mov    rax,QWORD PTR [r13+0x0]
   83ac7:	49 8b 4d 08                                     	mov    rcx,QWORD PTR [r13+0x8]
   83acb:	49 8b 55 10                                     	mov    rdx,QWORD PTR [r13+0x10]
   83acf:	49 8b 7d 18                                     	mov    rdi,QWORD PTR [r13+0x18]
   83ad3:	4c 21 c0                                        	and    rax,r8
   83ad6:	4c 21 c1                                        	and    rcx,r8
   83ad9:	4c 21 c2                                        	and    rdx,r8
   83adc:	4c 21 c7                                        	and    rdi,r8
   83adf:	49 01 c7                                        	add    r15,rax
   83ae2:	48 11 cb                                        	adc    rbx,rcx
   83ae5:	49 11 d2                                        	adc    r10,rdx
   83ae8:	49 11 f9                                        	adc    r9,rdi
   83aeb:	4c 89 7c 24 20                                  	mov    QWORD PTR [rsp+0x20],r15
   83af0:	48 89 5c 24 28                                  	mov    QWORD PTR [rsp+0x28],rbx
   83af5:	4c 89 54 24 30                                  	mov    QWORD PTR [rsp+0x30],r10
   83afa:	4c 89 4c 24 38                                  	mov    QWORD PTR [rsp+0x38],r9
   83aff:	c5 fd 7f 94 24 e0 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm2
   83b08:	48 8b 84 24 00 02 00 00                         	mov    rax,QWORD PTR [rsp+0x200]
   83b10:	48 8b 8c 24 80 02 00 00                         	mov    rcx,QWORD PTR [rsp+0x280]
   83b18:	48 8b b4 24 40 02 00 00                         	mov    rsi,QWORD PTR [rsp+0x240]
   83b20:	48 89 84 24 c0 01 00 00                         	mov    QWORD PTR [rsp+0x1c0],rax
   83b28:	48 89 8c 24 c8 01 00 00                         	mov    QWORD PTR [rsp+0x1c8],rcx
   83b30:	48 8b 8c 24 c0 02 00 00                         	mov    rcx,QWORD PTR [rsp+0x2c0]
   83b38:	48 89 b4 24 d0 01 00 00                         	mov    QWORD PTR [rsp+0x1d0],rsi
   83b40:	48 8d b4 24 c0 01 00 00                         	lea    rsi,[rsp+0x1c0]
   83b48:	48 89 8c 24 d8 01 00 00                         	mov    QWORD PTR [rsp+0x1d8],rcx
   83b50:	31 ff                                           	xor    edi,edi
   83b52:	31 c9                                           	xor    ecx,ecx
   83b54:	31 c0                                           	xor    eax,eax
   83b56:	45 31 c9                                        	xor    r9d,r9d
   83b59:	45 31 c0                                        	xor    r8d,r8d
   83b5c:	49 8b 13                                        	mov    rdx,QWORD PTR [r11]
   83b5f:	45 31 ff                                        	xor    r15d,r15d
   83b62:	c4 62 ab f6 36                                  	mulx   r14,r10,QWORD PTR [rsi]
   83b67:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   83b6d:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   83b73:	c4 62 ab f6 76 08                               	mulx   r14,r10,QWORD PTR [rsi+0x8]
   83b79:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   83b7f:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   83b85:	c4 62 ab f6 76 10                               	mulx   r14,r10,QWORD PTR [rsi+0x10]
   83b8b:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   83b91:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   83b97:	c4 62 ab f6 76 18                               	mulx   r14,r10,QWORD PTR [rsi+0x18]
   83b9d:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   83ba3:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   83ba9:	66 4d 0f 38 f6 c7                               	adcx   r8,r15
   83baf:	48 89 fa                                        	mov    rdx,rdi
   83bb2:	49 0f af d4                                     	imul   rdx,r12
   83bb6:	45 31 ff                                        	xor    r15d,r15d
   83bb9:	c4 42 ab f6 75 00                               	mulx   r14,r10,QWORD PTR [r13+0x0]
   83bbf:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   83bc5:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   83bcb:	c4 42 ab f6 75 08                               	mulx   r14,r10,QWORD PTR [r13+0x8]
   83bd1:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   83bd7:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   83bdd:	c4 42 ab f6 75 10                               	mulx   r14,r10,QWORD PTR [r13+0x10]
   83be3:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   83be9:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   83bef:	c4 42 ab f6 75 18                               	mulx   r14,r10,QWORD PTR [r13+0x18]
   83bf5:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   83bfb:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   83c01:	66 4d 0f 38 f6 c7                               	adcx   r8,r15
   83c07:	49 8b 53 08                                     	mov    rdx,QWORD PTR [r11+0x8]
   83c0b:	45 31 ff                                        	xor    r15d,r15d
   83c0e:	c4 62 ab f6 36                                  	mulx   r14,r10,QWORD PTR [rsi]
   83c13:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   83c19:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   83c1f:	c4 62 ab f6 76 08                               	mulx   r14,r10,QWORD PTR [rsi+0x8]
   83c25:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   83c2b:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   83c31:	c4 62 ab f6 76 10                               	mulx   r14,r10,QWORD PTR [rsi+0x10]
   83c37:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   83c3d:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   83c43:	c4 62 ab f6 76 18                               	mulx   r14,r10,QWORD PTR [rsi+0x18]
   83c49:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   83c4f:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   83c55:	66 49 0f 38 f6 ff                               	adcx   rdi,r15
   83c5b:	48 89 ca                                        	mov    rdx,rcx
   83c5e:	49 0f af d4                                     	imul   rdx,r12
   83c62:	45 31 ff                                        	xor    r15d,r15d
   83c65:	c4 42 ab f6 75 00                               	mulx   r14,r10,QWORD PTR [r13+0x0]
   83c6b:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   83c71:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   83c77:	c4 42 ab f6 75 08                               	mulx   r14,r10,QWORD PTR [r13+0x8]
   83c7d:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   83c83:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   83c89:	c4 42 ab f6 75 10                               	mulx   r14,r10,QWORD PTR [r13+0x10]
   83c8f:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   83c95:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   83c9b:	c4 42 ab f6 75 18                               	mulx   r14,r10,QWORD PTR [r13+0x18]
   83ca1:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   83ca7:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   83cad:	66 49 0f 38 f6 ff                               	adcx   rdi,r15
   83cb3:	49 8b 53 10                                     	mov    rdx,QWORD PTR [r11+0x10]
   83cb7:	45 31 ff                                        	xor    r15d,r15d
   83cba:	c4 62 ab f6 36                                  	mulx   r14,r10,QWORD PTR [rsi]
   83cbf:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   83cc5:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   83ccb:	c4 62 ab f6 76 08                               	mulx   r14,r10,QWORD PTR [rsi+0x8]
   83cd1:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   83cd7:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   83cdd:	c4 62 ab f6 76 10                               	mulx   r14,r10,QWORD PTR [rsi+0x10]
   83ce3:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   83ce9:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   83cef:	c4 62 ab f6 76 18                               	mulx   r14,r10,QWORD PTR [rsi+0x18]
   83cf5:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   83cfb:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   83d01:	66 49 0f 38 f6 cf                               	adcx   rcx,r15
   83d07:	48 89 c2                                        	mov    rdx,rax
   83d0a:	49 0f af d4                                     	imul   rdx,r12
   83d0e:	45 31 ff                                        	xor    r15d,r15d
   83d11:	c4 42 ab f6 75 00                               	mulx   r14,r10,QWORD PTR [r13+0x0]
   83d17:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   83d1d:	f3 4d 0f 38 f6 ce                               	adox   r9,r14
   83d23:	c4 42 ab f6 75 08                               	mulx   r14,r10,QWORD PTR [r13+0x8]
   83d29:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   83d2f:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   83d35:	c4 42 ab f6 75 10                               	mulx   r14,r10,QWORD PTR [r13+0x10]
   83d3b:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   83d41:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   83d47:	c4 42 ab f6 75 18                               	mulx   r14,r10,QWORD PTR [r13+0x18]
   83d4d:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   83d53:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   83d59:	66 49 0f 38 f6 cf                               	adcx   rcx,r15
   83d5f:	49 8b 53 18                                     	mov    rdx,QWORD PTR [r11+0x18]
   83d63:	45 31 ff                                        	xor    r15d,r15d
   83d66:	c4 62 ab f6 36                                  	mulx   r14,r10,QWORD PTR [rsi]
   83d6b:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   83d71:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   83d77:	c4 62 ab f6 76 08                               	mulx   r14,r10,QWORD PTR [rsi+0x8]
   83d7d:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   83d83:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   83d89:	c4 62 ab f6 76 10                               	mulx   r14,r10,QWORD PTR [rsi+0x10]
   83d8f:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   83d95:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   83d9b:	c4 62 ab f6 76 18                               	mulx   r14,r10,QWORD PTR [rsi+0x18]
   83da1:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   83da7:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   83dad:	66 49 0f 38 f6 c7                               	adcx   rax,r15
   83db3:	4c 89 ca                                        	mov    rdx,r9
   83db6:	49 0f af d4                                     	imul   rdx,r12
   83dba:	45 31 ff                                        	xor    r15d,r15d
   83dbd:	c4 42 ab f6 75 00                               	mulx   r14,r10,QWORD PTR [r13+0x0]
   83dc3:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   83dc9:	f3 4d 0f 38 f6 c6                               	adox   r8,r14
   83dcf:	c4 42 ab f6 75 08                               	mulx   r14,r10,QWORD PTR [r13+0x8]
   83dd5:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   83ddb:	f3 49 0f 38 f6 fe                               	adox   rdi,r14
   83de1:	c4 42 ab f6 75 10                               	mulx   r14,r10,QWORD PTR [r13+0x10]
   83de7:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   83ded:	f3 49 0f 38 f6 ce                               	adox   rcx,r14
   83df3:	c4 42 ab f6 75 18                               	mulx   r14,r10,QWORD PTR [r13+0x18]
   83df9:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   83dff:	f3 49 0f 38 f6 c6                               	adox   rax,r14
   83e05:	66 49 0f 38 f6 c7                               	adcx   rax,r15
   83e0b:	48 ba 73 35 8e 97 6e 95 7e 68                   	movabs rdx,0x687e956e978e3573
   83e15:	49 b9 47 fd 7c d8 16 8c 20 3c                   	movabs r9,0x3c208c16d87cfd47
   83e1f:	49 ba 8d ca 71 68 91 6a 81 97                   	movabs r10,0x97816a916871ca8d
   83e29:	48 01 fa                                        	add    rdx,rdi
   83e2c:	4d 39 c8                                        	cmp    r8,r9
   83e2f:	48 83 da 00                                     	sbb    rdx,0x0
   83e33:	41 0f 92 c1                                     	setb   r9b
   83e37:	4c 39 d7                                        	cmp    rdi,r10
   83e3a:	41 0f 92 c2                                     	setb   r10b
   83e3e:	45 08 ca                                        	or     r10b,r9b
   83e41:	49 b9 a3 a7 7e 7e 49 ba af 47                   	movabs r9,0x47afba497e7ea7a3
   83e4b:	4e 8d 34 09                                     	lea    r14,[rcx+r9*1]
   83e4f:	45 0f b6 ca                                     	movzx  r9d,r10b
   83e53:	49 ba 5d 58 81 81 b6 45 50 b8                   	movabs r10,0xb85045b68181585d
   83e5d:	4d 29 ce                                        	sub    r14,r9
   83e60:	41 0f 92 c1                                     	setb   r9b
   83e64:	4c 39 d1                                        	cmp    rcx,r10
   83e67:	41 0f 92 c2                                     	setb   r10b
   83e6b:	45 08 ca                                        	or     r10b,r9b
   83e6e:	49 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs r9,0xcf9bb18d1ece5fd7
   83e78:	4e 8d 3c 08                                     	lea    r15,[rax+r9*1]
   83e7c:	45 0f b6 ca                                     	movzx  r9d,r10b
   83e80:	49 ba 29 a0 31 e1 72 4e 64 30                   	movabs r10,0x30644e72e131a029
   83e8a:	4d 29 cf                                        	sub    r15,r9
   83e8d:	41 0f 92 c1                                     	setb   r9b
   83e91:	4c 39 d0                                        	cmp    rax,r10
   83e94:	41 0f 92 c2                                     	setb   r10b
   83e98:	45 08 ca                                        	or     r10b,r9b
   83e9b:	75 13                                           	jne    83eb0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x49d0>
   83e9d:	48 b8 b9 02 83 27 e9 73 df c3                   	movabs rax,0xc3df73e9278302b9
   83ea7:	49 01 c0                                        	add    r8,rax
   83eaa:	eb 0d                                           	jmp    83eb9 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x49d9>
   83eac:	0f 1f 40 00                                     	nop    DWORD PTR [rax+0x0]
   83eb0:	48 89 fa                                        	mov    rdx,rdi
   83eb3:	49 89 ce                                        	mov    r14,rcx
   83eb6:	49 89 c7                                        	mov    r15,rax
   83eb9:	c5 fd 6f 84 24 a0 0a 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0xaa0]
   83ec2:	c5 fd 7f 94 24 e0 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm2
   83ecb:	48 8d 74 24 20                                  	lea    rsi,[rsp+0x20]
   83ed0:	4c 8d a4 24 e0 01 00 00                         	lea    r12,[rsp+0x1e0]
   83ed8:	c5 fd 7f 44 24 20                               	vmovdqa YMMWORD PTR [rsp+0x20],ymm0
   83ede:	4c 2b 06                                        	sub    r8,QWORD PTR [rsi]
   83ee1:	48 1b 56 08                                     	sbb    rdx,QWORD PTR [rsi+0x8]
   83ee5:	4c 1b 76 10                                     	sbb    r14,QWORD PTR [rsi+0x10]
   83ee9:	4c 1b 7e 18                                     	sbb    r15,QWORD PTR [rsi+0x18]
   83eed:	4d 19 d2                                        	sbb    r10,r10
   83ef0:	49 8b 04 24                                     	mov    rax,QWORD PTR [r12]
   83ef4:	49 8b 4c 24 08                                  	mov    rcx,QWORD PTR [r12+0x8]
   83ef9:	49 8b 7c 24 10                                  	mov    rdi,QWORD PTR [r12+0x10]
   83efe:	4d 8b 4c 24 18                                  	mov    r9,QWORD PTR [r12+0x18]
   83f03:	4c 21 d0                                        	and    rax,r10
   83f06:	4c 21 d1                                        	and    rcx,r10
   83f09:	4c 21 d7                                        	and    rdi,r10
   83f0c:	4d 21 d1                                        	and    r9,r10
   83f0f:	49 01 c0                                        	add    r8,rax
   83f12:	48 11 ca                                        	adc    rdx,rcx
   83f15:	49 11 fe                                        	adc    r14,rdi
   83f18:	4d 11 cf                                        	adc    r15,r9
   83f1b:	48 8b bc 24 c0 04 00 00                         	mov    rdi,QWORD PTR [rsp+0x4c0]
   83f23:	48 3b bc 24 80 05 00 00                         	cmp    rdi,QWORD PTR [rsp+0x580]
   83f2b:	0f 83 80 1e 00 00                               	jae    85db1 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x68d1>
   83f31:	4c 8b 94 24 c0 03 00 00                         	mov    r10,QWORD PTR [rsp+0x3c0]
   83f39:	48 8b 4c 24 10                                  	mov    rcx,QWORD PTR [rsp+0x10]
   83f3e:	4c 8b 8c 24 40 05 00 00                         	mov    r9,QWORD PTR [rsp+0x540]
   83f46:	4c 8b a4 24 40 04 00 00                         	mov    r12,QWORD PTR [rsp+0x440]
   83f4e:	41 8b 02                                        	mov    eax,DWORD PTR [r10]
   83f51:	48 89 ce                                        	mov    rsi,rcx
   83f54:	25 ff ff ff 7f                                  	and    eax,0x7fffffff
   83f59:	48 39 c1                                        	cmp    rcx,rax
   83f5c:	0f 86 3d 1e 00 00                               	jbe    85d9f <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x68bf>
   83f62:	48 8b 8c 24 80 03 00 00                         	mov    rcx,QWORD PTR [rsp+0x380]
   83f6a:	4c 8b 9c 24 00 04 00 00                         	mov    r11,QWORD PTR [rsp+0x400]
   83f72:	48 c1 e0 06                                     	shl    rax,0x6
   83f76:	48 8b 9c 24 40 03 00 00                         	mov    rbx,QWORD PTR [rsp+0x340]
   83f7e:	49 83 c2 f0                                     	add    r10,0xfffffffffffffff0
   83f82:	49 89 0c 01                                     	mov    QWORD PTR [r9+rax*1],rcx
   83f86:	4d 89 5c 01 08                                  	mov    QWORD PTR [r9+rax*1+0x8],r11
   83f8b:	4c 8b 9c 24 80 04 00 00                         	mov    r11,QWORD PTR [rsp+0x480]
   83f93:	49 89 5c 01 10                                  	mov    QWORD PTR [r9+rax*1+0x10],rbx
   83f98:	48 8d 4f ff                                     	lea    rcx,[rdi-0x1]
   83f9c:	4d 89 5c 01 18                                  	mov    QWORD PTR [r9+rax*1+0x18],r11
   83fa1:	4d 89 44 01 20                                  	mov    QWORD PTR [r9+rax*1+0x20],r8
   83fa6:	49 89 54 01 28                                  	mov    QWORD PTR [r9+rax*1+0x28],rdx
   83fab:	4c 8b 84 24 c0 06 00 00                         	mov    r8,QWORD PTR [rsp+0x6c0]
   83fb3:	48 8b 94 24 80 06 00 00                         	mov    rdx,QWORD PTR [rsp+0x680]
   83fbb:	4d 89 74 01 30                                  	mov    QWORD PTR [r9+rax*1+0x30],r14
   83fc0:	4d 89 7c 01 38                                  	mov    QWORD PTR [r9+rax*1+0x38],r15
   83fc5:	49 81 c0 60 ff ff ff                            	add    r8,0xffffffffffffff60
   83fcc:	48 81 c2 60 ff ff ff                            	add    rdx,0xffffffffffffff60
   83fd3:	48 39 bc 24 40 07 00 00                         	cmp    QWORD PTR [rsp+0x740],rdi
   83fdb:	0f 82 7f ed ff ff                               	jb     82d60 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x3880>
   83fe1:	49 8b 54 24 10                                  	mov    rdx,QWORD PTR [r12+0x10]
   83fe6:	4c 8b ac 24 80 05 00 00                         	mov    r13,QWORD PTR [rsp+0x580]
   83fee:	49 ba 63 c2 e5 9c c8 60 00 00                   	movabs r10,0x60c89ce5c263
   83ff8:	49 89 f4                                        	mov    r12,rsi
   83ffb:	62 f1 fe 48 6f 44 24 02                         	vmovdqu64 zmm0,ZMMWORD PTR [rsp+0x80]
   84003:	62 f1 fe 48 6f 4c 24 03                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0xc0]
   8400b:	62 f1 fe 48 6f 54 24 04                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x100]
   84013:	62 f1 fe 48 6f 5c 24 05                         	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x140]
   8401b:	62 f1 fd 48 6f 3d db 33 f8 ff                   	vmovdqa64 zmm7,ZMMWORD PTR [rip+0xfffffffffff833db]        # 7400 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x460>
   84025:	62 f1 fd 48 6f 35 11 34 f8 ff                   	vmovdqa64 zmm6,ZMMWORD PTR [rip+0xfffffffffff83411]        # 7440 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4a0>
   8402f:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   84035:	62 71 ed 48 6c c3                               	vpunpcklqdq zmm8,zmm2,zmm3
   8403b:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   84041:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   84047:	62 f1 fd 48 6f ec                               	vmovdqa64 zmm5,zmm4
   8404d:	62 d2 c5 48 7e e8                               	vpermt2q zmm5,zmm7,zmm8
   84053:	62 f2 fd 48 76 fa                               	vpermi2q zmm7,zmm0,zmm2
   84059:	62 f2 cd 48 7e c2                               	vpermt2q zmm0,zmm6,zmm2
   8405f:	62 d2 cd 48 7e e0                               	vpermt2q zmm4,zmm6,zmm8
   84065:	62 f2 fd 48 59 35 d1 2b f8 ff                   	vpbroadcastq zmm6,QWORD PTR [rip+0xfffffffffff82bd1]        # 6c40 <GCC_except_table711+0x150>
   8406f:	62 f3 c5 48 71 cd 0c                            	vpshldq zmm1,zmm7,zmm5,0xc
   84076:	62 f3 fd 48 71 dc 24                            	vpshldq zmm3,zmm0,zmm4,0x24
   8407d:	62 f1 9d 48 73 d0 10                            	vpsrlq zmm12,zmm0,0x10
   84084:	62 71 d5 48 db d6                               	vpandq zmm10,zmm5,zmm6
   8408a:	62 f3 dd 48 71 ef 18                            	vpshldq zmm5,zmm4,zmm7,0x18
   84091:	62 71 f5 48 db de                               	vpandq zmm11,zmm1,zmm6
   84097:	62 71 e5 48 db f6                               	vpandq zmm14,zmm3,zmm6
   8409d:	62 71 d5 48 db ee                               	vpandq zmm13,zmm5,zmm6
   840a3:	4c 8b 44 24 18                                  	mov    r8,QWORD PTR [rsp+0x18]
   840a8:	48 85 d2                                        	test   rdx,rdx
   840ab:	0f 84 f7 19 00 00                               	je     85aa8 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x65c8>
   840b1:	48 8b 84 24 40 04 00 00                         	mov    rax,QWORD PTR [rsp+0x440]
   840b9:	62 62 fd 48 59 15 95 2c f8 ff                   	vpbroadcastq zmm26,QWORD PTR [rip+0xfffffffffff82c95]        # 6d58 <GCC_except_table711+0x268>
   840c3:	62 f2 fd 48 59 15 73 2b f8 ff                   	vpbroadcastq zmm2,QWORD PTR [rip+0xfffffffffff82b73]        # 6c40 <GCC_except_table711+0x150>
   840cd:	62 62 fd 48 59 1d 99 2b f8 ff                   	vpbroadcastq zmm27,QWORD PTR [rip+0xfffffffffff82b99]        # 6c70 <GCC_except_table711+0x180>
   840d7:	62 e2 fd 48 59 35 67 2b f8 ff                   	vpbroadcastq zmm22,QWORD PTR [rip+0xfffffffffff82b67]        # 6c48 <GCC_except_table711+0x158>
   840e1:	62 62 fd 48 59 25 15 2c f8 ff                   	vpbroadcastq zmm28,QWORD PTR [rip+0xfffffffffff82c15]        # 6d00 <GCC_except_table711+0x210>
   840eb:	48 69 d2 40 06 00 00                            	imul   rdx,rdx,0x640
   840f2:	48 be 48 e1 7a 14 ae 47 e1 7a                   	movabs rsi,0x7ae147ae147ae148
   840fc:	48 81 c2 c0 f9 ff ff                            	add    rdx,0xfffffffffffff9c0
   84103:	48 8b 48 08                                     	mov    rcx,QWORD PTR [rax+0x8]
   84107:	66 0f 1f 84 00 00 00 00 00                      	nop    WORD PTR [rax+rax*1+0x0]
   84110:	62 e1 fd 28 6f 3d c6 36 f8 ff                   	vmovdqa64 ymm23,YMMWORD PTR [rip+0xfffffffffff836c6]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   8411a:	48 b8 31 e1 72 4e 64 30 00 00                   	movabs rax,0x30644e72e131
   84124:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   8412a:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   84130:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   84136:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   8413c:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   84142:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   84148:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   8414c:	62 e1 fe 28 7f 7c 24 04                         	vmovdqu64 YMMWORD PTR [rsp+0x80],ymm23
   84154:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   8415c:	62 f1 fd 48 6f 4c 11 14                         	vmovdqa64 zmm1,ZMMWORD PTR [rcx+rdx*1+0x500]
   84164:	62 71 fd 48 6f 7c 11 17                         	vmovdqa64 zmm15,ZMMWORD PTR [rcx+rdx*1+0x5c0]
   8416c:	62 f1 fd 48 6f 7c 11 16                         	vmovdqa64 zmm7,ZMMWORD PTR [rcx+rdx*1+0x580]
   84174:	62 f1 fd 48 6f 6c 11 15                         	vmovdqa64 zmm5,ZMMWORD PTR [rcx+rdx*1+0x540]
   8417c:	62 f1 fd 48 6f 5c 11 18                         	vmovdqa64 zmm3,ZMMWORD PTR [rcx+rdx*1+0x600]
   84184:	62 72 fd 48 59 44 24 13                         	vpbroadcastq zmm8,QWORD PTR [rsp+0x98]
   8418c:	62 72 fd 48 59 4c 24 12                         	vpbroadcastq zmm9,QWORD PTR [rsp+0x90]
   84194:	62 f2 fd 48 59 44 24 11                         	vpbroadcastq zmm0,QWORD PTR [rsp+0x88]
   8419c:	62 f2 fd 48 59 74 24 14                         	vpbroadcastq zmm6,QWORD PTR [rsp+0xa0]
   841a4:	62 e1 fe 28 7f 7c 24 04                         	vmovdqu64 YMMWORD PTR [rsp+0x80],ymm23
   841ac:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   841b4:	62 c2 85 48 b5 ca                               	vpmadd52huq zmm17,zmm15,zmm10
   841ba:	62 c2 f5 48 b4 c2                               	vpmadd52luq zmm16,zmm1,zmm10
   841c0:	62 c2 c5 48 b5 da                               	vpmadd52huq zmm19,zmm7,zmm10
   841c6:	62 c2 d5 48 b5 d2                               	vpmadd52huq zmm18,zmm5,zmm10
   841cc:	62 c2 f5 48 b5 e2                               	vpmadd52huq zmm20,zmm1,zmm10
   841d2:	62 d2 e5 48 b5 e2                               	vpmadd52huq zmm4,zmm3,zmm10
   841d8:	62 82 fd 40 b4 ea                               	vpmadd52luq zmm21,zmm16,zmm26
   841de:	62 c2 e5 48 b4 ca                               	vpmadd52luq zmm17,zmm3,zmm10
   841e4:	62 c2 85 48 b4 da                               	vpmadd52luq zmm19,zmm15,zmm10
   841ea:	62 c2 c5 48 b4 d2                               	vpmadd52luq zmm18,zmm7,zmm10
   841f0:	62 c2 d5 48 b4 e2                               	vpmadd52luq zmm20,zmm5,zmm10
   841f6:	62 e1 fd 40 d4 c2                               	vpaddq zmm16,zmm16,zmm2
   841fc:	62 b1 fd 40 73 d0 34                            	vpsrlq zmm16,zmm16,0x34
   84203:	62 c2 d5 40 b5 c8                               	vpmadd52huq zmm17,zmm21,zmm8
   84209:	62 c2 d5 40 b5 d9                               	vpmadd52huq zmm19,zmm21,zmm9
   8420f:	62 e2 d5 40 b5 d0                               	vpmadd52huq zmm18,zmm21,zmm0
   84215:	62 82 d5 40 b5 c3                               	vpmadd52huq zmm16,zmm21,zmm27
   8421b:	62 e2 d5 40 b4 e0                               	vpmadd52luq zmm20,zmm21,zmm0
   84221:	62 f2 d5 40 b5 e6                               	vpmadd52huq zmm4,zmm21,zmm6
   84227:	62 e2 d5 40 b4 ce                               	vpmadd52luq zmm17,zmm21,zmm6
   8422d:	62 c2 d5 40 b4 d8                               	vpmadd52luq zmm19,zmm21,zmm8
   84233:	62 c2 d5 40 b4 d1                               	vpmadd52luq zmm18,zmm21,zmm9
   84239:	62 a1 dd 40 d4 e0                               	vpaddq zmm20,zmm20,zmm16
   8423f:	62 d2 85 48 b5 e3                               	vpmadd52huq zmm4,zmm15,zmm11
   84245:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   8424b:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   84251:	62 c2 e5 48 b5 c3                               	vpmadd52huq zmm16,zmm3,zmm11
   84257:	62 c2 f5 48 b4 e3                               	vpmadd52luq zmm20,zmm1,zmm11
   8425d:	62 c2 c5 48 b5 cb                               	vpmadd52huq zmm17,zmm7,zmm11
   84263:	62 c2 d5 48 b5 db                               	vpmadd52huq zmm19,zmm5,zmm11
   84269:	62 c2 f5 48 b5 d3                               	vpmadd52huq zmm18,zmm1,zmm11
   8426f:	62 d2 e5 48 b4 e3                               	vpmadd52luq zmm4,zmm3,zmm11
   84275:	62 82 dd 40 b4 ea                               	vpmadd52luq zmm21,zmm20,zmm26
   8427b:	62 e1 dd 40 d4 e2                               	vpaddq zmm20,zmm20,zmm2
   84281:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   84288:	62 c2 85 48 b4 cb                               	vpmadd52luq zmm17,zmm15,zmm11
   8428e:	62 c2 c5 48 b4 db                               	vpmadd52luq zmm19,zmm7,zmm11
   84294:	62 c2 d5 48 b4 d3                               	vpmadd52luq zmm18,zmm5,zmm11
   8429a:	62 d2 d5 40 b5 e0                               	vpmadd52huq zmm4,zmm21,zmm8
   842a0:	62 82 d5 40 b5 e3                               	vpmadd52huq zmm20,zmm21,zmm27
   842a6:	62 e2 d5 40 b5 c6                               	vpmadd52huq zmm16,zmm21,zmm6
   842ac:	62 c2 d5 40 b5 c9                               	vpmadd52huq zmm17,zmm21,zmm9
   842b2:	62 e2 d5 40 b5 d8                               	vpmadd52huq zmm19,zmm21,zmm0
   842b8:	62 e2 d5 40 b4 d0                               	vpmadd52luq zmm18,zmm21,zmm0
   842be:	62 f2 d5 40 b4 e6                               	vpmadd52luq zmm4,zmm21,zmm6
   842c4:	62 c2 85 48 b5 c5                               	vpmadd52huq zmm16,zmm15,zmm13
   842ca:	62 c2 d5 40 b4 c8                               	vpmadd52luq zmm17,zmm21,zmm8
   842d0:	62 c2 d5 40 b4 d9                               	vpmadd52luq zmm19,zmm21,zmm9
   842d6:	62 a1 ed 40 d4 e4                               	vpaddq zmm20,zmm18,zmm20
   842dc:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   842e2:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   842e8:	62 c2 e5 48 b5 d5                               	vpmadd52huq zmm18,zmm3,zmm13
   842ee:	62 c2 f5 48 b4 e5                               	vpmadd52luq zmm20,zmm1,zmm13
   842f4:	62 d2 c5 48 b5 e5                               	vpmadd52huq zmm4,zmm7,zmm13
   842fa:	62 c2 e5 48 b4 c5                               	vpmadd52luq zmm16,zmm3,zmm13
   84300:	62 c2 d5 48 b5 cd                               	vpmadd52huq zmm17,zmm5,zmm13
   84306:	62 c2 f5 48 b5 dd                               	vpmadd52huq zmm19,zmm1,zmm13
   8430c:	62 82 dd 40 b4 ea                               	vpmadd52luq zmm21,zmm20,zmm26
   84312:	62 d2 85 48 b4 e5                               	vpmadd52luq zmm4,zmm15,zmm13
   84318:	62 e1 dd 40 d4 e2                               	vpaddq zmm20,zmm20,zmm2
   8431e:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   84325:	62 c2 c5 48 b4 cd                               	vpmadd52luq zmm17,zmm7,zmm13
   8432b:	62 c2 d5 48 b4 dd                               	vpmadd52luq zmm19,zmm5,zmm13
   84331:	62 c2 d5 40 b5 c0                               	vpmadd52huq zmm16,zmm21,zmm8
   84337:	62 d2 d5 40 b5 e1                               	vpmadd52huq zmm4,zmm21,zmm9
   8433d:	62 82 d5 40 b5 e3                               	vpmadd52huq zmm20,zmm21,zmm27
   84343:	62 e2 d5 40 b5 d6                               	vpmadd52huq zmm18,zmm21,zmm6
   84349:	62 e2 d5 40 b5 c8                               	vpmadd52huq zmm17,zmm21,zmm0
   8434f:	62 e2 d5 40 b4 d8                               	vpmadd52luq zmm19,zmm21,zmm0
   84355:	62 e2 d5 40 b4 c6                               	vpmadd52luq zmm16,zmm21,zmm6
   8435b:	62 d2 d5 40 b4 e0                               	vpmadd52luq zmm4,zmm21,zmm8
   84361:	62 c2 85 48 b5 d6                               	vpmadd52huq zmm18,zmm15,zmm14
   84367:	62 c2 d5 40 b4 c9                               	vpmadd52luq zmm17,zmm21,zmm9
   8436d:	62 a1 e5 40 d4 e4                               	vpaddq zmm20,zmm19,zmm20
   84373:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   84379:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   8437f:	62 c2 e5 48 b5 de                               	vpmadd52huq zmm19,zmm3,zmm14
   84385:	62 c2 f5 48 b4 e6                               	vpmadd52luq zmm20,zmm1,zmm14
   8438b:	62 c2 c5 48 b5 c6                               	vpmadd52huq zmm16,zmm7,zmm14
   84391:	62 d2 d5 48 b5 e6                               	vpmadd52huq zmm4,zmm5,zmm14
   84397:	62 c2 e5 48 b4 d6                               	vpmadd52luq zmm18,zmm3,zmm14
   8439d:	62 c2 f5 48 b5 ce                               	vpmadd52huq zmm17,zmm1,zmm14
   843a3:	62 82 dd 40 b4 ea                               	vpmadd52luq zmm21,zmm20,zmm26
   843a9:	62 c2 85 48 b4 c6                               	vpmadd52luq zmm16,zmm15,zmm14
   843af:	62 d2 c5 48 b4 e6                               	vpmadd52luq zmm4,zmm7,zmm14
   843b5:	62 e1 dd 40 d4 e2                               	vpaddq zmm20,zmm20,zmm2
   843bb:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   843c2:	62 c2 d5 48 b4 ce                               	vpmadd52luq zmm17,zmm5,zmm14
   843c8:	62 c2 d5 40 b5 d0                               	vpmadd52huq zmm18,zmm21,zmm8
   843ce:	62 c2 d5 40 b5 c1                               	vpmadd52huq zmm16,zmm21,zmm9
   843d4:	62 f2 d5 40 b5 e0                               	vpmadd52huq zmm4,zmm21,zmm0
   843da:	62 82 d5 40 b5 e3                               	vpmadd52huq zmm20,zmm21,zmm27
   843e0:	62 e2 d5 40 b5 de                               	vpmadd52huq zmm19,zmm21,zmm6
   843e6:	62 e2 d5 40 b4 c8                               	vpmadd52luq zmm17,zmm21,zmm0
   843ec:	62 e2 d5 40 b4 d6                               	vpmadd52luq zmm18,zmm21,zmm6
   843f2:	62 c2 d5 40 b4 c0                               	vpmadd52luq zmm16,zmm21,zmm8
   843f8:	62 d2 d5 40 b4 e1                               	vpmadd52luq zmm4,zmm21,zmm9
   843fe:	62 c2 85 48 b5 dc                               	vpmadd52huq zmm19,zmm15,zmm12
   84404:	62 81 fd 48 6f ea                               	vmovdqa64 zmm21,zmm26
   8440a:	62 a1 f5 40 d4 cc                               	vpaddq zmm17,zmm17,zmm20
   84410:	62 c2 f5 48 b4 cc                               	vpmadd52luq zmm17,zmm1,zmm12
   84416:	62 c2 c5 48 b5 d4                               	vpmadd52huq zmm18,zmm7,zmm12
   8441c:	62 c2 d5 48 b5 c4                               	vpmadd52huq zmm16,zmm5,zmm12
   84422:	62 d2 f5 48 b5 e4                               	vpmadd52huq zmm4,zmm1,zmm12
   84428:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8442c:	62 c2 e5 48 b4 dc                               	vpmadd52luq zmm19,zmm3,zmm12
   84432:	62 d2 e5 48 b5 cc                               	vpmadd52huq zmm1,zmm3,zmm12
   84438:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   8443c:	62 92 f5 40 b4 da                               	vpmadd52luq zmm3,zmm17,zmm26
   84442:	62 c2 85 48 b4 d4                               	vpmadd52luq zmm18,zmm15,zmm12
   84448:	62 c2 c5 48 b4 c4                               	vpmadd52luq zmm16,zmm7,zmm12
   8444e:	62 d2 d5 48 b4 e4                               	vpmadd52luq zmm4,zmm5,zmm12
   84454:	62 b1 f5 40 d4 fe                               	vpaddq zmm7,zmm17,zmm22
   8445a:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8445f:	62 f1 c5 48 73 d7 30                            	vpsrlq zmm7,zmm7,0x30
   84466:	62 b1 e5 48 db ee                               	vpandq zmm5,zmm3,zmm22
   8446c:	62 f1 e5 48 73 f3 04                            	vpsllq zmm3,zmm3,0x4
   84473:	62 81 fd 48 6f f3                               	vmovdqa64 zmm22,zmm27
   84479:	62 c2 d5 48 b5 d1                               	vpmadd52huq zmm18,zmm5,zmm9
   8447f:	62 c2 d5 48 b5 d8                               	vpmadd52huq zmm19,zmm5,zmm8
   84485:	62 e2 d5 48 b5 c0                               	vpmadd52huq zmm16,zmm5,zmm0
   8448b:	62 f2 d5 48 b4 e0                               	vpmadd52luq zmm4,zmm5,zmm0
   84491:	62 92 e5 48 b5 fb                               	vpmadd52huq zmm7,zmm3,zmm27
   84497:	62 f2 d5 48 b5 ce                               	vpmadd52huq zmm1,zmm5,zmm6
   8449d:	62 c2 d5 48 b4 d0                               	vpmadd52luq zmm18,zmm5,zmm8
   844a3:	62 e2 d5 48 b4 de                               	vpmadd52luq zmm19,zmm5,zmm6
   844a9:	62 c2 d5 48 b4 c1                               	vpmadd52luq zmm16,zmm5,zmm9
   844af:	62 f1 fd 48 73 f4 04                            	vpsllq zmm0,zmm4,0x4
   844b6:	62 f1 f5 48 73 f1 04                            	vpsllq zmm1,zmm1,0x4
   844bd:	62 f1 e5 48 73 d4 30                            	vpsrlq zmm3,zmm4,0x30
   844c4:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   844c9:	62 91 fd 48 db c4                               	vpandq zmm0,zmm0,zmm28
   844cf:	62 f1 fd 48 d4 c7                               	vpaddq zmm0,zmm0,zmm7
   844d5:	62 b1 cd 48 73 f2 04                            	vpsllq zmm6,zmm18,0x4
   844dc:	62 b1 c5 48 73 f3 04                            	vpsllq zmm7,zmm19,0x4
   844e3:	62 b1 d5 48 73 d0 30                            	vpsrlq zmm5,zmm16,0x30
   844ea:	62 b1 bd 48 73 d2 30                            	vpsrlq zmm8,zmm18,0x30
   844f1:	62 b1 dd 48 73 f0 04                            	vpsllq zmm4,zmm16,0x4
   844f8:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   844fe:	62 91 cd 48 db f4                               	vpandq zmm6,zmm6,zmm28
   84504:	62 91 c5 48 db fc                               	vpandq zmm7,zmm7,zmm28
   8450a:	62 91 dd 48 db e4                               	vpandq zmm4,zmm4,zmm28
   84510:	62 61 fd 48 db e2                               	vpandq zmm28,zmm0,zmm2
   84516:	62 f1 cd 48 d4 ed                               	vpaddq zmm5,zmm6,zmm5
   8451c:	62 d1 c5 48 d4 f0                               	vpaddq zmm6,zmm7,zmm8
   84522:	62 b1 c5 48 73 d3 30                            	vpsrlq zmm7,zmm19,0x30
   84529:	62 12 9d 40 b5 fc                               	vpmadd52huq zmm15,zmm28,zmm28
   8452f:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   84535:	62 f1 f5 48 d4 cf                               	vpaddq zmm1,zmm1,zmm7
   8453b:	62 f1 c5 48 73 d0 34                            	vpsrlq zmm7,zmm0,0x34
   84542:	62 f1 c5 48 d4 db                               	vpaddq zmm3,zmm7,zmm3
   84548:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   8454c:	62 f1 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm4
   84552:	62 f2 fd 48 19 64 24 12                         	vbroadcastsd zmm4,QWORD PTR [rsp+0x90]
   8455a:	62 f1 fd 48 73 d3 34                            	vpsrlq zmm0,zmm3,0x34
   84561:	62 61 e5 48 db da                               	vpandq zmm27,zmm3,zmm2
   84567:	62 f1 fd 48 d4 c5                               	vpaddq zmm0,zmm0,zmm5
   8456d:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   84571:	62 92 a5 40 b5 ec                               	vpmadd52huq zmm5,zmm27,zmm28
   84577:	62 12 a5 40 b4 fc                               	vpmadd52luq zmm15,zmm27,zmm28
   8457d:	62 f1 e5 48 73 d0 34                            	vpsrlq zmm3,zmm0,0x34
   84584:	62 61 fd 48 db d2                               	vpandq zmm26,zmm0,zmm2
   8458a:	62 f1 e5 48 d4 de                               	vpaddq zmm3,zmm3,zmm6
   84590:	62 f2 fd 48 19 74 24 11                         	vbroadcastsd zmm6,QWORD PTR [rsp+0x88]
   84598:	62 92 ad 40 b5 fc                               	vpmadd52huq zmm7,zmm26,zmm28
   8459e:	62 f1 fd 48 73 d3 34                            	vpsrlq zmm0,zmm3,0x34
   845a5:	62 61 e5 48 db ca                               	vpandq zmm25,zmm3,zmm2
   845ab:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   845af:	62 61 fd 48 d4 c1                               	vpaddq zmm24,zmm0,zmm1
   845b5:	62 b1 fd 28 6f cf                               	vmovdqa64 ymm1,ymm23
   845bb:	62 e1 fd 48 6f 7c 11 0f                         	vmovdqa64 zmm23,ZMMWORD PTR [rcx+rdx*1+0x3c0]
   845c3:	62 92 b5 40 b5 dc                               	vpmadd52huq zmm3,zmm25,zmm28
   845c9:	62 e1 fd 28 6f d1                               	vmovdqa64 ymm18,ymm1
   845cf:	62 92 ad 40 b4 ec                               	vpmadd52luq zmm5,zmm26,zmm28
   845d5:	62 12 bd 40 b5 cc                               	vpmadd52huq zmm9,zmm24,zmm28
   845db:	62 f1 7c 48 29 64 24 09                         	vmovaps ZMMWORD PTR [rsp+0x240],zmm4
   845e3:	62 f2 fd 48 19 64 24 14                         	vbroadcastsd zmm4,QWORD PTR [rsp+0xa0]
   845eb:	62 92 b5 40 b4 fc                               	vpmadd52luq zmm7,zmm25,zmm28
   845f1:	62 92 bd 40 b4 dc                               	vpmadd52luq zmm3,zmm24,zmm28
   845f7:	62 f1 7c 48 29 74 24 1d                         	vmovaps ZMMWORD PTR [rsp+0x740],zmm6
   845ff:	62 f2 fd 48 19 74 24 13                         	vbroadcastsd zmm6,QWORD PTR [rsp+0x98]
   84607:	62 f1 7c 48 29 64 24 08                         	vmovaps ZMMWORD PTR [rsp+0x200],zmm4
   8460f:	62 f1 7c 48 28 64 11 11                         	vmovaps zmm4,ZMMWORD PTR [rcx+rdx*1+0x440]
   84617:	62 f1 7c 48 29 74 24 0a                         	vmovaps ZMMWORD PTR [rsp+0x280],zmm6
   8461f:	62 f1 7c 48 28 74 11 10                         	vmovaps zmm6,ZMMWORD PTR [rcx+rdx*1+0x400]
   84627:	62 f1 7c 48 29 64 24 0f                         	vmovaps ZMMWORD PTR [rsp+0x3c0],zmm4
   8462f:	62 f1 7c 48 28 64 11 13                         	vmovaps zmm4,ZMMWORD PTR [rcx+rdx*1+0x4c0]
   84637:	62 f1 7c 48 29 74 24 13                         	vmovaps ZMMWORD PTR [rsp+0x4c0],zmm6
   8463f:	62 f1 7c 48 28 74 11 12                         	vmovaps zmm6,ZMMWORD PTR [rcx+rdx*1+0x480]
   84647:	c5 fe 7f 8c 24 80 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0x80],ymm1
   84650:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   84658:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8465c:	62 92 9d 40 b4 cc                               	vpmadd52luq zmm1,zmm28,zmm28
   84662:	62 e2 fd 48 59 64 24 13                         	vpbroadcastq zmm20,QWORD PTR [rsp+0x98]
   8466a:	62 72 fd 48 59 44 24 12                         	vpbroadcastq zmm8,QWORD PTR [rsp+0x90]
   84672:	62 f1 7c 48 29 64 24 0b                         	vmovaps ZMMWORD PTR [rsp+0x2c0],zmm4
   8467a:	62 f2 fd 48 59 64 24 11                         	vpbroadcastq zmm4,QWORD PTR [rsp+0x88]
   84682:	62 a2 f5 48 b4 c5                               	vpmadd52luq zmm16,zmm1,zmm21
   84688:	62 f1 f5 48 d4 ca                               	vpaddq zmm1,zmm1,zmm2
   8468e:	62 f1 f5 48 73 d1 34                            	vpsrlq zmm1,zmm1,0x34
   84695:	62 f1 7c 48 29 74 24 16                         	vmovaps ZMMWORD PTR [rsp+0x580],zmm6
   8469d:	62 f2 fd 48 59 74 24 14                         	vpbroadcastq zmm6,QWORD PTR [rsp+0xa0]
   846a5:	62 b2 fd 40 b5 ce                               	vpmadd52huq zmm1,zmm16,zmm22
   846ab:	62 b2 fd 40 b5 dc                               	vpmadd52huq zmm3,zmm16,zmm20
   846b1:	62 d2 fd 40 b5 f8                               	vpmadd52huq zmm7,zmm16,zmm8
   846b7:	62 72 fd 40 b4 fc                               	vpmadd52luq zmm15,zmm16,zmm4
   846bd:	62 f2 fd 40 b5 ec                               	vpmadd52huq zmm5,zmm16,zmm4
   846c3:	62 b2 fd 40 b4 fc                               	vpmadd52luq zmm7,zmm16,zmm20
   846c9:	62 f2 fd 40 b4 de                               	vpmadd52luq zmm3,zmm16,zmm6
   846cf:	62 71 85 48 d4 f9                               	vpaddq zmm15,zmm15,zmm1
   846d5:	62 d2 fd 40 b4 e8                               	vpmadd52luq zmm5,zmm16,zmm8
   846db:	62 72 fd 40 b5 ce                               	vpmadd52huq zmm9,zmm16,zmm6
   846e1:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   846e7:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   846eb:	62 92 bd 40 b5 cb                               	vpmadd52huq zmm1,zmm24,zmm27
   846f1:	62 12 9d 40 b4 fb                               	vpmadd52luq zmm15,zmm28,zmm27
   846f7:	62 92 a5 40 b5 fb                               	vpmadd52huq zmm7,zmm27,zmm27
   846fd:	62 92 ad 40 b5 db                               	vpmadd52huq zmm3,zmm26,zmm27
   84703:	62 92 9d 40 b5 eb                               	vpmadd52huq zmm5,zmm28,zmm27
   84709:	62 12 b5 40 b5 cb                               	vpmadd52huq zmm9,zmm25,zmm27
   8470f:	62 a2 85 48 b4 c5                               	vpmadd52luq zmm16,zmm15,zmm21
   84715:	62 92 ad 40 b4 fb                               	vpmadd52luq zmm7,zmm26,zmm27
   8471b:	62 71 85 48 d4 fa                               	vpaddq zmm15,zmm15,zmm2
   84721:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   84728:	62 92 b5 40 b4 db                               	vpmadd52luq zmm3,zmm25,zmm27
   8472e:	62 92 a5 40 b4 eb                               	vpmadd52luq zmm5,zmm27,zmm27
   84734:	62 12 bd 40 b4 cb                               	vpmadd52luq zmm9,zmm24,zmm27
   8473a:	62 f2 fd 40 b5 fc                               	vpmadd52huq zmm7,zmm16,zmm4
   84740:	62 32 fd 40 b5 fe                               	vpmadd52huq zmm15,zmm16,zmm22
   84746:	62 f2 fd 40 b5 ce                               	vpmadd52huq zmm1,zmm16,zmm6
   8474c:	62 d2 fd 40 b5 d8                               	vpmadd52huq zmm3,zmm16,zmm8
   84752:	62 f2 fd 40 b4 ec                               	vpmadd52luq zmm5,zmm16,zmm4
   84758:	62 32 fd 40 b5 cc                               	vpmadd52huq zmm9,zmm16,zmm20
   8475e:	62 d2 fd 40 b4 f8                               	vpmadd52luq zmm7,zmm16,zmm8
   84764:	62 92 b5 40 b5 ca                               	vpmadd52huq zmm1,zmm25,zmm26
   8476a:	62 b2 fd 40 b4 dc                               	vpmadd52luq zmm3,zmm16,zmm20
   84770:	62 51 d5 48 d4 ff                               	vpaddq zmm15,zmm5,zmm15
   84776:	62 72 fd 40 b4 ce                               	vpmadd52luq zmm9,zmm16,zmm6
   8477c:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   84782:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   84786:	62 92 bd 40 b5 ea                               	vpmadd52huq zmm5,zmm24,zmm26
   8478c:	62 12 9d 40 b4 fa                               	vpmadd52luq zmm15,zmm28,zmm26
   84792:	62 92 9d 40 b5 fa                               	vpmadd52huq zmm7,zmm28,zmm26
   84798:	62 92 bd 40 b4 ca                               	vpmadd52luq zmm1,zmm24,zmm26
   8479e:	62 92 a5 40 b5 da                               	vpmadd52huq zmm3,zmm27,zmm26
   847a4:	62 12 ad 40 b5 ca                               	vpmadd52huq zmm9,zmm26,zmm26
   847aa:	62 a2 85 48 b4 c5                               	vpmadd52luq zmm16,zmm15,zmm21
   847b0:	62 92 a5 40 b4 fa                               	vpmadd52luq zmm7,zmm27,zmm26
   847b6:	62 71 85 48 d4 fa                               	vpaddq zmm15,zmm15,zmm2
   847bc:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   847c3:	62 92 ad 40 b4 da                               	vpmadd52luq zmm3,zmm26,zmm26
   847c9:	62 12 b5 40 b4 ca                               	vpmadd52luq zmm9,zmm25,zmm26
   847cf:	62 32 fd 40 b5 fe                               	vpmadd52huq zmm15,zmm16,zmm22
   847d5:	62 f2 fd 40 b4 fc                               	vpmadd52luq zmm7,zmm16,zmm4
   847db:	62 b2 fd 40 b5 cc                               	vpmadd52huq zmm1,zmm16,zmm20
   847e1:	62 f2 fd 40 b5 ee                               	vpmadd52huq zmm5,zmm16,zmm6
   847e7:	62 f2 fd 40 b5 dc                               	vpmadd52huq zmm3,zmm16,zmm4
   847ed:	62 52 fd 40 b5 c8                               	vpmadd52huq zmm9,zmm16,zmm8
   847f3:	62 51 c5 48 d4 ff                               	vpaddq zmm15,zmm7,zmm15
   847f9:	62 f2 fd 40 b4 ce                               	vpmadd52luq zmm1,zmm16,zmm6
   847ff:	62 92 b5 40 b5 e9                               	vpmadd52huq zmm5,zmm25,zmm25
   84805:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   84809:	62 92 bd 40 b5 f9                               	vpmadd52huq zmm7,zmm24,zmm25
   8480f:	62 12 9d 40 b4 f9                               	vpmadd52luq zmm15,zmm28,zmm25
   84815:	62 d2 fd 40 b4 d8                               	vpmadd52luq zmm3,zmm16,zmm8
   8481b:	62 32 fd 40 b4 cc                               	vpmadd52luq zmm9,zmm16,zmm20
   84821:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   84827:	62 92 ad 40 b5 c9                               	vpmadd52huq zmm1,zmm26,zmm25
   8482d:	62 92 bd 40 b4 e9                               	vpmadd52luq zmm5,zmm24,zmm25
   84833:	62 a2 85 48 b4 c5                               	vpmadd52luq zmm16,zmm15,zmm21
   84839:	62 71 85 48 d4 fa                               	vpaddq zmm15,zmm15,zmm2
   8483f:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   84846:	62 92 9d 40 b5 d9                               	vpmadd52huq zmm3,zmm28,zmm25
   8484c:	62 12 a5 40 b5 c9                               	vpmadd52huq zmm9,zmm27,zmm25
   84852:	62 92 b5 40 b4 c9                               	vpmadd52luq zmm1,zmm25,zmm25
   84858:	62 32 fd 40 b5 fe                               	vpmadd52huq zmm15,zmm16,zmm22
   8485e:	62 b2 fd 40 b5 ec                               	vpmadd52huq zmm5,zmm16,zmm20
   84864:	62 f2 fd 40 b5 fe                               	vpmadd52huq zmm7,zmm16,zmm6
   8486a:	62 92 a5 40 b4 d9                               	vpmadd52luq zmm3,zmm27,zmm25
   84870:	62 12 ad 40 b4 c9                               	vpmadd52luq zmm9,zmm26,zmm25
   84876:	62 d2 fd 40 b5 c8                               	vpmadd52huq zmm1,zmm16,zmm8
   8487c:	62 f2 fd 40 b4 ee                               	vpmadd52luq zmm5,zmm16,zmm6
   84882:	62 92 b5 40 b5 f8                               	vpmadd52huq zmm7,zmm25,zmm24
   84888:	62 f2 fd 40 b4 dc                               	vpmadd52luq zmm3,zmm16,zmm4
   8488e:	62 72 fd 40 b5 cc                               	vpmadd52huq zmm9,zmm16,zmm4
   84894:	62 b2 fd 40 b4 cc                               	vpmadd52luq zmm1,zmm16,zmm20
   8489a:	62 92 ad 40 b5 e8                               	vpmadd52huq zmm5,zmm26,zmm24
   848a0:	62 92 bd 40 b4 f8                               	vpmadd52luq zmm7,zmm24,zmm24
   848a6:	62 d1 e5 48 d4 df                               	vpaddq zmm3,zmm3,zmm15
   848ac:	62 52 fd 40 b4 c8                               	vpmadd52luq zmm9,zmm16,zmm8
   848b2:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   848b8:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   848bd:	62 12 bd 40 b5 f8                               	vpmadd52huq zmm15,zmm24,zmm24
   848c3:	62 92 9d 40 b4 d8                               	vpmadd52luq zmm3,zmm28,zmm24
   848c9:	62 92 a5 40 b5 c8                               	vpmadd52huq zmm1,zmm27,zmm24
   848cf:	62 92 b5 40 b4 e8                               	vpmadd52luq zmm5,zmm25,zmm24
   848d5:	62 12 9d 40 b5 c8                               	vpmadd52huq zmm9,zmm28,zmm24
   848db:	62 a2 e5 48 b4 c5                               	vpmadd52luq zmm16,zmm3,zmm21
   848e1:	62 e1 fd 50 db 0d 5d 23 f8 ff                   	vpandq zmm17,zmm16,QWORD BCST [rip+0xfffffffffff8235d]        # 6c48 <GCC_except_table711+0x158>
   848eb:	62 92 ad 40 b4 c8                               	vpmadd52luq zmm1,zmm26,zmm24
   848f1:	62 f1 e5 58 d4 1d 4d 23 f8 ff                   	vpaddq zmm3,zmm3,QWORD BCST [rip+0xfffffffffff8234d]        # 6c48 <GCC_except_table711+0x158>
   848fb:	62 12 a5 40 b4 c8                               	vpmadd52luq zmm9,zmm27,zmm24
   84901:	62 b1 fd 40 73 f0 04                            	vpsllq zmm16,zmm16,0x4
   84908:	62 d2 f5 40 b5 e8                               	vpmadd52huq zmm5,zmm17,zmm8
   8490e:	62 b2 f5 40 b5 fc                               	vpmadd52huq zmm7,zmm17,zmm20
   84914:	62 f2 f5 40 b5 cc                               	vpmadd52huq zmm1,zmm17,zmm4
   8491a:	62 72 f5 40 b5 fe                               	vpmadd52huq zmm15,zmm17,zmm6
   84920:	62 72 f5 40 b4 cc                               	vpmadd52luq zmm9,zmm17,zmm4
   84926:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   8492d:	62 b2 fd 40 b5 de                               	vpmadd52huq zmm3,zmm16,zmm22
   84933:	62 b2 f5 40 b4 ec                               	vpmadd52luq zmm5,zmm17,zmm20
   84939:	62 f2 f5 40 b4 fe                               	vpmadd52luq zmm7,zmm17,zmm6
   8493f:	62 d2 f5 40 b4 c8                               	vpmadd52luq zmm1,zmm17,zmm8
   84945:	62 d1 fd 48 73 f1 04                            	vpsllq zmm0,zmm9,0x4
   8494c:	62 f1 fd 58 db 05 aa 23 f8 ff                   	vpandq zmm0,zmm0,QWORD BCST [rip+0xfffffffffff823aa]        # 6d00 <GCC_except_table711+0x210>
   84956:	c5 7c 28 05 c2 2f f8 ff                         	vmovaps ymm8,YMMWORD PTR [rip+0xfffffffffff82fc2]        # 7920 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x980>
   8495e:	62 f1 cd 48 73 f5 04                            	vpsllq zmm6,zmm5,0x4
   84965:	62 f1 cd 58 db 35 91 23 f8 ff                   	vpandq zmm6,zmm6,QWORD BCST [rip+0xfffffffffff82391]        # 6d00 <GCC_except_table711+0x210>
   8496f:	62 f1 dd 48 73 f1 04                            	vpsllq zmm4,zmm1,0x4
   84976:	62 f1 f5 48 73 d1 30                            	vpsrlq zmm1,zmm1,0x30
   8497d:	62 f1 fd 40 73 f7 04                            	vpsllq zmm16,zmm7,0x4
   84984:	62 f1 dd 58 db 25 72 23 f8 ff                   	vpandq zmm4,zmm4,QWORD BCST [rip+0xfffffffffff82372]        # 6d00 <GCC_except_table711+0x210>
   8498e:	62 f1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm5,0x30
   84995:	62 f1 fd 48 d4 c3                               	vpaddq zmm0,zmm0,zmm3
   8499b:	62 d1 e5 48 73 d1 30                            	vpsrlq zmm3,zmm9,0x30
   849a2:	62 f1 b5 48 73 d7 30                            	vpsrlq zmm9,zmm7,0x30
   849a9:	62 d1 c5 48 73 f7 04                            	vpsllq zmm7,zmm15,0x4
   849b0:	c5 7c 11 84 24 80 00 00 00                      	vmovups YMMWORD PTR [rsp+0x80],ymm8
   849b9:	4c 89 94 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],r10
   849c1:	62 72 fd 48 59 3d cd 22 f8 ff                   	vpbroadcastq zmm15,QWORD PTR [rip+0xfffffffffff822cd]        # 6c98 <GCC_except_table711+0x1a8>
   849cb:	62 f1 cd 48 d4 c9                               	vpaddq zmm1,zmm6,zmm1
   849d1:	62 f1 fd 50 db 35 25 23 f8 ff                   	vpandq zmm6,zmm16,QWORD BCST [rip+0xfffffffffff82325]        # 6d00 <GCC_except_table711+0x210>
   849db:	62 e2 fd 48 59 05 43 23 f8 ff                   	vpbroadcastq zmm16,QWORD PTR [rip+0xfffffffffff82343]        # 6d28 <GCC_except_table711+0x238>
   849e5:	62 f1 cd 48 d4 ed                               	vpaddq zmm5,zmm6,zmm5
   849eb:	62 d1 c5 48 d4 f1                               	vpaddq zmm6,zmm7,zmm9
   849f1:	62 f1 c5 48 73 d0 34                            	vpsrlq zmm7,zmm0,0x34
   849f8:	62 f1 fd 48 db c2                               	vpandq zmm0,zmm0,zmm2
   849fe:	62 f1 fd 48 fb 44 11 0a                         	vpsubq zmm0,zmm0,ZMMWORD PTR [rcx+rdx*1+0x280]
   84a06:	62 f1 c5 48 d4 db                               	vpaddq zmm3,zmm7,zmm3
   84a0c:	62 f1 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm4
   84a12:	62 f1 dd 48 73 d3 34                            	vpsrlq zmm4,zmm3,0x34
   84a19:	62 f1 e5 48 db da                               	vpandq zmm3,zmm3,zmm2
   84a1f:	62 f1 e5 48 fb 5c 11 0b                         	vpsubq zmm3,zmm3,ZMMWORD PTR [rcx+rdx*1+0x2c0]
   84a27:	62 f1 dd 48 d4 c9                               	vpaddq zmm1,zmm4,zmm1
   84a2d:	62 f1 dd 48 73 d1 34                            	vpsrlq zmm4,zmm1,0x34
   84a34:	62 f1 f5 48 db ca                               	vpandq zmm1,zmm1,zmm2
   84a3a:	62 f1 f5 48 fb 4c 11 0c                         	vpsubq zmm1,zmm1,ZMMWORD PTR [rcx+rdx*1+0x300]
   84a42:	62 f1 dd 48 d4 e5                               	vpaddq zmm4,zmm4,zmm5
   84a48:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   84a4f:	62 f1 dd 48 db e2                               	vpandq zmm4,zmm4,zmm2
   84a55:	62 f1 dd 48 fb 64 11 0d                         	vpsubq zmm4,zmm4,ZMMWORD PTR [rcx+rdx*1+0x340]
   84a5d:	62 f1 d5 48 d4 ee                               	vpaddq zmm5,zmm5,zmm6
   84a63:	62 f1 d5 48 fb 6c 11 0e                         	vpsubq zmm5,zmm5,ZMMWORD PTR [rcx+rdx*1+0x380]
   84a6b:	62 f1 fd 48 db fa                               	vpandq zmm7,zmm0,zmm2
   84a71:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   84a78:	62 f2 fd 48 59 74 24 14                         	vpbroadcastq zmm6,QWORD PTR [rsp+0xa0]
   84a80:	62 f1 e5 48 d4 c0                               	vpaddq zmm0,zmm3,zmm0
   84a86:	62 f1 fd 48 db da                               	vpandq zmm3,zmm0,zmm2
   84a8c:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   84a93:	62 f1 f5 48 d4 c0                               	vpaddq zmm0,zmm1,zmm0
   84a99:	62 f1 fd 48 db ca                               	vpandq zmm1,zmm0,zmm2
   84a9f:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   84aa6:	62 e1 f5 58 d4 4c 24 12                         	vpaddq zmm17,zmm1,QWORD BCST [rsp+0x90]
   84aae:	62 f1 dd 48 d4 c0                               	vpaddq zmm0,zmm4,zmm0
   84ab4:	62 f1 fd 48 db e2                               	vpandq zmm4,zmm0,zmm2
   84aba:	62 f1 fd 48 72 e0 34                            	vpsraq zmm0,zmm0,0x34
   84ac1:	62 71 dd 58 d4 4c 24 13                         	vpaddq zmm9,zmm4,QWORD BCST [rsp+0x98]
   84ac9:	62 f1 d5 48 d4 c0                               	vpaddq zmm0,zmm5,zmm0
   84acf:	62 b1 c5 48 d4 e8                               	vpaddq zmm5,zmm7,zmm16
   84ad5:	62 d3 fd 48 1e cf 01                            	vpcmpltuq k1,zmm0,zmm15
   84adc:	62 f1 fd 49 6f ef                               	vmovdqa64 zmm5{k1},zmm7
   84ae2:	62 f1 e5 58 d4 7c 24 11                         	vpaddq zmm7,zmm3,QWORD BCST [rsp+0x88]
   84aea:	62 61 d5 48 db ea                               	vpandq zmm29,zmm5,zmm2
   84af0:	c5 7c 11 84 24 80 00 00 00                      	vmovups YMMWORD PTR [rsp+0x80],ymm8
   84af9:	4c 89 94 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],r10
   84b01:	62 d1 fd 49 6f f7                               	vmovdqa64 zmm6{k1},zmm15
   84b07:	62 f1 cd 48 d4 c0                               	vpaddq zmm0,zmm6,zmm0
   84b0d:	62 71 fd 48 6f 44 11 01                         	vmovdqa64 zmm8,ZMMWORD PTR [rcx+rdx*1+0x40]
   84b15:	62 e1 fd 49 6f c9                               	vmovdqa64 zmm17{k1},zmm1
   84b1b:	62 71 fd 49 6f cc                               	vmovdqa64 zmm9{k1},zmm4
   84b21:	62 f1 dd 48 73 d5 34                            	vpsrlq zmm4,zmm5,0x34
   84b28:	62 f1 fd 49 6f fb                               	vmovdqa64 zmm7{k1},zmm3
   84b2e:	62 f1 dd 48 d4 e7                               	vpaddq zmm4,zmm4,zmm7
   84b34:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   84b3b:	62 61 dd 48 db fa                               	vpandq zmm31,zmm4,zmm2
   84b41:	62 b1 d5 48 d4 d9                               	vpaddq zmm3,zmm5,zmm17
   84b47:	62 f1 fd 48 6f 6c 11 03                         	vmovdqa64 zmm5,ZMMWORD PTR [rcx+rdx*1+0xc0]
   84b4f:	62 f1 dd 48 73 d3 34                            	vpsrlq zmm4,zmm3,0x34
   84b56:	62 d1 dd 48 d4 c9                               	vpaddq zmm1,zmm4,zmm9
   84b5c:	62 71 e5 48 db ca                               	vpandq zmm9,zmm3,zmm2
   84b62:	62 f1 fd 48 6f 64 11 02                         	vmovdqa64 zmm4,ZMMWORD PTR [rcx+rdx*1+0x80]
   84b6a:	62 f1 e5 48 73 d1 34                            	vpsrlq zmm3,zmm1,0x34
   84b71:	62 f1 f5 48 db f2                               	vpandq zmm6,zmm1,zmm2
   84b77:	62 f1 fd 48 6f 0c 11                            	vmovdqa64 zmm1,ZMMWORD PTR [rcx+rdx*1]
   84b7e:	62 61 e5 48 d4 f0                               	vpaddq zmm30,zmm3,zmm0
   84b84:	62 91 bd 48 fb df                               	vpsubq zmm3,zmm8,zmm31
   84b8a:	62 71 fd 48 6f 44 11 04                         	vmovdqa64 zmm8,ZMMWORD PTR [rcx+rdx*1+0x100]
   84b92:	62 f2 fd 48 59 44 24 14                         	vpbroadcastq zmm0,QWORD PTR [rsp+0xa0]
   84b9a:	62 e1 8d 40 db ca                               	vpandq zmm17,zmm30,zmm2
   84ba0:	62 e1 fd 48 7f 4c 24 11                         	vmovdqa64 ZMMWORD PTR [rsp+0x440],zmm17
   84ba8:	62 f1 d5 48 fb ee                               	vpsubq zmm5,zmm5,zmm6
   84bae:	62 d1 dd 48 fb e1                               	vpsubq zmm4,zmm4,zmm9
   84bb4:	62 91 f5 48 fb cd                               	vpsubq zmm1,zmm1,zmm29
   84bba:	62 f1 f5 48 db fa                               	vpandq zmm7,zmm1,zmm2
   84bc0:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   84bc7:	62 31 bd 48 fb c1                               	vpsubq zmm8,zmm8,zmm17
   84bcd:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   84bd3:	62 f1 e5 48 d4 c9                               	vpaddq zmm1,zmm3,zmm1
   84bd9:	62 f1 f5 48 db da                               	vpandq zmm3,zmm1,zmm2
   84bdf:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   84be6:	62 f1 dd 48 d4 c9                               	vpaddq zmm1,zmm4,zmm1
   84bec:	62 f1 f5 48 db e2                               	vpandq zmm4,zmm1,zmm2
   84bf2:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   84bf9:	62 f1 d5 48 d4 c9                               	vpaddq zmm1,zmm5,zmm1
   84bff:	62 f1 f5 48 db ea                               	vpandq zmm5,zmm1,zmm2
   84c05:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   84c0c:	62 f1 bd 48 d4 c9                               	vpaddq zmm1,zmm8,zmm1
   84c12:	62 31 c5 48 d4 c0                               	vpaddq zmm8,zmm7,zmm16
   84c18:	62 e1 dd 58 d4 44 24 12                         	vpaddq zmm16,zmm4,QWORD BCST [rsp+0x90]
   84c20:	62 d3 f5 48 1e cf 01                            	vpcmpltuq k1,zmm1,zmm15
   84c27:	62 71 fd 49 6f c7                               	vmovdqa64 zmm8{k1},zmm7
   84c2d:	62 f1 e5 58 d4 7c 24 11                         	vpaddq zmm7,zmm3,QWORD BCST [rsp+0x88]
   84c35:	62 d1 fd 49 6f c7                               	vmovdqa64 zmm0{k1},zmm15
   84c3b:	62 f1 fd 48 d4 c1                               	vpaddq zmm0,zmm0,zmm1
   84c41:	62 d1 f5 48 73 d0 34                            	vpsrlq zmm1,zmm8,0x34
   84c48:	62 e1 fd 49 6f c4                               	vmovdqa64 zmm16{k1},zmm4
   84c4e:	62 f1 d5 58 d4 64 24 13                         	vpaddq zmm4,zmm5,QWORD BCST [rsp+0x98]
   84c56:	62 e1 fe 28 7f 54 24 04                         	vmovdqu64 YMMWORD PTR [rsp+0x80],ymm18
   84c5e:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   84c66:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   84c6c:	62 f1 fd 49 6f fb                               	vmovdqa64 zmm7{k1},zmm3
   84c72:	62 71 f5 48 d4 ff                               	vpaddq zmm15,zmm1,zmm7
   84c78:	62 f1 bd 48 db ca                               	vpandq zmm1,zmm8,zmm2
   84c7e:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   84c82:	62 e2 a5 40 b5 d1                               	vpmadd52huq zmm18,zmm27,zmm1
   84c88:	62 e2 ad 40 b5 c9                               	vpmadd52huq zmm17,zmm26,zmm1
   84c8e:	62 f2 b5 40 b5 f9                               	vpmadd52huq zmm7,zmm25,zmm1
   84c94:	62 e2 ad 40 b4 d1                               	vpmadd52luq zmm18,zmm26,zmm1
   84c9a:	62 e2 b5 40 b4 c9                               	vpmadd52luq zmm17,zmm25,zmm1
   84ca0:	62 f2 bd 40 b4 f9                               	vpmadd52luq zmm7,zmm24,zmm1
   84ca6:	62 f1 fd 49 6f e5                               	vmovdqa64 zmm4{k1},zmm5
   84cac:	62 d1 d5 48 73 d7 34                            	vpsrlq zmm5,zmm15,0x34
   84cb3:	62 a1 d5 48 d4 c0                               	vpaddq zmm16,zmm5,zmm16
   84cb9:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   84cbd:	62 f2 9d 40 b5 e9                               	vpmadd52huq zmm5,zmm28,zmm1
   84cc3:	62 b1 e5 48 73 d0 34                            	vpsrlq zmm3,zmm16,0x34
   84cca:	62 71 e5 48 d4 c4                               	vpaddq zmm8,zmm3,zmm4
   84cd0:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   84cd4:	62 f2 bd 40 b5 e1                               	vpmadd52huq zmm4,zmm24,zmm1
   84cda:	62 d1 e5 48 73 d0 34                            	vpsrlq zmm3,zmm8,0x34
   84ce1:	62 f1 e5 48 d4 c0                               	vpaddq zmm0,zmm3,zmm0
   84ce7:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   84ceb:	62 f2 9d 40 b4 d9                               	vpmadd52luq zmm3,zmm28,zmm1
   84cf1:	62 f2 a5 40 b4 e9                               	vpmadd52luq zmm5,zmm27,zmm1
   84cf7:	62 f1 fd 48 7f 44 24 15                         	vmovdqa64 ZMMWORD PTR [rsp+0x540],zmm0
   84cff:	62 f2 fd 48 59 44 24 11                         	vpbroadcastq zmm0,QWORD PTR [rsp+0x88]
   84d07:	62 a2 e5 48 b4 dd                               	vpmadd52luq zmm19,zmm3,zmm21
   84d0d:	62 f1 e5 48 d4 ca                               	vpaddq zmm1,zmm3,zmm2
   84d13:	62 f2 fd 48 59 5c 24 14                         	vpbroadcastq zmm3,QWORD PTR [rsp+0xa0]
   84d1b:	62 f1 f5 48 73 d1 34                            	vpsrlq zmm1,zmm1,0x34
   84d22:	62 b2 e5 40 b5 ce                               	vpmadd52huq zmm1,zmm19,zmm22
   84d28:	62 f2 e5 40 b4 e8                               	vpmadd52luq zmm5,zmm19,zmm0
   84d2e:	62 e2 e5 40 b5 d0                               	vpmadd52huq zmm18,zmm19,zmm0
   84d34:	62 f2 e5 40 b5 e3                               	vpmadd52huq zmm4,zmm19,zmm3
   84d3a:	62 e1 d5 48 d4 e1                               	vpaddq zmm20,zmm5,zmm1
   84d40:	62 f2 fd 48 59 6c 24 12                         	vpbroadcastq zmm5,QWORD PTR [rsp+0x90]
   84d48:	62 f2 fd 48 59 4c 24 13                         	vpbroadcastq zmm1,QWORD PTR [rsp+0x98]
   84d50:	62 e2 e5 40 b5 cd                               	vpmadd52huq zmm17,zmm19,zmm5
   84d56:	62 f2 e5 40 b5 f9                               	vpmadd52huq zmm7,zmm19,zmm1
   84d5c:	62 e2 e5 40 b4 d5                               	vpmadd52luq zmm18,zmm19,zmm5
   84d62:	62 e2 e5 40 b4 c9                               	vpmadd52luq zmm17,zmm19,zmm1
   84d68:	62 f2 e5 40 b4 fb                               	vpmadd52luq zmm7,zmm19,zmm3
   84d6e:	62 e1 85 48 db da                               	vpandq zmm19,zmm15,zmm2
   84d74:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   84d79:	62 a2 9d 40 b5 d3                               	vpmadd52huq zmm18,zmm28,zmm19
   84d7f:	62 b2 b5 40 b5 e3                               	vpmadd52huq zmm4,zmm25,zmm19
   84d85:	62 a2 9d 40 b4 e3                               	vpmadd52luq zmm20,zmm28,zmm19
   84d8b:	62 32 bd 40 b5 fb                               	vpmadd52huq zmm15,zmm24,zmm19
   84d91:	62 a2 a5 40 b5 cb                               	vpmadd52huq zmm17,zmm27,zmm19
   84d97:	62 b2 ad 40 b5 fb                               	vpmadd52huq zmm7,zmm26,zmm19
   84d9d:	62 a2 a5 40 b4 d3                               	vpmadd52luq zmm18,zmm27,zmm19
   84da3:	62 b2 bd 40 b4 e3                               	vpmadd52luq zmm4,zmm24,zmm19
   84da9:	62 a2 ad 40 b4 cb                               	vpmadd52luq zmm17,zmm26,zmm19
   84daf:	62 b2 b5 40 b4 fb                               	vpmadd52luq zmm7,zmm25,zmm19
   84db5:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   84dbb:	62 a2 dd 40 b4 dd                               	vpmadd52luq zmm19,zmm20,zmm21
   84dc1:	62 e1 dd 40 d4 e2                               	vpaddq zmm20,zmm20,zmm2
   84dc7:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   84dce:	62 e2 e5 40 b5 c8                               	vpmadd52huq zmm17,zmm19,zmm0
   84dd4:	62 f2 e5 40 b5 fd                               	vpmadd52huq zmm7,zmm19,zmm5
   84dda:	62 f2 e5 40 b5 e1                               	vpmadd52huq zmm4,zmm19,zmm1
   84de0:	62 a2 e5 40 b5 e6                               	vpmadd52huq zmm20,zmm19,zmm22
   84de6:	62 e2 e5 40 b4 d0                               	vpmadd52luq zmm18,zmm19,zmm0
   84dec:	62 72 e5 40 b5 fb                               	vpmadd52huq zmm15,zmm19,zmm3
   84df2:	62 e2 e5 40 b4 cd                               	vpmadd52luq zmm17,zmm19,zmm5
   84df8:	62 f2 e5 40 b4 f9                               	vpmadd52luq zmm7,zmm19,zmm1
   84dfe:	62 f2 e5 40 b4 e3                               	vpmadd52luq zmm4,zmm19,zmm3
   84e04:	62 e1 fd 40 db da                               	vpandq zmm19,zmm16,zmm2
   84e0a:	62 a1 ed 40 d4 d4                               	vpaddq zmm18,zmm18,zmm20
   84e10:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   84e16:	62 32 b5 40 b5 fb                               	vpmadd52huq zmm15,zmm25,zmm19
   84e1c:	62 a2 9d 40 b4 d3                               	vpmadd52luq zmm18,zmm28,zmm19
   84e22:	62 a2 bd 40 b5 c3                               	vpmadd52huq zmm16,zmm24,zmm19
   84e28:	62 a2 9d 40 b5 cb                               	vpmadd52huq zmm17,zmm28,zmm19
   84e2e:	62 b2 a5 40 b5 fb                               	vpmadd52huq zmm7,zmm27,zmm19
   84e34:	62 b2 ad 40 b5 e3                               	vpmadd52huq zmm4,zmm26,zmm19
   84e3a:	62 32 bd 40 b4 fb                               	vpmadd52luq zmm15,zmm24,zmm19
   84e40:	62 a2 a5 40 b4 cb                               	vpmadd52luq zmm17,zmm27,zmm19
   84e46:	62 b2 ad 40 b4 fb                               	vpmadd52luq zmm7,zmm26,zmm19
   84e4c:	62 b2 b5 40 b4 e3                               	vpmadd52luq zmm4,zmm25,zmm19
   84e52:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   84e58:	62 a2 ed 40 b4 dd                               	vpmadd52luq zmm19,zmm18,zmm21
   84e5e:	62 e1 ed 40 d4 d2                               	vpaddq zmm18,zmm18,zmm2
   84e64:	62 b1 ed 40 73 d2 34                            	vpsrlq zmm18,zmm18,0x34
   84e6b:	62 f2 e5 40 b5 f8                               	vpmadd52huq zmm7,zmm19,zmm0
   84e71:	62 f2 e5 40 b5 e5                               	vpmadd52huq zmm4,zmm19,zmm5
   84e77:	62 72 e5 40 b5 f9                               	vpmadd52huq zmm15,zmm19,zmm1
   84e7d:	62 a2 e5 40 b5 d6                               	vpmadd52huq zmm18,zmm19,zmm22
   84e83:	62 e2 e5 40 b4 c8                               	vpmadd52luq zmm17,zmm19,zmm0
   84e89:	62 e2 e5 40 b5 c3                               	vpmadd52huq zmm16,zmm19,zmm3
   84e8f:	62 f2 e5 40 b4 fd                               	vpmadd52luq zmm7,zmm19,zmm5
   84e95:	62 f2 e5 40 b4 e1                               	vpmadd52luq zmm4,zmm19,zmm1
   84e9b:	62 72 e5 40 b4 fb                               	vpmadd52luq zmm15,zmm19,zmm3
   84ea1:	62 a1 f5 40 d4 ca                               	vpaddq zmm17,zmm17,zmm18
   84ea7:	62 e1 bd 48 db d2                               	vpandq zmm18,zmm8,zmm2
   84ead:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   84eb2:	62 a2 b5 40 b5 c2                               	vpmadd52huq zmm16,zmm25,zmm18
   84eb8:	62 a2 9d 40 b4 ca                               	vpmadd52luq zmm17,zmm28,zmm18
   84ebe:	62 32 bd 40 b5 c2                               	vpmadd52huq zmm8,zmm24,zmm18
   84ec4:	62 b2 9d 40 b5 fa                               	vpmadd52huq zmm7,zmm28,zmm18
   84eca:	62 b2 a5 40 b5 e2                               	vpmadd52huq zmm4,zmm27,zmm18
   84ed0:	62 32 ad 40 b5 fa                               	vpmadd52huq zmm15,zmm26,zmm18
   84ed6:	62 a2 bd 40 b4 c2                               	vpmadd52luq zmm16,zmm24,zmm18
   84edc:	62 b2 a5 40 b4 fa                               	vpmadd52luq zmm7,zmm27,zmm18
   84ee2:	62 b2 ad 40 b4 e2                               	vpmadd52luq zmm4,zmm26,zmm18
   84ee8:	62 32 b5 40 b4 fa                               	vpmadd52luq zmm15,zmm25,zmm18
   84eee:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   84ef4:	62 a2 f5 40 b4 d5                               	vpmadd52luq zmm18,zmm17,zmm21
   84efa:	62 e1 f5 40 d4 ca                               	vpaddq zmm17,zmm17,zmm2
   84f00:	62 b1 f5 40 73 d1 34                            	vpsrlq zmm17,zmm17,0x34
   84f07:	62 a2 ed 40 b5 ce                               	vpmadd52huq zmm17,zmm18,zmm22
   84f0d:	62 f2 ed 40 b4 f8                               	vpmadd52luq zmm7,zmm18,zmm0
   84f13:	62 f2 ed 40 b5 e0                               	vpmadd52huq zmm4,zmm18,zmm0
   84f19:	62 72 ed 40 b5 fd                               	vpmadd52huq zmm15,zmm18,zmm5
   84f1f:	62 e2 ed 40 b5 c1                               	vpmadd52huq zmm16,zmm18,zmm1
   84f25:	62 72 ed 40 b5 c3                               	vpmadd52huq zmm8,zmm18,zmm3
   84f2b:	62 b1 c5 48 d4 f9                               	vpaddq zmm7,zmm7,zmm17
   84f31:	62 e1 ed 48 db 4c 24 15                         	vpandq zmm17,zmm2,ZMMWORD PTR [rsp+0x540]
   84f39:	62 f2 ed 40 b4 e5                               	vpmadd52luq zmm4,zmm18,zmm5
   84f3f:	62 72 ed 40 b4 f9                               	vpmadd52luq zmm15,zmm18,zmm1
   84f45:	62 e2 ed 40 b4 c3                               	vpmadd52luq zmm16,zmm18,zmm3
   84f4b:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   84f51:	62 b2 9d 40 b5 e1                               	vpmadd52huq zmm4,zmm28,zmm17
   84f57:	62 32 a5 40 b5 f9                               	vpmadd52huq zmm15,zmm27,zmm17
   84f5d:	62 a2 ad 40 b5 c1                               	vpmadd52huq zmm16,zmm26,zmm17
   84f63:	62 32 b5 40 b5 c1                               	vpmadd52huq zmm8,zmm25,zmm17
   84f69:	62 b2 9d 40 b4 f9                               	vpmadd52luq zmm7,zmm28,zmm17
   84f6f:	62 a2 bd 40 b5 d1                               	vpmadd52huq zmm18,zmm24,zmm17
   84f75:	62 62 fd 48 59 25 81 1d f8 ff                   	vpbroadcastq zmm28,QWORD PTR [rip+0xfffffffffff81d81]        # 6d00 <GCC_except_table711+0x210>
   84f7f:	62 b2 a5 40 b4 e1                               	vpmadd52luq zmm4,zmm27,zmm17
   84f85:	62 21 fd 48 6f de                               	vmovdqa64 zmm27,zmm22
   84f8b:	62 e2 fd 48 59 35 b3 1c f8 ff                   	vpbroadcastq zmm22,QWORD PTR [rip+0xfffffffffff81cb3]        # 6c48 <GCC_except_table711+0x158>
   84f95:	62 32 ad 40 b4 f9                               	vpmadd52luq zmm15,zmm26,zmm17
   84f9b:	62 a2 b5 40 b4 c1                               	vpmadd52luq zmm16,zmm25,zmm17
   84fa1:	62 32 bd 40 b4 c1                               	vpmadd52luq zmm8,zmm24,zmm17
   84fa7:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   84fad:	62 a2 c5 48 b4 cd                               	vpmadd52luq zmm17,zmm7,zmm21
   84fb3:	62 a1 f5 40 db de                               	vpandq zmm19,zmm17,zmm22
   84fb9:	62 b1 c5 48 d4 fe                               	vpaddq zmm7,zmm7,zmm22
   84fbf:	62 b1 f5 40 73 f1 04                            	vpsllq zmm17,zmm17,0x4
   84fc6:	62 e2 e5 40 b5 c5                               	vpmadd52huq zmm16,zmm19,zmm5
   84fcc:	62 72 e5 40 b5 c1                               	vpmadd52huq zmm8,zmm19,zmm1
   84fd2:	62 72 e5 40 b5 f8                               	vpmadd52huq zmm15,zmm19,zmm0
   84fd8:	62 f2 e5 40 b4 e0                               	vpmadd52luq zmm4,zmm19,zmm0
   84fde:	62 f1 c5 48 73 d7 30                            	vpsrlq zmm7,zmm7,0x30
   84fe5:	62 e2 e5 40 b5 d3                               	vpmadd52huq zmm18,zmm19,zmm3
   84feb:	62 92 f5 40 b5 fb                               	vpmadd52huq zmm7,zmm17,zmm27
   84ff1:	62 e2 e5 40 b4 c1                               	vpmadd52luq zmm16,zmm19,zmm1
   84ff7:	62 72 e5 40 b4 c3                               	vpmadd52luq zmm8,zmm19,zmm3
   84ffd:	62 72 e5 40 b4 fd                               	vpmadd52luq zmm15,zmm19,zmm5
   85003:	62 f1 fd 48 73 f4 04                            	vpsllq zmm0,zmm4,0x4
   8500a:	62 f1 f5 48 73 d4 30                            	vpsrlq zmm1,zmm4,0x30
   85011:	62 e1 fd 28 6f 1d c5 27 f8 ff                   	vmovdqa64 ymm19,YMMWORD PTR [rip+0xfffffffffff827c5]        # 77e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x840>
   8501b:	62 91 fd 48 db c4                               	vpandq zmm0,zmm0,zmm28
   85021:	62 f1 fd 48 d4 c7                               	vpaddq zmm0,zmm0,zmm7
   85027:	62 d1 c5 48 73 f0 04                            	vpsllq zmm7,zmm8,0x4
   8502e:	62 b1 d5 48 73 f0 04                            	vpsllq zmm5,zmm16,0x4
   85035:	62 d1 e5 48 73 f7 04                            	vpsllq zmm3,zmm15,0x4
   8503c:	62 d1 dd 48 73 d7 30                            	vpsrlq zmm4,zmm15,0x30
   85043:	62 b1 85 48 73 d0 30                            	vpsrlq zmm15,zmm16,0x30
   8504a:	62 d1 bd 48 73 d0 30                            	vpsrlq zmm8,zmm8,0x30
   85051:	62 b1 fd 40 73 f2 04                            	vpsllq zmm16,zmm18,0x4
   85058:	62 91 d5 48 db ec                               	vpandq zmm5,zmm5,zmm28
   8505e:	62 91 c5 48 db fc                               	vpandq zmm7,zmm7,zmm28
   85064:	62 91 e5 48 db dc                               	vpandq zmm3,zmm3,zmm28
   8506a:	62 f1 d5 48 d4 e4                               	vpaddq zmm4,zmm5,zmm4
   85070:	62 d1 c5 48 d4 ef                               	vpaddq zmm5,zmm7,zmm15
   85076:	62 f1 85 48 73 d0 34                            	vpsrlq zmm15,zmm0,0x34
   8507d:	62 b1 bd 48 d4 f8                               	vpaddq zmm7,zmm8,zmm16
   85083:	62 f1 fd 48 db c2                               	vpandq zmm0,zmm0,zmm2
   85089:	62 f1 85 48 d4 c9                               	vpaddq zmm1,zmm15,zmm1
   8508f:	62 f1 f5 48 d4 cb                               	vpaddq zmm1,zmm1,zmm3
   85095:	62 f1 e5 48 73 d1 34                            	vpsrlq zmm3,zmm1,0x34
   8509c:	62 f1 f5 48 db ca                               	vpandq zmm1,zmm1,zmm2
   850a2:	62 f1 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm4
   850a8:	62 f1 dd 48 73 d3 34                            	vpsrlq zmm4,zmm3,0x34
   850af:	62 f1 e5 48 db da                               	vpandq zmm3,zmm3,zmm2
   850b5:	62 f1 dd 48 d4 e5                               	vpaddq zmm4,zmm4,zmm5
   850bb:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   850c2:	62 e1 dd 48 db c2                               	vpandq zmm16,zmm4,zmm2
   850c8:	62 f1 d5 48 d4 ef                               	vpaddq zmm5,zmm5,zmm7
   850ce:	c5 fc 28 3d 4a 28 f8 ff                         	vmovaps ymm7,YMMWORD PTR [rip+0xfffffffffff8284a]        # 7920 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x980>
   850d6:	c5 fc 11 bc 24 80 00 00 00                      	vmovups YMMWORD PTR [rsp+0x80],ymm7
   850df:	4c 89 94 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],r10
   850e7:	62 61 fd 48 fb 44 11 05                         	vpsubq zmm24,zmm0,ZMMWORD PTR [rcx+rdx*1+0x140]
   850ef:	62 e1 fd 40 fb 4c 11 08                         	vpsubq zmm17,zmm16,ZMMWORD PTR [rcx+rdx*1+0x200]
   850f7:	62 72 fd 48 59 7c 24 11                         	vpbroadcastq zmm15,QWORD PTR [rsp+0x88]
   850ff:	62 72 fd 48 59 44 24 12                         	vpbroadcastq zmm8,QWORD PTR [rsp+0x90]
   85107:	62 f2 fd 48 59 7c 24 13                         	vpbroadcastq zmm7,QWORD PTR [rsp+0x98]
   8510f:	62 f2 fd 48 59 64 24 14                         	vpbroadcastq zmm4,QWORD PTR [rsp+0xa0]
   85117:	62 61 f5 48 fb 4c 11 06                         	vpsubq zmm25,zmm1,ZMMWORD PTR [rcx+rdx*1+0x180]
   8511f:	62 e1 e5 48 fb 54 11 07                         	vpsubq zmm18,zmm3,ZMMWORD PTR [rcx+rdx*1+0x1c0]
   85127:	62 e1 d5 48 fb 44 11 09                         	vpsubq zmm16,zmm5,ZMMWORD PTR [rcx+rdx*1+0x240]
   8512f:	62 e1 fe 28 7f 5c 24 04                         	vmovdqu64 YMMWORD PTR [rsp+0x80],ymm19
   85137:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   8513f:	62 f1 fd 48 6f 44 24 11                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x440]
   85147:	62 f1 85 50 fb 6c 24 11                         	vpsubq zmm5,zmm31,QWORD BCST [rsp+0x88]
   8514f:	62 f1 b5 58 fb 5c 24 12                         	vpsubq zmm3,zmm9,QWORD BCST [rsp+0x90]
   85157:	62 f1 cd 58 fb 4c 24 13                         	vpsubq zmm1,zmm6,QWORD BCST [rsp+0x98]
   8515f:	62 f1 fd 58 fb 44 24 14                         	vpsubq zmm0,zmm0,QWORD BCST [rsp+0xa0]
   85167:	62 e1 fe 28 7f 5c 24 04                         	vmovdqu64 YMMWORD PTR [rsp+0x80],ymm19
   8516f:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   85177:	48 89 d0                                        	mov    rax,rdx
   8517a:	48 c1 e8 06                                     	shr    rax,0x6
   8517e:	48 0f af c6                                     	imul   rax,rsi
   85182:	4c 39 e8                                        	cmp    rax,r13
   85185:	0f 83 1b 0a 00 00                               	jae    85ba6 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66c6>
   8518b:	48 89 c7                                        	mov    rdi,rax
   8518e:	48 c1 e7 04                                     	shl    rdi,0x4
   85192:	41 8b 3c 38                                     	mov    edi,DWORD PTR [r8+rdi*1]
   85196:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8519c:	49 39 fc                                        	cmp    r12,rdi
   8519f:	0f 86 94 09 00 00                               	jbe    85b39 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6659>
   851a5:	62 91 dd 40 72 e0 34                            	vpsraq zmm20,zmm24,0x34
   851ac:	62 21 fd 48 6f d5                               	vmovdqa64 zmm26,zmm21
   851b2:	62 e2 fd 48 59 2d dc 1a f8 ff                   	vpbroadcastq zmm21,QWORD PTR [rip+0xfffffffffff81adc]        # 6c98 <GCC_except_table711+0x1a8>
   851bc:	62 e1 bd 40 db da                               	vpandq zmm19,zmm24,zmm2
   851c2:	48 c1 e7 06                                     	shl    rdi,0x6
   851c6:	62 a1 b5 40 d4 e4                               	vpaddq zmm20,zmm25,zmm20
   851cc:	62 61 e5 50 d4 0d 52 1b f8 ff                   	vpaddq zmm25,zmm19,QWORD BCST [rip+0xfffffffffff81b52]        # 6d28 <GCC_except_table711+0x238>
   851d6:	62 61 dd 40 db c2                               	vpandq zmm24,zmm20,zmm2
   851dc:	62 b1 dd 40 72 e4 34                            	vpsraq zmm20,zmm20,0x34
   851e3:	62 a1 ed 40 d4 d4                               	vpaddq zmm18,zmm18,zmm20
   851e9:	62 51 bd 40 d4 ff                               	vpaddq zmm15,zmm24,zmm15
   851ef:	62 e1 ed 40 db e2                               	vpandq zmm20,zmm18,zmm2
   851f5:	62 b1 ed 40 72 e2 34                            	vpsraq zmm18,zmm18,0x34
   851fc:	62 a1 f5 40 d4 ca                               	vpaddq zmm17,zmm17,zmm18
   85202:	62 51 dd 40 d4 c0                               	vpaddq zmm8,zmm20,zmm8
   85208:	62 e1 f5 40 db d2                               	vpandq zmm18,zmm17,zmm2
   8520e:	62 b1 f5 40 72 e1 34                            	vpsraq zmm17,zmm17,0x34
   85215:	62 a1 fd 40 d4 c1                               	vpaddq zmm16,zmm16,zmm17
   8521b:	62 f1 ed 40 d4 ff                               	vpaddq zmm7,zmm18,zmm7
   85221:	62 b3 fd 40 1e cd 01                            	vpcmpltuq k1,zmm16,zmm21
   85228:	62 11 fd 49 6f f8                               	vmovdqa64 zmm15{k1},zmm24
   8522e:	62 62 fd 48 59 05 e0 1a f8 ff                   	vpbroadcastq zmm24,QWORD PTR [rip+0xfffffffffff81ae0]        # 6d18 <GCC_except_table711+0x228>
   85238:	62 21 fd 49 6f cb                               	vmovdqa64 zmm25{k1},zmm19
   8523e:	62 b1 fd 49 6f fa                               	vmovdqa64 zmm7{k1},zmm18
   85244:	62 b1 fd 49 6f e5                               	vmovdqa64 zmm4{k1},zmm21
   8524a:	62 a1 dd 48 d4 d0                               	vpaddq zmm18,zmm4,zmm16
   85250:	62 91 dd 48 73 d1 34                            	vpsrlq zmm4,zmm25,0x34
   85257:	62 31 fd 49 6f c4                               	vmovdqa64 zmm8{k1},zmm20
   8525d:	62 51 dd 48 d4 ff                               	vpaddq zmm15,zmm4,zmm15
   85263:	62 f1 b5 40 db e2                               	vpandq zmm4,zmm25,zmm2
   85269:	62 d1 fd 40 73 d7 34                            	vpsrlq zmm16,zmm15,0x34
   85270:	62 51 fd 40 d4 c0                               	vpaddq zmm8,zmm16,zmm8
   85276:	62 e1 85 48 db c2                               	vpandq zmm16,zmm15,zmm2
   8527c:	62 d1 85 48 73 d0 34                            	vpsrlq zmm15,zmm8,0x34
   85283:	62 e1 bd 48 db ca                               	vpandq zmm17,zmm8,zmm2
   85289:	62 f1 85 48 d4 ff                               	vpaddq zmm7,zmm15,zmm7
   8528f:	62 f1 bd 48 73 d7 34                            	vpsrlq zmm8,zmm7,0x34
   85296:	62 31 bd 48 d4 fa                               	vpaddq zmm15,zmm8,zmm18
   8529c:	62 e1 c5 48 db d2                               	vpandq zmm18,zmm7,zmm2
   852a2:	62 81 95 40 d4 e0                               	vpaddq zmm20,zmm29,zmm24
   852a8:	62 e1 85 48 db da                               	vpandq zmm19,zmm15,zmm2
   852ae:	62 01 dd 48 d4 c0                               	vpaddq zmm24,zmm4,zmm24
   852b4:	62 e1 e5 50 fb 5c 24 14                         	vpsubq zmm19,zmm19,QWORD BCST [rsp+0xa0]
   852bc:	62 b1 bd 48 72 e4 34                            	vpsraq zmm8,zmm20,0x34
   852c3:	62 91 b5 40 72 e0 34                            	vpsraq zmm25,zmm24,0x34
   852ca:	62 d1 d5 48 d4 e8                               	vpaddq zmm5,zmm5,zmm8
   852d0:	62 f1 bd 48 72 e5 34                            	vpsraq zmm8,zmm5,0x34
   852d7:	62 d1 e5 48 d4 d8                               	vpaddq zmm3,zmm3,zmm8
   852dd:	62 f1 bd 48 72 e3 34                            	vpsraq zmm8,zmm3,0x34
   852e4:	62 d1 f5 48 d4 c8                               	vpaddq zmm1,zmm1,zmm8
   852ea:	62 f1 bd 48 72 e1 34                            	vpsraq zmm8,zmm1,0x34
   852f1:	62 d1 fd 48 d4 c0                               	vpaddq zmm0,zmm0,zmm8
   852f7:	62 b3 fd 48 1e cd 01                            	vpcmpltuq k1,zmm0,zmm21
   852fe:	62 61 d5 49 db fa                               	vpandq zmm31{k1},zmm5,zmm2
   85304:	62 61 dd 41 db ea                               	vpandq zmm29{k1},zmm20,zmm2
   8530a:	62 61 fd 49 6f f0                               	vmovdqa64 zmm30{k1},zmm0
   85310:	62 71 e5 49 db ca                               	vpandq zmm9{k1},zmm3,zmm2
   85316:	62 f1 f5 49 db f2                               	vpandq zmm6{k1},zmm1,zmm2
   8531c:	62 e1 ed 50 fb 64 24 13                         	vpsubq zmm20,zmm18,QWORD BCST [rsp+0x98]
   85324:	62 91 fd 48 73 f7 34                            	vpsllq zmm0,zmm31,0x34
   8532b:	62 d1 f5 48 73 f1 28                            	vpsllq zmm1,zmm9,0x28
   85332:	62 91 e5 48 73 d7 0c                            	vpsrlq zmm3,zmm31,0xc
   85339:	62 f1 bd 48 73 f6 1c                            	vpsllq zmm8,zmm6,0x1c
   85340:	62 91 fd 48 eb ed                               	vporq  zmm5,zmm0,zmm29
   85346:	62 61 fd 50 fb 6c 24 11                         	vpsubq zmm29,zmm16,QWORD BCST [rsp+0x88]
   8534e:	62 d1 fd 48 73 d1 18                            	vpsrlq zmm0,zmm9,0x18
   85355:	62 71 f5 50 fb 4c 24 12                         	vpsubq zmm9,zmm17,QWORD BCST [rsp+0x90]
   8535d:	62 f1 f5 48 eb fb                               	vporq  zmm7,zmm1,zmm3
   85363:	62 91 e5 48 73 f6 10                            	vpsllq zmm3,zmm30,0x10
   8536a:	62 71 bd 48 eb c0                               	vporq  zmm8,zmm8,zmm0
   85370:	62 f1 fd 48 73 d6 24                            	vpsrlq zmm0,zmm6,0x24
   85377:	62 f1 e5 48 eb f0                               	vporq  zmm6,zmm3,zmm0
   8537d:	62 f1 d5 48 6c df                               	vpunpcklqdq zmm3,zmm5,zmm7
   85383:	62 f1 bd 48 6c c6                               	vpunpcklqdq zmm0,zmm8,zmm6
   85389:	62 91 95 40 d4 c9                               	vpaddq zmm1,zmm29,zmm25
   8538f:	62 f1 b5 40 72 e1 34                            	vpsraq zmm25,zmm1,0x34
   85396:	62 11 b5 48 d4 c9                               	vpaddq zmm9,zmm9,zmm25
   8539c:	62 d1 b5 40 72 e1 34                            	vpsraq zmm25,zmm9,0x34
   853a3:	62 81 dd 40 d4 e1                               	vpaddq zmm20,zmm20,zmm25
   853a9:	62 b1 b5 40 72 e4 34                            	vpsraq zmm25,zmm20,0x34
   853b0:	62 81 e5 40 d4 d9                               	vpaddq zmm19,zmm19,zmm25
   853b6:	62 b3 e5 40 1e cd 01                            	vpcmpltuq k1,zmm19,zmm21
   853bd:	62 e1 f5 49 db c2                               	vpandq zmm16{k1},zmm1,zmm2
   853c3:	62 f1 bd 41 db e2                               	vpandq zmm4{k1},zmm24,zmm2
   853c9:	62 e1 b5 49 db ca                               	vpandq zmm17{k1},zmm9,zmm2
   853cf:	62 e1 dd 41 db d2                               	vpandq zmm18{k1},zmm20,zmm2
   853d5:	62 31 fd 49 6f fb                               	vmovdqa64 zmm15{k1},zmm19
   853db:	62 d1 85 48 73 f7 10                            	vpsllq zmm15,zmm15,0x10
   853e2:	62 b1 f5 48 73 f0 34                            	vpsllq zmm1,zmm16,0x34
   853e9:	62 71 f5 48 eb cc                               	vporq  zmm9,zmm1,zmm4
   853ef:	62 b1 f5 48 73 d0 0c                            	vpsrlq zmm1,zmm16,0xc
   853f6:	62 b1 fd 40 73 f1 28                            	vpsllq zmm16,zmm17,0x28
   853fd:	62 e1 fd 40 eb c1                               	vporq  zmm16,zmm16,zmm1
   85403:	62 b1 f5 48 73 d1 18                            	vpsrlq zmm1,zmm17,0x18
   8540a:	62 b1 f5 40 73 f2 1c                            	vpsllq zmm17,zmm18,0x1c
   85411:	62 e1 f5 40 eb c9                               	vporq  zmm17,zmm17,zmm1
   85417:	62 b1 f5 48 73 d2 24                            	vpsrlq zmm1,zmm18,0x24
   8541e:	62 b1 b5 48 6c e0                               	vpunpcklqdq zmm4,zmm9,zmm16
   85424:	62 e3 65 28 38 d0 01                            	vinserti32x4 ymm18,ymm3,xmm0,0x1
   8542b:	62 71 85 48 eb f9                               	vporq  zmm15,zmm15,zmm1
   85431:	62 c1 fe 28 7f 14 39                            	vmovdqu64 YMMWORD PTR [r9+rdi*1],ymm18
   85438:	62 d1 f5 40 6c cf                               	vpunpcklqdq zmm1,zmm17,zmm15
   8543e:	62 e3 5d 28 38 d9 01                            	vinserti32x4 ymm19,ymm4,xmm1,0x1
   85445:	62 c1 fe 28 7f 5c 39 01                         	vmovdqu64 YMMWORD PTR [r9+rdi*1+0x20],ymm19
   8544d:	48 89 c7                                        	mov    rdi,rax
   85450:	48 83 cf 01                                     	or     rdi,0x1
   85454:	4c 39 ef                                        	cmp    rdi,r13
   85457:	0f 83 46 07 00 00                               	jae    85ba3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66c3>
   8545d:	48 c1 e7 04                                     	shl    rdi,0x4
   85461:	41 8b 3c 38                                     	mov    edi,DWORD PTR [r8+rdi*1]
   85465:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8546b:	49 39 fc                                        	cmp    r12,rdi
   8546e:	0f 86 c5 06 00 00                               	jbe    85b39 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6659>
   85474:	62 f1 d5 48 6d ff                               	vpunpckhqdq zmm7,zmm5,zmm7
   8547a:	62 f1 bd 48 6d f6                               	vpunpckhqdq zmm6,zmm8,zmm6
   85480:	62 b1 b5 48 6d e8                               	vpunpckhqdq zmm5,zmm9,zmm16
   85486:	62 51 f5 40 6d cf                               	vpunpckhqdq zmm9,zmm17,zmm15
   8548c:	48 c1 e7 06                                     	shl    rdi,0x6
   85490:	c4 63 45 38 c6 01                               	vinserti128 ymm8,ymm7,xmm6,0x1
   85496:	c4 43 55 38 f9 01                               	vinserti128 ymm15,ymm5,xmm9,0x1
   8549c:	c4 41 7e 7f 04 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm8
   854a2:	c4 41 7e 7f 7c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm15
   854a9:	48 89 c7                                        	mov    rdi,rax
   854ac:	48 83 cf 02                                     	or     rdi,0x2
   854b0:	4c 39 ef                                        	cmp    rdi,r13
   854b3:	0f 83 ea 06 00 00                               	jae    85ba3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66c3>
   854b9:	48 c1 e7 04                                     	shl    rdi,0x4
   854bd:	41 8b 3c 38                                     	mov    edi,DWORD PTR [r8+rdi*1]
   854c1:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   854c7:	49 39 fc                                        	cmp    r12,rdi
   854ca:	0f 86 69 06 00 00                               	jbe    85b39 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6659>
   854d0:	c4 63 65 46 c0 31                               	vperm2i128 ymm8,ymm3,ymm0,0x31
   854d6:	c4 63 5d 46 f9 31                               	vperm2i128 ymm15,ymm4,ymm1,0x31
   854dc:	48 c1 e7 06                                     	shl    rdi,0x6
   854e0:	c4 41 7e 7f 04 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm8
   854e6:	c4 41 7e 7f 7c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm15
   854ed:	48 89 c7                                        	mov    rdi,rax
   854f0:	48 83 cf 03                                     	or     rdi,0x3
   854f4:	4c 39 ef                                        	cmp    rdi,r13
   854f7:	0f 83 a6 06 00 00                               	jae    85ba3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66c3>
   854fd:	48 c1 e7 04                                     	shl    rdi,0x4
   85501:	41 8b 3c 38                                     	mov    edi,DWORD PTR [r8+rdi*1]
   85505:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8550b:	49 39 fc                                        	cmp    r12,rdi
   8550e:	0f 86 25 06 00 00                               	jbe    85b39 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6659>
   85514:	c4 63 45 46 c6 31                               	vperm2i128 ymm8,ymm7,ymm6,0x31
   8551a:	c4 43 55 46 f9 31                               	vperm2i128 ymm15,ymm5,ymm9,0x31
   85520:	48 c1 e7 06                                     	shl    rdi,0x6
   85524:	c4 41 7e 7f 04 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm8
   8552a:	c4 41 7e 7f 7c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm15
   85531:	48 89 c7                                        	mov    rdi,rax
   85534:	48 83 cf 04                                     	or     rdi,0x4
   85538:	4c 39 ef                                        	cmp    rdi,r13
   8553b:	0f 83 62 06 00 00                               	jae    85ba3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66c3>
   85541:	48 c1 e7 04                                     	shl    rdi,0x4
   85545:	41 8b 3c 38                                     	mov    edi,DWORD PTR [r8+rdi*1]
   85549:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8554f:	49 39 fc                                        	cmp    r12,rdi
   85552:	0f 86 e1 05 00 00                               	jbe    85b39 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6659>
   85558:	62 d3 7d 48 39 c0 02                            	vextracti32x4 xmm8,zmm0,0x2
   8555f:	62 f3 fd 48 3b db 01                            	vextracti64x4 ymm3,zmm3,0x1
   85566:	62 d3 7d 48 39 cf 02                            	vextracti32x4 xmm15,zmm1,0x2
   8556d:	62 f3 fd 48 3b e4 01                            	vextracti64x4 ymm4,zmm4,0x1
   85574:	48 c1 e7 06                                     	shl    rdi,0x6
   85578:	c4 43 65 38 c0 01                               	vinserti128 ymm8,ymm3,xmm8,0x1
   8557e:	c4 43 5d 38 ff 01                               	vinserti128 ymm15,ymm4,xmm15,0x1
   85584:	c4 41 7e 7f 04 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm8
   8558a:	c4 41 7e 7f 7c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm15
   85591:	48 89 c7                                        	mov    rdi,rax
   85594:	48 83 cf 05                                     	or     rdi,0x5
   85598:	4c 39 ef                                        	cmp    rdi,r13
   8559b:	0f 83 02 06 00 00                               	jae    85ba3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66c3>
   855a1:	48 c1 e7 04                                     	shl    rdi,0x4
   855a5:	41 8b 3c 38                                     	mov    edi,DWORD PTR [r8+rdi*1]
   855a9:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   855af:	49 39 fc                                        	cmp    r12,rdi
   855b2:	0f 86 81 05 00 00                               	jbe    85b39 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6659>
   855b8:	62 d3 7d 48 39 f7 02                            	vextracti32x4 xmm15,zmm6,0x2
   855bf:	62 d3 fd 48 3b f8 01                            	vextracti64x4 ymm8,zmm7,0x1
   855c6:	62 33 7d 48 39 c8 02                            	vextracti32x4 xmm16,zmm9,0x2
   855cd:	62 93 fd 48 3b e8 01                            	vextracti64x4 ymm24,zmm5,0x1
   855d4:	48 c1 e7 06                                     	shl    rdi,0x6
   855d8:	c4 c3 3d 38 ff 01                               	vinserti128 ymm7,ymm8,xmm15,0x1
   855de:	62 b3 3d 20 38 e8 01                            	vinserti32x4 ymm5,ymm24,xmm16,0x1
   855e5:	c4 c1 7e 7f 3c 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm7
   855eb:	c4 c1 7e 7f 6c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm5
   855f2:	48 89 c7                                        	mov    rdi,rax
   855f5:	48 83 cf 06                                     	or     rdi,0x6
   855f9:	4c 39 ef                                        	cmp    rdi,r13
   855fc:	0f 83 a1 05 00 00                               	jae    85ba3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66c3>
   85602:	48 c1 e7 04                                     	shl    rdi,0x4
   85606:	41 8b 3c 38                                     	mov    edi,DWORD PTR [r8+rdi*1]
   8560a:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   85610:	49 39 fc                                        	cmp    r12,rdi
   85613:	0f 86 20 05 00 00                               	jbe    85b39 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6659>
   85619:	62 f3 fd 48 3b c0 01                            	vextracti64x4 ymm0,zmm0,0x1
   85620:	62 f3 fd 48 3b c9 01                            	vextracti64x4 ymm1,zmm1,0x1
   85627:	48 c1 e7 06                                     	shl    rdi,0x6
   8562b:	48 83 c8 07                                     	or     rax,0x7
   8562f:	c4 e3 65 46 c0 31                               	vperm2i128 ymm0,ymm3,ymm0,0x31
   85635:	c4 e3 5d 46 c9 31                               	vperm2i128 ymm1,ymm4,ymm1,0x31
   8563b:	c4 c1 7e 7f 04 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm0
   85641:	c4 c1 7e 7f 4c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm1
   85648:	4c 39 e8                                        	cmp    rax,r13
   8564b:	0f 83 55 05 00 00                               	jae    85ba6 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x66c6>
   85651:	48 c1 e0 04                                     	shl    rax,0x4
   85655:	41 8b 3c 00                                     	mov    edi,DWORD PTR [r8+rax*1]
   85659:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   8565f:	49 39 fc                                        	cmp    r12,rdi
   85662:	0f 86 d1 04 00 00                               	jbe    85b39 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6659>
   85668:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8566c:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   85670:	62 b2 a5 48 b5 e7                               	vpmadd52huq zmm4,zmm11,zmm23
   85676:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   8567a:	62 b2 95 48 b5 ef                               	vpmadd52huq zmm5,zmm13,zmm23
   85680:	c5 e1 ef db                                     	vpxor  xmm3,xmm3,xmm3
   85684:	62 b2 8d 48 b5 df                               	vpmadd52huq zmm3,zmm14,zmm23
   8568a:	62 b2 ad 48 b4 cf                               	vpmadd52luq zmm1,zmm10,zmm23
   85690:	62 e1 fd 48 6f 5c 24 1d                         	vmovdqa64 zmm19,ZMMWORD PTR [rsp+0x740]
   85698:	62 e1 fd 48 6f 54 24 09                         	vmovdqa64 zmm18,ZMMWORD PTR [rsp+0x240]
   856a0:	62 e1 fd 48 6f 4c 24 0a                         	vmovdqa64 zmm17,ZMMWORD PTR [rsp+0x280]
   856a8:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   856ac:	62 b2 ad 48 b5 ff                               	vpmadd52huq zmm7,zmm10,zmm23
   856b2:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   856b7:	62 e1 fd 48 6f 44 24 08                         	vmovdqa64 zmm16,ZMMWORD PTR [rsp+0x200]
   856bf:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   856c3:	62 b2 9d 48 b5 c7                               	vpmadd52huq zmm0,zmm12,zmm23
   856c9:	62 e1 fd 48 6f 64 24 0b                         	vmovdqa64 zmm20,ZMMWORD PTR [rsp+0x2c0]
   856d1:	48 c1 e7 06                                     	shl    rdi,0x6
   856d5:	48 81 c2 c0 f9 ff ff                            	add    rdx,0xfffffffffffff9c0
   856dc:	62 12 f5 48 b4 fa                               	vpmadd52luq zmm15,zmm1,zmm26
   856e2:	62 b2 95 48 b4 e7                               	vpmadd52luq zmm4,zmm13,zmm23
   856e8:	62 b2 8d 48 b4 ef                               	vpmadd52luq zmm5,zmm14,zmm23
   856ee:	62 b2 9d 48 b4 df                               	vpmadd52luq zmm3,zmm12,zmm23
   856f4:	62 b2 a5 48 b4 ff                               	vpmadd52luq zmm7,zmm11,zmm23
   856fa:	62 f1 f5 48 d4 ca                               	vpaddq zmm1,zmm1,zmm2
   85700:	62 f1 f5 48 73 d1 34                            	vpsrlq zmm1,zmm1,0x34
   85707:	62 b2 85 48 b5 e3                               	vpmadd52huq zmm4,zmm15,zmm19
   8570d:	62 b2 85 48 b5 ea                               	vpmadd52huq zmm5,zmm15,zmm18
   85713:	62 b2 85 48 b5 d9                               	vpmadd52huq zmm3,zmm15,zmm17
   85719:	62 92 85 48 b5 cb                               	vpmadd52huq zmm1,zmm15,zmm27
   8571f:	62 b2 85 48 b4 fb                               	vpmadd52luq zmm7,zmm15,zmm19
   85725:	62 b2 85 48 b5 c0                               	vpmadd52huq zmm0,zmm15,zmm16
   8572b:	62 b2 85 48 b4 e2                               	vpmadd52luq zmm4,zmm15,zmm18
   85731:	62 b2 85 48 b4 e9                               	vpmadd52luq zmm5,zmm15,zmm17
   85737:	62 b2 85 48 b4 d8                               	vpmadd52luq zmm3,zmm15,zmm16
   8573d:	62 71 fd 48 6f 7c 24 13                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x4c0]
   85745:	62 f1 c5 48 d4 f9                               	vpaddq zmm7,zmm7,zmm1
   8574b:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8574f:	62 d2 ad 48 b5 e7                               	vpmadd52huq zmm4,zmm10,zmm15
   85755:	62 d2 a5 48 b5 ef                               	vpmadd52huq zmm5,zmm11,zmm15
   8575b:	62 d2 95 48 b5 df                               	vpmadd52huq zmm3,zmm13,zmm15
   85761:	62 d2 8d 48 b5 c7                               	vpmadd52huq zmm0,zmm14,zmm15
   85767:	62 d2 ad 48 b4 ff                               	vpmadd52luq zmm7,zmm10,zmm15
   8576d:	62 d2 9d 48 b5 cf                               	vpmadd52huq zmm1,zmm12,zmm15
   85773:	62 d2 a5 48 b4 e7                               	vpmadd52luq zmm4,zmm11,zmm15
   85779:	62 d2 95 48 b4 ef                               	vpmadd52luq zmm5,zmm13,zmm15
   8577f:	62 d2 8d 48 b4 df                               	vpmadd52luq zmm3,zmm14,zmm15
   85785:	62 d2 9d 48 b4 c7                               	vpmadd52luq zmm0,zmm12,zmm15
   8578b:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   85790:	62 12 c5 48 b4 fa                               	vpmadd52luq zmm15,zmm7,zmm26
   85796:	62 f1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm2
   8579c:	62 f1 c5 48 73 d7 34                            	vpsrlq zmm7,zmm7,0x34
   857a3:	62 b2 85 48 b5 eb                               	vpmadd52huq zmm5,zmm15,zmm19
   857a9:	62 b2 85 48 b5 da                               	vpmadd52huq zmm3,zmm15,zmm18
   857af:	62 b2 85 48 b5 c1                               	vpmadd52huq zmm0,zmm15,zmm17
   857b5:	62 92 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm27
   857bb:	62 b2 85 48 b4 e3                               	vpmadd52luq zmm4,zmm15,zmm19
   857c1:	62 b2 85 48 b5 c8                               	vpmadd52huq zmm1,zmm15,zmm16
   857c7:	62 b2 85 48 b4 ea                               	vpmadd52luq zmm5,zmm15,zmm18
   857cd:	62 b2 85 48 b4 d9                               	vpmadd52luq zmm3,zmm15,zmm17
   857d3:	62 b2 85 48 b4 c0                               	vpmadd52luq zmm0,zmm15,zmm16
   857d9:	62 71 fd 48 6f 7c 24 0f                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x3c0]
   857e1:	62 f1 dd 48 d4 ff                               	vpaddq zmm7,zmm4,zmm7
   857e7:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   857eb:	62 d2 ad 48 b5 ef                               	vpmadd52huq zmm5,zmm10,zmm15
   857f1:	62 d2 a5 48 b5 df                               	vpmadd52huq zmm3,zmm11,zmm15
   857f7:	62 d2 95 48 b5 c7                               	vpmadd52huq zmm0,zmm13,zmm15
   857fd:	62 d2 8d 48 b5 cf                               	vpmadd52huq zmm1,zmm14,zmm15
   85803:	62 d2 ad 48 b4 ff                               	vpmadd52luq zmm7,zmm10,zmm15
   85809:	62 d2 9d 48 b5 e7                               	vpmadd52huq zmm4,zmm12,zmm15
   8580f:	62 d2 a5 48 b4 ef                               	vpmadd52luq zmm5,zmm11,zmm15
   85815:	62 d2 95 48 b4 df                               	vpmadd52luq zmm3,zmm13,zmm15
   8581b:	62 d2 8d 48 b4 c7                               	vpmadd52luq zmm0,zmm14,zmm15
   85821:	62 d2 9d 48 b4 cf                               	vpmadd52luq zmm1,zmm12,zmm15
   85827:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   8582c:	62 12 c5 48 b4 fa                               	vpmadd52luq zmm15,zmm7,zmm26
   85832:	62 f1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm2
   85838:	62 f1 c5 48 73 d7 34                            	vpsrlq zmm7,zmm7,0x34
   8583f:	62 b2 85 48 b5 db                               	vpmadd52huq zmm3,zmm15,zmm19
   85845:	62 b2 85 48 b5 c2                               	vpmadd52huq zmm0,zmm15,zmm18
   8584b:	62 b2 85 48 b5 c9                               	vpmadd52huq zmm1,zmm15,zmm17
   85851:	62 92 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm27
   85857:	62 b2 85 48 b4 eb                               	vpmadd52luq zmm5,zmm15,zmm19
   8585d:	62 b2 85 48 b5 e0                               	vpmadd52huq zmm4,zmm15,zmm16
   85863:	62 b2 85 48 b4 da                               	vpmadd52luq zmm3,zmm15,zmm18
   85869:	62 b2 85 48 b4 c1                               	vpmadd52luq zmm0,zmm15,zmm17
   8586f:	62 b2 85 48 b4 c8                               	vpmadd52luq zmm1,zmm15,zmm16
   85875:	62 71 fd 48 6f 7c 24 16                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x580]
   8587d:	62 f1 d5 48 d4 ff                               	vpaddq zmm7,zmm5,zmm7
   85883:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   85887:	62 d2 ad 48 b5 df                               	vpmadd52huq zmm3,zmm10,zmm15
   8588d:	62 d2 a5 48 b5 c7                               	vpmadd52huq zmm0,zmm11,zmm15
   85893:	62 d2 95 48 b5 cf                               	vpmadd52huq zmm1,zmm13,zmm15
   85899:	62 d2 8d 48 b5 e7                               	vpmadd52huq zmm4,zmm14,zmm15
   8589f:	62 d2 ad 48 b4 ff                               	vpmadd52luq zmm7,zmm10,zmm15
   858a5:	62 d2 9d 48 b5 ef                               	vpmadd52huq zmm5,zmm12,zmm15
   858ab:	62 d2 a5 48 b4 df                               	vpmadd52luq zmm3,zmm11,zmm15
   858b1:	62 d2 95 48 b4 c7                               	vpmadd52luq zmm0,zmm13,zmm15
   858b7:	62 d2 8d 48 b4 cf                               	vpmadd52luq zmm1,zmm14,zmm15
   858bd:	62 d2 9d 48 b4 e7                               	vpmadd52luq zmm4,zmm12,zmm15
   858c3:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   858c8:	62 12 c5 48 b4 fa                               	vpmadd52luq zmm15,zmm7,zmm26
   858ce:	62 f1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm2
   858d4:	62 f1 c5 48 73 d7 34                            	vpsrlq zmm7,zmm7,0x34
   858db:	62 b2 85 48 b5 e1                               	vpmadd52huq zmm4,zmm15,zmm17
   858e1:	62 b2 85 48 b5 ca                               	vpmadd52huq zmm1,zmm15,zmm18
   858e7:	62 92 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm27
   858ed:	62 b2 85 48 b4 db                               	vpmadd52luq zmm3,zmm15,zmm19
   858f3:	62 b2 85 48 b5 c3                               	vpmadd52huq zmm0,zmm15,zmm19
   858f9:	62 b2 85 48 b5 e8                               	vpmadd52huq zmm5,zmm15,zmm16
   858ff:	62 b2 85 48 b4 e0                               	vpmadd52luq zmm4,zmm15,zmm16
   85905:	62 b2 85 48 b4 c9                               	vpmadd52luq zmm1,zmm15,zmm17
   8590b:	62 f1 e5 48 d4 df                               	vpaddq zmm3,zmm3,zmm7
   85911:	62 b2 85 48 b4 c2                               	vpmadd52luq zmm0,zmm15,zmm18
   85917:	62 b2 8d 48 b5 ec                               	vpmadd52huq zmm5,zmm14,zmm20
   8591d:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   85921:	62 b2 9d 48 b5 fc                               	vpmadd52huq zmm7,zmm12,zmm20
   85927:	62 b2 ad 48 b4 dc                               	vpmadd52luq zmm3,zmm10,zmm20
   8592d:	62 b2 95 48 b5 e4                               	vpmadd52huq zmm4,zmm13,zmm20
   85933:	62 b2 a5 48 b5 cc                               	vpmadd52huq zmm1,zmm11,zmm20
   85939:	62 b2 ad 48 b5 c4                               	vpmadd52huq zmm0,zmm10,zmm20
   8593f:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   85944:	62 b2 9d 48 b4 ec                               	vpmadd52luq zmm5,zmm12,zmm20
   8594a:	62 12 e5 48 b4 d2                               	vpmadd52luq zmm10,zmm3,zmm26
   85950:	62 b1 e5 48 d4 de                               	vpaddq zmm3,zmm3,zmm22
   85956:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   8595d:	62 b2 8d 48 b4 e4                               	vpmadd52luq zmm4,zmm14,zmm20
   85963:	62 b2 95 48 b4 cc                               	vpmadd52luq zmm1,zmm13,zmm20
   85969:	62 b2 a5 48 b4 c4                               	vpmadd52luq zmm0,zmm11,zmm20
   8596f:	62 31 ad 48 db de                               	vpandq zmm11,zmm10,zmm22
   85975:	62 d1 ad 48 73 f2 04                            	vpsllq zmm10,zmm10,0x4
   8597c:	62 b2 a5 48 b5 e9                               	vpmadd52huq zmm5,zmm11,zmm17
   85982:	62 92 ad 48 b5 db                               	vpmadd52huq zmm3,zmm10,zmm27
   85988:	62 b2 a5 48 b5 f8                               	vpmadd52huq zmm7,zmm11,zmm16
   8598e:	62 b2 a5 48 b5 e2                               	vpmadd52huq zmm4,zmm11,zmm18
   85994:	62 b2 a5 48 b5 cb                               	vpmadd52huq zmm1,zmm11,zmm19
   8599a:	62 b2 a5 48 b4 c3                               	vpmadd52luq zmm0,zmm11,zmm19
   859a0:	62 b2 a5 48 b4 e8                               	vpmadd52luq zmm5,zmm11,zmm16
   859a6:	62 f1 c5 48 73 f7 04                            	vpsllq zmm7,zmm7,0x4
   859ad:	62 b2 a5 48 b4 e1                               	vpmadd52luq zmm4,zmm11,zmm17
   859b3:	62 b2 a5 48 b4 ca                               	vpmadd52luq zmm1,zmm11,zmm18
   859b9:	62 f1 ad 48 73 f0 04                            	vpsllq zmm10,zmm0,0x4
   859c0:	62 f1 fd 48 73 d0 30                            	vpsrlq zmm0,zmm0,0x30
   859c7:	62 11 ad 48 db d4                               	vpandq zmm10,zmm10,zmm28
   859cd:	62 f1 ad 48 d4 db                               	vpaddq zmm3,zmm10,zmm3
   859d3:	62 f1 9d 48 73 f5 04                            	vpsllq zmm12,zmm5,0x4
   859da:	62 f1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm5,0x30
   859e1:	62 f1 c5 48 d4 ed                               	vpaddq zmm5,zmm7,zmm5
   859e7:	62 f1 a5 48 73 f4 04                            	vpsllq zmm11,zmm4,0x4
   859ee:	62 f1 ad 48 73 f1 04                            	vpsllq zmm10,zmm1,0x4
   859f5:	62 f1 f5 48 73 d1 30                            	vpsrlq zmm1,zmm1,0x30
   859fc:	62 f1 dd 48 73 d4 30                            	vpsrlq zmm4,zmm4,0x30
   85a03:	62 11 a5 48 db dc                               	vpandq zmm11,zmm11,zmm28
   85a09:	62 11 ad 48 db d4                               	vpandq zmm10,zmm10,zmm28
   85a0f:	62 f1 a5 48 d4 c9                               	vpaddq zmm1,zmm11,zmm1
   85a15:	62 11 9d 48 db dc                               	vpandq zmm11,zmm12,zmm28
   85a1b:	62 f1 a5 48 d4 e4                               	vpaddq zmm4,zmm11,zmm4
   85a21:	62 f1 a5 48 73 d3 34                            	vpsrlq zmm11,zmm3,0x34
   85a28:	62 f1 a5 48 d4 c0                               	vpaddq zmm0,zmm11,zmm0
   85a2e:	62 d1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm10
   85a34:	62 71 e5 48 db d2                               	vpandq zmm10,zmm3,zmm2
   85a3a:	62 f1 e5 48 73 d0 34                            	vpsrlq zmm3,zmm0,0x34
   85a41:	62 71 fd 48 db da                               	vpandq zmm11,zmm0,zmm2
   85a47:	62 f1 e5 48 d4 c9                               	vpaddq zmm1,zmm3,zmm1
   85a4d:	62 f1 fd 48 73 d1 34                            	vpsrlq zmm0,zmm1,0x34
   85a54:	62 71 f5 48 db ea                               	vpandq zmm13,zmm1,zmm2
   85a5a:	62 f1 fd 48 d4 c4                               	vpaddq zmm0,zmm0,zmm4
   85a60:	62 f1 f5 48 73 d0 34                            	vpsrlq zmm1,zmm0,0x34
   85a67:	62 71 fd 48 db f2                               	vpandq zmm14,zmm0,zmm2
   85a6d:	62 f3 fd 48 3b f0 01                            	vextracti64x4 ymm0,zmm6,0x1
   85a74:	62 71 f5 48 d4 e5                               	vpaddq zmm12,zmm1,zmm5
   85a7a:	62 73 fd 48 3b c9 01                            	vextracti64x4 ymm1,zmm9,0x1
   85a81:	c4 e3 3d 46 c0 31                               	vperm2i128 ymm0,ymm8,ymm0,0x31
   85a87:	62 f3 bd 20 43 c9 03                            	vshufi64x2 ymm1,ymm24,ymm1,0x3
   85a8e:	c4 c1 7e 7f 04 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm0
   85a94:	c4 c1 7e 7f 4c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm1
   85a9b:	48 81 fa c0 f9 ff ff                            	cmp    rdx,0xfffffffffffff9c0
   85aa2:	0f 85 68 e6 ff ff                               	jne    84110 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x4c30>
   85aa8:	48 8d 65 d8                                     	lea    rsp,[rbp-0x28]
   85aac:	5b                                              	pop    rbx
   85aad:	41 5c                                           	pop    r12
   85aaf:	41 5d                                           	pop    r13
   85ab1:	41 5e                                           	pop    r14
   85ab3:	41 5f                                           	pop    r15
   85ab5:	5d                                              	pop    rbp
   85ab6:	c5 f8 77                                        	vzeroupper
   85ab9:	c3                                              	ret
   85aba:	48 8d 0d 27 48 01 00                            	lea    rcx,[rip+0x14827]        # 9a2e8 <__frame_dummy_init_array_entry+0x2498>
   85ac1:	4c 89 ea                                        	mov    rdx,r13
   85ac4:	c5 f8 77                                        	vzeroupper
   85ac7:	e8 a4 b4 fa ff                                  	call   30f70 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
   85acc:	48 8d 0d 6d 47 01 00                            	lea    rcx,[rip+0x1476d]        # 9a240 <__frame_dummy_init_array_entry+0x23f0>
   85ad3:	4c 89 ea                                        	mov    rdx,r13
   85ad6:	c5 f8 77                                        	vzeroupper
   85ad9:	e8 92 b4 fa ff                                  	call   30f70 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
   85ade:	4c 89 c7                                        	mov    rdi,r8
   85ae1:	48 89 de                                        	mov    rsi,rbx
   85ae4:	62 61 fd 48 7f 4c 24 08                         	vmovdqa64 ZMMWORD PTR [rsp+0x200],zmm25
   85aec:	62 e1 fd 48 7f 64 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm20
   85af4:	62 e1 fd 48 7f 6c 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm21
   85afc:	62 e1 fd 48 7f 74 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm22
   85b04:	c5 f8 77                                        	vzeroupper
   85b07:	e8 44 e0 00 00                                  	call   93b50 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
   85b0c:	62 e1 fd 48 6f 74 24 0b                         	vmovdqa64 zmm22,ZMMWORD PTR [rsp+0x2c0]
   85b14:	62 e1 fd 48 6f 6c 24 09                         	vmovdqa64 zmm21,ZMMWORD PTR [rsp+0x240]
   85b1c:	62 e1 fd 48 6f 64 24 0a                         	vmovdqa64 zmm20,ZMMWORD PTR [rsp+0x280]
   85b24:	62 61 fd 48 6f 4c 24 08                         	vmovdqa64 zmm25,ZMMWORD PTR [rsp+0x200]
   85b2c:	4c 8b 84 24 40 04 00 00                         	mov    r8,QWORD PTR [rsp+0x440]
   85b34:	e9 ac 9a ff ff                                  	jmp    7f5e5 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x105>
   85b39:	48 8d 15 30 47 01 00                            	lea    rdx,[rip+0x14730]        # 9a270 <__frame_dummy_init_array_entry+0x2420>
   85b40:	4c 89 e6                                        	mov    rsi,r12
   85b43:	c5 f8 77                                        	vzeroupper
   85b46:	e8 29 a7 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85b4b:	4c 89 c7                                        	mov    rdi,r8
   85b4e:	48 89 de                                        	mov    rsi,rbx
   85b51:	62 61 fd 48 7f 4c 24 08                         	vmovdqa64 ZMMWORD PTR [rsp+0x200],zmm25
   85b59:	62 e1 fd 48 7f 64 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm20
   85b61:	62 e1 fd 48 7f 6c 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm21
   85b69:	62 e1 fd 48 7f 74 24 0b                         	vmovdqa64 ZMMWORD PTR [rsp+0x2c0],zmm22
   85b71:	c5 f8 77                                        	vzeroupper
   85b74:	e8 d7 df 00 00                                  	call   93b50 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
   85b79:	62 e1 fd 48 6f 74 24 0b                         	vmovdqa64 zmm22,ZMMWORD PTR [rsp+0x2c0]
   85b81:	62 e1 fd 48 6f 6c 24 09                         	vmovdqa64 zmm21,ZMMWORD PTR [rsp+0x240]
   85b89:	62 e1 fd 48 6f 64 24 0a                         	vmovdqa64 zmm20,ZMMWORD PTR [rsp+0x280]
   85b91:	62 61 fd 48 6f 4c 24 08                         	vmovdqa64 zmm25,ZMMWORD PTR [rsp+0x200]
   85b99:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
   85b9e:	e9 6e ac ff ff                                  	jmp    80811 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x1331>
   85ba3:	48 89 f8                                        	mov    rax,rdi
   85ba6:	48 8d 15 ab 46 01 00                            	lea    rdx,[rip+0x146ab]        # 9a258 <__frame_dummy_init_array_entry+0x2408>
   85bad:	48 89 c7                                        	mov    rdi,rax
   85bb0:	4c 89 ee                                        	mov    rsi,r13
   85bb3:	c5 f8 77                                        	vzeroupper
   85bb6:	e8 b9 a6 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85bbb:	4c 89 d9                                        	mov    rcx,r11
   85bbe:	48 8b 74 24 10                                  	mov    rsi,QWORD PTR [rsp+0x10]
   85bc3:	48 8d 15 7e 47 01 00                            	lea    rdx,[rip+0x1477e]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   85bca:	48 89 cf                                        	mov    rdi,rcx
   85bcd:	c5 f8 77                                        	vzeroupper
   85bd0:	e8 9f a6 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85bd5:	4c 89 f1                                        	mov    rcx,r14
   85bd8:	48 8b 74 24 10                                  	mov    rsi,QWORD PTR [rsp+0x10]
   85bdd:	48 8d 15 64 47 01 00                            	lea    rdx,[rip+0x14764]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   85be4:	48 89 cf                                        	mov    rdi,rcx
   85be7:	c5 f8 77                                        	vzeroupper
   85bea:	e8 85 a6 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85bef:	48 89 f1                                        	mov    rcx,rsi
   85bf2:	48 8b 74 24 10                                  	mov    rsi,QWORD PTR [rsp+0x10]
   85bf7:	48 8d 15 4a 47 01 00                            	lea    rdx,[rip+0x1474a]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   85bfe:	48 89 cf                                        	mov    rdi,rcx
   85c01:	c5 f8 77                                        	vzeroupper
   85c04:	e8 6b a6 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85c09:	48 83 c7 03                                     	add    rdi,0x3
   85c0d:	eb 1b                                           	jmp    85c2a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x674a>
   85c0f:	48 ff c7                                        	inc    rdi
   85c12:	eb 16                                           	jmp    85c2a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x674a>
   85c14:	48 83 c7 02                                     	add    rdi,0x2
   85c18:	eb 10                                           	jmp    85c2a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x674a>
   85c1a:	48 83 c7 06                                     	add    rdi,0x6
   85c1e:	eb 0a                                           	jmp    85c2a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x674a>
   85c20:	48 83 c7 04                                     	add    rdi,0x4
   85c24:	eb 04                                           	jmp    85c2a <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x674a>
   85c26:	48 83 c7 05                                     	add    rdi,0x5
   85c2a:	48 89 f8                                        	mov    rax,rdi
   85c2d:	48 8d 15 fc 46 01 00                            	lea    rdx,[rip+0x146fc]        # 9a330 <__frame_dummy_init_array_entry+0x24e0>
   85c34:	48 89 c7                                        	mov    rdi,rax
   85c37:	4c 89 ee                                        	mov    rsi,r13
   85c3a:	c5 f8 77                                        	vzeroupper
   85c3d:	e8 32 a6 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85c42:	4c 89 d1                                        	mov    rcx,r10
   85c45:	48 8b 74 24 10                                  	mov    rsi,QWORD PTR [rsp+0x10]
   85c4a:	48 8d 15 f7 46 01 00                            	lea    rdx,[rip+0x146f7]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   85c51:	48 89 cf                                        	mov    rdi,rcx
   85c54:	c5 f8 77                                        	vzeroupper
   85c57:	e8 18 a6 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85c5c:	4c 89 e1                                        	mov    rcx,r12
   85c5f:	48 8b 74 24 10                                  	mov    rsi,QWORD PTR [rsp+0x10]
   85c64:	48 8d 15 dd 46 01 00                            	lea    rdx,[rip+0x146dd]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   85c6b:	48 89 cf                                        	mov    rdi,rcx
   85c6e:	c5 f8 77                                        	vzeroupper
   85c71:	e8 fe a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85c76:	48 89 d9                                        	mov    rcx,rbx
   85c79:	48 8b 74 24 10                                  	mov    rsi,QWORD PTR [rsp+0x10]
   85c7e:	48 8d 15 c3 46 01 00                            	lea    rdx,[rip+0x146c3]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   85c85:	48 89 cf                                        	mov    rdi,rcx
   85c88:	c5 f8 77                                        	vzeroupper
   85c8b:	e8 e4 a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85c90:	4c 89 f9                                        	mov    rcx,r15
   85c93:	48 8b 74 24 10                                  	mov    rsi,QWORD PTR [rsp+0x10]
   85c98:	48 8d 15 a9 46 01 00                            	lea    rdx,[rip+0x146a9]        # 9a348 <__frame_dummy_init_array_entry+0x24f8>
   85c9f:	48 89 cf                                        	mov    rdi,rcx
   85ca2:	c5 f8 77                                        	vzeroupper
   85ca5:	e8 ca a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85caa:	48 83 c7 06                                     	add    rdi,0x6
   85cae:	eb 33                                           	jmp    85ce3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6803>
   85cb0:	4c 89 c8                                        	mov    rax,r9
   85cb3:	48 8d 15 be 46 01 00                            	lea    rdx,[rip+0x146be]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   85cba:	48 89 c7                                        	mov    rdi,rax
   85cbd:	4c 89 e6                                        	mov    rsi,r12
   85cc0:	c5 f8 77                                        	vzeroupper
   85cc3:	e8 ac a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85cc8:	48 83 c7 05                                     	add    rdi,0x5
   85ccc:	eb 15                                           	jmp    85ce3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6803>
   85cce:	48 83 c7 04                                     	add    rdi,0x4
   85cd2:	eb 0f                                           	jmp    85ce3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6803>
   85cd4:	48 83 c7 03                                     	add    rdi,0x3
   85cd8:	eb 09                                           	jmp    85ce3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6803>
   85cda:	48 83 c7 02                                     	add    rdi,0x2
   85cde:	eb 03                                           	jmp    85ce3 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_+0x6803>
   85ce0:	48 ff c7                                        	inc    rdi
   85ce3:	48 89 f9                                        	mov    rcx,rdi
   85ce6:	48 8d 15 73 46 01 00                            	lea    rdx,[rip+0x14673]        # 9a360 <__frame_dummy_init_array_entry+0x2510>
   85ced:	48 89 cf                                        	mov    rdi,rcx
   85cf0:	4c 89 ee                                        	mov    rsi,r13
   85cf3:	c5 f8 77                                        	vzeroupper
   85cf6:	e8 79 a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85cfb:	4c 89 c0                                        	mov    rax,r8
   85cfe:	48 8d 15 73 46 01 00                            	lea    rdx,[rip+0x14673]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   85d05:	48 89 c7                                        	mov    rdi,rax
   85d08:	4c 89 e6                                        	mov    rsi,r12
   85d0b:	c5 f8 77                                        	vzeroupper
   85d0e:	e8 61 a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85d13:	48 89 d0                                        	mov    rax,rdx
   85d16:	48 8d 15 5b 46 01 00                            	lea    rdx,[rip+0x1465b]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   85d1d:	48 89 c7                                        	mov    rdi,rax
   85d20:	4c 89 e6                                        	mov    rsi,r12
   85d23:	c5 f8 77                                        	vzeroupper
   85d26:	e8 49 a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85d2b:	48 89 f0                                        	mov    rax,rsi
   85d2e:	48 8d 15 43 46 01 00                            	lea    rdx,[rip+0x14643]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   85d35:	48 89 c7                                        	mov    rdi,rax
   85d38:	4c 89 e6                                        	mov    rsi,r12
   85d3b:	c5 f8 77                                        	vzeroupper
   85d3e:	e8 31 a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85d43:	48 89 d8                                        	mov    rax,rbx
   85d46:	48 8d 15 2b 46 01 00                            	lea    rdx,[rip+0x1462b]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   85d4d:	48 89 c7                                        	mov    rdi,rax
   85d50:	4c 89 e6                                        	mov    rsi,r12
   85d53:	c5 f8 77                                        	vzeroupper
   85d56:	e8 19 a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85d5b:	4c 89 d8                                        	mov    rax,r11
   85d5e:	48 8d 15 13 46 01 00                            	lea    rdx,[rip+0x14613]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   85d65:	48 89 c7                                        	mov    rdi,rax
   85d68:	4c 89 e6                                        	mov    rsi,r12
   85d6b:	c5 f8 77                                        	vzeroupper
   85d6e:	e8 01 a5 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85d73:	4c 89 d0                                        	mov    rax,r10
   85d76:	48 8d 15 fb 45 01 00                            	lea    rdx,[rip+0x145fb]        # 9a378 <__frame_dummy_init_array_entry+0x2528>
   85d7d:	48 89 c7                                        	mov    rdi,rax
   85d80:	4c 89 e6                                        	mov    rsi,r12
   85d83:	c5 f8 77                                        	vzeroupper
   85d86:	e8 e9 a4 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85d8b:	48 8b 74 24 10                                  	mov    rsi,QWORD PTR [rsp+0x10]
   85d90:	48 8d 15 39 45 01 00                            	lea    rdx,[rip+0x14539]        # 9a2d0 <__frame_dummy_init_array_entry+0x2480>
   85d97:	c5 f8 77                                        	vzeroupper
   85d9a:	e8 d5 a4 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85d9f:	48 8d 15 12 45 01 00                            	lea    rdx,[rip+0x14512]        # 9a2b8 <__frame_dummy_init_array_entry+0x2468>
   85da6:	48 89 c7                                        	mov    rdi,rax
   85da9:	c5 f8 77                                        	vzeroupper
   85dac:	e8 c3 a4 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85db1:	48 8b b4 24 80 05 00 00                         	mov    rsi,QWORD PTR [rsp+0x580]
   85db9:	48 8d 15 e0 44 01 00                            	lea    rdx,[rip+0x144e0]        # 9a2a0 <__frame_dummy_init_array_entry+0x2450>
   85dc0:	c5 f8 77                                        	vzeroupper
   85dc3:	e8 ac a4 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   85dc8:	48 8d 15 b9 44 01 00                            	lea    rdx,[rip+0x144b9]        # 9a288 <__frame_dummy_init_array_entry+0x2438>
   85dcf:	48 89 c7                                        	mov    rdi,rax
   85dd2:	c5 f8 77                                        	vzeroupper
   85dd5:	e8 9a a4 fa ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
