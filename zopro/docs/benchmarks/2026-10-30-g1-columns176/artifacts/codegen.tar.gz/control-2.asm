
/home/ubuntu/src/zopro-perf-work/g1-columns176/consumers/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

000000000007acb0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe>:
   7acb0:	55                                              	push   rbp
   7acb1:	41 57                                           	push   r15
   7acb3:	41 56                                           	push   r14
   7acb5:	41 55                                           	push   r13
   7acb7:	41 54                                           	push   r12
   7acb9:	53                                              	push   rbx
   7acba:	48 81 ec 98 0b 00 00                            	sub    rsp,0xb98
   7acc1:	48 89 54 24 48                                  	mov    QWORD PTR [rsp+0x48],rdx
   7acc6:	48 89 b4 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],rsi
   7acce:	49 89 ff                                        	mov    r15,rdi
   7acd1:	48 8d 35 75 7a f9 ff                            	lea    rsi,[rip+0xfffffffffff97a75]        # 1274d <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x45cd>
   7acd8:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7ace0:	ba 15 00 00 00                                  	mov    edx,0x15
   7ace5:	4c 89 4c 24 10                                  	mov    QWORD PTR [rsp+0x10],r9
   7acea:	4d 89 c4                                        	mov    r12,r8
   7aced:	48 89 8c 24 90 00 00 00                         	mov    QWORD PTR [rsp+0x90],rcx
   7acf5:	e8 96 f2 ff ff                                  	call   79f90 <_RNvNtNtNtCs9k3SxhrAWiO_3std3sys3env4unix6getenv>
   7acfa:	4c 8b b4 24 80 01 00 00                         	mov    r14,QWORD PTR [rsp+0x180]
   7ad02:	49 83 fe ff                                     	cmp    r14,0xffffffffffffffff
   7ad06:	74 66                                           	je     7ad6e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xbe>
   7ad08:	48 8b 9c 24 88 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x188]
   7ad10:	48 8b 94 24 90 01 00 00                         	mov    rdx,QWORD PTR [rsp+0x190]
   7ad18:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7ad20:	48 89 de                                        	mov    rsi,rbx
   7ad23:	e8 48 60 fb ff                                  	call   30d70 <_RNvNtNtCsgxBkk5gSRhY_4core3str8converts9from_utf8>
   7ad28:	80 bc 24 80 01 00 00 00                         	cmp    BYTE PTR [rsp+0x180],0x0
   7ad30:	74 07                                           	je     7ad39 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x89>
   7ad32:	4d 85 f6                                        	test   r14,r14
   7ad35:	7f 07                                           	jg     7ad3e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x8e>
   7ad37:	eb 35                                           	jmp    7ad6e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xbe>
   7ad39:	4d 85 f6                                        	test   r14,r14
   7ad3c:	74 30                                           	je     7ad6e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xbe>
   7ad3e:	49 81 fe ff ff 01 00                            	cmp    r14,0x1ffff
   7ad45:	76 1e                                           	jbe    7ad65 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xb5>
   7ad47:	4c 89 f6                                        	mov    rsi,r14
   7ad4a:	48 ff c6                                        	inc    rsi
   7ad4d:	0f 88 d1 08 00 00                               	js     7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7ad53:	42 80 3c 33 01                                  	cmp    BYTE PTR [rbx+r14*1],0x1
   7ad58:	75 0b                                           	jne    7ad65 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xb5>
   7ad5a:	48 89 df                                        	mov    rdi,rbx
   7ad5d:	ff 15 1d fa 01 00                               	call   QWORD PTR [rip+0x1fa1d]        # 9a780 <munmap@GLIBC_2.2.5>
   7ad63:	eb 09                                           	jmp    7ad6e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xbe>
   7ad65:	48 89 df                                        	mov    rdi,rbx
   7ad68:	ff 15 1a fa 01 00                               	call   QWORD PTR [rip+0x1fa1a]        # 9a788 <free@GLIBC_2.2.5>
   7ad6e:	bf 01 00 02 00                                  	mov    edi,0x20001
   7ad73:	4c 89 64 24 38                                  	mov    QWORD PTR [rsp+0x38],r12
   7ad78:	4c 89 bc 24 78 01 00 00                         	mov    QWORD PTR [rsp+0x178],r15
   7ad80:	ff 15 1a fa 01 00                               	call   QWORD PTR [rip+0x1fa1a]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7ad86:	48 85 c0                                        	test   rax,rax
   7ad89:	0f 84 80 3f 00 00                               	je     7ed0f <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x405f>
   7ad8f:	48 89 c5                                        	mov    rbp,rax
   7ad92:	c6 80 00 00 02 00 00                            	mov    BYTE PTR [rax+0x20000],0x0
   7ad99:	b8 c0 01 00 00                                  	mov    eax,0x1c0
   7ad9e:	48 8d 94 24 a0 01 00 00                         	lea    rdx,[rsp+0x1a0]
   7ada6:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7adaa:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   7adb0:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7adb4:	c5 fe 7f 84 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
   7adbd:	48 8d 4c 05 00                                  	lea    rcx,[rbp+rax*1+0x0]
   7adc2:	62 f1 7c 48 10 4c 24 06                         	vmovups zmm1,ZMMWORD PTR [rsp+0x180]
   7adca:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7adce:	c5 fe 7f 84 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
   7add7:	62 f1 7c 48 10 5c 24 06                         	vmovups zmm3,ZMMWORD PTR [rsp+0x180]
   7addf:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ade3:	c5 fe 7f 84 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
   7adec:	62 f1 7c 48 10 54 24 06                         	vmovups zmm2,ZMMWORD PTR [rsp+0x180]
   7adf4:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7adf8:	c5 fe 7f 84 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
   7ae01:	62 f1 7c 48 11 4c 05 f9                         	vmovups ZMMWORD PTR [rbp+rax*1-0x1c0],zmm1
   7ae09:	62 f1 7c 48 11 5c 05 fa                         	vmovups ZMMWORD PTR [rbp+rax*1-0x180],zmm3
   7ae11:	62 f1 7c 48 10 5c 24 06                         	vmovups zmm3,ZMMWORD PTR [rsp+0x180]
   7ae19:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ae1d:	c5 fe 7f 84 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
   7ae26:	62 f1 7c 48 11 54 05 fb                         	vmovups ZMMWORD PTR [rbp+rax*1-0x140],zmm2
   7ae2e:	62 f1 7c 48 10 54 24 06                         	vmovups zmm2,ZMMWORD PTR [rsp+0x180]
   7ae36:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ae3a:	c5 fe 7f 84 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
   7ae43:	62 f1 7c 48 11 5c 05 fc                         	vmovups ZMMWORD PTR [rbp+rax*1-0x100],zmm3
   7ae4b:	62 f1 7c 48 10 5c 24 06                         	vmovups zmm3,ZMMWORD PTR [rsp+0x180]
   7ae53:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ae57:	c5 fe 7f 84 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
   7ae60:	62 f1 7c 48 11 54 05 fd                         	vmovups ZMMWORD PTR [rbp+rax*1-0xc0],zmm2
   7ae68:	62 f1 fe 48 6f 54 24 06                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x180]
   7ae70:	62 f1 7c 48 11 5c 05 fe                         	vmovups ZMMWORD PTR [rbp+rax*1-0x80],zmm3
   7ae78:	62 f1 fe 48 7f 54 05 ff                         	vmovdqu64 ZMMWORD PTR [rbp+rax*1-0x40],zmm2
   7ae80:	48 3d c0 ff 01 00                               	cmp    rax,0x1ffc0
   7ae86:	74 26                                           	je     7aeae <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1fe>
   7ae88:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7ae8c:	c5 fe 7f 84 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
   7ae95:	48 05 00 02 00 00                               	add    rax,0x200
   7ae9b:	62 f1 fe 48 6f 4c 24 06                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x180]
   7aea3:	62 f1 fe 48 7f 09                               	vmovdqu64 ZMMWORD PTR [rcx],zmm1
   7aea9:	e9 02 ff ff ff                                  	jmp    7adb0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x100>
   7aeae:	bf 00 20 00 00                                  	mov    edi,0x2000
   7aeb3:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7aeb7:	62 f1 fe 48 7f 01                               	vmovdqu64 ZMMWORD PTR [rcx],zmm0
   7aebd:	c5 f8 77                                        	vzeroupper
   7aec0:	ff 15 da f8 01 00                               	call   QWORD PTR [rip+0x1f8da]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7aec6:	48 85 c0                                        	test   rax,rax
   7aec9:	0f 84 4f 3e 00 00                               	je     7ed1e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x406e>
   7aecf:	bf 00 01 00 00                                  	mov    edi,0x100
   7aed4:	be 01 00 00 00                                  	mov    esi,0x1
   7aed9:	49 89 c6                                        	mov    r14,rax
   7aedc:	ff 15 ee f8 01 00                               	call   QWORD PTR [rip+0x1f8ee]        # 9a7d0 <calloc@GLIBC_2.2.5>
   7aee2:	ba 00 20 00 00                                  	mov    edx,0x2000
   7aee7:	be ff 00 00 00                                  	mov    esi,0xff
   7aeec:	4c 89 f7                                        	mov    rdi,r14
   7aeef:	49 89 c7                                        	mov    r15,rax
   7aef2:	4c 89 74 24 08                                  	mov    QWORD PTR [rsp+0x8],r14
   7aef7:	ff 15 1b f9 01 00                               	call   QWORD PTR [rip+0x1f91b]        # 9a818 <memset@GLIBC_2.2.5>
   7aefd:	4c 89 7c 24 40                                  	mov    QWORD PTR [rsp+0x40],r15
   7af02:	4d 85 ff                                        	test   r15,r15
   7af05:	0f 84 27 3e 00 00                               	je     7ed32 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4082>
   7af0b:	bf 80 0c 00 00                                  	mov    edi,0xc80
   7af10:	ff 15 8a f8 01 00                               	call   QWORD PTR [rip+0x1f88a]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7af16:	48 89 44 24 18                                  	mov    QWORD PTR [rsp+0x18],rax
   7af1b:	48 85 c0                                        	test   rax,rax
   7af1e:	0f 84 1f 3e 00 00                               	je     7ed43 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4093>
   7af24:	bf 80 0c 00 00                                  	mov    edi,0xc80
   7af29:	ff 15 71 f8 01 00                               	call   QWORD PTR [rip+0x1f871]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7af2f:	48 89 44 24 50                                  	mov    QWORD PTR [rsp+0x50],rax
   7af34:	48 85 c0                                        	test   rax,rax
   7af37:	0f 84 17 3e 00 00                               	je     7ed54 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x40a4>
   7af3d:	48 8d 35 1e 79 f9 ff                            	lea    rsi,[rip+0xfffffffffff9791e]        # 12862 <_RNvNtNtNtCsgxBkk5gSRhY_4core7unicode12unicode_data11white_space14WHITESPACE_MAP+0x100>
   7af44:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7af4c:	ba 18 00 00 00                                  	mov    edx,0x18
   7af51:	e8 3a f0 ff ff                                  	call   79f90 <_RNvNtNtNtCs9k3SxhrAWiO_3std3sys3env4unix6getenv>
   7af56:	4c 8b a4 24 80 01 00 00                         	mov    r12,QWORD PTR [rsp+0x180]
   7af5e:	49 83 fc ff                                     	cmp    r12,0xffffffffffffffff
   7af62:	74 39                                           	je     7af9d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x2ed>
   7af64:	4c 8b b4 24 88 01 00 00                         	mov    r14,QWORD PTR [rsp+0x188]
   7af6c:	4c 8b bc 24 90 01 00 00                         	mov    r15,QWORD PTR [rsp+0x190]
   7af74:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7af7c:	4c 89 f6                                        	mov    rsi,r14
   7af7f:	4c 89 fa                                        	mov    rdx,r15
   7af82:	e8 e9 5d fb ff                                  	call   30d70 <_RNvNtNtCsgxBkk5gSRhY_4core3str8converts9from_utf8>
   7af87:	80 bc 24 80 01 00 00 00                         	cmp    BYTE PTR [rsp+0x180],0x0
   7af8f:	74 13                                           	je     7afa4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x2f4>
   7af91:	c6 44 24 28 01                                  	mov    BYTE PTR [rsp+0x28],0x1
   7af96:	4d 85 e4                                        	test   r12,r12
   7af99:	7f 22                                           	jg     7afbd <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x30d>
   7af9b:	eb 50                                           	jmp    7afed <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x33d>
   7af9d:	c6 44 24 28 01                                  	mov    BYTE PTR [rsp+0x28],0x1
   7afa2:	eb 49                                           	jmp    7afed <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x33d>
   7afa4:	c6 44 24 28 01                                  	mov    BYTE PTR [rsp+0x28],0x1
   7afa9:	49 83 ff 01                                     	cmp    r15,0x1
   7afad:	75 09                                           	jne    7afb8 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x308>
   7afaf:	41 80 3e 30                                     	cmp    BYTE PTR [r14],0x30
   7afb3:	0f 95 44 24 28                                  	setne  BYTE PTR [rsp+0x28]
   7afb8:	4d 85 e4                                        	test   r12,r12
   7afbb:	74 30                                           	je     7afed <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x33d>
   7afbd:	49 81 fc ff ff 01 00                            	cmp    r12,0x1ffff
   7afc4:	76 1e                                           	jbe    7afe4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x334>
   7afc6:	4c 89 e6                                        	mov    rsi,r12
   7afc9:	48 ff c6                                        	inc    rsi
   7afcc:	0f 88 52 06 00 00                               	js     7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7afd2:	43 80 3c 26 01                                  	cmp    BYTE PTR [r14+r12*1],0x1
   7afd7:	75 0b                                           	jne    7afe4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x334>
   7afd9:	4c 89 f7                                        	mov    rdi,r14
   7afdc:	ff 15 9e f7 01 00                               	call   QWORD PTR [rip+0x1f79e]        # 9a780 <munmap@GLIBC_2.2.5>
   7afe2:	eb 09                                           	jmp    7afed <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x33d>
   7afe4:	4c 89 f7                                        	mov    rdi,r14
   7afe7:	ff 15 9b f7 01 00                               	call   QWORD PTR [rip+0x1f79b]        # 9a788 <free@GLIBC_2.2.5>
   7afed:	48 8d 35 86 78 f9 ff                            	lea    rsi,[rip+0xfffffffffff97886]        # 1287a <_RNvNtNtNtCsgxBkk5gSRhY_4core7unicode12unicode_data11white_space14WHITESPACE_MAP+0x118>
   7aff4:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7affc:	ba 19 00 00 00                                  	mov    edx,0x19
   7b001:	e8 8a ef ff ff                                  	call   79f90 <_RNvNtNtNtCs9k3SxhrAWiO_3std3sys3env4unix6getenv>
   7b006:	4c 8b a4 24 80 01 00 00                         	mov    r12,QWORD PTR [rsp+0x180]
   7b00e:	49 83 fc ff                                     	cmp    r12,0xffffffffffffffff
   7b012:	74 39                                           	je     7b04d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x39d>
   7b014:	4c 8b b4 24 88 01 00 00                         	mov    r14,QWORD PTR [rsp+0x188]
   7b01c:	4c 8b bc 24 90 01 00 00                         	mov    r15,QWORD PTR [rsp+0x190]
   7b024:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7b02c:	4c 89 f6                                        	mov    rsi,r14
   7b02f:	4c 89 fa                                        	mov    rdx,r15
   7b032:	e8 39 5d fb ff                                  	call   30d70 <_RNvNtNtCsgxBkk5gSRhY_4core3str8converts9from_utf8>
   7b037:	80 bc 24 80 01 00 00 00                         	cmp    BYTE PTR [rsp+0x180],0x0
   7b03f:	74 13                                           	je     7b054 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3a4>
   7b041:	c6 44 24 20 01                                  	mov    BYTE PTR [rsp+0x20],0x1
   7b046:	4d 85 e4                                        	test   r12,r12
   7b049:	7f 22                                           	jg     7b06d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3bd>
   7b04b:	eb 50                                           	jmp    7b09d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ed>
   7b04d:	c6 44 24 20 01                                  	mov    BYTE PTR [rsp+0x20],0x1
   7b052:	eb 49                                           	jmp    7b09d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ed>
   7b054:	c6 44 24 20 01                                  	mov    BYTE PTR [rsp+0x20],0x1
   7b059:	49 83 ff 01                                     	cmp    r15,0x1
   7b05d:	75 09                                           	jne    7b068 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3b8>
   7b05f:	41 80 3e 30                                     	cmp    BYTE PTR [r14],0x30
   7b063:	0f 95 44 24 20                                  	setne  BYTE PTR [rsp+0x20]
   7b068:	4d 85 e4                                        	test   r12,r12
   7b06b:	74 30                                           	je     7b09d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ed>
   7b06d:	49 81 fc ff ff 01 00                            	cmp    r12,0x1ffff
   7b074:	76 1e                                           	jbe    7b094 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3e4>
   7b076:	4c 89 e6                                        	mov    rsi,r12
   7b079:	48 ff c6                                        	inc    rsi
   7b07c:	0f 88 a2 05 00 00                               	js     7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7b082:	43 80 3c 26 01                                  	cmp    BYTE PTR [r14+r12*1],0x1
   7b087:	75 0b                                           	jne    7b094 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3e4>
   7b089:	4c 89 f7                                        	mov    rdi,r14
   7b08c:	ff 15 ee f6 01 00                               	call   QWORD PTR [rip+0x1f6ee]        # 9a780 <munmap@GLIBC_2.2.5>
   7b092:	eb 09                                           	jmp    7b09d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ed>
   7b094:	4c 89 f7                                        	mov    rdi,r14
   7b097:	ff 15 eb f6 01 00                               	call   QWORD PTR [rip+0x1f6eb]        # 9a788 <free@GLIBC_2.2.5>
   7b09d:	48 8d 35 ef 77 f9 ff                            	lea    rsi,[rip+0xfffffffffff977ef]        # 12893 <_RNvNtNtNtCsgxBkk5gSRhY_4core7unicode12unicode_data11white_space14WHITESPACE_MAP+0x131>
   7b0a4:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7b0ac:	ba 1a 00 00 00                                  	mov    edx,0x1a
   7b0b1:	e8 da ee ff ff                                  	call   79f90 <_RNvNtNtNtCs9k3SxhrAWiO_3std3sys3env4unix6getenv>
   7b0b6:	4c 8b a4 24 80 01 00 00                         	mov    r12,QWORD PTR [rsp+0x180]
   7b0be:	49 83 fc ff                                     	cmp    r12,0xffffffffffffffff
   7b0c2:	74 62                                           	je     7b126 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x476>
   7b0c4:	4c 8b b4 24 88 01 00 00                         	mov    r14,QWORD PTR [rsp+0x188]
   7b0cc:	4c 8b ac 24 90 01 00 00                         	mov    r13,QWORD PTR [rsp+0x190]
   7b0d4:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7b0dc:	4c 89 f6                                        	mov    rsi,r14
   7b0df:	4c 89 ea                                        	mov    rdx,r13
   7b0e2:	e8 89 5c fb ff                                  	call   30d70 <_RNvNtNtCsgxBkk5gSRhY_4core3str8converts9from_utf8>
   7b0e7:	83 bc 24 80 01 00 00 01                         	cmp    DWORD PTR [rsp+0x180],0x1
   7b0ef:	75 3c                                           	jne    7b12d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x47d>
   7b0f1:	b3 02                                           	mov    bl,0x2
   7b0f3:	4d 85 e4                                        	test   r12,r12
   7b0f6:	0f 8e 3f 01 00 00                               	jle    7b23b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x58b>
   7b0fc:	49 81 fc ff ff 01 00                            	cmp    r12,0x1ffff
   7b103:	76 46                                           	jbe    7b14b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x49b>
   7b105:	4c 89 e6                                        	mov    rsi,r12
   7b108:	48 ff c6                                        	inc    rsi
   7b10b:	0f 88 13 05 00 00                               	js     7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7b111:	43 80 3c 26 01                                  	cmp    BYTE PTR [r14+r12*1],0x1
   7b116:	75 33                                           	jne    7b14b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x49b>
   7b118:	4c 89 f7                                        	mov    rdi,r14
   7b11b:	ff 15 5f f6 01 00                               	call   QWORD PTR [rip+0x1f65f]        # 9a780 <munmap@GLIBC_2.2.5>
   7b121:	e9 15 01 00 00                                  	jmp    7b23b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x58b>
   7b126:	b3 02                                           	mov    bl,0x2
   7b128:	e9 0e 01 00 00                                  	jmp    7b23b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x58b>
   7b12d:	4d 85 ed                                        	test   r13,r13
   7b130:	74 60                                           	je     7b192 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e2>
   7b132:	49 83 fd 01                                     	cmp    r13,0x1
   7b136:	75 21                                           	jne    7b159 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4a9>
   7b138:	41 0f b6 06                                     	movzx  eax,BYTE PTR [r14]
   7b13c:	45 31 c0                                        	xor    r8d,r8d
   7b13f:	83 f8 2b                                        	cmp    eax,0x2b
   7b142:	74 51                                           	je     7b195 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e5>
   7b144:	83 f8 2d                                        	cmp    eax,0x2d
   7b147:	74 4c                                           	je     7b195 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e5>
   7b149:	eb 12                                           	jmp    7b15d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4ad>
   7b14b:	4c 89 f7                                        	mov    rdi,r14
   7b14e:	ff 15 34 f6 01 00                               	call   QWORD PTR [rip+0x1f634]        # 9a788 <free@GLIBC_2.2.5>
   7b154:	e9 e2 00 00 00                                  	jmp    7b23b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x58b>
   7b159:	41 0f b6 06                                     	movzx  eax,BYTE PTR [r14]
   7b15d:	31 d2                                           	xor    edx,edx
   7b15f:	3c 2b                                           	cmp    al,0x2b
   7b161:	4c 89 e8                                        	mov    rax,r13
   7b164:	0f 94 c2                                        	sete   dl
   7b167:	48 29 d0                                        	sub    rax,rdx
   7b16a:	49 8d 0c 16                                     	lea    rcx,[r14+rdx*1]
   7b16e:	48 83 f8 03                                     	cmp    rax,0x3
   7b172:	73 5c                                           	jae    7b1d0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x520>
   7b174:	41 b0 01                                        	mov    r8b,0x1
   7b177:	48 85 c0                                        	test   rax,rax
   7b17a:	0f 84 a0 3a 00 00                               	je     7ec20 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3f70>
   7b180:	44 0f b6 39                                     	movzx  r15d,BYTE PTR [rcx]
   7b184:	41 83 c7 d0                                     	add    r15d,0xffffffd0
   7b188:	41 83 ff 09                                     	cmp    r15d,0x9
   7b18c:	0f 86 96 3a 00 00                               	jbe    7ec28 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3f78>
   7b192:	45 31 c0                                        	xor    r8d,r8d
   7b195:	4d 85 e4                                        	test   r12,r12
   7b198:	0f 84 87 00 00 00                               	je     7b225 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x575>
   7b19e:	49 81 fc ff ff 01 00                            	cmp    r12,0x1ffff
   7b1a5:	76 21                                           	jbe    7b1c8 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x518>
   7b1a7:	4c 89 e6                                        	mov    rsi,r12
   7b1aa:	48 ff c6                                        	inc    rsi
   7b1ad:	0f 88 71 04 00 00                               	js     7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7b1b3:	43 80 3c 26 01                                  	cmp    BYTE PTR [r14+r12*1],0x1
   7b1b8:	44 89 c3                                        	mov    ebx,r8d
   7b1bb:	75 5c                                           	jne    7b219 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x569>
   7b1bd:	4c 89 f7                                        	mov    rdi,r14
   7b1c0:	ff 15 ba f5 01 00                               	call   QWORD PTR [rip+0x1f5ba]        # 9a780 <munmap@GLIBC_2.2.5>
   7b1c6:	eb 5a                                           	jmp    7b222 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x572>
   7b1c8:	4c 89 f7                                        	mov    rdi,r14
   7b1cb:	44 89 c3                                        	mov    ebx,r8d
   7b1ce:	eb 4c                                           	jmp    7b21c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x56c>
   7b1d0:	48 f7 da                                        	neg    rdx
   7b1d3:	40 b6 0a                                        	mov    sil,0xa
   7b1d6:	45 31 ff                                        	xor    r15d,r15d
   7b1d9:	49 01 d5                                        	add    r13,rdx
   7b1dc:	31 d2                                           	xor    edx,edx
   7b1de:	49 f7 dd                                        	neg    r13
   7b1e1:	4c 89 e8                                        	mov    rax,r13
   7b1e4:	48 01 d0                                        	add    rax,rdx
   7b1e7:	0f 84 68 3a 00 00                               	je     7ec55 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3fa5>
   7b1ed:	44 89 f8                                        	mov    eax,r15d
   7b1f0:	40 f6 e6                                        	mul    sil
   7b1f3:	70 9d                                           	jo     7b192 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e2>
   7b1f5:	0f b6 3c 11                                     	movzx  edi,BYTE PTR [rcx+rdx*1]
   7b1f9:	41 89 c7                                        	mov    r15d,eax
   7b1fc:	83 c7 d0                                        	add    edi,0xffffffd0
   7b1ff:	41 00 ff                                        	add    r15b,dil
   7b202:	0f 92 c0                                        	setb   al
   7b205:	45 31 c0                                        	xor    r8d,r8d
   7b208:	83 ff 09                                        	cmp    edi,0x9
   7b20b:	77 88                                           	ja     7b195 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e5>
   7b20d:	48 ff c2                                        	inc    rdx
   7b210:	84 c0                                           	test   al,al
   7b212:	74 cd                                           	je     7b1e1 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x531>
   7b214:	e9 7c ff ff ff                                  	jmp    7b195 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e5>
   7b219:	4c 89 f7                                        	mov    rdi,r14
   7b21c:	ff 15 66 f5 01 00                               	call   QWORD PTR [rip+0x1f566]        # 9a788 <free@GLIBC_2.2.5>
   7b222:	41 89 d8                                        	mov    r8d,ebx
   7b225:	41 80 ff 03                                     	cmp    r15b,0x3
   7b229:	41 0f b6 df                                     	movzx  ebx,r15b
   7b22d:	b8 02 00 00 00                                  	mov    eax,0x2
   7b232:	0f 43 d8                                        	cmovae ebx,eax
   7b235:	45 84 c0                                        	test   r8b,r8b
   7b238:	0f 44 d8                                        	cmove  ebx,eax
   7b23b:	48 8d 35 9f 76 f9 ff                            	lea    rsi,[rip+0xfffffffffff9769f]        # 128e1 <_RNvNtNtNtCsgxBkk5gSRhY_4core7unicode12unicode_data11white_space14WHITESPACE_MAP+0x17f>
   7b242:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7b24a:	ba 1d 00 00 00                                  	mov    edx,0x1d
   7b24f:	e8 3c ed ff ff                                  	call   79f90 <_RNvNtNtNtCs9k3SxhrAWiO_3std3sys3env4unix6getenv>
   7b254:	4c 8b ac 24 80 01 00 00                         	mov    r13,QWORD PTR [rsp+0x180]
   7b25c:	49 83 fd ff                                     	cmp    r13,0xffffffffffffffff
   7b260:	74 37                                           	je     7b299 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x5e9>
   7b262:	4c 8b b4 24 88 01 00 00                         	mov    r14,QWORD PTR [rsp+0x188]
   7b26a:	4c 8b bc 24 90 01 00 00                         	mov    r15,QWORD PTR [rsp+0x190]
   7b272:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7b27a:	4c 89 f6                                        	mov    rsi,r14
   7b27d:	4c 89 fa                                        	mov    rdx,r15
   7b280:	e8 eb 5a fb ff                                  	call   30d70 <_RNvNtNtCsgxBkk5gSRhY_4core3str8converts9from_utf8>
   7b285:	80 bc 24 80 01 00 00 00                         	cmp    BYTE PTR [rsp+0x180],0x0
   7b28d:	74 0f                                           	je     7b29e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x5ee>
   7b28f:	41 b4 01                                        	mov    r12b,0x1
   7b292:	4d 85 ed                                        	test   r13,r13
   7b295:	7f 1d                                           	jg     7b2b4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x604>
   7b297:	eb 4b                                           	jmp    7b2e4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x634>
   7b299:	41 b4 01                                        	mov    r12b,0x1
   7b29c:	eb 46                                           	jmp    7b2e4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x634>
   7b29e:	41 b4 01                                        	mov    r12b,0x1
   7b2a1:	49 83 ff 01                                     	cmp    r15,0x1
   7b2a5:	75 08                                           	jne    7b2af <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x5ff>
   7b2a7:	41 80 3e 30                                     	cmp    BYTE PTR [r14],0x30
   7b2ab:	41 0f 95 c4                                     	setne  r12b
   7b2af:	4d 85 ed                                        	test   r13,r13
   7b2b2:	74 30                                           	je     7b2e4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x634>
   7b2b4:	49 81 fd ff ff 01 00                            	cmp    r13,0x1ffff
   7b2bb:	76 1e                                           	jbe    7b2db <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x62b>
   7b2bd:	4c 89 ee                                        	mov    rsi,r13
   7b2c0:	48 ff c6                                        	inc    rsi
   7b2c3:	0f 88 5b 03 00 00                               	js     7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7b2c9:	43 80 3c 2e 01                                  	cmp    BYTE PTR [r14+r13*1],0x1
   7b2ce:	75 0b                                           	jne    7b2db <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x62b>
   7b2d0:	4c 89 f7                                        	mov    rdi,r14
   7b2d3:	ff 15 a7 f4 01 00                               	call   QWORD PTR [rip+0x1f4a7]        # 9a780 <munmap@GLIBC_2.2.5>
   7b2d9:	eb 09                                           	jmp    7b2e4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x634>
   7b2db:	4c 89 f7                                        	mov    rdi,r14
   7b2de:	ff 15 a4 f4 01 00                               	call   QWORD PTR [rip+0x1f4a4]        # 9a788 <free@GLIBC_2.2.5>
   7b2e4:	44 88 a4 24 c8 03 00 00                         	mov    BYTE PTR [rsp+0x3c8],r12b
   7b2ec:	48 c7 84 24 80 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x180],0x0
   7b2f8:	48 c7 84 24 88 01 00 00 08 00 00 00             	mov    QWORD PTR [rsp+0x188],0x8
   7b304:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7b308:	c5 fa 7f 84 24 90 01 00 00                      	vmovdqu XMMWORD PTR [rsp+0x190],xmm0
   7b311:	48 c7 84 24 a0 01 00 00 40 00 00 00             	mov    QWORD PTR [rsp+0x1a0],0x40
   7b31d:	c5 fa 7f 84 24 a8 01 00 00                      	vmovdqu XMMWORD PTR [rsp+0x1a8],xmm0
   7b326:	48 c7 84 24 b8 01 00 00 40 00 00 00             	mov    QWORD PTR [rsp+0x1b8],0x40
   7b332:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7b336:	62 f1 fe 48 7f 44 24 07                         	vmovdqu64 ZMMWORD PTR [rsp+0x1c0],zmm0
   7b33e:	62 f1 fe 48 7f 44 24 08                         	vmovdqu64 ZMMWORD PTR [rsp+0x200],zmm0
   7b346:	62 f1 fe 48 7f 44 24 09                         	vmovdqu64 ZMMWORD PTR [rsp+0x240],zmm0
   7b34e:	62 f1 fe 48 7f 44 24 0a                         	vmovdqu64 ZMMWORD PTR [rsp+0x280],zmm0
   7b356:	62 f1 fe 48 7f 44 24 0b                         	vmovdqu64 ZMMWORD PTR [rsp+0x2c0],zmm0
   7b35e:	62 f1 fe 48 7f 44 24 0c                         	vmovdqu64 ZMMWORD PTR [rsp+0x300],zmm0
   7b366:	62 f1 fe 48 7f 44 24 0d                         	vmovdqu64 ZMMWORD PTR [rsp+0x340],zmm0
   7b36e:	62 f1 fe 48 7f 44 24 0e                         	vmovdqu64 ZMMWORD PTR [rsp+0x380],zmm0
   7b376:	48 c7 84 24 c0 03 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x3c0],0x0
   7b382:	48 8d 35 27 bb f8 ff                            	lea    rsi,[rip+0xfffffffffff8bb27]        # 6eb0 <GCC_except_table711+0x3c0>
   7b389:	48 8d bc 24 a0 07 00 00                         	lea    rdi,[rsp+0x7a0]
   7b391:	ba 10 00 00 00                                  	mov    edx,0x10
   7b396:	c5 f8 77                                        	vzeroupper
   7b399:	e8 f2 eb ff ff                                  	call   79f90 <_RNvNtNtNtCs9k3SxhrAWiO_3std3sys3env4unix6getenv>
   7b39e:	4c 8b a4 24 a0 07 00 00                         	mov    r12,QWORD PTR [rsp+0x7a0]
   7b3a6:	41 89 dd                                        	mov    r13d,ebx
   7b3a9:	49 83 fc ff                                     	cmp    r12,0xffffffffffffffff
   7b3ad:	74 36                                           	je     7b3e5 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x735>
   7b3af:	4c 8b b4 24 a8 07 00 00                         	mov    r14,QWORD PTR [rsp+0x7a8]
   7b3b7:	4c 8b bc 24 b0 07 00 00                         	mov    r15,QWORD PTR [rsp+0x7b0]
   7b3bf:	48 8d bc 24 a0 07 00 00                         	lea    rdi,[rsp+0x7a0]
   7b3c7:	4c 89 f6                                        	mov    rsi,r14
   7b3ca:	4c 89 fa                                        	mov    rdx,r15
   7b3cd:	e8 9e 59 fb ff                                  	call   30d70 <_RNvNtNtCsgxBkk5gSRhY_4core3str8converts9from_utf8>
   7b3d2:	80 bc 24 a0 07 00 00 00                         	cmp    BYTE PTR [rsp+0x7a0],0x0
   7b3da:	74 0d                                           	je     7b3e9 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x739>
   7b3dc:	b3 01                                           	mov    bl,0x1
   7b3de:	4d 85 e4                                        	test   r12,r12
   7b3e1:	7f 1a                                           	jg     7b3fd <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x74d>
   7b3e3:	eb 48                                           	jmp    7b42d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x77d>
   7b3e5:	b3 01                                           	mov    bl,0x1
   7b3e7:	eb 44                                           	jmp    7b42d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x77d>
   7b3e9:	b3 01                                           	mov    bl,0x1
   7b3eb:	49 83 ff 01                                     	cmp    r15,0x1
   7b3ef:	75 07                                           	jne    7b3f8 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x748>
   7b3f1:	41 80 3e 30                                     	cmp    BYTE PTR [r14],0x30
   7b3f5:	0f 95 c3                                        	setne  bl
   7b3f8:	4d 85 e4                                        	test   r12,r12
   7b3fb:	74 30                                           	je     7b42d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x77d>
   7b3fd:	49 81 fc ff ff 01 00                            	cmp    r12,0x1ffff
   7b404:	76 1e                                           	jbe    7b424 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x774>
   7b406:	4c 89 e6                                        	mov    rsi,r12
   7b409:	48 ff c6                                        	inc    rsi
   7b40c:	0f 88 12 02 00 00                               	js     7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7b412:	43 80 3c 26 01                                  	cmp    BYTE PTR [r14+r12*1],0x1
   7b417:	75 0b                                           	jne    7b424 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x774>
   7b419:	4c 89 f7                                        	mov    rdi,r14
   7b41c:	ff 15 5e f3 01 00                               	call   QWORD PTR [rip+0x1f35e]        # 9a780 <munmap@GLIBC_2.2.5>
   7b422:	eb 09                                           	jmp    7b42d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x77d>
   7b424:	4c 89 f7                                        	mov    rdi,r14
   7b427:	ff 15 5b f3 01 00                               	call   QWORD PTR [rip+0x1f35b]        # 9a788 <free@GLIBC_2.2.5>
   7b42d:	0f b6 44 24 28                                  	movzx  eax,BYTE PTR [rsp+0x28]
   7b432:	0f b6 4c 24 20                                  	movzx  ecx,BYTE PTR [rsp+0x20]
   7b437:	41 80 fd 02                                     	cmp    r13b,0x2
   7b43b:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7b43f:	0f 94 84 24 d0 07 00 00                         	sete   BYTE PTR [rsp+0x7d0]
   7b447:	45 84 ed                                        	test   r13b,r13b
   7b44a:	0f 95 84 24 d1 07 00 00                         	setne  BYTE PTR [rsp+0x7d1]
   7b452:	88 84 24 d2 07 00 00                            	mov    BYTE PTR [rsp+0x7d2],al
   7b459:	88 8c 24 d3 07 00 00                            	mov    BYTE PTR [rsp+0x7d3],cl
   7b460:	48 c7 84 24 a0 07 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x7a0],0x0
   7b46c:	48 c7 84 24 a8 07 00 00 40 00 00 00             	mov    QWORD PTR [rsp+0x7a8],0x40
   7b478:	c5 fa 7f 84 24 b0 07 00 00                      	vmovdqu XMMWORD PTR [rsp+0x7b0],xmm0
   7b481:	48 c7 84 24 c0 07 00 00 08 00 00 00             	mov    QWORD PTR [rsp+0x7c0],0x8
   7b48d:	48 c7 84 24 c8 07 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x7c8],0x0
   7b499:	48 8d 35 0d 74 f9 ff                            	lea    rsi,[rip+0xfffffffffff9740d]        # 128ad <_RNvNtNtNtCsgxBkk5gSRhY_4core7unicode12unicode_data11white_space14WHITESPACE_MAP+0x14b>
   7b4a0:	48 8d bc 24 50 05 00 00                         	lea    rdi,[rsp+0x550]
   7b4a8:	ba 1b 00 00 00                                  	mov    edx,0x1b
   7b4ad:	e8 de ea ff ff                                  	call   79f90 <_RNvNtNtNtCs9k3SxhrAWiO_3std3sys3env4unix6getenv>
   7b4b2:	4c 8b bc 24 50 05 00 00                         	mov    r15,QWORD PTR [rsp+0x550]
   7b4ba:	49 83 ff ff                                     	cmp    r15,0xffffffffffffffff
   7b4be:	74 41                                           	je     7b501 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x851>
   7b4c0:	4c 8b b4 24 58 05 00 00                         	mov    r14,QWORD PTR [rsp+0x558]
   7b4c8:	4c 8b ac 24 60 05 00 00                         	mov    r13,QWORD PTR [rsp+0x560]
   7b4d0:	48 8d bc 24 50 05 00 00                         	lea    rdi,[rsp+0x550]
   7b4d8:	4c 89 f6                                        	mov    rsi,r14
   7b4db:	4c 89 ea                                        	mov    rdx,r13
   7b4de:	e8 8d 58 fb ff                                  	call   30d70 <_RNvNtNtCsgxBkk5gSRhY_4core3str8converts9from_utf8>
   7b4e3:	4c 8b a4 24 50 05 00 00                         	mov    r12,QWORD PTR [rsp+0x550]
   7b4eb:	49 83 fd 01                                     	cmp    r13,0x1
   7b4ef:	0f 95 c0                                        	setne  al
   7b4f2:	44 08 e0                                        	or     al,r12b
   7b4f5:	74 21                                           	je     7b518 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x868>
   7b4f7:	c7 44 24 58 00 00 00 00                         	mov    DWORD PTR [rsp+0x58],0x0
   7b4ff:	eb 25                                           	jmp    7b526 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x876>
   7b501:	41 bc 01 00 00 00                               	mov    r12d,0x1
   7b507:	49 c7 c7 ff ff ff ff                            	mov    r15,0xffffffffffffffff
   7b50e:	c7 44 24 58 00 00 00 00                         	mov    DWORD PTR [rsp+0x58],0x0
   7b516:	eb 0e                                           	jmp    7b526 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x876>
   7b518:	41 80 3e 31                                     	cmp    BYTE PTR [r14],0x31
   7b51c:	0f 94 c0                                        	sete   al
   7b51f:	45 31 e4                                        	xor    r12d,r12d
   7b522:	89 44 24 58                                     	mov    DWORD PTR [rsp+0x58],eax
   7b526:	48 8d 35 9b 73 f9 ff                            	lea    rsi,[rip+0xfffffffffff9739b]        # 128c8 <_RNvNtNtNtCsgxBkk5gSRhY_4core7unicode12unicode_data11white_space14WHITESPACE_MAP+0x166>
   7b52d:	48 8d 7c 24 60                                  	lea    rdi,[rsp+0x60]
   7b532:	ba 19 00 00 00                                  	mov    edx,0x19
   7b537:	e8 54 ea ff ff                                  	call   79f90 <_RNvNtNtNtCs9k3SxhrAWiO_3std3sys3env4unix6getenv>
   7b53c:	4c 8b 6c 24 60                                  	mov    r13,QWORD PTR [rsp+0x60]
   7b541:	48 8d bc 24 50 05 00 00                         	lea    rdi,[rsp+0x550]
   7b549:	48 8d b4 24 80 01 00 00                         	lea    rsi,[rsp+0x180]
   7b551:	ba 50 02 00 00                                  	mov    edx,0x250
   7b556:	49 83 fd ff                                     	cmp    r13,0xffffffffffffffff
   7b55a:	0f 95 84 24 80 00 00 00                         	setne  BYTE PTR [rsp+0x80]
   7b562:	ff 15 40 f2 01 00                               	call   QWORD PTR [rip+0x1f240]        # 9a7a8 <memcpy@GLIBC_2.14>
   7b568:	c5 fe 6f 84 24 a0 07 00 00                      	vmovdqu ymm0,YMMWORD PTR [rsp+0x7a0]
   7b571:	c5 fe 6f 8c 24 b8 07 00 00                      	vmovdqu ymm1,YMMWORD PTR [rsp+0x7b8]
   7b57a:	c5 fe 7f 84 24 b0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xb0],ymm0
   7b583:	c5 fe 7f 8c 24 c8 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xc8],ymm1
   7b58c:	4d 85 ed                                        	test   r13,r13
   7b58f:	7e 26                                           	jle    7b5b7 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x907>
   7b591:	48 8b 7c 24 68                                  	mov    rdi,QWORD PTR [rsp+0x68]
   7b596:	49 81 fd ff ff 01 00                            	cmp    r13,0x1ffff
   7b59d:	76 51                                           	jbe    7b5f0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x940>
   7b59f:	4c 89 ee                                        	mov    rsi,r13
   7b5a2:	48 ff c6                                        	inc    rsi
   7b5a5:	78 7d                                           	js     7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7b5a7:	42 80 3c 2f 01                                  	cmp    BYTE PTR [rdi+r13*1],0x1
   7b5ac:	75 42                                           	jne    7b5f0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x940>
   7b5ae:	c5 f8 77                                        	vzeroupper
   7b5b1:	ff 15 c9 f1 01 00                               	call   QWORD PTR [rip+0x1f1c9]        # 9a780 <munmap@GLIBC_2.2.5>
   7b5b7:	4d 85 e4                                        	test   r12,r12
   7b5ba:	74 42                                           	je     7b5fe <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x94e>
   7b5bc:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   7b5c1:	4d 85 ff                                        	test   r15,r15
   7b5c4:	0f 8e 8e 00 00 00                               	jle    7b658 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x9a8>
   7b5ca:	49 81 ff ff ff 01 00                            	cmp    r15,0x1ffff
   7b5d1:	76 74                                           	jbe    7b647 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x997>
   7b5d3:	4c 89 fe                                        	mov    rsi,r15
   7b5d6:	48 ff c6                                        	inc    rsi
   7b5d9:	78 49                                           	js     7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7b5db:	43 80 3c 3e 01                                  	cmp    BYTE PTR [r14+r15*1],0x1
   7b5e0:	75 65                                           	jne    7b647 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x997>
   7b5e2:	4c 89 f7                                        	mov    rdi,r14
   7b5e5:	c5 f8 77                                        	vzeroupper
   7b5e8:	ff 15 92 f1 01 00                               	call   QWORD PTR [rip+0x1f192]        # 9a780 <munmap@GLIBC_2.2.5>
   7b5ee:	eb 63                                           	jmp    7b653 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x9a3>
   7b5f0:	c5 f8 77                                        	vzeroupper
   7b5f3:	ff 15 8f f1 01 00                               	call   QWORD PTR [rip+0x1f18f]        # 9a788 <free@GLIBC_2.2.5>
   7b5f9:	4d 85 e4                                        	test   r12,r12
   7b5fc:	75 be                                           	jne    7b5bc <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x90c>
   7b5fe:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   7b603:	4d 85 ff                                        	test   r15,r15
   7b606:	74 50                                           	je     7b658 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x9a8>
   7b608:	49 81 ff ff ff 01 00                            	cmp    r15,0x1ffff
   7b60f:	76 36                                           	jbe    7b647 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x997>
   7b611:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7b61b:	48 83 c0 06                                     	add    rax,0x6
   7b61f:	49 39 c7                                        	cmp    r15,rax
   7b622:	72 08                                           	jb     7b62c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x97c>
   7b624:	c5 f8 77                                        	vzeroupper
   7b627:	e8 54 d3 fc ff                                  	call   48980 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
   7b62c:	43 80 3c 3e 01                                  	cmp    BYTE PTR [r14+r15*1],0x1
   7b631:	75 14                                           	jne    7b647 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x997>
   7b633:	49 ff c7                                        	inc    r15
   7b636:	4c 89 f7                                        	mov    rdi,r14
   7b639:	4c 89 fe                                        	mov    rsi,r15
   7b63c:	c5 f8 77                                        	vzeroupper
   7b63f:	ff 15 3b f1 01 00                               	call   QWORD PTR [rip+0x1f13b]        # 9a780 <munmap@GLIBC_2.2.5>
   7b645:	eb 0c                                           	jmp    7b653 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x9a3>
   7b647:	4c 89 f7                                        	mov    rdi,r14
   7b64a:	c5 f8 77                                        	vzeroupper
   7b64d:	ff 15 35 f1 01 00                               	call   QWORD PTR [rip+0x1f135]        # 9a788 <free@GLIBC_2.2.5>
   7b653:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   7b658:	c5 fc 28 05 a0 c0 f8 ff                         	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffff8c0a0]        # 7700 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x760>
   7b660:	48 8b 4c 24 40                                  	mov    rcx,QWORD PTR [rsp+0x40]
   7b665:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
   7b66a:	48 c7 84 24 a0 07 00 00 00 08 00 00             	mov    QWORD PTR [rsp+0x7a0],0x800
   7b676:	48 89 ac 24 a8 07 00 00                         	mov    QWORD PTR [rsp+0x7a8],rbp
   7b67e:	48 8d bc 24 90 08 00 00                         	lea    rdi,[rsp+0x890]
   7b686:	48 8d b4 24 50 05 00 00                         	lea    rsi,[rsp+0x550]
   7b68e:	c5 fc 11 84 24 b0 07 00 00                      	vmovups YMMWORD PTR [rsp+0x7b0],ymm0
   7b697:	48 c7 84 24 d0 07 00 00 00 08 00 00             	mov    QWORD PTR [rsp+0x7d0],0x800
   7b6a3:	48 89 84 24 d8 07 00 00                         	mov    QWORD PTR [rsp+0x7d8],rax
   7b6ab:	c5 fc 11 84 24 e0 07 00 00                      	vmovups YMMWORD PTR [rsp+0x7e0],ymm0
   7b6b4:	48 c7 84 24 00 08 00 00 20 00 00 00             	mov    QWORD PTR [rsp+0x800],0x20
   7b6c0:	48 89 8c 24 08 08 00 00                         	mov    QWORD PTR [rsp+0x808],rcx
   7b6c8:	48 8b 4c 24 50                                  	mov    rcx,QWORD PTR [rsp+0x50]
   7b6cd:	48 c7 84 24 10 08 00 00 20 00 00 00             	mov    QWORD PTR [rsp+0x810],0x20
   7b6d9:	48 c7 84 24 18 08 00 00 c8 00 00 00             	mov    QWORD PTR [rsp+0x818],0xc8
   7b6e5:	48 89 94 24 20 08 00 00                         	mov    QWORD PTR [rsp+0x820],rdx
   7b6ed:	ba 50 02 00 00                                  	mov    edx,0x250
   7b6f2:	48 c7 84 24 28 08 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x828],0x0
   7b6fe:	48 c7 84 24 30 08 00 00 c8 00 00 00             	mov    QWORD PTR [rsp+0x830],0xc8
   7b70a:	c5 f8 57 c0                                     	vxorps xmm0,xmm0,xmm0
   7b70e:	48 89 8c 24 38 08 00 00                         	mov    QWORD PTR [rsp+0x838],rcx
   7b716:	c5 f8 11 84 24 40 08 00 00                      	vmovups XMMWORD PTR [rsp+0x840],xmm0
   7b71f:	48 c7 84 24 50 08 00 00 08 00 00 00             	mov    QWORD PTR [rsp+0x850],0x8
   7b72b:	c5 f8 11 84 24 58 08 00 00                      	vmovups XMMWORD PTR [rsp+0x858],xmm0
   7b734:	48 c7 84 24 68 08 00 00 08 00 00 00             	mov    QWORD PTR [rsp+0x868],0x8
   7b740:	c5 f8 11 84 24 70 08 00 00                      	vmovups XMMWORD PTR [rsp+0x870],xmm0
   7b749:	48 c7 84 24 80 08 00 00 08 00 00 00             	mov    QWORD PTR [rsp+0x880],0x8
   7b755:	48 c7 84 24 88 08 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x888],0x0
   7b761:	c5 f8 77                                        	vzeroupper
   7b764:	ff 15 3e f0 01 00                               	call   QWORD PTR [rip+0x1f03e]        # 9a7a8 <memcpy@GLIBC_2.14>
   7b76a:	c5 fe 6f 84 24 b0 00 00 00                      	vmovdqu ymm0,YMMWORD PTR [rsp+0xb0]
   7b773:	c5 fe 6f 8c 24 c8 00 00 00                      	vmovdqu ymm1,YMMWORD PTR [rsp+0xc8]
   7b77c:	0f b6 44 24 28                                  	movzx  eax,BYTE PTR [rsp+0x28]
   7b781:	48 8b 54 24 48                                  	mov    rdx,QWORD PTR [rsp+0x48]
   7b786:	48 8b 4c 24 38                                  	mov    rcx,QWORD PTR [rsp+0x38]
   7b78b:	0f b6 b4 24 80 00 00 00                         	movzx  esi,BYTE PTR [rsp+0x80]
   7b793:	48 39 d1                                        	cmp    rcx,rdx
   7b796:	48 0f 42 d1                                     	cmovb  rdx,rcx
   7b79a:	48 89 54 24 48                                  	mov    QWORD PTR [rsp+0x48],rdx
   7b79f:	c5 fe 7f 84 24 e0 0a 00 00                      	vmovdqu YMMWORD PTR [rsp+0xae0],ymm0
   7b7a8:	c5 fe 7f 8c 24 f8 0a 00 00                      	vmovdqu YMMWORD PTR [rsp+0xaf8],ymm1
   7b7b1:	48 c7 84 24 18 0b 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xb18],0x0
   7b7bd:	48 c7 84 24 20 0b 00 00 40 00 00 00             	mov    QWORD PTR [rsp+0xb20],0x40
   7b7c9:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7b7cd:	c5 fa 7f 84 24 28 0b 00 00                      	vmovdqu XMMWORD PTR [rsp+0xb28],xmm0
   7b7d6:	48 c7 84 24 38 0b 00 00 40 00 00 00             	mov    QWORD PTR [rsp+0xb38],0x40
   7b7e2:	c5 fa 7f 84 24 40 0b 00 00                      	vmovdqu XMMWORD PTR [rsp+0xb40],xmm0
   7b7eb:	48 c7 84 24 50 0b 00 00 08 00 00 00             	mov    QWORD PTR [rsp+0xb50],0x8
   7b7f7:	48 c7 84 24 58 0b 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xb58],0x0
   7b803:	88 84 24 60 0b 00 00                            	mov    BYTE PTR [rsp+0xb60],al
   7b80a:	0f b6 44 24 20                                  	movzx  eax,BYTE PTR [rsp+0x20]
   7b80f:	88 84 24 61 0b 00 00                            	mov    BYTE PTR [rsp+0xb61],al
   7b816:	8b 44 24 58                                     	mov    eax,DWORD PTR [rsp+0x58]
   7b81a:	88 84 24 62 0b 00 00                            	mov    BYTE PTR [rsp+0xb62],al
   7b821:	40 88 b4 24 63 0b 00 00                         	mov    BYTE PTR [rsp+0xb63],sil
   7b829:	c6 84 24 64 0b 00 00 00                         	mov    BYTE PTR [rsp+0xb64],0x0
   7b831:	88 9c 24 68 0b 00 00                            	mov    BYTE PTR [rsp+0xb68],bl
   7b838:	48 85 d2                                        	test   rdx,rdx
   7b83b:	0f 84 fd 0b 00 00                               	je     7c43e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x178e>
   7b841:	48 8b 44 24 10                                  	mov    rax,QWORD PTR [rsp+0x10]
   7b846:	bb ff ff ff ff                                  	mov    ebx,0xffffffff
   7b84b:	48 8d 04 85 00 00 00 00                         	lea    rax,[rax*4+0x0]
   7b853:	48 8d 54 40 ff                                  	lea    rdx,[rax+rax*2-0x1]
   7b858:	48 8d 0c 40                                     	lea    rcx,[rax+rax*2]
   7b85c:	89 d0                                           	mov    eax,edx
   7b85e:	83 e0 3f                                        	and    eax,0x3f
   7b861:	48 89 d6                                        	mov    rsi,rdx
   7b864:	48 c1 ee 06                                     	shr    rsi,0x6
   7b868:	48 89 54 24 20                                  	mov    QWORD PTR [rsp+0x20],rdx
   7b86d:	48 83 f8 34                                     	cmp    rax,0x34
   7b871:	48 89 44 24 08                                  	mov    QWORD PTR [rsp+0x8],rax
   7b876:	48 89 74 24 28                                  	mov    QWORD PTR [rsp+0x28],rsi
   7b87b:	0f 93 c0                                        	setae  al
   7b87e:	48 81 fa c0 00 00 00                            	cmp    rdx,0xc0
   7b885:	0f 92 c2                                        	setb   dl
   7b888:	45 31 e4                                        	xor    r12d,r12d
   7b88b:	20 c2                                           	and    dl,al
   7b88d:	b8 01 00 00 00                                  	mov    eax,0x1
   7b892:	29 c8                                           	sub    eax,ecx
   7b894:	88 54 24 40                                     	mov    BYTE PTR [rsp+0x40],dl
   7b898:	83 e0 3d                                        	and    eax,0x3d
   7b89b:	48 89 44 24 18                                  	mov    QWORD PTR [rsp+0x18],rax
   7b8a0:	eb 21                                           	jmp    7b8c3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc13>
   7b8a2:	48 c7 84 24 40 08 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x840],0x0
   7b8ae:	66 90                                           	xchg   ax,ax
   7b8b0:	48 8b 74 24 28                                  	mov    rsi,QWORD PTR [rsp+0x28]
   7b8b5:	49 ff c4                                        	inc    r12
   7b8b8:	4c 3b 64 24 48                                  	cmp    r12,QWORD PTR [rsp+0x48]
   7b8bd:	0f 84 7b 0b 00 00                               	je     7c43e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x178e>
   7b8c3:	4c 89 e1                                        	mov    rcx,r12
   7b8c6:	48 c1 e1 05                                     	shl    rcx,0x5
   7b8ca:	48 03 8c 24 90 00 00 00                         	add    rcx,QWORD PTR [rsp+0x90]
   7b8d2:	48 83 7c 24 10 00                               	cmp    QWORD PTR [rsp+0x10],0x0
   7b8d8:	74 36                                           	je     7b910 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc60>
   7b8da:	48 81 7c 24 20 ff 00 00 00                      	cmp    QWORD PTR [rsp+0x20],0xff
   7b8e3:	77 4b                                           	ja     7b930 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc80>
   7b8e5:	48 8b 44 24 08                                  	mov    rax,QWORD PTR [rsp+0x8]
   7b8ea:	80 7c 24 40 00                                  	cmp    BYTE PTR [rsp+0x40],0x0
   7b8ef:	c4 e2 fb f7 04 f1                               	shrx   rax,QWORD PTR [rcx+rsi*8],rax
   7b8f5:	74 3b                                           	je     7b932 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc82>
   7b8f7:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
   7b8fc:	c4 e2 e9 f7 4c f1 08                            	shlx   rcx,QWORD PTR [rcx+rsi*8+0x8],rdx
   7b903:	48 09 c8                                        	or     rax,rcx
   7b906:	eb 2a                                           	jmp    7b932 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc82>
   7b908:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   7b910:	48 8b 09                                        	mov    rcx,QWORD PTR [rcx]
   7b913:	81 e1 ff 0f 00 00                               	and    ecx,0xfff
   7b919:	8d 04 09                                        	lea    eax,[rcx+rcx*1]
   7b91c:	25 00 10 00 00                                  	and    eax,0x1000
   7b921:	48 29 c1                                        	sub    rcx,rax
   7b924:	74 8a                                           	je     7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7b926:	eb 24                                           	jmp    7b94c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc9c>
   7b928:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   7b930:	31 c0                                           	xor    eax,eax
   7b932:	89 c1                                           	mov    ecx,eax
   7b934:	81 e1 ff 1f 00 00                               	and    ecx,0x1fff
   7b93a:	ff c1                                           	inc    ecx
   7b93c:	d1 e9                                           	shr    ecx,1
   7b93e:	25 00 10 00 00                                  	and    eax,0x1000
   7b943:	48 29 c1                                        	sub    rcx,rax
   7b946:	0f 84 64 ff ff ff                               	je     7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7b94c:	4d 89 e5                                        	mov    r13,r12
   7b94f:	49 c1 e5 06                                     	shl    r13,0x6
   7b953:	4c 03 ac 24 88 00 00 00                         	add    r13,QWORD PTR [rsp+0x88]
   7b95b:	c4 c1 7e 6f 45 00                               	vmovdqu ymm0,YMMWORD PTR [r13+0x0]
   7b961:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7b966:	75 11                                           	jne    7b979 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xcc9>
   7b968:	c4 c1 7e 6f 45 20                               	vmovdqu ymm0,YMMWORD PTR [r13+0x20]
   7b96e:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7b973:	0f 84 37 ff ff ff                               	je     7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7b979:	89 c8                                           	mov    eax,ecx
   7b97b:	48 8b b4 24 10 08 00 00                         	mov    rsi,QWORD PTR [rsp+0x810]
   7b983:	66 f7 d8                                        	neg    ax
   7b986:	66 0f 48 c1                                     	cmovs  ax,cx
   7b98a:	0f b7 c0                                        	movzx  eax,ax
   7b98d:	48 ff c8                                        	dec    rax
   7b990:	49 89 c6                                        	mov    r14,rax
   7b993:	49 c1 ee 06                                     	shr    r14,0x6
   7b997:	49 39 f6                                        	cmp    r14,rsi
   7b99a:	0f 83 04 33 00 00                               	jae    7eca4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ff4>
   7b9a0:	48 8b 94 24 08 08 00 00                         	mov    rdx,QWORD PTR [rsp+0x808]
   7b9a8:	48 c1 e9 3f                                     	shr    rcx,0x3f
   7b9ac:	89 c5                                           	mov    ebp,eax
   7b9ae:	c1 e1 1f                                        	shl    ecx,0x1f
   7b9b1:	09 cd                                           	or     ebp,ecx
   7b9b3:	4a 8b 3c f2                                     	mov    rdi,QWORD PTR [rdx+r14*8]
   7b9b7:	48 0f a3 c7                                     	bt     rdi,rax
   7b9bb:	0f 83 56 03 00 00                               	jae    7bd17 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1067>
   7b9c1:	4c 8b b4 24 40 08 00 00                         	mov    r14,QWORD PTR [rsp+0x840]
   7b9c9:	4c 3b b4 24 30 08 00 00                         	cmp    r14,QWORD PTR [rsp+0x830]
   7b9d1:	75 10                                           	jne    7b9e3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xd33>
   7b9d3:	48 8d bc 24 30 08 00 00                         	lea    rdi,[rsp+0x830]
   7b9db:	c5 f8 77                                        	vzeroupper
   7b9de:	e8 ad ad 01 00                                  	call   96790 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecTmRINtNtCsgHCcee0nhgM_11zopro_bn2545curve6AffineNtBR_8G1ConfigEEE8grow_oneCsHW5vo2gROj_10zopro_core>
   7b9e3:	48 8b 84 24 38 08 00 00                         	mov    rax,QWORD PTR [rsp+0x838]
   7b9eb:	4c 89 f1                                        	mov    rcx,r14
   7b9ee:	48 c1 e1 04                                     	shl    rcx,0x4
   7b9f2:	89 2c 08                                        	mov    DWORD PTR [rax+rcx*1],ebp
   7b9f5:	4c 89 6c 08 08                                  	mov    QWORD PTR [rax+rcx*1+0x8],r13
   7b9fa:	49 8d 4e 01                                     	lea    rcx,[r14+0x1]
   7b9fe:	48 89 8c 24 40 08 00 00                         	mov    QWORD PTR [rsp+0x840],rcx
   7ba06:	49 81 fe c6 00 00 00                            	cmp    r14,0xc6
   7ba0d:	0f 85 9d fe ff ff                               	jne    7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7ba13:	41 bd 08 00 00 00                               	mov    r13d,0x8
   7ba19:	45 31 f6                                        	xor    r14d,r14d
   7ba1c:	eb 65                                           	jmp    7ba83 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xdd3>
   7ba1e:	48 8d bc 24 b8 07 00 00                         	lea    rdi,[rsp+0x7b8]
   7ba26:	c5 f8 77                                        	vzeroupper
   7ba29:	e8 b2 80 01 00                                  	call   93ae0 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtCsgHCcee0nhgM_11zopro_bn2545curve10ProjectiveNtBO_8G1ConfigEE8grow_oneCsHW5vo2gROj_10zopro_core>
   7ba2e:	62 f1 fe 48 6f 44 24 06                         	vmovdqu64 zmm0,ZMMWORD PTR [rsp+0x180]
   7ba36:	62 f1 fe 48 6f 8c 24 a0 01 00 00                	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x1a0]
   7ba41:	48 8b 84 24 c0 07 00 00                         	mov    rax,QWORD PTR [rsp+0x7c0]
   7ba49:	48 8d 4c 6d 00                                  	lea    rcx,[rbp+rbp*2+0x0]
   7ba4e:	48 ff c5                                        	inc    rbp
   7ba51:	48 c1 e1 05                                     	shl    rcx,0x5
   7ba55:	62 f1 fe 48 7f 8c 08 20 00 00 00                	vmovdqu64 ZMMWORD PTR [rax+rcx*1+0x20],zmm1
   7ba60:	62 f1 fe 48 7f 04 08                            	vmovdqu64 ZMMWORD PTR [rax+rcx*1],zmm0
   7ba67:	48 89 ac 24 c8 07 00 00                         	mov    QWORD PTR [rsp+0x7c8],rbp
   7ba6f:	49 ff c6                                        	inc    r14
   7ba72:	49 83 c5 10                                     	add    r13,0x10
   7ba76:	49 81 fe c7 00 00 00                            	cmp    r14,0xc7
   7ba7d:	0f 84 1f fe ff ff                               	je     7b8a2 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xbf2>
   7ba83:	48 8b b4 24 40 08 00 00                         	mov    rsi,QWORD PTR [rsp+0x840]
   7ba8b:	49 39 f6                                        	cmp    r14,rsi
   7ba8e:	0f 83 f2 31 00 00                               	jae    7ec86 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3fd6>
   7ba94:	48 8b 84 24 38 08 00 00                         	mov    rax,QWORD PTR [rsp+0x838]
   7ba9c:	42 8b 6c 28 f8                                  	mov    ebp,DWORD PTR [rax+r13*1-0x8]
   7baa1:	4a 8b 04 28                                     	mov    rax,QWORD PTR [rax+r13*1]
   7baa5:	85 ed                                           	test   ebp,ebp
   7baa7:	78 37                                           	js     7bae0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xe30>
   7baa9:	62 f1 fe 48 6f 00                               	vmovdqu64 zmm0,ZMMWORD PTR [rax]
   7baaf:	62 f1 fe 48 7f 84 24 50 05 00 00                	vmovdqu64 ZMMWORD PTR [rsp+0x550],zmm0
   7baba:	48 8b b4 24 e0 07 00 00                         	mov    rsi,QWORD PTR [rsp+0x7e0]
   7bac2:	81 e5 ff ff ff 7f                               	and    ebp,0x7fffffff
   7bac8:	48 39 ee                                        	cmp    rsi,rbp
   7bacb:	0f 87 c2 00 00 00                               	ja     7bb93 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xee3>
   7bad1:	e9 a4 31 00 00                                  	jmp    7ec7a <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3fca>
   7bad6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   7bae0:	c5 fc 10 00                                     	vmovups ymm0,YMMWORD PTR [rax]
   7bae4:	c5 fe 6f 0d f4 bd f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff8bdf4]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   7baec:	31 c9                                           	xor    ecx,ecx
   7baee:	31 d2                                           	xor    edx,edx
   7baf0:	31 f6                                           	xor    esi,esi
   7baf2:	4c 8d bc 24 80 01 00 00                         	lea    r15,[rsp+0x180]
   7bafa:	48 8d 5c 24 60                                  	lea    rbx,[rsp+0x60]
   7baff:	c5 fc 11 84 24 50 05 00 00                      	vmovups YMMWORD PTR [rsp+0x550],ymm0
   7bb08:	c5 fe 6f 40 20                                  	vmovdqu ymm0,YMMWORD PTR [rax+0x20]
   7bb0d:	c5 fe 7f 8c 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm1
   7bb16:	31 c0                                           	xor    eax,eax
   7bb18:	c5 fe 7f 44 24 60                               	vmovdqu YMMWORD PTR [rsp+0x60],ymm0
   7bb1e:	48 2b 0b                                        	sub    rcx,QWORD PTR [rbx]
   7bb21:	48 1b 53 08                                     	sbb    rdx,QWORD PTR [rbx+0x8]
   7bb25:	48 1b 73 10                                     	sbb    rsi,QWORD PTR [rbx+0x10]
   7bb29:	48 1b 43 18                                     	sbb    rax,QWORD PTR [rbx+0x18]
   7bb2d:	4d 19 db                                        	sbb    r11,r11
   7bb30:	49 8b 3f                                        	mov    rdi,QWORD PTR [r15]
   7bb33:	4d 8b 47 08                                     	mov    r8,QWORD PTR [r15+0x8]
   7bb37:	4d 8b 4f 10                                     	mov    r9,QWORD PTR [r15+0x10]
   7bb3b:	4d 8b 57 18                                     	mov    r10,QWORD PTR [r15+0x18]
   7bb3f:	4c 21 df                                        	and    rdi,r11
   7bb42:	4d 21 d8                                        	and    r8,r11
   7bb45:	4d 21 d9                                        	and    r9,r11
   7bb48:	4d 21 da                                        	and    r10,r11
   7bb4b:	48 01 f9                                        	add    rcx,rdi
   7bb4e:	4c 11 c2                                        	adc    rdx,r8
   7bb51:	4c 11 ce                                        	adc    rsi,r9
   7bb54:	4c 11 d0                                        	adc    rax,r10
   7bb57:	bb ff ff ff ff                                  	mov    ebx,0xffffffff
   7bb5c:	48 89 8c 24 70 05 00 00                         	mov    QWORD PTR [rsp+0x570],rcx
   7bb64:	48 89 94 24 78 05 00 00                         	mov    QWORD PTR [rsp+0x578],rdx
   7bb6c:	48 89 b4 24 80 05 00 00                         	mov    QWORD PTR [rsp+0x580],rsi
   7bb74:	48 89 84 24 88 05 00 00                         	mov    QWORD PTR [rsp+0x588],rax
   7bb7c:	48 8b b4 24 e0 07 00 00                         	mov    rsi,QWORD PTR [rsp+0x7e0]
   7bb84:	81 e5 ff ff ff 7f                               	and    ebp,0x7fffffff
   7bb8a:	48 39 ee                                        	cmp    rsi,rbp
   7bb8d:	0f 86 e7 30 00 00                               	jbe    7ec7a <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3fca>
   7bb93:	48 8b 8c 24 d8 07 00 00                         	mov    rcx,QWORD PTR [rsp+0x7d8]
   7bb9b:	48 8b b4 24 c8 07 00 00                         	mov    rsi,QWORD PTR [rsp+0x7c8]
   7bba3:	8b 04 a9                                        	mov    eax,DWORD PTR [rcx+rbp*4]
   7bba6:	48 39 d8                                        	cmp    rax,rbx
   7bba9:	74 75                                           	je     7bc20 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xf70>
   7bbab:	48 39 c6                                        	cmp    rsi,rax
   7bbae:	0f 86 db 30 00 00                               	jbe    7ec8f <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3fdf>
   7bbb4:	4c 8b bc 24 c0 07 00 00                         	mov    r15,QWORD PTR [rsp+0x7c0]
   7bbbc:	48 8d 2c 40                                     	lea    rbp,[rax+rax*2]
   7bbc0:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7bbc8:	48 8d 94 24 50 05 00 00                         	lea    rdx,[rsp+0x550]
   7bbd0:	48 c1 e5 05                                     	shl    rbp,0x5
   7bbd4:	49 8d 34 2f                                     	lea    rsi,[r15+rbp*1]
   7bbd8:	c5 f8 77                                        	vzeroupper
   7bbdb:	e8 d0 09 01 00                                  	call   8c5b0 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE10add_affineCsHW5vo2gROj_10zopro_core>
   7bbe0:	62 f1 fe 48 6f 44 24 06                         	vmovdqu64 zmm0,ZMMWORD PTR [rsp+0x180]
   7bbe8:	62 f1 fe 48 6f 8c 24 a0 01 00 00                	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x1a0]
   7bbf3:	62 d1 fe 48 7f 8c 2f 20 00 00 00                	vmovdqu64 ZMMWORD PTR [r15+rbp*1+0x20],zmm1
   7bbfe:	62 d1 fe 48 7f 04 2f                            	vmovdqu64 ZMMWORD PTR [r15+rbp*1],zmm0
   7bc05:	49 ff c6                                        	inc    r14
   7bc08:	49 83 c5 10                                     	add    r13,0x10
   7bc0c:	49 81 fe c7 00 00 00                            	cmp    r14,0xc7
   7bc13:	0f 85 6a fe ff ff                               	jne    7ba83 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xdd3>
   7bc19:	e9 84 fc ff ff                                  	jmp    7b8a2 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xbf2>
   7bc1e:	66 90                                           	xchg   ax,ax
   7bc20:	89 34 a9                                        	mov    DWORD PTR [rcx+rbp*4],esi
   7bc23:	4c 8b bc 24 f8 07 00 00                         	mov    r15,QWORD PTR [rsp+0x7f8]
   7bc2b:	4c 3b bc 24 e8 07 00 00                         	cmp    r15,QWORD PTR [rsp+0x7e8]
   7bc33:	75 10                                           	jne    7bc45 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xf95>
   7bc35:	48 8d bc 24 e8 07 00 00                         	lea    rdi,[rsp+0x7e8]
   7bc3d:	c5 f8 77                                        	vzeroupper
   7bc40:	e8 5b 9a fb ff                                  	call   356a0 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCsii3nOZuAKF_15crossbeam_utils>
   7bc45:	48 8b 84 24 f0 07 00 00                         	mov    rax,QWORD PTR [rsp+0x7f0]
   7bc4d:	4a 89 2c f8                                     	mov    QWORD PTR [rax+r15*8],rbp
   7bc51:	49 ff c7                                        	inc    r15
   7bc54:	c5 fe 6f 84 24 50 05 00 00                      	vmovdqu ymm0,YMMWORD PTR [rsp+0x550]
   7bc5d:	4c 89 bc 24 f8 07 00 00                         	mov    QWORD PTR [rsp+0x7f8],r15
   7bc65:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7bc6a:	75 10                                           	jne    7bc7c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xfcc>
   7bc6c:	c5 fe 6f 84 24 70 05 00 00                      	vmovdqu ymm0,YMMWORD PTR [rsp+0x570]
   7bc75:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7bc7a:	74 59                                           	je     7bcd5 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1025>
   7bc7c:	48 8d 84 24 70 05 00 00                         	lea    rax,[rsp+0x570]
   7bc84:	c5 fe 6f 94 24 50 05 00 00                      	vmovdqu ymm2,YMMWORD PTR [rsp+0x550]
   7bc8d:	c5 fe 6f 0d 0b bc f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff8bc0b]        # 78a0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x900>
   7bc95:	c5 fe 6f 00                                     	vmovdqu ymm0,YMMWORD PTR [rax]
   7bc99:	48 8d 84 24 a0 01 00 00                         	lea    rax,[rsp+0x1a0]
   7bca1:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7bca5:	48 8d 84 24 c0 01 00 00                         	lea    rax,[rsp+0x1c0]
   7bcad:	c5 fe 7f 94 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm2
   7bcb6:	c5 fe 7f 08                                     	vmovdqu YMMWORD PTR [rax],ymm1
   7bcba:	48 8b ac 24 c8 07 00 00                         	mov    rbp,QWORD PTR [rsp+0x7c8]
   7bcc2:	48 3b ac 24 b8 07 00 00                         	cmp    rbp,QWORD PTR [rsp+0x7b8]
   7bcca:	0f 85 5e fd ff ff                               	jne    7ba2e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xd7e>
   7bcd0:	e9 49 fd ff ff                                  	jmp    7ba1e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xd6e>
   7bcd5:	62 f1 fe 48 6f 05 01 6a f9 ff                   	vmovdqu64 zmm0,ZMMWORD PTR [rip+0xfffffffffff96a01]        # 126e0 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x4560>
   7bcdf:	62 f1 fe 48 6f 0d d7 69 f9 ff                   	vmovdqu64 zmm1,ZMMWORD PTR [rip+0xfffffffffff969d7]        # 126c0 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x4540>
   7bce9:	62 f1 fe 48 7f 84 24 a0 01 00 00                	vmovdqu64 ZMMWORD PTR [rsp+0x1a0],zmm0
   7bcf4:	62 f1 fe 48 7f 4c 24 06                         	vmovdqu64 ZMMWORD PTR [rsp+0x180],zmm1
   7bcfc:	48 8b ac 24 c8 07 00 00                         	mov    rbp,QWORD PTR [rsp+0x7c8]
   7bd04:	48 3b ac 24 b8 07 00 00                         	cmp    rbp,QWORD PTR [rsp+0x7b8]
   7bd0c:	0f 84 0c fd ff ff                               	je     7ba1e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xd6e>
   7bd12:	e9 17 fd ff ff                                  	jmp    7ba2e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xd7e>
   7bd17:	48 8b b4 24 b0 07 00 00                         	mov    rsi,QWORD PTR [rsp+0x7b0]
   7bd1f:	48 39 c6                                        	cmp    rsi,rax
   7bd22:	0f 86 85 2f 00 00                               	jbe    7ecad <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ffd>
   7bd28:	48 8b b4 24 a8 07 00 00                         	mov    rsi,QWORD PTR [rsp+0x7a8]
   7bd30:	49 89 c0                                        	mov    r8,rax
   7bd33:	49 c1 e0 06                                     	shl    r8,0x6
   7bd37:	c4 a1 7e 6f 04 06                               	vmovdqu ymm0,YMMWORD PTR [rsi+r8*1]
   7bd3d:	4a 8d 0c 06                                     	lea    rcx,[rsi+r8*1]
   7bd41:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7bd46:	75 10                                           	jne    7bd58 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x10a8>
   7bd48:	c5 fe 6f 41 20                                  	vmovdqu ymm0,YMMWORD PTR [rcx+0x20]
   7bd4d:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7bd52:	0f 84 cb 00 00 00                               	je     7be23 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1173>
   7bd58:	c5 fe 6f 01                                     	vmovdqu ymm0,YMMWORD PTR [rcx]
   7bd5c:	c4 c1 7d ef 45 00                               	vpxor  ymm0,ymm0,YMMWORD PTR [r13+0x0]
   7bd62:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7bd67:	74 67                                           	je     7bdd0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1120>
   7bd69:	b9 01 00 00 00                                  	mov    ecx,0x1
   7bd6e:	c4 e2 f9 f7 c1                                  	shlx   rax,rcx,rax
   7bd73:	48 09 c7                                        	or     rdi,rax
   7bd76:	4a 89 3c f2                                     	mov    QWORD PTR [rdx+r14*8],rdi
   7bd7a:	4c 8b b4 24 28 08 00 00                         	mov    r14,QWORD PTR [rsp+0x828]
   7bd82:	4c 3b b4 24 18 08 00 00                         	cmp    r14,QWORD PTR [rsp+0x818]
   7bd8a:	75 10                                           	jne    7bd9c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x10ec>
   7bd8c:	48 8d bc 24 18 08 00 00                         	lea    rdi,[rsp+0x818]
   7bd94:	c5 f8 77                                        	vzeroupper
   7bd97:	e8 f4 a9 01 00                                  	call   96790 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecTmRINtNtCsgHCcee0nhgM_11zopro_bn2545curve6AffineNtBR_8G1ConfigEEE8grow_oneCsHW5vo2gROj_10zopro_core>
   7bd9c:	48 8b 84 24 20 08 00 00                         	mov    rax,QWORD PTR [rsp+0x820]
   7bda4:	4c 89 f1                                        	mov    rcx,r14
   7bda7:	48 c1 e1 04                                     	shl    rcx,0x4
   7bdab:	49 ff c6                                        	inc    r14
   7bdae:	89 2c 08                                        	mov    DWORD PTR [rax+rcx*1],ebp
   7bdb1:	4c 89 6c 08 08                                  	mov    QWORD PTR [rax+rcx*1+0x8],r13
   7bdb6:	4c 89 b4 24 28 08 00 00                         	mov    QWORD PTR [rsp+0x828],r14
   7bdbe:	49 81 fe c8 00 00 00                            	cmp    r14,0xc8
   7bdc5:	0f 85 e5 fa ff ff                               	jne    7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7bdcb:	e9 a0 02 00 00                                  	jmp    7c070 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x13c0>
   7bdd0:	85 ed                                           	test   ebp,ebp
   7bdd2:	78 71                                           	js     7be45 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1195>
   7bdd4:	62 d1 7c 48 10 45 00                            	vmovups zmm0,ZMMWORD PTR [r13+0x0]
   7bddb:	62 f1 7c 48 11 84 24 b0 00 00 00                	vmovups ZMMWORD PTR [rsp+0xb0],zmm0
   7bde6:	c5 fe 6f 41 20                                  	vmovdqu ymm0,YMMWORD PTR [rcx+0x20]
   7bdeb:	c5 fd ef 84 24 d0 00 00 00                      	vpxor  ymm0,ymm0,YMMWORD PTR [rsp+0xd0]
   7bdf4:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7bdf9:	0f 84 73 01 00 00                               	je     7bf72 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x12c2>
   7bdff:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7be03:	62 f1 fe 48 7f 01                               	vmovdqu64 ZMMWORD PTR [rcx],zmm0
   7be09:	4c 8b b4 24 28 08 00 00                         	mov    r14,QWORD PTR [rsp+0x828]
   7be11:	49 81 fe c8 00 00 00                            	cmp    r14,0xc8
   7be18:	0f 85 92 fa ff ff                               	jne    7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7be1e:	e9 4d 02 00 00                                  	jmp    7c070 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x13c0>
   7be23:	85 ed                                           	test   ebp,ebp
   7be25:	0f 88 7c 01 00 00                               	js     7bfa7 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x12f7>
   7be2b:	c4 c1 7c 10 45 00                               	vmovups ymm0,YMMWORD PTR [r13+0x0]
   7be31:	c5 fc 11 84 24 80 01 00 00                      	vmovups YMMWORD PTR [rsp+0x180],ymm0
   7be3a:	c4 c1 7e 6f 45 20                               	vmovdqu ymm0,YMMWORD PTR [r13+0x20]
   7be40:	e9 04 02 00 00                                  	jmp    7c049 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1399>
   7be45:	c4 c1 7c 10 45 20                               	vmovups ymm0,YMMWORD PTR [r13+0x20]
   7be4b:	48 c7 44 24 50 00 00 00 00                      	mov    QWORD PTR [rsp+0x50],0x0
   7be54:	48 c7 44 24 38 00 00 00 00                      	mov    QWORD PTR [rsp+0x38],0x0
   7be5d:	48 c7 44 24 58 00 00 00 00                      	mov    QWORD PTR [rsp+0x58],0x0
   7be66:	48 c7 84 24 80 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x80],0x0
   7be72:	48 89 8c 24 f8 00 00 00                         	mov    QWORD PTR [rsp+0xf8],rcx
   7be7a:	4c 8d bc 24 50 05 00 00                         	lea    r15,[rsp+0x550]
   7be82:	48 8d 94 24 80 01 00 00                         	lea    rdx,[rsp+0x180]
   7be8a:	48 8b 74 24 50                                  	mov    rsi,QWORD PTR [rsp+0x50]
   7be8f:	48 8b 7c 24 38                                  	mov    rdi,QWORD PTR [rsp+0x38]
   7be94:	4c 8b 44 24 58                                  	mov    r8,QWORD PTR [rsp+0x58]
   7be99:	48 8b 8c 24 80 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x80]
   7bea1:	c5 fc 11 84 24 50 05 00 00                      	vmovups YMMWORD PTR [rsp+0x550],ymm0
   7beaa:	c5 fc 10 05 2e ba f8 ff                         	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffff8ba2e]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   7beb2:	c5 fc 11 84 24 80 01 00 00                      	vmovups YMMWORD PTR [rsp+0x180],ymm0
   7bebb:	49 2b 3f                                        	sub    rdi,QWORD PTR [r15]
   7bebe:	4d 1b 47 08                                     	sbb    r8,QWORD PTR [r15+0x8]
   7bec2:	49 1b 4f 10                                     	sbb    rcx,QWORD PTR [r15+0x10]
   7bec6:	49 1b 77 18                                     	sbb    rsi,QWORD PTR [r15+0x18]
   7beca:	4d 19 f6                                        	sbb    r14,r14
   7becd:	4c 8b 0a                                        	mov    r9,QWORD PTR [rdx]
   7bed0:	4c 8b 52 08                                     	mov    r10,QWORD PTR [rdx+0x8]
   7bed4:	4c 8b 5a 10                                     	mov    r11,QWORD PTR [rdx+0x10]
   7bed8:	48 8b 6a 18                                     	mov    rbp,QWORD PTR [rdx+0x18]
   7bedc:	4d 21 f1                                        	and    r9,r14
   7bedf:	4d 21 f2                                        	and    r10,r14
   7bee2:	4d 21 f3                                        	and    r11,r14
   7bee5:	4c 21 f5                                        	and    rbp,r14
   7bee8:	4c 01 cf                                        	add    rdi,r9
   7beeb:	4d 11 d0                                        	adc    r8,r10
   7beee:	4c 11 d9                                        	adc    rcx,r11
   7bef1:	48 11 ee                                        	adc    rsi,rbp
   7bef4:	48 89 7c 24 38                                  	mov    QWORD PTR [rsp+0x38],rdi
   7bef9:	4c 89 44 24 58                                  	mov    QWORD PTR [rsp+0x58],r8
   7befe:	48 89 8c 24 80 00 00 00                         	mov    QWORD PTR [rsp+0x80],rcx
   7bf06:	48 89 74 24 50                                  	mov    QWORD PTR [rsp+0x50],rsi
   7bf0b:	c4 c1 7c 10 45 00                               	vmovups ymm0,YMMWORD PTR [r13+0x0]
   7bf11:	48 8b 54 24 38                                  	mov    rdx,QWORD PTR [rsp+0x38]
   7bf16:	48 8b 4c 24 58                                  	mov    rcx,QWORD PTR [rsp+0x58]
   7bf1b:	48 8b 74 24 50                                  	mov    rsi,QWORD PTR [rsp+0x50]
   7bf20:	c5 fc 11 84 24 b0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xb0],ymm0
   7bf29:	48 89 94 24 d0 00 00 00                         	mov    QWORD PTR [rsp+0xd0],rdx
   7bf31:	48 89 8c 24 d8 00 00 00                         	mov    QWORD PTR [rsp+0xd8],rcx
   7bf39:	48 8b 8c 24 80 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x80]
   7bf41:	48 89 8c 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],rcx
   7bf49:	48 8b 8c 24 f8 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xf8]
   7bf51:	48 89 b4 24 e8 00 00 00                         	mov    QWORD PTR [rsp+0xe8],rsi
   7bf59:	c5 fe 6f 41 20                                  	vmovdqu ymm0,YMMWORD PTR [rcx+0x20]
   7bf5e:	c5 fd ef 84 24 d0 00 00 00                      	vpxor  ymm0,ymm0,YMMWORD PTR [rsp+0xd0]
   7bf67:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7bf6c:	0f 85 8d fe ff ff                               	jne    7bdff <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x114f>
   7bf72:	48 8d bc 24 a0 07 00 00                         	lea    rdi,[rsp+0x7a0]
   7bf7a:	48 8d 94 24 b0 00 00 00                         	lea    rdx,[rsp+0xb0]
   7bf82:	48 89 c6                                        	mov    rsi,rax
   7bf85:	c5 f8 77                                        	vzeroupper
   7bf88:	e8 63 04 01 00                                  	call   8c3f0 <_RNvMNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pendingINtB2_6WindowNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigE10projectiveB6_>
   7bf8d:	4c 8b b4 24 28 08 00 00                         	mov    r14,QWORD PTR [rsp+0x828]
   7bf95:	49 81 fe c8 00 00 00                            	cmp    r14,0xc8
   7bf9c:	0f 85 0e f9 ff ff                               	jne    7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7bfa2:	e9 c9 00 00 00                                  	jmp    7c070 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x13c0>
   7bfa7:	c4 c1 7c 10 45 20                               	vmovups ymm0,YMMWORD PTR [r13+0x20]
   7bfad:	31 c0                                           	xor    eax,eax
   7bfaf:	31 d2                                           	xor    edx,edx
   7bfb1:	31 f6                                           	xor    esi,esi
   7bfb3:	31 ff                                           	xor    edi,edi
   7bfb5:	4c 8d b4 24 50 05 00 00                         	lea    r14,[rsp+0x550]
   7bfbd:	4c 8d bc 24 80 01 00 00                         	lea    r15,[rsp+0x180]
   7bfc5:	c5 fc 11 84 24 50 05 00 00                      	vmovups YMMWORD PTR [rsp+0x550],ymm0
   7bfce:	c5 fc 10 05 0a b9 f8 ff                         	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffff8b90a]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   7bfd6:	c5 fc 11 84 24 80 01 00 00                      	vmovups YMMWORD PTR [rsp+0x180],ymm0
   7bfdf:	49 2b 06                                        	sub    rax,QWORD PTR [r14]
   7bfe2:	49 1b 56 08                                     	sbb    rdx,QWORD PTR [r14+0x8]
   7bfe6:	49 1b 76 10                                     	sbb    rsi,QWORD PTR [r14+0x10]
   7bfea:	49 1b 7e 18                                     	sbb    rdi,QWORD PTR [r14+0x18]
   7bfee:	48 19 ed                                        	sbb    rbp,rbp
   7bff1:	4d 8b 07                                        	mov    r8,QWORD PTR [r15]
   7bff4:	4d 8b 4f 08                                     	mov    r9,QWORD PTR [r15+0x8]
   7bff8:	4d 8b 57 10                                     	mov    r10,QWORD PTR [r15+0x10]
   7bffc:	4d 8b 5f 18                                     	mov    r11,QWORD PTR [r15+0x18]
   7c000:	49 21 e8                                        	and    r8,rbp
   7c003:	49 21 e9                                        	and    r9,rbp
   7c006:	49 21 ea                                        	and    r10,rbp
   7c009:	49 21 eb                                        	and    r11,rbp
   7c00c:	4c 01 c0                                        	add    rax,r8
   7c00f:	4c 11 ca                                        	adc    rdx,r9
   7c012:	4c 11 d6                                        	adc    rsi,r10
   7c015:	4c 11 df                                        	adc    rdi,r11
   7c018:	c4 e1 f9 6e ce                                  	vmovq  xmm1,rsi
   7c01d:	c4 e1 f9 6e d0                                  	vmovq  xmm2,rax
   7c022:	c4 c1 7c 10 45 00                               	vmovups ymm0,YMMWORD PTR [r13+0x0]
   7c028:	c5 fc 11 84 24 80 01 00 00                      	vmovups YMMWORD PTR [rsp+0x180],ymm0
   7c031:	c4 e1 f9 6e c7                                  	vmovq  xmm0,rdi
   7c036:	c5 f1 6c c0                                     	vpunpcklqdq xmm0,xmm1,xmm0
   7c03a:	c4 e1 f9 6e ca                                  	vmovq  xmm1,rdx
   7c03f:	c5 e9 6c c9                                     	vpunpcklqdq xmm1,xmm2,xmm1
   7c043:	c4 e3 75 38 c0 01                               	vinserti128 ymm0,ymm1,xmm0,0x1
   7c049:	c5 fe 6f 8c 24 80 01 00 00                      	vmovdqu ymm1,YMMWORD PTR [rsp+0x180]
   7c052:	c5 fe 7f 09                                     	vmovdqu YMMWORD PTR [rcx],ymm1
   7c056:	c5 fe 7f 41 20                                  	vmovdqu YMMWORD PTR [rcx+0x20],ymm0
   7c05b:	4c 8b b4 24 28 08 00 00                         	mov    r14,QWORD PTR [rsp+0x828]
   7c063:	49 81 fe c8 00 00 00                            	cmp    r14,0xc8
   7c06a:	0f 85 40 f8 ff ff                               	jne    7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7c070:	48 8b bc 24 a8 07 00 00                         	mov    rdi,QWORD PTR [rsp+0x7a8]
   7c078:	48 8b b4 24 b0 07 00 00                         	mov    rsi,QWORD PTR [rsp+0x7b0]
   7c080:	48 8b 94 24 20 08 00 00                         	mov    rdx,QWORD PTR [rsp+0x820]
   7c088:	80 bc 24 13 0b 00 00 00                         	cmp    BYTE PTR [rsp+0xb13],0x0
   7c090:	74 17                                           	je     7c0a9 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x13f9>
   7c092:	b9 c8 00 00 00                                  	mov    ecx,0xc8
   7c097:	4c 8d 84 24 e0 0a 00 00                         	lea    r8,[rsp+0xae0]
   7c09f:	c5 f8 77                                        	vzeroupper
   7c0a2:	e8 39 9d 00 00                                  	call   85de0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_>
   7c0a7:	eb 15                                           	jmp    7c0be <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x140e>
   7c0a9:	b9 c8 00 00 00                                  	mov    ecx,0xc8
   7c0ae:	4c 8d 84 24 e0 0a 00 00                         	lea    r8,[rsp+0xae0]
   7c0b6:	c5 f8 77                                        	vzeroupper
   7c0b9:	e8 22 34 00 00                                  	call   7f4e0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_>
   7c0be:	48 8b 84 24 28 08 00 00                         	mov    rax,QWORD PTR [rsp+0x828]
   7c0c6:	48 85 c0                                        	test   rax,rax
   7c0c9:	74 4b                                           	je     7c116 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1466>
   7c0cb:	48 8b 8c 24 20 08 00 00                         	mov    rcx,QWORD PTR [rsp+0x820]
   7c0d3:	48 8b 94 24 08 08 00 00                         	mov    rdx,QWORD PTR [rsp+0x808]
   7c0db:	48 8b b4 24 10 08 00 00                         	mov    rsi,QWORD PTR [rsp+0x810]
   7c0e3:	48 c1 e0 04                                     	shl    rax,0x4
   7c0e7:	31 ff                                           	xor    edi,edi
   7c0e9:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   7c0f0:	41 b8 06 19 00 00                               	mov    r8d,0x1906
   7c0f6:	c4 62 38 f7 34 39                               	bextr  r14d,DWORD PTR [rcx+rdi*1],r8d
   7c0fc:	4c 39 f6                                        	cmp    rsi,r14
   7c0ff:	0f 86 96 2b 00 00                               	jbe    7ec9b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3feb>
   7c105:	48 83 c7 10                                     	add    rdi,0x10
   7c109:	4a c7 04 f2 00 00 00 00                         	mov    QWORD PTR [rdx+r14*8],0x0
   7c111:	48 39 f8                                        	cmp    rax,rdi
   7c114:	75 da                                           	jne    7c0f0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1440>
   7c116:	48 c7 84 24 28 08 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x828],0x0
   7c122:	eb 2e                                           	jmp    7c152 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x14a2>
   7c124:	66 66 66 2e 0f 1f 84 00 00 00 00 00             	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7c130:	48 8b 84 24 20 08 00 00                         	mov    rax,QWORD PTR [rsp+0x820]
   7c138:	4c 89 f1                                        	mov    rcx,r14
   7c13b:	48 c1 e1 04                                     	shl    rcx,0x4
   7c13f:	49 ff c6                                        	inc    r14
   7c142:	89 2c 08                                        	mov    DWORD PTR [rax+rcx*1],ebp
   7c145:	4c 89 6c 08 08                                  	mov    QWORD PTR [rax+rcx*1+0x8],r13
   7c14a:	4c 89 b4 24 28 08 00 00                         	mov    QWORD PTR [rsp+0x828],r14
   7c152:	48 8b 8c 24 40 08 00 00                         	mov    rcx,QWORD PTR [rsp+0x840]
   7c15a:	48 85 c9                                        	test   rcx,rcx
   7c15d:	0f 84 4d f7 ff ff                               	je     7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7c163:	48 8b bc 24 38 08 00 00                         	mov    rdi,QWORD PTR [rsp+0x838]
   7c16b:	48 ff c9                                        	dec    rcx
   7c16e:	48 8b b4 24 10 08 00 00                         	mov    rsi,QWORD PTR [rsp+0x810]
   7c176:	49 89 c8                                        	mov    r8,rcx
   7c179:	49 c1 e0 04                                     	shl    r8,0x4
   7c17d:	42 8b 2c 07                                     	mov    ebp,DWORD PTR [rdi+r8*1]
   7c181:	89 e8                                           	mov    eax,ebp
   7c183:	25 ff ff ff 7f                                  	and    eax,0x7fffffff
   7c188:	41 89 c6                                        	mov    r14d,eax
   7c18b:	41 c1 ee 06                                     	shr    r14d,0x6
   7c18f:	49 39 f6                                        	cmp    r14,rsi
   7c192:	0f 83 0c 2b 00 00                               	jae    7eca4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ff4>
   7c198:	48 8b 94 24 08 08 00 00                         	mov    rdx,QWORD PTR [rsp+0x808]
   7c1a0:	4a 8b 34 f2                                     	mov    rsi,QWORD PTR [rdx+r14*8]
   7c1a4:	48 0f a3 c6                                     	bt     rsi,rax
   7c1a8:	0f 82 02 f7 ff ff                               	jb     7b8b0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0xc00>
   7c1ae:	4e 8b 6c 07 08                                  	mov    r13,QWORD PTR [rdi+r8*1+0x8]
   7c1b3:	48 89 8c 24 40 08 00 00                         	mov    QWORD PTR [rsp+0x840],rcx
   7c1bb:	48 8b b4 24 b0 07 00 00                         	mov    rsi,QWORD PTR [rsp+0x7b0]
   7c1c3:	48 39 c6                                        	cmp    rsi,rax
   7c1c6:	0f 86 e1 2a 00 00                               	jbe    7ecad <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ffd>
   7c1cc:	48 8b b4 24 a8 07 00 00                         	mov    rsi,QWORD PTR [rsp+0x7a8]
   7c1d4:	48 89 c7                                        	mov    rdi,rax
   7c1d7:	48 c1 e7 06                                     	shl    rdi,0x6
   7c1db:	c5 fe 6f 04 3e                                  	vmovdqu ymm0,YMMWORD PTR [rsi+rdi*1]
   7c1e0:	48 8d 0c 3e                                     	lea    rcx,[rsi+rdi*1]
   7c1e4:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7c1e9:	75 10                                           	jne    7c1fb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x154b>
   7c1eb:	c5 fe 6f 41 20                                  	vmovdqu ymm0,YMMWORD PTR [rcx+0x20]
   7c1f0:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7c1f5:	0f 84 90 00 00 00                               	je     7c28b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x15db>
   7c1fb:	c5 fe 6f 01                                     	vmovdqu ymm0,YMMWORD PTR [rcx]
   7c1ff:	c4 c1 7d ef 45 00                               	vpxor  ymm0,ymm0,YMMWORD PTR [r13+0x0]
   7c205:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7c20a:	74 44                                           	je     7c250 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x15a0>
   7c20c:	b9 01 00 00 00                                  	mov    ecx,0x1
   7c211:	c4 e2 f9 f7 c1                                  	shlx   rax,rcx,rax
   7c216:	4a 09 04 f2                                     	or     QWORD PTR [rdx+r14*8],rax
   7c21a:	4c 8b b4 24 28 08 00 00                         	mov    r14,QWORD PTR [rsp+0x828]
   7c222:	4c 3b b4 24 18 08 00 00                         	cmp    r14,QWORD PTR [rsp+0x818]
   7c22a:	0f 85 00 ff ff ff                               	jne    7c130 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1480>
   7c230:	48 8d bc 24 18 08 00 00                         	lea    rdi,[rsp+0x818]
   7c238:	c5 f8 77                                        	vzeroupper
   7c23b:	e8 50 a5 01 00                                  	call   96790 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecTmRINtNtCsgHCcee0nhgM_11zopro_bn2545curve6AffineNtBR_8G1ConfigEEE8grow_oneCsHW5vo2gROj_10zopro_core>
   7c240:	e9 eb fe ff ff                                  	jmp    7c130 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1480>
   7c245:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   7c250:	85 ed                                           	test   ebp,ebp
   7c252:	78 59                                           	js     7c2ad <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x15fd>
   7c254:	62 d1 7c 48 10 45 00                            	vmovups zmm0,ZMMWORD PTR [r13+0x0]
   7c25b:	62 f1 7c 48 11 44 24 06                         	vmovups ZMMWORD PTR [rsp+0x180],zmm0
   7c263:	c5 fe 6f 41 20                                  	vmovdqu ymm0,YMMWORD PTR [rcx+0x20]
   7c268:	c5 fd ef 84 24 a0 01 00 00                      	vpxor  ymm0,ymm0,YMMWORD PTR [rsp+0x1a0]
   7c271:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7c276:	0f 84 ea 00 00 00                               	je     7c366 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x16b6>
   7c27c:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7c280:	62 f1 fe 48 7f 01                               	vmovdqu64 ZMMWORD PTR [rcx],zmm0
   7c286:	e9 c7 fe ff ff                                  	jmp    7c152 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x14a2>
   7c28b:	85 ed                                           	test   ebp,ebp
   7c28d:	0f 88 f3 00 00 00                               	js     7c386 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x16d6>
   7c293:	c4 c1 7c 10 45 00                               	vmovups ymm0,YMMWORD PTR [r13+0x0]
   7c299:	c5 fc 11 84 24 50 05 00 00                      	vmovups YMMWORD PTR [rsp+0x550],ymm0
   7c2a2:	c4 c1 7e 6f 45 20                               	vmovdqu ymm0,YMMWORD PTR [r13+0x20]
   7c2a8:	e9 7a 01 00 00                                  	jmp    7c427 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1777>
   7c2ad:	c4 c1 7c 10 45 20                               	vmovups ymm0,YMMWORD PTR [r13+0x20]
   7c2b3:	31 d2                                           	xor    edx,edx
   7c2b5:	31 f6                                           	xor    esi,esi
   7c2b7:	31 ff                                           	xor    edi,edi
   7c2b9:	45 31 c0                                        	xor    r8d,r8d
   7c2bc:	4c 8d bc 24 50 05 00 00                         	lea    r15,[rsp+0x550]
   7c2c4:	48 8d 5c 24 60                                  	lea    rbx,[rsp+0x60]
   7c2c9:	c5 fc 11 44 24 60                               	vmovups YMMWORD PTR [rsp+0x60],ymm0
   7c2cf:	c5 fc 10 05 09 b6 f8 ff                         	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffff8b609]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   7c2d7:	c5 fc 11 84 24 50 05 00 00                      	vmovups YMMWORD PTR [rsp+0x550],ymm0
   7c2e0:	48 2b 13                                        	sub    rdx,QWORD PTR [rbx]
   7c2e3:	48 1b 73 08                                     	sbb    rsi,QWORD PTR [rbx+0x8]
   7c2e7:	48 1b 7b 10                                     	sbb    rdi,QWORD PTR [rbx+0x10]
   7c2eb:	4c 1b 43 18                                     	sbb    r8,QWORD PTR [rbx+0x18]
   7c2ef:	4d 19 f6                                        	sbb    r14,r14
   7c2f2:	4d 8b 0f                                        	mov    r9,QWORD PTR [r15]
   7c2f5:	4d 8b 57 08                                     	mov    r10,QWORD PTR [r15+0x8]
   7c2f9:	4d 8b 5f 10                                     	mov    r11,QWORD PTR [r15+0x10]
   7c2fd:	49 8b 6f 18                                     	mov    rbp,QWORD PTR [r15+0x18]
   7c301:	4d 21 f1                                        	and    r9,r14
   7c304:	4d 21 f2                                        	and    r10,r14
   7c307:	4d 21 f3                                        	and    r11,r14
   7c30a:	4c 21 f5                                        	and    rbp,r14
   7c30d:	4c 01 ca                                        	add    rdx,r9
   7c310:	4c 11 d6                                        	adc    rsi,r10
   7c313:	4c 11 df                                        	adc    rdi,r11
   7c316:	49 11 e8                                        	adc    r8,rbp
   7c319:	bb ff ff ff ff                                  	mov    ebx,0xffffffff
   7c31e:	c4 c1 7c 10 45 00                               	vmovups ymm0,YMMWORD PTR [r13+0x0]
   7c324:	c5 fc 11 84 24 80 01 00 00                      	vmovups YMMWORD PTR [rsp+0x180],ymm0
   7c32d:	48 89 94 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rdx
   7c335:	48 89 b4 24 a8 01 00 00                         	mov    QWORD PTR [rsp+0x1a8],rsi
   7c33d:	48 89 bc 24 b0 01 00 00                         	mov    QWORD PTR [rsp+0x1b0],rdi
   7c345:	4c 89 84 24 b8 01 00 00                         	mov    QWORD PTR [rsp+0x1b8],r8
   7c34d:	c5 fe 6f 41 20                                  	vmovdqu ymm0,YMMWORD PTR [rcx+0x20]
   7c352:	c5 fd ef 84 24 a0 01 00 00                      	vpxor  ymm0,ymm0,YMMWORD PTR [rsp+0x1a0]
   7c35b:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7c360:	0f 85 16 ff ff ff                               	jne    7c27c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x15cc>
   7c366:	48 8d bc 24 a0 07 00 00                         	lea    rdi,[rsp+0x7a0]
   7c36e:	48 8d 94 24 80 01 00 00                         	lea    rdx,[rsp+0x180]
   7c376:	48 89 c6                                        	mov    rsi,rax
   7c379:	c5 f8 77                                        	vzeroupper
   7c37c:	e8 6f 00 01 00                                  	call   8c3f0 <_RNvMNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pendingINtB2_6WindowNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigE10projectiveB6_>
   7c381:	e9 cc fd ff ff                                  	jmp    7c152 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x14a2>
   7c386:	c4 c1 7c 10 45 20                               	vmovups ymm0,YMMWORD PTR [r13+0x20]
   7c38c:	31 c0                                           	xor    eax,eax
   7c38e:	31 d2                                           	xor    edx,edx
   7c390:	31 f6                                           	xor    esi,esi
   7c392:	31 ff                                           	xor    edi,edi
   7c394:	4c 8d b4 24 50 05 00 00                         	lea    r14,[rsp+0x550]
   7c39c:	48 8d 5c 24 60                                  	lea    rbx,[rsp+0x60]
   7c3a1:	c5 fc 11 44 24 60                               	vmovups YMMWORD PTR [rsp+0x60],ymm0
   7c3a7:	c5 fc 10 05 31 b5 f8 ff                         	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffff8b531]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   7c3af:	c5 fc 11 84 24 50 05 00 00                      	vmovups YMMWORD PTR [rsp+0x550],ymm0
   7c3b8:	48 2b 13                                        	sub    rdx,QWORD PTR [rbx]
   7c3bb:	48 1b 73 08                                     	sbb    rsi,QWORD PTR [rbx+0x8]
   7c3bf:	48 1b 7b 10                                     	sbb    rdi,QWORD PTR [rbx+0x10]
   7c3c3:	48 1b 43 18                                     	sbb    rax,QWORD PTR [rbx+0x18]
   7c3c7:	48 19 ed                                        	sbb    rbp,rbp
   7c3ca:	4d 8b 06                                        	mov    r8,QWORD PTR [r14]
   7c3cd:	4d 8b 4e 08                                     	mov    r9,QWORD PTR [r14+0x8]
   7c3d1:	4d 8b 56 10                                     	mov    r10,QWORD PTR [r14+0x10]
   7c3d5:	4d 8b 5e 18                                     	mov    r11,QWORD PTR [r14+0x18]
   7c3d9:	49 21 e8                                        	and    r8,rbp
   7c3dc:	49 21 e9                                        	and    r9,rbp
   7c3df:	49 21 ea                                        	and    r10,rbp
   7c3e2:	49 21 eb                                        	and    r11,rbp
   7c3e5:	4c 01 c2                                        	add    rdx,r8
   7c3e8:	4c 11 ce                                        	adc    rsi,r9
   7c3eb:	4c 11 d7                                        	adc    rdi,r10
   7c3ee:	4c 11 d8                                        	adc    rax,r11
   7c3f1:	c4 e1 f9 6e cf                                  	vmovq  xmm1,rdi
   7c3f6:	c4 e1 f9 6e d2                                  	vmovq  xmm2,rdx
   7c3fb:	bb ff ff ff ff                                  	mov    ebx,0xffffffff
   7c400:	c4 c1 7c 10 45 00                               	vmovups ymm0,YMMWORD PTR [r13+0x0]
   7c406:	c5 fc 11 84 24 50 05 00 00                      	vmovups YMMWORD PTR [rsp+0x550],ymm0
   7c40f:	c4 e1 f9 6e c0                                  	vmovq  xmm0,rax
   7c414:	c5 f1 6c c0                                     	vpunpcklqdq xmm0,xmm1,xmm0
   7c418:	c4 e1 f9 6e ce                                  	vmovq  xmm1,rsi
   7c41d:	c5 e9 6c c9                                     	vpunpcklqdq xmm1,xmm2,xmm1
   7c421:	c4 e3 75 38 c0 01                               	vinserti128 ymm0,ymm1,xmm0,0x1
   7c427:	c5 fe 6f 8c 24 50 05 00 00                      	vmovdqu ymm1,YMMWORD PTR [rsp+0x550]
   7c430:	c5 fe 7f 09                                     	vmovdqu YMMWORD PTR [rcx],ymm1
   7c434:	c5 fe 7f 41 20                                  	vmovdqu YMMWORD PTR [rcx+0x20],ymm0
   7c439:	e9 14 fd ff ff                                  	jmp    7c152 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x14a2>
   7c43e:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7c446:	48 8d b4 24 a0 07 00 00                         	lea    rsi,[rsp+0x7a0]
   7c44e:	ba d0 03 00 00                                  	mov    edx,0x3d0
   7c453:	c5 f8 77                                        	vzeroupper
   7c456:	ff 15 4c e3 01 00                               	call   QWORD PTR [rip+0x1e34c]        # 9a7a8 <memcpy@GLIBC_2.14>
   7c45c:	48 8b 8c 24 08 02 00 00                         	mov    rcx,QWORD PTR [rsp+0x208]
   7c464:	48 85 c9                                        	test   rcx,rcx
   7c467:	0f 84 9f 00 00 00                               	je     7c50c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x185c>
   7c46d:	48 8b bc 24 88 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x188]
   7c475:	48 8b b4 24 90 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x190]
   7c47d:	48 8b 94 24 00 02 00 00                         	mov    rdx,QWORD PTR [rsp+0x200]
   7c485:	80 bc 24 f3 04 00 00 00                         	cmp    BYTE PTR [rsp+0x4f3],0x0
   7c48d:	4c 8d 84 24 c0 04 00 00                         	lea    r8,[rsp+0x4c0]
   7c495:	74 07                                           	je     7c49e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x17ee>
   7c497:	e8 44 99 00 00                                  	call   85de0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb1_KB1y_RINtBP_6AffineBN_EEB4_>
   7c49c:	eb 05                                           	jmp    7c4a3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x17f3>
   7c49e:	e8 3d 30 00 00                                  	call   7f4e0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm14stream_g1_implNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigKb0_Kb1_RINtBP_6AffineBN_EEB4_>
   7c4a3:	48 8b 84 24 08 02 00 00                         	mov    rax,QWORD PTR [rsp+0x208]
   7c4ab:	48 85 c0                                        	test   rax,rax
   7c4ae:	74 50                                           	je     7c500 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1850>
   7c4b0:	48 8b 8c 24 00 02 00 00                         	mov    rcx,QWORD PTR [rsp+0x200]
   7c4b8:	48 8b 94 24 e8 01 00 00                         	mov    rdx,QWORD PTR [rsp+0x1e8]
   7c4c0:	48 8b b4 24 f0 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x1f0]
   7c4c8:	48 c1 e0 04                                     	shl    rax,0x4
   7c4cc:	41 b8 06 19 00 00                               	mov    r8d,0x1906
   7c4d2:	4c 8d 0d 5f df 01 00                            	lea    r9,[rip+0x1df5f]        # 9a438 <__frame_dummy_init_array_entry+0x25e8>
   7c4d9:	31 ff                                           	xor    edi,edi
   7c4db:	0f 1f 44 00 00                                  	nop    DWORD PTR [rax+rax*1+0x0]
   7c4e0:	c4 62 38 f7 34 39                               	bextr  r14d,DWORD PTR [rcx+rdi*1],r8d
   7c4e6:	4c 39 f6                                        	cmp    rsi,r14
   7c4e9:	0f 86 d8 27 00 00                               	jbe    7ecc7 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4017>
   7c4ef:	48 83 c7 10                                     	add    rdi,0x10
   7c4f3:	4a c7 04 f2 00 00 00 00                         	mov    QWORD PTR [rdx+r14*8],0x0
   7c4fb:	48 39 f8                                        	cmp    rax,rdi
   7c4fe:	75 e0                                           	jne    7c4e0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1830>
   7c500:	48 c7 84 24 08 02 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x208],0x0
   7c50c:	4c 8b a4 24 20 02 00 00                         	mov    r12,QWORD PTR [rsp+0x220]
   7c514:	4d 85 e4                                        	test   r12,r12
   7c517:	0f 84 42 01 00 00                               	je     7c65f <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x19af>
   7c51d:	48 8d 05 b4 de 01 00                            	lea    rax,[rip+0x1deb4]        # 9a3d8 <__frame_dummy_init_array_entry+0x2588>
   7c524:	bd 08 00 00 00                                  	mov    ebp,0x8
   7c529:	48 8d 9c 24 80 01 00 00                         	lea    rbx,[rsp+0x180]
   7c531:	4c 8d bc 24 50 05 00 00                         	lea    r15,[rsp+0x550]
   7c539:	45 31 f6                                        	xor    r14d,r14d
   7c53c:	4c 89 64 24 48                                  	mov    QWORD PTR [rsp+0x48],r12
   7c541:	48 89 44 24 10                                  	mov    QWORD PTR [rsp+0x10],rax
   7c546:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   7c550:	48 8b b4 24 20 02 00 00                         	mov    rsi,QWORD PTR [rsp+0x220]
   7c558:	49 39 f6                                        	cmp    r14,rsi
   7c55b:	0f 83 6b 27 00 00                               	jae    7eccc <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x401c>
   7c561:	48 8b 84 24 18 02 00 00                         	mov    rax,QWORD PTR [rsp+0x218]
   7c569:	8b 74 28 f8                                     	mov    esi,DWORD PTR [rax+rbp*1-0x8]
   7c56d:	48 8b 04 28                                     	mov    rax,QWORD PTR [rax+rbp*1]
   7c571:	85 f6                                           	test   esi,esi
   7c573:	78 1b                                           	js     7c590 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x18e0>
   7c575:	62 f1 fe 48 6f 00                               	vmovdqu64 zmm0,ZMMWORD PTR [rax]
   7c57b:	62 f1 fe 48 7f 84 24 50 05 00 00                	vmovdqu64 ZMMWORD PTR [rsp+0x550],zmm0
   7c586:	e9 b0 00 00 00                                  	jmp    7c63b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x198b>
   7c58b:	0f 1f 44 00 00                                  	nop    DWORD PTR [rax+rax*1+0x0]
   7c590:	c5 fc 10 00                                     	vmovups ymm0,YMMWORD PTR [rax]
   7c594:	c5 fe 6f 0d 44 b3 f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff8b344]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   7c59c:	31 c9                                           	xor    ecx,ecx
   7c59e:	31 d2                                           	xor    edx,edx
   7c5a0:	31 ff                                           	xor    edi,edi
   7c5a2:	4c 8d 7c 24 60                                  	lea    r15,[rsp+0x60]
   7c5a7:	49 89 dc                                        	mov    r12,rbx
   7c5aa:	4c 8d ac 24 b0 00 00 00                         	lea    r13,[rsp+0xb0]
   7c5b2:	c5 fc 11 84 24 50 05 00 00                      	vmovups YMMWORD PTR [rsp+0x550],ymm0
   7c5bb:	c5 fe 6f 40 20                                  	vmovdqu ymm0,YMMWORD PTR [rax+0x20]
   7c5c0:	c5 fe 7f 8c 24 b0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xb0],ymm1
   7c5c9:	31 c0                                           	xor    eax,eax
   7c5cb:	c5 fe 7f 44 24 60                               	vmovdqu YMMWORD PTR [rsp+0x60],ymm0
   7c5d1:	49 2b 07                                        	sub    rax,QWORD PTR [r15]
   7c5d4:	49 1b 4f 08                                     	sbb    rcx,QWORD PTR [r15+0x8]
   7c5d8:	49 1b 57 10                                     	sbb    rdx,QWORD PTR [r15+0x10]
   7c5dc:	49 1b 7f 18                                     	sbb    rdi,QWORD PTR [r15+0x18]
   7c5e0:	48 19 db                                        	sbb    rbx,rbx
   7c5e3:	4d 8b 45 00                                     	mov    r8,QWORD PTR [r13+0x0]
   7c5e7:	4d 8b 4d 08                                     	mov    r9,QWORD PTR [r13+0x8]
   7c5eb:	4d 8b 55 10                                     	mov    r10,QWORD PTR [r13+0x10]
   7c5ef:	4d 8b 5d 18                                     	mov    r11,QWORD PTR [r13+0x18]
   7c5f3:	49 21 d8                                        	and    r8,rbx
   7c5f6:	49 21 d9                                        	and    r9,rbx
   7c5f9:	49 21 da                                        	and    r10,rbx
   7c5fc:	49 21 db                                        	and    r11,rbx
   7c5ff:	4c 01 c0                                        	add    rax,r8
   7c602:	4c 11 c9                                        	adc    rcx,r9
   7c605:	4c 11 d2                                        	adc    rdx,r10
   7c608:	4c 11 df                                        	adc    rdi,r11
   7c60b:	4c 89 e3                                        	mov    rbx,r12
   7c60e:	4c 8d bc 24 50 05 00 00                         	lea    r15,[rsp+0x550]
   7c616:	48 89 84 24 70 05 00 00                         	mov    QWORD PTR [rsp+0x570],rax
   7c61e:	48 89 8c 24 78 05 00 00                         	mov    QWORD PTR [rsp+0x578],rcx
   7c626:	48 89 94 24 80 05 00 00                         	mov    QWORD PTR [rsp+0x580],rdx
   7c62e:	48 89 bc 24 88 05 00 00                         	mov    QWORD PTR [rsp+0x588],rdi
   7c636:	4c 8b 64 24 48                                  	mov    r12,QWORD PTR [rsp+0x48]
   7c63b:	81 e6 ff ff ff 7f                               	and    esi,0x7fffffff
   7c641:	48 89 df                                        	mov    rdi,rbx
   7c644:	4c 89 fa                                        	mov    rdx,r15
   7c647:	c5 f8 77                                        	vzeroupper
   7c64a:	e8 a1 fd 00 00                                  	call   8c3f0 <_RNvMNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pendingINtB2_6WindowNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigE10projectiveB6_>
   7c64f:	49 ff c6                                        	inc    r14
   7c652:	48 83 c5 10                                     	add    rbp,0x10
   7c656:	4d 39 f4                                        	cmp    r12,r14
   7c659:	0f 85 f1 fe ff ff                               	jne    7c550 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x18a0>
   7c65f:	48 c7 84 24 20 02 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x220],0x0
   7c66b:	48 b8 55 55 55 55 55 55 55 01                   	movabs rax,0x155555555555555
   7c675:	48 8b 9c 24 a8 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x1a8]
   7c67d:	48 8b 8c 24 d8 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x1d8]
   7c685:	48 39 d9                                        	cmp    rcx,rbx
   7c688:	48 0f 42 d9                                     	cmovb  rbx,rcx
   7c68c:	49 89 df                                        	mov    r15,rbx
   7c68f:	49 c1 e7 05                                     	shl    r15,0x5
   7c693:	4b 8d 0c 7f                                     	lea    rcx,[r15+r15*2]
   7c697:	48 89 4c 24 18                                  	mov    QWORD PTR [rsp+0x18],rcx
   7c69c:	48 39 c3                                        	cmp    rbx,rax
   7c69f:	76 11                                           	jbe    7c6b2 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1a02>
   7c6a1:	31 ff                                           	xor    edi,edi
   7c6a3:	48 8b 74 24 18                                  	mov    rsi,QWORD PTR [rsp+0x18]
   7c6a8:	e8 b4 20 fb ff                                  	call   2e761 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7c6ad:	e9 09 27 00 00                                  	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7c6b2:	48 89 5c 24 40                                  	mov    QWORD PTR [rsp+0x40],rbx
   7c6b7:	48 85 db                                        	test   rbx,rbx
   7c6ba:	74 43                                           	je     7c6ff <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1a4f>
   7c6bc:	4c 8b b4 24 a0 01 00 00                         	mov    r14,QWORD PTR [rsp+0x1a0]
   7c6c4:	4c 8b a4 24 d0 01 00 00                         	mov    r12,QWORD PTR [rsp+0x1d0]
   7c6cc:	4c 89 7c 24 48                                  	mov    QWORD PTR [rsp+0x48],r15
   7c6d1:	48 81 fb 56 05 00 00                            	cmp    rbx,0x556
   7c6d8:	72 72                                           	jb     7c74c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1a9c>
   7c6da:	4b 8d 1c 7f                                     	lea    rbx,[r15+r15*2]
   7c6de:	48 89 df                                        	mov    rdi,rbx
   7c6e1:	48 83 cf 01                                     	or     rdi,0x1
   7c6e5:	ff 15 b5 e0 01 00                               	call   QWORD PTR [rip+0x1e0b5]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7c6eb:	48 85 c0                                        	test   rax,rax
   7c6ee:	0f 84 a1 26 00 00                               	je     7ed95 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x40e5>
   7c6f4:	48 89 44 24 10                                  	mov    QWORD PTR [rsp+0x10],rax
   7c6f9:	c6 04 18 00                                     	mov    BYTE PTR [rax+rbx*1],0x0
   7c6fd:	eb 65                                           	jmp    7c764 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1ab4>
   7c6ff:	c5 fe 6f 05 99 b1 f8 ff                         	vmovdqu ymm0,YMMWORD PTR [rip+0xfffffffffff8b199]        # 78a0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x900>
   7c707:	b8 08 00 00 00                                  	mov    eax,0x8
   7c70c:	41 bf 08 00 00 00                               	mov    r15d,0x8
   7c712:	48 c7 84 24 98 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x98],0x0
   7c71e:	48 c7 84 24 a0 00 00 00 08 00 00 00             	mov    QWORD PTR [rsp+0xa0],0x8
   7c72a:	45 31 f6                                        	xor    r14d,r14d
   7c72d:	48 c7 84 24 a8 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xa8],0x0
   7c739:	48 89 44 24 48                                  	mov    QWORD PTR [rsp+0x48],rax
   7c73e:	c5 fe 7f 84 24 30 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x130],ymm0
   7c747:	e9 da 05 00 00                                  	jmp    7cd26 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x2076>
   7c74c:	4b 8d 3c 7f                                     	lea    rdi,[r15+r15*2]
   7c750:	ff 15 4a e0 01 00                               	call   QWORD PTR [rip+0x1e04a]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7c756:	48 89 44 24 10                                  	mov    QWORD PTR [rsp+0x10],rax
   7c75b:	48 85 c0                                        	test   rax,rax
   7c75e:	0f 84 31 26 00 00                               	je     7ed95 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x40e5>
   7c764:	4c 8b bc 24 88 01 00 00                         	mov    r15,QWORD PTR [rsp+0x188]
   7c76c:	4c 8b ac 24 90 01 00 00                         	mov    r13,QWORD PTR [rsp+0x190]
   7c774:	31 db                                           	xor    ebx,ebx
   7c776:	31 ed                                           	xor    ebp,ebp
   7c778:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   7c780:	49 8b 14 ec                                     	mov    rdx,QWORD PTR [r12+rbp*8]
   7c784:	4c 39 ea                                        	cmp    rdx,r13
   7c787:	0f 83 51 25 00 00                               	jae    7ecde <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x402e>
   7c78d:	48 c1 e2 06                                     	shl    rdx,0x6
   7c791:	49 8d 34 1e                                     	lea    rsi,[r14+rbx*1]
   7c795:	48 8d bc 24 50 05 00 00                         	lea    rdi,[rsp+0x550]
   7c79d:	48 ff c5                                        	inc    rbp
   7c7a0:	4c 01 fa                                        	add    rdx,r15
   7c7a3:	c5 f8 77                                        	vzeroupper
   7c7a6:	e8 05 fe 00 00                                  	call   8c5b0 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE10add_affineCsHW5vo2gROj_10zopro_core>
   7c7ab:	62 f1 fe 48 6f 84 24 50 05 00 00                	vmovdqu64 zmm0,ZMMWORD PTR [rsp+0x550]
   7c7b6:	62 f1 fe 48 6f 8c 24 70 05 00 00                	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x570]
   7c7c1:	48 8b 44 24 10                                  	mov    rax,QWORD PTR [rsp+0x10]
   7c7c6:	62 f1 fe 48 7f 8c 18 20 00 00 00                	vmovdqu64 ZMMWORD PTR [rax+rbx*1+0x20],zmm1
   7c7d1:	62 f1 fe 48 7f 04 18                            	vmovdqu64 ZMMWORD PTR [rax+rbx*1],zmm0
   7c7d8:	48 83 c3 60                                     	add    rbx,0x60
   7c7dc:	48 39 6c 24 40                                  	cmp    QWORD PTR [rsp+0x40],rbp
   7c7e1:	75 9d                                           	jne    7c780 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1ad0>
   7c7e3:	48 8b 5c 24 40                                  	mov    rbx,QWORD PTR [rsp+0x40]
   7c7e8:	48 81 fb 00 10 00 00                            	cmp    rbx,0x1000
   7c7ef:	72 2a                                           	jb     7c81b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1b6b>
   7c7f1:	4c 8b 74 24 48                                  	mov    r14,QWORD PTR [rsp+0x48]
   7c7f6:	4c 89 f7                                        	mov    rdi,r14
   7c7f9:	48 83 cf 01                                     	or     rdi,0x1
   7c7fd:	c5 f8 77                                        	vzeroupper
   7c800:	ff 15 9a df 01 00                               	call   QWORD PTR [rip+0x1df9a]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7c806:	4c 8b 7c 24 10                                  	mov    r15,QWORD PTR [rsp+0x10]
   7c80b:	48 85 c0                                        	test   rax,rax
   7c80e:	0f 84 8b 25 00 00                               	je     7ed9f <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x40ef>
   7c814:	42 c6 04 30 00                                  	mov    BYTE PTR [rax+r14*1],0x0
   7c819:	eb 1f                                           	jmp    7c83a <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1b8a>
   7c81b:	4c 8b 74 24 48                                  	mov    r14,QWORD PTR [rsp+0x48]
   7c820:	4c 89 f7                                        	mov    rdi,r14
   7c823:	c5 f8 77                                        	vzeroupper
   7c826:	ff 15 74 df 01 00                               	call   QWORD PTR [rip+0x1df74]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7c82c:	4c 8b 7c 24 10                                  	mov    r15,QWORD PTR [rsp+0x10]
   7c831:	48 85 c0                                        	test   rax,rax
   7c834:	0f 84 65 25 00 00                               	je     7ed9f <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x40ef>
   7c83a:	c5 fe 6f 05 5e b0 f8 ff                         	vmovdqu ymm0,YMMWORD PTR [rip+0xfffffffffff8b05e]        # 78a0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x900>
   7c842:	48 89 9c 24 98 00 00 00                         	mov    QWORD PTR [rsp+0x98],rbx
   7c84a:	48 8b 5c 24 18                                  	mov    rbx,QWORD PTR [rsp+0x18]
   7c84f:	bd 01 00 00 00                                  	mov    ebp,0x1
   7c854:	41 bc 40 00 00 00                               	mov    r12d,0x40
   7c85a:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   7c862:	48 c7 84 24 a8 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xa8],0x0
   7c86e:	45 31 f6                                        	xor    r14d,r14d
   7c871:	4c 89 7c 24 10                                  	mov    QWORD PTR [rsp+0x10],r15
   7c876:	49 8d 0c 1f                                     	lea    rcx,[r15+rbx*1]
   7c87a:	48 f7 db                                        	neg    rbx
   7c87d:	48 89 4c 24 48                                  	mov    QWORD PTR [rsp+0x48],rcx
   7c882:	48 89 5c 24 18                                  	mov    QWORD PTR [rsp+0x18],rbx
   7c887:	c5 fe 7f 84 24 30 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x130],ymm0
   7c890:	eb 28                                           	jmp    7c8ba <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1c0a>
   7c892:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7c8a0:	4a 8d 4c 23 60                                  	lea    rcx,[rbx+r12*1+0x60]
   7c8a5:	48 ff c5                                        	inc    rbp
   7c8a8:	49 83 c6 20                                     	add    r14,0x20
   7c8ac:	49 83 c4 60                                     	add    r12,0x60
   7c8b0:	48 83 f9 40                                     	cmp    rcx,0x40
   7c8b4:	0f 84 64 04 00 00                               	je     7cd1e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x206e>
   7c8ba:	48 8d 4d ff                                     	lea    rcx,[rbp-0x1]
   7c8be:	48 3b 8c 24 98 00 00 00                         	cmp    rcx,QWORD PTR [rsp+0x98]
   7c8c6:	75 18                                           	jne    7c8e0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1c30>
   7c8c8:	48 8d bc 24 98 00 00 00                         	lea    rdi,[rsp+0x98]
   7c8d0:	c5 f8 77                                        	vzeroupper
   7c8d3:	e8 b8 52 01 00                                  	call   91b90 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtCsgHCcee0nhgM_11zopro_bn2542fp2FpNtBQ_8FqConfigEE8grow_oneCsHW5vo2gROj_10zopro_core>
   7c8d8:	48 8b 84 24 a0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xa0]
   7c8e0:	c5 fc 10 84 24 30 01 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+0x130]
   7c8e9:	c4 a1 7c 11 04 30                               	vmovups YMMWORD PTR [rax+r14*1],ymm0
   7c8ef:	48 89 ac 24 a8 00 00 00                         	mov    QWORD PTR [rsp+0xa8],rbp
   7c8f7:	c4 81 7e 6f 04 27                               	vmovdqu ymm0,YMMWORD PTR [r15+r12*1]
   7c8fd:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7c902:	74 9c                                           	je     7c8a0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1bf0>
   7c904:	4b 8d 0c 27                                     	lea    rcx,[r15+r12*1]
   7c908:	c5 fe 6f 94 24 30 01 00 00                      	vmovdqu ymm2,YMMWORD PTR [rsp+0x130]
   7c911:	c5 fe 6f 0d c7 af f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff8afc7]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   7c919:	48 89 84 24 90 00 00 00                         	mov    QWORD PTR [rsp+0x90],rax
   7c921:	4c 89 74 24 08                                  	mov    QWORD PTR [rsp+0x8],r14
   7c926:	48 8d 44 24 60                                  	lea    rax,[rsp+0x60]
   7c92b:	4c 8d ac 24 b0 00 00 00                         	lea    r13,[rsp+0xb0]
   7c933:	4c 8d bc 24 50 05 00 00                         	lea    r15,[rsp+0x550]
   7c93b:	48 be 89 63 86 e4 82 07 d2 87                   	movabs rsi,0x87d20782e4866389
   7c945:	c5 fe 6f 01                                     	vmovdqu ymm0,YMMWORD PTR [rcx]
   7c949:	c5 fe 7f 54 24 60                               	vmovdqu YMMWORD PTR [rsp+0x60],ymm2
   7c94f:	c5 fe 7f 8c 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm1
   7c958:	c5 fe 7f 84 24 b0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xb0],ymm0
   7c961:	45 31 f6                                        	xor    r14d,r14d
   7c964:	45 31 c0                                        	xor    r8d,r8d
   7c967:	31 ff                                           	xor    edi,edi
   7c969:	45 31 c9                                        	xor    r9d,r9d
   7c96c:	31 c9                                           	xor    ecx,ecx
   7c96e:	49 8b 55 00                                     	mov    rdx,QWORD PTR [r13+0x0]
   7c972:	31 db                                           	xor    ebx,ebx
   7c974:	c4 62 ab f6 18                                  	mulx   r11,r10,QWORD PTR [rax]
   7c979:	66 4d 0f 38 f6 f2                               	adcx   r14,r10
   7c97f:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7c985:	c4 62 ab f6 58 08                               	mulx   r11,r10,QWORD PTR [rax+0x8]
   7c98b:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7c991:	f3 49 0f 38 f6 fb                               	adox   rdi,r11
   7c997:	c4 62 ab f6 58 10                               	mulx   r11,r10,QWORD PTR [rax+0x10]
   7c99d:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   7c9a3:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7c9a9:	c4 62 ab f6 58 18                               	mulx   r11,r10,QWORD PTR [rax+0x18]
   7c9af:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7c9b5:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7c9bb:	66 48 0f 38 f6 cb                               	adcx   rcx,rbx
   7c9c1:	4c 89 f2                                        	mov    rdx,r14
   7c9c4:	48 0f af d6                                     	imul   rdx,rsi
   7c9c8:	31 db                                           	xor    ebx,ebx
   7c9ca:	c4 42 ab f6 1f                                  	mulx   r11,r10,QWORD PTR [r15]
   7c9cf:	66 4d 0f 38 f6 f2                               	adcx   r14,r10
   7c9d5:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7c9db:	c4 42 ab f6 5f 08                               	mulx   r11,r10,QWORD PTR [r15+0x8]
   7c9e1:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7c9e7:	f3 49 0f 38 f6 fb                               	adox   rdi,r11
   7c9ed:	c4 42 ab f6 5f 10                               	mulx   r11,r10,QWORD PTR [r15+0x10]
   7c9f3:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   7c9f9:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7c9ff:	c4 42 ab f6 5f 18                               	mulx   r11,r10,QWORD PTR [r15+0x18]
   7ca05:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7ca0b:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7ca11:	66 48 0f 38 f6 cb                               	adcx   rcx,rbx
   7ca17:	49 8b 55 08                                     	mov    rdx,QWORD PTR [r13+0x8]
   7ca1b:	31 db                                           	xor    ebx,ebx
   7ca1d:	c4 62 ab f6 18                                  	mulx   r11,r10,QWORD PTR [rax]
   7ca22:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7ca28:	f3 49 0f 38 f6 fb                               	adox   rdi,r11
   7ca2e:	c4 62 ab f6 58 08                               	mulx   r11,r10,QWORD PTR [rax+0x8]
   7ca34:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   7ca3a:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7ca40:	c4 62 ab f6 58 10                               	mulx   r11,r10,QWORD PTR [rax+0x10]
   7ca46:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7ca4c:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7ca52:	c4 62 ab f6 58 18                               	mulx   r11,r10,QWORD PTR [rax+0x18]
   7ca58:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7ca5e:	f3 4d 0f 38 f6 f3                               	adox   r14,r11
   7ca64:	66 4c 0f 38 f6 f3                               	adcx   r14,rbx
   7ca6a:	4c 89 c2                                        	mov    rdx,r8
   7ca6d:	48 0f af d6                                     	imul   rdx,rsi
   7ca71:	31 db                                           	xor    ebx,ebx
   7ca73:	c4 42 ab f6 1f                                  	mulx   r11,r10,QWORD PTR [r15]
   7ca78:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7ca7e:	f3 49 0f 38 f6 fb                               	adox   rdi,r11
   7ca84:	c4 42 ab f6 5f 08                               	mulx   r11,r10,QWORD PTR [r15+0x8]
   7ca8a:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   7ca90:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7ca96:	c4 42 ab f6 5f 10                               	mulx   r11,r10,QWORD PTR [r15+0x10]
   7ca9c:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7caa2:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7caa8:	c4 42 ab f6 5f 18                               	mulx   r11,r10,QWORD PTR [r15+0x18]
   7caae:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7cab4:	f3 4d 0f 38 f6 f3                               	adox   r14,r11
   7caba:	66 4c 0f 38 f6 f3                               	adcx   r14,rbx
   7cac0:	49 8b 55 10                                     	mov    rdx,QWORD PTR [r13+0x10]
   7cac4:	31 db                                           	xor    ebx,ebx
   7cac6:	c4 62 ab f6 18                                  	mulx   r11,r10,QWORD PTR [rax]
   7cacb:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   7cad1:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7cad7:	c4 62 ab f6 58 08                               	mulx   r11,r10,QWORD PTR [rax+0x8]
   7cadd:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7cae3:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7cae9:	c4 62 ab f6 58 10                               	mulx   r11,r10,QWORD PTR [rax+0x10]
   7caef:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7caf5:	f3 4d 0f 38 f6 f3                               	adox   r14,r11
   7cafb:	c4 62 ab f6 58 18                               	mulx   r11,r10,QWORD PTR [rax+0x18]
   7cb01:	66 4d 0f 38 f6 f2                               	adcx   r14,r10
   7cb07:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7cb0d:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7cb13:	48 89 fa                                        	mov    rdx,rdi
   7cb16:	48 0f af d6                                     	imul   rdx,rsi
   7cb1a:	31 db                                           	xor    ebx,ebx
   7cb1c:	c4 42 ab f6 1f                                  	mulx   r11,r10,QWORD PTR [r15]
   7cb21:	66 49 0f 38 f6 fa                               	adcx   rdi,r10
   7cb27:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7cb2d:	c4 42 ab f6 5f 08                               	mulx   r11,r10,QWORD PTR [r15+0x8]
   7cb33:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7cb39:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7cb3f:	c4 42 ab f6 5f 10                               	mulx   r11,r10,QWORD PTR [r15+0x10]
   7cb45:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7cb4b:	f3 4d 0f 38 f6 f3                               	adox   r14,r11
   7cb51:	c4 42 ab f6 5f 18                               	mulx   r11,r10,QWORD PTR [r15+0x18]
   7cb57:	66 4d 0f 38 f6 f2                               	adcx   r14,r10
   7cb5d:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7cb63:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7cb69:	49 8b 55 18                                     	mov    rdx,QWORD PTR [r13+0x18]
   7cb6d:	31 db                                           	xor    ebx,ebx
   7cb6f:	c4 62 ab f6 18                                  	mulx   r11,r10,QWORD PTR [rax]
   7cb74:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7cb7a:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7cb80:	c4 62 ab f6 58 08                               	mulx   r11,r10,QWORD PTR [rax+0x8]
   7cb86:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7cb8c:	f3 4d 0f 38 f6 f3                               	adox   r14,r11
   7cb92:	c4 62 ab f6 58 10                               	mulx   r11,r10,QWORD PTR [rax+0x10]
   7cb98:	66 4d 0f 38 f6 f2                               	adcx   r14,r10
   7cb9e:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7cba4:	c4 62 ab f6 58 18                               	mulx   r11,r10,QWORD PTR [rax+0x18]
   7cbaa:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7cbb0:	f3 49 0f 38 f6 fb                               	adox   rdi,r11
   7cbb6:	66 48 0f 38 f6 fb                               	adcx   rdi,rbx
   7cbbc:	4c 89 ca                                        	mov    rdx,r9
   7cbbf:	48 0f af d6                                     	imul   rdx,rsi
   7cbc3:	31 db                                           	xor    ebx,ebx
   7cbc5:	c4 42 ab f6 1f                                  	mulx   r11,r10,QWORD PTR [r15]
   7cbca:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7cbd0:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7cbd6:	c4 42 ab f6 5f 08                               	mulx   r11,r10,QWORD PTR [r15+0x8]
   7cbdc:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7cbe2:	f3 4d 0f 38 f6 f3                               	adox   r14,r11
   7cbe8:	c4 42 ab f6 5f 10                               	mulx   r11,r10,QWORD PTR [r15+0x10]
   7cbee:	66 4d 0f 38 f6 f2                               	adcx   r14,r10
   7cbf4:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7cbfa:	c4 42 ab f6 5f 18                               	mulx   r11,r10,QWORD PTR [r15+0x18]
   7cc00:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7cc06:	f3 49 0f 38 f6 fb                               	adox   rdi,r11
   7cc0c:	66 48 0f 38 f6 fb                               	adcx   rdi,rbx
   7cc12:	4c 89 b4 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],r14
   7cc1a:	4c 89 44 24 20                                  	mov    QWORD PTR [rsp+0x20],r8
   7cc1f:	49 b9 47 fd 7c d8 16 8c 20 3c                   	movabs r9,0x3c208c16d87cfd47
   7cc29:	48 ba 73 35 8e 97 6e 95 7e 68                   	movabs rdx,0x687e956e978e3573
   7cc33:	48 89 7c 24 28                                  	mov    QWORD PTR [rsp+0x28],rdi
   7cc38:	49 ba 8d ca 71 68 91 6a 81 97                   	movabs r10,0x97816a916871ca8d
   7cc42:	49 bb 5d 58 81 81 b6 45 50 b8                   	movabs r11,0xb85045b68181585d
   7cc4c:	48 bb 29 a0 31 e1 72 4e 64 30                   	movabs rbx,0x30644e72e131a029
   7cc56:	4c 8b 84 24 88 00 00 00                         	mov    r8,QWORD PTR [rsp+0x88]
   7cc5e:	4c 39 c9                                        	cmp    rcx,r9
   7cc61:	48 8b 7c 24 20                                  	mov    rdi,QWORD PTR [rsp+0x20]
   7cc66:	48 8b 74 24 28                                  	mov    rsi,QWORD PTR [rsp+0x28]
   7cc6b:	4c 8b 74 24 08                                  	mov    r14,QWORD PTR [rsp+0x8]
   7cc70:	4c 8b 7c 24 10                                  	mov    r15,QWORD PTR [rsp+0x10]
   7cc75:	48 8b 84 24 90 00 00 00                         	mov    rax,QWORD PTR [rsp+0x90]
   7cc7d:	49 8d 14 10                                     	lea    rdx,[r8+rdx*1]
   7cc81:	48 83 da 00                                     	sbb    rdx,0x0
   7cc85:	41 0f 92 c1                                     	setb   r9b
   7cc89:	4d 39 d0                                        	cmp    r8,r10
   7cc8c:	41 0f 92 c2                                     	setb   r10b
   7cc90:	45 08 ca                                        	or     r10b,r9b
   7cc93:	49 b9 a3 a7 7e 7e 49 ba af 47                   	movabs r9,0x47afba497e7ea7a3
   7cc9d:	49 01 f9                                        	add    r9,rdi
   7cca0:	45 0f b6 d2                                     	movzx  r10d,r10b
   7cca4:	4d 29 d1                                        	sub    r9,r10
   7cca7:	41 0f 92 c2                                     	setb   r10b
   7ccab:	4c 39 df                                        	cmp    rdi,r11
   7ccae:	41 0f 92 c3                                     	setb   r11b
   7ccb2:	45 08 d3                                        	or     r11b,r10b
   7ccb5:	49 ba d7 5f ce 1e 8d b1 9b cf                   	movabs r10,0xcf9bb18d1ece5fd7
   7ccbf:	49 01 f2                                        	add    r10,rsi
   7ccc2:	45 0f b6 db                                     	movzx  r11d,r11b
   7ccc6:	4d 29 da                                        	sub    r10,r11
   7ccc9:	41 0f 92 c3                                     	setb   r11b
   7cccd:	48 39 de                                        	cmp    rsi,rbx
   7ccd0:	0f 92 c3                                        	setb   bl
   7ccd3:	44 08 db                                        	or     bl,r11b
   7ccd6:	48 8b 5c 24 18                                  	mov    rbx,QWORD PTR [rsp+0x18]
   7ccdb:	49 bb b9 02 83 27 e9 73 df c3                   	movabs r11,0xc3df73e9278302b9
   7cce5:	4e 8d 1c 19                                     	lea    r11,[rcx+r11*1]
   7cce9:	49 0f 45 d0                                     	cmovne rdx,r8
   7cced:	4c 0f 45 cf                                     	cmovne r9,rdi
   7ccf1:	4c 0f 45 d6                                     	cmovne r10,rsi
   7ccf5:	49 0f 44 cb                                     	cmove  rcx,r11
   7ccf9:	48 89 8c 24 30 01 00 00                         	mov    QWORD PTR [rsp+0x130],rcx
   7cd01:	48 89 94 24 38 01 00 00                         	mov    QWORD PTR [rsp+0x138],rdx
   7cd09:	4c 89 8c 24 40 01 00 00                         	mov    QWORD PTR [rsp+0x140],r9
   7cd11:	4c 89 94 24 48 01 00 00                         	mov    QWORD PTR [rsp+0x148],r10
   7cd19:	e9 82 fb ff ff                                  	jmp    7c8a0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x1bf0>
   7cd1e:	48 8b 5c 24 40                                  	mov    rbx,QWORD PTR [rsp+0x40]
   7cd23:	49 89 de                                        	mov    r14,rbx
   7cd26:	48 8d bc 24 50 05 00 00                         	lea    rdi,[rsp+0x550]
   7cd2e:	48 8d b4 24 30 01 00 00                         	lea    rsi,[rsp+0x130]
   7cd36:	c5 f8 77                                        	vzeroupper
   7cd39:	e8 c2 4e 01 00                                  	call   91c00 <_RINvNtCsgHCcee0nhgM_11zopro_bn2547inverse7inverseNtB4_8FqConfigECsHW5vo2gROj_10zopro_core>
   7cd3e:	83 bc 24 50 05 00 00 01                         	cmp    DWORD PTR [rsp+0x550],0x1
   7cd46:	0f 85 11 1f 00 00                               	jne    7ec5d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3fad>
   7cd4c:	48 8b 84 24 58 05 00 00                         	mov    rax,QWORD PTR [rsp+0x558]
   7cd54:	48 8b ac 24 60 05 00 00                         	mov    rbp,QWORD PTR [rsp+0x560]
   7cd5c:	48 8b 94 24 68 05 00 00                         	mov    rdx,QWORD PTR [rsp+0x568]
   7cd64:	48 8b 8c 24 70 05 00 00                         	mov    rcx,QWORD PTR [rsp+0x570]
   7cd6c:	49 89 dc                                        	mov    r12,rbx
   7cd6f:	49 c1 e4 06                                     	shl    r12,0x6
   7cd73:	48 89 44 24 28                                  	mov    QWORD PTR [rsp+0x28],rax
   7cd78:	48 89 ac 24 90 00 00 00                         	mov    QWORD PTR [rsp+0x90],rbp
   7cd80:	48 89 54 24 08                                  	mov    QWORD PTR [rsp+0x8],rdx
   7cd85:	48 89 4c 24 18                                  	mov    QWORD PTR [rsp+0x18],rcx
   7cd8a:	48 85 db                                        	test   rbx,rbx
   7cd8d:	0f 84 64 01 00 00                               	je     7cef7 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x2247>
   7cd93:	4c 89 e7                                        	mov    rdi,r12
   7cd96:	48 81 fb 00 08 00 00                            	cmp    rbx,0x800
   7cd9d:	0f 82 67 01 00 00                               	jb     7cf0a <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x225a>
   7cda3:	48 83 cf 01                                     	or     rdi,0x1
   7cda7:	ff 15 f3 d9 01 00                               	call   QWORD PTR [rip+0x1d9f3]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7cdad:	48 85 c0                                        	test   rax,rax
   7cdb0:	0f 84 f8 1f 00 00                               	je     7edae <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x40fe>
   7cdb6:	48 8d 73 ff                                     	lea    rsi,[rbx-0x1]
   7cdba:	49 89 c0                                        	mov    r8,rax
   7cdbd:	42 c6 04 20 00                                  	mov    BYTE PTR [rax+r12*1],0x0
   7cdc2:	48 8d 84 24 70 05 00 00                         	lea    rax,[rsp+0x570]
   7cdca:	89 f1                                           	mov    ecx,esi
   7cdcc:	83 e1 07                                        	and    ecx,0x7
   7cdcf:	48 83 e6 f8                                     	and    rsi,0xfffffffffffffff8
   7cdd3:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7cdd7:	4c 89 c2                                        	mov    rdx,r8
   7cdda:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   7cde0:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7cde4:	c5 fe 7f 84 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm0
   7cded:	62 f1 fe 48 6f 8c 24 50 05 00 00                	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x550]
   7cdf8:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7cdfc:	c5 fe 7f 84 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm0
   7ce05:	62 f1 7c 48 10 94 24 50 05 00 00                	vmovups zmm2,ZMMWORD PTR [rsp+0x550]
   7ce10:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7ce14:	c5 fe 7f 84 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm0
   7ce1d:	62 f1 7c 48 10 9c 24 50 05 00 00                	vmovups zmm3,ZMMWORD PTR [rsp+0x550]
   7ce28:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7ce2c:	c5 fe 7f 84 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm0
   7ce35:	62 f1 fe 48 7f 0a                               	vmovdqu64 ZMMWORD PTR [rdx],zmm1
   7ce3b:	62 f1 7c 48 11 52 01                            	vmovups ZMMWORD PTR [rdx+0x40],zmm2
   7ce42:	62 f1 7c 48 10 94 24 50 05 00 00                	vmovups zmm2,ZMMWORD PTR [rsp+0x550]
   7ce4d:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7ce51:	c5 fe 7f 84 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm0
   7ce5a:	62 f1 7c 48 11 5a 02                            	vmovups ZMMWORD PTR [rdx+0x80],zmm3
   7ce61:	62 f1 7c 48 10 9c 24 50 05 00 00                	vmovups zmm3,ZMMWORD PTR [rsp+0x550]
   7ce6c:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7ce70:	c5 fe 7f 84 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm0
   7ce79:	62 f1 7c 48 11 52 03                            	vmovups ZMMWORD PTR [rdx+0xc0],zmm2
   7ce80:	62 f1 7c 48 10 94 24 50 05 00 00                	vmovups zmm2,ZMMWORD PTR [rsp+0x550]
   7ce8b:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7ce8f:	c5 fe 7f 84 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm0
   7ce98:	62 f1 7c 48 11 5a 04                            	vmovups ZMMWORD PTR [rdx+0x100],zmm3
   7ce9f:	62 f1 7c 48 10 9c 24 50 05 00 00                	vmovups zmm3,ZMMWORD PTR [rsp+0x550]
   7ceaa:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7ceae:	c5 fe 7f 84 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm0
   7ceb7:	62 f1 7c 48 11 52 05                            	vmovups ZMMWORD PTR [rdx+0x140],zmm2
   7cebe:	62 f1 fe 48 6f 94 24 50 05 00 00                	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x550]
   7cec9:	62 f1 7c 48 11 5a 06                            	vmovups ZMMWORD PTR [rdx+0x180],zmm3
   7ced0:	62 f1 fe 48 7f 52 07                            	vmovdqu64 ZMMWORD PTR [rdx+0x1c0],zmm2
   7ced7:	48 81 c2 00 02 00 00                            	add    rdx,0x200
   7cede:	48 83 c6 f8                                     	add    rsi,0xfffffffffffffff8
   7cee2:	0f 85 f8 fe ff ff                               	jne    7cde0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x2130>
   7cee8:	48 89 5c 24 38                                  	mov    QWORD PTR [rsp+0x38],rbx
   7ceed:	48 85 c9                                        	test   rcx,rcx
   7cef0:	75 61                                           	jne    7cf53 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x22a3>
   7cef2:	e9 95 00 00 00                                  	jmp    7cf8c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x22dc>
   7cef7:	48 c7 44 24 38 00 00 00 00                      	mov    QWORD PTR [rsp+0x38],0x0
   7cf00:	bb 08 00 00 00                                  	mov    ebx,0x8
   7cf05:	e9 8f 00 00 00                                  	jmp    7cf99 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x22e9>
   7cf0a:	ff 15 90 d8 01 00                               	call   QWORD PTR [rip+0x1d890]        # 9a7a0 <malloc@GLIBC_2.2.5>
   7cf10:	48 85 c0                                        	test   rax,rax
   7cf13:	0f 84 95 1e 00 00                               	je     7edae <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x40fe>
   7cf19:	49 89 c0                                        	mov    r8,rax
   7cf1c:	b8 01 00 00 00                                  	mov    eax,0x1
   7cf21:	48 89 44 24 38                                  	mov    QWORD PTR [rsp+0x38],rax
   7cf26:	48 83 fb 01                                     	cmp    rbx,0x1
   7cf2a:	75 05                                           	jne    7cf31 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x2281>
   7cf2c:	4c 89 c2                                        	mov    rdx,r8
   7cf2f:	eb 5b                                           	jmp    7cf8c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x22dc>
   7cf31:	48 8d 73 ff                                     	lea    rsi,[rbx-0x1]
   7cf35:	48 8d 84 24 70 05 00 00                         	lea    rax,[rsp+0x570]
   7cf3d:	48 8d 7b fe                                     	lea    rdi,[rbx-0x2]
   7cf41:	4c 89 c2                                        	mov    rdx,r8
   7cf44:	89 f1                                           	mov    ecx,esi
   7cf46:	83 e1 07                                        	and    ecx,0x7
   7cf49:	48 83 ff 07                                     	cmp    rdi,0x7
   7cf4d:	0f 83 7c fe ff ff                               	jae    7cdcf <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x211f>
   7cf53:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7cf57:	66 0f 1f 84 00 00 00 00 00                      	nop    WORD PTR [rax+rax*1+0x0]
   7cf60:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7cf64:	c5 fe 7f 84 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm0
   7cf6d:	62 f1 fe 48 6f 8c 24 50 05 00 00                	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x550]
   7cf78:	62 f1 fe 48 7f 0a                               	vmovdqu64 ZMMWORD PTR [rdx],zmm1
   7cf7e:	48 83 c2 40                                     	add    rdx,0x40
   7cf82:	48 ff c9                                        	dec    rcx
   7cf85:	75 d9                                           	jne    7cf60 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x22b0>
   7cf87:	48 89 5c 24 38                                  	mov    QWORD PTR [rsp+0x38],rbx
   7cf8c:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7cf90:	4c 89 c3                                        	mov    rbx,r8
   7cf93:	62 f1 fe 48 7f 02                               	vmovdqu64 ZMMWORD PTR [rdx],zmm0
   7cf99:	48 8d 05 e0 d4 01 00                            	lea    rax,[rip+0x1d4e0]        # 9a480 <__frame_dummy_init_array_entry+0x2630>
   7cfa0:	48 b9 ab aa aa aa aa aa aa aa                   	movabs rcx,0xaaaaaaaaaaaaaaab
   7cfaa:	48 89 84 24 28 01 00 00                         	mov    QWORD PTR [rsp+0x128],rax
   7cfb2:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7cfc0:	48 8b 74 24 48                                  	mov    rsi,QWORD PTR [rsp+0x48]
   7cfc5:	4c 39 fe                                        	cmp    rsi,r15
   7cfc8:	0f 84 d1 18 00 00                               	je     7e89f <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3bef>
   7cfce:	c5 fe 6f 46 e0                                  	vmovdqu ymm0,YMMWORD PTR [rsi-0x20]
   7cfd3:	48 8d 46 a0                                     	lea    rax,[rsi-0x60]
   7cfd7:	48 89 44 24 48                                  	mov    QWORD PTR [rsp+0x48],rax
   7cfdc:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7cfe1:	74 dd                                           	je     7cfc0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x2310>
   7cfe3:	48 8d 56 a0                                     	lea    rdx,[rsi-0x60]
   7cfe7:	48 8b 84 24 a8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xa8]
   7cfef:	4c 89 a4 24 70 01 00 00                         	mov    QWORD PTR [rsp+0x170],r12
   7cff7:	48 89 9c 24 f8 00 00 00                         	mov    QWORD PTR [rsp+0xf8],rbx
   7cfff:	4c 89 b4 24 80 00 00 00                         	mov    QWORD PTR [rsp+0x80],r14
   7d007:	4c 89 7c 24 10                                  	mov    QWORD PTR [rsp+0x10],r15
   7d00c:	4c 29 fa                                        	sub    rdx,r15
   7d00f:	48 c1 ea 05                                     	shr    rdx,0x5
   7d013:	48 0f af d1                                     	imul   rdx,rcx
   7d017:	48 89 54 24 58                                  	mov    QWORD PTR [rsp+0x58],rdx
   7d01c:	48 39 c2                                        	cmp    rdx,rax
   7d01f:	0f 83 40 1d 00 00                               	jae    7ed65 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x40b5>
   7d025:	48 8b 8c 24 a0 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xa0]
   7d02d:	48 8d 46 e0                                     	lea    rax,[rsi-0x20]
   7d031:	48 c1 e2 05                                     	shl    rdx,0x5
   7d035:	c5 fe 6f 15 a3 a8 f8 ff                         	vmovdqu ymm2,YMMWORD PTR [rip+0xfffffffffff8a8a3]        # 78e0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x940>
   7d03d:	4c 8b 6c 24 08                                  	mov    r13,QWORD PTR [rsp+0x8]
   7d042:	48 8b 6c 24 18                                  	mov    rbp,QWORD PTR [rsp+0x18]
   7d047:	48 89 74 24 50                                  	mov    QWORD PTR [rsp+0x50],rsi
   7d04c:	4c 8d 74 24 60                                  	lea    r14,[rsp+0x60]
   7d051:	48 8d bc 24 b0 00 00 00                         	lea    rdi,[rsp+0xb0]
   7d059:	4c 8d 8c 24 50 05 00 00                         	lea    r9,[rsp+0x550]
   7d061:	48 89 84 24 20 01 00 00                         	mov    QWORD PTR [rsp+0x120],rax
   7d069:	48 8b 44 24 28                                  	mov    rax,QWORD PTR [rsp+0x28]
   7d06e:	c5 fe 6f 04 11                                  	vmovdqu ymm0,YMMWORD PTR [rcx+rdx*1]
   7d073:	48 89 44 24 60                                  	mov    QWORD PTR [rsp+0x60],rax
   7d078:	48 8b 84 24 90 00 00 00                         	mov    rax,QWORD PTR [rsp+0x90]
   7d080:	c5 fe 7f 94 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm2
   7d089:	48 89 44 24 68                                  	mov    QWORD PTR [rsp+0x68],rax
   7d08e:	4c 89 6c 24 70                                  	mov    QWORD PTR [rsp+0x70],r13
   7d093:	48 89 6c 24 78                                  	mov    QWORD PTR [rsp+0x78],rbp
   7d098:	48 b8 89 63 86 e4 82 07 d2 87                   	movabs rax,0x87d20782e4866389
   7d0a2:	c5 fe 7f 84 24 70 0b 00 00                      	vmovdqu YMMWORD PTR [rsp+0xb70],ymm0
   7d0ab:	c5 fe 7f 84 24 b0 00 00 00                      	vmovdqu YMMWORD PTR [rsp+0xb0],ymm0
   7d0b4:	45 31 e4                                        	xor    r12d,r12d
   7d0b7:	45 31 ff                                        	xor    r15d,r15d
   7d0ba:	45 31 c0                                        	xor    r8d,r8d
   7d0bd:	31 c9                                           	xor    ecx,ecx
   7d0bf:	31 f6                                           	xor    esi,esi
   7d0c1:	48 8b 17                                        	mov    rdx,QWORD PTR [rdi]
   7d0c4:	31 db                                           	xor    ebx,ebx
   7d0c6:	c4 42 ab f6 1e                                  	mulx   r11,r10,QWORD PTR [r14]
   7d0cb:	66 4d 0f 38 f6 e2                               	adcx   r12,r10
   7d0d1:	f3 4d 0f 38 f6 fb                               	adox   r15,r11
   7d0d7:	c4 42 ab f6 5e 08                               	mulx   r11,r10,QWORD PTR [r14+0x8]
   7d0dd:	66 4d 0f 38 f6 fa                               	adcx   r15,r10
   7d0e3:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7d0e9:	c4 42 ab f6 5e 10                               	mulx   r11,r10,QWORD PTR [r14+0x10]
   7d0ef:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7d0f5:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7d0fb:	c4 42 ab f6 5e 18                               	mulx   r11,r10,QWORD PTR [r14+0x18]
   7d101:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7d107:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d10d:	66 48 0f 38 f6 f3                               	adcx   rsi,rbx
   7d113:	4c 89 e2                                        	mov    rdx,r12
   7d116:	48 0f af d0                                     	imul   rdx,rax
   7d11a:	31 db                                           	xor    ebx,ebx
   7d11c:	c4 42 ab f6 19                                  	mulx   r11,r10,QWORD PTR [r9]
   7d121:	66 4d 0f 38 f6 e2                               	adcx   r12,r10
   7d127:	f3 4d 0f 38 f6 fb                               	adox   r15,r11
   7d12d:	c4 42 ab f6 59 08                               	mulx   r11,r10,QWORD PTR [r9+0x8]
   7d133:	66 4d 0f 38 f6 fa                               	adcx   r15,r10
   7d139:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7d13f:	c4 42 ab f6 59 10                               	mulx   r11,r10,QWORD PTR [r9+0x10]
   7d145:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7d14b:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7d151:	c4 42 ab f6 59 18                               	mulx   r11,r10,QWORD PTR [r9+0x18]
   7d157:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7d15d:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d163:	66 48 0f 38 f6 f3                               	adcx   rsi,rbx
   7d169:	48 8b 57 08                                     	mov    rdx,QWORD PTR [rdi+0x8]
   7d16d:	31 db                                           	xor    ebx,ebx
   7d16f:	c4 42 ab f6 1e                                  	mulx   r11,r10,QWORD PTR [r14]
   7d174:	66 4d 0f 38 f6 fa                               	adcx   r15,r10
   7d17a:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7d180:	c4 42 ab f6 5e 08                               	mulx   r11,r10,QWORD PTR [r14+0x8]
   7d186:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7d18c:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7d192:	c4 42 ab f6 5e 10                               	mulx   r11,r10,QWORD PTR [r14+0x10]
   7d198:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7d19e:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d1a4:	c4 42 ab f6 5e 18                               	mulx   r11,r10,QWORD PTR [r14+0x18]
   7d1aa:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d1b0:	f3 4d 0f 38 f6 e3                               	adox   r12,r11
   7d1b6:	66 4c 0f 38 f6 e3                               	adcx   r12,rbx
   7d1bc:	4c 89 fa                                        	mov    rdx,r15
   7d1bf:	48 0f af d0                                     	imul   rdx,rax
   7d1c3:	31 db                                           	xor    ebx,ebx
   7d1c5:	c4 42 ab f6 19                                  	mulx   r11,r10,QWORD PTR [r9]
   7d1ca:	66 4d 0f 38 f6 fa                               	adcx   r15,r10
   7d1d0:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7d1d6:	c4 42 ab f6 59 08                               	mulx   r11,r10,QWORD PTR [r9+0x8]
   7d1dc:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7d1e2:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7d1e8:	c4 42 ab f6 59 10                               	mulx   r11,r10,QWORD PTR [r9+0x10]
   7d1ee:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7d1f4:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d1fa:	c4 42 ab f6 59 18                               	mulx   r11,r10,QWORD PTR [r9+0x18]
   7d200:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d206:	f3 4d 0f 38 f6 e3                               	adox   r12,r11
   7d20c:	66 4c 0f 38 f6 e3                               	adcx   r12,rbx
   7d212:	48 8b 57 10                                     	mov    rdx,QWORD PTR [rdi+0x10]
   7d216:	31 db                                           	xor    ebx,ebx
   7d218:	c4 42 ab f6 1e                                  	mulx   r11,r10,QWORD PTR [r14]
   7d21d:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7d223:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7d229:	c4 42 ab f6 5e 08                               	mulx   r11,r10,QWORD PTR [r14+0x8]
   7d22f:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7d235:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d23b:	c4 42 ab f6 5e 10                               	mulx   r11,r10,QWORD PTR [r14+0x10]
   7d241:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d247:	f3 4d 0f 38 f6 e3                               	adox   r12,r11
   7d24d:	c4 42 ab f6 5e 18                               	mulx   r11,r10,QWORD PTR [r14+0x18]
   7d253:	66 4d 0f 38 f6 e2                               	adcx   r12,r10
   7d259:	f3 4d 0f 38 f6 fb                               	adox   r15,r11
   7d25f:	66 4c 0f 38 f6 fb                               	adcx   r15,rbx
   7d265:	4c 89 c2                                        	mov    rdx,r8
   7d268:	48 0f af d0                                     	imul   rdx,rax
   7d26c:	31 db                                           	xor    ebx,ebx
   7d26e:	c4 42 ab f6 19                                  	mulx   r11,r10,QWORD PTR [r9]
   7d273:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7d279:	f3 49 0f 38 f6 cb                               	adox   rcx,r11
   7d27f:	c4 42 ab f6 59 08                               	mulx   r11,r10,QWORD PTR [r9+0x8]
   7d285:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7d28b:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d291:	c4 42 ab f6 59 10                               	mulx   r11,r10,QWORD PTR [r9+0x10]
   7d297:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d29d:	f3 4d 0f 38 f6 e3                               	adox   r12,r11
   7d2a3:	c4 42 ab f6 59 18                               	mulx   r11,r10,QWORD PTR [r9+0x18]
   7d2a9:	66 4d 0f 38 f6 e2                               	adcx   r12,r10
   7d2af:	f3 4d 0f 38 f6 fb                               	adox   r15,r11
   7d2b5:	66 4c 0f 38 f6 fb                               	adcx   r15,rbx
   7d2bb:	48 8b 57 18                                     	mov    rdx,QWORD PTR [rdi+0x18]
   7d2bf:	31 db                                           	xor    ebx,ebx
   7d2c1:	c4 42 ab f6 1e                                  	mulx   r11,r10,QWORD PTR [r14]
   7d2c6:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7d2cc:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d2d2:	c4 42 ab f6 5e 08                               	mulx   r11,r10,QWORD PTR [r14+0x8]
   7d2d8:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d2de:	f3 4d 0f 38 f6 e3                               	adox   r12,r11
   7d2e4:	c4 42 ab f6 5e 10                               	mulx   r11,r10,QWORD PTR [r14+0x10]
   7d2ea:	66 4d 0f 38 f6 e2                               	adcx   r12,r10
   7d2f0:	f3 4d 0f 38 f6 fb                               	adox   r15,r11
   7d2f6:	c4 42 ab f6 5e 18                               	mulx   r11,r10,QWORD PTR [r14+0x18]
   7d2fc:	66 4d 0f 38 f6 fa                               	adcx   r15,r10
   7d302:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7d308:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7d30e:	48 89 ca                                        	mov    rdx,rcx
   7d311:	48 0f af d0                                     	imul   rdx,rax
   7d315:	31 db                                           	xor    ebx,ebx
   7d317:	c4 42 ab f6 19                                  	mulx   r11,r10,QWORD PTR [r9]
   7d31c:	66 49 0f 38 f6 ca                               	adcx   rcx,r10
   7d322:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d328:	c4 42 ab f6 59 08                               	mulx   r11,r10,QWORD PTR [r9+0x8]
   7d32e:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d334:	f3 4d 0f 38 f6 e3                               	adox   r12,r11
   7d33a:	c4 42 ab f6 59 10                               	mulx   r11,r10,QWORD PTR [r9+0x10]
   7d340:	66 4d 0f 38 f6 e2                               	adcx   r12,r10
   7d346:	f3 4d 0f 38 f6 fb                               	adox   r15,r11
   7d34c:	c4 42 ab f6 59 18                               	mulx   r11,r10,QWORD PTR [r9+0x18]
   7d352:	66 4d 0f 38 f6 fa                               	adcx   r15,r10
   7d358:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7d35e:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7d364:	48 b9 b9 02 83 27 e9 73 df c3                   	movabs rcx,0xc3df73e9278302b9
   7d36e:	48 ba 8d ca 71 68 91 6a 81 97                   	movabs rdx,0x97816a916871ca8d
   7d378:	48 89 b4 24 18 01 00 00                         	mov    QWORD PTR [rsp+0x118],rsi
   7d380:	4c 89 84 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],r8
   7d388:	4c 89 a4 24 10 01 00 00                         	mov    QWORD PTR [rsp+0x110],r12
   7d390:	4c 89 bc 24 08 01 00 00                         	mov    QWORD PTR [rsp+0x108],r15
   7d398:	48 8d bc 24 50 05 00 00                         	lea    rdi,[rsp+0x550]
   7d3a0:	48 8d 04 0e                                     	lea    rax,[rsi+rcx*1]
   7d3a4:	48 b9 73 35 8e 97 6e 95 7e 68                   	movabs rcx,0x687e956e978e3573
   7d3ae:	4d 8d 0c 0c                                     	lea    r9,[r12+rcx*1]
   7d3b2:	48 b9 47 fd 7c d8 16 8c 20 3c                   	movabs rcx,0x3c208c16d87cfd47
   7d3bc:	48 89 44 24 20                                  	mov    QWORD PTR [rsp+0x20],rax
   7d3c1:	48 39 ce                                        	cmp    rsi,rcx
   7d3c4:	48 8b 74 24 28                                  	mov    rsi,QWORD PTR [rsp+0x28]
   7d3c9:	49 83 d9 00                                     	sbb    r9,0x0
   7d3cd:	0f 92 c1                                        	setb   cl
   7d3d0:	49 39 d4                                        	cmp    r12,rdx
   7d3d3:	49 bc 89 63 86 e4 82 07 d2 87                   	movabs r12,0x87d20782e4866389
   7d3dd:	0f 92 c2                                        	setb   dl
   7d3e0:	08 ca                                           	or     dl,cl
   7d3e2:	48 b9 a3 a7 7e 7e 49 ba af 47                   	movabs rcx,0x47afba497e7ea7a3
   7d3ec:	4d 8d 34 0f                                     	lea    r14,[r15+rcx*1]
   7d3f0:	0f b6 ca                                        	movzx  ecx,dl
   7d3f3:	48 ba 5d 58 81 81 b6 45 50 b8                   	movabs rdx,0xb85045b68181585d
   7d3fd:	48 89 74 24 60                                  	mov    QWORD PTR [rsp+0x60],rsi
   7d402:	48 8b b4 24 20 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x120]
   7d40a:	49 29 ce                                        	sub    r14,rcx
   7d40d:	0f 92 c1                                        	setb   cl
   7d410:	49 39 d7                                        	cmp    r15,rdx
   7d413:	0f 92 c2                                        	setb   dl
   7d416:	08 ca                                           	or     dl,cl
   7d418:	48 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs rcx,0xcf9bb18d1ece5fd7
   7d422:	49 8d 04 08                                     	lea    rax,[r8+rcx*1]
   7d426:	48 8b 8c 24 90 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x90]
   7d42e:	0f b6 d2                                        	movzx  edx,dl
   7d431:	48 29 d0                                        	sub    rax,rdx
   7d434:	48 89 84 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],rax
   7d43c:	0f 92 44 24 37                                  	setb   BYTE PTR [rsp+0x37]
   7d441:	48 89 4c 24 68                                  	mov    QWORD PTR [rsp+0x68],rcx
   7d446:	4c 89 6c 24 70                                  	mov    QWORD PTR [rsp+0x70],r13
   7d44b:	48 89 6c 24 78                                  	mov    QWORD PTR [rsp+0x78],rbp
   7d450:	4c 8d 6c 24 60                                  	lea    r13,[rsp+0x60]
   7d455:	48 8d ac 24 b0 00 00 00                         	lea    rbp,[rsp+0xb0]
   7d45d:	c5 fc 10 0e                                     	vmovups ymm1,YMMWORD PTR [rsi]
   7d461:	c5 fe 7f 94 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm2
   7d46a:	c5 fc 11 8c 24 b0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xb0],ymm1
   7d473:	45 31 d2                                        	xor    r10d,r10d
   7d476:	31 f6                                           	xor    esi,esi
   7d478:	45 31 c0                                        	xor    r8d,r8d
   7d47b:	31 c0                                           	xor    eax,eax
   7d47d:	31 c9                                           	xor    ecx,ecx
   7d47f:	48 8b 55 00                                     	mov    rdx,QWORD PTR [rbp+0x0]
   7d483:	45 31 db                                        	xor    r11d,r11d
   7d486:	c4 42 e3 f6 7d 00                               	mulx   r15,rbx,QWORD PTR [r13+0x0]
   7d48c:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   7d492:	f3 49 0f 38 f6 f7                               	adox   rsi,r15
   7d498:	c4 42 e3 f6 7d 08                               	mulx   r15,rbx,QWORD PTR [r13+0x8]
   7d49e:	66 48 0f 38 f6 f3                               	adcx   rsi,rbx
   7d4a4:	f3 4d 0f 38 f6 c7                               	adox   r8,r15
   7d4aa:	c4 42 e3 f6 7d 10                               	mulx   r15,rbx,QWORD PTR [r13+0x10]
   7d4b0:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7d4b6:	f3 49 0f 38 f6 c7                               	adox   rax,r15
   7d4bc:	c4 42 e3 f6 7d 18                               	mulx   r15,rbx,QWORD PTR [r13+0x18]
   7d4c2:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   7d4c8:	f3 49 0f 38 f6 cf                               	adox   rcx,r15
   7d4ce:	66 49 0f 38 f6 cb                               	adcx   rcx,r11
   7d4d4:	4c 89 d2                                        	mov    rdx,r10
   7d4d7:	49 0f af d4                                     	imul   rdx,r12
   7d4db:	45 31 db                                        	xor    r11d,r11d
   7d4de:	c4 62 e3 f6 3f                                  	mulx   r15,rbx,QWORD PTR [rdi]
   7d4e3:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   7d4e9:	f3 49 0f 38 f6 f7                               	adox   rsi,r15
   7d4ef:	c4 62 e3 f6 7f 08                               	mulx   r15,rbx,QWORD PTR [rdi+0x8]
   7d4f5:	66 48 0f 38 f6 f3                               	adcx   rsi,rbx
   7d4fb:	f3 4d 0f 38 f6 c7                               	adox   r8,r15
   7d501:	c4 62 e3 f6 7f 10                               	mulx   r15,rbx,QWORD PTR [rdi+0x10]
   7d507:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7d50d:	f3 49 0f 38 f6 c7                               	adox   rax,r15
   7d513:	c4 62 e3 f6 7f 18                               	mulx   r15,rbx,QWORD PTR [rdi+0x18]
   7d519:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   7d51f:	f3 49 0f 38 f6 cf                               	adox   rcx,r15
   7d525:	66 49 0f 38 f6 cb                               	adcx   rcx,r11
   7d52b:	48 8b 55 08                                     	mov    rdx,QWORD PTR [rbp+0x8]
   7d52f:	45 31 db                                        	xor    r11d,r11d
   7d532:	c4 42 e3 f6 7d 00                               	mulx   r15,rbx,QWORD PTR [r13+0x0]
   7d538:	66 48 0f 38 f6 f3                               	adcx   rsi,rbx
   7d53e:	f3 4d 0f 38 f6 c7                               	adox   r8,r15
   7d544:	c4 42 e3 f6 7d 08                               	mulx   r15,rbx,QWORD PTR [r13+0x8]
   7d54a:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7d550:	f3 49 0f 38 f6 c7                               	adox   rax,r15
   7d556:	c4 42 e3 f6 7d 10                               	mulx   r15,rbx,QWORD PTR [r13+0x10]
   7d55c:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   7d562:	f3 49 0f 38 f6 cf                               	adox   rcx,r15
   7d568:	c4 42 e3 f6 7d 18                               	mulx   r15,rbx,QWORD PTR [r13+0x18]
   7d56e:	66 48 0f 38 f6 cb                               	adcx   rcx,rbx
   7d574:	f3 4d 0f 38 f6 d7                               	adox   r10,r15
   7d57a:	66 4d 0f 38 f6 d3                               	adcx   r10,r11
   7d580:	48 89 f2                                        	mov    rdx,rsi
   7d583:	49 0f af d4                                     	imul   rdx,r12
   7d587:	45 31 db                                        	xor    r11d,r11d
   7d58a:	c4 62 e3 f6 3f                                  	mulx   r15,rbx,QWORD PTR [rdi]
   7d58f:	66 48 0f 38 f6 f3                               	adcx   rsi,rbx
   7d595:	f3 4d 0f 38 f6 c7                               	adox   r8,r15
   7d59b:	c4 62 e3 f6 7f 08                               	mulx   r15,rbx,QWORD PTR [rdi+0x8]
   7d5a1:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7d5a7:	f3 49 0f 38 f6 c7                               	adox   rax,r15
   7d5ad:	c4 62 e3 f6 7f 10                               	mulx   r15,rbx,QWORD PTR [rdi+0x10]
   7d5b3:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   7d5b9:	f3 49 0f 38 f6 cf                               	adox   rcx,r15
   7d5bf:	c4 62 e3 f6 7f 18                               	mulx   r15,rbx,QWORD PTR [rdi+0x18]
   7d5c5:	66 48 0f 38 f6 cb                               	adcx   rcx,rbx
   7d5cb:	f3 4d 0f 38 f6 d7                               	adox   r10,r15
   7d5d1:	66 4d 0f 38 f6 d3                               	adcx   r10,r11
   7d5d7:	48 8b 55 10                                     	mov    rdx,QWORD PTR [rbp+0x10]
   7d5db:	45 31 db                                        	xor    r11d,r11d
   7d5de:	c4 42 e3 f6 7d 00                               	mulx   r15,rbx,QWORD PTR [r13+0x0]
   7d5e4:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7d5ea:	f3 49 0f 38 f6 c7                               	adox   rax,r15
   7d5f0:	c4 42 e3 f6 7d 08                               	mulx   r15,rbx,QWORD PTR [r13+0x8]
   7d5f6:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   7d5fc:	f3 49 0f 38 f6 cf                               	adox   rcx,r15
   7d602:	c4 42 e3 f6 7d 10                               	mulx   r15,rbx,QWORD PTR [r13+0x10]
   7d608:	66 48 0f 38 f6 cb                               	adcx   rcx,rbx
   7d60e:	f3 4d 0f 38 f6 d7                               	adox   r10,r15
   7d614:	c4 42 e3 f6 7d 18                               	mulx   r15,rbx,QWORD PTR [r13+0x18]
   7d61a:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   7d620:	f3 49 0f 38 f6 f7                               	adox   rsi,r15
   7d626:	66 49 0f 38 f6 f3                               	adcx   rsi,r11
   7d62c:	4c 89 c2                                        	mov    rdx,r8
   7d62f:	49 0f af d4                                     	imul   rdx,r12
   7d633:	45 31 db                                        	xor    r11d,r11d
   7d636:	c4 62 e3 f6 3f                                  	mulx   r15,rbx,QWORD PTR [rdi]
   7d63b:	66 4c 0f 38 f6 c3                               	adcx   r8,rbx
   7d641:	f3 49 0f 38 f6 c7                               	adox   rax,r15
   7d647:	c4 62 e3 f6 7f 08                               	mulx   r15,rbx,QWORD PTR [rdi+0x8]
   7d64d:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   7d653:	f3 49 0f 38 f6 cf                               	adox   rcx,r15
   7d659:	c4 62 e3 f6 7f 10                               	mulx   r15,rbx,QWORD PTR [rdi+0x10]
   7d65f:	66 48 0f 38 f6 cb                               	adcx   rcx,rbx
   7d665:	f3 4d 0f 38 f6 d7                               	adox   r10,r15
   7d66b:	c4 62 e3 f6 7f 18                               	mulx   r15,rbx,QWORD PTR [rdi+0x18]
   7d671:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   7d677:	f3 49 0f 38 f6 f7                               	adox   rsi,r15
   7d67d:	66 49 0f 38 f6 f3                               	adcx   rsi,r11
   7d683:	48 8b 55 18                                     	mov    rdx,QWORD PTR [rbp+0x18]
   7d687:	45 31 db                                        	xor    r11d,r11d
   7d68a:	c4 42 e3 f6 7d 00                               	mulx   r15,rbx,QWORD PTR [r13+0x0]
   7d690:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   7d696:	f3 49 0f 38 f6 cf                               	adox   rcx,r15
   7d69c:	c4 42 e3 f6 7d 08                               	mulx   r15,rbx,QWORD PTR [r13+0x8]
   7d6a2:	66 48 0f 38 f6 cb                               	adcx   rcx,rbx
   7d6a8:	f3 4d 0f 38 f6 d7                               	adox   r10,r15
   7d6ae:	c4 42 e3 f6 7d 10                               	mulx   r15,rbx,QWORD PTR [r13+0x10]
   7d6b4:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   7d6ba:	f3 49 0f 38 f6 f7                               	adox   rsi,r15
   7d6c0:	c4 42 e3 f6 7d 18                               	mulx   r15,rbx,QWORD PTR [r13+0x18]
   7d6c6:	66 48 0f 38 f6 f3                               	adcx   rsi,rbx
   7d6cc:	f3 4d 0f 38 f6 c7                               	adox   r8,r15
   7d6d2:	66 4d 0f 38 f6 c3                               	adcx   r8,r11
   7d6d8:	48 89 c2                                        	mov    rdx,rax
   7d6db:	49 0f af d4                                     	imul   rdx,r12
   7d6df:	45 31 db                                        	xor    r11d,r11d
   7d6e2:	c4 62 e3 f6 3f                                  	mulx   r15,rbx,QWORD PTR [rdi]
   7d6e7:	66 48 0f 38 f6 c3                               	adcx   rax,rbx
   7d6ed:	f3 49 0f 38 f6 cf                               	adox   rcx,r15
   7d6f3:	c4 62 e3 f6 7f 08                               	mulx   r15,rbx,QWORD PTR [rdi+0x8]
   7d6f9:	66 48 0f 38 f6 cb                               	adcx   rcx,rbx
   7d6ff:	f3 4d 0f 38 f6 d7                               	adox   r10,r15
   7d705:	c4 62 e3 f6 7f 10                               	mulx   r15,rbx,QWORD PTR [rdi+0x10]
   7d70b:	66 4c 0f 38 f6 d3                               	adcx   r10,rbx
   7d711:	f3 49 0f 38 f6 f7                               	adox   rsi,r15
   7d717:	c4 62 e3 f6 7f 18                               	mulx   r15,rbx,QWORD PTR [rdi+0x18]
   7d71d:	66 48 0f 38 f6 f3                               	adcx   rsi,rbx
   7d723:	f3 4d 0f 38 f6 c7                               	adox   r8,r15
   7d729:	66 4d 0f 38 f6 c3                               	adcx   r8,r11
   7d72f:	48 b8 29 a0 31 e1 72 4e 64 30                   	movabs rax,0x30644e72e131a029
   7d739:	48 89 8c 24 20 01 00 00                         	mov    QWORD PTR [rsp+0x120],rcx
   7d741:	48 89 b4 24 60 01 00 00                         	mov    QWORD PTR [rsp+0x160],rsi
   7d749:	4c 89 84 24 58 01 00 00                         	mov    QWORD PTR [rsp+0x158],r8
   7d751:	4c 89 94 24 68 01 00 00                         	mov    QWORD PTR [rsp+0x168],r10
   7d759:	c5 fe 7f 94 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm2
   7d762:	4c 8d bc 24 b0 00 00 00                         	lea    r15,[rsp+0xb0]
   7d76a:	4c 8d a4 24 50 05 00 00                         	lea    r12,[rsp+0x550]
   7d772:	48 8d 7c 24 60                                  	lea    rdi,[rsp+0x60]
   7d777:	48 8d ac 24 50 05 00 00                         	lea    rbp,[rsp+0x550]
   7d77f:	4c 8d ac 24 b0 00 00 00                         	lea    r13,[rsp+0xb0]
   7d787:	48 8b 94 24 00 01 00 00                         	mov    rdx,QWORD PTR [rsp+0x100]
   7d78f:	48 8b 8c 24 88 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x88]
   7d797:	48 39 c2                                        	cmp    rdx,rax
   7d79a:	0f 92 c0                                        	setb   al
   7d79d:	0a 44 24 37                                     	or     al,BYTE PTR [rsp+0x37]
   7d7a1:	48 8b 44 24 20                                  	mov    rax,QWORD PTR [rsp+0x20]
   7d7a6:	48 0f 45 84 24 18 01 00 00                      	cmovne rax,QWORD PTR [rsp+0x118]
   7d7af:	4c 0f 45 8c 24 10 01 00 00                      	cmovne r9,QWORD PTR [rsp+0x110]
   7d7b8:	4c 0f 45 b4 24 08 01 00 00                      	cmovne r14,QWORD PTR [rsp+0x108]
   7d7c1:	48 0f 45 ca                                     	cmovne rcx,rdx
   7d7c5:	48 89 8c 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],rcx
   7d7cd:	48 89 44 24 60                                  	mov    QWORD PTR [rsp+0x60],rax
   7d7d2:	4c 89 4c 24 68                                  	mov    QWORD PTR [rsp+0x68],r9
   7d7d7:	4c 89 74 24 70                                  	mov    QWORD PTR [rsp+0x70],r14
   7d7dc:	48 89 4c 24 78                                  	mov    QWORD PTR [rsp+0x78],rcx
   7d7e1:	48 89 44 24 20                                  	mov    QWORD PTR [rsp+0x20],rax
   7d7e6:	4c 89 8c 24 90 00 00 00                         	mov    QWORD PTR [rsp+0x90],r9
   7d7ee:	4c 89 74 24 28                                  	mov    QWORD PTR [rsp+0x28],r14
   7d7f3:	48 8b 4c 24 68                                  	mov    rcx,QWORD PTR [rsp+0x68]
   7d7f8:	48 8b 44 24 60                                  	mov    rax,QWORD PTR [rsp+0x60]
   7d7fd:	48 8b 74 24 70                                  	mov    rsi,QWORD PTR [rsp+0x70]
   7d802:	48 89 8c 24 b8 00 00 00                         	mov    QWORD PTR [rsp+0xb8],rcx
   7d80a:	48 8b 4c 24 78                                  	mov    rcx,QWORD PTR [rsp+0x78]
   7d80f:	48 89 84 24 b0 00 00 00                         	mov    QWORD PTR [rsp+0xb0],rax
   7d817:	48 89 b4 24 c0 00 00 00                         	mov    QWORD PTR [rsp+0xc0],rsi
   7d81f:	48 89 8c 24 c8 00 00 00                         	mov    QWORD PTR [rsp+0xc8],rcx
   7d827:	48 b9 89 63 86 e4 82 07 d2 87                   	movabs rcx,0x87d20782e4866389
   7d831:	45 31 c0                                        	xor    r8d,r8d
   7d834:	31 f6                                           	xor    esi,esi
   7d836:	31 c0                                           	xor    eax,eax
   7d838:	45 31 c9                                        	xor    r9d,r9d
   7d83b:	31 db                                           	xor    ebx,ebx
   7d83d:	48 8b 17                                        	mov    rdx,QWORD PTR [rdi]
   7d840:	45 31 f6                                        	xor    r14d,r14d
   7d843:	c4 42 ab f6 1f                                  	mulx   r11,r10,QWORD PTR [r15]
   7d848:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7d84e:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d854:	c4 42 ab f6 5f 08                               	mulx   r11,r10,QWORD PTR [r15+0x8]
   7d85a:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d860:	f3 49 0f 38 f6 c3                               	adox   rax,r11
   7d866:	c4 42 ab f6 5f 10                               	mulx   r11,r10,QWORD PTR [r15+0x10]
   7d86c:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   7d872:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7d878:	c4 42 ab f6 5f 18                               	mulx   r11,r10,QWORD PTR [r15+0x18]
   7d87e:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7d884:	f3 49 0f 38 f6 db                               	adox   rbx,r11
   7d88a:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   7d890:	4c 89 c2                                        	mov    rdx,r8
   7d893:	48 0f af d1                                     	imul   rdx,rcx
   7d897:	45 31 f6                                        	xor    r14d,r14d
   7d89a:	c4 42 ab f6 1c 24                               	mulx   r11,r10,QWORD PTR [r12]
   7d8a0:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7d8a6:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d8ac:	c4 42 ab f6 5c 24 08                            	mulx   r11,r10,QWORD PTR [r12+0x8]
   7d8b3:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d8b9:	f3 49 0f 38 f6 c3                               	adox   rax,r11
   7d8bf:	c4 42 ab f6 5c 24 10                            	mulx   r11,r10,QWORD PTR [r12+0x10]
   7d8c6:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   7d8cc:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7d8d2:	c4 42 ab f6 5c 24 18                            	mulx   r11,r10,QWORD PTR [r12+0x18]
   7d8d9:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7d8df:	f3 49 0f 38 f6 db                               	adox   rbx,r11
   7d8e5:	66 49 0f 38 f6 de                               	adcx   rbx,r14
   7d8eb:	48 8b 57 08                                     	mov    rdx,QWORD PTR [rdi+0x8]
   7d8ef:	45 31 f6                                        	xor    r14d,r14d
   7d8f2:	c4 42 ab f6 1f                                  	mulx   r11,r10,QWORD PTR [r15]
   7d8f7:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d8fd:	f3 49 0f 38 f6 c3                               	adox   rax,r11
   7d903:	c4 42 ab f6 5f 08                               	mulx   r11,r10,QWORD PTR [r15+0x8]
   7d909:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   7d90f:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7d915:	c4 42 ab f6 5f 10                               	mulx   r11,r10,QWORD PTR [r15+0x10]
   7d91b:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7d921:	f3 49 0f 38 f6 db                               	adox   rbx,r11
   7d927:	c4 42 ab f6 5f 18                               	mulx   r11,r10,QWORD PTR [r15+0x18]
   7d92d:	66 49 0f 38 f6 da                               	adcx   rbx,r10
   7d933:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7d939:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   7d93f:	48 89 f2                                        	mov    rdx,rsi
   7d942:	48 0f af d1                                     	imul   rdx,rcx
   7d946:	45 31 f6                                        	xor    r14d,r14d
   7d949:	c4 42 ab f6 1c 24                               	mulx   r11,r10,QWORD PTR [r12]
   7d94f:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7d955:	f3 49 0f 38 f6 c3                               	adox   rax,r11
   7d95b:	c4 42 ab f6 5c 24 08                            	mulx   r11,r10,QWORD PTR [r12+0x8]
   7d962:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   7d968:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7d96e:	c4 42 ab f6 5c 24 10                            	mulx   r11,r10,QWORD PTR [r12+0x10]
   7d975:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7d97b:	f3 49 0f 38 f6 db                               	adox   rbx,r11
   7d981:	c4 42 ab f6 5c 24 18                            	mulx   r11,r10,QWORD PTR [r12+0x18]
   7d988:	66 49 0f 38 f6 da                               	adcx   rbx,r10
   7d98e:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7d994:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   7d99a:	48 8b 57 10                                     	mov    rdx,QWORD PTR [rdi+0x10]
   7d99e:	45 31 f6                                        	xor    r14d,r14d
   7d9a1:	c4 42 ab f6 1f                                  	mulx   r11,r10,QWORD PTR [r15]
   7d9a6:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   7d9ac:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7d9b2:	c4 42 ab f6 5f 08                               	mulx   r11,r10,QWORD PTR [r15+0x8]
   7d9b8:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7d9be:	f3 49 0f 38 f6 db                               	adox   rbx,r11
   7d9c4:	c4 42 ab f6 5f 10                               	mulx   r11,r10,QWORD PTR [r15+0x10]
   7d9ca:	66 49 0f 38 f6 da                               	adcx   rbx,r10
   7d9d0:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7d9d6:	c4 42 ab f6 5f 18                               	mulx   r11,r10,QWORD PTR [r15+0x18]
   7d9dc:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7d9e2:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7d9e8:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   7d9ee:	48 89 c2                                        	mov    rdx,rax
   7d9f1:	48 0f af d1                                     	imul   rdx,rcx
   7d9f5:	45 31 f6                                        	xor    r14d,r14d
   7d9f8:	c4 42 ab f6 1c 24                               	mulx   r11,r10,QWORD PTR [r12]
   7d9fe:	66 49 0f 38 f6 c2                               	adcx   rax,r10
   7da04:	f3 4d 0f 38 f6 cb                               	adox   r9,r11
   7da0a:	c4 42 ab f6 5c 24 08                            	mulx   r11,r10,QWORD PTR [r12+0x8]
   7da11:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7da17:	f3 49 0f 38 f6 db                               	adox   rbx,r11
   7da1d:	c4 42 ab f6 5c 24 10                            	mulx   r11,r10,QWORD PTR [r12+0x10]
   7da24:	66 49 0f 38 f6 da                               	adcx   rbx,r10
   7da2a:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7da30:	c4 42 ab f6 5c 24 18                            	mulx   r11,r10,QWORD PTR [r12+0x18]
   7da37:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7da3d:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7da43:	66 49 0f 38 f6 f6                               	adcx   rsi,r14
   7da49:	48 8b 57 18                                     	mov    rdx,QWORD PTR [rdi+0x18]
   7da4d:	45 31 f6                                        	xor    r14d,r14d
   7da50:	c4 42 ab f6 1f                                  	mulx   r11,r10,QWORD PTR [r15]
   7da55:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7da5b:	f3 49 0f 38 f6 db                               	adox   rbx,r11
   7da61:	c4 42 ab f6 5f 08                               	mulx   r11,r10,QWORD PTR [r15+0x8]
   7da67:	66 49 0f 38 f6 da                               	adcx   rbx,r10
   7da6d:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7da73:	c4 42 ab f6 5f 10                               	mulx   r11,r10,QWORD PTR [r15+0x10]
   7da79:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7da7f:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7da85:	c4 42 ab f6 5f 18                               	mulx   r11,r10,QWORD PTR [r15+0x18]
   7da8b:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7da91:	f3 49 0f 38 f6 c3                               	adox   rax,r11
   7da97:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   7da9d:	4c 89 ca                                        	mov    rdx,r9
   7daa0:	48 0f af d1                                     	imul   rdx,rcx
   7daa4:	45 31 f6                                        	xor    r14d,r14d
   7daa7:	c4 42 ab f6 1c 24                               	mulx   r11,r10,QWORD PTR [r12]
   7daad:	66 4d 0f 38 f6 ca                               	adcx   r9,r10
   7dab3:	f3 49 0f 38 f6 db                               	adox   rbx,r11
   7dab9:	c4 42 ab f6 5c 24 08                            	mulx   r11,r10,QWORD PTR [r12+0x8]
   7dac0:	66 49 0f 38 f6 da                               	adcx   rbx,r10
   7dac6:	f3 4d 0f 38 f6 c3                               	adox   r8,r11
   7dacc:	c4 42 ab f6 5c 24 10                            	mulx   r11,r10,QWORD PTR [r12+0x10]
   7dad3:	66 4d 0f 38 f6 c2                               	adcx   r8,r10
   7dad9:	f3 49 0f 38 f6 f3                               	adox   rsi,r11
   7dadf:	c4 42 ab f6 5c 24 18                            	mulx   r11,r10,QWORD PTR [r12+0x18]
   7dae6:	66 49 0f 38 f6 f2                               	adcx   rsi,r10
   7daec:	f3 49 0f 38 f6 c3                               	adox   rax,r11
   7daf2:	66 49 0f 38 f6 c6                               	adcx   rax,r14
   7daf8:	48 b9 73 35 8e 97 6e 95 7e 68                   	movabs rcx,0x687e956e978e3573
   7db02:	49 bb 47 fd 7c d8 16 8c 20 3c                   	movabs r11,0x3c208c16d87cfd47
   7db0c:	49 8d 3c 08                                     	lea    rdi,[r8+rcx*1]
   7db10:	4c 39 db                                        	cmp    rbx,r11
   7db13:	48 b9 8d ca 71 68 91 6a 81 97                   	movabs rcx,0x97816a916871ca8d
   7db1d:	48 83 df 00                                     	sbb    rdi,0x0
   7db21:	0f 92 c2                                        	setb   dl
   7db24:	49 39 c8                                        	cmp    r8,rcx
   7db27:	48 b9 a3 a7 7e 7e 49 ba af 47                   	movabs rcx,0x47afba497e7ea7a3
   7db31:	41 0f 92 c1                                     	setb   r9b
   7db35:	4c 8d 34 0e                                     	lea    r14,[rsi+rcx*1]
   7db39:	48 b9 5d 58 81 81 b6 45 50 b8                   	movabs rcx,0xb85045b68181585d
   7db43:	41 08 d1                                        	or     r9b,dl
   7db46:	41 0f b6 d1                                     	movzx  edx,r9b
   7db4a:	4c 8d 4c 24 60                                  	lea    r9,[rsp+0x60]
   7db4f:	49 29 d6                                        	sub    r14,rdx
   7db52:	0f 92 c2                                        	setb   dl
   7db55:	48 39 ce                                        	cmp    rsi,rcx
   7db58:	48 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs rcx,0xcf9bb18d1ece5fd7
   7db62:	41 0f 92 c2                                     	setb   r10b
   7db66:	4c 8d 3c 08                                     	lea    r15,[rax+rcx*1]
   7db6a:	48 b9 29 a0 31 e1 72 4e 64 30                   	movabs rcx,0x30644e72e131a029
   7db74:	41 08 d2                                        	or     r10b,dl
   7db77:	41 0f b6 d2                                     	movzx  edx,r10b
   7db7b:	49 29 d7                                        	sub    r15,rdx
   7db7e:	0f 92 c2                                        	setb   dl
   7db81:	48 39 c8                                        	cmp    rax,rcx
   7db84:	48 b9 b9 02 83 27 e9 73 df c3                   	movabs rcx,0xc3df73e9278302b9
   7db8e:	41 0f 92 c2                                     	setb   r10b
   7db92:	4c 8d 1c 0b                                     	lea    r11,[rbx+rcx*1]
   7db96:	41 08 d2                                        	or     r10b,dl
   7db99:	49 0f 45 f8                                     	cmovne rdi,r8
   7db9d:	4c 8b 44 24 50                                  	mov    r8,QWORD PTR [rsp+0x50]
   7dba2:	4c 0f 45 f8                                     	cmovne r15,rax
   7dba6:	4c 0f 45 f6                                     	cmovne r14,rsi
   7dbaa:	4c 0f 45 db                                     	cmovne r11,rbx
   7dbae:	48 89 7c 24 08                                  	mov    QWORD PTR [rsp+0x8],rdi
   7dbb3:	4c 89 74 24 18                                  	mov    QWORD PTR [rsp+0x18],r14
   7dbb8:	49 8d 40 a0                                     	lea    rax,[r8-0x60]
   7dbbc:	c5 fc 10 08                                     	vmovups ymm1,YMMWORD PTR [rax]
   7dbc0:	4c 89 9c 24 b0 00 00 00                         	mov    QWORD PTR [rsp+0xb0],r11
   7dbc8:	48 89 bc 24 b8 00 00 00                         	mov    QWORD PTR [rsp+0xb8],rdi
   7dbd0:	4c 89 b4 24 c0 00 00 00                         	mov    QWORD PTR [rsp+0xc0],r14
   7dbd8:	4c 89 bc 24 c8 00 00 00                         	mov    QWORD PTR [rsp+0xc8],r15
   7dbe0:	c5 fe 7f 94 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm2
   7dbe9:	48 bf 89 63 86 e4 82 07 d2 87                   	movabs rdi,0x87d20782e4866389
   7dbf3:	c5 fc 11 4c 24 60                               	vmovups YMMWORD PTR [rsp+0x60],ymm1
   7dbf9:	45 31 d2                                        	xor    r10d,r10d
   7dbfc:	45 31 e4                                        	xor    r12d,r12d
   7dbff:	45 31 f6                                        	xor    r14d,r14d
   7dc02:	31 db                                           	xor    ebx,ebx
   7dc04:	45 31 c0                                        	xor    r8d,r8d
   7dc07:	49 8b 55 00                                     	mov    rdx,QWORD PTR [r13+0x0]
   7dc0b:	31 c0                                           	xor    eax,eax
   7dc0d:	c4 c2 f3 f6 31                                  	mulx   rsi,rcx,QWORD PTR [r9]
   7dc12:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   7dc18:	f3 4c 0f 38 f6 e6                               	adox   r12,rsi
   7dc1e:	c4 c2 f3 f6 71 08                               	mulx   rsi,rcx,QWORD PTR [r9+0x8]
   7dc24:	66 4c 0f 38 f6 e1                               	adcx   r12,rcx
   7dc2a:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7dc30:	c4 c2 f3 f6 71 10                               	mulx   rsi,rcx,QWORD PTR [r9+0x10]
   7dc36:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7dc3c:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7dc42:	c4 c2 f3 f6 71 18                               	mulx   rsi,rcx,QWORD PTR [r9+0x18]
   7dc48:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7dc4e:	f3 4c 0f 38 f6 c6                               	adox   r8,rsi
   7dc54:	66 4c 0f 38 f6 c0                               	adcx   r8,rax
   7dc5a:	4c 89 d2                                        	mov    rdx,r10
   7dc5d:	48 0f af d7                                     	imul   rdx,rdi
   7dc61:	31 c0                                           	xor    eax,eax
   7dc63:	c4 e2 f3 f6 75 00                               	mulx   rsi,rcx,QWORD PTR [rbp+0x0]
   7dc69:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   7dc6f:	f3 4c 0f 38 f6 e6                               	adox   r12,rsi
   7dc75:	c4 e2 f3 f6 75 08                               	mulx   rsi,rcx,QWORD PTR [rbp+0x8]
   7dc7b:	66 4c 0f 38 f6 e1                               	adcx   r12,rcx
   7dc81:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7dc87:	c4 e2 f3 f6 75 10                               	mulx   rsi,rcx,QWORD PTR [rbp+0x10]
   7dc8d:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7dc93:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7dc99:	c4 e2 f3 f6 75 18                               	mulx   rsi,rcx,QWORD PTR [rbp+0x18]
   7dc9f:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7dca5:	f3 4c 0f 38 f6 c6                               	adox   r8,rsi
   7dcab:	66 4c 0f 38 f6 c0                               	adcx   r8,rax
   7dcb1:	49 8b 55 08                                     	mov    rdx,QWORD PTR [r13+0x8]
   7dcb5:	31 c0                                           	xor    eax,eax
   7dcb7:	c4 c2 f3 f6 31                                  	mulx   rsi,rcx,QWORD PTR [r9]
   7dcbc:	66 4c 0f 38 f6 e1                               	adcx   r12,rcx
   7dcc2:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7dcc8:	c4 c2 f3 f6 71 08                               	mulx   rsi,rcx,QWORD PTR [r9+0x8]
   7dcce:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7dcd4:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7dcda:	c4 c2 f3 f6 71 10                               	mulx   rsi,rcx,QWORD PTR [r9+0x10]
   7dce0:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7dce6:	f3 4c 0f 38 f6 c6                               	adox   r8,rsi
   7dcec:	c4 c2 f3 f6 71 18                               	mulx   rsi,rcx,QWORD PTR [r9+0x18]
   7dcf2:	66 4c 0f 38 f6 c1                               	adcx   r8,rcx
   7dcf8:	f3 4c 0f 38 f6 d6                               	adox   r10,rsi
   7dcfe:	66 4c 0f 38 f6 d0                               	adcx   r10,rax
   7dd04:	4c 89 e2                                        	mov    rdx,r12
   7dd07:	48 0f af d7                                     	imul   rdx,rdi
   7dd0b:	31 c0                                           	xor    eax,eax
   7dd0d:	c4 e2 f3 f6 75 00                               	mulx   rsi,rcx,QWORD PTR [rbp+0x0]
   7dd13:	66 4c 0f 38 f6 e1                               	adcx   r12,rcx
   7dd19:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7dd1f:	c4 e2 f3 f6 75 08                               	mulx   rsi,rcx,QWORD PTR [rbp+0x8]
   7dd25:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7dd2b:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7dd31:	c4 e2 f3 f6 75 10                               	mulx   rsi,rcx,QWORD PTR [rbp+0x10]
   7dd37:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7dd3d:	f3 4c 0f 38 f6 c6                               	adox   r8,rsi
   7dd43:	c4 e2 f3 f6 75 18                               	mulx   rsi,rcx,QWORD PTR [rbp+0x18]
   7dd49:	66 4c 0f 38 f6 c1                               	adcx   r8,rcx
   7dd4f:	f3 4c 0f 38 f6 d6                               	adox   r10,rsi
   7dd55:	66 4c 0f 38 f6 d0                               	adcx   r10,rax
   7dd5b:	49 8b 55 10                                     	mov    rdx,QWORD PTR [r13+0x10]
   7dd5f:	31 c0                                           	xor    eax,eax
   7dd61:	c4 c2 f3 f6 31                                  	mulx   rsi,rcx,QWORD PTR [r9]
   7dd66:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7dd6c:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7dd72:	c4 c2 f3 f6 71 08                               	mulx   rsi,rcx,QWORD PTR [r9+0x8]
   7dd78:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7dd7e:	f3 4c 0f 38 f6 c6                               	adox   r8,rsi
   7dd84:	c4 c2 f3 f6 71 10                               	mulx   rsi,rcx,QWORD PTR [r9+0x10]
   7dd8a:	66 4c 0f 38 f6 c1                               	adcx   r8,rcx
   7dd90:	f3 4c 0f 38 f6 d6                               	adox   r10,rsi
   7dd96:	c4 c2 f3 f6 71 18                               	mulx   rsi,rcx,QWORD PTR [r9+0x18]
   7dd9c:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   7dda2:	f3 4c 0f 38 f6 e6                               	adox   r12,rsi
   7dda8:	66 4c 0f 38 f6 e0                               	adcx   r12,rax
   7ddae:	4c 89 f2                                        	mov    rdx,r14
   7ddb1:	48 0f af d7                                     	imul   rdx,rdi
   7ddb5:	31 c0                                           	xor    eax,eax
   7ddb7:	c4 e2 f3 f6 75 00                               	mulx   rsi,rcx,QWORD PTR [rbp+0x0]
   7ddbd:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7ddc3:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7ddc9:	c4 e2 f3 f6 75 08                               	mulx   rsi,rcx,QWORD PTR [rbp+0x8]
   7ddcf:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7ddd5:	f3 4c 0f 38 f6 c6                               	adox   r8,rsi
   7dddb:	c4 e2 f3 f6 75 10                               	mulx   rsi,rcx,QWORD PTR [rbp+0x10]
   7dde1:	66 4c 0f 38 f6 c1                               	adcx   r8,rcx
   7dde7:	f3 4c 0f 38 f6 d6                               	adox   r10,rsi
   7dded:	c4 e2 f3 f6 75 18                               	mulx   rsi,rcx,QWORD PTR [rbp+0x18]
   7ddf3:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   7ddf9:	f3 4c 0f 38 f6 e6                               	adox   r12,rsi
   7ddff:	66 4c 0f 38 f6 e0                               	adcx   r12,rax
   7de05:	49 8b 55 18                                     	mov    rdx,QWORD PTR [r13+0x18]
   7de09:	31 c0                                           	xor    eax,eax
   7de0b:	c4 c2 f3 f6 31                                  	mulx   rsi,rcx,QWORD PTR [r9]
   7de10:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7de16:	f3 4c 0f 38 f6 c6                               	adox   r8,rsi
   7de1c:	c4 c2 f3 f6 71 08                               	mulx   rsi,rcx,QWORD PTR [r9+0x8]
   7de22:	66 4c 0f 38 f6 c1                               	adcx   r8,rcx
   7de28:	f3 4c 0f 38 f6 d6                               	adox   r10,rsi
   7de2e:	c4 c2 f3 f6 71 10                               	mulx   rsi,rcx,QWORD PTR [r9+0x10]
   7de34:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   7de3a:	f3 4c 0f 38 f6 e6                               	adox   r12,rsi
   7de40:	c4 c2 f3 f6 71 18                               	mulx   rsi,rcx,QWORD PTR [r9+0x18]
   7de46:	66 4c 0f 38 f6 e1                               	adcx   r12,rcx
   7de4c:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7de52:	66 4c 0f 38 f6 f0                               	adcx   r14,rax
   7de58:	48 89 da                                        	mov    rdx,rbx
   7de5b:	48 0f af d7                                     	imul   rdx,rdi
   7de5f:	31 c0                                           	xor    eax,eax
   7de61:	c4 e2 f3 f6 75 00                               	mulx   rsi,rcx,QWORD PTR [rbp+0x0]
   7de67:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7de6d:	f3 4c 0f 38 f6 c6                               	adox   r8,rsi
   7de73:	c4 e2 f3 f6 75 08                               	mulx   rsi,rcx,QWORD PTR [rbp+0x8]
   7de79:	66 4c 0f 38 f6 c1                               	adcx   r8,rcx
   7de7f:	f3 4c 0f 38 f6 d6                               	adox   r10,rsi
   7de85:	c4 e2 f3 f6 75 10                               	mulx   rsi,rcx,QWORD PTR [rbp+0x10]
   7de8b:	66 4c 0f 38 f6 d1                               	adcx   r10,rcx
   7de91:	f3 4c 0f 38 f6 e6                               	adox   r12,rsi
   7de97:	c4 e2 f3 f6 75 18                               	mulx   rsi,rcx,QWORD PTR [rbp+0x18]
   7de9d:	66 4c 0f 38 f6 e1                               	adcx   r12,rcx
   7dea3:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7dea9:	66 4c 0f 38 f6 f0                               	adcx   r14,rax
   7deaf:	4c 89 94 24 08 01 00 00                         	mov    QWORD PTR [rsp+0x108],r10
   7deb7:	4c 89 a4 24 10 01 00 00                         	mov    QWORD PTR [rsp+0x110],r12
   7debf:	4c 89 84 24 18 01 00 00                         	mov    QWORD PTR [rsp+0x118],r8
   7dec7:	4c 89 b4 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],r14
   7decf:	4c 8d 6c 24 60                                  	lea    r13,[rsp+0x60]
   7ded4:	4c 8d 94 24 50 05 00 00                         	lea    r10,[rsp+0x550]
   7dedc:	49 bc 89 63 86 e4 82 07 d2 87                   	movabs r12,0x87d20782e4866389
   7dee6:	4c 8d 84 24 b0 00 00 00                         	lea    r8,[rsp+0xb0]
   7deee:	48 8b 44 24 50                                  	mov    rax,QWORD PTR [rsp+0x50]
   7def3:	48 8b 7c 24 08                                  	mov    rdi,QWORD PTR [rsp+0x8]
   7def8:	4c 8b 4c 24 18                                  	mov    r9,QWORD PTR [rsp+0x18]
   7defd:	c5 fe 6f 48 c0                                  	vmovdqu ymm1,YMMWORD PTR [rax-0x40]
   7df02:	4c 89 9c 24 b0 00 00 00                         	mov    QWORD PTR [rsp+0xb0],r11
   7df0a:	48 89 bc 24 b8 00 00 00                         	mov    QWORD PTR [rsp+0xb8],rdi
   7df12:	4c 89 8c 24 c0 00 00 00                         	mov    QWORD PTR [rsp+0xc0],r9
   7df1a:	4c 89 bc 24 c8 00 00 00                         	mov    QWORD PTR [rsp+0xc8],r15
   7df22:	c5 fe 7f 94 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm2
   7df2b:	48 8b 7c 24 58                                  	mov    rdi,QWORD PTR [rsp+0x58]
   7df30:	c5 fe 7f 4c 24 60                               	vmovdqu YMMWORD PTR [rsp+0x60],ymm1
   7df36:	31 ed                                           	xor    ebp,ebp
   7df38:	45 31 c9                                        	xor    r9d,r9d
   7df3b:	45 31 f6                                        	xor    r14d,r14d
   7df3e:	31 c0                                           	xor    eax,eax
   7df40:	31 db                                           	xor    ebx,ebx
   7df42:	49 8b 10                                        	mov    rdx,QWORD PTR [r8]
   7df45:	45 31 db                                        	xor    r11d,r11d
   7df48:	c4 c2 f3 f6 75 00                               	mulx   rsi,rcx,QWORD PTR [r13+0x0]
   7df4e:	66 48 0f 38 f6 e9                               	adcx   rbp,rcx
   7df54:	f3 4c 0f 38 f6 ce                               	adox   r9,rsi
   7df5a:	c4 c2 f3 f6 75 08                               	mulx   rsi,rcx,QWORD PTR [r13+0x8]
   7df60:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   7df66:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7df6c:	c4 c2 f3 f6 75 10                               	mulx   rsi,rcx,QWORD PTR [r13+0x10]
   7df72:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7df78:	f3 48 0f 38 f6 c6                               	adox   rax,rsi
   7df7e:	c4 c2 f3 f6 75 18                               	mulx   rsi,rcx,QWORD PTR [r13+0x18]
   7df84:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   7df8a:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7df90:	66 49 0f 38 f6 db                               	adcx   rbx,r11
   7df96:	48 89 ea                                        	mov    rdx,rbp
   7df99:	49 0f af d4                                     	imul   rdx,r12
   7df9d:	45 31 db                                        	xor    r11d,r11d
   7dfa0:	c4 c2 f3 f6 32                                  	mulx   rsi,rcx,QWORD PTR [r10]
   7dfa5:	66 48 0f 38 f6 e9                               	adcx   rbp,rcx
   7dfab:	f3 4c 0f 38 f6 ce                               	adox   r9,rsi
   7dfb1:	c4 c2 f3 f6 72 08                               	mulx   rsi,rcx,QWORD PTR [r10+0x8]
   7dfb7:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   7dfbd:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7dfc3:	c4 c2 f3 f6 72 10                               	mulx   rsi,rcx,QWORD PTR [r10+0x10]
   7dfc9:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7dfcf:	f3 48 0f 38 f6 c6                               	adox   rax,rsi
   7dfd5:	c4 c2 f3 f6 72 18                               	mulx   rsi,rcx,QWORD PTR [r10+0x18]
   7dfdb:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   7dfe1:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7dfe7:	66 49 0f 38 f6 db                               	adcx   rbx,r11
   7dfed:	49 8b 50 08                                     	mov    rdx,QWORD PTR [r8+0x8]
   7dff1:	45 31 db                                        	xor    r11d,r11d
   7dff4:	c4 c2 f3 f6 75 00                               	mulx   rsi,rcx,QWORD PTR [r13+0x0]
   7dffa:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   7e000:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7e006:	c4 c2 f3 f6 75 08                               	mulx   rsi,rcx,QWORD PTR [r13+0x8]
   7e00c:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7e012:	f3 48 0f 38 f6 c6                               	adox   rax,rsi
   7e018:	c4 c2 f3 f6 75 10                               	mulx   rsi,rcx,QWORD PTR [r13+0x10]
   7e01e:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   7e024:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7e02a:	c4 c2 f3 f6 75 18                               	mulx   rsi,rcx,QWORD PTR [r13+0x18]
   7e030:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7e036:	f3 48 0f 38 f6 ee                               	adox   rbp,rsi
   7e03c:	66 49 0f 38 f6 eb                               	adcx   rbp,r11
   7e042:	4c 89 ca                                        	mov    rdx,r9
   7e045:	49 0f af d4                                     	imul   rdx,r12
   7e049:	45 31 db                                        	xor    r11d,r11d
   7e04c:	c4 c2 f3 f6 32                                  	mulx   rsi,rcx,QWORD PTR [r10]
   7e051:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   7e057:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7e05d:	c4 c2 f3 f6 72 08                               	mulx   rsi,rcx,QWORD PTR [r10+0x8]
   7e063:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7e069:	f3 48 0f 38 f6 c6                               	adox   rax,rsi
   7e06f:	c4 c2 f3 f6 72 10                               	mulx   rsi,rcx,QWORD PTR [r10+0x10]
   7e075:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   7e07b:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7e081:	c4 c2 f3 f6 72 18                               	mulx   rsi,rcx,QWORD PTR [r10+0x18]
   7e087:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7e08d:	f3 48 0f 38 f6 ee                               	adox   rbp,rsi
   7e093:	66 49 0f 38 f6 eb                               	adcx   rbp,r11
   7e099:	49 8b 50 10                                     	mov    rdx,QWORD PTR [r8+0x10]
   7e09d:	45 31 db                                        	xor    r11d,r11d
   7e0a0:	c4 c2 f3 f6 75 00                               	mulx   rsi,rcx,QWORD PTR [r13+0x0]
   7e0a6:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7e0ac:	f3 48 0f 38 f6 c6                               	adox   rax,rsi
   7e0b2:	c4 c2 f3 f6 75 08                               	mulx   rsi,rcx,QWORD PTR [r13+0x8]
   7e0b8:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   7e0be:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7e0c4:	c4 c2 f3 f6 75 10                               	mulx   rsi,rcx,QWORD PTR [r13+0x10]
   7e0ca:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7e0d0:	f3 48 0f 38 f6 ee                               	adox   rbp,rsi
   7e0d6:	c4 c2 f3 f6 75 18                               	mulx   rsi,rcx,QWORD PTR [r13+0x18]
   7e0dc:	66 48 0f 38 f6 e9                               	adcx   rbp,rcx
   7e0e2:	f3 4c 0f 38 f6 ce                               	adox   r9,rsi
   7e0e8:	66 4d 0f 38 f6 cb                               	adcx   r9,r11
   7e0ee:	4c 89 f2                                        	mov    rdx,r14
   7e0f1:	49 0f af d4                                     	imul   rdx,r12
   7e0f5:	45 31 db                                        	xor    r11d,r11d
   7e0f8:	c4 c2 f3 f6 32                                  	mulx   rsi,rcx,QWORD PTR [r10]
   7e0fd:	66 4c 0f 38 f6 f1                               	adcx   r14,rcx
   7e103:	f3 48 0f 38 f6 c6                               	adox   rax,rsi
   7e109:	c4 c2 f3 f6 72 08                               	mulx   rsi,rcx,QWORD PTR [r10+0x8]
   7e10f:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   7e115:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7e11b:	c4 c2 f3 f6 72 10                               	mulx   rsi,rcx,QWORD PTR [r10+0x10]
   7e121:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7e127:	f3 48 0f 38 f6 ee                               	adox   rbp,rsi
   7e12d:	c4 c2 f3 f6 72 18                               	mulx   rsi,rcx,QWORD PTR [r10+0x18]
   7e133:	66 48 0f 38 f6 e9                               	adcx   rbp,rcx
   7e139:	f3 4c 0f 38 f6 ce                               	adox   r9,rsi
   7e13f:	66 4d 0f 38 f6 cb                               	adcx   r9,r11
   7e145:	49 8b 50 18                                     	mov    rdx,QWORD PTR [r8+0x18]
   7e149:	45 31 db                                        	xor    r11d,r11d
   7e14c:	c4 c2 f3 f6 75 00                               	mulx   rsi,rcx,QWORD PTR [r13+0x0]
   7e152:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   7e158:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7e15e:	c4 c2 f3 f6 75 08                               	mulx   rsi,rcx,QWORD PTR [r13+0x8]
   7e164:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7e16a:	f3 48 0f 38 f6 ee                               	adox   rbp,rsi
   7e170:	c4 c2 f3 f6 75 10                               	mulx   rsi,rcx,QWORD PTR [r13+0x10]
   7e176:	66 48 0f 38 f6 e9                               	adcx   rbp,rcx
   7e17c:	f3 4c 0f 38 f6 ce                               	adox   r9,rsi
   7e182:	c4 c2 f3 f6 75 18                               	mulx   rsi,rcx,QWORD PTR [r13+0x18]
   7e188:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   7e18e:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7e194:	66 4d 0f 38 f6 f3                               	adcx   r14,r11
   7e19a:	48 89 c2                                        	mov    rdx,rax
   7e19d:	49 0f af d4                                     	imul   rdx,r12
   7e1a1:	45 31 db                                        	xor    r11d,r11d
   7e1a4:	c4 c2 f3 f6 32                                  	mulx   rsi,rcx,QWORD PTR [r10]
   7e1a9:	66 48 0f 38 f6 c1                               	adcx   rax,rcx
   7e1af:	f3 48 0f 38 f6 de                               	adox   rbx,rsi
   7e1b5:	c4 c2 f3 f6 72 08                               	mulx   rsi,rcx,QWORD PTR [r10+0x8]
   7e1bb:	66 48 0f 38 f6 d9                               	adcx   rbx,rcx
   7e1c1:	f3 48 0f 38 f6 ee                               	adox   rbp,rsi
   7e1c7:	c4 c2 f3 f6 72 10                               	mulx   rsi,rcx,QWORD PTR [r10+0x10]
   7e1cd:	66 48 0f 38 f6 e9                               	adcx   rbp,rcx
   7e1d3:	f3 4c 0f 38 f6 ce                               	adox   r9,rsi
   7e1d9:	c4 c2 f3 f6 72 18                               	mulx   rsi,rcx,QWORD PTR [r10+0x18]
   7e1df:	66 4c 0f 38 f6 c9                               	adcx   r9,rcx
   7e1e5:	f3 4c 0f 38 f6 f6                               	adox   r14,rsi
   7e1eb:	66 4d 0f 38 f6 f3                               	adcx   r14,r11
   7e1f1:	48 b8 47 fd 7c d8 16 8c 20 3c                   	movabs rax,0x3c208c16d87cfd47
   7e1fb:	48 b9 8d ca 71 68 91 6a 81 97                   	movabs rcx,0x97816a916871ca8d
   7e205:	48 be 29 a0 31 e1 72 4e 64 30                   	movabs rsi,0x30644e72e131a029
   7e20f:	c5 fe 7f 94 24 50 05 00 00                      	vmovdqu YMMWORD PTR [rsp+0x550],ymm2
   7e218:	48 39 c3                                        	cmp    rbx,rax
   7e21b:	48 b8 73 35 8e 97 6e 95 7e 68                   	movabs rax,0x687e956e978e3573
   7e225:	4c 8b 44 24 20                                  	mov    r8,QWORD PTR [rsp+0x20]
   7e22a:	48 8d 54 05 00                                  	lea    rdx,[rbp+rax*1+0x0]
   7e22f:	48 83 da 00                                     	sbb    rdx,0x0
   7e233:	0f 92 c0                                        	setb   al
   7e236:	48 39 cd                                        	cmp    rbp,rcx
   7e239:	0f 92 c1                                        	setb   cl
   7e23c:	08 c1                                           	or     cl,al
   7e23e:	4c 89 84 24 b0 00 00 00                         	mov    QWORD PTR [rsp+0xb0],r8
   7e246:	4c 8b 44 24 28                                  	mov    r8,QWORD PTR [rsp+0x28]
   7e24b:	0f b6 c1                                        	movzx  eax,cl
   7e24e:	48 b9 a3 a7 7e 7e 49 ba af 47                   	movabs rcx,0x47afba497e7ea7a3
   7e258:	4d 8d 3c 09                                     	lea    r15,[r9+rcx*1]
   7e25c:	48 b9 5d 58 81 81 b6 45 50 b8                   	movabs rcx,0xb85045b68181585d
   7e266:	49 29 c7                                        	sub    r15,rax
   7e269:	0f 92 c0                                        	setb   al
   7e26c:	49 39 c9                                        	cmp    r9,rcx
   7e26f:	0f 92 c1                                        	setb   cl
   7e272:	08 c1                                           	or     cl,al
   7e274:	0f b6 c1                                        	movzx  eax,cl
   7e277:	48 b9 d7 5f ce 1e 8d b1 9b cf                   	movabs rcx,0xcf9bb18d1ece5fd7
   7e281:	4c 01 f1                                        	add    rcx,r14
   7e284:	48 29 c1                                        	sub    rcx,rax
   7e287:	0f 92 c0                                        	setb   al
   7e28a:	49 39 f6                                        	cmp    r14,rsi
   7e28d:	40 0f 92 c6                                     	setb   sil
   7e291:	40 08 c6                                        	or     sil,al
   7e294:	48 b8 b9 02 83 27 e9 73 df c3                   	movabs rax,0xc3df73e9278302b9
   7e29e:	48 8d 04 03                                     	lea    rax,[rbx+rax*1]
   7e2a2:	48 0f 45 d5                                     	cmovne rdx,rbp
   7e2a6:	4d 0f 45 f9                                     	cmovne r15,r9
   7e2aa:	49 0f 45 ce                                     	cmovne rcx,r14
   7e2ae:	48 0f 45 c3                                     	cmovne rax,rbx
   7e2b2:	48 8d 9c 24 b0 00 00 00                         	lea    rbx,[rsp+0xb0]
   7e2ba:	48 89 44 24 60                                  	mov    QWORD PTR [rsp+0x60],rax
   7e2bf:	48 89 54 24 68                                  	mov    QWORD PTR [rsp+0x68],rdx
   7e2c4:	4c 89 7c 24 70                                  	mov    QWORD PTR [rsp+0x70],r15
   7e2c9:	48 89 4c 24 78                                  	mov    QWORD PTR [rsp+0x78],rcx
   7e2ce:	48 8b 8c 24 90 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x90]
   7e2d6:	48 89 8c 24 b8 00 00 00                         	mov    QWORD PTR [rsp+0xb8],rcx
   7e2de:	48 8b 8c 24 88 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x88]
   7e2e6:	4c 89 84 24 c0 00 00 00                         	mov    QWORD PTR [rsp+0xc0],r8
   7e2ee:	48 89 8c 24 c8 00 00 00                         	mov    QWORD PTR [rsp+0xc8],rcx
   7e2f6:	45 31 c0                                        	xor    r8d,r8d
   7e2f9:	45 31 c9                                        	xor    r9d,r9d
   7e2fc:	45 31 db                                        	xor    r11d,r11d
   7e2ff:	31 c0                                           	xor    eax,eax
   7e301:	31 c9                                           	xor    ecx,ecx
   7e303:	48 8b 13                                        	mov    rdx,QWORD PTR [rbx]
   7e306:	45 31 f6                                        	xor    r14d,r14d
   7e309:	c4 c2 cb f6 6d 00                               	mulx   rbp,rsi,QWORD PTR [r13+0x0]
   7e30f:	66 4c 0f 38 f6 c6                               	adcx   r8,rsi
   7e315:	f3 4c 0f 38 f6 cd                               	adox   r9,rbp
   7e31b:	c4 c2 cb f6 6d 08                               	mulx   rbp,rsi,QWORD PTR [r13+0x8]
   7e321:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   7e327:	f3 4c 0f 38 f6 dd                               	adox   r11,rbp
   7e32d:	c4 c2 cb f6 6d 10                               	mulx   rbp,rsi,QWORD PTR [r13+0x10]
   7e333:	66 4c 0f 38 f6 de                               	adcx   r11,rsi
   7e339:	f3 48 0f 38 f6 c5                               	adox   rax,rbp
   7e33f:	c4 c2 cb f6 6d 18                               	mulx   rbp,rsi,QWORD PTR [r13+0x18]
   7e345:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   7e34b:	f3 48 0f 38 f6 cd                               	adox   rcx,rbp
   7e351:	66 49 0f 38 f6 ce                               	adcx   rcx,r14
   7e357:	4c 89 c2                                        	mov    rdx,r8
   7e35a:	49 0f af d4                                     	imul   rdx,r12
   7e35e:	45 31 f6                                        	xor    r14d,r14d
   7e361:	c4 c2 cb f6 2a                                  	mulx   rbp,rsi,QWORD PTR [r10]
   7e366:	66 4c 0f 38 f6 c6                               	adcx   r8,rsi
   7e36c:	f3 4c 0f 38 f6 cd                               	adox   r9,rbp
   7e372:	c4 c2 cb f6 6a 08                               	mulx   rbp,rsi,QWORD PTR [r10+0x8]
   7e378:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   7e37e:	f3 4c 0f 38 f6 dd                               	adox   r11,rbp
   7e384:	c4 c2 cb f6 6a 10                               	mulx   rbp,rsi,QWORD PTR [r10+0x10]
   7e38a:	66 4c 0f 38 f6 de                               	adcx   r11,rsi
   7e390:	f3 48 0f 38 f6 c5                               	adox   rax,rbp
   7e396:	c4 c2 cb f6 6a 18                               	mulx   rbp,rsi,QWORD PTR [r10+0x18]
   7e39c:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   7e3a2:	f3 48 0f 38 f6 cd                               	adox   rcx,rbp
   7e3a8:	66 49 0f 38 f6 ce                               	adcx   rcx,r14
   7e3ae:	48 8b 53 08                                     	mov    rdx,QWORD PTR [rbx+0x8]
   7e3b2:	45 31 f6                                        	xor    r14d,r14d
   7e3b5:	c4 c2 cb f6 6d 00                               	mulx   rbp,rsi,QWORD PTR [r13+0x0]
   7e3bb:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   7e3c1:	f3 4c 0f 38 f6 dd                               	adox   r11,rbp
   7e3c7:	c4 c2 cb f6 6d 08                               	mulx   rbp,rsi,QWORD PTR [r13+0x8]
   7e3cd:	66 4c 0f 38 f6 de                               	adcx   r11,rsi
   7e3d3:	f3 48 0f 38 f6 c5                               	adox   rax,rbp
   7e3d9:	c4 c2 cb f6 6d 10                               	mulx   rbp,rsi,QWORD PTR [r13+0x10]
   7e3df:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   7e3e5:	f3 48 0f 38 f6 cd                               	adox   rcx,rbp
   7e3eb:	c4 c2 cb f6 6d 18                               	mulx   rbp,rsi,QWORD PTR [r13+0x18]
   7e3f1:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   7e3f7:	f3 4c 0f 38 f6 c5                               	adox   r8,rbp
   7e3fd:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   7e403:	4c 89 ca                                        	mov    rdx,r9
   7e406:	49 0f af d4                                     	imul   rdx,r12
   7e40a:	45 31 f6                                        	xor    r14d,r14d
   7e40d:	c4 c2 cb f6 2a                                  	mulx   rbp,rsi,QWORD PTR [r10]
   7e412:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   7e418:	f3 4c 0f 38 f6 dd                               	adox   r11,rbp
   7e41e:	c4 c2 cb f6 6a 08                               	mulx   rbp,rsi,QWORD PTR [r10+0x8]
   7e424:	66 4c 0f 38 f6 de                               	adcx   r11,rsi
   7e42a:	f3 48 0f 38 f6 c5                               	adox   rax,rbp
   7e430:	c4 c2 cb f6 6a 10                               	mulx   rbp,rsi,QWORD PTR [r10+0x10]
   7e436:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   7e43c:	f3 48 0f 38 f6 cd                               	adox   rcx,rbp
   7e442:	c4 c2 cb f6 6a 18                               	mulx   rbp,rsi,QWORD PTR [r10+0x18]
   7e448:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   7e44e:	f3 4c 0f 38 f6 c5                               	adox   r8,rbp
   7e454:	66 4d 0f 38 f6 c6                               	adcx   r8,r14
   7e45a:	48 8b 53 10                                     	mov    rdx,QWORD PTR [rbx+0x10]
   7e45e:	45 31 f6                                        	xor    r14d,r14d
   7e461:	c4 c2 cb f6 6d 00                               	mulx   rbp,rsi,QWORD PTR [r13+0x0]
   7e467:	66 4c 0f 38 f6 de                               	adcx   r11,rsi
   7e46d:	f3 48 0f 38 f6 c5                               	adox   rax,rbp
   7e473:	c4 c2 cb f6 6d 08                               	mulx   rbp,rsi,QWORD PTR [r13+0x8]
   7e479:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   7e47f:	f3 48 0f 38 f6 cd                               	adox   rcx,rbp
   7e485:	c4 c2 cb f6 6d 10                               	mulx   rbp,rsi,QWORD PTR [r13+0x10]
   7e48b:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   7e491:	f3 4c 0f 38 f6 c5                               	adox   r8,rbp
   7e497:	c4 c2 cb f6 6d 18                               	mulx   rbp,rsi,QWORD PTR [r13+0x18]
   7e49d:	66 4c 0f 38 f6 c6                               	adcx   r8,rsi
   7e4a3:	f3 4c 0f 38 f6 cd                               	adox   r9,rbp
   7e4a9:	66 4d 0f 38 f6 ce                               	adcx   r9,r14
   7e4af:	4c 89 da                                        	mov    rdx,r11
   7e4b2:	49 0f af d4                                     	imul   rdx,r12
   7e4b6:	45 31 f6                                        	xor    r14d,r14d
   7e4b9:	c4 c2 cb f6 2a                                  	mulx   rbp,rsi,QWORD PTR [r10]
   7e4be:	66 4c 0f 38 f6 de                               	adcx   r11,rsi
   7e4c4:	f3 48 0f 38 f6 c5                               	adox   rax,rbp
   7e4ca:	c4 c2 cb f6 6a 08                               	mulx   rbp,rsi,QWORD PTR [r10+0x8]
   7e4d0:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   7e4d6:	f3 48 0f 38 f6 cd                               	adox   rcx,rbp
   7e4dc:	c4 c2 cb f6 6a 10                               	mulx   rbp,rsi,QWORD PTR [r10+0x10]
   7e4e2:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   7e4e8:	f3 4c 0f 38 f6 c5                               	adox   r8,rbp
   7e4ee:	c4 c2 cb f6 6a 18                               	mulx   rbp,rsi,QWORD PTR [r10+0x18]
   7e4f4:	66 4c 0f 38 f6 c6                               	adcx   r8,rsi
   7e4fa:	f3 4c 0f 38 f6 cd                               	adox   r9,rbp
   7e500:	66 4d 0f 38 f6 ce                               	adcx   r9,r14
   7e506:	48 8b 53 18                                     	mov    rdx,QWORD PTR [rbx+0x18]
   7e50a:	45 31 f6                                        	xor    r14d,r14d
   7e50d:	c4 c2 cb f6 6d 00                               	mulx   rbp,rsi,QWORD PTR [r13+0x0]
   7e513:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   7e519:	f3 48 0f 38 f6 cd                               	adox   rcx,rbp
   7e51f:	c4 c2 cb f6 6d 08                               	mulx   rbp,rsi,QWORD PTR [r13+0x8]
   7e525:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   7e52b:	f3 4c 0f 38 f6 c5                               	adox   r8,rbp
   7e531:	c4 c2 cb f6 6d 10                               	mulx   rbp,rsi,QWORD PTR [r13+0x10]
   7e537:	66 4c 0f 38 f6 c6                               	adcx   r8,rsi
   7e53d:	f3 4c 0f 38 f6 cd                               	adox   r9,rbp
   7e543:	c4 c2 cb f6 6d 18                               	mulx   rbp,rsi,QWORD PTR [r13+0x18]
   7e549:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   7e54f:	f3 4c 0f 38 f6 dd                               	adox   r11,rbp
   7e555:	66 4d 0f 38 f6 de                               	adcx   r11,r14
   7e55b:	48 89 c2                                        	mov    rdx,rax
   7e55e:	49 0f af d4                                     	imul   rdx,r12
   7e562:	45 31 f6                                        	xor    r14d,r14d
   7e565:	c4 c2 cb f6 2a                                  	mulx   rbp,rsi,QWORD PTR [r10]
   7e56a:	66 48 0f 38 f6 c6                               	adcx   rax,rsi
   7e570:	f3 48 0f 38 f6 cd                               	adox   rcx,rbp
   7e576:	c4 c2 cb f6 6a 08                               	mulx   rbp,rsi,QWORD PTR [r10+0x8]
   7e57c:	66 48 0f 38 f6 ce                               	adcx   rcx,rsi
   7e582:	f3 4c 0f 38 f6 c5                               	adox   r8,rbp
   7e588:	c4 c2 cb f6 6a 10                               	mulx   rbp,rsi,QWORD PTR [r10+0x10]
   7e58e:	66 4c 0f 38 f6 c6                               	adcx   r8,rsi
   7e594:	f3 4c 0f 38 f6 cd                               	adox   r9,rbp
   7e59a:	c4 c2 cb f6 6a 18                               	mulx   rbp,rsi,QWORD PTR [r10+0x18]
   7e5a0:	66 4c 0f 38 f6 ce                               	adcx   r9,rsi
   7e5a6:	f3 4c 0f 38 f6 dd                               	adox   r11,rbp
   7e5ac:	66 4d 0f 38 f6 de                               	adcx   r11,r14
   7e5b2:	4c 89 4c 24 50                                  	mov    QWORD PTR [rsp+0x50],r9
   7e5b7:	4c 89 84 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],r8
   7e5bf:	48 89 4c 24 20                                  	mov    QWORD PTR [rsp+0x20],rcx
   7e5c4:	48 3b 7c 24 40                                  	cmp    rdi,QWORD PTR [rsp+0x40]
   7e5c9:	0f 83 aa 07 00 00                               	jae    7ed79 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x40c9>
   7e5cf:	4c 8b 94 24 00 01 00 00                         	mov    r10,QWORD PTR [rsp+0x100]
   7e5d7:	4c 8b 84 24 10 01 00 00                         	mov    r8,QWORD PTR [rsp+0x110]
   7e5df:	4c 8b 8c 24 08 01 00 00                         	mov    r9,QWORD PTR [rsp+0x108]
   7e5e7:	48 8b 8c 24 18 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x118]
   7e5ef:	48 b8 29 a0 31 e1 72 4e 64 30                   	movabs rax,0x30644e72e131a029
   7e5f9:	48 ba 5d 58 81 81 b6 45 50 b8                   	movabs rdx,0xb85045b68181585d
   7e603:	49 bf a3 a7 7e 7e 49 ba af 47                   	movabs r15,0x47afba497e7ea7a3
   7e60d:	48 8b 9c 24 58 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x158]
   7e615:	49 39 c2                                        	cmp    r10,rax
   7e618:	0f 92 c0                                        	setb   al
   7e61b:	49 39 d0                                        	cmp    r8,rdx
   7e61e:	48 ba 8d ca 71 68 91 6a 81 97                   	movabs rdx,0x97816a916871ca8d
   7e628:	40 0f 92 c6                                     	setb   sil
   7e62c:	49 39 d1                                        	cmp    r9,rdx
   7e62f:	48 ba 47 fd 7c d8 16 8c 20 3c                   	movabs rdx,0x3c208c16d87cfd47
   7e639:	40 0f 92 c5                                     	setb   bpl
   7e63d:	48 39 d1                                        	cmp    rcx,rdx
   7e640:	48 ba 73 35 8e 97 6e 95 7e 68                   	movabs rdx,0x687e956e978e3573
   7e64a:	49 8d 14 11                                     	lea    rdx,[r9+rdx*1]
   7e64e:	48 83 da 00                                     	sbb    rdx,0x0
   7e652:	41 0f 92 c6                                     	setb   r14b
   7e656:	41 08 ee                                        	or     r14b,bpl
   7e659:	4b 8d 2c 38                                     	lea    rbp,[r8+r15*1]
   7e65d:	45 0f b6 f6                                     	movzx  r14d,r14b
   7e661:	4c 29 f5                                        	sub    rbp,r14
   7e664:	41 0f 92 c6                                     	setb   r14b
   7e668:	41 08 f6                                        	or     r14b,sil
   7e66b:	41 0f b6 f6                                     	movzx  esi,r14b
   7e66f:	49 be d7 5f ce 1e 8d b1 9b cf                   	movabs r14,0xcf9bb18d1ece5fd7
   7e679:	4d 01 d6                                        	add    r14,r10
   7e67c:	49 29 f6                                        	sub    r14,rsi
   7e67f:	40 0f 92 c6                                     	setb   sil
   7e683:	40 08 c6                                        	or     sil,al
   7e686:	48 b8 b9 02 83 27 e9 73 df c3                   	movabs rax,0xc3df73e9278302b9
   7e690:	40 84 f6                                        	test   sil,sil
   7e693:	4c 8d 24 01                                     	lea    r12,[rcx+rax*1]
   7e697:	48 b8 29 a0 31 e1 72 4e 64 30                   	movabs rax,0x30644e72e131a029
   7e6a1:	49 0f 45 e8                                     	cmovne rbp,r8
   7e6a5:	49 0f 45 d1                                     	cmovne rdx,r9
   7e6a9:	4c 0f 45 e1                                     	cmovne r12,rcx
   7e6ad:	4d 0f 45 f2                                     	cmovne r14,r10
   7e6b1:	48 39 c3                                        	cmp    rbx,rax
   7e6b4:	48 8b 84 24 60 01 00 00                         	mov    rax,QWORD PTR [rsp+0x160]
   7e6bc:	4c 8b 8c 24 68 01 00 00                         	mov    r9,QWORD PTR [rsp+0x168]
   7e6c4:	48 b9 5d 58 81 81 b6 45 50 b8                   	movabs rcx,0xb85045b68181585d
   7e6ce:	49 b8 47 fd 7c d8 16 8c 20 3c                   	movabs r8,0x3c208c16d87cfd47
   7e6d8:	41 0f 92 c5                                     	setb   r13b
   7e6dc:	48 39 c8                                        	cmp    rax,rcx
   7e6df:	48 b9 8d ca 71 68 91 6a 81 97                   	movabs rcx,0x97816a916871ca8d
   7e6e9:	40 0f 92 c6                                     	setb   sil
   7e6ed:	49 39 c9                                        	cmp    r9,rcx
   7e6f0:	48 8b 8c 24 20 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x120]
   7e6f8:	41 0f 92 c2                                     	setb   r10b
   7e6fc:	4c 39 c1                                        	cmp    rcx,r8
   7e6ff:	49 b8 73 35 8e 97 6e 95 7e 68                   	movabs r8,0x687e956e978e3573
   7e709:	4f 8d 04 01                                     	lea    r8,[r9+r8*1]
   7e70d:	49 83 d8 00                                     	sbb    r8,0x0
   7e711:	41 0f 92 c7                                     	setb   r15b
   7e715:	45 08 d7                                        	or     r15b,r10b
   7e718:	45 0f b6 d7                                     	movzx  r10d,r15b
   7e71c:	49 bf a3 a7 7e 7e 49 ba af 47                   	movabs r15,0x47afba497e7ea7a3
   7e726:	49 01 c7                                        	add    r15,rax
   7e729:	4d 29 d7                                        	sub    r15,r10
   7e72c:	41 0f 92 c2                                     	setb   r10b
   7e730:	41 08 f2                                        	or     r10b,sil
   7e733:	41 0f b6 f2                                     	movzx  esi,r10b
   7e737:	49 ba d7 5f ce 1e 8d b1 9b cf                   	movabs r10,0xcf9bb18d1ece5fd7
   7e741:	49 01 da                                        	add    r10,rbx
   7e744:	49 29 f2                                        	sub    r10,rsi
   7e747:	40 0f 92 c6                                     	setb   sil
   7e74b:	44 08 ee                                        	or     sil,r13b
   7e74e:	40 84 f6                                        	test   sil,sil
   7e751:	4c 0f 45 f8                                     	cmovne r15,rax
   7e755:	48 b8 b9 02 83 27 e9 73 df c3                   	movabs rax,0xc3df73e9278302b9
   7e75f:	4c 0f 45 d3                                     	cmovne r10,rbx
   7e763:	48 8b 5c 24 50                                  	mov    rbx,QWORD PTR [rsp+0x50]
   7e768:	4d 0f 45 c1                                     	cmovne r8,r9
   7e76c:	4c 8b 8c 24 88 00 00 00                         	mov    r9,QWORD PTR [rsp+0x88]
   7e774:	48 8d 04 01                                     	lea    rax,[rcx+rax*1]
   7e778:	4c 89 54 24 18                                  	mov    QWORD PTR [rsp+0x18],r10
   7e77d:	4c 89 7c 24 08                                  	mov    QWORD PTR [rsp+0x8],r15
   7e782:	4c 89 84 24 90 00 00 00                         	mov    QWORD PTR [rsp+0x90],r8
   7e78a:	48 0f 45 c1                                     	cmovne rax,rcx
   7e78e:	48 b9 29 a0 31 e1 72 4e 64 30                   	movabs rcx,0x30644e72e131a029
   7e798:	49 39 cb                                        	cmp    r11,rcx
   7e79b:	48 8b 4c 24 20                                  	mov    rcx,QWORD PTR [rsp+0x20]
   7e7a0:	48 89 44 24 28                                  	mov    QWORD PTR [rsp+0x28],rax
   7e7a5:	48 b8 5d 58 81 81 b6 45 50 b8                   	movabs rax,0xb85045b68181585d
   7e7af:	41 0f 92 c2                                     	setb   r10b
   7e7b3:	48 39 c3                                        	cmp    rbx,rax
   7e7b6:	48 b8 8d ca 71 68 91 6a 81 97                   	movabs rax,0x97816a916871ca8d
   7e7c0:	41 0f 92 c7                                     	setb   r15b
   7e7c4:	49 39 c1                                        	cmp    r9,rax
   7e7c7:	48 b8 47 fd 7c d8 16 8c 20 3c                   	movabs rax,0x3c208c16d87cfd47
   7e7d1:	40 0f 92 c6                                     	setb   sil
   7e7d5:	48 39 c1                                        	cmp    rcx,rax
   7e7d8:	48 b8 73 35 8e 97 6e 95 7e 68                   	movabs rax,0x687e956e978e3573
   7e7e2:	49 8d 04 01                                     	lea    rax,[r9+rax*1]
   7e7e6:	48 83 d8 00                                     	sbb    rax,0x0
   7e7ea:	41 0f 92 c0                                     	setb   r8b
   7e7ee:	41 08 f0                                        	or     r8b,sil
   7e7f1:	48 be a3 a7 7e 7e 49 ba af 47                   	movabs rsi,0x47afba497e7ea7a3
   7e7fb:	45 0f b6 c0                                     	movzx  r8d,r8b
   7e7ff:	48 01 de                                        	add    rsi,rbx
   7e802:	4c 29 c6                                        	sub    rsi,r8
   7e805:	41 0f 92 c0                                     	setb   r8b
   7e809:	45 08 f8                                        	or     r8b,r15b
   7e80c:	49 bf d7 5f ce 1e 8d b1 9b cf                   	movabs r15,0xcf9bb18d1ece5fd7
   7e816:	45 0f b6 c0                                     	movzx  r8d,r8b
   7e81a:	4d 01 df                                        	add    r15,r11
   7e81d:	4d 29 c7                                        	sub    r15,r8
   7e820:	41 0f 92 c0                                     	setb   r8b
   7e824:	45 08 d0                                        	or     r8b,r10b
   7e827:	45 84 c0                                        	test   r8b,r8b
   7e82a:	49 b8 b9 02 83 27 e9 73 df c3                   	movabs r8,0xc3df73e9278302b9
   7e834:	48 0f 45 f3                                     	cmovne rsi,rbx
   7e838:	48 8b 9c 24 f8 00 00 00                         	mov    rbx,QWORD PTR [rsp+0xf8]
   7e840:	4e 8d 04 01                                     	lea    r8,[rcx+r8*1]
   7e844:	4d 0f 45 fb                                     	cmovne r15,r11
   7e848:	49 0f 45 c1                                     	cmovne rax,r9
   7e84c:	4c 0f 45 c1                                     	cmovne r8,rcx
   7e850:	48 c1 e7 06                                     	shl    rdi,0x6
   7e854:	48 b9 ab aa aa aa aa aa aa aa                   	movabs rcx,0xaaaaaaaaaaaaaaab
   7e85e:	4c 89 24 3b                                     	mov    QWORD PTR [rbx+rdi*1],r12
   7e862:	48 89 54 3b 08                                  	mov    QWORD PTR [rbx+rdi*1+0x8],rdx
   7e867:	48 89 6c 3b 10                                  	mov    QWORD PTR [rbx+rdi*1+0x10],rbp
   7e86c:	4c 89 74 3b 18                                  	mov    QWORD PTR [rbx+rdi*1+0x18],r14
   7e871:	4c 89 44 3b 20                                  	mov    QWORD PTR [rbx+rdi*1+0x20],r8
   7e876:	48 89 44 3b 28                                  	mov    QWORD PTR [rbx+rdi*1+0x28],rax
   7e87b:	48 89 74 3b 30                                  	mov    QWORD PTR [rbx+rdi*1+0x30],rsi
   7e880:	4c 89 7c 3b 38                                  	mov    QWORD PTR [rbx+rdi*1+0x38],r15
   7e885:	4c 8b 7c 24 10                                  	mov    r15,QWORD PTR [rsp+0x10]
   7e88a:	4c 8b b4 24 80 00 00 00                         	mov    r14,QWORD PTR [rsp+0x80]
   7e892:	4c 8b a4 24 70 01 00 00                         	mov    r12,QWORD PTR [rsp+0x170]
   7e89a:	e9 21 e7 ff ff                                  	jmp    7cfc0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x2310>
   7e89f:	48 8b 84 24 98 00 00 00                         	mov    rax,QWORD PTR [rsp+0x98]
   7e8a7:	48 85 c0                                        	test   rax,rax
   7e8aa:	74 48                                           	je     7e8f4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3c44>
   7e8ac:	48 8b bc 24 a0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xa0]
   7e8b4:	48 3d ff 0f 00 00                               	cmp    rax,0xfff
   7e8ba:	76 2f                                           	jbe    7e8eb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3c3b>
   7e8bc:	48 c1 e0 05                                     	shl    rax,0x5
   7e8c0:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7e8ca:	48 89 c6                                        	mov    rsi,rax
   7e8cd:	48 83 ce 01                                     	or     rsi,0x1
   7e8d1:	48 39 ce                                        	cmp    rsi,rcx
   7e8d4:	0f 83 4a cd ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7e8da:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7e8de:	75 0b                                           	jne    7e8eb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3c3b>
   7e8e0:	c5 f8 77                                        	vzeroupper
   7e8e3:	ff 15 97 be 01 00                               	call   QWORD PTR [rip+0x1be97]        # 9a780 <munmap@GLIBC_2.2.5>
   7e8e9:	eb 09                                           	jmp    7e8f4 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3c44>
   7e8eb:	c5 f8 77                                        	vzeroupper
   7e8ee:	ff 15 94 be 01 00                               	call   QWORD PTR [rip+0x1be94]        # 9a788 <free@GLIBC_2.2.5>
   7e8f4:	48 8b ac 24 d0 01 00 00                         	mov    rbp,QWORD PTR [rsp+0x1d0]
   7e8fc:	48 83 7c 24 40 00                               	cmp    QWORD PTR [rsp+0x40],0x0
   7e902:	74 5e                                           	je     7e962 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3cb2>
   7e904:	48 8b 84 24 d8 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1d8]
   7e90c:	48 8b 8c 24 88 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x188]
   7e914:	48 8b b4 24 90 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x190]
   7e91c:	31 d2                                           	xor    edx,edx
   7e91e:	48 c1 e0 03                                     	shl    rax,0x3
   7e922:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7e930:	48 39 d0                                        	cmp    rax,rdx
   7e933:	74 2d                                           	je     7e962 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3cb2>
   7e935:	48 8b 7c 15 00                                  	mov    rdi,QWORD PTR [rbp+rdx*1+0x0]
   7e93a:	48 39 f7                                        	cmp    rdi,rsi
   7e93d:	0f 83 b8 03 00 00                               	jae    7ecfb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x404b>
   7e943:	4c 8d 04 d3                                     	lea    r8,[rbx+rdx*8]
   7e947:	48 c1 e7 06                                     	shl    rdi,0x6
   7e94b:	48 83 c2 08                                     	add    rdx,0x8
   7e94f:	49 83 c4 c0                                     	add    r12,0xffffffffffffffc0
   7e953:	62 d1 fe 48 6f 00                               	vmovdqu64 zmm0,ZMMWORD PTR [r8]
   7e959:	62 f1 fe 48 7f 04 39                            	vmovdqu64 ZMMWORD PTR [rcx+rdi*1],zmm0
   7e960:	75 ce                                           	jne    7e930 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3c80>
   7e962:	48 8b 74 24 38                                  	mov    rsi,QWORD PTR [rsp+0x38]
   7e967:	48 85 f6                                        	test   rsi,rsi
   7e96a:	74 31                                           	je     7e99d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ced>
   7e96c:	48 81 fe ff 07 00 00                            	cmp    rsi,0x7ff
   7e973:	76 1c                                           	jbe    7e991 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ce1>
   7e975:	48 c1 e6 06                                     	shl    rsi,0x6
   7e979:	80 3c 33 01                                     	cmp    BYTE PTR [rbx+rsi*1],0x1
   7e97d:	75 12                                           	jne    7e991 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ce1>
   7e97f:	48 83 ce 01                                     	or     rsi,0x1
   7e983:	48 89 df                                        	mov    rdi,rbx
   7e986:	c5 f8 77                                        	vzeroupper
   7e989:	ff 15 f1 bd 01 00                               	call   QWORD PTR [rip+0x1bdf1]        # 9a780 <munmap@GLIBC_2.2.5>
   7e98f:	eb 0c                                           	jmp    7e99d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ced>
   7e991:	48 89 df                                        	mov    rdi,rbx
   7e994:	c5 f8 77                                        	vzeroupper
   7e997:	ff 15 eb bd 01 00                               	call   QWORD PTR [rip+0x1bdeb]        # 9a788 <free@GLIBC_2.2.5>
   7e99d:	c5 fa 6f 84 24 80 01 00 00                      	vmovdqu xmm0,XMMWORD PTR [rsp+0x180]
   7e9a6:	48 8b 8c 24 78 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x178]
   7e9ae:	48 8b 84 24 90 01 00 00                         	mov    rax,QWORD PTR [rsp+0x190]
   7e9b6:	48 89 41 10                                     	mov    QWORD PTR [rcx+0x10],rax
   7e9ba:	c5 fa 7f 01                                     	vmovdqu XMMWORD PTR [rcx],xmm0
   7e9be:	4d 85 f6                                        	test   r14,r14
   7e9c1:	74 36                                           	je     7e9f9 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3d49>
   7e9c3:	49 81 fe 55 05 00 00                            	cmp    r14,0x555
   7e9ca:	76 21                                           	jbe    7e9ed <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3d3d>
   7e9cc:	49 c1 e6 05                                     	shl    r14,0x5
   7e9d0:	4b 8d 34 76                                     	lea    rsi,[r14+r14*2]
   7e9d4:	41 80 3c 37 01                                  	cmp    BYTE PTR [r15+rsi*1],0x1
   7e9d9:	75 12                                           	jne    7e9ed <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3d3d>
   7e9db:	48 83 ce 01                                     	or     rsi,0x1
   7e9df:	4c 89 ff                                        	mov    rdi,r15
   7e9e2:	c5 f8 77                                        	vzeroupper
   7e9e5:	ff 15 95 bd 01 00                               	call   QWORD PTR [rip+0x1bd95]        # 9a780 <munmap@GLIBC_2.2.5>
   7e9eb:	eb 0c                                           	jmp    7e9f9 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3d49>
   7e9ed:	4c 89 ff                                        	mov    rdi,r15
   7e9f0:	c5 f8 77                                        	vzeroupper
   7e9f3:	ff 15 8f bd 01 00                               	call   QWORD PTR [rip+0x1bd8f]        # 9a788 <free@GLIBC_2.2.5>
   7e9f9:	48 8b 84 24 98 01 00 00                         	mov    rax,QWORD PTR [rsp+0x198]
   7ea01:	48 85 c0                                        	test   rax,rax
   7ea04:	74 4c                                           	je     7ea52 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3da2>
   7ea06:	48 8b bc 24 a0 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x1a0]
   7ea0e:	48 3d 55 05 00 00                               	cmp    rax,0x555
   7ea14:	76 33                                           	jbe    7ea49 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3d99>
   7ea16:	48 c1 e0 05                                     	shl    rax,0x5
   7ea1a:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7ea24:	48 8d 04 40                                     	lea    rax,[rax+rax*2]
   7ea28:	48 89 c6                                        	mov    rsi,rax
   7ea2b:	48 83 ce 01                                     	or     rsi,0x1
   7ea2f:	48 39 ce                                        	cmp    rsi,rcx
   7ea32:	0f 83 ec cb ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7ea38:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7ea3c:	75 0b                                           	jne    7ea49 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3d99>
   7ea3e:	c5 f8 77                                        	vzeroupper
   7ea41:	ff 15 39 bd 01 00                               	call   QWORD PTR [rip+0x1bd39]        # 9a780 <munmap@GLIBC_2.2.5>
   7ea47:	eb 09                                           	jmp    7ea52 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3da2>
   7ea49:	c5 f8 77                                        	vzeroupper
   7ea4c:	ff 15 36 bd 01 00                               	call   QWORD PTR [rip+0x1bd36]        # 9a788 <free@GLIBC_2.2.5>
   7ea52:	48 8b 84 24 b0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1b0]
   7ea5a:	48 85 c0                                        	test   rax,rax
   7ea5d:	74 4c                                           	je     7eaab <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3dfb>
   7ea5f:	48 8b bc 24 b8 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x1b8]
   7ea67:	48 3d ff 7f 00 00                               	cmp    rax,0x7fff
   7ea6d:	76 33                                           	jbe    7eaa2 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3df2>
   7ea6f:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7ea79:	48 c1 e0 02                                     	shl    rax,0x2
   7ea7d:	48 89 c6                                        	mov    rsi,rax
   7ea80:	48 83 ce 01                                     	or     rsi,0x1
   7ea84:	48 83 c1 04                                     	add    rcx,0x4
   7ea88:	48 39 ce                                        	cmp    rsi,rcx
   7ea8b:	0f 83 93 cb ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7ea91:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7ea95:	75 0b                                           	jne    7eaa2 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3df2>
   7ea97:	c5 f8 77                                        	vzeroupper
   7ea9a:	ff 15 e0 bc 01 00                               	call   QWORD PTR [rip+0x1bce0]        # 9a780 <munmap@GLIBC_2.2.5>
   7eaa0:	eb 09                                           	jmp    7eaab <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3dfb>
   7eaa2:	c5 f8 77                                        	vzeroupper
   7eaa5:	ff 15 dd bc 01 00                               	call   QWORD PTR [rip+0x1bcdd]        # 9a788 <free@GLIBC_2.2.5>
   7eaab:	48 8b 84 24 c8 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1c8]
   7eab3:	48 85 c0                                        	test   rax,rax
   7eab6:	74 47                                           	je     7eaff <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3e4f>
   7eab8:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7eabe:	76 33                                           	jbe    7eaf3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3e43>
   7eac0:	48 c1 e0 03                                     	shl    rax,0x3
   7eac4:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7eace:	48 89 c6                                        	mov    rsi,rax
   7ead1:	48 83 ce 01                                     	or     rsi,0x1
   7ead5:	48 39 ce                                        	cmp    rsi,rcx
   7ead8:	0f 83 46 cb ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7eade:	80 7c 05 00 01                                  	cmp    BYTE PTR [rbp+rax*1+0x0],0x1
   7eae3:	75 0e                                           	jne    7eaf3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3e43>
   7eae5:	48 89 ef                                        	mov    rdi,rbp
   7eae8:	c5 f8 77                                        	vzeroupper
   7eaeb:	ff 15 8f bc 01 00                               	call   QWORD PTR [rip+0x1bc8f]        # 9a780 <munmap@GLIBC_2.2.5>
   7eaf1:	eb 0c                                           	jmp    7eaff <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3e4f>
   7eaf3:	48 89 ef                                        	mov    rdi,rbp
   7eaf6:	c5 f8 77                                        	vzeroupper
   7eaf9:	ff 15 89 bc 01 00                               	call   QWORD PTR [rip+0x1bc89]        # 9a788 <free@GLIBC_2.2.5>
   7eaff:	48 8b 84 24 e0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1e0]
   7eb07:	48 85 c0                                        	test   rax,rax
   7eb0a:	74 48                                           	je     7eb54 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ea4>
   7eb0c:	48 8b bc 24 e8 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x1e8]
   7eb14:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7eb1a:	76 2f                                           	jbe    7eb4b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3e9b>
   7eb1c:	48 c1 e0 03                                     	shl    rax,0x3
   7eb20:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7eb2a:	48 89 c6                                        	mov    rsi,rax
   7eb2d:	48 83 ce 01                                     	or     rsi,0x1
   7eb31:	48 39 ce                                        	cmp    rsi,rcx
   7eb34:	0f 83 ea ca ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7eb3a:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7eb3e:	75 0b                                           	jne    7eb4b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3e9b>
   7eb40:	c5 f8 77                                        	vzeroupper
   7eb43:	ff 15 37 bc 01 00                               	call   QWORD PTR [rip+0x1bc37]        # 9a780 <munmap@GLIBC_2.2.5>
   7eb49:	eb 09                                           	jmp    7eb54 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ea4>
   7eb4b:	c5 f8 77                                        	vzeroupper
   7eb4e:	ff 15 34 bc 01 00                               	call   QWORD PTR [rip+0x1bc34]        # 9a788 <free@GLIBC_2.2.5>
   7eb54:	48 8b 84 24 f8 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1f8]
   7eb5c:	48 85 c0                                        	test   rax,rax
   7eb5f:	74 48                                           	je     7eba9 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ef9>
   7eb61:	48 8b bc 24 00 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x200]
   7eb69:	48 3d ff 1f 00 00                               	cmp    rax,0x1fff
   7eb6f:	76 2f                                           	jbe    7eba0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ef0>
   7eb71:	48 c1 e0 04                                     	shl    rax,0x4
   7eb75:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7eb7f:	48 89 c6                                        	mov    rsi,rax
   7eb82:	48 83 ce 01                                     	or     rsi,0x1
   7eb86:	48 39 ce                                        	cmp    rsi,rcx
   7eb89:	0f 83 95 ca ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7eb8f:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7eb93:	75 0b                                           	jne    7eba0 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ef0>
   7eb95:	c5 f8 77                                        	vzeroupper
   7eb98:	ff 15 e2 bb 01 00                               	call   QWORD PTR [rip+0x1bbe2]        # 9a780 <munmap@GLIBC_2.2.5>
   7eb9e:	eb 09                                           	jmp    7eba9 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3ef9>
   7eba0:	c5 f8 77                                        	vzeroupper
   7eba3:	ff 15 df bb 01 00                               	call   QWORD PTR [rip+0x1bbdf]        # 9a788 <free@GLIBC_2.2.5>
   7eba9:	48 8b 84 24 10 02 00 00                         	mov    rax,QWORD PTR [rsp+0x210]
   7ebb1:	48 85 c0                                        	test   rax,rax
   7ebb4:	74 48                                           	je     7ebfe <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3f4e>
   7ebb6:	48 8b bc 24 18 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x218]
   7ebbe:	48 3d ff 1f 00 00                               	cmp    rax,0x1fff
   7ebc4:	76 2f                                           	jbe    7ebf5 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3f45>
   7ebc6:	48 c1 e0 04                                     	shl    rax,0x4
   7ebca:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7ebd4:	48 89 c6                                        	mov    rsi,rax
   7ebd7:	48 83 ce 01                                     	or     rsi,0x1
   7ebdb:	48 39 ce                                        	cmp    rsi,rcx
   7ebde:	0f 83 40 ca ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7ebe4:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7ebe8:	75 0b                                           	jne    7ebf5 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3f45>
   7ebea:	c5 f8 77                                        	vzeroupper
   7ebed:	ff 15 8d bb 01 00                               	call   QWORD PTR [rip+0x1bb8d]        # 9a780 <munmap@GLIBC_2.2.5>
   7ebf3:	eb 09                                           	jmp    7ebfe <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x3f4e>
   7ebf5:	c5 f8 77                                        	vzeroupper
   7ebf8:	ff 15 8a bb 01 00                               	call   QWORD PTR [rip+0x1bb8a]        # 9a788 <free@GLIBC_2.2.5>
   7ebfe:	48 8d bc 24 28 02 00 00                         	lea    rdi,[rsp+0x228]
   7ec06:	c5 f8 77                                        	vzeroupper
   7ec09:	e8 12 2c 01 00                                  	call   91820 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCsHW5vo2gROj_10zopro_core3msm8BatchAddNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEEBG_>
   7ec0e:	48 81 c4 98 0b 00 00                            	add    rsp,0xb98
   7ec15:	5b                                              	pop    rbx
   7ec16:	41 5c                                           	pop    r12
   7ec18:	41 5d                                           	pop    r13
   7ec1a:	41 5e                                           	pop    r14
   7ec1c:	41 5f                                           	pop    r15
   7ec1e:	5d                                              	pop    rbp
   7ec1f:	c3                                              	ret
   7ec20:	45 31 ff                                        	xor    r15d,r15d
   7ec23:	e9 6d c5 ff ff                                  	jmp    7b195 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e5>
   7ec28:	48 83 f8 01                                     	cmp    rax,0x1
   7ec2c:	0f 84 63 c5 ff ff                               	je     7b195 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e5>
   7ec32:	0f b6 41 01                                     	movzx  eax,BYTE PTR [rcx+0x1]
   7ec36:	83 c0 d0                                        	add    eax,0xffffffd0
   7ec39:	83 f8 09                                        	cmp    eax,0x9
   7ec3c:	0f 87 50 c5 ff ff                               	ja     7b192 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e2>
   7ec42:	41 0f b6 cf                                     	movzx  ecx,r15b
   7ec46:	01 c9                                           	add    ecx,ecx
   7ec48:	8d 0c 89                                        	lea    ecx,[rcx+rcx*4]
   7ec4b:	00 c8                                           	add    al,cl
   7ec4d:	41 89 c7                                        	mov    r15d,eax
   7ec50:	e9 40 c5 ff ff                                  	jmp    7b195 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e5>
   7ec55:	41 b0 01                                        	mov    r8b,0x1
   7ec58:	e9 38 c5 ff ff                                  	jmp    7b195 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4e5>
   7ec5d:	48 8d 3d d8 3a f9 ff                            	lea    rdi,[rip+0xfffffffffff93ad8]        # 1273c <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x45bc>
   7ec64:	48 8d 15 e5 b7 01 00                            	lea    rdx,[rip+0x1b7e5]        # 9a450 <__frame_dummy_init_array_entry+0x2600>
   7ec6b:	be 11 00 00 00                                  	mov    esi,0x11
   7ec70:	e8 2b 36 fb ff                                  	call   322a0 <_RNvNtCsgxBkk5gSRhY_4core6option13expect_failed>
   7ec75:	e9 41 01 00 00                                  	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ec7a:	49 89 ee                                        	mov    r14,rbp
   7ec7d:	48 8d 15 24 b7 01 00                            	lea    rdx,[rip+0x1b724]        # 9a3a8 <__frame_dummy_init_array_entry+0x2558>
   7ec84:	eb 31                                           	jmp    7ecb7 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4007>
   7ec86:	48 8d 15 4b b7 01 00                            	lea    rdx,[rip+0x1b74b]        # 9a3d8 <__frame_dummy_init_array_entry+0x2588>
   7ec8d:	eb 28                                           	jmp    7ecb7 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4007>
   7ec8f:	49 89 c6                                        	mov    r14,rax
   7ec92:	48 8d 15 27 b7 01 00                            	lea    rdx,[rip+0x1b727]        # 9a3c0 <__frame_dummy_init_array_entry+0x2570>
   7ec99:	eb 1c                                           	jmp    7ecb7 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4007>
   7ec9b:	48 8d 15 96 b7 01 00                            	lea    rdx,[rip+0x1b796]        # 9a438 <__frame_dummy_init_array_entry+0x25e8>
   7eca2:	eb 13                                           	jmp    7ecb7 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4007>
   7eca4:	48 8d 15 45 b7 01 00                            	lea    rdx,[rip+0x1b745]        # 9a3f0 <__frame_dummy_init_array_entry+0x25a0>
   7ecab:	eb 0a                                           	jmp    7ecb7 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4007>
   7ecad:	49 89 c6                                        	mov    r14,rax
   7ecb0:	48 8d 15 51 b7 01 00                            	lea    rdx,[rip+0x1b751]        # 9a408 <__frame_dummy_init_array_entry+0x25b8>
   7ecb7:	4c 89 f7                                        	mov    rdi,r14
   7ecba:	c5 f8 77                                        	vzeroupper
   7ecbd:	e8 b2 15 fb ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   7ecc2:	e9 f4 00 00 00                                  	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ecc7:	4c 89 4c 24 10                                  	mov    QWORD PTR [rsp+0x10],r9
   7eccc:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
   7ecd1:	4c 89 f7                                        	mov    rdi,r14
   7ecd4:	e8 9b 15 fb ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   7ecd9:	e9 dd 00 00 00                                  	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ecde:	48 8d 05 ab b6 01 00                            	lea    rax,[rip+0x1b6ab]        # 9a390 <__frame_dummy_init_array_entry+0x2540>
   7ece5:	48 89 d7                                        	mov    rdi,rdx
   7ece8:	4c 89 ee                                        	mov    rsi,r13
   7eceb:	48 89 c2                                        	mov    rdx,rax
   7ecee:	c5 f8 77                                        	vzeroupper
   7ecf1:	e8 7e 15 fb ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   7ecf6:	e9 c0 00 00 00                                  	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ecfb:	48 8d 15 1e b7 01 00                            	lea    rdx,[rip+0x1b71e]        # 9a420 <__frame_dummy_init_array_entry+0x25d0>
   7ed02:	c5 f8 77                                        	vzeroupper
   7ed05:	e8 6a 15 fb ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   7ed0a:	e9 ac 00 00 00                                  	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ed0f:	bf 08 00 00 00                                  	mov    edi,0x8
   7ed14:	be 00 00 02 00                                  	mov    esi,0x20000
   7ed19:	e8 43 fa fa ff                                  	call   2e761 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7ed1e:	bf 04 00 00 00                                  	mov    edi,0x4
   7ed23:	be 00 20 00 00                                  	mov    esi,0x2000
   7ed28:	e8 34 fa fa ff                                  	call   2e761 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7ed2d:	e9 89 00 00 00                                  	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ed32:	bf 08 00 00 00                                  	mov    edi,0x8
   7ed37:	be 00 01 00 00                                  	mov    esi,0x100
   7ed3c:	e8 20 fa fa ff                                  	call   2e761 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7ed41:	eb 78                                           	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ed43:	bf 08 00 00 00                                  	mov    edi,0x8
   7ed48:	be 80 0c 00 00                                  	mov    esi,0xc80
   7ed4d:	e8 0f fa fa ff                                  	call   2e761 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7ed52:	eb 67                                           	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ed54:	bf 08 00 00 00                                  	mov    edi,0x8
   7ed59:	be 80 0c 00 00                                  	mov    esi,0xc80
   7ed5e:	e8 fe f9 fa ff                                  	call   2e761 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7ed63:	eb 56                                           	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ed65:	48 8d 0d fc b6 01 00                            	lea    rcx,[rip+0x1b6fc]        # 9a468 <__frame_dummy_init_array_entry+0x2618>
   7ed6c:	48 89 44 24 40                                  	mov    QWORD PTR [rsp+0x40],rax
   7ed71:	48 89 8c 24 28 01 00 00                         	mov    QWORD PTR [rsp+0x128],rcx
   7ed79:	48 8b 7c 24 58                                  	mov    rdi,QWORD PTR [rsp+0x58]
   7ed7e:	48 8b 74 24 40                                  	mov    rsi,QWORD PTR [rsp+0x40]
   7ed83:	48 8b 94 24 28 01 00 00                         	mov    rdx,QWORD PTR [rsp+0x128]
   7ed8b:	c5 f8 77                                        	vzeroupper
   7ed8e:	e8 e1 14 fb ff                                  	call   30274 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   7ed93:	eb 26                                           	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7ed95:	bf 08 00 00 00                                  	mov    edi,0x8
   7ed9a:	e9 04 d9 ff ff                                  	jmp    7c6a3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x19f3>
   7ed9f:	bf 08 00 00 00                                  	mov    edi,0x8
   7eda4:	4c 89 f6                                        	mov    rsi,r14
   7eda7:	e8 b5 f9 fa ff                                  	call   2e761 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7edac:	eb 0d                                           	jmp    7edbb <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x410b>
   7edae:	bf 08 00 00 00                                  	mov    edi,0x8
   7edb3:	4c 89 e6                                        	mov    rsi,r12
   7edb6:	e8 a6 f9 fa ff                                  	call   2e761 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7edbb:	0f 0b                                           	ud2
   7edbd:	4c 8b 7c 24 10                                  	mov    r15,QWORD PTR [rsp+0x10]
   7edc2:	48 8b 74 24 18                                  	mov    rsi,QWORD PTR [rsp+0x18]
   7edc7:	49 89 c5                                        	mov    r13,rax
   7edca:	e9 72 01 00 00                                  	jmp    7ef41 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4291>
   7edcf:	48 83 7c 24 38 00                               	cmp    QWORD PTR [rsp+0x38],0x0
   7edd5:	49 89 c5                                        	mov    r13,rax
   7edd8:	74 1b                                           	je     7edf5 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4145>
   7edda:	48 8b 74 24 38                                  	mov    rsi,QWORD PTR [rsp+0x38]
   7eddf:	48 8b bc 24 f8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xf8]
   7ede7:	ba 08 00 00 00                                  	mov    edx,0x8
   7edec:	48 c1 e6 06                                     	shl    rsi,0x6
   7edf0:	e8 ab 36 fa ff                                  	call   224a0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   7edf5:	4c 8b 7c 24 10                                  	mov    r15,QWORD PTR [rsp+0x10]
   7edfa:	4c 8b b4 24 80 00 00 00                         	mov    r14,QWORD PTR [rsp+0x80]
   7ee02:	e9 0a 01 00 00                                  	jmp    7ef11 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4261>
   7ee07:	48 8d bc 24 a0 07 00 00                         	lea    rdi,[rsp+0x7a0]
   7ee0f:	49 89 c5                                        	mov    r13,rax
   7ee12:	e8 f9 7a 01 00                                  	call   96910 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCsHW5vo2gROj_10zopro_core3msm12FqAddScratchEBF_>
   7ee17:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7ee1f:	e8 dc 79 01 00                                  	call   96800 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCsHW5vo2gROj_10zopro_core3msm7ScratchNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEEBG_>
   7ee24:	4d 85 e4                                        	test   r12,r12
   7ee27:	75 07                                           	jne    7ee30 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4180>
   7ee29:	4d 85 ff                                        	test   r15,r15
   7ee2c:	75 07                                           	jne    7ee35 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4185>
   7ee2e:	eb 52                                           	jmp    7ee82 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x41d2>
   7ee30:	4d 85 ff                                        	test   r15,r15
   7ee33:	7e 4d                                           	jle    7ee82 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x41d2>
   7ee35:	ba 01 00 00 00                                  	mov    edx,0x1
   7ee3a:	4c 89 f7                                        	mov    rdi,r14
   7ee3d:	4c 89 fe                                        	mov    rsi,r15
   7ee40:	e8 5b 36 fa ff                                  	call   224a0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   7ee45:	eb 3b                                           	jmp    7ee82 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x41d2>
   7ee47:	48 8d bc 24 a0 07 00 00                         	lea    rdi,[rsp+0x7a0]
   7ee4f:	49 89 c5                                        	mov    r13,rax
   7ee52:	e8 b9 7a 01 00                                  	call   96910 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCsHW5vo2gROj_10zopro_core3msm12FqAddScratchEBF_>
   7ee57:	eb 03                                           	jmp    7ee5c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x41ac>
   7ee59:	49 89 c5                                        	mov    r13,rax
   7ee5c:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7ee64:	e8 97 79 01 00                                  	call   96800 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCsHW5vo2gROj_10zopro_core3msm7ScratchNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEEBG_>
   7ee69:	eb 17                                           	jmp    7ee82 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x41d2>
   7ee6b:	49 89 c5                                        	mov    r13,rax
   7ee6e:	eb 1d                                           	jmp    7ee8d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x41dd>
   7ee70:	49 89 c5                                        	mov    r13,rax
   7ee73:	eb 23                                           	jmp    7ee98 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x41e8>
   7ee75:	49 89 c5                                        	mov    r13,rax
   7ee78:	eb 29                                           	jmp    7eea3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x41f3>
   7ee7a:	49 89 c5                                        	mov    r13,rax
   7ee7d:	eb 2f                                           	jmp    7eeae <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x41fe>
   7ee7f:	49 89 c5                                        	mov    r13,rax
   7ee82:	48 8b 7c 24 50                                  	mov    rdi,QWORD PTR [rsp+0x50]
   7ee87:	ff 15 fb b8 01 00                               	call   QWORD PTR [rip+0x1b8fb]        # 9a788 <free@GLIBC_2.2.5>
   7ee8d:	48 8b 7c 24 18                                  	mov    rdi,QWORD PTR [rsp+0x18]
   7ee92:	ff 15 f0 b8 01 00                               	call   QWORD PTR [rip+0x1b8f0]        # 9a788 <free@GLIBC_2.2.5>
   7ee98:	48 8b 7c 24 40                                  	mov    rdi,QWORD PTR [rsp+0x40]
   7ee9d:	ff 15 e5 b8 01 00                               	call   QWORD PTR [rip+0x1b8e5]        # 9a788 <free@GLIBC_2.2.5>
   7eea3:	48 8b 7c 24 08                                  	mov    rdi,QWORD PTR [rsp+0x8]
   7eea8:	ff 15 da b8 01 00                               	call   QWORD PTR [rip+0x1b8da]        # 9a788 <free@GLIBC_2.2.5>
   7eeae:	be 00 00 02 00                                  	mov    esi,0x20000
   7eeb3:	ba 08 00 00 00                                  	mov    edx,0x8
   7eeb8:	48 89 ef                                        	mov    rdi,rbp
   7eebb:	e8 e0 35 fa ff                                  	call   224a0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   7eec0:	4c 89 ef                                        	mov    rdi,r13
   7eec3:	e8 38 7f 01 00                                  	call   96e00 <_Unwind_Resume@plt>
   7eec8:	48 83 7c 24 38 00                               	cmp    QWORD PTR [rsp+0x38],0x0
   7eece:	49 89 c5                                        	mov    r13,rax
   7eed1:	74 61                                           	je     7ef34 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4284>
   7eed3:	48 8b 74 24 38                                  	mov    rsi,QWORD PTR [rsp+0x38]
   7eed8:	ba 08 00 00 00                                  	mov    edx,0x8
   7eedd:	48 89 df                                        	mov    rdi,rbx
   7eee0:	48 c1 e6 06                                     	shl    rsi,0x6
   7eee4:	eb 49                                           	jmp    7ef2f <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x427f>
   7eee6:	4c 8b 74 24 40                                  	mov    r14,QWORD PTR [rsp+0x40]
   7eeeb:	eb 21                                           	jmp    7ef0e <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x425e>
   7eeed:	eb 61                                           	jmp    7ef50 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42a0>
   7eeef:	eb 5f                                           	jmp    7ef50 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42a0>
   7eef1:	48 8b 7c 24 10                                  	mov    rdi,QWORD PTR [rsp+0x10]
   7eef6:	48 8b 74 24 18                                  	mov    rsi,QWORD PTR [rsp+0x18]
   7eefb:	ba 08 00 00 00                                  	mov    edx,0x8
   7ef00:	49 89 c5                                        	mov    r13,rax
   7ef03:	e8 98 35 fa ff                                  	call   224a0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   7ef08:	eb 61                                           	jmp    7ef6b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42bb>
   7ef0a:	eb 5c                                           	jmp    7ef68 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42b8>
   7ef0c:	eb 42                                           	jmp    7ef50 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42a0>
   7ef0e:	49 89 c5                                        	mov    r13,rax
   7ef11:	48 8b b4 24 98 00 00 00                         	mov    rsi,QWORD PTR [rsp+0x98]
   7ef19:	48 85 f6                                        	test   rsi,rsi
   7ef1c:	74 16                                           	je     7ef34 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4284>
   7ef1e:	48 8b bc 24 a0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xa0]
   7ef26:	48 c1 e6 05                                     	shl    rsi,0x5
   7ef2a:	ba 08 00 00 00                                  	mov    edx,0x8
   7ef2f:	e8 6c 35 fa ff                                  	call   224a0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   7ef34:	4d 85 f6                                        	test   r14,r14
   7ef37:	74 32                                           	je     7ef6b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42bb>
   7ef39:	49 c1 e6 05                                     	shl    r14,0x5
   7ef3d:	4b 8d 34 76                                     	lea    rsi,[r14+r14*2]
   7ef41:	ba 08 00 00 00                                  	mov    edx,0x8
   7ef46:	4c 89 ff                                        	mov    rdi,r15
   7ef49:	e8 52 35 fa ff                                  	call   224a0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   7ef4e:	eb 1b                                           	jmp    7ef6b <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42bb>
   7ef50:	48 8d bc 24 a0 07 00 00                         	lea    rdi,[rsp+0x7a0]
   7ef58:	49 89 c5                                        	mov    r13,rax
   7ef5b:	e8 60 03 00 00                                  	call   7f2c0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending6WindowNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEEBI_>
   7ef60:	4c 89 ef                                        	mov    rdi,r13
   7ef63:	e8 98 7e 01 00                                  	call   96e00 <_Unwind_Resume@plt>
   7ef68:	49 89 c5                                        	mov    r13,rax
   7ef6b:	48 8b 84 24 80 01 00 00                         	mov    rax,QWORD PTR [rsp+0x180]
   7ef73:	48 85 c0                                        	test   rax,rax
   7ef76:	75 7b                                           	jne    7eff3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4343>
   7ef78:	48 8b 84 24 98 01 00 00                         	mov    rax,QWORD PTR [rsp+0x198]
   7ef80:	48 85 c0                                        	test   rax,rax
   7ef83:	0f 85 cd 00 00 00                               	jne    7f056 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x43a6>
   7ef89:	48 8b 84 24 b0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1b0]
   7ef91:	48 85 c0                                        	test   rax,rax
   7ef94:	0f 85 23 01 00 00                               	jne    7f0bd <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x440d>
   7ef9a:	48 8b 84 24 c8 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1c8]
   7efa2:	48 85 c0                                        	test   rax,rax
   7efa5:	0f 85 79 01 00 00                               	jne    7f124 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4474>
   7efab:	48 8b 84 24 e0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1e0]
   7efb3:	48 85 c0                                        	test   rax,rax
   7efb6:	0f 85 cb 01 00 00                               	jne    7f187 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x44d7>
   7efbc:	48 8b 84 24 f8 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1f8]
   7efc4:	48 85 c0                                        	test   rax,rax
   7efc7:	0f 85 1d 02 00 00                               	jne    7f1ea <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x453a>
   7efcd:	48 8b 84 24 10 02 00 00                         	mov    rax,QWORD PTR [rsp+0x210]
   7efd5:	48 85 c0                                        	test   rax,rax
   7efd8:	0f 85 6f 02 00 00                               	jne    7f24d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x459d>
   7efde:	48 8d bc 24 28 02 00 00                         	lea    rdi,[rsp+0x228]
   7efe6:	e8 35 28 01 00                                  	call   91820 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCsHW5vo2gROj_10zopro_core3msm8BatchAddNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEEBG_>
   7efeb:	4c 89 ef                                        	mov    rdi,r13
   7efee:	e8 0d 7e 01 00                                  	call   96e00 <_Unwind_Resume@plt>
   7eff3:	48 8b bc 24 88 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x188]
   7effb:	48 3d ff 07 00 00                               	cmp    rax,0x7ff
   7f001:	76 3c                                           	jbe    7f03f <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x438f>
   7f003:	48 c1 e0 06                                     	shl    rax,0x6
   7f007:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7f011:	48 89 c6                                        	mov    rsi,rax
   7f014:	48 83 ce 01                                     	or     rsi,0x1
   7f018:	48 39 ce                                        	cmp    rsi,rcx
   7f01b:	0f 83 03 c6 ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7f021:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7f025:	75 18                                           	jne    7f03f <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x438f>
   7f027:	ff 15 53 b7 01 00                               	call   QWORD PTR [rip+0x1b753]        # 9a780 <munmap@GLIBC_2.2.5>
   7f02d:	48 8b 84 24 98 01 00 00                         	mov    rax,QWORD PTR [rsp+0x198]
   7f035:	48 85 c0                                        	test   rax,rax
   7f038:	75 1c                                           	jne    7f056 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x43a6>
   7f03a:	e9 4a ff ff ff                                  	jmp    7ef89 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42d9>
   7f03f:	ff 15 43 b7 01 00                               	call   QWORD PTR [rip+0x1b743]        # 9a788 <free@GLIBC_2.2.5>
   7f045:	48 8b 84 24 98 01 00 00                         	mov    rax,QWORD PTR [rsp+0x198]
   7f04d:	48 85 c0                                        	test   rax,rax
   7f050:	0f 84 33 ff ff ff                               	je     7ef89 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42d9>
   7f056:	48 8b bc 24 a0 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x1a0]
   7f05e:	48 3d 55 05 00 00                               	cmp    rax,0x555
   7f064:	76 40                                           	jbe    7f0a6 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x43f6>
   7f066:	48 c1 e0 05                                     	shl    rax,0x5
   7f06a:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7f074:	48 8d 04 40                                     	lea    rax,[rax+rax*2]
   7f078:	48 89 c6                                        	mov    rsi,rax
   7f07b:	48 83 ce 01                                     	or     rsi,0x1
   7f07f:	48 39 ce                                        	cmp    rsi,rcx
   7f082:	0f 83 9c c5 ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7f088:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7f08c:	75 18                                           	jne    7f0a6 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x43f6>
   7f08e:	ff 15 ec b6 01 00                               	call   QWORD PTR [rip+0x1b6ec]        # 9a780 <munmap@GLIBC_2.2.5>
   7f094:	48 8b 84 24 b0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1b0]
   7f09c:	48 85 c0                                        	test   rax,rax
   7f09f:	75 1c                                           	jne    7f0bd <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x440d>
   7f0a1:	e9 f4 fe ff ff                                  	jmp    7ef9a <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42ea>
   7f0a6:	ff 15 dc b6 01 00                               	call   QWORD PTR [rip+0x1b6dc]        # 9a788 <free@GLIBC_2.2.5>
   7f0ac:	48 8b 84 24 b0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1b0]
   7f0b4:	48 85 c0                                        	test   rax,rax
   7f0b7:	0f 84 dd fe ff ff                               	je     7ef9a <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42ea>
   7f0bd:	48 8b bc 24 b8 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x1b8]
   7f0c5:	48 3d ff 7f 00 00                               	cmp    rax,0x7fff
   7f0cb:	76 40                                           	jbe    7f10d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x445d>
   7f0cd:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7f0d7:	48 c1 e0 02                                     	shl    rax,0x2
   7f0db:	48 89 c6                                        	mov    rsi,rax
   7f0de:	48 83 ce 01                                     	or     rsi,0x1
   7f0e2:	48 83 c1 04                                     	add    rcx,0x4
   7f0e6:	48 39 ce                                        	cmp    rsi,rcx
   7f0e9:	0f 83 35 c5 ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7f0ef:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7f0f3:	75 18                                           	jne    7f10d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x445d>
   7f0f5:	ff 15 85 b6 01 00                               	call   QWORD PTR [rip+0x1b685]        # 9a780 <munmap@GLIBC_2.2.5>
   7f0fb:	48 8b 84 24 c8 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1c8]
   7f103:	48 85 c0                                        	test   rax,rax
   7f106:	75 1c                                           	jne    7f124 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4474>
   7f108:	e9 9e fe ff ff                                  	jmp    7efab <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42fb>
   7f10d:	ff 15 75 b6 01 00                               	call   QWORD PTR [rip+0x1b675]        # 9a788 <free@GLIBC_2.2.5>
   7f113:	48 8b 84 24 c8 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1c8]
   7f11b:	48 85 c0                                        	test   rax,rax
   7f11e:	0f 84 87 fe ff ff                               	je     7efab <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x42fb>
   7f124:	48 8b bc 24 d0 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x1d0]
   7f12c:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7f132:	76 3c                                           	jbe    7f170 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x44c0>
   7f134:	48 c1 e0 03                                     	shl    rax,0x3
   7f138:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7f142:	48 89 c6                                        	mov    rsi,rax
   7f145:	48 83 ce 01                                     	or     rsi,0x1
   7f149:	48 39 ce                                        	cmp    rsi,rcx
   7f14c:	0f 83 d2 c4 ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7f152:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7f156:	75 18                                           	jne    7f170 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x44c0>
   7f158:	ff 15 22 b6 01 00                               	call   QWORD PTR [rip+0x1b622]        # 9a780 <munmap@GLIBC_2.2.5>
   7f15e:	48 8b 84 24 e0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1e0]
   7f166:	48 85 c0                                        	test   rax,rax
   7f169:	75 1c                                           	jne    7f187 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x44d7>
   7f16b:	e9 4c fe ff ff                                  	jmp    7efbc <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x430c>
   7f170:	ff 15 12 b6 01 00                               	call   QWORD PTR [rip+0x1b612]        # 9a788 <free@GLIBC_2.2.5>
   7f176:	48 8b 84 24 e0 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1e0]
   7f17e:	48 85 c0                                        	test   rax,rax
   7f181:	0f 84 35 fe ff ff                               	je     7efbc <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x430c>
   7f187:	48 8b bc 24 e8 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x1e8]
   7f18f:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7f195:	76 3c                                           	jbe    7f1d3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4523>
   7f197:	48 c1 e0 03                                     	shl    rax,0x3
   7f19b:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7f1a5:	48 89 c6                                        	mov    rsi,rax
   7f1a8:	48 83 ce 01                                     	or     rsi,0x1
   7f1ac:	48 39 ce                                        	cmp    rsi,rcx
   7f1af:	0f 83 6f c4 ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7f1b5:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7f1b9:	75 18                                           	jne    7f1d3 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4523>
   7f1bb:	ff 15 bf b5 01 00                               	call   QWORD PTR [rip+0x1b5bf]        # 9a780 <munmap@GLIBC_2.2.5>
   7f1c1:	48 8b 84 24 f8 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1f8]
   7f1c9:	48 85 c0                                        	test   rax,rax
   7f1cc:	75 1c                                           	jne    7f1ea <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x453a>
   7f1ce:	e9 fa fd ff ff                                  	jmp    7efcd <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x431d>
   7f1d3:	ff 15 af b5 01 00                               	call   QWORD PTR [rip+0x1b5af]        # 9a788 <free@GLIBC_2.2.5>
   7f1d9:	48 8b 84 24 f8 01 00 00                         	mov    rax,QWORD PTR [rsp+0x1f8]
   7f1e1:	48 85 c0                                        	test   rax,rax
   7f1e4:	0f 84 e3 fd ff ff                               	je     7efcd <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x431d>
   7f1ea:	48 8b bc 24 00 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x200]
   7f1f2:	48 3d ff 1f 00 00                               	cmp    rax,0x1fff
   7f1f8:	76 3c                                           	jbe    7f236 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4586>
   7f1fa:	48 c1 e0 04                                     	shl    rax,0x4
   7f1fe:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7f208:	48 89 c6                                        	mov    rsi,rax
   7f20b:	48 83 ce 01                                     	or     rsi,0x1
   7f20f:	48 39 ce                                        	cmp    rsi,rcx
   7f212:	0f 83 0c c4 ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7f218:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7f21c:	75 18                                           	jne    7f236 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x4586>
   7f21e:	ff 15 5c b5 01 00                               	call   QWORD PTR [rip+0x1b55c]        # 9a780 <munmap@GLIBC_2.2.5>
   7f224:	48 8b 84 24 10 02 00 00                         	mov    rax,QWORD PTR [rsp+0x210]
   7f22c:	48 85 c0                                        	test   rax,rax
   7f22f:	75 1c                                           	jne    7f24d <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x459d>
   7f231:	e9 a8 fd ff ff                                  	jmp    7efde <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x432e>
   7f236:	ff 15 4c b5 01 00                               	call   QWORD PTR [rip+0x1b54c]        # 9a788 <free@GLIBC_2.2.5>
   7f23c:	48 8b 84 24 10 02 00 00                         	mov    rax,QWORD PTR [rsp+0x210]
   7f244:	48 85 c0                                        	test   rax,rax
   7f247:	0f 84 91 fd ff ff                               	je     7efde <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x432e>
   7f24d:	48 8b bc 24 18 02 00 00                         	mov    rdi,QWORD PTR [rsp+0x218]
   7f255:	48 3d ff 1f 00 00                               	cmp    rax,0x1fff
   7f25b:	76 3f                                           	jbe    7f29c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x45ec>
   7f25d:	48 c1 e0 04                                     	shl    rax,0x4
   7f261:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7f26b:	48 89 c6                                        	mov    rsi,rax
   7f26e:	48 83 ce 01                                     	or     rsi,0x1
   7f272:	48 39 ce                                        	cmp    rsi,rcx
   7f275:	0f 83 a9 c3 ff ff                               	jae    7b624 <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x974>
   7f27b:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7f27f:	75 1b                                           	jne    7f29c <_RNvCsHW5vo2gROj_10zopro_core16g1_columns_probe+0x45ec>
   7f281:	ff 15 f9 b4 01 00                               	call   QWORD PTR [rip+0x1b4f9]        # 9a780 <munmap@GLIBC_2.2.5>
   7f287:	48 8d bc 24 28 02 00 00                         	lea    rdi,[rsp+0x228]
   7f28f:	e8 8c 25 01 00                                  	call   91820 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCsHW5vo2gROj_10zopro_core3msm8BatchAddNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEEBG_>
   7f294:	4c 89 ef                                        	mov    rdi,r13
   7f297:	e8 64 7b 01 00                                  	call   96e00 <_Unwind_Resume@plt>
   7f29c:	ff 15 e6 b4 01 00                               	call   QWORD PTR [rip+0x1b4e6]        # 9a788 <free@GLIBC_2.2.5>
   7f2a2:	48 8d bc 24 28 02 00 00                         	lea    rdi,[rsp+0x228]
   7f2aa:	e8 71 25 01 00                                  	call   91820 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCsHW5vo2gROj_10zopro_core3msm8BatchAddNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G1ConfigEEBG_>
   7f2af:	4c 89 ef                                        	mov    rdi,r13
   7f2b2:	e8 49 7b 01 00                                  	call   96e00 <_Unwind_Resume@plt>
