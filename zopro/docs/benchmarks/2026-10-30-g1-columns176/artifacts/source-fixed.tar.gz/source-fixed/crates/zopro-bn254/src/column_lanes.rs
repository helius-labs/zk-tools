//! Native mixed R256 helpers for canonical, lane-stable bucket coordinates.
use crate::{ifma8::Ifma8, FpConfig};
use core::{arch::x86_64::*, marker::PhantomData};

impl<C: FpConfig> Ifma8<C, true> {
    /// Canonicalize normalized values below 2p without a host-word transpose.
    #[inline(always)]
    pub fn column_canonical(&self) -> Self {
        // This is the existing mixed get() reduction, without its word export.
        const MASK: u64 = (1 << 52) - 1;
        let p = C::P;
        let p = [
            p[0] & MASK,
            ((p[0] >> 52) | (p[1] << 12)) & MASK,
            ((p[1] >> 40) | (p[2] << 24)) & MASK,
            ((p[2] >> 28) | (p[3] << 36)) & MASK,
            p[3] >> 16,
        ];
        unsafe {
            let zero = _mm512_setzero_si512();
            let mask = _mm512_set1_epi64(MASK as i64);
            let mut d = [zero; 5];
            let mut borrow = zero;
            for j in 0..5 {
                let v = _mm512_add_epi64(
                    _mm512_sub_epi64(self.0[j], _mm512_set1_epi64(p[j] as i64)),
                    borrow,
                );
                d[j] = _mm512_and_si512(v, mask);
                borrow = _mm512_srai_epi64::<52>(v);
            }
            let keep = _mm512_cmpneq_epi64_mask(borrow, zero);
            Self(
                core::array::from_fn(|j| _mm512_mask_blend_epi64(keep, d[j], self.0[j])),
                PhantomData,
            )
        }
    }

    /// Select `other` in mask lanes. Both inputs retain their range contracts.
    #[inline(always)]
    pub fn column_select(&self, other: &Self, mask: u8) -> Self {
        unsafe {
            Self(
                core::array::from_fn(|j| _mm512_mask_blend_epi64(mask, self.0[j], other.0[j])),
                PhantomData,
            )
        }
    }

    /// Compare canonical normalized coordinates. Lazy representatives need prior canonicalization.
    #[inline(always)]
    pub fn column_eq_canonical(&self, other: &Self) -> u8 {
        unsafe {
            let mut equal = 255;
            for j in 0..5 {
                equal &= _mm512_cmpeq_epi64_mask(self.0[j], other.0[j]);
            }
            equal
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Fp;
    fn run<C: FpConfig, A: ark_ff::PrimeField>() {
        use ark_ff::Field;
        let inv_r = A::from(2u64).pow([256]).inverse().unwrap();
        let convert = |v: Fp<C>| {
            A::from_le_bytes_mod_order(
                &v.0.into_iter()
                    .flat_map(u64::to_le_bytes)
                    .collect::<Vec<_>>(),
            ) * inv_r
        };
        let mut seed = 0x79183fea883b7145u64;
        for round in 0..4352 {
            let mut next = || {
                let mut b = [0; 64];
                for c in b.chunks_mut(8) {
                    seed ^= seed << 13;
                    seed ^= seed >> 7;
                    seed ^= seed << 17;
                    c.copy_from_slice(&seed.to_le_bytes());
                }
                Fp::<C>::from_random_bytes(&b)
            };
            let a: [Fp<C>; 8] = core::array::from_fn(|i| {
                if round < 256 {
                    match (i + round) % 4 {
                        0 => Fp::ZERO,
                        1 => Fp::ONE,
                        2 => -Fp::ONE,
                        _ => Fp::from_montgomery([1, 0, 0, 0]),
                    }
                } else {
                    next()
                }
            });
            let b: [Fp<C>; 8] =
                core::array::from_fn(|i| if (round + i) % 5 == 0 { a[i] } else { next() });
            let av = Ifma8::<C, true>::new(&a);
            let bv = Ifma8::<C, true>::new(&b);
            let lazy = av.add(&bv);
            let canonical = lazy.column_canonical();
            let output = canonical.get();
            let raw: [[u64; 8]; 5] = unsafe { canonical.0.map(|v| core::mem::transmute(v)) };
            let p = C::P;
            const M: u64 = (1 << 52) - 1;
            let limbs = [
                p[0] & M,
                ((p[0] >> 52) | (p[1] << 12)) & M,
                ((p[1] >> 40) | (p[2] << 24)) & M,
                ((p[2] >> 28) | (p[3] << 36)) & M,
                p[3] >> 16,
            ];
            for i in 0..8 {
                let words = core::array::from_fn::<u64, 5, _>(|j| raw[j][i]);
                assert!(words.iter().all(|&w| w <= M));
                assert!(words.iter().rev().cmp(limbs.iter().rev()).is_lt());
                assert_eq!(convert(output[i]), convert(a[i]) + convert(b[i]));
            }
            let mask = round as u8;
            let selected = av.column_select(&bv, mask).get();
            for i in 0..8 {
                assert_eq!(selected[i], if mask >> i & 1 != 0 { b[i] } else { a[i] });
            }
            let expected = (0..8).fold(0u8, |m, i| m | if a[i] == b[i] { 1 << i } else { 0 });
            assert_eq!(av.column_eq_canonical(&bv), expected);
            assert_eq!(canonical.column_eq_canonical(&Ifma8::new(&output)), 255);
        }
        // Normalized representatives at 0,p,2p-1 must reduce to 0,0,p-1.
        let p = C::P;
        let twice = crate::portable::add4(p, p).0;
        let high = crate::portable::sub4(twice, [1, 0, 0, 0]).0;
        let values = [[0; 4], p, high];
        for shift in 0..3 {
            let host = core::array::from_fn(|i| Fp::<C>::from_montgomery(values[(i + shift) % 3]));
            let v = Ifma8::<C, true>::new(&host).column_canonical();
            let out = v.get();
            for i in 0..8 {
                let expected = if (i + shift) % 3 == 2 {
                    Fp::from_montgomery(crate::portable::sub4(p, [1, 0, 0, 0]).0)
                } else {
                    Fp::ZERO
                };
                assert_eq!(out[i], expected);
            }
        }
    }
    #[test]
    fn column_lanes_fq_ark() {
        run::<crate::FqConfig, ark_ref::Fq>();
    }
    #[test]
    fn column_lanes_fr_ark() {
        run::<crate::FrConfig, ark_ref::Fr>();
    }
}
