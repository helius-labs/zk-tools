use serde_json::{json, Value};
use std::{fs, path::Path};
use zopro_core::artifact::Artifact;
#[global_allocator]
static ALLOCATOR: zopro_core::alloc::Allocator = zopro_core::alloc::Allocator;
const R: &str = "/home/ubuntu/src/zopro-perf-work/g1-columns176";
fn main() {
    let r = Path::new(R);
    assert!(!r.join("inputs").exists());
    fs::create_dir(r.join("inputs")).unwrap();
    let cases: Value = serde_json::from_slice(
        &fs::read("/home/ubuntu/src/zopro-perf-work/g2-queue-scan-count175/cases.json").unwrap(),
    )
    .unwrap();
    let mut result = vec![];
    for c in cases.as_array().unwrap().iter().take(2) {
        let shape = c["shape"].as_str().unwrap();
        let bytes = fs::read(c["key"].as_str().unwrap()).unwrap();
        let a = Artifact::parse(&bytes).unwrap();
        let points = zopro_core::decompress_g1(a.a).unwrap();
        let cache = fs::read(format!(
            "/home/ubuntu/src/zopro-perf-work/g1-column-count176/{shape}-raw-a.words"
        ))
        .unwrap();
        assert_eq!(&cache[..8], b"ACOLUMN1");
        let n = u64::from_le_bytes(cache[8..16].try_into().unwrap()) as usize;
        assert_eq!(cache.len(), 16 + 33 * n);
        assert_eq!(points.len(), 64 * n);
        let mut out = b"ACOLMSM1".to_vec();
        out.extend_from_slice(&(n as u64).to_le_bytes());
        out.extend_from_slice(&points);
        for (i, row) in cache[16..].chunks_exact(33).enumerate() {
            assert_eq!(
                points[i * 64..i * 64 + 64].iter().all(|&x| x == 0),
                row[32] != 0
            );
            out.extend_from_slice(&row[..32]);
        }
        let file = r.join("inputs").join(format!("{shape}.a1q"));
        fs::write(&file, out).unwrap();
        result.push(json!({"shape":shape,"points":n,"file":file,"point_encoding":"canonical big-endian x,y;zero identity","scalar_encoding":"canonical little-endian four-u64 Fr","source_cache":format!("/home/ubuntu/src/zopro-perf-work/g1-column-count176/{shape}-raw-a.words")}));
    }
    fs::write(
        r.join("fixture-manifest.json"),
        serde_json::to_vec_pretty(&json!({"fixtures":result,"new_solver_calls":0,"new_proofs":0}))
            .unwrap(),
    )
    .unwrap();
    println!("Two local rawA fixtures prepared from accepted key decoding and exact saved scalars;zero solves/proofs");
}
