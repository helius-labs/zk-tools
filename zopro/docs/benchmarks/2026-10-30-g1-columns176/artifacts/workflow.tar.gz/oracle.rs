use ark_ec::{AdditiveGroup, AffineRepr, CurveGroup};
use ark_ff::{BigInt, PrimeField};
use serde_json::json;
use sha2::{Digest, Sha256};
use std::{fs, path::Path};
fn hash(b: &[u8]) -> String {
    format!("{:x}", Sha256::digest(b))
}
fn field(b: &[u8]) -> ark_bn254::Fq {
    let words = core::array::from_fn(|j| {
        u64::from_be_bytes(b[(3 - j) * 8..(4 - j) * 8].try_into().unwrap())
    });
    ark_bn254::Fq::from_bigint(BigInt(words)).unwrap()
}
fn be(value: ark_bn254::Fq) -> [u8; 32] {
    let a = value.into_bigint().0;
    core::array::from_fn(|i| a[3 - i / 8].to_be_bytes()[i % 8])
}
fn digit(s: &[u64; 4], w: usize) -> i16 {
    let bit = |i: usize| {
        if i >= 256 {
            0
        } else {
            ((s[i / 64] >> (i % 64)) & 1) as i64
        }
    };
    let o = w * 12;
    let v = (0..12).map(|j| bit(o + j) << j).sum::<i64>();
    (v + if o == 0 { 0 } else { bit(o - 1) } - (bit(o + 11) << 12)) as i16
}
fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    assert_eq!(args.len(), 3);
    let bytes = fs::read(&args[1]).unwrap();
    assert_eq!(&bytes[..8], b"ACOLMSM1");
    let n = u64::from_le_bytes(bytes[8..16].try_into().unwrap()) as usize;
    assert_eq!(bytes.len(), 16 + 96 * n);
    let mut points = Vec::with_capacity(n);
    for raw in bytes[16..16 + 64 * n].chunks_exact(64) {
        let p = if raw.iter().all(|&x| x == 0) {
            ark_bn254::G1Affine::identity()
        } else {
            ark_bn254::G1Affine::new_unchecked(field(&raw[..32]), field(&raw[32..]))
        };
        assert!(p.is_on_curve());
        assert!(p.is_in_correct_subgroup_assuming_on_curve());
        points.push(p);
    }
    let scalars = bytes[16 + 64 * n..]
        .chunks_exact(32)
        .map(|b| {
            let s = core::array::from_fn(|j| {
                u64::from_le_bytes(b[j * 8..j * 8 + 8].try_into().unwrap())
            });
            assert!(ark_bn254::Fr::from_bigint(BigInt(s)).is_some());
            s
        })
        .collect::<Vec<_>>();
    let mut out = b"ACOLREF1".to_vec();
    out.extend_from_slice(&21u32.to_le_bytes());
    out.extend_from_slice(&2048u32.to_le_bytes());
    for w in 0..21 {
        let mut buckets = vec![ark_bn254::G1Projective::ZERO; 2048];
        for (p, s) in points.iter().zip(&scalars) {
            let d = digit(s, w);
            if d != 0 && !p.is_zero() {
                if d < 0 {
                    buckets[d.unsigned_abs() as usize - 1] -= *p;
                } else {
                    buckets[d.unsigned_abs() as usize - 1] += *p;
                }
            }
        }
        let affine = ark_bn254::G1Projective::normalize_batch(&buckets);
        for p in affine {
            if p.is_zero() {
                out.extend_from_slice(&[0; 64]);
            } else {
                out.extend_from_slice(&be(p.x));
                out.extend_from_slice(&be(p.y));
            }
        }
    }
    assert!(!Path::new(&args[2]).exists());
    fs::write(&args[2], &out).unwrap();
    println!(
        "{}",
        json!({"fixture":args[1],"fixture_sha256":hash(&bytes),"expected":args[2],"expected_sha256":hash(&out),"points":n,"ordinary_windows":21,"bucket_outputs":21*2048,"all_points_on_curve":true,"all_points_in_prime_subgroup":true,"all_scalars_canonical":true,"independent_Arkworks_projective_bucket_sums":true,"new_proofs":0})
    );
}
