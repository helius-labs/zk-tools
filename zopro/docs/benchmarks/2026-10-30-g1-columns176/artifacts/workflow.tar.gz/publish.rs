use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fmt::Write, fs, path::Path, process::Command};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g1-columns176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn archive(dest: &Path, root: &Path, names: &[&str]) {
    assert!(Command::new("tar")
        .args([
            "--sort=name",
            "--mtime=@0",
            "--owner=0",
            "--group=0",
            "--numeric-owner",
            "--exclude=*-sdk",
            "-czf"
        ])
        .arg(dest)
        .arg("-C")
        .arg(root)
        .args(names)
        .status()
        .unwrap()
        .success());
}
fn main() {
    let r = Path::new(R);
    let d = Path::new(Z).join("docs/benchmarks/2026-10-30-g1-columns176");
    assert!(!d.exists());
    let a = read(r.join("analysis.json"));
    assert_eq!(a["caller_gate_passed"], false);
    assert_eq!(read(r.join("review.json"))["passed"], true);
    fs::create_dir_all(d.join("artifacts")).unwrap();
    for n in [
        "analysis.json",
        "review.json",
        "review.log",
        "symbols.json",
        "codegen.json",
        "source-audit.json",
        "source-audit-fixed.json",
        "design.md",
        "capture-design.md",
        "repair.md",
        "access-repair.md",
    ] {
        fs::copy(r.join(n), d.join("artifacts").join(n)).unwrap();
    }
    let mut text=String::from("# Native segmented SIMD G1 columns\n\n**Rejected at the complete-filler gate; no production adoption.** The32-worker equal-log aggregate is14.428%slower: paired ratio1.144285[1.119459,1.162425],0/15winning blocks. Every case fails the3%context upper-bound limit. Production source176, accepted proof timings and the verified-proof ledger remain unchanged.\n\nThe prior structural screen found about49%fewer logical field conversions with unchanged point-addition counts. The complete native implementation performs more total work and uses more memory. Logical conversion counts did not predict an overall gain. No fullSDK or proof-latency trial follows this failed component result.\n\n## Implemented mechanism\n\nFor each ordinary signed width12window, histogram/scatter borrowed input indices, split original buckets into segments of at most8points, sort similarly sized segments into8-lane cohorts, and keep their coordinates in native SIMD form through each update. The bounded circular schedule runs at most25cohorts per wave. Three-field prefix records use the existing inverse and affine addition formula. Export partial sums once, then merge them using the existing256-original-bucket group tree.\n\nNew handwritten field helpers canonicalize normalized values below2p without a host transpose, compare canonical coordinates and select lanes. Inactive, identity and equal-X cases use denominator1; complete scalar group operations handle identity/doubling/cancellation, and only ordinary lanes receive the vector result. New coordinates are canonical before the next canonical signed-difference step. Generated arithmetic and generators remain byte-identical. No per-key table, transformed/copied key, second solver plan, assembly, pool or production hook is added. Proof-local native columns, partial points and index metadata are additional scratch.\n\nThe control executes the original borrowed_pending Window::new/feed/finish bodies through a diagnostic wrapper. The candidate is a separate private snapshot; the failed unsplit-column layout and earlier G2 output-store result remain closed.\n\n## Complete ordinary-filler latency\n\nEach pass fills all21ordinary windows of one raw pre-group Aquery. Loading, independent oracle construction and pool creation are excluded. Histogram/sorting/scattering, all field and exception work, range repair, export/partial merging, allocation, output drop and pool dispatch/wait are included. Narrow top, final weighting, solving and proof verification are outside this scope. These are **filler timings, not proof latency**; raw inputs are not automatically final grouped-query populations.\n\nFifteen fixed rotated/reversed paired blocks use20timed passes per process after3primes, followed by1post-check, on the shared Ryzen9950X host. The same Rayon pool supports outer windows and candidate nested merges. Whole-process affinity is CPU2solo,0–15physical or0–31logical; workers may migrate within it. No owned build/hash/archive/second workload overlaps measurements.\n\n| Raw shape | Workers | OFF ms/pass | ON ms/pass | Paired ON/OFF | Paired bounds | Wins/15 |\n|---|---:|---:|---:|---:|---:|---:|\n");
    for shape in ["1x2", "2x2"] {
        for workers in [1, 16, 32] {
            let c = &a["cases"][format!("{shape}-w{workers}")];
            let q = &c["candidate_over_control"];
            writeln!(
                text,
                "| {shape} | {workers} | {:.6} | {:.6} | {:.6} | [{:.6}, {:.6}] | {} |",
                c["control_ns"]["median"].as_f64().unwrap() / 1e6,
                c["candidate_ns"]["median"].as_f64().unwrap() / 1e6,
                q["median"].as_f64().unwrap(),
                q["lower"].as_f64().unwrap(),
                q["upper"].as_f64().unwrap(),
                q["wins"]
            )
            .unwrap();
        }
    }
    text.push_str("\nThe gate requires primary aggregate upper ratio<1 and at least10/15wins, plus every context upper≤1.03. All fail. Bounds use paired order ranks4–12/15, nominal marginal96.484375%conditional coverage without a family-wise guarantee. Marginal medians and paired medians need not divide identically. There is no gain floor, excluded block, sample extension, unchanged reroll, favorable subset or layout/width/segment rescue in this experiment.\n\n## CPU service, faults and memory\n\n| Raw shape | Workers | OFF CPU ms/pass | ON CPU ms/pass | OFF/ON maximum sampled process RSS MiB | OFF/ON median minor faults/pass |\n|---|---:|---:|---:|---:|---:|\n");
    for shape in ["1x2", "2x2"] {
        for workers in [1, 16, 32] {
            let name = format!("{shape}-w{workers}");
            let c = &a["cases"][&name];
            let faults = |label: &str| {
                let mut v = a["rows"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .filter(|row| {
                        row["job"]["panel"] == "latency"
                            && row["job"]["case"]["name"] == name
                            && row["job"]["variant"] == label
                    })
                    .map(|row| row["receipt"]["usage"]["minor_faults"].as_f64().unwrap() / 20.)
                    .collect::<Vec<_>>();
                assert_eq!(v.len(), 15);
                v.sort_by(f64::total_cmp);
                v[7]
            };
            writeln!(
                text,
                "| {shape} | {workers} | {:.3} | {:.3} | {:.2} / {:.2} | {:.2} / {:.2} |",
                c["control_CPU_ms"]["median"].as_f64().unwrap(),
                c["candidate_CPU_ms"]["median"].as_f64().unwrap(),
                c["control_max_process_RSS_MiB"].as_f64().unwrap(),
                c["candidate_max_process_RSS_MiB"].as_f64().unwrap(),
                faults("control"),
                faults("candidate")
            )
            .unwrap();
        }
    }
    text.push_str("\nRSS is the process high-water sampled at the end of the timed loop, including loading, oracle arrays and primes; it is not minimumRAM or a full prover peak. Minor faults are process rusage deltas over the warm measured loop. They usually service resident/anonymous mappings without storage I/O, but this measurement does not isolate their cause or prove that faults explain the latency. The new native coordinate and exported partial arrays overlap during export, with additional maps, records, generic merge workspace and allocator effects. The count-stage payload estimates were not a memory-neutral architecture claim.\n\n## Warm counters and profiles\n\nAfter all latency, four grouped stat panels and four separate cycles:u profiles run200passes after3excluded primes on primary1x2 at16/32workers. This diagnostic duration was frozen before capture; the latency pass count remains20. FIFO acknowledgements exclude loading/primes and post-checks. All stat events run100%; single panels remain descriptive.\n\n| Workers / arm | Cycles M/pass | Instructions M/pass | Generic cache misses M/pass | Branch misses M/pass |\n|---|---:|---:|---:|---:|\n");
    for workers in [16, 32] {
        for label in ["control", "candidate"] {
            let c =
                &a["counters"][format!("stat-1x2-w{workers}-{label}")]["per_ordinary_fill_pass"];
            writeln!(
                text,
                "| {workers} / {label} | {:.3} | {:.3} | {:.6} | {:.6} |",
                c["cycles:u"].as_f64().unwrap() / 1e6,
                c["instructions:u"].as_f64().unwrap() / 1e6,
                c["cache-misses:u"].as_f64().unwrap() / 1e6,
                c["branch-misses:u"].as_f64().unwrap() / 1e6
            )
            .unwrap();
        }
    }
    text.push_str("\nAt32workers, the candidate counter panel has16.86%more instructions and about6.08×the generic cache misses. These observations accompany higher CPU service and RSS; they do not isolate RAM bandwidth, a cache level or a causal fraction of the slowdown.\n\n| Profile | Samples | Unknown share | Lost records |\n|---|---:|---:|---:|\n");
    for workers in [16, 32] {
        for label in ["control", "candidate"] {
            let name = format!("cycles-1x2-w{workers}-{label}");
            let p = &a["profiles"][&name];
            writeln!(
                text,
                "| {workers} / {label} | {} | {:.3}% | 0 |",
                p["samples"],
                p["unknown_share"].as_f64().unwrap() * 100.
            )
            .unwrap();
        }
    }
    let symbols = read(r.join("symbols.json"));
    let selected = &symbols["cycles-1x2-w32-candidate"];
    let share = |predicate: &dyn Fn(&str) -> bool| {
        selected
            .as_array()
            .unwrap()
            .iter()
            .filter(|s| predicate(s["symbol"].as_str().unwrap()))
            .map(|s| s["share"].as_f64().unwrap())
            .sum::<f64>()
            * 100.
    };
    writeln!(text,"\nCandidate32flat sampled-period shares include{:.2}%in the column-fill defining function,{:.2}%in the generic partial-merge caller context and{:.2}%in sort-function contexts. This is consistent with substantial bookkeeping and merging around the saved codecs. The fill function itself also contains inlined metadata/field/memory work; these shares cannot isolate arithmetic or be subtracted as removable wall time. Three profiles have fewer than1000samples. All3288samples are tied to one expected executablePID per recording, with all sampledTIDs matched to actual workerFORK records, allowed CPUbounds, fixed16Mperiod and zero losses. Absolute period-to-wall coverage is not validated.\n",share(&|s|s=="zopro_core::msm_affine::borrowed_pending::columns::fill"),share(&|s|s.contains("group_affine_impl")),share(&|s|s.starts_with("core::slice::sort::"))).unwrap();
    text.push_str("\nThe actual linked candidate fill is27,615bytes/4,956static instruction sites. The control keeps a17,927byte wrapper and two stream dispatch alternatives (the canonical stream is26,127bytes/4,414sites). These contexts have different inlining/scope, so sizes or RSPoperand counts are not a matched dynamic cost or spill comparison. Actual binaries are hash-bound in the linked-code receipt.\n\n## Correctness, retained failures and provenance\n\nNative control passes125unfiltered core tests; candidate passes128, including3new generator-bucket, complete exception/skew/tail and1/4/32worker512KiB-stack tests.35unchanged base field tests passed once, and the two new field helper tests separately pass against Arkworks with those35filtered out. This is inherited35plus2new qualification, not a freshly repeated37-test suite. No standalone prover/portable suite or SDK proof trial is claimed.\n\nTwo new independent Arkworks real-input oracles validate all21,006/36,637input points and canonical scalars, then compute all43,008bucket outputs per shape. They reuse saved scalar caches, with zero new solves. Every process checks all buckets in3prime passes and1post-check. All200processes complete:6,012ordinary-fill passes including checks/primes,126,252individual window fills and34,406,400bucket comparisons. Timed intermediate passes are not individually checked. No new SDK proof request or independent export occurs; ledger remains27,353.\n\nInitial native preparation wrongly placed core's ifma8feature condition on the field child and omitted three FqBatchforwarders. Candidate core compilation failed before new helper or point tests ran. A separate corrected178-file snapshot removes that field-only condition and appends the forwarding methods. Original helper/filler arithmetic bodies are byte-identical;172accepted originals remain exact, with4append-only parents and2children. Successful control/base-field results are inherited; only unfinished/new tests and builds continue. Both snapshots and the compiler failure remain in evidence.\n\nAll200measurements completed before a read-only decoder encountered root-owned0600recordings. Ownership changed only on those four generated files after saving hashes, and every byte hash remained unchanged. The first resume reused all200processes but refused the already failed decoder directory. That directory was retained separately; a second resume reused all200again and executed only16read-only decoding commands. Final216stepresult is complete. No latency/profile/proof/test measurement repeats.\n\nIndependent review recomputes all six latency/CPU/RSS cells, paired bounds and failed gate from original command/exit/stdout/stderr receipts, all four grouped counter panels, every profile sample/symbol bin and workerPID/TID/CPUownership. It rechecks exact source/library/executable/oracle hashes and production176. No test, model, solve, capture or verifier is rerun by review.\n\n## Accepted proof comparison — inherited, unchanged\n\n");
    let previous = fs::read_to_string(
        Path::new(Z).join("docs/benchmarks/2026-10-30-g1-column-count176/README.md"),
    )
    .unwrap();
    let start = previous.find("| Shape | Zopro ms |").unwrap();
    let end = previous[start..].find("\n\n[Initial protocol]").unwrap() + start;
    text.push_str(&previous[start..end]);
    text.push_str("\n\nNo new AWS/Aeglos, phone/ARM/TEE, huge-circuit, pressure/swap, concurrent-proof or minimumRAM qualification follows. This result closes the exact all-columns/circular-wave implementation; a future distinct mechanism needs its own protocol and evidence.\n\n[Design](artifacts/design.md), [frozen capture protocol](artifacts/capture-design.md), [all observations](artifacts/analysis.json), [symbols](artifacts/symbols.json), [independent review](artifacts/review.json), [linked code](artifacts/codegen.json), [source audit](artifacts/source-audit-fixed.json), [preparation repair](artifacts/repair.md), [decode repair](artifacts/access-repair.md). Archives: [original private source](artifacts/source-initial.tar.gz), [corrected private source](artifacts/source-fixed.tar.gz), [workflow and helper sources](artifacts/workflow.tar.gz), [all command receipts](artifacts/receipts.tar.gz), [linked disassembly](artifacts/codegen.tar.gz). [Checksums](SHA256SUMS).\n\nRaw key/scalar/point/oracle arrays, executables, immutable libraries and perf.data remain local with recorded hashes. No private witness-derived point outputs are uploaded. Related: [structural screen](../2026-10-30-g1-column-count176/README.md), [accepted production](../2026-10-30-g2-vector-sign-adoption176/README.md).\n");
    fs::write(d.join("README.md"), text).unwrap();
    for (tree, name) in [
        ("source", "source-initial"),
        ("source-fixed", "source-fixed"),
    ] {
        archive(&d.join(format!("artifacts/{name}.tar.gz")), r, &[tree]);
    }
    archive(
        &d.join("artifacts/receipts.tar.gz"),
        r,
        &[
            "native",
            "native-fixed",
            "consumers",
            "runs",
            "decode-failed-access",
            "native.log",
            "native-fixed.log",
            "consumers.log",
            "capture.log",
            "capture-resume.log",
            "capture-decode-resume.log",
            "finish.log",
        ],
    );
    let mut names = vec![];
    for label in ["control", "candidate"] {
        names.push(format!("{label}.nm"));
        for f in read(r.join("codegen.json"))["variants"][label]["functions"]
            .as_array()
            .unwrap()
        {
            names.push(f["disassembly"].as_str().unwrap().into());
        }
    }
    let refs = names.iter().map(String::as_str).collect::<Vec<_>>();
    archive(&d.join("artifacts/codegen.tar.gz"), r, &refs);
    archive(
        &d.join("artifacts/workflow.tar.gz"),
        r,
        &[
            "setup.rs",
            "setup.log",
            "prepare-build.rs",
            "prepare-build.log",
            "repair-build.rs",
            "repair-build.log",
            "seal-fixed.rs",
            "seal-fixed.log",
            "native.rs",
            "native-fixed.rs",
            "native-flags.txt",
            "candidate-flags.txt",
            "source-audit.json",
            "source-audit-fixed.json",
            "build-plan.json",
            "build-pins.json",
            "build-plan-fixed.json",
            "build-pins-fixed.json",
            "column_lanes.rs",
            "columns.rs",
            "fixtures.rs",
            "oracle.rs",
            "driver.rs",
            "perf_support.rs",
            "prepare-consumers.rs",
            "prepare-consumers.log",
            "consumer-plan.json",
            "consumer-pins.json",
            "fixture-manifest.json",
            "frozen-control.json",
            "frozen-candidate.json",
            "frozen-control-cargo.jsonl",
            "frozen-candidate-cargo.jsonl",
            "codegen.rs",
            "codegen.log",
            "capture.rs",
            "capture-prepare.log",
            "capture-design.md",
            "capture-plan.json",
            "capture-pins.json",
            "jobs.json",
            "cases.json",
            "identities.json",
            "sampling.rs",
            "counter.rs",
            "review.rs",
            "review.log",
            "publish.rs",
            "design.md",
            "repair.md",
            "access-repair.md",
            "perf-before-access-repair.sha256",
        ],
    );
    let raw = read(r.join("review.json"))["profiles"].clone();
    fs::write(
        d.join("artifacts/retained-perf-hashes.json"),
        serde_json::to_vec_pretty(&raw).unwrap(),
    )
    .unwrap();
    let receipt = json!({"published":d,"adopted":false,"failed_gate":true,"new_proofs":0,"accepted_manifest_sha256":hash(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"))});
    fs::write(
        r.join("publication.json"),
        serde_json::to_vec_pretty(&receipt).unwrap(),
    )
    .unwrap();
    println!("Published complete negative native-column result;all8CPU+Metal unchanged;failedpreparation/decode repairs retained;production176unchanged");
}
