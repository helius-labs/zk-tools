use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::{BufRead, BufReader},
    path::{Path, PathBuf},
    process::{Command, Stdio},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g1-columns176";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn pin(p: &mut BTreeMap<String, String>, file: impl AsRef<Path>) {
    let f = file.as_ref();
    p.insert(f.display().to_string(), hash(f));
}
fn step(name: &str, argv: Value) -> Value {
    json!({"kind":"command","name":name,"argv":argv,"timeout_seconds":600})
}
include!("sampling.rs");
include!("counter.rs");
fn loss(data: &str) {
    let mut c = Command::new("perf")
        .args(["script", "-D", "-i", data])
        .stdout(Stdio::piped())
        .spawn()
        .unwrap();
    let mut lost = vec![];
    let mut lines = 0;
    for l in BufReader::new(c.stdout.take().unwrap()).lines() {
        let l = l.unwrap();
        lines += 1;
        if l.contains("PERF_RECORD_LOST") {
            lost.push(l);
        }
    }
    assert!(c.wait().unwrap().success());
    println!(
        "{}",
        json!({"zero_lost":lost.is_empty(),"records":lost,"lines":lines})
    );
}
fn add(
    c: &Value,
    label: &str,
    block: usize,
    panel: &str,
    env: &Value,
    ids: &Value,
    jobs: &mut Vec<Value>,
    steps: &mut Vec<Value>,
) {
    let name = if panel == "latency" {
        format!("b{block}-{}-{label}", c["name"].as_str().unwrap())
    } else {
        format!("{panel}-{}-{label}", c["name"].as_str().unwrap())
    };
    let rounds = match panel {
        "preflight" => 1,
        "latency" => 20,
        _ => 200,
    };
    let workers = c["workers"].as_u64().unwrap();
    let affinity = if workers == 1 {
        "2".into()
    } else {
        format!("0-{}", workers - 1)
    };
    let mut environment = env.clone();
    environment["RAYON_NUM_THREADS"] = json!(workers.to_string());
    let mut argv = vec![];
    let mut data = Value::Null;
    if panel == "stat" || panel == "cycles" {
        environment["ZOPRO_BENCH_PERF_CTL"] = json!(r("ctl"));
        environment["ZOPRO_BENCH_PERF_ACK"] = json!(r("ack"));
        argv.extend(["sudo".to_string(), "-n".into(), "env".into()]);
        for (k, v) in environment.as_object().unwrap() {
            argv.push(format!("{k}={}", v.as_str().unwrap()));
        }
        argv.push("perf".into());
        if panel == "stat" {
            let file = r("stat").join(format!("{name}.csv"));
            data = json!(file);
            argv.extend([
                "stat".into(),
                "--no-big-num".into(),
                "-x".into(),
                ";".into(),
                "-e".into(),
                "{cycles:u,instructions:u,cache-misses:u,branch-misses:u}".into(),
                "-o".into(),
                file.display().to_string(),
            ]);
        } else {
            let file = r("perf").join(format!("{name}.data"));
            data = json!(file);
            argv.extend([
                "record".into(),
                "--no-buildid-cache".into(),
                "--sample-cpu".into(),
                "--timestamp".into(),
                "-P".into(),
                "-e".into(),
                "cycles:u".into(),
                "-c".into(),
                "16000000".into(),
                "-m".into(),
                "512".into(),
                "-o".into(),
                file.display().to_string(),
            ]);
        }
        argv.extend([
            "--delay=-1".into(),
            format!(
                "--control=fifo:{},{}",
                r("ctl").display(),
                r("ack").display()
            ),
            "--".into(),
        ]);
    }
    argv.extend([
        "taskset".into(),
        "-c".into(),
        affinity,
        ids[label]["binary"].as_str().unwrap().into(),
        c["fixture"].as_str().unwrap().into(),
        c["expected"].as_str().unwrap().into(),
        workers.to_string(),
        rounds.to_string(),
    ]);
    let mut s = step(&name, json!(argv));
    if panel == "latency" || panel == "preflight" {
        s["environment"] = environment;
    }
    steps.push(s);
    jobs.push(json!({"name":name,"case":c,"variant":label,"block":block,"panel":panel,"rounds":rounds,"data":data,"binary":ids[label]["binary"]}));
}
fn prepare() {
    assert!(!r("capture-plan.json").exists());
    assert_eq!(read(r("consumers/result.json"))["status"], "complete");
    assert_eq!(
        read(r("codegen.json"))["warrants_complete_filler_timing"],
        true
    );
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(read(r("consumer-pins.json"))).unwrap();
    for (p, h) in &pins {
        assert_eq!(hash(p), *h);
    }
    let mut ids = serde_json::Map::new();
    for label in ["control", "candidate"] {
        let a = read(r(format!("consumers/{label}/artifacts.json")));
        assert_eq!(hash(a["binary"].as_str().unwrap()), a["binary_sha256"]);
        for (p, h) in a["input_pins"].as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
            pin(&mut pins, p);
        }
        pin(&mut pins, a["binary"].as_str().unwrap());
        pin(&mut pins, r(format!("consumers/{label}/artifacts.json")));
        ids.insert(label.into(), a);
    }
    let ids = Value::Object(ids);
    save(r("identities.json"), &ids);
    let mut cases = vec![];
    for (shape, n) in [("1x2", 21006), ("2x2", 36637)] {
        let oracle = read(r(format!("consumers/oracle-{shape}/stdout.log")));
        let fixture = r(format!("inputs/{shape}.a1q"));
        let expected = r(format!("inputs/{shape}.expected"));
        assert_eq!(hash(&fixture), oracle["fixture_sha256"]);
        assert_eq!(hash(&expected), oracle["expected_sha256"]);
        for k in [
            "all_points_on_curve",
            "all_points_in_prime_subgroup",
            "all_scalars_canonical",
            "independent_Arkworks_projective_bucket_sums",
        ] {
            assert_eq!(oracle[k], true);
        }
        for p in [
            fixture.clone(),
            expected.clone(),
            r(format!("consumers/oracle-{shape}/stdout.log")),
        ] {
            pin(&mut pins, p);
        }
        for workers in [1, 16, 32] {
            cases.push(json!({"name":format!("{shape}-w{workers}"),"shape":shape,"points":n,"workers":workers,"fixture":fixture,"expected":expected}));
        }
    }
    let mut env = read(r("consumer-plan.json"))["steps"][1]["environment"].clone();
    env["RAYON_NUM_THREADS"] = json!("1");
    for dir in ["stat", "perf"] {
        fs::create_dir(r(dir)).unwrap();
    }
    for name in ["ctl", "ack"] {
        assert!(Command::new("mkfifo")
            .arg(r(name))
            .status()
            .unwrap()
            .success());
    }
    let (mut jobs, mut steps) = (vec![], vec![]);
    for c in &cases {
        for label in ["control", "candidate"] {
            add(c, label, 0, "preflight", &env, &ids, &mut jobs, &mut steps);
        }
    }
    for b in 0..15 {
        let mut order = (0..6).collect::<Vec<_>>();
        order.rotate_left(b % 6);
        if b % 2 == 1 {
            order.reverse();
        }
        let variants = if b % 2 == 0 {
            ["control", "candidate"]
        } else {
            ["candidate", "control"]
        };
        for i in order {
            for label in variants {
                add(
                    &cases[i], label, b, "latency", &env, &ids, &mut jobs, &mut steps,
                );
            }
        }
    }
    for panel in ["stat", "cycles"] {
        for workers in [16, 32] {
            let c = cases
                .iter()
                .find(|c| c["shape"] == "1x2" && c["workers"] == workers)
                .unwrap();
            for label in ["control", "candidate"] {
                add(c, label, 0, panel, &env, &ids, &mut jobs, &mut steps);
            }
        }
    }
    assert_eq!(jobs.len(), 200);
    for j in jobs.iter().filter(|j| j["panel"] == "cycles") {
        let name = j["name"].as_str().unwrap();
        let file = j["data"].as_str().unwrap();
        for (kind, argv) in [
            ("events", json!(["perf", "evlist", "-v", "-i", file])),
            ("loss", json!([r("capture"), "loss", file])),
            (
                "decode",
                json!([
                    "perf",
                    "script",
                    "--ns",
                    "-i",
                    file,
                    "-F",
                    "pid,tid,cpu,time,period,ip,sym"
                ]),
            ),
            (
                "metadata",
                json!([
                    "perf",
                    "script",
                    "--header",
                    "--show-mmap-events",
                    "--show-task-events",
                    "--ns",
                    "-i",
                    file,
                    "-F",
                    "pid,tid,cpu,time,period,ip,sym"
                ]),
            ),
        ] {
            steps.push(step(&format!("{kind}-{name}"), argv));
        }
    }
    assert_eq!(steps.len(), 216);
    save(r("jobs.json"), &json!(jobs));
    save(r("cases.json"), &json!(cases));
    for n in [
        "capture.rs",
        "capture",
        "capture-design.md",
        "sampling.rs",
        "counter.rs",
        "codegen.rs",
        "codegen",
        "codegen.json",
        "control.nm",
        "candidate.nm",
        "identities.json",
        "jobs.json",
        "cases.json",
    ] {
        pin(&mut pins, r(n));
    }
    for label in ["control", "candidate"] {
        for f in read(r("codegen.json"))["variants"][label]["functions"]
            .as_array()
            .unwrap()
        {
            pin(&mut pins, r(f["disassembly"].as_str().unwrap()));
        }
    }
    save(r("capture-pins.json"), &json!(pins));
    save(
        r("capture-plan.json"),
        &json!({"version":1,"source_pins":r("capture-pins.json"),"steps":steps}),
    );
    println!("Frozen216steps/200processes;12preflight/180latency/8warmprofiles;15fixedblocks;all21ordinarywindows included;no proof timing");
}
fn stats(values: &[f64]) -> Value {
    assert_eq!(values.len(), 15);
    let mut sorted = values.to_vec();
    assert!(sorted.iter().all(|&v| v > 0. && v.is_finite()));
    sorted.sort_by(f64::total_cmp);
    json!({"median":sorted[7],"lower":sorted[3],"upper":sorted[11],"wins":values.iter().filter(|&&v|v<1.).count(),"blocks":15,"values":values})
}
fn finish() {
    assert!(!r("analysis.json").exists());
    assert_eq!(read(r("runs/result.json"))["status"], "complete");
    for (p, h) in read(r("capture-pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let jobs = read(r("jobs.json"));
    let mut rows = vec![];
    let mut values = BTreeMap::<(String, String, usize), f64>::new();
    let mut cpu = BTreeMap::<(String, String, usize), f64>::new();
    let mut rss = BTreeMap::<(String, String), f64>::new();
    let (mut total_passes, mut checked) = (0u64, 0u64);
    let mut counters = BTreeMap::new();
    let mut profiles = BTreeMap::new();
    let mut symbols = BTreeMap::new();
    for j in jobs.as_array().unwrap() {
        let n = j["name"].as_str().unwrap();
        let text = fs::read_to_string(r(format!("runs/{n}/stdout.log"))).unwrap();
        let records = text
            .lines()
            .filter_map(|l| l.strip_prefix("CALLER "))
            .collect::<Vec<_>>();
        assert_eq!(records.len(), 1);
        let a: Value = serde_json::from_str(records[0]).unwrap();
        let rounds = j["rounds"].as_u64().unwrap();
        assert_eq!(a["workers"], j["case"]["workers"]);
        assert_eq!(a["input_rows"], j["case"]["points"]);
        assert_eq!(a["timed_passes"], rounds);
        assert_eq!(a["candidate"], j["variant"] == "candidate");
        assert_eq!(
            a["all_prime_and_post_buckets_match_independent_oracle"],
            true
        );
        assert_eq!(a["allocation_and_drop_inside_timer"], true);
        assert_eq!(a["new_proofs"], 0);
        assert_eq!(a["checked_bucket_outputs"], 4 * 21 * 2048);
        assert_eq!(a["timed_fills"], rounds * 21);
        assert_eq!(a["priming_passes"], 3);
        assert_eq!(a["postcheck_passes"], 1);
        total_passes += rounds + 4;
        checked += 4 * 21 * 2048;
        if j["panel"] == "latency" {
            let case = j["case"]["name"].as_str().unwrap();
            let label = j["variant"].as_str().unwrap();
            let b = j["block"].as_u64().unwrap() as usize;
            let ns = a["elapsed_ns"].as_f64().unwrap() / rounds as f64;
            assert_eq!(
                a["ns_per_complete_ordinary_fill_pass"].as_f64().unwrap(),
                ns
            );
            assert!(values.insert((case.into(), label.into(), b), ns).is_none());
            let c = (a["usage"]["user_cpu_ms"].as_f64().unwrap()
                + a["usage"]["system_cpu_ms"].as_f64().unwrap())
                / rounds as f64;
            cpu.insert((case.into(), label.into(), b), c);
            let peak = a["usage"]["whole_process_maxrss_kib"].as_f64().unwrap() / 1024.;
            let e = rss.entry((case.into(), label.into())).or_insert(0.);
            *e = e.max(peak);
        }
        if j["panel"] == "stat" {
            let events = fs::read_to_string(j["data"].as_str().unwrap())
                .unwrap()
                .lines()
                .filter_map(event_line)
                .collect::<BTreeMap<_, _>>();
            let mut per = BTreeMap::new();
            for k in [
                "cycles:u",
                "instructions:u",
                "cache-misses:u",
                "branch-misses:u",
            ] {
                assert!(events.contains_key(k));
                per.insert(k, events[k]["count"].as_f64().map(|v| v / rounds as f64));
            }
            counters.insert(n,json!({"events":events,"per_ordinary_fill_pass":per,"qualified":events.values().all(|v|v["qualified"]==true)}));
        }
        if j["panel"] == "cycles" {
            let attributes = fs::read_to_string(r(format!("runs/events-{n}/stdout.log"))).unwrap();
            for needle in ["cycles:u", "16000000", "CPU", "TIME", "PERIOD"] {
                assert!(attributes.contains(needle));
            }
            assert!(!attributes.contains("freq: 1"));
            assert_eq!(
                read(r(format!("runs/loss-{n}/stdout.log")))["zero_lost"],
                true
            );
            let metadata = fs::read_to_string(r(format!("runs/metadata-{n}/stdout.log"))).unwrap();
            assert!(metadata.contains("PERF_RECORD_FORK"));
            assert!(metadata.contains("PERF_RECORD_COMM"));
            let mut pids = BTreeSet::new();
            let mut tids = BTreeSet::new();
            let mut sym = BTreeMap::<String, (u64, u64)>::new();
            let mut samples = 0u64;
            let mut period = 0u64;
            for (p, t, cpu, weight, name) in
                fs::read_to_string(r(format!("runs/decode-{n}/stdout.log")))
                    .unwrap()
                    .lines()
                    .filter_map(sample)
            {
                assert!(cpu < j["case"]["workers"].as_u64().unwrap() as u32);
                assert_eq!(weight, 16000000);
                pids.insert(p);
                tids.insert(t);
                samples += 1;
                period += weight;
                let v = sym.entry(name).or_default();
                v.0 += 1;
                v.1 += weight;
            }
            assert_eq!(pids.len(), 1);
            assert!(samples > 0);
            assert!(tids.len() <= j["case"]["workers"].as_u64().unwrap() as usize + 1);
            let pid = *pids.first().unwrap();
            assert!(metadata.lines().any(|l| l.contains("PERF_RECORD_MMAP")
                && l.contains(j["binary"].as_str().unwrap())
                && l.contains(&format!("{pid}/{pid}"))));
            let unknown = sym
                .iter()
                .filter(|(n, _)| n.starts_with("[unknown]"))
                .map(|(_, (_, p))| *p)
                .sum::<u64>() as f64
                / period as f64;
            let mut sorted=sym.iter().map(|(n,(s,p))|json!({"symbol":n,"samples":s,"period":p,"share":*p as f64/period as f64})).collect::<Vec<_>>();
            sorted.sort_by(|a, b| b["period"].as_u64().cmp(&a["period"].as_u64()));
            symbols.insert(n, sorted);
            profiles.insert(n,json!({"samples":samples,"sampled_period":period,"PID":pid,"sampled_TIDs":tids,"unknown_share":unknown,"zero_lost":true,"binary_MMAP_PID_matches":true,"affinity_bounds_pass":true,"period16M":true,"small_sample_context":samples<1000,"absolute_period_coverage_not_validated":true}));
        }
        rows.push(
            json!({"job":j,"receipt":a,"stdout_sha256":hash(r(format!("runs/{n}/stdout.log")))}),
        );
    }
    let mut cases = BTreeMap::new();
    let mut primary = vec![0f64; 15];
    let mut all_contexts = true;
    for c in read(r("cases.json")).as_array().unwrap() {
        let name = c["name"].as_str().unwrap();
        let get = |map: &BTreeMap<(String, String, usize), f64>, label: &str| {
            (0..15)
                .map(|b| map[&(name.into(), label.into(), b)])
                .collect::<Vec<_>>()
        };
        let off = get(&values, "control");
        let on = get(&values, "candidate");
        let ratio = on.iter().zip(&off).map(|(a, b)| a / b).collect::<Vec<_>>();
        if c["workers"] == 32 {
            for (b, x) in ratio.iter().enumerate() {
                primary[b] += x.ln() / 2.;
            }
        }
        let pair = stats(&ratio);
        all_contexts &= pair["upper"].as_f64().unwrap() <= 1.03;
        cases.insert(name.to_string(),json!({"control_ns":stats(&off),"candidate_ns":stats(&on),"candidate_over_control":pair,"control_CPU_ms":stats(&get(&cpu,"control")),"candidate_CPU_ms":stats(&get(&cpu,"candidate")),"control_max_process_RSS_MiB":rss[&(name.into(),"control".into())],"candidate_max_process_RSS_MiB":rss[&(name.into(),"candidate".into())]}));
    }
    let primary = stats(&primary.iter().map(|v| v.exp()).collect::<Vec<_>>());
    let gate = primary["upper"].as_f64().unwrap() < 1.
        && primary["wins"].as_u64().unwrap() >= 10
        && all_contexts;
    assert_eq!(rows.len(), 200);
    assert_eq!(total_passes, 6012);
    assert_eq!(checked, 34406400);
    save(r("symbols.json"), &json!(symbols));
    save(
        r("analysis.json"),
        &json!({"cases":cases,"primary_equal_log_32":primary,"all_context_upper_le_1_03":all_contexts,"caller_gate_passed":gate,"counters":counters,"profiles":profiles,"workflow_steps":216,"caller_processes":200,"complete_ordinary_fill_passes_including_primes_and_checks":total_passes,"individual_window_fills":total_passes*21,"checked_prime_and_post_bucket_outputs":checked,"new_proofs":0,"verified_ledger_unchanged":27353,"rows":rows}),
    );
    println!("Wholefiller gate={gate};200processes/126252windowfills/34406400prime+postbucketchecks;0proofs");
}
fn main() {
    let a = std::env::args().collect::<Vec<_>>();
    match a.get(1).map(String::as_str) {
        Some("prepare") => prepare(),
        Some("finish") => finish(),
        Some("loss") => loss(&a[2]),
        _ => panic!("prepare/finish/loss"),
    }
}
