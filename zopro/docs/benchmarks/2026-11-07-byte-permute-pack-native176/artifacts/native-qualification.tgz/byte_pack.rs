//! Pack eight initialized 256-bit words into normalized radix-52 vectors.
use crate::{ifma8::Ifma8, FpConfig};
use core::{arch::x86_64::*, marker::PhantomData};

// Each source pair contains eight 16-byte rows. Masked-off selectors still
// name initialized register bytes; masks supply the required zero padding.
const fn indices(offset: usize, first: usize, count: usize) -> [u8; 64] {
    let mut out = [0u8; 64];
    let mut i = 0;
    while i < 8 {
        let mut j = 0;
        while j < count {
            out[i * 8 + first + j] = (i * 16 + offset + j) as u8;
            j += 1;
        }
        i += 1;
    }
    out
}
const INDEX0: [u8; 64] = indices(0, 0, 8);
const INDEX6: [u8; 64] = indices(6, 0, 8);
const INDEX13: [u8; 64] = indices(13, 0, 3);
const INDEX_MIDDLE_HIGH: [u8; 64] = indices(0, 3, 5);
const INDEX3: [u8; 64] = indices(3, 0, 8);
const INDEX10: [u8; 64] = indices(10, 0, 6);

#[inline(always)]
pub(crate) fn raw<C: FpConfig, const MIXED: bool>(x: &[[u64; 4]; 8]) -> Ifma8<C, MIXED> {
    // SAFETY: x contains exactly256 initialized bytes. Four unaligned loads
    // cover it exactly. All later operations select initialized register
    // bytes, without accessing memory through a computed selector.
    unsafe {
        let p = x.as_ptr().cast::<__m512i>();
        let r0 = _mm512_loadu_si512(p);
        let r1 = _mm512_loadu_si512(p.add(1));
        let r2 = _mm512_loadu_si512(p.add(2));
        let r3 = _mm512_loadu_si512(p.add(3));
        let a = _mm512_shuffle_i64x2::<0x88>(r0, r1);
        let b = _mm512_shuffle_i64x2::<0x88>(r2, r3);
        let c = _mm512_shuffle_i64x2::<0xdd>(r0, r1);
        let d = _mm512_shuffle_i64x2::<0xdd>(r2, r3);
        let mask = _mm512_set1_epi64((1i64 << 52) - 1);
        let i0 = _mm512_loadu_si512(INDEX0.as_ptr().cast());
        let i6 = _mm512_loadu_si512(INDEX6.as_ptr().cast());
        let i13 = _mm512_loadu_si512(INDEX13.as_ptr().cast());
        let im = _mm512_loadu_si512(INDEX_MIDDLE_HIGH.as_ptr().cast());
        let i3 = _mm512_loadu_si512(INDEX3.as_ptr().cast());
        let i10 = _mm512_loadu_si512(INDEX10.as_ptr().cast());
        let t0 = _mm512_and_si512(_mm512_permutex2var_epi8(a, i0, b), mask);
        let t1 = _mm512_and_si512(
            _mm512_srli_epi64::<4>(_mm512_permutex2var_epi8(a, i6, b)),
            mask,
        );
        let low = _mm512_maskz_permutex2var_epi8(0x0707_0707_0707_0707, a, i13, b);
        let high = _mm512_maskz_permutex2var_epi8(0xf8f8_f8f8_f8f8_f8f8, c, im, d);
        let t2 = _mm512_and_si512(_mm512_or_si512(low, high), mask);
        let t3 = _mm512_and_si512(
            _mm512_srli_epi64::<4>(_mm512_permutex2var_epi8(c, i3, d)),
            mask,
        );
        let t4 = _mm512_maskz_permutex2var_epi8(0x3f3f_3f3f_3f3f_3f3f, c, i10, d);
        Ifma8([t0, t1, t2, t3, t4], PhantomData)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Fp, FqConfig, FrConfig};
    use ark_ff::{Field, PrimeField};
    fn next(s: &mut u64) -> u64 {
        *s ^= *s << 13;
        *s ^= *s >> 7;
        *s ^= *s << 17;
        *s
    }
    fn bit_reference(x: &[[u64; 4]; 8]) -> [[u64; 8]; 5] {
        core::array::from_fn(|j| {
            core::array::from_fn(|i| {
                let mut out = 0;
                for b in 0..52 {
                    let k = j * 52 + b;
                    if k < 256 {
                        out |= ((x[i][k / 64] >> (k % 64)) & 1) << b;
                    }
                }
                out
            })
        })
    }
    fn check_words<C: FpConfig, const MIXED: bool>(x: [[u64; 4]; 8]) {
        let got = raw::<C, MIXED>(&x).0.map(|v| {
            // SAFETY: both types have exactly512 initialized bits.
            unsafe { core::mem::transmute::<__m512i, [u64; 8]>(v) }
        });
        assert_eq!(got, bit_reference(&x));
    }
    fn basis<C: FpConfig, const MIXED: bool>() {
        check_words::<C, MIXED>([[0; 4]; 8]);
        check_words::<C, MIXED>([[u64::MAX; 4]; 8]);
        for lane in 0..8 {
            for bit in 0..256 {
                let mut x = [[0; 4]; 8];
                x[lane][bit / 64] = 1u64 << (bit % 64);
                check_words::<C, MIXED>(x);
            }
        }
        for rotation in 0..8 {
            let x = core::array::from_fn(|i| {
                core::array::from_fn(|j| {
                    0x0706_0504_0302_0100u64.wrapping_mul(((i + rotation) % 8 * 4 + j + 1) as u64)
                })
            });
            check_words::<C, MIXED>(x);
        }
        let mut seed = 0x4c87_9bd0_35a2_f169;
        for _ in 0..4096 {
            check_words::<C, MIXED>(core::array::from_fn(|_| {
                core::array::from_fn(|_| next(&mut seed))
            }));
        }
    }
    #[test]
    fn every_input_bit_and_lane_matches_independent_reader() {
        basis::<FqConfig, true>();
        basis::<FqConfig, false>();
        basis::<FrConfig, true>();
        basis::<FrConfig, false>();
    }
    fn bytes(x: [u64; 4]) -> [u8; 32] {
        let mut b = [0; 32];
        for i in 0..4 {
            b[i * 8..i * 8 + 8].copy_from_slice(&x[i].to_le_bytes());
        }
        b
    }
    fn public<C: FpConfig, A: PrimeField, const MIXED: bool>() {
        let mut seed = 0x81ac_d439_2e7f_b065;
        let mut random = || {
            let mut data = [0u8; 64];
            for chunk in data.chunks_mut(8) {
                chunk.copy_from_slice(&next(&mut seed).to_le_bytes());
            }
            let value = Fp::<C>::from_random_bytes(&data);
            let expected = A::from_le_bytes_mod_order(&data);
            assert_eq!(
                A::from_le_bytes_mod_order(&bytes(value.to_canonical())),
                expected
            );
            value
        };
        for round in 0..1024 {
            let a = core::array::from_fn(|i| match (round + i) % 257 {
                0 => Fp::<C>::ZERO,
                1 => Fp::<C>::ONE,
                2 => -Fp::<C>::ONE,
                _ => random(),
            });
            let b = core::array::from_fn(|_| random());
            let av = Ifma8::<C, MIXED>::new(&a);
            let bv = Ifma8::<C, MIXED>::new(&b);
            assert_eq!(av.get(), a);
            assert_eq!(bv.get(), b);
            let result = av.mul(&bv).get();
            for i in 0..8 {
                let ar = A::from_le_bytes_mod_order(&bytes(a[i].to_canonical()));
                let br = A::from_le_bytes_mod_order(&bytes(b[i].to_canonical()));
                assert_eq!(
                    A::from_le_bytes_mod_order(&bytes(result[i].to_canonical())),
                    ar * br
                );
            }
        }
    }
    #[test]
    fn both_primes_radices_public_constructors_and_products() {
        public::<FqConfig, ark_ref::Fq, true>();
        public::<FqConfig, ark_ref::Fq, false>();
        public::<FrConfig, ark_ref::Fr, true>();
        public::<FrConfig, ark_ref::Fr, false>();
    }
}
