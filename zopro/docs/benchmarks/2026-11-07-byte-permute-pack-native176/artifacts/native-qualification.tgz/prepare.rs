use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/byte-permute-pack176";
const P: &str = "/home/ubuntu/src/zk-tools/zopro";
const MANIFEST:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json";
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let r = Path::new(R);
    let source = r.join("source");
    assert!(!source.exists());
    fs::create_dir(&source).unwrap();
    let manifest: Value = serde_json::from_slice(&fs::read(MANIFEST).unwrap()).unwrap();
    assert_eq!(
        manifest["source_files_sha256"].as_object().unwrap().len(),
        176
    );
    for (name, h) in manifest["source_files_sha256"].as_object().unwrap() {
        let p = Path::new(P).join(name);
        assert_eq!(hash(&p), h.as_str().unwrap());
        let dest = source.join(name);
        fs::create_dir_all(dest.parent().unwrap()).unwrap();
        fs::copy(p, dest).unwrap();
    }
    let generator = source.join("scripts/ifma8.py");
    let text = fs::read_to_string(&generator).unwrap();
    let needle = "    fn raw(x: &[[u64; 4]; 8]) -> Self {\n";
    assert_eq!(text.matches(needle).count(), 1);
    let changed=text.replace(needle,&format!("{needle}        #[cfg(all(zopro_vbmi_pack,target_feature=\"avx512vbmi\"))]\n        {{ return crate::byte_pack::raw::<C,MIXED>(x); }}\n"));
    let needle="        // SAFETY: the input is 256 initialized bytes; loads are unaligned.\n        // All permutations address lanes in the two supplied vectors.\n        unsafe {";
    assert_eq!(changed.matches(needle).count(), 1);
    let changed=changed.replace(needle,"        // SAFETY: the input is 256 initialized bytes; loads are unaligned.\n        // All permutations address lanes in the two supplied vectors.\n        #[cfg(not(all(zopro_vbmi_pack,target_feature=\"avx512vbmi\")))]\n        unsafe {");
    fs::write(generator, changed).unwrap();
    let lib = source.join("crates/zopro-bn254/src/lib.rs");
    let mut text = fs::read_to_string(&lib).unwrap();
    text.push_str("\n#[cfg(all(any(zopro_vbmi_pack,test),target_arch=\"x86_64\",target_feature=\"avx512vbmi\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma)))]\nmod byte_pack;\n");
    fs::write(lib, text).unwrap();
    fs::write(
        source.join("crates/zopro-bn254/src/byte_pack.rs"),
        include_str!("byte_pack.rs"),
    )
    .unwrap();
    let mut pins = BTreeMap::new();
    for p in [
        MANIFEST,
        &format!("{R}/design.md"),
        &format!("{R}/byte_pack.rs"),
        &format!("{R}/prepare.rs"),
    ] {
        pins.insert(p.to_owned(), hash(p));
    }
    fs::write(
        r.join("preparation-inputs.json"),
        serde_json::to_vec_pretty(&pins).unwrap(),
    )
    .unwrap();
    fs::write(r.join("preparation.json"),serde_json::to_vec_pretty(&json!({"accepted_files_checked":176,"new_source_files":177,"changed_parents_before_generation":2,"generator_executed":false,"native_calls":0,"timings":0,"extra_heap_bytes":0,"fixed_mask_payload_bytes":384})).unwrap()).unwrap();
    println!("prepared accepted176 + byte-permutation child and cfg generator hook");
}
