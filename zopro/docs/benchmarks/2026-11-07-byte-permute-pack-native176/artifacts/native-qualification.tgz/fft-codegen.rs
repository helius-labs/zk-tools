use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/byte-permute-pack176";
fn p(s: &str) -> String {
    format!("{R}/{s}")
}
fn load(s: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(s).unwrap()).unwrap()
}
fn save(s: impl AsRef<Path>, v: &Value) {
    assert!(!s.as_ref().exists());
    fs::write(s, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn hash(s: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(s).unwrap()))
}
fn exit(dir: &str) {
    let e = load(format!("{dir}/exit.json"));
    assert_eq!(e["success"], true);
    assert_eq!(e["returncode"], 0);
    for s in ["stdout", "stderr"] {
        assert_eq!(
            hash(format!("{dir}/{s}.log")),
            e[format!("{s}_sha256")].as_str().unwrap()
        );
    }
}
fn prepare() {
    let source = fs::read_to_string(p("source-fixed/crates/zopro-core/src/fft/pair.rs")).unwrap();
    assert!(source.contains("fn stored_column_leaf<S: PairStorage, const FORWARD: bool>"));
    let mut pins = load(p("codegen-pins.json"));
    let mut jobs = vec![];
    let mut steps = vec![];
    for arm in ["OFF", "ON"] {
        let dir = p(&format!("nm-runs/nm-{arm}"));
        exit(&dir);
        let mut found = BTreeMap::new();
        for l in fs::read_to_string(format!("{dir}/stdout.log"))
            .unwrap()
            .lines()
        {
            let f = l.split_whitespace().collect::<Vec<_>>();
            if f.len() != 4 {
                continue;
            }
            let name = format!("{:#}", rustc_demangle::demangle(f[3]));
            if !name.starts_with("zopro_core::fft::pair::stored_column_leaf::<")
                || !name.contains("PackedIfma8<zopro_bn254::FrConfig>")
            {
                continue;
            }
            let direction = if name.ends_with(", true>") {
                "forward"
            } else if name.ends_with(", false>") {
                "inverse"
            } else {
                panic!("unexpected direction {name}")
            };
            let address = u64::from_str_radix(f[0], 16).unwrap();
            let size = u64::from_str_radix(f[1], 16).unwrap();
            let job = json!({"arm":arm,"kind":format!("FFT-{direction}"),"name":format!("fft-decode-{direction}-{arm}"),"symbol":f[3],"demangled":name,"address":address,"size_bytes":size,"binary":p(&format!("sdk-build/{arm}-sdk"))});
            assert!(found.insert(direction.to_owned(), job).is_none());
        }
        assert_eq!(found.len(), 2);
        for job in found.into_values() {
            steps.push(json!({"kind":"command","name":job["name"],"argv":["/usr/bin/objdump","-d","-M","intel","--no-show-raw-insn",format!("--disassemble={}",job["symbol"].as_str().unwrap()),job["binary"]],"timeout_seconds":120}));
            jobs.push(job);
        }
    }
    for s in [
        p("fft-codegen.rs"),
        p("fft-codegen"),
        p("source-fixed/crates/zopro-core/src/fft/pair.rs"),
        p("codegen-analysis.json"),
    ] {
        pins[&s] = hash(&s).into();
    }
    save(p("fft-codegen-pins.json"), &pins);
    save(p("fft-codegen-jobs.json"), &json!(jobs));
    save(
        p("fft-decode-plan.json"),
        &json!({"version":1,"source_pins":p("fft-codegen-pins.json"),"steps":steps}),
    );
    println!("selected four FFT direction consumers from existing nm; no repeated nm or decode");
}
fn analyze() {
    let jobs = load(p("fft-codegen-jobs.json"));
    assert_eq!(jobs.as_array().unwrap().len(), 4);
    assert_eq!(load(p("fft-decode-runs/result.json"))["status"], "complete");
    let mut base = load(p("codegen-analysis.json"));
    let plan = load(p("fft-decode-plan.json"));
    for job in jobs.as_array().unwrap() {
        let dir = p(&format!(
            "fft-decode-runs/{}",
            job["name"].as_str().unwrap()
        ));
        exit(&dir);
        let step = plan["steps"]
            .as_array()
            .unwrap()
            .iter()
            .find(|s| s["name"] == job["name"])
            .unwrap();
        let command = load(format!("{dir}/command.json"));
        let a = command["argv"].as_array().unwrap();
        let b = step["argv"].as_array().unwrap();
        assert_eq!(&a[a.len() - b.len()..], b);
        let start = job["address"].as_u64().unwrap();
        let end = start + job["size_bytes"].as_u64().unwrap();
        let raw = fs::read_to_string(format!("{dir}/stdout.log")).unwrap();
        let mut ins = vec![];
        for l in raw.lines() {
            if let Some((ip, s)) = l.split_once(':') {
                if let Ok(ip) = u64::from_str_radix(ip.trim(), 16) {
                    if (start..end).contains(&ip) {
                        ins.push(s.trim().to_owned());
                    }
                }
            }
        }
        assert!(!ins.is_empty());
        let mut sub = 0u64;
        let mut probe = 0u64;
        let mut skip = false;
        let mut prologue = vec![];
        for l in &ins {
            if l.starts_with("vmov") {
                break;
            }
            prologue.push(l.clone());
            if let Some(v) = l.strip_prefix("sub    r11,0x") {
                probe = u64::from_str_radix(v, 16).unwrap();
                sub += probe;
                skip = true;
            }
            if let Some(v) = l.strip_prefix("sub    rsp,0x") {
                let n = u64::from_str_radix(v, 16).unwrap();
                if skip && n == 4096 {
                    skip = false
                } else {
                    sub += n;
                }
            }
        }
        let key = format!(
            "{}-{}",
            job["kind"].as_str().unwrap(),
            job["arm"].as_str().unwrap()
        );
        assert!(base["rows"].get(&key).is_none());
        base["rows"][&key] = json!({"job":job,"instructions":ins.len(),"IFMA_sites":ins.iter().filter(|s|s.starts_with("vpmadd52")).count(),"byte_permutation_sites":ins.iter().filter(|s|s.starts_with("vpermi2b ")||s.starts_with("vpermt2b ")||s.starts_with("vpermb ")).count(),"ZMM_stack_operand_rows":ins.iter().filter(|s|s.contains("ZMMWORD PTR [rsp")||s.contains("ZMMWORD PTR [rbp")).count(),"ZMM_stack_store_rows":ins.iter().filter(|s|s.split_once(',').map(|(dst,_)|dst.contains("ZMMWORD PTR [rsp")||dst.contains("ZMMWORD PTR [rbp")).unwrap_or(false)).count(),"calls":ins.iter().filter(|s|s.starts_with("call ")).cloned().collect::<Vec<_>>(),"prologue_rsp_subtraction_bytes":sub,"stack_probe_bytes":probe,"prologue":prologue,"binary_sha256":hash(job["binary"].as_str().unwrap()),"decode_sha256":hash(format!("{dir}/stdout.log"))});
    }
    base["FFT_selection_repair"] = json!({"original_optional_selector_assumed_field_radix":true,"actual_parameter":"const FORWARD: bool","source_checked":p("source-fixed/crates/zopro-core/src/fft/pair.rs"),"earlier_six_decodes_reused_exact":true,"additional_decodes":4,"nm_repeated":false});
    base["total_decodes"] = 10.into();
    save(p("codegen-complete-analysis.json"), &base);
    println!("complete ten-consumer analysis; six prior decodes reused, four FFT decodes added");
}
fn main() {
    match std::env::args().nth(1).as_deref() {
        Some("prepare") => prepare(),
        Some("analyze") => analyze(),
        _ => panic!("prepare|analyze"),
    }
}
