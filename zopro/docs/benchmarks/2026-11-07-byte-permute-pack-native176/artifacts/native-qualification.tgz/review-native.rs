use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/byte-permute-pack176";
const P: &str = "/home/ubuntu/src/zk-tools/zopro";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn text(p: impl AsRef<Path>) -> String {
    fs::read_to_string(p).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn replace(s: &mut String, a: &str, b: &str, n: usize) {
    assert_eq!(s.matches(a).count(), n, "{a}");
    *s = s.replace(a, b);
}
fn receipts(plan: &Path, out: &Path) -> usize {
    let p = load(plan);
    assert_eq!(load(out.join("result.json"))["status"], "complete");
    for s in p["steps"].as_array().unwrap() {
        let base = out.join(s["name"].as_str().unwrap());
        let e = load(base.join("exit.json"));
        assert_eq!(e["success"], true);
        assert_eq!(e["returncode"], 0);
        let c = load(base.join("command.json"));
        let a = c["argv"].as_array().unwrap();
        let b = s["argv"].as_array().unwrap();
        assert_eq!(&a[a.len() - b.len()..], b);
        for stream in ["stdout", "stderr"] {
            assert_eq!(
                hash(base.join(format!("{stream}.log"))),
                e[format!("{stream}_sha256")].as_str().unwrap()
            );
        }
    }
    p["steps"].as_array().unwrap().len()
}
fn main() {
    let r = Path::new(R);
    let m=load(Path::new(P).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let accepted = m["source_files_sha256"].as_object().unwrap();
    assert_eq!(accepted.len(), 176);
    for (p, h) in accepted {
        assert_eq!(hash(Path::new(P).join(p)), h.as_str().unwrap());
    }
    let before: BTreeMap<String, String> =
        serde_json::from_value(load(r.join("source-pins.json"))).unwrap();
    let fixed: BTreeMap<String, String> =
        serde_json::from_value(load(r.join("source-fixed-pins.json"))).unwrap();
    assert_eq!(before.len(), 177);
    assert_eq!(fixed.len(), 177);
    for (p, h) in before.iter().chain(fixed.iter()) {
        assert_eq!(&hash(p), h);
    }
    let source = r.join("source-fixed");
    let mut exact = 0;
    for (name, h) in accepted {
        if hash(source.join(name)) == h.as_str().unwrap() {
            exact += 1
        } else {
            assert!([
                "crates/zopro-bn254/src/lib.rs",
                "crates/zopro-bn254/src/ifma8.rs",
                "scripts/ifma8.py"
            ]
            .contains(&name.as_str()));
        }
    }
    assert_eq!(exact, 173);
    let old_child = text(r.join("source/crates/zopro-bn254/src/byte_pack.rs"));
    let child = text(source.join("crates/zopro-bn254/src/byte_pack.rs"));
    let mut repair = old_child.clone();
    replace(
        &mut repair,
        "let expected = A::from_le_bytes_mod_order(&data);",
        "let expected = A::from_be_bytes_mod_order(&data);",
        1,
    );
    assert_eq!(repair, child);
    for (p, h) in &before {
        let relative = Path::new(p).strip_prefix(r.join("source")).unwrap();
        if relative != Path::new("crates/zopro-bn254/src/byte_pack.rs") {
            assert_eq!(hash(source.join(relative)), *h);
        }
    }
    let mut lib = text(source.join("crates/zopro-bn254/src/lib.rs"));
    let suffix="\n#[cfg(all(any(zopro_vbmi_pack,test),target_arch=\"x86_64\",target_feature=\"avx512vbmi\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma)))]\nmod byte_pack;\n";
    assert!(lib.ends_with(suffix));
    lib.truncate(lib.len() - suffix.len());
    assert_eq!(
        lib,
        text(Path::new(P).join("crates/zopro-bn254/src/lib.rs"))
    );
    let mut gen = text(source.join("scripts/ifma8.py"));
    replace(&mut gen,"        #[cfg(all(zopro_vbmi_pack,target_feature=\"avx512vbmi\"))]\n        { return crate::byte_pack::raw::<C,MIXED>(x); }\n","",1);
    replace(
        &mut gen,
        "        #[cfg(not(all(zopro_vbmi_pack,target_feature=\"avx512vbmi\")))]\n",
        "",
        1,
    );
    assert_eq!(gen, text(Path::new(P).join("scripts/ifma8.py")));
    let mut generated = text(source.join("crates/zopro-bn254/src/ifma8.rs"));
    replace(&mut generated,"        #[cfg(all(zopro_vbmi_pack, target_feature = \"avx512vbmi\"))]\n        {\n            return crate::byte_pack::raw::<C, MIXED>(x);\n        }\n","",1);
    replace(
        &mut generated,
        "        #[cfg(not(all(zopro_vbmi_pack, target_feature = \"avx512vbmi\")))]\n",
        "",
        1,
    );
    assert_eq!(
        generated,
        text(Path::new(P).join("crates/zopro-bn254/src/ifma8.rs"))
    );
    let production = child.split("#[cfg(test)]").next().unwrap();
    for forbidden in ["Vec", "Box", "alloc", "from_random", "inverse", ".mul("] {
        assert!(!production.contains(forbidden));
    }
    assert_eq!(production.matches("_mm512_loadu_si512(p").count(), 4);
    assert_eq!(production.matches("const INDEX").count(), 6);
    assert!(production.contains("::<0x88>"));
    assert!(production.contains("::<0xdd>"));
    // Independent symbolic byte/bit map, using global input-byte identities.
    // low/high row groups follow 128-bit shuffle lanes0,2 and1,3 respectively.
    let low: (Vec<usize>, Vec<usize>) = (
        (0..4)
            .flat_map(|p| (0..16).map(move |b| p * 32 + b))
            .collect(),
        (4..8)
            .flat_map(|p| (0..16).map(move |b| p * 32 + b))
            .collect(),
    );
    let high: (Vec<usize>, Vec<usize>) = (
        (0..4)
            .flat_map(|p| (16..32).map(move |b| p * 32 + b))
            .collect(),
        (4..8)
            .flat_map(|p| (16..32).map(move |b| p * 32 + b))
            .collect(),
    );
    let fetch = |pair: &(Vec<usize>, Vec<usize>), index: usize| {
        if index < 64 {
            pair.0[index]
        } else {
            pair.1[index - 64]
        }
    };
    let mut checked = 0;
    let mut data_bits = 0;
    for lane in 0..8 {
        for limb in 0..5 {
            for bit in 0..64 {
                let live = bit < if limb == 4 { 48 } else { 52 };
                let got = if !live {
                    None
                } else {
                    let local = match limb {
                        0 => fetch(&low, lane * 16 + bit / 8) * 8 + bit % 8,
                        1 => fetch(&low, lane * 16 + 6 + (bit + 4) / 8) * 8 + (bit + 4) % 8,
                        2 => {
                            if bit < 24 {
                                fetch(&low, lane * 16 + 13 + bit / 8) * 8 + bit % 8
                            } else {
                                fetch(&high, lane * 16 + (bit - 24) / 8) * 8 + (bit - 24) % 8
                            }
                        }
                        3 => fetch(&high, lane * 16 + 3 + (bit + 4) / 8) * 8 + (bit + 4) % 8,
                        _ => fetch(&high, lane * 16 + 10 + bit / 8) * 8 + bit % 8,
                    };
                    Some(local)
                };
                let expected = if live {
                    Some(lane * 256 + limb * 52 + bit)
                } else {
                    None
                };
                assert_eq!(got, expected);
                checked += 1;
                data_bits += usize::from(live);
            }
        }
    }
    assert_eq!((checked, data_bits), (2560, 2048));
    let mut command_count = 0;
    for (p, o) in [
        ("generator-plan.json", "generator-runs"),
        ("field-fixed-plan.json", "field-fixed-runs"),
        ("core-fixed-plan.json", "core-fixed-runs"),
    ] {
        command_count += receipts(&r.join(p), &r.join(o));
    }
    let failed = r.join("field-runs/field-OFF");
    let exit = load(failed.join("exit.json"));
    assert_eq!(exit["returncode"], 101);
    for stream in ["stdout", "stderr"] {
        assert_eq!(
            hash(failed.join(format!("{stream}.log"))),
            exit[format!("{stream}_sha256")].as_str().unwrap()
        );
    }
    let out = text(failed.join("stdout.log"));
    assert!(out.contains("36 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out"));
    assert!(out.lines().any(
        |l| l.contains("every_input_bit_and_lane_matches_independent_reader")
            && l.ends_with(" ... ok")
    ));
    assert!(!r.join("field-runs/field-ON").exists());
    let off = text(r.join("field-fixed-runs/field-OFF-public-fixed/stdout.log"));
    assert!(off.contains("1 passed; 0 failed; 0 ignored; 0 measured; 36 filtered out"));
    let on = text(r.join("field-fixed-runs/field-ON/stdout.log"));
    assert!(on.contains("37 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
    for arm in ["core-off", "core-on"] {
        assert!(text(r.join(format!("core-fixed-runs/{arm}/stdout.log")))
            .contains("125 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
    }
    let q = load(r.join("prospective-pilot.json"));
    let mut c = 1u64;
    let mut tail = 1u64;
    for k in 1..=9 {
        c = c * (32 - k) / k;
        tail += c;
    }
    let coverage = 1. - 2. * tail as f64 / (1u64 << 31) as f64;
    assert_eq!(tail, 31621024);
    assert!((coverage - q["nominal_marginal_coverage"].as_f64().unwrap()).abs() < 1e-15);
    let out = json!({"review_passed":true,"production_files_checked":176,"source_files":177,"accepted_exact":173,"source_pin_occurrences":354,"four_lane_and_arithmetic_sources_unchanged":true,"generator_parent_and_output_recovered_exact":true,"test_only_endianness_repair":true,"OFF_successes_inherited":36,"OFF_failed_test_fixed":1,"ON_tests":37,"core_OFF_tests":125,"core_ON_tests":125,"successful_native_command_receipts":command_count,"symbolic_output_bits":checked,"symbolic_data_bits":data_bits,"zero_padding_bits":checked-data_bits,"raw_vectors_per_tag":6154,"raw_lane_outputs_per_configuration":6154*8*4,"public_roundtrip_outputs_per_configuration":1024*8*4*2,"public_product_outputs_per_configuration":1024*8*4,"fixed_mask_payload_bytes":384,"new_heap_bytes":0,"new_timings":0,"adopted":false,"limits":"Independent source/receipt/count/symbolic byte-map review. Native full basis and Arkworks tests are finite machine evidence, not a formal ISA/compiler proof. Repeated tags/OFF-ON populations are not new distinct input vectors. No latency, stack/RSS/minimum-RAM or device qualification."});
    let dest = r.join("native-review.json");
    assert!(!dest.exists());
    fs::write(dest, serde_json::to_vec_pretty(&out).unwrap()).unwrap();
    println!("native byte-map/source/receipt review PASS");
}
