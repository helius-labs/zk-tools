use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/byte-permute-pack176";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn exit(dir: &Path) {
    let e = load(dir.join("exit.json"));
    assert_eq!(e["success"], true);
    assert_eq!(e["returncode"], 0);
    for stream in ["stdout", "stderr"] {
        assert_eq!(
            hash(dir.join(format!("{stream}.log"))),
            e[format!("{stream}_sha256")].as_str().unwrap()
        );
    }
}
fn main() {
    let r = Path::new(R);
    let native = load(r.join("native-review.json"));
    assert_eq!(native["review_passed"], true);
    let mut pins = 0;
    for file in ["source-fixed-pins.json", "sdk-build-pins.json"] {
        for (p, h) in load(r.join(file)).as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
            pins += 1;
        }
    }
    assert_eq!(load(r.join("sdk-build/result.json"))["status"], "complete");
    let plan = load(r.join("sdk-build-plan.json"));
    assert_eq!(plan["steps"].as_array().unwrap().len(), 6);
    for step in plan["steps"].as_array().unwrap() {
        let base = r.join("sdk-build").join(step["name"].as_str().unwrap());
        exit(&base);
        let c = load(base.join("command.json"));
        let a = c["argv"].as_array().unwrap();
        if step["kind"] == "command" {
            let b = step["argv"].as_array().unwrap();
            assert_eq!(&a[a.len() - b.len()..], b);
        } else {
            assert!(a.iter().any(|v| v == "-O"));
            for opt in ["target-cpu=native", "lto=fat", "codegen-units=1"] {
                assert!(a.windows(2).any(|w| w[0] == "-C" && w[1] == opt));
            }
        }
    }
    for (name, n) in [("prover-lib-ON", 2), ("prover-cubic-ON", 6)] {
        let out = fs::read_to_string(r.join(format!("sdk-build/{name}/stdout.log"))).unwrap();
        assert!(out.contains(&format!(
            "{n} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
        )));
    }
    for arm in ["OFF", "ON"] {
        let a = load(r.join(format!("sdk-build/{arm}/artifacts.json")));
        assert_eq!(a["libraries"].as_object().unwrap().len(), 8);
        assert_eq!(
            hash(a["binary"].as_str().unwrap()),
            a["binary_sha256"].as_str().unwrap()
        );
        for (p, h) in a["input_pins"].as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
    }
    let mut receipts = 6;
    for stage in ["nm", "decode", "fft-decode"] {
        assert_eq!(
            load(r.join(format!("{stage}-runs/result.json")))["status"],
            "complete"
        );
        let plan = load(r.join(format!("{stage}-plan.json")));
        for step in plan["steps"].as_array().unwrap() {
            let base = r
                .join(format!("{stage}-runs"))
                .join(step["name"].as_str().unwrap());
            exit(&base);
            let c = load(base.join("command.json"));
            let a = c["argv"].as_array().unwrap();
            let b = step["argv"].as_array().unwrap();
            assert_eq!(&a[a.len() - b.len()..], b);
            receipts += 1;
        }
    }
    let initial = load(r.join("codegen-analysis.json"));
    let all = load(r.join("codegen-complete-analysis.json"));
    for (k, v) in initial["rows"].as_object().unwrap() {
        assert_eq!(all["rows"][k], *v);
    }
    assert_eq!(initial["rows"].as_object().unwrap().len(), 6);
    assert_eq!(all["rows"].as_object().unwrap().len(), 10);
    let mut jobs = load(r.join("codegen-jobs.json"))
        .as_array()
        .unwrap()
        .clone();
    jobs.extend(
        load(r.join("fft-codegen-jobs.json"))
            .as_array()
            .unwrap()
            .iter()
            .cloned(),
    );
    assert_eq!(jobs.len(), 10);
    for job in jobs {
        let name = job["name"].as_str().unwrap();
        let stage = if name.starts_with("fft-") {
            "fft-decode"
        } else {
            "decode"
        };
        let stream = r.join(format!("{stage}-runs/{name}/stdout.log"));
        let text = fs::read_to_string(&stream).unwrap();
        let begin = job["address"].as_u64().unwrap();
        let end = begin + job["size_bytes"].as_u64().unwrap();
        let mut ins = vec![];
        for l in text.lines() {
            if let Some((ip, body)) = l.split_once(':') {
                if let Ok(ip) = u64::from_str_radix(ip.trim(), 16) {
                    if (begin..end).contains(&ip) {
                        ins.push(body.trim());
                    }
                }
            }
        }
        let key = format!(
            "{}-{}",
            job["kind"].as_str().unwrap(),
            job["arm"].as_str().unwrap()
        );
        let row = &all["rows"][key];
        assert_eq!(row["instructions"], ins.len());
        assert_eq!(
            row["IFMA_sites"],
            ins.iter().filter(|s| s.starts_with("vpmadd52")).count()
        );
        assert_eq!(
            row["byte_permutation_sites"],
            ins.iter()
                .filter(|s| s.starts_with("vpermi2b ")
                    || s.starts_with("vpermt2b ")
                    || s.starts_with("vpermb "))
                .count()
        );
        assert_eq!(
            row["ZMM_stack_operand_rows"],
            ins.iter()
                .filter(|s| s.contains("ZMMWORD PTR [rsp") || s.contains("ZMMWORD PTR [rbp"))
                .count()
        );
        assert_eq!(
            row["calls"].as_array().unwrap().len(),
            ins.iter().filter(|s| s.starts_with("call ")).count()
        );
        assert_eq!(row["decode_sha256"], hash(stream));
        assert_eq!(row["binary_sha256"], hash(job["binary"].as_str().unwrap()));
    }
    for kind in ["G1", "G2", "Inverse", "FFT-forward", "FFT-inverse"] {
        let off = &all["rows"][format!("{kind}-OFF")];
        let on = &all["rows"][format!("{kind}-ON")];
        assert_eq!(off["IFMA_sites"], on["IFMA_sites"]);
        assert_eq!(off["byte_permutation_sites"], 0);
        if kind.starts_with("FFT") {
            for k in [
                "instructions",
                "prologue_rsp_subtraction_bytes",
                "ZMM_stack_operand_rows",
                "ZMM_stack_store_rows",
            ] {
                assert_eq!(off[k], on[k]);
            }
            assert_eq!(on["byte_permutation_sites"], 0);
        } else {
            assert!(on["byte_permutation_sites"].as_u64().unwrap() > 0);
            assert_eq!(on["new_wrapper_calls"], 0);
        }
    }
    assert_eq!(all["native_route_gate_passed"], true);
    let q = load(r.join("prospective-pilot.json"));
    assert_eq!(q["blocks"], 31);
    assert_eq!(q["paired_median_ranks"], json!([10, 22]));
    let result = json!({"review_passed":true,"input_pin_occurrences":pins,"SDK_nm_decode_receipts":receipts,"coherent_libraries_each":8,"ON_prover_tests":8,"actual_consumers":10,"earlier_six_decodes_reused_exact":true,"four_additional_FFT_direction_decodes":true,"FFT_parameter_source_checked":true,"bit_mapping_native_qualification_inherited":true,"native_route_passed":true,"performance_trial_selected":true,"whole_function_size_not_speed":true,"new_performance_clocks":0,"new_independent_Gnark_exports":0,"canonical_ledger_count":31777,"adopted":false,"limits":"Separate retained-text/source/hash/count/receipt review, not a second disassembler, native field oracle, formal stack/compiler proof or speed/RAM measurement. Static increases and stack tradeoffs remain in the evidence; first whole SDK trial has not run."});
    let dest = r.join("final-review.json");
    assert!(!dest.exists());
    fs::write(dest, serde_json::to_vec_pretty(&result).unwrap()).unwrap();
    println!("final native/SDK/ten-consumer review PASS; no performance clock yet");
}
