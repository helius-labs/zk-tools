
/home/ubuntu/src/zopro-perf-work/g1-column-tiles176/native/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

000000000007b850 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill>:
   7b850:	55                                              	push   rbp
   7b851:	48 89 e5                                        	mov    rbp,rsp
   7b854:	41 57                                           	push   r15
   7b856:	41 56                                           	push   r14
   7b858:	41 55                                           	push   r13
   7b85a:	41 54                                           	push   r12
   7b85c:	53                                              	push   rbx
   7b85d:	48 83 e4 c0                                     	and    rsp,0xffffffffffffffc0
   7b861:	48 81 ec c0 0f 00 00                            	sub    rsp,0xfc0
   7b868:	48 c7 04 24 00 00 00 00                         	mov    QWORD PTR [rsp],0x0
   7b870:	48 81 ec c0 03 00 00                            	sub    rsp,0x3c0
   7b877:	48 89 74 24 40                                  	mov    QWORD PTR [rsp+0x40],rsi
   7b87c:	48 89 94 24 38 06 00 00                         	mov    QWORD PTR [rsp+0x638],rdx
   7b884:	4c 89 84 24 80 01 00 00                         	mov    QWORD PTR [rsp+0x180],r8
   7b88c:	4c 39 c2                                        	cmp    rdx,r8
   7b88f:	0f 85 8d 5b 00 00                               	jne    81422 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5bd2>
   7b895:	48 89 d0                                        	mov    rax,rdx
   7b898:	48 c1 e8 1f                                     	shr    rax,0x1f
   7b89c:	48 89 d3                                        	mov    rbx,rdx
   7b89f:	0f 85 9b 5b 00 00                               	jne    81440 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5bf0>
   7b8a5:	4d 89 ce                                        	mov    r14,r9
   7b8a8:	49 83 f9 16                                     	cmp    r9,0x16
   7b8ac:	0f 83 a6 5b 00 00                               	jae    81458 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c08>
   7b8b2:	49 89 fc                                        	mov    r12,rdi
   7b8b5:	bf 00 40 00 00                                  	mov    edi,0x4000
   7b8ba:	be 01 00 00 00                                  	mov    esi,0x1
   7b8bf:	49 89 cf                                        	mov    r15,rcx
   7b8c2:	ff 15 d0 da 01 00                               	call   QWORD PTR [rip+0x1dad0]        # 99398 <calloc@GLIBC_2.2.5>
   7b8c8:	48 85 c0                                        	test   rax,rax
   7b8cb:	0f 84 07 5d 00 00                               	je     815d8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d88>
   7b8d1:	49 89 c5                                        	mov    r13,rax
   7b8d4:	48 85 db                                        	test   rbx,rbx
   7b8d7:	0f 84 04 01 00 00                               	je     7b9e1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x191>
   7b8dd:	4a 8d 04 b5 00 00 00 00                         	lea    rax,[r14*4+0x0]
   7b8e5:	4c 8b 4c 24 40                                  	mov    r9,QWORD PTR [rsp+0x40]
   7b8ea:	48 8d 34 40                                     	lea    rsi,[rax+rax*2]
   7b8ee:	48 8d 44 40 ff                                  	lea    rax,[rax+rax*2-0x1]
   7b8f3:	48 89 c7                                        	mov    rdi,rax
   7b8f6:	83 e0 3f                                        	and    eax,0x3f
   7b8f9:	48 c1 ef 06                                     	shr    rdi,0x6
   7b8fd:	48 83 f8 34                                     	cmp    rax,0x34
   7b901:	0f 93 c2                                        	setae  dl
   7b904:	49 83 fe 11                                     	cmp    r14,0x11
   7b908:	0f 92 c1                                        	setb   cl
   7b90b:	45 31 c0                                        	xor    r8d,r8d
   7b90e:	20 d1                                           	and    cl,dl
   7b910:	ba 01 00 00 00                                  	mov    edx,0x1
   7b915:	29 f2                                           	sub    edx,esi
   7b917:	49 8d 74 ff 08                                  	lea    rsi,[r15+rdi*8+0x8]
   7b91c:	48 89 df                                        	mov    rdi,rbx
   7b91f:	48 c1 e7 05                                     	shl    rdi,0x5
   7b923:	83 e2 3d                                        	and    edx,0x3d
   7b926:	eb 3d                                           	jmp    7b965 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x115>
   7b928:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   7b930:	45 29 d3                                        	sub    r11d,r10d
   7b933:	45 89 da                                        	mov    r10d,r11d
   7b936:	66 41 f7 da                                     	neg    r10w
   7b93a:	66 45 0f 48 d3                                  	cmovs  r10w,r11w
   7b93f:	45 0f b7 d2                                     	movzx  r10d,r10w
   7b943:	66 41 81 fa 00 08                               	cmp    r10w,0x800
   7b949:	0f 87 21 5c 00 00                               	ja     81570 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d20>
   7b94f:	4b ff 44 d5 f8                                  	inc    QWORD PTR [r13+r10*8-0x8]
   7b954:	49 83 c0 20                                     	add    r8,0x20
   7b958:	49 83 c1 40                                     	add    r9,0x40
   7b95c:	4c 39 c7                                        	cmp    rdi,r8
   7b95f:	0f 84 7c 00 00 00                               	je     7b9e1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x191>
   7b965:	4d 85 f6                                        	test   r14,r14
   7b968:	74 36                                           	je     7b9a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x150>
   7b96a:	c4 22 fb f7 54 06 f8                            	shrx   r10,QWORD PTR [rsi+r8*1-0x8],rax
   7b971:	84 c9                                           	test   cl,cl
   7b973:	74 09                                           	je     7b97e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x12e>
   7b975:	c4 22 e9 f7 1c 06                               	shlx   r11,QWORD PTR [rsi+r8*1],rdx
   7b97b:	4d 09 da                                        	or     r10,r11
   7b97e:	45 89 d3                                        	mov    r11d,r10d
   7b981:	41 81 e3 ff 1f 00 00                            	and    r11d,0x1fff
   7b988:	41 ff c3                                        	inc    r11d
   7b98b:	41 d1 eb                                        	shr    r11d,1
   7b98e:	41 81 e2 00 10 00 00                            	and    r10d,0x1000
   7b995:	4d 39 d3                                        	cmp    r11,r10
   7b998:	74 ba                                           	je     7b954 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x104>
   7b99a:	eb 1f                                           	jmp    7b9bb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x16b>
   7b99c:	0f 1f 40 00                                     	nop    DWORD PTR [rax+0x0]
   7b9a0:	4f 8b 1c 07                                     	mov    r11,QWORD PTR [r15+r8*1]
   7b9a4:	41 81 e3 ff 0f 00 00                            	and    r11d,0xfff
   7b9ab:	47 8d 14 1b                                     	lea    r10d,[r11+r11*1]
   7b9af:	41 81 e2 00 10 00 00                            	and    r10d,0x1000
   7b9b6:	4d 39 d3                                        	cmp    r11,r10
   7b9b9:	74 99                                           	je     7b954 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x104>
   7b9bb:	c4 c1 7e 6f 01                                  	vmovdqu ymm0,YMMWORD PTR [r9]
   7b9c0:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7b9c5:	0f 85 65 ff ff ff                               	jne    7b930 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe0>
   7b9cb:	c4 c1 7e 6f 41 20                               	vmovdqu ymm0,YMMWORD PTR [r9+0x20]
   7b9d1:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7b9d6:	0f 85 54 ff ff ff                               	jne    7b930 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe0>
   7b9dc:	e9 73 ff ff ff                                  	jmp    7b954 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x104>
   7b9e1:	48 8d bc 24 00 06 00 00                         	lea    rdi,[rsp+0x600]
   7b9e9:	4c 89 ee                                        	mov    rsi,r13
   7b9ec:	48 89 5c 24 60                                  	mov    QWORD PTR [rsp+0x60],rbx
   7b9f1:	c5 f8 77                                        	vzeroupper
   7b9f4:	e8 67 61 00 00                                  	call   81b60 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns14prefix_offsets>
   7b9f9:	48 8b 9c 24 10 06 00 00                         	mov    rbx,QWORD PTR [rsp+0x610]
   7ba01:	48 81 fb ff 07 00 00                            	cmp    rbx,0x7ff
   7ba08:	0f 86 e5 59 00 00                               	jbe    813f3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ba3>
   7ba0e:	4c 89 a4 24 58 01 00 00                         	mov    QWORD PTR [rsp+0x158],r12
   7ba16:	4c 8b a4 24 08 06 00 00                         	mov    r12,QWORD PTR [rsp+0x608]
   7ba1e:	bf 00 40 00 00                                  	mov    edi,0x4000
   7ba23:	ff 15 3f d9 01 00                               	call   QWORD PTR [rip+0x1d93f]        # 99368 <malloc@GLIBC_2.2.5>
   7ba29:	48 85 c0                                        	test   rax,rax
   7ba2c:	0f 84 b5 5b 00 00                               	je     815e7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d97>
   7ba32:	ba 00 40 00 00                                  	mov    edx,0x4000
   7ba37:	48 89 84 24 c8 00 00 00                         	mov    QWORD PTR [rsp+0xc8],rax
   7ba3f:	48 89 c7                                        	mov    rdi,rax
   7ba42:	4c 89 e6                                        	mov    rsi,r12
   7ba45:	ff 15 25 d9 01 00                               	call   QWORD PTR [rip+0x1d925]        # 99370 <memcpy@GLIBC_2.14>
   7ba4b:	48 81 fb 00 08 00 00                            	cmp    rbx,0x800
   7ba52:	0f 84 a3 5b 00 00                               	je     815fb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5dab>
   7ba58:	49 8b 94 24 00 40 00 00                         	mov    rdx,QWORD PTR [r12+0x4000]
   7ba60:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7ba6a:	48 8d 71 03                                     	lea    rsi,[rcx+0x3]
   7ba6e:	48 8d 1c 95 00 00 00 00                         	lea    rbx,[rdx*4+0x0]
   7ba76:	48 89 d0                                        	mov    rax,rdx
   7ba79:	48 c1 e8 3e                                     	shr    rax,0x3e
   7ba7d:	0f 95 c0                                        	setne  al
   7ba80:	48 39 f3                                        	cmp    rbx,rsi
   7ba83:	0f 97 c1                                        	seta   cl
   7ba86:	08 c1                                           	or     cl,al
   7ba88:	74 0f                                           	je     7ba99 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x249>
   7ba8a:	31 ff                                           	xor    edi,edi
   7ba8c:	48 89 de                                        	mov    rsi,rbx
   7ba8f:	e8 0d 38 fb ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7ba94:	e9 44 5c 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   7ba99:	4c 89 a4 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],r12
   7baa1:	48 89 54 24 50                                  	mov    QWORD PTR [rsp+0x50],rdx
   7baa6:	48 89 b4 24 c0 06 00 00                         	mov    QWORD PTR [rsp+0x6c0],rsi
   7baae:	48 85 db                                        	test   rbx,rbx
   7bab1:	74 45                                           	je     7baf8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2a8>
   7bab3:	48 81 fb 00 00 02 00                            	cmp    rbx,0x20000
   7baba:	72 50                                           	jb     7bb0c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2bc>
   7babc:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7bac6:	48 89 df                                        	mov    rdi,rbx
   7bac9:	48 83 cf 01                                     	or     rdi,0x1
   7bacd:	48 83 c0 04                                     	add    rax,0x4
   7bad1:	48 39 c7                                        	cmp    rdi,rax
   7bad4:	0f 83 75 5b 00 00                               	jae    8164f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5dff>
   7bada:	be 01 00 00 00                                  	mov    esi,0x1
   7badf:	ff 15 b3 d8 01 00                               	call   QWORD PTR [rip+0x1d8b3]        # 99398 <calloc@GLIBC_2.2.5>
   7bae5:	bf 04 00 00 00                                  	mov    edi,0x4
   7baea:	48 85 c0                                        	test   rax,rax
   7baed:	74 9d                                           	je     7ba8c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x23c>
   7baef:	49 89 c4                                        	mov    r12,rax
   7baf2:	c6 04 18 00                                     	mov    BYTE PTR [rax+rbx*1],0x0
   7baf6:	eb 2e                                           	jmp    7bb26 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2d6>
   7baf8:	41 bc 04 00 00 00                               	mov    r12d,0x4
   7bafe:	48 c7 84 24 a0 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xa0],0x0
   7bb0a:	eb 27                                           	jmp    7bb33 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2e3>
   7bb0c:	be 01 00 00 00                                  	mov    esi,0x1
   7bb11:	48 89 df                                        	mov    rdi,rbx
   7bb14:	ff 15 7e d8 01 00                               	call   QWORD PTR [rip+0x1d87e]        # 99398 <calloc@GLIBC_2.2.5>
   7bb1a:	49 89 c4                                        	mov    r12,rax
   7bb1d:	48 85 c0                                        	test   rax,rax
   7bb20:	0f 84 29 5b 00 00                               	je     8164f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5dff>
   7bb26:	48 8b 44 24 50                                  	mov    rax,QWORD PTR [rsp+0x50]
   7bb2b:	48 89 84 24 a0 00 00 00                         	mov    QWORD PTR [rsp+0xa0],rax
   7bb33:	48 83 7c 24 60 00                               	cmp    QWORD PTR [rsp+0x60],0x0
   7bb39:	4c 8b 5c 24 40                                  	mov    r11,QWORD PTR [rsp+0x40]
   7bb3e:	4c 89 6c 24 30                                  	mov    QWORD PTR [rsp+0x30],r13
   7bb43:	4c 89 64 24 38                                  	mov    QWORD PTR [rsp+0x38],r12
   7bb48:	0f 84 24 01 00 00                               	je     7bc72 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x422>
   7bb4e:	4a 8d 04 b5 00 00 00 00                         	lea    rax,[r14*4+0x0]
   7bb56:	4c 8b 8c 24 c8 00 00 00                         	mov    r9,QWORD PTR [rsp+0xc8]
   7bb5e:	41 b8 01 00 00 00                               	mov    r8d,0x1
   7bb64:	48 8d 14 40                                     	lea    rdx,[rax+rax*2]
   7bb68:	48 8d 44 40 ff                                  	lea    rax,[rax+rax*2-0x1]
   7bb6d:	48 89 c1                                        	mov    rcx,rax
   7bb70:	83 e0 3f                                        	and    eax,0x3f
   7bb73:	48 c1 e9 06                                     	shr    rcx,0x6
   7bb77:	48 83 f8 34                                     	cmp    rax,0x34
   7bb7b:	40 0f 93 c7                                     	setae  dil
   7bb7f:	49 83 fe 11                                     	cmp    r14,0x11
   7bb83:	40 0f 92 c6                                     	setb   sil
   7bb87:	41 29 d0                                        	sub    r8d,edx
   7bb8a:	48 8d 15 27 d4 01 00                            	lea    rdx,[rip+0x1d427]        # 98fb8 <__frame_dummy_init_array_entry+0x2968>
   7bb91:	45 31 d2                                        	xor    r10d,r10d
   7bb94:	40 20 fe                                        	and    sil,dil
   7bb97:	41 83 e0 3d                                     	and    r8d,0x3d
   7bb9b:	eb 19                                           	jmp    7bbb6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x366>
   7bb9d:	0f 1f 00                                        	nop    DWORD PTR [rax]
   7bba0:	49 ff c2                                        	inc    r10
   7bba3:	49 83 c7 20                                     	add    r15,0x20
   7bba7:	49 83 c3 40                                     	add    r11,0x40
   7bbab:	4c 39 54 24 60                                  	cmp    QWORD PTR [rsp+0x60],r10
   7bbb0:	0f 84 bc 00 00 00                               	je     7bc72 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x422>
   7bbb6:	4d 85 f6                                        	test   r14,r14
   7bbb9:	74 35                                           	je     7bbf0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3a0>
   7bbbb:	c4 c2 fb f7 3c cf                               	shrx   rdi,QWORD PTR [r15+rcx*8],rax
   7bbc1:	40 84 f6                                        	test   sil,sil
   7bbc4:	74 0a                                           	je     7bbd0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x380>
   7bbc6:	c4 c2 b9 f7 5c cf 08                            	shlx   rbx,QWORD PTR [r15+rcx*8+0x8],r8
   7bbcd:	48 09 df                                        	or     rdi,rbx
   7bbd0:	89 fb                                           	mov    ebx,edi
   7bbd2:	81 e3 ff 1f 00 00                               	and    ebx,0x1fff
   7bbd8:	ff c3                                           	inc    ebx
   7bbda:	d1 eb                                           	shr    ebx,1
   7bbdc:	81 e7 00 10 00 00                               	and    edi,0x1000
   7bbe2:	48 29 fb                                        	sub    rbx,rdi
   7bbe5:	74 b9                                           	je     7bba0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x350>
   7bbe7:	eb 1e                                           	jmp    7bc07 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3b7>
   7bbe9:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   7bbf0:	49 8b 1f                                        	mov    rbx,QWORD PTR [r15]
   7bbf3:	81 e3 ff 0f 00 00                               	and    ebx,0xfff
   7bbf9:	8d 3c 1b                                        	lea    edi,[rbx+rbx*1]
   7bbfc:	81 e7 00 10 00 00                               	and    edi,0x1000
   7bc02:	48 29 fb                                        	sub    rbx,rdi
   7bc05:	74 99                                           	je     7bba0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x350>
   7bc07:	c4 c1 7e 6f 03                                  	vmovdqu ymm0,YMMWORD PTR [r11]
   7bc0c:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7bc11:	75 0d                                           	jne    7bc20 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3d0>
   7bc13:	c4 c1 7e 6f 43 20                               	vmovdqu ymm0,YMMWORD PTR [r11+0x20]
   7bc19:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7bc1e:	74 80                                           	je     7bba0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x350>
   7bc20:	49 89 dc                                        	mov    r12,rbx
   7bc23:	49 f7 dc                                        	neg    r12
   7bc26:	4c 0f 48 e3                                     	cmovs  r12,rbx
   7bc2a:	49 81 fc 00 08 00 00                            	cmp    r12,0x800
   7bc31:	0f 87 5f 59 00 00                               	ja     81596 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d46>
   7bc37:	4b 8b 7c e1 f8                                  	mov    rdi,QWORD PTR [r9+r12*8-0x8]
   7bc3c:	48 3b 7c 24 50                                  	cmp    rdi,QWORD PTR [rsp+0x50]
   7bc41:	0f 83 46 59 00 00                               	jae    8158d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d3d>
   7bc47:	48 c1 eb 3f                                     	shr    rbx,0x3f
   7bc4b:	45 89 d5                                        	mov    r13d,r10d
   7bc4e:	c1 e3 1f                                        	shl    ebx,0x1f
   7bc51:	41 09 dd                                        	or     r13d,ebx
   7bc54:	48 8b 5c 24 38                                  	mov    rbx,QWORD PTR [rsp+0x38]
   7bc59:	44 89 2c bb                                     	mov    DWORD PTR [rbx+rdi*4],r13d
   7bc5d:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   7bc62:	48 ff c7                                        	inc    rdi
   7bc65:	4b 89 7c e1 f8                                  	mov    QWORD PTR [r9+r12*8-0x8],rdi
   7bc6a:	49 89 dc                                        	mov    r12,rbx
   7bc6d:	e9 2e ff ff ff                                  	jmp    7bba0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x350>
   7bc72:	48 8b bc 24 c8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc8]
   7bc7a:	c5 f8 77                                        	vzeroupper
   7bc7d:	ff 15 cd d6 01 00                               	call   QWORD PTR [rip+0x1d6cd]        # 99350 <free@GLIBC_2.2.5>
   7bc83:	bf 00 40 00 00                                  	mov    edi,0x4000
   7bc88:	ff 15 da d6 01 00                               	call   QWORD PTR [rip+0x1d6da]        # 99368 <malloc@GLIBC_2.2.5>
   7bc8e:	48 85 c0                                        	test   rax,rax
   7bc91:	0f 84 8b 59 00 00                               	je     81622 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5dd2>
   7bc97:	62 f2 fd 48 59 05 5f b7 f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff8b75f]        # 7400 <GCC_except_table740+0x1b8>
   7bca1:	48 89 c3                                        	mov    rbx,rax
   7bca4:	b8 38 00 00 00                                  	mov    eax,0x38
   7bca9:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   7bcb0:	62 d1 fe 48 6f 4c c5 f9                         	vmovdqu64 zmm1,ZMMWORD PTR [r13+rax*8-0x1c0]
   7bcb8:	62 d1 fe 48 6f 54 c5 fa                         	vmovdqu64 zmm2,ZMMWORD PTR [r13+rax*8-0x180]
   7bcc0:	62 d1 fe 48 6f 5c c5 fb                         	vmovdqu64 zmm3,ZMMWORD PTR [r13+rax*8-0x140]
   7bcc8:	62 d1 fe 48 6f 64 c5 fc                         	vmovdqu64 zmm4,ZMMWORD PTR [r13+rax*8-0x100]
   7bcd0:	62 51 fe 48 6f 4c c5 fd                         	vmovdqu64 zmm9,ZMMWORD PTR [r13+rax*8-0xc0]
   7bcd8:	62 f1 d5 48 73 d1 03                            	vpsrlq zmm5,zmm1,0x3
   7bcdf:	62 f2 f5 48 27 c0                               	vptestmq k0,zmm1,zmm0
   7bce5:	62 f1 cd 48 73 d2 03                            	vpsrlq zmm6,zmm2,0x3
   7bcec:	62 f2 ed 48 27 c8                               	vptestmq k1,zmm2,zmm0
   7bcf2:	62 f1 c5 48 73 d3 03                            	vpsrlq zmm7,zmm3,0x3
   7bcf9:	62 f2 e5 48 27 d0                               	vptestmq k2,zmm3,zmm0
   7bcff:	62 f1 bd 48 73 d4 03                            	vpsrlq zmm8,zmm4,0x3
   7bd06:	62 f2 dd 48 27 d8                               	vptestmq k3,zmm4,zmm0
   7bd0c:	62 f2 fe 48 38 c8                               	vpmovm2q zmm1,k0
   7bd12:	62 f1 d5 48 fb c9                               	vpsubq zmm1,zmm5,zmm1
   7bd18:	62 f2 fe 48 38 d1                               	vpmovm2q zmm2,k1
   7bd1e:	62 f2 fe 48 38 da                               	vpmovm2q zmm3,k2
   7bd24:	62 f2 fe 48 38 e3                               	vpmovm2q zmm4,k3
   7bd2a:	62 f1 cd 48 fb d2                               	vpsubq zmm2,zmm6,zmm2
   7bd30:	62 f1 c5 48 fb db                               	vpsubq zmm3,zmm7,zmm3
   7bd36:	62 f1 bd 48 fb e4                               	vpsubq zmm4,zmm8,zmm4
   7bd3c:	62 d1 d5 48 73 d1 03                            	vpsrlq zmm5,zmm9,0x3
   7bd43:	62 f2 b5 48 27 c0                               	vptestmq k0,zmm9,zmm0
   7bd49:	62 f1 fe 48 7f 4c c3 f9                         	vmovdqu64 ZMMWORD PTR [rbx+rax*8-0x1c0],zmm1
   7bd51:	62 f1 fe 48 7f 54 c3 fa                         	vmovdqu64 ZMMWORD PTR [rbx+rax*8-0x180],zmm2
   7bd59:	62 f1 fe 48 7f 5c c3 fb                         	vmovdqu64 ZMMWORD PTR [rbx+rax*8-0x140],zmm3
   7bd61:	62 d1 fe 48 6f 54 c5 fe                         	vmovdqu64 zmm2,ZMMWORD PTR [r13+rax*8-0x80]
   7bd69:	62 d1 fe 48 6f 5c c5 ff                         	vmovdqu64 zmm3,ZMMWORD PTR [r13+rax*8-0x40]
   7bd71:	62 f1 fe 48 7f 64 c3 fc                         	vmovdqu64 ZMMWORD PTR [rbx+rax*8-0x100],zmm4
   7bd79:	62 d1 fe 48 6f 64 c5 00                         	vmovdqu64 zmm4,ZMMWORD PTR [r13+rax*8+0x0]
   7bd81:	62 f2 fe 48 38 c8                               	vpmovm2q zmm1,k0
   7bd87:	62 f1 d5 48 fb c9                               	vpsubq zmm1,zmm5,zmm1
   7bd8d:	62 f1 fe 48 7f 4c c3 fd                         	vmovdqu64 ZMMWORD PTR [rbx+rax*8-0xc0],zmm1
   7bd95:	62 f1 cd 48 73 d2 03                            	vpsrlq zmm6,zmm2,0x3
   7bd9c:	62 f2 ed 48 27 c8                               	vptestmq k1,zmm2,zmm0
   7bda2:	62 f1 c5 48 73 d3 03                            	vpsrlq zmm7,zmm3,0x3
   7bda9:	62 f2 e5 48 27 d0                               	vptestmq k2,zmm3,zmm0
   7bdaf:	62 f1 bd 48 73 d4 03                            	vpsrlq zmm8,zmm4,0x3
   7bdb6:	62 f2 dd 48 27 d8                               	vptestmq k3,zmm4,zmm0
   7bdbc:	62 f2 fe 48 38 d1                               	vpmovm2q zmm2,k1
   7bdc2:	62 f2 fe 48 38 da                               	vpmovm2q zmm3,k2
   7bdc8:	62 f2 fe 48 38 e3                               	vpmovm2q zmm4,k3
   7bdce:	62 f1 cd 48 fb d2                               	vpsubq zmm2,zmm6,zmm2
   7bdd4:	62 f1 c5 48 fb db                               	vpsubq zmm3,zmm7,zmm3
   7bdda:	62 f1 bd 48 fb e4                               	vpsubq zmm4,zmm8,zmm4
   7bde0:	62 f1 fe 48 7f 54 c3 fe                         	vmovdqu64 ZMMWORD PTR [rbx+rax*8-0x80],zmm2
   7bde8:	62 f1 fe 48 7f 5c c3 ff                         	vmovdqu64 ZMMWORD PTR [rbx+rax*8-0x40],zmm3
   7bdf0:	62 f1 fe 48 7f 24 c3                            	vmovdqu64 ZMMWORD PTR [rbx+rax*8],zmm4
   7bdf7:	48 83 c0 40                                     	add    rax,0x40
   7bdfb:	48 3d 38 08 00 00                               	cmp    rax,0x838
   7be01:	0f 85 a9 fe ff ff                               	jne    7bcb0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x460>
   7be07:	48 8d bc 24 68 01 00 00                         	lea    rdi,[rsp+0x168]
   7be0f:	48 89 de                                        	mov    rsi,rbx
   7be12:	c5 f8 77                                        	vzeroupper
   7be15:	e8 46 5d 00 00                                  	call   81b60 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns14prefix_offsets>
   7be1a:	48 8b b4 24 78 01 00 00                         	mov    rsi,QWORD PTR [rsp+0x178]
   7be22:	48 89 9c 24 c0 00 00 00                         	mov    QWORD PTR [rsp+0xc0],rbx
   7be2a:	48 81 fe 01 08 00 00                            	cmp    rsi,0x801
   7be31:	0f 82 02 58 00 00                               	jb     81639 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5de9>
   7be37:	48 8b 9c 24 70 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x170]
   7be3f:	48 8b 93 00 40 00 00                            	mov    rdx,QWORD PTR [rbx+0x4000]
   7be46:	48 85 d2                                        	test   rdx,rdx
   7be49:	74 41                                           	je     7be8c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x63c>
   7be4b:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7be55:	48 8d 1c d5 00 00 00 00                         	lea    rbx,[rdx*8+0x0]
   7be5d:	48 89 d0                                        	mov    rax,rdx
   7be60:	48 c1 e8 3d                                     	shr    rax,0x3d
   7be64:	48 8d 71 ff                                     	lea    rsi,[rcx-0x1]
   7be68:	0f 95 c0                                        	setne  al
   7be6b:	48 39 f3                                        	cmp    rbx,rsi
   7be6e:	0f 97 c1                                        	seta   cl
   7be71:	08 c1                                           	or     cl,al
   7be73:	0f 84 ba 01 00 00                               	je     7c033 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x7e3>
   7be79:	45 31 f6                                        	xor    r14d,r14d
   7be7c:	48 89 de                                        	mov    rsi,rbx
   7be7f:	4c 89 f7                                        	mov    rdi,r14
   7be82:	e8 1a 34 fb ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7be87:	e9 51 58 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   7be8c:	bf 01 00 02 00                                  	mov    edi,0x20001
   7be91:	ff 15 d1 d4 01 00                               	call   QWORD PTR [rip+0x1d4d1]        # 99368 <malloc@GLIBC_2.2.5>
   7be97:	48 85 c0                                        	test   rax,rax
   7be9a:	0f 84 b9 57 00 00                               	je     81659 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e09>
   7bea0:	b9 c0 01 00 00                                  	mov    ecx,0x1c0
   7bea5:	48 8d 94 24 a0 01 00 00                         	lea    rdx,[rsp+0x1a0]
   7bead:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7beb1:	c6 80 00 00 02 00 00                            	mov    BYTE PTR [rax+0x20000],0x0
   7beb8:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   7bec0:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7bec4:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7becd:	48 8d 34 08                                     	lea    rsi,[rax+rcx*1]
   7bed1:	62 f1 7c 48 10 4c 24 06                         	vmovups zmm1,ZMMWORD PTR [rsp+0x180]
   7bed9:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7bedd:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7bee6:	62 f1 7c 48 10 5c 24 06                         	vmovups zmm3,ZMMWORD PTR [rsp+0x180]
   7beee:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7bef2:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7befb:	62 f1 7c 48 10 54 24 06                         	vmovups zmm2,ZMMWORD PTR [rsp+0x180]
   7bf03:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7bf07:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7bf10:	62 f1 7c 48 11 4c 08 f9                         	vmovups ZMMWORD PTR [rax+rcx*1-0x1c0],zmm1
   7bf18:	62 f1 7c 48 11 5c 08 fa                         	vmovups ZMMWORD PTR [rax+rcx*1-0x180],zmm3
   7bf20:	62 f1 7c 48 10 5c 24 06                         	vmovups zmm3,ZMMWORD PTR [rsp+0x180]
   7bf28:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7bf2c:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7bf35:	62 f1 7c 48 11 54 08 fb                         	vmovups ZMMWORD PTR [rax+rcx*1-0x140],zmm2
   7bf3d:	62 f1 7c 48 10 54 24 06                         	vmovups zmm2,ZMMWORD PTR [rsp+0x180]
   7bf45:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7bf49:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7bf52:	62 f1 7c 48 11 5c 08 fc                         	vmovups ZMMWORD PTR [rax+rcx*1-0x100],zmm3
   7bf5a:	62 f1 fe 48 6f 5c 24 06                         	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x180]
   7bf62:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7bf66:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7bf6f:	62 f1 7c 48 11 54 08 fd                         	vmovups ZMMWORD PTR [rax+rcx*1-0xc0],zmm2
   7bf77:	62 f1 fe 48 6f 54 24 06                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x180]
   7bf7f:	62 f1 fe 48 7f 5c 08 fe                         	vmovdqu64 ZMMWORD PTR [rax+rcx*1-0x80],zmm3
   7bf87:	62 f1 fe 48 7f 54 08 ff                         	vmovdqu64 ZMMWORD PTR [rax+rcx*1-0x40],zmm2
   7bf8f:	48 81 f9 c0 ff 01 00                            	cmp    rcx,0x1ffc0
   7bf96:	74 27                                           	je     7bfbf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x76f>
   7bf98:	c5 fe 7f 02                                     	vmovdqu YMMWORD PTR [rdx],ymm0
   7bf9c:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7bfa5:	48 81 c1 00 02 00 00                            	add    rcx,0x200
   7bfac:	62 f1 fe 48 6f 4c 24 06                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x180]
   7bfb4:	62 f1 fe 48 7f 0e                               	vmovdqu64 ZMMWORD PTR [rsi],zmm1
   7bfba:	e9 01 ff ff ff                                  	jmp    7bec0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x670>
   7bfbf:	48 8b 8c 24 58 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x158]
   7bfc7:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7bfcb:	62 f1 fe 48 7f 06                               	vmovdqu64 ZMMWORD PTR [rsi],zmm0
   7bfd1:	48 c7 01 00 08 00 00                            	mov    QWORD PTR [rcx],0x800
   7bfd8:	48 89 41 08                                     	mov    QWORD PTR [rcx+0x8],rax
   7bfdc:	48 8b 84 24 68 01 00 00                         	mov    rax,QWORD PTR [rsp+0x168]
   7bfe4:	48 c7 41 10 00 08 00 00                         	mov    QWORD PTR [rcx+0x10],0x800
   7bfec:	48 85 c0                                        	test   rax,rax
   7bfef:	0f 84 9c 00 00 00                               	je     7c091 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x841>
   7bff5:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7bffb:	0f 86 84 00 00 00                               	jbe    7c085 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x835>
   7c001:	48 c1 e0 03                                     	shl    rax,0x3
   7c005:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7c00f:	48 89 c6                                        	mov    rsi,rax
   7c012:	48 83 ce 01                                     	or     rsi,0x1
   7c016:	48 39 ce                                        	cmp    rsi,rcx
   7c019:	0f 83 34 5b 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   7c01f:	80 3c 03 01                                     	cmp    BYTE PTR [rbx+rax*1],0x1
   7c023:	75 60                                           	jne    7c085 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x835>
   7c025:	48 89 df                                        	mov    rdi,rbx
   7c028:	c5 f8 77                                        	vzeroupper
   7c02b:	ff 15 17 d3 01 00                               	call   QWORD PTR [rip+0x1d317]        # 99348 <munmap@GLIBC_2.2.5>
   7c031:	eb 5e                                           	jmp    7c091 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x841>
   7c033:	48 89 54 24 78                                  	mov    QWORD PTR [rsp+0x78],rdx
   7c038:	48 89 b4 24 00 07 00 00                         	mov    QWORD PTR [rsp+0x700],rsi
   7c040:	48 81 fb ff ff 01 00                            	cmp    rbx,0x1ffff
   7c047:	0f 86 15 01 00 00                               	jbe    7c162 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x912>
   7c04d:	48 89 df                                        	mov    rdi,rbx
   7c050:	48 83 cf 01                                     	or     rdi,0x1
   7c054:	41 be 08 00 00 00                               	mov    r14d,0x8
   7c05a:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7c064:	48 39 c7                                        	cmp    rdi,rax
   7c067:	0f 83 0f fe ff ff                               	jae    7be7c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62c>
   7c06d:	ff 15 f5 d2 01 00                               	call   QWORD PTR [rip+0x1d2f5]        # 99368 <malloc@GLIBC_2.2.5>
   7c073:	48 85 c0                                        	test   rax,rax
   7c076:	0f 84 00 fe ff ff                               	je     7be7c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62c>
   7c07c:	c6 04 18 00                                     	mov    BYTE PTR [rax+rbx*1],0x0
   7c080:	e9 2f 01 00 00                                  	jmp    7c1b4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x964>
   7c085:	48 89 df                                        	mov    rdi,rbx
   7c088:	c5 f8 77                                        	vzeroupper
   7c08b:	ff 15 bf d2 01 00                               	call   QWORD PTR [rip+0x1d2bf]        # 99350 <free@GLIBC_2.2.5>
   7c091:	48 8b bc 24 c0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc0]
   7c099:	c5 f8 77                                        	vzeroupper
   7c09c:	ff 15 ae d2 01 00                               	call   QWORD PTR [rip+0x1d2ae]        # 99350 <free@GLIBC_2.2.5>
   7c0a2:	48 8b 8c 24 a0 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xa0]
   7c0aa:	48 8b 9c 24 00 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x100]
   7c0b2:	48 85 c9                                        	test   rcx,rcx
   7c0b5:	74 46                                           	je     7c0fd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8ad>
   7c0b7:	48 81 f9 ff 7f 00 00                            	cmp    rcx,0x7fff
   7c0be:	76 34                                           	jbe    7c0f4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8a4>
   7c0c0:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7c0ca:	48 c1 e1 02                                     	shl    rcx,0x2
   7c0ce:	48 89 ce                                        	mov    rsi,rcx
   7c0d1:	48 83 ce 01                                     	or     rsi,0x1
   7c0d5:	48 83 c0 04                                     	add    rax,0x4
   7c0d9:	48 39 c6                                        	cmp    rsi,rax
   7c0dc:	0f 83 71 5a 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   7c0e2:	41 80 3c 0c 01                                  	cmp    BYTE PTR [r12+rcx*1],0x1
   7c0e7:	75 0b                                           	jne    7c0f4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8a4>
   7c0e9:	4c 89 e7                                        	mov    rdi,r12
   7c0ec:	ff 15 56 d2 01 00                               	call   QWORD PTR [rip+0x1d256]        # 99348 <munmap@GLIBC_2.2.5>
   7c0f2:	eb 09                                           	jmp    7c0fd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8ad>
   7c0f4:	4c 89 e7                                        	mov    rdi,r12
   7c0f7:	ff 15 53 d2 01 00                               	call   QWORD PTR [rip+0x1d253]        # 99350 <free@GLIBC_2.2.5>
   7c0fd:	48 8b 84 24 00 06 00 00                         	mov    rax,QWORD PTR [rsp+0x600]
   7c105:	48 85 c0                                        	test   rax,rax
   7c108:	74 40                                           	je     7c14a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8fa>
   7c10a:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7c110:	76 2f                                           	jbe    7c141 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8f1>
   7c112:	48 c1 e0 03                                     	shl    rax,0x3
   7c116:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7c120:	48 89 c6                                        	mov    rsi,rax
   7c123:	48 83 ce 01                                     	or     rsi,0x1
   7c127:	48 39 ce                                        	cmp    rsi,rcx
   7c12a:	0f 83 23 5a 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   7c130:	80 3c 03 01                                     	cmp    BYTE PTR [rbx+rax*1],0x1
   7c134:	75 0b                                           	jne    7c141 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8f1>
   7c136:	48 89 df                                        	mov    rdi,rbx
   7c139:	ff 15 09 d2 01 00                               	call   QWORD PTR [rip+0x1d209]        # 99348 <munmap@GLIBC_2.2.5>
   7c13f:	eb 09                                           	jmp    7c14a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8fa>
   7c141:	48 89 df                                        	mov    rdi,rbx
   7c144:	ff 15 06 d2 01 00                               	call   QWORD PTR [rip+0x1d206]        # 99350 <free@GLIBC_2.2.5>
   7c14a:	4c 89 ef                                        	mov    rdi,r13
   7c14d:	ff 15 fd d1 01 00                               	call   QWORD PTR [rip+0x1d1fd]        # 99350 <free@GLIBC_2.2.5>
   7c153:	48 8d 65 d8                                     	lea    rsp,[rbp-0x28]
   7c157:	5b                                              	pop    rbx
   7c158:	41 5c                                           	pop    r12
   7c15a:	41 5d                                           	pop    r13
   7c15c:	41 5e                                           	pop    r14
   7c15e:	41 5f                                           	pop    r15
   7c160:	5d                                              	pop    rbp
   7c161:	c3                                              	ret
   7c162:	48 85 db                                        	test   rbx,rbx
   7c165:	74 0b                                           	je     7c172 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x922>
   7c167:	48 89 df                                        	mov    rdi,rbx
   7c16a:	ff 15 f8 d1 01 00                               	call   QWORD PTR [rip+0x1d1f8]        # 99368 <malloc@GLIBC_2.2.5>
   7c170:	eb 39                                           	jmp    7c1ab <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x95b>
   7c172:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7c17a:	be 08 00 00 00                                  	mov    esi,0x8
   7c17f:	31 d2                                           	xor    edx,edx
   7c181:	48 c7 84 24 80 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x180],0x0
   7c18d:	41 be 08 00 00 00                               	mov    r14d,0x8
   7c193:	ff 15 f7 d1 01 00                               	call   QWORD PTR [rip+0x1d1f7]        # 99390 <posix_memalign@GLIBC_2.2.5>
   7c199:	31 f6                                           	xor    esi,esi
   7c19b:	85 c0                                           	test   eax,eax
   7c19d:	0f 85 dc fc ff ff                               	jne    7be7f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62f>
   7c1a3:	48 8b 84 24 80 01 00 00                         	mov    rax,QWORD PTR [rsp+0x180]
   7c1ab:	48 85 c0                                        	test   rax,rax
   7c1ae:	0f 84 c9 54 00 00                               	je     8167d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e2d>
   7c1b4:	48 8b 5c 24 78                                  	mov    rbx,QWORD PTR [rsp+0x78]
   7c1b9:	48 89 84 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],rax
   7c1c1:	48 89 9c 24 d0 00 00 00                         	mov    QWORD PTR [rsp+0xd0],rbx
   7c1c9:	48 89 84 24 d8 00 00 00                         	mov    QWORD PTR [rsp+0xd8],rax
   7c1d1:	48 c7 84 24 e0 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xe0],0x0
   7c1dd:	48 81 fb 00 00 02 00                            	cmp    rbx,0x20000
   7c1e4:	72 19                                           	jb     7c1ff <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x9af>
   7c1e6:	48 8d 7b 01                                     	lea    rdi,[rbx+0x1]
   7c1ea:	ff 15 78 d1 01 00                               	call   QWORD PTR [rip+0x1d178]        # 99368 <malloc@GLIBC_2.2.5>
   7c1f0:	48 85 c0                                        	test   rax,rax
   7c1f3:	0f 84 70 54 00 00                               	je     81669 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e19>
   7c1f9:	c6 04 18 00                                     	mov    BYTE PTR [rax+rbx*1],0x0
   7c1fd:	eb 12                                           	jmp    7c211 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x9c1>
   7c1ff:	48 89 df                                        	mov    rdi,rbx
   7c202:	ff 15 60 d1 01 00                               	call   QWORD PTR [rip+0x1d160]        # 99368 <malloc@GLIBC_2.2.5>
   7c208:	48 85 c0                                        	test   rax,rax
   7c20b:	0f 84 58 54 00 00                               	je     81669 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e19>
   7c211:	48 89 9c 24 a8 00 00 00                         	mov    QWORD PTR [rsp+0xa8],rbx
   7c219:	48 89 84 24 b0 00 00 00                         	mov    QWORD PTR [rsp+0xb0],rax
   7c221:	48 c7 84 24 b8 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xb8],0x0
   7c22d:	45 31 f6                                        	xor    r14d,r14d
   7c230:	31 c9                                           	xor    ecx,ecx
   7c232:	31 d2                                           	xor    edx,edx
   7c234:	eb 27                                           	jmp    7c25d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa0d>
   7c236:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   7c240:	48 8b 94 24 80 06 00 00                         	mov    rdx,QWORD PTR [rsp+0x680]
   7c248:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   7c24d:	48 ff c2                                        	inc    rdx
   7c250:	48 81 fa 00 08 00 00                            	cmp    rdx,0x800
   7c257:	0f 84 05 01 00 00                               	je     7c362 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xb12>
   7c25d:	49 8b 5c d5 00                                  	mov    rbx,QWORD PTR [r13+rdx*8+0x0]
   7c262:	48 89 94 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],rdx
   7c26a:	48 85 db                                        	test   rbx,rbx
   7c26d:	74 d1                                           	je     7c240 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x9f0>
   7c26f:	89 d8                                           	mov    eax,ebx
   7c271:	83 e0 07                                        	and    eax,0x7
   7c274:	49 89 df                                        	mov    r15,rbx
   7c277:	49 c1 ef 03                                     	shr    r15,0x3
   7c27b:	48 83 f8 01                                     	cmp    rax,0x1
   7c27f:	49 83 df ff                                     	sbb    r15,0xffffffffffffffff
   7c283:	45 31 ed                                        	xor    r13d,r13d
   7c286:	eb 3e                                           	jmp    7c2c6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa76>
   7c288:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   7c290:	48 8b 84 24 b0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xb0]
   7c298:	48 8b 8c 24 40 06 00 00                         	mov    rcx,QWORD PTR [rsp+0x640]
   7c2a0:	49 ff cf                                        	dec    r15
   7c2a3:	48 83 c3 f8                                     	add    rbx,0xfffffffffffffff8
   7c2a7:	49 83 c5 08                                     	add    r13,0x8
   7c2ab:	46 88 34 20                                     	mov    BYTE PTR [rax+r12*1],r14b
   7c2af:	4d 89 e6                                        	mov    r14,r12
   7c2b2:	49 ff c6                                        	inc    r14
   7c2b5:	4c 89 b4 24 b8 00 00 00                         	mov    QWORD PTR [rsp+0xb8],r14
   7c2bd:	4d 85 ff                                        	test   r15,r15
   7c2c0:	0f 84 7a ff ff ff                               	je     7c240 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x9f0>
   7c2c6:	48 8b 84 24 00 01 00 00                         	mov    rax,QWORD PTR [rsp+0x100]
   7c2ce:	48 8b 94 24 80 06 00 00                         	mov    rdx,QWORD PTR [rsp+0x680]
   7c2d6:	4c 8b 34 d0                                     	mov    r14,QWORD PTR [rax+rdx*8]
   7c2da:	48 8b 84 24 c0 03 00 00                         	mov    rax,QWORD PTR [rsp+0x3c0]
   7c2e2:	4d 01 ee                                        	add    r14,r13
   7c2e5:	48 3b 8c 24 d0 00 00 00                         	cmp    rcx,QWORD PTR [rsp+0xd0]
   7c2ed:	75 1b                                           	jne    7c30a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xaba>
   7c2ef:	48 8d bc 24 d0 00 00 00                         	lea    rdi,[rsp+0xd0]
   7c2f7:	49 89 cc                                        	mov    r12,rcx
   7c2fa:	e8 41 9f fb ff                                  	call   36240 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCsii3nOZuAKF_15crossbeam_utils>
   7c2ff:	48 8b 84 24 d8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xd8]
   7c307:	4c 89 e1                                        	mov    rcx,r12
   7c30a:	4c 89 34 c8                                     	mov    QWORD PTR [rax+rcx*8],r14
   7c30e:	48 89 84 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],rax
   7c316:	48 ff c1                                        	inc    rcx
   7c319:	48 83 fb 08                                     	cmp    rbx,0x8
   7c31d:	41 be 08 00 00 00                               	mov    r14d,0x8
   7c323:	48 8b 84 24 b8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xb8]
   7c32b:	4c 0f 42 f3                                     	cmovb  r14,rbx
   7c32f:	48 89 8c 24 40 06 00 00                         	mov    QWORD PTR [rsp+0x640],rcx
   7c337:	48 89 8c 24 e0 00 00 00                         	mov    QWORD PTR [rsp+0xe0],rcx
   7c33f:	49 89 c4                                        	mov    r12,rax
   7c342:	48 3b 84 24 a8 00 00 00                         	cmp    rax,QWORD PTR [rsp+0xa8]
   7c34a:	0f 85 40 ff ff ff                               	jne    7c290 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa40>
   7c350:	48 8d bc 24 a8 00 00 00                         	lea    rdi,[rsp+0xa8]
   7c358:	e8 c3 32 fb ff                                  	call   2f620 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
   7c35d:	e9 2e ff ff ff                                  	jmp    7c290 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xa40>
   7c362:	48 89 84 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],rax
   7c36a:	48 8b 84 24 00 06 00 00                         	mov    rax,QWORD PTR [rsp+0x600]
   7c372:	4c 8b 64 24 38                                  	mov    r12,QWORD PTR [rsp+0x38]
   7c377:	49 bf ff ff ff ff ff ff ff 3f                   	movabs r15,0x3fffffffffffffff
   7c381:	48 85 c0                                        	test   rax,rax
   7c384:	74 4a                                           	je     7c3d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xb80>
   7c386:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   7c38c:	76 34                                           	jbe    7c3c2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xb72>
   7c38e:	48 8b bc 24 00 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x100]
   7c396:	48 c1 e0 03                                     	shl    rax,0x3
   7c39a:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   7c3a4:	48 89 c6                                        	mov    rsi,rax
   7c3a7:	48 83 ce 01                                     	or     rsi,0x1
   7c3ab:	48 39 ce                                        	cmp    rsi,rcx
   7c3ae:	0f 83 9f 57 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   7c3b4:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   7c3b8:	75 10                                           	jne    7c3ca <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xb7a>
   7c3ba:	ff 15 88 cf 01 00                               	call   QWORD PTR [rip+0x1cf88]        # 99348 <munmap@GLIBC_2.2.5>
   7c3c0:	eb 0e                                           	jmp    7c3d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xb80>
   7c3c2:	48 8b bc 24 00 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x100]
   7c3ca:	ff 15 80 cf 01 00                               	call   QWORD PTR [rip+0x1cf80]        # 99350 <free@GLIBC_2.2.5>
   7c3d0:	4c 89 ef                                        	mov    rdi,r13
   7c3d3:	ff 15 77 cf 01 00                               	call   QWORD PTR [rip+0x1cf77]        # 99350 <free@GLIBC_2.2.5>
   7c3d9:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7c3dd:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7c3e5:	48 c7 84 24 40 04 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x440],0x0
   7c3f1:	31 c0                                           	xor    eax,eax
   7c3f3:	4d 85 f6                                        	test   r14,r14
   7c3f6:	74 63                                           	je     7c45b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xc0b>
   7c3f8:	4c 8b 94 24 c0 03 00 00                         	mov    r10,QWORD PTR [rsp+0x3c0]
   7c400:	41 0f b6 0c 02                                  	movzx  ecx,BYTE PTR [r10+rax*1]
   7c405:	8d 51 ff                                        	lea    edx,[rcx-0x1]
   7c408:	80 fa 08                                        	cmp    dl,0x8
   7c40b:	0f 83 c2 4f 00 00                               	jae    813d3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5b83>
   7c411:	48 ff 84 cc 00 04 00 00                         	inc    QWORD PTR [rsp+rcx*8+0x400]
   7c419:	48 ff c0                                        	inc    rax
   7c41c:	49 39 c6                                        	cmp    r14,rax
   7c41f:	75 df                                           	jne    7c400 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xbb0>
   7c421:	4c 8b 8c 24 40 04 00 00                         	mov    r9,QWORD PTR [rsp+0x440]
   7c429:	48 8b 8c 24 38 04 00 00                         	mov    rcx,QWORD PTR [rsp+0x438]
   7c431:	4c 8b 84 24 30 04 00 00                         	mov    r8,QWORD PTR [rsp+0x430]
   7c439:	48 8b bc 24 28 04 00 00                         	mov    rdi,QWORD PTR [rsp+0x428]
   7c441:	48 8b b4 24 20 04 00 00                         	mov    rsi,QWORD PTR [rsp+0x420]
   7c449:	48 8b 84 24 10 04 00 00                         	mov    rax,QWORD PTR [rsp+0x410]
   7c451:	48 8b 94 24 18 04 00 00                         	mov    rdx,QWORD PTR [rsp+0x418]
   7c459:	eb 16                                           	jmp    7c471 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xc21>
   7c45b:	4c 8b 94 24 c0 03 00 00                         	mov    r10,QWORD PTR [rsp+0x3c0]
   7c463:	31 d2                                           	xor    edx,edx
   7c465:	31 f6                                           	xor    esi,esi
   7c467:	31 ff                                           	xor    edi,edi
   7c469:	45 31 c0                                        	xor    r8d,r8d
   7c46c:	31 c9                                           	xor    ecx,ecx
   7c46e:	45 31 c9                                        	xor    r9d,r9d
   7c471:	4c 01 c9                                        	add    rcx,r9
   7c474:	62 f1 fd 48 7f 44 24 06                         	vmovdqa64 ZMMWORD PTR [rsp+0x180],zmm0
   7c47c:	48 c7 84 24 c0 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x1c0],0x0
   7c488:	4c 89 8c 24 b8 01 00 00                         	mov    QWORD PTR [rsp+0x1b8],r9
   7c490:	4a 8d 1c b5 00 00 00 00                         	lea    rbx,[r14*4+0x0]
   7c498:	48 89 8c 24 b0 01 00 00                         	mov    QWORD PTR [rsp+0x1b0],rcx
   7c4a0:	4c 01 c1                                        	add    rcx,r8
   7c4a3:	48 89 8c 24 a8 01 00 00                         	mov    QWORD PTR [rsp+0x1a8],rcx
   7c4ab:	48 01 f9                                        	add    rcx,rdi
   7c4ae:	48 89 8c 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rcx
   7c4b6:	48 01 f1                                        	add    rcx,rsi
   7c4b9:	48 89 8c 24 98 01 00 00                         	mov    QWORD PTR [rsp+0x198],rcx
   7c4c1:	48 01 d1                                        	add    rcx,rdx
   7c4c4:	48 89 8c 24 90 01 00 00                         	mov    QWORD PTR [rsp+0x190],rcx
   7c4cc:	48 01 c1                                        	add    rcx,rax
   7c4cf:	4d 39 fe                                        	cmp    r14,r15
   7c4d2:	0f 97 c0                                        	seta   al
   7c4d5:	48 3b 9c 24 c0 06 00 00                         	cmp    rbx,QWORD PTR [rsp+0x6c0]
   7c4dd:	48 89 8c 24 88 01 00 00                         	mov    QWORD PTR [rsp+0x188],rcx
   7c4e5:	0f 97 c1                                        	seta   cl
   7c4e8:	08 c1                                           	or     cl,al
   7c4ea:	74 12                                           	je     7c4fe <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xcae>
   7c4ec:	31 ff                                           	xor    edi,edi
   7c4ee:	48 89 de                                        	mov    rsi,rbx
   7c4f1:	c5 f8 77                                        	vzeroupper
   7c4f4:	e8 a8 2d fb ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7c4f9:	e9 df 51 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   7c4fe:	48 85 db                                        	test   rbx,rbx
   7c501:	74 50                                           	je     7c553 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd03>
   7c503:	48 81 fb 00 00 02 00                            	cmp    rbx,0x20000
   7c50a:	72 68                                           	jb     7c574 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd24>
   7c50c:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7c516:	48 89 df                                        	mov    rdi,rbx
   7c519:	48 83 cf 01                                     	or     rdi,0x1
   7c51d:	48 83 c0 04                                     	add    rax,0x4
   7c521:	48 39 c7                                        	cmp    rdi,rax
   7c524:	0f 83 80 51 00 00                               	jae    816aa <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e5a>
   7c52a:	be 01 00 00 00                                  	mov    esi,0x1
   7c52f:	c5 f8 77                                        	vzeroupper
   7c532:	ff 15 60 ce 01 00                               	call   QWORD PTR [rip+0x1ce60]        # 99398 <calloc@GLIBC_2.2.5>
   7c538:	bf 04 00 00 00                                  	mov    edi,0x4
   7c53d:	48 85 c0                                        	test   rax,rax
   7c540:	74 ac                                           	je     7c4ee <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xc9e>
   7c542:	4c 8b 94 24 c0 03 00 00                         	mov    r10,QWORD PTR [rsp+0x3c0]
   7c54a:	49 89 c0                                        	mov    r8,rax
   7c54d:	c6 04 18 00                                     	mov    BYTE PTR [rax+rbx*1],0x0
   7c551:	eb 46                                           	jmp    7c599 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd49>
   7c553:	41 b8 04 00 00 00                               	mov    r8d,0x4
   7c559:	48 c7 84 24 98 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x98],0x0
   7c565:	4c 89 44 24 70                                  	mov    QWORD PTR [rsp+0x70],r8
   7c56a:	4d 85 f6                                        	test   r14,r14
   7c56d:	75 3c                                           	jne    7c5ab <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd5b>
   7c56f:	e9 83 00 00 00                                  	jmp    7c5f7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xda7>
   7c574:	be 01 00 00 00                                  	mov    esi,0x1
   7c579:	48 89 df                                        	mov    rdi,rbx
   7c57c:	c5 f8 77                                        	vzeroupper
   7c57f:	ff 15 13 ce 01 00                               	call   QWORD PTR [rip+0x1ce13]        # 99398 <calloc@GLIBC_2.2.5>
   7c585:	4c 8b 94 24 c0 03 00 00                         	mov    r10,QWORD PTR [rsp+0x3c0]
   7c58d:	49 89 c0                                        	mov    r8,rax
   7c590:	48 85 c0                                        	test   rax,rax
   7c593:	0f 84 11 51 00 00                               	je     816aa <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e5a>
   7c599:	4c 89 b4 24 98 00 00 00                         	mov    QWORD PTR [rsp+0x98],r14
   7c5a1:	4c 89 44 24 70                                  	mov    QWORD PTR [rsp+0x70],r8
   7c5a6:	4d 85 f6                                        	test   r14,r14
   7c5a9:	74 4c                                           	je     7c5f7 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xda7>
   7c5ab:	48 8d 15 ce c8 01 00                            	lea    rdx,[rip+0x1c8ce]        # 98e80 <__frame_dummy_init_array_entry+0x2830>
   7c5b2:	48 8d 05 df c8 01 00                            	lea    rax,[rip+0x1c8df]        # 98e98 <__frame_dummy_init_array_entry+0x2848>
   7c5b9:	31 c9                                           	xor    ecx,ecx
   7c5bb:	0f 1f 44 00 00                                  	nop    DWORD PTR [rax+rax*1+0x0]
   7c5c0:	41 0f b6 3c 0a                                  	movzx  edi,BYTE PTR [r10+rcx*1]
   7c5c5:	48 83 ff 08                                     	cmp    rdi,0x8
   7c5c9:	0f 87 ec 4f 00 00                               	ja     815bb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d6b>
   7c5cf:	4c 8b 8c fc 80 01 00 00                         	mov    r9,QWORD PTR [rsp+rdi*8+0x180]
   7c5d7:	4d 39 f1                                        	cmp    r9,r14
   7c5da:	0f 83 e2 4f 00 00                               	jae    815c2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d72>
   7c5e0:	43 89 0c 88                                     	mov    DWORD PTR [r8+r9*4],ecx
   7c5e4:	49 ff c1                                        	inc    r9
   7c5e7:	48 ff c1                                        	inc    rcx
   7c5ea:	4c 89 8c fc 80 01 00 00                         	mov    QWORD PTR [rsp+rdi*8+0x180],r9
   7c5f2:	49 39 ce                                        	cmp    r14,rcx
   7c5f5:	75 c9                                           	jne    7c5c0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xd70>
   7c5f7:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7c5ff:	be 40 00 00 00                                  	mov    esi,0x40
   7c604:	ba c0 44 00 00                                  	mov    edx,0x44c0
   7c609:	48 c7 84 24 80 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x180],0x0
   7c615:	c5 f8 77                                        	vzeroupper
   7c618:	ff 15 72 cd 01 00                               	call   QWORD PTR [rip+0x1cd72]        # 99390 <posix_memalign@GLIBC_2.2.5>
   7c61e:	85 c0                                           	test   eax,eax
   7c620:	0f 85 62 50 00 00                               	jne    81688 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e38>
   7c626:	48 8b 9c 24 80 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x180]
   7c62e:	48 85 db                                        	test   rbx,rbx
   7c631:	0f 84 51 50 00 00                               	je     81688 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e38>
   7c637:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7c63f:	be 40 00 00 00                                  	mov    esi,0x40
   7c644:	ba 00 64 00 00                                  	mov    edx,0x6400
   7c649:	48 c7 84 24 80 00 00 00 19 00 00 00             	mov    QWORD PTR [rsp+0x80],0x19
   7c655:	48 89 9c 24 88 00 00 00                         	mov    QWORD PTR [rsp+0x88],rbx
   7c65d:	48 c7 84 24 90 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x90],0x0
   7c669:	48 c7 84 24 80 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x180],0x0
   7c675:	ff 15 15 cd 01 00                               	call   QWORD PTR [rip+0x1cd15]        # 99390 <posix_memalign@GLIBC_2.2.5>
   7c67b:	85 c0                                           	test   eax,eax
   7c67d:	0f 85 16 50 00 00                               	jne    81699 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e49>
   7c683:	48 8b 84 24 80 01 00 00                         	mov    rax,QWORD PTR [rsp+0x180]
   7c68b:	48 85 c0                                        	test   rax,rax
   7c68e:	0f 84 05 50 00 00                               	je     81699 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e49>
   7c694:	48 c7 84 24 e8 00 00 00 19 00 00 00             	mov    QWORD PTR [rsp+0xe8],0x19
   7c6a0:	48 89 84 24 f0 00 00 00                         	mov    QWORD PTR [rsp+0xf0],rax
   7c6a8:	48 8b 44 24 78                                  	mov    rax,QWORD PTR [rsp+0x78]
   7c6ad:	48 c7 84 24 f8 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xf8],0x0
   7c6b9:	48 89 c7                                        	mov    rdi,rax
   7c6bc:	48 c1 e7 06                                     	shl    rdi,0x6
   7c6c0:	48 c1 e8 3a                                     	shr    rax,0x3a
   7c6c4:	0f 95 c0                                        	setne  al
   7c6c7:	48 3b bc 24 00 07 00 00                         	cmp    rdi,QWORD PTR [rsp+0x700]
   7c6cf:	48 89 7c 24 58                                  	mov    QWORD PTR [rsp+0x58],rdi
   7c6d4:	0f 97 c1                                        	seta   cl
   7c6d7:	08 c1                                           	or     cl,al
   7c6d9:	74 15                                           	je     7c6f0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xea0>
   7c6db:	45 31 f6                                        	xor    r14d,r14d
   7c6de:	48 8b 74 24 58                                  	mov    rsi,QWORD PTR [rsp+0x58]
   7c6e3:	4c 89 f7                                        	mov    rdi,r14
   7c6e6:	e8 b6 2b fb ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   7c6eb:	e9 ed 4f 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   7c6f0:	4d 89 f7                                        	mov    r15,r14
   7c6f3:	48 81 ff ff ff 01 00                            	cmp    rdi,0x1ffff
   7c6fa:	76 32                                           	jbe    7c72e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xede>
   7c6fc:	48 83 cf 01                                     	or     rdi,0x1
   7c700:	41 be 08 00 00 00                               	mov    r14d,0x8
   7c706:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   7c710:	48 39 c7                                        	cmp    rdi,rax
   7c713:	73 c9                                           	jae    7c6de <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe8e>
   7c715:	ff 15 4d cc 01 00                               	call   QWORD PTR [rip+0x1cc4d]        # 99368 <malloc@GLIBC_2.2.5>
   7c71b:	48 85 c0                                        	test   rax,rax
   7c71e:	74 be                                           	je     7c6de <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe8e>
   7c720:	48 89 c2                                        	mov    rdx,rax
   7c723:	48 8b 44 24 58                                  	mov    rax,QWORD PTR [rsp+0x58]
   7c728:	c6 04 02 00                                     	mov    BYTE PTR [rdx+rax*1],0x0
   7c72c:	eb 50                                           	jmp    7c77e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xf2e>
   7c72e:	48 85 ff                                        	test   rdi,rdi
   7c731:	74 0b                                           	je     7c73e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xeee>
   7c733:	ff 15 2f cc 01 00                               	call   QWORD PTR [rip+0x1cc2f]        # 99368 <malloc@GLIBC_2.2.5>
   7c739:	48 89 c2                                        	mov    rdx,rax
   7c73c:	eb 37                                           	jmp    7c775 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xf25>
   7c73e:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7c746:	be 08 00 00 00                                  	mov    esi,0x8
   7c74b:	31 d2                                           	xor    edx,edx
   7c74d:	48 c7 84 24 80 01 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x180],0x0
   7c759:	41 be 08 00 00 00                               	mov    r14d,0x8
   7c75f:	ff 15 2b cc 01 00                               	call   QWORD PTR [rip+0x1cc2b]        # 99390 <posix_memalign@GLIBC_2.2.5>
   7c765:	85 c0                                           	test   eax,eax
   7c767:	0f 85 71 ff ff ff                               	jne    7c6de <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe8e>
   7c76d:	48 8b 94 24 80 01 00 00                         	mov    rdx,QWORD PTR [rsp+0x180]
   7c775:	48 85 d2                                        	test   rdx,rdx
   7c778:	0f 84 47 4f 00 00                               	je     816c5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e75>
   7c77e:	48 83 7c 24 78 01                               	cmp    QWORD PTR [rsp+0x78],0x1
   7c784:	4c 8b b4 24 a0 00 00 00                         	mov    r14,QWORD PTR [rsp+0xa0]
   7c78c:	48 89 54 24 48                                  	mov    QWORD PTR [rsp+0x48],rdx
   7c791:	0f 84 5d 01 00 00                               	je     7c8f4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x10a4>
   7c797:	48 8b 4c 24 78                                  	mov    rcx,QWORD PTR [rsp+0x78]
   7c79c:	48 8b 54 24 48                                  	mov    rdx,QWORD PTR [rsp+0x48]
   7c7a1:	48 8d 84 24 a0 01 00 00                         	lea    rax,[rsp+0x1a0]
   7c7a9:	48 8d 71 ff                                     	lea    rsi,[rcx-0x1]
   7c7ad:	48 8d 79 fe                                     	lea    rdi,[rcx-0x2]
   7c7b1:	89 f1                                           	mov    ecx,esi
   7c7b3:	83 e1 07                                        	and    ecx,0x7
   7c7b6:	48 83 ff 07                                     	cmp    rdi,0x7
   7c7ba:	0f 82 05 01 00 00                               	jb     7c8c5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1075>
   7c7c0:	48 8b 54 24 48                                  	mov    rdx,QWORD PTR [rsp+0x48]
   7c7c5:	48 83 e6 f8                                     	and    rsi,0xfffffffffffffff8
   7c7c9:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7c7cd:	0f 1f 00                                        	nop    DWORD PTR [rax]
   7c7d0:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7c7d4:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7c7dd:	62 f1 7c 48 10 4c 24 06                         	vmovups zmm1,ZMMWORD PTR [rsp+0x180]
   7c7e5:	62 f1 7c 48 11 0a                               	vmovups ZMMWORD PTR [rdx],zmm1
   7c7eb:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7c7ef:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7c7f8:	62 f1 7c 48 10 4c 24 06                         	vmovups zmm1,ZMMWORD PTR [rsp+0x180]
   7c800:	62 f1 7c 48 11 4a 01                            	vmovups ZMMWORD PTR [rdx+0x40],zmm1
   7c807:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7c80b:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7c814:	62 f1 7c 48 10 4c 24 06                         	vmovups zmm1,ZMMWORD PTR [rsp+0x180]
   7c81c:	62 f1 7c 48 11 4a 02                            	vmovups ZMMWORD PTR [rdx+0x80],zmm1
   7c823:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7c827:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7c830:	62 f1 7c 48 10 4c 24 06                         	vmovups zmm1,ZMMWORD PTR [rsp+0x180]
   7c838:	62 f1 7c 48 11 4a 03                            	vmovups ZMMWORD PTR [rdx+0xc0],zmm1
   7c83f:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7c843:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7c84c:	62 f1 7c 48 10 4c 24 06                         	vmovups zmm1,ZMMWORD PTR [rsp+0x180]
   7c854:	62 f1 7c 48 11 4a 04                            	vmovups ZMMWORD PTR [rdx+0x100],zmm1
   7c85b:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7c85f:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7c868:	62 f1 7c 48 10 4c 24 06                         	vmovups zmm1,ZMMWORD PTR [rsp+0x180]
   7c870:	62 f1 7c 48 11 4a 05                            	vmovups ZMMWORD PTR [rdx+0x140],zmm1
   7c877:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7c87b:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7c884:	62 f1 7c 48 10 4c 24 06                         	vmovups zmm1,ZMMWORD PTR [rsp+0x180]
   7c88c:	62 f1 7c 48 11 4a 06                            	vmovups ZMMWORD PTR [rdx+0x180],zmm1
   7c893:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7c897:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7c8a0:	62 f1 fe 48 6f 4c 24 06                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x180]
   7c8a8:	62 f1 fe 48 7f 4a 07                            	vmovdqu64 ZMMWORD PTR [rdx+0x1c0],zmm1
   7c8af:	48 81 c2 00 02 00 00                            	add    rdx,0x200
   7c8b6:	48 83 c6 f8                                     	add    rsi,0xfffffffffffffff8
   7c8ba:	0f 85 10 ff ff ff                               	jne    7c7d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xf80>
   7c8c0:	48 85 c9                                        	test   rcx,rcx
   7c8c3:	74 2f                                           	je     7c8f4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x10a4>
   7c8c5:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7c8c9:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   7c8d0:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7c8d4:	c5 fd 7f 84 24 80 01 00 00                      	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
   7c8dd:	62 f1 fe 48 6f 4c 24 06                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x180]
   7c8e5:	62 f1 fe 48 7f 0a                               	vmovdqu64 ZMMWORD PTR [rdx],zmm1
   7c8eb:	48 83 c2 40                                     	add    rdx,0x40
   7c8ef:	48 ff c9                                        	dec    rcx
   7c8f2:	75 dc                                           	jne    7c8d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1080>
   7c8f4:	c5 fd 6f 0d 44 b5 f8 ff                         	vmovdqa ymm1,YMMWORD PTR [rip+0xfffffffffff8b544]        # 7e40 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x800>
   7c8fc:	48 b8 07 9a c1 77 0a 0e 00 00                   	movabs rax,0xe0a77c19a07
   7c906:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7c90a:	62 f1 fe 48 7f 02                               	vmovdqu64 ZMMWORD PTR [rdx],zmm0
   7c910:	c5 fe 7f 8c 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm1
   7c919:	48 89 84 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rax
   7c921:	4d 85 ff                                        	test   r15,r15
   7c924:	0f 84 4c 45 00 00                               	je     80e76 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5626>
   7c92a:	62 f2 fd 48 19 4c 24 32                         	vbroadcastsd zmm1,QWORD PTR [rsp+0x190]
   7c932:	62 f2 fd 48 59 44 24 31                         	vpbroadcastq zmm0,QWORD PTR [rsp+0x188]
   7c93a:	62 f2 fd 48 59 54 24 33                         	vpbroadcastq zmm2,QWORD PTR [rsp+0x198]
   7c942:	48 8b 44 24 70                                  	mov    rax,QWORD PTR [rsp+0x70]
   7c947:	62 f1 7c 48 29 4c 24 2c                         	vmovaps ZMMWORD PTR [rsp+0xb00],zmm1
   7c94f:	62 f2 fd 48 59 4c 24 34                         	vpbroadcastq zmm1,QWORD PTR [rsp+0x1a0]
   7c957:	62 f1 fd 48 7f 44 24 2d                         	vmovdqa64 ZMMWORD PTR [rsp+0xb40],zmm0
   7c95f:	62 f1 fd 48 7f 54 24 2b                         	vmovdqa64 ZMMWORD PTR [rsp+0xac0],zmm2
   7c967:	62 f1 fd 48 7f 4c 24 2a                         	vmovdqa64 ZMMWORD PTR [rsp+0xa80],zmm1
   7c96f:	eb 28                                           	jmp    7c999 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1149>
   7c971:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00    	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7c980:	4c 8b bc 24 20 06 00 00                         	mov    r15,QWORD PTR [rsp+0x620]
   7c988:	48 8b 84 24 18 06 00 00                         	mov    rax,QWORD PTR [rsp+0x618]
   7c990:	4d 85 ff                                        	test   r15,r15
   7c993:	0f 84 7f 44 00 00                               	je     80e18 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x55c8>
   7c999:	49 81 ff c8 00 00 00                            	cmp    r15,0xc8
   7c9a0:	bf c8 00 00 00                                  	mov    edi,0xc8
   7c9a5:	4c 8b b4 24 d8 00 00 00                         	mov    r14,QWORD PTR [rsp+0xd8]
   7c9ad:	48 89 c1                                        	mov    rcx,rax
   7c9b0:	48 c7 84 24 90 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x90],0x0
   7c9bc:	48 c7 84 24 40 06 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x640],0x0
   7c9c8:	48 89 8c 24 80 0b 00 00                         	mov    QWORD PTR [rsp+0xb80],rcx
   7c9d0:	49 0f 42 ff                                     	cmovb  rdi,r15
   7c9d4:	49 29 ff                                        	sub    r15,rdi
   7c9d7:	89 f8                                           	mov    eax,edi
   7c9d9:	48 8d 04 81                                     	lea    rax,[rcx+rax*4]
   7c9dd:	4c 89 bc 24 20 06 00 00                         	mov    QWORD PTR [rsp+0x620],r15
   7c9e5:	4c 8b bc 24 e0 00 00 00                         	mov    r15,QWORD PTR [rsp+0xe0]
   7c9ed:	48 89 84 24 18 06 00 00                         	mov    QWORD PTR [rsp+0x618],rax
   7c9f5:	4c 89 bc 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],r15
   7c9fd:	e9 04 02 00 00                                  	jmp    7cc06 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x13b6>
   7ca02:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7ca10:	62 f1 fd 48 6f 4c 24 20                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x800]
   7ca18:	62 f1 fd 48 6f 54 24 30                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xc00]
   7ca20:	62 f1 fd 48 6f 5c 24 1f                         	vmovdqa64 zmm3,ZMMWORD PTR [rsp+0x7c0]
   7ca28:	62 f1 fd 48 6f 64 24 2f                         	vmovdqa64 zmm4,ZMMWORD PTR [rsp+0xbc0]
   7ca30:	62 f1 fd 48 6f 74 24 1b                         	vmovdqa64 zmm6,ZMMWORD PTR [rsp+0x6c0]
   7ca38:	62 f1 fd 48 6f 7c 24 22                         	vmovdqa64 zmm7,ZMMWORD PTR [rsp+0x880]
   7ca40:	62 71 fd 48 6f 44 24 1c                         	vmovdqa64 zmm8,ZMMWORD PTR [rsp+0x700]
   7ca48:	62 71 fd 48 6f 4c 24 21                         	vmovdqa64 zmm9,ZMMWORD PTR [rsp+0x840]
   7ca50:	62 71 fd 48 6f 1d 66 b0 f8 ff                   	vmovdqa64 zmm11,ZMMWORD PTR [rip+0xfffffffffff8b066]        # 7ac0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x480>
   7ca5a:	62 71 fd 48 6f 25 9c b0 f8 ff                   	vmovdqa64 zmm12,ZMMWORD PTR [rip+0xfffffffffff8b09c]        # 7b00 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4c0>
   7ca64:	62 72 fd 48 59 2d 52 a8 f8 ff                   	vpbroadcastq zmm13,QWORD PTR [rip+0xfffffffffff8a852]        # 72c0 <GCC_except_table740+0x78>
   7ca6e:	48 8b 94 24 40 06 00 00                         	mov    rdx,QWORD PTR [rsp+0x640]
   7ca76:	48 8b 84 24 88 00 00 00                         	mov    rax,QWORD PTR [rsp+0x88]
   7ca7e:	48 8b bc 24 80 06 00 00                         	mov    rdi,QWORD PTR [rsp+0x680]
   7ca86:	48 69 ca c0 02 00 00                            	imul   rcx,rdx,0x2c0
   7ca8d:	48 ff c2                                        	inc    rdx
   7ca90:	48 89 94 24 40 06 00 00                         	mov    QWORD PTR [rsp+0x640],rdx
   7ca98:	62 f1 f5 48 6c c2                               	vpunpcklqdq zmm0,zmm1,zmm2
   7ca9e:	62 f1 f5 48 6d ca                               	vpunpckhqdq zmm1,zmm1,zmm2
   7caa4:	62 f1 e5 48 6c d4                               	vpunpcklqdq zmm2,zmm3,zmm4
   7caaa:	62 f1 e5 48 6d dc                               	vpunpckhqdq zmm3,zmm3,zmm4
   7cab0:	62 71 cd 48 6c f7                               	vpunpcklqdq zmm14,zmm6,zmm7
   7cab6:	62 f1 cd 48 6d f7                               	vpunpckhqdq zmm6,zmm6,zmm7
   7cabc:	62 d1 bd 48 6c f9                               	vpunpcklqdq zmm7,zmm8,zmm9
   7cac2:	62 51 bd 48 6d c1                               	vpunpckhqdq zmm8,zmm8,zmm9
   7cac8:	62 f1 fd 48 6f e0                               	vmovdqa64 zmm4,zmm0
   7cace:	62 f1 fd 48 6f e9                               	vmovdqa64 zmm5,zmm1
   7cad4:	62 51 fd 48 6f ce                               	vmovdqa64 zmm9,zmm14
   7cada:	62 71 fd 48 6f d6                               	vmovdqa64 zmm10,zmm6
   7cae0:	62 f2 a5 48 7e e2                               	vpermt2q zmm4,zmm11,zmm2
   7cae6:	62 f2 9d 48 7e c2                               	vpermt2q zmm0,zmm12,zmm2
   7caec:	62 f2 a5 48 7e eb                               	vpermt2q zmm5,zmm11,zmm3
   7caf2:	62 f2 9d 48 7e cb                               	vpermt2q zmm1,zmm12,zmm3
   7caf8:	62 72 a5 48 7e cf                               	vpermt2q zmm9,zmm11,zmm7
   7cafe:	62 72 9d 48 7e f7                               	vpermt2q zmm14,zmm12,zmm7
   7cb04:	62 52 a5 48 7e d0                               	vpermt2q zmm10,zmm11,zmm8
   7cb0a:	62 d2 9d 48 7e f0                               	vpermt2q zmm6,zmm12,zmm8
   7cb10:	62 f3 d5 48 71 dc 0c                            	vpshldq zmm3,zmm5,zmm4,0xc
   7cb17:	62 d1 dd 48 db d5                               	vpandq zmm2,zmm4,zmm13
   7cb1d:	62 f3 fd 48 71 e5 18                            	vpshldq zmm4,zmm0,zmm5,0x18
   7cb24:	62 f3 f5 48 71 c0 24                            	vpshldq zmm0,zmm1,zmm0,0x24
   7cb2b:	62 d3 cd 48 71 ee 24                            	vpshldq zmm5,zmm6,zmm14,0x24
   7cb32:	62 53 ad 48 71 c1 0c                            	vpshldq zmm8,zmm10,zmm9,0xc
   7cb39:	62 d1 b5 48 db fd                               	vpandq zmm7,zmm9,zmm13
   7cb3f:	62 53 8d 48 71 ca 18                            	vpshldq zmm9,zmm14,zmm10,0x18
   7cb46:	62 f1 f5 48 73 d1 10                            	vpsrlq zmm1,zmm1,0x10
   7cb4d:	62 f1 cd 48 73 d6 10                            	vpsrlq zmm6,zmm6,0x10
   7cb54:	62 f1 fd 48 7f 14 08                            	vmovdqa64 ZMMWORD PTR [rax+rcx*1],zmm2
   7cb5b:	62 d1 e5 48 db dd                               	vpandq zmm3,zmm3,zmm13
   7cb61:	62 d1 dd 48 db e5                               	vpandq zmm4,zmm4,zmm13
   7cb67:	62 d1 fd 48 db c5                               	vpandq zmm0,zmm0,zmm13
   7cb6d:	62 51 bd 48 db c5                               	vpandq zmm8,zmm8,zmm13
   7cb73:	62 51 b5 48 db cd                               	vpandq zmm9,zmm9,zmm13
   7cb79:	62 d1 d5 48 db ed                               	vpandq zmm5,zmm5,zmm13
   7cb7f:	62 f1 fd 48 7f 5c 08 01                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x40],zmm3
   7cb87:	62 f1 fd 48 7f 64 08 02                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x80],zmm4
   7cb8f:	62 f1 fd 48 7f 44 08 03                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0xc0],zmm0
   7cb97:	62 f1 fd 48 7f 4c 08 04                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x100],zmm1
   7cb9f:	62 f1 fd 48 7f 7c 08 05                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x140],zmm7
   7cba7:	62 71 fd 48 7f 44 08 06                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x180],zmm8
   7cbaf:	62 71 fd 48 7f 4c 08 07                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x1c0],zmm9
   7cbb7:	62 f1 fd 48 7f 6c 08 08                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x200],zmm5
   7cbbf:	62 f1 fd 48 7f 74 08 09                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x240],zmm6
   7cbc7:	c5 fd 6f 84 24 80 03 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x380]
   7cbd0:	c5 fd 7f 84 08 80 02 00 00                      	vmovdqa YMMWORD PTR [rax+rcx*1+0x280],ymm0
   7cbd9:	c6 84 08 a0 02 00 00 01                         	mov    BYTE PTR [rax+rcx*1+0x2a0],0x1
   7cbe1:	88 9c 08 a1 02 00 00                            	mov    BYTE PTR [rax+rcx*1+0x2a1],bl
   7cbe8:	48 8b 8c 24 00 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x100]
   7cbf0:	48 8b 5c 24 60                                  	mov    rbx,QWORD PTR [rsp+0x60]
   7cbf5:	48 89 94 24 90 00 00 00                         	mov    QWORD PTR [rsp+0x90],rdx
   7cbfd:	48 85 ff                                        	test   rdi,rdi
   7cc00:	0f 84 5a 06 00 00                               	je     7d260 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a10>
   7cc06:	48 83 ff 08                                     	cmp    rdi,0x8
   7cc0a:	ba 08 00 00 00                                  	mov    edx,0x8
   7cc0f:	b8 ff ff ff ff                                  	mov    eax,0xffffffff
   7cc14:	48 89 bc 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],rdi
   7cc1c:	48 0f 42 d7                                     	cmovb  rdx,rdi
   7cc20:	89 d6                                           	mov    esi,edx
   7cc22:	48 83 ff 01                                     	cmp    rdi,0x1
   7cc26:	75 28                                           	jne    7cc50 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1400>
   7cc28:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   7cc2e:	bb ff ff ff ff                                  	mov    ebx,0xffffffff
   7cc33:	41 bb ff ff ff ff                               	mov    r11d,0xffffffff
   7cc39:	41 b9 ff ff ff ff                               	mov    r9d,0xffffffff
   7cc3f:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7cc45:	bf ff ff ff ff                                  	mov    edi,0xffffffff
   7cc4a:	eb 51                                           	jmp    7cc9d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x144d>
   7cc4c:	0f 1f 40 00                                     	nop    DWORD PTR [rax+0x0]
   7cc50:	49 89 fa                                        	mov    r10,rdi
   7cc53:	8b 79 04                                        	mov    edi,DWORD PTR [rcx+0x4]
   7cc56:	49 83 fa 03                                     	cmp    r10,0x3
   7cc5a:	72 24                                           	jb     7cc80 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1430>
   7cc5c:	44 8b 41 08                                     	mov    r8d,DWORD PTR [rcx+0x8]
   7cc60:	0f 85 92 05 00 00                               	jne    7d1f8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x19a8>
   7cc66:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   7cc6c:	bb ff ff ff ff                                  	mov    ebx,0xffffffff
   7cc71:	41 bb ff ff ff ff                               	mov    r11d,0xffffffff
   7cc77:	41 b9 ff ff ff ff                               	mov    r9d,0xffffffff
   7cc7d:	eb 1e                                           	jmp    7cc9d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x144d>
   7cc7f:	90                                              	nop
   7cc80:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   7cc86:	bb ff ff ff ff                                  	mov    ebx,0xffffffff
   7cc8b:	41 bb ff ff ff ff                               	mov    r11d,0xffffffff
   7cc91:	41 b9 ff ff ff ff                               	mov    r9d,0xffffffff
   7cc97:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7cc9d:	48 8d 34 b1                                     	lea    rsi,[rcx+rsi*4]
   7cca1:	8b 09                                           	mov    ecx,DWORD PTR [rcx]
   7cca3:	48 29 94 24 80 06 00 00                         	sub    QWORD PTR [rsp+0x680],rdx
   7ccab:	48 89 b4 24 00 01 00 00                         	mov    QWORD PTR [rsp+0x100],rsi
   7ccb3:	89 8c 24 80 03 00 00                            	mov    DWORD PTR [rsp+0x380],ecx
   7ccba:	89 bc 24 84 03 00 00                            	mov    DWORD PTR [rsp+0x384],edi
   7ccc1:	44 89 84 24 88 03 00 00                         	mov    DWORD PTR [rsp+0x388],r8d
   7ccc9:	44 89 8c 24 8c 03 00 00                         	mov    DWORD PTR [rsp+0x38c],r9d
   7ccd1:	44 89 9c 24 90 03 00 00                         	mov    DWORD PTR [rsp+0x390],r11d
   7ccd9:	89 9c 24 94 03 00 00                            	mov    DWORD PTR [rsp+0x394],ebx
   7cce0:	44 89 94 24 98 03 00 00                         	mov    DWORD PTR [rsp+0x398],r10d
   7cce8:	4c 8b 4c 24 60                                  	mov    r9,QWORD PTR [rsp+0x60]
   7cced:	4c 8b 54 24 40                                  	mov    r10,QWORD PTR [rsp+0x40]
   7ccf2:	89 84 24 9c 03 00 00                            	mov    DWORD PTR [rsp+0x39c],eax
   7ccf9:	48 8d 84 24 a0 01 00 00                         	lea    rax,[rsp+0x1a0]
   7cd01:	31 c9                                           	xor    ecx,ecx
   7cd03:	eb 44                                           	jmp    7cd49 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x14f9>
   7cd05:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   7cd10:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7cd14:	c5 fd 7f 84 24 c0 08 00 00                      	vmovdqa YMMWORD PTR [rsp+0x8c0],ymm0
   7cd1d:	c5 fd 6f 8c 24 c0 08 00 00                      	vmovdqa ymm1,YMMWORD PTR [rsp+0x8c0]
   7cd26:	48 ff c1                                        	inc    rcx
   7cd29:	c5 fe 7f 48 e0                                  	vmovdqu YMMWORD PTR [rax-0x20],ymm1
   7cd2e:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7cd32:	48 83 c0 40                                     	add    rax,0x40
   7cd36:	c5 fd 7f 8c 24 00 04 00 00                      	vmovdqa YMMWORD PTR [rsp+0x400],ymm1
   7cd3f:	48 83 f9 08                                     	cmp    rcx,0x8
   7cd43:	0f 84 27 01 00 00                               	je     7ce70 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1620>
   7cd49:	8b bc 8c 80 03 00 00                            	mov    edi,DWORD PTR [rsp+rcx*4+0x380]
   7cd50:	ba ff ff ff ff                                  	mov    edx,0xffffffff
   7cd55:	48 39 d7                                        	cmp    rdi,rdx
   7cd58:	74 b6                                           	je     7cd10 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x14c0>
   7cd5a:	49 39 ff                                        	cmp    r15,rdi
   7cd5d:	0f 86 20 47 00 00                               	jbe    81483 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c33>
   7cd63:	49 8b 3c fe                                     	mov    rdi,QWORD PTR [r14+rdi*8]
   7cd67:	48 3b 7c 24 50                                  	cmp    rdi,QWORD PTR [rsp+0x50]
   7cd6c:	0f 83 fe 46 00 00                               	jae    81470 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c20>
   7cd72:	41 8b 14 bc                                     	mov    edx,DWORD PTR [r12+rdi*4]
   7cd76:	89 d7                                           	mov    edi,edx
   7cd78:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7cd7e:	49 39 f9                                        	cmp    r9,rdi
   7cd81:	0f 86 0a 47 00 00                               	jbe    81491 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c41>
   7cd87:	48 c1 e7 06                                     	shl    rdi,0x6
   7cd8b:	c4 c1 7c 10 04 3a                               	vmovups ymm0,YMMWORD PTR [r10+rdi*1]
   7cd91:	c5 fc 29 84 24 c0 08 00 00                      	vmovaps YMMWORD PTR [rsp+0x8c0],ymm0
   7cd9a:	85 d2                                           	test   edx,edx
   7cd9c:	78 12                                           	js     7cdb0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1560>
   7cd9e:	c4 c1 7e 6f 44 3a 20                            	vmovdqu ymm0,YMMWORD PTR [r10+rdi*1+0x20]
   7cda5:	e9 73 ff ff ff                                  	jmp    7cd1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x14cd>
   7cdaa:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   7cdb0:	49 8d 54 3a 20                                  	lea    rdx,[r10+rdi*1+0x20]
   7cdb5:	4d 89 f7                                        	mov    r15,r14
   7cdb8:	31 f6                                           	xor    esi,esi
   7cdba:	31 ff                                           	xor    edi,edi
   7cdbc:	45 31 c0                                        	xor    r8d,r8d
   7cdbf:	4c 8d b4 24 40 0c 00 00                         	lea    r14,[rsp+0xc40]
   7cdc7:	4c 8d ac 24 00 04 00 00                         	lea    r13,[rsp+0x400]
   7cdcf:	c5 fc 10 02                                     	vmovups ymm0,YMMWORD PTR [rdx]
   7cdd3:	31 d2                                           	xor    edx,edx
   7cdd5:	c5 fc 29 84 24 40 0c 00 00                      	vmovaps YMMWORD PTR [rsp+0xc40],ymm0
   7cdde:	c5 fc 10 05 ba b1 f8 ff                         	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffff8b1ba]        # 7fa0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x960>
   7cde6:	c5 fc 29 84 24 00 04 00 00                      	vmovaps YMMWORD PTR [rsp+0x400],ymm0
   7cdef:	49 2b 36                                        	sub    rsi,QWORD PTR [r14]
   7cdf2:	49 1b 7e 08                                     	sbb    rdi,QWORD PTR [r14+0x8]
   7cdf6:	4d 1b 46 10                                     	sbb    r8,QWORD PTR [r14+0x10]
   7cdfa:	49 1b 56 18                                     	sbb    rdx,QWORD PTR [r14+0x18]
   7cdfe:	4d 19 e4                                        	sbb    r12,r12
   7ce01:	4d 8b 4d 00                                     	mov    r9,QWORD PTR [r13+0x0]
   7ce05:	4d 8b 55 08                                     	mov    r10,QWORD PTR [r13+0x8]
   7ce09:	4d 8b 5d 10                                     	mov    r11,QWORD PTR [r13+0x10]
   7ce0d:	49 8b 5d 18                                     	mov    rbx,QWORD PTR [r13+0x18]
   7ce11:	4d 21 e1                                        	and    r9,r12
   7ce14:	4d 21 e2                                        	and    r10,r12
   7ce17:	4d 21 e3                                        	and    r11,r12
   7ce1a:	4c 21 e3                                        	and    rbx,r12
   7ce1d:	4c 01 ce                                        	add    rsi,r9
   7ce20:	4c 11 d7                                        	adc    rdi,r10
   7ce23:	4d 11 d8                                        	adc    r8,r11
   7ce26:	48 11 da                                        	adc    rdx,rbx
   7ce29:	4d 89 fe                                        	mov    r14,r15
   7ce2c:	c4 e1 f9 6e c2                                  	vmovq  xmm0,rdx
   7ce31:	c4 c1 f9 6e c8                                  	vmovq  xmm1,r8
   7ce36:	c4 e1 f9 6e d6                                  	vmovq  xmm2,rsi
   7ce3b:	4c 8b bc 24 c0 03 00 00                         	mov    r15,QWORD PTR [rsp+0x3c0]
   7ce43:	4c 8b 54 24 40                                  	mov    r10,QWORD PTR [rsp+0x40]
   7ce48:	4c 8b 4c 24 60                                  	mov    r9,QWORD PTR [rsp+0x60]
   7ce4d:	4c 8b 64 24 38                                  	mov    r12,QWORD PTR [rsp+0x38]
   7ce52:	c5 f1 6c c0                                     	vpunpcklqdq xmm0,xmm1,xmm0
   7ce56:	c4 e1 f9 6e cf                                  	vmovq  xmm1,rdi
   7ce5b:	c5 e9 6c c9                                     	vpunpcklqdq xmm1,xmm2,xmm1
   7ce5f:	c4 e3 75 38 c0 01                               	vinserti128 ymm0,ymm1,xmm0,0x1
   7ce65:	e9 b3 fe ff ff                                  	jmp    7cd1d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x14cd>
   7ce6a:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   7ce70:	62 f1 7c 48 10 44 24 0d                         	vmovups zmm0,ZMMWORD PTR [rsp+0x340]
   7ce78:	62 f1 7c 48 10 4c 24 0c                         	vmovups zmm1,ZMMWORD PTR [rsp+0x300]
   7ce80:	62 f1 7c 48 10 54 24 0b                         	vmovups zmm2,ZMMWORD PTR [rsp+0x2c0]
   7ce88:	62 f1 7c 48 10 5c 24 09                         	vmovups zmm3,ZMMWORD PTR [rsp+0x240]
   7ce90:	62 f1 7c 48 29 44 24 17                         	vmovaps ZMMWORD PTR [rsp+0x5c0],zmm0
   7ce98:	62 f1 7c 48 10 44 24 06                         	vmovups zmm0,ZMMWORD PTR [rsp+0x180]
   7cea0:	62 f1 7c 48 29 4c 24 16                         	vmovaps ZMMWORD PTR [rsp+0x580],zmm1
   7cea8:	62 f1 7c 48 10 4c 24 0a                         	vmovups zmm1,ZMMWORD PTR [rsp+0x280]
   7ceb0:	62 f1 7c 48 29 54 24 15                         	vmovaps ZMMWORD PTR [rsp+0x540],zmm2
   7ceb8:	62 f1 7c 48 10 54 24 08                         	vmovups zmm2,ZMMWORD PTR [rsp+0x200]
   7cec0:	62 f1 7c 48 29 5c 24 13                         	vmovaps ZMMWORD PTR [rsp+0x4c0],zmm3
   7cec8:	62 f1 7c 48 29 44 24 10                         	vmovaps ZMMWORD PTR [rsp+0x400],zmm0
   7ced0:	62 f1 7c 48 29 4c 24 14                         	vmovaps ZMMWORD PTR [rsp+0x500],zmm1
   7ced8:	62 f1 7c 48 10 4c 24 07                         	vmovups zmm1,ZMMWORD PTR [rsp+0x1c0]
   7cee0:	62 f1 7c 48 29 54 24 12                         	vmovaps ZMMWORD PTR [rsp+0x480],zmm2
   7cee8:	c5 fd 6f 84 24 00 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x400]
   7cef1:	62 f1 7c 48 29 4c 24 11                         	vmovaps ZMMWORD PTR [rsp+0x440],zmm1
   7cef9:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7cefe:	0f 84 9c 01 00 00                               	je     7d0a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1850>
   7cf04:	31 db                                           	xor    ebx,ebx
   7cf06:	c5 fd 6f 84 24 40 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x440]
   7cf0f:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7cf14:	0f 84 ab 01 00 00                               	je     7d0c5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1875>
   7cf1a:	c5 fd 6f 84 24 80 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x480]
   7cf23:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7cf28:	0f 84 c5 01 00 00                               	je     7d0f3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x18a3>
   7cf2e:	c5 fd 6f 84 24 c0 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x4c0]
   7cf37:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7cf3c:	0f 84 df 01 00 00                               	je     7d121 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x18d1>
   7cf42:	c5 fd 6f 84 24 00 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x500]
   7cf4b:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7cf50:	0f 84 f9 01 00 00                               	je     7d14f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x18ff>
   7cf56:	c5 fd 6f 84 24 40 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x540]
   7cf5f:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7cf64:	0f 84 13 02 00 00                               	je     7d17d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x192d>
   7cf6a:	c5 fd 6f 84 24 80 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x580]
   7cf73:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7cf78:	0f 84 2d 02 00 00                               	je     7d1ab <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x195b>
   7cf7e:	c5 fd 6f 84 24 c0 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x5c0]
   7cf87:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7cf8c:	0f 84 47 02 00 00                               	je     7d1d9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1989>
   7cf92:	62 f1 7c 48 28 4c 24 12                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x480]
   7cf9a:	62 f1 7c 48 28 5c 24 16                         	vmovaps zmm3,ZMMWORD PTR [rsp+0x580]
   7cfa2:	62 f1 7c 48 28 54 24 14                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x500]
   7cfaa:	62 f1 7c 48 28 44 24 10                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x400]
   7cfb2:	62 f1 fe 48 6f a4 24 20 04 00 00                	vmovdqu64 zmm4,ZMMWORD PTR [rsp+0x420]
   7cfbd:	48 8b 84 24 40 06 00 00                         	mov    rax,QWORD PTR [rsp+0x640]
   7cfc5:	62 f3 f5 48 1a 4c 24 26 01                      	vinsertf64x4 zmm1,zmm1,YMMWORD PTR [rsp+0x4c0],0x1
   7cfce:	62 f3 ed 48 1a 54 24 2a 01                      	vinsertf64x4 zmm2,zmm2,YMMWORD PTR [rsp+0x540],0x1
   7cfd7:	62 f3 fd 48 1a 44 24 22 01                      	vinsertf64x4 zmm0,zmm0,YMMWORD PTR [rsp+0x440],0x1
   7cfe0:	62 f1 7c 48 29 4c 24 30                         	vmovaps ZMMWORD PTR [rsp+0xc00],zmm1
   7cfe8:	62 f3 e5 48 1a 4c 24 2e 01                      	vinsertf64x4 zmm1,zmm3,YMMWORD PTR [rsp+0x5c0],0x1
   7cff1:	62 f1 7c 48 29 54 24 1f                         	vmovaps ZMMWORD PTR [rsp+0x7c0],zmm2
   7cff9:	62 f1 fe 48 6f 94 24 20 05 00 00                	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x520]
   7d004:	62 f1 fe 48 6f 9c 24 a0 05 00 00                	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x5a0]
   7d00f:	62 f1 7c 48 29 44 24 20                         	vmovaps ZMMWORD PTR [rsp+0x800],zmm0
   7d017:	62 f3 dd 48 3a 44 24 23 01                      	vinserti64x4 zmm0,zmm4,YMMWORD PTR [rsp+0x460],0x1
   7d020:	62 f3 ed 48 3a 54 24 2b 01                      	vinserti64x4 zmm2,zmm2,YMMWORD PTR [rsp+0x560],0x1
   7d029:	62 f1 7c 48 29 4c 24 2f                         	vmovaps ZMMWORD PTR [rsp+0xbc0],zmm1
   7d031:	62 f1 7c 48 10 8c 24 a0 04 00 00                	vmovups zmm1,ZMMWORD PTR [rsp+0x4a0]
   7d03c:	62 f1 fd 48 7f 44 24 1b                         	vmovdqa64 ZMMWORD PTR [rsp+0x6c0],zmm0
   7d044:	62 f3 f5 48 1a 4c 24 27 01                      	vinsertf64x4 zmm1,zmm1,YMMWORD PTR [rsp+0x4e0],0x1
   7d04d:	62 f1 fd 48 7f 54 24 1c                         	vmovdqa64 ZMMWORD PTR [rsp+0x700],zmm2
   7d055:	62 f1 7c 48 29 4c 24 22                         	vmovaps ZMMWORD PTR [rsp+0x880],zmm1
   7d05d:	62 f3 e5 48 3a 4c 24 2f 01                      	vinserti64x4 zmm1,zmm3,YMMWORD PTR [rsp+0x5e0],0x1
   7d066:	62 f1 fd 48 7f 4c 24 21                         	vmovdqa64 ZMMWORD PTR [rsp+0x840],zmm1
   7d06e:	48 3b 84 24 80 00 00 00                         	cmp    rax,QWORD PTR [rsp+0x80]
   7d076:	0f 85 94 f9 ff ff                               	jne    7ca10 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x11c0>
   7d07c:	48 8d bc 24 80 00 00 00                         	lea    rdi,[rsp+0x80]
   7d084:	c5 f8 77                                        	vzeroupper
   7d087:	e8 74 c9 00 00                                  	call   89a00 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecNtNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns6ColumnE8grow_oneBT_>
   7d08c:	e9 7f f9 ff ff                                  	jmp    7ca10 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x11c0>
   7d091:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00    	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7d0a0:	c5 fd 6f 84 24 20 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x420]
   7d0a9:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d0ae:	0f 94 c3                                        	sete   bl
   7d0b1:	c5 fd 6f 84 24 40 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x440]
   7d0ba:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d0bf:	0f 85 55 fe ff ff                               	jne    7cf1a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x16ca>
   7d0c5:	c5 fd 6f 84 24 60 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x460]
   7d0ce:	8d 43 02                                        	lea    eax,[rbx+0x2]
   7d0d1:	0f b6 cb                                        	movzx  ecx,bl
   7d0d4:	0f b6 d8                                        	movzx  ebx,al
   7d0d7:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d0dc:	0f 45 d9                                        	cmovne ebx,ecx
   7d0df:	c5 fd 6f 84 24 80 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x480]
   7d0e8:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d0ed:	0f 85 3b fe ff ff                               	jne    7cf2e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x16de>
   7d0f3:	c5 fd 6f 84 24 a0 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x4a0]
   7d0fc:	8d 43 04                                        	lea    eax,[rbx+0x4]
   7d0ff:	0f b6 cb                                        	movzx  ecx,bl
   7d102:	0f b6 d8                                        	movzx  ebx,al
   7d105:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d10a:	0f 45 d9                                        	cmovne ebx,ecx
   7d10d:	c5 fd 6f 84 24 c0 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x4c0]
   7d116:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d11b:	0f 85 21 fe ff ff                               	jne    7cf42 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x16f2>
   7d121:	c5 fd 6f 84 24 e0 04 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x4e0]
   7d12a:	8d 43 08                                        	lea    eax,[rbx+0x8]
   7d12d:	0f b6 cb                                        	movzx  ecx,bl
   7d130:	0f b6 d8                                        	movzx  ebx,al
   7d133:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d138:	0f 45 d9                                        	cmovne ebx,ecx
   7d13b:	c5 fd 6f 84 24 00 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x500]
   7d144:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d149:	0f 85 07 fe ff ff                               	jne    7cf56 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1706>
   7d14f:	c5 fd 6f 84 24 20 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x520]
   7d158:	8d 43 10                                        	lea    eax,[rbx+0x10]
   7d15b:	0f b6 cb                                        	movzx  ecx,bl
   7d15e:	0f b6 d8                                        	movzx  ebx,al
   7d161:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d166:	0f 45 d9                                        	cmovne ebx,ecx
   7d169:	c5 fd 6f 84 24 40 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x540]
   7d172:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d177:	0f 85 ed fd ff ff                               	jne    7cf6a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x171a>
   7d17d:	c5 fd 6f 84 24 60 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x560]
   7d186:	8d 43 20                                        	lea    eax,[rbx+0x20]
   7d189:	0f b6 cb                                        	movzx  ecx,bl
   7d18c:	0f b6 d8                                        	movzx  ebx,al
   7d18f:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d194:	0f 45 d9                                        	cmovne ebx,ecx
   7d197:	c5 fd 6f 84 24 80 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x580]
   7d1a0:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d1a5:	0f 85 d3 fd ff ff                               	jne    7cf7e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x172e>
   7d1ab:	c5 fd 6f 84 24 a0 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x5a0]
   7d1b4:	8d 43 40                                        	lea    eax,[rbx+0x40]
   7d1b7:	0f b6 cb                                        	movzx  ecx,bl
   7d1ba:	0f b6 d8                                        	movzx  ebx,al
   7d1bd:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d1c2:	0f 45 d9                                        	cmovne ebx,ecx
   7d1c5:	c5 fd 6f 84 24 c0 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x5c0]
   7d1ce:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d1d3:	0f 85 b9 fd ff ff                               	jne    7cf92 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1742>
   7d1d9:	c5 fd 6f 84 24 e0 05 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x5e0]
   7d1e2:	8d 43 80                                        	lea    eax,[rbx-0x80]
   7d1e5:	0f b6 cb                                        	movzx  ecx,bl
   7d1e8:	0f b6 d8                                        	movzx  ebx,al
   7d1eb:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7d1f0:	0f 45 d9                                        	cmovne ebx,ecx
   7d1f3:	e9 9a fd ff ff                                  	jmp    7cf92 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1742>
   7d1f8:	44 8b 49 0c                                     	mov    r9d,DWORD PTR [rcx+0xc]
   7d1fc:	49 83 fa 05                                     	cmp    r10,0x5
   7d200:	72 16                                           	jb     7d218 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x19c8>
   7d202:	44 8b 59 10                                     	mov    r11d,DWORD PTR [rcx+0x10]
   7d206:	75 26                                           	jne    7d22e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x19de>
   7d208:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   7d20e:	bb ff ff ff ff                                  	mov    ebx,0xffffffff
   7d213:	e9 85 fa ff ff                                  	jmp    7cc9d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x144d>
   7d218:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   7d21e:	bb ff ff ff ff                                  	mov    ebx,0xffffffff
   7d223:	41 bb ff ff ff ff                               	mov    r11d,0xffffffff
   7d229:	e9 6f fa ff ff                                  	jmp    7cc9d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x144d>
   7d22e:	8b 59 14                                        	mov    ebx,DWORD PTR [rcx+0x14]
   7d231:	48 83 bc 24 80 06 00 00 07                      	cmp    QWORD PTR [rsp+0x680],0x7
   7d23a:	72 12                                           	jb     7d24e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x19fe>
   7d23c:	44 8b 51 18                                     	mov    r10d,DWORD PTR [rcx+0x18]
   7d240:	0f 84 57 fa ff ff                               	je     7cc9d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x144d>
   7d246:	8b 41 1c                                        	mov    eax,DWORD PTR [rcx+0x1c]
   7d249:	e9 4f fa ff ff                                  	jmp    7cc9d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x144d>
   7d24e:	41 ba ff ff ff ff                               	mov    r10d,0xffffffff
   7d254:	e9 44 fa ff ff                                  	jmp    7cc9d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x144d>
   7d259:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   7d260:	48 83 bc 24 40 06 00 00 1a                      	cmp    QWORD PTR [rsp+0x640],0x1a
   7d269:	0f 83 52 42 00 00                               	jae    814c1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c71>
   7d26f:	48 8b 8c 24 80 0b 00 00                         	mov    rcx,QWORD PTR [rsp+0xb80]
   7d277:	48 8b b4 24 b8 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xb8]
   7d27f:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   7d284:	8b 39                                           	mov    edi,DWORD PTR [rcx]
   7d286:	48 39 fe                                        	cmp    rsi,rdi
   7d289:	0f 86 87 43 00 00                               	jbe    81616 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5dc6>
   7d28f:	48 8b 8c 24 b0 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xb0]
   7d297:	49 bf 63 c2 e5 9c c8 60 00 00                   	movabs r15,0x60c89ce5c263
   7d2a1:	0f b6 0c 39                                     	movzx  ecx,BYTE PTR [rcx+rdi*1]
   7d2a5:	48 ff c9                                        	dec    rcx
   7d2a8:	48 89 8c 24 28 06 00 00                         	mov    QWORD PTR [rsp+0x628],rcx
   7d2b0:	0f 84 b2 35 00 00                               	je     80868 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5018>
   7d2b6:	4c 8b 74 24 50                                  	mov    r14,QWORD PTR [rsp+0x50]
   7d2bb:	31 c9                                           	xor    ecx,ecx
   7d2bd:	eb 32                                           	jmp    7d2f1 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1aa1>
   7d2bf:	90                                              	nop
   7d2c0:	48 8b 8c 24 60 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x160]
   7d2c8:	62 71 fd 48 7f 5c 24 06                         	vmovdqa64 ZMMWORD PTR [rsp+0x180],zmm11
   7d2d0:	62 71 fd 48 7f 54 24 07                         	vmovdqa64 ZMMWORD PTR [rsp+0x1c0],zmm10
   7d2d8:	62 f1 fd 48 7f 74 24 08                         	vmovdqa64 ZMMWORD PTR [rsp+0x200],zmm6
   7d2e0:	48 ff c1                                        	inc    rcx
   7d2e3:	48 3b 8c 24 28 06 00 00                         	cmp    rcx,QWORD PTR [rsp+0x628]
   7d2eb:	0f 84 5f 35 00 00                               	je     80850 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5000>
   7d2f1:	62 f2 fd 48 59 05 45 a0 f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff8a045]        # 7340 <GCC_except_table740+0xf8>
   7d2fb:	62 f1 7c 48 28 54 24 2d                         	vmovaps zmm2,ZMMWORD PTR [rsp+0xb40]
   7d303:	62 f1 7c 48 28 4c 24 2c                         	vmovaps zmm1,ZMMWORD PTR [rsp+0xb00]
   7d30b:	48 8b 84 24 90 00 00 00                         	mov    rax,QWORD PTR [rsp+0x90]
   7d313:	48 89 8c 24 60 01 00 00                         	mov    QWORD PTR [rsp+0x160],rcx
   7d31b:	48 c7 84 24 f8 00 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0xf8],0x0
   7d327:	48 89 84 24 30 06 00 00                         	mov    QWORD PTR [rsp+0x630],rax
   7d32f:	62 f1 fd 48 7f 44 24 31                         	vmovdqa64 ZMMWORD PTR [rsp+0xc40],zmm0
   7d337:	62 f1 7c 48 29 54 24 32                         	vmovaps ZMMWORD PTR [rsp+0xc80],zmm2
   7d33f:	62 f1 7c 48 29 4c 24 33                         	vmovaps ZMMWORD PTR [rsp+0xcc0],zmm1
   7d347:	62 f1 fd 48 6f 54 24 2b                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xac0]
   7d34f:	62 f1 fd 48 6f 4c 24 2a                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0xa80]
   7d357:	62 f1 fd 48 7f 54 24 34                         	vmovdqa64 ZMMWORD PTR [rsp+0xd00],zmm2
   7d35f:	62 f1 fd 48 7f 4c 24 35                         	vmovdqa64 ZMMWORD PTR [rsp+0xd40],zmm1
   7d367:	48 85 c0                                        	test   rax,rax
   7d36a:	0f 84 d0 1d 00 00                               	je     7f140 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x38f0>
   7d370:	62 f1 7c 48 28 54 24 2d                         	vmovaps zmm2,ZMMWORD PTR [rsp+0xb40]
   7d378:	62 f1 7c 48 28 4c 24 2c                         	vmovaps zmm1,ZMMWORD PTR [rsp+0xb00]
   7d380:	62 f2 fd 48 59 05 b6 9f f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff89fb6]        # 7340 <GCC_except_table740+0xf8>
   7d38a:	48 c7 84 24 c0 06 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x6c0],0x0
   7d396:	62 f1 7c 48 29 54 24 20                         	vmovaps ZMMWORD PTR [rsp+0x800],zmm2
   7d39e:	62 f1 7c 48 29 4c 24 21                         	vmovaps ZMMWORD PTR [rsp+0x840],zmm1
   7d3a6:	62 f1 fd 48 6f 54 24 2b                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xac0]
   7d3ae:	62 f1 fd 48 6f 4c 24 2a                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0xa80]
   7d3b6:	62 f1 fd 48 7f 44 24 1f                         	vmovdqa64 ZMMWORD PTR [rsp+0x7c0],zmm0
   7d3be:	62 f1 fd 48 7f 54 24 22                         	vmovdqa64 ZMMWORD PTR [rsp+0x880],zmm2
   7d3c6:	62 f1 fd 48 7f 4c 24 1c                         	vmovdqa64 ZMMWORD PTR [rsp+0x700],zmm1
   7d3ce:	e9 1b 02 00 00                                  	jmp    7d5ee <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d9e>
   7d3d3:	66 66 66 66 2e 0f 1f 84 00 00 00 00 00          	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7d3e0:	62 f1 fe 48 6f 44 24 23                         	vmovdqu64 zmm0,ZMMWORD PTR [rsp+0x8c0]
   7d3e8:	62 f1 fe 48 6f 4c 24 24                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x900]
   7d3f0:	62 f1 fe 48 6f 54 24 25                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x940]
   7d3f8:	62 f1 fe 48 6f 5c 24 26                         	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x980]
   7d400:	62 f1 fd 48 6f 35 b6 a6 f8 ff                   	vmovdqa64 zmm6,ZMMWORD PTR [rip+0xfffffffffff8a6b6]        # 7ac0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x480>
   7d40a:	62 f1 fd 48 6f 3d ec a6 f8 ff                   	vmovdqa64 zmm7,ZMMWORD PTR [rip+0xfffffffffff8a6ec]        # 7b00 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4c0>
   7d414:	62 72 fd 48 59 05 a2 9e f8 ff                   	vpbroadcastq zmm8,QWORD PTR [rip+0xfffffffffff89ea2]        # 72c0 <GCC_except_table740+0x78>
   7d41e:	4c 8b 64 24 38                                  	mov    r12,QWORD PTR [rsp+0x38]
   7d423:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   7d429:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   7d42f:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   7d435:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   7d43b:	62 f1 fd 48 6f dc                               	vmovdqa64 zmm3,zmm4
   7d441:	62 f1 fd 48 6f e8                               	vmovdqa64 zmm5,zmm0
   7d447:	62 f2 cd 48 7e d9                               	vpermt2q zmm3,zmm6,zmm1
   7d44d:	62 f2 c5 48 7e e1                               	vpermt2q zmm4,zmm7,zmm1
   7d453:	62 f2 cd 48 7e ea                               	vpermt2q zmm5,zmm6,zmm2
   7d459:	62 f2 c5 48 7e c2                               	vpermt2q zmm0,zmm7,zmm2
   7d45f:	62 f3 d5 48 71 d3 0c                            	vpshldq zmm2,zmm5,zmm3,0xc
   7d466:	62 d1 e5 48 db c8                               	vpandq zmm1,zmm3,zmm8
   7d46c:	62 f3 dd 48 71 dd 18                            	vpshldq zmm3,zmm4,zmm5,0x18
   7d473:	62 f3 fd 48 71 e4 24                            	vpshldq zmm4,zmm0,zmm4,0x24
   7d47a:	62 f1 fd 48 73 d0 10                            	vpsrlq zmm0,zmm0,0x10
   7d481:	62 d1 fd 48 7f 4d 00                            	vmovdqa64 ZMMWORD PTR [r13+0x0],zmm1
   7d488:	62 d1 ed 48 db d0                               	vpandq zmm2,zmm2,zmm8
   7d48e:	62 d1 e5 48 db d8                               	vpandq zmm3,zmm3,zmm8
   7d494:	62 d1 dd 48 db e0                               	vpandq zmm4,zmm4,zmm8
   7d49a:	62 d1 fd 48 7f 55 01                            	vmovdqa64 ZMMWORD PTR [r13+0x40],zmm2
   7d4a1:	62 d1 fd 48 7f 5d 02                            	vmovdqa64 ZMMWORD PTR [r13+0x80],zmm3
   7d4a8:	62 d1 fd 48 7f 65 03                            	vmovdqa64 ZMMWORD PTR [r13+0xc0],zmm4
   7d4af:	62 d1 fd 48 7f 45 04                            	vmovdqa64 ZMMWORD PTR [r13+0x100],zmm0
   7d4b6:	62 f1 fe 48 6f 44 24 06                         	vmovdqu64 zmm0,ZMMWORD PTR [rsp+0x180]
   7d4be:	62 f1 fe 48 6f 4c 24 07                         	vmovdqu64 zmm1,ZMMWORD PTR [rsp+0x1c0]
   7d4c6:	62 f1 fe 48 6f 54 24 08                         	vmovdqu64 zmm2,ZMMWORD PTR [rsp+0x200]
   7d4ce:	62 f1 fe 48 6f 5c 24 09                         	vmovdqu64 zmm3,ZMMWORD PTR [rsp+0x240]
   7d4d6:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   7d4dc:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   7d4e2:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   7d4e8:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   7d4ee:	62 f1 fd 48 6f dc                               	vmovdqa64 zmm3,zmm4
   7d4f4:	62 f1 fd 48 6f e8                               	vmovdqa64 zmm5,zmm0
   7d4fa:	62 f2 cd 48 7e d9                               	vpermt2q zmm3,zmm6,zmm1
   7d500:	62 f2 c5 48 7e e1                               	vpermt2q zmm4,zmm7,zmm1
   7d506:	62 f2 cd 48 7e ea                               	vpermt2q zmm5,zmm6,zmm2
   7d50c:	62 f2 c5 48 7e c2                               	vpermt2q zmm0,zmm7,zmm2
   7d512:	62 f3 d5 48 71 d3 0c                            	vpshldq zmm2,zmm5,zmm3,0xc
   7d519:	62 d1 e5 48 db c8                               	vpandq zmm1,zmm3,zmm8
   7d51f:	62 f3 dd 48 71 dd 18                            	vpshldq zmm3,zmm4,zmm5,0x18
   7d526:	62 f3 fd 48 71 e4 24                            	vpshldq zmm4,zmm0,zmm4,0x24
   7d52d:	62 f1 fd 48 73 d0 10                            	vpsrlq zmm0,zmm0,0x10
   7d534:	62 d1 fd 48 7f 4d 05                            	vmovdqa64 ZMMWORD PTR [r13+0x140],zmm1
   7d53b:	62 d1 ed 48 db d0                               	vpandq zmm2,zmm2,zmm8
   7d541:	62 d1 e5 48 db d8                               	vpandq zmm3,zmm3,zmm8
   7d547:	62 d1 dd 48 db e0                               	vpandq zmm4,zmm4,zmm8
   7d54d:	62 d1 fd 48 7f 55 06                            	vmovdqa64 ZMMWORD PTR [r13+0x180],zmm2
   7d554:	62 d1 fd 48 7f 5d 07                            	vmovdqa64 ZMMWORD PTR [r13+0x1c0],zmm3
   7d55b:	62 d1 fd 48 7f 65 08                            	vmovdqa64 ZMMWORD PTR [r13+0x200],zmm4
   7d562:	62 d1 fd 48 7f 45 09                            	vmovdqa64 ZMMWORD PTR [r13+0x240],zmm0
   7d569:	62 f1 7c 48 28 54 24 38                         	vmovaps zmm2,ZMMWORD PTR [rsp+0xe00]
   7d571:	62 f1 7c 48 28 4c 24 37                         	vmovaps zmm1,ZMMWORD PTR [rsp+0xdc0]
   7d579:	62 f1 fd 48 6f 44 24 39                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0xe40]
   7d581:	48 8b 84 24 c0 06 00 00                         	mov    rax,QWORD PTR [rsp+0x6c0]
   7d589:	48 8b 5c 24 60                                  	mov    rbx,QWORD PTR [rsp+0x60]
   7d58e:	4c 8b 74 24 50                                  	mov    r14,QWORD PTR [rsp+0x50]
   7d593:	49 bf 63 c2 e5 9c c8 60 00 00                   	movabs r15,0x60c89ce5c263
   7d59d:	48 ff c0                                        	inc    rax
   7d5a0:	48 89 84 24 c0 06 00 00                         	mov    QWORD PTR [rsp+0x6c0],rax
   7d5a8:	62 f1 7c 48 29 54 24 20                         	vmovaps ZMMWORD PTR [rsp+0x800],zmm2
   7d5b0:	62 f1 7c 48 29 4c 24 21                         	vmovaps ZMMWORD PTR [rsp+0x840],zmm1
   7d5b8:	62 f1 fd 48 6f 54 24 36                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0xd80]
   7d5c0:	62 f1 fd 48 6f 4c 24 3a                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0xe80]
   7d5c8:	62 f1 fd 48 7f 44 24 1f                         	vmovdqa64 ZMMWORD PTR [rsp+0x7c0],zmm0
   7d5d0:	62 f1 fd 48 7f 54 24 22                         	vmovdqa64 ZMMWORD PTR [rsp+0x880],zmm2
   7d5d8:	62 f1 fd 48 7f 4c 24 1c                         	vmovdqa64 ZMMWORD PTR [rsp+0x700],zmm1
   7d5e0:	48 3b 84 24 30 06 00 00                         	cmp    rax,QWORD PTR [rsp+0x630]
   7d5e8:	0f 84 52 1b 00 00                               	je     7f140 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x38f0>
   7d5ee:	48 8b b4 24 90 00 00 00                         	mov    rsi,QWORD PTR [rsp+0x90]
   7d5f6:	48 8b bc 24 c0 06 00 00                         	mov    rdi,QWORD PTR [rsp+0x6c0]
   7d5fe:	48 39 f7                                        	cmp    rdi,rsi
   7d601:	0f 83 2f 3f 00 00                               	jae    81536 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ce6>
   7d607:	4c 8b ac 24 88 00 00 00                         	mov    r13,QWORD PTR [rsp+0x88]
   7d60f:	48 69 c7 c0 02 00 00                            	imul   rax,rdi,0x2c0
   7d616:	48 8b b4 24 b8 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xb8]
   7d61e:	41 8b bc 05 80 02 00 00                         	mov    edi,DWORD PTR [r13+rax*1+0x280]
   7d626:	48 39 fe                                        	cmp    rsi,rdi
   7d629:	0f 86 15 3f 00 00                               	jbe    81544 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5cf4>
   7d62f:	49 01 c5                                        	add    r13,rax
   7d632:	48 8b 8c 24 b0 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xb0]
   7d63a:	41 0f b6 85 a0 02 00 00                         	movzx  eax,BYTE PTR [r13+0x2a0]
   7d642:	3a 04 39                                        	cmp    al,BYTE PTR [rcx+rdi*1]
   7d645:	0f 83 f5 1a 00 00                               	jae    7f140 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x38f0>
   7d64b:	48 8b 94 24 d8 00 00 00                         	mov    rdx,QWORD PTR [rsp+0xd8]
   7d653:	4c 8b bc 24 e0 00 00 00                         	mov    r15,QWORD PTR [rsp+0xe0]
   7d65b:	83 ff ff                                        	cmp    edi,0xffffffff
   7d65e:	74 60                                           	je     7d6c0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1e70>
   7d660:	49 39 ff                                        	cmp    r15,rdi
   7d663:	0f 86 39 3e 00 00                               	jbe    814a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c52>
   7d669:	48 8b 3c fa                                     	mov    rdi,QWORD PTR [rdx+rdi*8]
   7d66d:	48 01 c7                                        	add    rdi,rax
   7d670:	4c 39 f7                                        	cmp    rdi,r14
   7d673:	0f 83 37 3e 00 00                               	jae    814b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c60>
   7d679:	45 8b 04 bc                                     	mov    r8d,DWORD PTR [r12+rdi*4]
   7d67d:	44 89 c7                                        	mov    edi,r8d
   7d680:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7d686:	48 39 fb                                        	cmp    rbx,rdi
   7d689:	0f 86 57 3e 00 00                               	jbe    814e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c96>
   7d68f:	4c 8b 54 24 40                                  	mov    r10,QWORD PTR [rsp+0x40]
   7d694:	48 c1 e7 06                                     	shl    rdi,0x6
   7d698:	41 c1 e8 1f                                     	shr    r8d,0x1f
   7d69c:	4d 89 c1                                        	mov    r9,r8
   7d69f:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   7d6a6:	40 b7 01                                        	mov    dil,0x1
   7d6a9:	89 bc 24 00 01 00 00                            	mov    DWORD PTR [rsp+0x100],edi
   7d6b0:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7d6b8:	eb 20                                           	jmp    7d6da <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1e8a>
   7d6ba:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   7d6c0:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7d6c4:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7d6cc:	45 31 c9                                        	xor    r9d,r9d
   7d6cf:	c7 84 24 00 01 00 00 00 00 00 00                	mov    DWORD PTR [rsp+0x100],0x0
   7d6da:	62 f1 fd 48 6f 44 24 10                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x400]
   7d6e2:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7d6e8:	62 f1 fd 48 7f 44 24 06                         	vmovdqa64 ZMMWORD PTR [rsp+0x180],zmm0
   7d6f0:	41 8b bd 84 02 00 00                            	mov    edi,DWORD PTR [r13+0x284]
   7d6f7:	4c 39 c7                                        	cmp    rdi,r8
   7d6fa:	74 74                                           	je     7d770 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f20>
   7d6fc:	48 39 fe                                        	cmp    rsi,rdi
   7d6ff:	0f 86 09 3d 00 00                               	jbe    8140e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5bbe>
   7d705:	3a 04 39                                        	cmp    al,BYTE PTR [rcx+rdi*1]
   7d708:	73 66                                           	jae    7d770 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f20>
   7d70a:	49 39 ff                                        	cmp    r15,rdi
   7d70d:	0f 86 8f 3d 00 00                               	jbe    814a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c52>
   7d713:	48 8b 3c fa                                     	mov    rdi,QWORD PTR [rdx+rdi*8]
   7d717:	48 01 c7                                        	add    rdi,rax
   7d71a:	4c 39 f7                                        	cmp    rdi,r14
   7d71d:	0f 83 8d 3d 00 00                               	jae    814b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c60>
   7d723:	45 8b 04 bc                                     	mov    r8d,DWORD PTR [r12+rdi*4]
   7d727:	44 89 c7                                        	mov    edi,r8d
   7d72a:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7d730:	48 39 fb                                        	cmp    rbx,rdi
   7d733:	0f 86 ad 3d 00 00                               	jbe    814e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c96>
   7d739:	44 8b 94 24 00 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x100]
   7d741:	48 c1 e7 06                                     	shl    rdi,0x6
   7d745:	41 c1 e8 1e                                     	shr    r8d,0x1e
   7d749:	41 80 e0 02                                     	and    r8b,0x2
   7d74d:	45 08 c8                                        	or     r8b,r9b
   7d750:	45 89 c1                                        	mov    r9d,r8d
   7d753:	41 80 ca 02                                     	or     r10b,0x2
   7d757:	44 89 94 24 00 01 00 00                         	mov    DWORD PTR [rsp+0x100],r10d
   7d75f:	4c 8b 54 24 40                                  	mov    r10,QWORD PTR [rsp+0x40]
   7d764:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   7d76b:	eb 07                                           	jmp    7d774 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1f24>
   7d76d:	0f 1f 00                                        	nop    DWORD PTR [rax]
   7d770:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7d774:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7d77c:	62 f1 fd 48 6f 44 24 10                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x400]
   7d784:	48 8d bc 24 c0 01 00 00                         	lea    rdi,[rsp+0x1c0]
   7d78c:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7d792:	62 f1 fd 48 7f 44 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm0
   7d79a:	62 f1 fe 48 7f 07                               	vmovdqu64 ZMMWORD PTR [rdi],zmm0
   7d7a0:	41 8b bd 88 02 00 00                            	mov    edi,DWORD PTR [r13+0x288]
   7d7a7:	4c 39 c7                                        	cmp    rdi,r8
   7d7aa:	74 74                                           	je     7d820 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1fd0>
   7d7ac:	48 39 fe                                        	cmp    rsi,rdi
   7d7af:	0f 86 59 3c 00 00                               	jbe    8140e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5bbe>
   7d7b5:	3a 04 39                                        	cmp    al,BYTE PTR [rcx+rdi*1]
   7d7b8:	73 66                                           	jae    7d820 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1fd0>
   7d7ba:	49 39 ff                                        	cmp    r15,rdi
   7d7bd:	0f 86 df 3c 00 00                               	jbe    814a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c52>
   7d7c3:	48 8b 3c fa                                     	mov    rdi,QWORD PTR [rdx+rdi*8]
   7d7c7:	48 01 c7                                        	add    rdi,rax
   7d7ca:	4c 39 f7                                        	cmp    rdi,r14
   7d7cd:	0f 83 dd 3c 00 00                               	jae    814b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c60>
   7d7d3:	45 8b 04 bc                                     	mov    r8d,DWORD PTR [r12+rdi*4]
   7d7d7:	44 89 c7                                        	mov    edi,r8d
   7d7da:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7d7e0:	48 39 fb                                        	cmp    rbx,rdi
   7d7e3:	0f 86 fd 3c 00 00                               	jbe    814e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c96>
   7d7e9:	44 8b 94 24 00 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x100]
   7d7f1:	48 c1 e7 06                                     	shl    rdi,0x6
   7d7f5:	41 c1 e8 1d                                     	shr    r8d,0x1d
   7d7f9:	41 80 e0 04                                     	and    r8b,0x4
   7d7fd:	45 08 c8                                        	or     r8b,r9b
   7d800:	45 89 c1                                        	mov    r9d,r8d
   7d803:	41 80 ca 04                                     	or     r10b,0x4
   7d807:	44 89 94 24 00 01 00 00                         	mov    DWORD PTR [rsp+0x100],r10d
   7d80f:	4c 8b 54 24 40                                  	mov    r10,QWORD PTR [rsp+0x40]
   7d814:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   7d81b:	eb 07                                           	jmp    7d824 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1fd4>
   7d81d:	0f 1f 00                                        	nop    DWORD PTR [rax]
   7d820:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7d824:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7d82c:	62 f1 fd 48 6f 44 24 10                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x400]
   7d834:	48 8d bc 24 c0 01 00 00                         	lea    rdi,[rsp+0x1c0]
   7d83c:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7d842:	62 f1 fd 48 7f 44 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm0
   7d84a:	62 f1 fe 48 7f 47 01                            	vmovdqu64 ZMMWORD PTR [rdi+0x40],zmm0
   7d851:	41 8b bd 8c 02 00 00                            	mov    edi,DWORD PTR [r13+0x28c]
   7d858:	4c 39 c7                                        	cmp    rdi,r8
   7d85b:	74 73                                           	je     7d8d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2080>
   7d85d:	48 39 fe                                        	cmp    rsi,rdi
   7d860:	0f 86 a8 3b 00 00                               	jbe    8140e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5bbe>
   7d866:	3a 04 39                                        	cmp    al,BYTE PTR [rcx+rdi*1]
   7d869:	73 65                                           	jae    7d8d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2080>
   7d86b:	49 39 ff                                        	cmp    r15,rdi
   7d86e:	0f 86 2e 3c 00 00                               	jbe    814a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c52>
   7d874:	48 8b 3c fa                                     	mov    rdi,QWORD PTR [rdx+rdi*8]
   7d878:	48 01 c7                                        	add    rdi,rax
   7d87b:	4c 39 f7                                        	cmp    rdi,r14
   7d87e:	0f 83 2c 3c 00 00                               	jae    814b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c60>
   7d884:	45 8b 04 bc                                     	mov    r8d,DWORD PTR [r12+rdi*4]
   7d888:	44 89 c7                                        	mov    edi,r8d
   7d88b:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7d891:	48 39 fb                                        	cmp    rbx,rdi
   7d894:	0f 86 4c 3c 00 00                               	jbe    814e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c96>
   7d89a:	44 8b 94 24 00 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x100]
   7d8a2:	48 c1 e7 06                                     	shl    rdi,0x6
   7d8a6:	41 c1 e8 1c                                     	shr    r8d,0x1c
   7d8aa:	41 80 e0 08                                     	and    r8b,0x8
   7d8ae:	45 08 c8                                        	or     r8b,r9b
   7d8b1:	45 89 c1                                        	mov    r9d,r8d
   7d8b4:	41 80 ca 08                                     	or     r10b,0x8
   7d8b8:	44 89 94 24 00 01 00 00                         	mov    DWORD PTR [rsp+0x100],r10d
   7d8c0:	4c 8b 54 24 40                                  	mov    r10,QWORD PTR [rsp+0x40]
   7d8c5:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   7d8cc:	eb 06                                           	jmp    7d8d4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2084>
   7d8ce:	66 90                                           	xchg   ax,ax
   7d8d0:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7d8d4:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7d8dc:	62 f1 fd 48 6f 44 24 10                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x400]
   7d8e4:	48 8d bc 24 c0 01 00 00                         	lea    rdi,[rsp+0x1c0]
   7d8ec:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7d8f2:	62 f1 fd 48 7f 44 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm0
   7d8fa:	62 f1 fe 48 7f 47 02                            	vmovdqu64 ZMMWORD PTR [rdi+0x80],zmm0
   7d901:	41 8b bd 90 02 00 00                            	mov    edi,DWORD PTR [r13+0x290]
   7d908:	4c 39 c7                                        	cmp    rdi,r8
   7d90b:	74 73                                           	je     7d980 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2130>
   7d90d:	48 39 fe                                        	cmp    rsi,rdi
   7d910:	0f 86 f8 3a 00 00                               	jbe    8140e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5bbe>
   7d916:	3a 04 39                                        	cmp    al,BYTE PTR [rcx+rdi*1]
   7d919:	73 65                                           	jae    7d980 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2130>
   7d91b:	49 39 ff                                        	cmp    r15,rdi
   7d91e:	0f 86 7e 3b 00 00                               	jbe    814a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c52>
   7d924:	48 8b 3c fa                                     	mov    rdi,QWORD PTR [rdx+rdi*8]
   7d928:	48 01 c7                                        	add    rdi,rax
   7d92b:	4c 39 f7                                        	cmp    rdi,r14
   7d92e:	0f 83 7c 3b 00 00                               	jae    814b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c60>
   7d934:	45 8b 04 bc                                     	mov    r8d,DWORD PTR [r12+rdi*4]
   7d938:	44 89 c7                                        	mov    edi,r8d
   7d93b:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7d941:	48 39 fb                                        	cmp    rbx,rdi
   7d944:	0f 86 9c 3b 00 00                               	jbe    814e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c96>
   7d94a:	44 8b 94 24 00 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x100]
   7d952:	48 c1 e7 06                                     	shl    rdi,0x6
   7d956:	41 c1 e8 1b                                     	shr    r8d,0x1b
   7d95a:	41 80 e0 10                                     	and    r8b,0x10
   7d95e:	45 08 c8                                        	or     r8b,r9b
   7d961:	45 89 c1                                        	mov    r9d,r8d
   7d964:	41 80 ca 10                                     	or     r10b,0x10
   7d968:	44 89 94 24 00 01 00 00                         	mov    DWORD PTR [rsp+0x100],r10d
   7d970:	4c 8b 54 24 40                                  	mov    r10,QWORD PTR [rsp+0x40]
   7d975:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   7d97c:	eb 06                                           	jmp    7d984 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2134>
   7d97e:	66 90                                           	xchg   ax,ax
   7d980:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7d984:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7d98c:	62 f1 fd 48 6f 44 24 10                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x400]
   7d994:	48 8d bc 24 c0 01 00 00                         	lea    rdi,[rsp+0x1c0]
   7d99c:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7d9a2:	62 f1 fd 48 7f 44 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm0
   7d9aa:	62 f1 fe 48 7f 47 03                            	vmovdqu64 ZMMWORD PTR [rdi+0xc0],zmm0
   7d9b1:	41 8b bd 94 02 00 00                            	mov    edi,DWORD PTR [r13+0x294]
   7d9b8:	4c 39 c7                                        	cmp    rdi,r8
   7d9bb:	74 73                                           	je     7da30 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x21e0>
   7d9bd:	48 39 fe                                        	cmp    rsi,rdi
   7d9c0:	0f 86 48 3a 00 00                               	jbe    8140e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5bbe>
   7d9c6:	3a 04 39                                        	cmp    al,BYTE PTR [rcx+rdi*1]
   7d9c9:	73 65                                           	jae    7da30 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x21e0>
   7d9cb:	49 39 ff                                        	cmp    r15,rdi
   7d9ce:	0f 86 ce 3a 00 00                               	jbe    814a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c52>
   7d9d4:	48 8b 3c fa                                     	mov    rdi,QWORD PTR [rdx+rdi*8]
   7d9d8:	48 01 c7                                        	add    rdi,rax
   7d9db:	4c 39 f7                                        	cmp    rdi,r14
   7d9de:	0f 83 cc 3a 00 00                               	jae    814b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c60>
   7d9e4:	45 8b 04 bc                                     	mov    r8d,DWORD PTR [r12+rdi*4]
   7d9e8:	44 89 c7                                        	mov    edi,r8d
   7d9eb:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7d9f1:	48 39 fb                                        	cmp    rbx,rdi
   7d9f4:	0f 86 ec 3a 00 00                               	jbe    814e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c96>
   7d9fa:	44 8b 94 24 00 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x100]
   7da02:	48 c1 e7 06                                     	shl    rdi,0x6
   7da06:	41 c1 e8 1a                                     	shr    r8d,0x1a
   7da0a:	41 80 e0 20                                     	and    r8b,0x20
   7da0e:	45 08 c8                                        	or     r8b,r9b
   7da11:	45 89 c1                                        	mov    r9d,r8d
   7da14:	41 80 ca 20                                     	or     r10b,0x20
   7da18:	44 89 94 24 00 01 00 00                         	mov    DWORD PTR [rsp+0x100],r10d
   7da20:	4c 8b 54 24 40                                  	mov    r10,QWORD PTR [rsp+0x40]
   7da25:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   7da2c:	eb 06                                           	jmp    7da34 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x21e4>
   7da2e:	66 90                                           	xchg   ax,ax
   7da30:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7da34:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7da3c:	62 f1 fd 48 6f 44 24 10                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x400]
   7da44:	48 8d bc 24 c0 01 00 00                         	lea    rdi,[rsp+0x1c0]
   7da4c:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7da52:	62 f1 fd 48 7f 44 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm0
   7da5a:	62 f1 fe 48 7f 47 04                            	vmovdqu64 ZMMWORD PTR [rdi+0x100],zmm0
   7da61:	41 8b bd 98 02 00 00                            	mov    edi,DWORD PTR [r13+0x298]
   7da68:	4c 39 c7                                        	cmp    rdi,r8
   7da6b:	74 73                                           	je     7dae0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2290>
   7da6d:	48 39 fe                                        	cmp    rsi,rdi
   7da70:	0f 86 98 39 00 00                               	jbe    8140e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5bbe>
   7da76:	3a 04 39                                        	cmp    al,BYTE PTR [rcx+rdi*1]
   7da79:	73 65                                           	jae    7dae0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2290>
   7da7b:	49 39 ff                                        	cmp    r15,rdi
   7da7e:	0f 86 1e 3a 00 00                               	jbe    814a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c52>
   7da84:	48 8b 3c fa                                     	mov    rdi,QWORD PTR [rdx+rdi*8]
   7da88:	48 01 c7                                        	add    rdi,rax
   7da8b:	4c 39 f7                                        	cmp    rdi,r14
   7da8e:	0f 83 1c 3a 00 00                               	jae    814b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c60>
   7da94:	45 8b 04 bc                                     	mov    r8d,DWORD PTR [r12+rdi*4]
   7da98:	44 89 c7                                        	mov    edi,r8d
   7da9b:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7daa1:	48 39 fb                                        	cmp    rbx,rdi
   7daa4:	0f 86 3c 3a 00 00                               	jbe    814e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c96>
   7daaa:	44 8b 94 24 00 01 00 00                         	mov    r10d,DWORD PTR [rsp+0x100]
   7dab2:	48 c1 e7 06                                     	shl    rdi,0x6
   7dab6:	41 c1 e8 19                                     	shr    r8d,0x19
   7daba:	41 80 e0 40                                     	and    r8b,0x40
   7dabe:	45 08 c8                                        	or     r8b,r9b
   7dac1:	45 89 c1                                        	mov    r9d,r8d
   7dac4:	41 80 ca 40                                     	or     r10b,0x40
   7dac8:	44 89 94 24 00 01 00 00                         	mov    DWORD PTR [rsp+0x100],r10d
   7dad0:	4c 8b 54 24 40                                  	mov    r10,QWORD PTR [rsp+0x40]
   7dad5:	62 d1 fe 48 6f 04 3a                            	vmovdqu64 zmm0,ZMMWORD PTR [r10+rdi*1]
   7dadc:	eb 06                                           	jmp    7dae4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2294>
   7dade:	66 90                                           	xchg   ax,ax
   7dae0:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7dae4:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7daec:	62 f1 fd 48 6f 44 24 10                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x400]
   7daf4:	48 8d bc 24 c0 01 00 00                         	lea    rdi,[rsp+0x1c0]
   7dafc:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   7db02:	62 f1 fd 48 7f 44 24 23                         	vmovdqa64 ZMMWORD PTR [rsp+0x8c0],zmm0
   7db0a:	62 f1 fe 48 7f 47 05                            	vmovdqu64 ZMMWORD PTR [rdi+0x140],zmm0
   7db11:	41 8b bd 9c 02 00 00                            	mov    edi,DWORD PTR [r13+0x29c]
   7db18:	4c 39 c7                                        	cmp    rdi,r8
   7db1b:	74 73                                           	je     7db90 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2340>
   7db1d:	48 39 fe                                        	cmp    rsi,rdi
   7db20:	0f 86 e8 38 00 00                               	jbe    8140e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5bbe>
   7db26:	3a 04 39                                        	cmp    al,BYTE PTR [rcx+rdi*1]
   7db29:	73 65                                           	jae    7db90 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2340>
   7db2b:	49 39 ff                                        	cmp    r15,rdi
   7db2e:	0f 86 6e 39 00 00                               	jbe    814a2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c52>
   7db34:	48 8b 3c fa                                     	mov    rdi,QWORD PTR [rdx+rdi*8]
   7db38:	48 01 c7                                        	add    rdi,rax
   7db3b:	4c 39 f7                                        	cmp    rdi,r14
   7db3e:	0f 83 6c 39 00 00                               	jae    814b0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c60>
   7db44:	41 8b 0c bc                                     	mov    ecx,DWORD PTR [r12+rdi*4]
   7db48:	89 cf                                           	mov    edi,ecx
   7db4a:	81 e7 ff ff ff 7f                               	and    edi,0x7fffffff
   7db50:	48 39 fb                                        	cmp    rbx,rdi
   7db53:	0f 86 0d 3a 00 00                               	jbe    81566 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d16>
   7db59:	48 8b 74 24 40                                  	mov    rsi,QWORD PTR [rsp+0x40]
   7db5e:	48 c1 e7 06                                     	shl    rdi,0x6
   7db62:	8b 94 24 00 01 00 00                            	mov    edx,DWORD PTR [rsp+0x100]
   7db69:	c1 e9 18                                        	shr    ecx,0x18
   7db6c:	80 e1 80                                        	and    cl,0x80
   7db6f:	44 08 c9                                        	or     cl,r9b
   7db72:	41 89 ce                                        	mov    r14d,ecx
   7db75:	62 f1 fe 48 6f 04 3e                            	vmovdqu64 zmm0,ZMMWORD PTR [rsi+rdi*1]
   7db7c:	80 ca 80                                        	or     dl,0x80
   7db7f:	89 94 24 00 01 00 00                            	mov    DWORD PTR [rsp+0x100],edx
   7db86:	eb 0f                                           	jmp    7db97 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2347>
   7db88:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   7db90:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7db94:	4d 89 ce                                        	mov    r14,r9
   7db97:	62 f1 fd 48 7f 44 24 10                         	vmovdqa64 ZMMWORD PTR [rsp+0x400],zmm0
   7db9f:	62 f1 7c 48 28 44 24 10                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x400]
   7dba7:	48 8d 8c 24 c0 01 00 00                         	lea    rcx,[rsp+0x1c0]
   7dbaf:	fe c0                                           	inc    al
   7dbb1:	62 71 fd 48 6f 1d 05 9f f8 ff                   	vmovdqa64 zmm11,ZMMWORD PTR [rip+0xfffffffffff89f05]        # 7ac0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x480>
   7dbbb:	62 71 fd 48 6f 25 3b 9f f8 ff                   	vmovdqa64 zmm12,ZMMWORD PTR [rip+0xfffffffffff89f3b]        # 7b00 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x4c0>
   7dbc5:	62 e2 fd 48 59 05 f1 96 f8 ff                   	vpbroadcastq zmm16,QWORD PTR [rip+0xfffffffffff896f1]        # 72c0 <GCC_except_table740+0x78>
   7dbcf:	62 e1 7c 28 28 0d c7 a2 f8 ff                   	vmovaps ymm17,YMMWORD PTR [rip+0xfffffffffff8a2c7]        # 7ea0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x860>
   7dbd9:	62 e2 fd 48 59 15 15 97 f8 ff                   	vpbroadcastq zmm18,QWORD PTR [rip+0xfffffffffff89715]        # 72f8 <GCC_except_table740+0xb0>
   7dbe3:	62 f1 7c 48 11 41 06                            	vmovups ZMMWORD PTR [rcx+0x180],zmm0
   7dbea:	62 f1 7c 48 29 44 24 23                         	vmovaps ZMMWORD PTR [rsp+0x8c0],zmm0
   7dbf2:	62 f1 7c 48 28 4c 24 07                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x1c0]
   7dbfa:	62 f1 7c 48 28 54 24 08                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x200]
   7dc02:	62 f1 7c 48 28 44 24 06                         	vmovaps zmm0,ZMMWORD PTR [rsp+0x180]
   7dc0a:	62 f1 7c 48 28 5c 24 09                         	vmovaps zmm3,ZMMWORD PTR [rsp+0x240]
   7dc12:	62 f1 7c 48 29 4c 24 11                         	vmovaps ZMMWORD PTR [rsp+0x440],zmm1
   7dc1a:	62 f1 7c 48 29 54 24 12                         	vmovaps ZMMWORD PTR [rsp+0x480],zmm2
   7dc22:	62 f1 7c 48 28 54 24 0a                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x280]
   7dc2a:	62 f1 7c 48 28 4c 24 0b                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x2c0]
   7dc32:	62 f1 7c 48 29 44 24 10                         	vmovaps ZMMWORD PTR [rsp+0x400],zmm0
   7dc3a:	62 f1 7c 48 29 5c 24 13                         	vmovaps ZMMWORD PTR [rsp+0x4c0],zmm3
   7dc42:	62 f1 7c 48 29 54 24 14                         	vmovaps ZMMWORD PTR [rsp+0x500],zmm2
   7dc4a:	62 f1 7c 48 29 4c 24 15                         	vmovaps ZMMWORD PTR [rsp+0x540],zmm1
   7dc52:	62 f1 7c 48 28 54 24 0c                         	vmovaps zmm2,ZMMWORD PTR [rsp+0x300]
   7dc5a:	62 f1 7c 48 28 4c 24 0d                         	vmovaps zmm1,ZMMWORD PTR [rsp+0x340]
   7dc62:	62 f1 7c 48 29 54 24 16                         	vmovaps ZMMWORD PTR [rsp+0x580],zmm2
   7dc6a:	62 f1 7c 48 29 4c 24 17                         	vmovaps ZMMWORD PTR [rsp+0x5c0],zmm1
   7dc72:	41 88 85 a0 02 00 00                            	mov    BYTE PTR [r13+0x2a0],al
   7dc79:	48 b8 31 e1 72 4e 64 30 00 00                   	movabs rax,0x30644e72e131
   7dc83:	62 f1 fd 48 6f 44 24 10                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x400]
   7dc8b:	62 f1 fd 48 6f 4c 24 12                         	vmovdqa64 zmm1,ZMMWORD PTR [rsp+0x480]
   7dc93:	62 f1 fd 48 6f 54 24 14                         	vmovdqa64 zmm2,ZMMWORD PTR [rsp+0x500]
   7dc9b:	62 f1 fd 48 6f 5c 24 16                         	vmovdqa64 zmm3,ZMMWORD PTR [rsp+0x580]
   7dca3:	62 f1 fe 48 6f b4 24 a0 04 00 00                	vmovdqu64 zmm6,ZMMWORD PTR [rsp+0x4a0]
   7dcae:	62 f1 fe 48 6f bc 24 20 05 00 00                	vmovdqu64 zmm7,ZMMWORD PTR [rsp+0x520]
   7dcb9:	62 71 fe 48 6f 84 24 a0 05 00 00                	vmovdqu64 zmm8,ZMMWORD PTR [rsp+0x5a0]
   7dcc4:	62 51 fd 48 6f 6d 03                            	vmovdqa64 zmm13,ZMMWORD PTR [r13+0xc0]
   7dccb:	62 51 fd 48 6f 75 04                            	vmovdqa64 zmm14,ZMMWORD PTR [r13+0x100]
   7dcd2:	62 f3 fd 48 3a 44 24 22 01                      	vinserti64x4 zmm0,zmm0,YMMWORD PTR [rsp+0x440],0x1
   7dcdb:	62 f3 f5 48 3a 4c 24 26 01                      	vinserti64x4 zmm1,zmm1,YMMWORD PTR [rsp+0x4c0],0x1
   7dce4:	62 f3 ed 48 3a 54 24 2a 01                      	vinserti64x4 zmm2,zmm2,YMMWORD PTR [rsp+0x540],0x1
   7dced:	62 f3 e5 48 3a 5c 24 2e 01                      	vinserti64x4 zmm3,zmm3,YMMWORD PTR [rsp+0x5c0],0x1
   7dcf6:	62 f3 cd 48 3a 74 24 27 01                      	vinserti64x4 zmm6,zmm6,YMMWORD PTR [rsp+0x4e0],0x1
   7dcff:	62 f3 c5 48 3a 7c 24 2b 01                      	vinserti64x4 zmm7,zmm7,YMMWORD PTR [rsp+0x560],0x1
   7dd08:	62 73 bd 48 3a 44 24 2f 01                      	vinserti64x4 zmm8,zmm8,YMMWORD PTR [rsp+0x5e0],0x1
   7dd11:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   7dd17:	62 f1 fd 48 6d e9                               	vpunpckhqdq zmm5,zmm0,zmm1
   7dd1d:	62 f1 ed 48 6c c3                               	vpunpcklqdq zmm0,zmm2,zmm3
   7dd23:	62 f1 ed 48 6d cb                               	vpunpckhqdq zmm1,zmm2,zmm3
   7dd29:	62 f1 fd 48 6f d4                               	vmovdqa64 zmm2,zmm4
   7dd2f:	62 f1 fd 48 6f dd                               	vmovdqa64 zmm3,zmm5
   7dd35:	62 f2 a5 48 7e d0                               	vpermt2q zmm2,zmm11,zmm0
   7dd3b:	62 f2 9d 48 7e e0                               	vpermt2q zmm4,zmm12,zmm0
   7dd41:	62 f2 a5 48 7e d9                               	vpermt2q zmm3,zmm11,zmm1
   7dd47:	62 f2 9d 48 7e e9                               	vpermt2q zmm5,zmm12,zmm1
   7dd4d:	62 f3 e5 48 71 ca 0c                            	vpshldq zmm1,zmm3,zmm2,0xc
   7dd54:	62 b1 ed 48 db c0                               	vpandq zmm0,zmm2,zmm16
   7dd5a:	62 f3 dd 48 71 d3 18                            	vpshldq zmm2,zmm4,zmm3,0x18
   7dd61:	62 f3 d5 48 71 e4 24                            	vpshldq zmm4,zmm5,zmm4,0x24
   7dd68:	62 b1 dd 48 db d8                               	vpandq zmm3,zmm4,zmm16
   7dd6e:	62 f1 dd 48 73 d5 10                            	vpsrlq zmm4,zmm5,0x10
   7dd75:	62 f1 fe 48 6f ac 24 20 04 00 00                	vmovdqu64 zmm5,ZMMWORD PTR [rsp+0x420]
   7dd80:	62 b1 f5 48 db c8                               	vpandq zmm1,zmm1,zmm16
   7dd86:	62 b1 ed 48 db d0                               	vpandq zmm2,zmm2,zmm16
   7dd8c:	62 f3 d5 48 3a 6c 24 23 01                      	vinserti64x4 zmm5,zmm5,YMMWORD PTR [rsp+0x460],0x1
   7dd95:	62 71 d5 48 6c ce                               	vpunpcklqdq zmm9,zmm5,zmm6
   7dd9b:	62 f1 d5 48 6d ee                               	vpunpckhqdq zmm5,zmm5,zmm6
   7dda1:	62 d1 c5 48 6c f0                               	vpunpcklqdq zmm6,zmm7,zmm8
   7dda7:	62 d1 c5 48 6d f8                               	vpunpckhqdq zmm7,zmm7,zmm8
   7ddad:	62 51 fd 48 6f c1                               	vmovdqa64 zmm8,zmm9
   7ddb3:	62 71 fd 48 6f d5                               	vmovdqa64 zmm10,zmm5
   7ddb9:	62 72 a5 48 7e c6                               	vpermt2q zmm8,zmm11,zmm6
   7ddbf:	62 72 a5 48 7e d7                               	vpermt2q zmm10,zmm11,zmm7
   7ddc5:	62 f2 9d 48 7e ef                               	vpermt2q zmm5,zmm12,zmm7
   7ddcb:	62 72 9d 48 7e ce                               	vpermt2q zmm9,zmm12,zmm6
   7ddd1:	62 51 fd 48 6f 5d 01                            	vmovdqa64 zmm11,ZMMWORD PTR [r13+0x40]
   7ddd8:	62 51 fd 48 6f 65 02                            	vmovdqa64 zmm12,ZMMWORD PTR [r13+0x80]
   7dddf:	62 d3 ad 48 71 f8 0c                            	vpshldq zmm7,zmm10,zmm8,0xc
   7dde6:	62 d3 d5 48 71 f1 24                            	vpshldq zmm6,zmm5,zmm9,0x24
   7dded:	62 53 b5 48 71 d2 18                            	vpshldq zmm10,zmm9,zmm10,0x18
   7ddf4:	62 51 fd 48 6f 4d 00                            	vmovdqa64 zmm9,ZMMWORD PTR [r13+0x0]
   7ddfb:	62 f1 d5 48 73 d5 10                            	vpsrlq zmm5,zmm5,0x10
   7de02:	62 d2 fd 48 29 c9                               	vpcmpeqq k1,zmm0,zmm9
   7de08:	62 51 fd 48 fb c9                               	vpsubq zmm9,zmm0,zmm9
   7de0e:	62 f2 a5 49 29 c9                               	vpcmpeqq k1{k1},zmm11,zmm1
   7de14:	62 31 b5 48 d4 ca                               	vpaddq zmm9,zmm9,zmm18
   7de1a:	62 f2 9d 49 29 ca                               	vpcmpeqq k1{k1},zmm12,zmm2
   7de20:	62 d1 85 48 72 e1 34                            	vpsraq zmm15,zmm9,0x34
   7de27:	62 a1 b5 48 db d8                               	vpandq zmm19,zmm9,zmm16
   7de2d:	62 f2 95 49 29 cb                               	vpcmpeqq k1{k1},zmm13,zmm3
   7de33:	62 f2 8d 49 29 c4                               	vpcmpeqq k0{k1},zmm14,zmm4
   7de39:	c4 c1 7b 92 ce                                  	kmovd  k1,r14d
   7de3e:	c5 fb 93 c8                                     	kmovd  ecx,k0
   7de42:	41 0a 8d a1 02 00 00                            	or     cl,BYTE PTR [r13+0x2a1]
   7de49:	62 e1 7c 28 11 4c 24 0c                         	vmovups YMMWORD PTR [rsp+0x180],ymm17
   7de51:	48 89 84 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rax
   7de59:	62 71 85 58 d4 7c 24 31                         	vpaddq zmm15,zmm15,QWORD BCST [rsp+0x188]
   7de61:	41 89 cf                                        	mov    r15d,ecx
   7de64:	41 f6 d7                                        	not    r15b
   7de67:	62 71 85 48 d4 f9                               	vpaddq zmm15,zmm15,zmm1
   7de6d:	62 51 85 48 fb db                               	vpsubq zmm11,zmm15,zmm11
   7de73:	62 d1 85 48 72 e3 34                            	vpsraq zmm15,zmm11,0x34
   7de7a:	62 71 85 58 d4 7c 24 32                         	vpaddq zmm15,zmm15,QWORD BCST [rsp+0x190]
   7de82:	62 a1 a5 48 db e0                               	vpandq zmm20,zmm11,zmm16
   7de88:	62 71 85 48 d4 fa                               	vpaddq zmm15,zmm15,zmm2
   7de8e:	62 51 85 48 fb e4                               	vpsubq zmm12,zmm15,zmm12
   7de94:	62 d1 85 48 72 e4 34                            	vpsraq zmm15,zmm12,0x34
   7de9b:	62 71 85 58 d4 7c 24 33                         	vpaddq zmm15,zmm15,QWORD BCST [rsp+0x198]
   7dea3:	62 a1 9d 48 db e8                               	vpandq zmm21,zmm12,zmm16
   7dea9:	62 72 fe 48 38 e1                               	vpmovm2q zmm12,k1
   7deaf:	62 71 85 48 d4 fb                               	vpaddq zmm15,zmm15,zmm3
   7deb5:	62 51 85 48 fb ed                               	vpsubq zmm13,zmm15,zmm13
   7debb:	62 d1 85 48 72 e5 34                            	vpsraq zmm15,zmm13,0x34
   7dec2:	62 71 85 58 d4 7c 24 34                         	vpaddq zmm15,zmm15,QWORD BCST [rsp+0x1a0]
   7deca:	62 72 ed 51 64 1d f4 94 f8 ff                   	vpblendmq zmm11{k1},zmm18,QWORD BCST [rip+0xfffffffffff894f4]        # 73c8 <GCC_except_table740+0x180>
   7ded4:	62 a1 95 48 db f0                               	vpandq zmm22,zmm13,zmm16
   7deda:	62 71 85 48 d4 cc                               	vpaddq zmm9,zmm15,zmm4
   7dee0:	62 51 b5 48 fb ce                               	vpsubq zmm9,zmm9,zmm14
   7dee6:	62 a1 b5 48 db f8                               	vpandq zmm23,zmm9,zmm16
   7deec:	62 31 fd c9 6f c8                               	vmovdqa64 zmm9{k1}{z},zmm16
   7def2:	62 33 b5 48 25 c0 6c                            	vpternlogq zmm8,zmm9,zmm16,0x6c
   7def9:	62 b3 b5 48 25 f8 6c                            	vpternlogq zmm7,zmm9,zmm16,0x6c
   7df00:	62 33 b5 48 25 d0 6c                            	vpternlogq zmm10,zmm9,zmm16,0x6c
   7df07:	62 b3 b5 48 25 f0 6c                            	vpternlogq zmm6,zmm9,zmm16,0x6c
   7df0e:	62 d1 d5 48 ef e9                               	vpxorq zmm5,zmm5,zmm9
   7df14:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   7df19:	62 51 bd 48 fb c4                               	vpsubq zmm8,zmm8,zmm12
   7df1f:	62 51 bd 48 fb 45 05                            	vpsubq zmm8,zmm8,ZMMWORD PTR [r13+0x140]
   7df26:	62 72 fd 48 59 25 e8 94 f8 ff                   	vpbroadcastq zmm12,QWORD PTR [rip+0xfffffffffff894e8]        # 7418 <GCC_except_table740+0x1d0>
   7df30:	62 51 bd 48 d4 c3                               	vpaddq zmm8,zmm8,zmm11
   7df36:	62 71 fd 48 7f 44 24 3f                         	vmovdqa64 ZMMWORD PTR [rsp+0xfc0],zmm8
   7df3e:	62 d1 bd 48 72 e0 34                            	vpsraq zmm8,zmm8,0x34
   7df45:	62 d1 c5 48 d4 f8                               	vpaddq zmm7,zmm7,zmm8
   7df4b:	62 72 9d 59 64 1d bb 94 f8 ff                   	vpblendmq zmm11{k1},zmm12,QWORD BCST [rip+0xfffffffffff894bb]        # 7410 <GCC_except_table740+0x1c8>
   7df55:	62 d1 c5 48 fb 7d 06                            	vpsubq zmm7,zmm7,ZMMWORD PTR [r13+0x180]
   7df5c:	62 72 fd 48 59 05 9a 93 f8 ff                   	vpbroadcastq zmm8,QWORD PTR [rip+0xfffffffffff8939a]        # 7300 <GCC_except_table740+0xb8>
   7df66:	62 d1 c5 48 d4 fb                               	vpaddq zmm7,zmm7,zmm11
   7df6c:	62 f1 fd 48 7f 7c 24 3e                         	vmovdqa64 ZMMWORD PTR [rsp+0xf80],zmm7
   7df74:	62 f1 c5 48 72 e7 34                            	vpsraq zmm7,zmm7,0x34
   7df7b:	62 72 bd 59 64 05 6b 94 f8 ff                   	vpblendmq zmm8{k1},zmm8,QWORD BCST [rip+0xfffffffffff8946b]        # 73f0 <GCC_except_table740+0x1a8>
   7df85:	62 f1 ad 48 d4 ff                               	vpaddq zmm7,zmm10,zmm7
   7df8b:	62 d1 c5 48 fb 7d 07                            	vpsubq zmm7,zmm7,ZMMWORD PTR [r13+0x1c0]
   7df92:	c5 f8 91 4c 24 6e                               	kmovw  WORD PTR [rsp+0x6e],k1
   7df98:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   7df9d:	62 d1 c5 48 d4 f8                               	vpaddq zmm7,zmm7,zmm8
   7dfa3:	62 72 fd 48 59 05 a3 93 f8 ff                   	vpbroadcastq zmm8,QWORD PTR [rip+0xfffffffffff893a3]        # 7350 <GCC_except_table740+0x108>
   7dfad:	62 f1 fd 48 7f 7c 24 3d                         	vmovdqa64 ZMMWORD PTR [rsp+0xf40],zmm7
   7dfb5:	62 f1 c5 48 72 e7 34                            	vpsraq zmm7,zmm7,0x34
   7dfbc:	62 f1 cd 48 d4 f7                               	vpaddq zmm6,zmm6,zmm7
   7dfc2:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   7dfc6:	62 72 bd 59 64 05 b0 93 f8 ff                   	vpblendmq zmm8{k1},zmm8,QWORD BCST [rip+0xfffffffffff893b0]        # 7380 <GCC_except_table740+0x138>
   7dfd0:	62 d1 cd 48 fb 75 08                            	vpsubq zmm6,zmm6,ZMMWORD PTR [r13+0x200]
   7dfd7:	44 22 bc 24 00 01 00 00                         	and    r15b,BYTE PTR [rsp+0x100]
   7dfdf:	62 71 fd 48 6f 6c 24 22                         	vmovdqa64 zmm13,ZMMWORD PTR [rsp+0x880]
   7dfe7:	62 71 fd 48 6f 74 24 21                         	vmovdqa64 zmm14,ZMMWORD PTR [rsp+0x840]
   7dfef:	62 71 fd 48 6f 7c 24 20                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x800]
   7dff7:	62 71 fd 48 6f 64 24 1c                         	vmovdqa64 zmm12,ZMMWORD PTR [rsp+0x700]
   7dfff:	48 8b 9c 24 f8 00 00 00                         	mov    rbx,QWORD PTR [rsp+0xf8]
   7e007:	89 8c 24 c0 03 00 00                            	mov    DWORD PTR [rsp+0x3c0],ecx
   7e00e:	62 d1 cd 48 d4 f0                               	vpaddq zmm6,zmm6,zmm8
   7e014:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   7e019:	62 f1 fd 48 7f 74 24 3c                         	vmovdqa64 ZMMWORD PTR [rsp+0xf00],zmm6
   7e021:	62 f1 cd 48 72 e6 34                            	vpsraq zmm6,zmm6,0x34
   7e028:	62 f1 d5 48 d4 ee                               	vpaddq zmm5,zmm5,zmm6
   7e02e:	62 d1 d5 48 fb 6d 09                            	vpsubq zmm5,zmm5,ZMMWORD PTR [r13+0x240]
   7e035:	62 e1 7c 28 11 4c 24 0c                         	vmovups YMMWORD PTR [rsp+0x180],ymm17
   7e03d:	48 89 84 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rax
   7e045:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   7e049:	62 51 f5 48 d4 5d 01                            	vpaddq zmm11,zmm1,ZMMWORD PTR [r13+0x40]
   7e050:	62 d1 ed 48 d4 4d 02                            	vpaddq zmm1,zmm2,ZMMWORD PTR [r13+0x80]
   7e057:	62 d1 fd 48 d4 45 00                            	vpaddq zmm0,zmm0,ZMMWORD PTR [r13+0x0]
   7e05e:	62 d1 e5 48 d4 55 03                            	vpaddq zmm2,zmm3,ZMMWORD PTR [r13+0xc0]
   7e065:	62 f1 fd 48 7f 6c 24 3b                         	vmovdqa64 ZMMWORD PTR [rsp+0xec0],zmm5
   7e06d:	62 f2 fd 48 19 6c 24 31                         	vbroadcastsd zmm5,QWORD PTR [rsp+0x188]
   7e075:	62 f1 fd 48 7f 4c 24 45                         	vmovdqa64 ZMMWORD PTR [rsp+0x1140],zmm1
   7e07d:	62 d1 dd 48 d4 4d 04                            	vpaddq zmm1,zmm4,ZMMWORD PTR [r13+0x100]
   7e084:	62 71 fd 48 7f 5c 24 44                         	vmovdqa64 ZMMWORD PTR [rsp+0x1100],zmm11
   7e08c:	62 72 fd 48 59 1d 62 93 f8 ff                   	vpbroadcastq zmm11,QWORD PTR [rip+0xfffffffffff89362]        # 73f8 <GCC_except_table740+0x1b0>
   7e096:	62 f1 fd 48 7f 54 24 46                         	vmovdqa64 ZMMWORD PTR [rsp+0x1180],zmm2
   7e09e:	62 f1 fd 48 7f 44 24 48                         	vmovdqa64 ZMMWORD PTR [rsp+0x1200],zmm0
   7e0a6:	c5 d9 ef e4                                     	vpxor  xmm4,xmm4,xmm4
   7e0aa:	62 f1 7c 48 29 6c 24 40                         	vmovaps ZMMWORD PTR [rsp+0x1000],zmm5
   7e0b2:	62 f2 fd 48 19 6c 24 32                         	vbroadcastsd zmm5,QWORD PTR [rsp+0x190]
   7e0ba:	62 f1 fd 48 7f 4c 24 47                         	vmovdqa64 ZMMWORD PTR [rsp+0x11c0],zmm1
   7e0c2:	62 f1 7c 48 29 6c 24 41                         	vmovaps ZMMWORD PTR [rsp+0x1040],zmm5
   7e0ca:	62 f2 fd 48 19 6c 24 33                         	vbroadcastsd zmm5,QWORD PTR [rsp+0x198]
   7e0d2:	62 f1 7c 48 29 6c 24 42                         	vmovaps ZMMWORD PTR [rsp+0x1080],zmm5
   7e0da:	62 f2 fd 48 59 6c 24 34                         	vpbroadcastq zmm5,QWORD PTR [rsp+0x1a0]
   7e0e2:	62 e1 7c 28 11 4c 24 0c                         	vmovups YMMWORD PTR [rsp+0x180],ymm17
   7e0ea:	48 89 84 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rax
   7e0f2:	44 89 f8                                        	mov    eax,r15d
   7e0f5:	62 e1 fd 48 6f 4c 24 1f                         	vmovdqa64 zmm17,ZMMWORD PTR [rsp+0x7c0]
   7e0fd:	f6 d0                                           	not    al
   7e0ff:	62 f2 fd 48 59 4c 24 33                         	vpbroadcastq zmm1,QWORD PTR [rsp+0x198]
   7e107:	62 f2 fd 48 59 54 24 32                         	vpbroadcastq zmm2,QWORD PTR [rsp+0x190]
   7e10f:	62 f2 fd 48 59 5c 24 31                         	vpbroadcastq zmm3,QWORD PTR [rsp+0x188]
   7e117:	62 f2 fd 48 59 44 24 34                         	vpbroadcastq zmm0,QWORD PTR [rsp+0x1a0]
   7e11f:	c5 fb 92 c8                                     	kmovd  k1,eax
   7e123:	62 e2 fd 49 59 1d 13 92 f8 ff                   	vpbroadcastq zmm19{k1},QWORD PTR [rip+0xfffffffffff89213]        # 7340 <GCC_except_table740+0xf8>
   7e12d:	62 e1 fd 49 6f 64 24 2d                         	vmovdqa64 zmm20{k1},ZMMWORD PTR [rsp+0xb40]
   7e135:	62 e1 fd 49 6f 6c 24 2c                         	vmovdqa64 zmm21{k1},ZMMWORD PTR [rsp+0xb00]
   7e13d:	62 e1 fd 49 6f 74 24 2b                         	vmovdqa64 zmm22{k1},ZMMWORD PTR [rsp+0xac0]
   7e145:	62 e1 fd 49 6f 7c 24 2a                         	vmovdqa64 zmm23{k1},ZMMWORD PTR [rsp+0xa80]
   7e14d:	62 f1 fd 48 7f 6c 24 43                         	vmovdqa64 ZMMWORD PTR [rsp+0x10c0],zmm5
   7e155:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   7e159:	62 b2 95 48 b5 f3                               	vpmadd52huq zmm6,zmm13,zmm19
   7e15f:	62 b2 f5 40 b4 eb                               	vpmadd52luq zmm5,zmm17,zmm19
   7e165:	62 32 8d 48 b5 c3                               	vpmadd52huq zmm8,zmm14,zmm19
   7e16b:	62 b2 85 48 b5 fb                               	vpmadd52huq zmm7,zmm15,zmm19
   7e171:	62 32 f5 40 b5 cb                               	vpmadd52huq zmm9,zmm17,zmm19
   7e177:	62 b2 9d 48 b5 e3                               	vpmadd52huq zmm4,zmm12,zmm19
   7e17d:	62 e1 fd 48 7f 5c 24 30                         	vmovdqa64 ZMMWORD PTR [rsp+0xc00],zmm19
   7e185:	62 e1 fd 48 7f 64 24 2f                         	vmovdqa64 ZMMWORD PTR [rsp+0xbc0],zmm20
   7e18d:	62 e1 fd 48 7f 6c 24 2e                         	vmovdqa64 ZMMWORD PTR [rsp+0xb80],zmm21
   7e195:	62 e1 fd 48 7f 74 24 4a                         	vmovdqa64 ZMMWORD PTR [rsp+0x1280],zmm22
   7e19d:	62 e1 fd 48 7f 7c 24 49                         	vmovdqa64 ZMMWORD PTR [rsp+0x1240],zmm23
   7e1a5:	62 52 d5 48 b4 d3                               	vpmadd52luq zmm10,zmm5,zmm11
   7e1ab:	62 b2 9d 48 b4 f3                               	vpmadd52luq zmm6,zmm12,zmm19
   7e1b1:	62 32 95 48 b4 c3                               	vpmadd52luq zmm8,zmm13,zmm19
   7e1b7:	62 b2 8d 48 b4 fb                               	vpmadd52luq zmm7,zmm14,zmm19
   7e1bd:	62 32 85 48 b4 cb                               	vpmadd52luq zmm9,zmm15,zmm19
   7e1c3:	62 b1 d5 48 d4 e8                               	vpaddq zmm5,zmm5,zmm16
   7e1c9:	62 e2 fd 48 59 1d f5 90 f8 ff                   	vpbroadcastq zmm19,QWORD PTR [rip+0xfffffffffff890f5]        # 72c8 <GCC_except_table740+0x80>
   7e1d3:	62 f1 d5 48 73 d5 34                            	vpsrlq zmm5,zmm5,0x34
   7e1da:	62 f2 ad 48 b5 f1                               	vpmadd52huq zmm6,zmm10,zmm1
   7e1e0:	62 72 ad 48 b5 c2                               	vpmadd52huq zmm8,zmm10,zmm2
   7e1e6:	62 f2 ad 48 b5 fb                               	vpmadd52huq zmm7,zmm10,zmm3
   7e1ec:	62 b2 ad 48 b5 ea                               	vpmadd52huq zmm5,zmm10,zmm18
   7e1f2:	62 72 ad 48 b4 cb                               	vpmadd52luq zmm9,zmm10,zmm3
   7e1f8:	62 f2 ad 48 b5 e0                               	vpmadd52huq zmm4,zmm10,zmm0
   7e1fe:	62 f2 ad 48 b4 f0                               	vpmadd52luq zmm6,zmm10,zmm0
   7e204:	62 72 ad 48 b4 c1                               	vpmadd52luq zmm8,zmm10,zmm1
   7e20a:	62 f2 ad 48 b4 fa                               	vpmadd52luq zmm7,zmm10,zmm2
   7e210:	62 71 b5 48 d4 cd                               	vpaddq zmm9,zmm9,zmm5
   7e216:	62 b2 95 48 b5 e4                               	vpmadd52huq zmm4,zmm13,zmm20
   7e21c:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   7e221:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   7e225:	62 b2 9d 48 b5 ec                               	vpmadd52huq zmm5,zmm12,zmm20
   7e22b:	62 32 f5 40 b4 cc                               	vpmadd52luq zmm9,zmm17,zmm20
   7e231:	62 b2 8d 48 b5 f4                               	vpmadd52huq zmm6,zmm14,zmm20
   7e237:	62 32 85 48 b5 c4                               	vpmadd52huq zmm8,zmm15,zmm20
   7e23d:	62 b2 f5 40 b5 fc                               	vpmadd52huq zmm7,zmm17,zmm20
   7e243:	62 b2 9d 48 b4 e4                               	vpmadd52luq zmm4,zmm12,zmm20
   7e249:	62 52 b5 48 b4 d3                               	vpmadd52luq zmm10,zmm9,zmm11
   7e24f:	62 31 b5 48 d4 c8                               	vpaddq zmm9,zmm9,zmm16
   7e255:	62 d1 b5 48 73 d1 34                            	vpsrlq zmm9,zmm9,0x34
   7e25c:	62 b2 95 48 b4 f4                               	vpmadd52luq zmm6,zmm13,zmm20
   7e262:	62 32 8d 48 b4 c4                               	vpmadd52luq zmm8,zmm14,zmm20
   7e268:	62 b2 85 48 b4 fc                               	vpmadd52luq zmm7,zmm15,zmm20
   7e26e:	62 f2 ad 48 b5 e1                               	vpmadd52huq zmm4,zmm10,zmm1
   7e274:	62 32 ad 48 b5 ca                               	vpmadd52huq zmm9,zmm10,zmm18
   7e27a:	62 f2 ad 48 b5 e8                               	vpmadd52huq zmm5,zmm10,zmm0
   7e280:	62 f2 ad 48 b5 f2                               	vpmadd52huq zmm6,zmm10,zmm2
   7e286:	62 72 ad 48 b5 c3                               	vpmadd52huq zmm8,zmm10,zmm3
   7e28c:	62 f2 ad 48 b4 fb                               	vpmadd52luq zmm7,zmm10,zmm3
   7e292:	62 f2 ad 48 b4 e0                               	vpmadd52luq zmm4,zmm10,zmm0
   7e298:	62 b2 95 48 b5 ed                               	vpmadd52huq zmm5,zmm13,zmm21
   7e29e:	62 f2 ad 48 b4 f1                               	vpmadd52luq zmm6,zmm10,zmm1
   7e2a4:	62 72 ad 48 b4 c2                               	vpmadd52luq zmm8,zmm10,zmm2
   7e2aa:	62 51 c5 48 d4 c9                               	vpaddq zmm9,zmm7,zmm9
   7e2b0:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   7e2b5:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   7e2b9:	62 b2 9d 48 b5 fd                               	vpmadd52huq zmm7,zmm12,zmm21
   7e2bf:	62 32 f5 40 b4 cd                               	vpmadd52luq zmm9,zmm17,zmm21
   7e2c5:	62 b2 8d 48 b5 e5                               	vpmadd52huq zmm4,zmm14,zmm21
   7e2cb:	62 b2 9d 48 b4 ed                               	vpmadd52luq zmm5,zmm12,zmm21
   7e2d1:	62 b2 85 48 b5 f5                               	vpmadd52huq zmm6,zmm15,zmm21
   7e2d7:	62 32 f5 40 b5 c5                               	vpmadd52huq zmm8,zmm17,zmm21
   7e2dd:	62 52 b5 48 b4 d3                               	vpmadd52luq zmm10,zmm9,zmm11
   7e2e3:	62 b2 95 48 b4 e5                               	vpmadd52luq zmm4,zmm13,zmm21
   7e2e9:	62 31 b5 48 d4 c8                               	vpaddq zmm9,zmm9,zmm16
   7e2ef:	62 d1 b5 48 73 d1 34                            	vpsrlq zmm9,zmm9,0x34
   7e2f6:	62 b2 8d 48 b4 f5                               	vpmadd52luq zmm6,zmm14,zmm21
   7e2fc:	62 32 85 48 b4 c5                               	vpmadd52luq zmm8,zmm15,zmm21
   7e302:	62 f2 ad 48 b5 e9                               	vpmadd52huq zmm5,zmm10,zmm1
   7e308:	62 32 ad 48 b5 ca                               	vpmadd52huq zmm9,zmm10,zmm18
   7e30e:	62 f2 ad 48 b5 e2                               	vpmadd52huq zmm4,zmm10,zmm2
   7e314:	62 f2 ad 48 b5 f8                               	vpmadd52huq zmm7,zmm10,zmm0
   7e31a:	62 f2 ad 48 b5 f3                               	vpmadd52huq zmm6,zmm10,zmm3
   7e320:	62 72 ad 48 b4 c3                               	vpmadd52luq zmm8,zmm10,zmm3
   7e326:	62 f2 ad 48 b4 e8                               	vpmadd52luq zmm5,zmm10,zmm0
   7e32c:	62 f2 ad 48 b4 e1                               	vpmadd52luq zmm4,zmm10,zmm1
   7e332:	62 b2 95 48 b5 fe                               	vpmadd52huq zmm7,zmm13,zmm22
   7e338:	62 f2 ad 48 b4 f2                               	vpmadd52luq zmm6,zmm10,zmm2
   7e33e:	62 51 bd 48 d4 c9                               	vpaddq zmm9,zmm8,zmm9
   7e344:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   7e349:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   7e34e:	62 32 9d 48 b5 c6                               	vpmadd52huq zmm8,zmm12,zmm22
   7e354:	62 32 f5 40 b4 ce                               	vpmadd52luq zmm9,zmm17,zmm22
   7e35a:	62 b2 8d 48 b5 ee                               	vpmadd52huq zmm5,zmm14,zmm22
   7e360:	62 b2 85 48 b5 e6                               	vpmadd52huq zmm4,zmm15,zmm22
   7e366:	62 b2 9d 48 b4 fe                               	vpmadd52luq zmm7,zmm12,zmm22
   7e36c:	62 b2 f5 40 b5 f6                               	vpmadd52huq zmm6,zmm17,zmm22
   7e372:	62 52 b5 48 b4 d3                               	vpmadd52luq zmm10,zmm9,zmm11
   7e378:	62 b2 95 48 b4 ee                               	vpmadd52luq zmm5,zmm13,zmm22
   7e37e:	62 b2 8d 48 b4 e6                               	vpmadd52luq zmm4,zmm14,zmm22
   7e384:	62 31 b5 48 d4 c8                               	vpaddq zmm9,zmm9,zmm16
   7e38a:	62 d1 b5 48 73 d1 34                            	vpsrlq zmm9,zmm9,0x34
   7e391:	62 b2 85 48 b4 f6                               	vpmadd52luq zmm6,zmm15,zmm22
   7e397:	62 f2 ad 48 b5 f9                               	vpmadd52huq zmm7,zmm10,zmm1
   7e39d:	62 f2 ad 48 b5 ea                               	vpmadd52huq zmm5,zmm10,zmm2
   7e3a3:	62 32 ad 48 b5 ca                               	vpmadd52huq zmm9,zmm10,zmm18
   7e3a9:	62 f2 ad 48 b5 e3                               	vpmadd52huq zmm4,zmm10,zmm3
   7e3af:	62 72 ad 48 b5 c0                               	vpmadd52huq zmm8,zmm10,zmm0
   7e3b5:	62 f2 ad 48 b4 f3                               	vpmadd52luq zmm6,zmm10,zmm3
   7e3bb:	62 f2 ad 48 b4 f8                               	vpmadd52luq zmm7,zmm10,zmm0
   7e3c1:	62 f2 ad 48 b4 e9                               	vpmadd52luq zmm5,zmm10,zmm1
   7e3c7:	62 f2 ad 48 b4 e2                               	vpmadd52luq zmm4,zmm10,zmm2
   7e3cd:	62 32 95 48 b5 c7                               	vpmadd52huq zmm8,zmm13,zmm23
   7e3d3:	62 d1 cd 48 d4 f1                               	vpaddq zmm6,zmm6,zmm9
   7e3d9:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   7e3de:	62 b2 f5 40 b4 f7                               	vpmadd52luq zmm6,zmm17,zmm23
   7e3e4:	62 b2 8d 48 b5 ff                               	vpmadd52huq zmm7,zmm14,zmm23
   7e3ea:	62 b2 85 48 b5 ef                               	vpmadd52huq zmm5,zmm15,zmm23
   7e3f0:	62 b2 f5 40 b5 e7                               	vpmadd52huq zmm4,zmm17,zmm23
   7e3f6:	62 32 9d 48 b4 c7                               	vpmadd52luq zmm8,zmm12,zmm23
   7e3fc:	62 52 cd 48 b4 cb                               	vpmadd52luq zmm9,zmm6,zmm11
   7e402:	62 b2 95 48 b4 ff                               	vpmadd52luq zmm7,zmm13,zmm23
   7e408:	62 b2 8d 48 b4 ef                               	vpmadd52luq zmm5,zmm14,zmm23
   7e40e:	62 b1 cd 48 d4 f3                               	vpaddq zmm6,zmm6,zmm19
   7e414:	62 b2 85 48 b4 e7                               	vpmadd52luq zmm4,zmm15,zmm23
   7e41a:	62 f1 cd 48 73 d6 30                            	vpsrlq zmm6,zmm6,0x30
   7e421:	62 d1 ad 48 73 f1 04                            	vpsllq zmm10,zmm9,0x4
   7e428:	62 31 b5 48 db cb                               	vpandq zmm9,zmm9,zmm19
   7e42e:	62 f2 b5 48 b5 fa                               	vpmadd52huq zmm7,zmm9,zmm2
   7e434:	62 f2 b5 48 b5 eb                               	vpmadd52huq zmm5,zmm9,zmm3
   7e43a:	62 b2 ad 48 b5 f2                               	vpmadd52huq zmm6,zmm10,zmm18
   7e440:	62 72 fd 48 59 15 56 8f f8 ff                   	vpbroadcastq zmm10,QWORD PTR [rip+0xfffffffffff88f56]        # 73a0 <GCC_except_table740+0x158>
   7e44a:	62 72 b5 48 b5 c1                               	vpmadd52huq zmm8,zmm9,zmm1
   7e450:	62 f2 b5 48 b4 e3                               	vpmadd52luq zmm4,zmm9,zmm3
   7e456:	62 f2 b5 48 b4 f9                               	vpmadd52luq zmm7,zmm9,zmm1
   7e45c:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   7e460:	62 b2 9d 48 b5 cf                               	vpmadd52huq zmm1,zmm12,zmm23
   7e466:	62 f2 b5 48 b4 ea                               	vpmadd52luq zmm5,zmm9,zmm2
   7e46c:	62 72 b5 48 b4 c0                               	vpmadd52luq zmm8,zmm9,zmm0
   7e472:	62 f2 b5 48 b5 c8                               	vpmadd52huq zmm1,zmm9,zmm0
   7e478:	62 f1 fd 48 73 f4 04                            	vpsllq zmm0,zmm4,0x4
   7e47f:	62 f1 e5 48 73 f7 04                            	vpsllq zmm3,zmm7,0x4
   7e486:	62 f1 ed 48 73 d5 30                            	vpsrlq zmm2,zmm5,0x30
   7e48d:	62 f1 d5 48 73 f5 04                            	vpsllq zmm5,zmm5,0x4
   7e494:	62 f1 dd 48 73 d4 30                            	vpsrlq zmm4,zmm4,0x30
   7e49b:	62 d1 fd 48 db c2                               	vpandq zmm0,zmm0,zmm10
   7e4a1:	62 d1 e5 48 db da                               	vpandq zmm3,zmm3,zmm10
   7e4a7:	62 d1 d5 48 db ea                               	vpandq zmm5,zmm5,zmm10
   7e4ad:	62 f1 e5 48 d4 d2                               	vpaddq zmm2,zmm3,zmm2
   7e4b3:	62 f1 e5 48 73 d7 30                            	vpsrlq zmm3,zmm7,0x30
   7e4ba:	62 d1 c5 48 73 f0 04                            	vpsllq zmm7,zmm8,0x4
   7e4c1:	62 f1 fd 48 d4 c6                               	vpaddq zmm0,zmm0,zmm6
   7e4c7:	62 d1 bd 48 73 d0 30                            	vpsrlq zmm8,zmm8,0x30
   7e4ce:	62 d1 c5 48 db f2                               	vpandq zmm6,zmm7,zmm10
   7e4d4:	62 f1 c5 48 73 d0 34                            	vpsrlq zmm7,zmm0,0x34
   7e4db:	62 b1 fd 48 db c0                               	vpandq zmm0,zmm0,zmm16
   7e4e1:	62 f1 c5 48 d4 e4                               	vpaddq zmm4,zmm7,zmm4
   7e4e7:	62 f1 cd 48 d4 db                               	vpaddq zmm3,zmm6,zmm3
   7e4ed:	62 f1 f5 48 73 f1 04                            	vpsllq zmm1,zmm1,0x4
   7e4f4:	62 f1 fd 48 7f 44 24 39                         	vmovdqa64 ZMMWORD PTR [rsp+0xe40],zmm0
   7e4fc:	62 f1 fd 48 7f 44 24 31                         	vmovdqa64 ZMMWORD PTR [rsp+0xc40],zmm0
   7e504:	62 f1 dd 48 d4 e5                               	vpaddq zmm4,zmm4,zmm5
   7e50a:	62 d1 f5 48 d4 c8                               	vpaddq zmm1,zmm1,zmm8
   7e510:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   7e517:	62 b1 dd 48 db e0                               	vpandq zmm4,zmm4,zmm16
   7e51d:	62 f1 d5 48 d4 d2                               	vpaddq zmm2,zmm5,zmm2
   7e523:	62 f1 fd 48 7f 64 24 38                         	vmovdqa64 ZMMWORD PTR [rsp+0xe00],zmm4
   7e52b:	62 f1 fd 48 7f 64 24 32                         	vmovdqa64 ZMMWORD PTR [rsp+0xc80],zmm4
   7e533:	62 f1 d5 48 73 d2 34                            	vpsrlq zmm5,zmm2,0x34
   7e53a:	62 b1 ed 48 db d0                               	vpandq zmm2,zmm2,zmm16
   7e540:	62 f1 d5 48 d4 db                               	vpaddq zmm3,zmm5,zmm3
   7e546:	62 f1 fd 48 7f 54 24 37                         	vmovdqa64 ZMMWORD PTR [rsp+0xdc0],zmm2
   7e54e:	62 f1 fd 48 7f 54 24 33                         	vmovdqa64 ZMMWORD PTR [rsp+0xcc0],zmm2
   7e556:	62 f1 d5 48 73 d3 34                            	vpsrlq zmm5,zmm3,0x34
   7e55d:	62 b1 e5 48 db d8                               	vpandq zmm3,zmm3,zmm16
   7e563:	62 f1 d5 48 d4 c9                               	vpaddq zmm1,zmm5,zmm1
   7e569:	62 f1 fd 48 7f 5c 24 34                         	vmovdqa64 ZMMWORD PTR [rsp+0xd00],zmm3
   7e571:	62 f1 fd 48 7f 5c 24 36                         	vmovdqa64 ZMMWORD PTR [rsp+0xd80],zmm3
   7e579:	62 f1 fd 48 7f 4c 24 3a                         	vmovdqa64 ZMMWORD PTR [rsp+0xe80],zmm1
   7e581:	62 f1 fd 48 7f 4c 24 35                         	vmovdqa64 ZMMWORD PTR [rsp+0xd40],zmm1
   7e589:	48 3b 9c 24 e8 00 00 00                         	cmp    rbx,QWORD PTR [rsp+0xe8]
   7e591:	75 10                                           	jne    7e5a3 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x2d53>
   7e593:	48 8d bc 24 e8 00 00 00                         	lea    rdi,[rsp+0xe8]
   7e59b:	c5 f8 77                                        	vzeroupper
   7e59e:	e8 0d 52 00 00                                  	call   837b0 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecNtNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns6RecordE8grow_oneBT_>
   7e5a3:	62 f2 fd 48 59 05 eb 8d f8 ff                   	vpbroadcastq zmm0,QWORD PTR [rip+0xfffffffffff88deb]        # 7398 <GCC_except_table740+0x150>
   7e5ad:	62 72 fd 48 59 25 09 8d f8 ff                   	vpbroadcastq zmm12,QWORD PTR [rip+0xfffffffffff88d09]        # 72c0 <GCC_except_table740+0x78>
   7e5b7:	c5 f8 90 4c 24 6e                               	kmovw  k1,WORD PTR [rsp+0x6e]
   7e5bd:	62 72 fd 48 59 2d 31 8e f8 ff                   	vpbroadcastq zmm13,QWORD PTR [rip+0xfffffffffff88e31]        # 73f8 <GCC_except_table740+0x1b0>
   7e5c7:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   7e5cb:	c4 41 29 ef d2                                  	vpxor  xmm10,xmm10,xmm10
   7e5d0:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   7e5d5:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   7e5da:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   7e5de:	62 72 fd 48 59 35 10 8d f8 ff                   	vpbroadcastq zmm14,QWORD PTR [rip+0xfffffffffff88d10]        # 72f8 <GCC_except_table740+0xb0>
   7e5e8:	48 89 d9                                        	mov    rcx,rbx
   7e5eb:	48 c1 e1 0a                                     	shl    rcx,0xa
   7e5ef:	48 ff c3                                        	inc    rbx
   7e5f2:	62 f1 9d 48 db 6c 24 3f                         	vpandq zmm5,zmm12,ZMMWORD PTR [rsp+0xfc0]
   7e5fa:	62 f1 9d 48 db 64 24 3e                         	vpandq zmm4,zmm12,ZMMWORD PTR [rsp+0xf80]
   7e602:	62 f1 9d 48 db 5c 24 3d                         	vpandq zmm3,zmm12,ZMMWORD PTR [rsp+0xf40]
   7e60a:	62 f1 9d 48 db 54 24 3c                         	vpandq zmm2,zmm12,ZMMWORD PTR [rsp+0xf00]
   7e612:	62 f2 fd 59 64 05 0c 8d f8 ff                   	vpblendmq zmm0{k1},zmm0,QWORD BCST [rip+0xfffffffffff88d0c]        # 7328 <GCC_except_table740+0xe0>
   7e61c:	62 71 fd 48 6f 5c 24 1f                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x7c0]
   7e624:	62 e1 fd 48 6f 54 24 40                         	vmovdqa64 zmm18,ZMMWORD PTR [rsp+0x1000]
   7e62c:	62 e1 fd 48 6f 4c 24 41                         	vmovdqa64 zmm17,ZMMWORD PTR [rsp+0x1040]
   7e634:	62 e1 fd 48 6f 44 24 42                         	vmovdqa64 zmm16,ZMMWORD PTR [rsp+0x1080]
   7e63c:	62 71 fd 48 6f 7c 24 43                         	vmovdqa64 zmm15,ZMMWORD PTR [rsp+0x10c0]
   7e644:	48 8b 84 24 f0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xf0]
   7e64c:	48 8b 94 24 c0 06 00 00                         	mov    rdx,QWORD PTR [rsp+0x6c0]
   7e654:	62 f1 fd 48 d4 44 24 3b                         	vpaddq zmm0,zmm0,ZMMWORD PTR [rsp+0xec0]
   7e65c:	62 52 d5 48 b5 d3                               	vpmadd52huq zmm10,zmm5,zmm11
   7e662:	62 52 dd 48 b5 c3                               	vpmadd52huq zmm8,zmm4,zmm11
   7e668:	62 52 e5 48 b5 cb                               	vpmadd52huq zmm9,zmm3,zmm11
   7e66e:	62 d2 d5 48 b4 f3                               	vpmadd52luq zmm6,zmm5,zmm11
   7e674:	62 d2 ed 48 b5 fb                               	vpmadd52huq zmm7,zmm2,zmm11
   7e67a:	62 d1 fd 48 db cc                               	vpandq zmm1,zmm0,zmm12
   7e680:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7e684:	62 d2 f5 48 b5 c3                               	vpmadd52huq zmm0,zmm1,zmm11
   7e68a:	62 52 dd 48 b4 d3                               	vpmadd52luq zmm10,zmm4,zmm11
   7e690:	62 52 e5 48 b4 c3                               	vpmadd52luq zmm8,zmm3,zmm11
   7e696:	62 52 ed 48 b4 cb                               	vpmadd52luq zmm9,zmm2,zmm11
   7e69c:	62 d2 f5 48 b4 fb                               	vpmadd52luq zmm7,zmm1,zmm11
   7e6a2:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   7e6a7:	62 52 cd 48 b4 dd                               	vpmadd52luq zmm11,zmm6,zmm13
   7e6ad:	62 d1 cd 48 d4 f4                               	vpaddq zmm6,zmm6,zmm12
   7e6b3:	62 f1 cd 48 73 d6 34                            	vpsrlq zmm6,zmm6,0x34
   7e6ba:	62 32 a5 48 b5 c2                               	vpmadd52huq zmm8,zmm11,zmm18
   7e6c0:	62 32 a5 48 b5 c9                               	vpmadd52huq zmm9,zmm11,zmm17
   7e6c6:	62 b2 a5 48 b5 f8                               	vpmadd52huq zmm7,zmm11,zmm16
   7e6cc:	62 d2 a5 48 b5 f6                               	vpmadd52huq zmm6,zmm11,zmm14
   7e6d2:	62 32 a5 48 b4 d2                               	vpmadd52luq zmm10,zmm11,zmm18
   7e6d8:	62 d2 a5 48 b5 c7                               	vpmadd52huq zmm0,zmm11,zmm15
   7e6de:	62 32 a5 48 b4 c1                               	vpmadd52luq zmm8,zmm11,zmm17
   7e6e4:	62 32 a5 48 b4 c8                               	vpmadd52luq zmm9,zmm11,zmm16
   7e6ea:	62 d2 a5 48 b4 ff                               	vpmadd52luq zmm7,zmm11,zmm15
   7e6f0:	62 71 fd 48 6f 5c 24 20                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x800]
   7e6f8:	62 71 ad 48 d4 d6                               	vpaddq zmm10,zmm10,zmm6
   7e6fe:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   7e702:	62 52 d5 48 b5 c3                               	vpmadd52huq zmm8,zmm5,zmm11
   7e708:	62 52 dd 48 b5 cb                               	vpmadd52huq zmm9,zmm4,zmm11
   7e70e:	62 d2 e5 48 b5 fb                               	vpmadd52huq zmm7,zmm3,zmm11
   7e714:	62 d2 ed 48 b5 c3                               	vpmadd52huq zmm0,zmm2,zmm11
   7e71a:	62 52 d5 48 b4 d3                               	vpmadd52luq zmm10,zmm5,zmm11
   7e720:	62 d2 f5 48 b5 f3                               	vpmadd52huq zmm6,zmm1,zmm11
   7e726:	62 52 dd 48 b4 c3                               	vpmadd52luq zmm8,zmm4,zmm11
   7e72c:	62 52 e5 48 b4 cb                               	vpmadd52luq zmm9,zmm3,zmm11
   7e732:	62 d2 ed 48 b4 fb                               	vpmadd52luq zmm7,zmm2,zmm11
   7e738:	62 d2 f5 48 b4 c3                               	vpmadd52luq zmm0,zmm1,zmm11
   7e73e:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   7e743:	62 52 ad 48 b4 dd                               	vpmadd52luq zmm11,zmm10,zmm13
   7e749:	62 51 ad 48 d4 d4                               	vpaddq zmm10,zmm10,zmm12
   7e74f:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   7e756:	62 32 a5 48 b5 ca                               	vpmadd52huq zmm9,zmm11,zmm18
   7e75c:	62 b2 a5 48 b5 f9                               	vpmadd52huq zmm7,zmm11,zmm17
   7e762:	62 b2 a5 48 b5 c0                               	vpmadd52huq zmm0,zmm11,zmm16
   7e768:	62 52 a5 48 b5 d6                               	vpmadd52huq zmm10,zmm11,zmm14
   7e76e:	62 32 a5 48 b4 c2                               	vpmadd52luq zmm8,zmm11,zmm18
   7e774:	62 d2 a5 48 b5 f7                               	vpmadd52huq zmm6,zmm11,zmm15
   7e77a:	62 32 a5 48 b4 c9                               	vpmadd52luq zmm9,zmm11,zmm17
   7e780:	62 b2 a5 48 b4 f8                               	vpmadd52luq zmm7,zmm11,zmm16
   7e786:	62 d2 a5 48 b4 c7                               	vpmadd52luq zmm0,zmm11,zmm15
   7e78c:	62 71 fd 48 6f 5c 24 21                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x840]
   7e794:	62 51 bd 48 d4 d2                               	vpaddq zmm10,zmm8,zmm10
   7e79a:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   7e79f:	62 52 d5 48 b5 cb                               	vpmadd52huq zmm9,zmm5,zmm11
   7e7a5:	62 d2 dd 48 b5 fb                               	vpmadd52huq zmm7,zmm4,zmm11
   7e7ab:	62 d2 e5 48 b5 c3                               	vpmadd52huq zmm0,zmm3,zmm11
   7e7b1:	62 d2 ed 48 b5 f3                               	vpmadd52huq zmm6,zmm2,zmm11
   7e7b7:	62 52 d5 48 b4 d3                               	vpmadd52luq zmm10,zmm5,zmm11
   7e7bd:	62 52 f5 48 b5 c3                               	vpmadd52huq zmm8,zmm1,zmm11
   7e7c3:	62 52 dd 48 b4 cb                               	vpmadd52luq zmm9,zmm4,zmm11
   7e7c9:	62 d2 e5 48 b4 fb                               	vpmadd52luq zmm7,zmm3,zmm11
   7e7cf:	62 d2 ed 48 b4 c3                               	vpmadd52luq zmm0,zmm2,zmm11
   7e7d5:	62 d2 f5 48 b4 f3                               	vpmadd52luq zmm6,zmm1,zmm11
   7e7db:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   7e7e0:	62 52 ad 48 b4 dd                               	vpmadd52luq zmm11,zmm10,zmm13
   7e7e6:	62 51 ad 48 d4 d4                               	vpaddq zmm10,zmm10,zmm12
   7e7ec:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   7e7f3:	62 b2 a5 48 b5 fa                               	vpmadd52huq zmm7,zmm11,zmm18
   7e7f9:	62 b2 a5 48 b5 c1                               	vpmadd52huq zmm0,zmm11,zmm17
   7e7ff:	62 b2 a5 48 b5 f0                               	vpmadd52huq zmm6,zmm11,zmm16
   7e805:	62 52 a5 48 b5 d6                               	vpmadd52huq zmm10,zmm11,zmm14
   7e80b:	62 32 a5 48 b4 ca                               	vpmadd52luq zmm9,zmm11,zmm18
   7e811:	62 52 a5 48 b5 c7                               	vpmadd52huq zmm8,zmm11,zmm15
   7e817:	62 b2 a5 48 b4 f9                               	vpmadd52luq zmm7,zmm11,zmm17
   7e81d:	62 b2 a5 48 b4 c0                               	vpmadd52luq zmm0,zmm11,zmm16
   7e823:	62 d2 a5 48 b4 f7                               	vpmadd52luq zmm6,zmm11,zmm15
   7e829:	62 71 fd 48 6f 5c 24 22                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x880]
   7e831:	62 51 b5 48 d4 d2                               	vpaddq zmm10,zmm9,zmm10
   7e837:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   7e83c:	62 d2 d5 48 b5 fb                               	vpmadd52huq zmm7,zmm5,zmm11
   7e842:	62 d2 dd 48 b5 c3                               	vpmadd52huq zmm0,zmm4,zmm11
   7e848:	62 d2 e5 48 b5 f3                               	vpmadd52huq zmm6,zmm3,zmm11
   7e84e:	62 52 ed 48 b5 c3                               	vpmadd52huq zmm8,zmm2,zmm11
   7e854:	62 52 d5 48 b4 d3                               	vpmadd52luq zmm10,zmm5,zmm11
   7e85a:	62 52 f5 48 b5 cb                               	vpmadd52huq zmm9,zmm1,zmm11
   7e860:	62 d2 dd 48 b4 fb                               	vpmadd52luq zmm7,zmm4,zmm11
   7e866:	62 d2 e5 48 b4 c3                               	vpmadd52luq zmm0,zmm3,zmm11
   7e86c:	62 d2 ed 48 b4 f3                               	vpmadd52luq zmm6,zmm2,zmm11
   7e872:	62 52 f5 48 b4 c3                               	vpmadd52luq zmm8,zmm1,zmm11
   7e878:	c4 41 21 ef db                                  	vpxor  xmm11,xmm11,xmm11
   7e87d:	62 52 ad 48 b4 dd                               	vpmadd52luq zmm11,zmm10,zmm13
   7e883:	62 51 ad 48 d4 d4                               	vpaddq zmm10,zmm10,zmm12
   7e889:	62 d1 ad 48 73 d2 34                            	vpsrlq zmm10,zmm10,0x34
   7e890:	62 b2 a5 48 b5 c2                               	vpmadd52huq zmm0,zmm11,zmm18
   7e896:	62 b2 a5 48 b5 f1                               	vpmadd52huq zmm6,zmm11,zmm17
   7e89c:	62 32 a5 48 b5 c0                               	vpmadd52huq zmm8,zmm11,zmm16
   7e8a2:	62 52 a5 48 b5 d6                               	vpmadd52huq zmm10,zmm11,zmm14
   7e8a8:	62 b2 a5 48 b4 fa                               	vpmadd52luq zmm7,zmm11,zmm18
   7e8ae:	62 52 a5 48 b5 cf                               	vpmadd52huq zmm9,zmm11,zmm15
   7e8b4:	62 b2 a5 48 b4 c1                               	vpmadd52luq zmm0,zmm11,zmm17
   7e8ba:	62 b2 a5 48 b4 f0                               	vpmadd52luq zmm6,zmm11,zmm16
   7e8c0:	62 52 a5 48 b4 c7                               	vpmadd52luq zmm8,zmm11,zmm15
   7e8c6:	62 71 fd 48 6f 5c 24 1c                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x700]
   7e8ce:	62 d1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm10
   7e8d4:	62 71 fd 48 6f 54 24 48                         	vmovdqa64 zmm10,ZMMWORD PTR [rsp+0x1200]
   7e8dc:	62 d2 d5 48 b5 c3                               	vpmadd52huq zmm0,zmm5,zmm11
   7e8e2:	62 52 e5 48 b5 c3                               	vpmadd52huq zmm8,zmm3,zmm11
   7e8e8:	62 52 ed 48 b5 cb                               	vpmadd52huq zmm9,zmm2,zmm11
   7e8ee:	62 d2 d5 48 b4 fb                               	vpmadd52luq zmm7,zmm5,zmm11
   7e8f4:	62 f2 fd 48 59 2d ca 89 f8 ff                   	vpbroadcastq zmm5,QWORD PTR [rip+0xfffffffffff889ca]        # 72c8 <GCC_except_table740+0x80>
   7e8fe:	62 d2 dd 48 b5 f3                               	vpmadd52huq zmm6,zmm4,zmm11
   7e904:	62 52 ed 48 b4 c3                               	vpmadd52luq zmm8,zmm2,zmm11
   7e90a:	c5 e9 ef d2                                     	vpxor  xmm2,xmm2,xmm2
   7e90e:	62 52 f5 48 b4 cb                               	vpmadd52luq zmm9,zmm1,zmm11
   7e914:	62 d2 f5 48 b5 d3                               	vpmadd52huq zmm2,zmm1,zmm11
   7e91a:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   7e91e:	62 d2 c5 48 b4 cd                               	vpmadd52luq zmm1,zmm7,zmm13
   7e924:	62 d2 e5 48 b4 f3                               	vpmadd52luq zmm6,zmm3,zmm11
   7e92a:	62 d2 dd 48 b4 c3                               	vpmadd52luq zmm0,zmm4,zmm11
   7e930:	62 71 7c 48 28 5c 24 30                         	vmovaps zmm11,ZMMWORD PTR [rsp+0xc00]
   7e938:	62 71 7c 48 28 6c 24 2f                         	vmovaps zmm13,ZMMWORD PTR [rsp+0xbc0]
   7e940:	62 f1 dd 48 73 f1 04                            	vpsllq zmm4,zmm1,0x4
   7e947:	62 f1 f5 48 db cd                               	vpandq zmm1,zmm1,zmm5
   7e94d:	62 f1 c5 48 d4 dd                               	vpaddq zmm3,zmm7,zmm5
   7e953:	62 f2 fd 48 59 3d 43 8a f8 ff                   	vpbroadcastq zmm7,QWORD PTR [rip+0xfffffffffff88a43]        # 73a0 <GCC_except_table740+0x158>
   7e95d:	62 32 f5 48 b5 c1                               	vpmadd52huq zmm8,zmm1,zmm17
   7e963:	62 32 f5 48 b5 c8                               	vpmadd52huq zmm9,zmm1,zmm16
   7e969:	62 b2 f5 48 b5 f2                               	vpmadd52huq zmm6,zmm1,zmm18
   7e96f:	62 b2 f5 48 b4 c2                               	vpmadd52luq zmm0,zmm1,zmm18
   7e975:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   7e97c:	62 d2 f5 48 b5 d7                               	vpmadd52huq zmm2,zmm1,zmm15
   7e982:	62 d2 dd 48 b5 de                               	vpmadd52huq zmm3,zmm4,zmm14
   7e988:	62 71 7c 48 29 1c 08                            	vmovaps ZMMWORD PTR [rax+rcx*1],zmm11
   7e98f:	62 71 7c 48 28 5c 24 2e                         	vmovaps zmm11,ZMMWORD PTR [rsp+0xb80]
   7e997:	62 71 7c 48 29 6c 08 01                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x40],zmm13
   7e99f:	62 71 fd 48 6f 6c 24 4a                         	vmovdqa64 zmm13,ZMMWORD PTR [rsp+0x1280]
   7e9a7:	62 32 f5 48 b4 c0                               	vpmadd52luq zmm8,zmm1,zmm16
   7e9ad:	62 52 f5 48 b4 cf                               	vpmadd52luq zmm9,zmm1,zmm15
   7e9b3:	62 b2 f5 48 b4 f1                               	vpmadd52luq zmm6,zmm1,zmm17
   7e9b9:	62 f1 f5 48 73 f0 04                            	vpsllq zmm1,zmm0,0x4
   7e9c0:	62 f1 fd 48 73 d0 30                            	vpsrlq zmm0,zmm0,0x30
   7e9c7:	62 f1 ed 48 73 f2 04                            	vpsllq zmm2,zmm2,0x4
   7e9ce:	62 f1 f5 48 db cf                               	vpandq zmm1,zmm1,zmm7
   7e9d4:	62 d1 dd 48 73 f0 04                            	vpsllq zmm4,zmm8,0x4
   7e9db:	62 d1 d5 48 73 f1 04                            	vpsllq zmm5,zmm9,0x4
   7e9e2:	62 f1 f5 48 d4 cb                               	vpaddq zmm1,zmm1,zmm3
   7e9e8:	62 f1 e5 48 73 d6 30                            	vpsrlq zmm3,zmm6,0x30
   7e9ef:	62 d1 bd 48 73 d0 30                            	vpsrlq zmm8,zmm8,0x30
   7e9f6:	62 f1 dd 48 db e7                               	vpandq zmm4,zmm4,zmm7
   7e9fc:	62 f1 d5 48 db ef                               	vpandq zmm5,zmm5,zmm7
   7ea02:	62 f1 dd 48 d4 db                               	vpaddq zmm3,zmm4,zmm3
   7ea08:	62 d1 d5 48 d4 e0                               	vpaddq zmm4,zmm5,zmm8
   7ea0e:	62 f1 d5 48 73 d1 34                            	vpsrlq zmm5,zmm1,0x34
   7ea15:	62 d1 bd 48 73 d1 30                            	vpsrlq zmm8,zmm9,0x30
   7ea1c:	62 d1 f5 48 db cc                               	vpandq zmm1,zmm1,zmm12
   7ea22:	62 f1 d5 48 d4 c0                               	vpaddq zmm0,zmm5,zmm0
   7ea28:	62 f1 d5 48 73 f6 04                            	vpsllq zmm5,zmm6,0x4
   7ea2f:	62 d1 ed 48 d4 d0                               	vpaddq zmm2,zmm2,zmm8
   7ea35:	62 71 7c 48 29 5c 08 02                         	vmovaps ZMMWORD PTR [rax+rcx*1+0x80],zmm11
   7ea3d:	62 71 fd 48 6f 5c 24 49                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x1240]
   7ea45:	62 71 fd 48 7f 6c 08 03                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0xc0],zmm13
   7ea4d:	62 f1 d5 48 db ef                               	vpandq zmm5,zmm5,zmm7
   7ea53:	62 f1 fd 48 d4 c5                               	vpaddq zmm0,zmm0,zmm5
   7ea59:	62 f1 d5 48 73 d0 34                            	vpsrlq zmm5,zmm0,0x34
   7ea60:	62 d1 fd 48 db c4                               	vpandq zmm0,zmm0,zmm12
   7ea66:	62 f1 d5 48 d4 db                               	vpaddq zmm3,zmm5,zmm3
   7ea6c:	62 f1 d5 48 73 d3 34                            	vpsrlq zmm5,zmm3,0x34
   7ea73:	62 d1 e5 48 db dc                               	vpandq zmm3,zmm3,zmm12
   7ea79:	62 f1 d5 48 d4 e4                               	vpaddq zmm4,zmm5,zmm4
   7ea7f:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   7ea86:	62 f1 d5 48 d4 d2                               	vpaddq zmm2,zmm5,zmm2
   7ea8c:	62 d1 d5 48 73 d2 34                            	vpsrlq zmm5,zmm10,0x34
   7ea93:	62 f1 d5 48 d4 6c 24 44                         	vpaddq zmm5,zmm5,ZMMWORD PTR [rsp+0x1100]
   7ea9b:	62 71 fd 48 7f 5c 08 04                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x100],zmm11
   7eaa3:	62 f1 fd 48 7f 4c 08 05                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x140],zmm1
   7eaab:	62 d1 dd 48 db cc                               	vpandq zmm1,zmm4,zmm12
   7eab1:	62 f1 fd 48 7f 44 08 06                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x180],zmm0
   7eab9:	62 f1 fd 48 7f 5c 08 07                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x1c0],zmm3
   7eac1:	62 f1 fd 48 7f 4c 08 08                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x200],zmm1
   7eac9:	62 f1 fd 48 7f 54 08 09                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x240],zmm2
   7ead1:	62 d1 ad 48 db d4                               	vpandq zmm2,zmm10,zmm12
   7ead7:	62 f1 fd 48 7f 54 08 0a                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x280],zmm2
   7eadf:	62 f1 cd 48 73 d5 34                            	vpsrlq zmm6,zmm5,0x34
   7eae6:	62 f1 cd 48 d4 74 24 45                         	vpaddq zmm6,zmm6,ZMMWORD PTR [rsp+0x1140]
   7eaee:	62 d1 d5 48 db cc                               	vpandq zmm1,zmm5,zmm12
   7eaf4:	62 f1 fd 48 7f 4c 08 0b                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x2c0],zmm1
   7eafc:	62 f1 c5 48 73 d6 34                            	vpsrlq zmm7,zmm6,0x34
   7eb03:	62 f1 c5 48 d4 7c 24 46                         	vpaddq zmm7,zmm7,ZMMWORD PTR [rsp+0x1180]
   7eb0b:	62 d1 cd 48 db d4                               	vpandq zmm2,zmm6,zmm12
   7eb11:	62 f1 fd 48 7f 54 08 0c                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x300],zmm2
   7eb19:	62 f1 bd 48 73 d7 34                            	vpsrlq zmm8,zmm7,0x34
   7eb20:	62 71 bd 48 d4 44 24 47                         	vpaddq zmm8,zmm8,ZMMWORD PTR [rsp+0x11c0]
   7eb28:	62 d1 c5 48 db cc                               	vpandq zmm1,zmm7,zmm12
   7eb2e:	62 f1 fd 48 7f 4c 08 0d                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x340],zmm1
   7eb36:	62 71 fd 48 7f 44 08 0e                         	vmovdqa64 ZMMWORD PTR [rax+rcx*1+0x380],zmm8
   7eb3e:	89 94 08 c0 03 00 00                            	mov    DWORD PTR [rax+rcx*1+0x3c0],edx
   7eb45:	44 88 bc 08 c4 03 00 00                         	mov    BYTE PTR [rax+rcx*1+0x3c4],r15b
   7eb4d:	8b 84 24 c0 03 00 00                            	mov    eax,DWORD PTR [rsp+0x3c0]
   7eb54:	48 89 9c 24 f8 00 00 00                         	mov    QWORD PTR [rsp+0xf8],rbx
   7eb5c:	22 84 24 00 01 00 00                            	and    al,BYTE PTR [rsp+0x100]
   7eb63:	89 84 24 c0 03 00 00                            	mov    DWORD PTR [rsp+0x3c0],eax
   7eb6a:	0f 84 f9 e9 ff ff                               	je     7d569 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1d19>
   7eb70:	c5 7d 6f 1d 28 93 f8 ff                         	vmovdqa ymm11,YMMWORD PTR [rip+0xfffffffffff89328]        # 7ea0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x860>
   7eb78:	62 d1 fd 48 6f 45 00                            	vmovdqa64 zmm0,ZMMWORD PTR [r13+0x0]
   7eb7f:	62 72 fd 48 59 2d 2f 88 f8 ff                   	vpbroadcastq zmm13,QWORD PTR [rip+0xfffffffffff8882f]        # 73b8 <GCC_except_table740+0x170>
   7eb89:	48 b8 31 e1 72 4e 64 30 00 00                   	movabs rax,0x30644e72e131
   7eb93:	62 d1 fd 48 6f 4d 01                            	vmovdqa64 zmm1,ZMMWORD PTR [r13+0x40]
   7eb9a:	62 d1 fd 48 6f 55 02                            	vmovdqa64 zmm2,ZMMWORD PTR [r13+0x80]
   7eba1:	62 d1 fd 48 6f 5d 03                            	vmovdqa64 zmm3,ZMMWORD PTR [r13+0xc0]
   7eba8:	62 d1 fd 48 6f 65 04                            	vmovdqa64 zmm4,ZMMWORD PTR [r13+0x100]
   7ebaf:	62 72 fd 48 59 35 77 87 f8 ff                   	vpbroadcastq zmm14,QWORD PTR [rip+0xfffffffffff88777]        # 7330 <GCC_except_table740+0xe8>
   7ebb9:	62 71 fd 48 6f 3d 7d 8f f8 ff                   	vmovdqa64 zmm15,ZMMWORD PTR [rip+0xfffffffffff88f7d]        # 7b40 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x500>
   7ebc3:	62 e1 fd 48 6f 05 b3 8f f8 ff                   	vmovdqa64 zmm16,ZMMWORD PTR [rip+0xfffffffffff88fb3]        # 7b80 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x540>
   7ebcd:	31 db                                           	xor    ebx,ebx
   7ebcf:	45 31 ff                                        	xor    r15d,r15d
   7ebd2:	4c 89 ac 24 40 06 00 00                         	mov    QWORD PTR [rsp+0x640],r13
   7ebda:	4c 89 b4 24 80 06 00 00                         	mov    QWORD PTR [rsp+0x680],r14
   7ebe2:	c5 7e 7f 9c 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm11
   7ebeb:	48 89 84 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rax
   7ebf3:	62 51 fd 48 d4 cd                               	vpaddq zmm9,zmm0,zmm13
   7ebf9:	62 f1 f5 58 fb 6c 24 31                         	vpsubq zmm5,zmm1,QWORD BCST [rsp+0x188]
   7ec01:	62 f1 ed 58 fb 74 24 32                         	vpsubq zmm6,zmm2,QWORD BCST [rsp+0x190]
   7ec09:	62 f1 e5 58 fb 7c 24 33                         	vpsubq zmm7,zmm3,QWORD BCST [rsp+0x198]
   7ec11:	62 71 dd 58 fb 44 24 34                         	vpsubq zmm8,zmm4,QWORD BCST [rsp+0x1a0]
   7ec19:	62 d1 ad 48 72 e1 34                            	vpsraq zmm10,zmm9,0x34
   7ec20:	62 d1 d5 48 d4 ea                               	vpaddq zmm5,zmm5,zmm10
   7ec26:	62 f1 ad 48 72 e5 34                            	vpsraq zmm10,zmm5,0x34
   7ec2d:	62 d1 cd 48 d4 f2                               	vpaddq zmm6,zmm6,zmm10
   7ec33:	62 f1 ad 48 72 e6 34                            	vpsraq zmm10,zmm6,0x34
   7ec3a:	62 d1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm10
   7ec40:	62 f1 ad 48 72 e7 34                            	vpsraq zmm10,zmm7,0x34
   7ec47:	62 51 bd 48 d4 c2                               	vpaddq zmm8,zmm8,zmm10
   7ec4d:	62 d3 bd 48 1e ce 01                            	vpcmpltuq k1,zmm8,zmm14
   7ec54:	62 d1 d5 49 db cc                               	vpandq zmm1{k1},zmm5,zmm12
   7ec5a:	62 d1 cd 49 db d4                               	vpandq zmm2{k1},zmm6,zmm12
   7ec60:	62 d1 c5 49 db dc                               	vpandq zmm3{k1},zmm7,zmm12
   7ec66:	62 d1 fd 49 6f e0                               	vmovdqa64 zmm4{k1},zmm8
   7ec6c:	62 d1 b5 49 db c4                               	vpandq zmm0{k1},zmm9,zmm12
   7ec72:	62 f1 dd 48 73 f4 10                            	vpsllq zmm4,zmm4,0x10
   7ec79:	62 f1 d5 48 73 f1 34                            	vpsllq zmm5,zmm1,0x34
   7ec80:	62 f1 c5 48 73 f2 28                            	vpsllq zmm7,zmm2,0x28
   7ec87:	62 f1 f5 48 73 d1 0c                            	vpsrlq zmm1,zmm1,0xc
   7ec8e:	62 f1 cd 48 73 f3 1c                            	vpsllq zmm6,zmm3,0x1c
   7ec95:	62 f1 ed 48 73 d2 18                            	vpsrlq zmm2,zmm2,0x18
   7ec9c:	62 f1 e5 48 73 d3 24                            	vpsrlq zmm3,zmm3,0x24
   7eca3:	62 f1 d5 48 eb c0                               	vporq  zmm0,zmm5,zmm0
   7eca9:	62 f1 c5 48 eb c9                               	vporq  zmm1,zmm7,zmm1
   7ecaf:	62 f1 dd 48 eb db                               	vporq  zmm3,zmm4,zmm3
   7ecb5:	62 f1 cd 48 eb d2                               	vporq  zmm2,zmm6,zmm2
   7ecbb:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   7ecc1:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   7ecc7:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   7eccd:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   7ecd3:	62 f1 fd 48 6f dc                               	vmovdqa64 zmm3,zmm4
   7ecd9:	62 f2 85 48 7e d9                               	vpermt2q zmm3,zmm15,zmm1
   7ecdf:	62 f2 fd 40 7e e1                               	vpermt2q zmm4,zmm16,zmm1
   7ece5:	62 f1 fd 48 6f c8                               	vmovdqa64 zmm1,zmm0
   7eceb:	62 f2 85 48 7e ca                               	vpermt2q zmm1,zmm15,zmm2
   7ecf1:	62 f2 fd 40 7e c2                               	vpermt2q zmm0,zmm16,zmm2
   7ecf7:	62 f3 e5 48 3a d1 01                            	vinserti64x4 zmm2,zmm3,ymm1,0x1
   7ecfe:	62 f3 e5 48 43 c9 ee                            	vshufi64x2 zmm1,zmm3,zmm1,0xee
   7ed05:	62 f3 dd 48 3a d8 01                            	vinserti64x4 zmm3,zmm4,ymm0,0x1
   7ed0c:	62 f3 dd 48 43 c0 ee                            	vshufi64x2 zmm0,zmm4,zmm0,0xee
   7ed13:	62 f1 fe 48 7f 54 24 23                         	vmovdqu64 ZMMWORD PTR [rsp+0x8c0],zmm2
   7ed1b:	62 f1 fe 48 7f 4c 24 24                         	vmovdqu64 ZMMWORD PTR [rsp+0x900],zmm1
   7ed23:	62 f1 fe 48 7f 5c 24 25                         	vmovdqu64 ZMMWORD PTR [rsp+0x940],zmm3
   7ed2b:	62 f1 fe 48 7f 44 24 26                         	vmovdqu64 ZMMWORD PTR [rsp+0x980],zmm0
   7ed33:	62 d1 fd 48 6f 45 05                            	vmovdqa64 zmm0,ZMMWORD PTR [r13+0x140]
   7ed3a:	62 d1 fd 48 6f 4d 06                            	vmovdqa64 zmm1,ZMMWORD PTR [r13+0x180]
   7ed41:	62 d1 fd 48 6f 55 07                            	vmovdqa64 zmm2,ZMMWORD PTR [r13+0x1c0]
   7ed48:	62 d1 fd 48 6f 5d 08                            	vmovdqa64 zmm3,ZMMWORD PTR [r13+0x200]
   7ed4f:	62 d1 fd 48 6f 65 09                            	vmovdqa64 zmm4,ZMMWORD PTR [r13+0x240]
   7ed56:	c5 7e 7f 9c 24 80 01 00 00                      	vmovdqu YMMWORD PTR [rsp+0x180],ymm11
   7ed5f:	48 89 84 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rax
   7ed67:	62 f1 f5 58 fb 6c 24 31                         	vpsubq zmm5,zmm1,QWORD BCST [rsp+0x188]
   7ed6f:	62 f1 ed 58 fb 74 24 32                         	vpsubq zmm6,zmm2,QWORD BCST [rsp+0x190]
   7ed77:	62 f1 e5 58 fb 7c 24 33                         	vpsubq zmm7,zmm3,QWORD BCST [rsp+0x198]
   7ed7f:	62 71 dd 58 fb 44 24 34                         	vpsubq zmm8,zmm4,QWORD BCST [rsp+0x1a0]
   7ed87:	62 51 fd 48 d4 cd                               	vpaddq zmm9,zmm0,zmm13
   7ed8d:	62 d1 ad 48 72 e1 34                            	vpsraq zmm10,zmm9,0x34
   7ed94:	62 d1 d5 48 d4 ea                               	vpaddq zmm5,zmm5,zmm10
   7ed9a:	62 f1 ad 48 72 e5 34                            	vpsraq zmm10,zmm5,0x34
   7eda1:	62 d1 cd 48 d4 f2                               	vpaddq zmm6,zmm6,zmm10
   7eda7:	62 f1 ad 48 72 e6 34                            	vpsraq zmm10,zmm6,0x34
   7edae:	62 d1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm10
   7edb4:	62 f1 ad 48 72 e7 34                            	vpsraq zmm10,zmm7,0x34
   7edbb:	62 51 bd 48 d4 c2                               	vpaddq zmm8,zmm8,zmm10
   7edc1:	62 d3 bd 48 1e ce 01                            	vpcmpltuq k1,zmm8,zmm14
   7edc8:	62 d1 d5 49 db cc                               	vpandq zmm1{k1},zmm5,zmm12
   7edce:	62 d1 cd 49 db d4                               	vpandq zmm2{k1},zmm6,zmm12
   7edd4:	62 d1 c5 49 db dc                               	vpandq zmm3{k1},zmm7,zmm12
   7edda:	62 d1 fd 49 6f e0                               	vmovdqa64 zmm4{k1},zmm8
   7ede0:	62 d1 b5 49 db c4                               	vpandq zmm0{k1},zmm9,zmm12
   7ede6:	62 f1 dd 48 73 f4 10                            	vpsllq zmm4,zmm4,0x10
   7eded:	62 f1 d5 48 73 f1 34                            	vpsllq zmm5,zmm1,0x34
   7edf4:	62 f1 c5 48 73 f2 28                            	vpsllq zmm7,zmm2,0x28
   7edfb:	62 f1 f5 48 73 d1 0c                            	vpsrlq zmm1,zmm1,0xc
   7ee02:	62 f1 cd 48 73 f3 1c                            	vpsllq zmm6,zmm3,0x1c
   7ee09:	62 f1 ed 48 73 d2 18                            	vpsrlq zmm2,zmm2,0x18
   7ee10:	62 f1 e5 48 73 d3 24                            	vpsrlq zmm3,zmm3,0x24
   7ee17:	62 f1 d5 48 eb c0                               	vporq  zmm0,zmm5,zmm0
   7ee1d:	62 f1 c5 48 eb c9                               	vporq  zmm1,zmm7,zmm1
   7ee23:	62 f1 dd 48 eb db                               	vporq  zmm3,zmm4,zmm3
   7ee29:	62 f1 cd 48 eb d2                               	vporq  zmm2,zmm6,zmm2
   7ee2f:	62 f1 fd 48 6c e1                               	vpunpcklqdq zmm4,zmm0,zmm1
   7ee35:	62 f1 fd 48 6d c1                               	vpunpckhqdq zmm0,zmm0,zmm1
   7ee3b:	62 f1 ed 48 6c cb                               	vpunpcklqdq zmm1,zmm2,zmm3
   7ee41:	62 f1 ed 48 6d d3                               	vpunpckhqdq zmm2,zmm2,zmm3
   7ee47:	62 f1 fd 48 6f dc                               	vmovdqa64 zmm3,zmm4
   7ee4d:	62 f2 85 48 7e d9                               	vpermt2q zmm3,zmm15,zmm1
   7ee53:	62 f2 fd 40 7e e1                               	vpermt2q zmm4,zmm16,zmm1
   7ee59:	62 f1 fd 48 6f c8                               	vmovdqa64 zmm1,zmm0
   7ee5f:	62 f2 85 48 7e ca                               	vpermt2q zmm1,zmm15,zmm2
   7ee65:	62 f2 fd 40 7e c2                               	vpermt2q zmm0,zmm16,zmm2
   7ee6b:	62 f3 e5 48 3a d1 01                            	vinserti64x4 zmm2,zmm3,ymm1,0x1
   7ee72:	62 f3 e5 48 43 c9 ee                            	vshufi64x2 zmm1,zmm3,zmm1,0xee
   7ee79:	62 f3 dd 48 3a d8 01                            	vinserti64x4 zmm3,zmm4,ymm0,0x1
   7ee80:	62 f3 dd 48 43 c0 ee                            	vshufi64x2 zmm0,zmm4,zmm0,0xee
   7ee87:	62 f1 fe 48 7f 54 24 06                         	vmovdqu64 ZMMWORD PTR [rsp+0x180],zmm2
   7ee8f:	62 f1 fe 48 7f 4c 24 07                         	vmovdqu64 ZMMWORD PTR [rsp+0x1c0],zmm1
   7ee97:	62 f1 fe 48 7f 5c 24 08                         	vmovdqu64 ZMMWORD PTR [rsp+0x200],zmm3
   7ee9f:	62 f1 fe 48 7f 44 24 09                         	vmovdqu64 ZMMWORD PTR [rsp+0x240],zmm0
   7eea7:	eb 36                                           	jmp    7eedf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x368f>
   7eea9:	0f 1f 80 00 00 00 00                            	nop    DWORD PTR [rax+0x0]
   7eeb0:	31 c0                                           	xor    eax,eax
   7eeb2:	41 f6 d4                                        	not    r12b
   7eeb5:	45 22 a5 a1 02 00 00                            	and    r12b,BYTE PTR [r13+0x2a1]
   7eebc:	4c 8b b4 24 80 06 00 00                         	mov    r14,QWORD PTR [rsp+0x680]
   7eec4:	41 08 c4                                        	or     r12b,al
   7eec7:	45 88 a5 a1 02 00 00                            	mov    BYTE PTR [r13+0x2a1],r12b
   7eece:	49 ff c7                                        	inc    r15
   7eed1:	48 83 c3 20                                     	add    rbx,0x20
   7eed5:	49 83 ff 08                                     	cmp    r15,0x8
   7eed9:	0f 84 01 e5 ff ff                               	je     7d3e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1b90>
   7eedf:	0f b6 84 24 c0 03 00 00                         	movzx  eax,BYTE PTR [rsp+0x3c0]
   7eee7:	41 b4 01                                        	mov    r12b,0x1
   7eeea:	44 89 f9                                        	mov    ecx,r15d
   7eeed:	41 d2 e4                                        	shl    r12b,cl
   7eef0:	44 0f a3 f8                                     	bt     eax,r15d
   7eef4:	73 d8                                           	jae    7eece <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x367e>
   7eef6:	45 84 a5 a1 02 00 00                            	test   BYTE PTR [r13+0x2a1],r12b
   7eefd:	0f 84 dd 00 00 00                               	je     7efe0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3790>
   7ef03:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7ef07:	62 f1 fd 48 7f 44 24 1d                         	vmovdqa64 ZMMWORD PTR [rsp+0x740],zmm0
   7ef0f:	48 8d 84 5c 00 04 00 00                         	lea    rax,[rsp+rbx*2+0x400]
   7ef17:	45 84 f4                                        	test   r12b,r14b
   7ef1a:	0f 84 f8 00 00 00                               	je     7f018 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x37c8>
   7ef20:	c5 fc 10 00                                     	vmovups ymm0,YMMWORD PTR [rax]
   7ef24:	c5 fe 6f 94 5c 20 04 00 00                      	vmovdqu ymm2,YMMWORD PTR [rsp+rbx*2+0x420]
   7ef2d:	c5 fe 6f 0d 6b 90 f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff8906b]        # 7fa0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x960>
   7ef35:	31 c0                                           	xor    eax,eax
   7ef37:	31 c9                                           	xor    ecx,ecx
   7ef39:	31 d2                                           	xor    edx,edx
   7ef3b:	31 f6                                           	xor    esi,esi
   7ef3d:	4c 8d b4 24 e0 12 00 00                         	lea    r14,[rsp+0x12e0]
   7ef45:	4c 8d ac 24 00 0a 00 00                         	lea    r13,[rsp+0xa00]
   7ef4d:	c5 fc 29 84 24 80 07 00 00                      	vmovaps YMMWORD PTR [rsp+0x780],ymm0
   7ef56:	c5 fd 7f 94 24 e0 12 00 00                      	vmovdqa YMMWORD PTR [rsp+0x12e0],ymm2
   7ef5f:	c5 fd 7f 8c 24 00 0a 00 00                      	vmovdqa YMMWORD PTR [rsp+0xa00],ymm1
   7ef68:	49 2b 0e                                        	sub    rcx,QWORD PTR [r14]
   7ef6b:	49 1b 56 08                                     	sbb    rdx,QWORD PTR [r14+0x8]
   7ef6f:	49 1b 76 10                                     	sbb    rsi,QWORD PTR [r14+0x10]
   7ef73:	49 1b 46 18                                     	sbb    rax,QWORD PTR [r14+0x18]
   7ef77:	4d 19 db                                        	sbb    r11,r11
   7ef7a:	49 8b 7d 00                                     	mov    rdi,QWORD PTR [r13+0x0]
   7ef7e:	4d 8b 45 08                                     	mov    r8,QWORD PTR [r13+0x8]
   7ef82:	4d 8b 4d 10                                     	mov    r9,QWORD PTR [r13+0x10]
   7ef86:	4d 8b 55 18                                     	mov    r10,QWORD PTR [r13+0x18]
   7ef8a:	4c 21 df                                        	and    rdi,r11
   7ef8d:	4d 21 d8                                        	and    r8,r11
   7ef90:	4d 21 d9                                        	and    r9,r11
   7ef93:	4d 21 da                                        	and    r10,r11
   7ef96:	48 01 f9                                        	add    rcx,rdi
   7ef99:	4c 11 c2                                        	adc    rdx,r8
   7ef9c:	4c 11 ce                                        	adc    rsi,r9
   7ef9f:	4c 11 d0                                        	adc    rax,r10
   7efa2:	48 89 8c 24 a0 07 00 00                         	mov    QWORD PTR [rsp+0x7a0],rcx
   7efaa:	48 89 94 24 a8 07 00 00                         	mov    QWORD PTR [rsp+0x7a8],rdx
   7efb2:	48 89 b4 24 b0 07 00 00                         	mov    QWORD PTR [rsp+0x7b0],rsi
   7efba:	48 89 84 24 b8 07 00 00                         	mov    QWORD PTR [rsp+0x7b8],rax
   7efc2:	c5 fd 6f 84 24 40 07 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x740]
   7efcb:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7efd0:	75 78                                           	jne    7f04a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x37fa>
   7efd2:	eb 62                                           	jmp    7f036 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x37e6>
   7efd4:	66 66 66 2e 0f 1f 84 00 00 00 00 00             	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   7efe0:	c5 fe 6f 84 1c c0 08 00 00                      	vmovdqu ymm0,YMMWORD PTR [rsp+rbx*1+0x8c0]
   7efe9:	c5 fe 6f 8c 1c 80 01 00 00                      	vmovdqu ymm1,YMMWORD PTR [rsp+rbx*1+0x180]
   7eff2:	48 8d 84 24 60 07 00 00                         	lea    rax,[rsp+0x760]
   7effa:	c5 fd 7f 84 24 40 07 00 00                      	vmovdqa YMMWORD PTR [rsp+0x740],ymm0
   7f003:	c5 fe 7f 08                                     	vmovdqu YMMWORD PTR [rax],ymm1
   7f007:	48 8d 84 5c 00 04 00 00                         	lea    rax,[rsp+rbx*2+0x400]
   7f00f:	45 84 f4                                        	test   r12b,r14b
   7f012:	0f 85 08 ff ff ff                               	jne    7ef20 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x36d0>
   7f018:	62 f1 7c 48 10 00                               	vmovups zmm0,ZMMWORD PTR [rax]
   7f01e:	62 f1 7c 48 29 44 24 1e                         	vmovaps ZMMWORD PTR [rsp+0x780],zmm0
   7f026:	c5 fd 6f 84 24 40 07 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x740]
   7f02f:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7f034:	75 14                                           	jne    7f04a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x37fa>
   7f036:	c5 fd 6f 84 24 60 07 00 00                      	vmovdqa ymm0,YMMWORD PTR [rsp+0x760]
   7f03f:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7f044:	0f 84 c9 00 00 00                               	je     7f113 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x38c3>
   7f04a:	48 8d 84 24 60 07 00 00                         	lea    rax,[rsp+0x760]
   7f052:	c5 fd 6f 94 24 40 07 00 00                      	vmovdqa ymm2,YMMWORD PTR [rsp+0x740]
   7f05b:	c5 fe 6f 0d fd 8e f8 ff                         	vmovdqu ymm1,YMMWORD PTR [rip+0xfffffffffff88efd]        # 7f60 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x920>
   7f063:	c5 fe 6f 00                                     	vmovdqu ymm0,YMMWORD PTR [rax]
   7f067:	48 8d 84 24 20 0a 00 00                         	lea    rax,[rsp+0xa20]
   7f06f:	c5 fe 7f 00                                     	vmovdqu YMMWORD PTR [rax],ymm0
   7f073:	c5 fd 7f 94 24 00 0a 00 00                      	vmovdqa YMMWORD PTR [rsp+0xa00],ymm2
   7f07c:	c5 fe 7f 48 20                                  	vmovdqu YMMWORD PTR [rax+0x20],ymm1
   7f081:	4c 8b ac 24 40 06 00 00                         	mov    r13,QWORD PTR [rsp+0x640]
   7f089:	4c 8d b4 24 e0 12 00 00                         	lea    r14,[rsp+0x12e0]
   7f091:	48 8d b4 24 00 0a 00 00                         	lea    rsi,[rsp+0xa00]
   7f099:	48 8d 94 24 80 07 00 00                         	lea    rdx,[rsp+0x780]
   7f0a1:	4c 89 f7                                        	mov    rdi,r14
   7f0a4:	c5 f8 77                                        	vzeroupper
   7f0a7:	e8 74 47 00 00                                  	call   83820 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE10add_affineCsHW5vo2gROj_10zopro_core>
   7f0ac:	48 8d bc 24 c0 09 00 00                         	lea    rdi,[rsp+0x9c0]
   7f0b4:	4c 89 f6                                        	mov    rsi,r14
   7f0b7:	e8 d4 99 00 00                                  	call   88a90 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G1ConfigE9to_affineCsHW5vo2gROj_10zopro_core>
   7f0bc:	c5 fc 10 84 24 c0 09 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+0x9c0]
   7f0c5:	48 8d 84 24 e0 09 00 00                         	lea    rax,[rsp+0x9e0]
   7f0cd:	c5 fc 11 84 1c c0 08 00 00                      	vmovups YMMWORD PTR [rsp+rbx*1+0x8c0],ymm0
   7f0d6:	c5 fc 10 00                                     	vmovups ymm0,YMMWORD PTR [rax]
   7f0da:	c5 fc 11 84 1c 80 01 00 00                      	vmovups YMMWORD PTR [rsp+rbx*1+0x180],ymm0
   7f0e3:	c5 fe 6f 84 24 c0 09 00 00                      	vmovdqu ymm0,YMMWORD PTR [rsp+0x9c0]
   7f0ec:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7f0f1:	0f 85 b9 fd ff ff                               	jne    7eeb0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3660>
   7f0f7:	c5 fe 6f 84 24 e0 09 00 00                      	vmovdqu ymm0,YMMWORD PTR [rsp+0x9e0]
   7f100:	44 89 e0                                        	mov    eax,r12d
   7f103:	c4 e2 7d 17 c0                                  	vptest ymm0,ymm0
   7f108:	0f 85 a2 fd ff ff                               	jne    7eeb0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3660>
   7f10e:	e9 9f fd ff ff                                  	jmp    7eeb2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3662>
   7f113:	62 f1 fe 48 6f 05 0b 3c f9 ff                   	vmovdqu64 zmm0,ZMMWORD PTR [rip+0xfffffffffff93c0b]        # 12d28 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x45a8>
   7f11d:	62 f1 fe 48 6f 0d e1 3b f9 ff                   	vmovdqu64 zmm1,ZMMWORD PTR [rip+0xfffffffffff93be1]        # 12d08 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x4588>
   7f127:	62 f1 fe 48 7f 84 24 20 0a 00 00                	vmovdqu64 ZMMWORD PTR [rsp+0xa20],zmm0
   7f132:	62 f1 fd 48 7f 4c 24 28                         	vmovdqa64 ZMMWORD PTR [rsp+0xa00],zmm1
   7f13a:	e9 42 ff ff ff                                  	jmp    7f081 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3831>
   7f13f:	90                                              	nop
   7f140:	48 8d bc 24 80 01 00 00                         	lea    rdi,[rsp+0x180]
   7f148:	48 8d b4 24 40 0c 00 00                         	lea    rsi,[rsp+0xc40]
   7f150:	c5 f8 77                                        	vzeroupper
   7f153:	e8 08 2b 00 00                                  	call   81c60 <_RNvMs3_NtCsHW5vo2gROj_10zopro_core4simdNtB5_7FqBatch15inverse_nonzero>
   7f158:	48 8b 84 24 f8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xf8]
   7f160:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   7f165:	48 8b 8c 24 60 01 00 00                         	mov    rcx,QWORD PTR [rsp+0x160]
   7f16d:	48 85 c0                                        	test   rax,rax
   7f170:	0f 84 6a e1 ff ff                               	je     7d2e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a90>
   7f176:	62 71 fd 48 6f 5c 24 06                         	vmovdqa64 zmm11,ZMMWORD PTR [rsp+0x180]
   7f17e:	62 71 fd 48 6f 54 24 07                         	vmovdqa64 zmm10,ZMMWORD PTR [rsp+0x1c0]
   7f186:	62 f1 fd 48 6f 74 24 08                         	vmovdqa64 zmm6,ZMMWORD PTR [rsp+0x200]
   7f18e:	62 f1 fd 48 6f 7c 24 09                         	vmovdqa64 zmm7,ZMMWORD PTR [rsp+0x240]
   7f196:	62 f1 fd 48 6f 44 24 0a                         	vmovdqa64 zmm0,ZMMWORD PTR [rsp+0x280]
   7f19e:	48 8b 8c 24 f0 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xf0]
   7f1a6:	48 8b 94 24 88 00 00 00                         	mov    rdx,QWORD PTR [rsp+0x88]
   7f1ae:	48 8b b4 24 90 00 00 00                         	mov    rsi,QWORD PTR [rsp+0x90]
   7f1b6:	48 c1 e0 0a                                     	shl    rax,0xa
   7f1ba:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   7f1c0:	8b 7c 01 c0                                     	mov    edi,DWORD PTR [rcx+rax*1-0x40]
   7f1c4:	48 39 fe                                        	cmp    rsi,rdi
   7f1c7:	0f 86 38 23 00 00                               	jbe    81505 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5cb5>
   7f1cd:	62 61 fd 28 6f 0d c9 8c f8 ff                   	vmovdqa64 ymm25,YMMWORD PTR [rip+0xfffffffffff88cc9]        # 7ea0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x860>
   7f1d7:	49 b8 31 e1 72 4e 64 30 00 00                   	movabs r8,0x30644e72e131
   7f1e1:	62 62 fd 48 59 05 0d 82 f8 ff                   	vpbroadcastq zmm24,QWORD PTR [rip+0xfffffffffff8820d]        # 73f8 <GCC_except_table740+0x1b0>
   7f1eb:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   7f1f0:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   7f1f6:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   7f1fc:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   7f202:	62 62 fd 48 59 35 b4 80 f8 ff                   	vpbroadcastq zmm30,QWORD PTR [rip+0xfffffffffff880b4]        # 72c0 <GCC_except_table740+0x78>
   7f20c:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   7f212:	62 62 fd 48 59 15 dc 80 f8 ff                   	vpbroadcastq zmm26,QWORD PTR [rip+0xfffffffffff880dc]        # 72f8 <GCC_except_table740+0xb0>
   7f21c:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7f222:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   7f226:	62 62 fd 48 59 1d 98 80 f8 ff                   	vpbroadcastq zmm27,QWORD PTR [rip+0xfffffffffff88098]        # 72c8 <GCC_except_table740+0x80>
   7f230:	62 62 fd 48 59 25 66 81 f8 ff                   	vpbroadcastq zmm28,QWORD PTR [rip+0xfffffffffff88166]        # 73a0 <GCC_except_table740+0x158>
   7f23a:	62 a1 4d 00 ef f6                               	vpxord xmm22,xmm22,xmm22
   7f240:	62 a1 45 00 ef ff                               	vpxord xmm23,xmm23,xmm23
   7f246:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   7f24c:	48 69 ff c0 02 00 00                            	imul   rdi,rdi,0x2c0
   7f253:	62 01 15 00 ef ed                               	vpxord xmm29,xmm29,xmm29
   7f259:	62 61 fe 28 7f 4c 24 20                         	vmovdqu64 YMMWORD PTR [rsp+0x400],ymm25
   7f261:	4c 89 84 24 20 04 00 00                         	mov    QWORD PTR [rsp+0x420],r8
   7f269:	62 71 fd 48 6f 6c 01 f5                         	vmovdqa64 zmm13,ZMMWORD PTR [rcx+rax*1-0x2c0]
   7f271:	62 71 fd 48 6f 64 01 f6                         	vmovdqa64 zmm12,ZMMWORD PTR [rcx+rax*1-0x280]
   7f279:	62 71 fd 48 6f 4c 01 f7                         	vmovdqa64 zmm9,ZMMWORD PTR [rcx+rax*1-0x240]
   7f281:	62 71 fd 48 6f 44 01 f8                         	vmovdqa64 zmm8,ZMMWORD PTR [rcx+rax*1-0x200]
   7f289:	62 71 fd 48 6f 74 01 f9                         	vmovdqa64 zmm14,ZMMWORD PTR [rcx+rax*1-0x1c0]
   7f291:	62 f2 fd 48 59 a4 24 08 04 00 00                	vpbroadcastq zmm4,QWORD PTR [rsp+0x408]
   7f29c:	62 f2 fd 48 59 9c 24 10 04 00 00                	vpbroadcastq zmm3,QWORD PTR [rsp+0x410]
   7f2a7:	62 f2 fd 48 59 94 24 18 04 00 00                	vpbroadcastq zmm2,QWORD PTR [rsp+0x418]
   7f2b2:	62 f2 fd 48 59 8c 24 20 04 00 00                	vpbroadcastq zmm1,QWORD PTR [rsp+0x420]
   7f2bd:	62 61 fe 28 7f 4c 24 20                         	vmovdqu64 YMMWORD PTR [rsp+0x400],ymm25
   7f2c5:	4c 89 84 24 20 04 00 00                         	mov    QWORD PTR [rsp+0x420],r8
   7f2cd:	62 62 fd 48 59 bc 24 18 04 00 00                	vpbroadcastq zmm31,QWORD PTR [rsp+0x418]
   7f2d8:	62 c2 9d 48 b5 cb                               	vpmadd52huq zmm17,zmm12,zmm11
   7f2de:	62 c2 b5 48 b5 d3                               	vpmadd52huq zmm18,zmm9,zmm11
   7f2e4:	62 c2 bd 48 b5 c3                               	vpmadd52huq zmm16,zmm8,zmm11
   7f2ea:	62 52 95 48 b4 fb                               	vpmadd52luq zmm15,zmm13,zmm11
   7f2f0:	62 c2 95 48 b5 db                               	vpmadd52huq zmm19,zmm13,zmm11
   7f2f6:	62 d2 8d 48 b5 eb                               	vpmadd52huq zmm5,zmm14,zmm11
   7f2fc:	62 82 85 48 b4 e0                               	vpmadd52luq zmm20,zmm15,zmm24
   7f302:	62 c2 b5 48 b4 cb                               	vpmadd52luq zmm17,zmm9,zmm11
   7f308:	62 c2 bd 48 b4 d3                               	vpmadd52luq zmm18,zmm8,zmm11
   7f30e:	62 c2 8d 48 b4 c3                               	vpmadd52luq zmm16,zmm14,zmm11
   7f314:	62 c2 9d 48 b4 db                               	vpmadd52luq zmm19,zmm12,zmm11
   7f31a:	62 11 85 48 d4 fe                               	vpaddq zmm15,zmm15,zmm30
   7f320:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   7f327:	62 e2 dd 40 b5 cc                               	vpmadd52huq zmm17,zmm20,zmm4
   7f32d:	62 e2 dd 40 b5 d3                               	vpmadd52huq zmm18,zmm20,zmm3
   7f333:	62 e2 dd 40 b5 c2                               	vpmadd52huq zmm16,zmm20,zmm2
   7f339:	62 12 dd 40 b5 fa                               	vpmadd52huq zmm15,zmm20,zmm26
   7f33f:	62 e2 dd 40 b4 dc                               	vpmadd52luq zmm19,zmm20,zmm4
   7f345:	62 f2 dd 40 b5 e9                               	vpmadd52huq zmm5,zmm20,zmm1
   7f34b:	62 e2 dd 40 b4 cb                               	vpmadd52luq zmm17,zmm20,zmm3
   7f351:	62 e2 dd 40 b4 d2                               	vpmadd52luq zmm18,zmm20,zmm2
   7f357:	62 e2 dd 40 b4 c1                               	vpmadd52luq zmm16,zmm20,zmm1
   7f35d:	62 c1 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm15
   7f363:	62 d2 bd 48 b5 ea                               	vpmadd52huq zmm5,zmm8,zmm10
   7f369:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7f36f:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   7f374:	62 52 8d 48 b5 fa                               	vpmadd52huq zmm15,zmm14,zmm10
   7f37a:	62 c2 95 48 b4 da                               	vpmadd52luq zmm19,zmm13,zmm10
   7f380:	62 c2 95 48 b5 ca                               	vpmadd52huq zmm17,zmm13,zmm10
   7f386:	62 c2 9d 48 b5 d2                               	vpmadd52huq zmm18,zmm12,zmm10
   7f38c:	62 c2 b5 48 b5 c2                               	vpmadd52huq zmm16,zmm9,zmm10
   7f392:	62 d2 8d 48 b4 ea                               	vpmadd52luq zmm5,zmm14,zmm10
   7f398:	62 82 e5 40 b4 e0                               	vpmadd52luq zmm20,zmm19,zmm24
   7f39e:	62 81 e5 40 d4 de                               	vpaddq zmm19,zmm19,zmm30
   7f3a4:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   7f3ab:	62 c2 9d 48 b4 ca                               	vpmadd52luq zmm17,zmm12,zmm10
   7f3b1:	62 c2 b5 48 b4 d2                               	vpmadd52luq zmm18,zmm9,zmm10
   7f3b7:	62 c2 bd 48 b4 c2                               	vpmadd52luq zmm16,zmm8,zmm10
   7f3bd:	62 82 dd 40 b5 da                               	vpmadd52huq zmm19,zmm20,zmm26
   7f3c3:	62 f2 dd 40 b5 ea                               	vpmadd52huq zmm5,zmm20,zmm2
   7f3c9:	62 72 dd 40 b5 f9                               	vpmadd52huq zmm15,zmm20,zmm1
   7f3cf:	62 e2 dd 40 b5 d4                               	vpmadd52huq zmm18,zmm20,zmm4
   7f3d5:	62 e2 dd 40 b5 c3                               	vpmadd52huq zmm16,zmm20,zmm3
   7f3db:	62 e2 dd 40 b4 cc                               	vpmadd52luq zmm17,zmm20,zmm4
   7f3e1:	62 f2 dd 40 b4 e9                               	vpmadd52luq zmm5,zmm20,zmm1
   7f3e7:	62 72 bd 48 b5 fe                               	vpmadd52huq zmm15,zmm8,zmm6
   7f3ed:	62 a1 f5 40 d4 db                               	vpaddq zmm19,zmm17,zmm19
   7f3f3:	62 e2 dd 40 b4 d3                               	vpmadd52luq zmm18,zmm20,zmm3
   7f3f9:	62 e2 dd 40 b4 c2                               	vpmadd52luq zmm16,zmm20,zmm2
   7f3ff:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7f405:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   7f40b:	62 e2 8d 48 b5 ce                               	vpmadd52huq zmm17,zmm14,zmm6
   7f411:	62 e2 95 48 b4 de                               	vpmadd52luq zmm19,zmm13,zmm6
   7f417:	62 f2 b5 48 b5 ee                               	vpmadd52huq zmm5,zmm9,zmm6
   7f41d:	62 72 8d 48 b4 fe                               	vpmadd52luq zmm15,zmm14,zmm6
   7f423:	62 e2 95 48 b5 d6                               	vpmadd52huq zmm18,zmm13,zmm6
   7f429:	62 e2 9d 48 b5 c6                               	vpmadd52huq zmm16,zmm12,zmm6
   7f42f:	62 82 e5 40 b4 e0                               	vpmadd52luq zmm20,zmm19,zmm24
   7f435:	62 f2 bd 48 b4 ee                               	vpmadd52luq zmm5,zmm8,zmm6
   7f43b:	62 81 e5 40 d4 de                               	vpaddq zmm19,zmm19,zmm30
   7f441:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   7f448:	62 e2 9d 48 b4 d6                               	vpmadd52luq zmm18,zmm12,zmm6
   7f44e:	62 e2 b5 48 b4 c6                               	vpmadd52luq zmm16,zmm9,zmm6
   7f454:	62 72 dd 40 b5 fa                               	vpmadd52huq zmm15,zmm20,zmm2
   7f45a:	62 82 dd 40 b5 da                               	vpmadd52huq zmm19,zmm20,zmm26
   7f460:	62 f2 dd 40 b5 eb                               	vpmadd52huq zmm5,zmm20,zmm3
   7f466:	62 e2 dd 40 b5 c9                               	vpmadd52huq zmm17,zmm20,zmm1
   7f46c:	62 e2 dd 40 b5 c4                               	vpmadd52huq zmm16,zmm20,zmm4
   7f472:	62 e2 dd 40 b4 d4                               	vpmadd52luq zmm18,zmm20,zmm4
   7f478:	62 72 dd 40 b4 f9                               	vpmadd52luq zmm15,zmm20,zmm1
   7f47e:	62 f2 dd 40 b4 ea                               	vpmadd52luq zmm5,zmm20,zmm2
   7f484:	62 e2 bd 48 b5 cf                               	vpmadd52huq zmm17,zmm8,zmm7
   7f48a:	62 a1 ed 40 d4 db                               	vpaddq zmm19,zmm18,zmm19
   7f490:	62 e2 dd 40 b4 c3                               	vpmadd52luq zmm16,zmm20,zmm3
   7f496:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7f49c:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   7f4a2:	62 e2 8d 48 b5 d7                               	vpmadd52huq zmm18,zmm14,zmm7
   7f4a8:	62 72 b5 48 b5 ff                               	vpmadd52huq zmm15,zmm9,zmm7
   7f4ae:	62 e2 95 48 b4 df                               	vpmadd52luq zmm19,zmm13,zmm7
   7f4b4:	62 f2 9d 48 b5 ef                               	vpmadd52huq zmm5,zmm12,zmm7
   7f4ba:	62 e2 8d 48 b4 cf                               	vpmadd52luq zmm17,zmm14,zmm7
   7f4c0:	62 e2 95 48 b5 c7                               	vpmadd52huq zmm16,zmm13,zmm7
   7f4c6:	62 82 e5 40 b4 e0                               	vpmadd52luq zmm20,zmm19,zmm24
   7f4cc:	62 72 bd 48 b4 ff                               	vpmadd52luq zmm15,zmm8,zmm7
   7f4d2:	62 f2 b5 48 b4 ef                               	vpmadd52luq zmm5,zmm9,zmm7
   7f4d8:	62 81 e5 40 d4 de                               	vpaddq zmm19,zmm19,zmm30
   7f4de:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   7f4e5:	62 e2 9d 48 b4 c7                               	vpmadd52luq zmm16,zmm12,zmm7
   7f4eb:	62 72 dd 40 b5 fb                               	vpmadd52huq zmm15,zmm20,zmm3
   7f4f1:	62 82 dd 40 b5 da                               	vpmadd52huq zmm19,zmm20,zmm26
   7f4f7:	62 f2 dd 40 b5 ec                               	vpmadd52huq zmm5,zmm20,zmm4
   7f4fd:	62 e2 dd 40 b5 ca                               	vpmadd52huq zmm17,zmm20,zmm2
   7f503:	62 e2 dd 40 b5 d1                               	vpmadd52huq zmm18,zmm20,zmm1
   7f509:	62 e2 dd 40 b4 c4                               	vpmadd52luq zmm16,zmm20,zmm4
   7f50f:	62 72 dd 40 b4 fa                               	vpmadd52luq zmm15,zmm20,zmm2
   7f515:	62 f2 dd 40 b4 eb                               	vpmadd52luq zmm5,zmm20,zmm3
   7f51b:	62 e2 dd 40 b4 c9                               	vpmadd52luq zmm17,zmm20,zmm1
   7f521:	62 e2 bd 48 b5 d0                               	vpmadd52huq zmm18,zmm8,zmm0
   7f527:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7f52d:	62 a1 fd 40 d4 c3                               	vpaddq zmm16,zmm16,zmm19
   7f533:	62 e1 fd 48 6f 5c 01 f2                         	vmovdqa64 zmm19,ZMMWORD PTR [rcx+rax*1-0x380]
   7f53b:	62 72 9d 48 b5 f8                               	vpmadd52huq zmm15,zmm12,zmm0
   7f541:	62 e2 95 48 b4 c0                               	vpmadd52luq zmm16,zmm13,zmm0
   7f547:	62 f2 95 48 b5 e8                               	vpmadd52huq zmm5,zmm13,zmm0
   7f54d:	62 e2 b5 48 b5 c8                               	vpmadd52huq zmm17,zmm9,zmm0
   7f553:	62 e2 8d 48 b4 d0                               	vpmadd52luq zmm18,zmm14,zmm0
   7f559:	62 72 b5 48 b4 f8                               	vpmadd52luq zmm15,zmm9,zmm0
   7f55f:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   7f564:	62 12 fd 40 b4 c8                               	vpmadd52luq zmm9,zmm16,zmm24
   7f56a:	62 f2 9d 48 b4 e8                               	vpmadd52luq zmm5,zmm12,zmm0
   7f570:	62 e2 bd 48 b4 c8                               	vpmadd52luq zmm17,zmm8,zmm0
   7f576:	62 11 fd 40 d4 eb                               	vpaddq zmm13,zmm16,zmm27
   7f57c:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   7f581:	62 72 8d 48 b5 c0                               	vpmadd52huq zmm8,zmm14,zmm0
   7f587:	c4 41 09 ef f6                                  	vpxor  xmm14,xmm14,xmm14
   7f58c:	62 e1 fd 48 6f 44 01 f3                         	vmovdqa64 zmm16,ZMMWORD PTR [rcx+rax*1-0x340]
   7f594:	62 d1 95 48 73 d5 30                            	vpsrlq zmm13,zmm13,0x30
   7f59b:	62 11 b5 48 db e3                               	vpandq zmm12,zmm9,zmm27
   7f5a1:	62 d1 b5 48 73 f1 04                            	vpsllq zmm9,zmm9,0x4
   7f5a8:	62 72 9d 48 b5 fc                               	vpmadd52huq zmm15,zmm12,zmm4
   7f5ae:	62 e2 9d 48 b5 d2                               	vpmadd52huq zmm18,zmm12,zmm2
   7f5b4:	62 e2 9d 48 b5 cb                               	vpmadd52huq zmm17,zmm12,zmm3
   7f5ba:	62 f2 9d 48 b4 ec                               	vpmadd52luq zmm5,zmm12,zmm4
   7f5c0:	62 12 b5 48 b5 ea                               	vpmadd52huq zmm13,zmm9,zmm26
   7f5c6:	62 72 9d 48 b5 c1                               	vpmadd52huq zmm8,zmm12,zmm1
   7f5cc:	62 72 9d 48 b4 fb                               	vpmadd52luq zmm15,zmm12,zmm3
   7f5d2:	62 e2 9d 48 b4 d1                               	vpmadd52luq zmm18,zmm12,zmm1
   7f5d8:	62 e2 9d 48 b4 ca                               	vpmadd52luq zmm17,zmm12,zmm2
   7f5de:	62 f1 f5 48 73 f5 04                            	vpsllq zmm1,zmm5,0x4
   7f5e5:	62 f1 ed 48 73 d5 30                            	vpsrlq zmm2,zmm5,0x30
   7f5ec:	62 d1 bd 48 73 f0 04                            	vpsllq zmm8,zmm8,0x4
   7f5f3:	62 91 f5 48 db cc                               	vpandq zmm1,zmm1,zmm28
   7f5f9:	62 d1 f5 48 d4 cd                               	vpaddq zmm1,zmm1,zmm13
   7f5ff:	62 d1 e5 48 73 f7 04                            	vpsllq zmm3,zmm15,0x4
   7f606:	62 d1 dd 48 73 d7 30                            	vpsrlq zmm4,zmm15,0x30
   7f60d:	62 71 fd 48 6f 7c 01 f0                         	vmovdqa64 zmm15,ZMMWORD PTR [rcx+rax*1-0x400]
   7f615:	62 b1 b5 48 73 f2 04                            	vpsllq zmm9,zmm18,0x4
   7f61c:	62 b1 9d 48 73 d1 30                            	vpsrlq zmm12,zmm17,0x30
   7f623:	62 b1 d5 48 73 f1 04                            	vpsllq zmm5,zmm17,0x4
   7f62a:	62 b1 95 48 73 d2 30                            	vpsrlq zmm13,zmm18,0x30
   7f631:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   7f637:	62 e1 fd 48 6f 54 01 f1                         	vmovdqa64 zmm18,ZMMWORD PTR [rcx+rax*1-0x3c0]
   7f63f:	62 11 b5 48 db cc                               	vpandq zmm9,zmm9,zmm28
   7f645:	62 91 e5 48 db dc                               	vpandq zmm3,zmm3,zmm28
   7f64b:	62 91 d5 48 db ec                               	vpandq zmm5,zmm5,zmm28
   7f651:	62 51 bd 48 d4 c5                               	vpaddq zmm8,zmm8,zmm13
   7f657:	62 72 fd 48 59 ac 24 08 04 00 00                	vpbroadcastq zmm13,QWORD PTR [rsp+0x408]
   7f662:	62 51 b5 48 d4 cc                               	vpaddq zmm9,zmm9,zmm12
   7f668:	62 f1 9d 48 73 d1 34                            	vpsrlq zmm12,zmm1,0x34
   7f66f:	62 f1 d5 48 d4 e4                               	vpaddq zmm4,zmm5,zmm4
   7f675:	62 91 f5 48 db ee                               	vpandq zmm5,zmm1,zmm30
   7f67b:	62 f1 9d 48 d4 d2                               	vpaddq zmm2,zmm12,zmm2
   7f681:	62 72 fd 48 59 a4 24 10 04 00 00                	vpbroadcastq zmm12,QWORD PTR [rsp+0x410]
   7f68c:	62 f1 ed 48 d4 d3                               	vpaddq zmm2,zmm2,zmm3
   7f692:	62 f1 f5 48 73 d2 34                            	vpsrlq zmm1,zmm2,0x34
   7f699:	62 f1 f5 48 d4 cc                               	vpaddq zmm1,zmm1,zmm4
   7f69f:	62 91 ed 48 db e6                               	vpandq zmm4,zmm2,zmm30
   7f6a5:	62 f1 ed 48 73 d1 34                            	vpsrlq zmm2,zmm1,0x34
   7f6ac:	62 91 f5 48 db de                               	vpandq zmm3,zmm1,zmm30
   7f6b2:	62 c2 a5 48 b5 ff                               	vpmadd52huq zmm23,zmm11,zmm15
   7f6b8:	62 c2 ad 48 b5 ef                               	vpmadd52huq zmm21,zmm10,zmm15
   7f6be:	62 c2 cd 48 b5 e7                               	vpmadd52huq zmm20,zmm6,zmm15
   7f6c4:	62 c2 c5 48 b5 cf                               	vpmadd52huq zmm17,zmm7,zmm15
   7f6ca:	62 c2 a5 48 b4 f7                               	vpmadd52luq zmm22,zmm11,zmm15
   7f6d0:	62 d1 ed 48 d4 d1                               	vpaddq zmm2,zmm2,zmm9
   7f6d6:	62 52 fd 48 b5 f7                               	vpmadd52huq zmm14,zmm0,zmm15
   7f6dc:	62 f1 f5 48 73 d2 34                            	vpsrlq zmm1,zmm2,0x34
   7f6e3:	62 91 ed 48 db d6                               	vpandq zmm2,zmm2,zmm30
   7f6e9:	62 d1 f5 48 d4 c8                               	vpaddq zmm1,zmm1,zmm8
   7f6ef:	62 72 fd 48 59 84 24 20 04 00 00                	vpbroadcastq zmm8,QWORD PTR [rsp+0x420]
   7f6fa:	62 c2 ad 48 b4 ff                               	vpmadd52luq zmm23,zmm10,zmm15
   7f700:	62 c2 cd 48 b4 ef                               	vpmadd52luq zmm21,zmm6,zmm15
   7f706:	62 c2 c5 48 b4 e7                               	vpmadd52luq zmm20,zmm7,zmm15
   7f70c:	62 c2 fd 48 b4 cf                               	vpmadd52luq zmm17,zmm0,zmm15
   7f712:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   7f717:	62 12 cd 40 b4 f8                               	vpmadd52luq zmm15,zmm22,zmm24
   7f71d:	62 81 cd 40 d4 f6                               	vpaddq zmm22,zmm22,zmm30
   7f723:	62 b1 cd 40 73 d6 34                            	vpsrlq zmm22,zmm22,0x34
   7f72a:	62 c2 85 48 b5 ed                               	vpmadd52huq zmm21,zmm15,zmm13
   7f730:	62 c2 85 48 b5 e4                               	vpmadd52huq zmm20,zmm15,zmm12
   7f736:	62 82 85 48 b5 cf                               	vpmadd52huq zmm17,zmm15,zmm31
   7f73c:	62 82 85 48 b5 f2                               	vpmadd52huq zmm22,zmm15,zmm26
   7f742:	62 c2 85 48 b4 fd                               	vpmadd52luq zmm23,zmm15,zmm13
   7f748:	62 52 85 48 b5 f0                               	vpmadd52huq zmm14,zmm15,zmm8
   7f74e:	62 c2 85 48 b4 ec                               	vpmadd52luq zmm21,zmm15,zmm12
   7f754:	62 82 85 48 b4 e7                               	vpmadd52luq zmm20,zmm15,zmm31
   7f75a:	62 c2 85 48 b4 c8                               	vpmadd52luq zmm17,zmm15,zmm8
   7f760:	62 a1 c5 40 d4 f6                               	vpaddq zmm22,zmm23,zmm22
   7f766:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   7f76b:	62 32 fd 48 b5 fa                               	vpmadd52huq zmm15,zmm0,zmm18
   7f771:	62 a2 a5 48 b4 f2                               	vpmadd52luq zmm22,zmm11,zmm18
   7f777:	62 32 c5 48 b5 f2                               	vpmadd52huq zmm14,zmm7,zmm18
   7f77d:	62 a2 a5 48 b5 ea                               	vpmadd52huq zmm21,zmm11,zmm18
   7f783:	62 a2 ad 48 b5 e2                               	vpmadd52huq zmm20,zmm10,zmm18
   7f789:	62 a2 cd 48 b5 ca                               	vpmadd52huq zmm17,zmm6,zmm18
   7f78f:	62 32 fd 48 b4 f2                               	vpmadd52luq zmm14,zmm0,zmm18
   7f795:	62 a2 ad 48 b4 ea                               	vpmadd52luq zmm21,zmm10,zmm18
   7f79b:	62 a2 cd 48 b4 e2                               	vpmadd52luq zmm20,zmm6,zmm18
   7f7a1:	62 a2 c5 48 b4 ca                               	vpmadd52luq zmm17,zmm7,zmm18
   7f7a7:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   7f7ad:	62 82 cd 40 b4 d0                               	vpmadd52luq zmm18,zmm22,zmm24
   7f7b3:	62 81 cd 40 d4 f6                               	vpaddq zmm22,zmm22,zmm30
   7f7b9:	62 b1 cd 40 73 d6 34                            	vpsrlq zmm22,zmm22,0x34
   7f7c0:	62 c2 ed 40 b5 e5                               	vpmadd52huq zmm20,zmm18,zmm13
   7f7c6:	62 c2 ed 40 b5 cc                               	vpmadd52huq zmm17,zmm18,zmm12
   7f7cc:	62 12 ed 40 b5 f7                               	vpmadd52huq zmm14,zmm18,zmm31
   7f7d2:	62 82 ed 40 b5 f2                               	vpmadd52huq zmm22,zmm18,zmm26
   7f7d8:	62 c2 ed 40 b4 ed                               	vpmadd52luq zmm21,zmm18,zmm13
   7f7de:	62 52 ed 40 b5 f8                               	vpmadd52huq zmm15,zmm18,zmm8
   7f7e4:	62 c2 ed 40 b4 e4                               	vpmadd52luq zmm20,zmm18,zmm12
   7f7ea:	62 82 ed 40 b4 cf                               	vpmadd52luq zmm17,zmm18,zmm31
   7f7f0:	62 52 ed 40 b4 f0                               	vpmadd52luq zmm14,zmm18,zmm8
   7f7f6:	62 a1 d5 40 d4 ee                               	vpaddq zmm21,zmm21,zmm22
   7f7fc:	62 32 c5 48 b5 fb                               	vpmadd52huq zmm15,zmm7,zmm19
   7f802:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   7f808:	62 a2 fd 48 b5 d3                               	vpmadd52huq zmm18,zmm0,zmm19
   7f80e:	62 a1 4d 00 ef f6                               	vpxord xmm22,xmm22,xmm22
   7f814:	62 a2 a5 48 b4 eb                               	vpmadd52luq zmm21,zmm11,zmm19
   7f81a:	62 a2 a5 48 b5 e3                               	vpmadd52huq zmm20,zmm11,zmm19
   7f820:	62 a2 ad 48 b5 cb                               	vpmadd52huq zmm17,zmm10,zmm19
   7f826:	62 32 cd 48 b5 f3                               	vpmadd52huq zmm14,zmm6,zmm19
   7f82c:	62 32 fd 48 b4 fb                               	vpmadd52luq zmm15,zmm0,zmm19
   7f832:	62 a2 ad 48 b4 e3                               	vpmadd52luq zmm20,zmm10,zmm19
   7f838:	62 a2 cd 48 b4 cb                               	vpmadd52luq zmm17,zmm6,zmm19
   7f83e:	62 32 c5 48 b4 f3                               	vpmadd52luq zmm14,zmm7,zmm19
   7f844:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   7f84a:	62 82 d5 40 b4 d8                               	vpmadd52luq zmm19,zmm21,zmm24
   7f850:	62 81 d5 40 d4 ee                               	vpaddq zmm21,zmm21,zmm30
   7f856:	62 b1 d5 40 73 d5 34                            	vpsrlq zmm21,zmm21,0x34
   7f85d:	62 c2 e5 40 b5 cd                               	vpmadd52huq zmm17,zmm19,zmm13
   7f863:	62 52 e5 40 b5 f4                               	vpmadd52huq zmm14,zmm19,zmm12
   7f869:	62 12 e5 40 b5 ff                               	vpmadd52huq zmm15,zmm19,zmm31
   7f86f:	62 82 e5 40 b5 ea                               	vpmadd52huq zmm21,zmm19,zmm26
   7f875:	62 c2 e5 40 b4 e5                               	vpmadd52luq zmm20,zmm19,zmm13
   7f87b:	62 c2 e5 40 b5 d0                               	vpmadd52huq zmm18,zmm19,zmm8
   7f881:	62 c2 e5 40 b4 cc                               	vpmadd52luq zmm17,zmm19,zmm12
   7f887:	62 12 e5 40 b4 f7                               	vpmadd52luq zmm14,zmm19,zmm31
   7f88d:	62 52 e5 40 b4 f8                               	vpmadd52luq zmm15,zmm19,zmm8
   7f893:	62 a1 dd 40 d4 e5                               	vpaddq zmm20,zmm20,zmm21
   7f899:	62 a2 c5 48 b5 d0                               	vpmadd52huq zmm18,zmm7,zmm16
   7f89f:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   7f8a5:	62 a2 fd 48 b5 d8                               	vpmadd52huq zmm19,zmm0,zmm16
   7f8ab:	62 a2 a5 48 b4 e0                               	vpmadd52luq zmm20,zmm11,zmm16
   7f8b1:	62 a2 a5 48 b5 c8                               	vpmadd52huq zmm17,zmm11,zmm16
   7f8b7:	62 32 ad 48 b5 f0                               	vpmadd52huq zmm14,zmm10,zmm16
   7f8bd:	62 32 cd 48 b5 f8                               	vpmadd52huq zmm15,zmm6,zmm16
   7f8c3:	62 a2 fd 48 b4 d0                               	vpmadd52luq zmm18,zmm0,zmm16
   7f8c9:	62 a2 ad 48 b4 c8                               	vpmadd52luq zmm17,zmm10,zmm16
   7f8cf:	62 32 cd 48 b4 f0                               	vpmadd52luq zmm14,zmm6,zmm16
   7f8d5:	62 32 c5 48 b4 f8                               	vpmadd52luq zmm15,zmm7,zmm16
   7f8db:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   7f8e1:	62 82 dd 40 b4 c0                               	vpmadd52luq zmm16,zmm20,zmm24
   7f8e7:	62 81 dd 40 d4 e6                               	vpaddq zmm20,zmm20,zmm30
   7f8ed:	62 b1 dd 40 73 d4 34                            	vpsrlq zmm20,zmm20,0x34
   7f8f4:	62 52 fd 40 b5 f5                               	vpmadd52huq zmm14,zmm16,zmm13
   7f8fa:	62 52 fd 40 b5 fc                               	vpmadd52huq zmm15,zmm16,zmm12
   7f900:	62 82 fd 40 b5 d7                               	vpmadd52huq zmm18,zmm16,zmm31
   7f906:	62 82 fd 40 b5 e2                               	vpmadd52huq zmm20,zmm16,zmm26
   7f90c:	62 c2 fd 40 b4 cd                               	vpmadd52luq zmm17,zmm16,zmm13
   7f912:	62 c2 fd 40 b5 d8                               	vpmadd52huq zmm19,zmm16,zmm8
   7f918:	62 52 fd 40 b4 f4                               	vpmadd52luq zmm14,zmm16,zmm12
   7f91e:	62 12 fd 40 b4 ff                               	vpmadd52luq zmm15,zmm16,zmm31
   7f924:	62 c2 fd 40 b4 d0                               	vpmadd52luq zmm18,zmm16,zmm8
   7f92a:	62 e1 fd 48 6f 44 01 f4                         	vmovdqa64 zmm16,ZMMWORD PTR [rcx+rax*1-0x300]
   7f932:	62 a1 f5 40 d4 cc                               	vpaddq zmm17,zmm17,zmm20
   7f938:	62 61 fe 28 7f 4c 24 20                         	vmovdqu64 YMMWORD PTR [rsp+0x400],ymm25
   7f940:	4c 89 84 24 20 04 00 00                         	mov    QWORD PTR [rsp+0x420],r8
   7f948:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7f94e:	62 a2 cd 48 b5 d0                               	vpmadd52huq zmm18,zmm6,zmm16
   7f954:	62 a2 c5 48 b5 d8                               	vpmadd52huq zmm19,zmm7,zmm16
   7f95a:	62 a2 a5 48 b4 c8                               	vpmadd52luq zmm17,zmm11,zmm16
   7f960:	62 32 ad 48 b5 f8                               	vpmadd52huq zmm15,zmm10,zmm16
   7f966:	62 32 a5 48 b5 f0                               	vpmadd52huq zmm14,zmm11,zmm16
   7f96c:	62 a2 c5 48 b4 d0                               	vpmadd52luq zmm18,zmm7,zmm16
   7f972:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   7f976:	62 a2 fd 48 b4 d8                               	vpmadd52luq zmm19,zmm0,zmm16
   7f97c:	62 b2 fd 48 b5 f8                               	vpmadd52huq zmm7,zmm0,zmm16
   7f982:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   7f986:	62 92 f5 40 b4 c0                               	vpmadd52luq zmm0,zmm17,zmm24
   7f98c:	62 32 cd 48 b4 f8                               	vpmadd52luq zmm15,zmm6,zmm16
   7f992:	62 32 ad 48 b4 f0                               	vpmadd52luq zmm14,zmm10,zmm16
   7f998:	62 11 f5 40 d4 d3                               	vpaddq zmm10,zmm17,zmm27
   7f99e:	62 a1 7d 00 ef c0                               	vpxord xmm16,xmm16,xmm16
   7f9a4:	62 e2 ed 48 b5 c5                               	vpmadd52huq zmm16,zmm2,zmm5
   7f9aa:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   7f9b0:	62 e2 dd 48 b5 cd                               	vpmadd52huq zmm17,zmm4,zmm5
   7f9b6:	62 d1 ad 48 73 d2 30                            	vpsrlq zmm10,zmm10,0x30
   7f9bd:	62 91 fd 48 db f3                               	vpandq zmm6,zmm0,zmm27
   7f9c3:	62 f1 fd 48 73 f0 04                            	vpsllq zmm0,zmm0,0x4
   7f9ca:	62 e2 f5 48 b4 c5                               	vpmadd52luq zmm16,zmm1,zmm5
   7f9d0:	62 e2 e5 48 b4 cd                               	vpmadd52luq zmm17,zmm3,zmm5
   7f9d6:	62 c2 cd 48 b5 d4                               	vpmadd52huq zmm18,zmm6,zmm12
   7f9dc:	62 82 cd 48 b5 df                               	vpmadd52huq zmm19,zmm6,zmm31
   7f9e2:	62 52 cd 48 b5 fd                               	vpmadd52huq zmm15,zmm6,zmm13
   7f9e8:	62 52 cd 48 b4 f5                               	vpmadd52luq zmm14,zmm6,zmm13
   7f9ee:	62 12 fd 48 b5 d2                               	vpmadd52huq zmm10,zmm0,zmm26
   7f9f4:	62 d2 cd 48 b5 f8                               	vpmadd52huq zmm7,zmm6,zmm8
   7f9fa:	62 72 fd 48 59 ac 24 08 04 00 00                	vpbroadcastq zmm13,QWORD PTR [rsp+0x408]
   7fa05:	62 82 cd 48 b4 d7                               	vpmadd52luq zmm18,zmm6,zmm31
   7fa0b:	62 c2 cd 48 b4 d8                               	vpmadd52luq zmm19,zmm6,zmm8
   7fa11:	62 52 cd 48 b4 fc                               	vpmadd52luq zmm15,zmm6,zmm12
   7fa17:	62 d1 fd 48 73 f6 04                            	vpsllq zmm0,zmm14,0x4
   7fa1e:	62 f1 c5 48 73 f7 04                            	vpsllq zmm7,zmm7,0x4
   7fa25:	62 62 fd 48 59 3d 01 79 f8 ff                   	vpbroadcastq zmm31,QWORD PTR [rip+0xfffffffffff87901]        # 7330 <GCC_except_table740+0xe8>
   7fa2f:	62 91 fd 48 db c4                               	vpandq zmm0,zmm0,zmm28
   7fa35:	62 d1 fd 48 d4 f2                               	vpaddq zmm6,zmm0,zmm10
   7fa3b:	62 d1 fd 48 73 d6 30                            	vpsrlq zmm0,zmm14,0x30
   7fa42:	c4 41 09 ef f6                                  	vpxor  xmm14,xmm14,xmm14
   7fa47:	62 72 f5 48 b5 f5                               	vpmadd52huq zmm14,zmm1,zmm5
   7fa4d:	62 f1 fd 48 7f 74 24 0f                         	vmovdqa64 ZMMWORD PTR [rsp+0x3c0],zmm6
   7fa55:	62 b1 ad 48 73 f2 04                            	vpsllq zmm10,zmm18,0x4
   7fa5c:	62 b1 a5 48 73 f3 04                            	vpsllq zmm11,zmm19,0x4
   7fa63:	62 b1 9d 48 73 d2 30                            	vpsrlq zmm12,zmm18,0x30
   7fa6a:	62 d1 b5 48 73 d7 30                            	vpsrlq zmm9,zmm15,0x30
   7fa71:	62 d1 bd 48 73 f7 04                            	vpsllq zmm8,zmm15,0x4
   7fa78:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   7fa7d:	62 72 d5 48 b4 fd                               	vpmadd52luq zmm15,zmm5,zmm5
   7fa83:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   7fa89:	62 e2 e5 48 b5 d5                               	vpmadd52huq zmm18,zmm3,zmm5
   7fa8f:	62 11 ad 48 db d4                               	vpandq zmm10,zmm10,zmm28
   7fa95:	62 11 a5 48 db dc                               	vpandq zmm11,zmm11,zmm28
   7fa9b:	62 11 bd 48 db c4                               	vpandq zmm8,zmm8,zmm28
   7faa1:	62 51 ad 48 d4 c9                               	vpaddq zmm9,zmm10,zmm9
   7faa7:	62 51 a5 48 d4 d4                               	vpaddq zmm10,zmm11,zmm12
   7faad:	62 b1 9d 48 73 d3 30                            	vpsrlq zmm12,zmm19,0x30
   7fab4:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   7faba:	62 e2 d5 48 b5 dd                               	vpmadd52huq zmm19,zmm5,zmm5
   7fac0:	62 51 c5 48 d4 dc                               	vpaddq zmm11,zmm7,zmm12
   7fac6:	62 f1 9d 48 73 d6 34                            	vpsrlq zmm12,zmm6,0x34
   7facd:	62 f2 fd 48 59 bc 24 18 04 00 00                	vpbroadcastq zmm7,QWORD PTR [rsp+0x418]
   7fad8:	c5 fc 28 35 00 85 f8 ff                         	vmovaps ymm6,YMMWORD PTR [rip+0xfffffffffff88500]        # 7fe0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x9a0>
   7fae0:	62 f1 9d 48 d4 c0                               	vpaddq zmm0,zmm12,zmm0
   7fae6:	62 72 fd 48 59 a4 24 10 04 00 00                	vpbroadcastq zmm12,QWORD PTR [rsp+0x410]
   7faf1:	62 82 85 48 b4 e0                               	vpmadd52luq zmm20,zmm15,zmm24
   7faf7:	62 e2 ed 48 b4 d5                               	vpmadd52luq zmm18,zmm2,zmm5
   7fafd:	62 11 85 48 d4 fe                               	vpaddq zmm15,zmm15,zmm30
   7fb03:	62 d1 fd 48 d4 c0                               	vpaddq zmm0,zmm0,zmm8
   7fb09:	62 d1 85 48 73 d7 34                            	vpsrlq zmm15,zmm15,0x34
   7fb10:	62 11 fd 48 6f c0                               	vmovdqa64 zmm8,zmm24
   7fb16:	62 f1 fd 48 7f 44 24 19                         	vmovdqa64 ZMMWORD PTR [rsp+0x640],zmm0
   7fb1e:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   7fb25:	62 e2 dd 48 b4 dd                               	vpmadd52luq zmm19,zmm4,zmm5
   7fb2b:	62 d1 fd 48 d4 c1                               	vpaddq zmm0,zmm0,zmm9
   7fb31:	62 11 fd 48 6f ca                               	vmovdqa64 zmm9,zmm26
   7fb37:	62 f1 fd 48 7f 44 24 1a                         	vmovdqa64 ZMMWORD PTR [rsp+0x680],zmm0
   7fb3f:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   7fb46:	62 c2 dd 40 b5 cd                               	vpmadd52huq zmm17,zmm20,zmm13
   7fb4c:	62 12 dd 40 b5 fa                               	vpmadd52huq zmm15,zmm20,zmm26
   7fb52:	62 d1 fd 48 d4 c2                               	vpaddq zmm0,zmm0,zmm10
   7fb58:	62 72 fd 48 59 94 24 20 04 00 00                	vpbroadcastq zmm10,QWORD PTR [rsp+0x420]
   7fb63:	62 c2 dd 40 b4 dd                               	vpmadd52luq zmm19,zmm20,zmm13
   7fb69:	62 f1 fd 48 7f 44 24 04                         	vmovdqa64 ZMMWORD PTR [rsp+0x100],zmm0
   7fb71:	62 f1 fd 48 73 d0 34                            	vpsrlq zmm0,zmm0,0x34
   7fb78:	62 e2 dd 40 b5 c7                               	vpmadd52huq zmm16,zmm20,zmm7
   7fb7e:	62 d1 fd 48 d4 c3                               	vpaddq zmm0,zmm0,zmm11
   7fb84:	c5 fc 11 b4 24 00 04 00 00                      	vmovups YMMWORD PTR [rsp+0x400],ymm6
   7fb8d:	4c 89 bc 24 20 04 00 00                         	mov    QWORD PTR [rsp+0x420],r15
   7fb95:	62 c2 dd 40 b5 d4                               	vpmadd52huq zmm18,zmm20,zmm12
   7fb9b:	62 c2 dd 40 b4 cc                               	vpmadd52luq zmm17,zmm20,zmm12
   7fba1:	62 c1 e5 40 d4 df                               	vpaddq zmm19,zmm19,zmm15
   7fba7:	c4 41 01 ef ff                                  	vpxor  xmm15,xmm15,xmm15
   7fbac:	62 72 f5 48 b5 fc                               	vpmadd52huq zmm15,zmm1,zmm4
   7fbb2:	62 e2 d5 48 b4 dc                               	vpmadd52luq zmm19,zmm5,zmm4
   7fbb8:	62 e2 dd 40 b4 d7                               	vpmadd52luq zmm18,zmm20,zmm7
   7fbbe:	62 e2 d5 48 b5 cc                               	vpmadd52huq zmm17,zmm5,zmm4
   7fbc4:	62 c2 dd 40 b4 c2                               	vpmadd52luq zmm16,zmm20,zmm10
   7fbca:	62 52 dd 40 b5 f2                               	vpmadd52huq zmm14,zmm20,zmm10
   7fbd0:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7fbd6:	62 82 e5 40 b4 e0                               	vpmadd52luq zmm20,zmm19,zmm24
   7fbdc:	62 81 e5 40 d4 de                               	vpaddq zmm19,zmm19,zmm30
   7fbe2:	62 e2 dd 48 b5 d4                               	vpmadd52huq zmm18,zmm4,zmm4
   7fbe8:	62 e2 dd 48 b4 cc                               	vpmadd52luq zmm17,zmm4,zmm4
   7fbee:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   7fbf5:	62 e2 e5 48 b5 c4                               	vpmadd52huq zmm16,zmm3,zmm4
   7fbfb:	62 72 ed 48 b5 f4                               	vpmadd52huq zmm14,zmm2,zmm4
   7fc01:	62 82 dd 40 b5 da                               	vpmadd52huq zmm19,zmm20,zmm26
   7fc07:	62 52 dd 40 b5 fa                               	vpmadd52huq zmm15,zmm20,zmm10
   7fc0d:	62 e2 e5 48 b4 d4                               	vpmadd52luq zmm18,zmm3,zmm4
   7fc13:	62 c2 dd 40 b4 cd                               	vpmadd52luq zmm17,zmm20,zmm13
   7fc19:	62 e2 ed 48 b4 c4                               	vpmadd52luq zmm16,zmm2,zmm4
   7fc1f:	62 72 f5 48 b4 f4                               	vpmadd52luq zmm14,zmm1,zmm4
   7fc25:	62 72 ed 48 b5 fb                               	vpmadd52huq zmm15,zmm2,zmm3
   7fc2b:	62 c2 dd 40 b5 d5                               	vpmadd52huq zmm18,zmm20,zmm13
   7fc31:	62 a1 f5 40 d4 db                               	vpaddq zmm19,zmm17,zmm19
   7fc37:	62 a1 75 00 ef c9                               	vpxord xmm17,xmm17,xmm17
   7fc3d:	62 e2 f5 48 b5 cb                               	vpmadd52huq zmm17,zmm1,zmm3
   7fc43:	62 c2 dd 40 b5 c4                               	vpmadd52huq zmm16,zmm20,zmm12
   7fc49:	62 72 dd 40 b5 f7                               	vpmadd52huq zmm14,zmm20,zmm7
   7fc4f:	62 e2 d5 48 b4 db                               	vpmadd52luq zmm19,zmm5,zmm3
   7fc55:	62 72 f5 48 b4 fb                               	vpmadd52luq zmm15,zmm1,zmm3
   7fc5b:	62 c2 dd 40 b4 d4                               	vpmadd52luq zmm18,zmm20,zmm12
   7fc61:	62 e2 dd 40 b4 c7                               	vpmadd52luq zmm16,zmm20,zmm7
   7fc67:	62 52 dd 40 b4 f2                               	vpmadd52luq zmm14,zmm20,zmm10
   7fc6d:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7fc73:	62 82 e5 40 b4 e0                               	vpmadd52luq zmm20,zmm19,zmm24
   7fc79:	62 81 e5 40 d4 de                               	vpaddq zmm19,zmm19,zmm30
   7fc7f:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   7fc86:	62 e2 d5 48 b5 d3                               	vpmadd52huq zmm18,zmm5,zmm3
   7fc8c:	62 e2 dd 48 b5 c3                               	vpmadd52huq zmm16,zmm4,zmm3
   7fc92:	62 72 e5 48 b5 f3                               	vpmadd52huq zmm14,zmm3,zmm3
   7fc98:	62 72 dd 40 b5 ff                               	vpmadd52huq zmm15,zmm20,zmm7
   7fc9e:	62 82 dd 40 b5 da                               	vpmadd52huq zmm19,zmm20,zmm26
   7fca4:	62 c2 dd 40 b5 ca                               	vpmadd52huq zmm17,zmm20,zmm10
   7fcaa:	62 e2 dd 48 b4 d3                               	vpmadd52luq zmm18,zmm4,zmm3
   7fcb0:	62 e2 e5 48 b4 c3                               	vpmadd52luq zmm16,zmm3,zmm3
   7fcb6:	62 72 ed 48 b4 f3                               	vpmadd52luq zmm14,zmm2,zmm3
   7fcbc:	62 52 dd 40 b4 fa                               	vpmadd52luq zmm15,zmm20,zmm10
   7fcc2:	62 e2 ed 48 b5 ca                               	vpmadd52huq zmm17,zmm2,zmm2
   7fcc8:	62 c2 dd 40 b4 d5                               	vpmadd52luq zmm18,zmm20,zmm13
   7fcce:	62 c2 dd 40 b5 c5                               	vpmadd52huq zmm16,zmm20,zmm13
   7fcd4:	62 52 dd 40 b5 f4                               	vpmadd52huq zmm14,zmm20,zmm12
   7fcda:	62 72 e5 48 b5 fa                               	vpmadd52huq zmm15,zmm3,zmm2
   7fce0:	62 e2 f5 48 b4 ca                               	vpmadd52luq zmm17,zmm1,zmm2
   7fce6:	62 a1 ed 40 d4 db                               	vpaddq zmm19,zmm18,zmm19
   7fcec:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   7fcf2:	62 e2 f5 48 b5 d2                               	vpmadd52huq zmm18,zmm1,zmm2
   7fcf8:	62 c2 dd 40 b4 c4                               	vpmadd52luq zmm16,zmm20,zmm12
   7fcfe:	62 72 dd 40 b4 f7                               	vpmadd52luq zmm14,zmm20,zmm7
   7fd04:	62 e2 d5 48 b4 da                               	vpmadd52luq zmm19,zmm5,zmm2
   7fd0a:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7fd10:	62 72 ed 48 b4 fa                               	vpmadd52luq zmm15,zmm2,zmm2
   7fd16:	62 e2 d5 48 b5 c2                               	vpmadd52huq zmm16,zmm5,zmm2
   7fd1c:	62 82 e5 40 b4 e0                               	vpmadd52luq zmm20,zmm19,zmm24
   7fd22:	62 72 dd 48 b5 f2                               	vpmadd52huq zmm14,zmm4,zmm2
   7fd28:	62 81 e5 40 d4 de                               	vpaddq zmm19,zmm19,zmm30
   7fd2e:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   7fd35:	62 e2 dd 48 b4 c2                               	vpmadd52luq zmm16,zmm4,zmm2
   7fd3b:	62 72 e5 48 b4 f2                               	vpmadd52luq zmm14,zmm3,zmm2
   7fd41:	62 52 dd 40 b5 fc                               	vpmadd52huq zmm15,zmm20,zmm12
   7fd47:	62 e2 dd 40 b5 cf                               	vpmadd52huq zmm17,zmm20,zmm7
   7fd4d:	62 82 dd 40 b5 da                               	vpmadd52huq zmm19,zmm20,zmm26
   7fd53:	62 c2 dd 40 b5 d2                               	vpmadd52huq zmm18,zmm20,zmm10
   7fd59:	62 c2 dd 40 b4 c5                               	vpmadd52luq zmm16,zmm20,zmm13
   7fd5f:	62 52 dd 40 b5 f5                               	vpmadd52huq zmm14,zmm20,zmm13
   7fd65:	62 72 dd 40 b4 ff                               	vpmadd52luq zmm15,zmm20,zmm7
   7fd6b:	62 c2 dd 40 b4 ca                               	vpmadd52luq zmm17,zmm20,zmm10
   7fd71:	62 e2 ed 48 b5 d1                               	vpmadd52huq zmm18,zmm2,zmm1
   7fd77:	62 a1 fd 40 d4 c3                               	vpaddq zmm16,zmm16,zmm19
   7fd7d:	62 52 dd 40 b4 f4                               	vpmadd52luq zmm14,zmm20,zmm12
   7fd83:	62 72 dd 48 b5 f9                               	vpmadd52huq zmm15,zmm4,zmm1
   7fd89:	62 e2 e5 48 b5 c9                               	vpmadd52huq zmm17,zmm3,zmm1
   7fd8f:	62 a1 5d 00 ef e4                               	vpxord xmm20,xmm20,xmm20
   7fd95:	62 e2 f5 48 b4 d1                               	vpmadd52luq zmm18,zmm1,zmm1
   7fd9b:	62 a1 65 00 ef db                               	vpxord xmm19,xmm19,xmm19
   7fda1:	62 e2 f5 48 b5 d9                               	vpmadd52huq zmm19,zmm1,zmm1
   7fda7:	62 e2 d5 48 b4 c1                               	vpmadd52luq zmm16,zmm5,zmm1
   7fdad:	62 72 d5 48 b5 f1                               	vpmadd52huq zmm14,zmm5,zmm1
   7fdb3:	62 72 e5 48 b4 f9                               	vpmadd52luq zmm15,zmm3,zmm1
   7fdb9:	62 e2 ed 48 b4 c9                               	vpmadd52luq zmm17,zmm2,zmm1
   7fdbf:	62 82 fd 40 b4 e0                               	vpmadd52luq zmm20,zmm16,zmm24
   7fdc5:	62 81 fd 40 d4 c3                               	vpaddq zmm16,zmm16,zmm27
   7fdcb:	62 b1 fd 40 73 d0 30                            	vpsrlq zmm16,zmm16,0x30
   7fdd2:	62 72 dd 48 b4 f1                               	vpmadd52luq zmm14,zmm4,zmm1
   7fdd8:	62 81 dd 40 db eb                               	vpandq zmm21,zmm20,zmm27
   7fdde:	62 b1 dd 40 73 f4 04                            	vpsllq zmm20,zmm20,0x4
   7fde5:	62 01 25 00 ef db                               	vpxord xmm27,xmm27,xmm27
   7fdeb:	62 52 d5 40 b5 fd                               	vpmadd52huq zmm15,zmm21,zmm13
   7fdf1:	62 c2 d5 40 b5 cc                               	vpmadd52huq zmm17,zmm21,zmm12
   7fdf7:	62 e2 d5 40 b5 d7                               	vpmadd52huq zmm18,zmm21,zmm7
   7fdfd:	62 82 dd 40 b5 c2                               	vpmadd52huq zmm16,zmm20,zmm26
   7fe03:	62 c2 d5 40 b5 da                               	vpmadd52huq zmm19,zmm21,zmm10
   7fe09:	62 52 d5 40 b4 f5                               	vpmadd52luq zmm14,zmm21,zmm13
   7fe0f:	62 52 d5 40 b4 fc                               	vpmadd52luq zmm15,zmm21,zmm12
   7fe15:	62 e2 d5 40 b4 cf                               	vpmadd52luq zmm17,zmm21,zmm7
   7fe1b:	62 c2 d5 40 b4 d2                               	vpmadd52luq zmm18,zmm21,zmm10
   7fe21:	62 d1 ad 48 73 f6 04                            	vpsllq zmm10,zmm14,0x4
   7fe28:	62 d1 a5 48 73 d6 30                            	vpsrlq zmm11,zmm14,0x30
   7fe2f:	62 11 ad 48 db d4                               	vpandq zmm10,zmm10,zmm28
   7fe35:	62 d1 9d 48 73 f7 04                            	vpsllq zmm12,zmm15,0x4
   7fe3c:	62 b1 8d 48 73 f1 04                            	vpsllq zmm14,zmm17,0x4
   7fe43:	62 d1 95 48 73 d7 30                            	vpsrlq zmm13,zmm15,0x30
   7fe4a:	62 b1 85 48 73 f2 04                            	vpsllq zmm15,zmm18,0x4
   7fe51:	62 b1 c5 48 73 d1 30                            	vpsrlq zmm7,zmm17,0x30
   7fe58:	62 31 ad 48 d4 d0                               	vpaddq zmm10,zmm10,zmm16
   7fe5e:	62 b1 fd 40 73 f3 04                            	vpsllq zmm16,zmm19,0x4
   7fe65:	62 11 8d 48 db f4                               	vpandq zmm14,zmm14,zmm28
   7fe6b:	62 11 85 48 db fc                               	vpandq zmm15,zmm15,zmm28
   7fe71:	62 11 9d 48 db e4                               	vpandq zmm12,zmm12,zmm28
   7fe77:	62 01 1d 00 ef e4                               	vpxord xmm28,xmm28,xmm28
   7fe7d:	62 51 8d 48 d4 ed                               	vpaddq zmm13,zmm14,zmm13
   7fe83:	62 71 85 48 d4 f7                               	vpaddq zmm14,zmm15,zmm7
   7fe89:	62 b1 c5 48 73 d2 30                            	vpsrlq zmm7,zmm18,0x30
   7fe90:	62 31 c5 48 d4 f8                               	vpaddq zmm15,zmm7,zmm16
   7fe96:	62 d1 c5 48 73 d2 34                            	vpsrlq zmm7,zmm10,0x34
   7fe9d:	62 11 ad 48 db d6                               	vpandq zmm10,zmm10,zmm30
   7fea3:	62 71 ad 48 fb 54 01 fa                         	vpsubq zmm10,zmm10,ZMMWORD PTR [rcx+rax*1-0x180]
   7feab:	62 51 c5 48 d4 db                               	vpaddq zmm11,zmm7,zmm11
   7feb1:	62 f2 fd 48 59 3d 0d 75 f8 ff                   	vpbroadcastq zmm7,QWORD PTR [rip+0xfffffffffff8750d]        # 73c8 <GCC_except_table740+0x180>
   7febb:	62 51 a5 48 d4 dc                               	vpaddq zmm11,zmm11,zmm12
   7fec1:	62 d1 9d 48 73 d3 34                            	vpsrlq zmm12,zmm11,0x34
   7fec8:	62 11 a5 48 db de                               	vpandq zmm11,zmm11,zmm30
   7fece:	62 71 a5 48 fb 5c 01 fb                         	vpsubq zmm11,zmm11,ZMMWORD PTR [rcx+rax*1-0x140]
   7fed6:	62 51 9d 48 d4 e5                               	vpaddq zmm12,zmm12,zmm13
   7fedc:	62 d1 95 48 73 d4 34                            	vpsrlq zmm13,zmm12,0x34
   7fee3:	62 11 9d 48 db e6                               	vpandq zmm12,zmm12,zmm30
   7fee9:	62 71 9d 48 fb 64 01 fc                         	vpsubq zmm12,zmm12,ZMMWORD PTR [rcx+rax*1-0x100]
   7fef1:	62 51 95 48 d4 ee                               	vpaddq zmm13,zmm13,zmm14
   7fef7:	62 d1 8d 48 73 d5 34                            	vpsrlq zmm14,zmm13,0x34
   7fefe:	62 11 95 48 db ee                               	vpandq zmm13,zmm13,zmm30
   7ff04:	62 71 95 48 fb 6c 01 fd                         	vpsubq zmm13,zmm13,ZMMWORD PTR [rcx+rax*1-0xc0]
   7ff0c:	62 51 8d 48 d4 f7                               	vpaddq zmm14,zmm14,zmm15
   7ff12:	62 71 8d 48 fb 74 01 fe                         	vpsubq zmm14,zmm14,ZMMWORD PTR [rcx+rax*1-0x80]
   7ff1a:	62 81 ad 48 db c6                               	vpandq zmm16,zmm10,zmm30
   7ff20:	62 d1 ad 48 72 e2 34                            	vpsraq zmm10,zmm10,0x34
   7ff27:	62 72 fd 48 59 bc 24 20 04 00 00                	vpbroadcastq zmm15,QWORD PTR [rsp+0x420]
   7ff32:	62 51 a5 48 d4 d2                               	vpaddq zmm10,zmm11,zmm10
   7ff38:	62 11 ad 48 db de                               	vpandq zmm11,zmm10,zmm30
   7ff3e:	62 d1 ad 48 72 e2 34                            	vpsraq zmm10,zmm10,0x34
   7ff45:	62 e1 a5 58 d4 ac 24 08 04 00 00                	vpaddq zmm21,zmm11,QWORD BCST [rsp+0x408]
   7ff50:	62 51 9d 48 d4 d2                               	vpaddq zmm10,zmm12,zmm10
   7ff56:	62 11 ad 48 db e6                               	vpandq zmm12,zmm10,zmm30
   7ff5c:	62 d1 ad 48 72 e2 34                            	vpsraq zmm10,zmm10,0x34
   7ff63:	62 e1 9d 58 d4 9c 24 10 04 00 00                	vpaddq zmm19,zmm12,QWORD BCST [rsp+0x410]
   7ff6e:	62 51 95 48 d4 d2                               	vpaddq zmm10,zmm13,zmm10
   7ff74:	62 11 ad 48 db ee                               	vpandq zmm13,zmm10,zmm30
   7ff7a:	62 d1 ad 48 72 e2 34                            	vpsraq zmm10,zmm10,0x34
   7ff81:	62 e1 95 58 d4 94 24 18 04 00 00                	vpaddq zmm18,zmm13,QWORD BCST [rsp+0x418]
   7ff8c:	c5 fc 11 b4 24 00 04 00 00                      	vmovups YMMWORD PTR [rsp+0x400],ymm6
   7ff95:	4c 89 bc 24 20 04 00 00                         	mov    QWORD PTR [rsp+0x420],r15
   7ff9d:	62 51 8d 48 d4 d2                               	vpaddq zmm10,zmm14,zmm10
   7ffa3:	62 71 fd 40 d4 f7                               	vpaddq zmm14,zmm16,zmm7
   7ffa9:	62 e1 fd 48 6f 24 3a                            	vmovdqa64 zmm20,ZMMWORD PTR [rdx+rdi*1]
   7ffb0:	62 93 ad 48 1e cf 01                            	vpcmpltuq k1,zmm10,zmm31
   7ffb7:	62 11 fd 49 6f ff                               	vmovdqa64 zmm15{k1},zmm31
   7ffbd:	62 31 fd 49 6f f0                               	vmovdqa64 zmm14{k1},zmm16
   7ffc3:	62 c1 85 48 d4 ca                               	vpaddq zmm17,zmm15,zmm10
   7ffc9:	62 d1 85 48 73 d6 34                            	vpsrlq zmm15,zmm14,0x34
   7ffd0:	62 11 8d 48 db d6                               	vpandq zmm10,zmm14,zmm30
   7ffd6:	62 c1 fd 49 6f eb                               	vmovdqa64 zmm21{k1},zmm11
   7ffdc:	62 31 85 48 d4 fd                               	vpaddq zmm15,zmm15,zmm21
   7ffe2:	62 e1 fd 48 6f 6c 3a 04                         	vmovdqa64 zmm21,ZMMWORD PTR [rdx+rdi*1+0x100]
   7ffea:	62 d1 8d 48 73 d7 34                            	vpsrlq zmm14,zmm15,0x34
   7fff1:	62 11 85 48 db de                               	vpandq zmm11,zmm15,zmm30
   7fff7:	62 c1 fd 49 6f dc                               	vmovdqa64 zmm19{k1},zmm12
   7fffd:	62 31 8d 48 d4 f3                               	vpaddq zmm14,zmm14,zmm19
   80003:	62 e1 fd 48 6f 5c 3a 03                         	vmovdqa64 zmm19,ZMMWORD PTR [rdx+rdi*1+0xc0]
   8000b:	62 d1 85 48 73 d6 34                            	vpsrlq zmm15,zmm14,0x34
   80012:	62 11 8d 48 db e6                               	vpandq zmm12,zmm14,zmm30
   80018:	62 c1 fd 49 6f d5                               	vmovdqa64 zmm18{k1},zmm13
   8001e:	62 31 85 48 d4 fa                               	vpaddq zmm15,zmm15,zmm18
   80024:	62 e1 fd 48 6f 54 3a 02                         	vmovdqa64 zmm18,ZMMWORD PTR [rdx+rdi*1+0x80]
   8002c:	62 d1 8d 48 73 d7 34                            	vpsrlq zmm14,zmm15,0x34
   80033:	62 c1 dd 40 fb c2                               	vpsubq zmm16,zmm20,zmm10
   80039:	62 11 85 48 db ee                               	vpandq zmm13,zmm15,zmm30
   8003f:	62 72 fd 48 59 bc 24 20 04 00 00                	vpbroadcastq zmm15,QWORD PTR [rsp+0x420]
   8004a:	62 31 8d 48 d4 f1                               	vpaddq zmm14,zmm14,zmm17
   80050:	62 e1 fd 48 6f 4c 3a 01                         	vmovdqa64 zmm17,ZMMWORD PTR [rdx+rdi*1+0x40]
   80058:	62 81 fd 40 db e6                               	vpandq zmm20,zmm16,zmm30
   8005e:	62 b1 fd 40 72 e0 34                            	vpsraq zmm16,zmm16,0x34
   80065:	62 11 8d 48 db f6                               	vpandq zmm14,zmm14,zmm30
   8006b:	62 c1 d5 40 fb ee                               	vpsubq zmm21,zmm21,zmm14
   80071:	62 c1 e5 40 fb dd                               	vpsubq zmm19,zmm19,zmm13
   80077:	62 c1 ed 40 fb d4                               	vpsubq zmm18,zmm18,zmm12
   8007d:	62 c1 f5 40 fb cb                               	vpsubq zmm17,zmm17,zmm11
   80083:	62 a1 f5 40 d4 c0                               	vpaddq zmm16,zmm17,zmm16
   80089:	62 81 fd 40 db ce                               	vpandq zmm17,zmm16,zmm30
   8008f:	62 b1 fd 40 72 e0 34                            	vpsraq zmm16,zmm16,0x34
   80096:	62 61 f5 50 d4 84 24 08 04 00 00                	vpaddq zmm24,zmm17,QWORD BCST [rsp+0x408]
   800a1:	62 a1 ed 40 d4 c0                               	vpaddq zmm16,zmm18,zmm16
   800a7:	62 81 fd 40 db d6                               	vpandq zmm18,zmm16,zmm30
   800ad:	62 e1 ed 50 d4 bc 24 10 04 00 00                	vpaddq zmm23,zmm18,QWORD BCST [rsp+0x410]
   800b8:	62 b1 fd 40 72 e0 34                            	vpsraq zmm16,zmm16,0x34
   800bf:	62 a1 e5 40 d4 c0                               	vpaddq zmm16,zmm19,zmm16
   800c5:	62 81 fd 40 db de                               	vpandq zmm19,zmm16,zmm30
   800cb:	62 b1 fd 40 72 e0 34                            	vpsraq zmm16,zmm16,0x34
   800d2:	62 a1 d5 40 d4 c0                               	vpaddq zmm16,zmm21,zmm16
   800d8:	62 e1 dd 40 d4 ef                               	vpaddq zmm21,zmm20,zmm7
   800de:	62 93 fd 40 1e cf 01                            	vpcmpltuq k1,zmm16,zmm31
   800e5:	62 a1 fd 49 6f ec                               	vmovdqa64 zmm21{k1},zmm20
   800eb:	62 11 fd 49 6f ff                               	vmovdqa64 zmm15{k1},zmm31
   800f1:	62 31 85 48 d4 f8                               	vpaddq zmm15,zmm15,zmm16
   800f7:	62 b1 fd 40 73 d5 34                            	vpsrlq zmm16,zmm21,0x34
   800fe:	62 21 fd 49 6f c1                               	vmovdqa64 zmm24{k1},zmm17
   80104:	62 81 fd 40 d4 c0                               	vpaddq zmm16,zmm16,zmm24
   8010a:	62 b1 dd 40 73 d0 34                            	vpsrlq zmm20,zmm16,0x34
   80111:	62 01 fd 40 db d6                               	vpandq zmm26,zmm16,zmm30
   80117:	62 a1 fd 49 6f fa                               	vmovdqa64 zmm23{k1},zmm18
   8011d:	62 e1 e5 50 d4 94 24 18 04 00 00                	vpaddq zmm18,zmm19,QWORD BCST [rsp+0x418]
   80128:	62 61 fe 28 7f 4c 24 20                         	vmovdqu64 YMMWORD PTR [rsp+0x400],ymm25
   80130:	4c 89 84 24 20 04 00 00                         	mov    QWORD PTR [rsp+0x420],r8
   80138:	62 01 35 00 ef c9                               	vpxord xmm25,xmm25,xmm25
   8013e:	62 21 dd 40 d4 c7                               	vpaddq zmm24,zmm20,zmm23
   80144:	62 e2 fd 48 59 8c 24 08 04 00 00                	vpbroadcastq zmm17,QWORD PTR [rsp+0x408]
   8014f:	62 91 fd 40 73 d0 34                            	vpsrlq zmm16,zmm24,0x34
   80156:	62 a1 fd 49 6f d3                               	vmovdqa64 zmm18{k1},zmm19
   8015c:	62 81 d5 40 db de                               	vpandq zmm19,zmm21,zmm30
   80162:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   80168:	62 a1 fd 40 d4 fa                               	vpaddq zmm23,zmm16,zmm18
   8016e:	62 a1 6d 00 ef d2                               	vpxord xmm18,xmm18,xmm18
   80174:	62 22 d5 48 b5 e3                               	vpmadd52huq zmm28,zmm5,zmm19
   8017a:	62 a2 d5 48 b4 eb                               	vpmadd52luq zmm21,zmm5,zmm19
   80180:	62 22 dd 48 b5 db                               	vpmadd52huq zmm27,zmm4,zmm19
   80186:	62 22 e5 48 b5 cb                               	vpmadd52huq zmm25,zmm3,zmm19
   8018c:	62 a2 ed 48 b5 f3                               	vpmadd52huq zmm22,zmm2,zmm19
   80192:	62 a2 f5 48 b5 d3                               	vpmadd52huq zmm18,zmm1,zmm19
   80198:	62 b1 fd 40 73 d7 34                            	vpsrlq zmm16,zmm23,0x34
   8019f:	62 c1 fd 40 d4 e7                               	vpaddq zmm20,zmm16,zmm15
   801a5:	62 e2 fd 48 59 84 24 10 04 00 00                	vpbroadcastq zmm16,QWORD PTR [rsp+0x410]
   801b0:	62 72 fd 48 59 bc 24 18 04 00 00                	vpbroadcastq zmm15,QWORD PTR [rsp+0x418]
   801bb:	62 81 dd 40 db e6                               	vpandq zmm20,zmm20,zmm30
   801c1:	62 22 dd 48 b4 e3                               	vpmadd52luq zmm28,zmm4,zmm19
   801c7:	62 42 d5 40 b4 e8                               	vpmadd52luq zmm29,zmm21,zmm8
   801cd:	62 22 e5 48 b4 db                               	vpmadd52luq zmm27,zmm3,zmm19
   801d3:	62 22 ed 48 b4 cb                               	vpmadd52luq zmm25,zmm2,zmm19
   801d9:	62 a2 f5 48 b4 f3                               	vpmadd52luq zmm22,zmm1,zmm19
   801df:	62 81 d5 40 d4 de                               	vpaddq zmm19,zmm21,zmm30
   801e5:	62 a1 55 00 ef ed                               	vpxord xmm21,xmm21,xmm21
   801eb:	62 82 f5 48 b5 ea                               	vpmadd52huq zmm21,zmm1,zmm26
   801f1:	62 b1 e5 40 73 d3 34                            	vpsrlq zmm19,zmm19,0x34
   801f8:	62 c2 95 40 b5 d9                               	vpmadd52huq zmm19,zmm29,zmm9
   801fe:	62 22 95 40 b4 e1                               	vpmadd52luq zmm28,zmm29,zmm17
   80204:	62 22 95 40 b5 d9                               	vpmadd52huq zmm27,zmm29,zmm17
   8020a:	62 22 95 40 b5 c8                               	vpmadd52huq zmm25,zmm29,zmm16
   80210:	62 c2 95 40 b5 f7                               	vpmadd52huq zmm22,zmm29,zmm15
   80216:	62 21 9d 40 d4 e3                               	vpaddq zmm28,zmm28,zmm19
   8021c:	62 e2 fd 48 59 9c 24 20 04 00 00                	vpbroadcastq zmm19,QWORD PTR [rsp+0x420]
   80227:	62 22 95 40 b4 d8                               	vpmadd52luq zmm27,zmm29,zmm16
   8022d:	c5 fc 11 b4 24 00 04 00 00                      	vmovups YMMWORD PTR [rsp+0x400],ymm6
   80236:	4c 89 bc 24 20 04 00 00                         	mov    QWORD PTR [rsp+0x420],r15
   8023e:	62 42 95 40 b4 cf                               	vpmadd52luq zmm25,zmm29,zmm15
   80244:	62 02 d5 48 b4 e2                               	vpmadd52luq zmm28,zmm5,zmm26
   8024a:	62 02 d5 48 b5 da                               	vpmadd52huq zmm27,zmm5,zmm26
   80250:	62 02 dd 48 b5 ca                               	vpmadd52huq zmm25,zmm4,zmm26
   80256:	62 a2 95 40 b4 f3                               	vpmadd52luq zmm22,zmm29,zmm19
   8025c:	62 a2 95 40 b5 d3                               	vpmadd52huq zmm18,zmm29,zmm19
   80262:	62 02 dd 48 b4 da                               	vpmadd52luq zmm27,zmm4,zmm26
   80268:	62 02 e5 48 b4 ca                               	vpmadd52luq zmm25,zmm3,zmm26
   8026e:	62 82 e5 48 b5 f2                               	vpmadd52huq zmm22,zmm3,zmm26
   80274:	62 82 ed 48 b5 d2                               	vpmadd52huq zmm18,zmm2,zmm26
   8027a:	62 82 ed 48 b4 f2                               	vpmadd52luq zmm22,zmm2,zmm26
   80280:	62 82 f5 48 b4 d2                               	vpmadd52luq zmm18,zmm1,zmm26
   80286:	62 01 2d 00 ef d2                               	vpxord xmm26,xmm26,xmm26
   8028c:	62 42 9d 40 b4 d0                               	vpmadd52luq zmm26,zmm28,zmm8
   80292:	62 01 9d 40 d4 e6                               	vpaddq zmm28,zmm28,zmm30
   80298:	62 91 9d 40 73 d4 34                            	vpsrlq zmm28,zmm28,0x34
   8029f:	62 22 ad 40 b5 c9                               	vpmadd52huq zmm25,zmm26,zmm17
   802a5:	62 a2 ad 40 b5 f0                               	vpmadd52huq zmm22,zmm26,zmm16
   802ab:	62 42 ad 40 b5 e1                               	vpmadd52huq zmm28,zmm26,zmm9
   802b1:	62 22 ad 40 b4 d9                               	vpmadd52luq zmm27,zmm26,zmm17
   802b7:	62 c2 ad 40 b5 d7                               	vpmadd52huq zmm18,zmm26,zmm15
   802bd:	62 a2 ad 40 b5 eb                               	vpmadd52huq zmm21,zmm26,zmm19
   802c3:	62 22 ad 40 b4 c8                               	vpmadd52luq zmm25,zmm26,zmm16
   802c9:	62 c2 ad 40 b4 f7                               	vpmadd52luq zmm22,zmm26,zmm15
   802cf:	62 01 a5 40 d4 dc                               	vpaddq zmm27,zmm27,zmm28
   802d5:	62 01 bd 40 db e6                               	vpandq zmm28,zmm24,zmm30
   802db:	62 a2 ad 40 b4 d3                               	vpmadd52luq zmm18,zmm26,zmm19
   802e1:	62 01 2d 00 ef d2                               	vpxord xmm26,xmm26,xmm26
   802e7:	62 01 3d 00 ef c0                               	vpxord xmm24,xmm24,xmm24
   802ed:	62 02 d5 48 b4 dc                               	vpmadd52luq zmm27,zmm5,zmm28
   802f3:	62 82 ed 48 b5 ec                               	vpmadd52huq zmm21,zmm2,zmm28
   802f9:	62 02 f5 48 b5 c4                               	vpmadd52huq zmm24,zmm1,zmm28
   802ff:	62 02 d5 48 b5 cc                               	vpmadd52huq zmm25,zmm5,zmm28
   80305:	62 82 dd 48 b5 f4                               	vpmadd52huq zmm22,zmm4,zmm28
   8030b:	62 82 e5 48 b5 d4                               	vpmadd52huq zmm18,zmm3,zmm28
   80311:	62 42 a5 40 b4 d0                               	vpmadd52luq zmm26,zmm27,zmm8
   80317:	62 82 f5 48 b4 ec                               	vpmadd52luq zmm21,zmm1,zmm28
   8031d:	62 01 a5 40 d4 de                               	vpaddq zmm27,zmm27,zmm30
   80323:	62 91 a5 40 73 d3 34                            	vpsrlq zmm27,zmm27,0x34
   8032a:	62 02 dd 48 b4 cc                               	vpmadd52luq zmm25,zmm4,zmm28
   80330:	62 82 e5 48 b4 f4                               	vpmadd52luq zmm22,zmm3,zmm28
   80336:	62 82 ed 48 b4 d4                               	vpmadd52luq zmm18,zmm2,zmm28
   8033c:	62 42 ad 40 b5 d9                               	vpmadd52huq zmm27,zmm26,zmm9
   80342:	62 22 ad 40 b5 c3                               	vpmadd52huq zmm24,zmm26,zmm19
   80348:	62 c2 ad 40 b5 ef                               	vpmadd52huq zmm21,zmm26,zmm15
   8034e:	62 22 ad 40 b4 c9                               	vpmadd52luq zmm25,zmm26,zmm17
   80354:	62 a2 ad 40 b5 f1                               	vpmadd52huq zmm22,zmm26,zmm17
   8035a:	62 a2 ad 40 b5 d0                               	vpmadd52huq zmm18,zmm26,zmm16
   80360:	62 a2 ad 40 b4 eb                               	vpmadd52luq zmm21,zmm26,zmm19
   80366:	62 01 b5 40 d4 cb                               	vpaddq zmm25,zmm25,zmm27
   8036c:	62 01 c5 40 db de                               	vpandq zmm27,zmm23,zmm30
   80372:	62 a2 ad 40 b4 f0                               	vpmadd52luq zmm22,zmm26,zmm16
   80378:	62 c2 ad 40 b4 d7                               	vpmadd52luq zmm18,zmm26,zmm15
   8037e:	62 01 2d 00 ef d2                               	vpxord xmm26,xmm26,xmm26
   80384:	62 a1 45 00 ef ff                               	vpxord xmm23,xmm23,xmm23
   8038a:	62 02 ed 48 b5 c3                               	vpmadd52huq zmm24,zmm2,zmm27
   80390:	62 02 d5 48 b4 cb                               	vpmadd52luq zmm25,zmm5,zmm27
   80396:	62 82 e5 48 b5 eb                               	vpmadd52huq zmm21,zmm3,zmm27
   8039c:	62 82 f5 48 b5 fb                               	vpmadd52huq zmm23,zmm1,zmm27
   803a2:	62 82 d5 48 b5 f3                               	vpmadd52huq zmm22,zmm5,zmm27
   803a8:	62 82 dd 48 b5 d3                               	vpmadd52huq zmm18,zmm4,zmm27
   803ae:	62 42 b5 40 b4 d0                               	vpmadd52luq zmm26,zmm25,zmm8
   803b4:	62 02 f5 48 b4 c3                               	vpmadd52luq zmm24,zmm1,zmm27
   803ba:	62 82 ed 48 b4 eb                               	vpmadd52luq zmm21,zmm2,zmm27
   803c0:	62 01 b5 40 d4 ce                               	vpaddq zmm25,zmm25,zmm30
   803c6:	62 91 b5 40 73 d1 34                            	vpsrlq zmm25,zmm25,0x34
   803cd:	62 82 dd 48 b4 f3                               	vpmadd52luq zmm22,zmm4,zmm27
   803d3:	62 82 e5 48 b4 d3                               	vpmadd52luq zmm18,zmm3,zmm27
   803d9:	62 42 ad 40 b5 c7                               	vpmadd52huq zmm24,zmm26,zmm15
   803df:	62 42 ad 40 b5 c9                               	vpmadd52huq zmm25,zmm26,zmm9
   803e5:	62 a2 ad 40 b5 fb                               	vpmadd52huq zmm23,zmm26,zmm19
   803eb:	62 a2 ad 40 b5 e8                               	vpmadd52huq zmm21,zmm26,zmm16
   803f1:	62 a2 ad 40 b4 f1                               	vpmadd52luq zmm22,zmm26,zmm17
   803f7:	62 a2 ad 40 b5 d1                               	vpmadd52huq zmm18,zmm26,zmm17
   803fd:	62 22 ad 40 b4 c3                               	vpmadd52luq zmm24,zmm26,zmm19
   80403:	62 a2 ed 48 b5 fc                               	vpmadd52huq zmm23,zmm2,zmm20
   80409:	62 c2 ad 40 b4 ef                               	vpmadd52luq zmm21,zmm26,zmm15
   8040f:	62 81 cd 40 d4 f1                               	vpaddq zmm22,zmm22,zmm25
   80415:	62 a2 ad 40 b4 d0                               	vpmadd52luq zmm18,zmm26,zmm16
   8041b:	62 22 e5 48 b5 c4                               	vpmadd52huq zmm24,zmm3,zmm20
   80421:	62 a2 d5 48 b4 f4                               	vpmadd52luq zmm22,zmm5,zmm20
   80427:	62 a2 f5 48 b4 fc                               	vpmadd52luq zmm23,zmm1,zmm20
   8042d:	62 a2 dd 48 b5 ec                               	vpmadd52huq zmm21,zmm4,zmm20
   80433:	62 a2 d5 48 b5 d4                               	vpmadd52huq zmm18,zmm5,zmm20
   80439:	62 22 ed 48 b4 c4                               	vpmadd52luq zmm24,zmm2,zmm20
   8043f:	c5 e9 ef d2                                     	vpxor  xmm2,xmm2,xmm2
   80443:	62 b2 f5 48 b5 d4                               	vpmadd52huq zmm2,zmm1,zmm20
   80449:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   8044d:	62 d2 cd 40 b4 c8                               	vpmadd52luq zmm1,zmm22,zmm8
   80453:	62 72 fd 48 59 05 6b 6e f8 ff                   	vpbroadcastq zmm8,QWORD PTR [rip+0xfffffffffff86e6b]        # 72c8 <GCC_except_table740+0x80>
   8045d:	62 a2 e5 48 b4 ec                               	vpmadd52luq zmm21,zmm3,zmm20
   80463:	62 a2 dd 48 b4 d4                               	vpmadd52luq zmm18,zmm4,zmm20
   80469:	62 f1 dd 48 73 f1 04                            	vpsllq zmm4,zmm1,0x4
   80470:	62 d1 f5 48 db c8                               	vpandq zmm1,zmm1,zmm8
   80476:	62 d1 cd 40 d4 d8                               	vpaddq zmm3,zmm22,zmm8
   8047c:	62 72 fd 48 59 05 1a 6f f8 ff                   	vpbroadcastq zmm8,QWORD PTR [rip+0xfffffffffff86f1a]        # 73a0 <GCC_except_table740+0x158>
   80486:	62 e2 fd 48 59 35 c8 6e f8 ff                   	vpbroadcastq zmm22,QWORD PTR [rip+0xfffffffffff86ec8]        # 7358 <GCC_except_table740+0x110>
   80490:	62 a2 f5 48 b5 e9                               	vpmadd52huq zmm21,zmm1,zmm17
   80496:	62 22 f5 48 b5 c0                               	vpmadd52huq zmm24,zmm1,zmm16
   8049c:	62 c2 f5 48 b5 ff                               	vpmadd52huq zmm23,zmm1,zmm15
   804a2:	62 a2 f5 48 b4 d1                               	vpmadd52luq zmm18,zmm1,zmm17
   804a8:	62 f1 e5 48 73 d3 30                            	vpsrlq zmm3,zmm3,0x30
   804af:	62 b2 f5 48 b5 d3                               	vpmadd52huq zmm2,zmm1,zmm19
   804b5:	62 d2 dd 48 b5 d9                               	vpmadd52huq zmm3,zmm4,zmm9
   804bb:	62 42 f5 48 b4 c7                               	vpmadd52luq zmm24,zmm1,zmm15
   804c1:	62 a2 f5 48 b4 e8                               	vpmadd52luq zmm21,zmm1,zmm16
   804c7:	62 a2 f5 48 b4 fb                               	vpmadd52luq zmm23,zmm1,zmm19
   804cd:	62 b1 f5 48 73 f2 04                            	vpsllq zmm1,zmm18,0x4
   804d4:	62 f1 ed 48 73 f2 04                            	vpsllq zmm2,zmm2,0x4
   804db:	62 d1 f5 48 db c8                               	vpandq zmm1,zmm1,zmm8
   804e1:	62 a1 95 48 d4 de                               	vpaddq zmm19,zmm13,zmm22
   804e7:	62 b1 dd 48 73 f5 04                            	vpsllq zmm4,zmm21,0x4
   804ee:	62 91 85 48 73 f0 04                            	vpsllq zmm15,zmm24,0x4
   804f5:	62 b1 fd 40 73 f7 04                            	vpsllq zmm16,zmm23,0x4
   804fc:	62 f1 f5 48 d4 cb                               	vpaddq zmm1,zmm1,zmm3
   80502:	62 b1 e5 48 73 d2 30                            	vpsrlq zmm3,zmm18,0x30
   80509:	62 b1 d5 48 73 d5 30                            	vpsrlq zmm5,zmm21,0x30
   80510:	62 91 b5 48 73 d0 30                            	vpsrlq zmm9,zmm24,0x30
   80517:	62 e2 fd 48 59 2d 97 6e f8 ff                   	vpbroadcastq zmm21,QWORD PTR [rip+0xfffffffffff86e97]        # 73b8 <GCC_except_table740+0x170>
   80521:	62 51 85 48 db f8                               	vpandq zmm15,zmm15,zmm8
   80527:	62 d1 dd 48 db e0                               	vpandq zmm4,zmm4,zmm8
   8052d:	62 c1 fd 40 db c0                               	vpandq zmm16,zmm16,zmm8
   80533:	62 f1 bd 48 73 d1 34                            	vpsrlq zmm8,zmm1,0x34
   8053a:	62 91 f5 48 db ce                               	vpandq zmm1,zmm1,zmm30
   80540:	62 f1 f5 48 fb 4c 3a 05                         	vpsubq zmm1,zmm1,ZMMWORD PTR [rdx+rdi*1+0x140]
   80548:	62 f1 bd 48 d4 db                               	vpaddq zmm3,zmm8,zmm3
   8054e:	62 f1 85 48 d4 ed                               	vpaddq zmm5,zmm15,zmm5
   80554:	62 51 fd 40 d4 f9                               	vpaddq zmm15,zmm16,zmm9
   8055a:	62 b1 b5 48 73 d7 30                            	vpsrlq zmm9,zmm23,0x30
   80561:	62 e2 fd 48 59 3d 65 6d f8 ff                   	vpbroadcastq zmm23,QWORD PTR [rip+0xfffffffffff86d65]        # 72d0 <GCC_except_table740+0x88>
   8056b:	62 f1 e5 48 d4 dc                               	vpaddq zmm3,zmm3,zmm4
   80571:	62 f1 b5 48 d4 d2                               	vpaddq zmm2,zmm9,zmm2
   80577:	62 f1 dd 48 73 d3 34                            	vpsrlq zmm4,zmm3,0x34
   8057e:	62 91 e5 48 db de                               	vpandq zmm3,zmm3,zmm30
   80584:	62 f1 e5 48 fb 5c 3a 06                         	vpsubq zmm3,zmm3,ZMMWORD PTR [rdx+rdi*1+0x180]
   8058c:	62 f1 dd 48 d4 e5                               	vpaddq zmm4,zmm4,zmm5
   80592:	62 f1 d5 48 73 d4 34                            	vpsrlq zmm5,zmm4,0x34
   80599:	62 91 dd 48 db e6                               	vpandq zmm4,zmm4,zmm30
   8059f:	62 f1 dd 48 fb 64 3a 07                         	vpsubq zmm4,zmm4,ZMMWORD PTR [rdx+rdi*1+0x1c0]
   805a7:	62 d1 d5 48 d4 ef                               	vpaddq zmm5,zmm5,zmm15
   805ad:	62 f1 85 48 73 d5 34                            	vpsrlq zmm15,zmm5,0x34
   805b4:	62 91 d5 48 db ee                               	vpandq zmm5,zmm5,zmm30
   805ba:	62 f1 d5 48 fb 6c 3a 08                         	vpsubq zmm5,zmm5,ZMMWORD PTR [rdx+rdi*1+0x200]
   805c2:	62 f1 85 48 d4 d2                               	vpaddq zmm2,zmm15,zmm2
   805c8:	62 f1 ed 48 fb 54 3a 09                         	vpsubq zmm2,zmm2,ZMMWORD PTR [rdx+rdi*1+0x240]
   805d0:	62 81 f5 48 db c6                               	vpandq zmm16,zmm1,zmm30
   805d6:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   805dd:	62 72 fd 48 59 bc 24 20 04 00 00                	vpbroadcastq zmm15,QWORD PTR [rsp+0x420]
   805e8:	62 a1 8d 48 d4 e7                               	vpaddq zmm20,zmm14,zmm23
   805ee:	62 f1 e5 48 d4 c9                               	vpaddq zmm1,zmm3,zmm1
   805f4:	62 91 f5 48 db de                               	vpandq zmm3,zmm1,zmm30
   805fa:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   80601:	62 71 e5 58 d4 8c 24 08 04 00 00                	vpaddq zmm9,zmm3,QWORD BCST [rsp+0x408]
   8060c:	62 f1 dd 48 d4 c9                               	vpaddq zmm1,zmm4,zmm1
   80612:	62 91 f5 48 db e6                               	vpandq zmm4,zmm1,zmm30
   80618:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   8061f:	62 71 dd 58 d4 84 24 10 04 00 00                	vpaddq zmm8,zmm4,QWORD BCST [rsp+0x410]
   8062a:	62 f1 d5 48 d4 c9                               	vpaddq zmm1,zmm5,zmm1
   80630:	62 91 f5 48 db ee                               	vpandq zmm5,zmm1,zmm30
   80636:	62 f1 f5 48 72 e1 34                            	vpsraq zmm1,zmm1,0x34
   8063d:	62 f1 ed 48 d4 c9                               	vpaddq zmm1,zmm2,zmm1
   80643:	62 f1 fd 40 d4 d7                               	vpaddq zmm2,zmm16,zmm7
   80649:	62 f1 d5 58 d4 bc 24 18 04 00 00                	vpaddq zmm7,zmm5,QWORD BCST [rsp+0x418]
   80654:	62 93 f5 48 1e cf 01                            	vpcmpltuq k1,zmm1,zmm31
   8065b:	62 b1 fd 49 6f d0                               	vmovdqa64 zmm2{k1},zmm16
   80661:	62 f1 cd 48 73 d2 34                            	vpsrlq zmm6,zmm2,0x34
   80668:	62 11 fd 49 6f ff                               	vmovdqa64 zmm15{k1},zmm31
   8066e:	62 f1 85 48 d4 c9                               	vpaddq zmm1,zmm15,zmm1
   80674:	62 91 ed 48 db d6                               	vpandq zmm2,zmm2,zmm30
   8067a:	62 71 fd 49 6f cb                               	vmovdqa64 zmm9{k1},zmm3
   80680:	62 71 fd 49 6f c4                               	vmovdqa64 zmm8{k1},zmm4
   80686:	62 f1 fd 49 6f fd                               	vmovdqa64 zmm7{k1},zmm5
   8068c:	62 d1 cd 48 d4 e9                               	vpaddq zmm5,zmm6,zmm9
   80692:	62 f2 fd 48 59 35 74 6c f8 ff                   	vpbroadcastq zmm6,QWORD PTR [rip+0xfffffffffff86c74]        # 7310 <GCC_except_table740+0xc8>
   8069c:	62 f1 85 48 73 d5 34                            	vpsrlq zmm15,zmm5,0x34
   806a3:	62 91 d5 48 db ee                               	vpandq zmm5,zmm5,zmm30
   806a9:	62 d1 85 48 d4 d8                               	vpaddq zmm3,zmm15,zmm8
   806af:	62 31 ad 48 d4 c5                               	vpaddq zmm8,zmm10,zmm21
   806b5:	62 f1 85 48 73 d3 34                            	vpsrlq zmm15,zmm3,0x34
   806bc:	62 d1 fd 40 72 e0 34                            	vpsraq zmm16,zmm8,0x34
   806c3:	62 91 e5 48 db de                               	vpandq zmm3,zmm3,zmm30
   806c9:	62 f1 85 48 d4 e7                               	vpaddq zmm4,zmm15,zmm7
   806cf:	62 f2 fd 48 59 3d 5f 6c f8 ff                   	vpbroadcastq zmm7,QWORD PTR [rip+0xfffffffffff86c5f]        # 7338 <GCC_except_table740+0xf0>
   806d9:	62 a1 a5 48 d4 c0                               	vpaddq zmm16,zmm11,zmm16
   806df:	62 f1 85 48 73 d4 34                            	vpsrlq zmm15,zmm4,0x34
   806e6:	62 91 dd 48 db e6                               	vpandq zmm4,zmm4,zmm30
   806ec:	62 f1 85 48 d4 c9                               	vpaddq zmm1,zmm15,zmm1
   806f2:	62 91 f5 48 db ce                               	vpandq zmm1,zmm1,zmm30
   806f8:	62 e1 fd 40 d4 c6                               	vpaddq zmm16,zmm16,zmm6
   806fe:	62 31 f5 48 d4 ff                               	vpaddq zmm15,zmm1,zmm23
   80704:	62 b1 f5 40 72 e0 34                            	vpsraq zmm17,zmm16,0x34
   8070b:	62 e1 9d 48 d4 d7                               	vpaddq zmm18,zmm12,zmm7
   80711:	62 a1 ed 40 d4 c9                               	vpaddq zmm17,zmm18,zmm17
   80717:	62 b1 ed 40 72 e1 34                            	vpsraq zmm18,zmm17,0x34
   8071e:	62 a1 e5 40 d4 d2                               	vpaddq zmm18,zmm19,zmm18
   80724:	62 b1 e5 40 72 e2 34                            	vpsraq zmm19,zmm18,0x34
   8072b:	62 a1 dd 40 d4 db                               	vpaddq zmm19,zmm20,zmm19
   80731:	62 93 e5 40 1e cf 01                            	vpcmpltuq k1,zmm19,zmm31
   80738:	62 11 bd 49 db d6                               	vpandq zmm10{k1},zmm8,zmm30
   8073e:	62 11 fd 41 db de                               	vpandq zmm11{k1},zmm16,zmm30
   80744:	62 11 f5 41 db e6                               	vpandq zmm12{k1},zmm17,zmm30
   8074a:	62 11 ed 41 db ee                               	vpandq zmm13{k1},zmm18,zmm30
   80750:	62 11 e5 41 db f6                               	vpandq zmm14{k1},zmm19,zmm30
   80756:	c5 f9 90 4c 01 c4                               	kmovb  k1,BYTE PTR [rcx+rax*1-0x3c]
   8075c:	62 31 ed 48 d4 c5                               	vpaddq zmm8,zmm2,zmm21
   80762:	48 05 00 fc ff ff                               	add    rax,0xfffffffffffffc00
   80768:	62 71 fd 49 7f 14 3a                            	vmovdqa64 ZMMWORD PTR [rdx+rdi*1]{k1},zmm10
   8076f:	62 71 fd 49 7f 5c 3a 01                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x40]{k1},zmm11
   80777:	62 d1 a5 48 72 e0 34                            	vpsraq zmm11,zmm8,0x34
   8077e:	62 71 fd 49 7f 64 3a 02                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x80]{k1},zmm12
   80786:	62 71 fd 49 7f 6c 3a 03                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0xc0]{k1},zmm13
   8078e:	62 71 e5 48 d4 ef                               	vpaddq zmm13,zmm3,zmm7
   80794:	62 71 fd 49 7f 74 3a 04                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x100]{k1},zmm14
   8079c:	62 31 dd 48 d4 f6                               	vpaddq zmm14,zmm4,zmm22
   807a2:	62 71 8d 40 db 54 24 19                         	vpandq zmm10,zmm30,ZMMWORD PTR [rsp+0x640]
   807aa:	62 f1 8d 40 db 7c 24 04                         	vpandq zmm7,zmm30,ZMMWORD PTR [rsp+0x100]
   807b2:	62 51 d5 48 d4 db                               	vpaddq zmm11,zmm5,zmm11
   807b8:	62 71 a5 48 d4 de                               	vpaddq zmm11,zmm11,zmm6
   807be:	62 f1 8d 40 db 74 24 1a                         	vpandq zmm6,zmm30,ZMMWORD PTR [rsp+0x680]
   807c6:	62 d1 9d 48 72 e3 34                            	vpsraq zmm12,zmm11,0x34
   807cd:	62 51 95 48 d4 e4                               	vpaddq zmm12,zmm13,zmm12
   807d3:	62 d1 95 48 72 e4 34                            	vpsraq zmm13,zmm12,0x34
   807da:	62 51 8d 48 d4 ed                               	vpaddq zmm13,zmm14,zmm13
   807e0:	62 d1 8d 48 72 e5 34                            	vpsraq zmm14,zmm13,0x34
   807e7:	62 51 85 48 d4 f6                               	vpaddq zmm14,zmm15,zmm14
   807ed:	62 93 8d 48 1e d7 01                            	vpcmpltuq k2,zmm14,zmm31
   807f4:	62 91 a5 4a db ee                               	vpandq zmm5{k2},zmm11,zmm30
   807fa:	62 71 8d 40 db 5c 24 0f                         	vpandq zmm11,zmm30,ZMMWORD PTR [rsp+0x3c0]
   80802:	62 91 bd 4a db d6                               	vpandq zmm2{k2},zmm8,zmm30
   80808:	62 91 9d 4a db de                               	vpandq zmm3{k2},zmm12,zmm30
   8080e:	62 91 95 4a db e6                               	vpandq zmm4{k2},zmm13,zmm30
   80814:	62 91 8d 4a db ce                               	vpandq zmm1{k2},zmm14,zmm30
   8081a:	62 f1 fd 49 7f 54 3a 05                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x140]{k1},zmm2
   80822:	62 f1 fd 49 7f 6c 3a 06                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x180]{k1},zmm5
   8082a:	62 f1 fd 49 7f 5c 3a 07                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x1c0]{k1},zmm3
   80832:	62 f1 fd 49 7f 64 3a 08                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x200]{k1},zmm4
   8083a:	62 f1 fd 49 7f 4c 3a 09                         	vmovdqa64 ZMMWORD PTR [rdx+rdi*1+0x240]{k1},zmm1
   80842:	0f 85 78 e9 ff ff                               	jne    7f1c0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x3970>
   80848:	e9 73 ca ff ff                                  	jmp    7d2c0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1a70>
   8084d:	0f 1f 00                                        	nop    DWORD PTR [rax]
   80850:	48 8b 84 24 88 00 00 00                         	mov    rax,QWORD PTR [rsp+0x88]
   80858:	48 8b 8c 24 90 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x90]
   80860:	48 89 8c 24 40 06 00 00                         	mov    QWORD PTR [rsp+0x640],rcx
   80868:	48 8b 8c 24 40 06 00 00                         	mov    rcx,QWORD PTR [rsp+0x640]
   80870:	48 8b 74 24 78                                  	mov    rsi,QWORD PTR [rsp+0x78]
   80875:	4c 8b 4c 24 48                                  	mov    r9,QWORD PTR [rsp+0x48]
   8087a:	48 85 c9                                        	test   rcx,rcx
   8087d:	0f 84 fd c0 ff ff                               	je     7c980 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1130>
   80883:	48 69 c9 c0 02 00 00                            	imul   rcx,rcx,0x2c0
   8088a:	48 01 c1                                        	add    rcx,rax
   8088d:	48 05 a1 02 00 00                               	add    rax,0x2a1
   80893:	eb 3f                                           	jmp    808d4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5084>
   80895:	66 66 2e 0f 1f 84 00 00 00 00 00                	data16 cs nop WORD PTR [rax+rax*1+0x0]
   808a0:	62 f3 fd 48 3b d0 01                            	vextracti64x4 ymm0,zmm2,0x1
   808a7:	c4 e3 55 46 c0 31                               	vperm2i128 ymm0,ymm5,ymm0,0x31
   808ad:	48 c1 e7 06                                     	shl    rdi,0x6
   808b1:	c4 c1 7e 7f 0c 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm1
   808b7:	c4 c1 7e 7f 44 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm0
   808be:	48 05 c0 02 00 00                               	add    rax,0x2c0
   808c4:	48 81 c2 c0 02 00 00                            	add    rdx,0x2c0
   808cb:	48 39 ca                                        	cmp    rdx,rcx
   808ce:	0f 84 ac c0 ff ff                               	je     7c980 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x1130>
   808d4:	c5 7c 28 1d c4 75 f8 ff                         	vmovaps ymm11,YMMWORD PTR [rip+0xfffffffffff875c4]        # 7ea0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x860>
   808dc:	62 f1 fd 48 6f 80 5f fd ff ff                   	vmovdqa64 zmm0,ZMMWORD PTR [rax-0x2a1]
   808e6:	62 72 fd 48 59 3d c8 6a f8 ff                   	vpbroadcastq zmm15,QWORD PTR [rip+0xfffffffffff86ac8]        # 73b8 <GCC_except_table740+0x170>
   808f0:	48 ba 31 e1 72 4e 64 30 00 00                   	movabs rdx,0x30644e72e131
   808fa:	62 f1 fd 48 6f 88 9f fd ff ff                   	vmovdqa64 zmm1,ZMMWORD PTR [rax-0x261]
   80904:	62 f1 fd 48 6f a0 df fd ff ff                   	vmovdqa64 zmm4,ZMMWORD PTR [rax-0x221]
   8090e:	62 f1 fd 48 6f a8 1f fe ff ff                   	vmovdqa64 zmm5,ZMMWORD PTR [rax-0x1e1]
   80918:	62 f1 fd 48 6f b0 5f fe ff ff                   	vmovdqa64 zmm6,ZMMWORD PTR [rax-0x1a1]
   80922:	62 e2 fd 48 59 15 04 6a f8 ff                   	vpbroadcastq zmm18,QWORD PTR [rip+0xfffffffffff86a04]        # 7330 <GCC_except_table740+0xe8>
   8092c:	62 e2 fd 48 59 0d 8a 69 f8 ff                   	vpbroadcastq zmm17,QWORD PTR [rip+0xfffffffffff8698a]        # 72c0 <GCC_except_table740+0x78>
   80936:	c5 7c 11 9c 24 80 01 00 00                      	vmovups YMMWORD PTR [rsp+0x180],ymm11
   8093f:	48 89 94 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rdx
   80947:	62 51 fd 48 d4 cf                               	vpaddq zmm9,zmm0,zmm15
   8094d:	62 f1 f5 58 fb 54 24 31                         	vpsubq zmm2,zmm1,QWORD BCST [rsp+0x188]
   80955:	62 f1 dd 58 fb 5c 24 32                         	vpsubq zmm3,zmm4,QWORD BCST [rsp+0x190]
   8095d:	62 f1 d5 58 fb 7c 24 33                         	vpsubq zmm7,zmm5,QWORD BCST [rsp+0x198]
   80965:	62 71 cd 58 fb 44 24 34                         	vpsubq zmm8,zmm6,QWORD BCST [rsp+0x1a0]
   8096d:	62 d1 ad 48 72 e1 34                            	vpsraq zmm10,zmm9,0x34
   80974:	62 e1 fd 48 6f 98 9f fe ff ff                   	vmovdqa64 zmm19,ZMMWORD PTR [rax-0x161]
   8097e:	62 71 fd 48 6f a0 5f ff ff ff                   	vmovdqa64 zmm12,ZMMWORD PTR [rax-0xa1]
   80988:	62 71 fd 48 6f a8 9f ff ff ff                   	vmovdqa64 zmm13,ZMMWORD PTR [rax-0x61]
   80992:	62 d1 ed 48 d4 d2                               	vpaddq zmm2,zmm2,zmm10
   80998:	62 51 e5 40 d4 ff                               	vpaddq zmm15,zmm19,zmm15
   8099e:	62 f1 ad 48 72 e2 34                            	vpsraq zmm10,zmm2,0x34
   809a5:	62 d1 fd 40 72 e7 34                            	vpsraq zmm16,zmm15,0x34
   809ac:	62 d1 e5 48 d4 da                               	vpaddq zmm3,zmm3,zmm10
   809b2:	62 f1 ad 48 72 e3 34                            	vpsraq zmm10,zmm3,0x34
   809b9:	62 d1 c5 48 d4 fa                               	vpaddq zmm7,zmm7,zmm10
   809bf:	62 f1 ad 48 72 e7 34                            	vpsraq zmm10,zmm7,0x34
   809c6:	62 51 bd 48 d4 c2                               	vpaddq zmm8,zmm8,zmm10
   809cc:	62 b3 bd 48 1e ca 01                            	vpcmpltuq k1,zmm8,zmm18
   809d3:	62 b1 ed 49 db c9                               	vpandq zmm1{k1},zmm2,zmm17
   809d9:	62 b1 e5 49 db e1                               	vpandq zmm4{k1},zmm3,zmm17
   809df:	62 b1 c5 49 db e9                               	vpandq zmm5{k1},zmm7,zmm17
   809e5:	62 b1 b5 49 db c1                               	vpandq zmm0{k1},zmm9,zmm17
   809eb:	62 d1 fd 49 6f f0                               	vmovdqa64 zmm6{k1},zmm8
   809f1:	62 f1 ed 48 73 f1 34                            	vpsllq zmm2,zmm1,0x34
   809f8:	62 f1 c5 48 73 f5 1c                            	vpsllq zmm7,zmm5,0x1c
   809ff:	62 f1 e5 48 73 f4 28                            	vpsllq zmm3,zmm4,0x28
   80a06:	62 f1 f5 48 73 d1 0c                            	vpsrlq zmm1,zmm1,0xc
   80a0d:	62 f1 ed 48 eb d0                               	vporq  zmm2,zmm2,zmm0
   80a13:	62 f1 fd 48 73 d4 18                            	vpsrlq zmm0,zmm4,0x18
   80a1a:	62 f1 dd 48 73 f6 10                            	vpsllq zmm4,zmm6,0x10
   80a21:	62 f1 fd 48 6f b0 1f ff ff ff                   	vmovdqa64 zmm6,ZMMWORD PTR [rax-0xe1]
   80a2b:	62 f1 e5 48 eb d9                               	vporq  zmm3,zmm3,zmm1
   80a31:	62 f1 c5 48 eb f8                               	vporq  zmm7,zmm7,zmm0
   80a37:	62 f1 fd 48 73 d5 24                            	vpsrlq zmm0,zmm5,0x24
   80a3e:	62 f1 fd 48 6f a8 df fe ff ff                   	vmovdqa64 zmm5,ZMMWORD PTR [rax-0x121]
   80a48:	c5 7c 11 9c 24 80 01 00 00                      	vmovups YMMWORD PTR [rsp+0x180],ymm11
   80a51:	48 89 94 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],rdx
   80a59:	ba ff ff ff ff                                  	mov    edx,0xffffffff
   80a5e:	62 71 d5 58 fb 4c 24 31                         	vpsubq zmm9,zmm5,QWORD BCST [rsp+0x188]
   80a66:	62 71 cd 58 fb 54 24 32                         	vpsubq zmm10,zmm6,QWORD BCST [rsp+0x190]
   80a6e:	62 71 9d 58 fb 5c 24 33                         	vpsubq zmm11,zmm12,QWORD BCST [rsp+0x198]
   80a76:	62 71 95 58 fb 74 24 34                         	vpsubq zmm14,zmm13,QWORD BCST [rsp+0x1a0]
   80a7e:	8b 78 df                                        	mov    edi,DWORD PTR [rax-0x21]
   80a81:	62 71 dd 48 eb c0                               	vporq  zmm8,zmm4,zmm0
   80a87:	62 f1 ed 48 6c e3                               	vpunpcklqdq zmm4,zmm2,zmm3
   80a8d:	62 d1 c5 48 6c c0                               	vpunpcklqdq zmm0,zmm7,zmm8
   80a93:	62 31 b5 48 d4 c8                               	vpaddq zmm9,zmm9,zmm16
   80a99:	62 d1 fd 40 72 e1 34                            	vpsraq zmm16,zmm9,0x34
   80aa0:	62 31 ad 48 d4 d0                               	vpaddq zmm10,zmm10,zmm16
   80aa6:	62 d1 fd 40 72 e2 34                            	vpsraq zmm16,zmm10,0x34
   80aad:	62 31 a5 48 d4 d8                               	vpaddq zmm11,zmm11,zmm16
   80ab3:	62 d1 fd 40 72 e3 34                            	vpsraq zmm16,zmm11,0x34
   80aba:	62 31 8d 48 d4 f0                               	vpaddq zmm14,zmm14,zmm16
   80ac0:	62 b3 8d 48 1e ca 01                            	vpcmpltuq k1,zmm14,zmm18
   80ac7:	62 b1 ad 49 db f1                               	vpandq zmm6{k1},zmm10,zmm17
   80acd:	62 31 a5 49 db e1                               	vpandq zmm12{k1},zmm11,zmm17
   80ad3:	62 b1 b5 49 db e9                               	vpandq zmm5{k1},zmm9,zmm17
   80ad9:	62 a1 85 49 db d9                               	vpandq zmm19{k1},zmm15,zmm17
   80adf:	62 51 fd 49 6f ee                               	vmovdqa64 zmm13{k1},zmm14
   80ae5:	62 f1 f5 48 73 d6 18                            	vpsrlq zmm1,zmm6,0x18
   80aec:	62 d1 a5 48 73 f4 1c                            	vpsllq zmm11,zmm12,0x1c
   80af3:	62 f1 b5 48 73 f5 34                            	vpsllq zmm9,zmm5,0x34
   80afa:	62 f1 ad 48 73 f6 28                            	vpsllq zmm10,zmm6,0x28
   80b01:	62 f1 d5 48 73 d5 0c                            	vpsrlq zmm5,zmm5,0xc
   80b08:	62 d1 cd 48 73 f5 10                            	vpsllq zmm6,zmm13,0x10
   80b0f:	62 71 a5 48 eb d9                               	vporq  zmm11,zmm11,zmm1
   80b15:	62 d1 f5 48 73 d4 24                            	vpsrlq zmm1,zmm12,0x24
   80b1c:	62 31 b5 48 eb cb                               	vporq  zmm9,zmm9,zmm19
   80b22:	62 71 ad 48 eb d5                               	vporq  zmm10,zmm10,zmm5
   80b28:	62 71 cd 48 eb e1                               	vporq  zmm12,zmm6,zmm1
   80b2e:	62 d1 b5 48 6c ea                               	vpunpcklqdq zmm5,zmm9,zmm10
   80b34:	62 d1 a5 48 6c cc                               	vpunpcklqdq zmm1,zmm11,zmm12
   80b3a:	48 39 d7                                        	cmp    rdi,rdx
   80b3d:	74 40                                           	je     80b7f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x532f>
   80b3f:	48 39 fe                                        	cmp    rsi,rdi
   80b42:	0f 86 0a 0a 00 00                               	jbe    81552 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d02>
   80b48:	f6 00 01                                        	test   BYTE PTR [rax],0x1
   80b4b:	c5 c9 ef f6                                     	vpxor  xmm6,xmm6,xmm6
   80b4f:	74 0f                                           	je     80b60 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5310>
   80b51:	c4 41 11 ef ed                                  	vpxor  xmm13,xmm13,xmm13
   80b56:	74 10                                           	je     80b68 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5318>
   80b58:	eb 14                                           	jmp    80b6e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x531e>
   80b5a:	66 0f 1f 44 00 00                               	nop    WORD PTR [rax+rax*1+0x0]
   80b60:	c4 63 5d 38 e8 01                               	vinserti128 ymm13,ymm4,xmm0,0x1
   80b66:	75 06                                           	jne    80b6e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x531e>
   80b68:	c4 e3 55 38 f1 01                               	vinserti128 ymm6,ymm5,xmm1,0x1
   80b6e:	48 c1 e7 06                                     	shl    rdi,0x6
   80b72:	c4 41 7e 7f 2c 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm13
   80b78:	c4 c1 7e 7f 74 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm6
   80b7f:	48 8d 90 5f fd ff ff                            	lea    rdx,[rax-0x2a1]
   80b86:	62 f1 ed 48 6d f3                               	vpunpckhqdq zmm6,zmm2,zmm3
   80b8c:	62 d1 c5 48 6d d8                               	vpunpckhqdq zmm3,zmm7,zmm8
   80b92:	62 d1 b5 48 6d fa                               	vpunpckhqdq zmm7,zmm9,zmm10
   80b98:	62 d1 a5 48 6d d4                               	vpunpckhqdq zmm2,zmm11,zmm12
   80b9e:	41 b8 ff ff ff ff                               	mov    r8d,0xffffffff
   80ba4:	8b ba 84 02 00 00                               	mov    edi,DWORD PTR [rdx+0x284]
   80baa:	4c 39 c7                                        	cmp    rdi,r8
   80bad:	74 40                                           	je     80bef <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x539f>
   80baf:	48 39 fe                                        	cmp    rsi,rdi
   80bb2:	0f 86 9a 09 00 00                               	jbe    81552 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d02>
   80bb8:	f6 00 02                                        	test   BYTE PTR [rax],0x2
   80bbb:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   80bc0:	74 0e                                           	je     80bd0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5380>
   80bc2:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80bc7:	74 0f                                           	je     80bd8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5388>
   80bc9:	eb 13                                           	jmp    80bde <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x538e>
   80bcb:	0f 1f 44 00 00                                  	nop    DWORD PTR [rax+rax*1+0x0]
   80bd0:	c4 63 4d 38 cb 01                               	vinserti128 ymm9,ymm6,xmm3,0x1
   80bd6:	75 06                                           	jne    80bde <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x538e>
   80bd8:	c4 63 45 38 c2 01                               	vinserti128 ymm8,ymm7,xmm2,0x1
   80bde:	48 c1 e7 06                                     	shl    rdi,0x6
   80be2:	c4 41 7e 7f 0c 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm9
   80be8:	c4 41 7e 7f 44 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm8
   80bef:	8b ba 88 02 00 00                               	mov    edi,DWORD PTR [rdx+0x288]
   80bf5:	4c 39 c7                                        	cmp    rdi,r8
   80bf8:	74 45                                           	je     80c3f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x53ef>
   80bfa:	48 39 fe                                        	cmp    rsi,rdi
   80bfd:	0f 86 4f 09 00 00                               	jbe    81552 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d02>
   80c03:	f6 00 04                                        	test   BYTE PTR [rax],0x4
   80c06:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   80c0b:	74 13                                           	je     80c20 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x53d0>
   80c0d:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80c12:	74 14                                           	je     80c28 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x53d8>
   80c14:	eb 18                                           	jmp    80c2e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x53de>
   80c16:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   80c20:	c4 63 5d 46 c8 31                               	vperm2i128 ymm9,ymm4,ymm0,0x31
   80c26:	75 06                                           	jne    80c2e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x53de>
   80c28:	c4 63 55 46 c1 31                               	vperm2i128 ymm8,ymm5,ymm1,0x31
   80c2e:	48 c1 e7 06                                     	shl    rdi,0x6
   80c32:	c4 41 7e 7f 0c 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm9
   80c38:	c4 41 7e 7f 44 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm8
   80c3f:	8b ba 8c 02 00 00                               	mov    edi,DWORD PTR [rdx+0x28c]
   80c45:	4c 39 c7                                        	cmp    rdi,r8
   80c48:	74 45                                           	je     80c8f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x543f>
   80c4a:	48 39 fe                                        	cmp    rsi,rdi
   80c4d:	0f 86 ff 08 00 00                               	jbe    81552 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d02>
   80c53:	f6 00 08                                        	test   BYTE PTR [rax],0x8
   80c56:	c4 41 39 ef c0                                  	vpxor  xmm8,xmm8,xmm8
   80c5b:	74 13                                           	je     80c70 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5420>
   80c5d:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80c62:	74 14                                           	je     80c78 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5428>
   80c64:	eb 18                                           	jmp    80c7e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x542e>
   80c66:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   80c70:	c4 63 4d 46 cb 31                               	vperm2i128 ymm9,ymm6,ymm3,0x31
   80c76:	75 06                                           	jne    80c7e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x542e>
   80c78:	c4 63 45 46 c2 31                               	vperm2i128 ymm8,ymm7,ymm2,0x31
   80c7e:	48 c1 e7 06                                     	shl    rdi,0x6
   80c82:	c4 41 7e 7f 0c 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm9
   80c88:	c4 41 7e 7f 44 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm8
   80c8f:	8b ba 90 02 00 00                               	mov    edi,DWORD PTR [rdx+0x290]
   80c95:	62 d3 fd 48 3b e0 01                            	vextracti64x4 ymm8,zmm4,0x1
   80c9c:	62 f3 fd 48 3b ec 01                            	vextracti64x4 ymm4,zmm5,0x1
   80ca3:	4c 39 c7                                        	cmp    rdi,r8
   80ca6:	74 55                                           	je     80cfd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x54ad>
   80ca8:	48 39 fe                                        	cmp    rsi,rdi
   80cab:	0f 86 a1 08 00 00                               	jbe    81552 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d02>
   80cb1:	f6 00 10                                        	test   BYTE PTR [rax],0x10
   80cb4:	c5 d1 ef ed                                     	vpxor  xmm5,xmm5,xmm5
   80cb8:	74 16                                           	je     80cd0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5480>
   80cba:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80cbf:	74 1e                                           	je     80cdf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x548f>
   80cc1:	eb 29                                           	jmp    80cec <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x549c>
   80cc3:	66 66 66 66 2e 0f 1f 84 00 00 00 00 00          	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   80cd0:	62 d3 7d 48 39 c1 02                            	vextracti32x4 xmm9,zmm0,0x2
   80cd7:	c4 43 3d 38 c9 01                               	vinserti128 ymm9,ymm8,xmm9,0x1
   80cdd:	75 0d                                           	jne    80cec <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x549c>
   80cdf:	62 f3 7d 48 39 cd 02                            	vextracti32x4 xmm5,zmm1,0x2
   80ce6:	c4 e3 5d 38 ed 01                               	vinserti128 ymm5,ymm4,xmm5,0x1
   80cec:	48 c1 e7 06                                     	shl    rdi,0x6
   80cf0:	c4 41 7e 7f 0c 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm9
   80cf6:	c4 c1 7e 7f 6c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm5
   80cfd:	8b ba 94 02 00 00                               	mov    edi,DWORD PTR [rdx+0x294]
   80d03:	62 f3 fd 48 3b f6 01                            	vextracti64x4 ymm6,zmm6,0x1
   80d0a:	62 f3 fd 48 3b fd 01                            	vextracti64x4 ymm5,zmm7,0x1
   80d11:	4c 39 c7                                        	cmp    rdi,r8
   80d14:	74 57                                           	je     80d6d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x551d>
   80d16:	48 39 fe                                        	cmp    rsi,rdi
   80d19:	0f 86 33 08 00 00                               	jbe    81552 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d02>
   80d1f:	f6 00 20                                        	test   BYTE PTR [rax],0x20
   80d22:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   80d26:	74 18                                           	je     80d40 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x54f0>
   80d28:	c4 41 31 ef c9                                  	vpxor  xmm9,xmm9,xmm9
   80d2d:	74 20                                           	je     80d4f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x54ff>
   80d2f:	eb 2b                                           	jmp    80d5c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x550c>
   80d31:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00    	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   80d40:	62 d3 7d 48 39 d9 02                            	vextracti32x4 xmm9,zmm3,0x2
   80d47:	c4 43 4d 38 c9 01                               	vinserti128 ymm9,ymm6,xmm9,0x1
   80d4d:	75 0d                                           	jne    80d5c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x550c>
   80d4f:	62 f3 7d 48 39 d7 02                            	vextracti32x4 xmm7,zmm2,0x2
   80d56:	c4 e3 55 38 ff 01                               	vinserti128 ymm7,ymm5,xmm7,0x1
   80d5c:	48 c1 e7 06                                     	shl    rdi,0x6
   80d60:	c4 41 7e 7f 0c 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm9
   80d66:	c4 c1 7e 7f 7c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm7
   80d6d:	8b ba 98 02 00 00                               	mov    edi,DWORD PTR [rdx+0x298]
   80d73:	4c 39 c7                                        	cmp    rdi,r8
   80d76:	74 55                                           	je     80dcd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x557d>
   80d78:	48 39 fe                                        	cmp    rsi,rdi
   80d7b:	0f 86 d1 07 00 00                               	jbe    81552 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d02>
   80d81:	f6 00 40                                        	test   BYTE PTR [rax],0x40
   80d84:	c5 c1 ef ff                                     	vpxor  xmm7,xmm7,xmm7
   80d88:	74 16                                           	je     80da0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5550>
   80d8a:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   80d8e:	74 1f                                           	je     80daf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x555f>
   80d90:	eb 2a                                           	jmp    80dbc <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x556c>
   80d92:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   80da0:	62 f3 fd 48 3b c0 01                            	vextracti64x4 ymm0,zmm0,0x1
   80da7:	c4 e3 3d 46 c0 31                               	vperm2i128 ymm0,ymm8,ymm0,0x31
   80dad:	75 0d                                           	jne    80dbc <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x556c>
   80daf:	62 f3 fd 48 3b c9 01                            	vextracti64x4 ymm1,zmm1,0x1
   80db6:	c4 e3 5d 46 f9 31                               	vperm2i128 ymm7,ymm4,ymm1,0x31
   80dbc:	48 c1 e7 06                                     	shl    rdi,0x6
   80dc0:	c4 c1 7e 7f 04 39                               	vmovdqu YMMWORD PTR [r9+rdi*1],ymm0
   80dc6:	c4 c1 7e 7f 7c 39 20                            	vmovdqu YMMWORD PTR [r9+rdi*1+0x20],ymm7
   80dcd:	8b ba 9c 02 00 00                               	mov    edi,DWORD PTR [rdx+0x29c]
   80dd3:	4c 39 c7                                        	cmp    rdi,r8
   80dd6:	0f 84 e2 fa ff ff                               	je     808be <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x506e>
   80ddc:	48 39 fe                                        	cmp    rsi,rdi
   80ddf:	0f 86 6d 07 00 00                               	jbe    81552 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d02>
   80de5:	80 38 00                                        	cmp    BYTE PTR [rax],0x0
   80de8:	c5 f9 ef c0                                     	vpxor  xmm0,xmm0,xmm0
   80dec:	79 12                                           	jns    80e00 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x55b0>
   80dee:	c5 f1 ef c9                                     	vpxor  xmm1,xmm1,xmm1
   80df2:	0f 88 b5 fa ff ff                               	js     808ad <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x505d>
   80df8:	e9 a3 fa ff ff                                  	jmp    808a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5050>
   80dfd:	0f 1f 00                                        	nop    DWORD PTR [rax]
   80e00:	62 f3 fd 48 3b d9 01                            	vextracti64x4 ymm1,zmm3,0x1
   80e07:	c4 e3 4d 46 c9 31                               	vperm2i128 ymm1,ymm6,ymm1,0x31
   80e0d:	0f 88 9a fa ff ff                               	js     808ad <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x505d>
   80e13:	e9 88 fa ff ff                                  	jmp    808a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5050>
   80e18:	48 8b 84 24 80 00 00 00                         	mov    rax,QWORD PTR [rsp+0x80]
   80e20:	4c 8b b4 24 a0 00 00 00                         	mov    r14,QWORD PTR [rsp+0xa0]
   80e28:	48 85 c0                                        	test   rax,rax
   80e2b:	74 55                                           	je     80e82 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5632>
   80e2d:	48 8b 9c 24 88 00 00 00                         	mov    rbx,QWORD PTR [rsp+0x88]
   80e35:	48 3d ba 00 00 00                               	cmp    rax,0xba
   80e3b:	76 39                                           	jbe    80e76 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5626>
   80e3d:	48 69 c0 c0 02 00 00                            	imul   rax,rax,0x2c0
   80e44:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   80e4e:	48 83 c1 c8                                     	add    rcx,0xffffffffffffffc8
   80e52:	48 89 c6                                        	mov    rsi,rax
   80e55:	48 83 ce 01                                     	or     rsi,0x1
   80e59:	48 39 ce                                        	cmp    rsi,rcx
   80e5c:	0f 83 f1 0c 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   80e62:	80 3c 03 01                                     	cmp    BYTE PTR [rbx+rax*1],0x1
   80e66:	75 0e                                           	jne    80e76 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5626>
   80e68:	48 89 df                                        	mov    rdi,rbx
   80e6b:	c5 f8 77                                        	vzeroupper
   80e6e:	ff 15 d4 84 01 00                               	call   QWORD PTR [rip+0x184d4]        # 99348 <munmap@GLIBC_2.2.5>
   80e74:	eb 0c                                           	jmp    80e82 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5632>
   80e76:	48 89 df                                        	mov    rdi,rbx
   80e79:	c5 f8 77                                        	vzeroupper
   80e7c:	ff 15 ce 84 01 00                               	call   QWORD PTR [rip+0x184ce]        # 99350 <free@GLIBC_2.2.5>
   80e82:	48 8b 84 24 e8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xe8]
   80e8a:	48 85 c0                                        	test   rax,rax
   80e8d:	74 4a                                           	je     80ed9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5689>
   80e8f:	48 8b bc 24 f0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xf0]
   80e97:	48 83 f8 7f                                     	cmp    rax,0x7f
   80e9b:	76 33                                           	jbe    80ed0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5680>
   80e9d:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   80ea7:	48 c1 e0 0a                                     	shl    rax,0xa
   80eab:	48 89 c6                                        	mov    rsi,rax
   80eae:	48 83 ce 01                                     	or     rsi,0x1
   80eb2:	48 83 c1 c8                                     	add    rcx,0xffffffffffffffc8
   80eb6:	48 39 ce                                        	cmp    rsi,rcx
   80eb9:	0f 83 94 0c 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   80ebf:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   80ec3:	75 0b                                           	jne    80ed0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5680>
   80ec5:	c5 f8 77                                        	vzeroupper
   80ec8:	ff 15 7a 84 01 00                               	call   QWORD PTR [rip+0x1847a]        # 99348 <munmap@GLIBC_2.2.5>
   80ece:	eb 09                                           	jmp    80ed9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5689>
   80ed0:	c5 f8 77                                        	vzeroupper
   80ed3:	ff 15 77 84 01 00                               	call   QWORD PTR [rip+0x18477]        # 99350 <free@GLIBC_2.2.5>
   80ed9:	48 8b 5c 24 78                                  	mov    rbx,QWORD PTR [rsp+0x78]
   80ede:	4d 85 f6                                        	test   r14,r14
   80ee1:	74 50                                           	je     80f33 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x56e3>
   80ee3:	49 81 fe ff 7f 00 00                            	cmp    r14,0x7fff
   80eea:	76 3b                                           	jbe    80f27 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x56d7>
   80eec:	4a 8d 04 b5 00 00 00 00                         	lea    rax,[r14*4+0x0]
   80ef4:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   80efe:	48 83 c1 04                                     	add    rcx,0x4
   80f02:	48 89 c6                                        	mov    rsi,rax
   80f05:	48 83 ce 01                                     	or     rsi,0x1
   80f09:	48 39 ce                                        	cmp    rsi,rcx
   80f0c:	0f 83 41 0c 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   80f12:	41 80 3c 04 01                                  	cmp    BYTE PTR [r12+rax*1],0x1
   80f17:	75 0e                                           	jne    80f27 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x56d7>
   80f19:	4c 89 e7                                        	mov    rdi,r12
   80f1c:	c5 f8 77                                        	vzeroupper
   80f1f:	ff 15 23 84 01 00                               	call   QWORD PTR [rip+0x18423]        # 99348 <munmap@GLIBC_2.2.5>
   80f25:	eb 0c                                           	jmp    80f33 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x56e3>
   80f27:	4c 89 e7                                        	mov    rdi,r12
   80f2a:	c5 f8 77                                        	vzeroupper
   80f2d:	ff 15 1d 84 01 00                               	call   QWORD PTR [rip+0x1841d]        # 99350 <free@GLIBC_2.2.5>
   80f33:	48 8b 84 24 d0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xd0]
   80f3b:	4c 8b b4 24 98 00 00 00                         	mov    r14,QWORD PTR [rsp+0x98]
   80f43:	48 85 c0                                        	test   rax,rax
   80f46:	74 48                                           	je     80f90 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5740>
   80f48:	48 8b bc 24 d8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xd8]
   80f50:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   80f56:	76 2f                                           	jbe    80f87 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5737>
   80f58:	48 c1 e0 03                                     	shl    rax,0x3
   80f5c:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   80f66:	48 89 c6                                        	mov    rsi,rax
   80f69:	48 83 ce 01                                     	or     rsi,0x1
   80f6d:	48 39 ce                                        	cmp    rsi,rcx
   80f70:	0f 83 dd 0b 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   80f76:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   80f7a:	75 0b                                           	jne    80f87 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5737>
   80f7c:	c5 f8 77                                        	vzeroupper
   80f7f:	ff 15 c3 83 01 00                               	call   QWORD PTR [rip+0x183c3]        # 99348 <munmap@GLIBC_2.2.5>
   80f85:	eb 09                                           	jmp    80f90 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5740>
   80f87:	c5 f8 77                                        	vzeroupper
   80f8a:	ff 15 c0 83 01 00                               	call   QWORD PTR [rip+0x183c0]        # 99350 <free@GLIBC_2.2.5>
   80f90:	48 8b b4 24 a8 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xa8]
   80f98:	48 85 f6                                        	test   rsi,rsi
   80f9b:	74 45                                           	je     80fe2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5792>
   80f9d:	48 8b bc 24 b0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xb0]
   80fa5:	48 81 fe ff ff 01 00                            	cmp    rsi,0x1ffff
   80fac:	76 2b                                           	jbe    80fd9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5789>
   80fae:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   80fb8:	48 83 c0 06                                     	add    rax,0x6
   80fbc:	48 39 c6                                        	cmp    rsi,rax
   80fbf:	0f 83 8e 0b 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   80fc5:	80 3c 37 01                                     	cmp    BYTE PTR [rdi+rsi*1],0x1
   80fc9:	75 0e                                           	jne    80fd9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5789>
   80fcb:	48 ff c6                                        	inc    rsi
   80fce:	c5 f8 77                                        	vzeroupper
   80fd1:	ff 15 71 83 01 00                               	call   QWORD PTR [rip+0x18371]        # 99348 <munmap@GLIBC_2.2.5>
   80fd7:	eb 09                                           	jmp    80fe2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5792>
   80fd9:	c5 f8 77                                        	vzeroupper
   80fdc:	ff 15 6e 83 01 00                               	call   QWORD PTR [rip+0x1836e]        # 99350 <free@GLIBC_2.2.5>
   80fe2:	4d 85 f6                                        	test   r14,r14
   80fe5:	74 50                                           	je     81037 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x57e7>
   80fe7:	49 81 fe ff 7f 00 00                            	cmp    r14,0x7fff
   80fee:	76 39                                           	jbe    81029 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x57d9>
   80ff0:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   80ffa:	49 c1 e6 02                                     	shl    r14,0x2
   80ffe:	4c 89 f6                                        	mov    rsi,r14
   81001:	48 83 ce 01                                     	or     rsi,0x1
   81005:	48 83 c0 04                                     	add    rax,0x4
   81009:	48 39 c6                                        	cmp    rsi,rax
   8100c:	0f 83 41 0b 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   81012:	48 8b 7c 24 70                                  	mov    rdi,QWORD PTR [rsp+0x70]
   81017:	42 80 3c 37 01                                  	cmp    BYTE PTR [rdi+r14*1],0x1
   8101c:	75 10                                           	jne    8102e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x57de>
   8101e:	c5 f8 77                                        	vzeroupper
   81021:	ff 15 21 83 01 00                               	call   QWORD PTR [rip+0x18321]        # 99348 <munmap@GLIBC_2.2.5>
   81027:	eb 0e                                           	jmp    81037 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x57e7>
   81029:	48 8b 7c 24 70                                  	mov    rdi,QWORD PTR [rsp+0x70]
   8102e:	c5 f8 77                                        	vzeroupper
   81031:	ff 15 19 83 01 00                               	call   QWORD PTR [rip+0x18319]        # 99350 <free@GLIBC_2.2.5>
   81037:	41 89 dd                                        	mov    r13d,ebx
   8103a:	4e 8d 34 ad 00 00 00 00                         	lea    r14,[r13*4+0x0]
   81042:	4d 85 ed                                        	test   r13,r13
   81045:	0f 84 c8 00 00 00                               	je     81113 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x58c3>
   8104b:	4c 89 f7                                        	mov    rdi,r14
   8104e:	41 81 fd 00 80 00 00                            	cmp    r13d,0x8000
   81055:	0f 82 c3 00 00 00                               	jb     8111e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x58ce>
   8105b:	48 83 cf 01                                     	or     rdi,0x1
   8105f:	c5 f8 77                                        	vzeroupper
   81062:	ff 15 00 83 01 00                               	call   QWORD PTR [rip+0x18300]        # 99368 <malloc@GLIBC_2.2.5>
   81068:	48 85 c0                                        	test   rax,rax
   8106b:	0f 84 5f 06 00 00                               	je     816d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e80>
   81071:	49 89 c7                                        	mov    r15,rax
   81074:	42 c6 04 30 00                                  	mov    BYTE PTR [rax+r14*1],0x0
   81079:	62 f1 fd 48 6f 05 3d 6b f8 ff                   	vmovdqa64 zmm0,ZMMWORD PTR [rip+0xfffffffffff86b3d]        # 7bc0 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x580>
   81083:	62 f2 7d 48 58 0d bb 70 f8 ff                   	vpbroadcastd zmm1,DWORD PTR [rip+0xfffffffffff870bb]        # 8148 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb08>
   8108d:	62 f2 7d 48 58 15 c9 70 f8 ff                   	vpbroadcastd zmm2,DWORD PTR [rip+0xfffffffffff870c9]        # 8160 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb20>
   81097:	62 f2 7d 48 58 1d cf 70 f8 ff                   	vpbroadcastd zmm3,DWORD PTR [rip+0xfffffffffff870cf]        # 8170 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb30>
   810a1:	62 f2 7d 48 58 25 d5 70 f8 ff                   	vpbroadcastd zmm4,DWORD PTR [rip+0xfffffffffff870d5]        # 8180 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb40>
   810ab:	89 d8                                           	mov    eax,ebx
   810ad:	83 e0 c0                                        	and    eax,0xffffffc0
   810b0:	31 c9                                           	xor    ecx,ecx
   810b2:	66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   810c0:	62 f1 7d 48 fe e9                               	vpaddd zmm5,zmm0,zmm1
   810c6:	62 f1 7d 48 fe f2                               	vpaddd zmm6,zmm0,zmm2
   810cc:	62 f1 7d 48 fe fb                               	vpaddd zmm7,zmm0,zmm3
   810d2:	62 d1 fe 48 7f 04 8f                            	vmovdqu64 ZMMWORD PTR [r15+rcx*4],zmm0
   810d9:	62 f1 7d 48 fe c4                               	vpaddd zmm0,zmm0,zmm4
   810df:	62 d1 fe 48 7f 6c 8f 01                         	vmovdqu64 ZMMWORD PTR [r15+rcx*4+0x40],zmm5
   810e7:	62 d1 fe 48 7f 74 8f 02                         	vmovdqu64 ZMMWORD PTR [r15+rcx*4+0x80],zmm6
   810ef:	62 d1 fe 48 7f 7c 8f 03                         	vmovdqu64 ZMMWORD PTR [r15+rcx*4+0xc0],zmm7
   810f7:	48 83 c1 40                                     	add    rcx,0x40
   810fb:	48 39 c8                                        	cmp    rax,rcx
   810fe:	75 c0                                           	jne    810c0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5870>
   81100:	41 39 c5                                        	cmp    r13d,eax
   81103:	0f 84 93 00 00 00                               	je     8119c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x594c>
   81109:	f6 c3 38                                        	test   bl,0x38
   8110c:	75 3b                                           	jne    81149 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x58f9>
   8110e:	e9 7d 00 00 00                                  	jmp    81190 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5940>
   81113:	41 bf 04 00 00 00                               	mov    r15d,0x4
   81119:	e9 7e 00 00 00                                  	jmp    8119c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x594c>
   8111e:	c5 f8 77                                        	vzeroupper
   81121:	ff 15 41 82 01 00                               	call   QWORD PTR [rip+0x18241]        # 99368 <malloc@GLIBC_2.2.5>
   81127:	48 85 c0                                        	test   rax,rax
   8112a:	0f 84 a0 05 00 00                               	je     816d0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e80>
   81130:	49 89 c7                                        	mov    r15,rax
   81133:	41 83 fd 08                                     	cmp    r13d,0x8
   81137:	73 04                                           	jae    8113d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x58ed>
   81139:	31 c0                                           	xor    eax,eax
   8113b:	eb 53                                           	jmp    81190 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5940>
   8113d:	41 83 fd 40                                     	cmp    r13d,0x40
   81141:	0f 83 32 ff ff ff                               	jae    81079 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5829>
   81147:	31 c0                                           	xor    eax,eax
   81149:	48 89 c1                                        	mov    rcx,rax
   8114c:	62 f2 7d 28 7c c1                               	vpbroadcastd ymm0,ecx
   81152:	c5 fd eb 05 06 6d f8 ff                         	vpor   ymm0,ymm0,YMMWORD PTR [rip+0xfffffffffff86d06]        # 7e60 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x820>
   8115a:	c4 e2 7d 58 0d 01 70 f8 ff                      	vpbroadcastd ymm1,DWORD PTR [rip+0xfffffffffff87001]        # 8164 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0xb24>
   81163:	89 d8                                           	mov    eax,ebx
   81165:	83 e0 f8                                        	and    eax,0xfffffff8
   81168:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   81170:	c4 c1 7e 7f 04 8f                               	vmovdqu YMMWORD PTR [r15+rcx*4],ymm0
   81176:	48 83 c1 08                                     	add    rcx,0x8
   8117a:	c5 fd fe c1                                     	vpaddd ymm0,ymm0,ymm1
   8117e:	48 39 c8                                        	cmp    rax,rcx
   81181:	75 ed                                           	jne    81170 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5920>
   81183:	41 39 c5                                        	cmp    r13d,eax
   81186:	74 14                                           	je     8119c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x594c>
   81188:	0f 1f 84 00 00 00 00 00                         	nop    DWORD PTR [rax+rax*1+0x0]
   81190:	41 89 04 87                                     	mov    DWORD PTR [r15+rax*4],eax
   81194:	48 ff c0                                        	inc    rax
   81197:	49 39 c5                                        	cmp    r13,rax
   8119a:	75 f4                                           	jne    81190 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5940>
   8119c:	48 8b 4c 24 48                                  	mov    rcx,QWORD PTR [rsp+0x48]
   811a1:	4c 89 b4 24 c0 03 00 00                         	mov    QWORD PTR [rsp+0x3c0],r14
   811a9:	48 89 d8                                        	mov    rax,rbx
   811ac:	48 8b 9c 24 70 01 00 00                         	mov    rbx,QWORD PTR [rsp+0x170]
   811b4:	4c 8b b4 24 78 01 00 00                         	mov    r14,QWORD PTR [rsp+0x178]
   811bc:	bf 01 00 02 00                                  	mov    edi,0x20001
   811c1:	48 89 8c 24 40 0c 00 00                         	mov    QWORD PTR [rsp+0xc40],rcx
   811c9:	48 89 84 24 48 0c 00 00                         	mov    QWORD PTR [rsp+0xc48],rax
   811d1:	c5 f8 77                                        	vzeroupper
   811d4:	ff 15 8e 81 01 00                               	call   QWORD PTR [rip+0x1818e]        # 99368 <malloc@GLIBC_2.2.5>
   811da:	48 85 c0                                        	test   rax,rax
   811dd:	0f 84 d1 04 00 00                               	je     816b4 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e64>
   811e3:	49 89 c4                                        	mov    r12,rax
   811e6:	48 89 84 24 80 01 00 00                         	mov    QWORD PTR [rsp+0x180],rax
   811ee:	c6 80 00 00 02 00 00                            	mov    BYTE PTR [rax+0x20000],0x0
   811f5:	48 8b 8c 24 c0 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xc0]
   811fd:	64 48 8b 04 25 d8 ff ff ff                      	mov    rax,QWORD PTR fs:0xffffffffffffffd8
   81206:	48 8d 94 24 40 0c 00 00                         	lea    rdx,[rsp+0xc40]
   8120e:	48 c7 84 24 88 01 00 00 00 08 00 00             	mov    QWORD PTR [rsp+0x188],0x800
   8121a:	48 c7 84 24 90 01 00 00 00 01 00 00             	mov    QWORD PTR [rsp+0x190],0x100
   81226:	48 89 9c 24 98 01 00 00                         	mov    QWORD PTR [rsp+0x198],rbx
   8122e:	4c 89 b4 24 a0 01 00 00                         	mov    QWORD PTR [rsp+0x1a0],r14
   81236:	4c 89 bc 24 a8 01 00 00                         	mov    QWORD PTR [rsp+0x1a8],r15
   8123e:	4c 89 ac 24 b0 01 00 00                         	mov    QWORD PTR [rsp+0x1b0],r13
   81246:	4c 89 a4 24 00 04 00 00                         	mov    QWORD PTR [rsp+0x400],r12
   8124e:	48 c7 84 24 08 04 00 00 00 08 00 00             	mov    QWORD PTR [rsp+0x408],0x800
   8125a:	48 c7 84 24 10 04 00 00 00 01 00 00             	mov    QWORD PTR [rsp+0x410],0x100
   81266:	48 c7 84 24 18 04 00 00 00 00 00 00             	mov    QWORD PTR [rsp+0x418],0x0
   81272:	48 89 94 24 b8 01 00 00                         	mov    QWORD PTR [rsp+0x1b8],rdx
   8127a:	48 89 8c 24 c0 01 00 00                         	mov    QWORD PTR [rsp+0x1c0],rcx
   81282:	48 c7 84 24 c8 01 00 00 00 08 00 00             	mov    QWORD PTR [rsp+0x1c8],0x800
   8128e:	48 85 c0                                        	test   rax,rax
   81291:	74 08                                           	je     8129b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5a4b>
   81293:	48 05 10 01 00 00                               	add    rax,0x110
   81299:	eb 05                                           	jmp    812a0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5a50>
   8129b:	e8 e0 f4 fb ff                                  	call   40780 <_RNvNtCs8zaw6vLE3tn_10rayon_core8registry15global_registry>
   812a0:	48 8b 00                                        	mov    rax,QWORD PTR [rax]
   812a3:	48 8d 8c 24 98 01 00 00                         	lea    rcx,[rsp+0x198]
   812ab:	4c 8d 8c 24 d0 01 00 00                         	lea    r9,[rsp+0x1d0]
   812b3:	48 8b 90 08 02 00 00                            	mov    rdx,QWORD PTR [rax+0x208]
   812ba:	48 89 0c 24                                     	mov    QWORD PTR [rsp],rcx
   812be:	4c 8d 84 24 00 04 00 00                         	lea    r8,[rsp+0x400]
   812c6:	bf 08 00 00 00                                  	mov    edi,0x8
   812cb:	b9 01 00 00 00                                  	mov    ecx,0x1
   812d0:	31 f6                                           	xor    esi,esi
   812d2:	e8 79 a6 00 00                                  	call   8b950 <_RINvNvNtNtCsc3XWelWpAp8_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks17ChunksMutProducerINtNtNtCsgxBkk5gSRhY_4core3mem12maybe_uninit11MaybeUninitINtNtCsgHCcee0nhgM_11zopro_bn2545curve6AffineNtB3s_8G1ConfigEEEEINtNtB6_8map_with15MapInitConsumerNtNtB6_4noop12NoopConsumerNCINvNtCsHW5vo2gROj_10zopro_core3msm17group_affine_implB48_NCINvB5u_12group_affineB48_E0E0NCB5r_s_0EEB5w_>
   812d7:	48 8b 84 24 58 01 00 00                         	mov    rax,QWORD PTR [rsp+0x158]
   812df:	4c 8b 74 24 58                                  	mov    r14,QWORD PTR [rsp+0x58]
   812e4:	48 c7 00 00 08 00 00                            	mov    QWORD PTR [rax],0x800
   812eb:	4c 89 60 08                                     	mov    QWORD PTR [rax+0x8],r12
   812ef:	48 c7 40 10 00 08 00 00                         	mov    QWORD PTR [rax+0x10],0x800
   812f7:	4d 85 ed                                        	test   r13,r13
   812fa:	74 30                                           	je     8132c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5adc>
   812fc:	41 81 fd ff 7f 00 00                            	cmp    r13d,0x7fff
   81303:	76 1e                                           	jbe    81323 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ad3>
   81305:	48 8b b4 24 c0 03 00 00                         	mov    rsi,QWORD PTR [rsp+0x3c0]
   8130d:	41 80 3c 37 01                                  	cmp    BYTE PTR [r15+rsi*1],0x1
   81312:	75 0f                                           	jne    81323 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ad3>
   81314:	48 83 ce 01                                     	or     rsi,0x1
   81318:	4c 89 ff                                        	mov    rdi,r15
   8131b:	ff 15 27 80 01 00                               	call   QWORD PTR [rip+0x18027]        # 99348 <munmap@GLIBC_2.2.5>
   81321:	eb 09                                           	jmp    8132c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5adc>
   81323:	4c 89 ff                                        	mov    rdi,r15
   81326:	ff 15 24 80 01 00                               	call   QWORD PTR [rip+0x18024]        # 99350 <free@GLIBC_2.2.5>
   8132c:	49 81 fe ff ff 01 00                            	cmp    r14,0x1ffff
   81333:	76 2e                                           	jbe    81363 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5b13>
   81335:	4c 89 f6                                        	mov    rsi,r14
   81338:	48 83 ce 01                                     	or     rsi,0x1
   8133c:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   81346:	48 39 c6                                        	cmp    rsi,rax
   81349:	0f 83 04 08 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   8134f:	48 8b 7c 24 48                                  	mov    rdi,QWORD PTR [rsp+0x48]
   81354:	42 80 3c 37 01                                  	cmp    BYTE PTR [rdi+r14*1],0x1
   81359:	75 0d                                           	jne    81368 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5b18>
   8135b:	ff 15 e7 7f 01 00                               	call   QWORD PTR [rip+0x17fe7]        # 99348 <munmap@GLIBC_2.2.5>
   81361:	eb 0b                                           	jmp    8136e <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5b1e>
   81363:	48 8b 7c 24 48                                  	mov    rdi,QWORD PTR [rsp+0x48]
   81368:	ff 15 e2 7f 01 00                               	call   QWORD PTR [rip+0x17fe2]        # 99350 <free@GLIBC_2.2.5>
   8136e:	48 8b 84 24 68 01 00 00                         	mov    rax,QWORD PTR [rsp+0x168]
   81376:	48 85 c0                                        	test   rax,rax
   81379:	74 4b                                           	je     813c6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5b76>
   8137b:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   81381:	76 3a                                           	jbe    813bd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5b6d>
   81383:	48 c1 e0 03                                     	shl    rax,0x3
   81387:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   81391:	48 89 c6                                        	mov    rsi,rax
   81394:	48 83 ce 01                                     	or     rsi,0x1
   81398:	48 39 ce                                        	cmp    rsi,rcx
   8139b:	0f 83 b2 07 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   813a1:	80 3c 03 01                                     	cmp    BYTE PTR [rbx+rax*1],0x1
   813a5:	75 16                                           	jne    813bd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5b6d>
   813a7:	48 89 df                                        	mov    rdi,rbx
   813aa:	ff 15 98 7f 01 00                               	call   QWORD PTR [rip+0x17f98]        # 99348 <munmap@GLIBC_2.2.5>
   813b0:	48 8b bc 24 c0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc0]
   813b8:	e9 90 ad ff ff                                  	jmp    7c14d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8fd>
   813bd:	48 89 df                                        	mov    rdi,rbx
   813c0:	ff 15 8a 7f 01 00                               	call   QWORD PTR [rip+0x17f8a]        # 99350 <free@GLIBC_2.2.5>
   813c6:	48 8b bc 24 c0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc0]
   813ce:	e9 7a ad ff ff                                  	jmp    7c14d <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x8fd>
   813d3:	48 8d 3d 0b 1a f9 ff                            	lea    rdi,[rip+0xfffffffffff91a0b]        # 12de5 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x4665>
   813da:	48 8d 15 87 7a 01 00                            	lea    rdx,[rip+0x17a87]        # 98e68 <__frame_dummy_init_array_entry+0x2818>
   813e1:	be 26 00 00 00                                  	mov    esi,0x26
   813e6:	c5 f8 77                                        	vzeroupper
   813e9:	e8 f2 07 fb ff                                  	call   31be0 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
   813ee:	e9 ea 02 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   813f3:	48 8d 0d ee 7b 01 00                            	lea    rcx,[rip+0x17bee]        # 98fe8 <__frame_dummy_init_array_entry+0x2998>
   813fa:	be 00 08 00 00                                  	mov    esi,0x800
   813ff:	31 ff                                           	xor    edi,edi
   81401:	48 89 da                                        	mov    rdx,rbx
   81404:	e8 07 07 fb ff                                  	call   31b10 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
   81409:	e9 cf 02 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   8140e:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   81413:	49 89 f7                                        	mov    r15,rsi
   81416:	48 8d 15 23 79 01 00                            	lea    rdx,[rip+0x17923]        # 98d40 <__frame_dummy_init_array_entry+0x26f0>
   8141d:	e9 d3 00 00 00                                  	jmp    814f5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ca5>
   81422:	48 8d 0d 87 7a 01 00                            	lea    rcx,[rip+0x17a87]        # 98eb0 <__frame_dummy_init_array_entry+0x2860>
   81429:	48 8d bc 24 38 06 00 00                         	lea    rdi,[rsp+0x638]
   81431:	48 8d b4 24 80 01 00 00                         	lea    rsi,[rsp+0x180]
   81439:	31 d2                                           	xor    edx,edx
   8143b:	e8 c2 fd fa ff                                  	call   31202 <_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedjjEB4_>
   81440:	48 8d 3d c4 19 f9 ff                            	lea    rdi,[rip+0xfffffffffff919c4]        # 12e0b <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x468b>
   81447:	48 8d 15 7a 7a 01 00                            	lea    rdx,[rip+0x17a7a]        # 98ec8 <__frame_dummy_init_array_entry+0x2878>
   8144e:	be 2d 00 00 00                                  	mov    esi,0x2d
   81453:	e8 88 07 fb ff                                  	call   31be0 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
   81458:	48 8d 3d d9 19 f9 ff                            	lea    rdi,[rip+0xfffffffffff919d9]        # 12e38 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x46b8>
   8145f:	48 8d 15 7a 7a 01 00                            	lea    rdx,[rip+0x17a7a]        # 98ee0 <__frame_dummy_init_array_entry+0x2890>
   81466:	be 18 00 00 00                                  	mov    esi,0x18
   8146b:	e8 70 07 fb ff                                  	call   31be0 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
   81470:	4c 8b 7c 24 50                                  	mov    r15,QWORD PTR [rsp+0x50]
   81475:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   8147a:	48 8d 15 a7 78 01 00                            	lea    rdx,[rip+0x178a7]        # 98d28 <__frame_dummy_init_array_entry+0x26d8>
   81481:	eb 72                                           	jmp    814f5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ca5>
   81483:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   81488:	48 8d 15 81 78 01 00                            	lea    rdx,[rip+0x17881]        # 98d10 <__frame_dummy_init_array_entry+0x26c0>
   8148f:	eb 64                                           	jmp    814f5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ca5>
   81491:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   81496:	4d 89 cf                                        	mov    r15,r9
   81499:	48 8d 15 00 79 01 00                            	lea    rdx,[rip+0x17900]        # 98da0 <__frame_dummy_init_array_entry+0x2750>
   814a0:	eb 53                                           	jmp    814f5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ca5>
   814a2:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   814a7:	48 8d 15 aa 78 01 00                            	lea    rdx,[rip+0x178aa]        # 98d58 <__frame_dummy_init_array_entry+0x2708>
   814ae:	eb 45                                           	jmp    814f5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ca5>
   814b0:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   814b5:	4d 89 f7                                        	mov    r15,r14
   814b8:	48 8d 15 b1 78 01 00                            	lea    rdx,[rip+0x178b1]        # 98d70 <__frame_dummy_init_array_entry+0x2720>
   814bf:	eb 34                                           	jmp    814f5 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ca5>
   814c1:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   814c6:	48 8d 3d 83 19 f9 ff                            	lea    rdi,[rip+0xfffffffffff91983]        # 12e50 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x46d0>
   814cd:	48 8d 15 54 7a 01 00                            	lea    rdx,[rip+0x17a54]        # 98f28 <__frame_dummy_init_array_entry+0x28d8>
   814d4:	be 25 00 00 00                                  	mov    esi,0x25
   814d9:	c5 f8 77                                        	vzeroupper
   814dc:	e8 ff 06 fb ff                                  	call   31be0 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
   814e1:	e9 f7 01 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   814e6:	49 89 df                                        	mov    r15,rbx
   814e9:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   814ee:	48 8d 15 93 78 01 00                            	lea    rdx,[rip+0x17893]        # 98d88 <__frame_dummy_init_array_entry+0x2738>
   814f5:	4c 89 fe                                        	mov    rsi,r15
   814f8:	c5 f8 77                                        	vzeroupper
   814fb:	e8 14 f9 fa ff                                  	call   30e14 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   81500:	e9 d8 01 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   81505:	62 71 fd 48 7f 5c 24 06                         	vmovdqa64 ZMMWORD PTR [rsp+0x180],zmm11
   8150d:	62 71 fd 48 7f 54 24 07                         	vmovdqa64 ZMMWORD PTR [rsp+0x1c0],zmm10
   81515:	62 f1 fd 48 7f 74 24 08                         	vmovdqa64 ZMMWORD PTR [rsp+0x200],zmm6
   8151d:	62 f1 fd 48 7f 7c 24 09                         	vmovdqa64 ZMMWORD PTR [rsp+0x240],zmm7
   81525:	62 f1 fd 48 7f 44 24 0a                         	vmovdqa64 ZMMWORD PTR [rsp+0x280],zmm0
   8152d:	48 8d 15 6c 7a 01 00                            	lea    rdx,[rip+0x17a6c]        # 98fa0 <__frame_dummy_init_array_entry+0x2950>
   81534:	eb 23                                           	jmp    81559 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d09>
   81536:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   8153b:	48 8d 15 2e 7a 01 00                            	lea    rdx,[rip+0x17a2e]        # 98f70 <__frame_dummy_init_array_entry+0x2920>
   81542:	eb 15                                           	jmp    81559 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d09>
   81544:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   81549:	48 8d 15 38 7a 01 00                            	lea    rdx,[rip+0x17a38]        # 98f88 <__frame_dummy_init_array_entry+0x2938>
   81550:	eb 07                                           	jmp    81559 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d09>
   81552:	48 8d 15 ff 79 01 00                            	lea    rdx,[rip+0x179ff]        # 98f58 <__frame_dummy_init_array_entry+0x2908>
   81559:	c5 f8 77                                        	vzeroupper
   8155c:	e8 b3 f8 fa ff                                  	call   30e14 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   81561:	e9 77 01 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   81566:	4c 8b 7c 24 60                                  	mov    r15,QWORD PTR [rsp+0x60]
   8156b:	e9 79 ff ff ff                                  	jmp    814e9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5c99>
   81570:	49 8d 7a ff                                     	lea    rdi,[r10-0x1]
   81574:	48 8d 15 85 7a 01 00                            	lea    rdx,[rip+0x17a85]        # 99000 <__frame_dummy_init_array_entry+0x29b0>
   8157b:	be 00 08 00 00                                  	mov    esi,0x800
   81580:	c5 f8 77                                        	vzeroupper
   81583:	e8 8c f8 fa ff                                  	call   30e14 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   81588:	e9 50 01 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   8158d:	48 8d 15 3c 7a 01 00                            	lea    rdx,[rip+0x17a3c]        # 98fd0 <__frame_dummy_init_array_entry+0x2980>
   81594:	eb 10                                           	jmp    815a6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d56>
   81596:	49 ff cc                                        	dec    r12
   81599:	b8 00 08 00 00                                  	mov    eax,0x800
   8159e:	48 89 44 24 50                                  	mov    QWORD PTR [rsp+0x50],rax
   815a3:	4c 89 e7                                        	mov    rdi,r12
   815a6:	41 b7 01                                        	mov    r15b,0x1
   815a9:	48 8b 74 24 50                                  	mov    rsi,QWORD PTR [rsp+0x50]
   815ae:	c5 f8 77                                        	vzeroupper
   815b1:	e8 5e f8 fa ff                                  	call   30e14 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   815b6:	e9 22 01 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   815bb:	be 09 00 00 00                                  	mov    esi,0x9
   815c0:	eb 09                                           	jmp    815cb <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d7b>
   815c2:	4c 89 f6                                        	mov    rsi,r14
   815c5:	4c 89 cf                                        	mov    rdi,r9
   815c8:	48 89 c2                                        	mov    rdx,rax
   815cb:	c5 f8 77                                        	vzeroupper
   815ce:	e8 41 f8 fa ff                                  	call   30e14 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   815d3:	e9 05 01 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   815d8:	bf 08 00 00 00                                  	mov    edi,0x8
   815dd:	be 00 40 00 00                                  	mov    esi,0x4000
   815e2:	e8 ba dc fa ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   815e7:	bf 08 00 00 00                                  	mov    edi,0x8
   815ec:	be 00 40 00 00                                  	mov    esi,0x4000
   815f1:	e8 ab dc fa ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   815f6:	e9 e2 00 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   815fb:	48 8d 15 f6 78 01 00                            	lea    rdx,[rip+0x178f6]        # 98ef8 <__frame_dummy_init_array_entry+0x28a8>
   81602:	bf 00 08 00 00                                  	mov    edi,0x800
   81607:	be 00 08 00 00                                  	mov    esi,0x800
   8160c:	e8 03 f8 fa ff                                  	call   30e14 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   81611:	e9 c7 00 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   81616:	48 8d 15 23 79 01 00                            	lea    rdx,[rip+0x17923]        # 98f40 <__frame_dummy_init_array_entry+0x28f0>
   8161d:	e9 37 ff ff ff                                  	jmp    81559 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5d09>
   81622:	45 31 ff                                        	xor    r15d,r15d
   81625:	bf 08 00 00 00                                  	mov    edi,0x8
   8162a:	be 00 40 00 00                                  	mov    esi,0x4000
   8162f:	e8 6d dc fa ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   81634:	e9 a4 00 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   81639:	48 8d 15 d0 78 01 00                            	lea    rdx,[rip+0x178d0]        # 98f10 <__frame_dummy_init_array_entry+0x28c0>
   81640:	bf 00 08 00 00                                  	mov    edi,0x800
   81645:	e8 ca f7 fa ff                                  	call   30e14 <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
   8164a:	e9 8e 00 00 00                                  	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   8164f:	bf 04 00 00 00                                  	mov    edi,0x4
   81654:	e9 33 a4 ff ff                                  	jmp    7ba8c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x23c>
   81659:	be 00 00 02 00                                  	mov    esi,0x20000
   8165e:	41 be 08 00 00 00                               	mov    r14d,0x8
   81664:	e9 16 a8 ff ff                                  	jmp    7be7f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62f>
   81669:	4c 8b 64 24 38                                  	mov    r12,QWORD PTR [rsp+0x38]
   8166e:	bf 01 00 00 00                                  	mov    edi,0x1
   81673:	48 89 de                                        	mov    rsi,rbx
   81676:	e8 26 dc fa ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   8167b:	eb 60                                           	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   8167d:	41 be 08 00 00 00                               	mov    r14d,0x8
   81683:	e9 f4 a7 ff ff                                  	jmp    7be7c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62c>
   81688:	bf 40 00 00 00                                  	mov    edi,0x40
   8168d:	be c0 44 00 00                                  	mov    esi,0x44c0
   81692:	e8 0a dc fa ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   81697:	eb 44                                           	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   81699:	bf 40 00 00 00                                  	mov    edi,0x40
   8169e:	be 00 64 00 00                                  	mov    esi,0x6400
   816a3:	e8 f9 db fa ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   816a8:	eb 33                                           	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   816aa:	bf 04 00 00 00                                  	mov    edi,0x4
   816af:	e9 3a ae ff ff                                  	jmp    7c4ee <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xc9e>
   816b4:	bf 08 00 00 00                                  	mov    edi,0x8
   816b9:	be 00 00 02 00                                  	mov    esi,0x20000
   816be:	e8 de db fa ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   816c3:	eb 18                                           	jmp    816dd <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5e8d>
   816c5:	41 be 08 00 00 00                               	mov    r14d,0x8
   816cb:	e9 0e b0 ff ff                                  	jmp    7c6de <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0xe8e>
   816d0:	bf 04 00 00 00                                  	mov    edi,0x4
   816d5:	4c 89 f6                                        	mov    rsi,r14
   816d8:	e8 c4 db fa ff                                  	call   2f2a1 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
   816dd:	0f 0b                                           	ud2
   816df:	48 89 c3                                        	mov    rbx,rax
   816e2:	eb 34                                           	jmp    81718 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ec8>
   816e4:	48 89 c3                                        	mov    rbx,rax
   816e7:	eb 15                                           	jmp    816fe <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5eae>
   816e9:	be 00 00 02 00                                  	mov    esi,0x20000
   816ee:	ba 08 00 00 00                                  	mov    edx,0x8
   816f3:	4c 89 e7                                        	mov    rdi,r12
   816f6:	48 89 c3                                        	mov    rbx,rax
   816f9:	e8 e2 18 fa ff                                  	call   22fe0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   816fe:	4d 85 ed                                        	test   r13,r13
   81701:	74 15                                           	je     81718 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5ec8>
   81703:	48 8b b4 24 c0 03 00 00                         	mov    rsi,QWORD PTR [rsp+0x3c0]
   8170b:	ba 04 00 00 00                                  	mov    edx,0x4
   81710:	4c 89 ff                                        	mov    rdi,r15
   81713:	e8 c8 18 fa ff                                  	call   22fe0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   81718:	48 8b 7c 24 48                                  	mov    rdi,QWORD PTR [rsp+0x48]
   8171d:	48 8b 74 24 58                                  	mov    rsi,QWORD PTR [rsp+0x58]
   81722:	ba 08 00 00 00                                  	mov    edx,0x8
   81727:	e8 b4 18 fa ff                                  	call   22fe0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   8172c:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   81731:	4c 8b 64 24 38                                  	mov    r12,QWORD PTR [rsp+0x38]
   81736:	45 31 ff                                        	xor    r15d,r15d
   81739:	45 31 f6                                        	xor    r14d,r14d
   8173c:	48 8b 84 24 68 01 00 00                         	mov    rax,QWORD PTR [rsp+0x168]
   81744:	48 85 c0                                        	test   rax,rax
   81747:	0f 84 09 03 00 00                               	je     81a56 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6206>
   8174d:	e9 c2 02 00 00                                  	jmp    81a14 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x61c4>
   81752:	48 89 c3                                        	mov    rbx,rax
   81755:	e9 36 01 00 00                                  	jmp    81890 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6040>
   8175a:	48 89 c3                                        	mov    rbx,rax
   8175d:	e9 84 01 00 00                                  	jmp    818e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6096>
   81762:	48 89 c3                                        	mov    rbx,rax
   81765:	41 b6 01                                        	mov    r14b,0x1
   81768:	e9 23 02 00 00                                  	jmp    81990 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6140>
   8176d:	48 89 df                                        	mov    rdi,rbx
   81770:	48 89 c3                                        	mov    rbx,rax
   81773:	ff 15 d7 7b 01 00                               	call   QWORD PTR [rip+0x17bd7]        # 99350 <free@GLIBC_2.2.5>
   81779:	41 b6 01                                        	mov    r14b,0x1
   8177c:	e9 e8 02 00 00                                  	jmp    81a69 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6219>
   81781:	48 83 bc 24 98 00 00 00 00                      	cmp    QWORD PTR [rsp+0x98],0x0
   8178a:	48 89 c3                                        	mov    rbx,rax
   8178d:	74 1b                                           	je     817aa <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f5a>
   8178f:	48 8b b4 24 98 00 00 00                         	mov    rsi,QWORD PTR [rsp+0x98]
   81797:	48 8b 7c 24 70                                  	mov    rdi,QWORD PTR [rsp+0x70]
   8179c:	ba 04 00 00 00                                  	mov    edx,0x4
   817a1:	48 c1 e6 02                                     	shl    rsi,0x2
   817a5:	e8 36 18 fa ff                                  	call   22fe0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   817aa:	45 31 f6                                        	xor    r14d,r14d
   817ad:	eb 29                                           	jmp    817d8 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5f88>
   817af:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   817b4:	4c 8b 64 24 38                                  	mov    r12,QWORD PTR [rsp+0x38]
   817b9:	41 b6 01                                        	mov    r14b,0x1
   817bc:	48 89 c3                                        	mov    rbx,rax
   817bf:	e9 a8 02 00 00                                  	jmp    81a6c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x621c>
   817c4:	48 89 c3                                        	mov    rbx,rax
   817c7:	e9 76 03 00 00                                  	jmp    81b42 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62f2>
   817cc:	eb 37                                           	jmp    81805 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5fb5>
   817ce:	eb 35                                           	jmp    81805 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5fb5>
   817d0:	eb 33                                           	jmp    81805 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5fb5>
   817d2:	48 89 c3                                        	mov    rbx,rax
   817d5:	41 b6 01                                        	mov    r14b,0x1
   817d8:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   817dd:	4c 8b 64 24 38                                  	mov    r12,QWORD PTR [rsp+0x38]
   817e2:	e9 5d 01 00 00                                  	jmp    81944 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60f4>
   817e7:	48 89 c3                                        	mov    rbx,rax
   817ea:	48 8b 84 24 00 06 00 00                         	mov    rax,QWORD PTR [rsp+0x600]
   817f2:	48 85 c0                                        	test   rax,rax
   817f5:	0f 85 09 03 00 00                               	jne    81b04 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62b4>
   817fb:	e9 42 03 00 00                                  	jmp    81b42 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62f2>
   81800:	4c 8b 64 24 38                                  	mov    r12,QWORD PTR [rsp+0x38]
   81805:	48 89 c3                                        	mov    rbx,rax
   81808:	48 8b 7c 24 48                                  	mov    rdi,QWORD PTR [rsp+0x48]
   8180d:	48 8b 74 24 58                                  	mov    rsi,QWORD PTR [rsp+0x58]
   81812:	ba 08 00 00 00                                  	mov    edx,0x8
   81817:	e8 c4 17 fa ff                                  	call   22fe0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   8181c:	4c 8b 6c 24 30                                  	mov    r13,QWORD PTR [rsp+0x30]
   81821:	eb 1c                                           	jmp    8183f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5fef>
   81823:	48 8b 7c 24 48                                  	mov    rdi,QWORD PTR [rsp+0x48]
   81828:	48 8b 74 24 58                                  	mov    rsi,QWORD PTR [rsp+0x58]
   8182d:	ba 08 00 00 00                                  	mov    edx,0x8
   81832:	48 89 c3                                        	mov    rbx,rax
   81835:	e8 a6 17 fa ff                                  	call   22fe0 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
   8183a:	eb 03                                           	jmp    8183f <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x5fef>
   8183c:	48 89 c3                                        	mov    rbx,rax
   8183f:	48 8b 84 24 e8 00 00 00                         	mov    rax,QWORD PTR [rsp+0xe8]
   81847:	48 85 c0                                        	test   rax,rax
   8184a:	74 44                                           	je     81890 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6040>
   8184c:	48 8b bc 24 f0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xf0]
   81854:	48 83 f8 7f                                     	cmp    rax,0x7f
   81858:	76 30                                           	jbe    8188a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x603a>
   8185a:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   81864:	48 c1 e0 0a                                     	shl    rax,0xa
   81868:	48 89 c6                                        	mov    rsi,rax
   8186b:	48 83 ce 01                                     	or     rsi,0x1
   8186f:	48 83 c1 c8                                     	add    rcx,0xffffffffffffffc8
   81873:	48 39 ce                                        	cmp    rsi,rcx
   81876:	0f 83 d7 02 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   8187c:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   81880:	75 08                                           	jne    8188a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x603a>
   81882:	ff 15 c0 7a 01 00                               	call   QWORD PTR [rip+0x17ac0]        # 99348 <munmap@GLIBC_2.2.5>
   81888:	eb 06                                           	jmp    81890 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6040>
   8188a:	ff 15 c0 7a 01 00                               	call   QWORD PTR [rip+0x17ac0]        # 99350 <free@GLIBC_2.2.5>
   81890:	48 8b 84 24 80 00 00 00                         	mov    rax,QWORD PTR [rsp+0x80]
   81898:	48 85 c0                                        	test   rax,rax
   8189b:	74 49                                           	je     818e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6096>
   8189d:	48 8b bc 24 88 00 00 00                         	mov    rdi,QWORD PTR [rsp+0x88]
   818a5:	48 3d ba 00 00 00                               	cmp    rax,0xba
   818ab:	76 33                                           	jbe    818e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6090>
   818ad:	48 69 c0 c0 02 00 00                            	imul   rax,rax,0x2c0
   818b4:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   818be:	48 83 c1 c8                                     	add    rcx,0xffffffffffffffc8
   818c2:	48 89 c6                                        	mov    rsi,rax
   818c5:	48 83 ce 01                                     	or     rsi,0x1
   818c9:	48 39 ce                                        	cmp    rsi,rcx
   818cc:	0f 83 81 02 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   818d2:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   818d6:	75 08                                           	jne    818e0 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6090>
   818d8:	ff 15 6a 7a 01 00                               	call   QWORD PTR [rip+0x17a6a]        # 99348 <munmap@GLIBC_2.2.5>
   818de:	eb 06                                           	jmp    818e6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6096>
   818e0:	ff 15 6a 7a 01 00                               	call   QWORD PTR [rip+0x17a6a]        # 99350 <free@GLIBC_2.2.5>
   818e6:	48 8b 8c 24 98 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x98]
   818ee:	48 85 c9                                        	test   rcx,rcx
   818f1:	74 4e                                           	je     81941 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60f1>
   818f3:	48 81 f9 ff 7f 00 00                            	cmp    rcx,0x7fff
   818fa:	76 35                                           	jbe    81931 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60e1>
   818fc:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   81906:	48 c1 e1 02                                     	shl    rcx,0x2
   8190a:	48 89 ce                                        	mov    rsi,rcx
   8190d:	48 83 ce 01                                     	or     rsi,0x1
   81911:	48 83 c0 04                                     	add    rax,0x4
   81915:	48 39 c6                                        	cmp    rsi,rax
   81918:	0f 83 35 02 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   8191e:	48 8b 7c 24 70                                  	mov    rdi,QWORD PTR [rsp+0x70]
   81923:	80 3c 0f 01                                     	cmp    BYTE PTR [rdi+rcx*1],0x1
   81927:	75 0d                                           	jne    81936 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60e6>
   81929:	ff 15 19 7a 01 00                               	call   QWORD PTR [rip+0x17a19]        # 99348 <munmap@GLIBC_2.2.5>
   8192f:	eb 10                                           	jmp    81941 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60f1>
   81931:	48 8b 7c 24 70                                  	mov    rdi,QWORD PTR [rsp+0x70]
   81936:	ff 15 14 7a 01 00                               	call   QWORD PTR [rip+0x17a14]        # 99350 <free@GLIBC_2.2.5>
   8193c:	eb 03                                           	jmp    81941 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x60f1>
   8193e:	48 89 c3                                        	mov    rbx,rax
   81941:	45 31 f6                                        	xor    r14d,r14d
   81944:	48 8b b4 24 a8 00 00 00                         	mov    rsi,QWORD PTR [rsp+0xa8]
   8194c:	48 85 f6                                        	test   rsi,rsi
   8194f:	74 3f                                           	je     81990 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6140>
   81951:	48 8b bc 24 b0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xb0]
   81959:	48 81 fe ff ff 01 00                            	cmp    rsi,0x1ffff
   81960:	76 28                                           	jbe    8198a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x613a>
   81962:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   8196c:	48 83 c0 06                                     	add    rax,0x6
   81970:	48 39 c6                                        	cmp    rsi,rax
   81973:	0f 83 da 01 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   81979:	80 3c 37 01                                     	cmp    BYTE PTR [rdi+rsi*1],0x1
   8197d:	75 0b                                           	jne    8198a <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x613a>
   8197f:	48 ff c6                                        	inc    rsi
   81982:	ff 15 c0 79 01 00                               	call   QWORD PTR [rip+0x179c0]        # 99348 <munmap@GLIBC_2.2.5>
   81988:	eb 06                                           	jmp    81990 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6140>
   8198a:	ff 15 c0 79 01 00                               	call   QWORD PTR [rip+0x179c0]        # 99350 <free@GLIBC_2.2.5>
   81990:	48 8b 84 24 d0 00 00 00                         	mov    rax,QWORD PTR [rsp+0xd0]
   81998:	41 b7 01                                        	mov    r15b,0x1
   8199b:	48 85 c0                                        	test   rax,rax
   8199e:	74 4f                                           	je     819ef <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x619f>
   819a0:	48 8b bc 24 d8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xd8]
   819a8:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   819ae:	76 39                                           	jbe    819e9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6199>
   819b0:	48 c1 e0 03                                     	shl    rax,0x3
   819b4:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   819be:	48 89 c6                                        	mov    rsi,rax
   819c1:	48 83 ce 01                                     	or     rsi,0x1
   819c5:	48 39 ce                                        	cmp    rsi,rcx
   819c8:	0f 83 85 01 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   819ce:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   819d2:	75 15                                           	jne    819e9 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6199>
   819d4:	ff 15 6e 79 01 00                               	call   QWORD PTR [rip+0x1796e]        # 99348 <munmap@GLIBC_2.2.5>
   819da:	48 8b 84 24 68 01 00 00                         	mov    rax,QWORD PTR [rsp+0x168]
   819e2:	48 85 c0                                        	test   rax,rax
   819e5:	74 6f                                           	je     81a56 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6206>
   819e7:	eb 2b                                           	jmp    81a14 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x61c4>
   819e9:	ff 15 61 79 01 00                               	call   QWORD PTR [rip+0x17961]        # 99350 <free@GLIBC_2.2.5>
   819ef:	48 8b 84 24 68 01 00 00                         	mov    rax,QWORD PTR [rsp+0x168]
   819f7:	48 85 c0                                        	test   rax,rax
   819fa:	74 5a                                           	je     81a56 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6206>
   819fc:	eb 16                                           	jmp    81a14 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x61c4>
   819fe:	41 b7 01                                        	mov    r15b,0x1
   81a01:	41 b6 01                                        	mov    r14b,0x1
   81a04:	48 89 c3                                        	mov    rbx,rax
   81a07:	48 8b 84 24 68 01 00 00                         	mov    rax,QWORD PTR [rsp+0x168]
   81a0f:	48 85 c0                                        	test   rax,rax
   81a12:	74 42                                           	je     81a56 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6206>
   81a14:	48 8b bc 24 70 01 00 00                         	mov    rdi,QWORD PTR [rsp+0x170]
   81a1c:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   81a22:	76 2c                                           	jbe    81a50 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6200>
   81a24:	48 c1 e0 03                                     	shl    rax,0x3
   81a28:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   81a32:	48 89 c6                                        	mov    rsi,rax
   81a35:	48 83 ce 01                                     	or     rsi,0x1
   81a39:	48 39 ce                                        	cmp    rsi,rcx
   81a3c:	0f 83 11 01 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   81a42:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   81a46:	75 08                                           	jne    81a50 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6200>
   81a48:	ff 15 fa 78 01 00                               	call   QWORD PTR [rip+0x178fa]        # 99348 <munmap@GLIBC_2.2.5>
   81a4e:	eb 06                                           	jmp    81a56 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6206>
   81a50:	ff 15 fa 78 01 00                               	call   QWORD PTR [rip+0x178fa]        # 99350 <free@GLIBC_2.2.5>
   81a56:	48 8b bc 24 c0 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc0]
   81a5e:	ff 15 ec 78 01 00                               	call   QWORD PTR [rip+0x178ec]        # 99350 <free@GLIBC_2.2.5>
   81a64:	45 84 ff                                        	test   r15b,r15b
   81a67:	74 69                                           	je     81ad2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6282>
   81a69:	45 31 ff                                        	xor    r15d,r15d
   81a6c:	48 8b 8c 24 a0 00 00 00                         	mov    rcx,QWORD PTR [rsp+0xa0]
   81a74:	48 85 c9                                        	test   rcx,rcx
   81a77:	74 46                                           	je     81abf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x626f>
   81a79:	48 81 f9 ff 7f 00 00                            	cmp    rcx,0x7fff
   81a80:	76 34                                           	jbe    81ab6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6266>
   81a82:	48 b8 f9 ff ff ff ff ff ff 7f                   	movabs rax,0x7ffffffffffffff9
   81a8c:	48 c1 e1 02                                     	shl    rcx,0x2
   81a90:	48 89 ce                                        	mov    rsi,rcx
   81a93:	48 83 ce 01                                     	or     rsi,0x1
   81a97:	48 83 c0 04                                     	add    rax,0x4
   81a9b:	48 39 c6                                        	cmp    rsi,rax
   81a9e:	0f 83 af 00 00 00                               	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   81aa4:	41 80 3c 0c 01                                  	cmp    BYTE PTR [r12+rcx*1],0x1
   81aa9:	75 0b                                           	jne    81ab6 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6266>
   81aab:	4c 89 e7                                        	mov    rdi,r12
   81aae:	ff 15 94 78 01 00                               	call   QWORD PTR [rip+0x17894]        # 99348 <munmap@GLIBC_2.2.5>
   81ab4:	eb 09                                           	jmp    81abf <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x626f>
   81ab6:	4c 89 e7                                        	mov    rdi,r12
   81ab9:	ff 15 91 78 01 00                               	call   QWORD PTR [rip+0x17891]        # 99350 <free@GLIBC_2.2.5>
   81abf:	45 84 ff                                        	test   r15b,r15b
   81ac2:	74 0e                                           	je     81ad2 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6282>
   81ac4:	48 8b bc 24 c8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc8]
   81acc:	ff 15 7e 78 01 00                               	call   QWORD PTR [rip+0x1787e]        # 99350 <free@GLIBC_2.2.5>
   81ad2:	45 84 f6                                        	test   r14b,r14b
   81ad5:	74 74                                           	je     81b4b <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62fb>
   81ad7:	48 8b 84 24 00 06 00 00                         	mov    rax,QWORD PTR [rsp+0x600]
   81adf:	48 85 c0                                        	test   rax,rax
   81ae2:	75 20                                           	jne    81b04 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62b4>
   81ae4:	eb 5c                                           	jmp    81b42 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62f2>
   81ae6:	48 8b bc 24 c8 00 00 00                         	mov    rdi,QWORD PTR [rsp+0xc8]
   81aee:	48 89 c3                                        	mov    rbx,rax
   81af1:	ff 15 59 78 01 00                               	call   QWORD PTR [rip+0x17859]        # 99350 <free@GLIBC_2.2.5>
   81af7:	48 8b 84 24 00 06 00 00                         	mov    rax,QWORD PTR [rsp+0x600]
   81aff:	48 85 c0                                        	test   rax,rax
   81b02:	74 3e                                           	je     81b42 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62f2>
   81b04:	48 8b bc 24 08 06 00 00                         	mov    rdi,QWORD PTR [rsp+0x608]
   81b0c:	48 3d ff 3f 00 00                               	cmp    rax,0x3fff
   81b12:	76 28                                           	jbe    81b3c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62ec>
   81b14:	48 c1 e0 03                                     	shl    rax,0x3
   81b18:	48 b9 f9 ff ff ff ff ff ff 7f                   	movabs rcx,0x7ffffffffffffff9
   81b22:	48 89 c6                                        	mov    rsi,rax
   81b25:	48 83 ce 01                                     	or     rsi,0x1
   81b29:	48 39 ce                                        	cmp    rsi,rcx
   81b2c:	73 25                                           	jae    81b53 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x6303>
   81b2e:	80 3c 07 01                                     	cmp    BYTE PTR [rdi+rax*1],0x1
   81b32:	75 08                                           	jne    81b3c <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62ec>
   81b34:	ff 15 0e 78 01 00                               	call   QWORD PTR [rip+0x1780e]        # 99348 <munmap@GLIBC_2.2.5>
   81b3a:	eb 06                                           	jmp    81b42 <_RNvNtNtNtCsHW5vo2gROj_10zopro_core10msm_affine16borrowed_pending7columns4fill+0x62f2>
   81b3c:	ff 15 0e 78 01 00                               	call   QWORD PTR [rip+0x1780e]        # 99350 <free@GLIBC_2.2.5>
   81b42:	4c 89 ef                                        	mov    rdi,r13
   81b45:	ff 15 05 78 01 00                               	call   QWORD PTR [rip+0x17805]        # 99350 <free@GLIBC_2.2.5>
   81b4b:	48 89 df                                        	mov    rdi,rbx
   81b4e:	e8 ad 3a 01 00                                  	call   95600 <_Unwind_Resume@plt>
   81b53:	c5 f8 77                                        	vzeroupper
   81b56:	e8 c5 79 fc ff                                  	call   49520 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
