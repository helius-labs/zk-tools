use serde_json::{json, Value};
use std::{fmt::Write, fs, path::Path, process::Command};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g1-column-tiles176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn archive(out: &Path, r: &Path, files: &[&str]) {
    assert!(Command::new("tar")
        .args([
            "--sort=name",
            "--mtime=@0",
            "--owner=0",
            "--group=0",
            "--numeric-owner",
            "--exclude=*-sdk",
            "-czf"
        ])
        .arg(out)
        .arg("-C")
        .arg(r)
        .args(files)
        .status()
        .unwrap()
        .success());
}
fn main() {
    let r = Path::new(R);
    let d = Path::new(Z).join("docs/benchmarks/2026-10-30-g1-column-tiles176");
    assert!(!d.exists());
    let a = read(r.join("analysis.json"));
    assert_eq!(a["caller_gate_passed"], false);
    assert_eq!(read(r.join("review.json"))["passed"], true);
    fs::create_dir_all(d.join("artifacts")).unwrap();
    for n in [
        "analysis.json",
        "symbols.json",
        "review.json",
        "review.log",
        "codegen.json",
        "counts.json",
        "source-audit.json",
        "design.md",
        "capture-design.md",
    ] {
        fs::copy(r.join(n), d.join("artifacts").join(n)).unwrap();
    }
    let mut text=String::from("# Bounded native G1 column tiles\n\n**The complete-filler gate fails; no adoption.** The32-worker aggregate is1.003706[0.994900,1.028885],5/15winning blocks. The interval crosses parity and five of six context nonregression checks fail. The favorable1x2estimate remains in the table; it is not promoted independently. Production source176, accepted proof latency and ledger27,353 are unchanged.\n\nThe prior all-column/circular-wave implementation remains rejected. This follow-up changes the active-state lifetime and topology: process at most25cohorts/200partial segments to completion, export them, then reuse their native storage for the next tile. Replace comparison sorting with a stable eight-bin partition, preserving the exact descending-population/ascending-ID order. It removes the global CSR wave schedule and all-segment native coordinate allocation. Field/range helpers, segment size8, point formula, exception fallback and final partial-merge topology remain exact.\n\n## Count and memory tradeoff\n\nThe changed-path layout test checks sizeof(Column)=704 and sizeof(Record)=1024 on this target. Capacities bound native columns to17,600bytes and records to25,600bytes per active filler. Exported partial G1points, indices, maps, allocator overhead, merge workspace and compiler frames remain additional. This is not a43.2KB total memory bound or minimumRAM claim. The full partial-point output array remains live alongside each active tile.\n\nStable partition and tiled scheduling preserve the cohort order and linear vector-update/addition totals on all42ordinary rawA windows. Local tile boundaries add linear inversion stages:\n\n| Raw shape | Original ordinary additions including merges | Prior global linear waves | New tiled linear waves | Change |\n|---|---:|---:|---:|---:|\n");
    for s in read(r.join("counts.json"))["shapes"].as_array().unwrap() {
        let old = s["global_waves"].as_f64().unwrap();
        let new = s["tile_waves"].as_f64().unwrap();
        writeln!(
            text,
            "| {} | {} | {} | {} | +{:.3}% |",
            s["shape"].as_str().unwrap(),
            s["ordinary_adds"],
            s["global_waves"],
            s["tile_waves"],
            100. * (new / old - 1.)
        )
        .unwrap();
    }
    text.push_str("\nThese are structural nonexceptional stage counts, not measured inversion costs. Real curve exceptions/cancellations and final merging can differ. The prior count model's49%logical-codec saving is not a latency estimate. No segment/tile-size sweep is performed: eight points per segment and25cohorts per tile derive from the existing native lane and200-entry batch geometry.\n\n## Complete ordinary-filler measurements\n\nIdentical driver bytes compare the byte-exact original borrowed filler with the fresh tiled caller. Each pass fills all21ordinary width12windows for raw pre-group Ainputs; these are not automatically the final grouped-query populations. Timed scope includes histogram/partition/scatter, tile construction, all field/range/exception work, export/partial merge, allocation/drop and pool dispatch/wait. Loading, pool/oracle construction, narrow top, final weighting, solving and proof verification are excluded. **These are filler timings, not proof latency.**\n\nFifteen fixed rotated/reversed paired blocks use3primes,20timed passes and1post-check per process at1/16/32workers on the shared Ryzen9950X. Whole-process affinity is CPU2/0–15/0–31; workers may migrate within it. No additional worker pool or blocking worker barrier is introduced. No owned build/hash/archive/analysis workload overlaps captures; exclusive host use is not claimed.\n\n| Raw shape | Workers | OFF ms/pass | Tiled ms/pass | Paired tiled/OFF | Bounds | Wins/15 |\n|---|---:|---:|---:|---:|---:|---:|\n");
    for shape in ["1x2", "2x2"] {
        for workers in [1, 16, 32] {
            let c = &a["cases"][format!("{shape}-w{workers}")];
            let q = &c["candidate_over_control"];
            writeln!(
                text,
                "| {shape} | {workers} | {:.6} | {:.6} | {:.6} | [{:.6}, {:.6}] | {} |",
                c["control_ns"]["median"].as_f64().unwrap() / 1e6,
                c["candidate_ns"]["median"].as_f64().unwrap() / 1e6,
                q["median"].as_f64().unwrap(),
                q["lower"].as_f64().unwrap(),
                q["upper"].as_f64().unwrap(),
                q["wins"]
            )
            .unwrap();
        }
    }
    text.push_str("\nPrimary equal-log aggregate across both32-worker shapes requires upper ratio<1 and at least10wins; every context upper must be≤1.03. The aggregate fails both conditions. Only1x2-w32passes its context bound; its gain interval still crosses parity. Physical16medians are higher, with2x2clearly slower and1x2uncertain. Ranks4–12/15 give nominal marginal96.484375%conditional coverage without family-wise guarantees. Marginal medians need not divide into paired estimates. There is no minimum gain floor, exclusion, block extension, favorable subset or unchanged reroll. The old all-column failed gate remains false; the two implementations are separate studies, not a paired head-to-head attribution.\n\n## CPU service and sampled process memory\n\n| Raw shape | Workers | OFF CPU ms/pass | Tiled CPU ms/pass | OFF/tiled peak sampled RSS MiB | OFF/tiled median minor faults/pass |\n|---|---:|---:|---:|---:|---:|\n");
    for shape in ["1x2", "2x2"] {
        for workers in [1, 16, 32] {
            let name = format!("{shape}-w{workers}");
            let c = &a["cases"][&name];
            let faults = |label: &str| {
                let mut v = a["rows"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .filter(|x| {
                        x["job"]["panel"] == "latency"
                            && x["job"]["case"]["name"] == name
                            && x["job"]["variant"] == label
                    })
                    .map(|x| x["receipt"]["usage"]["minor_faults"].as_f64().unwrap() / 20.)
                    .collect::<Vec<_>>();
                assert_eq!(v.len(), 15);
                v.sort_by(f64::total_cmp);
                v[7]
            };
            writeln!(
                text,
                "| {shape} | {workers} | {:.3} | {:.3} | {:.2} / {:.2} | {:.2} / {:.2} |",
                c["control_CPU_ms"]["median"].as_f64().unwrap(),
                c["candidate_CPU_ms"]["median"].as_f64().unwrap(),
                c["control_max_process_RSS_MiB"].as_f64().unwrap(),
                c["candidate_max_process_RSS_MiB"].as_f64().unwrap(),
                faults("control"),
                faults("candidate")
            )
            .unwrap();
        }
    }
    text.push_str("\nRSS is the process high-water sampled at the timed-loop end, including loading, expected arrays and primes. It is not a prover peak, incremental workspace or minimumRAM. The bounded native tile does not remove other partial/index/merge allocations; total observed process memory remains higher than OFF. Fault counts do not isolate a latency cause.\n\n## Integrated warm counters and profiles\n\nAll latency precedes4grouped stat panels and4separate FIFO-gated cycles:u recordings. Each measures200passes after3excluded primes atprimary1x2w16/32. All four events run100%. Values below are one descriptive panel per context, not paired counter confidence intervals.\n\n| Workers / arm | Cycles M/pass | Instructions M/pass | Generic cache misses M/pass | Branch misses M/pass |\n|---|---:|---:|---:|---:|\n");
    for workers in [16, 32] {
        for label in ["control", "candidate"] {
            let c =
                &a["counters"][format!("stat-1x2-w{workers}-{label}")]["per_ordinary_fill_pass"];
            writeln!(
                text,
                "| {workers} / {label} | {:.3} | {:.3} | {:.6} | {:.6} |",
                c["cycles:u"].as_f64().unwrap() / 1e6,
                c["instructions:u"].as_f64().unwrap() / 1e6,
                c["cache-misses:u"].as_f64().unwrap() / 1e6,
                c["branch-misses:u"].as_f64().unwrap() / 1e6
            )
            .unwrap();
        }
    }
    text.push_str("\nAt32workers, tiled has about4.18%more instructions and5.60×generic cache misses than matched OFF. Bounding native coordinate state alone does not establish less total work or good overall memory behavior. The counters do not isolate a cache level, RAM bandwidth, input-gather cost or causal fraction of the latency.\n\n| Profile | Samples | Unknown share | Lost |\n|---|---:|---:|---:|\n");
    for workers in [16, 32] {
        for label in ["control", "candidate"] {
            let p = &a["profiles"][format!("cycles-1x2-w{workers}-{label}")];
            writeln!(
                text,
                "| {workers} / {label} | {} | {:.3}% | 0 |",
                p["samples"],
                p["unknown_share"].as_f64().unwrap() * 100.
            )
            .unwrap();
        }
    }
    text.push_str("\nAll3,102samples have the fixed16Mperiod, one expected executablePID per recording, sampledTIDs matched to actual workerFORK records and allowed CPUbounds. All profiles have fewer than1,000samples and zero lost records. Symbol bins include inlined work; sampled-period shares are not exclusive costs or removable wall time. Absolute period-to-wall coverage is not validated. The linked candidate contains no comparison-sort path for the column filler.\n\n## Qualification and retained preparation details\n\nThe isolated178-file snapshot changes only the column child relative to the qualified previous candidate:177files, including all field helpers, are byte-identical. The125unaffected core tests and35base+2field-helper tests are inherited. Four changed-path tests run now (125filtered): the previous3generator/exception/threaded tests against the new filler plus a new stable-partition,1600/1601/3201-point tile-boundary and native-layout test. All pass. No standalone prover/portable or fullSDK qualification is inferred.\n\nExact prior independent Arkworks real-point arrays and saved scalar fixtures are reused by hash, with no new solve or oracle execution. Every process checks all43,008buckets per shape in3primes and1post-check; timed intermediate outputs are black-boxed/dropped but not individually checked. All200caller processes pass:6,012ordinary-fill passes including primes/checks,126,252individual windows and34,406,400bucket comparisons. Zero new SDK proof requests or independent exports; ledger27,353unchanged.\n\nA preparation-utility character/string typo was corrected before its first execution. A template-whitespace assertion then stopped helper generation; initial utility sources, partial audit and assertion log are retained. The repaired audit is identical, and no native test or measurement had run. The subsequent4-step native build/test/freeze/link workflow and220-step capture workflow each complete on their first executions. Four planned ownership commands make only the generated perf.data readable before16read-onlydecoders; there is no failed decoder or capture rerun.\n\nIndependent review checks all raw200command/exit/stream receipts, six latency/CPU/RSS cells, paired distributions/failed gate, four grouped counters, every sample/symbol bin and executablePID/workerTID/CPUownership. It rechecks178private/176production sources, immutable libraries, unchanged oracle bindings and cached scalar words against actual input fixtures. It executes no tests, solve, model, capture or verifier again.\n\n## Accepted proof comparison — inherited, unchanged\n\n");
    let old =
        fs::read_to_string(Path::new(Z).join("docs/benchmarks/2026-10-30-g1-columns176/README.md"))
            .unwrap();
    let start = old.find("| Shape | Zopro ms |").unwrap();
    let end = old[start..].find("\n\nNo new AWS/Aeglos").unwrap() + start;
    text.push_str(&old[start..end]);
    text.push_str("\n\nNo new AWS/Aeglos, phone/ARM/TEE, huge-circuit, pressure/swap, concurrent-proof or minimumRAM result follows. This exact bounded-tile implementation is closed by the failed gate. No fullSDK trial or source promotion follows.\n\n[Design](artifacts/design.md), [capture protocol](artifacts/capture-design.md), [all observations](artifacts/analysis.json), [structural counts](artifacts/counts.json), [profiles](artifacts/symbols.json), [independent review](artifacts/review.json), [linked code](artifacts/codegen.json), [source audit](artifacts/source-audit.json). Archives: [private source](artifacts/source.tar.gz), [workflow/helper sources](artifacts/workflow.tar.gz), [all command receipts and raw counter CSVs](artifacts/receipts.tar.gz), [linked disassembly](artifacts/codegen.tar.gz). [Checksums](SHA256SUMS).\n\nRaw key/scalar/point/expected arrays, executables, libraries and perf.data stay local with recorded hashes. No witness-derived point outputs are published. Related: [previous all-column rejection](../2026-10-30-g1-columns176/README.md), [accepted production](../2026-10-30-g2-vector-sign-adoption176/README.md).\n");
    fs::write(d.join("README.md"), text).unwrap();
    archive(&d.join("artifacts/source.tar.gz"), r, &["source"]);
    archive(
        &d.join("artifacts/receipts.tar.gz"),
        r,
        &[
            "native",
            "runs",
            "stat",
            "consumer-metadata",
            "native.log",
            "capture.log",
            "finish.log",
        ],
    );
    let mut files = vec![];
    for label in ["control", "candidate"] {
        files.push(format!("{label}.nm"));
        for f in read(r.join("codegen.json"))["variants"][label]["functions"]
            .as_array()
            .unwrap()
        {
            files.push(f["disassembly"].as_str().unwrap().into());
        }
    }
    archive(
        &d.join("artifacts/codegen.tar.gz"),
        r,
        &files.iter().map(String::as_str).collect::<Vec<_>>(),
    );
    archive(
        &d.join("artifacts/workflow.tar.gz"),
        r,
        &[
            "setup.rs",
            "setup-initial.rs",
            "setup.log",
            "prepare.rs",
            "prepare-bootstrap-initial.rs",
            "bootstrap-initial.log",
            "bootstrap.log",
            "source-audit-bootstrap.json",
            "source-audit.json",
            "columns-before-rustfmt.rs",
            "columns-original.rs",
            "native.rs",
            "native-flags.txt",
            "candidate-flags.txt",
            "build-pins.json",
            "build-plan.json",
            "seal.log",
            "driver.rs",
            "perf_support.rs",
            "sampling.rs",
            "counter.rs",
            "count.rs",
            "count.log",
            "counts.json",
            "consumer-pins.json",
            "consumer-pins-before-counts.json",
            "consumers.log",
            "seal-capture.rs",
            "seal-capture.log",
            "codegen.rs",
            "codegen.log",
            "capture.rs",
            "capture-prepare.log",
            "capture-design.md",
            "capture-plan.json",
            "capture-pins.json",
            "cases.json",
            "jobs.json",
            "identities.json",
            "frozen-candidate.json",
            "frozen-candidate-cargo.jsonl",
            "review-prefix.rs",
            "make-review.rs",
            "review.rs",
            "review.log",
            "publish.rs",
            "design.md",
        ],
    );
    fs::write(
        d.join("artifacts/retained-perf-hashes.json"),
        serde_json::to_vec_pretty(&read(r.join("review.json"))["profiles"]).unwrap(),
    )
    .unwrap();
    fs::write(
        r.join("publication.json"),
        serde_json::to_vec_pretty(
            &json!({"published":d,"adopted":false,"new_proofs":0,"failed_gate_preserved":true}),
        )
        .unwrap(),
    )
    .unwrap();
    println!("Published bounded-tile negative;uncertainpositive1x2 retained;production176/ledger27353 unchanged");
}
