//! Private native ordinary G1 filler with bounded, lane-stable partial buckets.
use crate::simd::FqBatch;
use zopro_bn254::{Fq, G1Affine, G1Config};

const NONE: u32 = u32::MAX;
struct Column {
    x: FqBatch,
    y: FqBatch,
    ids: [u32; 8],
    step: u8,
    identity: u8,
}
struct Record {
    denominator: FqBatch,
    numerator: FqBatch,
    xsum: FqBatch,
    column: u32,
    ordinary: u8,
}

fn prefix_offsets(counts: &[usize]) -> Vec<usize> {
    let mut starts = Vec::with_capacity(counts.len() + 1);
    starts.push(0usize);
    for &n in counts {
        starts.push(starts.last().unwrap().checked_add(n).unwrap());
    }
    starts
}

pub(super) fn fill(
    points: &[G1Affine],
    words: &[[u64; 4]],
    w: usize,
    bits: usize,
) -> Vec<G1Affine> {
    assert_eq!(points.len(), words.len());
    assert!(points.len() < 1usize << 31);
    assert_eq!(bits, 12);
    assert!(w < 22);
    let buckets = 1usize << (bits - 1);
    let mut counts = vec![0usize; buckets];
    for (p, s) in points.iter().zip(words) {
        let d = super::digit(s, w, bits);
        if d != 0 && !p.is_identity() {
            counts[d.unsigned_abs() as usize - 1] += 1;
        }
    }
    let starts = prefix_offsets(&counts);
    let mut cursors = starts[..buckets].to_vec();
    let mut order = vec![0u32; starts[buckets]];
    for (i, (p, s)) in points.iter().zip(words).enumerate() {
        let d = super::digit(s, w, bits);
        if d != 0 && !p.is_identity() {
            let b = d.unsigned_abs() as usize - 1;
            order[cursors[b]] = i as u32 | if d < 0 { 1 << 31 } else { 0 };
            cursors[b] += 1;
        }
    }
    drop(cursors);
    let partial_counts = counts.iter().map(|&n| n.div_ceil(8)).collect::<Vec<_>>();
    let partial_starts = prefix_offsets(&partial_counts);
    let size = partial_starts[buckets];
    if size == 0 {
        return vec![G1Affine::IDENTITY; buckets];
    }
    let mut segment_starts = Vec::with_capacity(size);
    let mut segment_counts = Vec::with_capacity(size);
    for b in 0..buckets {
        for offset in (0..counts[b]).step_by(8) {
            segment_starts.push(starts[b] + offset);
            segment_counts.push((counts[b] - offset).min(8) as u8);
        }
    }
    drop(starts);
    drop(counts);
    let mut permutation = (0..size as u32).collect::<Vec<_>>();
    permutation.sort_unstable_by_key(|&i| (core::cmp::Reverse(segment_counts[i as usize]), i));
    let signed_point = |encoded: u32| {
        let p = points[(encoded & 0x7fffffff) as usize];
        if encoded >> 31 != 0 {
            -p
        } else {
            p
        }
    };
    let mut columns = Vec::with_capacity(size.div_ceil(8));
    let mut heights = Vec::with_capacity(size.div_ceil(8));
    for group in permutation.chunks(8) {
        let ids = core::array::from_fn(|i| group.get(i).copied().unwrap_or(NONE));
        let seed: [G1Affine; 8] = core::array::from_fn(|i| {
            if ids[i] == NONE {
                G1Affine::IDENTITY
            } else {
                signed_point(order[segment_starts[ids[i] as usize]])
            }
        });
        let identity = (0..8).fold(0u8, |mask, i| {
            mask | if seed[i].is_identity() { 1 << i } else { 0 }
        });
        columns.push(Column {
            x: FqBatch::new(&seed.map(|p| p.x)),
            y: FqBatch::new(&seed.map(|p| p.y)),
            ids,
            step: 1,
            identity,
        });
        heights.push(
            group
                .iter()
                .map(|&id| segment_counts[id as usize] as usize - 1)
                .max()
                .unwrap_or(0),
        );
    }
    drop(permutation);
    let total = heights.iter().sum::<usize>();
    let waves = heights
        .iter()
        .copied()
        .max()
        .unwrap_or(0)
        .max(total.div_ceil(25));
    let mut wave_counts = vec![0usize; waves];
    let mut cursor = 0usize;
    for &h in &heights {
        for _ in 0..h {
            wave_counts[cursor % waves] += 1;
            cursor += 1;
        }
    }
    assert!(wave_counts.iter().all(|&n| n <= 25));
    let wave_starts = prefix_offsets(&wave_counts);
    let mut wave_positions = wave_starts[..waves].to_vec();
    let mut wave_ids = vec![0u32; total];
    cursor = 0;
    for (id, &h) in heights.iter().enumerate() {
        assert!(h <= waves);
        for _ in 0..h {
            let wave = cursor % waves;
            wave_ids[wave_positions[wave]] = id as u32;
            wave_positions[wave] += 1;
            cursor += 1;
        }
    }
    drop(heights);
    drop(wave_counts);
    drop(wave_positions);
    let mut records = Vec::with_capacity(25);
    let one = FqBatch::one();
    for wave in 0..waves {
        let mut chains = one;
        records.clear();
        for &id in &wave_ids[wave_starts[wave]..wave_starts[wave + 1]] {
            let column = &mut columns[id as usize];
            let mut active = 0u8;
            let mut negative = 0u8;
            let incoming: [G1Affine; 8] = core::array::from_fn(|i| {
                let partial = column.ids[i];
                if partial != NONE && column.step < segment_counts[partial as usize] {
                    active |= 1 << i;
                    let encoded = order[segment_starts[partial as usize] + column.step as usize];
                    negative |= ((encoded >> 31) as u8) << i;
                    points[(encoded & 0x7fffffff) as usize]
                } else {
                    G1Affine::IDENTITY
                }
            });
            column.step += 1;
            let bx = FqBatch::new(&incoming.map(|p| p.x));
            let by = FqBatch::new(&incoming.map(|p| p.y));
            let ordinary = active & !column.identity & !column.x.column_eq_canonical(&bx);
            let denominator = bx.sub_canonical(&column.x).column_select(&one, !ordinary);
            let numerator = by.signed_difference_scaled(&column.y, &chains, negative);
            let xsum = column.x.add_canonical(&bx);
            chains = chains.mul(&denominator);
            records.push(Record {
                denominator,
                numerator,
                xsum,
                column: id,
                ordinary,
            });

            let exceptional = active & !ordinary;
            if exceptional != 0 {
                // Only exceptional lanes decode their old anchors. Ordinary
                // anchors remain canonical and untouched for the reverse pass.
                let mut x = column.x.get();
                let mut y = column.y.get();
                for i in 0..8 {
                    if exceptional >> i & 1 != 0 {
                        let a = if column.identity >> i & 1 != 0 {
                            G1Affine::IDENTITY
                        } else {
                            G1Affine::new(x[i], y[i])
                        };
                        let b = if negative >> i & 1 != 0 {
                            -incoming[i]
                        } else {
                            incoming[i]
                        };
                        let result = (a + b).to_affine();
                        x[i] = result.x;
                        y[i] = result.y;
                        column.identity = (column.identity & !(1 << i))
                            | if result.is_identity() { 1 << i } else { 0 };
                    }
                }
                column.x = FqBatch::new(&x);
                column.y = FqBatch::new(&y);
            }
        }
        let mut inverse = chains.inverse_nonzero();
        for record in records.iter().rev() {
            let column = &mut columns[record.column as usize];
            let slope = record.numerator.mul(&inverse);
            inverse = inverse.mul(&record.denominator);
            let x = slope.mul(&slope).sub(&record.xsum);
            let y = slope.mul(&column.x.sub(&x)).sub(&column.y);
            column.x = column
                .x
                .column_select(&x.column_canonical(), record.ordinary);
            column.y = column
                .y
                .column_select(&y.column_canonical(), record.ordinary);
        }
    }
    drop(records);
    drop(order);
    drop(segment_starts);
    drop(segment_counts);
    drop(wave_ids);
    drop(wave_starts);
    let mut partials = vec![G1Affine::IDENTITY; size];
    for column in &columns {
        let x = column.x.get();
        let y = column.y.get();
        for i in 0..8 {
            if column.ids[i] != NONE {
                partials[column.ids[i] as usize] = if column.identity >> i & 1 != 0 {
                    G1Affine::IDENTITY
                } else {
                    G1Affine::new(x[i], y[i])
                };
            }
        }
    }
    drop(columns);
    let indices = (0..size as u32).collect::<Vec<_>>();
    crate::msm::group_affine::<G1Config>(&partials, &indices, &partial_starts, &partial_counts)
}

#[cfg(test)]
mod tests {
    use super::*;
    use zopro_bn254::{Fr, G1Projective};
    fn reference_digit(s: &[u64; 4], w: usize) -> i16 {
        let bit = |offset: usize| {
            if offset >= 256 {
                0
            } else {
                ((s[offset / 64] >> (offset % 64)) & 1) as i64
            }
        };
        let offset = w * 12;
        let v = (0..12).map(|i| bit(offset + i) << i).sum::<i64>();
        (v + if offset == 0 { 0 } else { bit(offset - 1) } - (bit(offset + 11) << 12)) as i16
    }
    fn check(points: &[G1Affine], weights: &[Fr], words: &[[u64; 4]], w: usize) {
        let mut expected = vec![Fr::ZERO; 2048];
        for (i, s) in words.iter().enumerate() {
            let d = reference_digit(s, w);
            if d != 0 {
                expected[d.unsigned_abs() as usize - 1] +=
                    if d < 0 { -weights[i] } else { weights[i] };
            }
        }
        let original = points.to_vec();
        let raw = words.to_vec();
        let output = fill(points, words, w, 12);
        for (i, coefficient) in expected.iter().enumerate() {
            assert_eq!(
                output[i],
                (G1Projective::generator() * *coefficient).to_affine(),
                "w={w}bucket={i}"
            );
        }
        assert_eq!(output, super::super::column_control(points, words, w, 12));
        assert_eq!(points, original);
        assert_eq!(words, raw);
    }
    #[test]
    fn columns_full_width_signed_bucket_generator_oracles() {
        let n = 4097;
        let weights = (0..n)
            .map(|i| Fr::from((i * 173 + 811) as u64))
            .collect::<Vec<_>>();
        let points = G1Projective::batch_to_affine(
            &weights
                .iter()
                .map(|s| G1Projective::generator() * *s)
                .collect::<Vec<_>>(),
        );
        let mut state = 0x3b47a1da77cb4021u64;
        let words = (0..n)
            .map(|_| {
                let mut b = [0; 64];
                for c in b.chunks_mut(8) {
                    state ^= state << 13;
                    state ^= state >> 7;
                    state ^= state << 17;
                    c.copy_from_slice(&state.to_le_bytes());
                }
                Fr::from_random_bytes(&b).to_canonical()
            })
            .collect::<Vec<_>>();
        for len in [0, 1, 7, 8, 9, 31, 129, 2048, 4097] {
            for w in [0, 7, 20] {
                check(&points[..len], &weights[..len], &words[..len], w);
            }
        }
    }
    #[test]
    fn columns_complete_exceptions_skew_and_segment_tails() {
        for len in [8usize, 9, 17, 63, 257, 513] {
            for style in 0..3 {
                let weights = (0..len)
                    .map(|i| match (i + style) % 8 {
                        0 | 3 => Fr::ZERO,
                        1 | 2 => Fr::from(7u64),
                        4 => -Fr::from(7u64),
                        5 => Fr::from(3u64),
                        6 => -Fr::from(3u64),
                        _ => Fr::ONE,
                    })
                    .collect::<Vec<_>>();
                let points = G1Projective::batch_to_affine(
                    &weights
                        .iter()
                        .map(|s| G1Projective::generator() * *s)
                        .collect::<Vec<_>>(),
                );
                let words = (0..len)
                    .map(|i| {
                        match style {
                            0 => Fr::ONE,
                            1 => {
                                if i % 3 == 0 {
                                    -Fr::ONE
                                } else {
                                    Fr::ONE
                                }
                            }
                            _ => Fr::from((i % 11) as u64),
                        }
                        .to_canonical()
                    })
                    .collect::<Vec<_>>();
                for w in [0, 10, 20] {
                    check(&points, &weights, &words, w);
                }
            }
        }
    }
    #[test]
    fn columns_threaded_small_stacks_and_repeated_calls() {
        let weights = (0..1024)
            .map(|i| {
                if i % 7 == 0 {
                    Fr::ZERO
                } else {
                    Fr::from((i + 17) as u64)
                }
            })
            .collect::<Vec<_>>();
        let points = G1Projective::batch_to_affine(
            &weights
                .iter()
                .map(|s| G1Projective::generator() * *s)
                .collect::<Vec<_>>(),
        );
        let words = (0..1024)
            .map(|i| Fr::from((i % 31 + 1) as u64).to_canonical())
            .collect::<Vec<_>>();
        let expected = super::super::column_control(&points, &words, 0, 12);
        for workers in [1, 4, 32] {
            let pool = rayon::ThreadPoolBuilder::new()
                .num_threads(workers)
                .stack_size(512 * 1024)
                .build()
                .unwrap();
            pool.install(|| {
                use rayon::prelude::*;
                (0..workers).into_par_iter().for_each(|_| {
                    for _ in 0..3 {
                        assert_eq!(fill(&points, &words, 0, 12), expected);
                    }
                });
            });
        }
    }
}
