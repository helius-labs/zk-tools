use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::{Path, PathBuf},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g1-column-tiles176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn check(v: &[f64], s: &Value) {
    assert_eq!(v.len(), 15);
    let mut x = v.to_vec();
    x.sort_by(f64::total_cmp);
    for (k, i) in [("median", 7), ("lower", 3), ("upper", 11)] {
        assert!((x[i] - s[k].as_f64().unwrap()).abs() < 1e-7);
    }
    assert_eq!(s["wins"], v.iter().filter(|&&x| x < 1.).count());
}
fn main() {
    assert!(!r("review.json").exists());
    for name in ["build-pins.json", "consumer-pins.json", "capture-pins.json"] {
        for (p, h) in read(r(name)).as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
    }
    let manifest=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let audit = read(r("source-audit.json"));
    assert_eq!(audit["source_files_sha256"].as_object().unwrap().len(), 178);
    let mut exact = 0;
    for (rel, h) in manifest["source_files_sha256"].as_object().unwrap() {
        assert_eq!(hash(Path::new(Z).join(rel)), h.as_str().unwrap());
        if audit["source_files_sha256"][rel] == *h {
            exact += 1;
        }
    }
    assert_eq!(exact, 172);
    let previous = read("/home/ubuntu/src/zopro-perf-work/g1-columns176/source-audit-fixed.json");
    let mut changes = vec![];
    for (rel, h) in audit["source_files_sha256"].as_object().unwrap() {
        assert_eq!(hash(r("source").join(rel)), h.as_str().unwrap());
        if previous["source_files_sha256"][rel] != *h {
            changes.push(rel);
        }
    }
    assert_eq!(
        changes,
        vec!["crates/zopro-core/src/msm_affine/borrowed_pending/columns.rs"]
    );
    let tests = read(r("native/candidate-core/tests.json"));
    assert_eq!(tests["passed_tests"].as_array().unwrap().len(), 4);
    assert_eq!(tests["unfiltered"], false);
    for label in ["control", "candidate"] {
        let a = read(r(format!("consumer-metadata/{label}.json")));
        assert_eq!(hash(a["binary"].as_str().unwrap()), a["binary_sha256"]);
        for (p, h) in a["input_pins"].as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
    }
    for shape in ["1x2", "2x2"] {
        let base = Path::new("/home/ubuntu/src/zopro-perf-work/g1-columns176");
        let o = read(base.join(format!("consumers/oracle-{shape}/stdout.log")));
        let fixture = fs::read(base.join(format!("inputs/{shape}.a1q"))).unwrap();
        assert_eq!(
            format!("{:x}", Sha256::digest(&fixture)),
            o["fixture_sha256"]
        );
        assert_eq!(
            hash(base.join(format!("inputs/{shape}.expected"))),
            o["expected_sha256"]
        );
        let cache = fs::read(format!(
            "/home/ubuntu/src/zopro-perf-work/g1-column-count176/{shape}-raw-a.words"
        ))
        .unwrap();
        let n = u64::from_le_bytes(cache[8..16].try_into().unwrap()) as usize;
        assert_eq!(fixture.len(), 16 + 96 * n);
        for (i, record) in cache[16..].chunks_exact(33).enumerate() {
            assert_eq!(
                &fixture[16 + 64 * n + i * 32..16 + 64 * n + (i + 1) * 32],
                &record[..32]
            );
            assert_eq!(
                record[32] != 0,
                fixture[16 + 64 * i..16 + 64 * (i + 1)]
                    .iter()
                    .all(|&v| v == 0)
            );
        }
        for k in [
            "all_points_on_curve",
            "all_points_in_prime_subgroup",
            "all_scalars_canonical",
            "independent_Arkworks_projective_bucket_sums",
        ] {
            assert_eq!(o[k], true);
        }
    }
    let result = read(r("runs/result.json"));
    assert_eq!(result["status"], "complete");
    assert_eq!(result["steps"].as_array().unwrap().len(), 220);
    let a = read(r("analysis.json"));
    let symbols = read(r("symbols.json"));
    let plan = read(r("capture-plan.json"));
    let mut raw = BTreeMap::<(String, String, usize), f64>::new();
    let mut cpus = BTreeMap::<(String, String, usize), f64>::new();
    let mut rss = BTreeMap::<(String, String), f64>::new();
    let (mut processes, mut passes, mut buckets, mut sample_count, mut total_period) =
        (0u64, 0u64, 0u64, 0u64, 0u64);
    let mut checked_profiles = vec![];
    for row in a["rows"].as_array().unwrap() {
        let j = &row["job"];
        let name = j["name"].as_str().unwrap();
        let text = fs::read_to_string(r(format!("runs/{name}/stdout.log"))).unwrap();
        let lines = text
            .lines()
            .filter_map(|l| l.strip_prefix("CALLER "))
            .collect::<Vec<_>>();
        assert_eq!(lines.len(), 1);
        let v: Value = serde_json::from_str(lines[0]).unwrap();
        assert_eq!(v, row["receipt"]);
        let exit = read(r(format!("runs/{name}/exit.json")));
        assert_eq!(exit["success"], true);
        assert_eq!(exit["returncode"], 0);
        assert_eq!(
            hash(r(format!("runs/{name}/stdout.log"))),
            exit["stdout_sha256"]
        );
        assert_eq!(
            hash(r(format!("runs/{name}/stderr.log"))),
            exit["stderr_sha256"]
        );
        assert_eq!(exit["stdout_sha256"], row["stdout_sha256"]);
        let step = plan["steps"]
            .as_array()
            .unwrap()
            .iter()
            .find(|s| s["name"] == name)
            .unwrap();
        let cmd = read(r(format!("runs/{name}/command.json")));
        assert_eq!(
            &cmd["argv"].as_array().unwrap()[4..],
            step["argv"].as_array().unwrap()
        );
        assert_eq!(
            cmd["environment"],
            step.get("environment")
                .cloned()
                .unwrap_or_else(|| json!({}))
        );
        let rounds = j["rounds"].as_u64().unwrap();
        let workers = j["case"]["workers"].as_u64().unwrap();
        assert_eq!(v["timed_passes"], rounds);
        assert_eq!(v["workers"], workers);
        assert_eq!(v["input_rows"], j["case"]["points"]);
        assert_eq!(v["candidate"], j["variant"] == "candidate");
        assert_eq!(
            v["all_prime_and_post_buckets_match_independent_oracle"],
            true
        );
        assert_eq!(v["allocation_and_drop_inside_timer"], true);
        assert_eq!(v["new_proofs"], 0);
        assert_eq!(v["priming_passes"], 3);
        assert_eq!(v["postcheck_passes"], 1);
        assert_eq!(v["checked_bucket_outputs"], 172032);
        passes += rounds + 4;
        buckets += 172032;
        processes += 1;
        if j["panel"] == "latency" {
            let key = (
                j["case"]["name"].as_str().unwrap().into(),
                j["variant"].as_str().unwrap().into(),
                j["block"].as_u64().unwrap() as usize,
            );
            let ns = v["elapsed_ns"].as_f64().unwrap() / rounds as f64;
            assert_eq!(
                v["ns_per_complete_ordinary_fill_pass"].as_f64().unwrap(),
                ns
            );
            assert!(raw.insert(key.clone(), ns).is_none());
            cpus.insert(
                key.clone(),
                (v["usage"]["user_cpu_ms"].as_f64().unwrap()
                    + v["usage"]["system_cpu_ms"].as_f64().unwrap())
                    / rounds as f64,
            );
            let t = rss.entry((key.0, key.1)).or_insert(0.);
            *t = t.max(v["usage"]["whole_process_maxrss_kib"].as_f64().unwrap() / 1024.);
        }
        if j["panel"] == "stat" {
            let text = fs::read_to_string(j["data"].as_str().unwrap()).unwrap();
            let counter = &a["counters"][name];
            for line in text
                .lines()
                .filter(|l| !l.trim().is_empty() && !l.starts_with('#'))
            {
                let f = line.split(';').collect::<Vec<_>>();
                let count = f[0].parse::<f64>().unwrap();
                let coverage = f[4].parse::<f64>().unwrap();
                let key = f[2];
                assert!(coverage >= 99.9);
                assert_eq!(count, counter["events"][key]["count"].as_f64().unwrap());
                assert_eq!(
                    count / rounds as f64,
                    counter["per_ordinary_fill_pass"][key].as_f64().unwrap()
                );
            }
        }
        if j["panel"] == "cycles" {
            let profile = &a["profiles"][name];
            let metadata =
                fs::read_to_string(r(format!("runs/metadata-{name}/stdout.log"))).unwrap();
            let pid = profile["PID"].as_u64().unwrap();
            let mut fork_tids = BTreeSet::new();
            for l in metadata.lines() {
                if let Some(rest) = l.split("PERF_RECORD_FORK(").nth(1) {
                    let first = rest.split(')').next().unwrap();
                    let (p, t) = first.split_once(':').unwrap();
                    assert_eq!(p.parse::<u64>().unwrap(), pid);
                    fork_tids.insert(t.parse::<u64>().unwrap());
                }
            }
            assert_eq!(fork_tids.len(), workers as usize);
            assert!(metadata.lines().any(|l| l.contains("PERF_RECORD_MMAP")
                && l.contains(j["binary"].as_str().unwrap())
                && l.contains(&format!("{pid}/{pid}"))));
            let mut samples = 0u64;
            let mut period = 0u64;
            let mut tids = BTreeSet::new();
            let mut map = BTreeMap::<String, (u64, u64)>::new();
            for l in fs::read_to_string(r(format!("runs/decode-{name}/stdout.log")))
                .unwrap()
                .lines()
                .filter(|l| !l.trim().is_empty() && !l.trim_start().starts_with('#'))
            {
                let f = l.split_whitespace().collect::<Vec<_>>();
                let (p, t) = f[0].split_once('/').unwrap();
                let p = p.parse::<u64>().unwrap();
                let t = t.parse::<u64>().unwrap();
                assert_eq!(p, pid);
                assert!(t == pid || fork_tids.contains(&t));
                let cpu = f[1].trim_matches(['[', ']']).parse::<u64>().unwrap();
                assert!(cpu < workers);
                let per = f[3].parse::<u64>().unwrap();
                assert_eq!(per, 16000000);
                let raw = f[5..].join(" ");
                let sym = rustc_demangle::try_demangle(&raw)
                    .map(|s| format!("{s:#}"))
                    .unwrap_or(raw);
                let entry = map.entry(sym).or_default();
                entry.0 += 1;
                entry.1 += per;
                samples += 1;
                period += per;
                tids.insert(t);
            }
            assert_eq!(profile["samples"], samples);
            assert_eq!(profile["sampled_period"], period);
            let recorded: BTreeSet<u64> =
                serde_json::from_value(profile["sampled_TIDs"].clone()).unwrap();
            assert_eq!(tids, recorded);
            for sym in symbols[name].as_array().unwrap() {
                let key = sym["symbol"].as_str().unwrap();
                let value = map.remove(key).unwrap();
                assert_eq!(sym["samples"], value.0);
                assert_eq!(sym["period"], value.1);
            }
            assert!(map.is_empty());
            assert_eq!(
                read(r(format!("runs/loss-{name}/stdout.log")))["zero_lost"],
                true
            );
            assert_eq!(profile["zero_lost"], true);
            sample_count += samples;
            total_period += period;
            checked_profiles.push(json!({"name":name,"PID":pid,"forked_workers":fork_tids.len(),"samples":samples,"period":period,"all_sampled_TIDs_owned":true,"perf_sha256":hash(j["data"].as_str().unwrap())}));
        }
    }
    let mut primary = vec![1f64; 15];
    let mut contexts = true;
    for (name, c) in a["cases"].as_object().unwrap() {
        let get = |map: &BTreeMap<(String, String, usize), f64>, label: &str| {
            (0..15)
                .map(|b| map[&(name.clone(), label.into(), b)])
                .collect::<Vec<_>>()
        };
        let off = get(&raw, "control");
        let on = get(&raw, "candidate");
        check(&off, &c["control_ns"]);
        check(&on, &c["candidate_ns"]);
        check(&get(&cpus, "control"), &c["control_CPU_ms"]);
        check(&get(&cpus, "candidate"), &c["candidate_CPU_ms"]);
        assert_eq!(
            c["control_max_process_RSS_MiB"].as_f64().unwrap(),
            rss[&(name.clone(), "control".into())]
        );
        assert_eq!(
            c["candidate_max_process_RSS_MiB"].as_f64().unwrap(),
            rss[&(name.clone(), "candidate".into())]
        );
        let ratios = on.iter().zip(&off).map(|(a, b)| a / b).collect::<Vec<_>>();
        check(&ratios, &c["candidate_over_control"]);
        contexts &= c["candidate_over_control"]["upper"].as_f64().unwrap() <= 1.03;
        if name.ends_with("-w32") {
            for (b, v) in ratios.iter().enumerate() {
                primary[b] *= v.sqrt();
            }
        }
    }
    check(&primary, &a["primary_equal_log_32"]);
    let gate = contexts
        && a["primary_equal_log_32"]["upper"].as_f64().unwrap() < 1.
        && a["primary_equal_log_32"]["wins"].as_u64().unwrap() >= 10;
    assert!(!gate);
    assert_eq!(a["caller_gate_passed"], false);
    assert_eq!(processes, 200);
    assert_eq!(passes, 6012);
    assert_eq!(buckets, 34406400);
    assert_eq!(sample_count, 3102);
    let ledger=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/proof-sha256-after.json"));
    assert_eq!(ledger.as_array().unwrap().len(), 27353);
    let out = json!({"passed":true,"production176_unchanged":true,"corrected_private_files":178,"accepted_originals_exact":172,"base_core_inherited":125,"changed_core_tests_passed":4,"basefield_inherited":35,"field_helpers_inherited":2,"caller_processes":processes,"passes_including_primes_and_postchecks":passes,"individual_window_fills":passes*21,"checked_bucket_outputs":buckets,"independently_recomputed_gate":gate,"profile_samples":sample_count,"profile_period":total_period,"profiles":checked_profiles,"all220steps_complete_first_attempt":true,"new_proofs":0,"new_solver_calls":0,"verified_ledger_unchanged":27353,"scope":"Independent raw receipts/command/exits/source/libraries/oracles/paired statistics/PMU/sample-bin/PID/TID ownership review;no model/test/solver/proof/measurement rerun."});
    save(r("review.json"), &out);
    println!("Independent reviewPASS;200rawreceipts/6cases/aggregate/4PMU/4profiles3102owned samples;failedgate retained;source176/ledger27353unchanged");
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
