# Fixed workers claiming ready K/H reduction chunks

Hypothesis: retain existing fill/weighted arithmetic and twenty balanced windows,
but replace nested Rayon reduction jobs with at most pool_size scoped drainers.
A completed fill publishes immutable buckets and256-point reduction slots.
Drainers claim ready chunks by atomic index; the last completes the original
weighted fold. Workers yield to Rayon only with no claimed work. Panic sets a
cancellation flag before scoped joining, so waiters can leave. No worker pool,
expanded key, unsafe memory access or persistent graph is introduced.

This differs from Oct25 scoped dataflow (Rayon jobs for continuations) and from
min-grain tuning: the reduction chunks have no individual Rayon job/latch.
It borrows the work/finish separation discussed in deWolff/Keller ARRAY2024
https://doi.org/10.1145/3652586.3663313 but does not implement their activity-pointer
scheduler or claim its guarantees. All metadata/buckets live through this one
query; extra lifetime and worker scratch must be charged. Scope is K/H only;
a later integrated scheduler must address interference with other proof work.

Cheapest test: complete real K/H caller, same immutable fixture and independent
Arkworks oracle from two-bank-caller177. Current production Window/field/weighted
algorithms are unchanged. No two-bank accumulation is used. Only scheduling and
workspace ownership change. Single-worker calls use the original path.
Preparation allowance30minutes before first qualified executable; if exceeded,
state the unresolved issue before further work. Fixed capture allowance5minutes.

Before timing, qualify zero/dense/duplicate/signed scalar cases, worker counts
1/2/4/16/32, independent callers sharing one pool, and injected failure followed
by pool reuse. Successful calls must match an independent generator-weight oracle
and the original caller. The real fixture is already Arkworks checked; reuse its
pinned bytes and oracle, no repeated solving/FFT or point-oracle calculation.

Same protocol as previous caller: three independently written byte-identical
backings; fixed worker masks CPU2/0..15/0..31,512KiB worker stacks, accepted native
flags/allocator. Six preflights, then3blocks×3backings×3worker counts×2arms =54
processes. Three primes and17timed calls each; include allocation, fill, chunk
reduction, folds, drops, pool entry, normalization and equality in the timer.
Hashes/pool/fixture loading outside timing; lifetime RSS includes loading/primes.
Rotate worker/backing orders and alternate arm order. All inputs/outputs checked.
Only poll live capture handle; no helper/build/profile overlap. Preserve all
samples; no extension. Median paired ON/OFF and all3backing medians must improve
at a multithreaded context to select a short full-proof screen. Mixed signs are
inconclusive; coherent regressions reject this scheduling recipe locally.
No minimum gain floor, adoption or AWS claim; operation count alone predicts
no latency. No new proofs; canonical54007 unchanged.
