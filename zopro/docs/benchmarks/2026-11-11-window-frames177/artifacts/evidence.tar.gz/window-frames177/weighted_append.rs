// Private scheduling probe. Arithmetic copied literally from weighted_affine.
pub(super) struct FrameScratch {
 tree:Vec<LimbPoint<zopro_bn254::Fq>>,
 scratch:Scratch<zopro_bn254::G1Config>,
}
impl Default for FrameScratch {fn default()->Self{Self{tree:Vec::new(),scratch:Scratch::default()}}}
impl FrameScratch {
 pub(super) fn leaf(&mut self,buckets:&[zopro_bn254::G1Affine])->(zopro_bn254::G1Projective,zopro_bn254::G1Affine){
  let n=buckets.len();assert_eq!(n,256);
  self.tree.resize(2*n-1,LimbPoint::<zopro_bn254::Fq>::infinity());
  for(out,&point)in self.tree.iter_mut().zip(buckets){*out=limbs::<zopro_bn254::G1Config>(point);}
  let weighted=weighted_sum(&mut self.tree,n,&mut self.scratch);
  (weighted,affine::<zopro_bn254::G1Config>(self.tree[0]))
 }
}
pub(super) fn frame_finish(partials:&[(zopro_bn254::G1Projective,zopro_bn254::G1Affine)])->zopro_bn254::G1Projective{
 let mut sum=zopro_bn254::G1Projective::IDENTITY;
 let mut offset=zopro_bn254::G1Projective::IDENTITY;
 let mut running=zopro_bn254::G1Projective::IDENTITY;
 for &(weighted,total)in partials.iter().rev(){sum+=weighted;offset+=running;running+=total;}
 for _ in 0..8{offset=offset.double();}
 sum+offset
}
