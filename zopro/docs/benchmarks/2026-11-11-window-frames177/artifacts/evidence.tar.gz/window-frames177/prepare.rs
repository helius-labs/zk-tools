use std::{fs,collections::BTreeMap};use serde_json::{Value,json};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/window-frames177";const C:&str="/home/ubuntu/src/zopro-perf-work/two-bank-caller177";
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn cp(a:&str,b:&str){fs::create_dir_all(std::path::Path::new(b).parent().unwrap()).unwrap();fs::copy(a,b).unwrap();}
fn append(p:&str,s:&str){use std::io::Write;fs::OpenOptions::new().append(true).open(p).unwrap().write_all(s.as_bytes()).unwrap();}
fn main(){assert!(!std::path::Path::new(&format!("{R}/source")).exists());let original=read("/home/ubuntu/src/zopro-perf-work/two-bank177/source-bindings.json");for(p,h)in original.as_object().unwrap(){let from=format!("/home/ubuntu/src/zk-tools/zopro/{p}");assert_eq!(hash(&from),h.as_str().unwrap());cp(&from,&format!("{R}/source/{p}"));}assert_eq!(original.as_object().unwrap().len(),176);
cp(&format!("{R}/window_frames.rs"),&format!("{R}/source/crates/zopro-core/src/msm_affine/borrowed_pending/window_frames.rs"));append(&format!("{R}/source/crates/zopro-core/src/msm.rs"),&fs::read_to_string(format!("{R}/weighted_append.rs")).unwrap());
append(&format!("{R}/source/crates/zopro-core/src/msm_affine/borrowed_pending.rs"),r#"
pub(crate) mod window_frames;
pub(crate) fn frame_control(k:&[zopro_bn254::G1Affine],sk:&[[u64;4]],h:&[zopro_bn254::G1Affine],sh:&[[u64;4]])->zopro_bn254::G1Projective{fused(k,sk,h,sh,13)}
"#);
append(&format!("{R}/source/crates/zopro-core/src/msm_affine/borrowed_pending/balanced.rs"),r#"
pub(super) fn frame_fill(k:&[zopro_bn254::G1Affine],sk:&[[u64;4]],h:&[zopro_bn254::G1Affine],sh:&[[u64;4]],i:usize)->Vec<zopro_bn254::G1Affine>{
 let span=spans()[i];let size=batch_size(span.width).max(32);
 let mut state=Window::<zopro_bn254::G1Config>::new(1usize<<(span.width-1),size);
 feed(&mut state,k,sk,span,size);feed(&mut state,h,sh,span,size);state.finish()
}
"#);
append(&format!("{R}/source/crates/zopro-core/src/lib.rs"),r#"
#[doc(hidden)]pub fn frame_caller(k:&[G1Affine],sk:&[[u64;4]],h:&[G1Affine],sh:&[[u64;4]],on:bool)->G1Projective{if on{msm_affine::borrowed_pending::window_frames::fused(k,sk,h,sh)}else{msm_affine::borrowed_pending::frame_control(k,sk,h,sh)}}
#[doc(hidden)]pub fn frame_cancel(k:&[G1Affine],sk:&[[u64;4]],h:&[G1Affine],sh:&[[u64;4]]){msm_affine::borrowed_pending::window_frames::cancellation_probe(k,sk,h,sh)}
"#);
let old=fs::read_to_string(format!("{C}/driver.rs")).unwrap();let mut driver=old[..old.find("fn fixture(){").unwrap()].to_string();let tail=&old[old.find("struct Input").unwrap()..old.find("fn main()").unwrap()];driver.push_str(tail);driver.push_str(&fs::read_to_string(format!("{R}/qualify.rs")).unwrap());driver.push_str("\nfn main(){let a=std::env::args().collect::<Vec<_>>();if a.len()==2&&a[1]==\"qualify\"{qualify()}else{assert_eq!(a.len(),4);run(a[1].parse().unwrap(),&a[2],a[3].parse().unwrap());}}\n");driver=driver.replace(C,R).replace("bank_caller","frame_caller").replace("mod loader;","");fs::write(format!("{R}/driver.rs"),&driver).unwrap();fs::create_dir_all(format!("{R}/driver/src")).unwrap();fs::write(format!("{R}/driver/src/main.rs"),driver).unwrap();cp(&format!("{C}/driver/src/perf.rs"),&format!("{R}/driver/src/perf.rs"));let toml=fs::read_to_string(format!("{C}/driver/Cargo.toml")).unwrap().replace("two-bank-caller","window-frames");fs::write(format!("{R}/driver/Cargo.toml"),toml).unwrap();cp(&format!("{C}/driver/Cargo.lock"),&format!("{R}/driver/Cargo.lock"));
let priorpins=read(&format!("{C}/capture-pins.json"));for f in["fixture.bin","oracle.bin"]{let p=format!("{C}/{f}");assert_eq!(hash(&p),priorpins[&p].as_str().unwrap());cp(&p,&format!("{R}/{f}"));}
let mut env=read(&format!("{C}/environment.json"));env["CARGO_TARGET_DIR"]=json!(format!("{R}/target"));let plan=json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"steps":[{"kind":"command","name":"build","argv":["cargo","build","--locked","--offline","--release","--manifest-path",format!("{R}/driver/Cargo.toml"),"--message-format=json"],"environment":env,"timeout_seconds":900},{"kind":"command","name":"qualify","argv":[format!("{R}/target/release/window-frames"),"qualify"],"environment":env,"timeout_seconds":120}]});fs::write(format!("{R}/build-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();fs::write(format!("{R}/environment.json"),serde_json::to_vec_pretty(&env).unwrap()).unwrap();let pins:BTreeMap<_,_>=original.as_object().unwrap().iter().map(|(p,h)|(p,h)).collect();fs::write(format!("{R}/source-bindings.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();println!("Prepared176current originals plus4appendages and1child; reused real fixture/oracle.");}
