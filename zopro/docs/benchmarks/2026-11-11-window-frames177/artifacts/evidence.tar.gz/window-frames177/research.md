# Question and history check

Assumption challenged: independent256-bucket reduction leaves must be scheduled
as nested Rayon iterator jobs. Prediction: replacing those publications with
claims on an already-live window can reduce scheduling/allocation work while
preserving the mathematical DAG. This does not claim a larger arithmetic
parallelism bound or a2x latency prediction.

Cheapest discriminating test is the complete primary K/H caller with all fill,
weighted reduction, memory lifetimes and final fold charged. Faster kernel-only
or fewer-job counts would be insufficient. Positive multiworker caller evidence
selects an integrated screen; a coherent regression stops this recipe. Mixed
signs require a different discriminating question rather than more samples.

Added cost:20 frame objects, OnceLock partial outputs, one claim counter and
completion count per frame, one global fill cursor/completion count and panic
flag. All twenty bucket arrays can remain live through the query; each drainer
owns reusable weighted scratch. No new proving key/point table or thread pool.
The caller measurement must report RSS, not infer it from metadata size.

Reviewed prior experiments:
- Oct25 proof-dataflow-screen and proof-dataflow-c7a used scoped continuation
  jobs, including K/FFT overlap and optional merge/reduction fusion; negative.
  This prototype keeps the input dataflow and arithmetic, but does not publish
  an individual Rayon job for each ready reduction chunk.
- Oct25 worker-groups-c7a divided the fixed thread population into query groups;
  this prototype has no groups and permits helpers to change active windows.
- Oct25 static-worker-queues changed deque/reclamation behavior; this prototype
  leaves Rayon queues untouched and changes the units submitted to them.
- Oct26 bounded-steal-search limited simultaneous victim scans; this prototype
  changes available application work, not the scheduler's victim-search policy.
- Nov10 task-job-families identified a phi iterator; its min-grain intervention
  is already adopted. Repeating that change would not be new.
- zopro/parallel currently provides a minimum-grain Rayon adapter, not this
  execution model. No public crate modification or publication is made here.

Primary research: deWolff/Keller, ARRAY2024,
https://doi.org/10.1145/3652586.3663313 (author-hosted PDF:
https://research-portal.uu.nl/ws/files/250230018/file/).
The paper separates data-parallel work from a completion function and lets
workers join an active operation. It motivates this bounded phase prototype,
which is not their full scheduler and inherits none of its algorithmic guarantees.
No upstream implementation is copied; the GitHub README fetch returned404.
The2025 author artifact https://zenodo.org/records/15602901 describes integration
in Accelerate; its different benchmarks do not establish a prover speedup.
