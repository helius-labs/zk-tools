use std::{fs,sync::Arc,time::Instant,hint::black_box};
use sha2::{Sha256,Digest};use serde_json::json;
use zopro_bn254::{G1Affine as Z,Fq,Fr};
use ark_bn254::{G1Affine as A,G1Projective as P,Fr as S};
use ark_ec::{AffineRepr,CurveGroup,VariableBaseMSM};use ark_ff::{PrimeField,BigInteger,Zero};
mod perf;
#[global_allocator] static ALLOCATOR:zopro_core::alloc::Allocator=zopro_core::alloc::Allocator;
const R:&str="/home/ubuntu/src/zopro-perf-work/window-frames177";
const IMAGE:&str="/home/ubuntu/src/zopro-perf-work/sdk-control-copies/images/transfer_confidential_1_2.image";
const CACHE:&str="/home/ubuntu/src/zopro-perf-work/g1-tagged-phi-review176/private-input-cache.bin";
fn sha(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn words(b:&[u8])->[u64;4]{assert_eq!(b.len(),32);std::array::from_fn(|i|u64::from_le_bytes(b[i*8..i*8+8].try_into().unwrap()))}
fn encode(p:Z)->Vec<u8>{[p.x,p.y].into_iter().flat_map(|f|f.0.into_iter().flat_map(u64::to_le_bytes)).collect()}
fn decode(b:&[u8])->Z{Z::new(Fq::from_montgomery(words(&b[..32])),Fq::from_montgomery(words(&b[32..64])))}
fn to_ark(p:Z)->A{if p.is_identity(){A::identity()}else{let f=|x:Fq|ark_bn254::Fq::from_le_bytes_mod_order(&x.to_canonical().into_iter().flat_map(u64::to_le_bytes).collect::<Vec<_>>());let a=A::new_unchecked(f(p.x),f(p.y));assert!(a.is_on_curve()&&a.is_in_correct_subgroup_assuming_on_curve());a}}
fn from_ark(p:A)->Z{if p.is_zero(){Z::IDENTITY}else{let f=|x:ark_bn254::Fq|Fq::from_canonical(words(&x.into_bigint().to_bytes_le())).unwrap();Z::new(f(p.x),f(p.y))}}
struct Input{k:Vec<Z>,h:Vec<Z>,sk:Vec<[u64;4]>,sh:Vec<[u64;4]>}
impl Input{
 fn load()->Self{let b=fs::read(format!("{R}/fixture.bin")).unwrap();let pins:serde_json::Value=serde_json::from_slice(&fs::read(format!("{R}/capture-pins.json")).unwrap()).unwrap();assert_eq!(sha(&b),pins[format!("{R}/fixture.bin")]);assert_eq!(&b[..8],b"KHBANK01");let nk=u64::from_le_bytes(b[8..16].try_into().unwrap())as usize;let nh=u64::from_le_bytes(b[16..24].try_into().unwrap())as usize;assert_eq!((nk,nh),(30529,30922));assert_eq!(b.len(),24+96*(nk+nh));let mut p=Vec::new();let mut s=Vec::new();for c in b[24..].chunks_exact(96){p.push(decode(&c[..64]));s.push(words(&c[64..]));}let h=p.split_off(nk);let sh=s.split_off(nk);Self{k:p,h,sk:s,sh}}
 fn digest(&self)->String{let mut h=Sha256::new();for(p,s)in self.k.iter().zip(&self.sk).chain(self.h.iter().zip(&self.sh)){h.update(encode(*p));for w in s{h.update(w.to_le_bytes());}}format!("{:x}",h.finalize())}
 fn run(&self,on:bool,want:Z){let got=zopro_core::frame_caller(black_box(&self.k),black_box(&self.sk),black_box(&self.h),black_box(&self.sh),on).to_affine();assert_eq!(got,want);black_box(got);}
}
fn pin(cpu:usize){unsafe{let mut mask:libc::cpu_set_t=std::mem::zeroed();libc::CPU_ZERO(&mut mask);libc::CPU_SET(cpu,&mut mask);assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&mask),&mask),0);}}
fn run(workers:usize,arm:&str,rounds:usize){assert!([1,16,32].contains(&workers));assert!(["OFF","ON"].contains(&arm));assert!([1,17].contains(&rounds));let on=arm=="ON";let input=Input::load();let b=fs::read(format!("{R}/oracle.bin")).unwrap();let pins:serde_json::Value=serde_json::from_slice(&fs::read(format!("{R}/capture-pins.json")).unwrap()).unwrap();assert_eq!(sha(&b),pins[format!("{R}/oracle.bin")]);let want=decode(&b);let digest=input.digest();
 let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).start_handler(move|i|pin(if workers==1{2}else{i})).build().unwrap();let cpus=pool.broadcast(|ctx|{let cpu=unsafe{libc::sched_getcpu()};assert_eq!(cpu,if workers==1{2}else{ctx.index()as i32});cpu});for _ in 0..3{pool.install(||input.run(on,want));}
 let usage0=perf::Usage::now().unwrap();let mut samples=Vec::with_capacity(rounds);for _ in 0..rounds{let now=Instant::now();pool.install(||input.run(on,want));samples.push(now.elapsed().as_nanos()as u64);}let usage1=perf::Usage::now().unwrap();assert_eq!(input.digest(),digest);let cpus_after=pool.broadcast(|ctx|{let cpu=unsafe{libc::sched_getcpu()};assert_eq!(cpu,if workers==1{2}else{ctx.index()as i32});cpu});assert_eq!(cpus,cpus_after);
 println!("{}",json!({"workers":workers,"arm":arm,"rounds":rounds,"primes":3,"samples_ns":samples,"usage":serde_json::from_str::<serde_json::Value>(&usage1.difference(&usage0)).unwrap(),"worker_cpus":cpus,"input_digest":digest,"all_outputs_checked":true,"immutable_inputs":true,"new_proofs":0}));
}
fn qualify(){
 use zopro_bn254::{G1Projective,Field};
 let k:Vec<_>=(0..1024).map(|i|if i%19==0{Z::IDENTITY}else{(Z::GENERATOR*Fr::from((i+1)as u64)).to_affine()}).collect();
 let h:Vec<_>=(0..1025).map(|i|if i%23==0{Z::IDENTITY}else{(-Z::GENERATOR*Fr::from((i+7)as u64)).to_affine()}).collect();
 let mut variants=Vec::new();for mode in 0..4{let mut expected=Fr::ZERO;let mut make=|len:usize,is_h:bool|{(0..len).map(|i|{let scalar=match mode{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,_=>Fr::from((i+73)as u64).pow(&[17])};let weight=if (!is_h&&i%19==0)||(is_h&&i%23==0){Fr::ZERO}else if is_h{-Fr::from((i+7)as u64)}else{Fr::from((i+1)as u64)};expected+=weight*scalar;scalar.to_canonical()}).collect::<Vec<_>>()};let sk=make(k.len(),false);let sh=make(h.len(),true);variants.push((sk,sh,(G1Projective::generator()*expected).to_affine()));}
 let mut checks=0;for workers in[1,2,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();for(sk,sh,want)in &variants{for on in[false,true]{assert_eq!(pool.install(||zopro_core::frame_caller(&k,sk,&h,sh,on).to_affine()),*want);checks+=1;}}
 let(sk,sh,want)=&variants[3];let failed=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||pool.install(||zopro_core::frame_cancel(&k,sk,&h,sh))));assert!(failed.is_err());assert_eq!(pool.install(||zopro_core::frame_caller(&k,sk,&h,sh,true).to_affine()),*want);checks+=1;
 let(a,b)=pool.install(||rayon::join(||zopro_core::frame_caller(&k,sk,&h,sh,true),||zopro_core::frame_caller(&k,sk,&h,sh,true)));assert_eq!(a.to_affine(),*want);assert_eq!(b.to_affine(),*want);checks+=2;
 }
 let pool=rayon::ThreadPoolBuilder::new().num_threads(4).stack_size(512*1024).build().unwrap();std::thread::scope(|scope|{let mut handles=Vec::new();for caller in 0..4{let(pool,k,h,variants)=(&pool,&k,&h,&variants);handles.push(scope.spawn(move||{for round in 0..4{let(sk,sh,want)=&variants[(caller+round)%4];assert_eq!(pool.install(||zopro_core::frame_caller(k,sk,h,sh,true).to_affine()),*want);}}));}for handle in handles{handle.join().unwrap();}});checks+=16;
 println!("{}",json!({"passed":true,"generator_oracle_comparisons":checks,"cancellation_and_reuse_pools":5,"nested_join_pools":5,"concurrent_OS_callers":4,"shared_pool_workers":4,"new_proofs":0}));
}

fn main(){let a=std::env::args().collect::<Vec<_>>();if a.len()==2&&a[1]=="qualify"{qualify()}else{assert_eq!(a.len(),4);run(a[1].parse().unwrap(),&a[2],a[3].parse().unwrap());}}
