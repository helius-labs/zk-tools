fn qualify(){
 use zopro_bn254::{G1Projective,Field};
 let k:Vec<_>=(0..1024).map(|i|if i%19==0{Z::IDENTITY}else{(Z::GENERATOR*Fr::from((i+1)as u64)).to_affine()}).collect();
 let h:Vec<_>=(0..1025).map(|i|if i%23==0{Z::IDENTITY}else{(-Z::GENERATOR*Fr::from((i+7)as u64)).to_affine()}).collect();
 let mut variants=Vec::new();for mode in 0..4{let mut expected=Fr::ZERO;let mut make=|len:usize,is_h:bool|{(0..len).map(|i|{let scalar=match mode{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,_=>Fr::from((i+73)as u64).pow(&[17])};let weight=if (!is_h&&i%19==0)||(is_h&&i%23==0){Fr::ZERO}else if is_h{-Fr::from((i+7)as u64)}else{Fr::from((i+1)as u64)};expected+=weight*scalar;scalar.to_canonical()}).collect::<Vec<_>>()};let sk=make(k.len(),false);let sh=make(h.len(),true);variants.push((sk,sh,(G1Projective::generator()*expected).to_affine()));}
 let mut checks=0;for workers in[1,2,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();for(sk,sh,want)in &variants{for on in[false,true]{assert_eq!(pool.install(||zopro_core::frame_caller(&k,sk,&h,sh,on).to_affine()),*want);checks+=1;}}
 let(sk,sh,want)=&variants[3];let failed=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||pool.install(||zopro_core::frame_cancel(&k,sk,&h,sh))));assert!(failed.is_err());assert_eq!(pool.install(||zopro_core::frame_caller(&k,sk,&h,sh,true).to_affine()),*want);checks+=1;
 let(a,b)=pool.install(||rayon::join(||zopro_core::frame_caller(&k,sk,&h,sh,true),||zopro_core::frame_caller(&k,sk,&h,sh,true)));assert_eq!(a.to_affine(),*want);assert_eq!(b.to_affine(),*want);checks+=2;
 }
 let pool=rayon::ThreadPoolBuilder::new().num_threads(4).stack_size(512*1024).build().unwrap();std::thread::scope(|scope|{let mut handles=Vec::new();for caller in 0..4{let(pool,k,h,variants)=(&pool,&k,&h,&variants);handles.push(scope.spawn(move||{for round in 0..4{let(sk,sh,want)=&variants[(caller+round)%4];assert_eq!(pool.install(||zopro_core::frame_caller(k,sk,h,sh,true).to_affine()),*want);}}));}for handle in handles{handle.join().unwrap();}});checks+=16;
 println!("{}",json!({"passed":true,"generator_oracle_comparisons":checks,"cancellation_and_reuse_pools":5,"nested_join_pools":5,"concurrent_OS_callers":4,"shared_pool_workers":4,"new_proofs":0}));
}
