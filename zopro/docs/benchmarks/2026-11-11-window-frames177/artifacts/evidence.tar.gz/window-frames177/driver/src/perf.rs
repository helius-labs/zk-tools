//! Optional perf control and process accounting for SDK benchmarks.
use std::{
    fs::{File, OpenOptions},
    io::{self, Read, Write},
    path::Path,
    time::{Duration, Instant},
};

pub struct Control {
    command: File,
    acknowledgement: File,
    enabled: bool,
}

impl Control {
    pub fn from_env() -> io::Result<Option<Self>> {
        match (
            std::env::var_os("ZOPRO_BENCH_PERF_CTL"),
            std::env::var_os("ZOPRO_BENCH_PERF_ACK"),
        ) {
            (None, None) => Ok(None),
            (Some(command), Some(ack)) => {
                Self::open(Path::new(&command), Path::new(&ack)).map(Some)
            }
            _ => Err(io::Error::other(
                "both perf control FIFO paths are required",
            )),
        }
    }

    #[cfg(target_os = "linux")]
    fn open(command: &Path, acknowledgement: &Path) -> io::Result<Self> {
        use std::os::unix::{
            fs::{FileTypeExt, OpenOptionsExt},
            io::AsRawFd,
        };
        let open = |path: &Path| -> io::Result<File> {
            if !std::fs::metadata(path)?.file_type().is_fifo() {
                return Err(io::Error::other("perf control path must be a FIFO"));
            }
            let file = OpenOptions::new()
                .read(true)
                .write(true)
                .custom_flags(libc::O_NONBLOCK | libc::O_CLOEXEC)
                .open(path)?;
            // Check the opened descriptor as well as the path before using it.
            if !file.metadata()?.file_type().is_fifo() || file.as_raw_fd() < 0 {
                return Err(io::Error::other("invalid perf FIFO"));
            }
            Ok(file)
        };
        Ok(Self {
            command: open(command)?,
            acknowledgement: open(acknowledgement)?,
            enabled: false,
        })
    }

    #[cfg(not(target_os = "linux"))]
    fn open(_: &Path, _: &Path) -> io::Result<Self> {
        Err(io::Error::other("perf control currently requires Linux"))
    }

    #[cfg(target_os = "linux")]
    fn send(&mut self, command: &[u8]) -> io::Result<()> {
        use std::os::fd::AsRawFd;
        self.command.write_all(command)?;
        self.command.flush()?;
        let deadline = Instant::now() + Duration::from_secs(3);
        let mut reply = Vec::with_capacity(32);
        loop {
            let remaining = deadline.saturating_duration_since(Instant::now());
            if remaining.is_zero() {
                return Err(io::Error::new(
                    io::ErrorKind::TimedOut,
                    "perf acknowledgement timed out",
                ));
            }
            let mut descriptor = libc::pollfd {
                fd: self.acknowledgement.as_raw_fd(),
                events: libc::POLLIN,
                revents: 0,
            };
            // SAFETY: poll receives one initialized descriptor valid through the call.
            let result = unsafe {
                libc::poll(
                    &mut descriptor,
                    1,
                    remaining.as_millis().max(1).min(i32::MAX as u128) as i32,
                )
            };
            if result < 0 {
                let error = io::Error::last_os_error();
                if error.kind() == io::ErrorKind::Interrupted {
                    continue;
                }
                return Err(error);
            }
            if result == 0 {
                continue;
            }
            let mut bytes = [0u8; 32];
            match self.acknowledgement.read(&mut bytes) {
                Ok(0) => {
                    return Err(io::Error::new(
                        io::ErrorKind::UnexpectedEof,
                        "perf acknowledgement closed",
                    ))
                }
                Ok(n) => reply.extend_from_slice(&bytes[..n]),
                Err(error) if error.kind() == io::ErrorKind::WouldBlock => continue,
                Err(error) => return Err(error),
            }
            if reply.len() > 64 {
                return Err(io::Error::other("oversized perf acknowledgement"));
            }
            if reply.contains(&b'\n') {
                if reply
                    .split(|b| b.is_ascii_whitespace() || *b == 0)
                    .filter(|s| !s.is_empty())
                    .eq([b"ack".as_slice()])
                {
                    return Ok(());
                }
                return Err(io::Error::other("invalid perf acknowledgement"));
            }
        }
    }

    #[cfg(not(target_os = "linux"))]
    fn send(&mut self, _: &[u8]) -> io::Result<()> {
        Err(io::Error::other("perf control requires Linux"))
    }

    pub fn enable(&mut self) -> io::Result<()> {
        self.send(b"enable\n")?;
        self.enabled = true;
        Ok(())
    }
    pub fn disable(&mut self) -> io::Result<()> {
        if self.enabled {
            self.enabled = false;
            self.send(b"disable\n")?;
        }
        Ok(())
    }
}
impl Drop for Control {
    fn drop(&mut self) {
        let _ = self.disable();
    }
}

pub struct Usage(libc::rusage);
impl Usage {
pub fn now()->io::Result<Self>{let mut u=std::mem::MaybeUninit::<libc::rusage>::uninit();if unsafe{libc::getrusage(libc::RUSAGE_SELF,u.as_mut_ptr())}!=0{return Err(io::Error::last_os_error());}Ok(Self(unsafe{u.assume_init()}))}
pub fn difference(&self,before:&Self)->String{let ms=|t:libc::timeval|t.tv_sec as f64*1000.+t.tv_usec as f64/1000.;format!("{{\"user_cpu_ms\":{},\"system_cpu_ms\":{},\"minor_faults\":{},\"major_faults\":{},\"voluntary_switches\":{},\"involuntary_switches\":{},\"whole_process_maxrss_kib\":{}}}",ms(self.0.ru_utime)-ms(before.0.ru_utime),ms(self.0.ru_stime)-ms(before.0.ru_stime),self.0.ru_minflt-before.0.ru_minflt,self.0.ru_majflt-before.0.ru_majflt,self.0.ru_nvcsw-before.0.ru_nvcsw,self.0.ru_nivcsw-before.0.ru_nivcsw,self.0.ru_maxrss)} }
