//! Private fixed-drainer scheduling experiment, using unchanged point kernels.
use super::*;
use std::sync::{OnceLock,atomic::{AtomicBool,AtomicUsize,Ordering}};
use zopro_bn254::{G1Affine,G1Projective};
type Partial=(G1Projective,G1Affine);
struct Frame {
    buckets:OnceLock<Vec<G1Affine>>,
    next:AtomicUsize,
    left:AtomicUsize,
    partials:Vec<OnceLock<Partial>>,
    result:OnceLock<G1Projective>,
}
impl Frame {
    fn new(i:usize)->Self {
        let width=(i+1)*255/20-i*255/20;
        let n=(1usize<<(width-1))/256;
        Self{buckets:OnceLock::new(),next:AtomicUsize::new(0),left:AtomicUsize::new(n),partials:(0..n).map(|_|OnceLock::new()).collect(),result:OnceLock::new()}
    }
}
struct Cancel<'a>(&'a AtomicBool);
impl Drop for Cancel<'_>{fn drop(&mut self){if std::thread::panicking(){self.0.store(true,Ordering::Release);}}}
fn run<const FAIL:bool>(k:&[G1Affine],sk:&[[u64;4]],h:&[G1Affine],sh:&[[u64;4]])->G1Projective {
    assert_eq!(k.len(),sk.len());assert_eq!(h.len(),sh.len());
    let frames:Vec<_>=(0..20).map(Frame::new).collect();
    let fill_next=AtomicUsize::new(0);
    let completed=AtomicUsize::new(0);
    let cancelled=AtomicBool::new(false);
    rayon::scope(|scope|{
        for worker in 0..rayon::current_num_threads(){
            let frames=&frames;let fill_next=&fill_next;let completed=&completed;let cancelled=&cancelled;
            scope.spawn(move |_|{
                let _guard=Cancel(cancelled);
                let mut scratch=crate::msm::FrameScratch::default();
                let mut cursor=worker%20;
                loop {
                    if cancelled.load(Ordering::Acquire){return;}
                    if fill_next.load(Ordering::Relaxed)<20 {
                        let i=fill_next.fetch_add(1,Ordering::Relaxed);
                        if i<20 {
                            if FAIL&&i==3 {panic!("injected frame fill failure");}
                            let buckets=super::balanced::frame_fill(k,sk,h,sh,i);
                            assert!(frames[i].buckets.set(buckets).is_ok());
                            continue;
                        }
                    }
                    let mut worked=false;
                    for offset in 0..20 {
                        let i=(cursor+offset)%20;
                        let frame=&frames[i];
                        let Some(buckets)=frame.buckets.get() else {continue};
                        if frame.next.load(Ordering::Relaxed)>=frame.partials.len(){continue;}
                        let chunk=frame.next.fetch_add(1,Ordering::Relaxed);
                        if chunk>=frame.partials.len(){continue;}
                        let first=chunk*256;
                        let partial=scratch.leaf(&buckets[first..first+256]);
                        assert!(frame.partials[chunk].set(partial).is_ok());
                        if frame.left.fetch_sub(1,Ordering::AcqRel)==1 {
                            let parts:Vec<_>=frame.partials.iter().map(|p|*p.get().unwrap()).collect();
                            let sum=crate::msm::frame_finish(&parts);
                            assert!(frame.result.set(sum).is_ok());
                            completed.fetch_add(1,Ordering::Release);
                        }
                        cursor=(i+1)%20;
                        worked=true;break;
                    }
                    if !worked {
                        if completed.load(Ordering::Acquire)==20{return;}
                        rayon::yield_now();
                        std::hint::spin_loop();
                    }
                }
            });
        }
    });
    assert_eq!(completed.load(Ordering::Acquire),20);
    let mut result=G1Projective::IDENTITY;
    for i in (0..20).rev(){let width=(i+1)*255/20-i*255/20;for _ in 0..width{result=result.double();}result+=frames[i].result.get().unwrap();}
    result
}
pub(crate) fn fused(k:&[G1Affine],sk:&[[u64;4]],h:&[G1Affine],sh:&[[u64;4]])->G1Projective{
    if rayon::current_num_threads()==1 {return super::fused(k,sk,h,sh,13);}
    run::<false>(k,sk,h,sh)
}
pub(crate) fn cancellation_probe(k:&[G1Affine],sk:&[[u64;4]],h:&[G1Affine],sh:&[[u64;4]]){let _=run::<true>(k,sk,h,sh);}
