# Window-frame short SDK screen

Caller evidence:16worker primaryK/H paired ratio0.917105,9/9wins, unchanged/lower
RSS but31% more CPU.32worker ratio1.007700,1/9wins,26% more CPU. Test integration
rather than extrapolating isolated service into latency. No operation count or
paper result predicts the integrated gain.

Same native Window/frame/leaf implementation and acceptedflags; route only
bits13 fusedK/H whenworkers>1 and ZOPRO_EXPERIMENT_WINDOW_FRAMES=1. Single-worker
falls through to original caller, avoiding recursive fallback. OFF/ON share one
freshSDK, REF exactacceptedc88a3528. No production change or resource admission.

Preflight all3arms at1x2workers1/16/32 and2x2workers32:12processes,1timedcall+3primes.
Main3blocks×3backings×3cases(1x2w16/32,2x2w32)×3arms=81processes,17timedcalls+3primes.
Use3independently written byte-identical backings perSDK; rotatecases/backings/arms.
DefaultSDKstacks, acceptedallocator/runtimeflags. CPU2for1worker,0..15/0..31forothers.
Freezeallbeforepreflight. Noownedhelper/build/profileoverlap; onlypolllivehandle.

Timer includes fresh assignment/solving/randomness/proving/SDKverify/serialization,
excludesloading/primes/export. RecordCPU/RSS/faults/placement. Verify eachprocess's
lastexport independently withGnark and expectedimage/public bindings after all
capture inthatphase. Extendcanonical54007/SHA
 aab8d06c2d269b1ecbeede37289c505a81a13e17a0e1936c8f32ccff39b4c495
at two-bank-sdk177/proof-sha256-after-main.json. Do not reuseolderledger.

Reportprocessmean medians and matchedON/OFF/REF ratios with3per-backing medians.
All3backing medians mustimprove againstbothcomparators ataprimarycontext toselect
mechanismprofiling/resourceadmission work. Mixedsigns inconclusive; consistent
regressions rejecttheintegration for thatcontext. No sampleextension, min-gainfloor
oradoptionclaim. PreserveCPUincreases as a potential throughput cost. Thisisnot
allshape/ARM/mobile/pressure/C7a qualification. Preparationallowance30minutes,
capture5minutesexcludingverification. Nochanges topubliczopro-parallelAPI.
