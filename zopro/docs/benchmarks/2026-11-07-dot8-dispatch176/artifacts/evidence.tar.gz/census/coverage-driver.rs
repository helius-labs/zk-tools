//! Read only the current admitted solver dispatch; do not solve or prove.
use std::{fs,sync::Arc};
use serde_json::Value;
#[global_allocator]static ALLOCATOR:zopro_prover::zopro_core::alloc::Allocator=zopro_prover::zopro_core::alloc::Allocator;
fn main(){let a=std::env::args().collect::<Vec<_>>();assert_eq!(a.len(),3);rayon::ThreadPoolBuilder::new().num_threads(32).build_global().unwrap();let f=fs::File::open(&a[2]).unwrap();
 // SAFETY: the pinned trusted basis image remains immutable for this process.
 let map=unsafe{memmap2::Mmap::map(&f)}.unwrap();drop(f);let prover=zopro_prover::Prover::load_image(Arc::new(map)).unwrap();let counts:Value=serde_json::from_str(&prover.dot8_coverage().unwrap()).unwrap();assert_eq!(counts["workers"],32);println!("DOT8_COVERAGE {}",serde_json::json!({"shape":a[1],"image":a[2],"counts":counts,"proving_or_solving_performed":false,"new_proofs":0}));}
