//! Diagnostic-only metadata census of the current interpreter dispatch.
use super::*;
use sha2::{Digest,Sha256};
#[derive(Clone,Copy,Default,Debug,PartialEq,Eq)]
struct Count{dot8:u64,pairs:u64,single:u64,terms:u64}
impl Count{
 fn add(&mut self,x:Self){self.dot8+=x.dot8;self.pairs+=x.pairs;self.single+=x.single;self.terms+=x.terms;}
 fn check(self){assert_eq!(8*self.dot8+2*self.pairs+self.single,self.terms);}
 fn json(self)->String{format!("{{\"dot8\":{},\"pairs\":{},\"single\":{},\"terms\":{}}}",self.dot8,self.pairs,self.single,self.terms)}
}
#[derive(Clone,Copy)]struct Meta{stored:bool,chain:bool,wire:usize,coefficient:usize}
fn count(len:usize,mode:u8,get:impl Fn(usize)->Meta)->Count{
 let mut out=Count{terms:len as u64,..Count::default()};let mut i=0;
 while i<len{let first=get(i);if mode>=2&&i+8<=len&&(0..8).all(|j|{let s=get(i+j);(j==7||!s.stored)&&(j==0||s.chain)&&s.wire!=0&&s.coefficient>4}){out.dot8+=1;i+=8;}
 else if mode!=0&&!first.stored&&i+1<len&&get(i+1).chain&&first.wire!=0&&get(i+1).wire!=0&&first.coefficient>4&&get(i+1).coefficient>4{out.pairs+=1;i+=2;}
 else{out.single+=1;i+=1;}}
 out.check();out
}
struct HashWriter{hash:Sha256,length:u64}
impl std::io::Write for HashWriter{fn write(&mut self,bytes:&[u8])->std::io::Result<usize>{self.hash.update(bytes);self.length+=bytes.len()as u64;Ok(bytes.len())}fn flush(&mut self)->std::io::Result<()>{Ok(())}}
fn image_hash(p:&Plan)->(String,u64){let mut w=HashWriter{hash:Sha256::new(),length:0};p.write_image(&mut w).unwrap();assert_eq!(w.length,p.image_len());(format!("{:x}",w.hash.finalize()),w.length)}
impl Plan{
 fn dot8_op_count(&self,index:usize)->Count{match &self.ops[index]{Op::Hint(_)=>Count::default(),Op::Constraint(step)=>{let sums=&self.sums[step.sums()];count(sums.len(),self.fuse_sums,|i|{let s=&sums[i];Meta{stored:s.stored(),chain:matches!(s.previous(),Previous::Chain),wire:s.term.wire(),coefficient:s.term.coefficient()}})}}}
 pub(crate) fn dot8_coverage(&self)->Result<String,String>{
  let before=image_hash(self);let mut raw=Count::default();for i in 0..self.ops.len(){raw.add(self.dot8_op_count(i));}raw.check();
  let mut seen=vec![0u64;self.ops.len().div_ceil(64)];let mut dispatched=Count::default();let mut bypassed=Count::default();let mut dispatched_ops=0;let mut bypassed_ops=0;let mut spans=[0u64;14];let mut leaves=0;let mut tagged_leaves=0;
  let mut visit=|index:usize,skip:bool|{assert!(index<self.ops.len());let bit=1u64<<(index%64);assert_eq!(seen[index/64]&bit,0,"duplicate operation");seen[index/64]|=bit;let n=self.dot8_op_count(index);if skip{bypassed.add(n);bypassed_ops+=1;}else{dispatched.add(n);dispatched_ops+=1;}};
  let mut leaf=|task:&[u32]|{leaves+=1;#[cfg(zopro_resource_schedule)]if self.poseidon_task(task){tagged_leaves+=1;let mut pos=0;while pos<task.len(){let t=(task[pos]>>28)as usize;if t==0{visit((task[pos]&((1<<27)-1))as usize,false);pos+=1;}else{assert!((2..=13).contains(&t));let n=super::sparse_poseidon::dot8_observer_span_len(t);assert!(pos+n<=task.len());for &word in &task[pos..pos+n]{visit((word&((1<<27)-1))as usize,true);}spans[t]+=1;pos+=n;}}return;}for &op in task{visit(op as usize,false);}};
  let schedule=self.schedule.get();let serial=solve_epochs()==0||self.ops.len()<4096||schedule.is_some_and(|s|s.epochs.is_empty());let mut outer_epochs=0;let mut refined_parents=0;
  if serial{for i in 0..self.ops.len(){leaf(&[i as u32]);}}
  else{let schedule=schedule.ok_or("current key has no prepared schedule")?;outer_epochs=schedule.epochs.len();refined_parents=schedule.refined.len();for epoch in &schedule.epochs{for task in epoch{if let Some(waves)=schedule.refined.get(&(task[0]as usize)){for wave in waves{for part in wave{leaf(part);}}}else{leaf(task);}}}}
  drop(leaf);drop(visit);for i in 0..self.ops.len(){assert_ne!(seen[i/64]&(1u64<<(i%64)),0,"unvisited operation");}assert_eq!(dispatched_ops+bypassed_ops,self.ops.len());let mut combined=dispatched;combined.add(bypassed);assert_eq!(combined,raw);dispatched.check();bypassed.check();
  let canonical=self.coefficients.iter().all(|v|v.0.iter().rev().cmp(Fr::MODULUS.iter().rev())==std::cmp::Ordering::Less);assert!(canonical);let after=image_hash(self);assert_eq!(before,after);
  Ok(format!("{{\"ops\":{},\"constraints\":{},\"wires\":{},\"fuse_sums\":{},\"workers\":{},\"serial_fallback\":{},\"outer_epochs\":{},\"refined_parents\":{},\"dispatch_leaves\":{},\"tagged_leaves\":{},\"poseidon_spans_by_width\":{:?},\"dispatched_raw_ops\":{},\"recognized_bypassed_ops\":{},\"raw_plan\":{},\"actual_dispatch\":{},\"recognized_bypassed\":{},\"exactly_once\":true,\"term_conservation\":true,\"all_coefficients_canonical\":{},\"coefficients\":{},\"bitset_bytes\":{},\"solver_image_sha256\":\"{}\",\"solver_image_bytes\":{},\"solver_image_unchanged\":true,\"count_scope\":\"exact metadata branch opportunities on valid current dispatch, not executed field calls or timing\",\"new_proofs\":0}}",self.ops.len(),self.n_constraints,self.n_wires,self.fuse_sums,rayon::current_num_threads(),serial,outer_epochs,refined_parents,leaves,tagged_leaves,spans,dispatched_ops,bypassed_ops,raw.json(),dispatched.json(),bypassed.json(),canonical,self.coefficients.len(),seen.len()*8,before.0,before.1))
 }
}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn greedy_eight_pair_single_storage_and_chain_boundaries(){let d=Meta{stored:false,chain:true,wire:1,coefficient:5};let mut values=[d;16];let c=|v:&[Meta],mode|count(v.len(),mode,|i|v[i]);assert_eq!(c(&values[..8],2),Count{dot8:1,pairs:0,single:0,terms:8});assert_eq!(c(&values,2).dot8,2);assert_eq!(c(&values[..7],2),Count{dot8:0,pairs:3,single:1,terms:7});assert_eq!(c(&values[..8],1),Count{dot8:0,pairs:4,single:0,terms:8});assert_eq!(c(&values[..8],0),Count{dot8:0,pairs:0,single:8,terms:8});values[7].stored=true;assert_eq!(c(&values[..8],2).dot8,1);values=[d;16];values[3].stored=true;assert_eq!(c(&values[..8],2),Count{dot8:0,pairs:4,single:0,terms:8});values=[d;16];values[0].stored=true;assert_eq!(c(&values[..8],2),Count{dot8:0,pairs:3,single:2,terms:8});for field in 0..3{values=[d;16];match field{0=>values[3].wire=0,1=>values[3].coefficient=4,_=>values[3].chain=false};let n=c(&values[..8],2);assert_eq!(n.dot8,0);n.check();}assert_eq!(c(&[],2),Count::default());}
}
