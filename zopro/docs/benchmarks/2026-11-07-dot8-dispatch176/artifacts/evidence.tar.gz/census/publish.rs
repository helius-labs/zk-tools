use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::{Path,PathBuf},process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/dot8-preredc176";
const D:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-07-dot8-dispatch176";
fn hash(p:&Path)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn collect(base:&Path,dir:&Path,out:&mut BTreeMap<String,PathBuf>){
 let mut entries=fs::read_dir(dir).unwrap().map(Result::unwrap).collect::<Vec<_>>();entries.sort_by_key(|e|e.file_name());
 for e in entries{let ft=e.file_type().unwrap();assert!(!ft.is_symlink());let p=e.path();let name=e.file_name();let name=name.to_str().unwrap();
  if ft.is_dir(){if !["source","target-coverage","driver","publication-stage"].contains(&name){collect(base,&p,out);}continue}
  assert!(ft.is_file());if ![".rs",".json",".log",".md",".txt",".toml",".lock"].iter().any(|s|name.ends_with(s)){continue}
  let relative=p.strip_prefix(base).unwrap().to_str().unwrap();assert!(!relative.starts_with('/')&&!relative.split('/').any(|s|s==".."));
  assert!(out.insert(format!("census/{relative}"),p).is_none());
 }
}
fn main(){
 let review:Value=serde_json::from_slice(&fs::read(format!("{R}/coverage-review.json")).unwrap()).unwrap();
 assert_eq!(review["passed"],true);assert_eq!(review["new_proofs"],0);assert_eq!(review["qualified_for_mathematical_screen"],true);
 let mut files=BTreeMap::new();collect(Path::new(R),Path::new(R),&mut files);
 let audit:Value=serde_json::from_slice(&fs::read(format!("{R}/coverage-source-audit.json")).unwrap()).unwrap();
 for n in audit["append_only_parents"].as_object().unwrap().keys().map(String::as_str).chain(std::iter::once(audit["new_child"].as_str().unwrap())){
  assert!(!n.starts_with('/')&&!n.split('/').any(|s|s==".."));files.insert(format!("census/source/{n}"),Path::new(R).join("source").join(n));
 }
 for n in ["Cargo.toml","Cargo.lock","src/main.rs"]{files.insert(format!("census/driver/{n}"),Path::new(R).join("driver").join(n));}
 files.insert("report.md".into(),Path::new(D).join("README.md"));
 let stage=Path::new(R).join("publication-stage");assert!(!stage.exists());fs::create_dir(&stage).unwrap();let mut members=BTreeMap::new();
 for(name,src)in &files{let bytes=fs::read(src).unwrap();assert!(!bytes.contains(&0),"non-text {name}");let dst=stage.join(name);fs::create_dir_all(dst.parent().unwrap()).unwrap();fs::write(&dst,&bytes).unwrap();let h=hash(src);assert_eq!(hash(&dst),h);members.insert(name.clone(),h);}
 let artifacts=Path::new(D).join("artifacts");assert!(!artifacts.exists());fs::create_dir(&artifacts).unwrap();
 fs::write(artifacts.join("evidence-members.json"),serde_json::to_vec_pretty(&json!({"files":members,"members":members.len(),"excluded":"images, witness/request/public/proof payloads, executables, libraries, targets and raw performance recordings"})).unwrap()).unwrap();
 let list=Path::new(R).join("publication-members.txt");assert!(!list.exists());fs::write(&list,members.keys().map(|s|format!("{s}\n")).collect::<String>()).unwrap();
 let archive=artifacts.join("evidence.tar.gz");assert!(Command::new("tar").arg("-czf").arg(&archive).arg("-C").arg(&stage).arg("--files-from").arg(&list).status().unwrap().success());
 let listing=Command::new("tar").arg("-tzf").arg(&archive).output().unwrap();assert!(listing.status.success());assert_eq!(listing.stdout,fs::read(&list).unwrap());
 assert!(Command::new("tar").arg("-dzf").arg(&archive).arg("-C").arg(&stage).status().unwrap().success());
 for(name,h)in &members{assert_eq!(hash(&stage.join(name)),*h);assert_eq!(hash(&files[name]),*h);}
 let checksum=format!("{}  evidence.tar.gz\n",hash(&archive));fs::write(artifacts.join("SHA256SUMS"),&checksum).unwrap();println!("PASS {} safe text members; list/hash/archive comparison; {}",members.len(),checksum.trim());
}
