#![recursion_limit="256"]
use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/fixed-factor-fft176";const P:&str="/home/ubuntu/src/zopro-perf-work/fixed-factor-native176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
const C:&str="all(zopro_fixed_fft,zopro_fixed_factor_trunc,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma))";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(n:&str,v:Value){fs::write(format!("{R}/{n}"),serde_json::to_vec_pretty(&v).unwrap()).unwrap()}
fn replace(s:&mut String,old:&str,new:&str){assert_eq!(s.matches(old).count(),1,"anchor {old}");*s=s.replacen(old,new,1);}
fn base(step:&Value,generic:bool)->Value {
    let mut out=step.clone();let a=step["argv"].as_array().unwrap();let mut v:Vec<String>=vec![];let mut i=0;
    while i<a.len(){let s=a[i].as_str().unwrap();if s=="--cfg"&&a[i+1].as_str().unwrap().starts_with("zopro_joint_"){i+=2;continue;}
        if s=="-C"&&["debug-assertions=yes","overflow-checks=yes"].contains(&a[i+1].as_str().unwrap()){i+=2;continue;}
        v.push(s.replace("/home/ubuntu/src/zopro-perf-work/joint-coordinate-delta-callers176",R).replace("/home/ubuntu/src/zopro-perf-work/joint-coordinate-delta176",P).replace("libzopro_bn254.rlib","libzopro_bn254-release.rlib"));i+=1;}
    v.extend(["--cfg","zopro_fixed_fft","--cfg","zopro_fixed_factor_trunc","--cfg","zopro_fixed_fft_diagnostics","-C","debug-assertions=no","-C","overflow-checks=no"].map(str::to_owned));
    if generic{for s in &mut v{*s=s.replace("libzopro_bn254-release.rlib","libzopro_bn254-generic.rlib");}}
    out["argv"]=json!(v);if let Some(env)=out["environment"].as_object_mut(){for s in env.values_mut(){if let Some(text)=s.as_str(){*s=json!(text.replace("/home/ubuntu/src/zopro-perf-work/joint-coordinate-delta-callers176",R));}}}
    out
}
fn main(){assert!(!Path::new(&format!("{R}/source")).exists());assert_eq!(read(format!("{P}/codegen-review.json"))["passed"],true);
    for(p,h)in read(format!("{P}/codegen-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
    let manifest=format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");let m=read(&manifest);let mut pins=BTreeMap::new();
    for(rel,h)in m["source_files_sha256"].as_object().unwrap(){assert_eq!(hash(format!("{Z}/{rel}")),h.as_str().unwrap());let to=format!("{R}/source/{rel}");fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(format!("{P}/source/{rel}"),&to).unwrap();}
    let child="crates/zopro-bn254/src/ifma8/fixed_factor.rs";let to=format!("{R}/source/{child}");fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(format!("{P}/source/{child}"),&to).unwrap();
    let path=format!("{R}/source/crates/zopro-core/src/fft.rs");let mut fft=fs::read_to_string(&path).unwrap();
    replace(&mut fft,"struct Twiddles {",&format!("#[cfg({C})]\nmod fixed_roots;\n\nstruct Twiddles {{\n    #[cfg({C})]\n    fixed: Option<Box<fixed_roots::FixedRoots>>,"));
    assert_eq!(fft.matches("reservations: Vec::new(),").count(),3);
    fft=fft.replace("reservations: Vec::new(),",&format!("reservations: Vec::new(),\n            #[cfg({C})]\n            fixed: None,"));
    replace(&mut fft,"        super::trace(\"plan-roots\", started);",&format!("        #[cfg({C})] {{\n            roots.fixed=fixed_roots::FixedRoots::prepare(&roots);\n            inverse_roots.fixed=fixed_roots::FixedRoots::prepare(&inverse_roots);\n            if let Some((forward,_))=&mut twisted{{forward.fixed=fixed_roots::FixedRoots::prepare(forward);}}\n        }}\n        super::trace(\"plan-roots\", started);"));
    fft+=&format!("\n#[cfg(all({C},zopro_fixed_fft_diagnostics))]\n#[doc(hidden)]\npub mod fixed_fft_diagnostics {{\n    use super::*;\n    pub use super::fixed_roots::diag::DenyGuard;\n    pub fn counters()->[usize;5]{{fixed_roots::diag::counters()}}\n    pub fn snapshots(p:&Plan)->[[usize;4];3]{{fixed_roots::diag::snapshots(p)}}\n    pub fn unique_charged(p:&Plan)->usize{{fixed_roots::diag::unique_charged(p)}}\n    pub fn clear(p:&mut Plan){{fixed_roots::diag::clear(p)}}\n    pub fn force_denial()->DenyGuard{{fixed_roots::diag::force_denial()}}\n    pub fn transform(p:&Plan,a:Vec<Fr>,b:Vec<Fr>,direction:u8)->(Vec<Fr>,Vec<Fr>){{pair::fixed_fft_transform(p,a,b,direction)}}\n    pub fn inline_option_bytes()->usize{{core::mem::size_of::<Option<Box<fixed_roots::FixedRoots>>>()}}\n}}\n");fs::write(&path,fft).unwrap();
    let path=format!("{R}/source/crates/zopro-core/src/fft/pair/leaf.rs");let mut leaf=fs::read_to_string(&path).unwrap();
    for (stem,level) in [("dif","level"),("dit","roots.layers.len()-1-gap.trailing_zeros() as usize")] {
        let original=format!("        for chunk in values.chunks_exact_mut(gap*2) {{\n            let (lo,hi)=chunk.split_at_mut(gap);\n            {stem}_quads(lo,hi,layer);\n        }}");
        let replacement=format!("        #[cfg({C})]\n        if let Some(fixed)=roots.fixed.as_ref().and_then(|r|r.layer({level})) {{\n            for chunk in values.chunks_exact_mut(gap*2){{let(lo,hi)=chunk.split_at_mut(gap);fixed_{stem}_quads(lo,hi,&fixed[..gap]);}}\n        }} else {{\n{original}\n        }}\n        #[cfg(not({C}))]\n        {{\n{original}\n        }}");replace(&mut leaf,&original,&replacement);
    }
    for (original,new) in [("        dif_within(&mut a[0],&mut b[0],&broadcast(&roots.pair));","fixed_dif_within(&mut a[0],&mut b[0],fixed.pair());"),("        dit_within(&mut a[0],&mut b[0],&broadcast(&roots.pair),roots.single.as_ref().map(broadcast).as_ref());","fixed_dit_within(&mut a[0],&mut b[0],fixed.pair(),fixed.single());")] {
        let replacement=format!("        #[cfg({C})]\n        if let Some(fixed)=&roots.fixed{{{new}}}else{{\n{original}\n        }}\n        #[cfg(not({C}))]\n{original}");replace(&mut leaf,original,&replacement);
    }
    let helpers=fs::read_to_string(format!("{R}/leaf-fixed.rs")).unwrap().replace("#[inline(always)]",&format!("#[cfg({C})]\n#[inline(always)]"));leaf+=&format!("\n{helpers}");fs::write(&path,leaf).unwrap();
    let path=format!("{R}/source/crates/zopro-core/src/fft/pair.rs");let mut pair=fs::read_to_string(&path).unwrap();pair+=&format!("\n#[cfg(all({C},zopro_fixed_fft_diagnostics))]\n{}",fs::read_to_string(format!("{R}/diagnostics.rs")).unwrap());fs::write(&path,pair).unwrap();
    let child2="crates/zopro-core/src/fft/fixed_roots.rs";fs::copy(format!("{R}/fixed-roots.rs"),format!("{R}/source/{child2}")).unwrap();
    let mut changed=vec![];for(rel,h)in m["source_files_sha256"].as_object().unwrap(){let path=format!("{R}/source/{rel}");if hash(&path)!=h.as_str().unwrap(){changed.push(rel.clone());}pins.insert(path.clone(),hash(path));}assert_eq!(changed.len(),4);
    for child in [child,child2]{let path=format!("{R}/source/{child}");pins.insert(path.clone(),hash(path));}
    save("source-audit.json",json!({"passed":true,"source_entries":178,"exact_originals":172,"changed_originals":changed,"field_child_exact_parent":true,"production_changed":false,"candidate_guard":C}));
    let template=read("/home/ubuntu/src/zopro-perf-work/joint-coordinate-delta-callers176/plan.json");let mut core=base(&template["steps"][0],false);core["name"]=json!("build-normal-release-fixed-factor-fft-core");fs::create_dir_all(format!("{R}/libs/ON")).unwrap();fs::create_dir_all(format!("{R}/libs/OFF")).unwrap();
    let mut link=base(&template["steps"][1],false);link["name"]=json!("link-independent-complete-fft-oracles");link["argv"]=json!(link["argv"].as_array().unwrap().iter().map(|s|s.as_str().unwrap().replace("caller-tests","fft-tests")).collect::<Vec<_>>());
    let mut execute=template["steps"][2].clone();execute["name"]=json!("qualify-complete-fixed-factor-fft-consumers");execute["argv"]=json!([format!("{R}/fft-tests"),"--nocapture","--test-threads=1"]);execute["required_tests"]=json!(["independent_complete_transforms_and_consumers","short_padded_and_zero_consumers","admission_release_rebuild_and_forced_fallback","concurrent_small_stack_workers"]);
    execute["environment"]=core["environment"].clone();execute["environment"]["ZOPRO_CPU_TWISTED_FFT"]=json!("1");execute["environment"]["ZOPRO_CPU_QUOTIENT8"]=json!("1");
    let mut generic=base(&template["steps"][3],true);generic["name"]=json!("compile-fixed-factor-fft-generic-guard");
    let mut budget_link=link.clone();budget_link["name"]=json!("link-real-zero-budget-fft-oracle");let ba=budget_link["argv"].as_array().unwrap();budget_link["argv"]=json!(ba.iter().filter(|s|s.as_str()!=Some("--test")).map(|s|s.as_str().unwrap().replace("fft-tests","budget-tests")).collect::<Vec<_>>());
    let mut budget_run=execute.clone();budget_run["name"]=json!("qualify-real-zero-admission-budget");budget_run["argv"]=json!([format!("{R}/budget-tests")]);budget_run.as_object_mut().unwrap().remove("required_tests");budget_run.as_object_mut().unwrap().remove("unfiltered");budget_run["environment"]["ZOPRO_CPU_PREPARE_MAX_BYTES"]=json!("0");
    let plan=json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":[core,link,execute,generic,budget_link,budget_run]});
    for tail in["prepare.rs","fixed-roots.rs","leaf-fixed.rs","diagnostics.rs","design.md","fft-tests.rs","oracle.rs","budget-tests.rs","source-audit.json"]{let p=format!("{R}/{tail}");pins.insert(p.clone(),hash(p));}
    for p in [manifest,format!("{P}/codegen-review.json"),format!("{P}/source-audit.json")]{pins.insert(p.clone(),hash(p));}
    for step in plan["steps"].as_array().unwrap(){for arg in step["argv"].as_array().unwrap(){let a=arg.as_str().unwrap();let p=a.split_once('=').map_or(a,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.to_owned(),hash(p));}}}
    save("plan.json",plan);let p=format!("{R}/plan.json");pins.insert(p.clone(),hash(p));save("pins.json",json!(pins));println!("prepared178sources/172acceptedexact/4changedparents/2children/6newcommands; no timings");
}
