use ark_bn254::Fr as A;
use ark_ff::{BigInteger,PrimeField,Field,FftField};
use zopro_bn254::Fr as Z;
use zopro_core::fft::{self,Plan,fixed_fft_diagnostics as d};
use std::sync::atomic::{AtomicUsize,Ordering};
static COMPARED:AtomicUsize=AtomicUsize::new(0);
fn az(v:Z)->A{A::from_le_bytes_mod_order(&v.to_canonical().into_iter().flat_map(u64::to_le_bytes).collect::<Vec<_>>())}
fn za(v:A)->Z{Z::from_le_bytes_mod_order(&v.into_bigint().to_bytes_le())}
fn zs(v:&[A])->Vec<Z>{v.iter().copied().map(za).collect()}
fn compare(got:Vec<Z>,expected:&[A],label:&str){assert_eq!(got.len(),expected.len(),"{label}");for(i,(got,&expected))in got.into_iter().zip(expected).enumerate(){assert_eq!(az(got),expected,"{label} index={i}");}COMPARED.fetch_add(expected.len(),Ordering::Relaxed);}
fn comparisons()->usize{COMPARED.load(Ordering::Acquire)}
fn root(n:usize,power:u64)->A{let r=A::get_root_of_unity(n as u64).unwrap().pow([power]);assert_eq!(r.pow([n as u64]),A::ONE);assert_ne!(r.pow([(n/2)as u64]),A::ONE);r}
fn plan(n:usize,power:u64,coset:u64)->(Plan,A,A){let r=root(n,power);let c=A::from(coset);let den=(c.pow([n as u64])-A::ONE).inverse().unwrap();(Plan::new(n,za(r),za(c),za(den)),r,c)}
fn terms(n:usize,seed:u64)->(Vec<(usize,A)>,Vec<(usize,A)>){(vec![(0,A::from(seed+1)),(1,A::from(7u64)),(n/2+1,A::from(13u64)),(n-1,-A::ONE)],vec![(2,A::from(11u64)),(n/3,A::from(seed+19)),(n-2,A::from(23u64))])}
fn eval(n:usize,r:A,c:A,terms:&[(usize,A)])->Vec<A>{let mut out=vec![A::ZERO;n];for &(k,a)in terms{let step=r.pow([k as u64]);let mut v=a*c.pow([k as u64]);for out in &mut out{*out+=v;v*=step;}}out}
fn derivative(terms:&[(usize,A)])->Vec<(usize,A)>{terms.iter().map(|&(k,a)|(k,a*A::from(k as u64))).collect()}
fn reverse(i:usize,n:usize)->usize{i.reverse_bits()>>(usize::BITS-n.trailing_zeros())}
fn coefficients(n:usize,terms:&[(usize,A)],scale:A)->Vec<A>{let mut out=vec![A::ZERO;n];for &(k,a)in terms{out[reverse(k,n)]+=a*scale;}out}
fn inverse_dense(v:&[A],n:usize,r:A)->Vec<A>{let rinv=r.inverse().unwrap();let scale=A::from(n as u64).inverse().unwrap();(0..n).map(|k|{let step=rinv.pow([k as u64]);let mut x=A::ONE;let mut acc=A::ZERO;for &a in v{acc+=a*x;x*=step;}acc*scale}).collect()}
fn dense_terms(v:&[A])->Vec<(usize,A)>{v.iter().enumerate().map(|(k,&v)|(k,v)).collect()}
fn euler_expected(a:&[A],b:&[A],n:usize,r:A)->Vec<A>{let ca=dense_terms(&inverse_dense(a,n,r));let cb=dense_terms(&inverse_dense(b,n,r));let da=eval(n,r,A::ONE,&derivative(&ca));let db=eval(n,r,A::ONE,&derivative(&cb));(0..a.len().max(b.len())).map(|i|A::from(n as u64)*(da[i]*b.get(i).copied().unwrap_or(A::ZERO)+db[i]*a.get(i).copied().unwrap_or(A::ZERO))).collect()}
fn check_cache(p:&Plan,directions:usize){let rows=d::snapshots(p);assert_eq!(d::inline_option_bytes(),8);let mut charged=0;for row in rows.iter().take(directions){assert!((1..=31).contains(&row[0]));assert_eq!(row[0],row[1]);assert_eq!(row[2],row[1]*320+row[3]);assert!(row[2]<=31*320+row[3]);charged+=row[2];}assert_eq!(charged,d::unique_charged(p));}
fn sparse_consumers(p:&mut Plan,r:A,c:A,seed:u64,transforms:bool){let n=p.size();let(ta,tb)=terms(n,seed);let a=eval(n,r,A::ONE,&ta);let b=eval(n,r,A::ONE,&tb);let ac=eval(n,r,c,&ta);let bc=eval(n,r,c,&tb);
    if transforms{
        let (ia,ib)=d::transform(p,zs(&a),zs(&b),0);compare(ia,&coefficients(n,&ta,A::from(n as u64)),"inverse a");compare(ib,&coefficients(n,&tb,A::from(n as u64)),"inverse b");
        let ca=coefficients(n,&ta,A::ONE);let cb=coefficients(n,&tb,A::ONE);
        let (fa,fb)=d::transform(p,zs(&ca),zs(&cb),1);compare(fa,&a,"ordinary forward a");compare(fb,&b,"ordinary forward b");
        let (fa,fb)=d::transform(p,zs(&ca),zs(&cb),2);compare(fa,&ac,"twisted forward a");compare(fb,&bc,"twisted forward b");
    }
    compare(p.current_product_study(zs(&a),zs(&b)),&ac.iter().zip(&bc).map(|(&a,&b)|a*b).collect::<Vec<_>>(),"coset product");
    p.prepare_euler_study();
    let da=eval(n,r,A::ONE,&derivative(&ta));let db=eval(n,r,A::ONE,&derivative(&tb));let expected:Vec<_>=(0..n).map(|i|A::from(n as u64)*(da[i]*b[i]+a[i]*db[i])).collect();
    compare(p.euler_product_study(zs(&a),zs(&b)),&expected,"Euler product");
}
