/// Qualification only: production stored transform, without inverse/forward
/// cancellation. Direction 0 is inverse, 1 ordinary forward, 2 coset forward.
pub(super) fn fixed_fft_transform(plan:&Plan,a:Vec<Fr>,b:Vec<Fr>,direction:u8)->(Vec<Fr>,Vec<Fr>) {
    assert!(!plan.released&&plan.n>=8&&a.len()==plan.n&&b.len()==plan.n);
    let mut values:Vec<PackedPair>=(0..plan.n/4).map(|i|PackedPair::store(Pair::new(&core::array::from_fn(|j|if j<4{a[4*i+j]}else{b[4*i+j-4]})))).collect();
    match direction {
        0=>stored_transform::<PackedPair,false>(&mut values,&plan.inverse_roots,0),
        1=>stored_transform::<PackedPair,true>(&mut values,&plan.roots,0),
        2=>stored_transform::<PackedPair,true>(&mut values,&plan.twisted.as_ref().expect("twisted plan").0,0),
        _=>panic!("invalid direction"),
    }
    let(mut a,mut b)=(Vec::with_capacity(plan.n),Vec::with_capacity(plan.n));
    for value in values{let lanes=value.load().get();a.extend_from_slice(&lanes[..4]);b.extend_from_slice(&lanes[4..]);}
    (a,b)
}
