use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-screen176";
const N: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-native176";
const CASES: [&str; 16] = [
    "fq256_mul1",
    "fq256_mul4",
    "fq256_sum1",
    "fq256_diff1",
    "fr256_mul1",
    "fr256_mul4",
    "fr256_sum1",
    "fr256_diff1",
    "fq260_mul1",
    "fq260_mul4",
    "fq260_sum1",
    "fq260_diff1",
    "fr260_mul1",
    "fr260_mul4",
    "fr260_sum1",
    "fr260_diff1",
];
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn write(name: &str, x: &Value) {
    fs::write(format!("{R}/{name}"), serde_json::to_vec_pretty(x).unwrap()).unwrap();
}
fn summary(mut v: Vec<f64>) -> Value {
    assert_eq!(v.len(), 15);
    let wins = v.iter().filter(|&&x| x < 1.).count();
    v.sort_by(f64::total_cmp);
    json!({"low":v[3],"median":v[7],"high":v[11],"wins":wins,"ratios_sorted":v})
}
fn output(step: &str) -> Value {
    let s = fs::read_to_string(format!("{R}/runs/{step}/stdout.log")).unwrap();
    serde_json::from_str(s.trim()).unwrap()
}
fn code_range(role: &str, symbol: &str) -> (u64, u64) {
    let text = fs::read_to_string(format!("{N}/disassembly/{role}-{symbol}.txt")).unwrap();
    let mut addresses = Vec::new();
    for l in text.lines() {
        if let Some((a, _)) = l.trim().split_once(':') {
            if let Ok(a) = u64::from_str_radix(a, 16) {
                addresses.push(a);
            }
        }
    }
    (*addresses.first().unwrap(), *addresses.last().unwrap() + 1)
}
fn elf_exec(path: &str) -> Vec<(u64, u64)> {
    let b = fs::read(path).unwrap();
    assert_eq!(&b[..6], b"\x7fELF\x02\x01");
    let u16at = |k| u16::from_le_bytes(b[k..k + 2].try_into().unwrap());
    let u32at = |k| u32::from_le_bytes(b[k..k + 4].try_into().unwrap());
    let u64at = |k| u64::from_le_bytes(b[k..k + 8].try_into().unwrap());
    let start = u64at(32) as usize;
    let size = u16at(54) as usize;
    let n = u16at(56) as usize;
    let mut out = Vec::new();
    for j in 0..n {
        let k = start + j * size;
        if u32at(k) == 1 && u32at(k + 4) & 1 != 0 {
            out.push((u64at(k + 8) & !4095, u64at(k + 16) & !4095));
        }
    }
    assert!(!out.is_empty());
    out
}
fn profile(case: &str, role: &str) -> Value {
    let name = format!("cycles-{case}-{role}");
    let bin = format!("{N}/driver-{role}");
    let symbol = format!("pair52_{case}");
    let range = code_range(role, &symbol);
    let segments = elf_exec(&bin);
    let meta = fs::read_to_string(format!("{R}/runs/metadata-{name}/stdout.log")).unwrap();
    let decode = fs::read_to_string(format!("{R}/runs/decode-{name}/stdout.log")).unwrap();
    let mut mappings = Vec::new();
    for l in meta
        .lines()
        .filter(|l| l.contains("PERF_RECORD_MMAP2") && l.ends_with(&format!("r-xp {bin}")))
    {
        let rest = l.split("PERF_RECORD_MMAP2 ").nth(1).unwrap();
        let owner = rest.split('/').next().unwrap().parse::<u64>().unwrap();
        let addr = rest.split("[0x").nth(1).unwrap().split('(').next().unwrap();
        let addr = u64::from_str_radix(addr, 16).unwrap();
        let offset = rest
            .split(" @ 0x")
            .nth(1)
            .unwrap()
            .split_whitespace()
            .next()
            .unwrap();
        let offset = u64::from_str_radix(offset, 16).unwrap();
        let (_, vaddr) = segments.iter().find(|(off, _)| *off == offset).unwrap();
        mappings.push((owner, addr - *vaddr));
    }
    assert_eq!(mappings.len(), 1, "exact executable mapping for {name}");
    let (owner, bias) = mappings[0];
    let (mut total, mut target, mut unknown, mut period_bad, mut owner_bad) =
        (0u64, 0u64, 0u64, 0u64, 0u64);
    let mut symbols: BTreeMap<String, u64> = BTreeMap::new();
    let mut ips: BTreeMap<String, u64> = BTreeMap::new();
    for l in decode
        .lines()
        .filter(|l| !l.starts_with('#') && !l.trim().is_empty())
    {
        let f: Vec<_> = l.split_whitespace().collect();
        if f.len() < 6 || !f[0].contains('/') {
            continue;
        }
        let (pid, tid) = f[0].split_once('/').unwrap();
        let (pid, tid) = (pid.parse::<u64>().unwrap(), tid.parse::<u64>().unwrap());
        let cpu = f[1].trim_matches(['[', ']']).parse::<u64>().unwrap();
        let period = f[3].parse::<u64>().unwrap();
        let ip = u64::from_str_radix(f[4].trim_start_matches("0x"), 16).unwrap();
        let sym = f[5];
        total += 1;
        unknown += (sym == "[unknown]") as u64;
        period_bad += (period != 2000000) as u64;
        owner_bad += (pid != owner || tid != owner) as u64;
        *symbols.entry(sym.to_owned()).or_default() += 1;
        if pid == owner
            && tid == owner
            && cpu == 2
            && ip >= bias
            && ip - bias >= range.0
            && ip - bias < range.1
            && sym == symbol
        {
            target += 1;
            *ips.entry(format!("{:x}", ip - bias)).or_default() += 1;
        }
    }
    let lost = meta.matches("PERF_RECORD_LOST").count();
    let qualified = total >= 1000
        && unknown as f64 / total as f64 <= 0.05
        && target as f64 / total as f64 >= 0.95
        && lost == 0
        && period_bad == 0
        && owner_bad == 0;
    json!({"name":name,"qualified":qualified,"samples":total,"target_samples":target,"target_fraction":target as f64/total as f64,"unknown":unknown,"period_bad":period_bad,"owner_bad":owner_bad,"lost_records":lost,
 "owner_pid_tid":owner,"pie_bias":bias,"elf_exec_segments_offset_vaddr":segments,"function_range":range,"cpu":2,"symbols":symbols,"target_static_ip_samples":ips,
 "raw_perf_sha256":hash(format!("{R}/perf/{name}.data")),"decode_stdout_sha256":hash(format!("{R}/runs/decode-{name}/stdout.log")),"metadata_stdout_sha256":hash(format!("{R}/runs/metadata-{name}/stdout.log")),
 "scope":"whole-process user cycles; static IPs bound through ELF executable segment and MMAP2, not exclusive cycles or fault service time"})
}
fn stat(case: &str, role: &str) -> Value {
    let name = format!("stat-{case}-{role}");
    let text = fs::read_to_string(format!("{R}/stat/{name}.csv")).unwrap();
    let mut rows = BTreeMap::new();
    let mut qualified = true;
    for line in text
        .lines()
        .filter(|l| !l.starts_with('#') && !l.trim().is_empty())
    {
        let f: Vec<_> = line.split(';').collect();
        if f.len() < 5 {
            continue;
        }
        let value = f[0].parse::<f64>().unwrap();
        let coverage = f[4].parse::<f64>().unwrap();
        qualified &= coverage >= 90.;
        rows.insert(
            f[2].to_owned(),
            json!({"value":value,"coverage_percent":coverage,"runtime_ns":f[3]}),
        );
    }
    assert_eq!(rows.len(), 4);
    let denom = (1u64 << 24) as f64 * 8. * if case.ends_with("mul4") { 4. } else { 1. };
    json!({"name":name,"qualified":qualified,"rows":rows,"cycles_per_field":rows["cycles:u"]["value"].as_f64().unwrap()/denom,"instructions_per_field":rows["instructions:u"]["value"].as_f64().unwrap()/denom,"csv_sha256":hash(format!("{R}/stat/{name}.csv")),"scope":"whole process including setup/pack/export; not exclusive loop counters"})
}
fn main() {
    assert!(!Path::new(R).join("analysis.json").exists());
    let pins = read(format!("{R}/pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap(), "pin {p}");
    }
    assert_eq!(read(format!("{R}/runs/result.json"))["status"], "complete");
    let plan = read(format!("{R}/plan.json"));
    assert_eq!(plan["steps"].as_array().unwrap().len(), 816);
    let mut receipts = 0;
    for step in plan["steps"].as_array().unwrap() {
        let name = step["name"].as_str().unwrap();
        let d = format!("{R}/runs/{name}");
        let exit = read(format!("{d}/exit.json"));
        assert_eq!(exit["success"], true);
        assert_eq!(exit["returncode"], 0);
        for stream in ["stdout", "stderr"] {
            assert_eq!(
                exit[format!("{stream}_sha256")],
                hash(format!("{d}/{stream}.log"))
            );
        }
        let command = read(format!("{d}/command.json"));
        assert_eq!(
            command["argv"].as_array().unwrap()[4..],
            step["argv"].as_array().unwrap()[..]
        );
        receipts += 1;
    }
    let mut ratios = Vec::new();
    let mut checks = Vec::new();
    let mut aggregate = [vec![0f64; 15], vec![0f64; 15]];
    for (case_index, case) in CASES.iter().enumerate() {
        let mut times = [Vec::new(), Vec::new(), Vec::new()];
        for block in 0..15 {
            let mut outputs = Vec::new();
            for (j, role) in ["accepted", "OFF", "ON"].iter().enumerate() {
                let x = output(&format!("latency-b{block:02}-{case}-{role}"));
                assert_eq!(x["rounds"], 1 << 20);
                assert_eq!(x["case"], *case);
                assert_eq!(x["label"], *role);
                outputs.push(x["output"].clone());
                times[j].push(x["elapsed_ns"].as_u64().unwrap() as f64);
            }
            assert_eq!(outputs[0], outputs[1]);
            assert_eq!(outputs[0], outputs[2]);
        }
        let control = summary((0..15).map(|b| times[1][b] / times[0][b]).collect());
        let calibrated =
            control["low"].as_f64().unwrap() >= 0.97 && control["high"].as_f64().unwrap() <= 1.03;
        checks.push(json!({"case":case,"kind":"calibration","pass":calibrated,"summary":control}));
        let mut comparisons = Vec::new();
        for (j, role) in ["accepted", "OFF"].iter().enumerate() {
            let v: Vec<_> = (0..15).map(|b| times[2][b] / times[j][b]).collect();
            let s = summary(v.clone());
            checks.push(json!({"case":case,"kind":"nonregression","control":role,"pass":s["high"].as_f64().unwrap()<=1.01,"summary":s}));
            if case_index < 4 {
                checks.push(json!({"case":case,"kind":"gain","control":role,"pass":s["high"].as_f64().unwrap()<1.&&s["wins"].as_u64().unwrap()>=11,"summary":s}));
                for b in 0..15 {
                    aggregate[j][b] += v[b].ln() / 4.;
                }
            }
            comparisons.push(json!({"control":role,"summary":s}));
        }
        let denom = (1u64 << 20) as f64 * 8. * if case.ends_with("mul4") { 4. } else { 1. };
        let medians: Vec<_> = times
            .iter()
            .map(|t| summary(t.clone())["median"].as_f64().unwrap() / denom)
            .collect();
        ratios.push(
            json!({"case":case,"ns_per_field_accepted_OFF_ON":medians,"comparisons":comparisons}),
        );
    }
    for (j, role) in ["accepted", "OFF"].iter().enumerate() {
        let s = summary(aggregate[j].iter().map(|x| x.exp()).collect());
        checks.push(json!({"case":"primary equal-log aggregate","kind":"aggregate gain","control":role,"pass":s["high"].as_f64().unwrap()<1.&&s["wins"].as_u64().unwrap()>=11,"summary":s}));
    }
    assert_eq!(checks.len(), 58);
    let mut profiles = Vec::new();
    let mut stats = Vec::new();
    for case in &CASES[..4] {
        for role in ["accepted", "OFF", "ON"] {
            profiles.push(profile(case, role));
            stats.push(stat(case, role));
        }
    }
    for (case, n, prefix) in CASES.iter().map(|c| (*c, 16384, "warmup")).chain(
        CASES[..4]
            .iter()
            .flat_map(|c| [(*c, 1u64 << 24, "stat"), (*c, 1u64 << 26, "cycles")]),
    ) {
        let outputs: Vec<_> = ["accepted", "OFF", "ON"]
            .iter()
            .map(|role| {
                let x = output(&format!("{prefix}-{case}-{role}"));
                assert_eq!(x["rounds"], n);
                x["output"].clone()
            })
            .collect();
        assert_eq!(outputs[0], outputs[1]);
        assert_eq!(outputs[0], outputs[2]);
    }
    let failures: Vec<_> = checks
        .iter()
        .filter(|c| c["pass"] != true)
        .cloned()
        .collect();
    let diagnostics = profiles
        .iter()
        .chain(stats.iter())
        .all(|x| x["qualified"] == true);
    let out = json!({"status":"complete","receipts":receipts,"pins":pins.as_object().unwrap().len(),"timing_observations":720,"checks":checks,"failed_checks":failures,"ratios":ratios,"profiles":profiles,"stats":stats,
 "diagnostics_qualified":diagnostics,"gate":failures.is_empty()&&diagnostics,"decision":if failures.is_empty()&&diagnostics{"select separate complete-caller protocol, no adoption"}else{"close this fixed primitive recipe, no adoption/fullcaller/fullproof"},"new_proofs":0,"production_changed":false});
    write("analysis.json", &out);
    println!(
        "screen analyzed:816receipts/58gates, {}failures, diagnostics={diagnostics}",
        failures.len()
    );
}
