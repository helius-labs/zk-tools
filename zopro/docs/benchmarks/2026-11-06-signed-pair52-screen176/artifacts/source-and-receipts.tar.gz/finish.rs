use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-screen176";
const DEST: &str =
    "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-06-signed-pair52-screen176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn write(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn main() {
    let r = PathBuf::from(R);
    let d = PathBuf::from(DEST);
    assert!(!r.join("review.json").exists());
    let a = read(r.join("analysis.json"));
    assert_eq!(a["status"], "complete");
    assert_eq!(a["receipts"], 816);
    assert_eq!(a["gate"], false);
    assert_eq!(a["diagnostics_qualified"], true);
    let pins = read(r.join("pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    assert_eq!(pins.as_object().unwrap().len(), 275);
    let checks = a["checks"].as_array().unwrap();
    assert_eq!(checks.len(), 58);
    assert_eq!(a["failed_checks"].as_array().unwrap().len(), 8);
    assert!(a["failed_checks"]
        .as_array()
        .unwrap()
        .iter()
        .all(|x| x["kind"] == "nonregression" && x["case"].as_str().unwrap().contains("260_mul")));
    assert_eq!(
        checks
            .iter()
            .filter(|c| c["kind"] == "calibration" && c["pass"] == true)
            .count(),
        16
    );
    let plan = read(r.join("plan.json"));
    let mut raw = Vec::new();
    let mut local = Vec::new();
    let mut members: Vec<String> = [
        "campaign.rs",
        "analyze.rs",
        "start.rs",
        "finish.rs",
        "protocol.json",
        "plan.json",
        "pins.json",
        "analysis-frozen.json",
        "analysis.json",
        "analyze.stdout.log",
        "analyze.stderr.log",
        "workflow.log",
        "workflow-offline-resume.log",
        "offline-initial/repair.json",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect();
    let roles = ["accepted", "OFF", "ON"];
    for step in plan["steps"].as_array().unwrap() {
        let name = step["name"].as_str().unwrap();
        let base = r.join("runs").join(name);
        let exit = read(base.join("exit.json"));
        assert_eq!(exit["success"], true);
        let command = read(base.join("command.json"));
        assert_eq!(
            command["argv"].as_array().unwrap()[4..],
            step["argv"].as_array().unwrap()[..]
        );
        for stream in ["stdout", "stderr"] {
            assert_eq!(
                exit[format!("{stream}_sha256")],
                hash(base.join(format!("{stream}.log")))
            );
        }
        for file in ["command.json", "exit.json", "stderr.log", "tests.json"] {
            members.push(format!("runs/{name}/{file}"));
        }
        if name.starts_with("decode-") || name.starts_with("metadata-") {
            let path = base.join("stdout.log");
            local.push(json!({"kind":"decoded full trace LOCAL ONLY","path":path,"sha256":hash(&path),"bytes":fs::metadata(&path).unwrap().len()}));
        } else {
            members.push(format!("runs/{name}/stdout.log"));
            let output: Value =
                serde_json::from_slice(&fs::read(base.join("stdout.log")).unwrap()).unwrap();
            raw.push(json!({"step":name,"output":output}));
        }
    }
    assert_eq!(raw.len(), 792);
    let timing: Vec<_> = raw
        .iter()
        .filter(|x| x["step"].as_str().unwrap().starts_with("latency-"))
        .collect();
    assert_eq!(timing.len(), 720);
    for row in a["ratios"].as_array().unwrap() {
        let case = row["case"].as_str().unwrap();
        let lookup = |block: usize, role: &str| -> f64 {
            let name = format!("latency-b{block:02}-{case}-{role}");
            timing.iter().find(|x| x["step"] == name).unwrap()["output"]["elapsed_ns"]
                .as_u64()
                .unwrap() as f64
        };
        for (j, comparison) in row["comparisons"].as_array().unwrap().iter().enumerate() {
            let mut ratios: Vec<_> = (0..15)
                .map(|b| lookup(b, "ON") / lookup(b, roles[j]))
                .collect();
            let wins = ratios.iter().filter(|&&x| x < 1.).count();
            ratios.sort_by(f64::total_cmp);
            let s = &comparison["summary"];
            for (key, index) in [("low", 3), ("median", 7), ("high", 11)] {
                assert!((ratios[index] - s[key].as_f64().unwrap()).abs() < 1e-12);
            }
            assert_eq!(s["wins"], wins);
        }
    }
    assert_eq!(
        read(r.join("runs/completed.json"))
            .as_array()
            .unwrap()
            .len(),
        816
    );
    assert!(r.join("runs/attempt-0.json").exists());
    assert!(r.join("runs/attempt-1.json").exists());
    assert!(!r.join("runs/attempt-2.json").exists());
    let resume = fs::read_to_string(r.join("workflow-offline-resume.log")).unwrap();
    assert_eq!(
        resume.lines().filter(|l| l.starts_with("REUSE ")).count(),
        792
    );
    let failed = read(r.join("offline-initial/decode-cycles-fq256_mul1-accepted/exit.json"));
    assert_eq!(failed["success"], false);
    assert_eq!(failed["returncode"], 255);
    for file in ["command.json", "exit.json", "stdout.log", "stderr.log"] {
        members.push(format!(
            "offline-initial/decode-cycles-fq256_mul1-accepted/{file}"
        ));
    }
    let mut total_samples = 0u64;
    let mut min_target = 1f64;
    let mut max_unknown = 0f64;
    for p in a["profiles"].as_array().unwrap() {
        assert_eq!(p["qualified"], true);
        assert_eq!(p["lost_records"], 0);
        assert_eq!(p["owner_bad"], 0);
        assert_eq!(p["period_bad"], 0);
        let samples = p["samples"].as_u64().unwrap();
        total_samples += samples;
        min_target = min_target.min(p["target_fraction"].as_f64().unwrap());
        max_unknown = max_unknown.max(p["unknown"].as_u64().unwrap() as f64 / samples as f64);
        let path = r.join(format!("perf/{}.data", p["name"].as_str().unwrap()));
        assert_eq!(p["raw_perf_sha256"], hash(&path));
        local.push(json!({"kind":"raw perf LOCAL ONLY","path":path,"sha256":hash(&path),"bytes":fs::metadata(&path).unwrap().len()}));
    }
    for s in a["stats"].as_array().unwrap() {
        assert_eq!(s["qualified"], true);
        let file = format!("stat/{}.csv", s["name"].as_str().unwrap());
        assert_eq!(s["csv_sha256"], hash(r.join(&file)));
        members.push(file);
    }
    assert_eq!(a["profiles"].as_array().unwrap().len(), 12);
    assert_eq!(a["stats"].as_array().unwrap().len(), 12);
    let review = json!({"status":"pass","pins":275,"successful_receipts":816,"raw_timing_observations":720,"all_58_checks_reviewed":true,"failed_checks":8,"calibrations_passed":16,
  "paired_ratios_reconstructed_from_raw":32,"profiles_qualified":12,"PMU_panels_qualified":12,"samples":total_samples,"minimum_target_fraction":min_target,"maximum_unknown_fraction":max_unknown,
  "profile_binding":"ELF executable LOAD offset/vaddr + MMAP2 + PID/TID/CPU2 + static function IP interval and symbol",
  "capture_attempts":2,"native_measurement_or_recording_reruns":0,"successful_commands_reused_on_offline_resume":792,"failed_command_attempts_retained":1,
  "repair":"ownership only of twelve root-created0600 perf.data files; no bytes/protocol/source/analyzer changes; resume failed/unstarted offline steps only",
  "reviewer_source_sha256":hash(r.join("finish.rs")),"reviewer_binary_sha256":hash(r.join("finish")),
  "decision":"global fixed recipe fails declared gate on four uniform-radix ordinary contexts; preserve all R256 and fused wins; no subset adoption/fullcaller/fullproof",
  "new_proofs":0,"production_changed":false});
    write(r.join("review.json"), &review);
    write(r.join("raw-observations.json"), &json!(raw));
    write(r.join("local-trace-index.json"), &json!(local));
    for name in [
        "review.json",
        "raw-observations.json",
        "local-trace-index.json",
    ] {
        members.push(name.into());
    }
    for name in [
        "result.json",
        "protocol.json",
        "source-pins.json",
        "completed.json",
        "progress.json",
        "attempt-0.json",
        "attempt-1.json",
        "previous-failure-1.json",
    ] {
        members.push(format!("runs/{name}"));
    }
    fs::create_dir_all(d.join("artifacts")).unwrap();
    for name in [
        "analysis.json",
        "protocol.json",
        "review.json",
        "pins.json",
        "raw-observations.json",
        "local-trace-index.json",
    ] {
        fs::copy(r.join(name), d.join("artifacts").join(name)).unwrap();
    }
    let mut hashes = BTreeMap::new();
    for name in &members {
        let bytes = fs::read(r.join(name)).unwrap();
        std::str::from_utf8(&bytes).unwrap();
        hashes.insert(name.clone(), format!("{:x}", Sha256::digest(bytes)));
    }
    write(d.join("artifacts/archive-members.json"), &json!(hashes));
    let archive = d.join("artifacts/source-and-receipts.tar.gz");
    assert!(Command::new("tar")
        .arg("-czf")
        .arg(&archive)
        .arg("-C")
        .arg(&r)
        .arg("--")
        .args(&members)
        .status()
        .unwrap()
        .success());
    let listing = Command::new("tar")
        .arg("-tzf")
        .arg(&archive)
        .output()
        .unwrap();
    assert!(listing.status.success());
    assert_eq!(
        String::from_utf8(listing.stdout)
            .unwrap()
            .lines()
            .map(str::to_owned)
            .collect::<Vec<_>>(),
        members
    );
    let extract = r.join("archive-review");
    fs::create_dir(&extract).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&extract)
        .status()
        .unwrap()
        .success());
    for (name, h) in &hashes {
        assert_eq!(&hash(extract.join(name)), h);
    }
    let mut report=String::from("# Signed radix-52 primitive measurements\n\nThe fixed signed-difference recipe improves every measured R256 context and both radices' fused operations, but regresses ordinary R260 multiplication. **The declared overall gate fails**, so this global replacement is not adopted and no full-proof trial is selected. These primitive gains are retained; they are not full-proof speedups.\n\nThe implementation and its focused Arkworks qualification are in the [native report](../2026-11-06-signed-pair52-native176/README.md). Accepted, fresh OFF and candidate binaries were measured on CPU2 of the Ryzen9 9950X. All sixteen OFF/accepted calibration intervals passed. The protocol used fifteen paired, rotating/reversing blocks, 2^20 rounds per sample, with 48 warmups and 720 timing observations. Intervals are paired order statistics 4/8/12 of15: 96.484375% coverage for a median under independent stationary blocks, not family-wise inference. No minimum gain floor, optional extension or favorable subset was used.\n\n## All contexts\n\nTimes are median nanoseconds per lane operation, including fixed initialization, packing and export amortized across the long loop. Ratios are candidate/accepted from paired blocks; smaller is faster. Fresh OFF comparisons and every raw observation are in the linked artifacts.\n\n| Context | Accepted ns | Fresh OFF ns | Candidate ns | Paired ratio [interval] | Wins/15 |\n|---|---:|---:|---:|---:|---:|\n");
    for row in a["ratios"].as_array().unwrap() {
        let t = &row["ns_per_field_accepted_OFF_ON"];
        let s = &row["comparisons"][0]["summary"];
        report.push_str(&format!(
            "| {} | {:.4} | {:.4} | {:.4} | {:.5} [{:.5}, {:.5}] | {} |\n",
            row["case"].as_str().unwrap(),
            t[0].as_f64().unwrap(),
            t[1].as_f64().unwrap(),
            t[2].as_f64().unwrap(),
            s["median"].as_f64().unwrap(),
            s["low"].as_f64().unwrap(),
            s["high"].as_f64().unwrap(),
            s["wins"].as_u64().unwrap()
        ));
    }
    report.push_str("\nFq/R256 ordinary dependent multiplication improves about **3.4%**, the four-state loop **1.6%**, fused sum **12.0%**, and difference **5.3%**, winning all15 paired blocks against both controls in each context. These are genuine measured primitive gains. Ordinary uniform-R260 regressions are about3.6–13.4%, with zero wins in those four contexts. Eight of58 checks fail: both-control nonregression checks for Fq/Fr R260 ordinary one-/four-state multiplication. The primary gains and aggregate checks pass, but they do not override the prospectively declared all-context requirement.\n\nFour-state callers use distinct states in a compiler-rolled stream loop, not four simultaneously register-resident products. Fused callers keep the second product's operands constant across iterations, allowing some preprocessing hoisting. Timed setup/pack/export and these caller properties limit extrapolation to real curve arithmetic. No G1/G2 complete caller or full SDK proof ran.\n\n## Counters and profiles\n\nAll twelve whole-process PMU panels meet the90% coverage requirement, and all twelve cycle profiles qualify. No lost records were detected. Profile ownership is bound using the actual ELF executable segment offset/vaddr, MMAP2, PID/TID, CPU2, symbol and static IP range, accounting for PIE load addresses.\n\n| Fq/R256 context | Accepted cycles/field | Candidate cycles/field | Accepted instructions/field | Candidate instructions/field |\n|---|---:|---:|---:|---:|\n");
    for case in ["fq256_mul1", "fq256_mul4", "fq256_sum1", "fq256_diff1"] {
        let stats = a["stats"].as_array().unwrap();
        let find = |role: &str| {
            stats
                .iter()
                .find(|x| x["name"] == format!("stat-{case}-{role}"))
                .unwrap()
        };
        let x = find("accepted");
        let y = find("ON");
        report.push_str(&format!(
            "| {case} | {:.3} | {:.3} | {:.3} | {:.3} |\n",
            x["cycles_per_field"].as_f64().unwrap(),
            y["cycles_per_field"].as_f64().unwrap(),
            x["instructions_per_field"].as_f64().unwrap(),
            y["instructions_per_field"].as_f64().unwrap()
        ));
    }
    report.push_str(&format!("\nProfiles contain **{total_samples} samples** in total; the minimum target-kernel fraction is {:.4}% and maximum unknown fraction {:.4}%. The candidate executes more instructions yet uses fewer measured cycles in these R256 contexts. This supports keeping the IFMA-versus-additional-arithmetic tradeoff as a useful observation; it does not isolate the causal cost of IFMA dependencies, spills or a cache level. Whole-process PMU numbers include setup/export and are not exclusive loop cycles. Static code/stack findings remain those in the native report; no RSS peak or minimum-RAM measurement is added.\n",100.*min_target,100.*max_unknown));
    report.push_str("\n## Capture and decision\n\nThe initial workflow completed all792 warmup/timing/stat/record commands, then the first offline decode failed: `sudo perf record` had created root-owned mode0600 files. Only ownership of this campaign's twelve data files was changed to the workspace user. The failed receipt is retained. The same frozen plan/pins resumed, reusing all792 successful receipts and executing only the24 failed/unstarted offline commands. No timing, counter or recording was repeated. The frozen analyzer ran once; a separate review reconstructed all32 paired context/control summaries from raw timings, checked all58 gates, verified all816 successful receipts and the profile/counter guards.\n\nThis closes the **global fixed signed-difference replacement** under its declared gate. It does not erase its R256 gains or prove all pairwise algorithms unsuitable. No subset integration, parameter/layout/attribute rescue, unchanged reroll or full-proof speedup claim is selected. The next research question is whether the R256-versus-R260 difference identifies an independent reduction/carry dependency change in the retained arithmetic; existing reduction history must be checked before treating that as a new hypothesis.\n\nProduction source176/SDK6d83 remain unchanged. Accepted local32 1×2 stays **7.928660 ms**, merge54 **161.883899 ms**; inherited132.75MiB RSS is not a new peak or minimum. Proof ledger remains **30,846**. The inherited [all-eight M5 CPU and Metal comparison](../2026-11-06-signed-pair52-model176/README.md#accepted-full-proof-baseline-inherited) is unchanged, and the10× CPU goal remains unmet on all eight shapes. No new AWS/Aeglos, large-circuit, mobile, pressure, swap or concurrent-throughput result exists.\n\n[Analysis and all gates](artifacts/analysis.json), [protocol](artifacts/protocol.json), [review](artifacts/review.json), [raw observations](artifacts/raw-observations.json), [pins](artifacts/pins.json) and [source/receipts](artifacts/source-and-receipts.tar.gz) are preserved. Raw perf files and full decoded trace stdout stay local with a [hash/size index](artifacts/local-trace-index.json). Public artifacts contain no executable, library, key, witness or proof blobs.\n");
    fs::write(d.join("README.md"), report).unwrap();
    let mut sums = BTreeMap::new();
    for name in [
        "README.md",
        "artifacts/analysis.json",
        "artifacts/protocol.json",
        "artifacts/review.json",
        "artifacts/pins.json",
        "artifacts/raw-observations.json",
        "artifacts/local-trace-index.json",
        "artifacts/archive-members.json",
        "artifacts/source-and-receipts.tar.gz",
    ] {
        sums.insert(name, hash(d.join(name)));
    }
    write(d.join("checksums.json"), &json!(sums));
    for (name, h) in &sums {
        assert_eq!(&hash(d.join(name)), h);
    }
    write(
        r.join("publication.json"),
        &json!({"status":"pass","files":10,"utf8_archive_members":members.len(),"local_raw_perf":12,"local_decoded_stdout":24,"archive_roundtrip_members":hashes.len(),"archive_sha256":hash(archive)}),
    );
    println!("review/publication PASS:275pins/816receipts/58gates/12profiles/{}samples/{}archive members",total_samples,members.len());
}
