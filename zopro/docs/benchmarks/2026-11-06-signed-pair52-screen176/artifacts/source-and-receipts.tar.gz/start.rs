use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-screen176";
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    let mode = args[1].as_str();
    match mode {
        "freeze" => {
            assert!(!Path::new(R).join("analysis-frozen.json").exists());
            let mut pins: Value =
                serde_json::from_slice(&fs::read(format!("{R}/pins.json")).unwrap()).unwrap();
            for (p, h) in pins.as_object().unwrap() {
                assert_eq!(hash(p), h.as_str().unwrap());
            }
            for file in ["analyze.rs", "analyze", "start.rs", "start"] {
                let p = format!("{R}/{file}");
                pins[&p] = json!(hash(&p));
            }
            fs::write(
                format!("{R}/pins.json"),
                serde_json::to_vec_pretty(&pins).unwrap(),
            )
            .unwrap();
            fs::write(format!("{R}/analysis-frozen.json"),serde_json::to_vec_pretty(&json!({"status":"frozen before first clock","pins":pins.as_object().unwrap().len(),"analyzer_sha256":hash(format!("{R}/analyze")),"plan_sha256":hash(format!("{R}/plan.json"))})).unwrap()).unwrap();
            println!(
                "analyzer frozen before first clock; {}pins",
                pins.as_object().unwrap().len()
            );
        }
        "pending" => {
            let handle: u64 = args[2].parse().unwrap();
            let note=format!("# CURRENT: SIGNED RADIX-52 PRIMITIVE SCREEN LIVE / QUALIFICATION PUSHED\n\nRoot: {R}\nOwned exec_command session{handle} confirmed LIVE, gated on start.fifo; release once after this checkpoint, then poll SAME handle. Observation timeout is not terminal and never restarts. Workflowstdout workflow.log, progress runs/progress.json. No competing owned CPU/build/helper/hash/archive/analysis during capture. Frozen275pins/816commands:48warmups,720pairedlatencies(15blocks×16contexts×3roles),12whole-process stat,12cycles profiles,24offline decode+metadata. Analyzer frozen BEFORE first clock. No pilot/extension/reroll/sweeps.\n\nNative qualification3750847e05abe71edc04255b85e2ef5844f7d44d PUSHED/exactremoteverified. Root signed-pair52-native176; 178sources/174exact/all176recoverable. Workflow82836 TERMINAL0 all11commands first-success (generator/newtestbuild+4newtests/2fieldlibs/3drivers/3preflights).240096actualSIMDoutputs+240096exports match Arkworks;35oldtestsfiltered. All16preflights accepted/OFF/ONequal.48newdecodes once:80/110IFMAvs100/150, BUTordinaryFq256169->215staticlooprows and5->18vectorRSP/RBPoperandrows; explicitframe0x328->0x618, not livememorypeak. Fourstreamarraylooprolled, not4registerresidentproducts; invariantfusedc/d letsomepreprocessinghoist. No calls selectedloopspans; accepted/OFF instructiontextidenticalall16bodies.262pins/11receiptsreview+publisher9files/128UTF8members/archivehashroundtrip/checksumsPASS. Prepareinitialhelperexit101UTF8binaryfixture fixedONLYbytesnapshotbeforeanynativeexecution;retained.9testunusedwarnings(8old1new),no warningonlyrebuild. Push86828terminal0. No model/build/test/preflight/decode/reviewer/publisher reruns.\n\nSCREEN gates58:16OFF/acceptedcalibs interval[.97,1.03],32candidate/bothnonregupper<=1.01,8primaryFq256(allmul1/mul4/sum1/diff1)gainupper<1+>=11/15wins,2equal-logprimaryaggregatewins. Paired4th/8th/12thof15,96.484375%medianintervalunderstationaryindependentblocks,notfamilywise. No gainfloor/favorablesubset. Counts12>=90%coverage.12wholeprocesscyclesperiod2M,>=1000samples/<=5%unknown/zeroLOST/targetkernel>=95%,ELFexecsegment+MMAP/PID/TID/CPU2/IPbinding. Setup/pack/exportincluded;diagnosticnotexclusivecycles. Equaloutputhashes perblock/case/role/stat/profile mustpass.\n\nFIRST afterterminal0: run frozen analyze ONCE, independently review816receipts/all58gates/profileguards/loopownership; publishdecision/report/commitANDpush/checkpoint. Success selectsseparatecompletecallerprotocolnotadoption; lossclosesfixedrecipe,no width/layout/attribute/signed-sumrescueorunchangedreroll. Do NOT run analyze beforeterminal0 orwhilecapture. Rawdata/fulldecodeLOCALindexes,publictimings/receipts/summaries/source/PMU.\n\nParentmodel6448af92d1 passed240048reductions/1200240exactrows,19pins,firstsuccessRustmodel;reviewdefaultfieldsrepaironly,pushed. Production176/SDK6d83/local32 1x2 7.928660ms/merge54161.883899ms/inherited132.75MiB RSS NOTnewpeak/minRAM/proofledger30846 unchanged. Fullall8CPU10xACTIVE/UNMET0/8, CPU+Metalreportingrequired,no token/timebudget. No newproof/SDK/AWS/Aeglos/huge/mobile/pressure/swap/throughput. Previousstatus-onlyturnNO PROGRESS; thisturnPROGRESS newmath+nativequalification+publication+frozencapture. Noquestions/agents/giantLUT/keycopy/plan/newpools/CASM. Preserve prompt execution mandate.\n\n");
            let handoff = "/home/ubuntu/src/zopro-cpu-perf-handoff.md";
            let old = fs::read_to_string(handoff).unwrap();
            fs::write(handoff, format!("{note}{old}")).unwrap();
            let prompt = "/home/ubuntu/src/zopro-next-agent-prompt.md";
            let old = fs::read_to_string(prompt).unwrap();
            let suffix = &old[old.find("EXECUTION MANDATE FOR THE NEXT AGENT:").unwrap()..];
            fs::write(prompt, format!("{note}{suffix}")).unwrap();
            let p = "/home/ubuntu/src/zopro-perf-work/latest-status.json";
            let mut x: Value = serde_json::from_slice(&fs::read(p).unwrap()).unwrap();
            x["status"] = json!(note);
            x["commit"] = json!("3750847e05abe71edc04255b85e2ef5844f7d44d");
            x["active_experiment"] = json!(R);
            x["current_experiment"] = json!("signed-pair52-screen176 frozen capture live");
            x["next_action"] = json!(format!(
                "poll SAME live handle{handle}; analyzer only after terminal0"
            ));
            x["owned_live_jobs"] = json!([{"exec_command_session":handle,"kind":"gated primitive screen then capture","root":R}]);
            x["capture_handle_file"] = json!(format!("{R}/live.json"));
            x["signed_pair52_native176"] = json!({"root":"/home/ubuntu/src/zopro-perf-work/signed-pair52-native176","status":"qualified/pushed","commit":"3750847e05abe71edc04255b85e2ef5844f7d44d","outputs":240096,"exports":240096,"decodes":48,"adopted":false});
            fs::write(p, serde_json::to_vec_pretty(&x).unwrap()).unwrap();
            fs::write(format!("{R}/live.json"),serde_json::to_vec_pretty(&json!({"status":"LIVE gated start then capture; release once","exec_command_session":handle,"commands":816,"pins":275,"analyzer_frozen":true,"first_unfinished":"poll same handle after release","qualification_commit":"3750847e05abe71edc04255b85e2ef5844f7d44d"})).unwrap()).unwrap();
            println!("checkpoint pending session{handle}, release once");
        }
        _ => panic!("mode"),
    }
}
