use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-screen176";
const N: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-native176";
const CASES: [&str; 16] = [
    "fq256_mul1",
    "fq256_mul4",
    "fq256_sum1",
    "fq256_diff1",
    "fr256_mul1",
    "fr256_mul4",
    "fr256_sum1",
    "fr256_diff1",
    "fq260_mul1",
    "fq260_mul4",
    "fq260_sum1",
    "fq260_diff1",
    "fr260_mul1",
    "fr260_mul4",
    "fr260_sum1",
    "fr260_diff1",
];
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn write(name: &str, x: &Value) {
    fs::write(format!("{R}/{name}"), serde_json::to_vec_pretty(x).unwrap()).unwrap();
}
fn measure(role: &str, case: &str, n: u64, seed: u64) -> Vec<String> {
    vec![
        "taskset".into(),
        "-c".into(),
        "2".into(),
        format!("{N}/driver-{role}"),
        "measure".into(),
        case.into(),
        n.to_string(),
        seed.to_string(),
        role.into(),
    ]
}
fn step(name: String, argv: Vec<String>) -> Value {
    json!({"kind":"command","name":name,"argv":argv,"timeout_seconds":600})
}
fn main() {
    assert!(!Path::new(R).join("plan.json").exists());
    let native = read(format!("{N}/review.json"));
    assert_eq!(native["status"], "pass");
    let mut pins = read(format!("{N}/codegen-pins.json"))
        .as_object()
        .unwrap()
        .clone();
    for (p, h) in &pins {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    for p in [
        format!("{N}/review.json"),
        format!("{N}/codegen.json"),
        format!("{N}/publication.json"),
        format!("{R}/campaign.rs"),
        format!("{R}/campaign"),
        "/usr/bin/perf".into(),
        "/usr/bin/taskset".into(),
        "/usr/bin/sudo".into(),
    ] {
        pins.insert(p.clone(), json!(hash(p)));
    }
    for dir in ["stat", "perf"] {
        fs::create_dir(format!("{R}/{dir}")).unwrap();
    }
    let seed = 0x19a4_783b_ee20_16d5u64;
    let mut steps = Vec::new();
    for case in CASES {
        for role in ["accepted", "OFF", "ON"] {
            steps.push(step(
                format!("warmup-{case}-{role}"),
                measure(role, case, 16384, seed),
            ));
        }
    }
    for block in 0..15usize {
        let mut cases: Vec<_> = (0..16).map(|j| CASES[(j + block) % 16]).collect();
        if block % 2 == 1 {
            cases.reverse();
        }
        for case in cases {
            let roles = ["accepted", "OFF", "ON"];
            let mut roles: Vec<_> = (0..3).map(|j| roles[(j + block) % 3]).collect();
            if block % 2 == 1 {
                roles.reverse();
            }
            for role in roles {
                steps.push(step(
                    format!("latency-b{block:02}-{case}-{role}"),
                    measure(role, case, 1 << 20, seed + block as u64),
                ));
            }
        }
    }
    let primary = &CASES[..4];
    for case in primary {
        for role in ["accepted", "OFF", "ON"] {
            let name = format!("stat-{case}-{role}");
            let mut argv = vec![
                "sudo".into(),
                "-n".into(),
                "perf".into(),
                "stat".into(),
                "--no-big-num".into(),
                "-x".into(),
                ";".into(),
                "-e".into(),
                "{cycles:u,instructions:u,cache-misses:u,branch-misses:u}".into(),
                "-o".into(),
                format!("{R}/stat/{name}.csv"),
                "--".into(),
            ];
            argv.extend(measure(role, case, 1 << 24, seed));
            steps.push(step(name, argv));
        }
    }
    for case in primary {
        for role in ["accepted", "OFF", "ON"] {
            let name = format!("cycles-{case}-{role}");
            let mut argv = vec![
                "sudo".into(),
                "-n".into(),
                "perf".into(),
                "record".into(),
                "--no-buildid-cache".into(),
                "--sample-cpu".into(),
                "--timestamp".into(),
                "-P".into(),
                "-e".into(),
                "cycles:u".into(),
                "-c".into(),
                "2000000".into(),
                "-m".into(),
                "512".into(),
                "-o".into(),
                format!("{R}/perf/{name}.data"),
                "--".into(),
            ];
            argv.extend(measure(role, case, 1 << 26, seed));
            steps.push(step(name, argv));
        }
    }
    for case in primary {
        for role in ["accepted", "OFF", "ON"] {
            let name = format!("cycles-{case}-{role}");
            for (kind, extra) in [
                ("decode", vec![]),
                (
                    "metadata",
                    vec![
                        "--show-mmap-events",
                        "--show-task-events",
                        "--show-lost-events",
                    ],
                ),
            ] {
                let mut argv: Vec<String> = vec![
                    "perf".into(),
                    "script".into(),
                    "--header".into(),
                    "--ns".into(),
                    "-i".into(),
                    format!("{R}/perf/{name}.data"),
                    "-F".into(),
                    "pid,tid,cpu,time,period,ip,sym".into(),
                ];
                argv.extend(extra.into_iter().map(str::to_owned));
                steps.push(step(format!("{kind}-{name}"), argv));
            }
        }
    }
    assert_eq!(steps.len(), 816);
    let proto = json!({"version":1,"native_qualification_commit":"3750847e05abe71edc04255b85e2ef5844f7d44d","cases":CASES,"roles":["accepted","OFF","ON"],"blocks":15,"rounds":1<<20,"warmups":48,"timing_observations":720,"commands":816,
 "cpu":2,"SMT_sibling":18,"owned_concurrent_work":"none during capture; no build/hash/archive/analysis/second workload",
 "seed":seed,"ordering":"case rotation/block reversal; role rotation/block reversal within case",
 "interval":"paired order statistics 4th/8th/12th of 15; central median interval 96.484375% under independent stationary blocks; not family-wise inference",
 "calibration":"all 16 OFF/accepted intervals wholly within [0.97,1.03]",
 "nonregression":"all16 candidate/both-controls upper<=1.01",
 "primary_gain":"all4 Fq/R256 contexts candidate/both-controls upper<1 and >=11/15 wins; no minimum gain floor",
 "aggregate_gain":"equal-log mean across four primary contexts, block-paired; upper<1 and >=11/15wins vs both controls",
 "gate_checks":58,"no_optional_stopping":true,"no_rescue_sweeps_or_rerolls":true,
 "counter_protocol":"12 whole-process grouped cycles/instructions/cache-misses/branch-misses, >=90% coverage; n=2^24; fixed setup/export included, not inversion-exclusive cycles",
 "profile_protocol":"12 whole-process cycles:u at period2M, n=2^26, >=1000 samples, <=5% unknown, zero LOST, PID/TID/MMAP+CPU2 and >=95% samples in target kernel; no extension/pilot",
 "output_checks":"all equal case/block/role hashes and profile/stat outputs at their own equal rounds; no component output is a proof",
 "driver_caveats":"four-stream array loop is rolled, not four products resident; fused c/d invariant allows preprocessing hoist; timed interval includes initialization/pack/export",
 "scope":"primitive screen only, not full callers/proofs/memory peak/mobile/AWS; a loss closes this fixed recipe without favorable subset, not all pairwise algorithms"});
    write("protocol.json", &proto);
    pins.insert(
        format!("{R}/protocol.json"),
        json!(hash(format!("{R}/protocol.json"))),
    );
    write("pins.json", &json!(pins));
    write(
        "plan.json",
        &json!({"version":1,"source_pins":format!("{R}/pins.json"),"environment":{},"steps":steps}),
    );
    write(
        "live.json",
        &json!({"status":"frozen before first clock, not started","pins":pins.len(),"commands":816,"first":"launch plan once"}),
    );
    println!(
        "frozen {}pins/816commands/720paired observations/58gates before first clock",
        pins.len()
    );
}
