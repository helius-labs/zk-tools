use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/toom5-work176";
const RUSTC: &str = "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
const XTASK: &str = "/home/ubuntu/src/zopro-perf-work/sdk-link-flags176/tool-target/release/xtask";
const DEPS: &str = "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
const NUM: &str = "/home/ubuntu/src/zopro-perf-work/word-export176/target-candidate/release/deps";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(name: &str, x: &Value) {
    fs::write(format!("{R}/{name}"), serde_json::to_vec_pretty(x).unwrap()).unwrap();
}
fn main() {
    match std::env::args().nth(1).unwrap().as_str() {
        "prepare" => {
            assert!(!Path::new(R).join("build-plan.json").exists());
            let protocol = json!({"version":1,"kind":"exact fixed wide-word Toom5 work/range screen","points":["0","1","-1","2","-2","3","-3","4","infinity"],
   "signed_exact_divisions":5*(13+2048),"odd_divisors":[3,5,7,9,15],"full_limb_convolutions":6144,
   "full_limb_population":"all32endpointpatterns crossed, ordinary/fused;2048 inherited full52-bit random tuples ordinary/fused",
   "field_checks":240048,"field_population":"Fq/Fr x R256/R260 x ordinary/sum2/complement difference2; each122boundaryvalues crossed+4096random+1024changingchain tuples",
   "symbolic":"same fixed sparse interpolation tape over nine coefficient basis vectors, doubled triangular coefficient bounds, exact integer divisions, all nine outputs identity",
   "range":"normalized three-word signed-top values<2^126; every modeled lane checked signed64; polynomial assembly<3B",
   "work":"all evaluation, widened product, interpolation, exact division and scatter proxy ops counted; add inherited50IFMA cancellation skeleton; reducer ALU/moves/spills/code-size excluded",
   "scope":"mathematics/work screen only; no actual native SIMD/field/kernel/SDK/proof/clock/profile/AWS or memory peak",
   "fixture":"reuse unchanged public signed-pair52-model176/inputs.json for a DIFFERENT arithmetic algorithm; do not rerun the old model",
   "decision":"select native only if complete upstream work/ranges/liveness look credible against accepted; work-count rejection is not a theorem that allToom/native schedules are slower",
   "no_sweep":true,"no_unchanged_reruns":true});
            save("protocol.json", &protocol);
            let mut pins = BTreeMap::new();
            for path in [format!("{R}/model.rs"),format!("{R}/manage.rs"),format!("{R}/manage"),format!("{R}/design.md"),format!("{R}/bounds.md"),format!("{R}/protocol.json"),RUSTC.into(),XTASK.into(),
   format!("{DEPS}/libserde_json-cdebb9338c2784ad.rlib"),format!("{DEPS}/libsha2-16b8f2c03bdf5faa.rlib"),format!("{NUM}/libnum_bigint-c7c8e458843263c8.rlib"),
   "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/inputs.json".into(),"/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/bounds.md".into(),
   "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/result.json".into(),
   "/home/ubuntu/src/zk-tools/zopro/crates/zopro-bn254/src/lib.rs".into(),"/home/ubuntu/src/zk-tools/zopro/crates/zopro-bn254/src/ifma8.rs".into(),
   "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json".into()]{pins.insert(path.clone(),hash(path));}
            save("build-pins.json", &json!(pins));
            let argv = vec![
                RUSTC.to_owned(),
                "--edition=2021".into(),
                "-O".into(),
                format!("{R}/model.rs"),
                "-o".into(),
                format!("{R}/model"),
                "-L".into(),
                format!("dependency={DEPS}"),
                "-L".into(),
                format!("dependency={NUM}"),
                "--extern".into(),
                format!("num_bigint={NUM}/libnum_bigint-c7c8e458843263c8.rlib"),
                "--extern".into(),
                format!("serde_json={DEPS}/libserde_json-cdebb9338c2784ad.rlib"),
                "--extern".into(),
                format!("sha2={DEPS}/libsha2-16b8f2c03bdf5faa.rlib"),
            ];
            save(
                "build-plan.json",
                &json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"environment":{},"steps":[{"kind":"command","name":"build-toom5-work","argv":argv,"timeout_seconds":120}]}),
            );
            println!("prepared{}source/tool/inputpins, one normal Rust model build; no old model execution",pins.len());
        }
        "freeze" => {
            assert_eq!(read(format!("{R}/build/result.json"))["status"], "complete");
            let mut pins = read(format!("{R}/build-pins.json"))
                .as_object()
                .unwrap()
                .clone();
            for (p, h) in &pins {
                assert_eq!(hash(p), h.as_str().unwrap());
            }
            for path in [
                format!("{R}/model"),
                format!("{R}/build-plan.json"),
                format!("{R}/build/result.json"),
            ] {
                pins.insert(path.clone(), json!(hash(path)));
            }
            save("pins.json", &json!(pins));
            save(
                "run-plan.json",
                &json!({"version":1,"source_pins":format!("{R}/pins.json"),"environment":{},"steps":[{"kind":"command","name":"exact-toom5-work","argv":[format!("{R}/model"),R],"timeout_seconds":600}]}),
            );
            println!(
                "frozen{}pins before first new arithmetic execution",
                pins.len()
            );
        }
        _ => panic!("stage"),
    }
}
