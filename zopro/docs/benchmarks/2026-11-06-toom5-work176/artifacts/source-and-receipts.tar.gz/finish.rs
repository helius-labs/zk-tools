use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/toom5-work176";
const REPO: &str = "/home/ubuntu/src/zk-tools";
const DEST: &str = "zopro/docs/benchmarks/2026-11-06-toom5-work176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn write(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn main() {
    let r = PathBuf::from(R);
    let dest = Path::new(REPO).join(DEST);
    assert!(!r.join("review.json").exists());
    let pins = read(r.join("pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap(), "pin {p}");
    }
    assert_eq!(pins.as_object().unwrap().len(), 22);
    let result = read(r.join("result.json"));
    let symbolic = read(r.join("symbolic.json"));
    let proto = read(r.join("protocol.json"));
    assert_eq!(result["status"], "pass");
    assert_eq!(symbolic["status"], "pass");
    assert_eq!(result["symbolic_sha256"], hash(r.join("symbolic.json")));
    let mut receipt_count = 0;
    for (dir, plan) in [("build", "build-plan.json"), ("run", "run-plan.json")] {
        assert_eq!(read(r.join(dir).join("result.json"))["status"], "complete");
        assert!(!r.join(dir).join("attempt-1.json").exists());
        for step in read(r.join(plan))["steps"].as_array().unwrap() {
            let name = step["name"].as_str().unwrap();
            let d = r.join(dir).join(name);
            let exit = read(d.join("exit.json"));
            assert_eq!(exit["success"], true);
            assert_eq!(exit["returncode"], 0);
            for stream in ["stdout", "stderr"] {
                assert_eq!(
                    exit[format!("{stream}_sha256")],
                    hash(d.join(format!("{stream}.log")))
                );
            }
            assert_eq!(fs::read(d.join("stderr.log")).unwrap().len(), 0);
            assert_eq!(
                read(d.join("command.json"))["argv"].as_array().unwrap()[4..],
                step["argv"].as_array().unwrap()[..]
            );
            receipt_count += 1;
        }
    }
    assert_eq!(receipt_count, 2);
    let stdout = fs::read_to_string(r.join("run/exact-toom5-work/stdout.log")).unwrap();
    assert_eq!(
        serde_json::from_str::<Value>(stdout.strip_prefix("TOOM5_WORK ").unwrap().trim()).unwrap(),
        result
    );
    let failed = read(r.join("compile-initial/build/build-toom5-work/exit.json"));
    assert_eq!(failed["success"], false);
    assert_eq!(failed["returncode"], 1);
    assert_eq!(result["primitive_exact_divisions"], 5 * (13 + 2048));
    assert_eq!(proto["signed_exact_divisions"], 10305);
    assert_eq!(result["full_limb_convolutions"], 6144);
    assert_eq!(
        result["field_convolutions_and_Montgomery_references"],
        4 * 3 * (122 * 122 + 4096 + 1024)
    );
    for f in result["field_results"].as_array().unwrap() {
        assert_eq!(f["convolution_and_Montgomery_reference_checks"], 60012);
    }
    assert_eq!(result["field_results"].as_array().unwrap().len(), 4);
    // Independent ledger reconstruction from the symbolic wide-operation tape.
    let mut operations: BTreeMap<String, u64> = BTreeMap::new();
    let tri = [1i128, 2, 3, 4, 5, 4, 3, 2, 1];
    let mut max = 0i128;
    for node in symbolic["nodes"].as_array().unwrap() {
        let op = node["op"].as_str().unwrap();
        *operations.entry(op.to_owned()).or_default() += 1;
        let coeff: Vec<_> = node["linear_w0_to_w8"]
            .as_array()
            .unwrap()
            .iter()
            .map(|x| x.as_i64().unwrap() as i128)
            .collect();
        assert_eq!(coeff.len(), 9);
        let mut low = 0;
        let mut high = 0;
        for j in 0..9 {
            let v = coeff[j] * tri[j] * 2;
            if v < 0 {
                low += v;
            } else {
                high += v;
            }
        }
        assert_eq!(node["bounds_in_units_of_(B-1)^2"], json!([low, high]));
        max = max.max(low.abs()).max(high.abs());
    }
    assert_eq!(symbolic["nodes"].as_array().unwrap().len(), 64);
    assert_eq!(json!(operations), symbolic["operation_counts"]);
    assert_eq!(max, 158306);
    let (mut ii, mut mm, mut aa) = (0u64, 0u64, 0u64);
    for (op, n) in &operations {
        if matches!(op.as_str(), "add" | "sub") {
            aa += 9 * n;
        } else if op.starts_with("shift") {
            aa += 9 * n;
        } else if op.starts_with("scale") {
            ii += 4 * n;
            mm += n;
            aa += 3 * n;
        } else if let Some(d) = op.strip_prefix("div") {
            let d: u64 = d.parse().unwrap();
            let k = d.trailing_zeros();
            if k > 0 {
                aa += 9 * n;
            }
            if d >> k != 1 {
                ii += 4 * n;
                mm += n;
                aa += 4 * n;
            }
        } else {
            panic!("unknown op {op}");
        }
    }
    assert_eq!((ii, mm, aa), (56, 14, 510));
    // Two narrow and seven widened point products; 56 Horner ops/input.
    let ordinary =
        json!({"ifma":18+ii,"vector_mul64":21+mm,"other_vector_or_mask_ops":112+7*9+aa+27});
    let fused =
        json!({"ifma":36+ii,"vector_mul64":42+mm,"other_vector_or_mask_ops":2*(112+7*9)+9*9+aa+27});
    assert_eq!(ordinary, result["ordinary_convolution_cost"]);
    assert_eq!(fused, result["fused_convolution_cost"]);
    assert_eq!(
        result["with_common_50_IFMA_reduction"]["ordinary"]["ifma"],
        124
    );
    assert_eq!(
        result["with_common_50_IFMA_reduction"]["fused"]["ifma"],
        142
    );
    assert_eq!(
        result["primitive_division_cost"],
        json!({"ifma":10305*4,"vector_mul64":10305,"other_vector_or_mask_ops":10305*4})
    );
    assert!(result["max_abs_lane"].as_u64().unwrap() < (1u64 << 63));
    let peak = num_bigint::BigUint::parse_bytes(
        result["max_abs_normalized_wide_decimal"]
            .as_str()
            .unwrap()
            .as_bytes(),
        10,
    )
    .unwrap();
    assert!(peak < (num_bigint::BigUint::from(1u64) << 126usize));
    // Point4 inputs also need a bound; they precede the interpolation-only nodes.
    assert!(2 * 341 * 341 < 1 << 18);
    assert!(683i128 * (1i128 << 52) < 1i128 << 62);
    assert!(max < 1 << 18);
    let manifest=read(Path::new(REPO).join("zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let mut sources = 0;
    for (name, h) in manifest["source_files_sha256"].as_object().unwrap() {
        assert_eq!(
            hash(Path::new(REPO).join("zopro").join(name)),
            h.as_str().unwrap()
        );
        sources += 1;
    }
    assert_eq!(sources, 176);
    let review = json!({"status":"pass","pins":22,"successful_model_command_receipts":2,"retained_failed_compiler_receipts":1,"unchanged_production_sources":176,
  "new_field_convolution_and_Montgomery_reference_checks":240048,"new_full_limb_convolutions":6144,"new_signed_exact_divisions":10305,"symbolic_tape_nodes":64,
  "interpolation_proxy_reconstructed":{"ifma":ii,"vector_mul64":mm,"other_vector_or_mask_ops":aa},"max_interpolation_bound_units_(B-1)^2":158306,"point4_fused_bound_units_(B-1)^2":232562,
  "scope":"arithmetic model and literal recipe work; not native execution/performance or independent proof verification; inherited data reapplied to a different algorithm",
  "reviewer_source_sha256":hash(r.join("finish.rs")),"reviewer_binary_sha256":hash(r.join("finish")),
  "decision":"close fixed Toom5 recipe before native; literal ordinary work exceeds accepted IFMA count and adds35wide multiplies+712otherops; no claim allToom schedules are slower",
  "model_runtime_attempts":1,"successful_model_repeats":0,"new_proofs":0,"production_changed":false});
    write(r.join("review.json"), &review);
    fs::create_dir_all(dest.join("artifacts")).unwrap();
    for file in [
        "result.json",
        "symbolic.json",
        "protocol.json",
        "review.json",
        "pins.json",
        "bounds.md",
    ] {
        fs::copy(r.join(file), dest.join("artifacts").join(file)).unwrap();
    }
    let mut members: Vec<String> = [
        "design.md",
        "bounds.md",
        "model.rs",
        "manage.rs",
        "repair.rs",
        "finish.rs",
        "protocol.json",
        "pins.json",
        "build-pins.json",
        "build-plan.json",
        "run-plan.json",
        "result.json",
        "symbolic.json",
        "review.json",
        "compile-initial/model.rs",
        "compile-initial/build-pins.json",
        "compile-initial/repair.json",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect();
    for (dir, step) in [
        ("build", "build-toom5-work"),
        ("run", "exact-toom5-work"),
        ("compile-initial/build", "build-toom5-work"),
    ] {
        for file in ["protocol.json", "source-pins.json", "attempt-0.json"] {
            members.push(format!("{dir}/{file}"));
        }
        for file in ["command.json", "exit.json", "stdout.log", "stderr.log"] {
            members.push(format!("{dir}/{step}/{file}"));
        }
        if !dir.starts_with("compile") {
            for file in ["result.json", "completed.json", "progress.json"] {
                members.push(format!("{dir}/{file}"));
            }
            members.push(format!("{dir}/{step}/tests.json"));
        } else {
            members.push(format!("{dir}/failure.json"));
            members.push(format!("{dir}/progress.json"));
        }
    }
    let mut hashes = BTreeMap::new();
    for file in &members {
        let bytes = fs::read(r.join(file)).unwrap();
        std::str::from_utf8(&bytes).unwrap();
        hashes.insert(file.clone(), format!("{:x}", Sha256::digest(bytes)));
    }
    write(dest.join("artifacts/archive-members.json"), &json!(hashes));
    let archive = dest.join("artifacts/source-and-receipts.tar.gz");
    assert!(Command::new("tar")
        .arg("-czf")
        .arg(&archive)
        .arg("-C")
        .arg(&r)
        .arg("--")
        .args(&members)
        .status()
        .unwrap()
        .success());
    let listing = Command::new("tar")
        .arg("-tzf")
        .arg(&archive)
        .output()
        .unwrap();
    assert!(listing.status.success());
    assert_eq!(
        String::from_utf8(listing.stdout)
            .unwrap()
            .lines()
            .map(str::to_owned)
            .collect::<Vec<_>>(),
        members
    );
    let extraction = r.join("archive-review");
    fs::create_dir(&extraction).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&extraction)
        .status()
        .unwrap()
        .success());
    for (file, h) in &hashes {
        assert_eq!(&hash(extraction.join(file)), h);
    }
    let report="# Base-field Toom-5 work screen\n\nThe fixed nine-point Toom-5 recipe passes the arithmetic/range screen but is **closed before native implementation**. Once widened products, exact interpolation divisions and coefficient assembly are counted, it has more ordinary IFMAs than the retained recipe and many additional operations. This is a work-based decision about this explicit schedule, not a measured slowdown or a lower bound for all Toom algorithms. Production is unchanged.\n\n## Arithmetic and scope\n\nThe scheme treats five normalized radix52 limbs as degree-four polynomial coefficients and evaluates at0,±1,±2,±3,4 and infinity. A sparse even/odd interpolation reconstructs the degree-eight product. Seven point operands can exceed52bits; at4 an operand is below341B, B=2^52. Their products therefore require high-part corrections rather than one52×52 product each. Exact divisions by small odd constants also require work across the three-word representation. The common interpolation tape was checked symbolically over all nine coefficient basis vectors, with64 operation nodes and exact coefficient divisibility. General range arguments and the actual three-word instruction recipe are in [bounds.md](artifacts/bounds.md).\n\nThe new normal Rust model checked **240,048 field convolutions and mathematical Montgomery references**, **6,144 full-width limb convolutions**, and **10,305 signed exact divisions**. Field cases cover Fq/Fr, R256/R260, ordinary/sum2/positive-complement difference2, inclusive[0,2p] boundaries, full-width random tuples and changing chains. Every reconstructed coefficient and full product matched independent BigInt schoolbook multiplication. Every modeled stored arithmetic lane satisfied signed64 bounds; intended modulo64 inverse products were checked against exact signed quotients. No invalid unreduced Fp objects were constructed. Public fixtures were inherited and reapplied to a different algorithm; the old model was not rerun and these are not new unique proofs.\n\nMontgomery quotient references use independent extended Euclid and modular-power inverses. The inherited50-IFMA reduction skeleton was counted, not executed or requalified in this stage. Assembled coefficients are below3B, narrower than its earlier32B input envelope. No native field/kernel, ISA check, CPU profile, clock, solver, SDK or proof ran.\n\n## Literal recipe work\n\n| Stage | Ordinary IFMAs | Ordinary64-bit multiplies | Ordinary other ops | Fused IFMAs | Fused64-bit multiplies | Fused other ops |\n|---|---:|---:|---:|---:|---:|---:|\n| Evaluation and point products |18|21|175|36|42|431|\n| Exact interpolation |56|14|510|56|14|510|\n| Coefficient assembly |0|0|27|0|0|27|\n| New convolution total |74|35|712|92|56|968|\n| Including common reduction IFMAs |**124**|**35**|**712 + common reducer work**|**142**|**56**|**968 + common reducer work**|\n| Retained IFMA reference |100|—|—|150|—|—|\n\nCounts describe this literal normalized three-word recipe, not optimized instructions or latency. Common reducer ALU operations, constants, moves, code size, register allocation and spill costs remain excluded. Some source operations may disappear or be combined by a compiler; other schedules might reduce the cost. The optimistic ordinary total is already124 versus100 IFMAs, plus35wide multiplies and712other operations. The fused case saves only eight IFMAs while adding56wide multiplies and968other operations before common reducer costs. This fixed implementation does not justify a native benchmark.\n\nNine materialized three-word point products represent27 logical vector words, or1,728payload bytes for eight lanes, before other operands/scratch. This is a source payload model, not a concurrent-lifetime bound, actual compiler frame, RSS peak or minimum RAM. No lookup table, proving-key copy, execution plan or thread pool is introduced.\n\n## Validation and evidence\n\nThe first build stopped on cast/comparison syntax in two assert macros, before any executable or arithmetic run. Four casts were parenthesized, with original source/pins/compiler receipts preserved. The repaired build and the model execution each succeeded once; no successful stage was repeated. A separate review verified22pins, the two successful command receipts, the retained compiler failure, unchanged176production-source identities, all64 symbolic bounds and the work ledger reconstructed from the operation tape. The public archive includes selected UTF-8 source, protocols and receipts, with extraction hashes checked.\n\nThe motivation uses the evaluation/interpolation framework described by the primary [GMP Toom-3 documentation](https://gmplib.org/manual/Toom-3_002dWay-Multiplication) and its [higher-degree generalization](https://gmplib.org/manual/Higher-degree-Toom_0027n_0027half). GMP's arbitrary-precision crossover results do not predict BN254/IFMA performance; no GMP implementation was copied. This base-field limb scheme is distinct from the closed [imaginary Fq6 Toom-3 trial](../2026-10-29-fq6-toom175/README.md). The proposed final48-bit coefficient-shift follow-up was found to be the already closed [CIOS packing qualification](../2026-10-25-cios-pack-qualification/README.md), so it was not reimplemented.\n\nProduction source176/SDK6d83 remain unchanged: local32 1×2 **7.928660ms**, merge54 **161.883899ms**. Inherited132.75MiB RSS is not a new peak or minimum-RAM measurement. Canonical proof ledger remains30,846. The inherited [all-eight M5 CPU and Metal comparisons](../2026-11-06-signed-pair52-model176/README.md#accepted-full-proof-baseline-inherited) remain current; the all-eight10× CPU goal remains unmet. No new AWS/Aeglos, large-circuit, phone, pressure/swap or concurrent-throughput result is claimed.\n\n[Model result](artifacts/result.json), [symbolic tape](artifacts/symbolic.json), [protocol](artifacts/protocol.json), [review](artifacts/review.json), [pins](artifacts/pins.json), and [source/receipts](artifacts/source-and-receipts.tar.gz) are preserved. The inherited public fixture remains in the parent model archive; binary tools/libraries, private keys, witnesses and proof blobs are excluded. The observed wide maximum records checked normalized outputs, not a general bound or every standalone-division input; the general bounds are separate.\n";
    fs::write(dest.join("README.md"), report).unwrap();
    let mut sums = BTreeMap::new();
    for file in [
        "README.md",
        "artifacts/result.json",
        "artifacts/symbolic.json",
        "artifacts/protocol.json",
        "artifacts/review.json",
        "artifacts/pins.json",
        "artifacts/bounds.md",
        "artifacts/archive-members.json",
        "artifacts/source-and-receipts.tar.gz",
    ] {
        sums.insert(file, hash(dest.join(file)));
    }
    write(dest.join("checksums.json"), &json!(sums));
    for (file, h) in &sums {
        assert_eq!(&hash(dest.join(file)), h);
    }
    write(
        r.join("publication.json"),
        &json!({"status":"pass","files":10,"utf8_archive_members":members.len(),"archive_roundtrip_members":hashes.len(),"archive_sha256":hash(archive),"report":dest.join("README.md")}),
    );
    println!(
        "review/publication PASS:22pins/64symbolicnodes/240048fieldchecks/{}UTF8archive members",
        members.len()
    );
}
