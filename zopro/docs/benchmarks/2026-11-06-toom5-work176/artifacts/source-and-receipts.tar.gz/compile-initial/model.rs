//! Exact work/range screen. No native vector instruction or clock is executed.
use num_bigint::{BigInt, BigUint};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const B: i128 = 1i128 << 52;
const MASK: u64 = (1u64 << 52) - 1;
const POINTS: [i64; 8] = [0, 1, -1, 2, -2, 3, -3, 4];
const TRI: [i128; 9] = [1, 2, 3, 4, 5, 4, 3, 2, 1];
type Digits = [u64; 5];
type Wide = [i64; 3];
type Linear = [i128; 9];
fn u(x: u64) -> BigUint {
    BigUint::from(x)
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn parse(s: &str) -> BigUint {
    BigUint::parse_bytes(s.as_bytes(), 16).unwrap()
}
fn digits(x: &BigUint) -> Digits {
    let mut x = x.clone();
    std::array::from_fn(|_| {
        let d = (&x & u(MASK)).to_u64_digits().first().copied().unwrap_or(0);
        x >>= 52usize;
        d
    })
}
fn number(a: Digits) -> BigUint {
    a.iter().rev().fold(u(0), |n, &d| (n << 52usize) + u(d))
}
fn polynomial(a: &[i128]) -> BigInt {
    a.iter()
        .rev()
        .fold(BigInt::from(0), |n, &d| (n << 52usize) + BigInt::from(d))
}
fn wide_number(a: Wide) -> i128 {
    a[0] as i128 + B * (a[1] as i128 + B * a[2] as i128)
}
fn normalized(n: i128) -> Wide {
    [
        (n & (MASK as i128)) as i64,
        ((n >> 52) & MASK as i128) as i64,
        (n >> 104) as i64,
    ]
}
fn inv(d: u64) -> u64 {
    assert!(d % 2 == 1);
    let mut x = 1u64;
    for _ in 0..6 {
        x = x.wrapping_mul(2u64.wrapping_sub(d.wrapping_mul(x)));
    }
    assert_eq!(x.wrapping_mul(d), 1);
    x
}
#[derive(Clone, Copy, Default, Debug, PartialEq, Eq)]
struct Cost {
    ifma: u64,
    mul64: u64,
    alu: u64,
}
impl Cost {
    fn json(self) -> Value {
        json!({"ifma":self.ifma,"vector_mul64":self.mul64,"other_vector_or_mask_ops":self.alu})
    }
}
#[derive(Default)]
struct Machine {
    cost: Cost,
    max_lane: u64,
    max_wide: i128,
    negative_points: u64,
    odd_divisions: u64,
    digest: Sha256,
}
impl Machine {
    fn lane(&mut self, n: i128) -> i64 {
        assert!(
            n >= i64::MIN as i128 && n <= i64::MAX as i128,
            "signed lane overflow {n}"
        );
        self.max_lane = self.max_lane.max(n.unsigned_abs() as u64);
        n as i64
    }
    fn check(&mut self, a: Wide) -> Wide {
        assert!(a[0]>=0&&a[0]as i128<B&&a[1]>=0&&a[1]as i128<B);
        let n = wide_number(a);
        self.max_wide = self.max_wide.max(n.abs());
        assert!(n.abs() < (1i128 << 126));
        a
    }
    fn madd(&mut self, acc: i64, a: i64, b: i64, hi: bool) -> i64 {
        self.cost.ifma += 1;
        let p = ((a as u64) & MASK) as u128 * ((b as u64) & MASK) as u128;
        self.lane(
            acc as i128
                + if hi {
                    (p >> 52) as i128
                } else {
                    (p & MASK as u128) as i128
                },
        )
    }
    fn mul64(&mut self, a: i64, b: i64) -> i64 {
        self.cost.mul64 += 1;
        self.lane(a as i128 * b as i128)
    }
    fn mul64_mod(&mut self, a: i64, b: u64) -> i64 {
        self.cost.mul64 += 1;
        (a as u64).wrapping_mul(b) as i64
    }
    fn addlane(&mut self, a: i64, b: i64) -> i64 {
        self.cost.alu += 1;
        self.lane(a as i128 + b as i128)
    }
    fn sublane(&mut self, a: i64, b: i64) -> i64 {
        self.cost.alu += 1;
        self.lane(a as i128 - b as i128)
    }
    fn shr(&mut self, a: i64, k: u32) -> i64 {
        self.cost.alu += 1;
        a >> k
    }
    fn and(&mut self, a: i64, mask: u64) -> i64 {
        self.cost.alu += 1;
        ((a as u64) & mask) as i64
    }
    fn normalized_lanes(&mut self, mut a: Wide) -> Wide {
        let carry = self.shr(a[0], 52);
        a[0] = self.and(a[0], MASK);
        a[1] = self.addlane(a[1], carry);
        let carry = self.shr(a[1], 52);
        a[1] = self.and(a[1], MASK);
        a[2] = self.addlane(a[2], carry);
        self.check(a)
    }
    fn evaluation(&mut self, a: Digits, x: i64) -> i64 {
        if x == 0 {
            return a[0] as i64;
        }
        let mut n = a[4] as i64;
        for j in (0..4).rev() {
            let scaled = match x.abs() {
                1 => n,
                2 => {
                    self.cost.alu += 1;
                    self.lane(n as i128 * 2)
                }
                3 => {
                    self.cost.alu += 1;
                    let twice = self.lane(n as i128 * 2);
                    self.addlane(twice, n)
                }
                4 => {
                    self.cost.alu += 1;
                    self.lane(n as i128 * 4)
                }
                _ => unreachable!(),
            };
            n = if x < 0 {
                self.sublane(a[j] as i64, scaled)
            } else {
                self.addlane(a[j] as i64, scaled)
            };
        }
        assert!((n as i128).abs() < 341 * B);
        n
    }
    fn point_product(&mut self, a: i64, b: i64, narrow: bool) -> Wide {
        self.negative_points += (a < 0 || b < 0) as u64;
        let out = if narrow {
            assert!(a>=0&&a as i128<B&&b>=0&&b as i128<B);
            [self.madd(0, a, b, false), self.madd(0, a, b, true), 0]
        } else {
            let al = self.and(a, MASK);
            let ah = self.shr(a, 52);
            let bl = self.and(b, MASK);
            let bh = self.shr(b, 52);
            let lo = self.madd(0, al, bl, false);
            let hi = self.madd(0, al, bl, true);
            let ab = self.mul64(al, bh);
            let ba = self.mul64(ah, bl);
            let cross = self.addlane(ab, ba);
            let middle = self.addlane(hi, cross);
            let top = self.mul64(ah, bh);
            let carry = self.shr(middle, 52);
            let middle = self.and(middle, MASK);
            let top = self.addlane(top, carry);
            [lo, middle, top]
        };
        assert_eq!(
            wide_number(out),
            a as i128 * b as i128,
            "widened point product"
        );
        self.check(out)
    }
}
trait Ops {
    type V: Clone;
    fn add(&mut self, a: Self::V, b: Self::V) -> Self::V;
    fn sub(&mut self, a: Self::V, b: Self::V) -> Self::V;
    fn scale(&mut self, a: Self::V, m: u64) -> Self::V;
    fn shl(&mut self, a: Self::V, k: u32) -> Self::V;
    fn div(&mut self, a: Self::V, d: u64) -> Self::V;
}
impl Ops for Machine {
    type V = Wide;
    fn add(&mut self, a: Wide, b: Wide) -> Wide {
        let want = wide_number(a) + wide_number(b);
        let raw = std::array::from_fn(|j| self.addlane(a[j], b[j]));
        let out = self.normalized_lanes(raw);
        assert_eq!(wide_number(out), want);
        out
    }
    fn sub(&mut self, a: Wide, b: Wide) -> Wide {
        let want = wide_number(a) - wide_number(b);
        let raw = std::array::from_fn(|j| self.sublane(a[j], b[j]));
        let out = self.normalized_lanes(raw);
        assert_eq!(wide_number(out), want);
        out
    }
    fn scale(&mut self, a: Wide, m: u64) -> Wide {
        if m == 1 {
            return a;
        }
        assert!(m <= 65536);
        let want = wide_number(a) * m as i128;
        let lo = self.madd(0, a[0], m as i64, false);
        let mid = self.madd(0, a[0], m as i64, true);
        let mid = self.madd(mid, a[1], m as i64, false);
        let high = self.mul64(a[2], m as i64);
        let high = self.madd(high, a[1], m as i64, true);
        let carry = self.shr(mid, 52);
        let mid = self.and(mid, MASK);
        let high = self.addlane(high, carry);
        let out = self.check([lo, mid, high]);
        assert_eq!(wide_number(out), want);
        out
    }
    fn shl(&mut self, a: Wide, k: u32) -> Wide {
        assert!((1..=16).contains(&k));
        let want = wide_number(a) * (1i128 << k);
        // Low-word shifts deliberately model the ISA's modulo64 shift before masking.
        self.cost.alu += 9;
        let low = (((a[0] as u64) << k) & MASK) as i64;
        let mid = ((((a[1] as u64) << k) & MASK) | ((a[0] as u64) >> (52 - k))) as i64;
        let high = self.lane((a[2] as i128) * (1i128 << k) + (a[1] as i128 >> (52 - k)));
        let out = self.check([low, mid, high]);
        assert_eq!(wide_number(out), want);
        out
    }
    fn div(&mut self, a: Wide, d: u64) -> Wide {
        assert!(d > 0);
        assert_eq!(wide_number(a) % d as i128, 0, "exact division {d}");
        let want = wide_number(a) / d as i128;
        if d == 1 {
            return a;
        }
        let k = d.trailing_zeros();
        let odd = d >> k;
        let a = if k > 0 {
            assert!(k <= 4);
            assert_eq!((a[0] as u64) & ((1u64 << k) - 1), 0);
            self.cost.alu += 9;
            let out = [
                ((a[0] as u64 >> k) | (((a[1] as u64) & ((1u64 << k) - 1)) << (52 - k))) as i64,
                ((a[1] as u64 >> k) | (((a[2] as u64) & ((1u64 << k) - 1)) << (52 - k))) as i64,
                a[2] >> k,
            ];
            self.check(out)
        } else {
            a
        };
        if odd == 1 {
            assert_eq!(wide_number(a), want);
            return a;
        }
        assert!(odd <= 15);
        self.odd_divisions += 1;
        let inverse = inv(odd);
        let q0 = self.madd(0, a[0], (inverse & MASK) as i64, false);
        let c0 = self.madd(0, q0, odd as i64, true);
        let n1 = self.sublane(a[1], c0);
        let q1 = self.madd(0, n1, (inverse & MASK) as i64, false);
        let c1 = self.madd(0, q1, odd as i64, true);
        let n1_hi = self.shr(n1, 52);
        let c1 = self.sublane(c1, n1_hi);
        let n2 = self.sublane(a[2], c1);
        assert_eq!(n2 % (odd as i64), 0);
        let q2 = self.mul64_mod(n2, inverse);
        assert_eq!(q2, n2 / (odd as i64));
        let out = self.check([q0, q1, q2]);
        assert_eq!(wide_number(out), want);
        out
    }
}
#[derive(Default)]
struct Symbolic {
    nodes: Vec<Value>,
    op_counts: BTreeMap<String, u64>,
    max_units: i128,
}
impl Symbolic {
    fn record(&mut self, name: String, a: Linear) -> Linear {
        let low: i128 = a
            .iter()
            .zip(TRI)
            .filter(|(a, _)| **a < 0)
            .map(|(a, b)| a * b * 2)
            .sum();
        let high: i128 = a
            .iter()
            .zip(TRI)
            .filter(|(a, _)| **a > 0)
            .map(|(a, b)| a * b * 2)
            .sum();
        self.max_units = self.max_units.max(low.abs()).max(high.abs());
        assert!(low.abs() < (1i128 << 22) && high.abs() < (1i128 << 22));
        *self.op_counts.entry(name.clone()).or_default() += 1;
        self.nodes
            .push(json!({"op":name,"linear_w0_to_w8":a,"bounds_in_units_of_(B-1)^2":[low,high]}));
        a
    }
}
impl Ops for Symbolic {
    type V = Linear;
    fn add(&mut self, a: Linear, b: Linear) -> Linear {
        self.record("add".into(), std::array::from_fn(|j| a[j] + b[j]))
    }
    fn sub(&mut self, a: Linear, b: Linear) -> Linear {
        self.record("sub".into(), std::array::from_fn(|j| a[j] - b[j]))
    }
    fn scale(&mut self, a: Linear, m: u64) -> Linear {
        self.record(format!("scale{m}"), a.map(|x| x * m as i128))
    }
    fn shl(&mut self, a: Linear, k: u32) -> Linear {
        self.record(format!("shift{k}"), a.map(|x| x * (1i128 << k)))
    }
    fn div(&mut self, a: Linear, d: u64) -> Linear {
        for x in a {
            assert_eq!(x % d as i128, 0, "linear exact divisor {d}");
        }
        self.record(format!("div{d}"), a.map(|x| x / d as i128))
    }
}

// The fixed sparse even/odd interpolation tape. No dense inverse is executed.
fn interpolate<O: Ops>(o: &mut O, p: [O::V; 9]) -> [O::V; 9] {
    let [p0, p1, pm1, p2, pm2, p3, pm3, p4, inf] = p;
    let mut even = Vec::new();
    let mut odd = Vec::new();
    for (x, plus, minus) in [(1u64, p1, pm1), (2, p2, pm2), (3, p3, pm3)] {
        let sum = o.add(plus.clone(), minus.clone());
        let sum = o.div(sum, 2);
        let sum = o.sub(sum, p0.clone());
        let high = match x {
            1 => inf.clone(),
            2 => o.shl(inf.clone(), 8),
            3 => o.scale(inf.clone(), 6561),
            _ => unreachable!(),
        };
        let sum = o.sub(sum, high);
        even.push(o.div(sum, x * x));
        let difference = o.sub(plus, minus);
        odd.push(o.div(difference, 2 * x));
    }
    let h14 = o.sub(even[1].clone(), even[0].clone());
    let h14 = o.div(h14, 3);
    let h49 = o.sub(even[2].clone(), even[1].clone());
    let h49 = o.div(h49, 5);
    let w6 = o.sub(h49, h14.clone());
    let w6 = o.div(w6, 8);
    let five_w6 = o.scale(w6.clone(), 5);
    let w4 = o.sub(h14, five_w6);
    let w2 = o.sub(even[0].clone(), w4.clone());
    let w2 = o.sub(w2, w6.clone());
    let mut e16 = p0.clone();
    for (value, shift) in [
        (w2.clone(), 4),
        (w4.clone(), 8),
        (w6.clone(), 12),
        (inf.clone(), 16),
    ] {
        let term = o.shl(value, shift);
        e16 = o.add(e16, term);
    }
    let o16 = o.sub(p4, e16);
    let o16 = o.div(o16, 4);
    let d14 = o.sub(odd[1].clone(), odd[0].clone());
    let d14 = o.div(d14, 3);
    let d49 = o.sub(odd[2].clone(), odd[1].clone());
    let d49 = o.div(d49, 5);
    let d916 = o.sub(o16, odd[2].clone());
    let d916 = o.div(d916, 7);
    let dd149 = o.sub(d49.clone(), d14.clone());
    let dd149 = o.div(dd149, 8);
    let dd4916 = o.sub(d916, d49);
    let dd4916 = o.div(dd4916, 12);
    let w7 = o.sub(dd4916, dd149.clone());
    let w7 = o.div(w7, 15);
    let fourteen_w7 = o.scale(w7.clone(), 14);
    let w5 = o.sub(dd149, fourteen_w7);
    let five_w5 = o.scale(w5.clone(), 5);
    let w3 = o.sub(d14, five_w5);
    let twenty_one_w7 = o.scale(w7.clone(), 21);
    let w3 = o.sub(w3, twenty_one_w7);
    let w1 = o.sub(odd[0].clone(), w3.clone());
    let w1 = o.sub(w1, w5.clone());
    let w1 = o.sub(w1, w7.clone());
    [p0, w1, w2, w3, w4, w5, w6, w7, inf]
}
fn convolution(products: &[(Digits, Digits)], m: &mut Machine) -> ([i128; 11], Cost) {
    let before = m.cost;
    let mut p = [[0i64; 3]; 9];
    for (index, (a, b)) in products.iter().enumerate() {
        for k in 0..9 {
            let (a, b) = if k == 8 {
                (a[4] as i64, b[4] as i64)
            } else {
                (m.evaluation(*a, POINTS[k]), m.evaluation(*b, POINTS[k]))
            };
            let product = m.point_product(a, b, k == 0 || k == 8);
            p[k] = if index == 0 {
                product
            } else {
                m.add(p[k], product)
            };
        }
    }
    let w = interpolate(m, p);
    let mut t = [0i128; 11];
    for k in 0..9usize {
        let expected: BigInt = products
            .iter()
            .flat_map(|(a, b)| {
                (0..5).filter_map(move |j| {
                    k.checked_sub(j)
                        .filter(|&l| l < 5)
                        .map(|l| BigInt::from(a[j]) * BigInt::from(b[l]))
                })
            })
            .sum();
        assert_eq!(
            BigInt::from(wide_number(w[k])),
            expected,
            "independent coefficient {k}"
        );
        assert!(wide_number(w[k]) >= 0);
        for j in 0..3 {
            m.cost.alu += 1;
            t[k + j] += w[k][j] as i128;
            m.lane(t[k + j]);
        }
    }
    let expected: BigUint = products.iter().map(|(a, b)| number(*a) * number(*b)).sum();
    assert_eq!(
        polynomial(&t),
        BigInt::from(expected.clone()),
        "full polynomial product"
    );
    for coefficient in t {
        assert!(
            coefficient >= 0 && coefficient < 3 * B,
            "assembled coefficient bound"
        );
    }
    let bytes = expected.to_bytes_le();
    m.digest.update((bytes.len() as u64).to_le_bytes());
    m.digest.update(bytes);
    let delta = Cost {
        ifma: m.cost.ifma - before.ifma,
        mul64: m.cost.mul64 - before.mul64,
        alu: m.cost.alu - before.alu,
    };
    (t, delta)
}
fn rand64(s: &mut u64) -> u64 {
    *s = s.wrapping_add(0x9e3779b97f4a7c15);
    let mut z = *s;
    z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
    z ^ (z >> 31)
}
fn mont_constants(p: &BigUint, bits: usize) -> (BigUint, BigUint) {
    let r = u(1) << bits;
    let modulus = BigInt::from(r.clone());
    let pi = BigInt::from(p.clone());
    // Euclid is deliberately independent from the modeled three-word exact div.
    let (mut a, mut b) = (modulus.clone(), pi.clone());
    let (mut x, mut y) = (BigInt::from(0), BigInt::from(1));
    while b != BigInt::from(0) {
        let q = &a / &b;
        (a, b) = (b.clone(), a - &q * &b);
        (x, y) = (y.clone(), x - q * &y);
    }
    assert_eq!(a, BigInt::from(1));
    let inverse = ((x % &modulus) + &modulus) % &modulus;
    let negative = ((-inverse % &modulus) + &modulus) % &modulus;
    (r, negative.to_biguint().unwrap())
}
fn mont(full: &BigUint, p: &BigUint, r: &BigUint, negative: &BigUint) -> BigUint {
    let q = full * negative % r;
    let numerator = full + q * p;
    assert_eq!(&numerator % r, u(0));
    numerator / r
}
fn main() {
    let root = std::env::args().nth(1).unwrap();
    let root = Path::new(&root);
    let pins: Value = serde_json::from_slice(&fs::read(root.join("pins.json")).unwrap()).unwrap();
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let input_path = "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176/inputs.json";
    let input: Value = serde_json::from_slice(&fs::read(input_path).unwrap()).unwrap();
    let mut symbolic = Symbolic::default();
    let points: [Linear; 9] = std::array::from_fn(|k| {
        if k == 8 {
            std::array::from_fn(|j| (j == 8) as i128)
        } else {
            std::array::from_fn(|j| (POINTS[k] as i128).pow(j as u32))
        }
    });
    let out = interpolate(&mut symbolic, points);
    for j in 0..9 {
        assert_eq!(out[j], std::array::from_fn(|k| (j == k) as i128));
    }
    let mut m = Machine::default();
    let mut primitive_divisions = 0u64;
    let mut state = 0x51b3_9f02_c08e_7a14u64;
    for d in [3u64, 5, 7, 9, 15] {
        let mut quotients = vec![
            0,
            1,
            -1,
            B - 1,
            1 - B,
            B,
            -B,
            B * B - 1,
            1 - B * B,
            B * B,
            -B * B,
            (1i128 << 119) - 1,
            1 - (1i128 << 119),
        ];
        for _ in 0..2048 {
            let x = ((rand64(&mut state) as i128) << 56)
                | (rand64(&mut state) as i128 & ((1i128 << 56) - 1));
            quotients.push(if rand64(&mut state) & 1 == 0 { x } else { -x });
        }
        for q in quotients {
            let a = normalized(q * d as i128);
            let out = m.div(a, d);
            assert_eq!(wide_number(out), q);
            primitive_divisions += 1;
        }
    }
    let primitive_cost = m.cost;
    let mut ordinary = None;
    let mut fused = None;
    let mut test = |products: &[(Digits, Digits)], m: &mut Machine| {
        let (t, cost) = convolution(products, m);
        let wanted = if products.len() == 1 {
            &mut ordinary
        } else {
            &mut fused
        };
        if let Some(old) = wanted {
            assert_eq!(*old, cost);
        } else {
            *wanted = Some(cost);
        }
        t
    };
    let corners: Vec<Digits> = (0..32usize)
        .map(|mask| std::array::from_fn(|j| if mask & (1 << j) == 0 { 0 } else { MASK }))
        .collect();
    let mut full_checks = 0;
    for j in 0..32 {
        for k in 0..32 {
            test(&[(corners[j], corners[k])], &mut m);
            test(
                &[
                    (corners[j], corners[k]),
                    (corners[(j + 3) % 32], corners[(k + 7) % 32]),
                ],
                &mut m,
            );
            full_checks += 2;
        }
    }
    for row in input["full_random"].as_array().unwrap() {
        let [a, b, c, d]: [Digits; 4] = serde_json::from_value(row.clone()).unwrap();
        test(&[(a, b)], &mut m);
        test(&[(a, b), (c, d)], &mut m);
        full_checks += 2;
    }
    assert_eq!(full_checks, 6144);
    let mut field_results = Vec::new();
    let mut field_checks = 0;
    for field in input["fields"].as_array().unwrap() {
        let p = BigUint::parse_bytes(field["p_decimal"].as_str().unwrap().as_bytes(), 10).unwrap();
        let two = &p * u(2);
        let boundary: Vec<_> = field["boundary"]
            .as_array()
            .unwrap()
            .iter()
            .map(|x| parse(x.as_str().unwrap()))
            .collect();
        assert_eq!(boundary.len(), 122);
        let mut tuples = Vec::new();
        for (j, a) in boundary.iter().enumerate() {
            for (k, b) in boundary.iter().enumerate() {
                tuples.push([
                    a.clone(),
                    b.clone(),
                    boundary[(j + 3) % 122].clone(),
                    boundary[(k + 7) % 122].clone(),
                ]);
            }
        }
        for row in field["random"].as_array().unwrap() {
            tuples.push(std::array::from_fn(|j| parse(row[j].as_str().unwrap())));
        }
        for bits in [256usize, 260] {
            assert!(&p * u(4) < (u(1) << bits));
            assert!(&p * u(3) < (u(1) << 256usize));
            let ri = (u(1) << bits).modpow(&(&p - u(2)), &p);
            let (r, negative) = mont_constants(&p, bits);
            let mut checks = 0;
            let mut check = |tuple: &[BigUint; 4], m: &mut Machine| {
                let [a, b, c, d] = tuple;
                for n in tuple {
                    assert!(n <= &two);
                }
                let mut ordinary_result = u(0);
                for mode in 0..3 {
                    let mut products = vec![(digits(a), digits(b))];
                    if mode > 0 {
                        let second = if mode == 1 { c.clone() } else { &two - c };
                        products.push((digits(&second), digits(d)));
                    }
                    let t = test(&products, m);
                    assert_eq!(t[10], 0, "field input has no coefficient10");
                    let full = polynomial(&t).to_biguint().unwrap();
                    let raw = mont(&full, &p, &r, &negative);
                    assert!(raw < &p * u(if mode == 0 { 2 } else { 3 }));
                    let lazy = if raw >= two { raw - &two } else { raw };
                    assert!(lazy < two);
                    let expected = if mode == 0 {
                        a * b
                    } else if mode == 1 {
                        a * b + c * d
                    } else {
                        a * b + &two * d - c * d
                    };
                    assert_eq!((&lazy % &p), (&expected % &p) * &ri % &p);
                    if mode == 0 {
                        ordinary_result = lazy;
                    }
                    checks += 1;
                }
                ordinary_result
            };
            for tuple in &tuples {
                check(tuple, &mut m);
            }
            let mut chain = &p + u(1);
            for j in 0..1024 {
                let row = &field["random"][j];
                chain = check(
                    &[
                        chain,
                        parse(row[1].as_str().unwrap()),
                        parse(row[2].as_str().unwrap()),
                        parse(row[3].as_str().unwrap()),
                    ],
                    &mut m,
                );
            }
            assert_eq!(checks, 60012);
            field_checks += checks;
            field_results.push(json!({"field":field["tag"],"radix":bits,"convolution_and_Montgomery_reference_checks":checks}));
        }
    }
    assert_eq!(field_checks, 240048);
    let ordinary = ordinary.unwrap();
    let fused = fused.unwrap();
    let symbolic_result = json!({"status":"pass","nodes":symbolic.nodes,"operation_counts":symbolic.op_counts,"max_abs_bound_units_(B-1)^2":symbolic.max_units,"range":"all normalized wide values strictly below 2^126; this linear bound covers two products/full52-bit limbs"});
    fs::write(
        root.join("symbolic.json"),
        serde_json::to_vec_pretty(&symbolic_result).unwrap(),
    )
    .unwrap();
    let result = json!({"status":"pass","scope":"exact wide-lane/evaluation/interpolation/convolution and Montgomery-reference screen; no native field/kernel execution, timing or proof",
 "primitive_exact_divisions":primitive_divisions,"primitive_division_cost":primitive_cost.json(),"full_limb_convolutions":full_checks,"field_results":field_results,"field_convolutions_and_Montgomery_references":field_checks,
 "ordinary_convolution_cost":ordinary.json(),"fused_convolution_cost":fused.json(),
 "with_common_50_IFMA_reduction":{"ordinary":{"ifma":ordinary.ifma+50,"vector_mul64":ordinary.mul64,"other_ops_before_common_reducer":ordinary.alu},"fused":{"ifma":fused.ifma+50,"vector_mul64":fused.mul64,"other_ops_before_common_reducer":fused.alu}},
 "accepted_source_proxy":{"ordinary_ifma":100,"fused_ifma":150},"max_abs_lane":m.max_lane,"max_abs_normalized_wide_decimal":m.max_wide.to_string(),"negative_point_operands":m.negative_points,"total_odd_divisions":m.odd_divisions,
 "output_digest":format!("{:x}",m.digest.finalize()),"symbolic_sha256":hash(root.join("symbolic.json")),"fixture_sha256":hash(input_path),
 "cost_scope":"fixed literal SIMD recipe proxy, not optimized instructions or latency; common reducer ALU/constants/moves/spills/code size excluded; no lower bound for all Toom algorithms",
 "decision":"close this fixed widened-point interpolation recipe before native: complete source work exceeds accepted ordinary IFMA count and adds many wide multiplies/ALU operations; no native performance theorem"});
    fs::write(
        root.join("result.json"),
        serde_json::to_vec_pretty(&result).unwrap(),
    )
    .unwrap();
    println!("TOOM5_WORK {}", serde_json::to_string(&result).unwrap());
}
