use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::fs;
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){let root="/home/ubuntu/src/zopro-perf-work/toom5-work176";let mut x:Value=serde_json::from_slice(&fs::read(format!("{root}/build-pins.json")).unwrap()).unwrap();
let source=format!("{root}/model.rs");assert_eq!(x[&source],hash(&format!("{root}/compile-initial/model.rs")));
for(p,h)in x.as_object().unwrap(){if p!=&source{assert_eq!(hash(p),h.as_str().unwrap());}}
x[&source]=json!(hash(&source));for file in ["repair.rs","repair"]{let p=format!("{root}/{file}");x[&p]=json!(hash(&p));}
fs::write(format!("{root}/build-pins.json"),serde_json::to_vec_pretty(&x).unwrap()).unwrap();
fs::write(format!("{root}/compile-initial/repair.json"),serde_json::to_vec_pretty(&json!({"initial":"build failed before executable/any arithmetic","cause":"casts before < were parsed as generic arguments inside two assert macros","repair":"parenthesize four casts; no math, population, protocol or acceptance change","successful_repeats":0,"initial_source_sha256":hash(&format!("{root}/compile-initial/model.rs")),"source_sha256":hash(&source)})).unwrap()).unwrap();println!("repinned syntax-only compiler repair before first arithmetic execution");}
