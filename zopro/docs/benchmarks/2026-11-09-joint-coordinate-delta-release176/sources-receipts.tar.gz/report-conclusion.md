G2 executes fewer measured instructions but takes more measured cycles. The regression also appears solo, with equal scratch capacities and the same 2.75/3 MiB process RSS for the 200/352 solo fixtures. A scaling-only or larger-RAM-only explanation is insufficient. The G2-200 generic cache-miss panel decreases from about 324 to 38 per wave while cycles increase; G2-352 misses increase from about 209 to 234. These counters do not identify a cache level, DRAM cause, spill bottleneck, clock change or critical path.

Flat profiles put G2-200's main prefix kernel at 7,119/7,471 OFF/ON samples and G2-352's at 12,696/13,109. Inlining and sampling skid limit attribution. Fewer static rows or retired instructions do not guarantee fewer cycles. [Full diagnostics](artifacts/diagnostic-analysis.json).

The G1 record remains five fields and 1,600 bytes; the helper adds no production buffer, table, copied key, retained plan, pool or RAM cap. Maximum whole-process RSS is 14.75 MiB across latency processes and 15.25 MiB across all caller processes including diagnostics. These are small caller drivers, not full-proof peaks or minimum-RAM requirements. All per-context CPU service, RSS and capacity observations remain in the results. Prior qualification facade allocations are outside the changed kernel; the measured driver itself verifies zero timed allocations.

The next investigation needs a distinct material reduction of complete-consumer arithmetic or machine work. This local normalization/dependency rearrangement has now been tested through complete callers and is closed. Its retained code and profiles can support offline analysis, but they do not justify rescuing the same fixed proposal. The CPU 10× objective still requires a 52.91% wall reduction for primary 1×2 and 46.62% for 2×2, as well as gains on larger shapes. [Continuation](artifacts/next.md).

## Accepted CPU and Metal comparison, inherited

These unchanged local Ryzen 9950X full-proof results use 32 workers and common fixed placement. Supplied M5 CPU/Metal references are on different hardware. The caller times above are not proof times or new accepted baseline measurements.

