// Private qualification entry points retain the actual complete MSM dispatch.
#[doc(hidden)]pub fn joint_complete_g1(bases:&[G1Affine],words:&[[u64;4]])->G1Projective {
    msm_affine::msm_raw::<zopro_bn254::G1Config>(bases,words)
}
#[doc(hidden)]pub fn joint_complete_g2(bases:&[G2Affine],words:&[[u64;4]])->G2Projective {
    msm_affine::g2_query_raw(bases,words)
}
