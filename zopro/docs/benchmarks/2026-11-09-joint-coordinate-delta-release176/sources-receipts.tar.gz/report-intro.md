# Joint X/delta release caller comparison

**Rejected: jointly computing X and its Y delta does not improve the complete caller screen.** G2 regresses in calibrated solo and 16-worker contexts. Its 32-worker aggregate is **3.16% slower than matched OFF**, with one win in seven blocks. G1 improves about 1% solo, but the declared joint promotion checks fail. No optimization is adopted; accepted local full-proof 1×2 remains **7.857170 ms**.

This follows the [field/curve qualification](../2026-11-09-joint-coordinate-delta176/README.md) and [ordinary caller qualification](../2026-11-09-joint-coordinate-delta-callers176/README.md). The fixed proposal shares the uncarried X expression with an opaque, partially reduced delta, letting their carry chains proceed separately. Original multiply/cancellation bodies remain unchanged. The release comparison evaluates the complete signed borrowed G1 and G2 packet callers, including packing, prefix/inversion, finishing, writes and reuse.

## Qualification and release artifacts

The normal release field and matched OFF/ON cores explicitly disable debug assertions and overflow checks, and omit the diagnostic cfgs used in checked qualification. No TLS route symbols appear in the release consumers. Field arithmetic source is byte-exact to the checked parent. OFF and ON share source and the same new field library; only their core/driver selector differs. All 176 accepted sources remain recoverable; production sources stay exact. [Source audit](artifacts/source-audit.json), [release review](artifacts/review.json), [identities](artifacts/identities.json).

Each release arm passes 128 independent complete raw G1/G2 MSM comparisons over 53,680 input terms. Sizes are 0/1/7/8/9/255/1024/2051, with 1/4/16/32-worker pools and requested 512 KiB stacks. The oracle uses independent Arkworks coefficient sums and generator multiplication, including repeated/opposite/identity bases and zero/one/minus-one/full-width scalar cases. Inputs remain unchanged. These are synthetic complete MSM cases, not actual proving-key queries or proofs.

Thirteen successful build/oracle/symbol/decode commands are retained without repeating successful work. One initial external-oracle compile failed because Arkworks `ZERO` needed an `AdditiveGroup` import; the import-only [repair](artifacts/repair.json), original source and failed receipt remain. The first three successful builds were reused. An offline function reader also needed a [selector repair](artifacts/codegen-reader-repair.json) for Rust's inherent-method demangling. No build, test or decode was repeated for that repair.

The actual borrowed G1 kernel has 4,425/4,451 OFF/ON static instruction rows and 800/800 IFMA sites; G2 has 8,590/8,553 rows and 1,450/1,450 IFMA sites. Static stack-operand rows increase from 593 to 607 for G1 and 1,471 to 1,490 for G2. These counts do not measure spills, stack peaks or cycles. The unsigned G1 body has different inlining between builds and is outside the timed borrowed path. [Codegen review](artifacts/codegen-review.json).

## Frozen caller screen

The prospective screen includes both curves, 200/352 pairs and 1/16/32 workers: 12 contexts, exact frozen reference plus fresh matched OFF/ON, and seven rotated/reversed blocks. It retains every observation. There are 36 preflights, 252 latency processes and 24 diagnostic processes, totaling 312 checked caller processes and 50,455,296 worker batch calls including priming. These counts are not proofs. All 373 workflow commands succeed on their first execution.

Each latency process performs 4,096 rounds after three checked 128-round primes. Outputs and scratch capacities match across arms, with zero timed allocations. CPU placement and 512 KiB requested worker stacks are fixed. All recording finishes before offline decoding and analysis; no other owned work runs during recording. The original and matched controls are both required for promotion. [Selection](artifacts/selection.md), [prospective plan review](artifacts/capture-plan-review.json), [results](artifacts/capture-analysis.json), [separate final review](artifacts/capture-review.json).

Times below are microseconds per batch wave, with one fixture per worker. Ratios are medians of paired block ratios; they need not equal ratios of the separately reported median times. Brackets show the declared zero-based sorted ranks 1 and 5 of seven ratios: a descriptive screen interval, **not a 95% confidence interval**. Lower ratios are faster.

