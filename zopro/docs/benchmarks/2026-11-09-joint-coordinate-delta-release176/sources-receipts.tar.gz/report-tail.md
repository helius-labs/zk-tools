Two G1 32-worker OFF/reference calibrations fail the declared factor-1.05 range. Those rows are retained and cannot establish a reliable accepted-reference gain. The calibrated G2 solo and 16-worker regressions independently reject the proposal. Ten of twelve calibrations pass. There are 21 failed promotion checks and nine clear-regression checks. The fixed experiment is closed without rerolls, extension, a favorable curve/size subset, or an SDK followup.

The 32-worker G2 aggregate ON/OFF ratio is 1.031580 [1.022080, 1.036617], with 1/7 wins; against the frozen reference it is 1.045163 [1.011748, 1.052534], with 0/7 wins. G1's 32-worker matched aggregate is 1.000690 [0.921555, 1.012762], with 3/7 wins, subject to its failed control calibrations. The all-context 32-worker matched aggregate is 1.001219 [0.977394, 1.021658], with 3/7 wins. No aggregate gain qualifies.

## CPU work and memory

All counter panels run at 100%. All twelve profiles pass their declared quality checks: 94,820 samples in total, no LOST events, unknown symbols below 0.091%, with PID/TID/CPU/MMAP and 16-million-cycle period checks. The following single-panel comparisons describe work per 32-worker batch wave; they are not repeated counter estimates or causal attribution.

