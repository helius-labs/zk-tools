use ark_bn254::{Fq as A,Fr as R,G1Projective as P1,G2Projective as P2};
use ark_ec::{CurveGroup,PrimeGroup,AffineRepr,AdditiveGroup};use ark_ff::{PrimeField,BigInteger,Field};
use zopro_bn254::{Fq,Fq2,G1Affine,G2Affine};
fn random(s:&mut u64)->R {let mut b=[0;32];for x in b.chunks_exact_mut(8){*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;x.copy_from_slice(&s.to_le_bytes());}R::from_le_bytes_mod_order(&b)}
fn host(v:A)->Fq {Fq::from_le_bytes_mod_order(&v.into_bigint().to_bytes_le())}
fn h1(p:ark_bn254::G1Affine)->G1Affine {if p.is_zero(){G1Affine::IDENTITY}else{G1Affine::new(host(p.x),host(p.y))}}
fn h2(p:ark_bn254::G2Affine)->G2Affine {if p.is_zero(){G2Affine::IDENTITY}else{G2Affine::new(Fq2::new(host(p.x.c0),host(p.x.c1)),Fq2::new(host(p.y.c0),host(p.y.c1)))}}
#[test]fn complete_release_msms_cover_exceptions_and_scalar_edges(){
    let mut seed=0x72656c6561736533;let coefficients:Vec<R>=(0..64).map(|_|random(&mut seed)).collect();
    let one:Vec<_>=coefficients.iter().map(|&c|h1((P1::generator()*c).into_affine())).collect();
    let two:Vec<_>=coefficients.iter().map(|&c|h2((P2::generator()*c).into_affine())).collect();let mut cases=0;let mut terms=0;
    for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();
      for n in[0usize,1,7,8,9,255,1024,2051]{for adversarial in[false,true]{let mut expected=R::ZERO;let mut b1=Vec::new();let mut b2=Vec::new();let mut words=Vec::new();
        for i in 0..n {let j=(i/2+i/17)%64;let mut coefficient=coefficients[j];let (mut p,mut q)=(one[j],two[j]);
          if adversarial{match i%8 {0=>{coefficient=R::ZERO;p=G1Affine::IDENTITY;q=G2Affine::IDENTITY},2|5=>{coefficient=-coefficient;p=-p;q=-q},_=>{}}}
          let weight=if adversarial{match i%8{0|7=>R::ZERO,1|2=>R::ONE,3|4=>-R::ONE,5=>R::from(1u64<<63),_=>random(&mut seed)}}else{random(&mut seed)};
          expected+=coefficient*weight;b1.push(p);b2.push(q);words.push(weight.into_bigint().0);
        }
        let saved=(b1.clone(),b2.clone(),words.clone());let (got1,got2)=pool.install(||(zopro_core::joint_complete_g1(&b1,&words).to_affine(),zopro_core::joint_complete_g2(&b2,&words).to_affine()));
        assert_eq!(got1,h1((P1::generator()*expected).into_affine()),"G1 workers={workers} n={n} adversarial={adversarial}");
        assert_eq!(got2,h2((P2::generator()*expected).into_affine()),"G2 workers={workers} n={n} adversarial={adversarial}");assert_eq!((b1,b2,words),saved);cases+=2;terms+=2*n;
      }}
    }
    assert_eq!(cases,128);println!("JOINT_RELEASE_MSM comparisons={cases} input_terms={terms} worker_counts=1,4,16,32 stack_request=524288 raw_complete_dispatch=true immutable_inputs=true");
}
