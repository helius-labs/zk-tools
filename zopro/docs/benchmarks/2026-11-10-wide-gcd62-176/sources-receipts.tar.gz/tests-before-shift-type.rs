use super::*;
use num_bigint::{BigInt,BigUint,Sign};
use ark_ff::{Field,PrimeField};
fn next(s:&mut u64)->u64{*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;*s}
fn uint(a:&[u64;4])->BigUint{BigUint::from_bytes_le(&a.iter().flat_map(|w|w.to_le_bytes()).collect::<Vec<_>>())}
fn step_reference(mut a:u128,mut b:u128)->[i64;4]{let(mut f,mut g,mut h,mut k)=(1i128,0i128,0i128,1i128);for _ in 0..62{if a&1==0{a/=2;h*=2;k*=2;}else if a<b{let old=a;a=(b-a)/2;b=old;(f,g,h,k)=(h-f,k-g,2*f,2*g);}else{a=(a-b)/2;f-=h;g-=k;h*=2;k*=2;}}[f as i64,g as i64,h as i64,k as i64]}
#[test]fn wide_matrix_and_full_integer_rows(){let mut seed=0x79308b021e5d0147;let mut matrices=0;let mut rows=0;
 for case in 0..131072{let mut a=std::array::from_fn(|_|next(&mut seed));let mut b=std::array::from_fn(|_|next(&mut seed));b[0]|=1;
    match case%64 {0=>a=[0;4],1=>a=[1u64<<62,0,0,0],2=>a=b,3=>a=[u64::MAX;4],_=>{}}
    let bits=bit_len(&a).max(bit_len(&b));let small_a=approximate(&a,bits);let small_b=approximate(&b,bits);let m=matrix(small_a,small_b);assert_eq!(m,step_reference(small_a,small_b));matrices+=1;
    let det=(m[0] as i128)*(m[3] as i128)-(m[1] as i128)*(m[2] as i128);assert_eq!(det.unsigned_abs(),1u128<<62);
    for i in 0..2 {let(mut f,mut g)=(m[2*i],m[2*i+1]);assert!(f.unsigned_abs()+g.unsigned_abs()<=1u64<<62);let exact=BigInt::from(uint(&a))*f+BigInt::from(uint(&b))*g;assert_eq!(&exact%BigInt::from(1u64<<62),BigInt::from(0));let got=integer(&a,&b,&mut f,&mut g);let q=exact.magnitude()>>62usize;assert_eq!(uint(&got),q);assert!(q.bits()<=256);if exact.sign()==Sign::Minus{assert_eq!((f,g),(-m[2*i],-m[2*i+1]));}else{assert_eq!((f,g),(m[2*i],m[2*i+1]));}rows+=1;}
 }
 assert_eq!(decode((1u128<<62).wrapping_mul(1u128<<64)),(0,1i64<<62));assert_eq!(decode(1u128<<62),(1i64<<62,0));
 println!("WIDE62_MATRIX matrices={matrices} full_integer_rows={rows}");
}
fn check<C:FpConfig,A:PrimeField<BigInt=ark_ff::BigInt<4>>>(){
    assert_eq!(inverse(&Fp::<C>::ZERO),None);let p=uint(&C::P);let mut raw=vec![BigUint::from(1u64),&p-1u64,&p-2u64];
    for bit in 0..254{let v=BigUint::from(1u64)<<bit;for x in [&v-1u64,v.clone(),&v+1u64]{if x>BigUint::from(0u64)&&x<p{raw.push(x);}}}
    let mut seed=0x62a01c92e8b17d59;for _ in 0..4096{raw.push(uint(&std::array::from_fn(|_|next(&mut seed)))%&p);}
    let mut checked=0;for x in raw{if x==BigUint::from(0u64){continue;}let mut words=x.to_u64_digits();words.resize(4,0);let words:[u64;4]=words.try_into().unwrap();let x=Fp::<C>::from_montgomery(words);let expected=A::from_le_bytes_mod_order(&x.to_canonical().iter().flat_map(|w|w.to_le_bytes()).collect::<Vec<_>>());let got=inverse(&x).unwrap();assert_eq!(got.to_canonical(),expected.inverse().unwrap().into_bigint().0);assert_eq!(x*got,Fp::ONE);checked+=1;}
    // Output-fed raw Montgomery states exercise composition, not only inputs.
    let mut x=Fp::<C>::from(17);for i in 0..1024{let expected=A::from_le_bytes_mod_order(&x.to_canonical().iter().flat_map(|w|w.to_le_bytes()).collect::<Vec<_>>());let got=inverse(&x).unwrap();let canon=got.to_canonical();assert_eq!(A::from_le_bytes_mod_order(&canon.iter().flat_map(|w|w.to_le_bytes()).collect::<Vec<_>>()),expected.inverse().unwrap());x=got+Fp::from((i+1) as u64);if x==Fp::ZERO{x=Fp::ONE;}checked+=1;}
    println!("WIDE62_INVERSES field={} checked={checked}",core::any::type_name::<C>());
}
#[test]fn complete_fq_inverse(){check::<crate::FqConfig,ark_ref::Fq>();}
#[test]fn complete_fr_inverse(){check::<crate::FrConfig,ark_ref::Fr>();}
