// Test-only module path shim; no runtime source changes.
include!("wide62/tests.rs");
