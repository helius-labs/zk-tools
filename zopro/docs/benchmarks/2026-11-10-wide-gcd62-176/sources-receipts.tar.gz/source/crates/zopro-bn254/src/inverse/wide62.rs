use super::{bit_len,linear,coefficient_update,finish};
use crate::{Fp,FpConfig};
use core::hint::select_unpredictable;
const K:usize=62;
const LOW:u128=(1u128<<K)-1;
#[inline(always)]
fn approximate(a:&[u64;4],bits:usize)->u128 {
    if bits<=128 {return (a[0] as u128)|((a[1] as u128)<<64);}
    let shift=bits-66;let word=shift/64;let off=shift%64;
    let mut high=(a[word] as u128)>>off;
    if word+1<4 {high|=(a[word+1] as u128)<<(64-off);}
    if off!=0&&word+2<4 {high|=(a[word+2] as u128)<<(128-off);}
    (high<<K)|(((a[0] as u128)|((a[1] as u128)<<64))&LOW)
}
#[inline(always)]
fn decode(e:u128)->(i64,i64){let f=e as u64 as i64;let g=(e.wrapping_sub(f as u128) as i128)>>64;(f,g as i64)}
#[inline(always)]
fn matrix(mut a:u128,mut b:u128)->[i64;4]{
    let(mut r0,mut r1)=(1u128,1u128<<64);let mut left=K as u32;
    let first=a.trailing_zeros().min(left);a>>=first;r1<<=first;left-=first;
    while left!=0 {
        debug_assert_eq!(a&1,1);debug_assert_eq!(b&1,1);
        let smaller=a<b;let difference=a.wrapping_sub(b);
        let magnitude=select_unpredictable(smaller,difference.wrapping_neg(),difference);
        b=select_unpredictable(smaller,a,b);
        let old=r0;r0=select_unpredictable(smaller,r1,r0);r1=select_unpredictable(smaller,old,r1);
        r0=r0.wrapping_sub(r1);let zeros=magnitude.trailing_zeros().min(left);
        debug_assert!(zeros>0&&zeros<=K as u32);a=magnitude>>zeros;r1<<=zeros;left-=zeros;
    }
    let(f0,g0)=decode(r0);let(f1,g1)=decode(r1);[f0,g0,f1,g1]
}
#[inline(always)]
fn integer(a:&[u64;4],b:&[u64;4],f:&mut i64,g:&mut i64)->[u64;4]{
    let mut t=linear(a,*f,b,*g);
    if (t[4] as i64)<0 {*f=-*f;*g=-*g;let mut carry=1u128;for w in &mut t {carry+=(!*w) as u128;*w=carry as u64;carry>>=64;}}
    debug_assert_eq!(t[0]&((1u64<<K)-1),0);debug_assert_eq!(t[4]>>K,0);
    core::array::from_fn(|j|(t[j]>>K)|(t[j+1]<<(64-K)))
}
pub(super) fn inverse<C:FpConfig>(x:&Fp<C>)->Option<Fp<C>>{
    if x.0==[0;4] {return None;}
    let(mut a,mut b)=(x.0,C::P);let(mut u,mut v)=(C::R2,[0;4]);let mut rounds=0;
    while a!=[0;4] {
        let bits=bit_len(&a).max(bit_len(&b));if bits<=64{return Some(finish::<C>(a[0],b[0],u,v));}
        let[mut f0,mut g0,mut f1,mut g1]=matrix(approximate(&a,bits),approximate(&b,bits));
        debug_assert!(f0.unsigned_abs()+g0.unsigned_abs()<=1u64<<K);debug_assert!(f1.unsigned_abs()+g1.unsigned_abs()<=1u64<<K);
        let old=a;a=integer(&old,&b,&mut f0,&mut g0);b=integer(&old,&b,&mut f1,&mut g1);
        let old=u;u=coefficient_update::<C,K>(&old,&v,f0,g0);v=coefficient_update::<C,K>(&old,&v,f1,g1);
        rounds+=1;assert!(rounds<=32,"wide approximate GCD did not converge");
    }
    debug_assert_eq!(b,[1,0,0,0]);let result=Fp::from_montgomery(v);debug_assert_eq!(*x*result,Fp::ONE);Some(result)
}
#[cfg(test)]mod tests;
