use std::{fs,collections::BTreeMap};use serde_json::{Value,json};use sha2::{Sha256,Digest};
const R:&str="/home/ubuntu/src/zopro-perf-work/two-bank-caller177";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/two-bank177";
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn cp(a:&str,b:&str){fs::create_dir_all(std::path::Path::new(b).parent().unwrap()).unwrap();fs::copy(a,b).unwrap();}
fn append(p:&str,s:&str){use std::io::Write;fs::OpenOptions::new().append(true).open(p).unwrap().write_all(s.as_bytes()).unwrap();}
fn main(){assert!(!std::path::Path::new(&format!("{R}/source")).exists());
let pins:BTreeMap<String,String>=serde_json::from_slice(&fs::read(format!("{OLD}/native-fixed-pins.json")).unwrap()).unwrap();let mut copied=0;for(p,h)in &pins{if let Some(rel)=p.strip_prefix(&format!("{OLD}/source/")){assert_eq!(&hash(p),h);cp(p,&format!("{R}/source/{rel}"));copied+=1;}}
assert!(copied>170);
let original=fs::read_to_string(format!("{R}/source/crates/zopro-core/src/msm_affine/borrowed_pending/balanced.rs")).unwrap();let mut balanced=original.split("#[cfg(test)]").next().unwrap().replace("use super::*;","use super::*;\nuse rayon::prelude::*;\nuse crate::msm_affine::batch_size;");
let from="".to_string()+"        if state.busy(bucket) {\n            state.queue.push((encoded, point));\n            if state.queue.len() == size - 1 {\n                state.flush_queue();\n            }\n            continue;\n        }\n        state.add(encoded, point);";
let to="        let Some(physical) = state.select(bucket) else {\n            state.queue.push((encoded, point));\n            if state.queue.len() == size - 1 { state.flush_queue(); }\n            continue;\n        };\n        state.add(physical as u32 | (encoded & 0x80000000), point);";
assert_eq!(balanced.matches(&from).count(),1);balanced=balanced.replace(&from,to).replace("pub(super) fn fused","pub(crate) fn fused");balanced=balanced.replace("// Same borrowed pending/collision algorithm; only the digit reader differs.","// Qualified two-bank selection; digit extraction and full reduction unchanged.");
fs::create_dir_all(format!("{R}/source/crates/zopro-core/src/msm_affine/two_bank")).unwrap();fs::write(format!("{R}/source/crates/zopro-core/src/msm_affine/two_bank/balanced.rs"),balanced).unwrap();append(&format!("{R}/source/crates/zopro-core/src/msm_affine/two_bank.rs"),"\npub(crate) mod balanced;\n");
append(&format!("{R}/source/crates/zopro-core/src/msm_affine/borrowed_pending.rs"),"\npub(crate) fn caller_old(k:&[zopro_bn254::G1Affine],sk:&[[u64;4]],h:&[zopro_bn254::G1Affine],sh:&[[u64;4]])->zopro_bn254::G1Projective { fused(k,sk,h,sh,13) }\n");
append(&format!("{R}/source/crates/zopro-core/src/lib.rs"),r#"
#[doc(hidden)]
pub fn bank_caller(k:&[G1Affine],sk:&[[u64;4]],h:&[G1Affine],sh:&[[u64;4]],on:bool)->zopro_bn254::G1Projective {
 assert_eq!(k.len(),sk.len());assert_eq!(h.len(),sh.len());
 if on { msm_affine::two_bank::balanced::fused(k,sk,h,sh) }
 else { msm_affine::borrowed_pending::caller_old(k,sk,h,sh) }
}
impl Key {
 #[doc(hidden)] pub fn bank_points(&self)->(Vec<G1Affine>,Vec<G1Affine>){
 let q=self.lagrange.as_ref().unwrap();assert!(q.euler&&q.product_scale==Fr::ONE);
 (q.folded.as_ref().unwrap().private.to_vec(),q.product.to_vec())
 }
}
"#);
cp("/home/ubuntu/src/zopro-perf-work/g1-tagged-phi-review176/loader.rs",&format!("{R}/driver/src/loader.rs"));cp("/home/ubuntu/src/zopro-perf-work/shared-inverse-pair176/perf.rs",&format!("{R}/driver/src/perf.rs"));cp(&format!("{R}/driver.rs"),&format!("{R}/driver/src/main.rs"));
let toml=fs::read_to_string(format!("{OLD}/driver/Cargo.toml")).unwrap().replace("two-bank-qualification","two-bank-caller").replace("[profile.release]","memmap2=\"0.9\"\nsha2=\"0.10\"\nlibc=\"0.2\"\n[profile.release]");fs::write(format!("{R}/driver/Cargo.toml"),toml).unwrap();cp(&format!("{OLD}/driver/Cargo.lock"),&format!("{R}/driver/Cargo.lock"));
let prior:Value=serde_json::from_slice(&fs::read(format!("{OLD}/native-fixed-plan.json")).unwrap()).unwrap();let mut env=prior["steps"][0]["environment"].clone();env["CARGO_TARGET_DIR"]=json!(format!("{R}/target"));
let plan=json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"steps":[{"kind":"command","name":"build","argv":["cargo","build","--locked","--offline","--release","--manifest-path",format!("{R}/driver/Cargo.toml"),"--message-format=json"],"environment":env,"timeout_seconds":900},{"kind":"command","name":"fixture","argv":[format!("{R}/target/release/two-bank-caller"),"fixture"],"environment":env,"timeout_seconds":300}]});fs::write(format!("{R}/build-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();fs::write(format!("{R}/environment.json"),serde_json::to_vec_pretty(&env).unwrap()).unwrap();println!("Copied {copied} pinned source files, added noninstrumented caller and fixture extractor.");
}
