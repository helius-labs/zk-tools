//! Twenty balanced signed windows covering255 bits; no recoded digit array.
use super::*;
use rayon::prelude::*;
use crate::msm_affine::batch_size;
const COUNT: usize = 20;
const BITS: usize = 255;
#[derive(Clone, Copy, Debug)]
struct Span {
    start: usize,
    width: usize,
}
fn spans() -> [Span; COUNT] {
    core::array::from_fn(|i| {
        let start = i * BITS / COUNT;
        Span {
            start,
            width: (i + 1) * BITS / COUNT - start,
        }
    })
}
#[inline(always)]
fn digit_at(s: &[u64; 4], span: Span) -> i16 {
    let Span { start, width } = span;
    if start == 0 {
        let value = s[0] & ((1u64 << width) - 1);
        return (value as i64 - ((value >> (width - 1)) << width) as i64) as i16;
    }
    let offset = start - 1;
    let (word, shift) = (offset / 64, offset % 64);
    let mut value = if word < 4 { s[word] >> shift } else { 0 };
    if shift + width + 1 > 64 && word < 3 {
        value |= s[word + 1] << (64 - shift);
    }
    value &= (1u64 << (width + 1)) - 1;
    (((value + 1) >> 1) as i64 - ((value >> width) << width) as i64) as i16
}
fn feed<'a, C: CurveConfig<Base = Fq>>(
    state: &mut Window<'a, C>,
    points: &'a [Affine<C>],
    scalars: &[[u64; 4]],
    span: Span,
    size: usize,
) {
    // Qualified two-bank selection; digit extraction and full reduction unchanged.
    for (point, scalar) in points.iter().zip(scalars) {
        let d = digit_at(scalar, span);
        if d == 0 || point.is_identity() {
            continue;
        }
        let bucket = d.unsigned_abs() as usize - 1;
        let encoded = bucket as u32 | if d < 0 { 1 << 31 } else { 0 };
        let Some(physical) = state.select(bucket) else {
            state.queue.push((encoded, point));
            if state.queue.len() == size - 1 { state.flush_queue(); }
            continue;
        };
        state.add(physical as u32 | (encoded & 0x80000000), point);
        if state.batch.len() == size {
            state.execute();
            state.take_from_queue();
        }
    }
}
pub(crate) fn fused<C: CurveConfig<Base = Fq>>(
    k: &[Affine<C>],
    sk: &[[u64; 4]],
    h: &[Affine<C>],
    sh: &[[u64; 4]],
) -> Projective<C> {
    let cover = spans();
    let sums: Vec<_> = cover
        .par_iter()
        .map(|&span| {
            let size = batch_size(span.width).max(32);
            let mut state = Window::new(1usize << (span.width - 1), size);
            feed(&mut state, k, sk, span, size);
            feed(&mut state, h, sh, span, size);
            crate::msm::weighted_affine(&state.finish())
        })
        .collect();
    let mut result = Projective::<C>::IDENTITY;
    for (span, sum) in cover.iter().zip(&sums).rev() {
        for _ in 0..span.width {
            result = result.double();
        }
        result += sum;
    }
    result
}

