set pagination off
set confirm off
set print thread-events off
set debuginfod enabled off
set auto-load off
set language c
starti
set $hits = 0
set $function = (unsigned long)&'zopro_core::msm_affine::grouping::scalar_groups'
break *($function+17) if $rdx == 30089
commands
silent
set $hits = $hits + 1
set $frame = (unsigned long)$rsp
set $entry = $frame + 472
set $spill = $frame + 240
set $ret = *(unsigned long*)$entry
printf "STACK_ENTRY hit=%d n=%ld thread=%d entry=0x%lx frame=0x%lx spill=0x%lx return=0x%lx function=0x%lx scalar=0x%lx\n", $hits,$rdx,$_thread,$entry,$frame,$spill,$ret,$function,(unsigned long)$rsi
continue
end
continue
printf "STACK_ENTRIES %d\n",$hits
if $hits != 4
quit 7
end
quit
