use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/busy-reset176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert_eq!(read(format!("{R}/runs/qualify-bitmap-complete-windows/exit.json"))["returncode"],101);
 assert!(!Path::new(R).join("source-diagnostic").exists());
 let audit=read(format!("{R}/source-audit.json"));
 for(rel,_)in audit["originals"].as_object().unwrap(){let dest=format!("{R}/source-diagnostic/{rel}");fs::create_dir_all(Path::new(&dest).parent().unwrap()).unwrap();fs::copy(format!("{R}/source/{rel}"),dest).unwrap();}
 let p=format!("{R}/source-diagnostic/crates/zopro-core/src/msm_affine/g2_borrowed.rs");let old=fs::read_to_string(&p).unwrap();
 let before="            check(&s,&mut c);\n        }\n        execute(&mut s,&mut c);";
 let after=r#"            check(&s,&mut c);
            if half==1 && size==8 {
                let mut total=s.affine[0].to_projective();
                for v in &s.projective {total+=v;}
                for &(encoded,p) in s.batch.iter().chain(&s.queue) {total+=if encoded>>31!=0{-*p}else{*p};}
                assert_eq!(total.to_affine(),(Proj::generator()*want[0]).to_affine(),"first G2 divergence at arrival {i}, pending={},queue={},projective={}",s.batch.len(),s.queue.len(),s.projective.len());
            }
        }
        execute(&mut s,&mut c);"#;
 assert_eq!(old.matches(before).count(),1);fs::write(&p,old.replace(before,after)).unwrap();
 let mut step=read(format!("{R}/plan.json"))["steps"][2].clone();step["name"]=json!("build-G2-diagnostic-tests");for v in step["argv"].as_array_mut().unwrap(){let t=v.as_str().unwrap();*v=json!(if t==format!("{R}/core-tests"){format!("{R}/core-tests-diagnostic")}else{t.replace(&format!("{R}/source/"),&format!("{R}/source-diagnostic/"))});}step["environment"]["CARGO_MANIFEST_DIR"]=json!(format!("{R}/source-diagnostic/crates/zopro-core"));
 let run=json!({"kind":"command","name":"trace-failed-G2-window","argv":[format!("{R}/core-tests-diagnostic"),"msm_affine::g2_borrowed::busy_reset_qualification::exact_pending_set_complete_windows_and_workers","--exact","--nocapture","--test-threads=1"],"environment":step["environment"],"timeout_seconds":900});
 let plan=json!({"version":1,"source_pins":format!("{R}/diagnostic-pins.json"),"steps":[step,run]});fs::write(format!("{R}/diagnostic-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();
 let mut pins=read(format!("{R}/pins.json"));for(rel,_)in audit["originals"].as_object().unwrap(){let p=format!("{R}/source-diagnostic/{rel}");pins[&p]=json!(hash(&p));}for f in["prepare-diagnostic.rs","prepare-diagnostic","diagnostic-plan.json"]{let p=format!("{R}/{f}");pins[&p]=json!(hash(&p));}fs::write(format!("{R}/diagnostic-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
 println!("Preserved original snapshot/releases/G1 success; separate G2 test-only diagnostic snapshot; two commands, no clocks");
}
