use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/busy-reset176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";const P:&str="/home/ubuntu/src/zopro-perf-work/tree-option-owner176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(p:&str,v:Value){fs::write(format!("{R}/{p}"),serde_json::to_vec_pretty(&v).unwrap()).unwrap()}
fn main(){
 assert!(!Path::new(R).join("source").exists());
 let manifest=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));let originals=manifest["source_files_sha256"].as_object().unwrap();assert_eq!(originals.len(),176);
 let mut pins=BTreeMap::new();for(rel,h)in originals{let from=format!("{Z}/{rel}");assert_eq!(hash(&from),h.as_str().unwrap());let to=format!("{R}/source/{rel}");fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(&from,&to).unwrap();pins.insert(from,h.clone());}
 let template=fs::read_to_string(format!("{R}/cases-template.rs")).unwrap();let mut edits=Vec::new();
 for (rel,before,config,state,new,curve) in [
 ("crates/zopro-core/src/msm_affine/borrowed_pending.rs","        for (index, _) in &self.batch {\n            self.busy[(index & 0x7fffffff) as usize / 64] = 0;\n        }","zopro_bn254::G1Config","Window<'a, Config>","Window::new(half,size)","G1"),
 ("crates/zopro-core/src/msm_affine/g2_borrowed.rs","        for (i, _) in &self.batch {\n            self.busy[(i & 0x7fffffff) as usize / 64] = 0;\n        }","zopro_bn254::G2Config","Window<'a>","Window::new(half,size,BatchAdd::default())","G2")
 ] {
  let p=format!("{R}/source/{rel}");let text=fs::read_to_string(&p).unwrap();assert_eq!(text.matches(before).count(),1);
  let after=format!("        #[cfg(zopro_dense_busy_reset)]\n        if self.busy.len() <= self.batch.len() {{\n            self.busy.fill(0);\n        }} else {{\n{before}\n        }}\n        #[cfg(not(zopro_dense_busy_reset))]\n{before}");
  let suffix=format!("\n{}",template.replace("__CONFIG__",config).replace("__STATE__",state).replace("__NEW__",new).replace("__CURVE__",curve));
  fs::write(p,text.replace(before,&after)+&suffix).unwrap();edits.push(json!({"path":rel,"before":before,"after":after,"suffix":suffix}));
 }
 save("source-audit.json",json!({"originals":originals,"edits":edits,"exact_originals":174,"recoverable_originals":2,"total_originals":176,"field_unchanged":true,"production_changed":false,"no_common_wrapper_in_OFF":true}));
 let parent=read(format!("{P}/plan.json"));let mut steps=Vec::new();
 for (arm,test) in [("OFF",false),("ON",false),("ON-test",true)] {
  fs::create_dir_all(format!("{R}/libs/{arm}")).unwrap();let mut s=parent["steps"][0].clone();s["name"]=json!(format!("build-core-{arm}"));let argv=s["argv"].as_array_mut().unwrap();for v in argv.iter_mut(){*v=json!(v.as_str().unwrap().replace(P,R).replace(&format!("{R}/libs/OFF"),&format!("{R}/libs/{arm}")).replace("tree_option_owner176_OFF",&format!("busy_reset176_{arm}")));}
  if arm!="OFF"{argv.extend([json!("--cfg"),json!("zopro_dense_busy_reset")]);}
  if test{let at=argv.iter().position(|v|v=="--crate-type").unwrap();argv.drain(at..at+2);let at=argv.iter().position(|v|v=="-o").unwrap();argv[at+1]=json!(format!("{R}/core-tests"));argv.push(json!("--test"));}
  s["environment"]["CARGO_MANIFEST_DIR"]=json!(format!("{R}/source/crates/zopro-core"));steps.push(s);
 }
 let env=steps[0]["environment"].clone();
 steps.push(json!({"kind":"command","name":"qualify-bitmap-complete-windows","argv":[format!("{R}/core-tests"),"busy_reset_qualification::exact_pending_set_complete_windows_and_workers","--nocapture","--test-threads=1"],"environment":env,"timeout_seconds":900}));
 let repaired=read(format!("{P}/repair-plan.json"));let mut generic=repaired["steps"].as_array().unwrap().last().unwrap().clone();generic["name"]=json!("generic-noASM-noIFMA-guard");let argv=generic["argv"].as_array_mut().unwrap();for v in argv.iter_mut(){*v=json!(v.as_str().unwrap().replace(P,R).replace("tree_option_owner176_generic","busy_reset176_generic").replace("zopro_tree_option_owner","zopro_dense_busy_reset"));}generic["environment"]["CARGO_MANIFEST_DIR"]=json!(format!("{R}/source/crates/zopro-core"));fs::create_dir_all(format!("{R}/libs/ON")).unwrap();steps.push(generic);
 for (rel,_) in originals {let p=format!("{R}/source/{rel}");pins.insert(p.clone(),json!(hash(p)));}
 for f in ["design.md","cases-template.rs","prepare.rs","prepare","source-audit.json"]{let p=format!("{R}/{f}");pins.insert(p.clone(),json!(hash(p)));}
 for s in &steps{for v in s["argv"].as_array().unwrap(){let t=v.as_str().unwrap();let p=t.split_once('=').map_or(t,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.to_owned(),json!(hash(p)));}}}
 let plan=json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps});save("plan.json",plan);pins.insert(format!("{R}/plan.json"),json!(hash(format!("{R}/plan.json"))));save("pins.json",json!(pins));println!("Prepared two reversible bitmap edits;OFF/ON/test/generic;five commands;no clocks");
}
