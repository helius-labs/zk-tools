use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,process::Command,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/busy-reset176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert!(!Path::new(R).join("review-result.json").exists());
 let changed_path=format!("{R}/source/crates/zopro-core/src/msm_affine/g2_borrowed.rs");
 let mut pin_count=0;
 for pin_file in ["pins.json","diagnostic-pins.json","boundary-pins.json","repair-pins.json"] {
  let pins=read(format!("{R}/{pin_file}"));pin_count=pins.as_object().unwrap().len();
  for(p,h)in pins.as_object().unwrap(){let q=if p==&changed_path && pin_file!="repair-pins.json"{format!("{R}/before-g2-fixture/g2_borrowed.rs")}else{p.clone()};assert_eq!(hash(q),h.as_str().unwrap(),"{pin_file} {p}");}
 }
 let before=fs::read_to_string(format!("{R}/before-g2-fixture/g2_borrowed.rs")).unwrap();let after=fs::read_to_string(&changed_path).unwrap();assert_eq!(before.replace("        execute(&mut s,&mut c);\n        let actual=s.finish();let g=Proj::generator();","        execute(&mut s,&mut c);\n        s.flush_queue();\n        assert!(s.batch.is_empty() && s.queue.is_empty());\n        let actual=s.finish();let g=Proj::generator();"),after);let marker="\n#[cfg(all(test,zopro_dense_busy_reset))]\nmod busy_reset_qualification";assert_eq!(before.split(marker).next(),after.split(marker).next());
 let audit=read(format!("{R}/repaired-source-audit.json"));let originals=audit["originals"].as_object().unwrap();assert_eq!(originals.len(),176);assert_eq!(audit["edits"].as_array().unwrap().len(),2);
 for(rel,h)in originals{
  assert_eq!(hash(format!("{Z}/{rel}")),h.as_str().unwrap());let mut b=fs::read(format!("{R}/source/{rel}")).unwrap();
  if let Some(e)=audit["edits"].as_array().unwrap().iter().find(|e|e["path"]==rel.as_str()){
   let s=String::from_utf8(b).unwrap();let s=s.strip_suffix(e["suffix"].as_str().unwrap()).unwrap();assert_eq!(s.matches(e["after"].as_str().unwrap()).count(),1);assert!(e["after"].as_str().unwrap().contains("self.busy.len() <= self.batch.len()"));assert!(e["after"].as_str().unwrap().contains("self.busy.fill(0)"));b=s.replace(e["after"].as_str().unwrap(),e["before"].as_str().unwrap()).into_bytes();
  }
  assert_eq!(format!("{:x}",Sha256::digest(&b)),h.as_str().unwrap());
 }
 let plan=read(format!("{R}/plan.json"));let steps=plan["steps"].as_array().unwrap();assert_eq!(steps.len(),5);
 let mut receipt_count=0;let mut success_count=0;
 for(plan_file,run_dir,take)in[("plan.json","runs",4),("diagnostic-plan.json","diagnostic-run",2),("scalar-control-plan.json","scalar-control-run",1),("boundary-plan.json","boundary-run",2),("repair-plan.json","repair-run",3)] {
 let p=read(format!("{R}/{plan_file}"));for s in p["steps"].as_array().unwrap().iter().take(take){
  let dir=format!("{R}/{run_dir}/{}",s["name"].as_str().unwrap());let exit=read(format!("{dir}/exit.json"));let name=s["name"].as_str().unwrap();let success=name.starts_with("build-")||run_dir=="repair-run";assert_eq!(exit["success"],success);assert_eq!(exit["returncode"],if success{0}else{101});receipt_count+=1;if success{success_count+=1;}
  let cmd=read(format!("{dir}/command.json"));assert_eq!(&cmd["argv"].as_array().unwrap()[4..],s["argv"].as_array().unwrap());
  for stream in["stdout","stderr"]{assert_eq!(hash(format!("{dir}/{stream}.log")),exit[format!("{stream}_sha256")]);}
 }}assert_eq!(receipt_count,12);assert_eq!(success_count,8);
 for (i,arm) in ["OFF","ON","ON-test"].iter().enumerate(){
  let args=steps[i]["argv"].as_array().unwrap();assert!(args.iter().any(|v|v=="-O"));assert!(args.iter().any(|v|v=="target-cpu=native"));assert!(args.iter().any(|v|v=="codegen-units=1"));assert!(args.iter().any(|v|v.as_str().unwrap().ends_with("libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib")));assert_eq!(args.iter().any(|v|v=="zopro_dense_busy_reset"),*arm!="OFF");assert!(!args.iter().any(|v|v=="zopro_tree_option_owner"));
 }
 let generic=steps[4]["argv"].as_array().unwrap();for a in["target-cpu=x86-64","no_asm","no_ifma","zopro_dense_busy_reset"]{assert!(generic.iter().any(|v|v==a));}
 let initial=fs::read_to_string(format!("{R}/runs/qualify-bitmap-complete-windows/stdout.log")).unwrap();assert!(initial.contains("1 passed; 1 failed"));let repaired=fs::read_to_string(format!("{R}/repair-run/qualify-fixture-repaired-G2-only/stdout.log")).unwrap();assert!(repaired.contains("1 passed; 0 failed"));let text=initial+&repaired;let mut counts=BTreeMap::new();
 for curve in["G1","G2"]{
  let needle=format!("BUSY_RESET {curve} WORKERS=53 CONCURRENT_CALLS=12 COUNTS=Counts {{");let line=text.lines().find(|l|l.contains(&needle)).unwrap();let body=line.split(&needle).nth(1).unwrap().split('}').next().unwrap();let mut c=BTreeMap::new();for entry in body.split(','){let(k,v)=entry.trim().split_once(':').unwrap();c.insert(k.trim().to_owned(),v.trim().parse::<u64>().unwrap());}assert_eq!(c["cases"],110);for k in["checks","dense","sparse","empty","queued","flushes","identities","equal","opposite"]{assert!(c[k]>0,"{curve} {k}");}counts.insert(curve.to_owned(),c);
 }
 let control=fs::read_to_string(format!("{R}/source-boundary/crates/zopro-core/src/msm_affine/g2_borrowed.rs")).unwrap();let accepted=fs::read_to_string(format!("{Z}/crates/zopro-core/src/msm_affine/g2_borrowed.rs")).unwrap();assert!(control.starts_with(&accepted));let stdout=fs::read_to_string(format!("{R}/boundary-run/original-reset-G2-boundary-control/stdout.log")).unwrap();assert!(stdout.contains("G2_ORIGINAL_RESET stage=before finish pending=0 queue=2 projective=1"));
 // Independent word-set argument: if every set bit belongs to one pending
 // destination, the old word-clears and whole-array clear both yield zero.
 let mut set_cases=0;for mask in 0u32..4096{
  let mut busy=[0u64;4];let mut destinations=vec![];for b in 0..12{if mask>>b&1!=0{let bit=b*21;busy[bit/64]|=1u64<<(bit%64);destinations.push(bit);}}
  let mut original=busy;for b in &destinations{original[*b/64]=0;}let mut candidate=busy;if candidate.len()<=destinations.len(){candidate.fill(0);}else{for b in &destinations{candidate[*b/64]=0;}}
  assert_eq!(candidate,original);assert_eq!(candidate,[0;4]);set_cases+=1;
 }
 let mut identities=BTreeMap::new();for arm in["OFF","ON"]{
  let p=format!("{R}/libs/{arm}/libzopro_core.rlib");let out=Command::new("nm").args(["-C",&p]).output().unwrap();assert!(out.status.success());fs::write(format!("{R}/{arm}.nm"),&out.stdout).unwrap();let symbols=String::from_utf8(out.stdout).unwrap();for needle in["busy_reset_qualification","exact_pending_set_complete_windows_and_workers"]{assert!(!symbols.contains(needle));}identities.insert(arm,json!({"library":p,"sha256":hash(&p),"nm_sha256":hash(format!("{R}/{arm}.nm"))}));
 }
 let ledger="/home/ubuntu/src/zopro-perf-work/negative-phi-sdk176/proof-sha256-after-capture.json";assert_eq!(read(ledger).as_array().unwrap().len(),41104);
 let out=json!({"passed":true,"actual_native_commands":12,"successful_native_commands":8,"retained_invalid_fixture_test_exits":4,"repair_pins":pin_count,"G1_success_reused_not_replayed":true,"G2_test_only_queue_precondition_repair":true,"release_libraries_reused_not_rebuilt_after_test_repair":true,"original_reset_G2_control_retains_same_fixture_failure":true,"kernel_bug_not_established":true,"exact_originals":174,"recovered_originals":176,"curves":counts,"complete_window_cases":220,"actual_workers_per_curve":53,"shared_pool_concurrent_calls_per_curve":12,"independent_bitmap_set_cases":set_cases,"source_invariant_reviewed":true,"busy_pointer_capacity_unchanged":true,"original_scalar_curve_generator_oracle":true,"new_independent_Arkworks_oracle":false,"generic_compile_only_not_ARM_execution":true,"field1200_unchanged":true,"release_test_helpers_absent":true,"identities":identities,"new_proofs":0,"canonical_proofs":41104,"ledger_sha256":hash(ledger),"production_changed":false,"speed_measured":false,"adopted":false,"goal_complete":false});
 fs::write(format!("{R}/review-result.json"),serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("{}",serde_json::to_string(&out).unwrap());
}
