use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path};const R:&str="/home/ubuntu/src/zopro-perf-work/busy-reset176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert!(!Path::new(R).join("source-boundary").exists());let audit=read(format!("{R}/source-audit.json"));
 for(rel,_)in audit["originals"].as_object().unwrap(){let p=format!("{R}/source-boundary/{rel}");fs::create_dir_all(Path::new(&p).parent().unwrap()).unwrap();fs::copy(format!("{R}/source-diagnostic/{rel}"),p).unwrap();}
 let p=format!("{R}/source-boundary/crates/zopro-core/src/msm_affine/g2_borrowed.rs");let mut t=fs::read_to_string(&p).unwrap();let e=&audit["edits"][1];assert_eq!(t.matches(e["after"].as_str().unwrap()).count(),1);t=t.replace(e["after"].as_str().unwrap(),e["before"].as_str().unwrap());
 let before="        execute(&mut s,&mut c);\n        s.take_from_queue();check(&s,&mut c);\n        execute(&mut s,&mut c);\n        let actual=s.finish();let g=Proj::generator();";
 let after=r#"        let conserved=|s:&State<'_>,stage:&str|{
            if half==1 && size==8 {
                let mut total=s.affine[0].to_projective();
                for v in &s.projective {total+=v;}
                for &(encoded,p) in s.batch.iter().chain(&s.queue) {total+=if encoded>>31!=0{-*p}else{*p};}
                assert_eq!(total.to_affine(),(Proj::generator()*want[0]).to_affine(),"original-reset G2 stage {stage},pending={},queue={},projective={}",s.batch.len(),s.queue.len(),s.projective.len());
                println!("G2_ORIGINAL_RESET stage={stage} pending={} queue={} projective={}",s.batch.len(),s.queue.len(),s.projective.len());
            }
        };
        conserved(&s,"before execute1");execute(&mut s,&mut c);conserved(&s,"after execute1");
        s.take_from_queue();check(&s,&mut c);conserved(&s,"after queue drain");
        execute(&mut s,&mut c);conserved(&s,"before finish");
        let actual=s.finish();let g=Proj::generator();"#;
 assert_eq!(t.matches(before).count(),1);t=t.replace(before,after);fs::write(&p,&t).unwrap();
 let original=fs::read_to_string("/home/ubuntu/src/zk-tools/zopro/crates/zopro-core/src/msm_affine/g2_borrowed.rs").unwrap();assert!(t.starts_with(&original));
 let mut step=read(format!("{R}/diagnostic-plan.json"))["steps"][0].clone();step["name"]=json!("build-original-reset-G2-boundary-tests");for v in step["argv"].as_array_mut().unwrap(){*v=json!(v.as_str().unwrap().replace(&format!("{R}/source-diagnostic/"),&format!("{R}/source-boundary/")).replace(&format!("{R}/core-tests-diagnostic"),&format!("{R}/core-tests-boundary")));}step["environment"]["CARGO_MANIFEST_DIR"]=json!(format!("{R}/source-boundary/crates/zopro-core"));
 let run=json!({"kind":"command","name":"original-reset-G2-boundary-control","argv":[format!("{R}/core-tests-boundary"),"msm_affine::g2_borrowed::busy_reset_qualification::exact_pending_set_complete_windows_and_workers","--exact","--nocapture","--test-threads=1"],"environment":step["environment"],"timeout_seconds":900});let plan=json!({"version":1,"source_pins":format!("{R}/boundary-pins.json"),"steps":[step,run]});fs::write(format!("{R}/boundary-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();
 let mut pins=read(format!("{R}/diagnostic-pins.json"));for(rel,_)in audit["originals"].as_object().unwrap(){let p=format!("{R}/source-boundary/{rel}");pins[&p]=json!(hash(&p));}for f in["prepare-boundary.rs","prepare-boundary","boundary-plan.json","scalar-control-plan.json"]{let p=format!("{R}/{f}");pins[&p]=json!(hash(&p));}fs::write(format!("{R}/boundary-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();println!("Separate original-reset G2 control has byte-exact accepted non-test prefix; new completion-boundary assertions; no release/source replay");
}
