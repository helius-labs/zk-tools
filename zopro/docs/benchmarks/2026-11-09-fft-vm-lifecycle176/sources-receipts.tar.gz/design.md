# Accepted FFT/SDK virtual-memory lifecycle diagnostic

Previous turn progressed: bounded fixed-factor FFT was measured, rejected in
all six contexts, independently reviewed and pushed28d885a9ac. That recipe stays
closed. Goal remains verified CPUAVX single-proof >=10x suppliedM5CPU ALL8, with
CPU/Metal comparisons. This diagnostic seeks an actual accepted-code memory
lifecycle mechanism; it cannot select or claim a speedup.

A scope audit found the previous complete-consumer driver uses System while
the SDK installs zopro_core::alloc::Allocator and enters proof pressure scopes.
Thus the rare low-fault consumer block does not establish an SDK optimization.
Compare: unchanged System caller-REF; a new baseline-only caller differing only
by installing the existing Zopro allocator; unchanged accepted SDK6d83. No
candidate arithmetic, fixed factors or production source changes are involved.
The new caller first checks two independent full-output fixtures with NEW seeds.

Freeze16 traces: six domains65536/262144 x workers1/16/32 for each consumer
allocator; SDK1x2/merge54 x workers1/32. Three ordinary primes, then3 traced calls
per process. Consumers check full Arkworks outputs/digests; SDK verifies all
requests internally and exports its final proof. Four exports receive independent
Gnark verification after all recordings. Total24 SDK proofs including primes,
four new distinct exports against the prior40154 ledger. These are diagnostic
proofs, not replacement latency measurements. Never publish raw input/proof
payloads or the full proof ledger.

Use existing acknowledged perfFIFO gates. Start disabled, then trace only the
warmed loop. Capture sys_enter/exit for mmap,munmap,madvise,brk,mremap,mprotect
with period1, plus minor-faults at period512. Record addresses and DWARF user
callchains (8192bytes), timestamp,CPU,period,512mmap pages. Rawstack recordings
stay private. Capture all16 before any ownership/hash/decode/analysis/verifier
work; only poll the confirmed live workflow. No preflight or untraced timing
reroll. Plan/inputs/ELFs/events/loops are fixed before recording.

After capture, validate events/gates/PID and binary mappings, zeroLOST and exact
proof bindings. Pair each syscall entry/exit within its TID, keeping unmatched
boundary events visible. Report successful mapped/unmapped/advised byte volume,
callers and fault-sample stacks. Zero events are valid observations, not a reason
to rerun. Stack truncation/unknown frames limit attribution. Tracing affects
scheduling and timings; no recorded ms or syscall duration is an optimization
claim. Sampled minor faults are not exact event counts; getrusage totals and
tracepoint events are separate observations.

Questions fixed before data: does the large repeated fault pattern appear with
the real allocator and SDK? Is it associated with explicit pressure routing,
glibc arena mapping/decommit, or new first touch without unmapping? Which actual
Rust caller owns affected scratch? A source fix requires direct mechanism
evidence in the SDK, not favorable consumer-only behavior. No revival of old
coarse/bulk prefault, executable-copy, generic scheduler or stack-frame variants.
No new persistent workspace/cache/pool, synthetic cap, C/ASM rewrite, allocator
setting sweep or disabled low-memory reclamation.

Instrumentation follows the kernel perf manual's event-period, DWARF stack
and acknowledged control mechanisms:
https://man7.org/linux/man-pages/man1/perf-record.1.html
Localperf6.8.12 and tracefs formats are authoritative for this capture.
