//! Remove only known-unit prefix products and the final unused inverse update.
use super::*;
pub(super) fn g1<C: CurveConfig<Base = Fq>, const FAST: bool, const SIGNED: bool>(
    buckets: &mut [Affine<C>],
    batch: &[(u32, impl std::borrow::Borrow<Affine<C>> + Copy)],
    s: &mut FqAddScratch,
) {
    let full = batch.len() / LANES * LANES;
    let mut chains = FqBatch::one();
    s.groups.clear();
    assert!(full >= LANES && s.write_groups && s.reserve_groups && s.vector_inverse && s.canonical);
    s.groups.reserve(full / LANES);
    {
        let a: [Affine<C>; LANES] = core::array::from_fn(|i| buckets[batch_index::<SIGNED>(batch[i].0)]);
        let b: [Affine<C>; LANES] = core::array::from_fn(|i| *batch[i].1.borrow());
        let ax = FqBatch::new(&a.map(|p| p.x));
        let bx = FqBatch::new(&b.map(|p| p.x));
        let denominator = canonical_sub::<FAST>(&bx, &ax);
        let xsum = canonical_add::<FAST>(&ax, &bx);
        let ay = FqBatch::new(&a.map(|p| p.y));
        let by = FqBatch::new(&b.map(|p| p.y));
        let numerator = if SIGNED {by.signed_difference_canonical(&ay,signs::<SIGNED,C>(&batch[..LANES]))}else{canonical_sub::<FAST>(&by,&ay)};
        s.groups.push(FqAddGroup{ax,ay,xsum,denominator,numerator});
        chains = denominator;
    }
        for k in (LANES..full).step_by(LANES) {
            let a: [Affine<C>; LANES] = core::array::from_fn(|i| buckets[batch_index::<SIGNED>(batch[k + i].0)]);
            let b: [Affine<C>; LANES] = core::array::from_fn(|i| *batch[k + i].1.borrow());
            // SAFETY: reserve covers full/LANES records, k/LANES is in
            // that range, and no allocation changes during these writes.
            // addr_of_mut! creates no reference to uninitialized storage.
            unsafe {
                let slot = s.groups.as_mut_ptr().add(k / LANES);
                let ax = FqBatch::new(&a.map(|p| p.x));
                core::ptr::addr_of_mut!((*slot).ax).write(ax);
                let bx = FqBatch::new(&b.map(|p| p.x));
                let denominator = canonical_sub::<FAST>(&bx, &ax);
                core::ptr::addr_of_mut!((*slot).xsum).write(canonical_add::<FAST>(&ax, &bx));
                core::ptr::addr_of_mut!((*slot).denominator).write(denominator);
                let ay = FqBatch::new(&a.map(|p| p.y));
                core::ptr::addr_of_mut!((*slot).ay).write(ay);
                let by = FqBatch::new(&b.map(|p| p.y));
                let numerator = scaled_signed_dy::<FAST,SIGNED>(&by,&ay,&chains,signs::<SIGNED,C>(&batch[k..k+LANES]));
                core::ptr::addr_of_mut!((*slot).numerator).write(numerator);
                chains = chains.mul(&denominator);
                // All five fields of this record are now initialized.
                s.groups.set_len(k / LANES + 1);
            }
        }
    s.tail.clear();
    let mut inverse = if let Some(value)=direct_chain_inverse(&chains,full==batch.len(),s.vector_inverse) {
        value
    } else {
        let mut tail = chains.get();
        for k in full..batch.len() {
            let (index, b) = batch[k];
            let b = *b.borrow();
            let b = if SIGNED && index>>31!=0 {-b}else{b};
            let a = buckets[batch_index::<SIGNED>(index)];
            let denominator = b.x - a.x;
            let numerator = (b.y - a.y) * tail[k % LANES];
            tail[k % LANES] *= denominator;
            s.tail.push([a.x, a.y, a.x + b.x, denominator, numerator]);
        }
        let mut inverse = invert_lanes(tail, s.vector_inverse);
        for k in (full..batch.len()).rev() {
            let [ax, ay, xsum, denominator, numerator] = s.tail[k - full];
            let slope = numerator * inverse[k % LANES];
            inverse[k % LANES] *= denominator;
            let x = slope.square() - xsum;
            let y = slope * (ax - x) - ay;
            buckets[batch_index::<SIGNED>(batch[k].0)] = Affine::new(x, y);
        }
        FqBatch::new(&inverse)
    };
    for (j, g) in s.groups.iter().enumerate().skip(1).rev() {
        let slope = g.numerator.mul(&inverse);
        inverse = inverse.mul(&g.denominator);
        let x = slope.mul(&slope).sub(&g.xsum);
        let y = slope.mul(&g.ax.sub(&x)).sub(&g.ay);
        let (x, y) = (x.get(), y.get());
        for i in 0..LANES {
            buckets[batch_index::<SIGNED>(batch[j * LANES + i].0)] = Affine::new(x[i], y[i]);
        }
    }
    {let j=0; let g=&s.groups[0];
        let slope = g.numerator.mul(&inverse);
        let x = slope.mul(&slope).sub(&g.xsum);
        let y = slope.mul(&g.ax.sub(&x)).sub(&g.ay);
        let (x, y) = (x.get(), y.get());
        for i in 0..LANES {
            buckets[batch_index::<SIGNED>(batch[j * LANES + i].0)] = Affine::new(x[i], y[i]);
        }
    }

}
pub(super) fn g2<C: CurveConfig<Base = Fq2>, const FAST: bool>(
    buckets: &mut [Affine<C>],
    batch: &[(u32, &Affine<C>)],
    s: &mut Fq2AddScratch,
) {
    let full = batch.len() / LANES * LANES;
    let mut chains = FqBatch::one();
    s.prefix_records.clear();
    s.prefix_records.reserve(full / LANES);
    assert!(full>=LANES && FAST && s.vector_inverse && s.canonical);
    { let k=0;
        let ax = fq2_pack(core::array::from_fn(|i| {
            buckets[(batch[k + i].0 & 0x7fffffff) as usize].x
        }));
        let bx = fq2_pack(core::array::from_fn(|i| batch[k + i].1.x));
        let denominator = core::array::from_fn(|i| canonical_sub::<FAST>(&bx[i], &ax[i]));
        let norm = Fq2::lanes_norm(&denominator);
        s.prefix_records.push([chains, norm]);
        chains = norm;
    }
    for k in (LANES..full).step_by(LANES) {
        let ax = fq2_pack(core::array::from_fn(|i| {
            buckets[(batch[k + i].0 & 0x7fffffff) as usize].x
        }));
        let bx = fq2_pack(core::array::from_fn(|i| batch[k + i].1.x));
        let denominator = core::array::from_fn(|i| canonical_sub::<FAST>(&bx[i], &ax[i]));
        let norm = Fq2::lanes_norm(&denominator);
        s.prefix_records.push([chains, norm]);
        chains = chains.mul(&norm);
    }
    s.tail.clear();
    let mut inverse =
        if let Some(value) = direct_chain_inverse(&chains, full == batch.len(), s.vector_inverse) {
            value
        } else {
            let mut tail = chains.get();
            for k in full..batch.len() {
                let (encoded, b) = batch[k];
                let index = encoded & 0x7fffffff;
                let b = if encoded >> 31 != 0 { -*b } else { *b };
                let a = buckets[index as usize];
                let denominator = b.x - a.x;
                let norm = denominator.c0.square() + denominator.c1.square();
                let numerator = ((b.y - a.y) * denominator.conjugate()).mul_by_fp(&tail[k % LANES]);
                tail[k % LANES] *= norm;
                s.tail
                    .push([a.x, a.y, a.x + b.x, Fq2::new(norm, Fq::ZERO), numerator]);
            }
            let mut inverse = invert_lanes(tail, s.vector_inverse);
            for k in (full..batch.len()).rev() {
                let [ax, ay, xsum, norm, numerator] = s.tail[k - full];
                let slope = numerator.mul_by_fp(&inverse[k % LANES]);
                inverse[k % LANES] *= norm.c0;
                let x = slope.square() - xsum;
                let y = slope * (ax - x) - ay;
                buckets[(batch[k].0 & 0x7fffffff) as usize] = Affine::new(x, y);
            }
            FqBatch::new(&inverse)
        };
    for j in (1..full / LANES).rev() {
        let k = j * LANES;
        let a: [Affine<C>; LANES] =
            core::array::from_fn(|i| buckets[(batch[k + i].0 & 0x7fffffff) as usize]);
        let b: [&Affine<C>; LANES] = core::array::from_fn(|i| batch[k + i].1);
        let ax = fq2_pack(a.map(|p| p.x));
        let ay = fq2_pack(a.map(|p| p.y));
        let bx = fq2_pack(b.map(|p| p.x));
        let dy=if FAST{
            let by=fq2_pack(b.map(|p|p.y));
            let negative=signs::<true,C>(&batch[k..k+LANES]);
            core::array::from_fn(|i|by[i].signed_difference_canonical(&ay[i],negative))
        }else{
            let by=fq2_pack(core::array::from_fn(|i|if batch[k+i].0>>31!=0{-b[i].y}else{b[i].y}));
            core::array::from_fn(|i|canonical_sub::<FAST>(&by[i],&ay[i]))
        };
        let denominator=core::array::from_fn(|i|canonical_sub::<FAST>(&bx[i],&ax[i]));
        let factor = s.prefix_records[j][0].mul(&inverse);
        inverse = inverse.mul(&s.prefix_records[j][1]);
        let slope = Fq2::lanes_scaled_numerator(&dy, &denominator, &factor);
        let x = Fq2::lanes_sub(&Fq2::lanes_square(&slope), &Fq2::lanes_add(&ax, &bx));
        let y = Fq2::lanes_sub(&Fq2::lanes_mul(&slope, &Fq2::lanes_sub(&ax, &x)), &ay);
        let (x, y) = (fq2_unpack(x), fq2_unpack(y));
        for i in 0..LANES {
            buckets[(batch[k + i].0 & 0x7fffffff) as usize] = Affine::new(x[i], y[i]);
        }
    }
    {let j=0;
        let k = j * LANES;
        let a: [Affine<C>; LANES] =
            core::array::from_fn(|i| buckets[(batch[k + i].0 & 0x7fffffff) as usize]);
        let b: [&Affine<C>; LANES] = core::array::from_fn(|i| batch[k + i].1);
        let ax = fq2_pack(a.map(|p| p.x));
        let ay = fq2_pack(a.map(|p| p.y));
        let bx = fq2_pack(b.map(|p| p.x));
        let dy=if FAST{
            let by=fq2_pack(b.map(|p|p.y));
            let negative=signs::<true,C>(&batch[k..k+LANES]);
            core::array::from_fn(|i|by[i].signed_difference_canonical(&ay[i],negative))
        }else{
            let by=fq2_pack(core::array::from_fn(|i|if batch[k+i].0>>31!=0{-b[i].y}else{b[i].y}));
            core::array::from_fn(|i|canonical_sub::<FAST>(&by[i],&ay[i]))
        };
        let denominator=core::array::from_fn(|i|canonical_sub::<FAST>(&bx[i],&ax[i]));
        let factor = inverse;
        let slope = Fq2::lanes_scaled_numerator(&dy, &denominator, &factor);
        let x = Fq2::lanes_sub(&Fq2::lanes_square(&slope), &Fq2::lanes_add(&ax, &bx));
        let y = Fq2::lanes_sub(&Fq2::lanes_mul(&slope, &Fq2::lanes_sub(&ax, &x)), &ay);
        let (x, y) = (fq2_unpack(x), fq2_unpack(y));
        for i in 0..LANES {
            buckets[(batch[k + i].0 & 0x7fffffff) as usize] = Affine::new(x[i], y[i]);
        }
    }

}
