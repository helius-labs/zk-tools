#[cfg(all(test,zopro_unit_prefix))]
mod unit_tests{
 use super::*;
 #[test]fn complete_signed_and_owned_tails_match_generators(){
  for n in[0,1,7,8,9,15,16,17,31,32,33,63,64,127,128,199,200,201,351,352,353,511,512]{for seed in[1,19]{
   for borrowed in[false,true]{let mut a=G1Caller::new(n,seed);for rounds in[1,3,17]{a.reset();a.run(rounds,true,borrowed);a.check(rounds);}}
   let mut b=G2Caller::new(n,seed);for rounds in[1,3,17]{b.reset();b.run(rounds,true,true);b.check(rounds);}
  }}
 }
 #[test]fn same_scratch_off_on_transitions_and_capacity(){for n in[8,9,16,200,352,511]{
  let mut a=G1Caller::new(n,23);let mut b=G2Caller::new(n,23);for on in[false,true,false,true]{a.reset();b.reset();a.run(9,on,true);b.run(9,on,true);a.check(9);b.check(9);}let ca=a.capacities();let cb=b.capacities();a.reset();b.reset();a.run(17,true,true);b.run(17,true,true);assert_eq!(a.capacities(),ca);assert_eq!(b.capacities(),cb);a.check(17);b.check(17);
 }}
 #[test]fn threaded_small_stack(){use rayon::prelude::*;for w in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(w).stack_size(512*1024).build().unwrap();pool.install(||(0..w).into_par_iter().for_each(|i|{for n in[8,17,200,352]{let mut a=G1Caller::new(n,i as u64+31);let mut b=G2Caller::new(n,i as u64+31);a.run(3,true,true);b.run(3,true,true);a.check(3);b.check(3);}}));}}
}
