use std::fs;const R:&str="/home/ubuntu/src/zopro-perf-work/unit-prefix176";
fn change(s:String,a:&str,b:&str)->String{assert_eq!(s.matches(a).count(),1,"{a}");s.replace(a,b)}
fn main(){let mut s=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/high-borrow176/publish.rs").unwrap().replace("/home/ubuntu/src/zopro-perf-work/high-borrow176",R).replace("2026-10-31-high-borrow176","2026-10-31-unit-prefix176");
let a=s.find("assert_eq!(v[\"samples\"],93990);").unwrap();let b=s[a..].find("fs::create_dir_all(d(\"artifacts\"))").unwrap()+a;
let checks=r#"assert!(v["samples"].as_u64().unwrap()>0);assert_eq!(v["gate_passed"],a["gate_passed"]);for(p,h)in read(r("pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}assert_eq!(hash("/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/native/candidate-sdk"),"6d83f1d6fda6f16576cb351b81789e8d26a6177cc0f26f169a3dc98448c0e661");for(label,bin)in[("control","control-bin"),("candidate","ON-bin")]{assert_eq!(hash(r(bin)),code[label]["binary_sha256"]);for f in code[label]["functions"].as_array().unwrap(){assert_eq!(hash(f["disassembly"].as_str().unwrap()),f["sha256"]);}}assert_eq!(hash(r("OFF-bin")),hash(r("ON-bin")));
"#;s.replace_range(a..b,checks);
s=change(s,"\"helper-repair.md\",\"publish.rs\"","\"history.md\",\"publish.rs\"");
s=change(s,"doc=doc.replace(\"{{AGGREGATES}}\",&table);","doc=doc.replace(\"{{AGGREGATES}}\",&table).replace(\"{{GATE}}\",&a[\"gate_passed\"].to_string()).replace(\"{{SAMPLES}}\",&v[\"samples\"].to_string());");
let a=s.find("table=\"|Linked function|").unwrap();let b=s[a..].find("let m=read(").unwrap()+a;
let block=r#"table="|Compiled context / function|Bytes|\n|---|---:|\n".into();for arm in["control","candidate"]{for f in code[arm]["functions"].as_array().unwrap(){writeln!(table,"|{arm} / `{}`|{}|",f["symbol"].as_str().unwrap(),f["bytes"]).unwrap();}}doc=doc.replace("{{CODEGEN}}",&table);
"#;s.replace_range(a..b,block);
s=change(s,"assert_eq!(assembly.len(),7);walk(&r(\"linked-code-initial\"),&mut assembly);assert_eq!(assembly.len(),11);","");
s=change(s,"\"field_tests\":37,\"core_tests\":127","\"field_tests_fresh\":0,\"field_tests_inherited\":35,\"core_tests\":128");s=change(s,"\"profile_samples\":93990,\"gate_passed\":false,\"failed_checks\":12","\"profile_samples\":v[\"samples\"],\"gate_passed\":a[\"gate_passed\"],\"failed_checks\":a[\"failed_checks\"]");s=change(s,"\"proof_ledger\":28349","\"proof_ledger\":28847");s=change(s,"guarded-borrow gatefalse","unit-prefix qualification");
fs::write(format!("{R}/publish.rs"),s).unwrap();}
