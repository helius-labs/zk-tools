use std::fs;
const R:&str="/home/ubuntu/src/zopro-perf-work/unit-prefix176";
fn change(s:String,a:&str,b:&str)->String{assert_eq!(s.matches(a).count(),1,"{a}");s.replace(a,b)}
fn main(){
 let mut s=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/high-borrow176/campaign.rs").unwrap().replace("/home/ubuntu/src/zopro-perf-work/high-borrow176",R);
 s=change(s,"test result: ok. 127 passed;","test result: ok. 128 passed;");
 s=change(s,"assert!(fs::read_to_string(r(\"field-tests.log\")).unwrap().contains(\"test result: ok. 37 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out\"));","");
 s=change(s,"assert_ne!(hash(r(\"OFF-bin\")),hash(r(\"ON-bin\")));","assert_eq!(hash(r(\"OFF-bin\")),hash(r(\"ON-bin\")));");
 s=change(s,"for label in[\"control\",\"OFF\",\"ON\"]","for label in[\"control\",\"candidate\"]");s=change(s,"--crate-name zopro_high_borrow_","--crate-name zopro_unit_prefix_");
 let a=s.find("for f in[\"setup.rs\"").unwrap();let b=a+s[a..].find("{files.push(r(f));}").unwrap()+"{files.push(r(f));}".len();
 let list="for f in[\"setup.rs\",\"setup\",\"build.rs\",\"build\",\"g1-seed.txt\",\"unit_prefix.rs\",\"g1-original.rs\",\"g2-original.rs\",\"test-core.rs\",\"prepare-driver.rs\",\"prepare-driver\",\"prepare-campaign.rs\",\"prepare-campaign\",\"g1-caller.rs\",\"g2-caller.rs\",\"design.md\",\"history.md\",\"driver.rs\",\"campaign.rs\",\"campaign\",\"control-flags.txt\",\"candidate-flags.txt\",\"control-bin\",\"OFF-bin\",\"ON-bin\",\"original-pins.json\",\"core-tests.log\",\"build-control.log\",\"build-candidate.log\",\"host.txt\",\"source-audit.json\",\"audit.rs\",\"audit\",\"source-audit.log\"]{files.push(r(f));}";
 s.replace_range(a..b,list);
 s=change(s,"walk(&r(\"linked-code\"),&mut files);","");
 s=change(s,"\"proof_ledger\":28349","\"proof_ledger\":28847");
 fs::write(format!("{R}/campaign.rs"),s).unwrap();println!("Campaign prepared: inherited15block12context caller/PMU/profile flow;new qualification/pins/identicalcandidateOFF-ON/ledger updated;capture not launched");
}
