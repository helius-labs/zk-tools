# Server G2 all-window bucket experiment

Question: does an immutable shifted base table permit one shared bucket reduction
that beats the existing complete G2 query? Earlier shift64 trials retained quarter
reductions and regressed; fixed-odd trials retained many scalar multiplications.
This prototype instead routes all signed radix4096 windows to one bucket set,
using the existing indexed reducer and weighted sum. No solver duplication.
Aeglos's Sorted source motivates this topology; no C++ code is copied.

Assumption challenged: low-memory window separation is necessary for speed on
our CPU. Observable: reduced complete-query latency/CPU despite recode/scatter
and shifted point accesses. Cheap test: exact captured primary1x2 and2x2 B2query,
independent retained Arkworks full-MSM oracle; native16/32workers,3primes/mode,
9alternatingpairedtimings perquery/worker after threeoracletests. Include scalar
clone,recoding,count,scatter,indexedreduce,negativebucketmerge,weightednormalize.
Onebinary, no parameter sweep; width12,22windows fixedbeforemeasurement.

Table payload22*128*nbytes, builder doubling+normalization peak additionally
includes one original-point-sized projectivevector plus conversion scratch per
parallel chunk. Build outside warmtimer, report walltime and all Vec capacities.
Per-call counts/starts/positions/order and inherited reducer scratch are additional.
No production budget enforcement claim: exact allocator accounting/concurrent
admission must follow a successful topology test. No production API or default
change. Preflight should reject an insufficient table allowance before allocation.

Every result matches independently calculated complete-query coordinate hash.
Separate weighted-generator edge cases cover0,1,-1,fullwidth,duplicate,inverse,
identity andwindowboundaries. Bothpreparedqueries are immutable,shared across
fourOS callers for correctness. No fullproofspeedup from component results.
Screen advancement: lowerpairedmedianand>=6/9wins onprimaryat32,latencymedian
<=1.05othercontexts; report allsamples,CPU andRSS; nogainfloor. Mixedresultmeans
inconclusive, donotrepeatunchangedtest; survives->fullSDKscreenwithbudgetedsetup.
Do notcloseC7apossibilityfromlocalnegativealone; reportmechanism bottleneck.
Preparationallowance30min,capture2min. NoAWSlaunchorpushwithoutnewauthorization.
No proofs generated; canonical56585unchanged. Goalall8CPU10xremainsunmet.
