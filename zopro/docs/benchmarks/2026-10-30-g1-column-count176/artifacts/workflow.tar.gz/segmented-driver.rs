mod inherited {
    include!("model-corrected.rs");
    include!("segmented.rs");
}
fn main() { inherited::segmented_main(); }
