use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/g1-column-count176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){let r=Path::new(R);assert!(!r.join("plan-segmented.json").exists());assert_eq!(read(r.join("corrected/result.json"))["status"],"complete");let old=read(r.join("analysis-corrected.json"));assert!(old["shapes"].as_array().unwrap().iter().all(|s|s["necessary_gate_passed"]==false));
 let mut pins:BTreeMap<String,String>=serde_json::from_value(read(r.join("pins-corrected.json"))).unwrap();for(p,h)in &pins{assert_eq!(hash(p),*h);}
 for n in["segmented-driver.rs","segmented.rs","segmented-design.md","prepare-segmented.rs","prepare-segmented","analysis-corrected.json","workflow-corrected.log","corrected/model/artifacts.json","corrected/count/stdout.log","1x2-raw-a.words","2x2-raw-a.words"]{pins.insert(r.join(n).display().to_string(),hash(r.join(n)));}
 let mut plan=read(r.join("plan-corrected.json"));plan["source_pins"]=json!(r.join("pins-segmented.json"));plan["steps"][0]["driver"]=json!(r.join("segmented-driver.rs"));plan["steps"][0]["additional_sources"]=json!([r.join("model-corrected.rs"),r.join("segmented.rs")]);plan["steps"][1]["argv"][3]=json!(r.join("segmented/model-sdk"));
 fs::write(r.join("pins-segmented.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();fs::write(r.join("plan-segmented.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();println!("Frozen bounded8point segments plus allmergecosts;cached rawinputs;no new solve/proof/timing;{}pins",pins.len());}
