use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    fs,
    path::{Path, PathBuf},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g1-column-count176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn bit(s: &[u64; 4], i: usize) -> usize {
    if i >= 256 {
        0
    } else {
        ((s[i / 64] >> (i % 64)) & 1) as usize
    }
}
fn digit(s: &[u64; 4], w: usize, width: usize) -> i16 {
    let offset = w * width;
    let value = (0..width).map(|j| bit(s, offset + j) << j).sum::<usize>();
    let carry = if offset == 0 { 0 } else { bit(s, offset - 1) };
    let negative = bit(s, offset + width - 1);
    (value as i64 + carry as i64 - ((negative << width) as i64)) as i16
}
fn summary(values: &[usize], capacity: usize) -> (usize, usize) {
    let mut sorted = values.to_vec();
    sorted.sort_unstable_by(|a, b| b.cmp(a));
    let heights = sorted
        .chunks(8)
        .map(|g| g.iter().copied().max().unwrap().saturating_sub(1))
        .collect::<Vec<_>>();
    let t = heights.iter().sum::<usize>();
    (
        t * 8,
        heights
            .iter()
            .copied()
            .max()
            .unwrap_or(0)
            .max(t.div_ceil(capacity)),
    )
}
fn main() {
    assert!(!r("review.json").exists());
    for file in ["pins.json", "pins-corrected.json", "pins-segmented.json"] {
        for (p, h) in read(r(file)).as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
    }
    for stage in ["runs", "corrected", "segmented"] {
        assert_eq!(
            read(r(format!("{stage}/result.json")))["status"],
            "complete"
        );
        let a = read(r(format!("{stage}/model/artifacts.json")));
        assert_eq!(hash(a["binary"].as_str().unwrap()), a["binary_sha256"]);
        for (p, h) in a["input_pins"].as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
    }
    assert!(fs::read_to_string(r("runs/count/stdout.log"))
        .unwrap()
        .contains("MODEL_SELF_CHECKS 73"));
    assert!(!fs::read_to_string(r("corrected/count/stdout.log"))
        .unwrap()
        .contains("MODEL_SELF_CHECKS"));
    assert!(fs::read_to_string(r("segmented/count/stdout.log"))
        .unwrap()
        .contains("NEW_SEGMENT_MODEL_CHECKS=71"));
    let original = fs::read_to_string(r("model.rs")).unwrap();
    let corrected = fs::read_to_string(r("model-corrected.rs")).unwrap();
    assert_eq!(
        original.split("fn main()").next().unwrap(),
        corrected.split("fn main()").next().unwrap()
    );
    let original = read(r("analysis.json"));
    let corrected = read(r("analysis-corrected.json"));
    let segmented = read(r("analysis-segmented.json"));
    let mut reviewed = vec![];
    for (shape, index) in [("1x2", 0usize), ("2x2", 1)] {
        let bytes = fs::read(r(format!("{shape}-raw-a.words"))).unwrap();
        assert_eq!(&bytes[..8], b"ACOLUMN1");
        let n = u64::from_le_bytes(bytes[8..16].try_into().unwrap()) as usize;
        assert_eq!(bytes.len(), 16 + 33 * n);
        let values = bytes[16..]
            .chunks_exact(33)
            .map(|b| {
                (
                    core::array::from_fn(|j| {
                        u64::from_le_bytes(b[j * 8..j * 8 + 8].try_into().unwrap())
                    }),
                    b[32] != 0,
                )
            })
            .collect::<Vec<([u64; 4], bool)>>();
        let mut corrected_rows = vec![];
        for data in [&original, &corrected] {
            let s = &data["shapes"][index];
            assert_eq!(s["shape"], shape);
            assert_eq!(s["rows"], n);
            let width = s["width"].as_u64().unwrap() as usize;
            let capacity = if width == 10 {
                10
            } else if width == 11 {
                19
            } else {
                25
            };
            for row in s["observations"].as_array().unwrap() {
                let w = row["window"].as_u64().unwrap() as usize;
                let mut counts = vec![0usize; 1 << (width - 1)];
                for (words, identity) in &values {
                    let d = digit(words, w, width);
                    if !identity && d != 0 {
                        counts[d.unsigned_abs() as usize - 1] += 1;
                    }
                }
                let n = counts.iter().sum::<usize>();
                let b = counts.iter().filter(|&&c| c > 0).count();
                let (slots, waves) = summary(&counts, capacity);
                assert_eq!(row["insertions"], n);
                assert_eq!(row["seed_points"], b);
                assert_eq!(row["nonexceptional_additions"], n - b);
                assert_eq!(row["vector_lane_slots"], slots);
                assert_eq!(row["inversion_waves"], waves);
                if width == 12 {
                    corrected_rows.push((w, counts, n, b));
                }
            }
        }
        let mut aggregate = json!({"shape":shape,"ordinary_windows":21,"insertions":0,"original_additions":0,"segments":0,"linear_additions":0,"merge_additions":0,"reference_logical_codec_fields":0,"candidate_logical_codec_fields":0,"linear_waves":0,"merge_layers":0,"ideal_dense_batches":0,"minimum_utilization":1.0,"minimum_codec_reduction":1.0});
        let mut rows = vec![];
        for (w, counts, n, b) in corrected_rows {
            let mut sizes = vec![];
            let mut merge_counts = vec![];
            for &count in &counts {
                let full = count / 8;
                let tail = count % 8;
                for _ in 0..full {
                    sizes.push(8);
                }
                if tail > 0 {
                    sizes.push(tail);
                }
                merge_counts.push(count.div_ceil(8));
            }
            let segments = sizes.len();
            let (linear_slots, waves) = summary(&sizes, 25);
            let (mut merge_adds, mut merge_slots, mut merge_layers) = (0usize, 0usize, 0usize);
            for chunk in merge_counts.chunks(256) {
                let mut c = chunk.to_vec();
                while c.iter().any(|&v| v > 1) {
                    let pairs = c.iter().map(|v| v / 2).sum::<usize>();
                    merge_adds += pairs;
                    merge_slots += pairs.div_ceil(8) * 8;
                    merge_layers += 1;
                    for v in &mut c {
                        *v = v.div_ceil(2);
                    }
                }
            }
            assert_eq!(merge_adds, segments - b);
            let linear_adds = n - segments;
            assert_eq!(linear_adds + merge_adds, n - b);
            let util = (n - b) as f64 / (linear_slots + merge_slots) as f64;
            let fields = 6 * (n - b);
            let new_fields = 2 * n + 2 * segments + 6 * merge_adds;
            assert!(fields > new_fields);
            let reduction = 1.0 - new_fields as f64 / fields as f64;
            let row = &segmented["shapes"][index]["observations"][w]["result"];
            for (k, v) in [
                ("insertions", n),
                ("occupied_original_buckets", b),
                ("segments", segments),
                ("linear_adds", linear_adds),
                ("partial_merge_adds", merge_adds),
                ("linear_vector_slots", linear_slots),
                ("merge_padded_pair_slots", merge_slots),
                ("linear_inversion_waves", waves),
                ("partial_merge_layer_calls", merge_layers),
                ("reference_logical_codec_fields", fields),
                ("candidate_logical_codec_fields", new_fields),
            ] {
                assert_eq!(row[k], v, "{shape}w{w}{k}");
            }
            assert!((row["total_utilization"].as_f64().unwrap() - util).abs() < 1e-14);
            assert_eq!(row["gate_passed"], util >= 0.98 && fields > new_fields);
            assert_eq!(row["oracle_passed"], true);
            assert!(util >= 0.98);
            for (k, v) in [
                ("insertions", n),
                ("original_additions", n - b),
                ("segments", segments),
                ("linear_additions", linear_adds),
                ("merge_additions", merge_adds),
                ("reference_logical_codec_fields", fields),
                ("candidate_logical_codec_fields", new_fields),
                ("linear_waves", waves),
                ("merge_layers", merge_layers),
                ("ideal_dense_batches", (n - b).div_ceil(200)),
            ] {
                aggregate[k] = json!(aggregate[k].as_u64().unwrap() + v as u64);
            }
            aggregate["minimum_utilization"] =
                json!(aggregate["minimum_utilization"].as_f64().unwrap().min(util));
            aggregate["minimum_codec_reduction"] = json!(aggregate["minimum_codec_reduction"]
                .as_f64()
                .unwrap()
                .min(reduction));
            rows.push(json!({"window":w,"utilization":util,"logical_codec_reduction":reduction,"column_coordinate_requested_bytes":row["column_coordinate_requested_bytes"],"partial_affine_requested_bytes":row["partial_affine_requested_bytes"],"input_index_requested_bytes":row["input_index_requested_bytes"]}));
        }
        assert_eq!(rows.len(), 21);
        assert_eq!(corrected["shapes"][index]["necessary_gate_passed"], false);
        assert_eq!(segmented["shapes"][index]["necessary_gate_passed"], true);
        aggregate["rows"] = json!(rows);
        reviewed.push(aggregate);
    }
    let m=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    for (rel, h) in m["source_files_sha256"].as_object().unwrap() {
        assert_eq!(hash(Path::new(Z).join(rel)), h.as_str().unwrap());
    }
    let ledger=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/proof-sha256-after.json"));
    assert_eq!(ledger.as_array().unwrap().len(), 27353);
    let out = json!({"passed":true,"reviewed_shapes":reviewed,"production176_unchanged":true,"inherited_column_model_checks":73,"new_segment_model_checks":71,"original_unsplit_gate":false,"segmented_count_gate":true,"native_candidate_exists":false,"study_solver_calls":4,"new_proofs":0,"verified_ledger_unchanged":27353,"scope":"Independent bit-reader/histogram/segment/wave/tree/codec accounting plus all input/source/library hashes. Fr-token oracles remain actual native model assertions, not a second independently executed field implementation. No timing/proof/solver rerun."});
    fs::write(r("review.json"), serde_json::to_vec_pretty(&out).unwrap()).unwrap();
    println!("ReviewPASS;90initial/corrected rawwindow counts+42segmented windows;source176/ledger27353unchanged;unsplitfalse/segmentedtrue");
}
