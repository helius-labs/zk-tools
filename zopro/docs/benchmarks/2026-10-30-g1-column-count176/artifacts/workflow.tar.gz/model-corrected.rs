use serde_json::{json, Value};
use std::{collections::BTreeSet, fs, path::Path};
use zopro_bn254::Fr;
use zopro_core::artifact::Artifact;
#[global_allocator]
static ALLOCATOR: zopro_core::alloc::Allocator = zopro_core::alloc::Allocator;
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/g1-column-count176";

// Copied verbatim from accepted source176; preparation verifies exact text.
#[inline(always)]
fn booth_digit(words:&[u64;4],w:usize,width:usize)->i16 {
    if w==0 {let value=words[0]&((1u64<<width)-1);return (value as i64-((value>>(width-1))<<width)as i64)as i16;}
    let offset=w*width-1;let(word,shift)=(offset/64,offset%64);
    let mut value=if word<4 {words[word]>>shift}else{0};
    if shift+width+1>64&&word<3 {value|=words[word+1]<<(64-shift);}
    value&=(1u64<<(width+1))-1;
    (((value+1)>>1)as i64-((value>>width)<<width)as i64)as i16
}

fn token(row: usize, stream: u64) -> Fr {
    let mut bytes = [0; 64];
    let mut state = row as u64 ^ stream;
    for chunk in bytes.chunks_mut(8) {
        state = state.wrapping_add(0x9e3779b97f4a7c15);
        let mut x = state;
        x = (x ^ (x >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
        x = (x ^ (x >> 27)).wrapping_mul(0x94d049bb133111eb);
        chunk.copy_from_slice(&(x ^ (x >> 31)).to_le_bytes());
    }
    Fr::from_random_bytes(&bytes)
}

fn signed(value: Fr, negative: bool) -> Fr {
    if negative { -value } else { value }
}

struct Columns {
    buckets: Vec<Vec<(usize, bool)>>,
    order: Vec<usize>,
    heights: Vec<usize>,
    waves: Vec<Vec<usize>>,
    adds: usize,
    slots: usize,
    seeds: usize,
}
impl Columns {
    fn new(digits: &[i16], identities: &[bool], buckets: usize, capacity: usize) -> Self {
        assert_eq!(digits.len(), identities.len());
        assert!(capacity > 0);
        let mut lists = vec![vec![]; buckets];
        for (row, (&digit, &identity)) in digits.iter().zip(identities).enumerate() {
            if digit != 0 && !identity {
                let b = digit.unsigned_abs() as usize - 1;
                assert!(b < buckets);
                lists[b].push((row, digit < 0));
            }
        }
        let mut order = (0..buckets).collect::<Vec<_>>();
        order.sort_unstable_by_key(|&b| (std::cmp::Reverse(lists[b].len()), b));
        let heights = order.chunks(8).map(|g| g.iter().map(|&b| lists[b].len().saturating_sub(1)).max().unwrap_or(0)).collect::<Vec<_>>();
        let updates = heights.iter().sum::<usize>();
        let wave_count = heights.iter().copied().max().unwrap_or(0).max(updates.div_ceil(capacity));
        let mut waves = vec![vec![]; wave_count];
        let mut cursor = 0;
        for (group, &height) in heights.iter().enumerate() {
            assert!(height <= wave_count);
            for _ in 0..height {
                waves[cursor % wave_count].push(group);
                cursor += 1;
            }
        }
        assert_eq!(cursor, updates);
        for wave in &waves {
            assert!(wave.len() <= capacity);
            assert_eq!(wave.iter().copied().collect::<BTreeSet<_>>().len(), wave.len());
        }
        let seeds = lists.iter().filter(|v| !v.is_empty()).count();
        let adds = lists.iter().map(|v|v.len().saturating_sub(1)).sum::<usize>();
        let slots = updates * 8;
        assert!(slots >= adds);
        Self { buckets: lists, order, heights, waves, adds, slots, seeds }
    }

    fn check(&self, digits: &[i16], identities: &[bool], stream: u64) -> Fr {
        let tokens = (0..digits.len()).map(|row|token(row,stream)).collect::<Vec<_>>();
        let mut expected = vec![Fr::ZERO; self.buckets.len()];
        let mut direct_weighted = Fr::ZERO;
        for (row, (&d, &identity)) in digits.iter().zip(identities).enumerate() {
            if d==0 || identity {continue;}
            expected[d.unsigned_abs() as usize-1] += signed(tokens[row],d<0);
            direct_weighted += signed(tokens[row]*Fr::from(d.unsigned_abs() as u64),d<0);
        }
        let mut actual = vec![Fr::ZERO; self.buckets.len()];
        let mut positions = vec![0; self.buckets.len()];
        let mut seen = vec![0u8;digits.len()];
        for (b, list) in self.buckets.iter().enumerate() {
            if let Some(&(row,negative)) = list.first() { actual[b]=signed(tokens[row],negative);positions[b]=1;seen[row]+=1; }
        }
        let mut occurrences = vec![0; self.heights.len()];
        for wave in &self.waves {
            for &group in wave {
                occurrences[group]+=1;
                let mut live=0;
                for &b in &self.order[group*8..((group+1)*8).min(self.order.len())] {
                    if let Some(&(row,negative)) = self.buckets[b].get(positions[b]) {
                        actual[b]+=signed(tokens[row],negative);positions[b]+=1;seen[row]+=1;live+=1;
                    }
                }
                assert!(live>0&&live<=8);
            }
        }
        assert_eq!(occurrences,self.heights);assert_eq!(actual,expected);
        for b in 0..self.buckets.len(){assert_eq!(positions[b],self.buckets[b].len());}
        for row in 0..digits.len(){assert_eq!(seen[row],u8::from(digits[row]!=0&&!identities[row]));}
        let weighted=actual.iter().enumerate().fold(Fr::ZERO,|s,(b,v)|s+*v*Fr::from((b+1)as u64));
        assert_eq!(weighted,direct_weighted);
        weighted
    }

    fn stats(&self, input_len:usize, width:usize, window:usize, batch:usize)->Value {
        let updates = self.slots/8;
        let insertion_count=self.adds+self.seeds;
        let reference_dense_batches=self.adds.div_ceil(batch);
        let reference_import_fields=4*self.adds+2*self.seeds;
        let reference_export_fields=2*self.adds;
        let column_import_fields=2*insertion_count;
        let column_export_fields=2*self.seeds;
        let b=self.buckets.len();let w=self.waves.len();
        json!({"window":window,"width":width,"input_rows":input_len,"bucket_capacity":b,"insertions":insertion_count,"seed_points":self.seeds,"nonexceptional_additions":self.adds,"vector_cohort_updates":updates,"vector_lane_slots":self.slots,"lane_utilization":if self.slots==0{1.0}else{self.adds as f64/self.slots as f64},"inversion_waves":w,"max_cohorts_per_wave":self.waves.iter().map(Vec::len).max().unwrap_or(0),"ideal_dense_reference_batches":reference_dense_batches,"wave_over_ideal_dense":if reference_dense_batches==0{1.0}else{w as f64/reference_dense_batches as f64},"reference_import_scalar_fields":reference_import_fields,"reference_export_scalar_fields":reference_export_fields,"column_import_scalar_fields":column_import_fields,"column_export_scalar_fields":column_export_fields,"host_codec_fields_saved":reference_import_fields+reference_export_fields-column_import_fields-column_export_fields,"column_coordinate_payload_bytes":b.div_ceil(8)*2*5*64,"ordinary_coordinate_payload_bytes":b*64,"input_index_payload_bytes":4*insertion_count,"starts_and_scatter_cursor_payload_bytes":8*(2*b+1),"bucket_permutation_payload_bytes":2*b,"wave_group_id_payload_bytes":2*updates,"wave_offset_payload_bytes":8*(w+1),"three_field_record_payload_bytes":3*5*64*(batch/8),"in_lane_canonicalization_charged":false,"actual_point_exceptions_modeled":false})
    }
}

fn checks() {
    let patterns = [vec![],vec![0;19],vec![1],vec![-1,1,-1,1],(0..29).map(|i|(i%7+1)as i16*if i%3==0{-1}else{1}).collect(),(0..257).map(|i|if i<200{1}else{(i%16+1)as i16}).collect(),(0..511).map(|i|(i%17+1)as i16).collect()];
    let mut cases=0;
    for digits in patterns {for cap in [1,2,3,25]{for style in 0..2{
        let identities=(0..digits.len()).map(|i|style==1&&i%5==0).collect::<Vec<_>>();
        let c=Columns::new(&digits,&identities,32,cap);c.check(&digits,&identities,0x42);c.check(&digits,&identities,0x819abc);cases+=1;
    }}}
    // Every possible final SIMD cohort length and a circular wave wrap.
    for n in 1..=17 {let digits=(0..n).flat_map(|i|std::iter::repeat_n((i+1)as i16,i%7+1)).collect::<Vec<_>>();let identities=vec![false;digits.len()];let c=Columns::new(&digits,&identities,n,3);c.check(&digits,&identities,0x91);cases+=1;}
    println!("MODEL_SELF_CHECKS {cases}");
}

fn width(n:usize)->usize{
    let work=|c:usize|(n+(2usize<<c))*255usize.div_ceil(c);
    let least=(4..=15).map(work).min().unwrap();
    (4..=15).filter(|&c|work(c)<=least+least*15/100).min_by_key(|&c|(255usize.div_ceil(c).div_ceil(32),work(c))).unwrap()
}
fn main(){
    assert_eq!(rayon::current_num_threads(),32);
    // Exact model/self-check bodies inherited from the completed initial run.
    assert_eq!(std::env::var("ZOPRO_CPU_DEFER_SIGNED_Y").unwrap(), "1");
    assert_eq!(std::env::var("ZOPRO_CPU_DEFER_SIGN_PARTS").unwrap(), "1");
    let cases:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zopro-perf-work/g2-queue-scan-count175/cases.json").unwrap()).unwrap();
    let mut results=vec![];
    for case in cases.as_array().unwrap().iter().take(2){
        let bytes=fs::read(case["key"].as_str().unwrap()).unwrap();let request=fs::read_to_string(case["request"].as_str().unwrap()).unwrap();
        let sdk=zopro_zolana::Prover::load(&bytes).unwrap();let witness=sdk.witness(&request).unwrap();let image=sdk.solver_image().unwrap();drop(sdk);
        let artifact=Artifact::parse(&bytes).unwrap();let key=artifact.key(artifact.points(),Some(&image)).unwrap();
        let witness=witness.iter().flat_map(|v|v.0.iter().flat_map(|w|w.to_le_bytes())).collect::<Vec<_>>();
        let [scalars,_,_]=key.msm_scalars(&witness).unwrap();drop(key);
        let points=zopro_core::decompress_g1(artifact.a).unwrap();assert_eq!(points.len(),64*scalars.len());
        let identities=points.chunks_exact(64).map(|p|p.iter().all(|&v|v==0)).collect::<Vec<_>>();
        let words=scalars.iter().map(Fr::to_canonical).collect::<Vec<_>>();
        assert!((1024..65536).contains(&words.len()));
        let bits=std::env::var("ZOPRO_CPU_DEFER_SIGN_WIDTH").unwrap().parse::<usize>().unwrap();assert_eq!(bits,12);
        let windows=255usize.div_ceil(bits);
        let cache=Path::new(ROOT).join(format!("{}-raw-a.words",case["shape"].as_str().unwrap()));assert!(!cache.exists());
        let mut payload=b"ACOLUMN1".to_vec();payload.extend_from_slice(&(words.len()as u64).to_le_bytes());
        for(row,s)in words.iter().enumerate(){for word in s{payload.extend_from_slice(&word.to_le_bytes());}payload.push(u8::from(identities[row]));}fs::write(cache,payload).unwrap();
        let batch=match bits{0..=9=>0,10=>80,11=>152,12=>200,13=>352,14=>400,_=>504};assert!(batch>0);
        let mut observations=vec![];
        let mut rec=vec![Fr::ZERO;scalars.len()];let mut power=Fr::ONE;let radix=Fr::from(1u64<<bits);
        let mut full_weighted=[Fr::ZERO;2];
        for w in 0..windows{
            let digits=words.iter().map(|s|booth_digit(s,w,bits)).collect::<Vec<_>>();
            for i in 0..digits.len(){rec[i]+=signed(power*Fr::from(digits[i].unsigned_abs()as u64),digits[i]<0);}
            let indexed_top=w+1==windows&&254-w*bits<=8;
            if indexed_top {
                for(stream,seed)in[0x42,0x819abc].iter().enumerate(){full_weighted[stream]+=power*digits.iter().enumerate().filter(|(i,_)|!identities[*i]).fold(Fr::ZERO,|a,(i,d)|a+signed(token(i,*seed)*Fr::from(d.unsigned_abs()as u64),*d<0));}
            }else{
                let column=Columns::new(&digits,&identities,1<<(bits-1),batch/8);
                for(stream,seed)in[0x42,0x819abc].iter().enumerate(){full_weighted[stream]+=power*column.check(&digits,&identities,*seed);}
                observations.push(column.stats(words.len(),bits,w,batch));
            }
            power*=radix;
        }
        assert_eq!(rec,scalars);
        for(stream,seed)in[0x42,0x819abc].iter().enumerate(){let direct=scalars.iter().enumerate().filter(|(i,_)|!identities[*i]).fold(Fr::ZERO,|a,(i,s)|a+*s*token(i,*seed));assert_eq!(full_weighted[stream],direct);}
        let pass=observations.iter().all(|o|o["lane_utilization"].as_f64().unwrap()>=0.98&&o["host_codec_fields_saved"].as_u64().unwrap()>0);
        println!("RAW_A_COUNT shape={}rows={}width={}ordinarywindows={}necessary_gate={pass}",case["shape"],words.len(),bits,observations.len());
        results.push(json!({"shape":case["shape"],"query":"A raw pre-group inputs","rows":words.len(),"identity_inputs":identities.iter().filter(|&&x|x).count(),"width":bits,"windows":windows,"indexed_top_unchanged":windows-observations.len(),"necessary_gate_passed":pass,"token_streams":2,"all_bucket_and_full_weighted_oracles_passed":true,"observations":observations}));
    }
    let output=json!({"shapes":results,"native_candidate_exists":false,"new_proofs":0,"new_solver_calls":2,"new_SDK_requests":0,"scope":"Raw pre-group A input metadata/token model. No curve arithmetic candidate, latency, actual current operation census or RAM result."});
    let path=Path::new(ROOT).join("analysis-corrected.json");assert!(!path.exists());fs::write(path,serde_json::to_vec_pretty(&output).unwrap()).unwrap();
}
