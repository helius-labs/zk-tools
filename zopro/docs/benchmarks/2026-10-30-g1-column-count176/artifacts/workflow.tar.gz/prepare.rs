use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/g1-column-count176";
const P:&str="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){let r=Path::new(R);assert!(!r.join("plan.json").exists());let mut pins=BTreeMap::new();
 let mut pin=|p:PathBuf|{pins.insert(p.display().to_string(),hash(&p));};
 let manifest=Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");
 let m=read(&manifest);for(rel,h)in m["source_files_sha256"].as_object().unwrap(){let p=Path::new(Z).join(rel);assert_eq!(hash(&p),h.as_str().unwrap());assert_eq!(hash(Path::new(P).join("source").join(rel)),h.as_str().unwrap());pin(p);}pin(manifest);
 let model=fs::read_to_string(r.join("model.rs")).unwrap();let s=fs::read_to_string(Path::new(Z).join("crates/zopro-core/src/msm_affine.rs")).unwrap();let start=s.find("fn booth_digit(").unwrap();let mut level=0i64;let mut end=None;for(i,ch)in s[start..].char_indices(){if ch=='{'{level+=1;}if ch=='}'{level-=1;if level==0{end=Some(start+i+1);break;}}}let f=&s[start..end.unwrap()];assert!(model.contains(f),"accepted Booth reader exact");
 let frozen=read(Path::new(P).join("frozen-candidate.json"));for(p,h)in frozen["input_pins"].as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pin(p.into());}
 let a=Path::new(P).join("frozen-candidate-cargo.jsonl");pin(a.clone());
 let cases_path=Path::new("/home/ubuntu/src/zopro-perf-work/g2-queue-scan-count175/cases.json");let cases=read(cases_path);pin(cases_path.into());
 for c in cases.as_array().unwrap().iter().take(2){for key in["key","image","request"]{let p=PathBuf::from(c[key].as_str().unwrap());if key!="request"{assert_eq!(hash(&p),c[format!("{key}_sha256")]);}pin(p);}}
 for n in["model.rs","design.md","prepare.rs","prepare"]{pin(r.join(n));}
 let mut env=read(Path::new(P).join("build-plan.json"))["steps"][0]["environment"].clone();for key in["RUSTFLAGS","CARGO_TARGET_DIR","CARGO_BUILD_JOBS"]{env.as_object_mut().unwrap().remove(key);}env["RAYON_NUM_THREADS"]=json!("32");
 let steps=json!([{"kind":"link-sdk","name":"model","driver":r.join("model.rs"),"artifacts":a,"timeout_seconds":600},{"kind":"command","name":"count","argv":["taskset","-c","0-31",r.join("runs/model-sdk")],"environment":env,"timeout_seconds":600}]);
 fs::write(r.join("pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();fs::write(r.join("plan.json"),serde_json::to_vec_pretty(&json!({"version":1,"source_pins":r.join("pins.json"),"steps":steps})).unwrap()).unwrap();println!("Frozen accepted176/libraries/two rawA inputs/Booth reader and model;no prover rebuild/proof/latency;{}pins",pins.len());}
