use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/g1-column-count176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){let r=Path::new(R);assert!(!r.join("plan-corrected.json").exists());assert_eq!(read(r.join("runs/result.json"))["status"],"complete");
 let mut pins:BTreeMap<String,String>=serde_json::from_value(read(r.join("pins.json"))).unwrap();for(p,h)in &pins{assert_eq!(hash(p),*h);}
 let initial=fs::read_to_string(r.join("model.rs")).unwrap();let corrected=fs::read_to_string(r.join("model-corrected.rs")).unwrap();assert_eq!(initial.split("fn main()").next().unwrap(),corrected.split("fn main()").next().unwrap());
 for n in["model-corrected.rs","correction.md","prepare-corrected.rs","prepare-corrected","analysis.json","workflow.log","runs/model/artifacts.json","runs/count/stdout.log"]{pins.insert(r.join(n).display().to_string(),hash(r.join(n)));}
 let mut plan=read(r.join("plan.json"));plan["source_pins"]=json!(r.join("pins-corrected.json"));plan["steps"][0]["driver"]=json!(r.join("model-corrected.rs"));plan["steps"][1]["argv"][3]=json!(r.join("corrected/model-sdk"));
 fs::write(r.join("pins-corrected.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();fs::write(r.join("plan-corrected.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();println!("Corrected entry geometry12/parts1;model+73self-check bodies exact;original run preserved;{}pins",pins.len());}
