fn segments(digits:&[i16],identities:&[bool],bucket_count:usize,stream:u64)->Value {
    let mut original=vec![vec![];bucket_count];
    for(i,(&d,&identity))in digits.iter().zip(identities).enumerate(){if d!=0&&!identity{original[d.unsigned_abs()as usize-1].push((i,d<0));}}
    let mut partial_map=vec![];let mut expanded=vec![0i16;digits.len()];let mut starts=vec![0usize];
    for(b,rows)in original.iter().enumerate(){for chunk in rows.chunks(8){let partial=partial_map.len();assert!(partial<i16::MAX as usize);partial_map.push(b);for &(i,negative)in chunk{expanded[i]=(partial as i16+1)*if negative{-1}else{1};}}starts.push(partial_map.len());}
    let column=Columns::new(&expanded,identities,partial_map.len(),25);
    column.check(&expanded,identities,stream);
    assert!(column.heights.iter().all(|&h|h<=7));
    let mut sums=vec![vec![];bucket_count];
    for(s,rows)in column.buckets.iter().enumerate(){assert!(!rows.is_empty()&&rows.len()<=8);let t=rows.iter().fold(Fr::ZERO,|a,&(i,n)|a+signed(token(i,stream),n));sums[partial_map[s]].push(t);}
    let mut merge_adds=0usize;let mut merge_slots=0usize;let mut merge_layers=0usize;let mut per_group=vec![];
    for group in sums.chunks_mut(256){let mut layers=vec![];while group.iter().any(|b|b.len()>1){let pairs=group.iter().map(|b|b.len()/2).sum::<usize>();let slots=pairs.div_ceil(8)*8;merge_adds+=pairs;merge_slots+=slots;merge_layers+=1;layers.push(json!({"pairs":pairs,"padded_pair_slots":slots}));for b in group.iter_mut(){let old=std::mem::take(b);*b=old.chunks(2).map(|c|if c.len()==2{c[0]+c[1]}else{c[0]}).collect();}}per_group.push(layers);}
    let mut weighted=Fr::ZERO;let mut direct=Fr::ZERO;
    for b in 0..bucket_count{let expected=original[b].iter().fold(Fr::ZERO,|a,&(i,n)|a+signed(token(i,stream),n));let got=sums[b].first().copied().unwrap_or(Fr::ZERO);assert_eq!(got,expected);weighted+=got*Fr::from((b+1)as u64);for &(i,n)in &original[b]{direct+=signed(token(i,stream)*Fr::from((b+1)as u64),n);}}
    assert_eq!(weighted,direct);
    let n=original.iter().map(Vec::len).sum::<usize>();let b=original.iter().filter(|x|!x.is_empty()).count();let s=partial_map.len();
    assert_eq!(column.seeds,s);assert_eq!(column.adds,n-s);assert_eq!(merge_adds,s-b);assert_eq!(column.adds+merge_adds,n-b);
    let slots=column.slots+merge_slots;let utilization=if slots==0{1.0}else{(n-b)as f64/slots as f64};
    let reference_fields=6*(n-b);let candidate_fields=2*n+2*s+6*merge_adds;let saved=reference_fields as i64-candidate_fields as i64;
    json!({"insertions":n,"occupied_original_buckets":b,"segments":s,"segment_points_max":8,"linear_adds":column.adds,"partial_merge_adds":merge_adds,"original_nonexceptional_adds":n-b,"linear_vector_slots":column.slots,"merge_padded_pair_slots":merge_slots,"total_utilization":utilization,"linear_inversion_waves":column.waves.len(),"partial_merge_layer_calls":merge_layers,"ideal_dense_reference_batches":(n-b).div_ceil(200),"reference_logical_codec_fields":reference_fields,"candidate_logical_codec_fields":candidate_fields,"logical_codec_fields_saved":saved,"logical_codec_reduction":if reference_fields==0{0.0}else{saved as f64/reference_fields as f64},"column_coordinate_requested_bytes":s.div_ceil(8)*2*5*64,"partial_affine_requested_bytes":64*s,"input_index_requested_bytes":4*n,"partial_to_bucket_requested_bytes":2*s,"bucket_offsets_requested_bytes":8*(bucket_count+1),"cohort_order_requested_bytes":2*s,"wave_group_ids_requested_bytes":2*(column.slots/8),"wave_offsets_requested_bytes":8*(column.waves.len()+1),"three_field_record_requested_bytes":3*5*64*25,"per_original_group_merge_layers":per_group,"gate_passed":utilization>=0.98&&saved>0,"oracle_passed":true})
}

pub fn segmented_main(){
    assert_eq!(rayon::current_num_threads(),32);
    let mut checks=0;
    for n in 0..=65{let digits=(0..n).map(|i|if i%13==0{0}else{((i%17+1)as i16)*if i%3==0{-1}else{1}}).collect::<Vec<_>>();let ids=(0..n).map(|i|i%19==0).collect::<Vec<_>>();segments(&digits,&ids,32,0x42);checks+=1;}
    for n in [127usize,128,129,1023,4097]{let digits=(0..n).map(|i|if i%11==0{-2}else{1}).collect::<Vec<_>>();segments(&digits,&vec![false;n],32,0x819abc);checks+=1;}
    println!("NEW_SEGMENT_MODEL_CHECKS={checks};73originalcolumnchecks inherited");
    let mut shapes=vec![];
    for shape in["1x2","2x2"]{
        let path=Path::new(ROOT).join(format!("{shape}-raw-a.words"));let bytes=fs::read(path).unwrap();assert_eq!(&bytes[..8],b"ACOLUMN1");let n=u64::from_le_bytes(bytes[8..16].try_into().unwrap())as usize;assert_eq!(bytes.len(),16+33*n);
        let mut words=Vec::with_capacity(n);let mut identities=Vec::with_capacity(n);
        for row in bytes[16..].chunks_exact(33){let limbs=core::array::from_fn(|i|u64::from_le_bytes(row[i*8..i*8+8].try_into().unwrap()));assert!(Fr::from_canonical(limbs).is_some());words.push(limbs);assert!(row[32]<=1);identities.push(row[32]!=0);}
        let mut observations=vec![];
        for w in 0..21{let digits=words.iter().map(|s|booth_digit(s,w,12)).collect::<Vec<_>>();let first=segments(&digits,&identities,2048,0x42);let second=segments(&digits,&identities,2048,0x819abc);assert_eq!(first,second);observations.push(json!({"window":w,"width":12,"result":first}));}
        let gate=observations.iter().all(|o|o["result"]["gate_passed"]==true);
        println!("SEGMENTED shape={shape}rows={n}windows=21gate={gate}");
        shapes.push(json!({"shape":shape,"query":"A raw pre-group inputs","rows":n,"token_streams":2,"ordinary_windows":21,"indexed_top_unchanged":true,"necessary_gate_passed":gate,"observations":observations}));
    }
    let out=json!({"shapes":shapes,"new_model_checks":checks,"inherited_column_checks":73,"new_solver_calls":0,"new_proofs":0,"native_candidate_exists":false,"scope":"Segmented-column metadata and Fr-token model including partial merges. No native curve candidate, latency or RAM result."});
    let path=Path::new(ROOT).join("analysis-segmented.json");assert!(!path.exists());fs::write(path,serde_json::to_vec_pretty(&out).unwrap()).unwrap();
}
