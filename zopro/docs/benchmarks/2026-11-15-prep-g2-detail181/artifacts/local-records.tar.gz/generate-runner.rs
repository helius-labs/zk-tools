use std::fs;
const R:&str="/home/ubuntu/src/zopro-perf-work/prep-g2-detail181";
fn one(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1);}
fn main(){
 let mut s=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/msm-local180/local.rs").unwrap().replace("/home/ubuntu/src/zopro-perf-work/msm-local180",R);
 one(&mut s,"const I: &str = \"/home/ubuntu/src/zopro-perf-work/msm-full180\";",&format!("const I: &str = \"{R}/inputs\";"));
 s=s.replace("f40afdcc062125e33e69e523708915956f1aa21bfc25b2dfd2604e81d28e0446","5aa3b76fe67d3cc541636a7c94fa8eef7459b91a1cc7840d5330c901ddef0a4a").replace("proof-sha256-after-preflight.json","seed.json");
 s=s.replace("{ 1 } else { 51 }","{ 1 } else { 31 }");
 one(&mut s,"        j[\"panel\"] = json!(panel);","        j[\"panel\"] = json!(panel);\n        let binary=format!(\"{R}/bins/{}{}\",if arm==\"REF\" {\"ref\"} else {\"diag\"},block%3);\n        j[\"binary\"]=json!(binary);j[\"backing\"]=json!(block%3);j[\"binary_sha256\"]=json!(hash(&binary));");
 one(&mut s,"        step[\"name\"] = json!(name);","        step[\"name\"] = json!(name);\n        step[\"argv\"][3]=json!(binary);");
 let a=s.find("    for w in [16, 32] {").unwrap();let b=a+s[a..].find("    for block in 0..9 {").unwrap();s.replace_range(a..b,"    for arm in [\"OFF\",\"ON\"] {add(4,0,\"preflight\",\"zopro\",arm);}\n");
 s=s.replace("[\"zopro\", \"sorted\", \"windowed\"]","[\"zopro\"]").replace("modes.rotate_left(block % 3)","modes.rotate_left(0)");
 s=s.replace("assert_eq!(jobs.len(), 220)","assert_eq!(jobs.len(), 56)").replace("        10780\n","        1844\n");
 s=s.replace("{R}/local","{R}/runner").replace("{R}/make-validator.rs","{R}/generate-runner.rs").replace("{R}/protocol.md","{R}/design.md");
 s=s.replace("assert_eq!(ledger.len(), 55220)","assert_eq!(ledger.len(), 55664)").replace("assert_eq!(ledger.len(), 55440)","assert_eq!(ledger.len(), 55720)").replace("assert_eq!(rows.len(), 198)","assert_eq!(rows.len(), 54)");
 one(&mut s,"if !z || ![\"A\", \"KH\", \"G2\"].contains(&phase)","if [\"solve\",\"prepare\",\"fft\",\"queries\",\"output\"].contains(&phase)");
 one(&mut s,"            if z {\n                let rr", "            if z {\n                detail_metrics(p,&mut sums);\n                let rr");
 one(&mut s,"            / 51.;","            / 31.;");
 one(&mut s,"                gates.push(json!({\"mode\":mode", "                for backing in 0..3 {let values=raw.iter().enumerate().filter(|(b,_)|b%3==backing).map(|(_,v)|*v).collect::<Vec<_>>();let m=median(&values);gates.push(json!({\"kind\":\"backing\",\"workers\":w,\"ratio\":format!(\"{num}/{den}\"),\"backing\":backing,\"median\":m,\"passed\":(0.95..=1.05).contains(&m)}));}\n                gates.push(json!({\"kind\":\"interval\",\"mode\":mode");
 s=s.replace("\"sdk_calls\":10780,\"exports\":220,\"canonical_count\":55440","\"sdk_calls\":1844,\"exports\":56,\"canonical_count\":55720");
 s=s.replace("Frozen220 processes10780SDKcalls; canonical55220->55440; no capture yet","Frozen56 processes1844SDKcalls; canonical55664->55720; no capture yet").replace("COMPLETE220 verified exports; canonical55440; interpret individual diagnostic gates","COMPLETE56 verified exports; canonical55720; inspect16 calibration/backing gates");
 s.push_str(r#"
fn detail_metrics(p:&Value,s:&mut BTreeMap<String,f64>){
 let rows=p["rows"].as_array().unwrap();let b=|i:usize|rows[i]["begin_ns"].as_u64().unwrap();let e=|i:usize|rows[i]["end_ns"].as_u64().unwrap();
 let last_g1=e(4).max(e(5));let last_window=(19..30).map(e).max().unwrap();let last_part=(30..52).map(e).max().unwrap();
 s.insert("g2_late_callback".into(),e(6).saturating_sub(last_g1) as f64/1e6);
 s.insert("g2_collection_after_last_window".into(),(e(17)-last_window)as f64/1e6);
 s.insert("g2_collection_after_last_part".into(),(e(17)-last_part)as f64/1e6);
 s.insert("g2_late_collection_return_gap".into(),e(17).saturating_sub(last_window.max(last_g1))as f64/1e6);
 s.insert("g2_window_late_work_span".into(),last_window.saturating_sub(last_g1)as f64/1e6);
 s.insert("gather_span".into(),(e(12).max(e(13))-b(12).min(b(13)))as f64/1e6);
 let late_window=(19..30).max_by_key(|&i|e(i)).unwrap();s.insert("last_window_index".into(),(late_window-19)as f64);
 let measured_prep=(8..12).map(|i|e(i)-b(i)).sum::<u64>()+e(12).max(e(13))-b(12).min(b(13));
 s.insert("prepare_unassigned".into(),((e(1)-b(1)).checked_sub(measured_prep).unwrap())as f64/1e6);
}
"#);
 fs::write(format!("{R}/runner.rs"),s).unwrap();
 let mut v=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/msm-local180/validate.rs").unwrap();
 one(&mut v,"                names,","                &names[..8],");
 one(&mut v,"            for row in rows {\n                assert_eq!(row[\"state\"], 2);\n            }","            assert_eq!(phase[\"version\"],2);assert_eq!(rows.len(),74);\n            for(i,row)in rows.iter().enumerate(){if i==15 {assert!([0,2].contains(&row[\"state\"].as_u64().unwrap()));}else{assert_eq!(row[\"state\"],2);}}\n            detail_validate(rows);");
 v.push_str(r#"
fn detail_validate(rows:&[Value]) {
 let b=|i:usize|rows[i]["begin_ns"].as_u64().unwrap();let e=|i:usize|rows[i]["end_ns"].as_u64().unwrap();
 let within=|i:usize,p:usize|assert!(b(p)<=b(i)&&e(i)<=e(p),"child {i},parent{p}");
 let names=["reclaim","drop_c","public_correction","canonical_w","gather_a","gather_b","g2_group_scalars","g2_group_points","g2_split","g2_collect","g2_combine"];
 for(i,n)in names.iter().enumerate(){assert_eq!(rows[i+8]["phase"],*n);}
 for i in 8..14 {within(i,1);}
 for(i,j)in [(8,9),(9,10),(10,11),(11,12),(11,13)]{assert!(e(i)<=b(j));}
 for i in 14..19{if rows[i]["state"]==2 {within(i,6);}}
 assert!(e(14)<=b(16));if rows[15]["state"]==2 {assert!(e(14)<=b(15)&&e(15)<=b(16));}
 assert!(e(16)<=b(17)&&e(17)<=b(18));
 for w in 0..11 {let wi=19+w;within(wi,17);assert_eq!(rows[wi]["phase"],format!("g2_window_{w}"));
 for part in 0..2 {let pi=30+2*w+part;assert_eq!(rows[pi]["phase"],format!("g2_part_{w}_{part}"));within(pi,wi);assert!(e(pi)<=b(63+w));}
 assert_eq!(rows[52+w]["phase"],format!("g2_weight_{w}"));assert_eq!(rows[63+w]["phase"],format!("g2_merge_{w}"));
 within(52+w,wi);within(63+w,wi);assert!(e(63+w)<=b(52+w));}
}
"#);
 fs::write(format!("{R}/validate.rs"),v).unwrap();
}
