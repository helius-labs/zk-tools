use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::Path,
    process::Command,
};
mod validate;
const R: &str = "/output/prep-g2-c7a181";
const I: &str = "/cr-detail";
const SEED: &str = "810baa30d05dcad89de5c6af5ceda9ce7ca9090807e25103b3f62240389891e5";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(n: &str, v: Value) {
    let p = format!("{R}/{n}");
    assert!(!Path::new(&p).exists(), "already exists: {p}");
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn mean(v: &[f64]) -> f64 {
    assert!(!v.is_empty());
    assert!(v.iter().all(|v| v.is_finite()));
    v.iter().sum::<f64>() / v.len() as f64
}
fn median(v: &[f64]) -> f64 {
    let mut v = v.to_vec();
    v.sort_by(f64::total_cmp);
    v[v.len() / 2]
}
fn state() -> Value {
    let mut m = BTreeMap::new();
    for p in [
        "/proc/loadavg",
        "/proc/meminfo",
        "/proc/swaps",
        "/proc/vmstat",
        "/proc/stat",
        "/proc/pressure/cpu",
        "/proc/pressure/memory",
        "/proc/pressure/io",
        "/proc/self/cgroup",
        "/sys/fs/cgroup/cpu.max","/sys/fs/cgroup/cpu.stat","/sys/fs/cgroup/memory.max","/sys/fs/cgroup/memory.events","/sys/fs/cgroup/memory.swap.max","/sys/fs/cgroup/memory.swap.events","/sys/fs/cgroup/memory.peak",
    ] {
        if let Ok(s) = fs::read_to_string(p) {
            m.insert(p, s);
        }
    }
    json!(m)
}
fn verify_pins() {
    for (p, h) in read(format!("{R}/pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap(), "{p}");
    }
}
fn prepare(smoke:bool) {
    save("mode.json",json!({"smoke":smoke}));
    assert_eq!(hash(format!("{I}/seed.json")), SEED);
    let original = read(format!("{I}/preflight-jobs.json"));
    let plan = read(format!("{I}/preflight-plan.json"));
    let mut pins = read(format!("{I}/preflight-pins.json"))
        .as_object()
        .unwrap()
        .clone();
    for (p, h) in &pins {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let mut jobs = vec![];
    let mut steps = vec![];
    let mut late = vec![];
    let mut add = |workers: usize, block: usize, panel: &str, mode: &str, arm: &str| {
        let base_name = format!("{mode}-{arm}");
        let orig = original
            .as_array()
            .unwrap()
            .iter()
            .find(|j| j["name"] == base_name)
            .unwrap();
        let mut j = orig.clone();
        let name = format!("{panel}-w{workers}-{base_name}-b{block:02}");
        let dir = format!("{R}/proofs/{name}/transfer_confidential_1_2");
        let rounds = if panel == "preflight" { 1 } else { 31 };
        j["name"] = json!(name);
        j["proof_dir"] = json!(dir);
        j["workers"] = json!(workers);
        j["rounds"] = json!(rounds);
        j["block"] = json!(block);
        j["panel"] = json!(panel);
        let binary=format!("{R}/bins/{}{}",if arm=="REF" {"ref"} else {"diag"},block%3);
        j["binary"]=json!(binary);j["backing"]=json!(block%3);j["binary_sha256"]=json!(hash(&binary));
        let mut step = plan["steps"]
            .as_array()
            .unwrap()
            .iter()
            .find(|s| s["name"] == base_name)
            .unwrap()
            .clone();
        step["name"] = json!(name);
        step["argv"][3]=json!(binary);
        step["argv"][2] = json!(format!("0-{}", workers - 1));
        step["environment"]["RAYON_NUM_THREADS"] = json!(workers.to_string());
        if mode == "zopro" {
            step["argv"][6] = json!(rounds.to_string());
            step["argv"][7] = json!(dir);
        } else {
            step["argv"][7] = json!(rounds.to_string());
            step["environment"]["AEGLOS_CPU_THREADS"] = json!(workers.to_string());
            step["environment"]["GOMAXPROCS"] = json!(workers.to_string());
            step["environment"]["ZOPRO_BENCH_PROOFS"] = json!(format!("{R}/proofs/{name}"));
        }
        let mut verify = plan["steps"]
            .as_array()
            .unwrap()
            .iter()
            .find(|s| s["name"] == format!("verify-{base_name}"))
            .unwrap()
            .clone();
        verify["name"] = json!(format!("verify-{name}"));
        verify["argv"][3] = json!(format!("{dir}/0.proof"));
        verify["argv"][4] = json!(format!("{dir}/0.public"));
        let inspect = json!({"kind":"command","name":format!("inspect-{name}"),"argv":["/usr/local/bin/detail-runner".to_owned(),"inspect",name],"timeout_seconds":60});
        jobs.push(j);
        steps.push(step);
        if panel == "preflight" {
            steps.extend([verify, inspect]);
        } else {
            late.extend([verify, inspect]);
        }
    };
    for arm in ["OFF","ON"] {add(4,0,"preflight","zopro",arm);}
    for block in 0..if smoke {0}else{9} {
        let mut counts = [32, 96];
        if block % 2 == 1 {
            counts.reverse();
        }
        let mut modes = ["zopro"];
        modes.rotate_left(0);
        if block % 2 == 1 {
            modes.reverse();
        }
        for mode in modes {
            let mut arms = if mode == "zopro" {
                vec!["REF", "OFF", "ON"]
            } else {
                vec!["REF", "FRESH", "OFF", "ON"]
            };
            let n = arms.len();
            arms.rotate_left(block % n);
            if block % 2 == 1 {
                arms.reverse();
            }
            for w in counts {
                for arm in &arms {
                    add(w, block, "main", mode, arm);
                }
            }
        }
    }
    drop(add);
    assert_eq!(jobs.len(), if smoke {2}else{56});
    assert_eq!(
        jobs.iter()
            .map(|j| j["rounds"].as_u64().unwrap() + 3)
            .sum::<u64>(),
        if smoke {8}else{1844}
    );
    steps.push(json!({"kind":"command","name":"after-capture-state","argv":["/usr/local/bin/detail-runner".to_owned(),"snapshot","after"],"timeout_seconds":60}));
    steps.extend(late);
    steps.push(json!({"kind":"command","name":"review","argv":["/usr/local/bin/detail-runner".to_owned(),"review"],"timeout_seconds":120}));
    save("jobs.json", json!(jobs));
    for p in [
        "/usr/local/bin/detail-runner".to_owned(),
        format!("{I}/runner.rs"),
        format!("{I}/validate.rs"),
        format!("{I}/generate.rs"),
        format!("{I}/protocol.md"),
        format!("{R}/jobs.json"),
        format!("{I}/seed.json"),
        format!("{I}/preflight-plan.json"),
    ] {
        pins.insert(p.clone(), json!(hash(p)));
    }
    save("pins.json", json!(pins));
    save(
        "plan.json",
        json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps}),
    );
    println!("Frozen56 processes1844SDKcalls; targetbranch55720->55776; no capture yet");
}
fn review() {
    verify_pins();
    let seed = read(format!("{I}/seed.json"));
    let mut ledger: BTreeSet<String> = serde_json::from_value(seed).unwrap();
    assert_eq!(ledger.len(), 55720);
    let jobs = read(format!("{R}/jobs.json"));
    let mut rows = vec![];
    for j in jobs.as_array().unwrap() {
        let name = j["name"].as_str().unwrap();
        let v = read(format!("{R}/checks/{name}.json"));
        assert_eq!(v["passed"], true);
        assert!(ledger.insert(v["proof_sha256"].as_str().unwrap().into()));
        if j["panel"] != "main" {
            continue;
        }
        let z = j["engine"] == "zopro";
        let ss = v["samples"].as_array().unwrap();
        let times = ss
            .iter()
            .map(|s| s[if z { "ms" } else { "verified_ms" }].as_f64().unwrap())
            .collect::<Vec<_>>();
        let mut pm: BTreeMap<String, Vec<f64>> = BTreeMap::new();
        let mut geometry = BTreeSet::new();
        for (i, p) in v["phases"].as_array().unwrap().iter().skip(3).enumerate() {
            let mut sums = BTreeMap::<String, f64>::new();
            let mut counted = 0.;
            for row in p["rows"].as_array().unwrap() {
                let phase = row["phase"].as_str().unwrap();
                let dur = (row["end_ns"].as_u64().unwrap() - row["begin_ns"].as_u64().unwrap())
                    as f64
                    / 1e6;
                *sums.entry(phase.into()).or_default() += dur;
                if ["solve","prepare","fft","queries","output"].contains(&phase) {
                    counted += dur;
                }
            }
            let total = p["total_ns"].as_u64().unwrap() as f64 / 1e6;
            assert!(counted <= total + 1e-6);
            assert!(total <= times[i] + 1e-3);
            sums.insert("observer_total".into(), total);
            sums.insert("unassigned_within_observer".into(), total - counted);
            sums.insert("request_outside_observer".into(), times[i] - total);
            if z {
                detail_metrics(p,&mut sums);
                let rr = p["rows"].as_array().unwrap();
                let query_end = rr[3]["end_ns"].as_u64().unwrap();
                for k in 4..7 {
                    sums.insert(
                        format!("{}_completion_tail", rr[k]["phase"].as_str().unwrap()),
                        (query_end - rr[k]["end_ns"].as_u64().unwrap()) as f64 / 1e6,
                    );
                }
            } else {
                let g=p["rows"].as_array().unwrap().iter().map(|r|json!({"phase":r["phase"],"items":r["items"],"job_items":r["job_items"]})).collect::<Vec<_>>();
                geometry.insert(serde_json::to_string(&g).unwrap());
            }
            for (k, n) in sums {
                pm.entry(k).or_default().push(n);
            }
        }
        let phase_means = pm
            .into_iter()
            .map(|(k, v)| (k, mean(&v)))
            .collect::<BTreeMap<_, _>>();
        let usage = &v["summary"];
        let cpu = (usage["user_cpu_ms"].as_f64().unwrap()
            + usage["system_cpu_ms"].as_f64().unwrap())
            / 31.;
        rows.push(json!({"job":j,"median_ms":median(&times),"mean_ms":mean(&times),"cpu_ms_per_request":cpu,"usage":usage,"phase_mean_ms":phase_means,"work_geometries":geometry.iter().map(|s|serde_json::from_str::<Value>(s).unwrap()).collect::<Vec<_>>() }));
    }
    if read(format!("{R}/mode.json"))["smoke"]==true {assert_eq!(ledger.len(),55722);save("proof-sha256-after-smoke.json",json!(ledger));save("smoke-complete.json",json!({"status":"complete","exports":2,"sdk_calls":8,"canonical_count":55722,"canonical_sha256":hash(format!("{R}/proof-sha256-after-smoke.json"))}));println!("SMOKE COMPLETE2exports");return;}
    assert_eq!(rows.len(), 54);
    assert_eq!(ledger.len(), 55776);
    let mut gates = vec![];
    let mut contexts = vec![];
    let mut scaling = vec![];
    let get = |mode: &str, w: usize, arm: &str, b: usize| {
        rows.iter()
            .find(|r| {
                r["job"]["mode"] == mode
                    && r["job"]["workers"] == w
                    && r["job"]["arm"] == arm
                    && r["job"]["block"] == b
            })
            .unwrap()
    };
    for mode in ["zopro"] {
        for w in [32, 96] {
            let pairs = if mode == "zopro" {
                vec![("OFF", "REF"), ("ON", "OFF")]
            } else {
                vec![("FRESH", "REF"), ("OFF", "FRESH"), ("ON", "OFF")]
            };
            for (num, den) in pairs {
                let raw = (0..9)
                    .map(|b| {
                        get(mode, w, num, b)["median_ms"].as_f64().unwrap()
                            / get(mode, w, den, b)["median_ms"].as_f64().unwrap()
                    })
                    .collect::<Vec<_>>();
                let mut ratios = raw.clone();
                ratios.sort_by(f64::total_cmp);
                for backing in 0..3 {let values=raw.iter().enumerate().filter(|(b,_)|b%3==backing).map(|(_,v)|*v).collect::<Vec<_>>();let m=median(&values);gates.push(json!({"kind":"backing","workers":w,"ratio":format!("{num}/{den}"),"backing":backing,"median":m,"passed":(0.95..=1.05).contains(&m)}));}
                gates.push(json!({"kind":"interval","mode":mode,"workers":w,"ratio":format!("{num}/{den}"),"block_ratios":raw,"median":ratios[4],"interval":[ratios[1],ratios[7]],"passed":ratios[1]>=0.95&&ratios[7]<=1.05}));
            }
            for arm in if mode == "zopro" {
                vec!["REF", "OFF", "ON"]
            } else {
                vec!["REF", "FRESH", "OFF", "ON"]
            } {
                let rs = (0..9).map(|b| get(mode, w, arm, b)).collect::<Vec<_>>();
                let mut phases = BTreeMap::new();
                for key in rs[0]["phase_mean_ms"].as_object().unwrap().keys() {
                    phases.insert(
                        key.clone(),
                        mean(
                            &rs.iter()
                                .map(|r| r["phase_mean_ms"][key].as_f64().unwrap())
                                .collect::<Vec<_>>(),
                        ),
                    );
                }
                contexts.push(json!({"mode":mode,"workers":w,"arm":arm,"median_of_process_medians_ms":median(&rs.iter().map(|r|r["median_ms"].as_f64().unwrap()).collect::<Vec<_>>()),"pooled_mean_ms":mean(&rs.iter().map(|r|r["mean_ms"].as_f64().unwrap()).collect::<Vec<_>>()),"cpu_ms_per_request":mean(&rs.iter().map(|r|r["cpu_ms_per_request"].as_f64().unwrap()).collect::<Vec<_>>()),"max_rss_mib":rs.iter().map(|r|r["usage"]["whole_process_maxrss_kib"].as_f64().unwrap()/1024.).fold(0.,f64::max),"phase_mean_ms":phases}));
            }
        }
        for arm in ["REF", "ON"] {
            let ratios = (0..9)
                .map(|b| {
                    get(mode, 96, arm, b)["median_ms"].as_f64().unwrap()
                        / get(mode, 32, arm, b)["median_ms"].as_f64().unwrap()
                })
                .collect::<Vec<_>>();
            scaling.push(json!({"mode":mode,"arm":arm,"median_96_over_32":median(&ratios),"improving_blocks":ratios.iter().filter(|&&v|v<1.).count(),"block_ratios":ratios}));
        }
    }
    save("rows.json", json!(rows));
    save("proof-sha256-after-capture.json", json!(ledger));
    save(
        "review.json",
        json!({"status":"complete","sdk_calls":1844,"exports":56,"canonical_count":55776,"canonical_sha256":hash(format!("{R}/proof-sha256-after-capture.json")),"all_gates_pass":gates.iter().all(|v|v["passed"]==true),"gates":gates,"contexts":contexts,"scaling":scaling,"production_change":false}),
    );
    println!("COMPLETE56 verified exports; targetbranch55776; inspect16 calibration/backing gates");
}
fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    match args[1].as_str() {
        "smoke" => execute(true),
        "measure" => execute(false),
        "inspect" => {
            let v = validate::inspect(&args[2]);
            fs::create_dir_all(format!("{R}/checks")).unwrap();
            save(&format!("checks/{}.json", args[2]), v);
        }
        "snapshot" => {
            snapshot(&args[2]);
            if args[2] == "before" {
                let o = Command::new("lscpu")
                    .args(["-p=CPU,CORE,SOCKET,ONLINE"])
                    .output()
                    .unwrap();
                assert!(o.status.success());
                fs::write(format!("{R}/topology.csv"), o.stdout).unwrap();
            }
        }
        "review" => {review(); if read(format!("{R}/mode.json"))["smoke"]==false {extended_review();}},
        _ => panic!("unknown operation"),
    }
}

fn detail_metrics(p:&Value,s:&mut BTreeMap<String,f64>){
 let rows=p["rows"].as_array().unwrap();let b=|i:usize|rows[i]["begin_ns"].as_u64().unwrap();let e=|i:usize|rows[i]["end_ns"].as_u64().unwrap();
 let last_g1=e(4).max(e(5));let last_window=(19..30).map(e).max().unwrap();let last_part=(30..52).map(e).max().unwrap();
 s.insert("g2_late_callback".into(),e(6).saturating_sub(last_g1) as f64/1e6);
 s.insert("g2_collection_after_last_window".into(),(e(17)-last_window)as f64/1e6);
 s.insert("g2_collection_after_last_part".into(),(e(17)-last_part)as f64/1e6);
 s.insert("g2_late_collection_return_gap".into(),e(17).saturating_sub(last_window.max(last_g1))as f64/1e6);
 s.insert("g2_window_late_work_span".into(),last_window.saturating_sub(last_g1)as f64/1e6);
 s.insert("gather_span".into(),(e(12).max(e(13))-b(12).min(b(13)))as f64/1e6);
 let late_window=(19..30).max_by_key(|&i|e(i)).unwrap();s.insert("last_window_index".into(),(late_window-19)as f64);
 let measured_prep=(8..12).map(|i|e(i)-b(i)).sum::<u64>()+e(12).max(e(13))-b(12).min(b(13));
 s.insert("prepare_unassigned".into(),((e(1)-b(1)).checked_sub(measured_prep).unwrap())as f64/1e6);
}
fn backings()->Value{use std::os::unix::fs::MetadataExt;let mut ids=BTreeSet::new();let mut out=vec![];for family in ["ref","diag"]{let expected=hash(format!("/usr/local/bin/detail-{family}"));for i in 0..3{let p=format!("{R}/bins/{family}{i}");let m=fs::metadata(&p).unwrap();assert!(ids.insert((m.dev(),m.ino())));assert_eq!(hash(&p),expected);out.push(json!({"path":p,"dev":m.dev(),"ino":m.ino(),"sha256":expected}));}}json!(out)}
fn snapshot(label:&str){save(&format!("{label}.json"),state());save(&format!("backings-{label}.json"),backings());}
fn counters(v:&Value,p:&str)->BTreeMap<String,u64>{v[p].as_str().unwrap().lines().map(|l|{let f=l.split_whitespace().collect::<Vec<_>>();assert_eq!(f.len(),2);(f[0].into(),f[1].parse().unwrap())}).collect()}
fn extended_review(){let basic=read(format!("{R}/review.json"));let mut v=basic.clone();let before=read(format!("{R}/before.json"));let after=read(format!("{R}/after.json"));let mut events=vec![];for(p,keys)in [("/sys/fs/cgroup/cpu.stat",vec!["nr_throttled","throttled_usec"]),("/sys/fs/cgroup/memory.events",vec!["high","max","oom","oom_kill","oom_group_kill"]),("/sys/fs/cgroup/memory.swap.events",vec!["high","max","fail"])]{let a=counters(&before,p);let b=counters(&after,p);for k in keys{let x=*a.get(k).unwrap();let y=*b.get(k).unwrap();assert!(y>=x);events.push(json!({"file":p,"counter":k,"delta":y-x,"passed":y==x}));}}assert_eq!(read(format!("{R}/backings-before.json")),read(format!("{R}/backings-after.json")));v["environment_guards"]=json!(events);v["all_gates_pass"]=json!(basic["all_gates_pass"]==true&&events.iter().all(|g|g["passed"]==true));save("basic-review.json",basic);fs::write(format!("{R}/review.json"),serde_json::to_vec_pretty(&v).unwrap()).unwrap();println!("TARGET COMPLETE56 exports; calibrated={}",v["all_gates_pass"]);}
fn execute(smoke:bool){use std::os::unix::fs::PermissionsExt;fs::create_dir(R).unwrap();fs::create_dir(format!("{R}/bins")).unwrap();for family in ["ref","diag"]{let bytes=fs::read(format!("/usr/local/bin/detail-{family}")).unwrap();for i in 0..3{let p=format!("{R}/bins/{family}{i}");fs::write(&p,&bytes).unwrap();fs::set_permissions(p,fs::Permissions::from_mode(0o755)).unwrap();}}
 let o=Command::new("lscpu").args(["-p=CPU,CORE,SOCKET,ONLINE"]).output().unwrap();assert!(o.status.success());let t=String::from_utf8(o.stdout).unwrap();fs::write(format!("{R}/topology.csv"),&t).unwrap();if !smoke{let mut cores=BTreeSet::new();let mut cpus=BTreeSet::new();for l in t.lines().filter(|l|!l.starts_with('#')){let f=l.split(',').collect::<Vec<_>>();assert_eq!(f[3],"Y");cpus.insert(f[0].parse::<usize>().unwrap());assert!(cores.insert((f[1],f[2])));}assert_eq!(cpus,(0..96).collect());assert_eq!(cores.len(),96);let cpu=fs::read_to_string("/sys/fs/cgroup/cpu.max").unwrap();let f=cpu.split_whitespace().collect::<Vec<_>>();assert_eq!(f[0].parse::<u64>().unwrap(),96*f[1].parse::<u64>().unwrap());assert_eq!(fs::read_to_string("/sys/fs/cgroup/memory.max").unwrap().trim(),(30u64<<30).to_string());assert_eq!(fs::read_to_string("/sys/fs/cgroup/memory.swap.max").unwrap().trim(),"0");}
 snapshot("before");prepare(smoke);let log=fs::File::create(format!("{R}/workflow.log")).unwrap();let s=Command::new("/usr/local/bin/cr-xtask").args(["workflow",&format!("{R}/plan.json"),&format!("{R}/run")]).stdout(std::process::Stdio::from(log.try_clone().unwrap())).stderr(std::process::Stdio::from(log)).status().unwrap();assert!(s.success(),"Preserve partial outputs; never replay successful SDK calls");println!("COMPLETE {}",if smoke{"smoke"}else{"measure"});}
