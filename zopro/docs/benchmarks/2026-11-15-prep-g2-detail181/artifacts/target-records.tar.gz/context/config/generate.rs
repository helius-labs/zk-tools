use std::{fs,path::Path};use serde_json::{Value,json};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/prep-g2-c7a181";const L:&str="/home/ubuntu/src/zopro-perf-work/prep-g2-detail181";const OLD:&str="/home/ubuntu/src/zopro-perf-work/msm-c7a180";
fn one(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1);}
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(p:impl AsRef<Path>,v:Value){fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap()}
fn main(){
 let mut s=fs::read_to_string(format!("{L}/runner.rs")).unwrap().replace(L,"/output/prep-g2-c7a181");
 one(&mut s,"const I: &str = \"/output/prep-g2-c7a181/inputs\";","const I: &str = \"/cr-detail\";");
 s=s.replace("5aa3b76fe67d3cc541636a7c94fa8eef7459b91a1cc7840d5330c901ddef0a4a","810baa30d05dcad89de5c6af5ceda9ce7ca9090807e25103b3f62240389891e5");
 s=s.replace("[16, 32]","[32, 96]").replace("get(mode, 32, arm, b)","get(mode, 96, arm, b)").replace("get(mode, 16, arm, b)","get(mode, 32, arm, b)").replace("median_32_over_16","median_96_over_32");
 one(&mut s,"fn prepare() {","fn prepare(smoke:bool) {\n    save(\"mode.json\",json!({\"smoke\":smoke}));");
 one(&mut s,"    for block in 0..9 {","    for block in 0..if smoke {0}else{9} {");
 s=s.replace("assert_eq!(jobs.len(), 56)","assert_eq!(jobs.len(), if smoke {2}else{56})").replace("        1844\n","        if smoke {8}else{1844}\n");
 s=s.replace("format!(\"{R}/runner\")","\"/usr/local/bin/detail-runner\".to_owned()").replace("format!(\"{R}/runner.rs\")","format!(\"{I}/runner.rs\")").replace("format!(\"{R}/validate.rs\")","format!(\"{I}/validate.rs\")").replace("format!(\"{R}/generate-runner.rs\")","format!(\"{I}/generate.rs\")").replace("format!(\"{R}/design.md\")","format!(\"{I}/protocol.md\")");
 one(&mut s,"    assert_eq!(ledger.len(), 55664);","    assert_eq!(ledger.len(), 55720);");
 one(&mut s,"    assert_eq!(rows.len(), 54);","    if read(format!(\"{R}/mode.json\"))[\"smoke\"]==true {assert_eq!(ledger.len(),55722);save(\"proof-sha256-after-smoke.json\",json!(ledger));save(\"smoke-complete.json\",json!({\"status\":\"complete\",\"exports\":2,\"sdk_calls\":8,\"canonical_count\":55722,\"canonical_sha256\":hash(format!(\"{R}/proof-sha256-after-smoke.json\"))}));println!(\"SMOKE COMPLETE2exports\");return;}\n    assert_eq!(rows.len(), 54);");
 one(&mut s,"    assert_eq!(ledger.len(), 55720);\n    let mut gates", "    assert_eq!(ledger.len(), 55776);\n    let mut gates");
 s=s.replace("\"canonical_count\":55720","\"canonical_count\":55776").replace("canonical55664->55720","targetbranch55720->55776").replace("canonical55720; inspect16","targetbranch55776; inspect16");
 one(&mut s,"        \"/proc/self/cgroup\",","        \"/proc/self/cgroup\",\n        \"/sys/fs/cgroup/cpu.max\",\"/sys/fs/cgroup/cpu.stat\",\"/sys/fs/cgroup/memory.max\",\"/sys/fs/cgroup/memory.events\",\"/sys/fs/cgroup/memory.swap.max\",\"/sys/fs/cgroup/memory.swap.events\",\"/sys/fs/cgroup/memory.peak\",");
 one(&mut s,"        \"prepare\" => prepare(),","        \"smoke\" => execute(true),\n        \"measure\" => execute(false),");
 one(&mut s,"            save(&format!(\"{}.json\", args[2]), state());","            snapshot(&args[2]);");
 one(&mut s,"        \"review\" => review(),","        \"review\" => {review(); if read(format!(\"{R}/mode.json\"))[\"smoke\"]==false {extended_review();}},");
 s.push_str(&fs::read_to_string(format!("{R}/extra.rs")).unwrap());fs::write(format!("{R}/runner.rs"),s).unwrap();fs::copy(format!("{L}/validate.rs"),format!("{R}/validate.rs")).unwrap();
 let ctx=Path::new(R).join("context");let mut plan=read(format!("{OLD}/context/config/preflight-plan.json"));plan["steps"].as_array_mut().unwrap().retain(|s|s["name"].as_str().unwrap().starts_with("zopro-")||s["name"].as_str().unwrap().starts_with("verify-zopro-"));save(ctx.join("config/preflight-plan.json"),plan);
 fs::copy(format!("{L}/inputs/preflight-jobs.json"),ctx.join("config/preflight-jobs.json")).unwrap();fs::copy(format!("{L}/proof-sha256-after-capture.json"),ctx.join("config/seed.json")).unwrap();
 for(n,dest)in [("runner.rs","runner.rs"),("validate.rs","validate.rs"),("generate.rs","generate.rs"),("protocol.md","protocol.md")]{fs::copy(format!("{R}/{n}"),ctx.join("config").join(dest)).unwrap();}
 fs::copy(format!("{L}/bins/ref0"),ctx.join("bins/detail-ref")).unwrap();fs::copy(format!("{L}/bins/diag0"),ctx.join("bins/detail-diag")).unwrap();
 let old=read(format!("{OLD}/context/config/preflight-pins.json"));let mut pins=serde_json::Map::new();for(p,h)in old.as_object().unwrap(){if p.starts_with("/cr-basis/")||p.starts_with("/fixtures/")||p=="/usr/local/bin/interval-verify"||p=="/usr/local/bin/cr-xtask"{pins.insert(p.clone(),h.clone());}}
 for family in ["ref","diag"]{let h=hash(ctx.join(format!("bins/detail-{family}")));pins.insert(format!("/usr/local/bin/detail-{family}"),json!(h));for i in 0..3{pins.insert(format!("/output/prep-g2-c7a181/bins/{family}{i}"),json!(h));}}
 for n in ["preflight-plan.json","preflight-jobs.json","seed.json","runner.rs","validate.rs","generate.rs","protocol.md"]{pins.insert(format!("/cr-detail/{n}"),json!(hash(ctx.join("config").join(n))));}save(ctx.join("config/preflight-pins.json"),json!(pins));
 for f in ["cloud.rs","transfer.rs","sigv4.rs","launch-template-resolved.json","user-data-template.sh"]{let s=fs::read_to_string(format!("{OLD}/{f}")).unwrap().replace(OLD,R).replace("msm-c7a180","prep-g2-c7a181");fs::write(format!("{R}/{f}"),if f=="cloud.rs"{s.replace("im[\"local_gnark_proofs\"], 4","im[\"local_gnark_proofs\"], 2").replace("im[\"local_preflight_sdk\"], 16","im[\"local_preflight_sdk\"], 8").replace("local4Gnark/16SDK","local2Gnark/8SDK")}else{s}).unwrap();}
}
