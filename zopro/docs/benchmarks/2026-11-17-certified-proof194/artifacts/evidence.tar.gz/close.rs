use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/certified-proof194";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let start = std::time::Instant::now();
    let base=read(format!("{Z}/docs/benchmarks/2026-11-17-fused-preparation182/artifacts/production-source-manifest.json"));
    let mut changed = vec![];
    let mut unchanged = 0;
    for (p, h) in base["source_files_sha256"].as_object().unwrap() {
        assert_eq!(hash(format!("{Z}/{p}")), h.as_str().unwrap());
        let q = format!("{R}/source-v2/{p}");
        if hash(&q) != h.as_str().unwrap() {
            changed.push(p);
        } else {
            unchanged += 1;
        }
    }
    assert_eq!(unchanged, 174);
    assert_eq!(changed.len(), 4);
    let mut receipts = 0;
    for (plan, run, pins) in [
        ("build-plan-v2.json", "build-run-v2", "build-pins-v2.json"),
        (
            "prover-tests-plan.json",
            "prover-tests-run",
            "build-pins-v2.json",
        ),
        ("plan.json", "run", "pins.json"),
    ] {
        for (p, h) in read(format!("{R}/{pins}")).as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap(), "{p}");
        }
        assert_eq!(read(format!("{R}/{run}/result.json"))["status"], "complete");
        let plan = read(format!("{R}/{plan}"));
        for step in plan["steps"].as_array().unwrap() {
            let name = step["name"].as_str().unwrap();
            let path = format!("{R}/{run}/{name}");
            let exit = read(format!("{path}/exit.json"));
            assert_eq!(exit["success"], true);
            assert_eq!(exit["returncode"], 0);
            let cmd = read(format!("{path}/command.json"));
            if step["kind"] == "command" {
                assert_eq!(&cmd["argv"].as_array().unwrap()[4..],step["argv"].as_array().unwrap());
            } else {
                assert_eq!(step["kind"],"link-sdk");
                let args=cmd["argv"].as_array().unwrap();
                assert!(args.iter().any(|a|a==&step["driver"]));
                for flag in step["rustc_flags"].as_array().unwrap(){assert!(args.contains(flag));}
            }
            for stream in ["stdout", "stderr"] {
                assert_eq!(
                    hash(format!("{path}/{stream}.log")),
                    exit[format!("{stream}_sha256")]
                );
            }
            receipts += 1;
        }
    }
    let review = read(format!("{R}/review.json"));
    assert_eq!(review["screen_advances"], true);
    assert_eq!(review["canonical_count"], 57392);
    let rows = read(format!("{R}/rows.json"));
    let mut cold = vec![];
    for case in ["1x2-w16", "1x2-w32", "2x2-w32"] {
        let mut values = rows
            .as_array()
            .unwrap()
            .iter()
            .filter(|v| v["job"]["case"] == case && v["job"]["arm"] == "ON")
            .map(|v| v["usage"]["generated_certification_ns"].as_f64().unwrap() / 1e6)
            .collect::<Vec<_>>();
        assert_eq!(values.len(), 9);
        values.sort_by(f64::total_cmp);
        cold.push(json!({"case":case,"median_ms":values[4],"min_ms":values[0],"max_ms":values[8]}));
    }
    let mut cold_calls = 0;
    for row in rows
        .as_array()
        .unwrap()
        .iter()
        .filter(|v| v["job"]["arm"] == "ON")
    {
        assert_eq!(row["usage"]["generated_fast_parses"], 31);
        assert_eq!(row["usage"]["generated_total_key_scans"], 1);
        assert_eq!(row["usage"]["generated_total_fixed_scans"], 1);
        assert_eq!(row["usage"]["generated_timed_key_scans"], 0);
        assert_eq!(row["usage"]["generated_timed_fixed_scans"], 0);
        cold_calls += 31;
    }
    let bytes = fs::read_to_string(format!(
        "{R}/source-v2/crates/zopro-core/src/generated_proof.rs"
    ))
    .unwrap();
    assert!(!bytes.contains("get_or_init"));
    assert!(bytes.contains("self.0.set(valid)"));
    let native = fs::read_to_string(format!("{R}/build-run-v2/core-tests/stdout.log")).unwrap();
    assert!(native.contains("134 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
    for (n, count) in [("prover-unit-on", 2), ("cubic-on", 6)] {
        let text = fs::read_to_string(format!("{R}/prover-tests-run/{n}/stdout.log")).unwrap();
        assert!(text.contains(&format!(
            "{count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
        )));
    }
    let first = read(format!("{R}/build-run/core-tests/exit.json"));
    assert_eq!(first["success"], false);
    assert_eq!(first["returncode"], 101);
    let time = |p: &str| {
        fs::metadata(format!("{R}/{p}"))
            .unwrap()
            .modified()
            .unwrap()
    };
    let prep = time("run/preflight-1x2-w4-OFF-b00/command.json")
        .duration_since(time("design.md"))
        .unwrap()
        .as_secs_f64();
    let capture = time("run/result.json")
        .duration_since(time("run/preflight-1x2-w4-OFF-b00/command.json"))
        .unwrap()
        .as_secs_f64();
    let report = json!({"passed":true,"screen_advances":true,"sdk_sha256":hash(format!("{R}/build-run-v2/candidate-sdk")),"changed_production_parents":changed,"unchanged_production_files":unchanged,"total_source_files":179,"production_unchanged":true,"receipts_checked":receipts,"native_core_tests_passed":134,"prover_unit_tests_passed":2,"cubic_tests_passed":6,"original_attempt":"Interrupted native test exposed cooperative Rayon/OnceLock initializer cycle; repaired before SDK build/capture, old failure retained","first_native_returncode":101,"all_enabled_main_fast_parses":cold_calls,"cold_certification":cold,"cold_scans_timed":0,"setup_seconds_first_design_to_capture":prep,"capture_workflow_seconds":capture,"closing_reader_seconds":start.elapsed().as_secs_f64(),"fresh_Gnark_exports":83,"SDK_calls":2762,"canonical_count":57392,"canonical_sha256":review["canonical_sha256"],"adopted":false,"remaining":["Exact SDK profile/observer qualification","All-shape performance against accepted production","Portable and full resource/release qualification"],"AWS_resources_created":0,"public_push":false});
    fs::write(
        format!("{R}/close.json"),
        serde_json::to_vec_pretty(&report).unwrap(),
    )
    .unwrap();
    println!("{}", serde_json::to_string(&report).unwrap());
}
