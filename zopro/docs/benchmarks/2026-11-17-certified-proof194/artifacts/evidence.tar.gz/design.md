# Certificate at the generated-proof boundary

Previous193 was progress: exact qualification completed, primary gain not reproduced,
production unchanged. Start from accepted fusion182, not rejected finite191.

Assumption challenged: every freshly CPU-generated G2 proof output needs a new
subgroup multiplication even when every immutable G2 input has already been checked.
Current solve_rerandomized builds B from Key.b2, fixed beta2/delta2 and fresh Fr
linear combinations, including its A0=identity fallback. Subgroups are closed under
these operations. Once-only deterministic input validation can certify this fact.

Prototype: an opaque GeneratedProof, minted only by Key, carries the existing raw
Vec and a private certificate bit. Public external Proof::from_raw always keeps
all checks. Generated parsing keeps coordinate bounds and all on-curve checks;
only the G2 subgroup check may be omitted. Key owns an independent OnceLock<bool>
for its immutable B2 Store; PreparedFixedPoints owns another for its immutable
beta2/delta2, so changing fixed objects cannot reuse another object's decision.
Any invalid input declines certification and retains ordinary parsing, without
rejecting the key or changing existing solver/invalid-proof error mapping.

Explicit private ZOPRO_BENCH_CERTIFIED_OUTPUT=1, native Linux IFMA only, B2 length
below65536. Ineligible/disabled paths do no scan. First eligible proof scans every
B2 point on-curve+subgroup in the existing pool. Certificate caches retain only
two OnceLocks, no points, scalars, extra heap table, solver image or worker pool.
Fixed inputs checked once as well. Cold setup cost must be reported separately;
primed latency cannot stand in for first-proof latency. No physical mobile claim.

Predicted observable: one input certificate scan per eligible key/fixed object,
zero timed scans after priming, one generated fast parse per enabled timed proof,
less subgroup scalar work, same external parser rejection for non-subgroup points.
Cheapest test: native correctness and cached-oracle parsing, then actual short
fresh-proof SDK screen against accepted plus same-binary OFF. Extra state is tiny;
added cold CPU could outweigh repeated savings for one-shot use. Refuted by missing
fast-route receipts, output mismatch, or no primary improvement in the fixed screen.

History: seed-NAF176 optimizes the integer subgroup multiplication itself; packed
Miller176 changes verification arithmetic; finite191 skips MSM identity checks.
This candidate moves a validation dependency to immutable input preparation and
does not reuse any of those rejected kernels. Typed projective MSM outlets and
proof serialization removal are deliberately outside this first discriminant.
Earlier zero/scalar scans, SRE/global pairs, frontend/fused-product overlap,
independent G2 planes and hexagonal buckets are already studied; no replay.
Primary papers revisited: https://arxiv.org/html/2610.27452v1 (small-window serial
Python scope); https://eprint.iacr.org/2026/1902 (existing hexagonal/LFG history);
https://arxiv.org/html/2509.12494v1 (128-bit FHE kernels and proposed MQX ISA,
not an available BN254 CPU speedup). No external runtime claim imported.

Before builds, add tests: valid/identity/off-curve/non-subgroup input certificates;
external parser rejection; valid old/new parsing equality; invalid certificate
fallback; distinct fixed objects; concurrent OnceLock use on512KiB worker stacks.
Reuse independent seed-NAF fixtures if available, otherwise derive an on-curve
non-subgroup point with the existing curve API and assert its subgroup rejection.
Native unfiltered suite required; portable before adoption. No new proof ledger
entries from core tests. Current canonical57309 SHA
cec72464ff1de85ef6ee11cebf62f1ddd59fbc4fa41608fe52dc66e11cafca37.

Screen if correctness passes: same83process/2762call nine-block protocol as191,
primary16/32 and2x2/32,3primes+31timed; two4worker preflights. All three independent
REF/candidate backings retained. Both arms fusion/indexedON. REF sole adoption
comparator; OFF mechanism control. Advance if either primary paired median beats
both controls with>=6/9wins and all three latency medians<=1.03,CPU<=1.05,RSS
<=control*1.05+8MiB. No minimum gain floor, extension, dropped copy or reroll.
Freeze readers/plan before preflight. Any positive screen still needs exact-build
profile, all-shape and resource qualification. No production adoption or push here.
Allow30min preparation,10min initial measurement; simplify if scope expands.
