use serde_json::{Value,json};use sha2::{Digest,Sha256};use std::{fs,path::Path,process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/certified-proof194";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
let mut s=fs::read_to_string(format!("{R}/generated_proof.rs")).unwrap();let a=r##"        *self.0.get_or_init(|| {
            let start=std::time::Instant::now();
            let valid=points.par_iter().with_min_len(64).all(|p|p.is_on_curve()&&p.is_in_subgroup());
            probe::scan(fixed,start.elapsed().as_nanos().try_into().unwrap());
            valid
        })"##;let b=r##"        if let Some(&valid)=self.0.get(){return valid;}
        // Rayon may execute another caller while this scan waits for its tasks.
        // Do not hold a OnceLock initializer across that cooperative wait.
        // First callers may duplicate only cold work; publish a completed bool.
        let start=std::time::Instant::now();
        let valid=points.par_iter().with_min_len(64).all(|p|p.is_on_curve()&&p.is_in_subgroup());
        probe::scan(fixed,start.elapsed().as_nanos().try_into().unwrap());
        if let Err(other)=self.0.set(valid){debug_assert_eq!(other,valid);}
        let published=*self.0.get().unwrap();debug_assert_eq!(published,valid);published"##;assert_eq!(s.matches(a).count(),1);s=s.replacen(a,b,1);
let rel="crates/zopro-core/src/generated_proof.rs";let overlay=format!("{R}/overlay-v2/{rel}");fs::create_dir_all(Path::new(&overlay).parent().unwrap()).unwrap();fs::write(&overlay,s).unwrap();let mut files=json!({});for(p,h)in read(format!("{R}/source/.xtask/source-pins.json")).as_object().unwrap(){files[p.strip_prefix(&format!("{R}/source/")).unwrap()]=h.clone();}fs::write(format!("{R}/manifest-v1.json"),serde_json::to_vec_pretty(&json!({"source_files_sha256":files})).unwrap()).unwrap();
let output=Command::new("/home/ubuntu/src/zk-tools/zopro/xtask/target/release/xtask").args(["prepare",&format!("{R}/manifest-v1.json"),&format!("{R}/source"),&format!("{R}/source-v2"),&format!("{R}/overlay-v2")]).output().unwrap();fs::write(format!("{R}/prepare-v2.stdout"),output.stdout).unwrap();fs::write(format!("{R}/prepare-v2.stderr"),output.stderr).unwrap();assert!(output.status.success());
let mut design=fs::read_to_string(format!("{R}/design.md")).unwrap();design.push_str("\n## Corrected concurrency before any SDK execution\n\nThe first native run hung in the new shared-pool certificate test. The test process\nwas explicitly terminated; its source, partial stdout and thread-state observation\nremain. Parallel work inside OnceLock::get_or_init can yield to a second pool caller\nthat waits on the same initializer, causing a dependency cycle. The repaired source\nfirst checks the cache, scans outside initialization, then publishes a completed bool\nwith set. Racing first callers may duplicate cold validation. All actual scans and\ntheir elapsed times are counted, rather than claiming only one scan under concurrent\nfirst use. Subsequent callers use the immutable published Boolean. There is no new\nlock/pool/spin protocol. Original first-key scan-count expectations apply only to\nthe serial SDK consumer. Runtime math and proof parsing are otherwise unchanged.\nThe new artifact has a new source snapshot/build receipts; no successful SDK capture\nexists or is replayed. Cold latency is setup cost, not warm proof latency.\n");fs::write(format!("{R}/design-v2.md"),design).unwrap();
let text=fs::read_to_string(format!("{R}/build-plan.json")).unwrap().replace(&format!("{R}/source/"),&format!("{R}/source-v2/")).replace(&format!("{R}/build-run/"),&format!("{R}/build-run-v2/"));let mut plan:Value=serde_json::from_str(&text).unwrap();plan["source_pins"]=json!(format!("{R}/build-pins-v2.json"));fs::write(format!("{R}/build-plan-v2.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();let mut pins=read(format!("{R}/source-v2/.xtask/source-pins.json"));for n in["setup.rs","repair.rs","build-plan-v2.json","design-v2.md","driver.rs","support/perf.rs"]{let p=format!("{R}/{n}");pins[&p]=json!(hash(&p));}fs::write(format!("{R}/build-pins-v2.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
}
