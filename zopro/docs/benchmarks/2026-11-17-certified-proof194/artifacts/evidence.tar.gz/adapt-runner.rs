use std::fs;
fn main(){let r="/home/ubuntu/src/zopro-perf-work/certified-proof194";let old="/home/ubuntu/src/zopro-perf-work/finite-sdk191";
let s=fs::read_to_string(format!("{old}/runner.rs")).unwrap().replace(old,r)
.replace("/home/ubuntu/src/zopro-perf-work/fused-preparation-c7a182/transport/proof-sha256.json","/home/ubuntu/src/zopro-perf-work/finite-all193/proof-sha256-after-main.json")
.replace("fd19e2e7d510008759cb6248bac6004db9274c698fc56cfa02a9f8006dc2cf36","cec72464ff1de85ef6ee11cebf62f1ddd59fbc4fa41608fe52dc66e11cafca37")
.replace("56585","57309").replace("56668","57392").replace("ZOPRO_BENCH_FINITE_G2","ZOPRO_BENCH_CERTIFIED_OUTPUT");fs::write(format!("{r}/runner.rs"),s).unwrap();
let mut s=fs::read_to_string(format!("{old}/validate.rs")).unwrap();let start=s.find("    if j[\"arm\"]!=\"REF\" {let summary=").unwrap();let end=s[start..].find('\n').unwrap()+start;
s.replace_range(start..end,r##"    if j["arm"]!="REF" {let summary=&summaries[0];let fast=summary["generated_fast_parses"].as_u64().unwrap();let keys=summary["generated_total_key_scans"].as_u64().unwrap();let fixed=summary["generated_total_fixed_scans"].as_u64().unwrap();let ns=summary["generated_certification_ns"].as_u64().unwrap();assert_eq!(summary["generated_timed_key_scans"],0);assert_eq!(summary["generated_timed_fixed_scans"],0);let rounds=j["rounds"].as_u64().unwrap();if j["arm"]=="OFF"{assert_eq!((fast,keys,fixed,ns),(0,0,0,0));}else{assert_eq!((fast,keys,fixed),(rounds,1,1));assert!(ns>0);}}"##);
fs::write(format!("{r}/validate.rs"),s).unwrap();}
