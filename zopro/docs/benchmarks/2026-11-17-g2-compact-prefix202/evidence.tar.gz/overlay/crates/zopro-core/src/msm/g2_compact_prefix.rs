//! Signed borrowed G2 prefix, retaining accepted arithmetic and scratch.
use super::*;
pub(super) fn apply<C: CurveConfig<Base = Fq2>, const FAST: bool>(
    buckets: &mut [Affine<C>],
    batch: &[(u32, &Affine<C>)],
    s: &mut Fq2AddScratch,
) {
    let full = batch.len() / LANES * LANES;
    let mut chains = FqBatch::one();
    s.compact_records.clear();
    s.compact_records.reserve_exact(full / LANES);
    for k in (0..full).step_by(LANES) {
        let ax = fq2_pack(core::array::from_fn(|i| {
            buckets[(batch[k + i].0 & 0x7fffffff) as usize].x
        }));
        let bx = fq2_pack(core::array::from_fn(|i| batch[k + i].1.x));
        let denominator = core::array::from_fn(|i| canonical_sub::<FAST>(&bx[i], &ax[i]));
        let norm = Fq2::lanes_norm(&denominator);
        s.compact_records.push([chains.compact_prefix(), norm.compact_prefix()]);
        chains = chains.mul(&norm);
    }
    s.tail.clear();
    let mut inverse =
        if let Some(value) = direct_chain_inverse(&chains, full == batch.len(), s.vector_inverse) {
            value
        } else {
            let mut tail = chains.get();
            for k in full..batch.len() {
                let (encoded, b) = batch[k];
                let index = encoded & 0x7fffffff;
                let b = if encoded >> 31 != 0 { -*b } else { *b };
                let a = buckets[index as usize];
                let denominator = b.x - a.x;
                let norm = denominator.c0.square() + denominator.c1.square();
                let numerator = ((b.y - a.y) * denominator.conjugate()).mul_by_fp(&tail[k % LANES]);
                tail[k % LANES] *= norm;
                s.tail
                    .push([a.x, a.y, a.x + b.x, Fq2::new(norm, Fq::ZERO), numerator]);
            }
            let mut inverse = invert_lanes(tail, s.vector_inverse);
            for k in (full..batch.len()).rev() {
                let [ax, ay, xsum, norm, numerator] = s.tail[k - full];
                let slope = numerator.mul_by_fp(&inverse[k % LANES]);
                inverse[k % LANES] *= norm.c0;
                let x = slope.square() - xsum;
                let y = slope * (ax - x) - ay;
                buckets[(batch[k].0 & 0x7fffffff) as usize] = Affine::new(x, y);
            }
            FqBatch::new(&inverse)
        };
    for j in (0..full / LANES).rev() {
        let k = j * LANES;
        let a: [Affine<C>; LANES] =
            core::array::from_fn(|i| buckets[(batch[k + i].0 & 0x7fffffff) as usize]);
        let b: [&Affine<C>; LANES] = core::array::from_fn(|i| batch[k + i].1);
        let ax = fq2_pack(a.map(|p| p.x));
        let ay = fq2_pack(a.map(|p| p.y));
        let bx = fq2_pack(b.map(|p| p.x));
        let dy=if FAST{
            let by=fq2_pack(b.map(|p|p.y));
            let negative=signs::<true,C>(&batch[k..k+LANES]);
            core::array::from_fn(|i|by[i].signed_difference_canonical(&ay[i],negative))
        }else{
            let by=fq2_pack(core::array::from_fn(|i|if batch[k+i].0>>31!=0{-b[i].y}else{b[i].y}));
            core::array::from_fn(|i|canonical_sub::<FAST>(&by[i],&ay[i]))
        };
        let denominator=core::array::from_fn(|i|canonical_sub::<FAST>(&bx[i],&ax[i]));
        let factor = s.compact_records[j][0].expand().mul(&inverse);
        inverse = inverse.mul(&s.compact_records[j][1].expand());
        let slope = Fq2::lanes_scaled_numerator(&dy, &denominator, &factor);
        let x = Fq2::lanes_sub(&Fq2::lanes_square(&slope), &Fq2::lanes_add(&ax, &bx));
        let y = Fq2::lanes_sub(&Fq2::lanes_mul(&slope, &Fq2::lanes_sub(&ax, &x)), &ay);
        let (x, y) = (fq2_unpack(x), fq2_unpack(y));
        for i in 0..LANES {
            buckets[(batch[k + i].0 & 0x7fffffff) as usize] = Affine::new(x[i], y[i]);
        }
    }
}


impl<C:CurveConfig<Base=Fq2>> BatchAdd<C> { pub(crate) fn apply_signed_compact_g2(&mut self,buckets:&mut[Affine<C>],batch:&[(u32,&Affine<C>)]) { if self.borrowed_g2_enabled() { apply::<C,true>(buckets,batch,&mut self.fq2) }else { self.apply_signed_borrowed_g2(buckets,batch) } } }
#[cfg(test)]mod compact_tests{
use super::*;use zopro_bn254::{Fr,G2Config};use crate::simd::compact_prefix::PackedFqBatch;
#[test]fn curve_oracles_signs_tails_reuse_and_capacity(){
assert_eq!(core::mem::size_of::<[PackedFqBatch;2]>(),512);assert_eq!(core::mem::size_of::<[FqBatch;2]>(),640);
let g=Projective::<G2Config>::generator();let nmax=512;let initial=Projective::<G2Config>::batch_to_affine(&(0..nmax).map(|i|g*Fr::from(10001+i as u64)).collect::<Vec<_>>());let incoming=Projective::<G2Config>::batch_to_affine(&(0..nmax).map(|i|g*Fr::from(90001+i as u64)).collect::<Vec<_>>());
let mut refs=vec![];for neg in[false,true]{for pass in 0..=3{refs.push(Projective::<G2Config>::batch_to_affine(&(0..nmax).map(|i|{let a=Fr::from(10001+i as u64);let b=Fr::from(90001+i as u64)*Fr::from(pass);g*(if neg{a-b}else{a+b})}).collect::<Vec<_>>()));}}
let mut scratch=Fq2AddScratch{canonical:true,vector_inverse:true,prefix_enabled:true,..Default::default()};let mut maximum=0;
for n in[0usize,1,7,8,9,15,16,31,32,33,200,352,511,32,8,0]{maximum=maximum.max(n);for mask in 0..256{let batch=(0..n).map(|i|(i as u32|if mask>>(i%8)&1!=0{1<<31}else{0},&incoming[i])).collect::<Vec<_>>();let mut current=initial.clone();let mut plain=initial.clone();for pass in 1..=3{apply::<G2Config,true>(&mut current,&batch,&mut scratch);crate::msm::g2_borrowed::apply::<G2Config,true>(&mut plain,&batch,&mut scratch);assert_eq!(current,plain);for i in 0..n{assert_eq!(current[i],refs[usize::from(mask>>(i%8)&1!=0)*4+pass][i]);}}
let capacity=scratch.compact_records.capacity()*core::mem::size_of::<[PackedFqBatch;2]>()+scratch.prefix_records.capacity()*core::mem::size_of::<[FqBatch;2]>()+scratch.groups.capacity()*core::mem::size_of::<Fq2AddGroup>()+scratch.tail.capacity()*core::mem::size_of::<[Fq2;5]>()+2*core::mem::size_of::<Vec<[FqBatch;2]>>();assert!(capacity<=workspace_batch::<G2Config>(maximum).unwrap());assert!(scratch.compact_records.capacity()<=maximum/8);}}
for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.broadcast(|ctx|{let mask=ctx.index()%256;let mut s=Fq2AddScratch{canonical:true,vector_inverse:true,prefix_enabled:true,..Default::default()};for n in[8,200,16]{let batch=(0..n).map(|i|(i as u32|if mask>>(i%8)&1!=0{1<<31}else{0},&incoming[i])).collect::<Vec<_>>();let mut current=initial.clone();apply::<G2Config,true>(&mut current,&batch,&mut s);for i in 0..n{assert_eq!(current[i],refs[usize::from(mask>>(i%8)&1!=0)*4+1][i]);}}});}
println!("compact record640->512B; all masks/tails/three-pass reuse and combined scratch bound checked; no field arithmetic change");}
}
