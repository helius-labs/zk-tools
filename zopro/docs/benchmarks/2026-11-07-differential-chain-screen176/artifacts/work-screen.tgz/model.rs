use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{collections::{BTreeMap,BTreeSet},fs,path::Path};
mod split;
type Word=[u64;4];
include!("groups.rs");
const R:&str="/home/ubuntu/src/zopro-perf-work/differential-chain-screen176";
const PRIOR:&str="/home/ubuntu/src/zopro-perf-work/g2-fixed-wnaf176/analysis.json";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn lower_bound(bits:&[u32])->u64{bits.iter().map(|&b|b.saturating_sub(1) as u64).sum()}
fn main(){
 assert!(!Path::new(&format!("{R}/analysis.json")).exists());
 for(p,h)in read(format!("{R}/count-pins.json")).as_object().unwrap(){assert_eq!(hash(&fs::read(p).unwrap()),h.as_str().unwrap());}
 let prior=read(PRIOR);let mut cases=BTreeMap::new();let mut selected=true;
 for shape in ["1x2","2x2"]{
  let old=&prior["cases"][shape];let path=old["input_fixture"].as_str().unwrap();let raw=fs::read(path).unwrap();assert_eq!(hash(&raw),old["fixture_sha256"]);assert_eq!(&raw[..8],b"B2SCAN01");
  let n=u64::from_le_bytes(raw[8..16].try_into().unwrap()) as usize;assert_eq!(raw.len(),16+160*n);
  let scalars=raw[16+128*n..].chunks_exact(32).map(|s|core::array::from_fn(|i|u64::from_le_bytes(s[8*i..8*i+8].try_into().unwrap()))).collect::<Vec<Word>>();
  let grouped=groups(&scalars);let values=grouped.as_ref().map(|v|v.0.as_slice()).unwrap_or(&scalars);assert_eq!(values.len(),old["scalar_terms"]);assert_eq!(grouped.is_some(),old["data_only_grouping_selected"]);
  let mut scalarhash=Sha256::new();let mut componenthash=Sha256::new();let mut lengths=Vec::new();let mut histogram=vec![0u64;127];
  for &v in values{for w in v.iter().rev(){scalarhash.update(w.to_be_bytes());}let s=split::phi_split(v);
   for i in 0..2{let mag=s[2*i] as u128|((s[2*i+1]&0x7fff_ffff_ffff_ffff) as u128)<<64;assert!(mag<1u128<<126);componenthash.update(mag.to_le_bytes());let bits=128-mag.leading_zeros();histogram[bits as usize]+=1;lengths.push(bits);}
  }
  let scalarhash=format!("{:x}",scalarhash.finalize());assert_eq!(scalarhash,old["scalar_values_BE_sha256"]);
  let bound=lower_bound(&lengths);let original=old["original_Booth"]["complete_noncancelling_cost"]["all_point_add_calls"].as_u64().unwrap();let pass=bound<original;selected&=pass;
  cases.insert(shape,json!({"fixture_sha256":hash(&raw),"scalar_values_BE_sha256":scalarhash,"component_magnitudes_LE_sha256":format!("{:x}",componenthash.finalize()),"input_rows":n,"scalar_terms":values.len(),"components":lengths.len(),"component_bitlength_histogram":histogram,"optimistic_regular_ladder_add_lower_bound":bound,"original_complete_point_add_calls":original,"scheduled_add_lower_bound_ratio":bound as f64/original as f64,"necessary_selection_passed":pass,"all_doublings_precompute_recovery_merges_ignored":true}));
 }
 let tables=(1..=20u32).map(|d|{let count=(3u128.pow(d)-1)/2;json!({"dimension":d,"stored_points":count.to_string(),"G1_x_only_bytes_minimum":(32*count).to_string(),"G2_x_only_bytes_minimum":(64*count).to_string(),"not_RAM_peak":true})}).collect::<Vec<_>>();
 let out=json!({"complete":true,"cases":cases,"difference_table_sizes":tables,"necessary_native_selection_passed":selected,"model_only":true,"new_SDK_calls":0,"new_proofs":0,"canonical_proof_ledger":31913,"adopted":false,"production_changed":false,"goal_achieved":false,"scope":"fixed regular d-MUL recurrence, not all differential chains or the separate revised2024/038algorithm"});fs::write(format!("{R}/analysis.json"),serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("{}",json!({"selected":selected,"cases":out["cases"]}));
}
#[cfg(test)]mod tests{
 use super::*;
 fn partition_cost(bits:&[u32], groups:&[usize])->u64{let mut maxima=vec![0;bits.len()];let mut sizes=vec![0u64;bits.len()];for(&b,&g)in bits.iter().zip(groups){if b>1{maxima[g]=maxima[g].max(b);sizes[g]+=1;}}maxima.iter().zip(sizes).map(|(&m,n)|n*m.saturating_sub(1) as u64).sum()}
 fn partitions(bits:&[u32],groups:&mut Vec<usize>,largest:usize,checks:&mut u64){if groups.len()==bits.len(){assert!(lower_bound(bits)<=partition_cost(bits,groups));*checks+=1;return}for g in 0..=largest+1{groups.push(g);partitions(bits,groups,largest.max(g),checks);groups.pop();}}
 #[test]fn partition_bound_and_ternary_sign_classes(){
  let mut checks=0;for n in 1..=5{for code in 0..6usize.pow(n as u32){let mut k=code;let bits=(0..n).map(|_|{let b=(k%6) as u32;k/=6;b}).collect::<Vec<_>>();partitions(&bits,&mut vec![0],0,&mut checks);}}
  assert_eq!(lower_bound(&[0,1,2,126,125]),250);assert!(checks>400000);
  for d in 0..=6usize{let mut classes=BTreeSet::new();for code in 1..3usize.pow(d as u32){let mut k=code;let mut signed=vec![];for _ in 0..d{signed.push((k%3) as i8-1);k/=3;}if signed.iter().all(|&n|n==0){continue}if signed.iter().find(|&&n|n!=0).copied()==Some(-1){for n in &mut signed{*n=-*n;}}classes.insert(signed);}
   // Include code0: it is the all-minus-one vector for d>0.
   if d>0{classes.insert(vec![1;d]);}assert_eq!(classes.len(),(3usize.pow(d as u32)-1)/2);
  }
 }
}
