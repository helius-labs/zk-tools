# Independent-reader display-ratio repair

The first reader compiled successfully, then exited101 on exact f64 equality after reconstructing primary integers:10.895279013248519 versus10.89527901324852. JSON serialization/parsing differs in the final binary bit in the linked serde configuration. All integer counts are exact, selection uses only integers, and the producer/input/design/model remain unchanged.

Preserve review-original.rs plus review-runs and original review-pins/plan. The repaired reader allows two relative f64 epsilons only for this descriptive ratio, after checking exact numerator/denominator and failed selection. Every other assertion stays unchanged. Compile the changed reader, then repeat only this failed review stage; no model/test/native/query/proof is repeated. The repair does not change a performance or statistical gate.
