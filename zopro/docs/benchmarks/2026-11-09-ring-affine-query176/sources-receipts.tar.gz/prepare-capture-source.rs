use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/ring-affine-query176";const P:&str="/home/ubuntu/src/zopro-perf-work/g2-joint-ring-native176";
fn change(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replace(a,b);}
fn main(){assert!(!Path::new(&format!("{R}/capture.rs")).exists());let mut s=fs::read_to_string(format!("{P}/capture.rs")).unwrap().replace(P,R).replace("FROZEN","REF").replace("30708","40154");
 change(&mut s,"r(\"consumers/result.json\")","r(\"build/result.json\")");change(&mut s,"r(\"capture-base-pins.json\")","r(\"build-pins.json\")");s=s.replace("native-plan.json","build-plan.json").replace("consumer-plan.json","build-plan.json");
 change(&mut s,"for dir in[\"stat\",\"perf\"]", "for(k,v)in[(\"ZOPRO_CPU_DEDUP\",\"1\"),(\"ZOPRO_CPU_SMALL_GROUPS\",\"1\"),(\"ZOPRO_CPU_RESERVE_GROUPS\",\"1\")]{env[k]=json!(v);}for dir in[\"stat\",\"perf\"]");
 change(&mut s,"steps.push(command(\"preflight-check\",json!([r(\"capture\"),\"preflight\"])));", "// All offline preflight review is deferred until every recording completes.");
 s=s.replace("assert_eq!(steps.len(),379)","assert_eq!(steps.len(),378)").replace("Prepared379steps","Prepared378steps").replace("\"workflow_steps\":379","\"workflow_steps\":378");
 change(&mut s,"let on=job[\"variant\"]==\"ON\"&&job[\"case\"][\"query\"]==\"B\";", "let on=job[\"variant\"]==\"ON\"&&job[\"case\"][\"expected_ON_route\"]==316;");s=s.replace("if on{314}else{0}","if on{316}else{0}").replace("route314","route316/production grouping");
 change(&mut s,"let gate=calibration&&nonregression&&gains&&diagnostics;",r#"
let mut checks=vec![];
for(name,c)in &cases {
 checks.push(json!({"name":format!("{name}/OFF/REF/calibration"),"passed":c["calibration_passed"]}));
 for control in["OFF","REF"]{let v=&c["ON_comparisons"][control];checks.push(json!({"name":format!("{name}/ON/{control}/nonregression"),"passed":v["upper"].as_f64().unwrap()<=1.02}));if name=="1x2-A-w32"{checks.push(json!({"name":format!("{name}/ON/{control}/unchanged-A"),"passed":v["lower"].as_f64().unwrap()>=1./1.03&&v["upper"].as_f64().unwrap()<=1.03}));}if name=="1x2-B-w32"{checks.push(json!({"name":format!("{name}/ON/{control}/gain"),"passed":v["upper"].as_f64().unwrap()<1.&&v["wins"].as_u64().unwrap()>=10}));}}
 let control=c["REF_max_RSS_MiB"].as_f64().unwrap().max(c["OFF_max_RSS_MiB"].as_f64().unwrap());let limit=control*1.05+1.;checks.push(json!({"name":format!("{name}/RSS"),"passed":c["ON_max_RSS_MiB"].as_f64().unwrap()<=limit,"limit_MiB":limit}));
}
for control in["OFF","REF"]{let v=&aggregate[control];checks.push(json!({"name":format!("B32-two-shape/ON/{control}/gain"),"passed":v["upper"].as_f64().unwrap()<1.&&v["wins"].as_u64().unwrap()>=10}));}
for(name,v)in &profiles{checks.push(json!({"name":format!("{name}/profile-quality"),"passed":v["qualified"]}));}for(name,v)in &counters{checks.push(json!({"name":format!("{name}/PMU-quality"),"passed":v["qualified"]}));}
assert_eq!(checks.len(),46);let failed=checks.iter().filter(|v|v["passed"]!=true).map(|v|v["name"].clone()).collect::<Vec<_>>();let gate=failed.is_empty();
"#);
 change(&mut s,"\"complete_query_gate_passed\":gate,", "\"checks\":checks,\"failed_checks\":failed,\"complete_query_gate_passed\":gate,");
 change(&mut s,"\"capture.rs\",\"capture\",\"sampling.rs\",\"counter.rs\",\"protocol.md\",\"identities.json\",\"cases.json\",\"jobs.json\",\"build-plan.json\"", "\"capture.rs\",\"capture\",\"sampling.rs\",\"counter.rs\",\"protocol.md\",\"identities.json\",\"cases.json\",\"jobs.json\",\"build-plan.json\",\"prepare-capture-source.rs\",\"review.rs\",\"review\",\"fixture-routing.json\",\"build-review.json\"");
 fs::write(format!("{R}/capture.rs"),s).unwrap();for name in["sampling.rs","counter.rs"]{fs::copy(format!("{P}/{name}"),format!("{R}/{name}")).unwrap();}fs::copy(format!("{R}/design.md"),format!("{R}/protocol.md")).unwrap();println!("prepared fixed378step capsule/46checks/group-aware routing; readers not yet compiled/frozen");}
