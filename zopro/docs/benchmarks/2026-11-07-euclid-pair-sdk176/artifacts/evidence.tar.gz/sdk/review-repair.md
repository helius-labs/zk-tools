# Offline reviewer arithmetic repair

The first offline reviewer rejected a reconstructed process mean of 9.469095098039217 ms versus the saved JSON value 9.469095098039215 ms. It used exact f64 equality across JSON round-tripping. The original review.rs and captured review-attempt stderr remain unchanged. The previous context's uncaptured invocation also produced no review-result.json; its exact output is unavailable and is not reconstructed here.

review2.rs changes only this reconstruction assertion to absolute error below 1e-11 ms. Confidence intervals, bootstrap population, paired ratios, wins, timing observations and all five failed selection checks remain unchanged. No native build/test, cryptographic verifier, capture, bootstrap analysis or decoder is repeated. The repaired offline review succeeds.
