            #[cfg(zopro_fused_correction_mask)]
            if LANES == 8 {
                // The existing >= mask is exact when no high limbs tie.
                // Ties retain the complete original comparison/reduction.
                unsafe {
                    let tied = _mm512_cmpeq_epu64_mask(t[4], high);
                    if tied == 0 {
                        let p = split(modulus).map(Self::splat);
                        let mask = Self::splat(MASK);
                        let mut out = [Self::splat(0); 5];
                        let mut carry = Self::splat(0);
                        for j in 0..5 {
                            let subtract = _mm512_maskz_mov_epi64(needs, p[j]);
                            let v = _mm512_add_epi64(_mm512_sub_epi64(t[j], subtract), carry);
                            out[j] = _mm512_and_si512(v, mask);
                            carry = _mm512_srai_epi64::<52>(v);
                        }
                        return Self(out, PhantomData);
                    }
                }
            }
