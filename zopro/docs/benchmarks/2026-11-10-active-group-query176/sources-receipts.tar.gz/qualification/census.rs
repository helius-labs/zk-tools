//! Data-only descriptor census; no field arithmetic or latency inference.
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{collections::{BTreeMap,BTreeSet},fs};
const R:&str="/home/ubuntu/src/zopro-perf-work/active-group-scan176";
type Word=[u64;4];
include!("/home/ubuntu/src/zopro-perf-work/indexed-wide-bands176/groups.rs");
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn count(counts:&[usize])->Value{
    let(mut old,mut new,mut layers,mut pairs,mut skipped_self_copies,mut active_steps)=(0usize,0usize,0usize,0usize,0usize,0usize);
    let(mut better,mut worse,mut equal)=(0usize,0usize,0usize);let mut rows=vec![];
    for (i,tile)in counts.chunks(256).enumerate(){
        let mut c=tile.to_vec();let(mut ov,mut nv,mut levels,mut self_copies,mut operations,mut active_sum)=(0usize,c.len(),0usize,0usize,0usize,0usize);
        loop{
            let first=c.iter().position(|n|*n>1);ov+=first.map_or(c.len(),|j|j+1);
            let Some(_)=first else{break};
            let active=c.iter().filter(|n|**n>1).count();ov+=2*c.len();nv+=3*active;
            self_copies+=c.iter().filter(|n|**n==1).count();operations+=c.iter().map(|n|n/2).sum::<usize>();active_sum+=active;
            for n in &mut c{*n=n.div_ceil(2);}levels+=1;
        }
        assert!(c.iter().all(|n|*n<=1));
        assert_eq!(operations,tile.iter().map(|n|n.saturating_sub(1)).sum::<usize>());
        old+=ov;new+=nv;layers+=levels;pairs+=operations;skipped_self_copies+=self_copies;active_steps+=active_sum;
        if nv<ov{better+=1}else if nv>ov{worse+=1}else{equal+=1}
        rows.push(json!({"tile":i,"classes":tile.len(),"points":tile.iter().sum::<usize>(),"levels":levels,"old_descriptor_visits":ov,"new_descriptor_visits":nv,"ordinary_or_exceptional_pairs_unchanged":operations,"singleton_point_self_assignments_omitted":self_copies}));
    }
    json!({"tiles":rows.len(),"levels":layers,"old_descriptor_visits":old,"new_descriptor_visits":new,"new_to_old_descriptor_ratio":if old==0{1.}else{new as f64/old as f64},"descriptor_saving_fraction":if old==0{0.}else{1.-new as f64/old as f64},"tiles_fewer_equal_more_visits":[better,equal,worse],"ordinary_or_exceptional_pairs_unchanged":pairs,"active_class_level_steps":active_steps,"singleton_point_self_assignments_omitted":skipped_self_copies,"tiles_detail":rows})
}
fn main(){
    let prior=read("/home/ubuntu/src/zopro-perf-work/iterative-bands176/analysis.json");let mut cases=BTreeMap::new();
    for shape in["1x2","2x2"]{
        let p=&prior["cases"][shape];let b=fs::read(p["fixture_path"].as_str().unwrap()).unwrap();assert_eq!(hash(&b),p["fixture_sha256"]);assert_eq!(&b[..8],b"B2SCAN01");let n=u64::from_le_bytes(b[8..16].try_into().unwrap())as usize;assert_eq!(b.len(),16+160*n);
        let raw=b[16+128*n..].chunks_exact(32).map(|s|std::array::from_fn(|i|u64::from_le_bytes(s[8*i..8*i+8].try_into().unwrap()))).collect::<Vec<Word>>();
        let g=groups(&raw);let values=g.as_ref().map(|g|g.0.as_slice()).unwrap_or(raw.as_slice());let bytes=values.iter().flat_map(|v|v.iter().rev().flat_map(|w|w.to_be_bytes())).collect::<Vec<_>>();assert_eq!(hash(&bytes),p["scalar_values_BE_sha256"]);assert_eq!(values.len(),p["scalar_terms"]);assert_eq!(g.is_some(),p["grouping_selected"]);
        // Independently assign stable classes by first occurrence, as the source does.
        let mut index=BTreeMap::new();let(mut counts,mut stable_values)=(vec![],vec![]);let mut classes=vec![usize::MAX;n];
        for(i,&v)in raw.iter().enumerate(){if v==[0;4]{continue}let k=*index.entry(v).or_insert_with(||{let k=counts.len();counts.push(0usize);stable_values.push(v);k});counts[k]+=1;classes[i]=k;}
        if let Some((v,c))=&g{assert_eq!(stable_values,*v);assert_eq!(classes,*c);}
        let mut hist=BTreeMap::new();for &c in&counts{*hist.entry(c).or_insert(0usize)+=1;}
        cases.insert(shape,json!({"fixture_sha256":p["fixture_sha256"],"input_rows":n,"scalar_values_BE_sha256":hash(&bytes),"grouping_admitted":g.is_some(),"nonzero_scalar_classes":counts.len(),"class_size_histogram":hist,"ordered_scalar_class_reducer_work":if g.is_some(){count(&counts)}else{Value::Null},"declined_grouping_work_not_executed":if g.is_none(){count(&counts)}else{Value::Null}}));
    }
    let edge=BTreeMap::from([("dense2",count(&vec![2;256])),("dense9",count(&vec![9;256])),("hot_last",{let mut v=vec![1;256];v[255]=4097;count(&v)}),("empty",count(&[])),("singleton",count(&[1;256]))]);
    let ledger="/home/ubuntu/src/zopro-perf-work/large-class-sdk176/proof-sha256-after-capture.json";assert_eq!(read(ledger).as_array().unwrap().len(),43730);
    let out=json!({"kind":"data_only_ordered_descriptor_census","cases":cases,"adverse_and_boundary_cases":edge,"definitions":{"old_visits":"any predicate prefix including final false scan + two full descriptor loops per level","new_visits":"one initial descriptor scan + pair, compaction, and active filter scans per active class per level","point_self_assignment":"old compaction with count=1 writes the same stored point to itself; candidate omits it; source-level operation, optimizer may remove it","not_priced":"512-byte array initialization, u16 indexing, fields, loads/stores, branches, cycles, allocation, SMT"},"canonical_proof_count":43730,"canonical_ledger_sha256":hash(&fs::read(ledger).unwrap()),"new_proofs":0,"latency_measured":false,"adopted":false});
    fs::write(format!("{R}/census.json"),serde_json::to_vec_pretty(&out).unwrap()).unwrap();
    for s in["1x2","2x2"]{let c=&out["cases"][s];println!("CENSUS {s} admitted={} classes={} work={}",c["grouping_admitted"],c["nonzero_scalar_classes"],if c["grouping_admitted"]==true{json!({"old":c["ordered_scalar_class_reducer_work"]["old_descriptor_visits"],"new":c["ordered_scalar_class_reducer_work"]["new_descriptor_visits"],"fraction_saved":c["ordered_scalar_class_reducer_work"]["descriptor_saving_fraction"]})}else{json!("grouping declined; hypothetical counts are not runtime work")});}
}
