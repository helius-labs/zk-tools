use super::*;
use ark_ec::{AdditiveGroup, CurveGroup, PrimeGroup};
use rayon::prelude::*;
mod q {
    include!("/home/ubuntu/src/zopro-perf-work/active-group-scan176/test_support.rs");
}
macro_rules! curve_tests {
    ($module:ident,$config:ty,$point:ty,$ark:ty,$convert:ident) => {
        mod $module {
            use super::*;
            type Config=$config;
            type Ark=$ark;
            fn fixture(counts:&[usize])->(Vec<$point>,Vec<u32>,Vec<usize>,Vec<$point>){
                let pool=Ark::normalize_batch(&q::weights().iter().map(|s|Ark::generator()*s).collect::<Vec<_>>());
                let(mut points,mut order,mut starts,mut expected)=(vec![],vec![],vec![0],vec![]);
                for (group,&count)in counts.iter().enumerate(){let mut sum=Ark::ZERO;let base=points.len();
                    for i in 0..count{let index=match (group%4,i%7){(_,0)=>0,(0,1..=3)=>1,(0,4..=6)=>2,_=>(i+group)%64};let p=pool[index];sum+=p;points.push(q::$convert(p));}
                    order.extend((base..points.len()).rev().map(|i|i as u32));starts.push(order.len());expected.push(q::$convert(sum.into_affine()));
                }(points,order,starts,expected)
            }
            fn run(counts:&[usize])->(usize,usize){
                assert!(counts.len()<=256);let(p,order,starts,want)=fixture(counts);
                let raw:Vec<_>=order.iter().map(|&i|limbs::<Config>(p[i as usize])).collect();let(mut old,mut new)=(raw.clone(),raw.clone());let(mut a,mut b)=(counts.to_vec(),counts.to_vec());let(mut sa,mut sb)=(Scratch::<Config>::default(),Scratch::<Config>::default());
                let(mut original_visits,mut selected_visits,mut layers)=(0,counts.len(),0);
                loop{let active=a.iter().enumerate().filter(|(_,n)|**n>1).map(|(i,_)|i as u16).collect::<Vec<_>>();original_visits+=a.iter().position(|n|*n>1).map_or(a.len(),|i|i+1);if active.is_empty(){break;}
                    original_visits+=2*a.len();selected_visits+=3*active.len();
                    reduce_layer::<Config>(&mut old,&starts[..counts.len()],&mut a,&mut sa);
                    selected_layer::<Config>(&mut new,&starts[..counts.len()],&mut b,&mut sb,&active);
                    assert_eq!(a,b);assert_eq!(sa.pairs,sb.pairs);for(x,y)in old.iter().zip(&new){assert_eq!(x.x,y.x);assert_eq!(x.y,y.y);}layers+=1;
                }
                let mut complete=raw.clone();let mut c=counts.to_vec();reduce::<Config>(&mut complete,&starts[..counts.len()],&mut c,&mut Scratch::default());assert_eq!(a,c);
                for (i,want)in want.iter().enumerate(){let got=if c[i]==0{<$point>::IDENTITY}else{affine::<Config>(complete[starts[i]])};assert_eq!(got,*want);}
                assert_eq!(group_affine::<Config>(&p,&order,&starts,counts),want);
                let split=p.len()/2;assert_eq!(group_affine_prepared::<Config>(&p[..split],&p[split..],&order,&starts,counts),want);
                println!("ACTIVE_{} groups={} rows={} layers={layers} original_descriptor_visits={original_visits} new_descriptor_visits={selected_visits}",stringify!($module),counts.len(),p.len());
                (original_visits,selected_visits)
            }
            #[test]
            fn exact_layer_trajectories_and_arkworks_class_sums(){
                for n in[0,1,2,3,7,8,31,32,199,200,201,511,1024,2049,4097]{let mut c=vec![1;256];c[n%256]=n;c[(n+17)%256]=n/3;c[(n+31)%256]=0;run(&c);}
                run(&[]);run(&[0,0,0]);run(&[1,1,1]);run(&vec![2;256]);run(&vec![9;256]);run(&[0,1,2,3,7,8,31,199,200,201]);
                let mut hot=vec![1;256];hot[255]=4097;let(old,new)=run(&hot);assert!(new<old);
                let(old,new)=run(&vec![2;256]);assert!(new>old); // Retain dense adverse count case.
            }
            #[test]
            fn full_partial_chunks_workers_and_concurrent_callers(){
                let counts=(0..513).map(|i|match i%13{0=>129,1=>33,2=>7,3=>2,4=>0,_=>1}).collect::<Vec<_>>();let(p,order,starts,want)=fixture(&counts);let saved=p.clone();
                let check=||{assert_eq!(group_affine::<Config>(&p,&order,&starts,&counts),want);let split=p.len()/2;assert_eq!(group_affine_prepared::<Config>(&p[..split],&p[split..],&order,&starts,&counts),want);};
                for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.broadcast(|_|check());}
                let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();std::thread::scope(|scope|{for _ in 0..4{let(pool,check)=(&pool,&check);std::thread::Builder::new().stack_size(512*1024).spawn_scoped(scope,move||pool.install(check)).unwrap();}});assert_eq!(p,saved);
                println!("ACTIVE_{}_OWNER_CONTEXTS=57 ORDINARY_PREPARED=true WORKERS=1,4,16,32 SHARED_OS_CALLERS=4 POOL=8 STACK_KIB=512 GROUPS=513",stringify!($module));
            }
        }
    };
}
curve_tests!(g1,zopro_bn254::G1Config,zopro_bn254::G1Affine,ark_bn254::G1Projective,g1);
curve_tests!(g2,zopro_bn254::G2Config,zopro_bn254::G2Affine,ark_bn254::G2Projective,g2);

#[test]
fn checked_stack_payload_forecast(){
    assert_eq!(EXTRA_STACK_BYTES,512);
    for jobs in[0usize,1,4,16,32,128]{for n in[0usize,1,255,256,257,65535]{
        let extra=if cfg!(all(zopro_active_group_scan,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma))){512}else{0};
        let each=core::mem::size_of::<LimbPoint<zopro_bn254::Fq>>()+core::mem::size_of::<usize>()+core::mem::size_of::<Group<zopro_bn254::Fq>>().div_ceil(2*LANES);
        let old=n*each+jobs*(4*core::mem::size_of::<usize>()+3*64+core::mem::size_of::<Vec<[FqBatch;2]>>());
        assert_eq!(workspace_grouping_linear::<zopro_bn254::G1Config>(n,jobs),Some(old+jobs*extra));
    }}
    assert!(workspace_grouping_linear::<zopro_bn254::G1Config>(usize::MAX,32).is_none());
    assert!(workspace_grouping_linear::<zopro_bn254::G2Config>(1,usize::MAX).is_none());
    println!("ACTIVE_WORKSPACE_CASES=36 OVERFLOW_CASES=2 STACK_BYTES_PER_LEAF=512");
}
