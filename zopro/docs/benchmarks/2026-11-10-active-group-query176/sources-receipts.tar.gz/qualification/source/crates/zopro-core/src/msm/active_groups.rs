//! Keep only unfinished scalar classes in subsequent descriptor scans.
use super::*;
const GROUP: usize = 256;
pub(super) const EXTRA_STACK_BYTES: usize = core::mem::size_of::<[u16; GROUP]>();

pub(super) fn reduce<C: CurveConfig>(
    points: &mut [LimbPoint<C::Base>],
    starts: &[usize],
    counts: &mut [usize],
    scratch: &mut Scratch<C>,
) where
    C::Base: BatchInverse,
{
    assert!(counts.len() <= GROUP);
    let mut active = [0u16; GROUP];
    let mut len = 0;
    for (index, &count) in counts.iter().enumerate() {
        if count > 1 {
            active[len] = index as u16;
            len += 1;
        }
    }
    while len != 0 {
        selected_layer(points, starts, counts, scratch, &active[..len]);
        let mut next = 0;
        for i in 0..len {
            let index = active[i];
            if counts[index as usize] > 1 {
                active[next] = index;
                next += 1;
            }
        }
        len = next;
    }
}

// selected_layer is generated from the unchanged accepted reduce_layer body.
// Only its signature and the two descriptor-loop headers differ.
fn selected_layer<C: CurveConfig>(
    points: &mut [LimbPoint<C::Base>],
    starts: &[usize],
    counts: &mut [usize],
    s: &mut Scratch<C>,
    active: &[u16],
) where
    C::Base: BatchInverse,
{
    s.pairs.clear();
    for &selected in active {
        let index = selected as usize;
        let offset = starts[index];
        for j in (0..counts[index].saturating_sub(1)).step_by(2) {
            let (a, b) = (&points[offset + j], &points[offset + j + 1]);
            if !a.is_infinity() && !b.is_infinity() && a.x != b.x {
                s.pairs.push(offset + j);
            }
        }
    }
    type F<C> = <C as CurveConfig>::Base;
    let m = s.pairs.len();
    let use_prefix = F::<C>::TREE_PREFIX && m >= 32;
    let full = m / LANES * LANES;
    s.groups.clear();
    if !use_prefix {s.groups.reserve_exact(full / LANES);}

    let mut chains = FqBatch::one();
    if use_prefix {
        s.prefix_records.clear();
        s.prefix_records.reserve(full / LANES);
        for k in (0..full).step_by(LANES) {
            let a = core::array::from_fn(|i| &points[s.pairs[k + i]].x);
            let b = core::array::from_fn(|i| &points[s.pairs[k + i] + 1].x);
            let dx = F::<C>::lanes_sub(&F::<C>::load(b), &F::<C>::load(a));
            let norm = F::<C>::lanes_norm(&dx);
            s.prefix_records.push([chains, norm]);
            chains = chains.mul(&norm);
        }
    } else {
    for k in (0..full).step_by(LANES) {
        let a: [&LimbPoint<F<C>>; LANES] = core::array::from_fn(|i| &points[s.pairs[k + i]]);
        let b: [&LimbPoint<F<C>>; LANES] = core::array::from_fn(|i| &points[s.pairs[k + i] + 1]);
        let (ax, ay) = (F::<C>::load(a.map(|p| &p.x)), F::<C>::load(a.map(|p| &p.y)));
        let (bx, by) = (F::<C>::load(b.map(|p| &p.x)), F::<C>::load(b.map(|p| &p.y)));
        let denominator = F::<C>::lanes_sub(&bx, &ax);
        let norm = F::<C>::lanes_norm(&denominator);
        let numerator =
            F::<C>::lanes_scaled_numerator(&F::<C>::lanes_sub(&by, &ay), &denominator, &chains);
        chains = chains.mul(&norm);
        s.groups.push(Group {
            ax,
            ay,
            xsum: F::<C>::lanes_add(&ax, &bx),
            norm,
            numerator,
        });
    }

    }
    let mut inverses = if let Some(value)=direct_chain_inverse(&chains,full==m,s.vector_inverse) {
        value
    } else {
        let mut tail = chains.get();
        for k in full..m {
            let (a, b) = (
                affine::<C>(points[s.pairs[k]]),
                affine::<C>(points[s.pairs[k] + 1]),
            );
            let denominator = b.x - a.x;
            {
                s.denominators[k - full] = denominator;
                s.products[k - full] = F::<C>::prefix(&mut tail[k % LANES], denominator);
            }
        }
        let mut inverses = invert_lanes(tail, s.vector_inverse);
        for k in (full..m).rev() {
            let t = k - full;
            F::<C>::reverse(
                &mut inverses[k % LANES],
                s.denominators[t],
                &mut s.products[t],
            );
        }
        FqBatch::new(&inverses)
    };
    if use_prefix {
        for (j, record) in s.prefix_records.iter().enumerate().rev() {
            let k = j * LANES;
            let a: [&LimbPoint<F<C>>; LANES] = core::array::from_fn(|i| &points[s.pairs[k + i]]);
            let b: [&LimbPoint<F<C>>; LANES] = core::array::from_fn(|i| &points[s.pairs[k + i] + 1]);
            let (ax, ay) = (F::<C>::load(a.map(|p| &p.x)), F::<C>::load(a.map(|p| &p.y)));
            let (bx, by) = (F::<C>::load(b.map(|p| &p.x)), F::<C>::load(b.map(|p| &p.y)));
            let denominator = F::<C>::lanes_sub(&bx, &ax);
            let factor = record[0].mul(&inverses);
            inverses = inverses.mul(&record[1]);
            let slope = F::<C>::lanes_scaled_numerator(&F::<C>::lanes_sub(&by, &ay), &denominator, &factor);
            let x = F::<C>::lanes_sub(&F::<C>::lanes_square(&slope), &F::<C>::lanes_add(&ax, &bx));
            let y = F::<C>::lanes_sub(&F::<C>::lanes_mul(&slope, &F::<C>::lanes_sub(&ax, &x)), &ay);
            let (x, y) = (F::<C>::store(&x), F::<C>::store(&y));
            for i in 0..LANES { points[s.pairs[k + i]] = LimbPoint {x:x[i], y:y[i]}; }
        }
    } else {
    for (j, group) in s.groups.iter().enumerate().rev() {
        let slope = F::<C>::lanes_scale(&group.numerator, &inverses);
        inverses = inverses.mul(&group.norm);
        let x = F::<C>::lanes_sub(&F::<C>::lanes_square(&slope), &group.xsum);
        let y = F::<C>::lanes_sub(
            &F::<C>::lanes_mul(&slope, &F::<C>::lanes_sub(&group.ax, &x)),
            &group.ay,
        );
        let (x, y) = (F::<C>::store(&x), F::<C>::store(&y));
        for i in 0..LANES {
            {
                points[s.pairs[j * LANES + i]] = LimbPoint { x: x[i], y: y[i] };
            }
        }
    }

    }
    for k in full..m {
        let t = k - full;
        let (a, b) = (
            affine::<C>(points[s.pairs[k]]),
            affine::<C>(points[s.pairs[k] + 1]),
        );
        let slope = (b.y - a.y) * F::<C>::denominator_inverse(s.denominators[t], s.products[t]);
        let x = slope.square() - a.x - b.x;
        let y = slope * (a.x - x) - a.y;
        {
            points[s.pairs[k]] = limbs::<C>(Affine::new(x, y));
        }
    }
    // All vector inputs were captured before the reverse pass. Each ordinary
    // pair writes only its first input slot, disjoint from every other pair
    // and exceptional pair. Scalar tails are likewise disjoint. Compaction
    // writes before the next unread pair, so no result vector is needed.
    // Each bucket keeps its pair sums in front, in order. A write lands
    // before the pairs still to be read.
    let mut cursor = 0;
    for &selected in active {
        let index = selected as usize;
        let offset = starts[index];
        let n = counts[index];
        for j in 0..n / 2 {
            points[offset + j] = if s.pairs.get(cursor) == Some(&(offset + 2 * j)) {
                cursor += 1;
                {
                    points[offset + 2 * j]
                }
            } else {
                let (a, b) = (points[offset + 2 * j], points[offset + 2 * j + 1]);
                if a.is_infinity() {
                    b
                } else if b.is_infinity() {
                    a
                } else {
                    // Doubling and opposite points need the complete formulas.
                    limbs::<C>((affine::<C>(a) + affine::<C>(b)).to_affine())
                }
            };
        }
        if !n.is_multiple_of(2) {
            points[offset + n / 2] = points[offset + n - 1];
        }
        counts[index] = n.div_ceil(2);
    }
}

#[cfg(test)]
mod qualification;
