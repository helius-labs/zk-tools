use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/active-group-scan176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
    let test=format!("{R}/tests.rs");let old=fs::read_to_string(&test).unwrap();
    assert_eq!(old.matches("assert_eq!(x.x,y.x);assert_eq!(x.y,y.y);").count(),1);
    fs::write(format!("{R}/before-debug-assert-fix-tests.rs"),&old).unwrap();
    let new=old.replace("assert_eq!(x.x,y.x);assert_eq!(x.y,y.y);","assert!(x.x==y.x);assert!(x.y==y.y);");
    for path in[&test,&format!("{R}/source/crates/zopro-core/src/msm/active_groups/qualification.rs")]{fs::write(path,&new).unwrap();}
    let p=read(format!("{R}/repair-plan.json"));
    let steps=p["steps"].as_array().unwrap()[2..].to_vec();
    assert_eq!(steps[0]["name"],"build-native-tests");
    let mut pins=read(format!("{R}/repair-pins.json"));let pins=pins.as_object_mut().unwrap();
    for rel in["tests.rs","source/crates/zopro-core/src/msm/active_groups/qualification.rs","before-debug-assert-fix-tests.rs","repair-tests.rs","repair-tests","libs/OFF/libzopro_core.rlib","libs/ON/libzopro_core.rlib"]{let path=format!("{R}/{rel}");pins.insert(path.clone(),json!(hash(path)));}
    let path=format!("{R}/remaining-plan.json");fs::write(&path,serde_json::to_vec_pretty(&json!({"version":1,"source_pins":format!("{R}/remaining-pins.json"),"steps":steps})).unwrap()).unwrap();
    pins.insert(path.clone(),json!(hash(path)));fs::write(format!("{R}/remaining-pins.json"),serde_json::to_vec_pretty(pins).unwrap()).unwrap();
    fs::write(format!("{R}/test-repair-note.md"),"Both repaired native release cores compiled successfully. The native test build then failed because assert_eq requires Debug for FqLimbs. Two coordinate equality assertions now use assert!(a==b), retaining the same exact limb comparisons without changing the production type. The original tests and failure receipts are preserved. The remaining five steps reuse the successful native release cores. No arithmetic, fixtures, expected outputs, or comparison tolerances changed.\n").unwrap();
    println!("Prepared remaining5commands; reused2successfulnativecores;exactlimbcomparisonsunchanged");
}
