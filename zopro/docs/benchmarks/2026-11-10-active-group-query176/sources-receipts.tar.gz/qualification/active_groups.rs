//! Keep only unfinished scalar classes in subsequent descriptor scans.
use super::*;
const GROUP: usize = 256;
pub(super) const EXTRA_STACK_BYTES: usize = core::mem::size_of::<[u16; GROUP]>();

pub(super) fn reduce<C: CurveConfig>(
    points: &mut [LimbPoint<C::Base>],
    starts: &[usize],
    counts: &mut [usize],
    scratch: &mut Scratch<C>,
) where
    C::Base: BatchInverse,
{
    assert!(counts.len() <= GROUP);
    let mut active = [0u16; GROUP];
    let mut len = 0;
    for (index, &count) in counts.iter().enumerate() {
        if count > 1 {
            active[len] = index as u16;
            len += 1;
        }
    }
    while len != 0 {
        selected_layer(points, starts, counts, scratch, &active[..len]);
        let mut next = 0;
        for i in 0..len {
            let index = active[i];
            if counts[index as usize] > 1 {
                active[next] = index;
                next += 1;
            }
        }
        len = next;
    }
}

// selected_layer is generated from the unchanged accepted reduce_layer body.
// Only its signature and the two descriptor-loop headers differ.
