use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/two-bank177";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn files(p:&Path,out:&mut Vec<String>){for e in fs::read_dir(p).unwrap(){let e=e.unwrap();if e.file_type().unwrap().is_dir(){files(&e.path(),out)}else{assert!(!e.file_type().unwrap().is_symlink());out.push(e.path().display().to_string());}}out.sort();}
fn replace(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1);}
fn main(){assert!(!Path::new(&format!("{R}/source")).exists());let mut old=Vec::new();let prev="/home/ubuntu/src/zopro-perf-work/top-elision177/source";files(Path::new(prev),&mut old);let mut bindings=BTreeMap::new();
for p in old {let relative=p.strip_prefix(&format!("{prev}/")).unwrap();let source=format!("{Z}/{relative}");if !Path::new(&source).is_file(){continue}let dest=format!("{R}/source/{relative}");fs::create_dir_all(Path::new(&dest).parent().unwrap()).unwrap();fs::copy(&source,&dest).unwrap();bindings.insert(relative.to_string(),format!("{:x}",Sha256::digest(fs::read(source).unwrap())));}
let path=format!("{R}/source/crates/zopro-core/src/msm_affine/borrowed_pending.rs");let original=fs::read_to_string(&path).unwrap();let start=original.find("struct Window<'a").unwrap();let end=original.find("pub(super) fn fused<").unwrap();let mut child=format!("use crate::msm::BatchAdd;\nuse zopro_bn254::{{Affine,CurveConfig,Field,Fq,Projective,G1Config,G1Affine}};\n{}",&original[start..end]);
replace(&mut child,"    affine: Vec<Affine<C>>,","    half: usize,\n    affine: Vec<Affine<C>>,");replace(&mut child,"            affine: vec![Affine::<C>::IDENTITY; half],","            half,\n            affine: vec![Affine::<C>::IDENTITY; 2*half],");replace(&mut child,"busy: vec![0; half.div_ceil(64)]","busy: vec![0; (2*half).div_ceil(64)]");
replace(&mut child,"        let index = self.projective_indices[bucket];","        let bucket=bucket%self.half;\n        let index = self.projective_indices[bucket];");
let feed_start=child.find("    fn feed(\n").unwrap();let feed_end=child.find("    fn finish(mut self)").unwrap();child.replace_range(feed_start..feed_end,"");
replace(&mut child,"            if self.busy((encoded & 0x7fffffff) as usize) {\n                return;\n            }\n            self.queue.pop();\n            self.add(encoded, point);","            let Some(physical)=self.select((encoded&0x7fffffff)as usize) else {return};\n            self.queue.pop();\n            self.add(physical as u32|(encoded&0x80000000), point);");
replace(&mut child,"    fn take_from_queue(&mut self) {","    fn select(&self,b:usize)->Option<usize>{if !self.busy(b){Some(b)}else if !self.busy(b+self.half){Some(b+self.half)}else{None}}\n    fn take_from_queue(&mut self) {");
replace(&mut child,"        self.affine\n    }","        {\n            let (left,right)=self.affine.split_at_mut(self.half);\n            let mut pairs=Vec::with_capacity(self.half);\n            for (i,(a,b)) in left.iter_mut().zip(right.iter()).enumerate(){\n                if a.is_identity(){*a=*b;}else if b.is_identity(){}else if a.x==b.x{*a=(*a+*b).to_affine();}else{pairs.push((i as u32,b));}\n            }\n            self.packed.apply_signed_borrowed(left,&pairs);\n        }\n        self.affine.truncate(self.half);\n        self.affine\n    }");
child.push_str(r#"
pub(super) fn probe(points:&[G1Affine],indices:&[u32],half:usize,size:usize)->(Vec<G1Affine>,[u64;6]){
 assert_eq!(points.len(),indices.len());assert!(half>0&&half<=4096&&size>=2);
 let mut s=Window::<G1Config>::new(half,size);let mut counts=[0u64;6];
 for (p,&encoded)in points.iter().zip(indices){let b=(encoded&0x7fffffff)as usize;assert!(b<half);if p.is_identity(){counts[5]+=1;continue}
  if let Some(i)=s.select(b){counts[0]+=u64::from(i>=half);let a=s.affine[i];if !a.is_identity()&&a.x==p.x{counts[3]+=1;let signed=if encoded>>31!=0{-*p}else{*p};counts[4]+=u64::from(a.y!=signed.y);}s.add(i as u32|(encoded&0x80000000),p);if s.batch.len()==size{s.execute();s.take_from_queue();}}
  else{s.queue.push((encoded,p));counts[1]+=1;if s.queue.len()==size-1{s.flush_queue();counts[2]+=1;}}
 }
 (s.finish(),counts)
}
"#);
fs::write(format!("{R}/source/crates/zopro-core/src/msm_affine/two_bank.rs"),&child).unwrap();fs::write(format!("{R}/two_bank.rs"),&child).unwrap();
let adapter=r#"
pub(crate) fn bank_probe_old(points:&[zopro_bn254::G1Affine],indices:&[u32],half:usize,size:usize)->Vec<zopro_bn254::G1Affine>{
 assert_eq!(points.len(),indices.len());let mut s=Window::<zopro_bn254::G1Config>::new(half,size);
 for(p,&encoded)in points.iter().zip(indices){let b=(encoded&0x7fffffff)as usize;assert!(b<half);if p.is_identity(){continue}if s.busy(b){s.queue.push((encoded,p));if s.queue.len()==size-1{s.flush_queue();}}else{s.add(encoded,p);if s.batch.len()==size{s.execute();s.take_from_queue();}}}s.finish()
}
"#;fs::write(&path,format!("{original}{adapter}")).unwrap();
let path=format!("{R}/source/crates/zopro-core/src/msm_affine.rs");let original=fs::read_to_string(&path).unwrap();fs::write(&path,format!("{original}\npub(crate) mod two_bank;\n")).unwrap();
let path=format!("{R}/source/crates/zopro-core/src/lib.rs");let original=fs::read_to_string(&path).unwrap();fs::write(&path,format!("{original}\npub fn two_bank_probe(p:&[zopro_bn254::G1Affine],i:&[u32],h:usize,s:usize,on:bool)->(Vec<zopro_bn254::G1Affine>,[u64;6]){{if on{{msm_affine::two_bank::probe(p,i,h,s)}}else{{(msm_affine::borrowed_pending::bank_probe_old(p,i,h,s),[0;6])}}}}\n")).unwrap();
fs::create_dir_all(format!("{R}/driver/src")).unwrap();fs::copy(format!("{R}/driver.rs"),format!("{R}/driver/src/main.rs")).unwrap();fs::write(format!("{R}/driver/Cargo.toml"),r#"[package]
name="two-bank-qualification"
version="0.0.0"
edition="2021"
publish=false
[workspace]
[dependencies]
zopro-core={path="../source/crates/zopro-core"}
zopro-bn254={path="../source/crates/zopro-bn254"}
ark-bn254="0.5"
ark-ec="0.5"
ark-ff="0.5"
rayon="1.10"
serde_json="=1.0.149"
[profile.release]
opt-level=3
lto="fat"
codegen-units=1
"#).unwrap();
fs::write(format!("{R}/source-bindings.json"),serde_json::to_vec_pretty(&bindings).unwrap()).unwrap();
let ctl:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zopro-perf-work/top-elision177/build-plan.json").unwrap()).unwrap();let mut env=ctl["steps"][0]["environment"].clone();env["CARGO_TARGET_DIR"]=format!("{R}/target").into();
let plan=json!({"version":1,"source_pins":format!("{R}/native-pins.json"),"steps":[{"kind":"command","name":"build","argv":["cargo","build","--locked","--offline","--release","--manifest-path",format!("{R}/driver/Cargo.toml"),"--message-format=json"],"environment":env,"timeout_seconds":1800},{"kind":"command","name":"qualify","argv":[format!("{R}/target/release/two-bank-qualification")],"environment":env,"timeout_seconds":600}]});fs::write(format!("{R}/native-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();println!("Prepared isolated current-source copy with diagnostic-only entry points; generate offline driver lock before pinning.");}
