use ark_bn254::{G1Affine as A, G1Projective as P, Fr as S};
use ark_ec::{AffineRepr,CurveGroup,PrimeGroup};
use ark_ff::{BigInteger,PrimeField,Zero};
use zopro_bn254::{G1Affine as Z,Fq};
use serde_json::json;
fn convert(p:A)->Z{if p.is_zero(){Z::IDENTITY}else{let cv=|x:ark_bn254::Fq|{let b=x.into_bigint().to_bytes_le();Fq::from_canonical(std::array::from_fn(|i|u64::from_le_bytes(b[i*8..i*8+8].try_into().unwrap()))).unwrap()};Z::new(cv(p.x),cv(p.y))}}
fn fixture()->(Vec<A>,Vec<Z>){let mut x=0x3141592653589793u64;let mut a=Vec::new();for i in 0..128{x=x.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);let mut bytes=[0u8;32];for c in bytes.chunks_mut(8){x=x.wrapping_mul(6364136223846793005).wrapping_add(1);c.copy_from_slice(&x.to_le_bytes());}let s=match i%16{0=>S::from(0),1|2=>S::from(1),3=>-S::from(1),_=>S::from_le_bytes_mod_order(&bytes)};a.push((P::generator()*s).into_affine());}let z=a.iter().copied().map(convert).collect();(a,z)}
fn case(half:usize,cap:usize,pattern:usize,ark:&[A],points:&[Z])->[u64;6]{
 let mut selected=Vec::new();let mut indices=Vec::new();let mut expected=vec![P::zero();half];
 for i in 0..4097{let b=match pattern{0=>0,1=>i%half,2=>(i*37+i/11)%half,_=>if i%9==0{i%half}else{0}};let k=(i*17+i/128)%points.len();let negative=i%3==0;selected.push(points[k]);indices.push(b as u32|if negative{1<<31}else{0});let p=ark[k];if negative{expected[b]-=p}else{expected[b]+=p}}
 let immutable=selected.clone();let want:Vec<_>=P::normalize_batch(&expected).into_iter().map(convert).collect();let (old,_)=zopro_core::two_bank_probe(&selected,&indices,half,cap,false);assert_eq!(old,want,"old {half}/{cap}/{pattern}");let (new,stats)=zopro_core::two_bank_probe(&selected,&indices,half,cap,true);assert_eq!(new,want,"new {half}/{cap}/{pattern}");assert_eq!(selected,immutable);stats
}

fn main(){let(ark,z)=fixture();let mut cases=0;let mut outputs=0;let mut merges=0;
for half in[2048,4096]{for cap in[200,352]{let mut points=Vec::new();let mut indices=Vec::new();let mut want=Vec::new();for b in 0..half{let k=4+16*(b%8);let a=ark[k]+ark[k+1];let c=ark[k+2]+ark[k+3];assert!(!a.is_zero()&&!c.is_zero());assert_ne!(a.into_affine().x,c.into_affine().x);let negative=b%3==0;let total=if negative{-(a+c)}else{a+c};want.push(convert(total.into_affine()));for j in 0..4{points.push(z[k+j]);indices.push(b as u32|if negative{1<<31}else{0});}}
let copy=points.clone();let (off,_)=zopro_core::two_bank_probe(&points,&indices,half,cap,false);assert_eq!(off,want);let(on,stats)=zopro_core::two_bank_probe(&points,&indices,half,cap,true);assert_eq!(on,want);assert_eq!(points,copy);assert_eq!(stats[0],2*half as u64);assert_eq!(stats[1],0);assert_eq!(stats[3],0);cases+=1;outputs+=2*half;merges+=half;}
}println!("{}",json!({"passed":true,"cases":cases,"bucket_comparisons":outputs,"forced_nonexceptional_bank_merges":merges,"merge_lengths":[2048,4096],"stream_capacities":[200,352],"independent_Arkworks":true,"input_points_unchanged":true,"performance_measured":false}));}
