use ark_bn254::{G1Affine as A, G1Projective as P, Fr as S};
use ark_ec::{AffineRepr,CurveGroup,PrimeGroup};
use ark_ff::{BigInteger,PrimeField,Zero};
use zopro_bn254::{G1Affine as Z,Fq};
use serde_json::json;
fn convert(p:A)->Z{if p.is_zero(){Z::IDENTITY}else{let cv=|x:ark_bn254::Fq|{let b=x.into_bigint().to_bytes_le();Fq::from_canonical(std::array::from_fn(|i|u64::from_le_bytes(b[i*8..i*8+8].try_into().unwrap()))).unwrap()};Z::new(cv(p.x),cv(p.y))}}
fn fixture()->(Vec<A>,Vec<Z>){let mut x=0x3141592653589793u64;let mut a=Vec::new();for i in 0..128{x=x.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);let mut bytes=[0u8;32];for c in bytes.chunks_mut(8){x=x.wrapping_mul(6364136223846793005).wrapping_add(1);c.copy_from_slice(&x.to_le_bytes());}let s=match i%16{0=>S::from(0),1|2=>S::from(1),3=>-S::from(1),_=>S::from_le_bytes_mod_order(&bytes)};a.push((P::generator()*s).into_affine());}let z=a.iter().copied().map(convert).collect();(a,z)}
fn case(half:usize,cap:usize,pattern:usize,ark:&[A],points:&[Z])->[u64;6]{
 let mut selected=Vec::new();let mut indices=Vec::new();let mut expected=vec![P::zero();half];
 for i in 0..4097{let b=match pattern{0=>0,1=>i%half,2=>(i*37+i/11)%half,_=>if i%9==0{i%half}else{0}};let k=(i*17+i/128)%points.len();let negative=i%3==0;selected.push(points[k]);indices.push(b as u32|if negative{1<<31}else{0});let p=ark[k];if negative{expected[b]-=p}else{expected[b]+=p}}
 let immutable=selected.clone();let want:Vec<_>=P::normalize_batch(&expected).into_iter().map(convert).collect();let (old,_)=zopro_core::two_bank_probe(&selected,&indices,half,cap,false);assert_eq!(old,want,"old {half}/{cap}/{pattern}");let (new,stats)=zopro_core::two_bank_probe(&selected,&indices,half,cap,true);assert_eq!(new,want,"new {half}/{cap}/{pattern}");assert_eq!(selected,immutable);stats
}
fn main(){let(ark,points)=fixture();let mut counts=[0u64;6];let mut cases=0;let mut add=|s:[u64;6]|{for i in 0..6{counts[i]+=s[i];}cases+=1;};
 for half in[1,63,65,2048,4096]{for cap in[8,200,352]{for pattern in 0..4{add(case(half,cap,pattern,&ark,&points));}}}
 for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();for v in pool.broadcast(|c|case(65,32,c.index()%4,&ark,&points)){add(v);}}
 let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();let outputs=std::thread::scope(|scope|{let mut handles=Vec::new();for i in 0..4{let pool=&pool;let ark=&ark;let points=&points;handles.push(scope.spawn(move||pool.install(||case(65,32,i,ark,points))));}handles.into_iter().map(|h|h.join().unwrap()).collect::<Vec<_>>()});for v in outputs{add(v);}drop(add);
 for on in[false,true]{assert_eq!(zopro_core::two_bank_probe(&[],&[],65,32,on).0,vec![Z::IDENTITY;65]);}assert_eq!(cases,117);assert!(counts.iter().all(|&n|n>0));println!("{}",json!({"passed":true,"nonempty_cases":cases,"empty_cases":2,"native_counts":{"secondary_routes":counts[0],"queued":counts[1],"flushes":counts[2],"same_x":counts[3],"inverse_points":counts[4],"skipped_identities":counts[5]},"oracle":"independent Arkworks complete signed bucket sums","input_points_unchanged":true,"new_proofs":0}));}
