use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-parent176";
const PREVIOUS: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
fn read(p: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(p).unwrap()).unwrap() }
fn hash(p: impl AsRef<Path>) -> String { format!("{:x}", Sha256::digest(fs::read(p).unwrap())) }
include!("/home/ubuntu/src/zopro-perf-work/phi-grain-clean176/statistics.rs");
fn main() {
    let r=Path::new(ROOT);let p=Path::new(PREVIOUS);
    let review=read(p.join("remote-review.json"));assert_eq!(review["status"],"PASS");assert_eq!(review["canonical_verified_exports"],50752);
    let a=read(p.join("target-analysis.json"));let raw=read(p.join("remote-results/output/measure/rows.json"));
    let mut latency=BTreeMap::new();let mut cpu=BTreeMap::new();let mut rss=BTreeMap::<(String,String),f64>::new();
    let mut pins=BTreeMap::new();
    for f in ["target-analysis.json","remote-review.json","remote-results/output/measure/rows.json","statistics.rs","proof-sha256-after-capture.json"] {pins.insert(p.join(f).display().to_string(),hash(p.join(f)));}
    for row in raw.as_array().unwrap().iter().filter(|v|v["job"]["panel"]=="latency") {
        let j=&row["job"];let ctx=j["case"]["name"].as_str().unwrap().to_owned();let arm=j["arm"].as_str().unwrap().to_owned();let b=j["block"].as_u64().unwrap() as usize;let n=j["rounds"].as_u64().unwrap();let u=&row["usage"];
        assert!(latency.insert((ctx.clone(),arm.clone(),b),row["mean_ns"].as_f64().unwrap()/1e6).is_none());
        assert!(cpu.insert((ctx.clone(),arm.clone(),b),(u["user_cpu_ms"].as_f64().unwrap()+u["system_cpu_ms"].as_f64().unwrap())/n as f64).is_none());
        rss.entry((ctx,arm)).and_modify(|v|*v=v.max(u["whole_process_maxrss_kib"].as_f64().unwrap()/1024.)).or_insert(u["whole_process_maxrss_kib"].as_f64().unwrap()/1024.);
    }
    assert_eq!(latency.len(),351);let mut contexts=vec![];
    for m in a["medians"].as_array().unwrap().iter().filter(|v|v["arm"]=="PARENT"){
        let ctx=m["context"].as_str().unwrap();let get=|arm:&str,values:&BTreeMap<(String,String,usize),f64>|median9((0..9).map(|b|values[&(ctx.into(),arm.into(),b)]).collect());
        assert!((get("PARENT",&latency)-m["ms"].as_f64().unwrap()).abs()<1e-9);
        contexts.push(json!({"context":ctx,"shape":m["shape"],"workers":m["workers"],"PARENT_ms":get("PARENT",&latency),"REF_ms":get("REF",&latency),"latency":paired9(&latency,ctx,"PARENT","REF"),"CPU":paired9(&cpu,ctx,"PARENT","REF"),"PARENT_maxRSS_MiB":rss[&(ctx.into(),"PARENT".into())],"REF_maxRSS_MiB":rss[&(ctx.into(),"REF".into())]}));
    }
    assert_eq!(contexts.len(),13);
    let output=json!({"analysis":"Retrospective PARENT-versus-REF comparison of retained validated control measurements","new_adoption_gates_passed":false,"original_CLEAN_qualification_unchanged":true,"interval":"ranks1/7 of9;nominal96.09375% marginal under independent exchangeable blocks;no joint/stationarity guarantee","contexts":contexts,"input_sha256":pins,"new_SDK_calls":0,"new_exported_proofs":0,"new_crypto_verifications":0,"canonical_verified_exports":50752,"next":"Inventory missing exact-candidate adoption requirements; do not retroactively qualify control comparisons"});
    assert!(!r.join("retrospective.json").exists());fs::write(r.join("retrospective.json"),serde_json::to_vec_pretty(&output).unwrap()).unwrap();
    for row in output["contexts"].as_array().unwrap(){println!("{}: {:.6}->{:.6}ms latency ratio {:.6} [{:.6},{:.6}], CPU {:.6}, RSS {:.2}/{:.2}MiB",row["context"].as_str().unwrap(),row["REF_ms"].as_f64().unwrap(),row["PARENT_ms"].as_f64().unwrap(),row["latency"]["median"].as_f64().unwrap(),row["latency"]["lower"].as_f64().unwrap(),row["latency"]["upper"].as_f64().unwrap(),row["CPU"]["median"].as_f64().unwrap(),row["PARENT_maxRSS_MiB"].as_f64().unwrap(),row["REF_maxRSS_MiB"].as_f64().unwrap());}
}
