use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{fs,path::Path,process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/phi-grain-parent176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(p:impl AsRef<Path>,v:Value){assert!(!p.as_ref().exists());fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap()}
fn main(){match std::env::args().nth(1).as_deref(){
Some("cases")=>{
 let full="avx512ifma,avx512vl,avx512dq";
 let cases=[("native-linux","x86_64",full,true,false,"linux",false,false,true),("native-metal","x86_64",full,true,false,"macos",true,true,true),("native-wgpu","x86_64",full,true,false,"linux",false,true,true),("native-optout","x86_64",full,true,true,"linux",false,false,false),("no-ifma8","x86_64",full,false,false,"linux",false,false,false),("missing-vl","x86_64","avx512ifma,avx512dq",true,false,"linux",false,false,false),("missing-dq","x86_64","avx512ifma,avx512vl",true,false,"linux",false,false,false),("generic-x86","x86_64","",true,false,"linux",false,false,false),("arm-selector","aarch64","neon",true,false,"ios",true,false,false),("wasm-selector","wasm32","",true,false,"unknown",false,true,false)];
 let mut rows=vec![];
 for(name,arch,features,ifma8,disabled,os,metal,wgpu,expected)in cases {
  let mut outputs=vec![];for arm in["before","after"]{let binary=format!("{R}/selector-{arm}");let mut env=serde_json::Map::new();env.insert("CARGO_CFG_TARGET_ARCH".into(),arch.into());env.insert("CARGO_CFG_TARGET_FEATURE".into(),features.into());env.insert("CARGO_CFG_TARGET_OS".into(),os.into());for(k,on)in[("CARGO_FEATURE_IFMA8",ifma8),("CARGO_CFG_NO_IFMA",disabled),("CARGO_FEATURE_METAL",metal),("CARGO_FEATURE_WGPU",wgpu)]{if on{env.insert(k.into(),"1".into());}}
   let mut command=Command::new(&binary);command.env_clear();for(k,v)in&env{command.env(k,v.as_str().unwrap());}let out=command.output().unwrap();assert!(out.status.success());let stdout=String::from_utf8(out.stdout).unwrap();let stderr=String::from_utf8(out.stderr).unwrap();assert!(stderr.is_empty());outputs.push(json!({"binary":binary,"binary_sha256":hash(&binary),"environment":env,"stdout":stdout,"stderr":stderr,"exit_code":out.status.code()}));
  }
  let old=outputs[0]["stdout"].as_str().unwrap();let new=outputs[1]["stdout"].as_str().unwrap();assert_eq!(new.lines().filter(|l|!l.contains("zopro_phi_grain")).collect::<Vec<_>>(),old.lines().collect::<Vec<_>>());let actual=new.lines().filter(|l|*l=="cargo::rustc-cfg=zopro_phi_grain").count();assert_eq!(actual,usize::from(expected));assert_eq!(new.lines().filter(|l|*l=="cargo::rustc-check-cfg=cfg(zopro_phi_grain)").count(),1);rows.push(json!({"name":name,"expected_phi":expected,"selected_phi":actual==1,"existing_dense_and_GPU_output_preserved":true,"commands":outputs}));
 }
 save(format!("{R}/selection-cases.json"),json!({"passed":true,"cases":10,"rows":rows,"physical_ARM_or_GPU_execution":false}));println!("PASS10selectorcontexts;nativephi/defaultoptout/generic/ARM/wasm/GPU selectionpreserved;noSDKcalls");
},
Some("cargo")=>{
 let path=format!("{R}/selection-runs/actual-Cargo-native-default-selection/stdout.log");let text=fs::read_to_string(&path).unwrap();let events=text.lines().filter_map(|l|serde_json::from_str::<Value>(l).ok()).collect::<Vec<_>>();let matching=events.iter().filter(|v|v["reason"]=="build-script-executed"&&v["package_id"].as_str().unwrap_or("").contains("zopro-core")&&v["cfgs"].as_array().is_some_and(|a|a.iter().any(|v|v=="zopro_phi_grain"))).count();assert_eq!(matching,1);assert!(events.iter().any(|v|v["reason"]=="compiler-artifact"&&v["target"]["name"]=="zopro_core"));assert!(events.iter().any(|v|v["reason"]=="build-finished"&&v["success"]==true));let plan=read(format!("{R}/selection-plan.json"));let cmd=plan["steps"].as_array().unwrap().iter().find(|v|v["name"]=="actual-Cargo-native-default-selection").unwrap();assert!(!cmd["environment"]["CARGO_ENCODED_RUSTFLAGS"].as_str().unwrap().contains("zopro_phi_grain"));save(format!("{R}/selection-cargo.json"),json!({"passed":true,"Cargo_selected_phi_without_explicit_flag":true,"core_artifact_typechecked":true,"SDK_latency_or_new_release_SDK_claim":false,"Cargo_stdout_sha256":hash(path)}));println!("PASSactualCargo native core defaultphi selected withoutmanualphi flag;type/build evidenceonly");
},_=>panic!("cases|cargo")}}
