use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-parent176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn main() {
    let r = Path::new(R);
    let z = Path::new(Z);
    assert!(!r.join("decision.json").exists());
    let review = read(r.join("remote-review.json"));
    assert_eq!(review["status"], "PASS");
    assert_eq!(review["canonical_verified_exports"], 51586);
    assert_eq!(
        read(r.join("proof-sha256-after-capture.json"))
            .as_array()
            .unwrap()
            .len(),
        51586
    );
    let analysis = read(r.join("target-analysis.json"));
    assert_eq!(analysis["qualification_passed"], true);
    let gates = analysis["gates"].as_array().unwrap();
    assert_eq!(gates.len(), 40);
    assert!(gates.iter().all(|g| g["pass"] == true));
    let raw = read(r.join("remote-results/output/measure/rows.json"));
    let mut metrics = BTreeMap::new();
    for row in raw
        .as_array()
        .unwrap()
        .iter()
        .filter(|v| v["job"]["panel"] == "latency")
    {
        let j = &row["job"];
        let u = &row["usage"];
        let key = (
            j["case"]["name"].as_str().unwrap().to_owned(),
            j["arm"].as_str().unwrap().to_owned(),
            j["block"].as_u64().unwrap() as usize,
        );
        let n = j["rounds"].as_u64().unwrap() as f64;
        assert!(metrics
            .insert(
                key,
                (
                    row["mean_ns"].as_f64().unwrap() / 1e6,
                    (u["user_cpu_ms"].as_f64().unwrap() + u["system_cpu_ms"].as_f64().unwrap()) / n,
                    u["whole_process_maxrss_kib"].as_f64().unwrap() / 1024.
                )
            )
            .is_none());
    }
    assert_eq!(metrics.len(), 806);
    for g in gates {
        let ctx = g["context"].as_str().unwrap();
        let kind = g["kind"].as_str().unwrap();
        if kind == "RSS" {
            let max = |arm: &str| {
                (0..31)
                    .map(|b| metrics[&(ctx.into(), arm.into(), b)].2)
                    .fold(0., f64::max)
            };
            let parent = max("PARENT");
            let limit = max("REF") * 1.05 + 1.;
            assert_eq!(g["PARENT_mib"], parent);
            assert_eq!(g["limit_mib"], limit);
            assert!(parent <= limit);
        } else {
            assert_eq!(g["ratio"], "PARENT/REF");
            let mut v = (0..31)
                .map(|b| {
                    let a = metrics[&(ctx.into(), "PARENT".into(), b)];
                    let d = metrics[&(ctx.into(), "REF".into(), b)];
                    if kind == "CPU" {
                        a.1 / d.1
                    } else {
                        a.0 / d.0
                    }
                })
                .collect::<Vec<_>>();
            assert_eq!(g["wins"], v.iter().filter(|&&v| v < 1.).count());
            v.sort_by(f64::total_cmp);
            for (k, i) in [("lower", 9), ("median", 15), ("upper", 21)] {
                assert!((v[i] - g[k].as_f64().unwrap()).abs() < 1e-12);
            }
            assert!(if kind == "primary96_gain" {
                v[21] < 1.
            } else {
                v[21] <= 1.02
            });
        }
    }
    assert_eq!(read(r.join("selection-cases.json"))["passed"], true);
    assert_eq!(read(r.join("selection-cargo.json"))["passed"], true);
    assert_eq!(
        read(r.join("release-review.json"))["status"],
        "PASS_before_performance_qualification"
    );
    let source = read(r.join("source-review.json"));
    let originals = source["originals"].as_object().unwrap();
    let promoted = source["promotion_source_sha256"].as_object().unwrap();
    assert_eq!(originals.len(), 176);
    assert_eq!(promoted.len(), 176);
    let mut changes = vec![];
    for (rel, h) in originals {
        assert_eq!(hash(z.join(rel)), h.as_str().unwrap());
        assert_eq!(
            hash(r.join("promotion-source").join(rel)),
            promoted[rel].as_str().unwrap()
        );
        if h != &promoted[rel] {
            changes.push(rel.clone());
        }
    }
    changes.sort();
    assert_eq!(
        changes,
        vec![
            "crates/zopro-core/build.rs",
            "crates/zopro-core/src/msm_affine/g2_phi.rs"
        ]
    );
    let g2 = "crates/zopro-core/src/msm_affine/g2_phi.rs";
    assert_eq!(
        hash(r.join("promotion-source").join(g2)),
        hash(Path::new("/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176/source").join(g2))
    );
    // Verify the only build-script changes are registration/emission and its comment.
    let before = fs::read_to_string(z.join("crates/zopro-core/build.rs")).unwrap();
    let after = fs::read_to_string(r.join("promotion-source/crates/zopro-core/build.rs")).unwrap();
    let recovered=after.replace("    // Select the measured native IFMA paths.\n    println!(\"cargo::rustc-check-cfg=cfg(zopro_phi_grain)\");","    // Select the measured borrowed-window metadata path on native IFMA builds.").replace("\n        println!(\"cargo::rustc-cfg=zopro_phi_grain\");","");
    assert_eq!(recovered, before);
    for rel in &changes {
        let backup = r.join("before").join(rel);
        fs::create_dir_all(backup.parent().unwrap()).unwrap();
        fs::copy(z.join(rel), backup).unwrap();
    }
    let mut copied = vec![];
    for rel in &changes {
        if let Err(e) = fs::copy(r.join("promotion-source").join(rel), z.join(rel)) {
            for prior in &copied {
                fs::copy(r.join("before").join(prior), z.join(prior)).unwrap();
            }
            panic!("promotion copy failed, prior writes restored:{e}");
        }
        copied.push(rel.clone());
    }
    for (rel, h) in promoted {
        assert_eq!(hash(z.join(rel)), h.as_str().unwrap());
    }
    let sdk = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176/sdk-candidate-znver4";
    assert_eq!(
        hash(sdk),
        "c88a3528d5feb363732dd2557d1894c93e9161f4e3ec9e9d3c7e2564283bf2fe"
    );
    let flags =
        fs::read_to_string("/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176/candidate-flags.txt")
            .unwrap();
    let decision = json!({"adopted":true,"candidate":"g2-phi-grain-experimental176","performance_gates_passed":40,"performance_gates_required":40,"independent_producer_gate_recheck":true,"raw_samples_and832transport_proofs_checked":true,"source_files":176,"changed_originals":2,"unchanged_originals":174,"runtime_g2_file_byte_exact_to_measured_parent":true,"only_additional_change":"native build-script cfg registration/emission plus comment","ten_selector_cases_passed":true,"Cargo_phi_selected_without_explicit_phi":true,"native_generic_tests_inherited":true,"functional_concurrency_inherited_cases":3,"new_concurrent_throughput_claim":false,"new_SDK_build_for_promotion":false,"new_proofs_for_promotion":0,"canonical_verified_exports":51586,"canonical_ledger_sha256":hash(r.join("proof-sha256-after-capture.json")),"all8_CPU10x_goal_complete":false,"performance_scope":"C7a exact measured hand-linked znver4 SDK;Cargo default activation type-checked,not newly timed","historical_CLEAN_failure_unchanged":true});
    save(r.join("decision.json"), decision.clone());
    let old="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json";
    let manifest = json!({"source_files_sha256":promoted,"source_snapshot":r.join("promotion-source"),"adopted":true,"adoption_kind":"Exact measured experimental runtime plus native default cfg selector","source_changes":changes,"previous_accepted_manifest":old,"previous_accepted_manifest_sha256":hash(old),"native_binary":sdk,"native_binary_sha256":hash(sdk),"native_binary_interface":"cpu-sdk IMAGE REQUEST_JSON ROUNDS [PROOF_DIRECTORY]","rustflags":flags.trim(),"native_build_source_snapshot":"/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176/source","native_build_source_mapping":{"g2_runtime_file_exact":true,"only_additional_build_script_selection":true,"Cargo_default_check_not_new_release_SDK_timing":true},"Cargo_default_cfg_selection":{"cfg":"zopro_phi_grain","targets":"x86_64+ifma8+avx512ifma/vl/dq without no_ifma","ten_contexts_passed":true,"actual_Cargo_check_passed":true,"flag_not_explicitly_passed_to_Cargo_check":true},"decision":r.join("decision.json"),"decision_sha256":hash(r.join("decision.json")),"performance_protocol":r.join("protocol.md"),"performance_protocol_sha256":hash(r.join("protocol.md")),"performance_result":r.join("target-analysis.json"),"performance_result_sha256":hash(r.join("target-analysis.json")),"final_performance_report":"zopro/docs/benchmarks/2026-11-11-phi-grain-parent176/README.md","full_performance_gate_passed":true,"resource_qualification_passed":true,"qualification_scope":"inherited native/generic tests and3functionalconcurrency cases;10finite emitter cases+actualCargo;13context31block40gateC7a;832freshGnark target proofs+transport rechecks","proof_ledger":51586,"proof_ledger_path":r.join("proof-sha256-after-capture.json"),"proof_ledger_sha256":hash(r.join("proof-sha256-after-capture.json")),"ms":analysis["all8"],"original8_CPU10x_rows":analysis["all8"],"goal_achieved":false,"goal_targets_met":0,"goal_status":"unmet;continue research","limitations":["Exact hand-linked znver4 SDK timings on C7a;default Cargo selection type-checked,not newly release-timed","No fresh Aeglos/local-speed/phone/ARM/TEE/hugecircuit/pressure/swap/minRAM/concurrentthroughput measurement","Earlier failed default variant remains separate and unadopted"]});
    save(r.join("production-source-manifest.json"), manifest);
    save(
        r.join("post-adoption-review.json"),
        json!({"passed":true,"source_files_rechecked":176,"unchanged_originals":174,"explicit_changes":2,"measured_runtime_hash_preserved":true,"default_selector_reviewed":true,"historical_originals_saved":r.join("before"),"new_qualification_or_proof_replay":false,"adopted":true,"canonical_verified_exports":51586,"goal_complete":false}),
    );
    println!("ADOPTED exactexperimentalruntime+nativecfgselector;40of40PASS;176sources174unchanged+2explicit;no newSDK/proofs;canonical51586");
}
