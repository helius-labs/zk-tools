const BLOCKS: usize = 31;
const LOWER: usize = 9;
const UPPER: usize = 21;
fn median31(mut values: Vec<f64>) -> f64 {
    assert_eq!(values.len(), BLOCKS);
    assert!(values.iter().all(|v|v.is_finite()));
    values.sort_by(f64::total_cmp);
    values[15]
}
fn paired31(values:&BTreeMap<(String,String,usize),f64>,context:&str,a:&str,b:&str)->Value {
    let mut ratios=vec![];let mut savings=vec![];
    for block in 0..BLOCKS {let n=values[&(context.into(),a.into(),block)];let d=values[&(context.into(),b.into(),block)];assert!(n>0.&&d>0.&&n.is_finite()&&d.is_finite());ratios.push(n/d);savings.push(d-n);}
    let wins=ratios.iter().filter(|&&v|v<1.).count();ratios.sort_by(f64::total_cmp);
    json!({"context":context,"ratio":format!("{a}/{b}"),"lower":ratios[LOWER],"median":ratios[15],"upper":ratios[UPPER],"wins":wins,"paired_median_saving":median31(savings)})
}
fn statistical_models(){
    let mut m=BTreeMap::new();
    for b in 0..BLOCKS {for a in["A","B"]{m.insert(("ties".into(),a.into(),b),2.);}m.insert(("reverse".into(),"A".into(),b),(31-b)as f64);m.insert(("reverse".into(),"B".into(),b),(b+1)as f64);m.insert(("other-same-workers".into(),"A".into(),b),4.);m.insert(("other-same-workers".into(),"B".into(),b),2.);}
    let ties=paired31(&m,"ties","A","B");for k in["lower","median","upper"]{assert_eq!(ties[k],1.);}assert_eq!(ties["wins"],0);
    let r=paired31(&m,"reverse","A","B");assert_eq!(r["lower"],10./22.);assert_eq!(r["median"],1.);assert_eq!(r["upper"],22./10.);assert_eq!(paired31(&m,"other-same-workers","A","B")["median"],2.);
    let mut pascal=vec![1u64];for _ in 0..31 {let mut next=vec![1];for pair in pascal.windows(2){next.push(pair[0]+pair[1]);}next.push(1);pascal=next;}
    let tail_pascal=pascal[..=LOWER].iter().sum::<u64>();let mut choose=1u64;let mut tail_independent=1;for k in 1..=LOWER {choose=choose*(32-k)as u64/k as u64;tail_independent+=choose;}assert_eq!(tail_pascal,tail_independent);assert_eq!(LOWER+UPPER,30);
    let coverage=1.-2.*tail_pascal as f64/(1u64<<31)as f64;assert!(coverage>0.96&&coverage<0.98);
    println!("PASS4models31:ties,nonproportionalpairing,contextisolation,independentbinomial;coverage={:.12}% ranks9/21",coverage*100.);
}
