# Exact parent adoption follow-up

Continue the pending experimental candidate c88a3528, preserving its measured
runtime source and native/generic qualification. The failed unconditional CLEAN
campaign remains closed and unchanged. Retrospective all-shape PARENT control
analysis is review evidence, not new passed gates. New protocol.md declares
31blocks/two retained consumers/all13contexts/40gates before any new preflight.
Default activation is a separate native build-script selector, following the
prior busy-reset promotion. Inherit functional concurrency with source review;
do not claim new throughput, ARM/phone, memory-pressure or minimum-RAM evidence.
No new prover/SDK build, runtime rewrite, table/buffer/pool or RAMcap. Reuse the
known measured artifacts and current verified ledger50752. Local harness smoke
adds2exports/8calls; target832exports/57268calls; futurefinal51586 ifverified.
Report/commitANDpush each experiment and retain separate candidate decisions.
FullALL8verifiedCPU10x+Metal objective unchanged/unmet0of8; no budget.
