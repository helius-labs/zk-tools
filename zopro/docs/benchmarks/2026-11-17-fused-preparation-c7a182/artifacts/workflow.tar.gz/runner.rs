use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::Path,
    process::Command,
};
mod validate;
const R: &str = "/output/fused-preparation-c7a182";
const I: &str = "/cr-detail";
const SEED: &str = "2721a5c49351ae5dea2fdf91c3889d99a3f48619ee22fc520b5e36adfdeb3b23";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(n: &str, v: Value) {
    let p = format!("{R}/{n}");
    assert!(!Path::new(&p).exists(), "already exists: {p}");
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn mean(v: &[f64]) -> f64 {
    assert!(!v.is_empty());
    assert!(v.iter().all(|v| v.is_finite()));
    v.iter().sum::<f64>() / v.len() as f64
}
fn median(v: &[f64]) -> f64 {
    let mut v = v.to_vec();
    v.sort_by(f64::total_cmp);
    v[v.len() / 2]
}
fn state() -> Value {
    let mut m = BTreeMap::new();
    for p in [
        "/proc/loadavg",
        "/proc/meminfo",
        "/proc/swaps",
        "/proc/vmstat",
        "/proc/stat",
        "/proc/pressure/cpu",
        "/proc/pressure/memory",
        "/proc/pressure/io",
        "/proc/self/cgroup",
        "/sys/fs/cgroup/cpu.max","/sys/fs/cgroup/cpu.stat","/sys/fs/cgroup/memory.max","/sys/fs/cgroup/memory.events","/sys/fs/cgroup/memory.swap.max","/sys/fs/cgroup/memory.swap.events","/sys/fs/cgroup/memory.peak",
    ] {
        if let Ok(s) = fs::read_to_string(p) {
            m.insert(p, s);
        }
    }
    json!(m)
}
fn verify_pins() {
    for (p, h) in read(format!("{R}/pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap(), "{p}");
    }
}
fn prepare(smoke:bool) {
    save("mode.json",json!({"smoke":smoke}));
    assert_eq!(hash(format!("{I}/seed.json")), SEED);
    let original = read(format!("{I}/preflight-jobs.json"));
    let plan = read(format!("{I}/preflight-plan.json"));
    let mut pins = read(format!("{I}/preflight-pins.json"))
        .as_object()
        .unwrap()
        .clone();
    for (p, h) in &pins {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let mut jobs = vec![];
    let mut steps = vec![];
    let mut late = vec![];
    let mut add = |workers: usize, block: usize, panel: &str, mode: &str, arm: &str| {
        let base_name = format!("{mode}-{arm}");
        let orig = original
            .as_array()
            .unwrap()
            .iter()
            .find(|j| j["name"] == base_name)
            .unwrap();
        let mut j = orig.clone();
        let name = format!("{panel}-w{workers}-{base_name}-b{block:02}");
        let dir = format!("{R}/proofs/{name}/transfer_confidential_1_2");
        let rounds = if panel == "preflight" { 1 } else { 51 };
        j["name"] = json!(name);
        j["proof_dir"] = json!(dir);
        j["workers"] = json!(workers);
        j["rounds"] = json!(rounds);
        j["block"] = json!(block);
        j["panel"] = json!(panel);
        let binary=format!("{R}/bins/{}{}",if mode=="sorted" {"aeglos"} else if arm=="REF" {"ref"} else {"diag"},block%3);
        j["binary"]=json!(binary);j["backing"]=json!(block%3);j["binary_sha256"]=json!(hash(&binary));
        let mut step = plan["steps"]
            .as_array()
            .unwrap()
            .iter()
            .find(|s| s["name"] == base_name)
            .unwrap()
            .clone();
        step["name"] = json!(name);
        step["argv"][3]=json!(binary);
        step["argv"][2] = json!(format!("0-{}", workers - 1));
        step["environment"]["RAYON_NUM_THREADS"] = json!(workers.to_string());
        if mode == "zopro" {
            step["environment"]["ZOPRO_BENCH_FUSED_PREPARATION"]=json!(if arm=="ON"{"1"}else{"0"});
            step["environment"]["ZOPRO_BENCH_MSM_PHASES"]=json!("0");
            step["argv"][6] = json!(rounds.to_string());
            step["argv"][7] = json!(dir);
        } else {
            step["argv"][7] = json!(rounds.to_string());
            step["environment"]["AEGLOS_CPU_THREADS"] = json!(workers.to_string());
            step["environment"]["GOMAXPROCS"] = json!(workers.to_string());
            step["environment"]["ZOPRO_BENCH_PROOFS"] = json!(format!("{R}/proofs/{name}"));
        }
        let mut verify = plan["steps"]
            .as_array()
            .unwrap()
            .iter()
            .find(|s| s["name"] == format!("verify-{base_name}"))
            .unwrap()
            .clone();
        verify["name"] = json!(format!("verify-{name}"));
        verify["argv"][3] = json!(format!("{dir}/0.proof"));
        verify["argv"][4] = json!(format!("{dir}/0.public"));
        let inspect = json!({"kind":"command","name":format!("inspect-{name}"),"argv":["/usr/local/bin/detail-runner".to_owned(),"inspect",name],"timeout_seconds":60});
        jobs.push(j);
        steps.push(step);
        if panel == "preflight" {
            steps.extend([verify, inspect]);
        } else {
            late.extend([verify, inspect]);
        }
    };
    if smoke {for(mode,arm)in [("zopro","OFF"),("zopro","ON"),("sorted","REF")]{add(4,0,"preflight",mode,arm);}}else{for w in [32,96]{for(mode,arm)in [("zopro","REF"),("zopro","OFF"),("zopro","ON"),("sorted","REF")]{add(w,0,"preflight",mode,arm);}}}
    for block in 0..if smoke {0}else{9} {
        let mut counts = [32, 96];
        if block % 2 == 1 {
            counts.reverse();
        }
        let mut modes = ["zopro","sorted"];
        modes.rotate_left(block%2);
        if block % 2 == 1 {
            modes.reverse();
        }
        for mode in modes {
            let mut arms = if mode == "zopro" {
                vec!["REF", "OFF", "ON"]
            } else {
                vec!["REF"]
            };
            let n = arms.len();
            arms.rotate_left(block % n);
            if block % 2 == 1 {
                arms.reverse();
            }
            for w in counts {
                for arm in &arms {
                    add(w, block, "main", mode, arm);
                }
            }
        }
    }
    drop(add);
    assert_eq!(jobs.len(), if smoke {3}else{80});
    assert_eq!(
        jobs.iter()
            .map(|j| j["rounds"].as_u64().unwrap() + 3)
            .sum::<u64>(),
        if smoke {12}else{3920}
    );
    steps.push(json!({"kind":"command","name":"after-capture-state","argv":["/usr/local/bin/detail-runner".to_owned(),"snapshot","after"],"timeout_seconds":60}));
    steps.extend(late);
    steps.push(json!({"kind":"command","name":"review","argv":["/usr/local/bin/detail-runner".to_owned(),"review"],"timeout_seconds":120}));
    save("jobs.json", json!(jobs));
    for p in [
        "/usr/local/bin/detail-runner".to_owned(),
        format!("{I}/runner.rs"),
        format!("{I}/validate.rs"),
        format!("{I}/generate.rs"),
        format!("{I}/protocol.md"),
        format!("{R}/jobs.json"),
        format!("{I}/seed.json"),
        format!("{I}/preflight-plan.json"),
    ] {
        pins.insert(p.clone(), json!(hash(p)));
    }
    save("pins.json", json!(pins));
    save(
        "plan.json",
        json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps}),
    );
    println!("Frozen80processes3920SDKcalls; targetbranch56502->56582; no capture yet");
}
fn review(){verify_pins();let smoke=read(format!("{R}/mode.json"))["smoke"]==true;let mut ledger:BTreeSet<String>=serde_json::from_value(read(format!("{I}/seed.json"))).unwrap();assert_eq!(ledger.len(),56502);let jobs=read(format!("{R}/jobs.json"));let mut rows=vec![];for j in jobs.as_array().unwrap(){let v=read(format!("{R}/checks/{}.json",j["name"].as_str().unwrap()));assert_eq!(v["passed"],true);assert!(ledger.insert(v["proof_sha256"].as_str().unwrap().into()));if j["panel"]!="main"{continue;}let times=v["samples"].as_array().unwrap().iter().map(|s|s[if j["engine"]=="zopro"{"ms"}else{"verified_ms"}].as_f64().unwrap()).collect::<Vec<_>>();let summary=&v["summary"];rows.push(json!({"job":j,"median_ms":median(&times),"mean_ms":mean(&times),"summary":summary,"cpu_ms":(summary["user_cpu_ms"].as_f64().unwrap()+summary["system_cpu_ms"].as_f64().unwrap())/51.,"rss_mib":summary["whole_process_maxrss_kib"].as_f64().unwrap()/1024.}));}
assert_eq!(ledger.len(),if smoke{56505}else{56582});let output=if smoke{"proof-sha256-after-smoke.json"}else{"proof-sha256-after-capture.json"};save(output,json!(ledger));if smoke{save("smoke-complete.json",json!({"status":"complete","exports":3,"sdk_calls":12,"canonical_count":56505,"canonical_sha256":hash(format!("{R}/{output}"))}));return;}
let mut comparisons=vec![];let mut contexts=vec![];let mut guards=vec![];let mut scaling=vec![];
for w in [32,96]{let get=|mode:&str,arm:&str,b:usize|rows.iter().find(|r|r["job"]["mode"]==mode&&r["job"]["arm"]==arm&&r["job"]["workers"]==w&&r["job"]["block"]==b).unwrap();
for(mode,arm)in[("zopro","REF"),("zopro","OFF"),("zopro","ON"),("sorted","REF")]{let vals=|k:&str|(0..9).map(|b|get(mode,arm,b)[k].as_f64().unwrap()).collect::<Vec<_>>();contexts.push(json!({"workers":w,"mode":mode,"arm":arm,"median_ms":median(&vals("median_ms")),"mean_cpu_ms":mean(&vals("cpu_ms")),"peak_rss_mib":vals("rss_mib").into_iter().fold(0.,f64::max)}));}
for(nm,na,dm,da)in[("zopro","ON","zopro","REF"),("zopro","ON","zopro","OFF"),("zopro","OFF","zopro","REF"),("sorted","REF","zopro","ON")]{for metric in["median_ms","cpu_ms"]{let ratios=(0..9).map(|b|get(nm,na,b)[metric].as_f64().unwrap()/get(dm,da,b)[metric].as_f64().unwrap()).collect::<Vec<_>>();let mut sorted=ratios.clone();sorted.sort_by(f64::total_cmp);let bycopy=(0..3).map(|c|json!({"copy":c,"median":median(&(c..9).step_by(3).map(|b|ratios[b]).collect::<Vec<_>>())})).collect::<Vec<_>>();comparisons.push(json!({"workers":w,"numerator":format!("{nm}-{na}"),"denominator":format!("{dm}-{da}"),"metric":metric,"median":median(&ratios),"interval":[sorted[1],sorted[7]],"wins":ratios.iter().filter(|&&r|r<1.).count(),"block_ratios":ratios,"backings":bycopy}));if nm=="zopro"&&na=="ON"{guards.push(json!({"workers":w,"comparator":da,"metric":metric,"upper":sorted[7],"passed":sorted[7]<=1.02}));}}
if nm=="zopro"&&na=="ON"{let peak=|m:&str,a:&str|(0..9).map(|b|get(m,a,b)["rss_mib"].as_f64().unwrap()).fold(0.,f64::max);let a=peak(nm,na);let b=peak(dm,da);guards.push(json!({"workers":w,"comparator":da,"metric":"peak_rss_mib","ON":a,"control":b,"passed":a<=b*1.05+1.}));}}
}
for(mode,arm)in[("zopro","REF"),("zopro","OFF"),("zopro","ON"),("sorted","REF")]{let ratios=(0..9).map(|b|{let get=|w|rows.iter().find(|r|r["job"]["mode"]==mode&&r["job"]["arm"]==arm&&r["job"]["workers"]==w&&r["job"]["block"]==b).unwrap()["median_ms"].as_f64().unwrap();get(96)/get(32)}).collect::<Vec<_>>();scaling.push(json!({"mode":mode,"arm":arm,"median_96_over_32":median(&ratios),"block_ratios":ratios}));}
save("rows.json",json!(rows));save("review.json",json!({"status":"complete","exports":80,"sdk_calls":3920,"canonical_count":56582,"canonical_sha256":hash(format!("{R}/{output}")),"contexts":contexts,"comparisons":comparisons,"scaling":scaling,"gates":guards,"all_gates_pass":guards.iter().all(|g|g["passed"]==true)}));}
fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    match args[1].as_str() {
        "smoke" => execute(true),
        "measure" => execute(false),
        "inspect" => {
            let v = validate::inspect(&args[2]);
            fs::create_dir_all(format!("{R}/checks")).unwrap();
            save(&format!("checks/{}.json", args[2]), v);
        }
        "snapshot" => {
            snapshot(&args[2]);
            if args[2] == "before" {
                let o = Command::new("lscpu")
                    .args(["-p=CPU,CORE,SOCKET,ONLINE"])
                    .output()
                    .unwrap();
                assert!(o.status.success());
                fs::write(format!("{R}/topology.csv"), o.stdout).unwrap();
            }
        }
        "review" => {review(); if read(format!("{R}/mode.json"))["smoke"]==false {extended_review();}},
        _ => panic!("unknown operation"),
    }
}

fn detail_metrics(p:&Value,s:&mut BTreeMap<String,f64>){
 let rows=p["rows"].as_array().unwrap();let b=|i:usize|rows[i]["begin_ns"].as_u64().unwrap();let e=|i:usize|rows[i]["end_ns"].as_u64().unwrap();
 let last_g1=e(4).max(e(5));let last_window=(19..30).map(e).max().unwrap();let last_part=(30..52).map(e).max().unwrap();
 s.insert("g2_late_callback".into(),e(6).saturating_sub(last_g1) as f64/1e6);
 s.insert("g2_collection_after_last_window".into(),(e(17)-last_window)as f64/1e6);
 s.insert("g2_collection_after_last_part".into(),(e(17)-last_part)as f64/1e6);
 s.insert("g2_late_collection_return_gap".into(),e(17).saturating_sub(last_window.max(last_g1))as f64/1e6);
 s.insert("g2_window_late_work_span".into(),last_window.saturating_sub(last_g1)as f64/1e6);
 s.insert("gather_span".into(),(e(12).max(e(13))-b(12).min(b(13)))as f64/1e6);
 let late_window=(19..30).max_by_key(|&i|e(i)).unwrap();s.insert("last_window_index".into(),(late_window-19)as f64);
 let measured_prep=(8..12).map(|i|e(i)-b(i)).sum::<u64>()+e(12).max(e(13))-b(12).min(b(13));
 s.insert("prepare_unassigned".into(),((e(1)-b(1)).checked_sub(measured_prep).unwrap())as f64/1e6);
}
fn backings()->Value{use std::os::unix::fs::MetadataExt;let mut ids=BTreeSet::new();let mut out=vec![];for family in ["ref","diag","aeglos"]{let expected=hash(format!("/usr/local/bin/detail-{family}"));for i in 0..3{let p=format!("{R}/bins/{family}{i}");let m=fs::metadata(&p).unwrap();assert!(ids.insert((m.dev(),m.ino())));assert_eq!(hash(&p),expected);out.push(json!({"path":p,"dev":m.dev(),"ino":m.ino(),"sha256":expected}));}}json!(out)}
fn snapshot(label:&str){save(&format!("{label}.json"),state());save(&format!("backings-{label}.json"),backings());}
fn counters(v:&Value,p:&str)->BTreeMap<String,u64>{v[p].as_str().unwrap().lines().map(|l|{let f=l.split_whitespace().collect::<Vec<_>>();assert_eq!(f.len(),2);(f[0].into(),f[1].parse().unwrap())}).collect()}
fn extended_review(){let basic=read(format!("{R}/review.json"));let mut v=basic.clone();let before=read(format!("{R}/before.json"));let after=read(format!("{R}/after.json"));let mut events=vec![];for(p,keys)in [("/sys/fs/cgroup/cpu.stat",vec!["nr_throttled","throttled_usec"]),("/sys/fs/cgroup/memory.events",vec!["high","max","oom","oom_kill","oom_group_kill"]),("/sys/fs/cgroup/memory.swap.events",vec!["high","max","fail"])]{let a=counters(&before,p);let b=counters(&after,p);for k in keys{let x=*a.get(k).unwrap();let y=*b.get(k).unwrap();assert!(y>=x);events.push(json!({"file":p,"counter":k,"delta":y-x,"passed":y==x}));}}assert_eq!(read(format!("{R}/backings-before.json")),read(format!("{R}/backings-after.json")));v["environment_guards"]=json!(events);v["all_gates_pass"]=json!(basic["all_gates_pass"]==true&&events.iter().all(|g|g["passed"]==true));save("basic-review.json",basic);fs::write(format!("{R}/review.json"),serde_json::to_vec_pretty(&v).unwrap()).unwrap();println!("TARGET COMPLETE80 exports; calibrated={}",v["all_gates_pass"]);}
fn execute(smoke:bool){use std::os::unix::fs::PermissionsExt;fs::create_dir(R).unwrap();fs::create_dir(format!("{R}/bins")).unwrap();for family in ["ref","diag","aeglos"]{let bytes=fs::read(format!("/usr/local/bin/detail-{family}")).unwrap();for i in 0..3{let p=format!("{R}/bins/{family}{i}");fs::write(&p,&bytes).unwrap();fs::set_permissions(p,fs::Permissions::from_mode(0o755)).unwrap();}}
 let o=Command::new("lscpu").args(["-p=CPU,CORE,SOCKET,ONLINE"]).output().unwrap();assert!(o.status.success());let t=String::from_utf8(o.stdout).unwrap();fs::write(format!("{R}/topology.csv"),&t).unwrap();if !smoke{let mut cores=BTreeSet::new();let mut cpus=BTreeSet::new();for l in t.lines().filter(|l|!l.starts_with('#')){let f=l.split(',').collect::<Vec<_>>();assert_eq!(f[3],"Y");cpus.insert(f[0].parse::<usize>().unwrap());assert!(cores.insert((f[1],f[2])));}assert_eq!(cpus,(0..96).collect());assert_eq!(cores.len(),96);let cpu=fs::read_to_string("/sys/fs/cgroup/cpu.max").unwrap();let f=cpu.split_whitespace().collect::<Vec<_>>();assert_eq!(f[0].parse::<u64>().unwrap(),96*f[1].parse::<u64>().unwrap());assert_eq!(fs::read_to_string("/sys/fs/cgroup/memory.max").unwrap().trim(),(30u64<<30).to_string());assert_eq!(fs::read_to_string("/sys/fs/cgroup/memory.swap.max").unwrap().trim(),"0");}
 snapshot("before");prepare(smoke);let log=fs::File::create(format!("{R}/workflow.log")).unwrap();let s=Command::new("/usr/local/bin/cr-xtask").args(["workflow",&format!("{R}/plan.json"),&format!("{R}/run")]).stdout(std::process::Stdio::from(log.try_clone().unwrap())).stderr(std::process::Stdio::from(log)).status().unwrap();assert!(s.success(),"Preserve partial outputs; never replay successful SDK calls");println!("COMPLETE {}",if smoke{"smoke"}else{"measure"});}
