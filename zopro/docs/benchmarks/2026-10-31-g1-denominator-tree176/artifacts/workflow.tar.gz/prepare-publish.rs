use std::fs;
fn main(){let old="/home/ubuntu/src/zopro-perf-work/deferred-equality176";let r="/home/ubuntu/src/zopro-perf-work/g1-denominator-tree176";let mut s=fs::read_to_string(format!("{old}/publish.rs")).unwrap().replace(old,r).replace("2026-10-31-deferred-equality176","2026-10-31-g1-denominator-tree176").replace("4148","4442").replace("682","482").replace("9018","41418").replace("len(),9)","len(),4)").replace("false9checks","false4checks");
let a=s.find("for f in[\"analysis.json\"").unwrap();let b=a+s[a..].find("let mut doc=").unwrap();s.replace_range(a..b,r#"for f in["analysis.json","review.json","review.log","audit.json","profile-symbols.json","codegen.json","design.md","capture-protocol.md","fixture-bindings.json","parents.json","pins.json","plan.json","publish.rs","report.md.in"]{fs::copy(r(f),d("artifacts").join(f)).unwrap();}
"#);
s=s.replace("[\"control\",\"candidate\",\"candidate-fixed\"]","[\"control\",\"candidate\"]").replace("source.len(),537","source.len(),356").replace("[\"qualification\",\"qualification-v2\"]","[\"qualification\",\"builds\"]");
// Correct seven-column table separators in the renderer before first publication.
s=s.replace("|---|---:|---:|---:|---:|---:|\\n","|---|---:|---:|---:|---:|---:|---:|\\n");
fs::write(format!("{r}/publish.rs"),s).unwrap();println!("Publisher prepared:356source files/482pins/4failedchecks/4442samples/41418passes;fiveexactarchives andall8INHERITED CPU+Metal");}
