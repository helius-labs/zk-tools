//! G1 raw-numerator denominator tree in existing anchor slots.
use super::*;
// Existing G2 heap indexing, adapted to G1 anchor/denominator record fields.
fn node(records:&[FqAddGroup],m:usize,index:usize)->FqBatch{
 if index<m-1{records[index].ax}else{records[index-(m-1)].denominator}
}
fn set_node(records:&mut[FqAddGroup],m:usize,index:usize,value:FqBatch){
 if index<m-1{records[index].ax=value;}else{records[index-(m-1)].denominator=value;}
}
fn build_products(records:&mut[FqAddGroup])->FqBatch{
 let m=records.len();if m==0{return FqBatch::one();}if m==1{return records[0].denominator;}
 for i in(0..m-1).rev(){records[i].ax=node(records,m,2*i+1).mul(&node(records,m,2*i+2));}
 records[0].ax
}
fn propagate_inverse(records:&mut[FqAddGroup],inverse:FqBatch){
 let m=records.len();if m==0{return;}if m==1{records[0].denominator=inverse;return;}
 records[0].ax=inverse;
 for i in 0..m-1{let a=node(records,m,2*i+1);let b=node(records,m,2*i+2);let inv=records[i].ax;let ia=inv.mul(&b);let ib=inv.mul(&a);set_node(records,m,2*i+1,ia);set_node(records,m,2*i+2,ib);}
}

fn apply<C:CurveConfig<Base=Fq>>(buckets:&mut[Affine<C>],batch:&[(u32,impl std::borrow::Borrow<Affine<C>>+Copy)],s:&mut FqAddScratch){
    let full = batch.len() / LANES * LANES;
    if full==0 || !s.canonical || !s.vector_inverse{return stream_g1_impl::<C,true,true>(buckets,batch,s);}
    s.groups.clear();
    if s.write_groups {
        // Reserve all records before taking any pointers. Each record is
        // Copy and its length is published only after all five fields are
        // initialized. A panic before then leaves no partial record in len.
        s.groups.reserve(full / LANES);
        for k in (0..full).step_by(LANES) {
            let a: [Affine<C>; LANES] = core::array::from_fn(|i| buckets[batch_index::<true>(batch[k + i].0)]);
            let b: [Affine<C>; LANES] = core::array::from_fn(|i| *batch[k + i].1.borrow());
            // SAFETY: reserve covers full/LANES records, k/LANES is in
            // that range, and no allocation changes during these writes.
            // addr_of_mut! creates no reference to uninitialized storage.
            unsafe {
                let slot = s.groups.as_mut_ptr().add(k / LANES);
                let ax = FqBatch::new(&a.map(|p| p.x));
                core::ptr::addr_of_mut!((*slot).ax).write(ax);
                let bx = FqBatch::new(&b.map(|p| p.x));
                let denominator = canonical_sub::<true>(&bx, &ax);
                core::ptr::addr_of_mut!((*slot).xsum).write(canonical_add::<true>(&ax, &bx));
                core::ptr::addr_of_mut!((*slot).denominator).write(denominator);
                let ay = FqBatch::new(&a.map(|p| p.y));
                core::ptr::addr_of_mut!((*slot).ay).write(ay);
                let by = FqBatch::new(&b.map(|p| p.y));
                let numerator = by.signed_difference_canonical(&ay,signs::<true,C>(&batch[k..k+LANES]));
                core::ptr::addr_of_mut!((*slot).numerator).write(numerator);
                
                // All five fields of this record are now initialized.
                s.groups.set_len(k / LANES + 1);
            }
        }
    } else {
        if s.reserve_groups {
            s.groups.reserve(full / LANES);
        }
        for k in (0..full).step_by(LANES) {
            let a: [Affine<C>; LANES] = core::array::from_fn(|i| buckets[batch_index::<true>(batch[k + i].0)]);
            let b: [Affine<C>; LANES] = core::array::from_fn(|i| *batch[k + i].1.borrow());
            let ax = FqBatch::new(&a.map(|p| p.x));
            let ay = FqBatch::new(&a.map(|p| p.y));
            let bx = FqBatch::new(&b.map(|p| p.x));
            let by = FqBatch::new(&b.map(|p| p.y));
            // Host coordinates are canonical; only the resulting differences are lazy.
            let denominator = canonical_sub::<true>(&bx, &ax);
            let numerator = by.signed_difference_canonical(&ay,signs::<true,C>(&batch[k..k+LANES]));
            
            s.groups.push(FqAddGroup {
                ax,
                ay,
                xsum: canonical_add::<true>(&ax, &bx),
                denominator,
                numerator,
            });
        }
    }
    let chains=build_products(&mut s.groups);
    s.tail.clear();
    let mut inverse = if let Some(value)=direct_chain_inverse(&chains,full==batch.len(),s.vector_inverse) {
        value
    } else {
        let mut tail = chains.get();
        for k in full..batch.len() {
            let (index, b) = batch[k];
            let b = *b.borrow();
            let b = if true && index>>31!=0 {-b}else{b};
            let a = buckets[batch_index::<true>(index)];
            let denominator = b.x - a.x;
            let numerator = (b.y - a.y) * tail[k % LANES];
            tail[k % LANES] *= denominator;
            s.tail.push([a.x, a.y, a.x + b.x, denominator, numerator]);
        }
        let mut inverse = invert_lanes(tail, s.vector_inverse);
        for k in (full..batch.len()).rev() {
            let [ax, ay, xsum, denominator, numerator] = s.tail[k - full];
            let slope = numerator * inverse[k % LANES];
            inverse[k % LANES] *= denominator;
            let x = slope.square() - xsum;
            let y = slope * (ax - x) - ay;
            buckets[batch_index::<true>(batch[k].0)] = Affine::new(x, y);
        }
        FqBatch::new(&inverse)
    };
    propagate_inverse(&mut s.groups,inverse);
    for (j, g) in s.groups.iter().enumerate().rev() {
        let ax=FqBatch::new(&core::array::from_fn(|i|buckets[batch_index::<true>(batch[j*LANES+i].0)].x));
        let slope = g.numerator.mul(&g.denominator);
        let x = slope.mul(&slope).sub(&g.xsum);
        let y = slope.mul(&ax.sub(&x)).sub(&g.ay);
        let (x, y) = (x.get(), y.get());
        for i in 0..LANES {
            buckets[batch_index::<true>(batch[j * LANES + i].0)] = Affine::new(x[i], y[i]);
        }
    }
}

impl<C:CurveConfig<Base=Fq>> BatchAdd<C>{pub(crate) fn apply_g1_denominator_tree(&mut self,buckets:&mut[Affine<C>],batch:&[(u32,&Affine<C>)]){apply::<C>(buckets,batch,&mut self.fq)}}
#[cfg(test)]mod tests{
use super::*;use zopro_bn254::{G1Affine,G1Config,G1Projective,Fr};
#[test]fn heap_all_irregular_sizes_against_independent_products(){
 for m in 0..=65 {let values=(0..m).map(|j|core::array::from_fn(|i|Fq::from((j*8+i+2)as u64))).collect::<Vec<[Fq;8]>>();let expected=core::array::from_fn(|i|values.iter().fold(Fq::ONE,|p,v|p*v[i]));let mut records=values.iter().map(|a|FqAddGroup{ax:FqBatch::one(),ay:FqBatch::one(),xsum:FqBatch::one(),denominator:FqBatch::new(a),numerator:FqBatch::one()}).collect::<Vec<_>>();let root=build_products(&mut records);assert_eq!(root.get(),expected);propagate_inverse(&mut records,root.inverse_nonzero());for(j,g)in records.iter().enumerate(){assert_eq!(g.denominator.get(),core::array::from_fn(|i|values[j][i].inverse().unwrap()));assert_eq!(g.numerator.get(),[Fq::ONE;8]);assert_eq!(g.ay.get(),[Fq::ONE;8]);assert_eq!(g.xsum.get(),[Fq::ONE;8]);}}
}
#[test]fn complete_signed_batches_tails_and_changing_reuse(){
 let g=G1Affine::GENERATOR;
 for n in[0,1,7,8,9,15,16,17,31,32,33,63,64,65,127,128,129,199,200,201,351,352,353,511,512] {let a=(0..n).map(|i|Fr::from(i as u64+12345)).collect::<Vec<_>>();let b=(0..n).map(|i|Fr::from(i as u64+900001)).collect::<Vec<_>>();let initial=G1Projective::batch_to_affine(&a.iter().map(|c|g**c).collect::<Vec<_>>());let incoming=G1Projective::batch_to_affine(&b.iter().map(|c|g**c).collect::<Vec<_>>());let immutable=incoming.clone();for sign in 0..3 {let neg=|i:usize|sign==1||sign==2&&i%3==0;let batch=incoming.iter().enumerate().map(|(i,p)|(i as u32|if neg(i){1<<31}else{0},p)).collect::<Vec<_>>();let mut actual=initial.clone();let mut work=FqAddScratch{canonical:true,vector_inverse:true,write_groups:true,reserve_groups:true,..Default::default()};for pass in 1..=3 {apply::<G1Config>(&mut actual,&batch,&mut work);let expected=G1Projective::batch_to_affine(&(0..n).map(|i|g*(a[i]+if neg(i){-b[i]}else{b[i]}*Fr::from(pass as u64))).collect::<Vec<_>>());assert_eq!(actual,expected);assert_eq!(incoming,immutable);}}
 }
}
}
