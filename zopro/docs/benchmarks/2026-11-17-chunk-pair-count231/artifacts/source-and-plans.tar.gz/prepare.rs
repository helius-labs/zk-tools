use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::{Path,PathBuf},collections::BTreeMap};
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/chunk-pair-count231";
fn p(s:&str)->PathBuf{Path::new(ROOT).join(s)}
fn hash(s:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(s).unwrap()))}
fn load(s:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(s).unwrap()).unwrap()}
fn save(s:&str,v:Value){assert!(!p(s).exists());fs::write(p(s),serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn main(){
 assert!(!p("plan.json").exists());let mf="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-17-scaled-prefix-adoption229/artifacts/production-source-manifest.json";let manifest=load(mf);let mut pins=BTreeMap::new();let source=manifest["source_files_sha256"].as_object().unwrap();assert_eq!(source.len(),186);
 for(s,h)in source{let path=Path::new("/home/ubuntu/src/zk-tools/zopro").join(s);assert_eq!(hash(&path),h.as_str().unwrap());pins.insert(path.display().to_string(),hash(&path));}
 let original="/home/ubuntu/src/zopro-perf-work/lfg-tiled-count176/inputs.json";let inputs=load(original);for v in inputs.as_object().unwrap().values(){let file=v["file"].as_str().unwrap();assert_eq!(hash(file),v["sha256"].as_str().unwrap());pins.insert(file.into(),hash(file));let receipt=v["provenance_receipt"].as_str().unwrap();pins.insert(receipt.into(),hash(receipt));}
 fs::copy(original,p("inputs.json")).unwrap();
 let ledger="/home/ubuntu/src/zopro-perf-work/unscaled-mixed230/proof-sha256-after-main.json";assert_eq!(hash(ledger),"ab290bf3ef3d535745621f21aa914423ff5d578abfb30f44ed80f2f6998104f8");
 let compiler="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
 let deps="/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";let serde=format!("{deps}/libserde_json-cdebb9338c2784ad.rlib");let sha=format!("{deps}/libsha2-16b8f2c03bdf5faa.rlib");
 for s in[original,mf,ledger,compiler,&serde,&sha,"/home/ubuntu/src/zk-tools/zopro/xtask/target/release/xtask"]{pins.insert(s.into(),hash(s));}
 for s in["protocol.md","count.rs","review.rs","prepare.rs","prepare","inputs.json"]{pins.insert(p(s).display().to_string(),hash(p(s)));}
 let compile=|source:&str,output:&str,test:bool|{let mut argv=vec![compiler.to_string(),"--edition=2021".into(),"-O".into(),p(source).display().to_string(),"-L".into(),format!("dependency={deps}"),"--extern".into(),format!("serde_json={serde}"),"--extern".into(),format!("sha2={sha}")];if test{argv.push("--test".into());}argv.extend(["-o".into(),p(output).display().to_string()]);argv};
 let cmd=|name:&str,argv:Vec<String>,unfiltered:bool|json!({"kind":"command","name":name,"argv":argv,"timeout_seconds":300,"unfiltered":unfiltered});
 let steps=vec![cmd("compile-tests",compile("count.rs","count-tests",true),false),cmd("model-tests",vec![p("count-tests").display().to_string(),"--test-threads=1".into()],true),cmd("compile-count",compile("count.rs","count",false),false),cmd("real-counts",vec![p("count").display().to_string()],false),cmd("compile-review",compile("review.rs","review",false),false),cmd("independent-review",vec![p("review").display().to_string()],false)];
 save("pins.json",json!(pins));save("plan.json",json!({"version":1,"source_pins":p("pins.json"),"steps":steps}));println!("Prepared6steps;186productionfiles exact;4retainedinputs;noSDK/native candidate");
}
