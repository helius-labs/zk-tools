use serde_json::{Value,json};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeSet};
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn load(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn main(){
 let root=Path::new("/home/ubuntu/src/zopro-perf-work/chunk-pair-count231");let pins=load(root.join("pins.json"));
 for(p,h)in pins.as_object().unwrap(){assert_eq!(hash(&fs::read(p).unwrap()),h.as_str().unwrap(),"{p}");}
 let inputs=load(root.join("inputs.json"));let model=load(root.join("counts.json"));let rows=model["rows"].as_array().unwrap();assert_eq!(rows.len(),64);
 let mut checked=0;
 for(name,meta)in inputs.as_object().unwrap(){let raw=fs::read(meta["file"].as_str().unwrap()).unwrap();assert_eq!(hash(&raw),meta["sha256"]);let size=if meta["query"]=="B"{128usize}else{64};let n=u64::from_le_bytes(raw[8..16].try_into().unwrap())as usize;let mut words=Vec::new();let mut identity=Vec::new();
  if size==128{assert_eq!(&raw[..8],b"B2SCAN01");assert_eq!(raw.len(),16+160*n);for i in 0..n{identity.push(raw[16+i*128..16+(i+1)*128].iter().all(|&b|b==0));words.push(&raw[16+128*n+i*32..16+128*n+(i+1)*32]);}}
  else{assert_eq!(&raw[..8],b"ACOLUMN1");assert_eq!(raw.len(),16+33*n);for i in 0..n{assert!(raw[16+33*i+32]<=1);identity.push(raw[16+33*i+32]!=0);words.push(&raw[16+33*i..16+33*i+32]);}}
  // This reader uses unsigned12-bit groups and the preceding group's high
  // bit as carry, retaining Booth's positive2048 tie when g=2047,carry=1. It does
  // not import the primary extraction, Booth, histogram or payload helpers.
  let mut d=Vec::new();for w in words{let mut carry=0i32;for j in 0..22{let mut x=0;for bit in 0..12{let b=j*12+bit;if b<256{x+=(((w[b/8]>>(b%8))&1)as i32)<<bit;}}let next=x>>11;d.push(x+carry-4096*next);carry=next;}assert_eq!(carry,0);}
  let total=d.iter().enumerate().filter(|(i,x)|!identity[i/22]&&**x!=0).count()as u64;let distinct=d.iter().enumerate().filter(|(i,x)|!identity[i/22]&&**x!=0).map(|(_,x)|x.abs()).collect::<BTreeSet<_>>().len()as u64;let fill=total-distinct;
  let summary=model["summaries"].as_array().unwrap().iter().find(|s|s["query"]==*name).unwrap();assert_eq!(summary["original_points"],n);assert_eq!(summary["identity_points"],identity.iter().filter(|x|**x).count());assert_eq!(summary["nonzero_contributions"],total);assert_eq!(summary["prepared_fill_generic_additions"],fill);
  for chunk in[2usize,4,8,16,32,64,128,256]{for both in[false,true]{let mut saving=0u64;let mut pairs=0u64;for start in(0..d.len()).step_by(chunk){let end=(start+chunk).min(d.len());let mut run=(start..end).filter(|&i|!identity[i/22]&&d[i]!=0).map(|i|if both{d[i].abs()}else{d[i]}).collect::<Vec<_>>();run.sort_unstable();let(mut begin,mut endrun)=(0,0);while begin<run.len(){while endrun<run.len()&&run[endrun]==run[begin]{endrun+=1;}saving+=((endrun-begin)/2)as u64;begin=endrun;}
    let k=(start..end).filter(|&i|!identity[i/22]).count()as u64;pairs+=k*k.saturating_sub(1)/2;
   }
   let cache=if both{"sum_and_difference"}else{"sum_only"};let row=rows.iter().find(|r|r["query"]==*name&&r["chunk"]==chunk&&r["cache"]==cache).unwrap();let base=n as u64*22*size as u64;let extra=pairs*size as u64*(if both{2}else{1});
   for(k,v)in[("nonzero_contributions",total),("prepared_fill_generic_additions",fill),("saved_generic_additions",saving),("remaining_fill_generic_additions",fill-saving),("cached_unordered_pairs",pairs),("base_shifted_bytes",base),("extra_pair_payload_bytes",extra),("total_point_payload_bytes",base+extra)]{assert_eq!(row[k],v,"{name} {chunk} {cache} {k}");}
   for(k,v)in[("saved_fill_fraction",saving as f64/fill as f64),("saved_additions_per_extra_MiB",saving as f64/(extra as f64/1048576.0))]{assert!((row[k].as_f64().unwrap()-v).abs()<1e-10);}
   checked+=1;
  }}
 }
 assert_eq!(checked,64);let mut commands=0;for stage in["compile-tests","model-tests","compile-count","real-counts","compile-review"]{let dir=root.join("run").join(stage);let exit=load(dir.join("exit.json"));assert_eq!(exit["returncode"],0);assert_eq!(exit["success"],true);for(k,file)in[("stdout_sha256","stdout.log"),("stderr_sha256","stderr.log")]{assert_eq!(hash(&fs::read(dir.join(file)).unwrap()),exit[k]);}commands+=1;}
 let production=load("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-17-scaled-prefix-adoption229/artifacts/production-source-manifest.json");let src=production["source_files_sha256"].as_object().unwrap();assert_eq!(src.len(),186);for(p,h)in src{assert_eq!(hash(&fs::read(Path::new("/home/ubuntu/src/zk-tools/zopro").join(p)).unwrap()),h.as_str().unwrap());}
 let ledger=fs::read("/home/ubuntu/src/zopro-perf-work/unscaled-mixed230/proof-sha256-after-main.json").unwrap();assert_eq!(hash(&ledger),"ab290bf3ef3d535745621f21aa914423ff5d578abfb30f44ed80f2f6998104f8");assert_eq!(model["canonical_count"],61143);assert_eq!(model["new_Gnark_exports"],0);assert_eq!(model["production_changed"],false);
 let out=json!({"passed":true,"independently_checked_rows":checked,"input_queries":4,"pins":pins.as_object().unwrap().len(),"receipt_streams_checked":commands*2,"production_source_files":src.len(),"canonical_count":61143,"canonical_sha256":hash(&ledger),"new_Gnark_exports":0,"limitations":"Independent digit/count/payload reader; same retained fixtures and standard SHA/JSON dependencies; no native curve/performance qualification or external audit"});let dest=root.join("review.json");assert!(!dest.exists());fs::write(dest,serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("PASS {checked} independent rows, {commands} receipts,186 production files");
}
