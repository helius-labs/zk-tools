use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::{Path,PathBuf},time::UNIX_EPOCH};
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/chunk-pair-count231";
fn p(s:&str)->PathBuf{Path::new(ROOT).join(s)}
fn load(s:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(s).unwrap()).unwrap()}
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn time(s:impl AsRef<Path>)->f64{fs::metadata(s).unwrap().modified().unwrap().duration_since(UNIX_EPOCH).unwrap().as_secs_f64()}
fn save(s:&str,v:&Value){assert!(!p(s).exists());fs::write(p(s),serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn main(){
 let pins=load(p("additional-pins.json"));for(path,h)in pins.as_object().unwrap(){assert_eq!(hash(&fs::read(path).unwrap()),h.as_str().unwrap());}
 let independent=load(p("review.json"));assert_eq!(independent["passed"],true);
 let mut commands=Vec::new();let mut active=0.0;
 for(stage,name)in[("run","compile-tests"),("run","model-tests"),("run","compile-count"),("run","real-counts"),("run","compile-review"),("run","independent-review"),("additional-run","compile-formal"),("additional-run","formal-coefficients")]{
  let dir=p(stage).join(name);let exit=load(dir.join("exit.json"));assert_eq!(exit["returncode"],0);assert_eq!(exit["success"],true);active+=exit["elapsed_ms"].as_f64().unwrap()/1000.;
  for(key,file)in[("stdout_sha256","stdout.log"),("stderr_sha256","stderr.log")]{assert_eq!(hash(&fs::read(dir.join(file)).unwrap()),exit[key]);}
  commands.push(json!({"stage":stage,"name":name,"command":load(dir.join("command.json")),"exit":exit}));
 }
 let original=fs::read_to_string(p("run/model-tests/stdout.log")).unwrap();assert!(original.contains("2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
 let formal=fs::read_to_string(p("additional-run/formal-coefficients/stdout.log")).unwrap();assert!(formal.contains("1 passed; 0 failed; 0 ignored; 0 measured; 2 filtered out"));
 let start=time(p("protocol.md"));let first=time(p("run/compile-tests/command.json"));let original_end=time(p("run/independent-review/exit.json"));let last=time(p("additional-run/formal-coefficients/exit.json"));
 save("receipts.json",&json!({"commands":commands,"commands_checked":8,"streams_checked":16,"all_first_scientific_executions_succeeded":true}));
 save("timing.json",&json!({"method":"Filesystem command/exit mtimes bound wall spans; active durations use xtask elapsed_ms. Not monotonic instrumented timers. Earlier paper/history research precedes protocol creation.","preparation_seconds":first-start,"original_workflow_wall_span_seconds":original_end-first,"additional_validation_after_original_end_seconds":last-original_end,"protocol_to_final_validation_seconds":last-start,"active_command_seconds":active,"preparation_allowance_seconds":1800,"model_capture_allowance_seconds":300,"allowances_met":first-start<=1800.&&original_end-first<=300.}));
 let counts=load(p("counts.json"));assert_eq!(counts["rows"].as_array().unwrap().len(),64);
 let comparisons=[("1x2",7.634234,37.,24.),("2x2",10.695071,59.,30.),("4x2",15.853243,109.,48.),("8x2",24.089668,189.,74.),("12x2",33.894323,284.,101.),("16x2",39.850686,335.,124.),("24x2",66.290215,528.,176.),("merge24x1",66.016778,507.,175.)].into_iter().map(|(shape,ms,cpu,metal)|json!({"shape":shape,"accepted227_ms_inherited_from228":ms,"M5_CPU_ms":cpu,"M5_Metal_ms":metal,"CPU_speedup":cpu/ms,"Metal_speedup":metal/ms,"CPU_10x_limit_ms":cpu/10.,"goal_met":ms<=cpu/10.})).collect::<Vec<_>>();
 assert!(comparisons.iter().all(|v|v["goal_met"]==false));save("accepted-comparison.json",&json!({"inherited":true,"new_measurements":false,"evidence":"../2026-11-17-scaled-prefix-all228/README.md","comparisons":comparisons,"goals_met":0,"goals_required":8,"merge54_ms_inherited":164.152637}));
 save("decision.json",&json!({"status":"complete_pair_cache_recipe_closed_without_native_implementation","scope":"Signed point-major all-window full chunk-pair cache, widths/order/chunks fixed before execution","reason":"At primary G2,161.61MiB point payload saves128 generic fill additions(0.0211%);646.44MiB saves1043(0.1716%);20.20GiB theoretical saves7.0397%. Existing complete prepared query already regresses versus streaming. No credible complete-caller benefit case within intended architecture from these counts; no arbitrary minimum speedup or fixed RAM admission cap introduced.","does_not_close":"Sparse/deduplicated cache, alternative MSM, every small low-memory optimization or the cited paper on its target small queries","counts_sha256":hash(&fs::read(p("counts.json")).unwrap()),"independent_review_sha256":hash(&fs::read(p("review.json")).unwrap()),"new_model_test_executions":3,"new_SDK_calls":0,"new_Gnark_exports":0,"canonical_count":61143,"production_changed":false,"goal_status":"active_unmet_0_of_8"}));
 println!("Final publication checks PASS:8receipts16streams;3 new tests;64count rows;no proof or source change");
}
