use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::Path};
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/chunk-pair-count231";
const WINDOWS:usize=22;
type Word=[u64;4];
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn save(p:&Path,v:&Value){assert!(!p.exists());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn extract(s:Word,offset:usize,bits:usize)->u64{
    let (i,j)=(offset/64,offset%64);
    let mut v=if i<4{s[i]>>j}else{0};
    if j+bits>64&&i<3{v|=s[i+1]<<(64-j);}
    v&((1<<bits)-1)
}
fn booth(s:Word,w:usize)->i16{
    if w==0{let v=extract(s,0,12);return (v as i32-((v>>11)<<12)as i32)as i16;}
    let v=extract(s,w*12-1,13);
    (((v+1)>>1)as i32-((v>>12)<<12)as i32)as i16
}
fn read(file:&str,g2:bool)->(Vec<Word>,Vec<bool>){
    let b=fs::read(file).unwrap();let n=u64::from_le_bytes(b[8..16].try_into().unwrap())as usize;
    if g2{assert_eq!(&b[..8],b"B2SCAN01");assert_eq!(b.len(),16+160*n);
        let words=b[16+128*n..].chunks_exact(32).map(|v|std::array::from_fn(|i|u64::from_le_bytes(v[8*i..8*i+8].try_into().unwrap()))).collect();
        let ids=b[16..16+128*n].chunks_exact(128).map(|v|v.iter().all(|x|*x==0)).collect();(words,ids)
    }else{assert_eq!(&b[..8],b"ACOLUMN1");assert_eq!(b.len(),16+33*n);
        let words=b[16..].chunks_exact(33).map(|v|std::array::from_fn(|i|u64::from_le_bytes(v[8*i..8*i+8].try_into().unwrap()))).collect();
        let ids=b[16..].chunks_exact(33).map(|v|{assert!(v[32]<=1);v[32]!=0}).collect();(words,ids)}
}
fn words_mod(w:Word,p:u64)->u64{w.iter().rev().fold(0,|v,&x|((v as u128*((1u128<<64)%p as u128)+x as u128)%p as u128)as u64)}
fn grouping_admitted(words:&[Word])->bool{
    use std::collections::BTreeSet;
    let n=words.len();let sample=n.min(2048);let stride=n.div_ceil(sample);let observed=n.div_ceil(stride).min(sample);
    let selected=words.iter().step_by(stride).take(sample).collect::<Vec<_>>();let set=selected.iter().copied().collect::<BTreeSet<_>>();
    if set.len()*200>observed*199{return false;}
    let percent=if(32768..65536).contains(&n){95}else{80};let zeros=selected.iter().filter(|x|***x==[0;4]).count();let nonzero=observed-zeros;
    if set.len()-usize::from(zeros>0)==nonzero&&nonzero*100>observed*percent{return false;}
    words.iter().filter(|x|**x!=[0;4]).collect::<BTreeSet<_>>().len()*100<=n*percent
}
// Match every bucket independently within one fixed key chunk. Neither a zero
// witness digit nor a matched pair removes a key entry from preparation sizing.
fn count(digits:&[i16],live:&[bool],chunk:usize,both:bool)->(u64,u64,u64){
    assert_eq!(digits.len(),live.len());let(mut saved,mut pairs,mut nonzero)=(0,0,0);
    for (ds,ls)in digits.chunks(chunk).zip(live.chunks(chunk)){
        let n=ls.iter().filter(|&&x|x).count()as u64;pairs+=n*(n.saturating_sub(1))/2;
        let mut histogram=BTreeMap::<i16,u64>::new();
        for(&d,&l)in ds.iter().zip(ls){if l&&d!=0{nonzero+=1;*histogram.entry(if both{d.abs()}else{d}).or_default()+=1;}}
        saved+=histogram.values().map(|n|n/2).sum::<u64>();
    }(saved,pairs,nonzero)
}
fn verify_group(digits:&[i16],live:&[bool],values:&[u64],chunk:usize,both:bool,p:u64)->u64{
    let signed=|v:u64,d:i16|if d<0{(p-v)%p}else{v};
    let mut buckets=vec![0u64;2048];let mut original=0u64;let mut saved=0;
    for ((ds,ls),vs)in digits.chunks(chunk).zip(live.chunks(chunk)).zip(values.chunks(chunk)){
        let mut used=vec![false;ds.len()];
        for i in 0..ds.len(){if used[i]||!ls[i]||ds[i]==0{continue;}
            used[i]=true;let d=ds[i];let a=signed(vs[i],d);let mut result=a;
            if let Some(j)=(i+1..ds.len()).find(|&j|!used[j]&&ls[j]&&ds[j]!=0&&if both{ds[j].abs()==d.abs()}else{ds[j]==d}){
                used[j]=true;let b=signed(vs[j],ds[j]);result=(a+b)%p;saved+=1;
                // A plus/minus table stores vi+vj and vi-vj; an outer sign
                // chooses the orientation. This check does not store a table.
                let cached=if (d<0)==(ds[j]<0){(vs[i]+vs[j])%p}else{(vs[i]+p-vs[j])%p};
                assert_eq!(result,signed(cached,d));
            }
            let b=d.unsigned_abs()as usize-1;buckets[b]=(buckets[b]+result)%p;
        }
        for i in 0..ds.len(){if ls[i]&&ds[i]!=0{original=(original+signed(vs[i],ds[i])*ds[i].unsigned_abs()as u64)%p;}}
    }
    let got=buckets.iter().enumerate().fold(0,|v,(i,x)|(v+*x*(i as u64+1))%p);
    assert_eq!(got,original);saved
}
fn main(){
    let root=Path::new(ROOT);let inputs:Value=serde_json::from_slice(&fs::read(root.join("inputs.json")).unwrap()).unwrap();
    let mut rows=Vec::new();let mut summaries=Vec::new();
    for(name,v)in inputs.as_object().unwrap(){let file=v["file"].as_str().unwrap();let bytes=fs::read(file).unwrap();assert_eq!(hash(&bytes),v["sha256"]);
        let g2=v["query"]=="B";let (words,ids)=read(file,g2);let size=if g2{128u64}else{64};
        assert!(words.iter().all(|w|w[3]>>62==0));
        let digits=words.iter().flat_map(|&s|(0..WINDOWS).map(move|w|booth(s,w))).collect::<Vec<_>>();
        let live=ids.iter().flat_map(|&id|[!id;WINDOWS]).collect::<Vec<_>>();
        let nonzero=digits.iter().zip(&live).filter(|(d,l)|**l&&**d!=0).count()as u64;
        let mut occupied=[false;2048];for(&d,&l)in digits.iter().zip(&live){if l&&d!=0{occupied[d.unsigned_abs()as usize-1]=true;}}
        let fill=nonzero-occupied.into_iter().filter(|x|*x).count()as u64;
        for p in[65537u64,1000000007]{
            let mut shifts=[1u64;WINDOWS];for i in 1..WINDOWS{shifts[i]=shifts[i-1]*4096%p;}
            let values=words.iter().enumerate().flat_map(|(i,_)|shifts.map(move|x|x*((i as u64+1)*7919+37)%p)).collect::<Vec<_>>();
            let expected=words.iter().zip(&ids).enumerate().fold(0u64,|v,(i,(&w,&id))|if id{v}else{(v+words_mod(w,p)*(((i as u64+1)*7919+37)%p))%p});
            let actual=digits.iter().zip(&live).zip(&values).fold(0,|v,((&d,&l),&x)|if !l||d==0{v}else{let term=x*d.unsigned_abs()as u64%p;(v+if d<0{(p-term)%p}else{term})%p});assert_eq!(expected,actual);
            // Independent explicit matching and the whole weighted-bucket
            // identity check cover every real row at both small prime oracles.
            for chunk in[2,4,8,16,32,64,128,256]{for both in[false,true]{assert_eq!(verify_group(&digits,&live,&values,chunk,both,p),count(&digits,&live,chunk,both).0);}}
        }
        for chunk in[2usize,4,8,16,32,64,128,256]{for both in[false,true]{let(saved,pairs,observed)=count(&digits,&live,chunk,both);assert_eq!(observed,nonzero);assert!(saved<=fill);
            let base=words.len()as u64*WINDOWS as u64*size;let extra=pairs*size*if both{2}else{1};
            rows.push(json!({"query":name,"chunk":chunk,"cache":if both{"sum_and_difference"}else{"sum_only"},"nonzero_contributions":nonzero,"prepared_fill_generic_additions":fill,"saved_generic_additions":saved,"remaining_fill_generic_additions":fill-saved,"saved_fill_fraction":saved as f64/fill as f64,"cached_unordered_pairs":pairs,"base_shifted_bytes":base,"extra_pair_payload_bytes":extra,"total_point_payload_bytes":base+extra,"saved_additions_per_extra_MiB":saved as f64/(extra as f64/1048576.0)}));
        }}
        let grouping=grouping_admitted(&words);assert_eq!(grouping,name.starts_with("2x2"));
        summaries.push(json!({"query":name,"original_points":words.len(),"identity_points":ids.iter().filter(|x|**x).count(),"shifted_entries":digits.len(),"nonzero_contributions":nonzero,"prepared_fill_generic_additions":fill,"original_grouping_admitted":grouping,"compares_to_current227":false}));
    }
    let output=json!({"source":"https://www.preprints.org/manuscript/202604.0045","scope":"signed extension of chunk pair caching in closed all-window prepared geometry; logical generic group operations, not a native performance result","summaries":summaries,"rows":rows,"rows_expected":64,"toy_group_primes":[65537,1000000007],"production_changed":false,"new_SDK_calls":0,"new_Gnark_exports":0,"canonical_count":61143,"native_candidate_selected":false,"no_general_lower_bound_claim":true});assert_eq!(rows.len(),64);save(&root.join("counts.json"),&output);
}
#[cfg(test)]mod tests{
 use super::*;
 fn reconstruct(ds:&[i16])->[u64;5]{let mut x=[0u64;5];for &d in ds.iter().rev(){let mut carry=0;for v in &mut x{let next=*v>>52;*v=(*v<<12)|carry;carry=next;}if d>=0{let(mut v,mut carry)=x[0].overflowing_add(d as u64);x[0]=v;for j in 1..5{(v,carry)=x[j].overflowing_add(carry as u64);x[j]=v;}}else{let(mut v,mut borrow)=x[0].overflowing_sub(d.unsigned_abs()as u64);x[0]=v;for j in 1..5{(v,borrow)=x[j].overflowing_sub(borrow as u64);x[j]=v;}}}x}
 #[test]fn signed_digit_reconstruction_full_width_boundaries(){let mut inputs=vec![[0;4],[u64::MAX,u64::MAX,u64::MAX,(1<<62)-1]];for bit in 0..254{let mut w=[0;4];w[bit/64]=1<<(bit%64);inputs.push(w);if bit>0{let mut one=1u64;for x in &mut w{let(v,b)=x.overflowing_sub(one);*x=v;one=b as u64;}inputs.push(w);}}let mut seed=0x99114eacb3u64;for _ in 0..512{let mut w=[0;4];for x in &mut w{seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;*x=seed;}w[3]&=(1<<62)-1;inputs.push(w);}for w in inputs{let ds=(0..WINDOWS).map(|j|booth(w,j)).collect::<Vec<_>>();assert_eq!(reconstruct(&ds),[w[0],w[1],w[2],w[3],0]);}}
 #[test]fn exhaustive_signed_matching_identity_and_payload_accounting(){let alphabet=[-2i16,-1,0,1,2];for n in 1..=4usize{for code in 0..5usize.pow(n as u32){let mut c=code;let ds=(0..n).map(|_|{let v=alphabet[c%5];c/=5;v}).collect::<Vec<_>>();for mask in 0..1usize<<n{let live=(0..n).map(|i|mask>>i&1!=0).collect::<Vec<_>>();let values=(0..n).map(|i|i as u64*7919+37).collect::<Vec<_>>();for chunk in[1,2,3,8]{for both in[false,true]{let(got,pairs,_)=count(&ds,&live,chunk,both);assert_eq!(got,verify_group(&ds,&live,&values,chunk,both,1000000007));let expected=live.chunks(chunk).map(|l|{let mut out=0;for i in 0..l.len(){for j in i+1..l.len(){out+=u64::from(l[i]&&l[j]);}}out}).sum::<u64>();assert_eq!(pairs,expected);}}}}}}
}
