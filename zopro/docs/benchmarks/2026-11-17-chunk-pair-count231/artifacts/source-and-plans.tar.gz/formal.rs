// Additional coefficient coverage only. Include the frozen implementation;
// select this new test by exact name without replaying either earlier test.
include!("count.rs");
#[cfg(test)]mod formal{
 use super::*;
 #[test]fn independent_basis_coefficients_for_every_small_signed_population(){
  // Basis values256^i encode the original contribution indices injectively.
  // Digits have magnitude<=2, each index appears at most once, and n<=4.
  // The largest signed difference has absolute value<4*(1+256+256²+256³)
  // <1,000,000,007; equal residues therefore prove equal integer sums.
  // Balanced base256 with coefficient differences in[-4,4] is unique, so
  // this checks individual formal coefficients, not just one dot product.
  let p=1_000_000_007u64;assert!(4*(1+256+65536+16777216)<p);
  for n in 1..=4usize{let values=(0..n).map(|i|1u64<<(8*i)).collect::<Vec<_>>();
   for code in 0..5usize.pow(n as u32){let mut x=code;let digits=(0..n).map(|_|{let d=(x%5)as i16-2;x/=5;d}).collect::<Vec<_>>();
    for mask in 0..1usize<<n{let live=(0..n).map(|i|mask>>i&1!=0).collect::<Vec<_>>();
     for chunk in[1,2,3,8]{for both in[false,true]{assert_eq!(verify_group(&digits,&live,&values,chunk,both,p),count(&digits,&live,chunk,both).0);}}
    }
   }
  }
 }
}
