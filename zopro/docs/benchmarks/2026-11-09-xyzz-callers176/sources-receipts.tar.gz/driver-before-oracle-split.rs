use serde_json::json;
use sha2::{Digest,Sha256};
use std::{alloc::{GlobalAlloc,Layout},hint::black_box,sync::{Arc,Mutex,atomic::{AtomicBool,AtomicUsize,Ordering::Relaxed}},time::Instant};
use ark_ec::{AdditiveGroup,AffineRepr,CurveGroup,PrimeGroup};
use ark_ff::{PrimeField,Zero};
use zopro_bn254::{Fq,Fq2,G1Affine,G2Affine};
mod perf;
static AUDIT:AtomicBool=AtomicBool::new(false);static ALLOCS:AtomicUsize=AtomicUsize::new(0);static REALLOCS:AtomicUsize=AtomicUsize::new(0);static BYTES:AtomicUsize=AtomicUsize::new(0);
struct Counted;
unsafe impl GlobalAlloc for Counted{
    unsafe fn alloc(&self,l:Layout)->*mut u8{if AUDIT.load(Relaxed){ALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(l.size(),Relaxed);}unsafe{zopro_core::alloc::Allocator.alloc(l)}}
    unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8{if AUDIT.load(Relaxed){ALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(l.size(),Relaxed);}unsafe{zopro_core::alloc::Allocator.alloc_zeroed(l)}}
    unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8{if AUDIT.load(Relaxed){REALLOCS.fetch_add(1,Relaxed);BYTES.fetch_add(n,Relaxed);}unsafe{zopro_core::alloc::Allocator.realloc(p,l,n)}}
    unsafe fn dealloc(&self,p:*mut u8,l:Layout){unsafe{zopro_core::alloc::Allocator.dealloc(p,l)}}
}
#[global_allocator]static A:Counted=Counted;
fn affinity(cpu:usize){unsafe{let mut mask:libc::cpu_set_t=std::mem::zeroed();libc::CPU_ZERO(&mut mask);libc::CPU_SET(cpu,&mut mask);assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&mask),&mask),0);}}
fn scalar(seed:&mut u64)->ark_bn254::Fr{let mut b=[0;32];for c in b.chunks_mut(8){*seed^=*seed<<13;*seed^=*seed>>7;*seed^=*seed<<17;c.copy_from_slice(&seed.to_le_bytes());}ark_bn254::Fr::from_le_bytes_mod_order(&b)}
fn fq(x:ark_bn254::Fq)->Fq{Fq::from_canonical(x.into_bigint().0).unwrap()}
fn g1(p:ark_bn254::G1Affine)->G1Affine{if p.is_zero(){G1Affine::IDENTITY}else{G1Affine::new(fq(p.x),fq(p.y))}}
fn g2(p:ark_bn254::G2Affine)->G2Affine{if p.is_zero(){G2Affine::IDENTITY}else{G2Affine::new(Fq2::new(fq(p.x.c0),fq(p.x.c1)),Fq2::new(fq(p.y.c0),fq(p.y.c1)))}}
enum Points{G1(Vec<G1Affine>,G1Affine),G2(Vec<G2Affine>,G2Affine)}
fn main(){
    let a=std::env::args().collect::<Vec<_>>();assert_eq!(a.len(),5);let case=a[1].as_str();let workers=a[2].parse::<usize>().unwrap();let rounds=a[3].parse::<usize>().unwrap();assert!([1,16,32].contains(&workers)&&rounds>0);assert!(["OFF","ON"].contains(&a[4].as_str()));if a[4]=="ON"{assert!(cfg!(zopro_sparse_xyzz));}
    let(n,split,bits,is_g2)=match case{"g1-balanced"=>(30529+32768,30529,13,false),"g1-uniform"=>(30529+32768,30529,12,false),"g1-ordinary"=>(21006,0,12,false),"g2-phi"=>(15044,0,12,true),_=>panic!("case")};
    let seen=Arc::new(Mutex::new(Vec::new()));let seen2=seen.clone();let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).start_handler(move|i|{let cpu=if workers==1{2}else{i};affinity(cpu);seen2.lock().unwrap().push(json!({"worker":i,"cpu":cpu,"tid":unsafe{libc::syscall(libc::SYS_gettid)}}));}).build().unwrap();pool.broadcast(|_|());let mut mapping=seen.lock().unwrap().clone();mapping.sort_by_key(|x|x["worker"].as_u64().unwrap());assert_eq!(mapping.len(),workers);
    let mut seed=0x78797a7a63616c6c;let s:Vec<_>=(0..n).map(|_|scalar(&mut seed)).collect();let words:Vec<_>=s.iter().map(|s|s.into_bigint().0).collect();
    let coefficient=s.iter().enumerate().fold(ark_bn254::Fr::zero(),|sum,(i,s)|sum+*s*ark_bn254::Fr::from(98761+i as u64));
    let points=if is_g2{let g=ark_bn254::G2Projective::generator();let mut p=g*ark_bn254::Fr::from(98761u64);let mut v=Vec::with_capacity(n);for _ in 0..n{v.push(p);p+=g;}Points::G2(ark_bn254::G2Projective::normalize_batch(&v).into_iter().map(g2).collect(),g2((g*coefficient).into_affine()))}else{let g=ark_bn254::G1Projective::generator();let mut p=g*ark_bn254::Fr::from(98761u64);let mut v=Vec::with_capacity(n);for _ in 0..n{v.push(p);p+=g;}Points::G1(ark_bn254::G1Projective::normalize_batch(&v).into_iter().map(g1).collect(),g1((g*coefficient).into_affine()))};drop(s);
    let required=pool.install(||zopro_core::sparse_trial_forecast(n,split,is_g2));let _forecast=zopro_core::sparse_trial_hold_forecast(required);
    let run=||match &points{
        Points::G1(p,_)=>{let p=zopro_core::sparse_trial_g1(p,black_box(&words),split,bits);let mut out=[0u64;8];out[..4].copy_from_slice(&p.x.0);out[4..].copy_from_slice(&p.y.0);out.to_vec()},
        Points::G2(p,_)=>{let mut short=words.clone();let p=zopro_core::sparse_trial_g2(p,black_box(&mut short));let mut out=Vec::with_capacity(16);for f in[p.x.c0,p.x.c1,p.y.c0,p.y.c1]{out.extend_from_slice(&f.0);}out}
    };
    let expected:Vec<_>=match &points{Points::G1(_,p)=>p.x.0.into_iter().chain(p.y.0).collect(),Points::G2(_,p)=>[p.x.c0,p.x.c1,p.y.c0,p.y.c1].into_iter().flat_map(|f|f.0).collect()};
    for _ in 0..3{assert_eq!(pool.install(&run),expected);}
    let audit=std::env::var_os("ZOPRO_WINDOW_ALLOC_AUDIT").is_some();let mut control=perf::Control::from_env().unwrap();if let Some(c)=control.as_mut(){c.enable().unwrap();}let usage0=perf::Usage::now().unwrap();AUDIT.store(audit,Relaxed);let start=Instant::now();let mut last=vec![];
    pool.install(||{for _ in 0..black_box(rounds){last=run();black_box(&last);}});let elapsed=start.elapsed().as_nanos()as u64;AUDIT.store(false,Relaxed);let usage1=perf::Usage::now().unwrap();if let Some(c)=control.as_mut(){c.disable().unwrap();}
    assert_eq!(last,expected);let mut hash=Sha256::new();for w in last{hash.update(w.to_le_bytes());}pool.broadcast(|ctx|assert_eq!(unsafe{libc::sched_getcpu()},if workers==1{2}else{ctx.index()}as i32));
    println!("CALLER {}",json!({"case":case,"kind":if is_g2{"G2"}else{"G1"},"size":n,"split":split,"workers":workers,"rounds_per_worker":rounds,"arm":a[4],"pid":std::process::id(),"worker_rows":mapping,"elapsed_ns":elapsed,"ns_per_batch_wave":elapsed as f64/rounds as f64,"allocation_audit_enabled":audit,"audited_allocations":ALLOCS.load(Relaxed),"audited_reallocations":REALLOCS.load(Relaxed),"audited_requested_bytes":BYTES.load(Relaxed),"complete_generator_oracle":true,"independent_oracle":"Arkworks point generation and full scalar-weight sum","priming_passes":3,"priming_rounds":1,"output_sha256":format!("{:x}",hash.finalize()),"usage":usage1.difference(&usage0),"required_workspace_forecast_bytes":required,"new_proofs":0,"geometry":{"bits":bits,"ordinary_parts":1,"G2_parts":2},"scope":"one complete MSM per loop, construction/admission/normal affine work/sparse doubling/Phi/weighted tree/final normalization; G2 fresh scalar copy included; final validation and fixture/pool/primes excluded"}));
}
