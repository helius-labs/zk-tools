fn profile_diags(callers:&BTreeMap<String,Value>,failed:&mut Vec<String>)->(Value,Value){
    let mut counters = BTreeMap::new();
    let mut profiles = BTreeMap::new();
    let mut symbols_all = BTreeMap::new();
    for c in contexts().iter().filter(|c| c.3 >= 16) {
        for arm in ["OFF", "ON"] {
            let stat = format!("stat-{}-{arm}", c.0);
            let mut values = BTreeMap::new();
            for line in fs::read_to_string(r(format!("stat/{stat}.csv")))
                .unwrap()
                .lines()
                .filter(|l| !l.starts_with('#') && !l.trim().is_empty())
            {
                let fields = line.split(';').collect::<Vec<_>>();
                let event = fields[2].trim();
                if ![
                    "cycles:u",
                    "instructions:u",
                    "cache-misses:u",
                    "branch-misses:u",
                ]
                .contains(&event)
                {
                    continue;
                }
                let count = fields[0].trim().parse::<f64>().unwrap();
                assert!(fields[4].trim().parse::<f64>().unwrap() >= 99.9);
                values.insert(
                    event.to_owned(),
                    json!({"count":count,"per_wave":count/256.}),
                );
            }
            assert_eq!(values.len(), 4);
            counters.insert(stat, json!(values));
            let name = format!("cycles-{}-{arm}", c.0);
            let v = &callers[&name];
            let pid = v["pid"].as_u64().unwrap();
            let tids = v["worker_rows"]
                .as_array()
                .unwrap()
                .iter()
                .map(|x| x["tid"].as_u64().unwrap())
                .chain([pid])
                .collect::<BTreeSet<_>>();
            let binary = r(match arm {
                "frozen" => "REF-bin",
                "OFF" => "OFF-bin",
                "ON" => "ON-bin",
                _ => panic!("arm"),
            });
            let metadata =
                fs::read_to_string(r(format!("runs/metadata-{name}/stdout.log"))).unwrap();
            let owners = metadata
                .lines()
                .filter(|l| l.contains("PERF_RECORD_MMAP") && l.contains(binary.to_str().unwrap()))
                .map(|l| {
                    l.split_whitespace()
                        .next()
                        .unwrap()
                        .split('/')
                        .next()
                        .unwrap()
                        .parse::<u64>()
                        .unwrap()
                })
                .collect::<BTreeSet<_>>();
            assert_eq!(owners, BTreeSet::from([pid]));
            let mut forked = BTreeSet::from([pid]);
            for l in metadata.lines() {
                if let Some((_, tail)) = l.split_once("PERF_RECORD_FORK(") {
                    let f = tail
                        .split(')')
                        .next()
                        .unwrap()
                        .split(':')
                        .map(|x| x.parse::<u64>().unwrap())
                        .collect::<Vec<_>>();
                    if f[0] == pid {
                        forked.insert(f[1]);
                    }
                }
            }
            assert!(tids.is_subset(&forked));
            let attrs = fs::read_to_string(r(format!("runs/events-{name}/stdout.log"))).unwrap();
            for needle in ["cycles:u", "16000000", "CPU", "TIME", "PERIOD"] {
                assert!(attrs.contains(needle));
            }
            assert!(!attrs.contains("freq: 1"));
            assert_eq!(
                read(r(format!("runs/loss-{name}/stdout.log")))["zero_lost"],
                true
            );
            let data = r(format!("perf/{name}.data"));
            let owner = read(r(format!("runs/own-{name}/stdout.log")));
            assert_eq!(owner["sha256_before"], owner["sha256_after"]);
            assert_eq!(hash(&data), owner["sha256_before"]);
            let assigned = v["worker_rows"]
                .as_array()
                .unwrap()
                .iter()
                .map(|v| (v["tid"].as_u64().unwrap(), v["cpu"].as_u64().unwrap()))
                .collect::<BTreeMap<_, _>>();
            let mut count = 0u64;
            let mut unknown = 0;
            let mut bins = BTreeMap::<String, u64>::new();
            for l in fs::read_to_string(r(format!("runs/decode-{name}/stdout.log")))
                .unwrap()
                .lines()
                .filter(|l| !l.starts_with('#') && !l.trim().is_empty())
            {
                let f = l.split_whitespace().collect::<Vec<_>>();
                let (p, t) = f[0].split_once('/').unwrap();
                assert_eq!(p.parse::<u64>().unwrap(), pid);
                assert!(tids.contains(&t.parse::<u64>().unwrap()));
                let cpu = f[1].trim_matches(['[', ']']).parse::<u64>().unwrap();
                assert!(cpu < 32);
                let tid = t.parse::<u64>().unwrap();
                if tid != pid {
                    assert_eq!(assigned[&tid], cpu);
                }
                assert_eq!(f[3].parse::<u64>().unwrap(), 16000000);
                let raw = f[5..].join(" ");
                let sym = rustc_demangle::try_demangle(&raw)
                    .map(|v| format!("{v:#}"))
                    .unwrap_or(raw);
                if sym.starts_with("[unknown]") {
                    unknown += 1;
                }
                *bins.entry(sym).or_default() += 1;
                count += 1;
            }
            let unknown_share = unknown as f64 / count as f64;
            let qualified = count >= 1000 && unknown_share <= 0.05;
            if !qualified {
                failed.push(format!("{name}/profile"));
            }
            symbols_all.insert(name.clone(), json!(bins));
            profiles.insert(name,json!({"samples":count,"unknown_share":unknown_share,"qualified":qualified,"zero_lost":true,"PID":pid,"TIDs":tids,"raw_sha256":hash(data)}));
        }
    }
    save(r("profile-symbols.json"), &json!(symbols_all));

(json!(counters),json!(profiles))
}
