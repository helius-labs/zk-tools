// Benchmark-only exports, identical in REF/OFF/ON. No production API change.
#[inline(never)]
pub fn sparse_trial_g1(bases:&[zopro_bn254::G1Affine],words:&[[u64;4]],split:usize,bits:usize)->zopro_bn254::G1Affine{
    use zopro_bn254::G1Config;
    let result=if split==0{borrowed_pending::msm::<G1Config>(bases,words,1,12)}else{
        borrowed_pending::fused::<G1Config>(&bases[..split],&words[..split],&bases[split..],&words[split..],bits)
    };result.to_affine()
}
#[inline(never)]
pub fn sparse_trial_g2(bases:&[zopro_bn254::G2Affine],words:&mut[[u64;4]])->zopro_bn254::G2Affine{
    g2_phi::raw_exclusive(bases,words).to_affine()
}
pub fn sparse_trial_forecast(n:usize,split:usize,g2:bool)->usize{
    workspace::forecast(workspace::Geometry{wires:n,slots:0,inputs:n,public:0,domain:32768,a:if g2{0}else{n},b:if g2{n}else{0},k:if split==0{0}else{split},h:if split==0{0}else{n-split},correction:0}).expect("original required forecast").total
}
pub fn sparse_trial_hold_forecast(bytes:usize)->impl Drop {
    crate::preparation::Reservation::schedule(32768,Some(0),Some(bytes)).expect("required forecast token")
}
