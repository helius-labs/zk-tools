use serde_json::{json,Value};use std::{collections::BTreeMap,fs};const R:&str="/home/ubuntu/src/zopro-perf-work/xyzz-callers176";
fn read(f:&str)->Value{serde_json::from_slice(&fs::read(format!("{R}/{f}")).unwrap()).unwrap()}fn median(mut v:Vec<f64>)->f64{v.sort_by(f64::total_cmp);v[v.len()/2]}
fn main(){let a=read("analysis.json");let symbols=read("profile-symbols.json");let mut rows=vec![];
    for row in a["rows"].as_array().unwrap(){let name=row["context"].as_str().unwrap();let mut usage=json!({});for arm in["REF","OFF","ON"]{let mut stats=BTreeMap::new();for metric in["user_cpu_ms","system_cpu_ms","minor_faults","involuntary_switches"]{let values=(0..15).map(|b|a["caller_receipts"][format!("latency-{name}-b{b:02}-{arm}")]["usage"][metric].as_f64().unwrap()/15.).collect();stats.insert(metric,median(values));}usage[arm]=json!(stats);}
        let mut pmu=json!({});let mut tops=json!({});let mut candidate_samples=0;
        if !name.ends_with("w1"){for arm in["OFF","ON"]{let bins=symbols[format!("cycles-{name}-{arm}")].as_object().unwrap();let total=bins.values().map(|v|v.as_u64().unwrap()).sum::<u64>();let mut sorted=bins.iter().map(|(s,v)|(s.clone(),v.as_u64().unwrap())).collect::<Vec<_>>();sorted.sort_by_key(|(_,n)|std::cmp::Reverse(*n));tops[arm]=json!(sorted.into_iter().take(10).map(|(s,n)|json!({"symbol":s,"samples":n,"share":n as f64/total as f64})).collect::<Vec<_>>());if arm=="ON"{candidate_samples=bins.iter().filter(|(s,_)|s.contains("sparse_point::xyzz::Xyzz")).map(|(_,n)|n.as_u64().unwrap()).sum();}}
            for event in["cycles:u","instructions:u","cache-misses:u","branch-misses:u"]{let off=a["counters"][format!("stat-{name}-OFF")][event]["per_wave"].as_f64().unwrap();let on=a["counters"][format!("stat-{name}-ON")][event]["per_wave"].as_f64().unwrap();pmu[event]=json!({"OFF_per_MSM":off,"ON_per_MSM":on,"ON_OFF":on/off});}
        }
        println!("{} usage={} pmu={} XYZZnamespaceSamples={candidate_samples}",name,usage,pmu);
        rows.push(json!({"context":name,"median_usage_per_MSM":usage,"single_panel_PMU":pmu,"profile_top_symbols":tops,"XYZZ_type_namespace_samples":candidate_samples}));
    }
    fs::write(format!("{R}/diagnostic-summary.json"),serde_json::to_vec_pretty(&json!({"rows":rows,"interpretation_limits":"Separate descriptive PMU panels and flat symbols do not isolate wall-critical time or a unique cause. Namespace samples establish XYZZ Window execution; many include ordinary feed code with that type."})).unwrap()).unwrap();
}
