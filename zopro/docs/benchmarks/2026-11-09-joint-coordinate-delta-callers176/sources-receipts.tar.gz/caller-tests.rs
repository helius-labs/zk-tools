use ark_bn254::{Fq as A,Fq2 as A2,Fr as R,G1Affine as A1,G2Affine as A2P,G1Projective as P1,G2Projective as P2};
use ark_ec::{AffineRepr,CurveGroup,PrimeGroup};use ark_ff::{PrimeField,BigInteger};
use zopro_bn254::{Fq,Fq2,G1Affine,G2Affine};
use zopro_core::{G1Probe,G2Probe,joint_caller_routes as routes,joint_caller_layout as layout};
fn host(v:A)->Fq {Fq::from_le_bytes_mod_order(&v.into_bigint().to_bytes_le())}
fn h1(p:A1)->G1Affine {if p.is_zero(){G1Affine::IDENTITY}else{G1Affine::new(host(p.x),host(p.y))}}
fn h2(p:A2P)->G2Affine {if p.is_zero(){G2Affine::IDENTITY}else{G2Affine::new(Fq2::new(host(p.x.c0),host(p.x.c1)),Fq2::new(host(p.y.c0),host(p.y.c1)))}}
fn random(s:&mut u64)->R {let mut b=[0;32];for x in b.chunks_exact_mut(8){*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;x.copy_from_slice(&s.to_le_bytes());}R::from_le_bytes_mod_order(&b)}
struct Fixture {g1:Vec<A1>,g2:Vec<A2P>}
impl Fixture{fn new(seed:u64)->Self {let mut state=seed;let scalars=(0..64).map(|_|random(&mut state)).collect::<Vec<_>>();Self{g1:scalars.iter().map(|&v|(P1::generator()*v).into_affine()).collect(),g2:scalars.iter().map(|&v|(P2::generator()*v).into_affine()).collect()}}}
macro_rules! exercise {($name:ident,$ark:ty,$host:ty,$probe:ty,$convert:ident,$field:ident,$g2:expr)=>{
fn $name(f:&Fixture,n:usize,fast:bool,borrowed:bool,write:bool,vector:bool,seed:usize,rounds:usize)->usize {
    let size=n.max(1).next_power_of_two();let mut expected:Vec<$ark>=(0..size).map(|i|f.$field[(i*5+seed)%64]).collect();
    let mut got:Vec<$host>=expected.iter().copied().map($convert).collect();let mut probe=<$probe>::default();let mut caps=None;
    for round in 0..rounds {
        let batch:Vec<(u32,$host)>=(0..n).map(|i|{let k=(i*37+seed)%size;let p=expected[k];let mut j=(i*13+seed+round*11)%64;
            while f.$field[j].x==p.x{j=(j+1)%64;}
            let q=if round==0&&i%8==0{(-(p.into_group()+p)).into_affine()}else{f.$field[j]};
            assert!(!q.is_zero()&&!p.is_zero()&&q.x!=p.x);
            let negative=match round%3{0=>false,1=>true,_=>i%3!=0};
            let signed=if negative{-q}else{q};expected[k]=(p.into_group()+signed).into_affine();
            ((k as u32)|if negative{1<<31}else{0},$convert(q))
        }).collect();let saved=batch.clone();let before=routes();
        if $g2 { probe.apply_g2(&mut got,&batch,fast,borrowed,vector); }
        else { probe.apply_g1(&mut got,&batch,fast,borrowed,write,vector); }
        let after=routes();let mut want=[0;3];if fast{want[if $g2 {if borrowed{1}else{2}}else{0}]=n/8;}
        assert_eq!(std::array::from_fn::<_,3,_>(|i|after[i]-before[i]),want,"route n={n} fast={fast} borrowed={borrowed}");
        assert_eq!(batch,saved);assert_eq!(got,expected.iter().copied().map($convert).collect::<Vec<_>>(),"n={n} round={round} fast={fast} borrowed={borrowed} write={write} vector={vector}");
        let c=probe.capacities();if let Some(old)=caps{assert_eq!(old,c,"same-sized scratch reuse");}else{caps=Some(c);}
    }size*rounds
}
};}
// These tiny traits allow one oracle population to use both concrete facades.
trait Call1 {fn apply_g1(&mut self,b:&mut[G1Affine],v:&[(u32,G1Affine)],f:bool,r:bool,w:bool,i:bool);fn apply_g2(&mut self,_:&mut[G1Affine],_:&[(u32,G1Affine)],_:bool,_:bool,_:bool){unreachable!()}}
impl Call1 for G1Probe{fn apply_g1(&mut self,b:&mut[G1Affine],v:&[(u32,G1Affine)],f:bool,r:bool,w:bool,i:bool){self.apply(b,v,f,r,w,i)}}
trait Call2 {fn apply_g2(&mut self,b:&mut[G2Affine],v:&[(u32,G2Affine)],f:bool,r:bool,i:bool);fn apply_g1(&mut self,_:&mut[G2Affine],_:&[(u32,G2Affine)],_:bool,_:bool,_:bool,_:bool){unreachable!()}}
impl Call2 for G2Probe{fn apply_g2(&mut self,b:&mut[G2Affine],v:&[(u32,G2Affine)],f:bool,r:bool,i:bool){self.apply(b,v,f,r,i)}}
exercise!(g1,A1,G1Affine,G1Probe,h1,g1,false);
exercise!(g2,A2P,G2Affine,G2Probe,h2,g2,true);
#[test]fn changing_packets_all_tails_signs_storage_and_inverse_modes(){assert_eq!(layout(),[1600,64,640,8]);let f=Fixture::new(0x6a6f696e7463616c);let mut outputs=0;
    for n in (0..=17).chain(192..=200).chain(344..=352).chain([511,512]){for borrowed in[false,true]{for write in[false,true]{for vector in[false,true]{outputs+=g1(&f,n,true,borrowed,write,vector,19,3);if !write{outputs+=g2(&f,n,true,borrowed,write,vector,19,3);}}}}}
    println!("JOINT_COMPLETE changing_output_point_comparisons={outputs} candidate_routes={:?} all8tails=true",routes());
}
#[test]fn nonfast_controls_bypass_new_endpoints(){let f=Fixture::new(0x6e6f6e6661737433);let mut outputs=0;for n in[0,1,7,8,9,17,199,200,201,351,352,353,511,512]{for borrowed in[false,true]{for write in[false,true]{outputs+=g1(&f,n,false,borrowed,write,true,31,2);if !write{outputs+=g2(&f,n,false,borrowed,write,false,31,2);}}}}assert_eq!(routes(),[0;3]);println!("JOINT_NONFAST point_comparisons={outputs} routes=0");}
#[test]fn each_small_stack_worker_qualifies_all_candidate_routes(){use std::sync::atomic::{AtomicUsize,Ordering};let f=Fixture::new(0x776f726b65726433);let visits=AtomicUsize::new(0);let outputs=AtomicUsize::new(0);
    for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.broadcast(|context|{let seed=context.index()*2+7;let mut count=0;for n in[17,200,353]{count+=g1(&f,n,true,true,true,true,seed,3);count+=g1(&f,n,true,false,false,false,seed,3);count+=g2(&f,n,true,true,false,true,seed,3);count+=g2(&f,n,true,false,false,false,seed,3);}assert!(routes().iter().all(|&c|c>0));visits.fetch_add(1,Ordering::SeqCst);outputs.fetch_add(count,Ordering::SeqCst);});}
    assert_eq!(visits.load(Ordering::SeqCst),53);println!("JOINT_WORKERS visits=53 stack_request=524288 independent_point_comparisons={}",outputs.load(Ordering::SeqCst));
}
