#[cfg(zopro_joint_caller_diagnostics)]
std::thread_local! { static JOINT_ROUTES: std::cell::Cell<[usize;3]>=const {std::cell::Cell::new([0;3])}; }
#[cfg(zopro_joint_caller_diagnostics)]
#[inline(always)]fn joint_route(i:usize) { JOINT_ROUTES.with(|v|{let mut c=v.get();c[i]+=1;v.set(c);}); }
#[inline(always)]
fn joint_g1_finish(s:&FqBatch,ax:&FqBatch,bx:&FqBatch,ay:&FqBatch)->(FqBatch,FqBatch) {
    #[cfg(zopro_joint_caller_diagnostics)] joint_route(0);
    let (x,d)=s.mul(s).joint_x_delta(ax,bx);
    (x,d.mul(s).sub(ay))
}
#[inline(always)]
fn joint_g2_finish<const BORROWED:bool>(s:&[FqBatch;2],ax:&[FqBatch;2],bx:&[FqBatch;2],ay:&[FqBatch;2])->([FqBatch;2],[FqBatch;2]) {
    #[cfg(zopro_joint_caller_diagnostics)] joint_route(if BORROWED{1}else{2});
    let square=Fq2::lanes_square(s);
    let(x0,d0)=square[0].joint_x_delta(&ax[0],&bx[0]);
    let(x1,d1)=square[1].joint_x_delta(&ax[1],&bx[1]);
    let y=crate::simd::JointDelta::complex_mul(&d0,&d1,s);
    ([x0,x1],Fq2::lanes_sub(&y,ay))
}
