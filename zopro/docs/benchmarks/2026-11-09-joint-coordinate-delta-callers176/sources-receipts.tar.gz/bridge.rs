// This bridge retains Delta3's type and never exports it as an ordinary field.
pub(crate) struct JointDelta(zopro_bn254::ifma8::AffineDelta3<FqConfig>);
impl FqBatch {
    #[inline(always)]
    pub(crate) fn joint_x_delta(&self, ax: &Self, bx: &Self) -> (Self, JointDelta) {
        let (x,d)=self.0.joint_x_delta(&ax.0,&bx.0); (Self(x),JointDelta(d))
    }
}
impl JointDelta {
    #[inline(always)]
    pub(crate) fn mul(&self,s:&FqBatch)->FqBatch { FqBatch(self.0.mul(&s.0)) }
    #[inline(always)]
    pub(crate) fn complex_mul(d0:&Self,d1:&Self,s:&[FqBatch;2])->[FqBatch;2] {
        zopro_bn254::ifma8::AffineDelta3::complex_mul(&d0.0,&d1.0,&s[0].0,&s[1].0).map(FqBatch)
    }
}
