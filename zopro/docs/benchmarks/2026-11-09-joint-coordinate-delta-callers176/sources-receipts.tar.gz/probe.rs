// Qualification facade only. Vector construction here is not a kernel allocation.
#[derive(Default)]pub struct G1Probe { scratch:FqAddScratch }
impl G1Probe {
    pub fn apply(&mut self,b:&mut[G1Affine],batch:&[(u32,G1Affine)],fast:bool,borrowed:bool,write:bool,vector:bool) {
        self.scratch.write_groups=write;self.scratch.reserve_groups=true;self.scratch.vector_inverse=vector;
        if borrowed {let refs:Vec<_>=batch.iter().map(|(i,p)|(*i,p)).collect();
            if fast {stream_g1_impl::<G1Config,true,true>(b,&refs,&mut self.scratch)}else{stream_g1_impl::<G1Config,false,true>(b,&refs,&mut self.scratch)}
        }else{let owned:Vec<_>=batch.iter().map(|&(i,p)|(i&0x7fffffff,if i>>31!=0{-p}else{p})).collect();
            if fast {stream_g1_impl::<G1Config,true,false>(b,&owned,&mut self.scratch)}else{stream_g1_impl::<G1Config,false,false>(b,&owned,&mut self.scratch)}
        }
    }
    pub fn capacities(&self)->[usize;2]{[self.scratch.groups.capacity()*core::mem::size_of::<FqAddGroup>(),self.scratch.tail.capacity()*core::mem::size_of::<[Fq;5]>()]}
}
#[derive(Default)]pub struct G2Probe { scratch:Fq2AddScratch }
impl G2Probe {
    pub fn apply(&mut self,b:&mut[G2Affine],batch:&[(u32,G2Affine)],fast:bool,borrowed:bool,vector:bool) {
        self.scratch.vector_inverse=vector;
        if borrowed{let refs:Vec<_>=batch.iter().map(|(i,p)|(*i,p)).collect();
            if fast{super::g2_borrowed::apply::<G2Config,true>(b,&refs,&mut self.scratch)}else{super::g2_borrowed::apply::<G2Config,false>(b,&refs,&mut self.scratch)}
        }else{let owned:Vec<_>=batch.iter().map(|&(i,p)|(i&0x7fffffff,if i>>31!=0{-p}else{p})).collect();
            if fast{super::g2_prefix::apply::<G2Config,true>(b,&owned,&mut self.scratch)}else{super::g2_prefix::apply::<G2Config,false>(b,&owned,&mut self.scratch)}
        }
    }
    pub fn capacities(&self)->[usize;3]{[self.scratch.prefix_records.capacity()*core::mem::size_of::<[FqBatch;2]>(),self.scratch.tail.capacity()*core::mem::size_of::<[Fq2;5]>(),self.scratch.groups.capacity()*core::mem::size_of::<Fq2AddGroup>()]}
}
pub fn routes()->[usize;3] { #[cfg(zopro_joint_caller_diagnostics)]{return JOINT_ROUTES.with(|v|v.get());} #[cfg(not(zopro_joint_caller_diagnostics))]{[0;3]} }
pub fn record_layout()->[usize;4]{[core::mem::size_of::<FqAddGroup>(),core::mem::align_of::<FqAddGroup>(),core::mem::size_of::<[FqBatch;2]>(),LANES]}
