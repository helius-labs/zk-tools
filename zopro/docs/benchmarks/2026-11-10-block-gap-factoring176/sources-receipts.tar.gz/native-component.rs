use super::*;
fn component(bases:&[G2Affine],short:&[[u64;4]],high:bool)->(Vec<G2Affine>,Vec<[u64;4]>){
 let offset=usize::from(high)*2;
 let mut order=short.iter().enumerate().filter_map(|(i,s)|{let m=s[offset]as u128|((s[offset+1]&0x7fff_ffff_ffff_ffff)as u128)<<64;(m!=0&&!bases[i].is_identity()).then_some((m,i,s[offset+1]>>63!=0))}).collect::<Vec<_>>();
 order.sort_unstable_by_key(|&(m,i,_)|(m,i));
 let mut suffix=crate::msm::block_gap_suffix(bases,&order);let mut words=Vec::with_capacity(suffix.len());let mut write=0;
 for(j,&(m,_,_))in order.iter().enumerate(){let d=if j%256==0{m}else{m-order[j-1].0};if d==0||suffix[j].is_identity(){continue}suffix[write]=suffix[j];write+=1;
  let mut s=[0u64;4];s[offset]=d as u64;s[offset+1]=(d>>64)as u64;words.push(s);
 }
 suffix.truncate(write);(suffix,words)
}
pub(super) fn prepare(bases:&[G2Affine],short:&[[u64;4]])->(Vec<G2Affine>,Vec<[u64;4]>){
 let((mut low,mut lw),(mut high,mut hw))=rayon::join(||component(bases,short,false),||component(bases,short,true));
 low.append(&mut high);lw.append(&mut hw);(low,lw)
}
