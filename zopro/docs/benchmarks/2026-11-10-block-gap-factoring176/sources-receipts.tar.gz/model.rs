use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{collections::{BTreeMap,BTreeSet},fs,path::Path,str::FromStr};
use ark_bn254::{Fq,Fq2,Fr,G2Affine,G2Projective};
use ark_ec::{AffineRepr,CurveGroup,VariableBaseMSM};
use ark_ff::{AdditiveGroup,PrimeField,Zero};
const R:&str="/home/ubuntu/src/zopro-perf-work/block-gap-factoring176";
type Word=[u64;4];mod split;include!("groups.rs");include!("original-booth.rs");
include!("weighted.rs");
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(b:&[u8])->String{format!("{:x}",Sha256::digest(b))}
fn point_hash(p:G2Affine)->String{let mut h=Sha256::new();if p.is_zero(){h.update([0u8;128]);}else{for f in[p.x.c0,p.x.c1,p.y.c0,p.y.c1]{for w in f.into_bigint().0{h.update(w.to_le_bytes())}}}format!("{:x}",h.finalize())}
fn summarize(parts:&[Vec<(u128,bool)>;2],presence:&[Vec<bool>;2],bits:usize,windows:usize,grouping:usize,scan_adds:usize)->Value{
    let mut total=Cost::default();let mut rows=vec![];let mut live=vec![];let mut visits=0usize;
    for w in 0..windows{let top=bits.saturating_sub(w*12);let n=if w+1==windows&&top<=8{1usize<<top}else{2048};let mut counts: [Vec<u64>;2]=std::array::from_fn(|_|vec![0;n]);
        for component in 0..2{let chunk=parts[component].len().div_ceil(2);for(i,&(m,negative))in parts[component].iter().enumerate(){if !presence[component][i]{continue}let sign=if negative{-1}else{1};let d=booth_digit(&[m as u64,(m>>64)as u64,0,0],w,12)*sign;if d==0{continue}let b=d.unsigned_abs()as usize-1;assert!(b<n);let part=usize::from(i>=chunk);counts[part][b]+=1;visits+=1;}}
        let arrivals=counts.iter().map(|v|v.iter().sum::<u64>()).sum::<u64>();let occupied=(0..n).filter(|&i|counts[0][i]>0||counts[1][i]>0).count()as u64;let leaves=(0..n).map(|i|Node(i128::from(counts[0][i]>0||counts[1][i]>0))).collect::<Vec<_>>();let mut packed=vec![0u8;n.div_ceil(8)];for(i,p)in leaves.iter().enumerate(){if p.0!=0{packed[i/8]|=1<<(i%8);}}let occupancy=packed.iter().map(|v|format!("{v:02x}")).collect::<String>();let(weighted_value,_,mut c)=weighted(&leaves);c.affine_pairs+=arrivals-occupied;total.plus(c);live.push(weighted_value.0!=0);rows.push(json!({"window":w,"physical_buckets":n,"nonzero_nonidentity_arrivals":arrivals,"occupied_final_buckets_generic_no_cancellation":occupied,"occupancy_bits_LE_hex":occupancy,"fill_and_part_merge_joins":arrivals-occupied,"weighted_and_fill":c.value()}));
    }
    let mut horner=Cost::default();let mut present=false;for b in live.into_iter().rev(){for _ in 0..12{horner.invoked_doubles+=1;if present{horner.active_doubles+=1;}}if present&&b{horner.projective_adds+=1;}present|=b;}total.plus(horner);total.affine_pairs+=grouping as u64+scan_adds as u64;
    json!({"bits_bound":bits,"width":12,"parts":2,"windows":windows,"common_generic_grouping_joins":grouping,"actual_scan_nonidentity_joins":scan_adds,"nonzero_nonidentity_arrivals":visits,"cost":total.value(),"Horner":horner.value(),"windows_detail":rows})
}
fn transform(points:&[G2Affine],terms:&[(u128,bool)])->(Vec<G2Affine>,Vec<(u128,bool)>,Value){
 assert_eq!(points.len(),terms.len());
 let mut order=terms.iter().enumerate().filter(|(i,(m,_))|*m!=0&&!points[*i].is_zero()).map(|(i,&(m,s))|(m,i,s)).collect::<Vec<_>>();
 order.sort_unstable_by_key(|&(m,i,_)|(m,i));
 let mut suffix=vec![G2Projective::ZERO;order.len()];let mut joins=0usize;let mut stage_pairs=[0usize;255];
 for (block,rows) in order.chunks(256).enumerate(){let mut acc=G2Projective::ZERO;
  for (j,&(_,i,s)) in rows.iter().enumerate().rev(){let q=if s{-points[i].into_group()}else{points[i].into_group()};
   if !acc.is_zero()&&!q.is_zero(){joins+=1;stage_pairs[rows.len()-1-j-1]+=1;}
   acc+=q;suffix[block*256+j]=acc;
  }
 }
 let got=G2Projective::normalize_batch(&suffix);
 let(mut output,mut coefficients)=(vec![],vec![]);let(mut max_bits,mut max_gap_bits,mut zeros,mut identities,mut corrections,mut gap_outputs)=(0usize,0usize,0usize,0usize,0usize,0usize);
 let mut order_hash=Sha256::new();let mut payload_hash=Sha256::new();let mut identity_positions=vec![];
 for(j,&(m,i,negative))in order.iter().enumerate(){
  order_hash.update(m.to_le_bytes());order_hash.update((i as u64).to_le_bytes());order_hash.update([u8::from(negative)]);
  let correction=j%256==0;let d=if correction{m}else{m-order[j-1].0};
  let bits=if d==0{0}else{128-d.leading_zeros()as usize};max_bits=max_bits.max(bits);if !correction{max_gap_bits=max_gap_bits.max(bits);}
  payload_hash.update(d.to_le_bytes());payload_hash.update([u8::from(correction)]);payload_hash.update(point_hash(got[j]).as_bytes());
  if d==0{zeros+=1;continue}if got[j].is_zero(){identities+=1;identity_positions.push(j);continue}
  if correction{corrections+=1}else{gap_outputs+=1}output.push(got[j]);coefficients.push((d,false));
 }
 let out=json!({"input_scan_rows":order.len(),"block_size":256,"blocks":order.len().div_ceil(256),"nonidentity_scan_joins":joins,"linear_scan_structural_edges":order.len().saturating_sub(order.len().div_ceil(256)),"nonzero_gap_outputs":gap_outputs,"high_bit_correction_outputs":corrections,"nonzero_coefficient_outputs":coefficients.len(),"zero_gaps_dropped":zeros,"identity_coefficient_outputs_dropped":identities,"identity_coefficient_sorted_positions":identity_positions,"maximum_gap_bits":max_gap_bits,"maximum_coefficient_bits":max_bits,"sort_and_sign_order_sha256":format!("{:x}",order_hash.finalize()),"coefficient_point_payload_sha256":format!("{:x}",payload_hash.finalize()),"all_block_coefficients_reconstruct_by_telescoping":true,"affine_plan_dependency_stages":stage_pairs.iter().filter(|p|**p>0).count(),"affine_plan_pairs_per_stage":stage_pairs.to_vec(),"affine_plan_minimum_nonempty_batch_inversions":stage_pairs.iter().filter(|p|**p>0).count(),"point_scan_is_offline_Arkworks_projective":true});
 (output,coefficients,out)
}
fn main(){
    assert!(!Path::new(R).join("analysis.json").exists());for(p,h)in read(format!("{R}/pins.json")).as_object().unwrap(){assert_eq!(hash(&fs::read(p).unwrap()),h.as_str().unwrap());}
    let old=read("/home/ubuntu/src/zopro-perf-work/iterative-bands176/analysis.json");let lambda=Fr::from_str("4407920970296243842393367215006156084916469457145843978461").unwrap();let beta=Fq::from_str("21888242871839275220042445260109153167277707414472061641714758635765020556616").unwrap();let mut cases=BTreeMap::new();let mut gates=BTreeMap::new();
    for shape in["1x2","2x2"]{
        let prior=&old["cases"][shape];let fixture=prior["fixture_path"].as_str().unwrap();let bytes=fs::read(fixture).unwrap();assert_eq!(hash(&bytes),prior["fixture_sha256"]);assert_eq!(&bytes[..8],b"B2SCAN01");let n=u64::from_le_bytes(bytes[8..16].try_into().unwrap())as usize;assert_eq!(bytes.len(),16+160*n);
        let field=|b:&[u8]|{let words=std::array::from_fn(|i|u64::from_be_bytes(b[24-i*8..32-i*8].try_into().unwrap()));Fq::from_bigint(ark_ff::BigInt(words)).unwrap()};
        let points=bytes[16..16+128*n].chunks_exact(128).map(|p|{if p.iter().all(|v|*v==0){G2Affine::zero()}else{let q=G2Affine::new_unchecked(Fq2::new(field(&p[32..64]),field(&p[..32])),Fq2::new(field(&p[96..128]),field(&p[64..96])));assert!(q.is_on_curve());q}}).collect::<Vec<_>>();let raw=bytes[16+128*n..].chunks_exact(32).map(|b|std::array::from_fn(|i|u64::from_le_bytes(b[8*i..8*i+8].try_into().unwrap()))).collect::<Vec<Word>>();let grouping=groups(&raw);let mut group_joins=0usize;
        let(values,bases)=if let Some((values,classes))=&grouping{let mut sums=vec![G2Projective::ZERO;values.len()];let mut count=vec![0usize;values.len()];for(i,&c)in classes.iter().enumerate(){if c!=usize::MAX&&!points[i].is_zero(){sums[c]+=points[i];count[c]+=1;}}group_joins=count.iter().map(|n|n.saturating_sub(1)).sum();(values.clone(),G2Projective::normalize_batch(&sums))}else{(raw.clone(),points)};assert_eq!(values.len(),prior["scalar_terms"]);assert_eq!(grouping.is_some(),prior["grouping_selected"]);let sd=values.iter().flat_map(|v|v.iter().rev().flat_map(|w|w.to_be_bytes())).collect::<Vec<_>>();assert_eq!(hash(&sd),prior["scalar_values_BE_sha256"]);
        let mut original:[Vec<(u128,bool)>;2]=std::array::from_fn(|_|vec![]);for &v in&values{let s=split::phi_split(v);let mut reconstruction=Fr::ZERO;for c in 0..2{let m=s[c*2]as u128|((s[c*2+1]&0x7fff_ffff_ffff_ffff)as u128)<<64;let negative=s[c*2+1]>>63!=0;assert!(m<1u128<<126);let mut x=Fr::from(m);if negative{x=-x;}reconstruction+=if c==0{x}else{lambda*x};original[c].push((m,negative));}assert_eq!(reconstruction,Fr::from_bigint(ark_ff::BigInt(v)).unwrap());}
        let presence=std::array::from_fn(|_|bases.iter().map(|p|!p.is_zero()).collect());let baseline=summarize(&original,&presence,126,11,group_joins,0);
        let mut candidate:[Vec<(u128,bool)>;2]=std::array::from_fn(|_|vec![]);let mut component_reports=vec![];let mut results=[G2Projective::ZERO;2];let mut scan_rows=0usize;let mut scan_joins=0usize;let mut bits=0usize;
        for c in 0..2{let(p,terms,r)=transform(&bases,&original[c]);scan_rows+=r["input_scan_rows"].as_u64().unwrap()as usize;scan_joins+=r["nonidentity_scan_joins"].as_u64().unwrap()as usize;bits=bits.max(r["maximum_coefficient_bits"].as_u64().unwrap()as usize);let scalars=terms.iter().map(|(m,_)|Fr::from(*m)).collect::<Vec<_>>();results[c]=G2Projective::msm(&p,&scalars).unwrap();candidate[c]=terms;component_reports.push(r);}
        let high=results[1].into_affine();let high=if high.is_zero(){high}else{G2Affine::new_unchecked(Fq2::new(high.x.c0*beta,high.x.c1*beta),high.y)};let answer=(results[0]+high).into_affine();let oracle_path=format!("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/oracle-fixed-runs/oracle-{shape}/stdout.log");let oracle=read(&oracle_path);assert_eq!(oracle["independent_Arkworks_complete_MSM"],true);assert_eq!(oracle["fixture_sha256"],hash(&bytes));assert_eq!(point_hash(answer),oracle["expected_canonical_result_sha256"]);
        let windows=(bits+1).div_ceil(12).max(1);let presence=std::array::from_fn(|c|vec![true;candidate[c].len()]);let cost=summarize(&candidate,&presence,bits,windows,group_joins,scan_joins);let before=baseline["cost"]["all_point_add_calls"].as_u64().unwrap();let after=cost["cost"]["all_point_add_calls"].as_u64().unwrap();gates.insert(format!("{shape}/fewer_complete_generic_point_adds"),after<before);gates.insert(format!("{shape}/active_doublings_not_increased"),cost["cost"]["active_doublings"].as_u64().unwrap()<=baseline["cost"]["active_doublings"].as_u64().unwrap());
        let new_payload=scan_rows.checked_mul(128+32+16+8+32).unwrap();let inherited_words=values.len().checked_mul(32).unwrap();let checked_total=new_payload.checked_add(inherited_words).unwrap();gates.insert(format!("{shape}/checked_payload"),checked_total>=new_payload);
        cases.insert(shape,json!({"fixture_sha256":hash(&bytes),"oracle_sha256":hash(&fs::read(oracle_path).unwrap()),"input_rows":n,"grouping_admitted":grouping.is_some(),"scalar_terms":values.len(),"scalar_values_BE_sha256":hash(&sd),"grouped_input_identity_points":bases.iter().filter(|p|p.is_zero()).count(),"component_reports":component_reports,"baseline":baseline,"candidate":cost,"generic_point_add_ratio":after as f64/before as f64,"new_native_logical_payload_bytes":new_payload,"unchanged_mutable_scalar_words_bytes":inherited_words,"checked_total_payload_bytes":checked_total,"new_complete_Arkworks_result_matches_retained_oracle":true,"final_point_sha256":point_hash(answer)}));
    }
    let ledger="/home/ubuntu/src/zopro-perf-work/retained-tail-sdk176/proof-sha256-after-capture.json";assert_eq!(read(ledger).as_array().unwrap().len(),45335);let selected=gates.values().all(|p|*p);let out=json!({"cases":cases,"necessary_checks":gates,"native_selected":selected,"new_native_kernel":false,"new_complete_Arkworks_MSMs":4,"new_native_timing":false,"canonical_proofs":45335,"new_proofs":0,"production_unchanged":true,"adopted":false,"goal_complete":false,"model_limit":"generic fill/merge/weighted/Horner plus actual block scans and full-width base corrections; no native latency/field/inversion-cost equivalence"});fs::write(format!("{R}/analysis.json"),serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("BLOCK_GAP native_selected={selected} cases2 newcomponentArkMSMs4 checks6");for(shape,c)in out["cases"].as_object().unwrap(){println!("{shape} original_adds={} new_adds={} ratio={} scan_joins={} new_payload_bytes={}",c["baseline"]["cost"]["all_point_add_calls"],c["candidate"]["cost"]["all_point_add_calls"],c["generic_point_add_ratio"],c["candidate"]["actual_scan_nonidentity_joins"],c["new_native_logical_payload_bytes"]);}
}

#[cfg(test)]mod tests{
 use super::*;
 #[test]fn ragged_block_factoring_signed_integer_identity(){
  let mut cases=0;for n in[0usize,1,2,3,7,8,17,31,127,255,256,257,511,512,513,769,1024]{for seed in 0..32i128{
   let mut rows=(0..n).map(|i|(((i as i128*13+seed*7)%1031),i,(i as i128*19+seed)%101-50)).collect::<Vec<_>>();
   let expected=rows.iter().map(|(m,_,p)|m*p).sum::<i128>();rows.sort_unstable_by_key(|&(m,i,_)|(m,i));
   let mut got=0;for block in rows.chunks(256){let mut suffix=0i128;for(j,&(m,_,p))in block.iter().enumerate().rev(){suffix+=p;let d=if j==0{m}else{m-block[j-1].0};got+=d*suffix;}}
   assert_eq!(got,expected,"n={n} seed={seed}");cases+=1;
  }}assert_eq!(cases,544);println!("BLOCK_GAP_INTEGER_CASES={cases}");
 }
 #[test]fn curve_exceptional_blocks_and_boundaries(){
  let generator=G2Affine::generator();let mut cases=0;for n in[0usize,1,2,7,255,256,257,513]{for mode in 0..4{
   let points=(0..n).map(|i|match mode{0=>G2Affine::zero(),1=>generator,2=>if i%2==0{generator}else{-generator},_=>if i%7==0{G2Affine::zero()}else{generator}}).collect::<Vec<_>>();
   let terms=(0..n).map(|i|(((i*13%101)as u128),i%3==0)).collect::<Vec<_>>();
   let (p,c,report)=transform(&points,&terms);let expected=points.iter().zip(&terms).map(|(p,&(m,s))|p.mul_bigint(Fr::from(m).into_bigint())*if s{-Fr::from(1u64)}else{Fr::from(1u64)}).sum::<G2Projective>();
   let scalars=c.iter().map(|v|Fr::from(v.0)).collect::<Vec<_>>();assert_eq!(G2Projective::msm(&p,&scalars).unwrap(),expected);
   assert_eq!(report["block_size"],256);cases+=1;
  }}assert_eq!(cases,32);println!("BLOCK_GAP_CURVE_EXCEPTION_CASES={cases}");
 }
}
