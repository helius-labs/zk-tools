use super::*;
use zopro_bn254::{G2Affine,G2Config};

pub(crate) fn suffix(bases:&[G2Affine],order:&[(u128,usize,bool)])->Vec<G2Affine>{
 let mut out=vec![G2Affine::IDENTITY;order.len()];let blocks=order.len().div_ceil(256);
 let mut accum=vec![G2Affine::IDENTITY;blocks];
 let signed=|row:(u128,usize,bool)|if row.2{-bases[row.1]}else{bases[row.1]};
 for (k,rows)in order.chunks(256).enumerate(){let end=k*256+rows.len()-1;accum[k]=signed(rows[rows.len()-1]);out[end]=accum[k];}
 let mut scratch=Fq2AddScratch{canonical:true,vector_inverse:true,
  #[cfg(all(zopro_g2_prefix_records,feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma)))]
  prefix_enabled:std::env::var("ZOPRO_CPU_G2_PREFIX_RECORDS").as_deref()==Ok("1"),
  ..Default::default()};
 let mut batch=Vec::with_capacity(blocks);
 for depth in 1..256{batch.clear();
  for(k,rows)in order.chunks(256).enumerate(){if rows.len()<=depth{continue}let b=signed(rows[rows.len()-1-depth]);let a=accum[k];
   if a.is_identity(){accum[k]=b;}else if b.is_identity(){}else if a.x==b.x{accum[k]=(a+b).to_affine();}else{batch.push((k as u32,b));}
  }
  if !batch.is_empty(){stream_g2::<G2Config>(&mut accum,&batch,&mut scratch);}
  for(k,rows)in order.chunks(256).enumerate(){if rows.len()>depth{out[k*256+rows.len()-1-depth]=accum[k];}}
 }
 out
}

#[cfg(test)]mod tests{
 use super::*;
 #[test]fn suffix_matches_complete_formulas_at_block_boundaries(){
  let generator=G2Affine::GENERATOR;let mut compared=0usize;
  for n in[0usize,1,2,7,255,256,257,511,512,513,1025]{for mode in 0..5{
   let bases=(0..n).map(|i|match mode{0=>G2Affine::IDENTITY,1=>generator,2=>if i%2==0{generator}else{-generator},3=>if i%7==0{G2Affine::IDENTITY}else{generator},_=>if i%3==0{generator}else{generator.to_projective().double().to_affine()}}).collect::<Vec<_>>();
   let order=(0..n).map(|i|((i as u128)*3,i,i%5==0)).collect::<Vec<_>>();let got=suffix(&bases,&order);
   for(k,rows)in order.chunks(256).enumerate(){let mut expected=zopro_bn254::G2Projective::IDENTITY;for(j,row)in rows.iter().enumerate().rev(){expected+=if row.2{-bases[row.1]}else{bases[row.1]};assert_eq!(got[k*256+j],expected.to_affine(),"n={n} mode={mode} j={j}");compared+=1;}}
  }}println!("NATIVE_BLOCK_SUFFIX_POINTS={compared}");
 }
}
