#[derive(Default,Clone,Copy,Debug,PartialEq,Eq)]struct Cost{affine_pairs:u64,projective_adds:u64,active_doubles:u64,invoked_doubles:u64}
impl Cost{fn plus(&mut self,b:Self){self.affine_pairs+=b.affine_pairs;self.projective_adds+=b.projective_adds;self.active_doubles+=b.active_doubles;self.invoked_doubles+=b.invoked_doubles;}fn adds(&self)->u64{self.affine_pairs+self.projective_adds}fn value(&self)->Value{json!({"affine_tree_or_fill_pairs":self.affine_pairs,"projective_add_sub_calls":self.projective_adds,"all_point_add_calls":self.adds(),"active_doublings":self.active_doubles,"invoked_doublings":self.invoked_doubles})}}
#[derive(Clone,Copy,Default)]struct Node(i128);
fn add(a:Node,b:Node,c:&mut Cost)->Node{if a.0!=0&&b.0!=0{c.projective_adds+=1;}Node(a.0+b.0)}
fn sub(a:Node,b:Node,c:&mut Cost)->Node{if a.0!=0&&b.0!=0{c.projective_adds+=1;}Node(a.0-b.0)}
fn double(a:Node,c:&mut Cost)->Node{c.invoked_doubles+=1;if a.0!=0{c.active_doubles+=1;}Node(2*a.0)}
fn weighted_group(input:&[Node],cost:&mut Cost)->(Node,Node){
 assert!(input.len().is_power_of_two());let n=input.len();let mut points=vec![Node::default();2*n-1];points[..n].copy_from_slice(input);let(mut starts,mut counts)=(vec![0],vec![n]);let mut next=n;
 while counts[0]>1{let half=counts[0]/2;for i in 0..half{points[next+i]=points[2*i];}
  for(&first,count)in starts.iter().zip(counts.iter_mut()){for i in(0..count.saturating_sub(1)).step_by(2){let(a,b)=(points[first+i],points[first+i+1]);if a.0!=0&&b.0!=0{cost.affine_pairs+=1;}points[first+i/2]=Node(a.0+b.0);}if *count%2!=0{points[first+*count/2]=points[first+*count-1];}*count=count.div_ceil(2);}
  starts.push(next);counts.push(half);next+=half;
 }
 let total=points[0];let mut weighted=total;for&first in starts[1..].iter().rev(){weighted=double(weighted,cost);weighted=sub(weighted,points[first],cost);}
 assert_eq!(weighted.0,input.iter().enumerate().map(|(i,p)|(i as i128+1)*p.0).sum::<i128>());assert_eq!(total.0,input.iter().map(|p|p.0).sum::<i128>());(weighted,total)
}
fn weighted(input:&[Node])->(Node,Node,Cost){
 let mut cost=Cost::default();let partials=input.chunks(256).map(|p|weighted_group(p,&mut cost)).collect::<Vec<_>>();let(mut sum,mut offset,mut running)=(Node(0),Node(0),Node(0));for(w,t)in partials.into_iter().rev(){sum=add(sum,w,&mut cost);offset=add(offset,running,&mut cost);running=add(running,t,&mut cost);}for _ in 0..8{offset=double(offset,&mut cost);}let result=add(sum,offset,&mut cost);assert_eq!(result.0,input.iter().enumerate().map(|(i,p)|(i as i128+1)*p.0).sum::<i128>());assert_eq!(running.0,input.iter().map(|p|p.0).sum::<i128>());(result,running,cost)
}