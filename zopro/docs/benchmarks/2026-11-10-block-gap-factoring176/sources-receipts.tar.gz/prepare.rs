use serde_json::{json,Value}; use sha2::{Digest,Sha256};
use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/block-gap-factoring176";
const G:&str="/home/ubuntu/src/zopro-perf-work/sorted-gap-scan176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){
 assert!(!Path::new(R).join("plan.json").exists());
 for f in["split.rs","groups.rs","original-booth.rs","weighted.rs"]{fs::copy(format!("{G}/{f}"),format!("{R}/{f}")).unwrap();}
 let old=fs::read_to_string(format!("{G}/model.rs")).unwrap();
 let prefix=&old[..old.find("fn scan<T:Copy>").unwrap()];
 let summarize=&old[old.find("fn summarize(").unwrap()..old.find("fn transform(").unwrap()];
 let transform=fs::read_to_string(format!("{R}/transform.inc")).unwrap();
 let mut main=old[old.find("fn main(){").unwrap()..old.find("\n#[cfg(test)]").unwrap()].to_string();
 main=main.replace("/home/ubuntu/src/zopro-perf-work/large-class-sdk176/proof-sha256-after-capture.json","/home/ubuntu/src/zopro-perf-work/retained-tail-sdk176/proof-sha256-after-capture.json").replace("43730","45335");
 main=main.replace("SORTED_GAP","BLOCK_GAP");
 main=main.replace("r[\"maximum_gap_bits\"]","r[\"maximum_coefficient_bits\"]");
 main=main.replace("generic fill/merge/weighted/Horner joins plus actual scan joins; no cancellation/exception/queue/inversion/sorting/packing/normalization/scheduling cost equivalence","generic fill/merge/weighted/Horner plus actual block scans and full-width base corrections; no native latency/field/inversion-cost equivalence");
 let tests=fs::read_to_string(format!("{R}/tests.inc")).unwrap();
 fs::write(format!("{R}/model.rs"),format!("{}{}{}{}{}",prefix.replace(G,R),summarize,transform,main,tests)).unwrap();
 let reviewer=fs::read_to_string(format!("{G}/review.rs")).unwrap();let reader_prefix=&reviewer[..reviewer.find("fn main(){").unwrap()];
 fs::write(format!("{R}/review.rs"),format!("{}{}",reader_prefix.replace(G,R),fs::read_to_string(format!("{R}/review.inc")).unwrap())).unwrap();
 let mut pins=BTreeMap::new();let m=read(format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json"));
 for(rel,h)in m["source_files_sha256"].as_object().unwrap(){let p=format!("{Z}/{rel}");assert_eq!(hash(&p),h.as_str().unwrap());pins.insert(p,h.clone());}
 for f in["design.md","prepare.rs","prepare","transform.inc","tests.inc","review.inc","model.rs","review.rs","split.rs","groups.rs","original-booth.rs","weighted.rs"]{let p=format!("{R}/{f}");pins.insert(p.clone(),json!(hash(p)));}
 for p in[format!("{G}/analysis.json"),format!("{G}/model.rs"),"/home/ubuntu/src/zopro-perf-work/iterative-bands176/analysis.json".into(),"/home/ubuntu/src/zopro-perf-work/retained-tail-sdk176/proof-sha256-after-capture.json".into()]{pins.insert(p.clone(),json!(hash(p)));}
 for shape in["1x2","2x2"]{for p in[format!("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/inputs/{shape}.b2q"),format!("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/oracle-fixed-runs/oracle-{shape}/stdout.log")]{pins.insert(p.clone(),json!(hash(p)));}}
 let mut plan=read(format!("{G}/plan.json"));plan["source_pins"]=json!(format!("{R}/pins.json"));for step in plan["steps"].as_array_mut().unwrap(){for arg in step["argv"].as_array_mut().unwrap(){if let Some(a)=arg.as_str(){*arg=json!(a.replace(G,R));}}
  for a in step["argv"].as_array().unwrap(){let a=a.as_str().unwrap();let p=a.split_once('=').map_or(a,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.into(),json!(hash(p)));}}
 }
 fs::write(format!("{R}/plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();pins.insert(format!("{R}/plan.json"),json!(hash(format!("{R}/plan.json"))));fs::write(format!("{R}/pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();println!("Prepared fixed256 block factoring /6 serialized commands /{} pins",pins.len());
}
