use std::{fs,path::Path};use serde_json::{Value,json};use sha2::{Sha256,Digest};
const R:&str="/home/ubuntu/src/zopro-perf-work/shifted-c7a197";
fn main(){
 let prod=Path::new("/home/ubuntu/src/zk-tools/zopro");
 let manifest:Value=serde_json::from_slice(&fs::read(prod.join("docs/benchmarks/2026-11-17-certified-all196/artifacts/production-source-manifest.json")).unwrap()).unwrap();
 let members=manifest["source_files_sha256"].as_object().unwrap();assert_eq!(members.len(),179);
 for(p,h)in members{assert_eq!(format!("{:x}",Sha256::digest(fs::read(prod.join(p)).unwrap())),h.as_str().unwrap());}
 fs::write(format!("{R}/manifest.json"),serde_json::to_vec_pretty(&json!({"files":members})).unwrap()).unwrap();
 let ov=Path::new(R).join("overlay/crates/zopro-core/src");
 let mut parent=fs::read_to_string(prod.join("crates/zopro-core/src/msm_affine.rs")).unwrap();parent.push_str("\n#[cfg(test)]\nmod server_shifted;\n");fs::write(ov.join("msm_affine.rs"),parent).unwrap();
 let mut child=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/shifted-identity188/source/crates/zopro-core/src/msm_affine/server_shifted.rs").unwrap();let end=child.rfind('}').unwrap();child.insert_str(end,&fs::read_to_string(format!("{R}/test.rs")).unwrap());fs::write(ov.join("msm_affine/server_shifted.rs"),child).unwrap();
 let mut plan:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zopro-perf-work/shifted-identity188/build-plan.json").unwrap()).unwrap();let text=serde_json::to_string(&plan).unwrap().replace("/home/ubuntu/src/zopro-perf-work/shifted-identity188",R);plan=serde_json::from_str(&text).unwrap();
 plan["steps"][0]["timeout_seconds"]=json!(1200);plan["environment"]["ZOPRO_CPU_INDEXED_TILE_BUNDLES"]=json!("1");
 fs::write(format!("{R}/build-plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();
 println!("179 production hashes verified; one test-only parent and exact188 module with appended harness");
}
