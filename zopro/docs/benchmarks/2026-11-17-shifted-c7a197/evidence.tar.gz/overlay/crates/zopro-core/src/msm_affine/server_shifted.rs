use rayon::prelude::*;
use zopro_bn254::{G2Affine,G2Projective};
const WIDTH:usize=12;const WINDOWS:usize=22;const HALF:usize=1<<(WIDTH-1);
struct Table{points:Vec<G2Affine>,active:Vec<u8>,n:usize}
impl Table{
 fn new(bases:&[G2Affine],allowance:usize)->Option<Self>{let count=bases.len().checked_mul(WINDOWS)?;let bytes=count.checked_mul(std::mem::size_of::<G2Affine>())?.checked_add(count)?;if bytes>allowance||count>u32::MAX as usize{return None;}
 let mut points=Vec::with_capacity(count);points.extend_from_slice(bases);
 for w in 1..WINDOWS{let prev=&points[(w-1)*bases.len()..w*bases.len()];let chunks:Vec<Vec<G2Affine>>=prev.par_chunks(128).map(|chunk|{let projective:Vec<_>=chunk.iter().map(|p|{let mut p=p.to_projective();for _ in 0..WIDTH{p=p.double();}p}).collect();G2Projective::batch_to_affine(&projective)}).collect();for chunk in chunks{points.extend(chunk);}}
 let active=points.iter().map(|p|u8::from(!p.is_identity())).collect();Some(Self{points,active,n:bases.len()})}
 fn route_parallel(&self,words:&[[u64;4]])->(Vec<u32>,Vec<usize>){
let chunk=self.n.div_ceil(rayon::current_num_threads());
let shards:Vec<_>=words.par_chunks(chunk.max(1)).enumerate().map(|(part,scalars)|{
 let begin=part*chunk;let bucket=|d:i16|d.unsigned_abs()as usize-1+if d<0{HALF}else{0};
 let mut starts=vec![0usize;2*HALF+1];for w in 0..WINDOWS{for(i,s)in scalars.iter().enumerate(){let d=super::digit(s,w,WIDTH);if d!=0&&!self.points[w*self.n+begin+i].is_identity(){starts[bucket(d)+1]+=1;}}}
 for i in 1..starts.len(){starts[i]+=starts[i-1];}let mut pos=starts[..2*HALF].to_vec();let mut order=vec![0u32;*starts.last().unwrap()];for w in 0..WINDOWS{for(i,s)in scalars.iter().enumerate(){let d=super::digit(s,w,WIDTH);if d!=0&&!self.points[w*self.n+begin+i].is_identity(){let b=bucket(d);order[pos[b]]=(w*self.n+begin+i)as u32;pos[b]+=1;}}}(order,starts)
}).collect();
let mut starts=vec![0usize;2*HALF+1];for b in 0..2*HALF{starts[b+1]=starts[b]+shards.iter().map(|(_,s)|s[b+1]-s[b]).sum::<usize>();}
let mut order=vec![0u32;*starts.last().unwrap()];let mut rest=&mut order[..];let mut destinations=Vec::with_capacity(2*HALF);for b in 0..2*HALF{let(out,next)=rest.split_at_mut(starts[b+1]-starts[b]);destinations.push(out);rest=next;}
destinations.into_par_iter().enumerate().for_each(|(b,mut out)|{for(o,s)in &shards{let chunk=&o[s[b]..s[b+1]];let(first,next)=out.split_at_mut(chunk.len());first.copy_from_slice(chunk);out=next;}assert!(out.is_empty());});(order,starts)
}

 fn route_masked(&self,words:&[[u64;4]])->(Vec<u32>,Vec<usize>){
let chunk=self.n.div_ceil(rayon::current_num_threads());
let shards:Vec<_>=words.par_chunks(chunk.max(1)).enumerate().map(|(part,scalars)|{
 let begin=part*chunk;let bucket=|d:i16|d.unsigned_abs()as usize-1+if d<0{HALF}else{0};
 let mut starts=vec![0usize;2*HALF+1];for w in 0..WINDOWS{for(i,s)in scalars.iter().enumerate(){let d=super::digit(s,w,WIDTH);if d!=0&&self.active[w*self.n+begin+i]!=0{starts[bucket(d)+1]+=1;}}}
 for i in 1..starts.len(){starts[i]+=starts[i-1];}let mut pos=starts[..2*HALF].to_vec();let mut order=vec![0u32;*starts.last().unwrap()];for w in 0..WINDOWS{for(i,s)in scalars.iter().enumerate(){let d=super::digit(s,w,WIDTH);if d!=0&&self.active[w*self.n+begin+i]!=0{let b=bucket(d);order[pos[b]]=(w*self.n+begin+i)as u32;pos[b]+=1;}}}(order,starts)
}).collect();
let mut starts=vec![0usize;2*HALF+1];for b in 0..2*HALF{starts[b+1]=starts[b]+shards.iter().map(|(_,s)|s[b+1]-s[b]).sum::<usize>();}
let mut order=vec![0u32;*starts.last().unwrap()];let mut rest=&mut order[..];let mut destinations=Vec::with_capacity(2*HALF);for b in 0..2*HALF{let(out,next)=rest.split_at_mut(starts[b+1]-starts[b]);destinations.push(out);rest=next;}
destinations.into_par_iter().enumerate().for_each(|(b,mut out)|{for(o,s)in &shards{let chunk=&o[s[b]..s[b+1]];let(first,next)=out.split_at_mut(chunk.len());first.copy_from_slice(chunk);out=next;}assert!(out.is_empty());});(order,starts)
}


 fn apply_masked(&self,words:&[[u64;4]])->(G2Projective,[u64;2]){assert_eq!(words.len(),self.n);let begin=std::time::Instant::now();let(order,starts)=self.route_masked(words);let routed=begin.elapsed().as_nanos()as u64;
 let mut sums=crate::msm::reduce_indexed_buckets(&self.points,&order,&starts);let mut negative=sums.split_off(HALF);for p in &mut negative{*p=-*p;}super::merge_buckets(&mut sums,&negative);let result=crate::msm::weighted_affine(&sums);(result,[routed,begin.elapsed().as_nanos()as u64-routed])}
 fn apply(&self,words:&[[u64;4]])->G2Projective{self.apply_mode(words,false).0}
 fn apply_mode(&self,words:&[[u64;4]],parallel:bool)->(G2Projective,[u64;2]){let begin=std::time::Instant::now();assert_eq!(words.len(),self.n);let(order,starts)=if parallel{self.route_parallel(words)}else{let mut starts=vec![0usize;2*HALF+1];let bucket=|d:i16|d.unsigned_abs()as usize-1+if d<0{HALF}else{0};
 for w in 0..WINDOWS{for(s,p)in words.iter().zip(&self.points[w*self.n..(w+1)*self.n]){let d=super::digit(s,w,WIDTH);if d!=0&&!p.is_identity(){starts[bucket(d)+1]+=1;}}}
 for i in 1..starts.len(){starts[i]+=starts[i-1];}let mut positions=starts[..2*HALF].to_vec();let mut order=vec![0u32;*starts.last().unwrap()];
 for w in 0..WINDOWS{for(i,(s,p))in words.iter().zip(&self.points[w*self.n..(w+1)*self.n]).enumerate(){let d=super::digit(s,w,WIDTH);if d!=0&&!p.is_identity(){let b=bucket(d);order[positions[b]]=(w*self.n+i)as u32;positions[b]+=1;}}}
(order,starts)};let routed=begin.elapsed().as_nanos()as u64;
 let mut sums=crate::msm::reduce_indexed_buckets(&self.points,&order,&starts);let mut negative=sums.split_off(HALF);for p in &mut negative{*p=-*p;}super::merge_buckets(&mut sums,&negative);let result=crate::msm::weighted_affine(&sums);(result,[routed,begin.elapsed().as_nanos()as u64-routed])}
}
#[cfg(test)]mod tests{
use super::*;use sha2::{Digest,Sha256};use zopro_bn254::{Fq,Fq2,Fr};use std::{fs,time::Instant};
fn fixture(name:&str)->(Vec<G2Affine>,Vec<[u64;4]>,String){let path=format!("/home/ubuntu/src/zopro-perf-work/g2-queue-scan175/inputs/{name}.b2q");let bytes=fs::read(path).unwrap();assert_eq!(&bytes[..8],b"B2SCAN01");let n=u64::from_le_bytes(bytes[8..16].try_into().unwrap())as usize;assert_eq!(bytes.len(),16+n*160);let points=bytes[16..16+128*n].chunks_exact(128).map(|p|{let f=p.chunks_exact(32).map(|v|Fq::from_be_bytes(v.try_into().unwrap()).unwrap()).collect::<Vec<_>>();G2Affine::new(Fq2::new(f[1],f[0]),Fq2::new(f[3],f[2]))}).collect();let words=bytes[16+128*n..].chunks_exact(32).map(|v|std::array::from_fn(|i|u64::from_le_bytes(v[i*8..i*8+8].try_into().unwrap()))).collect();
let expected=match name{"1x2" => {assert_eq!(format!("{:x}",Sha256::digest(&bytes)),"421d6ba37e8b3a6f5feb23829c174d11bc034cb9bd8874adf672d65038fb0ad0");"8ff656ce44bbebe641139dbc019ae10fc8b3146db4e3af5ad45a0ed3832d4dd7".to_owned()},"2x2" => {assert_eq!(format!("{:x}",Sha256::digest(&bytes)),"2b325a5850f1fc9ea21e715e6027f14cc7a29d2c602d0acc683bbfb8377921bc");"0fb52c0dece236bf024cfb1afade3d403618730859e99e60bb2bea90b866ecae".to_owned()}, _=>panic!()};(points,words,expected)}
fn coords(p:G2Projective)->String{let p=p.to_affine();let mut h=Sha256::new();for f in[p.x.c0,p.x.c1,p.y.c0,p.y.c1]{for w in f.to_canonical(){h.update(w.to_le_bytes());}}format!("{:x}",h.finalize())}
#[test]fn edge_oracle_and_shared_table(){let pool=rayon::ThreadPoolBuilder::new().num_threads(4).stack_size(512*1024).build().unwrap();let mut points=vec![G2Affine::GENERATOR;17];points[0]=G2Affine::IDENTITY;points[1]=-G2Affine::GENERATOR;let scalars:Vec<_>=(0..17).map(|i|match i%5{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,_=>Fr::from((i*71+1)as u64).square()}).collect();let words:Vec<_>=scalars.iter().map(Fr::to_canonical).collect();let expected=points.iter().zip(&scalars).fold(G2Projective::IDENTITY,|sum,(p,s)|sum+p.mul(s));assert!(Table::new(&points,0).is_none());let table=pool.install(||Table::new(&points,usize::MAX).unwrap());std::thread::scope(|scope|for _ in 0..4{let(table,words)=(&table,&words);let pool=&pool;scope.spawn(move||assert_eq!(pool.install(||table.apply(words)).to_affine(),expected.to_affine()));});}
#[test]fn captured_full_query_oracles(){for name in["1x2","2x2"]{let(p,w,e)=fixture(name);let pool=rayon::ThreadPoolBuilder::new().num_threads(4).build().unwrap();pool.install(||{let t=Table::new(&p,usize::MAX).unwrap();assert_eq!(coords(t.apply(&w)),e);assert_eq!(coords(super::super::g2_query_exclusive(&p,&mut w.clone())),e);});}}
#[test]#[ignore]fn frozen_query_screen(){for workers in[16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).start_handler(move|i|{unsafe{let mut set:libc::cpu_set_t=std::mem::zeroed();libc::CPU_ZERO(&mut set);libc::CPU_SET(i,&mut set);assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&set),&set),0);}}).build().unwrap();for name in["1x2","2x2"]{let(p,w,e)=fixture(name);let start=Instant::now();let table=pool.install(||Table::new(&p,usize::MAX).unwrap());eprintln!("SETUP {name} {workers} n={} bytes={} ms={}",p.len(),table.points.capacity()*128,start.elapsed().as_secs_f64()*1000.);for _ in 0..3{for on in[false,true]{let result=pool.install(||if on{table.apply(&w.clone())}else{super::super::g2_query_exclusive(&p,&mut w.clone())});assert_eq!(coords(result),e);}}for block in 0..9{for on in if block%2==0{[false,true]}else{[true,false]}{let start=Instant::now();let result=pool.install(||if on{table.apply(&w.clone())}else{super::super::g2_query_exclusive(&p,&mut w.clone())});let ns=start.elapsed().as_nanos();assert_eq!(coords(result),e);println!("TIMING {name} {workers} {block} {on} {ns}");}}}}}
#[test]#[ignore]fn parallel_route_screen(){let pool=rayon::ThreadPoolBuilder::new().num_threads(32).start_handler(|i|unsafe{let mut set:libc::cpu_set_t=std::mem::zeroed();libc::CPU_ZERO(&mut set);libc::CPU_SET(i,&mut set);assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&set),&set),0);}).build().unwrap();for name in["1x2","2x2"]{let(p,w,e)=fixture(name);let t=pool.install(||Table::new(&p,usize::MAX).unwrap());let run=|arm|pool.install(||{let mut words=w.clone();if arm==0{(super::super::g2_query_exclusive(&p,&mut words),[0,0])}else{t.apply_mode(&words,arm==2)}});for _ in 0..3{for arm in 0..3{assert_eq!(coords(run(arm).0),e);}}for b in 0..9{let mut arms=[0,1,2];arms.rotate_left(b%3);if b%2==1{arms.reverse();}for arm in arms{let clock=Instant::now();let(p,stages)=run(arm);let total=clock.elapsed().as_nanos();assert_eq!(coords(p),e);println!("ROUTE {name} {b} {arm} {total} {} {}",stages[0],stages[1]);}}}}
#[test]fn cached_identity_exact_and_budgeted(){let bases=[G2Affine::IDENTITY,G2Affine::GENERATOR,-G2Affine::GENERATOR,G2Affine::GENERATOR];let required=bases.len()*WINDOWS*129;assert!(Table::new(&bases,required-1).is_none());let t=Table::new(&bases,required).unwrap();assert_eq!(t.active.len(),t.points.len());for(p,&active)in t.points.iter().zip(&t.active){assert_eq!(active,u8::from(!p.is_identity()));}let words=vec![(-Fr::ONE).to_canonical();bases.len()];assert_eq!(coords(t.apply_mode(&words,true).0),coords(t.apply_masked(&words).0));}
#[test]#[ignore]fn identity_query_screen(){for workers in[16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).start_handler(|i|unsafe{let mut set:libc::cpu_set_t=std::mem::zeroed();libc::CPU_ZERO(&mut set);libc::CPU_SET(i,&mut set);assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&set),&set),0);}).build().unwrap();for name in if workers==16{vec!["1x2"]}else{vec!["1x2","2x2"]}{let(p,w,expected)=fixture(name);let clock=Instant::now();let table=pool.install(||Table::new(&p,usize::MAX).unwrap());eprintln!("SETUP {name} {workers} pointbytes={} maskbytes={} ms={}",table.points.capacity()*128,table.active.capacity(),clock.elapsed().as_secs_f64()*1000.);let run=|arm|pool.install(||{let mut words=w.clone();let result=match arm{0=>super::super::g2_query_exclusive(&p,&mut words),1=>table.apply_mode(&words,true).0,_=>table.apply_masked(&words).0};result.to_affine()});let check=|point:zopro_bn254::G2Affine|{let mut h=Sha256::new();for f in[point.x.c0,point.x.c1,point.y.c0,point.y.c1]{for w in f.to_canonical(){h.update(w.to_le_bytes());}}assert_eq!(format!("{:x}",h.finalize()),expected);};for _ in 0..3{for arm in 0..3{check(run(arm));}}for b in 0..9{let mut arms=[0,1,2];arms.rotate_left(b%3);if b%2==1{arms.reverse();}for arm in arms{let clock=Instant::now();let p=std::hint::black_box(run(arm));let ns=clock.elapsed().as_nanos();check(p);println!("IDENTITY {name} {workers} {b} {arm} {ns}");}}}}}
#[test]
#[ignore]
fn c7a_screen() {
    let workers: usize = std::env::var("SHIFTED_WORKERS").unwrap().parse().unwrap();
    let arm: usize = std::env::var("SHIFTED_ARM").unwrap().parse().unwrap();
    let rounds: usize = std::env::var("SHIFTED_ROUNDS").unwrap().parse().unwrap();
    let name = std::env::var("SHIFTED_SHAPE").unwrap();
    assert!([1, 4, 16, 32, 96].contains(&workers) && arm < 2 && rounds > 0);
    let pool = rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024)
        .start_handler(move |i| unsafe {
            let cpu = if workers == 1 { 2 } else { i };
            let mut set: libc::cpu_set_t = std::mem::zeroed();
            libc::CPU_ZERO(&mut set); libc::CPU_SET(cpu, &mut set);
            assert_eq!(libc::sched_setaffinity(0, std::mem::size_of_val(&set), &set), 0);
        }).build().unwrap();
    let (p,w,expected) = fixture(&name);
    let setup = Instant::now();
    let table = if arm == 1 { Some(pool.install(||Table::new(&p,usize::MAX).unwrap())) } else { None };
    let setup_ns = setup.elapsed().as_nanos();
    let point_bytes = table.as_ref().map_or(0, |t| t.points.capacity()*128);
    let mask_bytes = table.as_ref().map_or(0, |t| t.active.capacity());
    let check = |point: G2Affine| {
        let mut h = Sha256::new();
        for f in [point.x.c0,point.x.c1,point.y.c0,point.y.c1] { for v in f.to_canonical() { h.update(v.to_le_bytes()); } }
        assert_eq!(format!("{:x}",h.finalize()), expected);
    };
    let input_hash = |points:&[G2Affine]| {
        let mut h=Sha256::new();for p in points { for f in [p.x.c0,p.x.c1,p.y.c0,p.y.c1] { for v in f.to_canonical(){h.update(v.to_le_bytes());} } }format!("{:x}",h.finalize())
    };
    let before=input_hash(&p);
    let run=||pool.install(|| {
        let mut words=w.clone();
        let value=if let Some(t)=&table { t.apply_masked(&words).0 } else { super::super::g2_query_exclusive(&p,&mut words) };
        value.to_affine()
    });
    for _ in 0..3 { check(run()); }
    let usage=||unsafe {let mut u:libc::rusage=std::mem::zeroed();assert_eq!(libc::getrusage(libc::RUSAGE_SELF,&mut u),0);u};
    let cpu_us=|u:&libc::rusage| (u.ru_utime.tv_sec+u.ru_stime.tv_sec)*1_000_000+u.ru_utime.tv_usec+u.ru_stime.tv_usec;
    let initial=usage();let mut times=Vec::with_capacity(rounds);
    for _ in 0..rounds { let start=Instant::now();let out=std::hint::black_box(run());times.push(start.elapsed().as_nanos());check(out); }
    let final_usage=usage();check(run());assert_eq!(before,input_hash(&p));
    println!("SCREEN {{\"shape\":\"{}\",\"workers\":{},\"arm\":{},\"rounds\":{},\"setup_ns\":{},\"point_bytes\":{},\"mask_bytes\":{},\"cpu_us\":{},\"peak_kib\":{},\"times_ns\":{:?}}}", name,workers,arm,rounds,setup_ns,point_bytes,mask_bytes,cpu_us(&final_usage)-cpu_us(&initial),final_usage.ru_maxrss,times);
}
}
