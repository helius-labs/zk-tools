#[test]
#[ignore]
fn c7a_screen() {
    let workers: usize = std::env::var("SHIFTED_WORKERS").unwrap().parse().unwrap();
    let arm: usize = std::env::var("SHIFTED_ARM").unwrap().parse().unwrap();
    let rounds: usize = std::env::var("SHIFTED_ROUNDS").unwrap().parse().unwrap();
    let name = std::env::var("SHIFTED_SHAPE").unwrap();
    assert!([1, 4, 16, 32, 96].contains(&workers) && arm < 2 && rounds > 0);
    let pool = rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024)
        .start_handler(move |i| unsafe {
            let cpu = if workers == 1 { 2 } else { i };
            let mut set: libc::cpu_set_t = std::mem::zeroed();
            libc::CPU_ZERO(&mut set); libc::CPU_SET(cpu, &mut set);
            assert_eq!(libc::sched_setaffinity(0, std::mem::size_of_val(&set), &set), 0);
        }).build().unwrap();
    let (p,w,expected) = fixture(&name);
    let setup = Instant::now();
    let table = if arm == 1 { Some(pool.install(||Table::new(&p,usize::MAX).unwrap())) } else { None };
    let setup_ns = setup.elapsed().as_nanos();
    let point_bytes = table.as_ref().map_or(0, |t| t.points.capacity()*128);
    let mask_bytes = table.as_ref().map_or(0, |t| t.active.capacity());
    let check = |point: G2Affine| {
        let mut h = Sha256::new();
        for f in [point.x.c0,point.x.c1,point.y.c0,point.y.c1] { for v in f.to_canonical() { h.update(v.to_le_bytes()); } }
        assert_eq!(format!("{:x}",h.finalize()), expected);
    };
    let input_hash = |points:&[G2Affine]| {
        let mut h=Sha256::new();for p in points { for f in [p.x.c0,p.x.c1,p.y.c0,p.y.c1] { for v in f.to_canonical(){h.update(v.to_le_bytes());} } }format!("{:x}",h.finalize())
    };
    let before=input_hash(&p);
    let run=||pool.install(|| {
        let mut words=w.clone();
        let value=if let Some(t)=&table { t.apply_masked(&words).0 } else { super::super::g2_query_exclusive(&p,&mut words) };
        value.to_affine()
    });
    for _ in 0..3 { check(run()); }
    let usage=||unsafe {let mut u:libc::rusage=std::mem::zeroed();assert_eq!(libc::getrusage(libc::RUSAGE_SELF,&mut u),0);u};
    let cpu_us=|u:&libc::rusage| (u.ru_utime.tv_sec+u.ru_stime.tv_sec)*1_000_000+u.ru_utime.tv_usec+u.ru_stime.tv_usec;
    let initial=usage();let mut times=Vec::with_capacity(rounds);
    for _ in 0..rounds { let start=Instant::now();let out=std::hint::black_box(run());times.push(start.elapsed().as_nanos());check(out); }
    let final_usage=usage();check(run());assert_eq!(before,input_hash(&p));
    println!("SCREEN {{\"shape\":\"{}\",\"workers\":{},\"arm\":{},\"rounds\":{},\"setup_ns\":{},\"point_bytes\":{},\"mask_bytes\":{},\"cpu_us\":{},\"peak_kib\":{},\"times_ns\":{:?}}}", name,workers,arm,rounds,setup_ns,point_bytes,mask_bytes,cpu_us(&final_usage)-cpu_us(&initial),final_usage.ru_maxrss,times);
}
