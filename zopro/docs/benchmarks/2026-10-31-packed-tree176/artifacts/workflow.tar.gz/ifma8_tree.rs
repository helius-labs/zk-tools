//! Lane movement and zero detection only; no new field arithmetic.
use super::*;
impl<C:FpConfig,const MIXED:bool> Ifma8<C,MIXED> {
    /// Split sixteen contiguous values into eight adjacent-pair sides.
    #[inline(always)]
    pub fn tree_adjacent(a:&Self,b:&Self)->(Self,Self) {
        unsafe {
            let even=_mm512_set_epi64(14,12,10,8,6,4,2,0);
            let odd=_mm512_set_epi64(15,13,11,9,7,5,3,1);
            (Self(core::array::from_fn(|i|_mm512_permutex2var_epi64(a.0[i],even,b.0[i])),PhantomData),
             Self(core::array::from_fn(|i|_mm512_permutex2var_epi64(a.0[i],odd,b.0[i])),PhantomData))
        }
    }
    /// Normalized values strictly below 2p represent zero as 0 or p.
    #[inline(always)]
    pub fn tree_zero_mask(&self)->u8 {
        unsafe {
            let mut zero=0xffu8;let mut modulus=0xffu8;let p=split(C::P);
            for j in 0..5 {
                zero&=_mm512_cmpeq_epi64_mask(self.0[j],Self::splat(0));
                modulus&=_mm512_cmpeq_epi64_mask(self.0[j],Self::splat(p[j]));
            }
            zero|modulus
        }
    }
}
#[cfg(test)]mod tests {
use super::*;
fn check<C:FpConfig,const M:bool>() {
    for offset in 0..32u64 {
        let a=core::array::from_fn(|i|Fp::<C>::from(offset+1+i as u64));
        let b=core::array::from_fn(|i|Fp::<C>::from(offset+9+i as u64));
        let(x,y)=Ifma8::<C,M>::tree_adjacent(&Ifma8::new(&a),&Ifma8::new(&b));
        let all=[a,b].concat();assert_eq!(x.get(),core::array::from_fn(|i|all[2*i]));assert_eq!(y.get(),core::array::from_fn(|i|all[2*i+1]));
        let values=core::array::from_fn(|i|if (offset>>i)&1==0{Fp::<C>::ZERO}else{Fp::<C>::from((i+1)as u64)});
        let v=Ifma8::<C,M>::new(&values);assert_eq!(v.tree_zero_mask(),!(offset as u8));assert_eq!(v.sub(&v).tree_zero_mask(),255);
    }
    if M {
        let p=split(C::P);unsafe{
            let raw=Ifma8::<C,M>(core::array::from_fn(|j|_mm512_set_epi64(0,p[j]as i64,0,p[j]as i64,0,p[j]as i64,0,p[j]as i64)),PhantomData);
            assert_eq!(raw.tree_zero_mask(),255);
        }
    }
}
#[test]fn lane_pairing_and_zero_masks_all_fields_radices(){check::<crate::FqConfig,true>();check::<crate::FrConfig,true>();check::<crate::FqConfig,false>();check::<crate::FrConfig,false>();}
}
