//! Bounded complete unweighted tree. Native coordinates persist across levels.
use super::*;
use zopro_bn254::{G1Config,G2Config};
trait PackedBase:BatchInverse {
    fn adjacent(a:&Self::Lanes,b:&Self::Lanes)->(Self::Lanes,Self::Lanes);
}
impl PackedBase for Fq {
    fn adjacent(a:&FqBatch,b:&FqBatch)->(FqBatch,FqBatch){
        #[cfg(zopro_packed_tree)]{FqBatch::tree_adjacent(a,b)}
        #[cfg(not(zopro_packed_tree))]{let x=a.get();let y=b.get();let all=[x,y].concat();(FqBatch::new(&core::array::from_fn(|i|all[i*2])),FqBatch::new(&core::array::from_fn(|i|all[i*2+1])))}
    }
}
impl PackedBase for Fq2 {
    fn adjacent(a:&[FqBatch;2],b:&[FqBatch;2])->([FqBatch;2],[FqBatch;2]){let(x0,y0)=Fq::adjacent(&a[0],&b[0]);let(x1,y1)=Fq::adjacent(&a[1],&b[1]);([x0,x1],[y0,y1])}
}
#[derive(Clone,Copy)]struct Point<F:PackedBase>{x:F::Lanes,y:F::Lanes}
struct Work<C:CurveConfig>where C::Base:PackedBase {
    a:Vec<Point<C::Base>>,b:Vec<Point<C::Base>>,prefix:Vec<[FqBatch;2]>,
    original:Vec<LimbPoint<C::Base>>,scratch:Scratch<C>, fallback:usize,
}
impl<C:CurveConfig>Default for Work<C>where C::Base:PackedBase {
    fn default()->Self{Self{a:vec![],b:vec![],prefix:vec![],original:vec![],scratch:Scratch{vector_inverse:true,..Default::default()},fallback:0}}
}
impl<C:CurveConfig>Work<C>where C::Base:PackedBase {
    fn original(&mut self,input:&[Affine<C>])->Affine<C>{
        self.original.clear();self.original.extend(input.iter().copied().map(limbs::<C>));
        let mut count=[input.len()];while count[0]>1{reduce_layer(&mut self.original,&[0],&mut count,&mut self.scratch);}
        self.original.first().copied().map(affine::<C>).unwrap_or(Affine::<C>::IDENTITY)
    }
    fn run(&mut self,input:&[Affine<C>],on:bool)->Affine<C>{
        #[cfg(zopro_packed_tree)]if on{if let Some(p)=self.packed(input){return p;}self.fallback+=1;}
        let _=on;self.original(input)
    }
    #[cfg(zopro_packed_tree)]
    fn packed(&mut self,input:&[Affine<C>])->Option<Affine<C>>{
        type F<C>=<C as CurveConfig>::Base;
        if input.len()<16||!input.len().is_power_of_two(){return None;}
        self.a.clear();self.a.reserve_exact(input.len()/8);
        for group in input.chunks_exact(8){if group.iter().any(|p|p.is_identity()){return None;}
            let raw:[LimbPoint<C::Base>;8]=core::array::from_fn(|i|limbs::<C>(group[i]));
            self.a.push(Point{x:F::<C>::load(core::array::from_fn(|i|&raw[i].x)),y:F::<C>::load(core::array::from_fn(|i|&raw[i].y))});
        }
        let mut in_a=true;let mut count=input.len()/8;
        self.b.clear();self.b.reserve_exact(count/2);self.prefix.clear();self.prefix.reserve_exact(count/2);
        while count>1 {
            let(src,dst)=if in_a{(&self.a,&mut self.b)}else{(&self.b,&mut self.a)};
            self.prefix.clear();let mut chains=FqBatch::one();
            for j in 0..count/2{let(ax,bx)=F::<C>::adjacent(&src[2*j].x,&src[2*j+1].x);let dx=F::<C>::lanes_sub(&bx,&ax);let norm=F::<C>::lanes_norm(&dx);
                if norm.tree_zero_mask()!=0{return None;}
                self.prefix.push([chains,norm]);chains=chains.mul(&norm);
            }
            let mut inverse=chains.inverse_nonzero();dst.clear();dst.resize(count/2,Point{x:src[0].x,y:src[0].y});
            for j in(0..count/2).rev(){let(ax,bx)=F::<C>::adjacent(&src[2*j].x,&src[2*j+1].x);let(ay,by)=F::<C>::adjacent(&src[2*j].y,&src[2*j+1].y);let dx=F::<C>::lanes_sub(&bx,&ax);
                let factor=self.prefix[j][0].mul(&inverse);inverse=inverse.mul(&self.prefix[j][1]);
                let slope=F::<C>::lanes_scaled_numerator(&F::<C>::lanes_sub(&by,&ay),&dx,&factor);
                let x=F::<C>::lanes_sub(&F::<C>::lanes_square(&slope),&F::<C>::lanes_add(&ax,&bx));
                let y=F::<C>::lanes_sub(&F::<C>::lanes_mul(&slope,&F::<C>::lanes_sub(&ax,&x)),&ay);dst[j]=Point{x,y};
            }
            count/=2;in_a=!in_a;
        }
        let p=if in_a{&self.a[0]}else{&self.b[0]};let x=F::<C>::store(&p.x);let y=F::<C>::store(&p.y);
        let mut tail:[LimbPoint<C::Base>;8]=core::array::from_fn(|i|LimbPoint{x:x[i],y:y[i]});let mut count=[8];
        while count[0]>1{reduce_layer(&mut tail,&[0],&mut count,&mut self.scratch);}Some(affine::<C>(tail[0]))
    }
    fn capacity(&self)->usize{(self.a.capacity()+self.b.capacity())*core::mem::size_of::<Point<C::Base>>()+self.prefix.capacity()*core::mem::size_of::<[FqBatch;2]>()+self.original.capacity()*core::mem::size_of::<LimbPoint<C::Base>>()+self.scratch.groups.capacity()*core::mem::size_of::<Group<C::Base>>()+self.scratch.prefix_records.capacity()*core::mem::size_of::<[FqBatch;2]>()+self.scratch.pairs.capacity()*core::mem::size_of::<usize>()}
}
struct Fixture<C:CurveConfig>where C::Base:PackedBase{source:Vec<Affine<C>>,last:[Affine<C>;2],work:Work<C>,n:usize,seed:u64}
impl<C:CurveConfig>Fixture<C>where C::Base:PackedBase{
fn new(n:usize,seed:u64)->Self{let g=Projective::<C>::generator();let source=Projective::<C>::batch_to_affine(&(0..n+1).map(|i|g*Fr::from(seed*1000003+i as u64+1)).collect::<Vec<_>>());Self{source,last:[Affine::IDENTITY;2],work:Work::default(),n,seed}}
fn run(&mut self,rounds:usize,on:bool){for i in 0..rounds{let k=i%2;self.last[k]=std::hint::black_box(self.work.run(std::hint::black_box(&self.source[k..k+self.n]),on));}}
fn check(&self){for k in 0..2{let sum=(0..self.n).fold(Fr::ZERO,|v,i|v+Fr::from(self.seed*1000003+i as u64+k as u64+1));assert_eq!(self.last[k],(Projective::<C>::generator()*sum).to_affine());}}
}
pub struct CallerG1(Fixture<G1Config>);pub struct CallerG2(Fixture<G2Config>);
macro_rules! caller{($t:ident)=>{impl $t{pub fn new(n:usize,seed:u64)->Self{Self(Fixture::new(n,seed))}pub fn run(&mut self,n:usize,on:bool){self.0.run(n,on)}pub fn check(&self){self.0.check()}pub fn capacity_bytes(&self)->usize{self.0.work.capacity()}pub fn fallback_count(&self)->usize{self.0.work.fallback}pub fn digest(&self)->String{format!("{:?}",self.0.last)}}};}
caller!(CallerG1);caller!(CallerG2);
#[cfg(test)]mod tests{
use super::*;
fn check<C:CurveConfig>()where C::Base:PackedBase{
let g=Projective::<C>::generator();for n in[0usize,1,7,8,9,15,16,17,31,32,33,63,64,127,128,256,1024]{for family in 0..5{let mut p=Projective::<C>::batch_to_affine(&(0..n).map(|i|g*Fr::from(i as u64+73)).collect::<Vec<_>>());if n>=2{match family{1=>p[n/2]=Affine::IDENTITY,2=>p[1]=p[0],3=>p[1]=-p[0],4=>{p[1]=-p[0];if n>=4{p[3]=-p[2];}},_=>{}}}let sum=p.iter().fold(Projective::<C>::IDENTITY,|s,p|s+*p).to_affine();let before=p.clone();for on in[false,true]{let mut w=Work::<C>::default();for _ in 0..3{assert_eq!(w.run(&p,on),sum,"n{n} family{family} on{on}");}assert_eq!(p,before);}}}
}
#[test]fn complete_g1_generator_tails_exceptions_reuse(){check::<G1Config>();}
#[test]fn complete_g2_generator_tails_exceptions_reuse(){check::<G2Config>();}
#[test]fn small_stack_pools(){use rayon::prelude::*;for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();pool.install(||(0..workers*2).into_par_iter().for_each(|i|{let mut a=CallerG1::new(256,i as u64+1);let mut b=CallerG2::new(256,i as u64+1);for on in[false,true]{a.run(4,on);a.check();b.run(4,on);b.check();}}));}}
}
