    #[cfg(zopro_packed_tree)]
    #[inline(always)]
    pub(crate) fn tree_adjacent(a:&Self,b:&Self)->(Self,Self){let(x,y)=zopro_bn254::ifma8::Ifma8::tree_adjacent(&a.0,&b.0);(Self(x),Self(y))}
    #[cfg(zopro_packed_tree)]
    #[inline(always)]
    pub(crate) fn tree_zero_mask(&self)->u8{self.0.tree_zero_mask()}
