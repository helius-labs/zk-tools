# Continue after the owned-root full-proof comparison

LATEST USER DIRECTION: stop starting sibling local optimization trials and think
about the observed AWS/Aeglos scaling gap. Finish/push this completed report,
then use existing AWS32/64/96 data and profiles to explain what the local16-physical/
32-logical host cannot expose. Do not launch another experiment before a concrete
causal hypothesis and discriminating test follow from that review. User has not
requested pausing the full goal; analytical progress remains authorized.

Goal ACTIVE/UNMET0/8: verifiedCPUAVXsingleproof>=10x suppliedM5CPU forEACHALL8,
reportCPU+Metal. No budget. Userauthorizesautonomousloop/noquestions,commitANDpush
eachfinishedexperiment,politefacts. No subagents/Python/C/ASM/giantLUT/expanded
keyplan/newproductionpool/artificialRAMcap. PreviousgoalturnPROGRESS: ownedroot
storage implemented/native131+13buildlinkcommandsqualified/pushed9dff6f1a0d.
THISturnPROGRESS: completeSDKALL8+54/primary1/16/32measured/Gnarkverified/frozen
analysis+separatereader reviewed; no confirmedgain/notadopted. Readcheckpoint.json
for actualcommit/push/exactremoteverification,do notassumependingpublicationdone.

R=/home/ubuntu/src/zopro-perf-work/weighted-owned-roots-sdk176
Q=/home/ubuntu/src/zopro-perf-work/weighted-owned-roots176
Report zopro/docs/benchmarks/2026-11-10-weighted-owned-roots-sdk176/README.md.
Workflow2441TERMINAL0/all1329commands succeededonce. Analysis87314TERMINAL0,
separate rawreader77184TERMINAL0,eachfirstexecution. No livecapture/build/profile.
Both actualreaders/79gates/400pins/order/input/copies frozenBEFOREANYfunctionalSDK
preflight. No ownedhelper/build/hash/analyze/report/push overlappedpreflightor
recording:only2441polledthroughterminal. Allrecordingsbeforeoffline45operations
and609Gnarkcapturechecks. Toolstdoutfinalhugetruncatedbutexplicitexit0 received;
fullauthoritative runs/result.json completes1329. Do notrestartoldhandles or
repeat successfulnative/crypto/model/capture forbookkeeping.

RESULT73/79,NOTadopted. ALL11calibrations,22nonregressions,22RSSguards,18diagnostic
qualitychecksPASS. Sixfailures: primary32gain+winningblocksagainstbothcontrols,
bothALL8gainchecks. ThisisNOTinvalid-controlresult. No minimumpositivegainfloor.
Noexcludedblocks/addedrequests/thresholdchange/workerorcompilerorlayoutrescue/
favorablebacking/subsetpromotion/unchangedrecapture. FixedownedrecipeCLOSED.
PrimaryREF7.821798556291391ms/OFF7.842524509933775/ON7.83219315231788.
PairedON/OFF .9970677679958713 CI[.9894759574521999,1.0030094132949456],18/31;
ON/REF .9994704937853649 CI[.9958207356112428,1.0036020342692984],16/31.
PointestimatespositivebutBOTHintervalscross1;neitherestablishesgainorslowdown.
ALL8ON/OFF .9994067320675718 CI[.9970162397618999,1.0017228635008666];
ON/REF1.0004260939541585 CI[.9984247681768408,1.0024173471692341]. Nearparity.
16ON9.188609ms vsREF9.214387/OFF9.215165;ON/OFF .994016 CI[.982596,1.001305],
24/31wins;ON/REF .999638 CI[.996788,1.002975],20/31. SoloON94.661267ms vs
REF94.887026/OFF94.644843;bothpairedintervalscrossparity. Retainalltheseestimates,
doNOTstatepositivesdiscardedbecausebelowanartificialgainthreshold.
PrimaryON134.25MiBvsREF135.25/OFF135.75;54ON163.404904ms/2000.90MiBvsREF163.133911/
1974.49MiB. No minimumRAM/stack/swap-pressurebound. Alltimedbatchmajorfaults0.

120368profilesamples,all9qualityPASS,maxunknown~1.925%,zeroLOST,actualbinaryMMAP/
PID/TID/CPUchecked. PrivateownednamespaceONonly52(primary16),75(primary32),110
(2x2-32) confirmsdynamicexecution;notexclusive/removablewalltime. All9rawprofiles
anddecode/counters/receiptsarchived. SinglePMUpanels ~0.3%fewerinstructions inall3,
cyclesmixed,notreplicatedcausalattribution.
SystemCPUprimary32 medianOFF4.609861ms/ON4.719424/REF4.710358;volswitchOFF360.46/
ON366.77/REF357.58. ComparedwithPREVIOUSheaprecipeON8.411ms/532switches, thisis
backnearcurrentcontrols. Across-campaigncomparisonNOTformalcausalinteraction:
source removesrootalloc/admissionbutalsostorage/gathers/schedulingdiffer. Required
scratch/zerooptionalbudgetsemanticsheld;doNOTrestoreextraallocationwithoutcharge.

CANONICALNOW50005:
/home/ubuntu/src/zopro-perf-work/weighted-owned-roots-sdk176/proof-sha256-after-capture.json
SHA527430558d0f8fc6a277ad61115c5a449039619cf23ee2408db9b5eb56fe82f6.
Stage44238SDKrequestsincludingprimes/642freshunique164-byteGnarkexports;
49363->49396->50005allbindings/freshnessverified. Everyfutureexportseed50005,
NOT49363/48721/48079/older. No newAWSresourcesorAeglosmeasurement.

ExactUNADOPTEDSDKs:Q/sdk-OFF SHA5925a9afa618c5f8eb3adb37cff2565a422c3a3902bd2fd817fb8bc3f79273d7;
Q/sdk-ON SHA5111083185d9e5364c4cd39364122cb76451aa0966ab828152c3fed9a5ffbfcd.
AcceptedREFstill /home/ubuntu/src/zopro-perf-work/busy-reset-sdk176/sdk-ON
SHA7aff5f602a1e250a6b9b28889bf6278b51ec400af8399c7481c36248a8718d01.
Originalfield1200/current176source/allcfgs+densebusyreset unchanged. Private170
exact+6reversibleparents+3children/9ownedterminalcalls,originalborrowedbody+old
roots/kernelbyteexact. OwnedVecstores9rootsper256groupinexistingprefix,barrier,
thenSIMDfold8groups. Guards>=2048/fullgroups/resourcepolicyBEFOREmutation;G2/
short/nonfull/disabledoriginal. No separateheaprootarray/newReservation/procreads/
ADMISSIONlock,existingparentforecast+6176logicalfixedG1leafextra;notemittedstack/
RSSbound. No keytable/plan/newpool/RAMcap. Native131tests/13commands inherited
withoutreplay,65newfullcases/19declines/20validtails/53workers/12sharedpoolcalls.
Portable-disabledcompileonlynotARMexecution. SeeQ/next.mdforqualificationfailure
source-selectorrepairdetails,exactlibrariesandownership/capacityevidence.

NEXT: stop cycling the weighted double-add storage/fanout family. Serial8group
recipewasnearparity,parallelheaprecipe+19.7%primary,ownedbufferrecipebacknearparity
butnoconfirmedgain. ThisdoesNOTproveallweightedalgorithmsimpossible,butnoanother
siblingmicrovariantisselected. The next candidate needs a DISTINCT substantial
reduction in dominant complete-prover work, basedonsource/workcensus/profiles,
not counts of cheaper pointproducts or more workitems alone. Use existing current
REF profiles andthe old consumer-work-audit176/field-census,notgenericnewprofile
foritsownsake. Flat epoch/rayon symbols may containinlinedpayload,NOTidle/removable.

Checkexisting /home/ubuntu/src/zopro-perf-work/aeglos-arithmetic-audit and
/aeglos-msm-mechanism176 beforeclaimingnewinsightsfromAeglossource. Upstream
helius-labs/aeglos alex/cpu-latency revisionmightbecheckedforREALchanges ifuseful;
readprimaryactualsource/revisionnotassumeitupdated. Userinvitedpapers/code
research,primarysourcesonly,andexplicitlyvaluescleverRust/lowmemoryoverC/ASM/
lookup-planrewrites. Do not duplicateexistingmathmodels justtorenametheexperiment.
No new dominantkernelcandidate yetselectedatthischeckpoint. Thisisnotanexternal
blocker;useexistingevidenceandmakeconcretesource/math/nativeprogress nextturn.

Alreadyclosedhistories: G1GLVKHfullSDKOct29+4.27%;taggedphiNov6extra585kbetaM;
wideGCD62G1query+5.32%;weightedliveprefixcal/nonregfail;retainedtailsall8positive
butprimaryREFCIcrossed;SIMDBooth+1.45%primary;G2nativebuckets+persistentquarter/
phase/lifetime/earlyfactor/lookahead;factorrecoding/HrabarLogJumps/SRE/global
windowsearch/BosCoster/differentialchains/pointmodel/PMNSbridges/VNNI/FMA studies
alreadyexist. Do not endlesslyretry4032024/038PDF. No paper speedfactortransfers.
PreviousheapparallelrootSDK2041eb342b primary9.356124vsREF7.827060,58/79,primary
controlsPASS,8x2calfail,allRSSdiagnosticsPASS. Native9dff6f1a0dandearlier0c84e1a80e
reportsremainqualifiedonly;noentryadopted. Do notreopenthemunchanged.

LatestfreshacceptedREFALL8ms(SAMEbuild,norecord/adoptionclaim):
7.821798556291391/10.944241806451613/15.772085/23.978159096774196/
33.96326396774194/39.89684570967742/66.5533466451613/65.34963383870968.
M5CPU37/59/109/189/284/335/528/507;Metal24/30/48/74/101/124/176/175;
CPU10xlimits3.7/5.9/10.9/18.9/28.4/33.5/52.8/50.7. Shapeorder1x2,2x2,4x2,
8x2,12x2,16x2,24x2,merge24x1. Historicdifferenthardware,notremeasured.54noM5ref.
Fullgoal0/8active,nevercompleteforbenchmark/report/buildalone.
AWSlatestaccepted2026-11-10-accepted-current-c7a176:Z1x2best11.243892ms32/122.52MiB
vsA7.902802ms96/479.98MiB;A32=11.870012.54Z120.757128ms64/2003.02MiBvsA171.908504ms96/
13102.11MiB. No newAWS/Aeglos/ARM/mobile/TEE/250/4999/pressure/swap/minRAM/
concurrentproofthroughputclaim. Earlieronlyc7ai-0a15ad9ae313aa976terminated/cleanup.

Rust1.98.1explicit,serializedretainedxtask. SourcebinaryfixturehashbytesnotUTF8.
FreezeBOTHactualrawreaders/allgates/order/inputs/copies/profiles beforeANYSDK
functionalpreflight. DuringANYpreflight/recordingONLYpollexactconfirmedhandle
throughterminal;nohelper/build/hash/analyze/report/push. Timeout/truncationnot
terminal,neverrestartlive. Allrecordingsbeforeoffline;thenanalysis/separatereview,
mandatoryfreshGnark/bindings/freshness/resources. CommitANDpush completedexperiment,
exactremoteverify,updatecheckpoint+sharedhandoff. Stageonlynewreportdir,leaveold
untrackedreports. No scientificreplayforbookkeeping. No goalblockedmerelyhard/slow.
