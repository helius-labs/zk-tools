# Consume temporary bucket storage for weighted roots

Previous goal turn PROGRESS: fullSDK parallel-root negative verified/reviewed/
pushed2041eb342b. Goal CPU AVX single-proof>=10xM5CPU EACH ALL8, withCPU+Metal,
remains active/unmet0/8, no budget. Canonical49363 unchanged here. User authorizes
noquestions/autonomousloop,commitANDpush each experiment,politefacts,no subagents.

Different storage/ownership contract, not removal of a memory check from oldrecipe.
FreshCURRENT176 sources. Nine real G1/generic terminal calls consume temporary
Vecs produced by affine_buckets/state.finish/reduce_indexed_buckets or final
combined merges. Caller references to immutable key points/scalars remain borrowed;
no use of the consumed bucket Vec follows. G2 Phi/Horner internal entry unchanged.
A new weighted_affine_owned(Vec) wrapper lends its exclusive slice to G1 hook,
otherwise invokes accepted weighted_affine(&buckets). Originalborrowed function
BODY must remain byte-exact. New hook guards len>=2048,full256groups and resource
policy BEFORE mutation; G2/default/short/nonfullgroups fall back unchanged.

Eligible root pass: old511slottree and Scratch copy/reduce each256inputgroup,
then store the unchanged nine roots in that group's first nine EXISTING entries.
No resize/reserve/clone of bucketstorage. All other247entries remain original.
BarrierreleasesallrootScratch; foldpassgatherseight9prefixes into fixedoldarrays,
calls exactqualifieddouble-add kernel,retainsweightedandunweightedpartialsandold
chunk-offset corrections. Up to8lanes partiallasttile handled. Existingpartialout
Vec of (Projective,Affine) stayssamecapacity; no full heaprootarray exists.

shape() already charges bucketVec+partialout per suspended windowparent; no extra
parentarray may be hidden in per-worker maximum. workspace_weighted adds6176logical
fixedfoldbytes per possibleG1leaf (same oldobjects). G2extra0; checkedoverflowNone.
Rootphasefixed9rootreturn fits conservative6176 and doesnot overlapfoldlocals;
original511tree+Scratchcharged asbefore. Extra'ssum islogicalNOTemittedstack/RSS.
No new optionalallocation/Reservation/OSheadroomlookup/ADMISSIONlock. This doesnot
promise no allocator syscalls: original trees/partials still allocate/drop. Required
proofscratch is outsideoptionalPREPARE_MAX_BYTES;zerooptionalbudgetdoesnot prohibit
thisnoextraheap route,resource_schedule=0 explicitlyretainsaccepted route. Existing
policy/forecast/allocator implementation bytes remain exact. No keytable/plan/
persistentcache/newpool/artificialRAMcap. Mobile/ARM originallyportable untouched.

Correctness: unchangedkernel/rootsalgebra reused withoutstandalone replay. New
integrationnativewholecoretests,independentArkweightedANDunweightedpartials,
all5populations,sparse/cancel/opposites,fullgroupnon8multiples,decline-before-write
nonfull/short,original-validpartialtails throughwrapper,G2bypass,guardedzerooptional
budget,resourceoff;1/4/16/32 requested512KiBworker pools and12sharedpoolcallers.
Pointer/len/capacity/unchangednonprefixentrieschecked on actualmutableslicepath;
immutableexternalpointschecked acrossownedclones. Directslicehookprivate;actual
SDKonlyviaownedVecwrapper. Native131? expected127inherited+4new=131,actualoutput
mustdecide. Genericdisabled compileonly,notARMexecution. Allacceptedcfgs/densebusy
reset andoriginalfield1200 retained,coherentSDKlinksafterqualification. No clocks
orproofs inthisnative stage. Extra barrier,rootstores/reloads/gathers/packing/
inversions/guards/offsets/drop allcharged in futureWHOLESDK ALL8+54 primary1/16/32.

Newrecipe mustbeprospectivelyfrozenbeforeANYSDKpreflight,withbothactualreaders,
all79gates/inputs/order/backings/automaticprofiles/resources. Source/historyaudit
foundnoexactownedrootstorage priorcandidate intargeteddesign/README searches;
notexhaustiveproof. Priorweightedtranspose wasdifferentcircuit502joins,closed;
priorgroupedandheapparallelrootnegativesremainclosed. Moreworkitemsdon'tguarantee
concurrency,lowerheap/syscallsdon'tguaranteelatency. No2xforecastfromthislocalpath.
