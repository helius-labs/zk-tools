use super::*;
use ark_ec::{AffineRepr,CurveGroup,PrimeGroup};
use ark_ff::{BigInt,PrimeField,Zero};
use zopro_bn254::{G1Config,G1Affine,G2Config,G2Affine};
fn af(v:Fr)->ark_bn254::Fr{ark_bn254::Fr::from_bigint(BigInt(v.to_canonical())).unwrap()}
fn aq(v:ark_bn254::Fq)->Fq{Fq::from_canonical(v.into_bigint().0).unwrap()}
fn check_g1(got:Projective<G1Config>,want:ark_bn254::G1Projective){let got=got.to_affine();let want=want.into_affine();if want.is_zero(){assert!(got.is_identity());}else{assert_eq!([got.x,got.y],[aq(want.x),aq(want.y)]);}}
fn seed(state:&mut u64)->Fr{let mut b=[0;32];for c in b.chunks_exact_mut(8){*state^=*state<<13;*state^=*state>>7;*state^=*state<<17;c.copy_from_slice(&state.to_le_bytes());}Fr::from_le_bytes_mod_order(&b)}
fn population(n:usize,kind:usize)->(Vec<G1Affine>,Vec<ark_bn254::Fr>){let mut state=0xa851743bacd02e17;let g=ark_bn254::G1Projective::generator();let pool:Vec<_>=(0..64).map(|_|af(seed(&mut state))).collect();let native:Vec<_>=pool.iter().map(|s|{let p=(g* *s).into_affine();G1Affine::new(aq(p.x),aq(p.y))}).collect();let mut coeff=Vec::with_capacity(n);let points=(0..n).map(|i|{let j=(i*37+i/256)%64;let (s,p)=match kind{0=>(ark_bn254::Fr::zero(),G1Affine::IDENTITY),1=>(pool[j],native[j]),2=>if i%2==0{(pool[j],native[j])}else{(-pool[j],-native[j])},3=>if i%13!=0{(ark_bn254::Fr::zero(),G1Affine::IDENTITY)}else{(pool[j],native[j])},_=>if i%5==0{(-pool[0],-native[0])}else{(pool[0],native[0])}};coeff.push(s);p}).collect();(points,coeff)}
fn expected(c:&[ark_bn254::Fr],weighted:bool)->ark_bn254::G1Projective{let s=c.iter().enumerate().fold(ark_bn254::Fr::zero(),|s,(i,x)|s+ *x*ark_bn254::Fr::from(if weighted{i as u64+1}else{1}));ark_bn254::G1Projective::generator()*s}

#[test]
fn owned_full_groups_both_outputs_and_original_borrowed_entry() {
    let mut cases=0;
    for kind in 0..5 {let (p,c)=population(16384,kind);let keep=p.clone();
        for n in [2048usize,2304,2560,2816,3072,3328,3584,3840,4096,4352,6144,8192,16384] {
            let mut input=p[..n].to_vec();let ptr=input.as_ptr();let cap=input.capacity();
            let jobs=ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed);
            let folds=FOLD_JOBS.load(std::sync::atomic::Ordering::Relaxed);
            check_g1(weighted(&mut input).unwrap(),expected(&c[..n],true));
            assert_eq!((input.as_ptr(),input.len(),input.capacity()),(ptr,n,cap));
            assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed)-jobs,n/256);
            assert_eq!(FOLD_JOBS.load(std::sync::atomic::Ordering::Relaxed)-folds,(n/256).div_ceil(8));
            for (got,old) in input.chunks(256).zip(p[..n].chunks(256)){assert_eq!(&got[9..],&old[9..]);}
            check_g1(weighted_affine_owned(p[..n].to_vec()),expected(&c[..n],true));
            // Both partial outputs are required for the outer group offsets.
            let mut input=p[..n].to_vec();let out=partials(&mut input);
            for ((w,total),c) in out.into_iter().zip(c[..n].chunks(256)){check_g1(w,expected(c,true));check_g1(total.to_projective(),expected(c,false));}
            check_g1(weighted_affine(&p[..n]),expected(&c[..n],true));
            assert_eq!(p,keep);cases+=1;
        }
    }
    assert_eq!(cases,65);println!("OWNED_FULL_CASES=65;BOTH_PARTIAL_OUTPUTS=Ark_checked;INPUT_STORAGE_PTR_LEN_CAP=unchanged;NONPREFIX_ENTRIES=unchanged;EXTERNAL_POINTS=unchanged;BORROWED_ENTRY=original");
}

#[test]
fn declined_slice_is_unchanged_and_wrapper_keeps_original_valid_tails() {
    let(p,c)=population(4352,2);let mut declined=0;
    for n in[0usize,1,2,3,4,8,128,256,257,512,1024,1792,2047,2049,2051,2055,2303,4095,4097] {
        let mut input=p[..n].to_vec();let keep=input.clone();let ptr=input.as_ptr();let cap=input.capacity();
        let before=ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed);
        assert!(weighted(&mut input).is_none());assert_eq!(input,keep);
        assert_eq!((input.as_ptr(),input.len(),input.capacity()),(ptr,n,cap));
        assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed),before);declined+=1;
    }
    let mut tails=0;for n in[0usize,1,2,4,8,128,256,257,512,1024,1792,2049,2050,2052,2056,2064,2080,2112,2176,4097] {check_g1(weighted_affine_owned(p[..n].to_vec()),expected(&c[..n],true));tails+=1;}
    let prior=std::env::var_os("ZOPRO_CPU_RESOURCE_SCHEDULE");std::env::set_var("ZOPRO_CPU_RESOURCE_SCHEDULE","0");
    let mut input=p[..2048].to_vec();let keep=input.clone();assert!(weighted(&mut input).is_none());assert_eq!(input,keep);
    check_g1(weighted_affine_owned(input),expected(&c[..2048],true));
    match prior{Some(v)=>std::env::set_var("ZOPRO_CPU_RESOURCE_SCHEDULE",v),None=>std::env::remove_var("ZOPRO_CPU_RESOURCE_SCHEDULE")};
    let prior=std::env::var_os("ZOPRO_CPU_PREPARE_MAX_BYTES");std::env::set_var("ZOPRO_CPU_PREPARE_MAX_BYTES","0");
    let before=ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed);check_g1(weighted_affine_owned(p[..2048].to_vec()),expected(&c[..2048],true));assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed)-before,8);
    match prior{Some(v)=>std::env::set_var("ZOPRO_CPU_PREPARE_MAX_BYTES",v),None=>std::env::remove_var("ZOPRO_CPU_PREPARE_MAX_BYTES")};
    assert_eq!((declined,tails),(19,20));println!("DECLINE_BEFORE_WRITE=19;ORIGINAL_VALID_TAILS=20;RESOURCE_OFF=original;ZERO_OPTIONAL_PREP_BUDGET=no_extra_heap_route");
}

#[test]
fn actual_workers_and_shared_pool_owned_calls() {
    let(p,c)=population(4352,2);let want=expected(&c,true);let keep=p.clone();let mut count=0;
    for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();let seen=std::sync::Mutex::new(std::collections::BTreeSet::new());pool.broadcast(|ctx|{check_g1(weighted_affine_owned(p.clone()),want);seen.lock().unwrap().insert(ctx.index());});assert_eq!(seen.into_inner().unwrap().len(),workers);count+=workers;}
    let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();std::thread::scope(|s|{let tasks:Vec<_>=(0..4).map(|_|s.spawn(||{for _ in 0..3{pool.install(||check_g1(weighted_affine_owned(p.clone()),want));}})).collect();for t in tasks{t.join().unwrap();}});assert_eq!(p,keep);assert_eq!(count,53);println!("ACTUAL_WORKERS=53;CONCURRENT_OWNED_CALLS=12;REQUESTED_STACK=512KiB;PHASE_BARRIER=checked");
}

#[test]
fn typed_fixed_scratch_forecast_overflow_and_g2_original() {
    let logical=8*9*core::mem::size_of::<G1Affine>()+2*8*core::mem::size_of::<G1Affine>()+core::mem::size_of::<kernel::Output<G1Config>>();assert_eq!(logical,6176);assert_eq!(extra::<G1Config>(),Some(logical));
    use crate::msm_affine::workspace::vector as v;
    let base=|n:usize|->Option<usize>{if n==0{return Some(0)}let g=n.min(256);let pairs=g/2;let per=v::<LimbPoint<Fq>>(2*g-1,false)?.checked_add(v::<usize>(pairs,true)?)?.checked_add(v::<Group<Fq>>(pairs/LANES,false)?)?.checked_add(core::mem::size_of::<Vec<[FqBatch;2]>>())?;per.checked_mul(n.div_ceil(256))?.checked_add(v::<(Projective<G1Config>,G1Affine)>(n.div_ceil(256),false)?)};
    for n in[0usize,1,256,2048,4096,65536]{assert_eq!(workspace_weighted::<G1Config>(n),base(n).and_then(|b|b.checked_add(logical.checked_mul(n.div_ceil(256))?)));}
    assert_eq!(workspace_weighted::<G1Config>(usize::MAX),None);assert_eq!(<Fq2 as BatchInverse>::weighted_owned_extra::<G2Config>(),Some(0));
    let g=ark_bn254::G2Projective::generator();let pool:Vec<_>=(1..=16).map(|i|(g*ark_bn254::Fr::from(i as u64)).into_affine()).collect();let p:Vec<_>=(0..2048).map(|i|{let p=pool[i%16];G2Affine::new(Fq2::new(aq(p.x.c0),aq(p.x.c1)),Fq2::new(aq(p.y.c0),aq(p.y.c1)))}).collect();let keep=p.clone();let before=ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed);let got=weighted_affine_owned::<G2Config>(p).to_affine();let want=(g*(0..2048).fold(ark_bn254::Fr::zero(),|s,i|s+ark_bn254::Fr::from((i as u64+1)*(i as u64%16+1)))).into_affine();assert_eq!([got.x.c0,got.x.c1,got.y.c0,got.y.c1],[aq(want.x.c0),aq(want.x.c1),aq(want.y.c0),aq(want.y.c1)]);assert_eq!(ROOT_JOBS.load(std::sync::atomic::Ordering::Relaxed),before);
    let got=weighted_affine(&keep).to_affine();assert_eq!([got.x.c0,got.x.c1,got.y.c0,got.y.c1],[aq(want.x.c0),aq(want.x.c1),aq(want.y.c0),aq(want.y.c1)]);
    println!("FIXED_EXTRA_PER_G1_LEAF=6176;ROOT_PARENT_EXTRA=0;FORECAST_EDGES=6;OVERFLOW=declined;G2=original");
}
