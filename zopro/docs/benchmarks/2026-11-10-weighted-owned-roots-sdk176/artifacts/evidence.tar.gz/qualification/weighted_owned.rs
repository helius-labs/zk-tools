//! Consume temporary buckets: root prefixes reuse their existing storage.
use super::*;
mod kernel;
#[cfg(test)]
static ROOT_JOBS:std::sync::atomic::AtomicUsize=std::sync::atomic::AtomicUsize::new(0);
#[cfg(test)]
static FOLD_JOBS:std::sync::atomic::AtomicUsize=std::sync::atomic::AtomicUsize::new(0);

pub(super) fn extra<C:CurveConfig<Base=Fq>>()->Option<usize> {
    core::mem::size_of::<[[Affine<C>;9];8]>()
        .checked_add(core::mem::size_of::<[Affine<C>;8]>().checked_mul(2)?)?
        .checked_add(core::mem::size_of::<kernel::Output<C>>())
}

// ROOTS_BODY_INSERTION

fn partials<C:CurveConfig<Base=Fq>>(buckets:&mut[Affine<C>])->Vec<(Projective<C>,Affine<C>)> {
    assert!(!buckets.is_empty()&&buckets.len()%256==0);
    let groups=buckets.len()/256;
    #[cfg(test)] let done=std::sync::atomic::AtomicUsize::new(0);
    buckets.par_chunks_mut(256).for_each_init(
        ||(Vec::<LimbPoint<Fq>>::new(),Scratch::<C>::default()),
        |(tree,scratch),input| {
            let values=roots(input,tree,scratch);
            input[..9].copy_from_slice(&values);
            #[cfg(test)] {
                ROOT_JOBS.fetch_add(1,std::sync::atomic::Ordering::Relaxed);
                done.fetch_add(1,std::sync::atomic::Ordering::Release);
            }
        });
    // The owning caller retains this same bucket allocation through the fold.
    // No root-phase tree or Scratch survives the completed parallel call.
    let mut partials=vec![(Projective::<C>::IDENTITY,Affine::<C>::IDENTITY);groups];
    partials.par_chunks_mut(8).zip(buckets.par_chunks(8*256)).for_each(|(out,input)| {
        #[cfg(test)] {
            assert_eq!(done.load(std::sync::atomic::Ordering::Acquire),groups);
            FOLD_JOBS.fetch_add(1,std::sync::atomic::Ordering::Relaxed);
        }
        let active=out.len();let mut values=[[Affine::<C>::IDENTITY;9];8];
        for (lane,group) in input.chunks(256).enumerate(){values[lane].copy_from_slice(&group[..9]);}
        let (weighted,_)=kernel::fold(&values,active);
        for i in 0..active {out[i]=(weighted[i].to_projective(),values[i][0]);}
    });
    partials
}

pub(super) fn weighted<C:CurveConfig<Base=Fq>>(buckets:&mut[Affine<C>])->Option<Projective<C>> {
    if buckets.len()<2048 || buckets.len()%256!=0 || !crate::simd::cpu_option("ZOPRO_CPU_RESOURCE_SCHEDULE"){return None;}
    let partials=partials(buckets);
    let mut sum=Projective::<C>::IDENTITY;
    let mut offset=Projective::<C>::IDENTITY;
    let mut running=Projective::<C>::IDENTITY;
    for (weighted,total) in partials.into_iter().rev(){sum+=weighted;offset+=running;running+=total;}
    for _ in 0..256usize.ilog2(){offset=offset.double();}
    Some(sum+offset)
}

#[cfg(test)]
mod tests;
