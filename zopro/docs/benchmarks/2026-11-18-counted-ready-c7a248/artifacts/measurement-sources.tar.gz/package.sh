#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
p=../counted-ready247
prior=../ready-solver246/bundle
test ! -e bundle
jq -e '.status=="complete"' helper-run/result.json "$p"/{build,generic,local-run}/result.json >/dev/null
jq -e '.passed and .canonical_count==64307 and .local_functional_exports==6' "$p/local-review.json" >/dev/null
(cd "$prior" && jq -r 'to_entries[]|"\(.value)  \(.key)"' payload-pins.json | sha256sum -c --quiet)
mkdir -p bundle/{bin,config}
cp -al "$prior"/{keys,images,requests,lib} bundle/
cp "$prior"/bin/{xtask,verify,reference} bundle/bin/
cp "$prior/bin/sdk" bundle/bin/old
cp "$p/build/candidate-sdk" bundle/bin/sdk
cp runner independent bundle/bin/
cp "$p/proof-sha256-after-local.json" bundle/config/seed.json
sha256sum -c <<'DIGEST'
60bdbcb13137800eeb8fa9e9b31edaa93a96ca0fd9d0f010ee6f8445beba900a  bundle/config/seed.json
2d47de55858b89ff4a48f46753aec91a1183b802cd0a6d083e122c55ba8cd407  bundle/bin/sdk
1e0cdbfa3b0ee307b74fa670d93ef15c3c685825e287adcaaf3a405326061549  bundle/bin/old
d523f49e8548620c4373a1ab4be2712d705709fdd7a590c5ed73e9aff97424e3  bundle/bin/reference
DIGEST
jq '.old_sha256=.sdk_sha256|.sdk_sha256="2d47de55858b89ff4a48f46753aec91a1183b802cd0a6d083e122c55ba8cd407"|.seed_count=64307|.scope="Count-first solver C7a comparison"|.measured_sdk_scope="Previous solver enabled, corrected solver enabled and disabled, exact accepted reference"' "$prior/config/config.json" > bundle/config/config.json
cp "$p/production-manifest.json" .
cp runner.rs independent.rs protocol.md production-manifest.json "$p/local-review.json" bundle/config/
jq '{passed,local_functional_exports,local_SDK_calls,canonical_count,canonical_sha256}' "$p/local-review.json" > native-qualification.json
./runner "$PWD/bundle" pins
tar -cf - -C bundle . | gzip -1 > bundle.tar.gz
sha256sum "$PWD/bundle.tar.gz" | jq -Rn 'input|capture("^(?<hash>[a-f0-9]+)  (?<path>.+)$")|{(.path):.hash}' > package-hashes.json
jq -n --argjson size "$(stat -c%s bundle.tar.gz)" '{passed:true,bytes:$size}' > package-ready.json
