use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const N: &str = "/home/ubuntu/src/zopro-perf-work/byte-permute-pack176";
const R: &str = "/home/ubuntu/src/zopro-perf-work/byte-permute-pack176/pilot";
const O: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix-cfg176/sdk";
const BEFORE:&str="/home/ubuntu/src/zopro-perf-work/uniform-prefix-cfg176/sdk/primary-pilot/proof-sha256-after-diagnostic.json";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: &Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn rep(s: &mut String, a: &str, b: &str, n: usize) {
    assert_eq!(s.matches(a).count(), n, "{a}");
    *s = s.replace(a, b);
}
fn retarget(s: &str) -> String {
    s.replace("/home/ubuntu/src/zopro-perf-work/uniform-prefix176/native/sdk-build",&format!("{N}/sdk-build")).replace(O,R).replace("/home/ubuntu/src/zopro-perf-work/borrowed-bucket-tree176/native/primary-pilot/proof-sha256-after-diagnostic.json",BEFORE).replace("31699","__BEFORE__").replace("31726","__PREFLIGHT__").replace("31771","__LATENCY__").replace("31777","__DIAGNOSTIC__").replace("__BEFORE__","31777").replace("__PREFLIGHT__","31804").replace("__LATENCY__","31897").replace("__DIAGNOSTIC__","31903")
}
fn tune_pilot(mut s: String) -> String {
    rep(&mut s, "\"blocks\":15", "\"blocks\":31", 1);
    rep(&mut s, "0..15", "0..31", 2);
    rep(&mut s, "vec![1.; 15]", "vec![1.; 31]", 1);
    rep(
        &mut s,
        "assert_eq!(a.len(), 15)",
        "assert_eq!(a.len(), 31)",
        1,
    );
    rep(
        &mut s,
        "assert_eq!(b.len(), 15)",
        "assert_eq!(b.len(), 31)",
        1,
    );
    rep(&mut s, "r[7]", "r[15]", 1);
    rep(&mut s, "r[3]", "r[9]", 1);
    rep(&mut s, "r[11]", "r[21]", 1);
    rep(&mut s, "{ 45 } else { 6 }", "{ 93 } else { 6 }", 1);
    rep(&mut s, ">= 10", ">= 21", 1);
    rep(&mut s, "6930", "14322", 2);
    rep(
        &mut s,
        "\"latency_exports\":45",
        "\"latency_exports\":93",
        1,
    );
    rep(
        &mut s,
        "\"fresh_independent_exports\":45",
        "\"fresh_independent_exports\":93",
        1,
    );
    rep(
        &mut s,
        "indices3..11 (ranks4..12)",
        "indices9..21 (ranks10..22)",
        1,
    );
    rep(&mut s, "nominal96.484375%", "nominal97.0550626516%", 2);
    rep(&mut s, "at least10/15wins", "at least21/31wins", 1);
    rep(
        &mut s,
        "prepared45latency+45verification",
        "prepared93latency+93verification",
        1,
    );
    s
}
fn tune_review(mut s: String) -> String {
    rep(
        &mut s,
        "assert_eq!(means[arm].len(), 15)",
        "assert_eq!(means[arm].len(), 31)",
        1,
    );
    rep(&mut s, "0..15", "0..31", 1);
    rep(
        &mut s,
        "[(3, \"lower\"), (7, \"median\"), (11, \"upper\")]",
        "[(9, \"lower\"), (15, \"median\"), (21, \"upper\")]",
        1,
    );
    rep(&mut s, "ratios[7]", "ratios[15]", 1);
    rep(&mut s, "ratios[3]", "ratios[9]", 1);
    rep(&mut s, "ratios[11]", "ratios[21]", 1);
    rep(&mut s, ">= 10", ">= 21", 1);
    rep(
        &mut s,
        "assert_eq!(requests, 7794)",
        "assert_eq!(requests, 15186)",
        1,
    );
    rep(
        &mut s,
        "assert_eq!(exported, 51)",
        "assert_eq!(exported, 99)",
        1,
    );
    assert!(s.contains("take(15)"));
    s
}
fn main() {
    assert_eq!(
        load(format!("{N}/native-review.json"))["review_passed"],
        true
    );
    let final_review = load(format!("{N}/final-review.json"));
    assert_eq!(final_review["review_passed"], true);
    assert_eq!(final_review["performance_trial_selected"], true);
    assert_eq!(load(BEFORE).as_array().unwrap().len(), 31777);
    let q = load(format!("{N}/prospective-pilot.json"));
    assert_eq!(q["blocks"], 31);
    assert_eq!(q["paired_median_ranks"], json!([10, 22]));
    let r = Path::new(R);
    assert!(!r.exists());
    fs::create_dir_all(r).unwrap();
    for file in [
        "pilot.rs",
        "review-pilot.rs",
        "review-preflight.rs",
        "preflight-plan.json",
        "preflight-jobs.json",
        "preflight-review-plan.json",
        "pilot-compilation-plan.json",
    ] {
        let mut s = retarget(&fs::read_to_string(Path::new(O).join(file)).unwrap());
        if file == "pilot.rs" {
            s = tune_pilot(s);
        }
        if file == "review-pilot.rs" {
            s = tune_review(s);
        }
        fs::write(r.join(file), s).unwrap();
    }
    let mut ids = load(format!("{O}/sdk-identities.json"));
    for arm in ["OFF", "ON"] {
        let a = load(format!("{N}/sdk-build/{arm}/artifacts.json"));
        let b = a["binary"].as_str().unwrap();
        assert_eq!(hash(b), a["binary_sha256"].as_str().unwrap());
        ids[arm] = json!({"binary":b,"binary_sha256":hash(b)});
    }
    assert_eq!(
        hash(ids["accepted"]["binary"].as_str().unwrap()),
        ids["accepted"]["binary_sha256"].as_str().unwrap()
    );
    save(r.join("sdk-identities.json"), &ids);
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(load(format!("{N}/sdk-build-pins.json"))).unwrap();
    let accepted=load("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");
    for (name, h) in accepted["source_files_sha256"].as_object().unwrap() {
        let p = format!("/home/ubuntu/src/zk-tools/zopro/{name}");
        assert_eq!(hash(&p), h.as_str().unwrap());
        pins.insert(p, h.as_str().unwrap().into());
    }
    for (p, h) in load(format!("{O}/preflight-pins.json"))
        .as_object()
        .unwrap()
    {
        if p.contains("/sdk-control-copies/images/")
            || p.contains("/tools/zolana/fixtures/")
            || p.contains("/batch-local-steal/gnark/")
            || p.contains("/tool-target/release/deps/")
        {
            assert_eq!(hash(p), h.as_str().unwrap());
            pins.insert(p.clone(), h.as_str().unwrap().into());
        }
    }
    for arm in ["accepted", "OFF", "ON"] {
        let p = ids[arm]["binary"].as_str().unwrap();
        pins.insert(p.into(), hash(p));
    }
    for file in [
        "review-preflight.rs",
        "preflight-plan.json",
        "preflight-jobs.json",
        "sdk-identities.json",
    ] {
        let p = format!("{R}/{file}");
        pins.insert(p.clone(), hash(&p));
    }
    for p in [
        BEFORE,
        &format!("{N}/design.md"),
        &format!("{N}/native-review.json"),
        &format!("{N}/final-review.json"),
        &format!("{N}/codegen-complete-analysis.json"),
        &format!("{N}/prospective-pilot.json"),
        &format!("{N}/prepare-pilot.rs"),
    ] {
        pins.insert(p.into(), hash(p));
    }
    for (p, h) in &pins {
        assert_eq!(&hash(p), h);
    }
    save(r.join("preflight-pins.json"), &json!(pins));
    save(
        r.join("preparation.json"),
        &json!({"prospective":q,"same_qualified_SDKs":ids,"preflight_shapes":9,"preflight_arms":3,"preflight_requests":108,"preflight_exports":27,"latency_requests":14322,"latency_exports":93,"diagnostic_requests":864,"diagnostic_exports":6,"all_study_requests":15294,"all_study_exports":126,"ledger_before":31777,"after_preflight":31804,"after_latency":31897,"after_diagnostic":31903,"preflight_pins":pins.len(),"old_successful_qualifications_not_replayed":true,"performance_clocks_started":false}),
    );
    println!(
        "prepared first31block wholeSDK campaign; ledger31777→31804→31897→31903; no clocks started"
    );
}
