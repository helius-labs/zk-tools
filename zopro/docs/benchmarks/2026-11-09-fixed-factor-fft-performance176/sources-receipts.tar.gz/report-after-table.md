
The two 32-worker contexts' paired geometric aggregate is 1.038771 ON/OFF,
with descriptive ranks 1–5 of [1.035163, 1.043983] and one win in seven blocks.
Nineteen selection gates fail, including six clear matched regressions. The
fixed recipe is closed without extension, reroll, layout or subset rescue.

The arithmetic saved IFMA sites but increased total work. Single-worker PMU
instructions increase 22.9% at domain 65,536 and 19.9% at 262,144; user cycles
increase 32.6% and 24.1%. Both arms have zero measured minor faults in those
single-worker contexts. At 32 workers, instructions increase 18.1% and 16.9%.
Flat samples in the actual DIF/DIT leaf functions increase substantially.
Expansion, loads, normalization and carry work are plausible costs; this study
does not isolate a causal contribution for each. Generic cache counters do not
support attributing the regression solely to memory capacity or page faults.

The inherited compact-cache charge is at most 32,016 bytes across three
directions and 21,344 bytes after Euler conversion, plus optional pointers.
That allocation charge did not bound process RSS: the small-domain ON harness
peaks 1.75–2.25 MiB above OFF and fails five pairwise RSS checks. The harness
peak includes oracle and plan setup, allocator behavior and stacks; it is not
the prover's minimum RAM, nor a measurement of cache bytes alone.

This consumer also shows diminishing scaling: OFF takes 1.063/1.160 ms at
16/32 workers for the small domain and 6.973/7.068 ms for the large domain.
Summed phase CPU roughly doubles. Two named scheduling/epoch functions are
prominent in parallel flat profiles, but their samples do not measure all Rayon
overhead or an exclusive removable wall-time fraction. These findings do not
establish that the full prover should use 16 workers.

One favorable large-domain ON block is retained: 4.954 ms with 5.8 minor faults
per call, versus roughly 6,300 faults and 7.3–7.4 ms in its other blocks. The
single favorable block is included in the failed selection. Fault correlation
is a separate allocation/page-lifecycle question, not evidence for adopting the
lookup candidate. Earlier page-initialization, stack and scheduler experiments
must be checked before any distinct follow-up; this does not revive their
rejected variants.

All 270 capture/offline commands passed on first execution: 18 preflights,
126 latency processes, 18 gated counter panels, 18 gated cycle profiles, then
90 offline commands. The measured loops contain 24,696 complete consumer calls.
Every process checks a full independent Arkworks oracle before measurement and
a complete result digest afterwards. Workers are individually pinned with
512 KiB stacks. Profiles start disabled and gate only the warmed loop; this
includes result deallocation, whereas per-call wall timing excludes that drop.
All recordings finished before helper, analysis, hash, decode or publication
work. There are 4,236,256 samples, no LOST events, 100% assigned tasks and 100%
PMU running time. Unknown samples are 2.28% in aggregate and below 5% per profile.

The actual measurement executables first passed 2,949,120 new oracle outputs
and were decoded. One earlier link failed because a helper JSON library lacked
LTO bitcode; all arms were rebound to the same frozen JSON library before any
test or timing. The failure is retained. Two result readers independently
validated receipts, raw medians, paired ratios and the rejection without
repeating measurements.

[Capture analysis](artifacts/capture-analysis.json),
[profiles and counters](artifacts/diagnostic-analysis.json),
[interpretation and all large-32 blocks](artifacts/insights.json),
[independent review](artifacts/review.json),
[frozen protocol](artifacts/capture-protocol.json) and
[continuation notes](artifacts/next.md) retain the evidence. The
[release qualification](../2026-11-09-fixed-factor-fft-release176/README.md)
documents the admission-order fix used here. Full local results, including raw
perf recordings and decoded samples, remain under
`/home/ubuntu/src/zopro-perf-work/fixed-factor-fft-performance176`.

The archive contains source, receipts, timing samples, counters and profile
summaries. Large decoded logs and raw perf data remain local; the index lists
omissions and hashes. No private proving inputs or proof ledger are published.

The following local 9950X/32-worker full-proof results are inherited from the
accepted build. The supplied M5 CPU/Metal figures are reference measurements
from another machine. This candidate adds no full-proof row; the CPU 10× goal
remains active and unmet for all eight shapes.

