# Bounded fixed-factor FFT: matched consumer result

The corrected bounded fixed-factor FFT candidate is **rejected**. It regresses
in all six matched complete-Euler contexts. All six OFF/accepted-reference
calibrations pass; all 18 profiles meet the declared quality checks. Production
sources and the accepted SDK remain unchanged. This experiment adds no verified
full-proof latency or Aeglos/AWS comparison.

The table below measures the complete Euler consumer, including input clones
and factor expansion. Values are medians of seven process medians. The paired
ratio is computed within blocks and need not equal the ratio of the displayed
medians. These are consumer timings, not 1×2 proof timings.

