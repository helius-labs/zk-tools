//! Diagnostic observation of existing FqBatch scalar inversions, never field values.
use std::{cell::RefCell,fs,sync::{Arc,Mutex,OnceLock,atomic::{AtomicU32,Ordering}},time::Instant};
use zopro_bn254::Fq;
pub const EVENT_CAPACITY:usize=65536;
#[derive(Clone,Copy,Debug)]
pub struct Event{pub begin_ns:u64,pub end_ns:u64}
pub struct ThreadTrace{pub tid:u32,pub rust_thread:String,pub name:String,pub worker:Option<usize>,pub allowed_cpus:String,pub events:Vec<Event>,pub overflow:u64}
impl ThreadTrace{fn push(&mut self,e:Event){if self.events.len()<self.events.capacity(){self.events.push(e);}else{self.overflow+=1;}}}
struct State{origin:Instant,epoch:AtomicU32,registry:Mutex<Vec<Arc<Mutex<ThreadTrace>>>>}
static STATE:OnceLock<State>=OnceLock::new();
thread_local!{static LOCAL:RefCell<Option<Arc<Mutex<ThreadTrace>>>>=const{RefCell::new(None)};}
fn state()->&'static State{STATE.get_or_init(||State{origin:Instant::now(),epoch:AtomicU32::new(0),registry:Mutex::new(Vec::new())})}
fn now()->u64{state().origin.elapsed().as_nanos().try_into().unwrap()}
fn local()->Arc<Mutex<ThreadTrace>>{LOCAL.with(|cell|{let mut value=cell.borrow_mut();if let Some(value)=value.as_ref(){return value.clone()}let status=fs::read_to_string("/proc/thread-self/status").unwrap();let field=|key:&str|status.lines().find_map(|l|l.strip_prefix(key)).unwrap().trim().to_owned();let tid=field("Pid:").parse().unwrap();assert_eq!(field("Tgid:").parse::<u32>().unwrap(),std::process::id());let thread=std::thread::current();let trace=Arc::new(Mutex::new(ThreadTrace{tid,rust_thread:format!("{:?}",thread.id()),name:thread.name().unwrap_or("").into(),worker:rayon::current_thread_index(),allowed_cpus:field("Cpus_allowed_list:"),events:Vec::with_capacity(EVENT_CAPACITY),overflow:0}));state().registry.lock().unwrap().push(trace.clone());*value=Some(trace.clone());trace})}
pub fn register_thread(){let _=local();}
pub fn begin(epoch:u32)->u64{assert!(epoch>0);assert_eq!(state().epoch.load(Ordering::Acquire),0);for trace in state().registry.lock().unwrap().iter(){let mut trace=trace.lock().unwrap();trace.events.clear();trace.overflow=0;}let start=now();state().epoch.store(epoch,Ordering::Release);start}
pub struct End{pub epoch:u32,pub end_ns:u64,pub threads:usize,pub events:usize,pub overflow:u64}
/// Call only after all SDK jobs have joined. The callback runs outside the proof.
pub fn finish(mut visit:impl FnMut(&ThreadTrace))->End{let end=now();let epoch=state().epoch.swap(0,Ordering::AcqRel);assert!(epoch>0);let registry=state().registry.lock().unwrap();let mut out=End{epoch,end_ns:end,threads:registry.len(),events:0,overflow:0};for trace in registry.iter(){let trace=trace.lock().unwrap();out.events+=trace.events.len();out.overflow+=trace.overflow;visit(&trace);}out}
#[inline]
pub(crate) fn invert(value:Fq)->Fq{let epoch=state().epoch.load(Ordering::Acquire);if epoch==0{return value.inverse().unwrap()}let trace=local();let start=now();let inverse=value.inverse().unwrap();let end=now();assert_eq!(state().epoch.load(Ordering::Acquire),epoch,"SDK jobs must join before finishing observation");trace.lock().unwrap().push(Event{begin_ns:start,end_ns:end});inverse}

#[cfg(test)]
mod tests{
use super::*;
fn export()->Vec<(u32,usize,u64,Vec<Event>)>{let mut rows=vec![];let end=finish(|t|rows.push((t.tid,t.events.capacity(),t.overflow,t.events.clone())));assert_eq!(end.overflow,0);rows}
#[test]fn wrapper_and_epochs(){register_thread();for epoch in 1..=3{let start=begin(epoch);for i in 1..=31{let x=if i%2==0{-Fq::from(i)}else{Fq::from(i)};let actual=invert(x);assert_eq!(actual*x,Fq::ONE);assert_eq!(actual,x.inverse().unwrap());}let rows=export();let events=rows.iter().flat_map(|r|&r.3).collect::<Vec<_>>();assert_eq!(events.len(),31);assert!(events.iter().all(|e|e.begin_ns>=start&&e.end_ns>e.begin_ns));assert!(rows.iter().all(|r|r.1>=EVENT_CAPACITY&&r.2==0));}assert_eq!(invert(Fq::ONE),Fq::ONE);assert_eq!(state().epoch.load(Ordering::Acquire),0);}
#[test]fn concurrent_identities(){use std::sync::Barrier;let warm=Arc::new(Barrier::new(5));let run=Arc::new(Barrier::new(5));let mut jobs=vec![];for worker in 0..4{let(warm,run)=(warm.clone(),run.clone());jobs.push(std::thread::spawn(move||{register_thread();warm.wait();run.wait();for i in 1..=19{let value=Fq::from((i+worker*101)as u64);assert_eq!(invert(value)*value,Fq::ONE);}}));}warm.wait();let _=begin(4);run.wait();for job in jobs{job.join().unwrap();}let rows=export();let active=rows.iter().filter(|r|!r.3.is_empty()).collect::<Vec<_>>();assert_eq!(active.len(),4);let ids=active.iter().map(|r|r.0).collect::<std::collections::BTreeSet<_>>();assert_eq!(ids.len(),4);assert_eq!(active.iter().map(|r|r.3.len()).sum::<usize>(),76);}
#[test]fn overflow_is_visible(){let mut trace=ThreadTrace{tid:1,rust_thread:String::new(),name:String::new(),worker:None,allowed_cpus:String::new(),events:Vec::with_capacity(2),overflow:0};for i in 0..5{trace.push(Event{begin_ns:i,end_ns:i+1});}assert_eq!(trace.events.len(),2);assert_eq!(trace.overflow,3);}
}
