
/home/ubuntu/src/zopro-perf-work/simd-booth176/sdk-OFF:     file format elf64-x86-64


Disassembly of section .text:

00000000003c9c00 <<zopro_core::msm_affine::g2_borrowed::Window>::feed>:
  3c9c00:	push   %rbp
  3c9c01:	push   %r15
  3c9c03:	push   %r14
  3c9c05:	push   %r13
  3c9c07:	push   %r12
  3c9c09:	push   %rbx
  3c9c0a:	sub    $0x208,%rsp
  3c9c11:	cmp    %rdx,%r8
  3c9c14:	mov    %rsi,0xf0(%rsp)
  3c9c1c:	mov    %rdi,%rbx
  3c9c1f:	cmovb  %r8,%rdx
  3c9c23:	test   %rdx,%rdx
  3c9c26:	je     3ca96e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xd6e>
  3c9c2c:	mov    0x250(%rsp),%rdi
  3c9c34:	mov    0x248(%rsp),%rsi
  3c9c3c:	mov    0x240(%rsp),%r11
  3c9c44:	movzbl %r9b,%eax
  3c9c48:	mov    %rcx,%r8
  3c9c4b:	vpxor  %xmm9,%xmm9,%xmm9
  3c9c50:	mov    %rdx,0x30(%rsp)
  3c9c55:	shl    $0x4,%eax
  3c9c58:	add    %rax,%r8
  3c9c5b:	mov    %r8,0xf8(%rsp)
  3c9c63:	lea    -0x2(%rdi),%rax
  3c9c67:	mov    %rax,0xd0(%rsp)
  3c9c6f:	mov    %rsi,%rax
  3c9c72:	imul   %r11,%rax
  3c9c76:	lea    -0x1(%rax),%rdi
  3c9c7a:	mov    %rdi,%rcx
  3c9c7d:	shr    $0x6,%rcx
  3c9c81:	mov    %rdi,0xe8(%rsp)
  3c9c89:	mov    %rcx,0xb0(%rsp)
  3c9c91:	mov    %edi,%ecx
  3c9c93:	and    $0x3f,%ecx
  3c9c96:	mov    %rcx,0xa8(%rsp)
  3c9c9e:	lea    -0x40(%rsi,%rcx,1),%rcx
  3c9ca3:	cmp    $0xffffffffffffffbf,%rcx
  3c9ca7:	setb   %cl
  3c9caa:	cmp    $0xc0,%rdi
  3c9cb1:	setb   %dil
  3c9cb5:	xor    %r13d,%r13d
  3c9cb8:	and    %cl,%dil
  3c9cbb:	mov    $0x1,%ecx
  3c9cc0:	sub    %eax,%ecx
  3c9cc2:	mov    %dil,0x17(%rsp)
  3c9cc7:	lea    0x1(%rsi),%eax
  3c9cca:	mov    $0xffffffffffffffff,%rdi
  3c9cd1:	shlx   %rax,%rdi,%rax
  3c9cd6:	and    $0x3f,%ecx
  3c9cd9:	not    %rax
  3c9cdc:	mov    %rcx,0xa0(%rsp)
  3c9ce4:	mov    %rax,0xe0(%rsp)
  3c9cec:	mov    %esi,%eax
  3c9cee:	and    $0x3f,%eax
  3c9cf1:	dec    %esi
  3c9cf3:	mov    %rax,0xc0(%rsp)
  3c9cfb:	shlx   %rax,%rdi,%rax
  3c9d00:	and    $0x3f,%esi
  3c9d03:	mov    %rax,0xd8(%rsp)
  3c9d0b:	not    %rax
  3c9d0e:	mov    %rsi,0xc8(%rsp)
  3c9d16:	mov    %rax,0xb8(%rsp)
  3c9d1e:	jmp    3c9d3e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x13e>
  3c9d20:	mov    0x30(%rsp),%rdx
  3c9d25:	mov    0x240(%rsp),%r11
  3c9d2d:	vpxor  %xmm9,%xmm9,%xmm9
  3c9d32:	inc    %r13
  3c9d35:	cmp    %rdx,%r13
  3c9d38:	je     3ca96e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xd6e>
  3c9d3e:	mov    0xf8(%rsp),%rsi
  3c9d46:	mov    %r13,%rcx
  3c9d49:	shl    $0x5,%rcx
  3c9d4d:	lea    0x110(%rsp),%rdi
  3c9d55:	mov    (%rsi,%rcx,1),%rax
  3c9d59:	mov    0x8(%rsi,%rcx,1),%rcx
  3c9d5e:	mov    $0x3f,%sil
  3c9d61:	bzhi   %rsi,%rcx,%rsi
  3c9d66:	mov    %rax,0x100(%rsp)
  3c9d6e:	mov    %rsi,0x108(%rsp)
  3c9d76:	vmovdqu %xmm9,(%rdi)
  3c9d7a:	test   %r11,%r11
  3c9d7d:	je     3c9dd0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x1d0>
  3c9d7f:	cmpq   $0xff,0xe8(%rsp)
  3c9d8b:	ja     3c9e00 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x200>
  3c9d8d:	mov    0xb0(%rsp),%rax
  3c9d95:	mov    0xa8(%rsp),%rsi
  3c9d9d:	cmpb   $0x0,0x17(%rsp)
  3c9da2:	shrx   %rsi,0x100(%rsp,%rax,8),%rsi
  3c9dac:	je     3c9e02 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x202>
  3c9dae:	mov    0xa0(%rsp),%rdi
  3c9db6:	shlx   %rdi,0x108(%rsp,%rax,8),%rax
  3c9dc0:	or     %rax,%rsi
  3c9dc3:	jmp    3c9e02 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x202>
  3c9dc5:	data16 cs nopw 0x0(%rax,%rax,1)
  3c9dd0:	and    0xb8(%rsp),%rax
  3c9dd8:	mov    0xc8(%rsp),%rsi
  3c9de0:	mov    0xc0(%rsp),%rdi
  3c9de8:	shrx   %rsi,%rax,%rsi
  3c9ded:	shlx   %rdi,%rsi,%rsi
  3c9df2:	jmp    3c9e19 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x219>
  3c9df4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  3c9e00:	xor    %esi,%esi
  3c9e02:	and    0xe0(%rsp),%rsi
  3c9e0a:	lea    0x1(%rsi),%rax
  3c9e0e:	and    0xd8(%rsp),%rsi
  3c9e16:	shr    $1,%rax
  3c9e19:	sub    %rsi,%rax
  3c9e1c:	mov    %eax,%esi
  3c9e1e:	neg    %esi
  3c9e20:	test   %rcx,%rcx
  3c9e23:	cmovns %eax,%esi
  3c9e26:	test   %si,%si
  3c9e29:	je     3c9d32 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x132>
  3c9e2f:	mov    %r13,%r12
  3c9e32:	shl    $0x7,%r12
  3c9e36:	add    0xf0(%rsp),%r12
  3c9e3e:	vmovdqu (%r12),%ymm0
  3c9e44:	vptest %ymm0,%ymm0
  3c9e49:	jne    3c9e80 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x280>
  3c9e4b:	vmovdqu 0x20(%r12),%ymm0
  3c9e52:	vptest %ymm0,%ymm0
  3c9e57:	jne    3c9e80 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x280>
  3c9e59:	vmovdqu 0x40(%r12),%ymm0
  3c9e60:	vptest %ymm0,%ymm0
  3c9e65:	jne    3c9e80 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x280>
  3c9e67:	vmovdqu 0x60(%r12),%ymm0
  3c9e6e:	vptest %ymm0,%ymm0
  3c9e73:	je     3c9d32 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x132>
  3c9e79:	nopl   0x0(%rax)
  3c9e80:	xor    %ecx,%ecx
  3c9e82:	test   %si,%si
  3c9e85:	mov    %eax,%edi
  3c9e87:	sets   %sil
  3c9e8b:	neg    %di
  3c9e8e:	cmovs  %ax,%di
  3c9e92:	mov    0x70(%rbx),%rax
  3c9e96:	movzwl %di,%r10d
  3c9e9a:	dec    %r10
  3c9e9d:	mov    %r10,%rdi
  3c9ea0:	shr    $0x6,%rdi
  3c9ea4:	cmp    %rax,%rdi
  3c9ea7:	jae    3ca993 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xd93>
  3c9ead:	mov    0x68(%rbx),%r8
  3c9eb1:	mov    %sil,%cl
  3c9eb4:	mov    %r10d,%ebp
  3c9eb7:	shl    $0x1f,%ecx
  3c9eba:	or     %ecx,%ebp
  3c9ebc:	mov    (%r8,%rdi,8),%rcx
  3c9ec0:	bt     %r10,%rcx
  3c9ec4:	jae    3c9f30 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x330>
  3c9ec6:	mov    0xa0(%rbx),%r15
  3c9ecd:	cmp    0x90(%rbx),%r15
  3c9ed4:	je     3ca57f <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x97f>
  3c9eda:	mov    0x98(%rbx),%rax
  3c9ee1:	mov    %r15,%rcx
  3c9ee4:	shl    $0x4,%rcx
  3c9ee8:	mov    %ebp,(%rax,%rcx,1)
  3c9eeb:	mov    %r12,0x8(%rax,%rcx,1)
  3c9ef0:	lea    0x1(%r15),%rcx
  3c9ef4:	mov    %rcx,0xa0(%rbx)
  3c9efb:	cmp    0xd0(%rsp),%r15
  3c9f03:	jne    3c9d32 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x132>
  3c9f09:	mov    %rbx,%rdi
  3c9f0c:	vzeroupper
  3c9f0f:	call   3cbed0 <<zopro_core::msm_affine::g2_borrowed::Window>::flush_queue>
  3c9f14:	mov    0x240(%rsp),%r11
  3c9f1c:	mov    0x30(%rsp),%rdx
  3c9f21:	jmp    3c9d2d <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x12d>
  3c9f26:	cs nopw 0x0(%rax,%rax,1)
  3c9f30:	mov    0x10(%rbx),%rcx
  3c9f34:	mov    %r10d,%esi
  3c9f37:	and    $0x7fffffff,%esi
  3c9f3d:	cmp    %rsi,%rcx
  3c9f40:	jbe    3ca9ba <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xdba>
  3c9f46:	mov    0x8(%rbx),%rdi
  3c9f4a:	mov    %rsi,%r9
  3c9f4d:	shl    $0x7,%r9
  3c9f51:	vmovdqu (%rdi,%r9,1),%ymm0
  3c9f57:	lea    (%rdi,%r9,1),%rcx
  3c9f5b:	vptest %ymm0,%ymm0
  3c9f60:	jne    3c9f90 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x390>
  3c9f62:	vmovdqu 0x20(%rcx),%ymm0
  3c9f67:	vptest %ymm0,%ymm0
  3c9f6c:	jne    3c9f90 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x390>
  3c9f6e:	vmovdqu 0x40(%rcx),%ymm0
  3c9f73:	vptest %ymm0,%ymm0
  3c9f78:	jne    3c9f90 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x390>
  3c9f7a:	vmovdqu 0x60(%rcx),%ymm0
  3c9f7f:	vptest %ymm0,%ymm0
  3c9f84:	je     3ca795 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb95>
  3c9f8a:	nopw   0x0(%rax,%rax,1)
  3c9f90:	vmovdqu (%rcx),%ymm0
  3c9f94:	vpxor  (%r12),%ymm0,%ymm0
  3c9f9a:	vptest %ymm0,%ymm0
  3c9f9f:	jne    3c9fb8 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x3b8>
  3c9fa1:	vmovdqu 0x20(%rcx),%ymm0
  3c9fa6:	vpxor  0x20(%r12),%ymm0,%ymm0
  3c9fad:	vptest %ymm0,%ymm0
  3c9fb2:	je     3ca53e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x93e>
  3c9fb8:	shr    $0x6,%esi
  3c9fbb:	cmp    %rax,%rsi
  3c9fbe:	jae    3ca9cf <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xdcf>
  3c9fc4:	mov    $0x1,%eax
  3c9fc9:	shlx   %r10,%rax,%rax
  3c9fce:	or     %rax,(%r8,%rsi,8)
  3c9fd2:	mov    0x88(%rbx),%r15
  3c9fd9:	cmp    0x78(%rbx),%r15
  3c9fdd:	je     3ca772 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb72>
  3c9fe3:	mov    0x80(%rbx),%rax
  3c9fea:	mov    %r15,%rcx
  3c9fed:	shl    $0x4,%rcx
  3c9ff1:	inc    %r15
  3c9ff4:	mov    %ebp,(%rax,%rcx,1)
  3c9ff7:	mov    %r12,0x8(%rax,%rcx,1)
  3c9ffc:	mov    %r15,0x88(%rbx)
  3ca003:	mov    0x250(%rsp),%rax
  3ca00b:	cmp    %rax,0x88(%rbx)
  3ca012:	jne    3c9d32 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x132>
  3ca018:	mov    %rbx,%rdi
  3ca01b:	vzeroupper
  3ca01e:	call   3cba60 <<zopro_core::msm_affine::g2_borrowed::Window>::execute>
  3ca023:	mov    0xa0(%rbx),%rdx
  3ca02a:	mov    $0x1,%r11d
  3ca030:	test   %rdx,%rdx
  3ca033:	jne    3ca08a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x48a>
  3ca035:	jmp    3c9d20 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x120>
  3ca03a:	nopw   0x0(%rax,%rax,1)
  3ca040:	shlx   %rsi,%r11,%rax
  3ca045:	or     %rax,(%rcx,%rdi,8)
  3ca049:	mov    0x88(%rbx),%r15
  3ca050:	cmp    0x78(%rbx),%r15
  3ca054:	je     3ca364 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x764>
  3ca05a:	mov    0x80(%rbx),%rax
  3ca061:	mov    %r15,%rcx
  3ca064:	shl    $0x4,%rcx
  3ca068:	inc    %r15
  3ca06b:	mov    %ebp,(%rax,%rcx,1)
  3ca06e:	mov    %r12,0x8(%rax,%rcx,1)
  3ca073:	mov    %r15,0x88(%rbx)
  3ca07a:	mov    0xa0(%rbx),%rdx
  3ca081:	test   %rdx,%rdx
  3ca084:	je     3c9d20 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x120>
  3ca08a:	mov    0x98(%rbx),%r8
  3ca091:	dec    %rdx
  3ca094:	mov    0x70(%rbx),%rax
  3ca098:	mov    %rdx,%r9
  3ca09b:	shl    $0x4,%r9
  3ca09f:	mov    (%r8,%r9,1),%ebp
  3ca0a3:	mov    %ebp,%esi
  3ca0a5:	and    $0x7fffffff,%esi
  3ca0ab:	mov    %esi,%edi
  3ca0ad:	shr    $0x6,%edi
  3ca0b0:	cmp    %rax,%rdi
  3ca0b3:	jae    3ca993 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xd93>
  3ca0b9:	mov    0x68(%rbx),%rcx
  3ca0bd:	mov    (%rcx,%rdi,8),%rax
  3ca0c1:	bt     %rsi,%rax
  3ca0c5:	jb     3c9d20 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x120>
  3ca0cb:	mov    0x8(%r8,%r9,1),%r12
  3ca0d0:	mov    %rdx,0xa0(%rbx)
  3ca0d7:	mov    0x10(%rbx),%rax
  3ca0db:	cmp    %rsi,%rax
  3ca0de:	jbe    3ca9a5 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xda5>
  3ca0e4:	mov    0x8(%rbx),%rdx
  3ca0e8:	mov    %rsi,%r8
  3ca0eb:	shl    $0x7,%r8
  3ca0ef:	vmovdqu (%rdx,%r8,1),%ymm0
  3ca0f5:	lea    (%rdx,%r8,1),%rax
  3ca0f9:	vptest %ymm0,%ymm0
  3ca0fe:	jne    3ca130 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x530>
  3ca100:	vmovdqu 0x20(%rax),%ymm0
  3ca105:	vptest %ymm0,%ymm0
  3ca10a:	jne    3ca130 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x530>
  3ca10c:	vmovdqu 0x40(%rax),%ymm0
  3ca111:	vptest %ymm0,%ymm0
  3ca116:	jne    3ca130 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x530>
  3ca118:	vmovdqu 0x60(%rax),%ymm0
  3ca11d:	vptest %ymm0,%ymm0
  3ca122:	je     3ca37b <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x77b>
  3ca128:	nopl   0x0(%rax,%rax,1)
  3ca130:	vmovdqu (%rax),%ymm0
  3ca134:	vpxor  (%r12),%ymm0,%ymm0
  3ca13a:	vptest %ymm0,%ymm0
  3ca13f:	jne    3ca040 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x440>
  3ca145:	vmovdqu 0x20(%rax),%ymm0
  3ca14a:	vpxor  0x20(%r12),%ymm0,%ymm0
  3ca151:	vptest %ymm0,%ymm0
  3ca156:	jne    3ca040 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x440>
  3ca15c:	test   %ebp,%ebp
  3ca15e:	js     3ca19d <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x59d>
  3ca160:	vmovups (%r12),%zmm0
  3ca167:	vmovdqu64 0x40(%r12),%zmm1
  3ca16f:	vmovdqu64 %zmm1,0x140(%rsp)
  3ca177:	vmovups %zmm0,0x100(%rsp)
  3ca17f:	vmovdqu 0x40(%rax),%ymm0
  3ca184:	vpxor  0x140(%rsp),%ymm0,%ymm0
  3ca18d:	vptest %ymm0,%ymm0
  3ca192:	jne    3ca34e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x74e>
  3ca198:	jmp    3ca339 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x739>
  3ca19d:	vmovups 0x40(%r12),%ymm0
  3ca1a4:	vmovdqu -0x39c56c(%rip),%ymm2        # 2dc40 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3ca1ac:	movq   $0x0,0x20(%rsp)
  3ca1b5:	movq   $0x0,(%rsp)
  3ca1bd:	movq   $0x0,0x8(%rsp)
  3ca1c6:	movq   $0x0,0x18(%rsp)
  3ca1cf:	mov    %r13,0x28(%rsp)
  3ca1d4:	lea    0x80(%rsp),%rcx
  3ca1dc:	lea    0x40(%rsp),%rdx
  3ca1e1:	mov    0x20(%rsp),%rdi
  3ca1e6:	mov    (%rsp),%r14
  3ca1ea:	mov    0x8(%rsp),%r8
  3ca1ef:	mov    0x18(%rsp),%r13
  3ca1f4:	vmovups %ymm0,0x80(%rsp)
  3ca1fd:	vmovdqu %ymm2,0x40(%rsp)
  3ca203:	sub    (%rcx),%rdi
  3ca206:	sbb    0x8(%rcx),%r14
  3ca20a:	sbb    0x10(%rcx),%r8
  3ca20e:	sbb    0x18(%rcx),%r13
  3ca212:	sbb    %r15,%r15
  3ca215:	mov    (%rdx),%r9
  3ca218:	mov    0x8(%rdx),%r10
  3ca21c:	mov    0x10(%rdx),%r11
  3ca220:	mov    0x18(%rdx),%rbp
  3ca224:	and    %r15,%r9
  3ca227:	and    %r15,%r10
  3ca22a:	and    %r15,%r11
  3ca22d:	and    %r15,%rbp
  3ca230:	add    %r9,%rdi
  3ca233:	adc    %r10,%r14
  3ca236:	adc    %r11,%r8
  3ca239:	adc    %rbp,%r13
  3ca23c:	mov    %r13,0x18(%rsp)
  3ca241:	mov    %r8,0x8(%rsp)
  3ca246:	mov    %r14,(%rsp)
  3ca24a:	mov    %rdi,0x20(%rsp)
  3ca24f:	xor    %r13d,%r13d
  3ca252:	xor    %r10d,%r10d
  3ca255:	xor    %r11d,%r11d
  3ca258:	xor    %r15d,%r15d
  3ca25b:	lea    0x80(%rsp),%r8
  3ca263:	lea    0x40(%rsp),%r9
  3ca268:	vmovdqu 0x60(%r12),%ymm1
  3ca26f:	vmovdqu %ymm2,0x40(%rsp)
  3ca275:	vmovdqu %ymm1,0x80(%rsp)
  3ca27e:	sub    (%r8),%r10
  3ca281:	sbb    0x8(%r8),%r11
  3ca285:	sbb    0x10(%r8),%r15
  3ca289:	sbb    0x18(%r8),%r13
  3ca28d:	sbb    %rdi,%rdi
  3ca290:	mov    (%r9),%rbp
  3ca293:	mov    0x8(%r9),%r14
  3ca297:	mov    0x10(%r9),%rcx
  3ca29b:	mov    0x18(%r9),%rdx
  3ca29f:	and    %rdi,%rbp
  3ca2a2:	and    %rdi,%r14
  3ca2a5:	and    %rdi,%rcx
  3ca2a8:	and    %rdi,%rdx
  3ca2ab:	add    %rbp,%r10
  3ca2ae:	adc    %r14,%r11
  3ca2b1:	adc    %rcx,%r15
  3ca2b4:	adc    %rdx,%r13
  3ca2b7:	vmovups (%r12),%zmm0
  3ca2be:	mov    0x20(%rsp),%rcx
  3ca2c3:	mov    (%rsp),%rdx
  3ca2c7:	mov    0x8(%rsp),%rdi
  3ca2cc:	vmovups %zmm0,0x100(%rsp)
  3ca2d4:	mov    %rcx,0x140(%rsp)
  3ca2dc:	mov    %rdx,0x148(%rsp)
  3ca2e4:	mov    0x18(%rsp),%rdx
  3ca2e9:	mov    %rdi,0x150(%rsp)
  3ca2f1:	mov    %rdx,0x158(%rsp)
  3ca2f9:	mov    %r10,0x160(%rsp)
  3ca301:	mov    %r11,0x168(%rsp)
  3ca309:	mov    %r15,0x170(%rsp)
  3ca311:	mov    %r13,0x178(%rsp)
  3ca319:	mov    0x28(%rsp),%r13
  3ca31e:	mov    $0x1,%r11d
  3ca324:	vmovdqu 0x40(%rax),%ymm0
  3ca329:	vpxor  0x140(%rsp),%ymm0,%ymm0
  3ca332:	vptest %ymm0,%ymm0
  3ca337:	jne    3ca34e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x74e>
  3ca339:	vmovdqu 0x60(%rax),%ymm0
  3ca33e:	vpxor  0x160(%rsp),%ymm0,%ymm0
  3ca347:	vptest %ymm0,%ymm0
  3ca34c:	je     3ca39b <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x79b>
  3ca34e:	vpxor  %xmm0,%xmm0,%xmm0
  3ca352:	vmovdqu64 %zmm0,0x40(%rax)
  3ca359:	vmovdqu64 %zmm0,(%rax)
  3ca35f:	jmp    3ca07a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x47a>
  3ca364:	lea    0x78(%rbx),%rdi
  3ca368:	vzeroupper
  3ca36b:	call   213cf0 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3ca370:	mov    $0x1,%r11d
  3ca376:	jmp    3ca05a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x45a>
  3ca37b:	test   %ebp,%ebp
  3ca37d:	js     3ca3b9 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x7b9>
  3ca37f:	vmovups (%r12),%zmm0
  3ca386:	vmovups %zmm0,0x40(%rsp)
  3ca38e:	vmovdqu64 0x40(%r12),%zmm0
  3ca396:	jmp    3ca524 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x924>
  3ca39b:	lea    0x100(%rsp),%rdx
  3ca3a3:	mov    %rbx,%rdi
  3ca3a6:	vzeroupper
  3ca3a9:	call   3cc0f0 <<zopro_core::msm_affine::g2_borrowed::Window>::projective>
  3ca3ae:	mov    $0x1,%r11d
  3ca3b4:	jmp    3ca07a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x47a>
  3ca3b9:	lea    0x40(%r12),%rcx
  3ca3be:	vmovdqu -0x39c786(%rip),%ymm10        # 2dc40 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3ca3c6:	xor    %r14d,%r14d
  3ca3c9:	xor    %edx,%edx
  3ca3cb:	xor    %esi,%esi
  3ca3cd:	xor    %edi,%edi
  3ca3cf:	lea    0x40(%rsp),%r15
  3ca3d4:	vmovups (%rcx),%ymm0
  3ca3d8:	lea    0x80(%rsp),%rcx
  3ca3e0:	vmovdqu %ymm10,0x40(%rsp)
  3ca3e6:	vmovups %ymm0,0x80(%rsp)
  3ca3ef:	sub    (%rcx),%r14
  3ca3f2:	sbb    0x8(%rcx),%rdx
  3ca3f6:	sbb    0x10(%rcx),%rsi
  3ca3fa:	sbb    0x18(%rcx),%rdi
  3ca3fe:	sbb    %rbp,%rbp
  3ca401:	mov    (%r15),%r8
  3ca404:	mov    0x8(%r15),%r9
  3ca408:	mov    0x10(%r15),%r10
  3ca40c:	mov    0x18(%r15),%r11
  3ca410:	and    %rbp,%r8
  3ca413:	and    %rbp,%r9
  3ca416:	and    %rbp,%r10
  3ca419:	and    %rbp,%r11
  3ca41c:	add    %r8,%r14
  3ca41f:	adc    %r9,%rdx
  3ca422:	adc    %r10,%rsi
  3ca425:	adc    %r11,%rdi
  3ca428:	mov    %rsi,0x28(%rsp)
  3ca42d:	mov    %rdx,0x18(%rsp)
  3ca432:	movq   $0x0,0x8(%rsp)
  3ca43b:	mov    %rdi,0x38(%rsp)
  3ca440:	movq   $0x0,(%rsp)
  3ca448:	mov    %r14,0x20(%rsp)
  3ca44d:	xor    %esi,%esi
  3ca44f:	xor    %edx,%edx
  3ca451:	lea    0x40(%rsp),%r10
  3ca456:	lea    0x80(%rsp),%r8
  3ca45e:	vmovups 0x60(%r12),%ymm1
  3ca465:	vmovdqu %ymm10,0x40(%rsp)
  3ca46b:	mov    0x8(%rsp),%r11
  3ca470:	mov    (%rsp),%rdi
  3ca474:	vmovups %ymm1,0x80(%rsp)
  3ca47d:	sub    (%r8),%rsi
  3ca480:	sbb    0x8(%r8),%rdx
  3ca484:	sbb    0x10(%r8),%rdi
  3ca488:	sbb    0x18(%r8),%r11
  3ca48c:	sbb    %r9,%r9
  3ca48f:	mov    (%r10),%rbp
  3ca492:	mov    0x8(%r10),%r14
  3ca496:	mov    0x10(%r10),%r15
  3ca49a:	mov    0x18(%r10),%rcx
  3ca49e:	and    %r9,%rbp
  3ca4a1:	and    %r9,%r14
  3ca4a4:	and    %r9,%r15
  3ca4a7:	and    %r9,%rcx
  3ca4aa:	add    %rbp,%rsi
  3ca4ad:	adc    %r14,%rdx
  3ca4b0:	adc    %r15,%rdi
  3ca4b3:	adc    %rcx,%r11
  3ca4b6:	mov    %r11,0x8(%rsp)
  3ca4bb:	mov    %rdi,(%rsp)
  3ca4bf:	vmovq  %rdx,%xmm7
  3ca4c4:	vmovq  %rsi,%xmm8
  3ca4c9:	mov    $0x1,%r11d
  3ca4cf:	vmovq  0x38(%rsp),%xmm1
  3ca4d5:	vmovq  0x28(%rsp),%xmm2
  3ca4db:	vmovq  0x18(%rsp),%xmm3
  3ca4e1:	vmovq  0x20(%rsp),%xmm4
  3ca4e7:	vmovups (%r12),%zmm0
  3ca4ee:	vmovq  0x8(%rsp),%xmm5
  3ca4f4:	vmovq  (%rsp),%xmm6
  3ca4f9:	vpunpcklqdq %xmm1,%xmm2,%xmm9
  3ca4fd:	vpunpcklqdq %xmm3,%xmm4,%xmm1
  3ca501:	vmovups %zmm0,0x40(%rsp)
  3ca509:	vpunpcklqdq %xmm7,%xmm8,%xmm2
  3ca50d:	vinserti128 $0x1,%xmm9,%ymm1,%ymm0
  3ca513:	vpunpcklqdq %xmm5,%xmm6,%xmm1
  3ca517:	vinserti128 $0x1,%xmm1,%ymm2,%ymm1
  3ca51d:	vinserti64x4 $0x1,%ymm1,%zmm0,%zmm0
  3ca524:	vmovdqu64 0x40(%rsp),%zmm1
  3ca52c:	vmovdqu64 %zmm1,(%rax)
  3ca532:	vmovdqu64 %zmm0,0x40(%rax)
  3ca539:	jmp    3ca07a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x47a>
  3ca53e:	test   %ebp,%ebp
  3ca540:	js     3ca5a5 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x9a5>
  3ca542:	vmovups (%r12),%zmm0
  3ca549:	vmovdqu64 0x40(%r12),%zmm1
  3ca551:	vmovdqu64 %zmm1,0x1c0(%rsp)
  3ca559:	vmovups %zmm0,0x180(%rsp)
  3ca561:	vmovdqu 0x40(%rcx),%ymm0
  3ca566:	vpxor  0x1c0(%rsp),%ymm0,%ymm0
  3ca56f:	vptest %ymm0,%ymm0
  3ca574:	jne    3ca75c <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb5c>
  3ca57a:	jmp    3ca747 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb47>
  3ca57f:	lea    0x90(%rbx),%rdi
  3ca586:	vzeroupper
  3ca589:	call   213cf0 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3ca58e:	mov    0x240(%rsp),%r11
  3ca596:	mov    0x30(%rsp),%rdx
  3ca59b:	vpxor  %xmm9,%xmm9,%xmm9
  3ca5a0:	jmp    3c9eda <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x2da>
  3ca5a5:	vmovups 0x40(%r12),%ymm0
  3ca5ac:	vmovdqu -0x39c974(%rip),%ymm2        # 2dc40 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3ca5b4:	movq   $0x0,0x18(%rsp)
  3ca5bd:	movq   $0x0,0x20(%rsp)
  3ca5c6:	movq   $0x0,(%rsp)
  3ca5ce:	movq   $0x0,0x8(%rsp)
  3ca5d7:	mov    %rcx,0x28(%rsp)
  3ca5dc:	lea    0x40(%rsp),%rdx
  3ca5e1:	lea    0x100(%rsp),%rcx
  3ca5e9:	mov    0x8(%rsp),%rax
  3ca5ee:	mov    0x18(%rsp),%rdi
  3ca5f3:	mov    0x20(%rsp),%r8
  3ca5f8:	mov    (%rsp),%r14
  3ca5fc:	vmovups %ymm0,0x40(%rsp)
  3ca602:	vmovdqu %ymm2,0x100(%rsp)
  3ca60b:	sub    (%rdx),%rdi
  3ca60e:	sbb    0x8(%rdx),%r8
  3ca612:	sbb    0x10(%rdx),%r14
  3ca616:	sbb    0x18(%rdx),%rax
  3ca61a:	sbb    %r15,%r15
  3ca61d:	mov    (%rcx),%r9
  3ca620:	mov    0x8(%rcx),%r10
  3ca624:	mov    0x10(%rcx),%r11
  3ca628:	mov    0x18(%rcx),%rbp
  3ca62c:	and    %r15,%r9
  3ca62f:	and    %r15,%r10
  3ca632:	and    %r15,%r11
  3ca635:	and    %r15,%rbp
  3ca638:	add    %r9,%rdi
  3ca63b:	adc    %r10,%r8
  3ca63e:	adc    %r11,%r14
  3ca641:	adc    %rbp,%rax
  3ca644:	mov    %r14,(%rsp)
  3ca648:	mov    %r8,0x20(%rsp)
  3ca64d:	mov    %rdi,0x18(%rsp)
  3ca652:	mov    %rax,0x8(%rsp)
  3ca657:	vmovdqu %ymm2,0x100(%rsp)
  3ca660:	xor    %r14d,%r14d
  3ca663:	xor    %ecx,%ecx
  3ca665:	xor    %r11d,%r11d
  3ca668:	xor    %r15d,%r15d
  3ca66b:	lea    0x40(%rsp),%r9
  3ca670:	lea    0x100(%rsp),%r10
  3ca678:	vmovdqu 0x60(%r12),%ymm1
  3ca67f:	vmovdqu %ymm1,0x40(%rsp)
  3ca685:	sub    (%r9),%r14
  3ca688:	sbb    0x8(%r9),%rcx
  3ca68c:	sbb    0x10(%r9),%r11
  3ca690:	sbb    0x18(%r9),%r15
  3ca694:	sbb    %r8,%r8
  3ca697:	mov    (%r10),%rbp
  3ca69a:	mov    0x8(%r10),%rax
  3ca69e:	mov    0x10(%r10),%rdx
  3ca6a2:	mov    0x18(%r10),%rdi
  3ca6a6:	and    %r8,%rbp
  3ca6a9:	and    %r8,%rax
  3ca6ac:	and    %r8,%rdx
  3ca6af:	and    %r8,%rdi
  3ca6b2:	add    %rbp,%r14
  3ca6b5:	adc    %rax,%rcx
  3ca6b8:	adc    %rdx,%r11
  3ca6bb:	adc    %rdi,%r15
  3ca6be:	vmovups (%r12),%zmm0
  3ca6c5:	mov    0x18(%rsp),%rax
  3ca6ca:	mov    0x20(%rsp),%rdx
  3ca6cf:	mov    (%rsp),%rdi
  3ca6d3:	vmovups %zmm0,0x180(%rsp)
  3ca6db:	mov    %rax,0x1c0(%rsp)
  3ca6e3:	mov    %rdx,0x1c8(%rsp)
  3ca6eb:	mov    0x8(%rsp),%rdx
  3ca6f0:	mov    %rdi,0x1d0(%rsp)
  3ca6f8:	mov    %rdx,0x1d8(%rsp)
  3ca700:	mov    %r14,0x1e0(%rsp)
  3ca708:	mov    %rcx,0x1e8(%rsp)
  3ca710:	mov    %r11,0x1f0(%rsp)
  3ca718:	mov    0x28(%rsp),%rcx
  3ca71d:	mov    0x30(%rsp),%rdx
  3ca722:	mov    0x240(%rsp),%r11
  3ca72a:	mov    %r15,0x1f8(%rsp)
  3ca732:	vmovdqu 0x40(%rcx),%ymm0
  3ca737:	vpxor  0x1c0(%rsp),%ymm0,%ymm0
  3ca740:	vptest %ymm0,%ymm0
  3ca745:	jne    3ca75c <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb5c>
  3ca747:	vmovdqu 0x60(%rcx),%ymm0
  3ca74c:	vpxor  0x1e0(%rsp),%ymm0,%ymm0
  3ca755:	vptest %ymm0,%ymm0
  3ca75a:	je     3ca7b5 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xbb5>
  3ca75c:	vpxor  %xmm0,%xmm0,%xmm0
  3ca760:	vmovdqu64 %zmm0,0x40(%rcx)
  3ca767:	vmovdqu64 %zmm0,(%rcx)
  3ca76d:	jmp    3ca003 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x403>
  3ca772:	lea    0x78(%rbx),%rdi
  3ca776:	vzeroupper
  3ca779:	call   213cf0 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3ca77e:	mov    0x240(%rsp),%r11
  3ca786:	mov    0x30(%rsp),%rdx
  3ca78b:	vpxor  %xmm9,%xmm9,%xmm9
  3ca790:	jmp    3c9fe3 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x3e3>
  3ca795:	test   %ebp,%ebp
  3ca797:	js     3ca7df <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xbdf>
  3ca799:	vmovups (%r12),%zmm0
  3ca7a0:	vmovups %zmm0,0x100(%rsp)
  3ca7a8:	vmovdqu64 0x40(%r12),%zmm0
  3ca7b0:	jmp    3ca954 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xd54>
  3ca7b5:	lea    0x180(%rsp),%rdx
  3ca7bd:	mov    %rbx,%rdi
  3ca7c0:	vzeroupper
  3ca7c3:	call   3cc0f0 <<zopro_core::msm_affine::g2_borrowed::Window>::projective>
  3ca7c8:	mov    0x240(%rsp),%r11
  3ca7d0:	mov    0x30(%rsp),%rdx
  3ca7d5:	vpxor  %xmm9,%xmm9,%xmm9
  3ca7da:	jmp    3ca003 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x403>
  3ca7df:	lea    0x40(%r12),%rax
  3ca7e4:	vmovups -0x39cbac(%rip),%ymm11        # 2dc40 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3ca7ec:	xor    %edx,%edx
  3ca7ee:	xor    %esi,%esi
  3ca7f0:	xor    %r15d,%r15d
  3ca7f3:	xor    %edi,%edi
  3ca7f5:	lea    0x40(%rsp),%r14
  3ca7fa:	vmovups (%rax),%ymm0
  3ca7fe:	lea    0x100(%rsp),%rax
  3ca806:	vmovups %ymm11,0x100(%rsp)
  3ca80f:	vmovups %ymm0,0x40(%rsp)
  3ca815:	sub    (%r14),%rdx
  3ca818:	sbb    0x8(%r14),%rsi
  3ca81c:	sbb    0x10(%r14),%r15
  3ca820:	sbb    0x18(%r14),%rdi
  3ca824:	sbb    %rbp,%rbp
  3ca827:	mov    (%rax),%r8
  3ca82a:	mov    0x8(%rax),%r9
  3ca82e:	mov    0x10(%rax),%r10
  3ca832:	mov    0x18(%rax),%r11
  3ca836:	and    %rbp,%r8
  3ca839:	and    %rbp,%r9
  3ca83c:	and    %rbp,%r10
  3ca83f:	and    %rbp,%r11
  3ca842:	add    %r8,%rdx
  3ca845:	adc    %r9,%rsi
  3ca848:	adc    %r10,%r15
  3ca84b:	adc    %r11,%rdi
  3ca84e:	mov    %rsi,0x18(%rsp)
  3ca853:	mov    %rdx,0x20(%rsp)
  3ca858:	movq   $0x0,0x8(%rsp)
  3ca861:	mov    %rdi,0x38(%rsp)
  3ca866:	movq   $0x0,(%rsp)
  3ca86e:	mov    %r15,0x28(%rsp)
  3ca873:	vmovups %ymm11,0x100(%rsp)
  3ca87c:	xor    %esi,%esi
  3ca87e:	xor    %edx,%edx
  3ca880:	lea    0x100(%rsp),%r14
  3ca888:	lea    0x40(%rsp),%r10
  3ca88d:	vmovups 0x60(%r12),%ymm1
  3ca894:	mov    0x8(%rsp),%r11
  3ca899:	mov    (%rsp),%rdi
  3ca89d:	vmovups %ymm1,0x40(%rsp)
  3ca8a3:	sub    (%r10),%rsi
  3ca8a6:	sbb    0x8(%r10),%rdx
  3ca8aa:	sbb    0x10(%r10),%r11
  3ca8ae:	sbb    0x18(%r10),%rdi
  3ca8b2:	sbb    %r9,%r9
  3ca8b5:	mov    (%r14),%rbp
  3ca8b8:	mov    0x8(%r14),%r15
  3ca8bc:	mov    0x10(%r14),%r8
  3ca8c0:	mov    0x18(%r14),%rax
  3ca8c4:	and    %r9,%rbp
  3ca8c7:	and    %r9,%r15
  3ca8ca:	and    %r9,%r8
  3ca8cd:	and    %r9,%rax
  3ca8d0:	add    %rbp,%rsi
  3ca8d3:	adc    %r15,%rdx
  3ca8d6:	adc    %r8,%r11
  3ca8d9:	adc    %rax,%rdi
  3ca8dc:	mov    %r11,0x8(%rsp)
  3ca8e1:	mov    %rdi,(%rsp)
  3ca8e5:	mov    %rdx,%r8
  3ca8e8:	mov    0x240(%rsp),%r11
  3ca8f0:	vmovq  %r8,%xmm7
  3ca8f5:	vmovq  %rsi,%xmm8
  3ca8fa:	vmovq  0x38(%rsp),%xmm1
  3ca900:	vmovq  0x28(%rsp),%xmm2
  3ca906:	vmovq  0x18(%rsp),%xmm3
  3ca90c:	vmovq  0x20(%rsp),%xmm4
  3ca912:	vmovups (%r12),%zmm0
  3ca919:	vmovq  (%rsp),%xmm5
  3ca91e:	vmovq  0x8(%rsp),%xmm6
  3ca924:	mov    0x30(%rsp),%rdx
  3ca929:	vpunpcklqdq %xmm1,%xmm2,%xmm10
  3ca92d:	vpunpcklqdq %xmm3,%xmm4,%xmm1
  3ca931:	vmovups %zmm0,0x100(%rsp)
  3ca939:	vpunpcklqdq %xmm7,%xmm8,%xmm2
  3ca93d:	vinserti128 $0x1,%xmm10,%ymm1,%ymm0
  3ca943:	vpunpcklqdq %xmm5,%xmm6,%xmm1
  3ca947:	vinserti128 $0x1,%xmm1,%ymm2,%ymm1
  3ca94d:	vinserti64x4 $0x1,%ymm1,%zmm0,%zmm0
  3ca954:	vmovdqu64 0x100(%rsp),%zmm1
  3ca95c:	vmovdqu64 %zmm1,(%rcx)
  3ca962:	vmovdqu64 %zmm0,0x40(%rcx)
  3ca969:	jmp    3ca003 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x403>
  3ca96e:	mov    %rbx,%rdi
  3ca971:	vzeroupper
  3ca974:	call   3cba60 <<zopro_core::msm_affine::g2_borrowed::Window>::execute>
  3ca979:	mov    %rbx,%rdi
  3ca97c:	call   3cbed0 <<zopro_core::msm_affine::g2_borrowed::Window>::flush_queue>
  3ca981:	add    $0x208,%rsp
  3ca988:	pop    %rbx
  3ca989:	pop    %r12
  3ca98b:	pop    %r13
  3ca98d:	pop    %r14
  3ca98f:	pop    %r15
  3ca991:	pop    %rbp
  3ca992:	ret
  3ca993:	lea    0x12cc2e(%rip),%rdx        # 4f75c8 <__frame_dummy_init_array_entry+0x42a8>
  3ca99a:	mov    %rax,%rsi
  3ca99d:	vzeroupper
  3ca9a0:	call   10313b <core::panicking::panic_bounds_check>
  3ca9a5:	lea    0x12cc34(%rip),%rdx        # 4f75e0 <__frame_dummy_init_array_entry+0x42c0>
  3ca9ac:	mov    %rsi,%rdi
  3ca9af:	mov    %rax,%rsi
  3ca9b2:	vzeroupper
  3ca9b5:	call   10313b <core::panicking::panic_bounds_check>
  3ca9ba:	lea    0x12cc1f(%rip),%rdx        # 4f75e0 <__frame_dummy_init_array_entry+0x42c0>
  3ca9c1:	mov    %rsi,%rdi
  3ca9c4:	mov    %rcx,%rsi
  3ca9c7:	vzeroupper
  3ca9ca:	call   10313b <core::panicking::panic_bounds_check>
  3ca9cf:	lea    0x12cc22(%rip),%rdx        # 4f75f8 <__frame_dummy_init_array_entry+0x42d8>
  3ca9d6:	mov    %rsi,%rdi
  3ca9d9:	mov    %rax,%rsi
  3ca9dc:	vzeroupper
  3ca9df:	call   10313b <core::panicking::panic_bounds_check>
