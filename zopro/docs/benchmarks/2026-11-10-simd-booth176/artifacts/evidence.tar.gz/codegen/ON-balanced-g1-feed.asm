
/home/ubuntu/src/zopro-perf-work/simd-booth176/sdk-ON:     file format elf64-x86-64


Disassembly of section .text:

00000000003fb7d0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>>:
  3fb7d0:	push   %rbp
  3fb7d1:	push   %r15
  3fb7d3:	push   %r14
  3fb7d5:	push   %r13
  3fb7d7:	push   %r12
  3fb7d9:	push   %rbx
  3fb7da:	sub    $0x338,%rsp
  3fb7e1:	mov    0x370(%rsp),%rax
  3fb7e9:	mov    %r9,0x70(%rsp)
  3fb7ee:	mov    %r9,%r13
  3fb7f1:	lea    -0x1(%rax),%r9
  3fb7f5:	mov    %rax,0x78(%rsp)
  3fb7fa:	cmp    $0xf,%r9
  3fb7fe:	jae    3fc471 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xca1>
  3fb804:	movabs $0x3fffffffffffff8,%r11
  3fb80e:	mov    %rdx,%r10
  3fb811:	mov    %rdi,%r12
  3fb814:	shl    $0x6,%r10
  3fb818:	mov    %rsi,%r15
  3fb81b:	lea    0x70(%rsp),%rsi
  3fb820:	vpxor  %xmm0,%xmm0,%xmm0
  3fb824:	vmovdqu %xmm0,0x280(%rsp)
  3fb82d:	movq   $0x0,0x1c8(%rsp)
  3fb839:	movq   $0x0,0x1f0(%rsp)
  3fb845:	mov    %rcx,0x20(%rsp)
  3fb84a:	mov    %rcx,0x218(%rsp)
  3fb852:	and    %r8,%r11
  3fb855:	and    $0x7,%r8d
  3fb859:	add    %r15,%r10
  3fb85c:	mov    %r11,%r14
  3fb85f:	shl    $0x5,%r14
  3fb863:	mov    %r8d,%edi
  3fb866:	shl    $0x5,%edi
  3fb869:	mov    %r11,0x28(%rsp)
  3fb86e:	mov    %r11,0x220(%rsp)
  3fb876:	mov    %r10,0xb0(%rsp)
  3fb87e:	add    %rcx,%r14
  3fb881:	add    %r14,%rdi
  3fb884:	mov    %r14,0x228(%rsp)
  3fb88c:	mov    %r8,0x230(%rsp)
  3fb894:	movq   $0x8,0x238(%rsp)
  3fb8a0:	mov    %r13,0x240(%rsp)
  3fb8a8:	mov    %rax,0x248(%rsp)
  3fb8b0:	movb   $0x2,0x250(%rsp)
  3fb8b8:	mov    %r14,0x258(%rsp)
  3fb8c0:	mov    %rdi,0x260(%rsp)
  3fb8c8:	mov    %rsi,0x268(%rsp)
  3fb8d0:	mov    %r15,0x270(%rsp)
  3fb8d8:	mov    %rdi,0xa8(%rsp)
  3fb8e0:	mov    %r10,0x278(%rsp)
  3fb8e8:	test   %rdx,%rdx
  3fb8eb:	je     3fc45c <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xc8c>
  3fb8f1:	mov    0x378(%rsp),%rcx
  3fb8f9:	mov    %r13,%r8
  3fb8fc:	vmovdqa64 -0x3cf486(%rip),%zmm3        # 2c480 <GCC_except_table3227+0x5410>
  3fb906:	vmovq  %rax,%xmm2
  3fb90b:	vmovq  %r9,%xmm1
  3fb910:	mov    %r13,0x50(%rsp)
  3fb915:	vmovdqa %xmm2,0x80(%rsp)
  3fb91e:	vmovdqa %xmm1,0x170(%rsp)
  3fb927:	lea    -0x2(%rcx),%rdx
  3fb92b:	mov    %rdx,0xa0(%rsp)
  3fb933:	xor    %edx,%edx
  3fb935:	test   %r13,%r13
  3fb938:	setne  %dl
  3fb93b:	sub    %rdx,%r8
  3fb93e:	add    %rax,%rdx
  3fb941:	lea    -0x1(%rcx),%rax
  3fb945:	mov    %r8d,%esi
  3fb948:	and    $0x3f,%esi
  3fb94b:	mov    %r8,%r10
  3fb94e:	shr    $0x6,%r10
  3fb952:	mov    %r8,0x48(%rsp)
  3fb957:	mov    %rax,0xb8(%rsp)
  3fb95f:	lea    (%rdx,%rsi,1),%rdi
  3fb963:	mov    %r10,0x40(%rsp)
  3fb968:	inc    %r10
  3fb96b:	vpbroadcastq %rsi,%zmm0
  3fb971:	cmp    $0x41,%rdi
  3fb975:	mov    %rdi,0x98(%rsp)
  3fb97d:	mov    %r10,0x60(%rsp)
  3fb982:	vmovdqu64 %zmm0,0x2f0(%rsp)
  3fb98d:	setb   %dil
  3fb991:	cmp    $0xc0,%r8
  3fb998:	mov    $0x40,%r8d
  3fb99e:	setae  %r10b
  3fb9a2:	sub    %esi,%r8d
  3fb9a5:	xor    %ecx,%ecx
  3fb9a7:	vmovd  %r8d,%xmm0
  3fb9ac:	mov    $0xffffffffffffffff,%r8
  3fb9b3:	or     %dil,%r10b
  3fb9b6:	shlx   %rdx,%r8,%rdx
  3fb9bb:	vmovdqa %xmm0,0x100(%rsp)
  3fb9c4:	mov    %r10b,0xf(%rsp)
  3fb9c9:	not    %rdx
  3fb9cc:	vpbroadcastq %rdx,%zmm0
  3fb9d2:	vmovdqu64 %zmm0,0x290(%rsp)
  3fb9dd:	jmp    3fba17 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x247>
  3fb9df:	mov    0x50(%rsp),%r13
  3fb9e4:	mov    0x10(%rsp),%r14
  3fb9e9:	mov    0x18(%rsp),%r15
  3fb9ee:	movq   $0x0,0xa0(%r12)
  3fb9fa:	nopw   0x0(%rax,%rax,1)
  3fba00:	mov    0x68(%rsp),%rcx
  3fba05:	add    $0x40,%r15
  3fba09:	cmp    0xb0(%rsp),%r15
  3fba11:	je     3fc45c <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xc8c>
  3fba17:	cmp    $0x2,%rcx
  3fba1b:	jne    3fba90 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x2c0>
  3fba1d:	cmp    0xa8(%rsp),%r14
  3fba25:	je     3fc45c <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xc8c>
  3fba2b:	mov    0x70(%rsp),%rdx
  3fba30:	mov    0x78(%rsp),%rax
  3fba35:	test   %rdx,%rdx
  3fba38:	je     3fbb00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x330>
  3fba3e:	cmp    $0x100,%rdx
  3fba45:	ja     3fbb14 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x344>
  3fba4b:	lea    -0x1(%rdx),%rdi
  3fba4f:	mov    %rdi,%rsi
  3fba52:	shr    $0x6,%rsi
  3fba56:	and    $0x3f,%edi
  3fba59:	shrx   %rdi,(%r14,%rsi,8),%rcx
  3fba5f:	cmp    $0xc0,%rdx
  3fba66:	ja     3fbb16 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x346>
  3fba6c:	lea    -0x40(%rax,%rdi,1),%rdi
  3fba71:	cmp    $0xffffffffffffffbf,%rdi
  3fba75:	jae    3fbb16 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x346>
  3fba7b:	mov    $0x1,%dil
  3fba7e:	sub    %dl,%dil
  3fba81:	shlx   %rdi,0x8(%r14,%rsi,8),%rdx
  3fba88:	or     %rdx,%rcx
  3fba8b:	jmp    3fbb16 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x346>
  3fba90:	cmpq   $0x8,0x58(%rsp)
  3fba96:	setne  %al
  3fba99:	and    %cl,%al
  3fba9b:	test   %r13,%r13
  3fba9e:	je     3fbb51 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x381>
  3fbaa4:	cmpq   $0x41,0x98(%rsp)
  3fbaad:	jae    3fbbd5 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x405>
  3fbab3:	test   %al,%al
  3fbab5:	jne    3fbcaa <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x4da>
  3fbabb:	cmpq   $0x8,0x28(%rsp)
  3fbac1:	jb     3fba1d <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x24d>
  3fbac7:	cmpq   $0xff,0x48(%rsp)
  3fbad0:	mov    0x20(%rsp),%rcx
  3fbad5:	vpxor  %xmm0,%xmm0,%xmm0
  3fbad9:	ja     3fbaef <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x31f>
  3fbadb:	mov    0x40(%rsp),%rax
  3fbae0:	kxnorb %k0,%k0,%k1
  3fbae4:	lea    (%rcx,%rax,8),%rax
  3fbae8:	vpgatherqq (%rax,%zmm3,8),%zmm0{%k1}
  3fbaef:	vpsrlvq 0x2f0(%rsp),%zmm0,%zmm0
  3fbafa:	jmp    3fbc4d <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x47d>
  3fbaff:	nop
  3fbb00:	mov    %eax,%ecx
  3fbb02:	lea    -0x1(%rax),%edx
  3fbb05:	and    $0x3f,%cl
  3fbb08:	bzhi   %rcx,(%r14),%rcx
  3fbb0d:	shrx   %rdx,%rcx,%rdx
  3fbb12:	jmp    3fbb2d <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x35d>
  3fbb14:	xor    %ecx,%ecx
  3fbb16:	lea    0x1(%rax),%edx
  3fbb19:	and    $0x3f,%dl
  3fbb1c:	bzhi   %rdx,%rcx,%rdx
  3fbb21:	lea    0x1(%rdx),%rcx
  3fbb25:	shrx   %rax,%rdx,%rdx
  3fbb2a:	shr    $1,%rcx
  3fbb2d:	shlx   %rax,%rdx,%rax
  3fbb32:	add    $0x20,%r14
  3fbb36:	sub    %rax,%rcx
  3fbb39:	mov    $0x2,%eax
  3fbb3e:	mov    %rax,0x68(%rsp)
  3fbb43:	test   %cx,%cx
  3fbb46:	jne    3fbcd2 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x502>
  3fbb4c:	jmp    3fba00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x230>
  3fbb51:	test   %al,%al
  3fbb53:	jne    3fbcaa <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x4da>
  3fbb59:	cmpq   $0x8,0x28(%rsp)
  3fbb5f:	jb     3fba1d <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x24d>
  3fbb65:	mov    0x20(%rsp),%rcx
  3fbb6a:	mov    0x40(%rsp),%rax
  3fbb6f:	kxnorb %k0,%k0,%k1
  3fbb73:	vpxor  %xmm0,%xmm0,%xmm0
  3fbb77:	cmpb   $0x0,0xf(%rsp)
  3fbb7c:	lea    (%rcx,%rax,8),%rax
  3fbb80:	vpgatherqq (%rax,%zmm3,8),%zmm0{%k1}
  3fbb87:	jne    3fbbaf <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x3df>
  3fbb89:	mov    0x60(%rsp),%rax
  3fbb8e:	kxnorb %k0,%k0,%k1
  3fbb92:	vpxor  %xmm1,%xmm1,%xmm1
  3fbb96:	lea    (%rcx,%rax,8),%rax
  3fbb9a:	vpgatherqq (%rax,%zmm3,8),%zmm1{%k1}
  3fbba1:	vpsllq 0x100(%rsp),%zmm1,%zmm1
  3fbba9:	vporq  %zmm0,%zmm1,%zmm0
  3fbbaf:	vpandq 0x290(%rsp),%zmm0,%zmm0
  3fbbba:	vpsrlq 0x170(%rsp),%zmm0,%zmm1
  3fbbc2:	vpsllq 0x80(%rsp),%zmm1,%zmm1
  3fbbca:	vpsubq %zmm1,%zmm0,%zmm0
  3fbbd0:	jmp    3fbc87 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x4b7>
  3fbbd5:	test   %al,%al
  3fbbd7:	jne    3fbcaa <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x4da>
  3fbbdd:	cmpq   $0x8,0x28(%rsp)
  3fbbe3:	jb     3fba1d <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x24d>
  3fbbe9:	cmpq   $0xff,0x48(%rsp)
  3fbbf2:	mov    0x20(%rsp),%rcx
  3fbbf7:	vpxor  %xmm0,%xmm0,%xmm0
  3fbbfb:	ja     3fbc4d <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x47d>
  3fbbfd:	mov    0x40(%rsp),%rax
  3fbc02:	kxnorb %k0,%k0,%k1
  3fbc06:	cmpq   $0xbf,0x48(%rsp)
  3fbc0f:	lea    (%rcx,%rax,8),%rax
  3fbc13:	vpgatherqq (%rax,%zmm3,8),%zmm0{%k1}
  3fbc1a:	vpsrlvq 0x2f0(%rsp),%zmm0,%zmm0
  3fbc25:	ja     3fbc4d <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x47d>
  3fbc27:	mov    0x60(%rsp),%rax
  3fbc2c:	kxnorb %k0,%k0,%k1
  3fbc30:	vpxor  %xmm1,%xmm1,%xmm1
  3fbc34:	lea    (%rcx,%rax,8),%rax
  3fbc38:	vpgatherqq (%rax,%zmm3,8),%zmm1{%k1}
  3fbc3f:	vpsllq 0x100(%rsp),%zmm1,%zmm1
  3fbc47:	vporq  %zmm0,%zmm1,%zmm0
  3fbc4d:	vpandq 0x290(%rsp),%zmm0,%zmm0
  3fbc58:	vmovdqa 0x80(%rsp),%xmm2
  3fbc61:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
  3fbc68:	vpsubq %zmm1,%zmm0,%zmm1
  3fbc6e:	vpsrlq %xmm2,%zmm0,%zmm0
  3fbc74:	vpsrlq $0x1,%zmm1,%zmm1
  3fbc7b:	vpsllq %xmm2,%zmm0,%zmm0
  3fbc81:	vpsubq %zmm0,%zmm1,%zmm0
  3fbc87:	addq   $0xfffffffffffffff8,0x28(%rsp)
  3fbc8d:	add    $0x100,%rcx
  3fbc94:	vpmovqw %zmm0,0x1e0(%rsp)
  3fbc9c:	movq   $0x0,0x58(%rsp)
  3fbca5:	mov    %rcx,0x20(%rsp)
  3fbcaa:	mov    0x58(%rsp),%rax
  3fbcaf:	movzwl 0x1e0(%rsp,%rax,2),%ecx
  3fbcb7:	inc    %rax
  3fbcba:	mov    %rax,0x58(%rsp)
  3fbcbf:	mov    $0x1,%eax
  3fbcc4:	mov    %rax,0x68(%rsp)
  3fbcc9:	test   %cx,%cx
  3fbccc:	je     3fba00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x230>
  3fbcd2:	vmovdqu (%r15),%ymm0
  3fbcd7:	vptest %ymm0,%ymm0
  3fbcdc:	jne    3fbcef <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x51f>
  3fbcde:	vmovdqu 0x20(%r15),%ymm0
  3fbce4:	vptest %ymm0,%ymm0
  3fbce9:	je     3fba00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x230>
  3fbcef:	xor    %edx,%edx
  3fbcf1:	test   %cx,%cx
  3fbcf4:	mov    %ecx,%eax
  3fbcf6:	sets   %r8b
  3fbcfa:	neg    %ax
  3fbcfd:	cmovs  %cx,%ax
  3fbd01:	movzwl %ax,%esi
  3fbd04:	mov    0x70(%r12),%rax
  3fbd09:	dec    %rsi
  3fbd0c:	mov    %rsi,%rdi
  3fbd0f:	shr    $0x6,%rdi
  3fbd13:	cmp    %rax,%rdi
  3fbd16:	jae    3fc4bc <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xcec>
  3fbd1c:	mov    0x68(%r12),%rcx
  3fbd21:	mov    %r8b,%dl
  3fbd24:	mov    %esi,%ebx
  3fbd26:	shl    $0x1f,%edx
  3fbd29:	or     %edx,%ebx
  3fbd2b:	mov    (%rcx,%rdi,8),%rdx
  3fbd2f:	bt     %rsi,%rdx
  3fbd33:	jae    3fc0ae <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x8de>
  3fbd39:	mov    %r14,0x10(%rsp)
  3fbd3e:	mov    0xa0(%r12),%r14
  3fbd46:	cmp    0x90(%r12),%r14
  3fbd4e:	je     3fc32f <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xb5f>
  3fbd54:	mov    0x98(%r12),%rax
  3fbd5c:	mov    %r14,%rcx
  3fbd5f:	shl    $0x4,%rcx
  3fbd63:	mov    %ebx,(%rax,%rcx,1)
  3fbd66:	mov    %r15,0x8(%rax,%rcx,1)
  3fbd6b:	lea    0x1(%r14),%rax
  3fbd6f:	mov    %rax,0xa0(%r12)
  3fbd77:	cmp    0xa0(%rsp),%r14
  3fbd7f:	mov    0x10(%rsp),%r14
  3fbd84:	jne    3fba00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x230>
  3fbd8a:	mov    %r15,0x18(%rsp)
  3fbd8f:	test   %rax,%rax
  3fbd92:	je     3fb9df <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x20f>
  3fbd98:	mov    $0x8,%r13d
  3fbd9e:	xor    %r14d,%r14d
  3fbda1:	jmp    3fbe49 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x679>
  3fbda6:	cs nopw 0x0(%rax,%rax,1)
  3fbdb0:	lea    0xe0(%rsp),%rax
  3fbdb8:	vmovdqu 0xc0(%rsp),%ymm2
  3fbdc1:	vmovups -0x3ce129(%rip),%ymm1        # 2dca0 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0x80>
  3fbdc9:	vmovups (%rax),%ymm0
  3fbdcd:	lea    0x130(%rsp),%rax
  3fbdd5:	vmovups %ymm0,(%rax)
  3fbdd9:	vmovdqu %ymm2,0x110(%rsp)
  3fbde2:	vmovups %ymm1,0x20(%rax)
  3fbde7:	mov    0x28(%r12),%rbx
  3fbdec:	cmp    0x18(%r12),%rbx
  3fbdf1:	je     3fc076 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x8a6>
  3fbdf7:	vmovdqu64 0x110(%rsp),%zmm0
  3fbe02:	vmovdqu64 0x130(%rsp),%zmm1
  3fbe0d:	mov    0x20(%r12),%rax
  3fbe12:	lea    (%rbx,%rbx,2),%rcx
  3fbe16:	inc    %rbx
  3fbe19:	shl    $0x5,%rcx
  3fbe1d:	vmovdqu64 %zmm1,0x20(%rax,%rcx,1)
  3fbe28:	vmovdqu64 %zmm0,(%rax,%rcx,1)
  3fbe2f:	mov    %rbx,0x28(%r12)
  3fbe34:	inc    %r14
  3fbe37:	add    $0x10,%r13
  3fbe3b:	cmp    %r14,0xb8(%rsp)
  3fbe43:	je     3fb9df <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x20f>
  3fbe49:	mov    0xa0(%r12),%rsi
  3fbe51:	cmp    %rsi,%r14
  3fbe54:	jae    3fc489 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xcb9>
  3fbe5a:	mov    0x98(%r12),%rax
  3fbe62:	mov    -0x8(%rax,%r13,1),%ebx
  3fbe67:	mov    (%rax,%r13,1),%rax
  3fbe6b:	test   %ebx,%ebx
  3fbe6d:	js     3fbea0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x6d0>
  3fbe6f:	vmovups (%rax),%zmm0
  3fbe75:	vmovups %zmm0,0xc0(%rsp)
  3fbe7d:	mov    0x40(%r12),%rsi
  3fbe82:	and    $0x7fffffff,%ebx
  3fbe88:	cmp    %rbx,%rsi
  3fbe8b:	ja     3fbf52 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x782>
  3fbe91:	jmp    3fc49b <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xccb>
  3fbe96:	cs nopw 0x0(%rax,%rax,1)
  3fbea0:	vmovups (%rax),%ymm0
  3fbea4:	vmovdqu -0x3ce1ac(%rip),%ymm1        # 2dd00 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3fbeac:	xor    %ecx,%ecx
  3fbeae:	xor    %edx,%edx
  3fbeb0:	xor    %esi,%esi
  3fbeb2:	lea    0x110(%rsp),%rbp
  3fbeba:	lea    0x2d0(%rsp),%r15
  3fbec2:	vmovups %ymm0,0xc0(%rsp)
  3fbecb:	vmovups 0x20(%rax),%ymm0
  3fbed0:	vmovdqu %ymm1,0x110(%rsp)
  3fbed9:	xor    %eax,%eax
  3fbedb:	vmovups %ymm0,0x2d0(%rsp)
  3fbee4:	sub    (%r15),%rcx
  3fbee7:	sbb    0x8(%r15),%rdx
  3fbeeb:	sbb    0x10(%r15),%rsi
  3fbeef:	sbb    0x18(%r15),%rax
  3fbef3:	sbb    %r11,%r11
  3fbef6:	mov    0x0(%rbp),%rdi
  3fbefa:	mov    0x8(%rbp),%r8
  3fbefe:	mov    0x10(%rbp),%r9
  3fbf02:	mov    0x18(%rbp),%r10
  3fbf06:	and    %r11,%rdi
  3fbf09:	and    %r11,%r8
  3fbf0c:	and    %r11,%r9
  3fbf0f:	and    %r11,%r10
  3fbf12:	add    %rdi,%rcx
  3fbf15:	adc    %r8,%rdx
  3fbf18:	adc    %r9,%rsi
  3fbf1b:	adc    %r10,%rax
  3fbf1e:	mov    %rcx,0xe0(%rsp)
  3fbf26:	mov    %rdx,0xe8(%rsp)
  3fbf2e:	mov    %rsi,0xf0(%rsp)
  3fbf36:	mov    %rax,0xf8(%rsp)
  3fbf3e:	mov    0x40(%r12),%rsi
  3fbf43:	and    $0x7fffffff,%ebx
  3fbf49:	cmp    %rbx,%rsi
  3fbf4c:	jbe    3fc49b <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xccb>
  3fbf52:	mov    0x38(%r12),%rax
  3fbf57:	mov    0x28(%r12),%rsi
  3fbf5c:	mov    $0xffffffff,%ecx
  3fbf61:	mov    (%rax,%rbx,4),%edi
  3fbf64:	cmp    %rcx,%rdi
  3fbf67:	je     3fbff0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x820>
  3fbf6d:	cmp    %rdi,%rsi
  3fbf70:	jbe    3fc4ad <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xcdd>
  3fbf76:	mov    0x20(%r12),%rbx
  3fbf7b:	lea    (%rdi,%rdi,2),%rbp
  3fbf7f:	lea    0x110(%rsp),%rdi
  3fbf87:	lea    0xc0(%rsp),%rdx
  3fbf8f:	shl    $0x5,%rbp
  3fbf93:	lea    (%rbx,%rbp,1),%rsi
  3fbf97:	vzeroupper
  3fbf9a:	call   126d40 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G1Config>>::add_affine>
  3fbf9f:	vmovdqa64 -0x3cfb29(%rip),%zmm3        # 2c480 <GCC_except_table3227+0x5410>
  3fbfa9:	vmovdqu64 0x110(%rsp),%zmm0
  3fbfb4:	vmovdqu64 0x130(%rsp),%zmm1
  3fbfbf:	vmovdqu64 %zmm1,0x20(%rbx,%rbp,1)
  3fbfca:	vmovdqu64 %zmm0,(%rbx,%rbp,1)
  3fbfd1:	inc    %r14
  3fbfd4:	add    $0x10,%r13
  3fbfd8:	cmp    %r14,0xb8(%rsp)
  3fbfe0:	jne    3fbe49 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x679>
  3fbfe6:	jmp    3fb9df <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x20f>
  3fbfeb:	nopl   0x0(%rax,%rax,1)
  3fbff0:	mov    %esi,(%rax,%rbx,4)
  3fbff3:	mov    0x58(%r12),%rbp
  3fbff8:	cmp    0x48(%r12),%rbp
  3fbffd:	je     3fc092 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x8c2>
  3fc003:	mov    0x50(%r12),%rax
  3fc008:	mov    %rbx,(%rax,%rbp,8)
  3fc00c:	inc    %rbp
  3fc00f:	vmovdqu 0xc0(%rsp),%ymm0
  3fc018:	mov    %rbp,0x58(%r12)
  3fc01d:	vptest %ymm0,%ymm0
  3fc022:	jne    3fbdb0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x5e0>
  3fc028:	vmovdqu 0xe0(%rsp),%ymm0
  3fc031:	vptest %ymm0,%ymm0
  3fc036:	jne    3fbdb0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x5e0>
  3fc03c:	vmovups -0x3c66ae(%rip),%zmm0        # 35998 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x81c>
  3fc046:	vmovups -0x3c66d8(%rip),%zmm1        # 35978 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x7fc>
  3fc050:	vmovups %zmm0,0x130(%rsp)
  3fc05b:	vmovups %zmm1,0x110(%rsp)
  3fc066:	mov    0x28(%r12),%rbx
  3fc06b:	cmp    0x18(%r12),%rbx
  3fc070:	jne    3fbdf7 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x627>
  3fc076:	lea    0x18(%r12),%rdi
  3fc07b:	vzeroupper
  3fc07e:	call   126cd0 <<alloc::raw_vec::RawVec<zopro_bn254::curve::Projective<zopro_bn254::curve::G1Config>>>::grow_one>
  3fc083:	vmovdqa64 -0x3cfc0d(%rip),%zmm3        # 2c480 <GCC_except_table3227+0x5410>
  3fc08d:	jmp    3fbdf7 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x627>
  3fc092:	lea    0x48(%r12),%rdi
  3fc097:	vzeroupper
  3fc09a:	call   108390 <<alloc::raw_vec::RawVec<usize>>::grow_one>
  3fc09f:	vmovdqa64 -0x3cfc29(%rip),%zmm3        # 2c480 <GCC_except_table3227+0x5410>
  3fc0a9:	jmp    3fc003 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x833>
  3fc0ae:	mov    0x10(%r12),%rax
  3fc0b3:	cmp    %rsi,%rax
  3fc0b6:	jbe    3fc4ce <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xcfe>
  3fc0bc:	mov    0x8(%r12),%r8
  3fc0c1:	mov    %rsi,%r9
  3fc0c4:	shl    $0x6,%r9
  3fc0c8:	vmovdqu (%r8,%r9,1),%ymm0
  3fc0ce:	lea    (%r8,%r9,1),%rax
  3fc0d2:	vptest %ymm0,%ymm0
  3fc0d7:	jne    3fc0e9 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x919>
  3fc0d9:	vmovdqu 0x20(%rax),%ymm0
  3fc0de:	vptest %ymm0,%ymm0
  3fc0e3:	je     3fc1b0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x9e0>
  3fc0e9:	vmovdqu (%rax),%ymm0
  3fc0ed:	vpxor  (%r15),%ymm0,%ymm0
  3fc0f2:	vptest %ymm0,%ymm0
  3fc0f7:	je     3fc160 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x990>
  3fc0f9:	mov    $0x1,%eax
  3fc0fe:	mov    %r14,%rbp
  3fc101:	shlx   %rsi,%rax,%rax
  3fc106:	or     %rax,%rdx
  3fc109:	mov    %rdx,(%rcx,%rdi,8)
  3fc10d:	mov    0x88(%r12),%r14
  3fc115:	cmp    0x78(%r12),%r14
  3fc11a:	je     3fc440 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xc70>
  3fc120:	mov    0x80(%r12),%rax
  3fc128:	mov    %r14,%rcx
  3fc12b:	shl    $0x4,%rcx
  3fc12f:	inc    %r14
  3fc132:	mov    %ebx,(%rax,%rcx,1)
  3fc135:	mov    %r15,0x8(%rax,%rcx,1)
  3fc13a:	mov    %r14,0x88(%r12)
  3fc142:	mov    %rbp,%r14
  3fc145:	mov    0x378(%rsp),%rax
  3fc14d:	cmp    %rax,0x88(%r12)
  3fc155:	jne    3fba00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x230>
  3fc15b:	jmp    3fc41e <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xc4e>
  3fc160:	test   %ebx,%ebx
  3fc162:	js     3fc1d1 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xa01>
  3fc164:	vmovups (%r15),%zmm0
  3fc16a:	vmovups %zmm0,0x180(%rsp)
  3fc172:	vmovdqu 0x20(%rax),%ymm0
  3fc177:	vpxor  0x1a0(%rsp),%ymm0,%ymm0
  3fc180:	vptest %ymm0,%ymm0
  3fc185:	je     3fc2f7 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xb27>
  3fc18b:	vpxor  %xmm0,%xmm0,%xmm0
  3fc18f:	vmovdqu64 %zmm0,(%rax)
  3fc195:	mov    0x378(%rsp),%rax
  3fc19d:	cmp    %rax,0x88(%r12)
  3fc1a5:	jne    3fba00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x230>
  3fc1ab:	jmp    3fc41e <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xc4e>
  3fc1b0:	test   %ebx,%ebx
  3fc1b2:	js     3fc34e <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xb7e>
  3fc1b8:	vmovups (%r15),%ymm0
  3fc1bd:	vmovups %ymm0,0x110(%rsp)
  3fc1c6:	vmovdqu 0x20(%r15),%ymm0
  3fc1cc:	jmp    3fc3f6 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xc26>
  3fc1d1:	vmovups 0x20(%r15),%ymm0
  3fc1d7:	movq   $0x0,0x10(%rsp)
  3fc1e0:	movq   $0x0,0x18(%rsp)
  3fc1e9:	movq   $0x0,0x38(%rsp)
  3fc1f2:	movq   $0x0,0x30(%rsp)
  3fc1fb:	mov    %rax,0x90(%rsp)
  3fc203:	lea    0xc0(%rsp),%r13
  3fc20b:	lea    0x110(%rsp),%rcx
  3fc213:	mov    0x10(%rsp),%rdx
  3fc218:	mov    0x18(%rsp),%rdi
  3fc21d:	mov    0x38(%rsp),%r8
  3fc222:	mov    0x30(%rsp),%rax
  3fc227:	vmovups %ymm0,0xc0(%rsp)
  3fc230:	vmovups -0x3ce538(%rip),%ymm0        # 2dd00 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3fc238:	vmovups %ymm0,0x110(%rsp)
  3fc241:	sub    0x0(%r13),%rdi
  3fc245:	sbb    0x8(%r13),%r8
  3fc249:	sbb    0x10(%r13),%rax
  3fc24d:	sbb    0x18(%r13),%rdx
  3fc251:	sbb    %rbp,%rbp
  3fc254:	mov    (%rcx),%r9
  3fc257:	mov    0x8(%rcx),%r10
  3fc25b:	mov    0x10(%rcx),%r11
  3fc25f:	mov    0x18(%rcx),%rbx
  3fc263:	and    %rbp,%r9
  3fc266:	and    %rbp,%r10
  3fc269:	and    %rbp,%r11
  3fc26c:	and    %rbp,%rbx
  3fc26f:	add    %r9,%rdi
  3fc272:	adc    %r10,%r8
  3fc275:	adc    %r11,%rax
  3fc278:	adc    %rbx,%rdx
  3fc27b:	mov    %rdi,0x18(%rsp)
  3fc280:	mov    %r8,0x38(%rsp)
  3fc285:	mov    %rax,0x30(%rsp)
  3fc28a:	mov    %rdx,0x10(%rsp)
  3fc28f:	vmovups (%r15),%ymm0
  3fc294:	mov    0x18(%rsp),%rcx
  3fc299:	mov    0x38(%rsp),%rax
  3fc29e:	mov    0x50(%rsp),%r13
  3fc2a3:	mov    0x10(%rsp),%rdx
  3fc2a8:	vmovups %ymm0,0x180(%rsp)
  3fc2b1:	mov    %rcx,0x1a0(%rsp)
  3fc2b9:	mov    %rax,0x1a8(%rsp)
  3fc2c1:	mov    0x30(%rsp),%rax
  3fc2c6:	mov    %rax,0x1b0(%rsp)
  3fc2ce:	mov    0x90(%rsp),%rax
  3fc2d6:	mov    %rdx,0x1b8(%rsp)
  3fc2de:	vmovdqu 0x20(%rax),%ymm0
  3fc2e3:	vpxor  0x1a0(%rsp),%ymm0,%ymm0
  3fc2ec:	vptest %ymm0,%ymm0
  3fc2f1:	jne    3fc18b <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x9bb>
  3fc2f7:	lea    0x180(%rsp),%rdx
  3fc2ff:	mov    %r12,%rdi
  3fc302:	vzeroupper
  3fc305:	call   168550 <<zopro_core::msm_affine::borrowed_pending::Window<zopro_bn254::curve::G1Config>>::projective>
  3fc30a:	vmovdqa64 -0x3cfe94(%rip),%zmm3        # 2c480 <GCC_except_table3227+0x5410>
  3fc314:	mov    0x378(%rsp),%rax
  3fc31c:	cmp    %rax,0x88(%r12)
  3fc324:	jne    3fba00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x230>
  3fc32a:	jmp    3fc41e <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xc4e>
  3fc32f:	lea    0x90(%r12),%rdi
  3fc337:	vzeroupper
  3fc33a:	call   214340 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3fc33f:	vmovdqa64 -0x3cfec9(%rip),%zmm3        # 2c480 <GCC_except_table3227+0x5410>
  3fc349:	jmp    3fbd54 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x584>
  3fc34e:	vmovups 0x20(%r15),%ymm0
  3fc354:	xor    %ecx,%ecx
  3fc356:	xor    %edx,%edx
  3fc358:	xor    %esi,%esi
  3fc35a:	xor    %edi,%edi
  3fc35c:	lea    0xc0(%rsp),%r13
  3fc364:	lea    0x110(%rsp),%rbp
  3fc36c:	vmovups %ymm0,0xc0(%rsp)
  3fc375:	vmovups -0x3ce67d(%rip),%ymm0        # 2dd00 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3fc37d:	vmovups %ymm0,0x110(%rsp)
  3fc386:	sub    0x0(%r13),%rcx
  3fc38a:	sbb    0x8(%r13),%rdx
  3fc38e:	sbb    0x10(%r13),%rsi
  3fc392:	sbb    0x18(%r13),%rdi
  3fc396:	sbb    %rbx,%rbx
  3fc399:	mov    0x0(%rbp),%r8
  3fc39d:	mov    0x8(%rbp),%r9
  3fc3a1:	mov    0x10(%rbp),%r10
  3fc3a5:	mov    0x18(%rbp),%r11
  3fc3a9:	and    %rbx,%r8
  3fc3ac:	and    %rbx,%r9
  3fc3af:	and    %rbx,%r10
  3fc3b2:	and    %rbx,%r11
  3fc3b5:	add    %r8,%rcx
  3fc3b8:	adc    %r9,%rdx
  3fc3bb:	adc    %r10,%rsi
  3fc3be:	adc    %r11,%rdi
  3fc3c1:	vmovq  %rsi,%xmm1
  3fc3c6:	vmovq  %rcx,%xmm2
  3fc3cb:	vmovups (%r15),%ymm0
  3fc3d0:	mov    0x50(%rsp),%r13
  3fc3d5:	vmovups %ymm0,0x110(%rsp)
  3fc3de:	vmovq  %rdi,%xmm0
  3fc3e3:	vpunpcklqdq %xmm0,%xmm1,%xmm0
  3fc3e7:	vmovq  %rdx,%xmm1
  3fc3ec:	vpunpcklqdq %xmm1,%xmm2,%xmm1
  3fc3f0:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
  3fc3f6:	vmovdqu 0x110(%rsp),%ymm1
  3fc3ff:	vmovdqu %ymm1,(%rax)
  3fc403:	vmovdqu %ymm0,0x20(%rax)
  3fc408:	mov    0x378(%rsp),%rax
  3fc410:	cmp    %rax,0x88(%r12)
  3fc418:	jne    3fba00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x230>
  3fc41e:	mov    %r12,%rdi
  3fc421:	vzeroupper
  3fc424:	call   168480 <<zopro_core::msm_affine::borrowed_pending::Window<zopro_bn254::curve::G1Config>>::execute>
  3fc429:	mov    %r12,%rdi
  3fc42c:	call   1756b0 <<zopro_core::msm_affine::borrowed_pending::Window<zopro_bn254::curve::G1Config>>::take_from_queue>
  3fc431:	vmovdqa64 -0x3cffbb(%rip),%zmm3        # 2c480 <GCC_except_table3227+0x5410>
  3fc43b:	jmp    3fba00 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x230>
  3fc440:	lea    0x78(%r12),%rdi
  3fc445:	vzeroupper
  3fc448:	call   214340 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3fc44d:	vmovdqa64 -0x3cffd7(%rip),%zmm3        # 2c480 <GCC_except_table3227+0x5410>
  3fc457:	jmp    3fc120 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x950>
  3fc45c:	add    $0x338,%rsp
  3fc463:	pop    %rbx
  3fc464:	pop    %r12
  3fc466:	pop    %r13
  3fc468:	pop    %r14
  3fc46a:	pop    %r15
  3fc46c:	pop    %rbp
  3fc46d:	vzeroupper
  3fc470:	ret
  3fc471:	lea    -0x3c6620(%rip),%rdi        # 35e58 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0xcdc>
  3fc478:	lea    0xfbee9(%rip),%rdx        # 4f8368 <__frame_dummy_init_array_entry+0x4308>
  3fc47f:	mov    $0x2b,%esi
  3fc484:	call   1043e0 <core::panicking::panic>
  3fc489:	lea    0xfbf20(%rip),%rdx        # 4f83b0 <__frame_dummy_init_array_entry+0x4350>
  3fc490:	mov    %r14,%rdi
  3fc493:	vzeroupper
  3fc496:	call   1033bb <core::panicking::panic_bounds_check>
  3fc49b:	lea    0xfbede(%rip),%rdx        # 4f8380 <__frame_dummy_init_array_entry+0x4320>
  3fc4a2:	mov    %rbx,%rdi
  3fc4a5:	vzeroupper
  3fc4a8:	call   1033bb <core::panicking::panic_bounds_check>
  3fc4ad:	lea    0xfbee4(%rip),%rdx        # 4f8398 <__frame_dummy_init_array_entry+0x4338>
  3fc4b4:	vzeroupper
  3fc4b7:	call   1033bb <core::panicking::panic_bounds_check>
  3fc4bc:	lea    0xfbf05(%rip),%rdx        # 4f83c8 <__frame_dummy_init_array_entry+0x4368>
  3fc4c3:	mov    %rax,%rsi
  3fc4c6:	vzeroupper
  3fc4c9:	call   1033bb <core::panicking::panic_bounds_check>
  3fc4ce:	lea    0xfbf0b(%rip),%rdx        # 4f83e0 <__frame_dummy_init_array_entry+0x4380>
  3fc4d5:	mov    %rsi,%rdi
  3fc4d8:	mov    %rax,%rsi
  3fc4db:	vzeroupper
  3fc4de:	call   1033bb <core::panicking::panic_bounds_check>
