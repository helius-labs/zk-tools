
/home/ubuntu/src/zopro-perf-work/simd-booth176/sdk-OFF:     file format elf64-x86-64


Disassembly of section .text:

00000000003fac50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>>:
  3fac50:	push   %rbp
  3fac51:	push   %r15
  3fac53:	push   %r14
  3fac55:	push   %r13
  3fac57:	push   %r12
  3fac59:	push   %rbx
  3fac5a:	sub    $0x188,%rsp
  3fac61:	cmp    %rdx,%r8
  3fac64:	mov    %rcx,0x70(%rsp)
  3fac69:	mov    %rsi,0x58(%rsp)
  3fac6e:	cmovb  %r8,%rdx
  3fac72:	mov    %rdx,0x68(%rsp)
  3fac77:	test   %rdx,%rdx
  3fac7a:	je     3fb4be <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x86e>
  3fac80:	mov    0x1c0(%rsp),%rsi
  3fac88:	lea    -0x1(%r9),%rax
  3fac8c:	mov    %rdi,%r13
  3fac8f:	mov    %r9,%r15
  3fac92:	mov    0x1c8(%rsp),%rdx
  3fac9a:	mov    %r9,0x10(%rsp)
  3fac9f:	mov    %rax,%rdi
  3faca2:	and    $0x3f,%eax
  3faca5:	shr    $0x6,%rdi
  3faca9:	mov    %rax,0x20(%rsp)
  3facae:	mov    %rdi,0x60(%rsp)
  3facb3:	lea    -0x40(%rsi,%rax,1),%rax
  3facb8:	lea    -0x2(%rdx),%r8
  3facbc:	mov    %r8,0x28(%rsp)
  3facc1:	cmp    $0xffffffffffffffbf,%rax
  3facc5:	setb   %al
  3facc8:	cmp    $0xc1,%r9
  3faccf:	setb   %cl
  3facd2:	and    %al,%cl
  3facd4:	mov    $0x1,%eax
  3facd9:	sub    %r15d,%eax
  3facdc:	mov    %cl,0x7(%rsp)
  3face0:	mov    $0xffffffffffffffff,%rcx
  3face7:	and    $0x3f,%eax
  3facea:	mov    %rax,0x18(%rsp)
  3facef:	lea    0x1(%rsi),%eax
  3facf2:	shlx   %rax,%rcx,%rax
  3facf7:	not    %rax
  3facfa:	mov    %rax,0x50(%rsp)
  3facff:	mov    %esi,%eax
  3fad01:	and    $0x3f,%eax
  3fad04:	dec    %esi
  3fad06:	mov    %rax,0x38(%rsp)
  3fad0b:	shlx   %rax,%rcx,%rax
  3fad10:	and    $0x3f,%esi
  3fad13:	lea    -0x1(%rdx),%rcx
  3fad17:	mov    %rax,0x48(%rsp)
  3fad1c:	not    %rax
  3fad1f:	mov    %rsi,0x40(%rsp)
  3fad24:	xor    %esi,%esi
  3fad26:	mov    %rcx,0x78(%rsp)
  3fad2b:	mov    %rax,0x30(%rsp)
  3fad30:	jmp    3fad63 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x113>
  3fad32:	mov    0x10(%rsp),%r15
  3fad37:	mov    0x8(%rsp),%rsi
  3fad3c:	movq   $0x0,0xa0(%r13)
  3fad47:	nopw   0x0(%rax,%rax,1)
  3fad50:	mov    0x60(%rsp),%rdi
  3fad55:	inc    %rsi
  3fad58:	cmp    0x68(%rsp),%rsi
  3fad5d:	je     3fb4be <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x86e>
  3fad63:	mov    %rsi,%rax
  3fad66:	shl    $0x5,%rax
  3fad6a:	add    0x70(%rsp),%rax
  3fad6f:	test   %r15,%r15
  3fad72:	je     3fada0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x150>
  3fad74:	cmp    $0x100,%r15
  3fad7b:	ja     3fadd0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x180>
  3fad7d:	mov    0x20(%rsp),%rcx
  3fad82:	cmpb   $0x0,0x7(%rsp)
  3fad87:	shrx   %rcx,(%rax,%rdi,8),%rcx
  3fad8d:	je     3fadd2 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x182>
  3fad8f:	mov    0x18(%rsp),%rdx
  3fad94:	shlx   %rdx,0x8(%rax,%rdi,8),%rax
  3fad9b:	or     %rax,%rcx
  3fad9e:	jmp    3fadd2 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x182>
  3fada0:	mov    (%rax),%rax
  3fada3:	mov    0x40(%rsp),%rcx
  3fada8:	mov    0x38(%rsp),%rdx
  3fadad:	and    0x30(%rsp),%rax
  3fadb2:	shrx   %rcx,%rax,%rcx
  3fadb7:	shlx   %rdx,%rcx,%rcx
  3fadbc:	sub    %rcx,%rax
  3fadbf:	test   %ax,%ax
  3fadc2:	jne    3fadef <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x19f>
  3fadc4:	jmp    3fad50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x100>
  3fadc6:	cs nopw 0x0(%rax,%rax,1)
  3fadd0:	xor    %ecx,%ecx
  3fadd2:	and    0x50(%rsp),%rcx
  3fadd7:	lea    0x1(%rcx),%rax
  3faddb:	and    0x48(%rsp),%rcx
  3fade0:	shr    $1,%rax
  3fade3:	sub    %rcx,%rax
  3fade6:	test   %ax,%ax
  3fade9:	je     3fad50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x100>
  3fadef:	mov    %rsi,%r14
  3fadf2:	shl    $0x6,%r14
  3fadf6:	add    0x58(%rsp),%r14
  3fadfb:	vmovdqu (%r14),%ymm0
  3fae00:	vptest %ymm0,%ymm0
  3fae05:	jne    3fae18 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x1c8>
  3fae07:	vmovdqu 0x20(%r14),%ymm0
  3fae0d:	vptest %ymm0,%ymm0
  3fae12:	je     3fad50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x100>
  3fae18:	mov    %rsi,0x8(%rsp)
  3fae1d:	xor    %ecx,%ecx
  3fae1f:	test   %ax,%ax
  3fae22:	mov    %eax,%esi
  3fae24:	sets   %dl
  3fae27:	neg    %si
  3fae2a:	cmovs  %ax,%si
  3fae2e:	mov    0x70(%r13),%rax
  3fae32:	movzwl %si,%esi
  3fae35:	dec    %rsi
  3fae38:	mov    %rsi,%rdi
  3fae3b:	shr    $0x6,%rdi
  3fae3f:	cmp    %rax,%rdi
  3fae42:	jae    3fb506 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x8b6>
  3fae48:	mov    %dl,%cl
  3fae4a:	mov    %esi,%ebp
  3fae4c:	shl    $0x1f,%ecx
  3fae4f:	or     %ecx,%ebp
  3fae51:	mov    0x68(%r13),%rcx
  3fae55:	mov    (%rcx,%rdi,8),%rdx
  3fae59:	bt     %rsi,%rdx
  3fae5d:	jae    3fb190 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x540>
  3fae63:	mov    0xa0(%r13),%r15
  3fae6a:	cmp    0x90(%r13),%r15
  3fae71:	je     3fb3ab <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x75b>
  3fae77:	mov    0x98(%r13),%rax
  3fae7e:	mov    %r15,%rcx
  3fae81:	shl    $0x4,%rcx
  3fae85:	mov    0x8(%rsp),%rsi
  3fae8a:	mov    %ebp,(%rax,%rcx,1)
  3fae8d:	mov    %r14,0x8(%rax,%rcx,1)
  3fae92:	lea    0x1(%r15),%rax
  3fae96:	mov    %rax,0xa0(%r13)
  3fae9d:	cmp    0x28(%rsp),%r15
  3faea2:	mov    0x10(%rsp),%r15
  3faea7:	jne    3fad50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x100>
  3faead:	test   %rax,%rax
  3faeb0:	je     3fad32 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xe2>
  3faeb6:	mov    $0x8,%r15d
  3faebc:	xor    %r14d,%r14d
  3faebf:	jmp    3faf60 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x310>
  3faec4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  3faed0:	lea    0xa0(%rsp),%rax
  3faed8:	vmovdqu 0x80(%rsp),%ymm2
  3faee1:	vmovups -0x3cd309(%rip),%ymm1        # 2dbe0 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0x80>
  3faee9:	vmovups (%rax),%ymm0
  3faeed:	lea    0xe0(%rsp),%rax
  3faef5:	vmovups %ymm0,(%rax)
  3faef9:	vmovdqu %ymm2,0xc0(%rsp)
  3faf02:	vmovups %ymm1,0x20(%rax)
  3faf07:	mov    0x28(%r13),%rbp
  3faf0b:	cmp    0x18(%r13),%rbp
  3faf0f:	je     3fb169 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x519>
  3faf15:	vmovdqu64 0xc0(%rsp),%zmm0
  3faf1d:	vmovups 0xe0(%rsp),%zmm1
  3faf28:	mov    0x20(%r13),%rax
  3faf2c:	lea    0x0(%rbp,%rbp,2),%rcx
  3faf31:	inc    %rbp
  3faf34:	shl    $0x5,%rcx
  3faf38:	vmovups %zmm1,0x20(%rax,%rcx,1)
  3faf43:	vmovdqu64 %zmm0,(%rax,%rcx,1)
  3faf4a:	mov    %rbp,0x28(%r13)
  3faf4e:	inc    %r14
  3faf51:	add    $0x10,%r15
  3faf55:	cmp    %r14,0x78(%rsp)
  3faf5a:	je     3fad32 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xe2>
  3faf60:	mov    0xa0(%r13),%rsi
  3faf67:	cmp    %rsi,%r14
  3faf6a:	jae    3fb4d3 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x883>
  3faf70:	mov    0x98(%r13),%rax
  3faf77:	mov    -0x8(%rax,%r15,1),%ebp
  3faf7c:	mov    (%rax,%r15,1),%rax
  3faf80:	test   %ebp,%ebp
  3faf82:	js     3fafb0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x360>
  3faf84:	vmovups (%rax),%zmm0
  3faf8a:	vmovups %zmm0,0x80(%rsp)
  3faf92:	mov    0x40(%r13),%rsi
  3faf96:	and    $0x7fffffff,%ebp
  3faf9c:	cmp    %rbp,%rsi
  3faf9f:	ja     3fb064 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x414>
  3fafa5:	jmp    3fb4e5 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x895>
  3fafaa:	nopw   0x0(%rax,%rax,1)
  3fafb0:	vmovups (%rax),%ymm0
  3fafb4:	vmovups -0x3cd37c(%rip),%ymm1        # 2dc40 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3fafbc:	xor    %ecx,%ecx
  3fafbe:	xor    %edx,%edx
  3fafc0:	xor    %esi,%esi
  3fafc2:	lea    0xc0(%rsp),%r12
  3fafca:	lea    0x160(%rsp),%rbx
  3fafd2:	vmovups %ymm0,0x80(%rsp)
  3fafdb:	vmovups 0x20(%rax),%ymm0
  3fafe0:	vmovups %ymm1,0xc0(%rsp)
  3fafe9:	xor    %eax,%eax
  3fafeb:	vmovups %ymm0,0x160(%rsp)
  3faff4:	sub    (%rbx),%rcx
  3faff7:	sbb    0x8(%rbx),%rdx
  3faffb:	sbb    0x10(%rbx),%rsi
  3fafff:	sbb    0x18(%rbx),%rax
  3fb003:	sbb    %r11,%r11
  3fb006:	mov    (%r12),%rdi
  3fb00a:	mov    0x8(%r12),%r8
  3fb00f:	mov    0x10(%r12),%r9
  3fb014:	mov    0x18(%r12),%r10
  3fb019:	and    %r11,%rdi
  3fb01c:	and    %r11,%r8
  3fb01f:	and    %r11,%r9
  3fb022:	and    %r11,%r10
  3fb025:	add    %rdi,%rcx
  3fb028:	adc    %r8,%rdx
  3fb02b:	adc    %r9,%rsi
  3fb02e:	adc    %r10,%rax
  3fb031:	mov    %rcx,0xa0(%rsp)
  3fb039:	mov    %rdx,0xa8(%rsp)
  3fb041:	mov    %rsi,0xb0(%rsp)
  3fb049:	mov    %rax,0xb8(%rsp)
  3fb051:	mov    0x40(%r13),%rsi
  3fb055:	and    $0x7fffffff,%ebp
  3fb05b:	cmp    %rbp,%rsi
  3fb05e:	jbe    3fb4e5 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x895>
  3fb064:	mov    0x38(%r13),%rax
  3fb068:	mov    0x28(%r13),%rsi
  3fb06c:	mov    $0xffffffff,%ecx
  3fb071:	mov    (%rax,%rbp,4),%edi
  3fb074:	cmp    %rcx,%rdi
  3fb077:	je     3fb0f0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x4a0>
  3fb079:	cmp    %rdi,%rsi
  3fb07c:	jbe    3fb4f7 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x8a7>
  3fb082:	mov    0x20(%r13),%r12
  3fb086:	lea    (%rdi,%rdi,2),%rbp
  3fb08a:	lea    0xc0(%rsp),%rdi
  3fb092:	lea    0x80(%rsp),%rdx
  3fb09a:	shl    $0x5,%rbp
  3fb09e:	lea    (%r12,%rbp,1),%rsi
  3fb0a2:	vzeroupper
  3fb0a5:	call   126ac0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G1Config>>::add_affine>
  3fb0aa:	vmovdqu64 0xc0(%rsp),%zmm0
  3fb0b2:	vmovups 0xe0(%rsp),%zmm1
  3fb0bd:	vmovups %zmm1,0x20(%r12,%rbp,1)
  3fb0c8:	vmovdqu64 %zmm0,(%r12,%rbp,1)
  3fb0cf:	inc    %r14
  3fb0d2:	add    $0x10,%r15
  3fb0d6:	cmp    %r14,0x78(%rsp)
  3fb0db:	jne    3faf60 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x310>
  3fb0e1:	jmp    3fad32 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0xe2>
  3fb0e6:	cs nopw 0x0(%rax,%rax,1)
  3fb0f0:	mov    %esi,(%rax,%rbp,4)
  3fb0f3:	mov    0x58(%r13),%r12
  3fb0f7:	cmp    0x48(%r13),%r12
  3fb0fb:	je     3fb17a <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x52a>
  3fb0fd:	mov    0x50(%r13),%rax
  3fb101:	mov    %rbp,(%rax,%r12,8)
  3fb105:	inc    %r12
  3fb108:	vmovdqu 0x80(%rsp),%ymm0
  3fb111:	mov    %r12,0x58(%r13)
  3fb115:	vptest %ymm0,%ymm0
  3fb11a:	jne    3faed0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x280>
  3fb120:	vmovdqu 0xa0(%rsp),%ymm0
  3fb129:	vptest %ymm0,%ymm0
  3fb12e:	jne    3faed0 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x280>
  3fb134:	vmovups -0x3c58ce(%rip),%zmm0        # 35870 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x81c>
  3fb13e:	vmovups -0x3c58f8(%rip),%zmm1        # 35850 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x7fc>
  3fb148:	vmovups %zmm0,0xe0(%rsp)
  3fb153:	vmovups %zmm1,0xc0(%rsp)
  3fb15b:	mov    0x28(%r13),%rbp
  3fb15f:	cmp    0x18(%r13),%rbp
  3fb163:	jne    3faf15 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x2c5>
  3fb169:	lea    0x18(%r13),%rdi
  3fb16d:	vzeroupper
  3fb170:	call   126a50 <<alloc::raw_vec::RawVec<zopro_bn254::curve::Projective<zopro_bn254::curve::G1Config>>>::grow_one>
  3fb175:	jmp    3faf15 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x2c5>
  3fb17a:	lea    0x48(%r13),%rdi
  3fb17e:	vzeroupper
  3fb181:	call   108110 <<alloc::raw_vec::RawVec<usize>>::grow_one>
  3fb186:	jmp    3fb0fd <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x4ad>
  3fb18b:	nopl   0x0(%rax,%rax,1)
  3fb190:	mov    0x10(%r13),%rax
  3fb194:	cmp    %rsi,%rax
  3fb197:	jbe    3fb518 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x8c8>
  3fb19d:	mov    0x8(%r13),%r8
  3fb1a1:	mov    %rsi,%r9
  3fb1a4:	shl    $0x6,%r9
  3fb1a8:	vmovdqu (%r8,%r9,1),%ymm0
  3fb1ae:	lea    (%r8,%r9,1),%rax
  3fb1b2:	vptest %ymm0,%ymm0
  3fb1b7:	jne    3fb1c9 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x579>
  3fb1b9:	vmovdqu 0x20(%rax),%ymm0
  3fb1be:	vptest %ymm0,%ymm0
  3fb1c3:	je     3fb296 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x646>
  3fb1c9:	vmovdqu (%rax),%ymm0
  3fb1cd:	vpxor  (%r14),%ymm0,%ymm0
  3fb1d2:	vptest %ymm0,%ymm0
  3fb1d7:	je     3fb23f <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x5ef>
  3fb1d9:	mov    $0x1,%eax
  3fb1de:	shlx   %rsi,%rax,%rax
  3fb1e3:	or     %rax,%rdx
  3fb1e6:	mov    %rdx,(%rcx,%rdi,8)
  3fb1ea:	mov    0x88(%r13),%r15
  3fb1f1:	cmp    0x78(%r13),%r15
  3fb1f5:	je     3fb4ad <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x85d>
  3fb1fb:	mov    0x80(%r13),%rax
  3fb202:	mov    %r15,%rcx
  3fb205:	shl    $0x4,%rcx
  3fb209:	inc    %r15
  3fb20c:	mov    %ebp,(%rax,%rcx,1)
  3fb20f:	mov    %r14,0x8(%rax,%rcx,1)
  3fb214:	mov    %r15,0x88(%r13)
  3fb21b:	mov    0x10(%rsp),%r15
  3fb220:	mov    0x8(%rsp),%rsi
  3fb225:	mov    0x1c8(%rsp),%rax
  3fb22d:	cmp    %rax,0x88(%r13)
  3fb234:	jne    3fad50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x100>
  3fb23a:	jmp    3fb490 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x840>
  3fb23f:	test   %ebp,%ebp
  3fb241:	js     3fb2b7 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x667>
  3fb243:	vmovups (%r14),%zmm0
  3fb249:	vmovups %zmm0,0x120(%rsp)
  3fb254:	vmovdqu 0x20(%rax),%ymm0
  3fb259:	vpxor  0x140(%rsp),%ymm0,%ymm0
  3fb262:	vptest %ymm0,%ymm0
  3fb267:	je     3fb379 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x729>
  3fb26d:	vpxor  %xmm0,%xmm0,%xmm0
  3fb271:	vmovdqu64 %zmm0,(%rax)
  3fb277:	mov    0x8(%rsp),%rsi
  3fb27c:	mov    0x1c8(%rsp),%rax
  3fb284:	cmp    %rax,0x88(%r13)
  3fb28b:	jne    3fad50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x100>
  3fb291:	jmp    3fb490 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x840>
  3fb296:	test   %ebp,%ebp
  3fb298:	js     3fb3bf <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x76f>
  3fb29e:	vmovups (%r14),%ymm0
  3fb2a3:	vmovups %ymm0,0xc0(%rsp)
  3fb2ac:	vmovdqu 0x20(%r14),%ymm0
  3fb2b2:	jmp    3fb464 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x814>
  3fb2b7:	vmovups 0x20(%r14),%ymm0
  3fb2bd:	xor    %ebx,%ebx
  3fb2bf:	xor    %edx,%edx
  3fb2c1:	xor    %edi,%edi
  3fb2c3:	xor    %r8d,%r8d
  3fb2c6:	lea    0x80(%rsp),%r12
  3fb2ce:	lea    0xc0(%rsp),%rcx
  3fb2d6:	vmovups %ymm0,0x80(%rsp)
  3fb2df:	vmovups -0x3cd6a7(%rip),%ymm0        # 2dc40 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3fb2e7:	vmovups %ymm0,0xc0(%rsp)
  3fb2f0:	sub    (%r12),%rdx
  3fb2f4:	sbb    0x8(%r12),%rdi
  3fb2f9:	sbb    0x10(%r12),%r8
  3fb2fe:	sbb    0x18(%r12),%rbx
  3fb303:	sbb    %r15,%r15
  3fb306:	mov    (%rcx),%r9
  3fb309:	mov    0x8(%rcx),%r10
  3fb30d:	mov    0x10(%rcx),%r11
  3fb311:	mov    0x18(%rcx),%rbp
  3fb315:	and    %r15,%r9
  3fb318:	and    %r15,%r10
  3fb31b:	and    %r15,%r11
  3fb31e:	and    %r15,%rbp
  3fb321:	add    %r9,%rdx
  3fb324:	adc    %r10,%rdi
  3fb327:	adc    %r11,%r8
  3fb32a:	adc    %rbp,%rbx
  3fb32d:	vmovups (%r14),%ymm0
  3fb332:	mov    0x10(%rsp),%r15
  3fb337:	vmovups %ymm0,0x120(%rsp)
  3fb340:	mov    %rdx,0x140(%rsp)
  3fb348:	mov    %rdi,0x148(%rsp)
  3fb350:	mov    %r8,0x150(%rsp)
  3fb358:	mov    %rbx,0x158(%rsp)
  3fb360:	vmovdqu 0x20(%rax),%ymm0
  3fb365:	vpxor  0x140(%rsp),%ymm0,%ymm0
  3fb36e:	vptest %ymm0,%ymm0
  3fb373:	jne    3fb26d <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x61d>
  3fb379:	lea    0x120(%rsp),%rdx
  3fb381:	mov    %r13,%rdi
  3fb384:	vzeroupper
  3fb387:	call   167f00 <<zopro_core::msm_affine::borrowed_pending::Window<zopro_bn254::curve::G1Config>>::projective>
  3fb38c:	mov    0x8(%rsp),%rsi
  3fb391:	mov    0x1c8(%rsp),%rax
  3fb399:	cmp    %rax,0x88(%r13)
  3fb3a0:	jne    3fad50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x100>
  3fb3a6:	jmp    3fb490 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x840>
  3fb3ab:	lea    0x90(%r13),%rdi
  3fb3b2:	vzeroupper
  3fb3b5:	call   213cf0 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3fb3ba:	jmp    3fae77 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x227>
  3fb3bf:	vmovups 0x20(%r14),%ymm0
  3fb3c5:	xor    %ecx,%ecx
  3fb3c7:	xor    %ebx,%ebx
  3fb3c9:	xor    %esi,%esi
  3fb3cb:	xor    %edi,%edi
  3fb3cd:	lea    0x80(%rsp),%r12
  3fb3d5:	lea    0xc0(%rsp),%rdx
  3fb3dd:	vmovups %ymm0,0x80(%rsp)
  3fb3e6:	vmovups -0x3cd7ae(%rip),%ymm0        # 2dc40 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3fb3ee:	vmovups %ymm0,0xc0(%rsp)
  3fb3f7:	sub    (%r12),%rbx
  3fb3fb:	sbb    0x8(%r12),%rsi
  3fb400:	sbb    0x10(%r12),%rdi
  3fb405:	sbb    0x18(%r12),%rcx
  3fb40a:	sbb    %rbp,%rbp
  3fb40d:	mov    (%rdx),%r8
  3fb410:	mov    0x8(%rdx),%r9
  3fb414:	mov    0x10(%rdx),%r10
  3fb418:	mov    0x18(%rdx),%r11
  3fb41c:	and    %rbp,%r8
  3fb41f:	and    %rbp,%r9
  3fb422:	and    %rbp,%r10
  3fb425:	and    %rbp,%r11
  3fb428:	add    %r8,%rbx
  3fb42b:	adc    %r9,%rsi
  3fb42e:	adc    %r10,%rdi
  3fb431:	adc    %r11,%rcx
  3fb434:	vmovq  %rdi,%xmm1
  3fb439:	vmovq  %rbx,%xmm2
  3fb43e:	vmovups (%r14),%ymm0
  3fb443:	vmovups %ymm0,0xc0(%rsp)
  3fb44c:	vmovq  %rcx,%xmm0
  3fb451:	vpunpcklqdq %xmm0,%xmm1,%xmm0
  3fb455:	vmovq  %rsi,%xmm1
  3fb45a:	vpunpcklqdq %xmm1,%xmm2,%xmm1
  3fb45e:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
  3fb464:	vmovups 0xc0(%rsp),%ymm1
  3fb46d:	vmovups %ymm1,(%rax)
  3fb471:	vmovdqu %ymm0,0x20(%rax)
  3fb476:	mov    0x8(%rsp),%rsi
  3fb47b:	mov    0x1c8(%rsp),%rax
  3fb483:	cmp    %rax,0x88(%r13)
  3fb48a:	jne    3fad50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x100>
  3fb490:	mov    %r13,%rdi
  3fb493:	vzeroupper
  3fb496:	call   167e30 <<zopro_core::msm_affine::borrowed_pending::Window<zopro_bn254::curve::G1Config>>::execute>
  3fb49b:	mov    %r13,%rdi
  3fb49e:	call   175060 <<zopro_core::msm_affine::borrowed_pending::Window<zopro_bn254::curve::G1Config>>::take_from_queue>
  3fb4a3:	mov    0x8(%rsp),%rsi
  3fb4a8:	jmp    3fad50 <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x100>
  3fb4ad:	lea    0x78(%r13),%rdi
  3fb4b1:	vzeroupper
  3fb4b4:	call   213cf0 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3fb4b9:	jmp    3fb1fb <zopro_core::msm_affine::borrowed_pending::balanced::feed::<zopro_bn254::curve::G1Config>+0x5ab>
  3fb4be:	add    $0x188,%rsp
  3fb4c5:	pop    %rbx
  3fb4c6:	pop    %r12
  3fb4c8:	pop    %r13
  3fb4ca:	pop    %r14
  3fb4cc:	pop    %r15
  3fb4ce:	pop    %rbp
  3fb4cf:	vzeroupper
  3fb4d2:	ret
  3fb4d3:	lea    0xfc196(%rip),%rdx        # 4f7670 <__frame_dummy_init_array_entry+0x4350>
  3fb4da:	mov    %r14,%rdi
  3fb4dd:	vzeroupper
  3fb4e0:	call   10313b <core::panicking::panic_bounds_check>
  3fb4e5:	lea    0xfc154(%rip),%rdx        # 4f7640 <__frame_dummy_init_array_entry+0x4320>
  3fb4ec:	mov    %rbp,%rdi
  3fb4ef:	vzeroupper
  3fb4f2:	call   10313b <core::panicking::panic_bounds_check>
  3fb4f7:	lea    0xfc15a(%rip),%rdx        # 4f7658 <__frame_dummy_init_array_entry+0x4338>
  3fb4fe:	vzeroupper
  3fb501:	call   10313b <core::panicking::panic_bounds_check>
  3fb506:	lea    0xfc17b(%rip),%rdx        # 4f7688 <__frame_dummy_init_array_entry+0x4368>
  3fb50d:	mov    %rax,%rsi
  3fb510:	vzeroupper
  3fb513:	call   10313b <core::panicking::panic_bounds_check>
  3fb518:	lea    0xfc181(%rip),%rdx        # 4f76a0 <__frame_dummy_init_array_entry+0x4380>
  3fb51f:	mov    %rsi,%rdi
  3fb522:	mov    %rax,%rsi
  3fb525:	vzeroupper
  3fb528:	call   10313b <core::panicking::panic_bounds_check>
