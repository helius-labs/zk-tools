
/home/ubuntu/src/zopro-perf-work/simd-booth176/sdk-ON:     file format elf64-x86-64


Disassembly of section .text:

00000000003ca390 <<zopro_core::msm_affine::g2_borrowed::Window>::feed>:
  3ca390:	push   %rbp
  3ca391:	push   %r15
  3ca393:	push   %r14
  3ca395:	push   %r13
  3ca397:	push   %r12
  3ca399:	push   %rbx
  3ca39a:	sub    $0x3a8,%rsp
  3ca3a1:	mov    %rcx,0x20(%rsp)
  3ca3a6:	mov    0x3e8(%rsp),%rax
  3ca3ae:	mov    0x3e0(%rsp),%r10
  3ca3b6:	mov    %r9b,0xe(%rsp)
  3ca3bb:	cmp    $0x10,%rax
  3ca3bf:	jae    3cb525 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x1195>
  3ca3c5:	mov    0x20(%rsp),%r14
  3ca3ca:	movabs $0x3fffffffffffff8,%rcx
  3ca3d4:	imul   %rax,%r10
  3ca3d8:	mov    %rsi,%r15
  3ca3db:	mov    %rdi,%rbx
  3ca3de:	mov    %rdx,%rdi
  3ca3e1:	shl    $0x7,%rdi
  3ca3e5:	vpxor  %xmm9,%xmm9,%xmm9
  3ca3ea:	vmovdqu %xmm9,0x310(%rsp)
  3ca3f3:	movq   $0x0,0x248(%rsp)
  3ca3ff:	movq   $0x0,0x270(%rsp)
  3ca40b:	and    %r8,%rcx
  3ca40e:	and    $0x7,%r8d
  3ca412:	add    %r15,%rdi
  3ca415:	mov    %rcx,%r11
  3ca418:	shl    $0x5,%r11
  3ca41c:	mov    %r8d,%esi
  3ca41f:	shl    $0x5,%esi
  3ca422:	mov    %rcx,0x50(%rsp)
  3ca427:	mov    %rdi,0x118(%rsp)
  3ca42f:	add    %r14,%r11
  3ca432:	mov    %r14,0x298(%rsp)
  3ca43a:	mov    %rcx,0x2a0(%rsp)
  3ca442:	lea    0xe(%rsp),%rcx
  3ca447:	add    %r11,%rsi
  3ca44a:	mov    %r11,0x2a8(%rsp)
  3ca452:	mov    %r8,0x2b0(%rsp)
  3ca45a:	movq   $0x8,0x2b8(%rsp)
  3ca466:	mov    %r10,0x2c0(%rsp)
  3ca46e:	mov    %rax,0x2c8(%rsp)
  3ca476:	mov    %r9b,0x2d0(%rsp)
  3ca47e:	mov    %r11,0x2d8(%rsp)
  3ca486:	lea    0x3e0(%rsp),%r8
  3ca48e:	mov    %rsi,0x2e0(%rsp)
  3ca496:	mov    %rsi,0x110(%rsp)
  3ca49e:	lea    0x3e8(%rsp),%rsi
  3ca4a6:	mov    %rcx,0x2e8(%rsp)
  3ca4ae:	mov    %r8,0x2f0(%rsp)
  3ca4b6:	mov    %rsi,0x2f8(%rsp)
  3ca4be:	mov    %rdi,0x308(%rsp)
  3ca4c6:	test   %rdx,%rdx
  3ca4c9:	je     3cb500 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x1170>
  3ca4cf:	mov    0x3f0(%rsp),%rdx
  3ca4d7:	mov    %r10,%rsi
  3ca4da:	vmovdqa64 -0x39e3a4(%rip),%zmm10        # 2c140 <GCC_except_table3227+0x50d0>
  3ca4e4:	lea    -0x1(%rax),%rcx
  3ca4e8:	vmovq  %rax,%xmm2
  3ca4ed:	mov    %r10,0x38(%rsp)
  3ca4f2:	vmovq  %rcx,%xmm1
  3ca4f7:	vmovdqa %xmm2,0xc0(%rsp)
  3ca500:	vmovdqa %xmm1,0x1b0(%rsp)
  3ca509:	add    $0xfffffffffffffffe,%rdx
  3ca50d:	mov    %rdx,0x108(%rsp)
  3ca515:	movzbl %r9b,%edx
  3ca519:	add    %edx,%edx
  3ca51b:	mov    %rdx,0x60(%rsp)
  3ca520:	xor    %edx,%edx
  3ca522:	test   %r10,%r10
  3ca525:	setne  %dl
  3ca528:	sub    %rdx,%rsi
  3ca52b:	add    %rax,%rdx
  3ca52e:	mov    %rsi,%r8
  3ca531:	mov    %rsi,0x78(%rsp)
  3ca536:	and    $0x3f,%esi
  3ca539:	shr    $0x6,%r8
  3ca53d:	lea    (%rdx,%rsi,1),%rdi
  3ca541:	mov    %r8,0x48(%rsp)
  3ca546:	vpbroadcastq %rsi,%zmm0
  3ca54c:	cmp    $0x41,%rdi
  3ca550:	mov    %rdi,0x100(%rsp)
  3ca558:	vmovdqu64 %zmm0,0x360(%rsp)
  3ca563:	setb   %dil
  3ca567:	test   %r8,%r8
  3ca56a:	mov    $0x40,%r8d
  3ca570:	setne  %r9b
  3ca574:	sub    %esi,%r8d
  3ca577:	xor    %r14d,%r14d
  3ca57a:	vmovd  %r8d,%xmm0
  3ca57f:	mov    $0xffffffffffffffff,%r8
  3ca586:	or     %dil,%r9b
  3ca589:	shlx   %rdx,%r8,%rdx
  3ca58e:	vmovdqa %xmm0,0x1a0(%rsp)
  3ca597:	mov    %r9b,0xf(%rsp)
  3ca59c:	not    %rdx
  3ca59f:	vpbroadcastq %rdx,%zmm0
  3ca5a5:	vmovdqu64 %zmm0,0x320(%rsp)
  3ca5b0:	jmp    3ca5e2 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x252>
  3ca5b2:	vmovdqa64 -0x39e47c(%rip),%zmm10        # 2c140 <GCC_except_table3227+0x50d0>
  3ca5bc:	mov    0x38(%rsp),%r10
  3ca5c1:	mov    0x68(%rsp),%r11
  3ca5c6:	mov    0x40(%rsp),%r14
  3ca5cb:	vpxor  %xmm9,%xmm9,%xmm9
  3ca5d0:	sub    $0xffffffffffffff80,%r15
  3ca5d4:	cmp    0x118(%rsp),%r15
  3ca5dc:	je     3cb500 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x1170>
  3ca5e2:	cmp    $0x2,%r14
  3ca5e6:	jne    3ca6b0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x320>
  3ca5ec:	cmp    0x110(%rsp),%r11
  3ca5f4:	je     3cb500 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x1170>
  3ca5fa:	movzbl 0xe(%rsp),%eax
  3ca5ff:	mov    0x3e0(%rsp),%rdx
  3ca607:	mov    0x3e8(%rsp),%rcx
  3ca60f:	mov    $0x3f,%dil
  3ca612:	lea    0x130(%rsp),%r8
  3ca61a:	shl    $0x4,%eax
  3ca61d:	mov    (%r11,%rax,1),%rsi
  3ca621:	mov    0x8(%r11,%rax,1),%rax
  3ca626:	bzhi   %rdi,%rax,%rdi
  3ca62b:	mov    %rsi,0x120(%rsp)
  3ca633:	mov    %rdi,0x128(%rsp)
  3ca63b:	vmovdqu %xmm9,(%r8)
  3ca640:	test   %rdx,%rdx
  3ca643:	je     3ca7a0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x410>
  3ca649:	imul   %rcx,%rdx
  3ca64d:	lea    -0x1(%rdx),%r8
  3ca651:	cmp    $0xff,%r8
  3ca658:	ja     3ca7b4 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x424>
  3ca65e:	mov    %r8d,%r9d
  3ca661:	mov    %r8,%rdi
  3ca664:	shr    $0x6,%rdi
  3ca668:	and    $0x3f,%r9d
  3ca66c:	shrx   %r9,0x120(%rsp,%rdi,8),%rsi
  3ca676:	cmp    $0xbf,%r8
  3ca67d:	ja     3ca7b6 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x426>
  3ca683:	lea    -0x40(%rcx,%r9,1),%r8
  3ca688:	cmp    $0xffffffffffffffbf,%r8
  3ca68c:	jae    3ca7b6 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x426>
  3ca692:	mov    $0x1,%r8b
  3ca695:	sub    %dl,%r8b
  3ca698:	shlx   %r8,0x128(%rsp,%rdi,8),%rdx
  3ca6a2:	or     %rdx,%rsi
  3ca6a5:	jmp    3ca7b6 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x426>
  3ca6aa:	nopw   0x0(%rax,%rax,1)
  3ca6b0:	cmpq   $0x8,0x70(%rsp)
  3ca6b6:	setne  %al
  3ca6b9:	and    %r14b,%al
  3ca6bc:	test   %r10,%r10
  3ca6bf:	je     3ca7f7 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x467>
  3ca6c5:	cmpq   $0x41,0x100(%rsp)
  3ca6ce:	jae    3ca886 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x4f6>
  3ca6d4:	test   %al,%al
  3ca6d6:	jne    3ca9a2 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x612>
  3ca6dc:	cmpq   $0x8,0x50(%rsp)
  3ca6e2:	jb     3ca5ec <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x25c>
  3ca6e8:	cmpq   $0x7f,0x78(%rsp)
  3ca6ee:	mov    0x60(%rsp),%rcx
  3ca6f3:	vpxor  %xmm0,%xmm0,%xmm0
  3ca6f7:	ja     3ca726 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x396>
  3ca6f9:	mov    0x20(%rsp),%rax
  3ca6fe:	mov    0x48(%rsp),%rdx
  3ca703:	kxnorb %k0,%k0,%k1
  3ca707:	lea    (%rax,%rcx,8),%rax
  3ca70b:	lea    (%rax,%rdx,8),%rax
  3ca70f:	vpgatherqq (%rax,%zmm10,8),%zmm0{%k1}
  3ca716:	cmp    $0x1,%rdx
  3ca71a:	jne    3ca726 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x396>
  3ca71c:	vpandq -0x3a3556(%rip){1to8},%zmm0,%zmm0        # 271d0 <GCC_except_table3227+0x160>
  3ca726:	vpsrlvq 0x360(%rsp),%zmm0,%zmm0
  3ca731:	vmovdqa 0xc0(%rsp),%xmm2
  3ca73a:	mov    0x20(%rsp),%rax
  3ca73f:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
  3ca746:	kxnorb %k0,%k0,%k1
  3ca74a:	vpandq 0x320(%rsp),%zmm0,%zmm0
  3ca755:	lea    (%rax,%rcx,8),%rax
  3ca759:	vpsubq %zmm1,%zmm0,%zmm1
  3ca75f:	vpsrlq %xmm2,%zmm0,%zmm0
  3ca765:	vpsrlq $0x1,%zmm1,%zmm1
  3ca76c:	vpsllq %xmm2,%zmm0,%zmm0
  3ca772:	vpsubq %zmm0,%zmm1,%zmm0
  3ca778:	vpxor  %xmm1,%xmm1,%xmm1
  3ca77c:	vpgatherqq 0x8(%rax,%zmm10,8),%zmm1{%k1}
  3ca784:	vpsraq $0x3f,%zmm1,%zmm1
  3ca78b:	vpxorq %zmm1,%zmm0,%zmm0
  3ca791:	jmp    3ca97c <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x5ec>
  3ca796:	cs nopw 0x0(%rax,%rax,1)
  3ca7a0:	mov    %ecx,%edx
  3ca7a2:	and    $0x3f,%dl
  3ca7a5:	bzhi   %rdx,%rsi,%rdx
  3ca7aa:	lea    -0x1(%rcx),%esi
  3ca7ad:	shrx   %rsi,%rdx,%rsi
  3ca7b2:	jmp    3ca7cd <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x43d>
  3ca7b4:	xor    %esi,%esi
  3ca7b6:	lea    0x1(%rcx),%edx
  3ca7b9:	and    $0x3f,%dl
  3ca7bc:	bzhi   %rdx,%rsi,%rsi
  3ca7c1:	lea    0x1(%rsi),%rdx
  3ca7c5:	shrx   %rcx,%rsi,%rsi
  3ca7ca:	shr    $1,%rdx
  3ca7cd:	shlx   %rcx,%rsi,%rcx
  3ca7d2:	add    $0x20,%r11
  3ca7d6:	mov    $0x2,%r14d
  3ca7dc:	sub    %rcx,%rdx
  3ca7df:	mov    %edx,%ecx
  3ca7e1:	neg    %ecx
  3ca7e3:	test   %rax,%rax
  3ca7e6:	cmovns %edx,%ecx
  3ca7e9:	test   %cx,%cx
  3ca7ec:	jne    3ca9c6 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x636>
  3ca7f2:	jmp    3ca5d0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x240>
  3ca7f7:	test   %al,%al
  3ca7f9:	jne    3ca9a2 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x612>
  3ca7ff:	cmpq   $0x8,0x50(%rsp)
  3ca805:	jb     3ca5ec <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x25c>
  3ca80b:	mov    0x60(%rsp),%rax
  3ca810:	mov    0x20(%rsp),%rcx
  3ca815:	kxnorb %k0,%k0,%k1
  3ca819:	vpxor  %xmm0,%xmm0,%xmm0
  3ca81d:	cmpb   $0x0,0xf(%rsp)
  3ca822:	lea    (%rcx,%rax,8),%rax
  3ca826:	mov    0x48(%rsp),%rcx
  3ca82b:	lea    (%rax,%rcx,8),%rcx
  3ca82f:	vpgatherqq (%rcx,%zmm10,8),%zmm0{%k1}
  3ca836:	jne    3ca860 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x4d0>
  3ca838:	kxnorb %k0,%k0,%k1
  3ca83c:	vpxor  %xmm1,%xmm1,%xmm1
  3ca840:	vpgatherqq 0x8(%rax,%zmm10,8),%zmm1{%k1}
  3ca848:	vpandq -0x3a3682(%rip){1to8},%zmm1,%zmm1        # 271d0 <GCC_except_table3227+0x160>
  3ca852:	vpsllq 0x1a0(%rsp),%zmm1,%zmm1
  3ca85a:	vporq  %zmm0,%zmm1,%zmm0
  3ca860:	vpandq 0x320(%rsp),%zmm0,%zmm0
  3ca86b:	vpsrlq 0x1b0(%rsp),%zmm0,%zmm1
  3ca873:	vpsllq 0xc0(%rsp),%zmm1,%zmm1
  3ca87b:	vpsubq %zmm1,%zmm0,%zmm0
  3ca881:	jmp    3ca95f <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x5cf>
  3ca886:	test   %al,%al
  3ca888:	jne    3ca9a2 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x612>
  3ca88e:	cmpq   $0x8,0x50(%rsp)
  3ca894:	jb     3ca5ec <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x25c>
  3ca89a:	cmpq   $0x7f,0x78(%rsp)
  3ca8a0:	mov    0x60(%rsp),%rcx
  3ca8a5:	vpxor  %xmm0,%xmm0,%xmm0
  3ca8a9:	ja     3ca8d8 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x548>
  3ca8ab:	mov    0x20(%rsp),%rax
  3ca8b0:	mov    0x48(%rsp),%rdx
  3ca8b5:	kxnorb %k0,%k0,%k1
  3ca8b9:	lea    (%rax,%rcx,8),%rax
  3ca8bd:	lea    (%rax,%rdx,8),%rax
  3ca8c1:	vpgatherqq (%rax,%zmm10,8),%zmm0{%k1}
  3ca8c8:	cmp    $0x1,%rdx
  3ca8cc:	jne    3ca8d8 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x548>
  3ca8ce:	vpandq -0x3a3708(%rip){1to8},%zmm0,%zmm0        # 271d0 <GCC_except_table3227+0x160>
  3ca8d8:	vpsrlvq 0x360(%rsp),%zmm0,%zmm0
  3ca8e3:	cmpq   $0x0,0x48(%rsp)
  3ca8e9:	jne    3ca91c <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x58c>
  3ca8eb:	mov    0x20(%rsp),%rax
  3ca8f0:	kxnorb %k0,%k0,%k1
  3ca8f4:	vpxor  %xmm1,%xmm1,%xmm1
  3ca8f8:	lea    (%rax,%rcx,8),%rax
  3ca8fc:	vpgatherqq 0x8(%rax,%zmm10,8),%zmm1{%k1}
  3ca904:	vpandq -0x3a373e(%rip){1to8},%zmm1,%zmm1        # 271d0 <GCC_except_table3227+0x160>
  3ca90e:	vpsllq 0x1a0(%rsp),%zmm1,%zmm1
  3ca916:	vporq  %zmm0,%zmm1,%zmm0
  3ca91c:	vpandq 0x320(%rsp),%zmm0,%zmm0
  3ca927:	vmovdqa 0xc0(%rsp),%xmm2
  3ca930:	vpternlogd $0xff,%zmm1,%zmm1,%zmm1
  3ca937:	mov    0x20(%rsp),%rax
  3ca93c:	lea    (%rax,%rcx,8),%rax
  3ca940:	vpsubq %zmm1,%zmm0,%zmm1
  3ca946:	vpsrlq %xmm2,%zmm0,%zmm0
  3ca94c:	vpsrlq $0x1,%zmm1,%zmm1
  3ca953:	vpsllq %xmm2,%zmm0,%zmm0
  3ca959:	vpsubq %zmm0,%zmm1,%zmm0
  3ca95f:	kxnorb %k0,%k0,%k1
  3ca963:	vpxor  %xmm1,%xmm1,%xmm1
  3ca967:	vpgatherqq 0x8(%rax,%zmm10,8),%zmm1{%k1}
  3ca96f:	vpsraq $0x3f,%zmm1,%zmm1
  3ca976:	vpxorq %zmm0,%zmm1,%zmm0
  3ca97c:	addq   $0xfffffffffffffff8,0x50(%rsp)
  3ca982:	addq   $0x100,0x20(%rsp)
  3ca98b:	vpsubq %zmm1,%zmm0,%zmm0
  3ca991:	movq   $0x0,0x70(%rsp)
  3ca99a:	vpmovqw %zmm0,0x260(%rsp)
  3ca9a2:	mov    0x70(%rsp),%rax
  3ca9a7:	mov    $0x1,%r14d
  3ca9ad:	movzwl 0x260(%rsp,%rax,2),%ecx
  3ca9b5:	inc    %rax
  3ca9b8:	mov    %rax,0x70(%rsp)
  3ca9bd:	test   %cx,%cx
  3ca9c0:	je     3ca5d0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x240>
  3ca9c6:	vmovdqu (%r15),%ymm0
  3ca9cb:	vptest %ymm0,%ymm0
  3ca9d0:	jne    3caa00 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x670>
  3ca9d2:	vmovdqu 0x20(%r15),%ymm0
  3ca9d8:	vptest %ymm0,%ymm0
  3ca9dd:	jne    3caa00 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x670>
  3ca9df:	vmovdqu 0x40(%r15),%ymm0
  3ca9e5:	vptest %ymm0,%ymm0
  3ca9ea:	jne    3caa00 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x670>
  3ca9ec:	vmovdqu 0x60(%r15),%ymm0
  3ca9f2:	vptest %ymm0,%ymm0
  3ca9f7:	je     3ca5d0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x240>
  3ca9fd:	nopl   (%rax)
  3caa00:	xor    %edx,%edx
  3caa02:	test   %cx,%cx
  3caa05:	mov    %ecx,%eax
  3caa07:	sets   %r8b
  3caa0b:	neg    %ax
  3caa0e:	cmovs  %cx,%ax
  3caa12:	movzwl %ax,%esi
  3caa15:	mov    0x70(%rbx),%rax
  3caa19:	dec    %rsi
  3caa1c:	mov    %rsi,%rdi
  3caa1f:	shr    $0x6,%rdi
  3caa23:	cmp    %rax,%rdi
  3caa26:	jae    3cb53d <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x11ad>
  3caa2c:	mov    0x68(%rbx),%rcx
  3caa30:	mov    %r8b,%dl
  3caa33:	mov    %esi,%r12d
  3caa36:	shl    $0x1f,%edx
  3caa39:	or     %edx,%r12d
  3caa3c:	mov    (%rcx,%rdi,8),%rdx
  3caa40:	bt     %rsi,%rdx
  3caa44:	jae    3caac0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x730>
  3caa46:	mov    0xa0(%rbx),%rbp
  3caa4d:	cmp    0x90(%rbx),%rbp
  3caa54:	je     3cb13e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xdae>
  3caa5a:	mov    0x98(%rbx),%rax
  3caa61:	mov    %rbp,%rcx
  3caa64:	shl    $0x4,%rcx
  3caa68:	mov    %r12d,(%rax,%rcx,1)
  3caa6c:	mov    %r15,0x8(%rax,%rcx,1)
  3caa71:	lea    0x1(%rbp),%rcx
  3caa75:	mov    %rcx,0xa0(%rbx)
  3caa7c:	cmp    0x108(%rsp),%rbp
  3caa84:	jne    3ca5d0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x240>
  3caa8a:	mov    %rbx,%rdi
  3caa8d:	mov    %r11,%r12
  3caa90:	vzeroupper
  3caa93:	call   3cca50 <<zopro_core::msm_affine::g2_borrowed::Window>::flush_queue>
  3caa98:	vmovdqa64 -0x39e962(%rip),%zmm10        # 2c140 <GCC_except_table3227+0x50d0>
  3caaa2:	mov    0x38(%rsp),%r10
  3caaa7:	vpxor  %xmm9,%xmm9,%xmm9
  3caaac:	mov    %r12,%r11
  3caaaf:	jmp    3ca5d0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x240>
  3caab4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  3caac0:	mov    0x10(%rbx),%rax
  3caac4:	mov    %r14,0x40(%rsp)
  3caac9:	cmp    %rsi,%rax
  3caacc:	jbe    3cb54f <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x11bf>
  3caad2:	mov    0x8(%rbx),%r8
  3caad6:	mov    %rsi,%r9
  3caad9:	shl    $0x7,%r9
  3caadd:	vmovdqu (%r8,%r9,1),%ymm0
  3caae3:	lea    (%r8,%r9,1),%rax
  3caae7:	vptest %ymm0,%ymm0
  3caaec:	jne    3cab20 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x790>
  3caaee:	vmovdqu 0x20(%rax),%ymm0
  3caaf3:	vptest %ymm0,%ymm0
  3caaf8:	jne    3cab20 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x790>
  3caafa:	vmovdqu 0x40(%rax),%ymm0
  3caaff:	vptest %ymm0,%ymm0
  3cab04:	jne    3cab20 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x790>
  3cab06:	vmovdqu 0x60(%rax),%ymm0
  3cab0b:	vptest %ymm0,%ymm0
  3cab10:	je     3cb347 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xfb7>
  3cab16:	cs nopw 0x0(%rax,%rax,1)
  3cab20:	vmovdqu (%rax),%ymm0
  3cab24:	mov    0x40(%rsp),%r14
  3cab29:	vpxor  (%r15),%ymm0,%ymm0
  3cab2e:	vptest %ymm0,%ymm0
  3cab33:	jne    3cab4b <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x7bb>
  3cab35:	vmovdqu 0x20(%rax),%ymm0
  3cab3a:	vpxor  0x20(%r15),%ymm0,%ymm0
  3cab40:	vptest %ymm0,%ymm0
  3cab45:	je     3cb0fe <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xd6e>
  3cab4b:	mov    $0x1,%eax
  3cab50:	shlx   %rsi,%rax,%rax
  3cab55:	or     %rax,%rdx
  3cab58:	mov    %rdx,(%rcx,%rdi,8)
  3cab5c:	mov    0x88(%rbx),%rbp
  3cab63:	cmp    0x78(%rbx),%rbp
  3cab67:	je     3cb317 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xf87>
  3cab6d:	mov    0x80(%rbx),%rax
  3cab74:	mov    %rbp,%rcx
  3cab77:	shl    $0x4,%rcx
  3cab7b:	inc    %rbp
  3cab7e:	mov    %r12d,(%rax,%rcx,1)
  3cab82:	mov    %r15,0x8(%rax,%rcx,1)
  3cab87:	mov    %rbp,0x88(%rbx)
  3cab8e:	mov    0x3f0(%rsp),%rax
  3cab96:	cmp    %rax,0x88(%rbx)
  3cab9d:	jne    3ca5d0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x240>
  3caba3:	mov    %rbx,%rdi
  3caba6:	mov    %r11,0x68(%rsp)
  3cabab:	vzeroupper
  3cabae:	call   3cc5e0 <<zopro_core::msm_affine::g2_borrowed::Window>::execute>
  3cabb3:	mov    0xa0(%rbx),%rdx
  3cabba:	mov    $0x1,%r10d
  3cabc0:	test   %rdx,%rdx
  3cabc3:	jne    3cac1a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x88a>
  3cabc5:	jmp    3ca5b2 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x222>
  3cabca:	nopw   0x0(%rax,%rax,1)
  3cabd0:	shlx   %rsi,%r10,%rax
  3cabd5:	or     %rax,(%rcx,%rdi,8)
  3cabd9:	mov    0x88(%rbx),%r13
  3cabe0:	cmp    0x78(%rbx),%r13
  3cabe4:	je     3caf0d <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb7d>
  3cabea:	mov    0x80(%rbx),%rax
  3cabf1:	mov    %r13,%rcx
  3cabf4:	shl    $0x4,%rcx
  3cabf8:	inc    %r13
  3cabfb:	mov    %ebp,(%rax,%rcx,1)
  3cabfe:	mov    %r12,0x8(%rax,%rcx,1)
  3cac03:	mov    %r13,0x88(%rbx)
  3cac0a:	mov    0xa0(%rbx),%rdx
  3cac11:	test   %rdx,%rdx
  3cac14:	je     3ca5b2 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x222>
  3cac1a:	mov    0x98(%rbx),%r8
  3cac21:	dec    %rdx
  3cac24:	mov    0x70(%rbx),%rax
  3cac28:	mov    %rdx,%r9
  3cac2b:	shl    $0x4,%r9
  3cac2f:	mov    (%r8,%r9,1),%ebp
  3cac33:	mov    %ebp,%esi
  3cac35:	and    $0x7fffffff,%esi
  3cac3b:	mov    %esi,%edi
  3cac3d:	shr    $0x6,%edi
  3cac40:	cmp    %rax,%rdi
  3cac43:	jae    3cb53d <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x11ad>
  3cac49:	mov    0x68(%rbx),%rcx
  3cac4d:	mov    (%rcx,%rdi,8),%rax
  3cac51:	bt     %rsi,%rax
  3cac55:	jb     3ca5b2 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x222>
  3cac5b:	mov    0x8(%r8,%r9,1),%r12
  3cac60:	mov    %rdx,0xa0(%rbx)
  3cac67:	mov    0x10(%rbx),%rax
  3cac6b:	cmp    %rsi,%rax
  3cac6e:	jbe    3cb54f <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x11bf>
  3cac74:	mov    0x8(%rbx),%rdx
  3cac78:	mov    %rsi,%r8
  3cac7b:	shl    $0x7,%r8
  3cac7f:	vmovdqu (%rdx,%r8,1),%ymm0
  3cac85:	lea    (%rdx,%r8,1),%rax
  3cac89:	vptest %ymm0,%ymm0
  3cac8e:	jne    3cacc0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x930>
  3cac90:	vmovdqu 0x20(%rax),%ymm0
  3cac95:	vptest %ymm0,%ymm0
  3cac9a:	jne    3cacc0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x930>
  3cac9c:	vmovdqu 0x40(%rax),%ymm0
  3caca1:	vptest %ymm0,%ymm0
  3caca6:	jne    3cacc0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x930>
  3caca8:	vmovdqu 0x60(%rax),%ymm0
  3cacad:	vptest %ymm0,%ymm0
  3cacb2:	je     3caf24 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb94>
  3cacb8:	nopl   0x0(%rax,%rax,1)
  3cacc0:	vmovdqu (%rax),%ymm0
  3cacc4:	vpxor  (%r12),%ymm0,%ymm0
  3cacca:	vptest %ymm0,%ymm0
  3caccf:	jne    3cabd0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x840>
  3cacd5:	vmovdqu 0x20(%rax),%ymm0
  3cacda:	vpxor  0x20(%r12),%ymm0,%ymm0
  3cace1:	vptest %ymm0,%ymm0
  3cace6:	jne    3cabd0 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x840>
  3cacec:	test   %ebp,%ebp
  3cacee:	js     3cad33 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x9a3>
  3cacf0:	vmovups (%r12),%zmm0
  3cacf7:	vmovdqu64 0x40(%r12),%zmm1
  3cacff:	vmovdqu64 %zmm1,0x160(%rsp)
  3cad0a:	vmovups %zmm0,0x120(%rsp)
  3cad15:	vmovdqu 0x40(%rax),%ymm0
  3cad1a:	vpxor  0x160(%rsp),%ymm0,%ymm0
  3cad23:	vptest %ymm0,%ymm0
  3cad28:	jne    3caef7 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb67>
  3cad2e:	jmp    3caee2 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb52>
  3cad33:	vmovups 0x40(%r12),%ymm0
  3cad3a:	vmovdqu -0x39d042(%rip),%ymm2        # 2dd00 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3cad42:	movq   $0x0,0x30(%rsp)
  3cad4b:	movq   $0x0,0x10(%rsp)
  3cad54:	movq   $0x0,0x18(%rsp)
  3cad5d:	movq   $0x0,0x28(%rsp)
  3cad66:	mov    %r15,0x58(%rsp)
  3cad6b:	lea    0xd0(%rsp),%rcx
  3cad73:	lea    0x80(%rsp),%rdx
  3cad7b:	mov    0x30(%rsp),%rdi
  3cad80:	mov    0x10(%rsp),%r14
  3cad85:	mov    0x18(%rsp),%r8
  3cad8a:	mov    0x28(%rsp),%r15
  3cad8f:	vmovups %ymm0,0xd0(%rsp)
  3cad98:	vmovdqu %ymm2,0x80(%rsp)
  3cada1:	sub    (%rcx),%rdi
  3cada4:	sbb    0x8(%rcx),%r14
  3cada8:	sbb    0x10(%rcx),%r8
  3cadac:	sbb    0x18(%rcx),%r15
  3cadb0:	sbb    %r13,%r13
  3cadb3:	mov    (%rdx),%r9
  3cadb6:	mov    0x8(%rdx),%r10
  3cadba:	mov    0x10(%rdx),%r11
  3cadbe:	mov    0x18(%rdx),%rbp
  3cadc2:	and    %r13,%r9
  3cadc5:	and    %r13,%r10
  3cadc8:	and    %r13,%r11
  3cadcb:	and    %r13,%rbp
  3cadce:	add    %r9,%rdi
  3cadd1:	adc    %r10,%r14
  3cadd4:	adc    %r11,%r8
  3cadd7:	adc    %rbp,%r15
  3cadda:	mov    %r15,0x28(%rsp)
  3caddf:	mov    %r8,0x18(%rsp)
  3cade4:	mov    %r14,0x10(%rsp)
  3cade9:	mov    %rdi,0x30(%rsp)
  3cadee:	xor    %r15d,%r15d
  3cadf1:	xor    %r10d,%r10d
  3cadf4:	xor    %r11d,%r11d
  3cadf7:	xor    %r13d,%r13d
  3cadfa:	lea    0xd0(%rsp),%r8
  3cae02:	lea    0x80(%rsp),%r9
  3cae0a:	vmovdqu 0x60(%r12),%ymm1
  3cae11:	vmovdqu %ymm2,0x80(%rsp)
  3cae1a:	vmovdqu %ymm1,0xd0(%rsp)
  3cae23:	sub    (%r8),%r10
  3cae26:	sbb    0x8(%r8),%r11
  3cae2a:	sbb    0x10(%r8),%r13
  3cae2e:	sbb    0x18(%r8),%r15
  3cae32:	sbb    %rdi,%rdi
  3cae35:	mov    (%r9),%rbp
  3cae38:	mov    0x8(%r9),%r14
  3cae3c:	mov    0x10(%r9),%rcx
  3cae40:	mov    0x18(%r9),%rdx
  3cae44:	and    %rdi,%rbp
  3cae47:	and    %rdi,%r14
  3cae4a:	and    %rdi,%rcx
  3cae4d:	and    %rdi,%rdx
  3cae50:	add    %rbp,%r10
  3cae53:	adc    %r14,%r11
  3cae56:	adc    %rcx,%r13
  3cae59:	adc    %rdx,%r15
  3cae5c:	vmovups (%r12),%zmm0
  3cae63:	mov    0x30(%rsp),%rcx
  3cae68:	mov    0x10(%rsp),%rdx
  3cae6d:	mov    0x18(%rsp),%rdi
  3cae72:	vmovups %zmm0,0x120(%rsp)
  3cae7d:	mov    %rcx,0x160(%rsp)
  3cae85:	mov    %rdx,0x168(%rsp)
  3cae8d:	mov    0x28(%rsp),%rdx
  3cae92:	mov    %rdi,0x170(%rsp)
  3cae9a:	mov    %rdx,0x178(%rsp)
  3caea2:	mov    %r10,0x180(%rsp)
  3caeaa:	mov    %r11,0x188(%rsp)
  3caeb2:	mov    %r13,0x190(%rsp)
  3caeba:	mov    %r15,0x198(%rsp)
  3caec2:	mov    0x58(%rsp),%r15
  3caec7:	mov    $0x1,%r10d
  3caecd:	vmovdqu 0x40(%rax),%ymm0
  3caed2:	vpxor  0x160(%rsp),%ymm0,%ymm0
  3caedb:	vptest %ymm0,%ymm0
  3caee0:	jne    3caef7 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xb67>
  3caee2:	vmovdqu 0x60(%rax),%ymm0
  3caee7:	vpxor  0x180(%rsp),%ymm0,%ymm0
  3caef0:	vptest %ymm0,%ymm0
  3caef5:	je     3caf44 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xbb4>
  3caef7:	vpxor  %xmm0,%xmm0,%xmm0
  3caefb:	vmovdqu64 %zmm0,0x40(%rax)
  3caf02:	vmovdqu64 %zmm0,(%rax)
  3caf08:	jmp    3cac0a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x87a>
  3caf0d:	lea    0x78(%rbx),%rdi
  3caf11:	vzeroupper
  3caf14:	call   214340 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3caf19:	mov    $0x1,%r10d
  3caf1f:	jmp    3cabea <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x85a>
  3caf24:	test   %ebp,%ebp
  3caf26:	js     3caf62 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xbd2>
  3caf28:	vmovups (%r12),%zmm0
  3caf2f:	vmovups %zmm0,0x80(%rsp)
  3caf37:	vmovdqu64 0x40(%r12),%zmm0
  3caf3f:	jmp    3cb0e4 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xd54>
  3caf44:	lea    0x120(%rsp),%rdx
  3caf4c:	mov    %rbx,%rdi
  3caf4f:	vzeroupper
  3caf52:	call   3ccc70 <<zopro_core::msm_affine::g2_borrowed::Window>::projective>
  3caf57:	mov    $0x1,%r10d
  3caf5d:	jmp    3cac0a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x87a>
  3caf62:	lea    0x40(%r12),%rcx
  3caf67:	vmovdqu -0x39d26f(%rip),%ymm10        # 2dd00 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3caf6f:	xor    %r14d,%r14d
  3caf72:	xor    %edx,%edx
  3caf74:	xor    %esi,%esi
  3caf76:	xor    %edi,%edi
  3caf78:	lea    0x80(%rsp),%r13
  3caf80:	vmovups (%rcx),%ymm0
  3caf84:	lea    0xd0(%rsp),%rcx
  3caf8c:	vmovdqu %ymm10,0x80(%rsp)
  3caf95:	vmovups %ymm0,0xd0(%rsp)
  3caf9e:	sub    (%rcx),%r14
  3cafa1:	sbb    0x8(%rcx),%rdx
  3cafa5:	sbb    0x10(%rcx),%rsi
  3cafa9:	sbb    0x18(%rcx),%rdi
  3cafad:	sbb    %rbp,%rbp
  3cafb0:	mov    0x0(%r13),%r8
  3cafb4:	mov    0x8(%r13),%r9
  3cafb8:	mov    0x10(%r13),%r10
  3cafbc:	mov    0x18(%r13),%r11
  3cafc0:	and    %rbp,%r8
  3cafc3:	and    %rbp,%r9
  3cafc6:	and    %rbp,%r10
  3cafc9:	and    %rbp,%r11
  3cafcc:	add    %r8,%r14
  3cafcf:	adc    %r9,%rdx
  3cafd2:	adc    %r10,%rsi
  3cafd5:	adc    %r11,%rdi
  3cafd8:	mov    %rsi,0x58(%rsp)
  3cafdd:	mov    %rdx,0x28(%rsp)
  3cafe2:	movq   $0x0,0x18(%rsp)
  3cafeb:	mov    %rdi,0xf8(%rsp)
  3caff3:	movq   $0x0,0x10(%rsp)
  3caffc:	mov    %r14,0x30(%rsp)
  3cb001:	xor    %esi,%esi
  3cb003:	xor    %edx,%edx
  3cb005:	lea    0x80(%rsp),%r10
  3cb00d:	lea    0xd0(%rsp),%r8
  3cb015:	vmovups 0x60(%r12),%ymm1
  3cb01c:	vmovdqu %ymm10,0x80(%rsp)
  3cb025:	mov    0x18(%rsp),%r11
  3cb02a:	mov    0x10(%rsp),%rdi
  3cb02f:	vmovups %ymm1,0xd0(%rsp)
  3cb038:	sub    (%r8),%rsi
  3cb03b:	sbb    0x8(%r8),%rdx
  3cb03f:	sbb    0x10(%r8),%rdi
  3cb043:	sbb    0x18(%r8),%r11
  3cb047:	sbb    %r9,%r9
  3cb04a:	mov    (%r10),%rbp
  3cb04d:	mov    0x8(%r10),%r14
  3cb051:	mov    0x10(%r10),%r13
  3cb055:	mov    0x18(%r10),%rcx
  3cb059:	and    %r9,%rbp
  3cb05c:	and    %r9,%r14
  3cb05f:	and    %r9,%r13
  3cb062:	and    %r9,%rcx
  3cb065:	add    %rbp,%rsi
  3cb068:	adc    %r14,%rdx
  3cb06b:	adc    %r13,%rdi
  3cb06e:	adc    %rcx,%r11
  3cb071:	mov    %rdi,0x10(%rsp)
  3cb076:	mov    %r11,0x18(%rsp)
  3cb07b:	vmovq  %rdx,%xmm7
  3cb080:	vmovq  %rsi,%xmm8
  3cb085:	mov    $0x1,%r10d
  3cb08b:	vmovq  0xf8(%rsp),%xmm1
  3cb094:	vmovq  0x58(%rsp),%xmm2
  3cb09a:	vmovq  0x28(%rsp),%xmm3
  3cb0a0:	vmovq  0x30(%rsp),%xmm4
  3cb0a6:	vmovups (%r12),%zmm0
  3cb0ad:	vmovq  0x18(%rsp),%xmm5
  3cb0b3:	vmovq  0x10(%rsp),%xmm6
  3cb0b9:	vpunpcklqdq %xmm1,%xmm2,%xmm9
  3cb0bd:	vpunpcklqdq %xmm3,%xmm4,%xmm1
  3cb0c1:	vmovups %zmm0,0x80(%rsp)
  3cb0c9:	vpunpcklqdq %xmm7,%xmm8,%xmm2
  3cb0cd:	vinserti128 $0x1,%xmm9,%ymm1,%ymm0
  3cb0d3:	vpunpcklqdq %xmm5,%xmm6,%xmm1
  3cb0d7:	vinserti128 $0x1,%xmm1,%ymm2,%ymm1
  3cb0dd:	vinserti64x4 $0x1,%ymm1,%zmm0,%zmm0
  3cb0e4:	vmovdqu64 0x80(%rsp),%zmm1
  3cb0ec:	vmovdqu64 %zmm1,(%rax)
  3cb0f2:	vmovdqu64 %zmm0,0x40(%rax)
  3cb0f9:	jmp    3cac0a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x87a>
  3cb0fe:	test   %r12d,%r12d
  3cb101:	js     3cb16c <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xddc>
  3cb103:	vmovups (%r15),%zmm0
  3cb109:	vmovdqu64 0x40(%r15),%zmm1
  3cb110:	vmovdqu64 %zmm1,0x200(%rsp)
  3cb118:	vmovups %zmm0,0x1c0(%rsp)
  3cb120:	vmovdqu 0x40(%rax),%ymm0
  3cb125:	vpxor  0x200(%rsp),%ymm0,%ymm0
  3cb12e:	vptest %ymm0,%ymm0
  3cb133:	jne    3cb301 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xf71>
  3cb139:	jmp    3cb2ec <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xf5c>
  3cb13e:	lea    0x90(%rbx),%rdi
  3cb145:	mov    %r11,%r13
  3cb148:	vzeroupper
  3cb14b:	call   214340 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3cb150:	vmovdqa64 -0x39f01a(%rip),%zmm10        # 2c140 <GCC_except_table3227+0x50d0>
  3cb15a:	mov    0x38(%rsp),%r10
  3cb15f:	vpxor  %xmm9,%xmm9,%xmm9
  3cb164:	mov    %r13,%r11
  3cb167:	jmp    3caa5a <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x6ca>
  3cb16c:	vmovups 0x40(%r15),%ymm0
  3cb172:	vmovdqu -0x39d47a(%rip),%ymm2        # 2dd00 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3cb17a:	mov    %r11,0x68(%rsp)
  3cb17f:	xor    %r14d,%r14d
  3cb182:	xor    %edx,%edx
  3cb184:	xor    %edi,%edi
  3cb186:	xor    %r8d,%r8d
  3cb189:	lea    0x80(%rsp),%r13
  3cb191:	lea    0x120(%rsp),%rcx
  3cb199:	vmovups %ymm0,0x80(%rsp)
  3cb1a2:	vmovdqu %ymm2,0x120(%rsp)
  3cb1ab:	sub    0x0(%r13),%r14
  3cb1af:	sbb    0x8(%r13),%rdx
  3cb1b3:	sbb    0x10(%r13),%rdi
  3cb1b7:	sbb    0x18(%r13),%r8
  3cb1bb:	sbb    %r12,%r12
  3cb1be:	mov    (%rcx),%r9
  3cb1c1:	mov    0x8(%rcx),%r10
  3cb1c5:	mov    0x10(%rcx),%r11
  3cb1c9:	mov    0x18(%rcx),%rbp
  3cb1cd:	and    %r12,%r9
  3cb1d0:	and    %r12,%r10
  3cb1d3:	and    %r12,%r11
  3cb1d6:	and    %r12,%rbp
  3cb1d9:	add    %r9,%r14
  3cb1dc:	adc    %r10,%rdx
  3cb1df:	adc    %r11,%rdi
  3cb1e2:	adc    %rbp,%r8
  3cb1e5:	mov    %r14,0x28(%rsp)
  3cb1ea:	mov    %r8,0x30(%rsp)
  3cb1ef:	mov    %rdx,0x10(%rsp)
  3cb1f4:	mov    %rdi,0x18(%rsp)
  3cb1f9:	vmovdqu %ymm2,0x120(%rsp)
  3cb202:	xor    %r9d,%r9d
  3cb205:	xor    %r10d,%r10d
  3cb208:	xor    %r11d,%r11d
  3cb20b:	xor    %r12d,%r12d
  3cb20e:	lea    0x80(%rsp),%r8
  3cb216:	lea    0x120(%rsp),%r14
  3cb21e:	vmovdqu 0x60(%r15),%ymm1
  3cb224:	vmovdqu %ymm1,0x80(%rsp)
  3cb22d:	sub    (%r8),%r9
  3cb230:	sbb    0x8(%r8),%r10
  3cb234:	sbb    0x10(%r8),%r11
  3cb238:	sbb    0x18(%r8),%r12
  3cb23c:	sbb    %rdi,%rdi
  3cb23f:	mov    (%r14),%rbp
  3cb242:	mov    0x8(%r14),%r13
  3cb246:	mov    0x10(%r14),%rcx
  3cb24a:	mov    0x18(%r14),%rdx
  3cb24e:	and    %rdi,%rbp
  3cb251:	and    %rdi,%r13
  3cb254:	and    %rdi,%rcx
  3cb257:	and    %rdi,%rdx
  3cb25a:	add    %rbp,%r9
  3cb25d:	adc    %r13,%r10
  3cb260:	adc    %rcx,%r11
  3cb263:	adc    %rdx,%r12
  3cb266:	vmovups (%r15),%zmm0
  3cb26c:	mov    0x28(%rsp),%rcx
  3cb271:	mov    0x10(%rsp),%rdx
  3cb276:	mov    0x18(%rsp),%rdi
  3cb27b:	mov    0x40(%rsp),%r14
  3cb280:	vmovups %zmm0,0x1c0(%rsp)
  3cb288:	mov    %rcx,0x200(%rsp)
  3cb290:	mov    %rdx,0x208(%rsp)
  3cb298:	mov    0x30(%rsp),%rdx
  3cb29d:	mov    %rdi,0x210(%rsp)
  3cb2a5:	mov    %rdx,0x218(%rsp)
  3cb2ad:	mov    %r9,0x220(%rsp)
  3cb2b5:	mov    %r10,0x228(%rsp)
  3cb2bd:	mov    %r11,0x230(%rsp)
  3cb2c5:	mov    0x38(%rsp),%r10
  3cb2ca:	mov    0x68(%rsp),%r11
  3cb2cf:	mov    %r12,0x238(%rsp)
  3cb2d7:	vmovdqu 0x40(%rax),%ymm0
  3cb2dc:	vpxor  0x200(%rsp),%ymm0,%ymm0
  3cb2e5:	vptest %ymm0,%ymm0
  3cb2ea:	jne    3cb301 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xf71>
  3cb2ec:	vmovdqu 0x60(%rax),%ymm0
  3cb2f1:	vpxor  0x220(%rsp),%ymm0,%ymm0
  3cb2fa:	vptest %ymm0,%ymm0
  3cb2ff:	je     3cb36e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0xfde>
  3cb301:	vpxor  %xmm0,%xmm0,%xmm0
  3cb305:	vmovdqu64 %zmm0,0x40(%rax)
  3cb30c:	vmovdqu64 %zmm0,(%rax)
  3cb312:	jmp    3cab8e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x7fe>
  3cb317:	lea    0x78(%rbx),%rdi
  3cb31b:	mov    %r11,%r13
  3cb31e:	vzeroupper
  3cb321:	call   214340 <<alloc::raw_vec::RawVec<zopro_core::preparation::Reservation>>::grow_one>
  3cb326:	vmovdqa64 -0x39f1f0(%rip),%zmm10        # 2c140 <GCC_except_table3227+0x50d0>
  3cb330:	mov    0x40(%rsp),%r14
  3cb335:	mov    0x38(%rsp),%r10
  3cb33a:	vpxor  %xmm9,%xmm9,%xmm9
  3cb33f:	mov    %r13,%r11
  3cb342:	jmp    3cab6d <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x7dd>
  3cb347:	mov    0x40(%rsp),%r14
  3cb34c:	test   %r12d,%r12d
  3cb34f:	js     3cb3a5 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x1015>
  3cb351:	vmovups (%r15),%zmm0
  3cb357:	vmovups %zmm0,0x120(%rsp)
  3cb362:	vmovdqu64 0x40(%r15),%zmm0
  3cb369:	jmp    3cb4e3 <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x1153>
  3cb36e:	lea    0x1c0(%rsp),%rdx
  3cb376:	mov    %rbx,%rdi
  3cb379:	mov    %r11,%r12
  3cb37c:	vzeroupper
  3cb37f:	call   3ccc70 <<zopro_core::msm_affine::g2_borrowed::Window>::projective>
  3cb384:	vmovdqa64 -0x39f24e(%rip),%zmm10        # 2c140 <GCC_except_table3227+0x50d0>
  3cb38e:	mov    0x40(%rsp),%r14
  3cb393:	mov    0x38(%rsp),%r10
  3cb398:	vpxor  %xmm9,%xmm9,%xmm9
  3cb39d:	mov    %r12,%r11
  3cb3a0:	jmp    3cab8e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x7fe>
  3cb3a5:	lea    0x40(%r15),%rcx
  3cb3a9:	xor    %edx,%edx
  3cb3ab:	xor    %esi,%esi
  3cb3ad:	xor    %edi,%edi
  3cb3af:	mov    %r11,%r12
  3cb3b2:	lea    0x80(%rsp),%r14
  3cb3ba:	lea    0x120(%rsp),%r13
  3cb3c2:	vmovups (%rcx),%ymm0
  3cb3c6:	xor    %ecx,%ecx
  3cb3c8:	vmovups %ymm0,0x80(%rsp)
  3cb3d1:	vmovups -0x39d6d9(%rip),%ymm0        # 2dd00 <<serde_json::value::Value as core::ops::index::Index<_>>::index::NULL+0xe0>
  3cb3d9:	vmovups %ymm0,0x120(%rsp)
  3cb3e2:	sub    (%r14),%rcx
  3cb3e5:	sbb    0x8(%r14),%rdx
  3cb3e9:	sbb    0x10(%r14),%rsi
  3cb3ed:	sbb    0x18(%r14),%rdi
  3cb3f1:	sbb    %rbp,%rbp
  3cb3f4:	mov    0x0(%r13),%r8
  3cb3f8:	mov    0x8(%r13),%r9
  3cb3fc:	mov    0x10(%r13),%r10
  3cb400:	mov    0x18(%r13),%r11
  3cb404:	and    %rbp,%r8
  3cb407:	and    %rbp,%r9
  3cb40a:	and    %rbp,%r10
  3cb40d:	and    %rbp,%r11
  3cb410:	add    %r8,%rcx
  3cb413:	adc    %r9,%rdx
  3cb416:	adc    %r10,%rsi
  3cb419:	adc    %r11,%rdi
  3cb41c:	vmovups %ymm0,0x120(%rsp)
  3cb425:	xor    %r8d,%r8d
  3cb428:	xor    %r9d,%r9d
  3cb42b:	xor    %r10d,%r10d
  3cb42e:	xor    %r11d,%r11d
  3cb431:	vmovq  %rdi,%xmm0
  3cb436:	vmovq  %rdx,%xmm2
  3cb43b:	vmovq  %rcx,%xmm3
  3cb440:	vmovups 0x60(%r15),%ymm1
  3cb446:	vmovups %ymm1,0x80(%rsp)
  3cb44f:	vmovq  %rsi,%xmm1
  3cb454:	sub    (%r14),%r8
  3cb457:	sbb    0x8(%r14),%r9
  3cb45b:	sbb    0x10(%r14),%r10
  3cb45f:	sbb    0x18(%r14),%r11
  3cb463:	sbb    %rbp,%rbp
  3cb466:	mov    0x0(%r13),%rcx
  3cb46a:	mov    0x8(%r13),%rdx
  3cb46e:	mov    0x10(%r13),%rsi
  3cb472:	mov    0x18(%r13),%rdi
  3cb476:	and    %rbp,%rcx
  3cb479:	and    %rbp,%rdx
  3cb47c:	and    %rbp,%rsi
  3cb47f:	and    %rbp,%rdi
  3cb482:	add    %rcx,%r8
  3cb485:	adc    %rdx,%r9
  3cb488:	adc    %rsi,%r10
  3cb48b:	adc    %rdi,%r11
  3cb48e:	vmovq  %r10,%xmm5
  3cb493:	vmovq  %r11,%xmm4
  3cb498:	vpunpcklqdq %xmm0,%xmm1,%xmm0
  3cb49c:	vpunpcklqdq %xmm2,%xmm3,%xmm1
  3cb4a0:	vmovq  %r9,%xmm6
  3cb4a5:	vmovq  %r8,%xmm7
  3cb4aa:	mov    %r12,%r11
  3cb4ad:	vmovdqu64 (%r15),%zmm8
  3cb4b3:	mov    0x38(%rsp),%r10
  3cb4b8:	mov    0x40(%rsp),%r14
  3cb4bd:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
  3cb4c3:	vpunpcklqdq %xmm4,%xmm5,%xmm1
  3cb4c7:	vpunpcklqdq %xmm6,%xmm7,%xmm2
  3cb4cb:	vinserti128 $0x1,%xmm1,%ymm2,%ymm1
  3cb4d1:	vinserti64x4 $0x1,%ymm1,%zmm0,%zmm0
  3cb4d8:	vmovdqu64 %zmm8,0x120(%rsp)
  3cb4e3:	vmovdqu64 0x120(%rsp),%zmm1
  3cb4ee:	vmovdqu64 %zmm1,(%rax)
  3cb4f4:	vmovdqu64 %zmm0,0x40(%rax)
  3cb4fb:	jmp    3cab8e <<zopro_core::msm_affine::g2_borrowed::Window>::feed+0x7fe>
  3cb500:	mov    %rbx,%rdi
  3cb503:	vzeroupper
  3cb506:	call   3cc5e0 <<zopro_core::msm_affine::g2_borrowed::Window>::execute>
  3cb50b:	mov    %rbx,%rdi
  3cb50e:	call   3cca50 <<zopro_core::msm_affine::g2_borrowed::Window>::flush_queue>
  3cb513:	add    $0x3a8,%rsp
  3cb51a:	pop    %rbx
  3cb51b:	pop    %r12
  3cb51d:	pop    %r13
  3cb51f:	pop    %r14
  3cb521:	pop    %r15
  3cb523:	pop    %rbp
  3cb524:	ret
  3cb525:	lea    -0x3956d4(%rip),%rdi        # 35e58 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0xcdc>
  3cb52c:	lea    0x12ce35(%rip),%rdx        # 4f8368 <__frame_dummy_init_array_entry+0x4308>
  3cb533:	mov    $0x2b,%esi
  3cb538:	call   1043e0 <core::panicking::panic>
  3cb53d:	lea    0x12cdc4(%rip),%rdx        # 4f8308 <__frame_dummy_init_array_entry+0x42a8>
  3cb544:	mov    %rax,%rsi
  3cb547:	vzeroupper
  3cb54a:	call   1033bb <core::panicking::panic_bounds_check>
  3cb54f:	lea    0x12cdca(%rip),%rdx        # 4f8320 <__frame_dummy_init_array_entry+0x42c0>
  3cb556:	mov    %rsi,%rdi
  3cb559:	mov    %rax,%rsi
  3cb55c:	vzeroupper
  3cb55f:	call   1033bb <core::panicking::panic_bounds_check>
