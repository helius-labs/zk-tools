#[path = "booth_packets.rs"]
mod booth_packets;
use booth_packets::Plan;

fn oracle(row: &[u64; 4], start: usize, width: usize, component: Option<bool>) -> i16 {
    let base = usize::from(component == Some(true)) * 2;
    let count = if component.is_some() { 127 } else { 256 };
    let bit = |i: usize| -> i64 {
        if i >= count { 0 } else { ((row[base + i / 64] >> (i % 64)) & 1) as i64 }
    };
    let unsigned = (0..width).map(|i| bit(start + i) << i).sum::<i64>();
    let incoming = if start == 0 { 0 } else { bit(start - 1) };
    let d = unsigned + incoming - (bit(start + width - 1) << width);
    (if component.is_some() && row[base + 1] >> 63 != 0 { -d } else { d }) as i16
}

fn add(sum: &mut [u64; 5], digit: i16, start: usize) {
    let mut term = [0u64; 5];
    let word = start / 64;
    let shift = start % 64;
    term[word] = (digit.unsigned_abs() as u64) << shift;
    if shift != 0 && word + 1 < 5 {
        term[word + 1] = (digit.unsigned_abs() as u64) >> (64 - shift);
    }
    if digit >= 0 {
        let mut carry = 0u128;
        for i in 0..5 { let n = sum[i] as u128 + term[i] as u128 + carry; sum[i] = n as u64; carry = n >> 64; }
    } else {
        let mut borrow = false;
        for i in 0..5 { let (n,b) = sum[i].overflowing_sub(term[i]); let (n,c) = n.overflowing_sub(u64::from(borrow)); sum[i]=n; borrow=b||c; }
    }
}

fn population() -> Vec<[u64; 4]> {
    let mut rows = vec![[0;4], [u64::MAX;4], [0,1<<63,0,1<<63], [1,0,1,0]];
    for bit in 0..256 {
        let mut row = [0u64;4]; row[bit/64] = 1u64<<(bit%64);
        rows.push(row);
        let mut below = row; let mut borrow = true;
        for w in &mut below { let (v,b)=w.overflowing_sub(u64::from(borrow)); *w=v; borrow=b; }
        rows.push(below);
        let mut above=row; let mut carry=true;
        for w in &mut above { let(v,c)=w.overflowing_add(u64::from(carry));*w=v;carry=c; }
        rows.push(above);
    }
    let mut seed = 0x8f3a62da4c9b710du64;
    for _ in 0..4096 { rows.push(core::array::from_fn(|_| { seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;seed })); }
    rows
}

#[test]
fn packet_digits_match_independent_bits_and_reconstruct_exact_integers() {
    assert!(std::arch::is_x86_feature_detected!("avx512f"));
    let rows=population(); let mut comparisons=0usize; let mut reconstructions=0usize;
    for component in [None,Some(false),Some(true)] {
        let cover=if component.is_some(){127usize}else{256usize};
        for width in 1..=15usize {
            let mut sums=vec![[0u64;5];rows.len()];
            for w in 0..=cover.div_ceil(width) {
                let start=w*width;
                let got=Plan::new(start,width,component).digits(&rows,|s|oracle(s,start,width,component)).collect::<Vec<_>>();
                assert_eq!(got.len(),rows.len());
                for (i,(row,&d)) in rows.iter().zip(&got).enumerate() {
                    assert_eq!(d,oracle(row,start,width,component),"component={component:?}/width={width}/start={start}/i={i}");
                    add(&mut sums[i],d,start); comparisons+=1;
                }
            }
            for (row,sum) in rows.iter().zip(&sums) {
                let mut expected=[0u64;5];
                if let Some(high)=component {
                    let base=usize::from(high)*2;expected[0]=row[base];expected[1]=row[base+1]&i64::MAX as u64;
                    if row[base+1]>>63!=0 { let mut carry=true; for word in &mut expected {let(v,c)=(!*word).overflowing_add(u64::from(carry));*word=v;carry=c;} }
                } else { expected[..4].copy_from_slice(row); }
                assert_eq!(*sum,expected); reconstructions+=1;
            }
        }
    }
    println!("SIMD_BOOTH comparisons={comparisons} exact_320bit_reconstructions={reconstructions} population={}",rows.len());
}

#[test]
fn packet_tails_and_variable_balanced_spans_preserve_length_and_inputs() {
    let rows=population();let original=rows.clone();let mut comparisons=0usize;
    for n in 0..=33usize {
        for span in 0..20 {
            let start=span*255/20;let width=(span+1)*255/20-start;
            let got=Plan::new(start,width,None).digits(&rows[..n],|s|oracle(s,start,width,None)).collect::<Vec<_>>();
            assert_eq!(got.len(),n);
            for(i,&d)in got.iter().enumerate(){assert_eq!(d,oracle(&rows[i],start,width,None));comparisons+=1;}
        }
    }
    assert_eq!(rows,original);
    println!("SIMD_BOOTH variable_span_tail_comparisons={comparisons} lengths=0..33 input_unchanged=true");
}
