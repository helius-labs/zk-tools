# Preparation and review exceptions

The first direct retained-xtask launch returned1 while parsing plan.json:
`xtask: missing field version at line535 column1` (formatting normalized here).
No workflow command ran and the requested runs directory was not created.
The tool-call output is the original record; it was not redirected to a file.
plan.json remains unchanged. plan-v1.json differs only by version:1, independently
checked by the reviewer. All seven native steps then succeeded once in runs-v1.

All eight coherent SDK build/symbol steps succeeded once in sdk-runs.

The first direct offline review returned101 at review.rs:18. It incorrectly
expected CARGO_MANIFEST_DIR in command.json. xtask supplies the plan environment
to the process but intentionally receipts only managed performance variables;
CARGO_MANIFEST_DIR/CARGO_PKG_NAME/CARGO_PKG_VERSION are not managed. The original
review source and captured stdout/stderr remain exact. review-v2.rs checks the
applicable managed variables, keeping all argv, hashes, source recovery, tests,
link, ledger and emitted-code checks unchanged. Its one execution returned0.
No successful build, test, link, symbol listing or measurement was repeated.

The direct helper compiles are outside the15 workflow-command count. Four
pre-publication helper builds (prepare, prepare-sdk, review, review-v2) succeeded;
publication compilation is also direct. Compiler warnings in native/portable
core builds are retained without warning-only rebuilds.

This stage records no SDK request, proving time, PMU/profile capture or fresh
Gnark export. Correctness qualification is not a performance result.
