use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::Path,process::Command};
const R:&str="/home/ubuntu/src/zopro-perf-work/simd-booth176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(n:&str,v:&Value){let p=format!("{R}/{n}");assert!(!Path::new(&p).exists());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn main(){
    assert!(!Path::new(&format!("{R}/review-result.json")).exists());
    let mut commands=0;let mut pin_occurrences=0;
    for (plan,folder)in[("plan-v1.json","runs-v1"),("sdk-plan.json","sdk-runs")]{
        let plan=read(format!("{R}/{plan}"));assert_eq!(plan["version"],1);assert_eq!(read(format!("{R}/{folder}/result.json"))["status"],"complete");
        for(p,h)in read(plan["source_pins"].as_str().unwrap()).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pin_occurrences+=1;}
        for step in plan["steps"].as_array().unwrap(){
            let dir=format!("{R}/{folder}/{}",step["name"].as_str().unwrap());let e=read(format!("{dir}/exit.json"));assert_eq!(e["returncode"],0);assert_eq!(e["success"],true);
            for stream in["stdout","stderr"]{assert_eq!(hash(format!("{dir}/{stream}.log")),e[format!("{stream}_sha256")]);}
            let cmd=read(format!("{dir}/command.json"));assert_eq!(&cmd["argv"].as_array().unwrap()[4..],step["argv"].as_array().unwrap());
            for(k,v)in step["environment"].as_object().into_iter().flatten(){assert_eq!(cmd["environment"][k],*v);}
            commands+=1;
        }
    }assert_eq!(commands,15);
    let mut no_version=read(format!("{R}/plan.json"));assert!(no_version.get("version").is_none());no_version["version"]=1.into();assert_eq!(no_version,read(format!("{R}/plan-v1.json")));
    assert!(!Path::new(&format!("{R}/runs")).exists());
    let audit=read(format!("{R}/source-audit.json"));let original=audit["originals"].as_object().unwrap();assert_eq!(original.len(),176);assert_eq!(audit["edits"].as_array().unwrap().len(),4);
    let production=read(format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json"));assert_eq!(audit["originals"],production["source_files_sha256"]);
    let mut unchanged=0;
    for(relative,h)in original {
        assert_eq!(hash(format!("{Z}/{relative}")),h.as_str().unwrap());let bytes=fs::read(format!("{R}/source/{relative}")).unwrap();
        if let Some(e)=audit["edits"].as_array().unwrap().iter().find(|e|e["path"]==relative.as_str()){
            let mut source=String::from_utf8(bytes).unwrap();
            if e["kind"]=="suffix" {source=source.strip_suffix(e["after"].as_str().unwrap()).unwrap().to_string();}
            else {
                if let Some(suffix)=e.get("suffix"){source=source.strip_suffix(suffix.as_str().unwrap()).unwrap().to_string();}
                let after=e["after"].as_str().unwrap();assert_eq!(source.matches(after).count(),1);source=source.replace(after,e["before"].as_str().unwrap());
            }
            assert_eq!(format!("{:x}",Sha256::digest(source.as_bytes())),h.as_str().unwrap());
        }else{assert_eq!(format!("{:x}",Sha256::digest(&bytes)),h.as_str().unwrap());unchanged+=1;}
    }assert_eq!(unchanged,172);
    assert_eq!(hash(format!("{R}/booth_packets.rs")),hash(format!("{R}/source/crates/zopro-core/src/msm_affine/booth_packets.rs")));
    let decode=fs::read_to_string(format!("{R}/booth_packets.rs")).unwrap();
    for needle in["Vec", "Box", "alloc::", "thread_local", "static mut", "asm!"]{assert!(!decode.contains(needle));}
    let n=4+3*256+4096;let expected_comparisons=n*(1..=15usize).map(|w|256usize.div_ceil(w)+1+2*(127usize.div_ceil(w)+1)).sum::<usize>();let recon=n*45;
    let digit=fs::read_to_string(format!("{R}/runs-v1/qualify-independent-digits-and-integer-reconstruction/stdout.log")).unwrap();
    assert!(digit.contains(&format!("SIMD_BOOTH comparisons={expected_comparisons} exact_320bit_reconstructions={recon} population={n}")));
    let tail=(0..=33usize).sum::<usize>()*20;assert!(digit.contains(&format!("variable_span_tail_comparisons={tail} lengths=0..33 input_unchanged=true")));assert!(digit.contains("2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
    let core=fs::read_to_string(format!("{R}/runs-v1/qualify-all-native-core-and-curve-tests/stdout.log")).unwrap();assert!(core.contains("129 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
    for curve in["G1","G2"]{assert!(core.contains(&format!("SIMD_BOOTH_NATIVE_CURVE={curve} CASES=352 BUCKET_COMPARISONS=22528 INPUTS_UNCHANGED=true BATCH_QUEUE_POINTER_CAPACITY_STABLE=true")));}
    let native=read(format!("{R}/plan-v1.json"));
    for arm in ["OFF","ON","portable-compile"]{let step=native["steps"].as_array().unwrap().iter().find(|s|s["name"]==format!("build-core-{arm}")).unwrap();let a=step["argv"].as_array().unwrap();for cfg in ["zopro_booth_digits","zopro_dense_busy_reset","zopro_cios_cancel_carry"]{assert!(a.iter().any(|v|v==cfg));}assert_eq!(a.iter().any(|v|v=="zopro_simd_booth"),arm!="OFF");if arm=="portable-compile"{for arg in["target-cpu=x86-64","no_ifma"]{assert!(a.iter().any(|v|v==arg));}}else{assert!(a.iter().any(|v|v=="target-cpu=native"));}}
    let sdk_plan=read(format!("{R}/sdk-plan.json"));let mut identities=BTreeMap::new();let mut code=BTreeMap::new();
    fs::create_dir_all(format!("{R}/codegen")).unwrap();
    for arm in ["OFF","ON"] {
        let bin=format!("{R}/sdk-{arm}");let link=sdk_plan["steps"].as_array().unwrap().iter().find(|s|s["name"]==format!("sdk-{arm}")).unwrap();let a=link["argv"].as_array().unwrap();
        for flag in["-O","target-cpu=native","lto=fat","codegen-units=1"]{assert!(a.iter().any(|v|v==flag));}
        for name in["zopro_core","zopro_prover","zopro_zolana"]{assert!(a.iter().any(|v|v==&format!("{name}={R}/libs/{arm}/lib{name}.rlib")));}
        assert!(a.iter().any(|v|v=="/home/ubuntu/src/zopro-perf-work/worker-placement-control176/driver.rs"));
        let text=fs::read_to_string(format!("{R}/sdk-runs/list-actual-sdk-{arm}-symbols/stdout.log")).unwrap();let mut selected=vec![];
        for line in text.lines(){let parts=line.split_whitespace().collect::<Vec<_>>();if parts.len()!=4{continue;}let symbol=parts[3];let name=format!("{:#}",rustc_demangle::demangle(symbol));
            assert!(!name.contains("booth_packet_tests"));assert!(!name.contains("busy_reset_qualification"));
            let label=if name.contains("g2_borrowed::Window")&&name.ends_with("::feed"){Some("g2-feed")}else if name.contains("borrowed_pending::balanced::feed"){Some("balanced-g1-feed")}else{None};
            if let Some(label)=label{let address=u64::from_str_radix(parts[0],16).unwrap();let size=u64::from_str_radix(parts[1],16).unwrap();let argv=vec!["--no-show-raw-insn".to_string(),"-d".into(),"-C".into(),format!("--start-address={address}"),format!("--stop-address={}",address+size),bin.clone()];
                let o=Command::new("objdump").args(&argv).output().unwrap();assert!(o.status.success());let path=format!("{R}/codegen/{arm}-{label}.asm");assert!(!Path::new(&path).exists());fs::write(&path,&o.stdout).unwrap();fs::write(format!("{R}/codegen/{arm}-{label}.stderr"),&o.stderr).unwrap();
                let body=String::from_utf8(o.stdout).unwrap();let gather=body.lines().filter(|l|l.contains("vpgatherqq")).count();let narrow=body.lines().filter(|l|l.contains("vpmovqw")).count();let shifts=body.lines().filter(|l|l.contains("vpsrlq")||l.contains("vpsllq")).count();
                if arm=="ON"{assert!(gather>0);assert!(narrow>0);}else{assert_eq!(gather,0);assert_eq!(narrow,0);}
                selected.push(json!({"label":label,"symbol":symbol,"demangled":name,"address":address,"bytes":size,"gather_sites":gather,"narrow_sites":narrow,"vector_shift_sites":shifts,"decode":path,"decode_sha256":hash(&path),"command":{"program":"objdump","argv":argv,"success":true,"returncode":0,"stderr_sha256":format!("{:x}",Sha256::digest(&o.stderr))}}));
            }
        }assert_eq!(selected.len(),2);code.insert(arm,json!(selected));
        identities.insert(arm,json!({"binary":bin,"sha256":hash(&bin),"core_sha256":hash(format!("{R}/libs/{arm}/libzopro_core.rlib")),"prover_sha256":hash(format!("{R}/libs/{arm}/libzopro_prover.rlib")),"zolana_sha256":hash(format!("{R}/libs/{arm}/libzopro_zolana.rlib"))}));
    }
    let ledger="/home/ubuntu/src/zopro-perf-work/compiler199-sdk176/proof-sha256-after-capture.json";assert_eq!(read(ledger).as_array().unwrap().len(),47437);assert_eq!(hash(ledger),"04f436ae856d2f68595d6b97bb79ce73517d91501d2a203153bf52f0f26aeda8");
    let accepted="/home/ubuntu/src/zopro-perf-work/busy-reset-sdk176/sdk-ON";assert_eq!(hash(accepted),"7aff5f602a1e250a6b9b28889bf6278b51ec400af8399c7481c36248a8718d01");
    save("identities.json",&json!(identities));save("codegen.json",&json!(code));
    let out=json!({"passed":true,"same_agent_separate_reader":true,"workflow_commands":commands,"pin_occurrences_checked":pin_occurrences,"original_plan_parse_failure_before_any_command":true,"version_only_repair_checked":true,"source_originals":176,"unchanged_originals":unchanged,"recovered_originals":176,"new_children":3,"snapshot_members":179,"digit_population":n,"independent_digit_comparisons":expected_comparisons,"exact_320bit_reconstructions":recon,"variable_span_tail_comparisons":tail,"standalone_integer_tests_passed":2,"native_core_tests_passed":129,"new_native_bucket_cases":704,"independent_Arkworks_bucket_outputs":45056,"pool_sizes":[1,4,16,32],"requested_native_test_worker_stack_bytes":524288,"native_pool_tests_are_not_concurrent_proof_throughput":true,"portable_feature_disabled_compile_only":true,"portable_not_ARM_execution":true,"unchanged_field1200_tests_inherited":true,"selected_final_sdk_decodes":4,"selected_ON_feeds_have_integer_packet_instructions":true,"selected_OFF_feeds_have_no_integer_packet_instructions":true,"new_SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":47437,"canonical_sha256":hash(ledger),"source_production_changed":false,"accepted_sdk_changed":false,"latency_measured":false,"adopted":false,"goal_complete":false});
    save("review-result.json",&out);println!("REVIEW PASS:15workflowcommands/{pin_occurrences}pins;176source recovery;{expected_comparisons}digits/{recon}exactintegers/45056Ark buckets;4actualSDKdecodes;0newproofs;no latency/adoption");
}
