use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/simd-booth176";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/busy-reset-sdk176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(n:&str,v:Value){let p=format!("{R}/{n}");assert!(!Path::new(&p).exists());fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap()}
fn main(){
    assert_eq!(read(format!("{R}/runs-v1/result.json"))["status"],"complete");
    let suite=fs::read_to_string(format!("{R}/runs-v1/qualify-all-native-core-and-curve-tests/stdout.log")).unwrap();assert!(suite.contains("129 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
    for curve in ["G1","G2"]{assert!(suite.contains(&format!("SIMD_BOOTH_NATIVE_CURVE={curve} CASES=352 BUCKET_COMPARISONS=22528")));}
    let template=read(format!("{OLD}/build-plan.json"));let mut steps=vec![];let mut pins=read(format!("{R}/pins.json")).as_object().unwrap().iter().map(|(p,h)|(p.clone(),h.as_str().unwrap().to_owned())).collect::<BTreeMap<_,_>>();
    for arm in ["OFF","ON"]{for stem in ["zopro_prover","zopro_zolana","sdk"]{
        let name=format!("{stem}-{arm}");let mut step=template["steps"].as_array().unwrap().iter().find(|s|s["name"]==name).unwrap().clone();
        for v in step["argv"].as_array_mut().unwrap(){let text=v.as_str().unwrap();*v=text.replace(OLD,R).replace("/home/ubuntu/src/zopro-perf-work/busy-reset176/libs",&format!("{R}/libs")).replace("busy_reset_sdk176","simd_booth_sdk176").into();}
        if let Some(env)=step.get_mut("environment"){for v in env.as_object_mut().unwrap().values_mut(){if let Some(s)=v.as_str(){*v=s.replace(OLD,R).into();}}}
        steps.push(step);
    }}
    for arm in ["OFF","ON"]{steps.push(json!({"kind":"command","name":format!("list-actual-sdk-{arm}-symbols"),"argv":["nm","-S","--defined-only",format!("{R}/sdk-{arm}")],"timeout_seconds":300}));}
    for p in ["prepare-sdk.rs","plan.json","plan-v1.json","runs-v1/result.json","runs-v1/qualify-all-native-core-and-curve-tests/stdout.log","runs-v1/qualify-independent-digits-and-integer-reconstruction/stdout.log"]{let p=format!("{R}/{p}");pins.insert(p.clone(),hash(p));}
    for step in &steps{for v in step["argv"].as_array().unwrap(){let text=v.as_str().unwrap();let p=text.split_once('=').map_or(text,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.to_string(),hash(p));}}}
    for(p,h)in &pins {assert_eq!(hash(p),*h,"{p}");}
    save("sdk-pins.json",json!(pins));save("sdk-plan.json",json!({"version":1,"source_pins":format!("{R}/sdk-pins.json"),"steps":steps}));
    println!("Prepared8 coherent SDK build/symbol steps;reuse exact qualified cores and field1200;no SDK requests or clocks");
}
