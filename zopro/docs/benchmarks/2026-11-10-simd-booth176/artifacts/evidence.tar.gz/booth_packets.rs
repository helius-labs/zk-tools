//! Eight independent Booth digits; no retained digit matrix or heap storage.
use core::arch::x86_64::*;

#[derive(Clone, Copy)]
pub(super) struct Plan {
    start: usize,
    width: usize,
    component: Option<bool>,
}

impl Plan {
    pub(super) fn new(start: usize, width: usize, component: Option<bool>) -> Self {
        assert!((1..=15).contains(&width));
        Self { start, width, component }
    }

    #[inline(always)]
    fn decode(self, rows: &[[u64; 4]]) -> [i16; 8] {
        assert_eq!(rows.len(), 8);
        // SAFETY: this module is compiled only with AVX512F. All eight
        // indices address the same in-range word of distinct four-word rows.
        // G2 magnitudes have two words, with bit127 carrying the sign.
        // Missing high words are supplied as zero, never gathered.
        unsafe {
            let offsets = _mm512_set_epi64(28, 24, 20, 16, 12, 8, 4, 0);
            let base = usize::from(self.component == Some(true)) * 2;
            let limbs = if self.component.is_some() { 2 } else { 4 };
            let gather = |word: usize| {
                if word >= limbs {
                    return _mm512_setzero_si512();
                }
                let v = _mm512_i64gather_epi64::<8>(
                    offsets, rows.as_ptr().cast::<i64>().add(base + word),
                );
                if self.component.is_some() && word == 1 {
                    _mm512_and_si512(v, _mm512_set1_epi64(i64::MAX))
                } else { v }
            };
            let offset = self.start.saturating_sub(1);
            let word = offset / 64;
            let shift = offset % 64;
            let mut value = _mm512_srl_epi64(gather(word), _mm_cvtsi64_si128(shift as i64));
            let read_width = self.width + usize::from(self.start != 0);
            if shift + read_width > 64 && word + 1 < limbs {
                value = _mm512_or_si512(value, _mm512_sll_epi64(
                    gather(word + 1), _mm_cvtsi64_si128((64 - shift) as i64),
                ));
            }
            value = _mm512_and_si512(value, _mm512_set1_epi64((1i64 << read_width) - 1));
            let d = if self.start == 0 {
                let sign = _mm512_srl_epi64(value, _mm_cvtsi64_si128((self.width - 1) as i64));
                _mm512_sub_epi64(value, _mm512_sll_epi64(sign, _mm_cvtsi64_si128(self.width as i64)))
            } else {
                let magnitude = _mm512_srli_epi64::<1>(_mm512_add_epi64(value, _mm512_set1_epi64(1)));
                let sign = _mm512_srl_epi64(value, _mm_cvtsi64_si128(self.width as i64));
                _mm512_sub_epi64(magnitude, _mm512_sll_epi64(sign, _mm_cvtsi64_si128(self.width as i64)))
            };
            let d = if self.component.is_some() {
                let top = _mm512_i64gather_epi64::<8>(
                    offsets, rows.as_ptr().cast::<i64>().add(base + 1),
                );
                let negative = _mm512_srai_epi64::<63>(top);
                _mm512_sub_epi64(_mm512_xor_si512(d, negative), negative)
            } else { d };
            let mut out = [0i16; 8];
            _mm_storeu_si128(out.as_mut_ptr().cast(), _mm512_cvtepi64_epi16(d));
            out
        }
    }

    /// Decode only complete packets. The existing scalar reader owns the
    /// remainder, including an empty input; no padding or overread is needed.
    pub(super) fn digits<'a, F>(self, rows: &'a [[u64; 4]], tail: F)
        -> impl Iterator<Item = i16> + 'a
    where F: FnMut(&[u64; 4]) -> i16 + 'a {
        let chunks = rows.chunks_exact(8);
        let remainder = chunks.remainder();
        chunks.flat_map(move |rows| self.decode(rows)).chain(remainder.iter().map(tail))
    }
}
