# Continue the full CPU AVX goal from the qualified SIMD Booth candidate

Goal ACTIVE/UNMET0/8: verified single-proof CPU AVX latency >=10× supplied M5 CPU
on ALL8, reporting CPU+Metal comparisons. No token budget. Do not substitute a
component result or subset for completion. User authorizes autonomous research,
no questions, commit AND push after each completed experiment, polite reports.
No subagents, Python/C/ASM rewrite, giant LUT/key plan/new pool/artificial RAM cap.

This turn makes concrete progress: distinct bounded eight-scalar Booth decoder
implemented, independently qualified, linked into actual optimized SDKs and
published. No timing measured, no production adoption. Do not call correctness
a speed gain. Before this turn the immediately preceding status-only turn made
no progress; this turn changed authoritative candidate state and completed work.

Root /home/ubuntu/src/zopro-perf-work/simd-booth176. Native workflow session16833
and SDK build session28059 TERMINAL0. All15 workflow commands succeeded once;
original missing-version plan failed before commands, preserved, version-only
repair checked. Offline review first101 on unreceipted CARGO metadata assumption;
review-v2 executed0. No live workflow/build/profiler/cloud job. Do not poll these
old handles or replay successful tests/builds for bookkeeping.

Report zopro/docs/benchmarks/2026-11-10-simd-booth176/README.md. Current publication
commit/remote identity is recorded in checkpoint.json after push. Follow the
actual repo and checkpoint; do not assume a pending push finished.

Source: original176 accepted files copied privately;172 exact,4 reversible parent
edits,3 children=179. Production176 all exact, accepted libraries unchanged.
Common Plan::digits uses eight independent AVX512F gathers/shifts/Booth signs,
narrows into16-byte array, then the ORIGINAL per-point bucket dispatch in original
order. No collective admission/busy gathers/predicate, no heap digit matrix or
barrier. Scalar tail reuses original readers. All G1 ordinary/balanced K/H and G2
low/high feeds covered. G2 two-word127-bit magnitudes exclude high sign bit.
Cfg guard all(zopro_simd_booth,zopro_booth_digits,target_arch=x86_64,
target_feature=avx512f,not(no_ifma)). Actual x86-64/no_ifma compile passed, not ARM.

Inherited field1200 exact, no primitive change or field-suite replay. New tests:
8,562,812 independent per-bit digits,219,060 exact320-bit reconstructions from
4,868 inputs (all256 one-bit boundaries±1, zeros/signs/max,4096 xorshift rows),
all widths1..15 and over-top windows, plus11,220 balanced-span/tail comparisons.
Standalone2tests PASS. Unfiltered native core129PASS including704 new G1/G2
window cases and45,056 independent Arkworks bucket outputs.1/4/16/32-worker pools
request512KiB stacks; these pool-context cases do not establish concurrent-proof
throughput. Existing full query/GLV/balanced/resource tests also pass. Stable
input, batch and queue pointer/capacity checks pass. No phone/minRAM/RSS claim.

review-v2 validates409 pin occurrences/15 receipts/source reversals/cfgs/coherent
links/old accepted SDK/current47437ledger. Direct GNU objdump decodes4 actual
SDK functions. BalancedG1 OFF2269B/ON3347B (ON5staticgathers/1narrow); G2feed
OFF3556B/ON4564B (ON7gathers/1narrow). Static sites include alternative branches,
NOTdynamic executed counts, removable work or cycle savings. OrdinaryG1feed is
inlined in the SDK and not separately decoded. Larger code/iterator/gather costs
may lose. Native test code is absent from final SDK symbol lists.

USE THE EXACT LINKED CONSUMERS, DO NOT REBUILD THEM:
OFF /home/ubuntu/src/zopro-perf-work/simd-booth176/sdk-OFF
SHA7abaa14cc6b0908e373786fe0674c27bb8084ac5dee12e6010bf77d4a785b38f
ON /home/ubuntu/src/zopro-perf-work/simd-booth176/sdk-ON
SHAd6b18ee4e37d190e3ca2ba13786aefb6b450cb9e65f5c66c7388a0243f01fe8a
Core/prover/Zolana rlibs under R/libs/OFF and ON, exact hashes identities.json.
Same Rust1.98.1/O3/native/fatLTO/CGU1/default-stack worker-placement SDK driver
as accepted. Every manual accepted cfg retained incl zopro_dense_busy_reset.
No mixed field/core bitcode metadata. Portable-compile rlib is compile-only.

NEXT ACTION: freeze a matched complete-proof experiment for this qualified
candidate, accepted REF versus fresh OFF/ON, ALL8+54 at32 plus primary1/16.
No SDK preflight/latency, timing schedule, gates or capture readers are yet frozen
by this qualification. Build/freeze both raw readers, exact inputs/order/gates,
automatic gated PMU and fixed-cycle profiles BEFORE first SDK preflight.
Reuse complete SDK support from compiler199-sdk176 or simd-bucket-sdk176, adapting
source qualification and counts truthfully. No new arithmetic candidate/source
change is necessary to make this one measurable. Test complete SDK consumer,
not isolated digit extraction. All packing/iterator/gather/fallback cost is in.

ACCOUNT PROSPECTIVELY FOR BACKING: previous f2453 control audit reproduced a
known class of executable-backing associated timing gaps. A suitable prospective
design uses independently written exact full-ELF copies per arm per predeclared
matched block (e.g31primary/15other blocks); equal-length names and modes, pin
full SHA/dev/inode before/after, fixed copy assignment, retain ALL outcomes. Do
not select fastest backing, rescue an old failed recipe, or assume one copy
normalizes everything. Exact design/copy count/statistical model must be frozen
before any clock. This is a methodological precaution, not a production copy
optimization. Original binaries remain unmodified. Diagnostic replicas must be
declared too; profiles identify the ACTUAL launched path/inode/MMAP/PID/TID/CPU.

Keep accepted/fresh control calibration, all-context nonregression/RSS, primary
and ALL8 gain rules against BOTH controls, no arbitrary positive-gain floor.
Retained20kfixedseedpaired-logbootstrap handles15/31 blocks; no exclusions,
sampling extensions, layout/compiler/worker rescue if exact recipe fails.
SDK threads use default stacks;512KiB applied ONLY to native tests. Prime/startup
outside full solve/prove/verify/serialize timings. Need fresh independent Gnark
verification and proof-binding/freshness for every export.

CANONICAL UNCHANGED47437:
/home/ubuntu/src/zopro-perf-work/compiler199-sdk176/proof-sha256-after-capture.json
SHA04f436ae856d2f68595d6b97bb79ce73517d91501d2a203153bf52f0f26aeda8.
Seed EVERY new export inventory from THIS, not46828/46802/46193/46167. Current
qualification adds ZERO SDK requests/Gnark exports. Do not replay old exports or
native/crypto qualification to increment bookkeeping.

Accepted REF /home/ubuntu/src/zopro-perf-work/busy-reset-sdk176/sdk-ON
SHA7aff5f602a1e250a6b9b28889bf6278b51ec400af8399c7481c36248a8718d01.
Latest accepted ALL8 local ms:7.863366940397351/11.051833032258065/
15.850651838709677/24.050326903225805/33.87786951612903/39.777695709677424/
66.20851712903226/65.47314448387097. Primary16=9.257515794701986,
solo95.05816763636363,54=162.6523380967742. Same accepted binary, observations
not new adoption. Old7.77ms observations remain historical. Source manifest:
zopro/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json.

M5 CPU37/59/109/189/284/335/528/507ms; Metal24/30/48/74/101/124/176/175.
CPU10× limits3.7/5.9/10.9/18.9/28.4/33.5/52.8/50.7. Historical cross-hardware
references, not remeasured. Shape order1x2/2x2/4x2/8x2/12x2/16x2/24x2/merge24x1.
54 has no suppliedM5. Goal0/8 on both local/AWS, notcomplete.

AWS accepted report2026-11-10-accepted-current-c7a176. Best1x2Z11.243892ms32/
122.52MiB vsA7.902802ms96/479.98MiB; A32=11.870012. Best54Z120.757128ms64/
2003.02MiB vsA171.908504ms96/13102.11MiB. Zbest6/9,Afirst3. No newAWS here.
Only earlierc7ai-0a15ad9ae313aa976terminated/cleanupverified. No newARM/mobile/
TEE/250/4999/pressure/swap/minRAM/concurrent-throughput claims.

Relevant closed history: SIMD bucket admission fullSDK +2%primary/slower and no
adoption (2026-11-10-simd-bucket-sdk176); full digit matrix32workerfill +17–20%
slow (2026-10-31-digit-planes176). This candidate removes neither any field op
nor point arrival; hypothesis is purely cheaper decoder, not2× forecast. Core
packet API copies no upstream code/newdependency. Aeglos/TACEO mechanisms, queue
scan/drain, four-lane MSM, opposite-scalar grouping, outlining, GLS4, R260,
FMA/IFMA/VNNI/Toom and coordination have many prior closed studies; consult
backing-control176/next.md and full report history before proposing repeats.

Autoresearch: distinct bounded hypothesis -> meaningful math/native/resource/
portable/concurrent qualification -> freeze actual coherent consumers/controls/
inputs/order/gates/two readers/automatic profiles -> serialized Rust1.98 xtask ->
ONLY poll exact confirmed live handle during ANY preflight/recording until a
terminal exit (no helper/build/hash/analyze/report/push overlap) -> all recordings
before offline/Gnark -> ALL8+54 fullSDK/resource review -> polite report -> commit
ANDpush/exact remote verify -> update canonical/checkpoint -> continue fullgoal.
Commentary<=60sec; polls30+20sec. Timeout/truncation is not terminal. Existing
xtask /home/ubuntu/src/zopro-perf-work/tool-target/release/xtask. Explicit Rust
/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc, ambient
is1.99.1. No fatLTO for helper builds linked to non-bitcode tool deps.

Git use gc.auto=0, httpsinsteadOfgit@github.com:, gh credentialhelper and
http.versionHTTP/1.1; push HEAD:refs/heads/sergei/zopro-cpu-perf, then verify exact
ls-remote. Stage only current report directory; unrelated old untracked reports
stay untouched. Keep fullgoal active; do not markcomplete/blocked for difficulty.
