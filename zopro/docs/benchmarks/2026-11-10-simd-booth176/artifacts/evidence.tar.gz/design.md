# Bounded eight-row Booth decoding

Hypothesis: replacing repeated scalar window extraction/sign handling with
eight-lane integer decoding can remove online dispatch instructions without
changing point work. No twofold proof-gain forecast follows.

This differs from the closed SIMD admission trial: no conflicts, busy-state
gathers, limb predicates or collective bucket admission. It differs from the
closed digit-plane trial: no input-sized matrix, allocation or readiness barrier.
Only complete eight-row scalar packets use SIMD. Original scalar readers handle
the remainder, original pending/busy/exception/queue/batch boundaries remain in
their input order. G1 ordinary, balanced K/H and signed two-limb G2 feeds share a
small decoder. Four-limb G1 and two-limb signed-magnitude G2 retain exact Booth
digits. The test oracle uses individual bits and reconstructs signed 320-bit
integers, not field residues. Native window tests compare Arkworks bucket sums.

Candidate is private, opt-in zopro_simd_booth plus zopro_booth_digits, x86_64,
AVX512F, not no_ifma. Portable/default paths retain original scalar iterators.
Production source176 and accepted libraries stay immutable. No field change,
key plan/table, heap buffer, allocator/pool/RAM policy change, inline assembly
or new dependency. Iterator/plan and a16-byte output array are stack values;
emitted frame size and whole-program RAM are not yet measured.

Qualify standalone integer/bit/reconstruction/tail cases, native unfiltered core
suite including independent G1/G2 bucket outputs with exceptions and1/4/16/32
worker pools requesting512KiB stacks, and compile the feature-disabled path.
Use retained Rust1.98.1 and serialized xtask; preserve all accepted cfgs including
dense busy reset and accepted field1200. No clock or source-count result alone
selects adoption. Full coherent SDK all8+54/fresh Gnark, resources, calibration
and automatic profiles remain necessary before any production change.

No performance schedule/gates are frozen by this qualification document. If
qualification passes, the next stage freezes matched actual complete-consumer
comparisons before any functional preflight/clock, including predetermined file
backing variation, exact accepted/fresh controls, all costs and raw readers.
