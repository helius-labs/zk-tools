use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/simd-booth176";
const Z:&str="/home/ubuntu/src/zk-tools/zopro";
const RC:&str="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
const GUARD:&str="all(zopro_simd_booth,zopro_booth_digits,target_arch=\"x86_64\",target_feature=\"avx512f\",not(no_ifma))";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn write(p:impl AsRef<Path>,s:impl AsRef<[u8]>){let p=p.as_ref();assert!(!p.exists(),"{}",p.display());fs::create_dir_all(p.parent().unwrap()).unwrap();fs::write(p,s).unwrap()}
fn save(n:&str,v:Value){write(format!("{R}/{n}"),serde_json::to_vec_pretty(&v).unwrap())}
fn main(){
    let manifest=read(format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json"));
    let originals=manifest["source_files_sha256"].as_object().unwrap();assert_eq!(originals.len(),176);
    let mut pins=BTreeMap::new();
    for(p,h)in originals{assert_eq!(hash(format!("{Z}/{p}")),h.as_str().unwrap());write(format!("{R}/source/{p}"),fs::read(format!("{Z}/{p}")).unwrap());}
    write(format!("{R}/source/crates/zopro-core/src/msm_affine/booth_packets.rs"),fs::read(format!("{R}/booth_packets.rs")).unwrap());
    let parent="crates/zopro-core/src/msm_affine.rs";
    let p=format!("{R}/source/{parent}");let mut s=fs::read_to_string(&p).unwrap();let suffix=format!("\n#[cfg({GUARD})]\nmod booth_packets;\n");s.push_str(&suffix);fs::write(&p,s).unwrap();
    let mut edits=vec![json!({"path":parent,"before":"","after":suffix,"kind":"suffix"})];
    let template=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/simd-bucket-admission176/window-test-template.rs").unwrap();
    for g2 in [false,true]{
        let relative=if g2{"crates/zopro-core/src/msm_affine/g2_borrowed.rs"}else{"crates/zopro-core/src/msm_affine/borrowed_pending.rs"};
        let p=format!("{R}/source/{relative}");let mut s=fs::read_to_string(&p).unwrap();
        let (before,after)=if g2 {
            ("        for (p, s) in bases.iter().zip(short) {\n            let d = component(s, high, w, bits);".to_string(),format!("        #[cfg({GUARD})]\n        let digits = super::booth_packets::Plan::new(w*bits,bits,Some(high)).digits(short, |s|component(s,high,w,bits));\n        #[cfg(not({GUARD}))]\n        let digits = short.iter().map(|s|component(s,high,w,bits));\n        for (p, d) in bases.iter().zip(digits) {{"))
        }else{
            ("        for (point, scalar) in points.iter().zip(scalars) {\n            let d = digit(scalar, w, bits);".to_string(),format!("        #[cfg({GUARD})]\n        let digits = super::booth_packets::Plan::new(w*bits,bits,None).digits(scalars, |s|digit(s,w,bits));\n        #[cfg(not({GUARD}))]\n        let digits = scalars.iter().map(|s|digit(s,w,bits));\n        for (point, d) in points.iter().zip(digits) {{"))
        };
        assert_eq!(s.matches(&before).count(),1);s=s.replace(&before,&after);
        let child=if g2{"g2_booth_tests.rs"}else{"g1_booth_tests.rs"};let suffix=format!("\n#[cfg(all(test,{GUARD}))]\n#[path=\"{child}\"]mod booth_packet_tests;\n");s.push_str(&suffix);fs::write(&p,s).unwrap();
        edits.push(json!({"path":relative,"before":before,"after":after,"suffix":suffix,"kind":"replace_suffix"}));
        let mut t=template.replace("packet_feed_matches_independent_curve_buckets_threads_exceptions_and_tails","decoded_feed_matches_independent_curve_buckets_threads_exceptions_and_tails");
        t=t.replace("    let before=ADMITTED_PACKETS.load(std::sync::atomic::Ordering::Relaxed);\n","")
            .replace("    let admitted=ADMITTED_PACKETS.load(std::sync::atomic::Ordering::Relaxed)-before;\n","")
            .replace("assert_eq!(cases,352);assert!(admitted>0);","assert_eq!(cases,352);")
            .replace("PACKET_NATIVE_CURVE=","SIMD_BOOTH_NATIVE_CURVE=")
            .replace(" ADMITTED_PACKETS={admitted}","")
            .replace("let half=64usize;","let half=64usize;let w=if mode>=2{5}else{0};")
            .replace("points.push(generator*incoming);words.push([raw,0,raw,0]);",if g2 {
                "let shift=w*12;let lo=raw<<shift;let hi=if shift==0{0}else{raw>>(64-shift)};let marker=if mode==3{1u64<<63}else{0};points.push(generator*incoming);words.push([lo,hi|marker,lo,hi|marker]);"
            }else{
                "let shift=w*12;let lo=raw<<shift;let hi=if shift==0{0}else{raw>>(64-shift)};points.push(generator*incoming);words.push([lo,hi,0,0]);"
            });
        if g2 {t=t.replace("expected[id]+=if negative{-scalar}else{scalar};","expected[id]+=if negative^(mode==3){-scalar}else{scalar};");}
        t=t.replace("@PROJECTIVE@",if g2{"G2Projective"}else{"Projective::<zopro_bn254::G1Config>"})
            .replace("@ARK_PROJECTIVE@",if g2{"ark_bn254::G2Projective"}else{"ark_bn254::G1Projective"})
            .replace("@LABEL@",if g2{"G2"}else{"G1"})
            .replace("@NEW_WINDOW@",if g2{"Window::new(half,size,BatchAdd::default())"}else{"Window::<zopro_bn254::G1Config>::new(half,size)"})
            .replace("@FEED@",if g2{"state.feed(&points,&words,false,w,12,size);"}else{"state.feed(&points,&words,w,12,size);"});
        let convert=if g2{"if expected.infinity {G2Affine::IDENTITY}else{let f=|x:ark_bn254::Fq|Fq::from_canonical(x.into_bigint().0).unwrap();G2Affine::new(zopro_bn254::Fq2::new(f(expected.x.c0),f(expected.x.c1)),zopro_bn254::Fq2::new(f(expected.y.c0),f(expected.y.c1)))}"}else{"if expected.infinity {Affine::<zopro_bn254::G1Config>::IDENTITY}else{Affine::new(Fq::from_canonical(expected.x.into_bigint().0).unwrap(),Fq::from_canonical(expected.y.into_bigint().0).unwrap())}"};
        t=t.replace("@CONVERT@",convert);write(format!("{R}/source/crates/zopro-core/src/msm_affine/{child}"),t);
    }
    let relative="crates/zopro-core/src/msm_affine/borrowed_pending/balanced.rs";let p=format!("{R}/source/{relative}");let mut s=fs::read_to_string(&p).unwrap();
    let before="    for (point, scalar) in points.iter().zip(scalars) {\n        let d = digit_at(scalar, span);";
    let after=format!("    #[cfg({GUARD})]\n    let digits = super::super::booth_packets::Plan::new(span.start,span.width,None).digits(scalars, |s|digit_at(s,span));\n    #[cfg(not({GUARD}))]\n    let digits = scalars.iter().map(|s|digit_at(s,span));\n    for (point, d) in points.iter().zip(digits) {{");
    assert_eq!(s.matches(before).count(),1);s=s.replace(before,&after);fs::write(p,s).unwrap();edits.push(json!({"path":relative,"before":before,"after":after,"kind":"replace"}));
    save("source-audit.json",json!({"originals":originals,"edits":edits,"children":["crates/zopro-core/src/msm_affine/booth_packets.rs","crates/zopro-core/src/msm_affine/g1_booth_tests.rs","crates/zopro-core/src/msm_affine/g2_booth_tests.rs"],"guard":GUARD,"production_changed":false}));
    let mut steps=vec![json!({"kind":"command","name":"build-eight-lane-integer-tests","argv":[RC,"--edition=2021","--test","-O","-Ctarget-cpu=native","-Coverflow-checks=yes","-Cdebug-assertions=yes",format!("{R}/digit_tests.rs"),"-o",format!("{R}/digit-tests")],"timeout_seconds":300}),json!({"kind":"command","name":"qualify-independent-digits-and-integer-reconstruction","argv":[format!("{R}/digit-tests"),"--nocapture","--test-threads=1"],"timeout_seconds":300})];
    let old=read("/home/ubuntu/src/zopro-perf-work/busy-reset176/plan.json");let base=old["steps"].as_array().unwrap().iter().find(|s|s["name"]=="build-core-ON").unwrap().clone();
    for arm in ["OFF","ON","portable-compile"]{
        fs::create_dir_all(format!("{R}/libs/{arm}")).unwrap();let mut b=base.clone();b["name"]=format!("build-core-{arm}").into();b["environment"]["CARGO_MANIFEST_DIR"]=format!("{R}/source/crates/zopro-core").into();
        for v in b["argv"].as_array_mut().unwrap(){let t=v.as_str().unwrap();*v=t.replace("/home/ubuntu/src/zopro-perf-work/busy-reset176/source",&format!("{R}/source")).replace("/home/ubuntu/src/zopro-perf-work/busy-reset176/libs/ON",&format!("{R}/libs/{arm}")).replace("busy_reset176_ON",&format!("simd_booth176_{arm}")).into();}
        if arm!="OFF"{b["argv"].as_array_mut().unwrap().extend([json!("--cfg"),json!("zopro_simd_booth")]);}
        if arm=="portable-compile"{let a=b["argv"].as_array_mut().unwrap();for v in a.iter_mut(){if v=="target-cpu=native"{*v="target-cpu=x86-64".into();}}a.extend([json!("--cfg"),json!("no_ifma")]);}
        steps.push(b.clone());
        if arm=="ON"{
            let mut t=b;t["name"]="build-native-core-and-curve-tests".into();let a=t["argv"].as_array_mut().unwrap();let i=a.iter().position(|v|v=="--crate-type").unwrap();a.drain(i..i+2);let i=a.iter().position(|v|v=="-o").unwrap();a[i+1]=format!("{R}/core-tests").into();
            let deps="/home/ubuntu/src/zopro-perf-work/word-export176/target-candidate/release/deps";a.extend([json!("--test"),json!("-Coverflow-checks=yes"),json!("-Cdebug-assertions=yes"),json!("-L"),json!(format!("dependency={deps}"))]);
            for(n,f)in[("ark_bn254","libark_bn254-d28868a71f06f5b5.rlib"),("ark_ec","libark_ec-59ebd5b49f9b3011.rlib"),("ark_ff","libark_ff-3a8e68dc8045d2bd.rlib")]{a.extend([json!("--extern"),json!(format!("{n}={deps}/{f}"))]);}
            steps.push(t);steps.push(json!({"kind":"command","name":"qualify-all-native-core-and-curve-tests","argv":[format!("{R}/core-tests"),"--nocapture","--test-threads=1"],"timeout_seconds":900}));
        }
    }
    for p in ["prepare.rs","booth_packets.rs","digit_tests.rs","design.md","source-audit.json"]{let f=format!("{R}/{p}");pins.insert(f.clone(),hash(f));}
    for p in originals.keys().map(String::as_str).chain(["crates/zopro-core/src/msm_affine/booth_packets.rs","crates/zopro-core/src/msm_affine/g1_booth_tests.rs","crates/zopro-core/src/msm_affine/g2_booth_tests.rs"]){let f=format!("{R}/source/{p}");pins.insert(f.clone(),hash(f));}
    pins.insert(RC.to_string(),hash(RC));
    for step in &steps{let a=step["argv"].as_array().unwrap();for w in a.windows(2){if w[0]=="--extern"{let p=w[1].as_str().unwrap().split_once('=').unwrap().1;pins.insert(p.to_string(),hash(p));}}}
    let ledger="/home/ubuntu/src/zopro-perf-work/compiler199-sdk176/proof-sha256-after-capture.json";assert_eq!(read(ledger).as_array().unwrap().len(),47437);pins.insert(ledger.to_string(),hash(ledger));
    save("pins.json",json!(pins));save("plan.json",json!({"source_pins":format!("{R}/pins.json"),"steps":steps}));
    println!("Prepared {} serialized commands;176 accepted originals+3 children;4 reversible parent edits;0 clocks/proofs;production unchanged",steps.len());
}
