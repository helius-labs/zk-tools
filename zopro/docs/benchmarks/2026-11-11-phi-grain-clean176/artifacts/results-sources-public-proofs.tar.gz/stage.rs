use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    os::unix::fs::{MetadataExt, PermissionsExt},
    path::Path,
    process::Command,
};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
const SEED: &str =
    "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176/proof-sha256-after-capture.json";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn cmd(a: &[&str]) -> String {
    let o = Command::new(a[0]).args(&a[1..]).output().unwrap();
    assert!(o.status.success());
    String::from_utf8(o.stdout).unwrap().trim().into()
}
fn main() {
    let r = Path::new(ROOT);
    match std::env::args().nth(1).as_deref() {
        Some("freeze-preflight") => {
            assert_eq!(
                read(r.join("docker-runs/result.json"))["status"],
                "complete"
            );
            let id = cmd(&[
                "docker",
                "image",
                "inspect",
                "zopro-phi-grain-clean:preflight",
                "--format",
                "{{.Id}}",
            ]);
            assert!(id.starts_with("sha256:"));
            let out = r.join("local-output");
            fs::create_dir(&out).unwrap();
            fs::set_permissions(&out, fs::Permissions::from_mode(0o770)).unwrap();
            let gid = fs::metadata(&out).unwrap().gid().to_string();
            let mut pins: BTreeMap<String, String> =
                serde_json::from_value(read(r.join("docker-pins.json"))).unwrap();
            for p in [r.join("stage.rs"), r.join("stage"), SEED.into()] {
                pins.insert(p.display().to_string(), hash(p));
            }
            save(
                r.join("preflight-image.json"),
                json!({"image_id":id,"output_group":gid,"output_mode":"0770"}),
            );
            pins.insert(
                r.join("preflight-image.json").display().to_string(),
                hash(r.join("preflight-image.json")),
            );
            save(r.join("preflight-pins.json"), json!(pins));
            save(
                r.join("preflight-plan.json"),
                json!({"version":1,"source_pins":r.join("preflight-pins.json"),"steps":[{"kind":"command","name":"all9-candidate-plus-primary-controls","argv":["docker","run","--rm","--network","none","--cpus","4","--memory","30g","--memory-swap","30g","--pids-limit","2048","--group-add",gid,"--cap-drop","ALL","--security-opt","no-new-privileges","-v",format!("{ROOT}/local-output:/output"),id,"preflight"],"timeout_seconds":1800},{"kind":"command","name":"independent-preflight-review","argv":[r.join("post"),"local"],"timeout_seconds":600}]}),
            );
            println!("Frozenuntraced11exports/44calls; ledger50351; actualoutputgroup matched beforeANYSDKcall");
        }
        Some("final") => {
            assert_eq!(
                read(r.join("preflight-runs/result.json"))["status"],
                "complete"
            );
            assert_eq!(read(r.join("local-review.json"))["status"], "PASS");
            let complete = read(r.join("local-output/preflight/complete.json"));
            assert_eq!(complete["sdk_requests"], 44);
            assert_eq!(complete["proof_ledger"], 50362);
            let seen: BTreeSet<String> =
                serde_json::from_value(read(r.join("proof-sha256-after-preflight.json"))).unwrap();
            assert_eq!(seen.len(), 50362);
            fs::copy(
                r.join("local-output/preflight/complete.json"),
                r.join("context/preflight-complete.json"),
            )
            .unwrap();
            let docker = fs::read_to_string(r.join("context/Dockerfile")).unwrap();
            fs::write(
                r.join("context/Dockerfile.final"),
                format!("{docker}COPY preflight-complete.json /cr/preflight-complete.json\n"),
            )
            .unwrap();
            let id = format!("phi-clean-c7a-{}", cmd(&["date", "-u", "+%Y%m%d-%H%M%S"]));
            assert!(!r.join("run-id.txt").exists());
            fs::write(r.join("run-id.txt"), &id).unwrap();
            let tag =
                format!("558215002830.dkr.ecr.eu-north-1.amazonaws.com/zolana-prover:bench-{id}");
            let mut pins = BTreeMap::new();
            for f in [
                "context/Dockerfile.final",
                "context/manifest.json",
                "context/preflight-complete.json",
                "context/cr-previous",
                "context/cr-parent",
                "context/cr-current",
                "context/interval-verify",
                "context/aws-runner",
                "context/cr-xtask",
                "post.rs",
                "post",
                "statistics.rs",
                "design.md",
                "target-protocol.md",
                "stage.rs",
                "stage",
                "run-id.txt",
                "proof-sha256-after-preflight.json",
                "local-review.json",
            ] {
                pins.insert(r.join(f).display().to_string(), hash(r.join(f)));
            }
            save(r.join("final-pins.json"), json!(pins));
            save(
                r.join("final-plan.json"),
                json!({"version":1,"source_pins":r.join("final-pins.json"),"steps":[{"kind":"command","name":"final-cloud-image","argv":["docker","build","-t",tag,"-f",r.join("context/Dockerfile.final"),r.join("context")],"timeout_seconds":1200}]}),
            );
            save(
                r.join("image-manifest-pending.json"),
                json!({"image_tag":tag,"local_preflight_sdk":44,"local_gnark_proofs":11,"local_proof_ledger":50362,"source_files":176,"accepted_sdk_sha256":hash(r.join("context/cr-previous")),"parent_sdk_sha256":hash(r.join("context/cr-parent")),"clean_sdk_sha256":hash(r.join("context/cr-current")),"target_blocks":9,"target_SDK_requests":25050,"target_exports":390,"target_final_ledger":50752,"status":"local preflight complete; not published/not launched"}),
            );
            println!("Local44SDK/11freshGnark/independentreaderPASS, canonical50362; finalimagebuildnext");
        }
        Some("image") => {
            assert_eq!(read(r.join("final-runs/result.json"))["status"], "complete");
            let mut m = read(r.join("image-manifest-pending.json"));
            m["local_image_id"] = json!(cmd(&[
                "docker",
                "image",
                "inspect",
                m["image_tag"].as_str().unwrap(),
                "--format",
                "{{.Id}}"
            ]));
            save(r.join("image-manifest.json"), m);
            println!("Finalimagepinned; noAWSpublish/instance");
        }
        _ => panic!("freeze-preflight|final|image"),
    }
}
