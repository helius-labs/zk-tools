use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let r = Path::new(ROOT);
    assert!(!r.join("native-review.json").exists());
    let a = read(r.join("source-audit.json"));
    let orig = a["originals"].as_object().unwrap();
    assert_eq!(orig.len(), 176);
    let e = &a["edits"][0];
    for (rel, h) in orig {
        let p = r.join("source").join(rel);
        let actual = if e["path"] == rel.as_str() {
            let s = fs::read_to_string(&p).unwrap();
            assert_eq!(s.matches(e["after"].as_str().unwrap()).count(), 1);
            assert!(!s.contains("zopro_phi_grain"));
            format!(
                "{:x}",
                Sha256::digest(
                    s.replace(e["after"].as_str().unwrap(), e["before"].as_str().unwrap())
                        .as_bytes()
                )
            )
        } else {
            hash(p)
        };
        assert_eq!(actual, h.as_str().unwrap());
        assert_eq!(
            hash(Path::new("/home/ubuntu/src/zk-tools/zopro").join(rel)),
            h.as_str().unwrap()
        );
    }
    let flags = fs::read_to_string(r.join("candidate-flags.txt")).unwrap();
    assert!(
        !flags.contains("zopro_phi_grain")
            && flags.contains("target-cpu=znver4")
            && flags.contains("zopro_dense_busy_reset")
    );
    assert_eq!(
        read(r.join("native-candidate/result.json"))["status"],
        "complete"
    );
    for step in [
        "candidate-core",
        "candidate-prover",
        "libraries-candidate",
        "freeze-candidate",
        "link-candidate",
    ] {
        let d = r.join("native-candidate").join(step);
        let e = read(d.join("exit.json"));
        assert_eq!(e["success"], true);
        assert_eq!(e["returncode"], 0);
        for (f, k) in [
            ("stdout.log", "stdout_sha256"),
            ("stderr.log", "stderr_sha256"),
        ] {
            assert_eq!(hash(d.join(f)), e[k]);
        }
    }
    let core = fs::read_to_string(r.join("native-candidate/candidate-core/stdout.log")).unwrap();
    assert!(core.lines().any(|x| x.starts_with(
        "test result: ok. 127 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
    )));
    let prover =
        fs::read_to_string(r.join("native-candidate/candidate-prover/stdout.log")).unwrap();
    for n in [2, 6] {
        assert!(prover.lines().any(|x| x.starts_with(&format!(
            "test result: ok. {n} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
        ))));
    }
    let frozen = read(r.join("frozen-candidate.json"));
    assert_eq!(frozen["libraries"].as_object().unwrap().len(), 8);
    for (p, h) in frozen["input_pins"].as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let pins: BTreeMap<String, String> =
        serde_json::from_value(read(r.join("build-pins.json"))).unwrap();
    for (p, h) in &pins {
        assert_eq!(&hash(p), h);
    }
    let result = json!({"status":"PASS","source_files":176,"unchanged_originals":175,"reversible_originals":1,"default_unconditional_min128":true,"no_experimental_cfg":true,"production_unchanged":true,"core_tests":127,"prover_tests":2,"cubic_tests":6,"workflow_commands":5,"input_pins_checked":pins.len(),"binary":r.join("sdk-candidate-znver4"),"binary_sha256":hash(r.join("sdk-candidate-znver4")),"frozen":frozen,"new_SDK_requests":0,"new_exported_proofs":0,"canonical_ledger":50351});
    fs::write(
        r.join("native-review.json"),
        serde_json::to_vec_pretty(&result).unwrap(),
    )
    .unwrap();
    println!(
        "CleanDEFAULT native127core+2prover+6cubic/coherent8libs/sourceinverse/pins PASS; SDK{}",
        result["binary_sha256"]
    );
}
