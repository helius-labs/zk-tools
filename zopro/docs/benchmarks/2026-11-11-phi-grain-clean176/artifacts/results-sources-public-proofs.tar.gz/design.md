# Clean default G2 scalar grain qualification

Full objective remains verified single-proof CPU AVX >=10x EACH supplied
M5CPU timing, with CPU+Metal comparisons for ALL8. Active/unmet0/8; no budget.
The preceding current176 C7a experiment passes12/12 fixed target checks:
96worker paired latency5.12%better/CPU12.62%lower thanaccepted,21/21wins;
32worker latency nearparity. No production change yet. Report pushed3a872e8e85.

Prepare actual default source: original176 accepted files,175exact andone
reversible parent g2_phi.rs adds with_min_len128 to the existing in-place
phi_split iterator unconditionally. No experimental cfg/runtime selector,
new table/buffer/point copy/pool/RAMcap/ISA/field arithmetic/window/order change.
This is the same effective iterator body as the qualified experimentalON,
now default code. Metadata/code-layout changes require exactconsumer checks.

Reuse prior native source-building helper and original accepted driver. Build
one coherent8lib cleanSDK for znver4 with Rust1.98.1/all acceptedmanualflags
including densebusyreset, no zopro_phi_grain cfg. Native core/prover/cubic
unfiltered qualification, separate genericx86-64/noIFMA/noASM correctness.
Field source remains exact; field qualification inherited. Explicit1.98.1link,
frozenCargoactualrlibs+proc_macroobjects, sourceinverse/productionhashchecks.
Never run retainedxtask inside itself (globalhostlock); use direct plans.

Next performance protocol will be frozen before any newSDKpreflight. Cover
all9shapes at previously accepted best counts (32for1x2/2x2,64others), plus
primary16/64/96 and2x2_96. Use acceptedREF d5e1b2... and experimentallyqualified
parentphi c88a352... as frozen controls. Parent is NOT same algorithm asREF;
do not require parent/REF parity at96 or falselylabel itfreshoriginalOFF.
Clean vs bothcontrols nonregression/resources, primary96gain vsaccepted,
freshproofs/ALL8CPU+Metal reporting required before adoption. No unchanged
localtiming replay of Oct27; this is actualdefault plus allshape/currentC7a
qualification. NoAeglosremeasurement currentlyplanned.

Canonical NOW50351 phi-grain-c7a176/proof-sha256-after-capture.json
SHAa53fea4a995310c8d67fbb31cb0738f36b4df7c2708f1b0a149fc3caaaf84938.
This stage builds/tests/links only, noSDKrequests or proofexports yet. Every
futureexport mustseed50351, not50219. All previous ownedAWSresources cleaned.
Currentdevrole validuntil2026-11-11T23:09:33Z; recheckbeforefuturelaunch.

Use serialized Rust1.98 retainedxtask. During ANYSDKpreflight/recordingONLYpoll
confirmedlivehandleuntilterminal; noownedhelper/build/hash/analysis/report/
push overlaps. Preserve failures, no successfulscience replay forbookkeeping.
CommitANDpush eachcompletedexperiment, politefactualreports. Noquestions/
subagents/Python/C/ASM/LUT/newprodpool/artificialarchitecturalRAMcap.
