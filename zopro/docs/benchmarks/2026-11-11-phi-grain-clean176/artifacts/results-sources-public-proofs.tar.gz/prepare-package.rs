use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::Path,
    process::Command,
};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
const PARENT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
const DEPS: &str = "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn compile(r: &Path, name: &str) {
    let compiler = "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
    let argv = vec![
        "--edition=2021".to_owned(),
        "-O".into(),
        r.join(format!("{name}.rs")).display().to_string(),
        "-L".into(),
        format!("dependency={DEPS}"),
        "--extern".into(),
        format!("serde_json={DEPS}/libserde_json-cdebb9338c2784ad.rlib"),
        "--extern".into(),
        format!("sha2={DEPS}/libsha2-16b8f2c03bdf5faa.rlib"),
        "-o".into(),
        r.join(name).display().to_string(),
    ];
    let o = Command::new(compiler).args(&argv).output().unwrap();
    fs::write(r.join(format!("{name}-build.stdout")), o.stdout).unwrap();
    fs::write(r.join(format!("{name}-build.stderr")), o.stderr).unwrap();
    save(
        r.join(format!("{name}-build.json")),
        json!({"compiler":compiler,"argv":argv,"success":o.status.success(),"exit_code":o.status.code()}),
    );
    assert!(o.status.success(), "{name} compile failed");
}
fn main() {
    let r = Path::new(ROOT);
    assert!(!r.join("context").exists());
    let native = read(r.join("native-review.json"));
    assert_eq!(native["status"], "PASS");
    assert_eq!(read(r.join("portable-review.json"))["status"], "PASS");
    compile(r, "runner");
    compile(r, "post");
    let context = r.join("context");
    fs::create_dir(&context).unwrap();
    for sub in ["basis", "fixtures"] {
        fs::create_dir(context.join(sub)).unwrap();
    }
    let mut m = read(Path::new(PARENT).join("context/manifest.json"));
    let mut container = BTreeMap::new();
    let mut pins = BTreeMap::<String, String>::new();
    for c in m["cases"].as_array().unwrap() {
        for (field, folder) in [("image", "basis"), ("request", "fixtures")] {
            let name = Path::new(c[field].as_str().unwrap()).file_name().unwrap();
            let source = Path::new(PARENT).join("context").join(folder).join(name);
            let dest = context.join(folder).join(name);
            fs::copy(&source, &dest).unwrap();
            assert_eq!(hash(&dest), hash(source));
            if field == "image" {
                assert_eq!(hash(&dest), c["image_sha256"]);
            }
            container.insert(c[field].as_str().unwrap().to_owned(), hash(dest));
        }
    }
    let best = read("/home/ubuntu/src/zopro-perf-work/accepted-current-c7a176/best-counts.json");
    let mut contexts = vec![];
    for c in m["cases"].as_array().unwrap() {
        let w = best["rows"]
            .as_array()
            .unwrap()
            .iter()
            .find(|b| b["shape"] == c["shape"])
            .unwrap()["Zopro_workers"]
            .as_u64()
            .unwrap();
        let mut c = c.clone();
        c["workers"] = json!(w);
        c["name"] = json!(format!("{}-w{w}", c["shape"].as_str().unwrap()));
        c["cpu_affinity"] = json!(format!("0-{}", w - 1));
        c["rounds"] = json!(if c["shape"] == "1x2" { 151 } else { 31 });
        contexts.push(c);
    }
    for (shape, w) in [("1x2", 16), ("1x2", 64), ("1x2", 96), ("2x2", 96)] {
        let mut c = m["cases"]
            .as_array()
            .unwrap()
            .iter()
            .find(|c| c["shape"] == shape)
            .unwrap()
            .clone();
        c["workers"] = json!(w);
        c["name"] = json!(format!("{shape}-w{w}"));
        c["cpu_affinity"] = json!(format!("0-{}", w - 1));
        c["rounds"] = json!(if shape == "1x2" { 151 } else { 31 });
        contexts.push(c);
    }
    assert_eq!(contexts.len(), 13);
    let names = contexts
        .iter()
        .map(|c| c["name"].as_str().unwrap())
        .collect::<BTreeSet<_>>();
    assert_eq!(names.len(), 13);
    assert_eq!(
        contexts
            .iter()
            .map(|c| c["rounds"].as_u64().unwrap())
            .sum::<u64>(),
        883
    );
    m["contexts"] = json!(contexts);
    let previous = Path::new(PARENT).join("context/cr-previous");
    let parent = Path::new(PARENT).join("context/cr-current");
    assert_eq!(
        hash(&previous),
        "d5e1b2c981fb9bcab2beb69e3b2af5608d298d792c7e3814e87273b04509662e"
    );
    assert_eq!(
        hash(&parent),
        "c88a3528d5feb363732dd2557d1894c93e9161f4e3ec9e9d3c7e2564283bf2fe"
    );
    let clean = native["binary"].as_str().unwrap();
    assert_eq!(hash(clean), native["binary_sha256"]);
    for (name, src) in [
        ("cr-previous", previous.display().to_string()),
        ("cr-parent", parent.display().to_string()),
        ("cr-current", clean.into()),
        ("aws-runner", r.join("runner").display().to_string()),
        (
            "cr-xtask",
            "/home/ubuntu/src/zopro-perf-work/tool-target/release/xtask".into(),
        ),
        (
            "interval-verify",
            Path::new(PARENT)
                .join("context/interval-verify")
                .display()
                .to_string(),
        ),
    ] {
        let dest = context.join(name);
        fs::copy(&src, &dest).unwrap();
        assert_eq!(hash(&dest), hash(&src));
        container.insert(format!("/usr/local/bin/{name}"), hash(dest));
        pins.insert(src.clone(), hash(src));
    }
    let seed = Path::new(PARENT).join("proof-sha256-after-capture.json");
    assert_eq!(
        hash(&seed),
        "a53fea4a995310c8d67fbb31cb0738f36b4df7c2708f1b0a149fc3caaaf84938"
    );
    m["prior_proof_sha256"] = read(&seed);
    assert_eq!(m["prior_proof_sha256"].as_array().unwrap().len(), 50351);
    pins.insert(seed.display().to_string(), hash(&seed));
    m["container_pins"] = json!(container);
    m["mode_map"] = json!({"REF":"previous","PARENT":"parent","CLEAN":"current"});
    m["scope"] = "cleanDEFAULT all9best+4extra contexts,9blocks/151primary31others,66gates".into();
    m["source_audit"] = read(r.join("source-audit.json"));
    m["native_review"] = native;
    m["portable_review"] = read(r.join("portable-review.json"));
    m["helper_sha256"] = json!({});
    for f in [
        "runner.rs",
        "runner",
        "post.rs",
        "post",
        "statistics.rs",
        "design.md",
        "target-protocol.md",
        "prepare-package.rs",
    ] {
        m["helper_sha256"][f] = json!(hash(r.join(f)));
    }
    save(context.join("manifest.json"), m);
    let base =
        "558215002830.dkr.ecr.eu-north-1.amazonaws.com/zolana-prover:bench-pmu-c7a-20261027-123202";
    let o = Command::new("docker")
        .args(["image", "inspect", base, "--format", "{{.Id}}"])
        .output()
        .unwrap();
    assert!(o.status.success());
    assert_eq!(
        String::from_utf8(o.stdout).unwrap().trim(),
        "sha256:a24195e830e9becaa887ece0898c7c07b628edba3f365f439988e885c78bd1b5"
    );
    fs::write(context.join("Dockerfile"),format!("FROM {base}\nCOPY cr-previous cr-parent cr-current aws-runner cr-xtask interval-verify /usr/local/bin/\nCOPY basis/ /cr-basis/\nCOPY fixtures/ /fixtures/\nCOPY manifest.json /cr/manifest.json\nENTRYPOINT [\"/usr/local/bin/aws-runner\"]\n")).unwrap();
    fn collect(p: &Path, m: &mut BTreeMap<String, String>) {
        for e in fs::read_dir(p).unwrap() {
            let p = e.unwrap().path();
            if p.is_dir() {
                collect(&p, m)
            } else {
                m.insert(p.display().to_string(), hash(p));
            }
        }
    }
    collect(&context, &mut pins);
    for f in [
        "prepare-package.rs",
        "prepare-package",
        "runner.rs",
        "runner",
        "post.rs",
        "post",
        "statistics.rs",
        "design.md",
        "target-protocol.md",
    ] {
        let p = r.join(f);
        pins.insert(p.display().to_string(), hash(p));
    }
    save(r.join("docker-pins.json"), json!(pins));
    save(
        r.join("docker-plan.json"),
        json!({"version":1,"source_pins":r.join("docker-pins.json"),"steps":[{"kind":"command","name":"reader-models","argv":[r.join("post"),"test"],"timeout_seconds":60},{"kind":"command","name":"build-preflight-image","argv":["docker","build","-t","zopro-phi-grain-clean:preflight",context],"timeout_seconds":1200}]}),
    );
    println!("PreparedcleanDEFAULT3consumers/13contexts/all66gates/bothreaders/models BEFOREanynewSDKcall");
}
