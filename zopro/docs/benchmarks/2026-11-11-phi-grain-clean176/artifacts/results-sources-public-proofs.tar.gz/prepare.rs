use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
const PARENT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
const PROD: &str = "/home/ubuntu/src/zk-tools/zopro";
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn save(p: impl AsRef<Path>, v: &Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn main() {
    let r = Path::new(ROOT);
    assert!(!r.join("source").exists());
    let parent = read(Path::new(PARENT).join("target-analysis.json"));
    assert_eq!(parent["target_passed"], true);
    assert_eq!(parent["gates"].as_array().unwrap().len(), 12);
    let manifest=read(Path::new(PROD).join("docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json"));
    let orig = manifest["source_files_sha256"].as_object().unwrap();
    assert_eq!(orig.len(), 176);
    let mut pins = BTreeMap::new();
    for (rel, h) in orig {
        let p = Path::new(PROD).join(rel);
        assert_eq!(hash(&p), h.as_str().unwrap());
        let d = r.join("source").join(rel);
        fs::create_dir_all(d.parent().unwrap()).unwrap();
        fs::copy(&p, &d).unwrap();
        pins.insert(p.display().to_string(), hash(p));
    }
    let rel = "crates/zopro-core/src/msm_affine/g2_phi.rs";
    let p = r.join("source").join(rel);
    let before = "    short.par_iter_mut().for_each(|s| *s = phi_split(*s));";
    let after = "    short.par_iter_mut().with_min_len(128).for_each(|s| *s = phi_split(*s));";
    let text = fs::read_to_string(&p).unwrap();
    assert_eq!(text.matches(before).count(), 1);
    fs::write(&p, text.replace(before, after)).unwrap();
    let recovered = fs::read_to_string(&p).unwrap().replace(after, before);
    assert_eq!(
        format!("{:x}", Sha256::digest(recovered.as_bytes())),
        orig[rel]
    );
    save(
        r.join("source-audit.json"),
        &json!({"originals":orig,"changed_originals":1,"unchanged_originals":175,"edits":[{"path":rel,"before":before,"after":after}],"inverse_recovery":true,"production_unchanged":true,"default_body_no_experimental_cfg":true}),
    );
    fs::create_dir(r.join("support")).unwrap();
    for f in ["driver.rs", "support/perf.rs"] {
        fs::copy(Path::new(PARENT).join(f), r.join(f)).unwrap();
    }
    let native = fs::read_to_string(Path::new(PARENT).join("native.rs"))
        .unwrap()
        .replace(PARENT, ROOT);
    fs::write(r.join("native.rs"), native).unwrap();
    let compiler = "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
    let deps = "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
    let argv = vec![
        "--edition=2021".to_owned(),
        "-O".into(),
        r.join("native.rs").display().to_string(),
        "-L".into(),
        format!("dependency={deps}"),
        "--extern".into(),
        format!("serde_json={deps}/libserde_json-cdebb9338c2784ad.rlib"),
        "--extern".into(),
        format!("sha2={deps}/libsha2-16b8f2c03bdf5faa.rlib"),
        "-o".into(),
        r.join("native-helper").display().to_string(),
    ];
    let o = Command::new(compiler).args(&argv).output().unwrap();
    fs::write(r.join("native-helper.stdout"), o.stdout).unwrap();
    fs::write(r.join("native-helper.stderr"), o.stderr).unwrap();
    save(
        r.join("native-helper-build.json"),
        &json!({"compiler":compiler,"argv":argv,"success":o.status.success(),"exit_code":o.status.code()}),
    );
    assert!(o.status.success());
    let text = fs::read_to_string(Path::new(PARENT).join("candidate-plan.json"))
        .unwrap()
        .replace(PARENT, ROOT);
    let mut plan: Value = serde_json::from_str(&text).unwrap();
    for step in plan["steps"].as_array_mut().unwrap() {
        if let Some(env) = step.get_mut("environment") {
            let flags = env["RUSTFLAGS"]
                .as_str()
                .unwrap()
                .replace(" --check-cfg=cfg(zopro_phi_grain)", "")
                .replace(" --cfg zopro_phi_grain", "");
            assert!(
                !flags.contains("zopro_phi_grain")
                    && flags.contains("zopro_dense_busy_reset")
                    && flags.contains("target-cpu=znver4")
            );
            env["RUSTFLAGS"] = json!(flags);
            fs::write(
                r.join("candidate-flags.txt"),
                env["RUSTFLAGS"].as_str().unwrap(),
            )
            .unwrap();
        }
    }
    plan["source_pins"] = json!(r.join("build-pins.json"));
    save(r.join("candidate-plan.json"), &plan);
    for rel in orig.keys() {
        let p = r.join("source").join(rel);
        pins.insert(p.display().to_string(), hash(p));
    }
    for f in [
        "prepare.rs",
        "prepare",
        "design.md",
        "native.rs",
        "native-helper",
        "driver.rs",
        "support/perf.rs",
        "source-audit.json",
        "candidate-flags.txt",
        "candidate-plan.json",
    ] {
        let p = r.join(f);
        pins.insert(p.display().to_string(), hash(p));
    }
    for f in [
        "target-analysis.json",
        "native-review.json",
        "remote-review.json",
    ] {
        let p = Path::new(PARENT).join(f);
        pins.insert(p.display().to_string(), hash(p));
    }
    save(r.join("build-pins.json"), &json!(pins));
    println!("Prepared cleanDEFAULT176source,175exact+1reversible; coherentcandidateonly native5steps, noexperimentalCFG/noSDKrequests");
}
