use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let r = Path::new(ROOT);
    assert!(!r.join("portable-review.json").exists());
    assert_eq!(
        read(r.join("portable-runs/result.json"))["status"],
        "complete"
    );
    let step = r.join("portable-runs/generic-core-prover-cubic");
    let e = read(step.join("exit.json"));
    assert_eq!(e["success"], true);
    assert_eq!(e["returncode"], 0);
    for (f, k) in [
        ("stdout.log", "stdout_sha256"),
        ("stderr.log", "stderr_sha256"),
    ] {
        assert_eq!(hash(step.join(f)), e[k]);
    }
    let text = fs::read_to_string(step.join("stdout.log")).unwrap();
    for n in [102, 2, 0] {
        assert!(text.lines().any(|l| l.starts_with(&format!(
            "test result: ok. {n} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
        ))));
    }
    assert_eq!(
        read(step.join("tests.json"))["passed_tests"]
            .as_array()
            .unwrap()
            .len(),
        104
    );
    let cmd = read(step.join("command.json"));
    let flags = cmd["environment"]["RUSTFLAGS"].as_str().unwrap();
    for x in ["target-cpu=x86-64", "--cfg no_ifma", "--cfg no_asm"] {
        assert!(flags.contains(x));
    }
    assert!(!flags.contains("zopro_phi_grain"));
    let pins: BTreeMap<String, String> =
        serde_json::from_value(read(r.join("portable-pins.json"))).unwrap();
    for (p, h) in &pins {
        assert_eq!(&hash(p), h);
    }
    let native = read(r.join("native-review.json"));
    assert_eq!(
        hash(native["binary"].as_str().unwrap()),
        native["binary_sha256"]
    );
    let mut f = vec![];
    for entry in
        fs::read_dir(r.join("target-generic/x86_64-unknown-linux-gnu/release/.fingerprint"))
            .unwrap()
    {
        let p = entry.unwrap().path().join("test-lib-zopro_core.json");
        if p.exists() {
            let v = read(p);
            assert_eq!(
                v["rustflags"],
                json!(flags.split_whitespace().collect::<Vec<_>>())
            );
            f.push(v);
        }
    }
    assert_eq!(f.len(), 1);
    let v = json!({"status":"PASS","default_source_no_experimental_cfg":true,"core_tests":102,"prover_tests":2,"zolana_tests":0,"zolana_target_compiled":true,"command_receipts":1,"input_pins_checked":pins.len(),"fingerprints":f,"physical_ARM_execution":false,"new_SDK_requests":0,"new_exports":0,"canonical_ledger":50351});
    fs::write(
        r.join("portable-review.json"),
        serde_json::to_vec_pretty(&v).unwrap(),
    )
    .unwrap();
    println!("CleanDEFAULTgeneric102core+2proverPASS/Zolana0compiled, source/pins/nativeSDKunchanged; noexports");
}
