fn median9(mut values: Vec<f64>) -> f64 {
    assert_eq!(values.len(), 9);
    assert!(values.iter().all(|v| v.is_finite()));
    values.sort_by(f64::total_cmp);
    values[4]
}
fn paired9(
    values: &BTreeMap<(String, String, usize), f64>,
    context: &str,
    a: &str,
    b: &str,
) -> Value {
    let mut ratios = vec![];
    let mut savings = vec![];
    for block in 0..9 {
        let n = values[&(context.into(), a.into(), block)];
        let d = values[&(context.into(), b.into(), block)];
        assert!(n > 0. && d > 0. && n.is_finite() && d.is_finite());
        ratios.push(n / d);
        savings.push(d - n);
    }
    let wins = ratios.iter().filter(|&&x| x < 1.).count();
    ratios.sort_by(f64::total_cmp);
    json!({"context":context,"ratio":format!("{a}/{b}"),"lower":ratios[1],"median":ratios[4],"upper":ratios[7],"wins":wins,"paired_median_saving":median9(savings)})
}
fn statistical_models() {
    let mut v = BTreeMap::new();
    for b in 0..9 {
        for arm in ["A", "B"] {
            v.insert(("equal".into(), arm.into(), b), 2.);
        }
        v.insert(("reverse".into(), "A".into(), b), (9 - b) as f64);
        v.insert(("reverse".into(), "B".into(), b), (b + 1) as f64);
        v.insert(("other-same-worker".into(), "A".into(), b), 4.);
        v.insert(("other-same-worker".into(), "B".into(), b), 2.);
    }
    let e = paired9(&v, "equal", "A", "B");
    assert_eq!(e["median"], 1.);
    assert_eq!(e["lower"], 1.);
    assert_eq!(e["upper"], 1.);
    assert_eq!(e["wins"], 0);
    let r = paired9(&v, "reverse", "A", "B");
    assert_eq!(r["lower"], 0.25);
    assert_eq!(r["median"], 1.);
    assert_eq!(r["upper"], 4.);
    assert_eq!(r["wins"], 4);
    assert_eq!(paired9(&v, "other-same-worker", "A", "B")["median"], 2.);
    let mut pascal = vec![1u64];
    for _ in 0..9 {
        let mut next = vec![1];
        for w in pascal.windows(2) {
            next.push(w[0] + w[1]);
        }
        next.push(1);
        pascal = next;
    }
    assert_eq!(pascal[..2].iter().sum::<u64>(), 10);
    assert_eq!((1. - 2. * 10. / 512.) * 100., 96.09375);
    println!("PASS4models: ties, paired-order, context-isolation and binomial96.09375%");
}
