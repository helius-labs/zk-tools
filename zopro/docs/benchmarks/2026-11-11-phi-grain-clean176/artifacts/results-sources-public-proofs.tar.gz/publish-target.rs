use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
const DEST: &str = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-11-phi-grain-clean176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn copy(p: &Path, q: &Path) {
    fs::create_dir_all(q.parent().unwrap()).unwrap();
    fs::copy(p, q).unwrap();
}
fn tree(p: &Path, q: &Path) {
    for e in fs::read_dir(p).unwrap() {
        let s = e.unwrap().path();
        let d = q.join(s.file_name().unwrap());
        if s.is_dir() {
            tree(&s, &d)
        } else {
            copy(&s, &d)
        }
    }
}
fn inventory(p: &Path, base: &Path, m: &mut BTreeMap<String, String>) {
    for e in fs::read_dir(p).unwrap() {
        let p = e.unwrap().path();
        if p.is_dir() {
            inventory(&p, base, m)
        } else {
            assert!(m
                .insert(p.strip_prefix(base).unwrap().display().to_string(), hash(p))
                .is_none());
        }
    }
}
fn receipts(p: &Path) -> usize {
    let mut n = 0;
    for e in fs::read_dir(p).unwrap() {
        let d = e.unwrap().path();
        if !d.is_dir() {
            continue;
        }
        if d.join("exit.json").exists() {
            let e = read(d.join("exit.json"));
            assert_eq!(e["success"], true);
            assert_eq!(
                e.get("returncode").or_else(|| e.get("exit_code")).unwrap(),
                0
            );
            for (f, k) in [
                ("stdout.log", "stdout_sha256"),
                ("stderr.log", "stderr_sha256"),
            ] {
                assert_eq!(hash(d.join(f)), e[k]);
            }
            n += 1;
        } else {
            n += receipts(&d)
        }
    }
    n
}
fn median(mut v: Vec<f64>) -> f64 {
    assert_eq!(v.len(), 9);
    v.sort_by(f64::total_cmp);
    v[4]
}
fn main() {
    let r = Path::new(ROOT);
    let d = Path::new(DEST);
    let a = d.join("artifacts");
    assert!(!d.exists());
    fs::create_dir_all(&a).unwrap();
    let review = read(r.join("remote-review.json"));
    assert_eq!(review["status"], "PASS");
    assert_eq!(review["canonical_verified_exports"], 50752);
    let analysis = read(r.join("target-analysis.json"));
    let gates = analysis["gates"].as_array().unwrap();
    assert_eq!(gates.len(), 66);
    let rows = read(r.join("remote-results/output/measure/rows.json"));
    let mut metrics = BTreeMap::<(String, String, usize), (f64, f64, f64)>::new();
    let mut resources = vec![];
    for row in rows
        .as_array()
        .unwrap()
        .iter()
        .filter(|x| x["job"]["panel"] == "latency")
    {
        let j = &row["job"];
        let u = &row["usage"];
        let ctx = j["case"]["name"].as_str().unwrap();
        let arm = j["arm"].as_str().unwrap();
        let block = j["block"].as_u64().unwrap() as usize;
        let n = j["rounds"].as_u64().unwrap();
        assert_eq!(n, if j["case"]["shape"] == "1x2" { 151 } else { 31 });
        let ms = row["mean_ns"].as_f64().unwrap() / 1e6;
        let cpu =
            (u["user_cpu_ms"].as_f64().unwrap() + u["system_cpu_ms"].as_f64().unwrap()) / n as f64;
        let rss = u["whole_process_maxrss_kib"].as_f64().unwrap() / 1024.;
        assert!(metrics
            .insert((ctx.into(), arm.into(), block), (ms, cpu, rss))
            .is_none());
        resources.push(json!({"job":j["name"],"context":ctx,"workers":j["workers"],"arm":arm,"block":block,"ms":ms,"cpu_ms":cpu,"rss_mib":rss,"minor_faults_per_request":u["minor_faults"].as_f64().unwrap()/n as f64,"major_faults_per_request":u["major_faults"].as_f64().unwrap()/n as f64}));
    }
    assert_eq!(metrics.len(), 351);
    for g in gates {
        let ctx = g["context"].as_str().unwrap();
        let kind = g["kind"].as_str().unwrap();
        if kind == "RSS" {
            let get = |arm: &str| {
                (0..9)
                    .map(|b| metrics[&(ctx.into(), arm.into(), b)].2)
                    .fold(0., f64::max)
            };
            let clean = get("CLEAN");
            let limit = get("REF").max(get("PARENT")) * 1.05 + 1.;
            assert_eq!(g["CLEAN_mib"], clean);
            assert_eq!(g["limit_mib"], limit);
            assert_eq!(g["pass"], clean <= limit);
            continue;
        }
        let arms = g["ratio"].as_str().unwrap().split('/').collect::<Vec<_>>();
        let mut ratios = (0..9)
            .map(|b| {
                let n = metrics[&(ctx.into(), arms[0].into(), b)];
                let d = metrics[&(ctx.into(), arms[1].into(), b)];
                if kind == "CPU" {
                    n.1 / d.1
                } else {
                    n.0 / d.0
                }
            })
            .collect::<Vec<_>>();
        let wins = ratios.iter().filter(|v| **v < 1.).count();
        ratios.sort_by(f64::total_cmp);
        for (k, i) in [("lower", 1), ("median", 4), ("upper", 7)] {
            assert!((g[k].as_f64().unwrap() - ratios[i]).abs() < 1e-12);
        }
        assert_eq!(g["wins"], wins);
        assert_eq!(
            g["pass"],
            if kind == "primary96_gain" {
                ratios[7] < 1.
            } else {
                ratios[7] <= 1.02
            }
        );
    }
    for m in analysis["medians"].as_array().unwrap() {
        let ctx = m["context"].as_str().unwrap();
        let arm = m["arm"].as_str().unwrap();
        for (k, i) in [("ms", 0), ("cpu_ms", 1)] {
            let v = (0..9)
                .map(|b| {
                    let row = metrics[&(ctx.into(), arm.into(), b)];
                    if i == 0 {
                        row.0
                    } else {
                        row.1
                    }
                })
                .collect();
            assert!((m[k].as_f64().unwrap() - median(v)).abs() < 1e-9);
        }
    }
    let passed = gates.iter().filter(|g| g["pass"] == true).count();
    assert_eq!(passed, 58);
    assert_eq!(analysis["qualification_passed"], false);
    let command_receipts = receipts(&r.join("remote-results/output/measure/workflow"));
    assert_eq!(command_receipts, 780);
    let transported = receipts(&r.join("transport-verification"));
    assert_eq!(transported, 390);
    let transport_names = fs::read_dir(r.join("transport-verification"))
        .unwrap()
        .map(|e| e.unwrap().file_name().to_string_lossy().into_owned())
        .collect::<Vec<_>>();
    assert_eq!(
        transport_names
            .iter()
            .filter(|n| n.contains("-w4-"))
            .count(),
        0
    );
    assert_eq!(
        transport_names
            .iter()
            .filter(|n| !n.contains("-w4-"))
            .count(),
        390
    );
    assert_eq!(
        read(r.join("termination-observation.json"))["Reservations"][0]["Instances"][0]["State"]
            ["Name"],
        "terminated"
    );
    assert!(read(r.join("volume-observation.json"))["Volumes"]
        .as_array()
        .unwrap()
        .is_empty());
    assert!(read(r.join("ecr-cleanup.json"))["failures"]
        .as_array()
        .unwrap()
        .is_empty());
    assert_eq!(read(r.join("ecr-absence.json"))["images"], 0);
    assert_eq!(
        read(r.join("ecr-absence.json"))["failures"],
        json!(["ImageNotFound"])
    );
    assert!(read(r.join("existing-benchmarks-after-cleanup.json"))
        .as_array()
        .unwrap()
        .is_empty());
    assert_eq!(
        read(r.join("bucket-cleanup.json"))["status"],
        "owned object removed; bucket deleted"
    );
    let cleanup = json!({"instance_id":"i-03e4693289a111e75","state":"terminated","owned_volumes":0,"temporary_ECR_tag_absent":true,"private_S3_object_and_bucket_deleted":true,"live_temporary_benchmarks":0,"region":"eu-north-1"});
    save(r.join("cleanup.json"), &cleanup);
    let inspect = read(r.join("remote-results/container-inspect.json"));
    let inspect = &inspect[0];
    let host = &inspect["HostConfig"];
    assert_eq!(inspect["State"]["ExitCode"], 0);
    assert_eq!(host["NanoCpus"], 96000000000u64);
    assert_eq!(host["Memory"], 30u64 << 30);
    assert_eq!(host["MemorySwap"], 30u64 << 30);
    assert_eq!(host["NetworkMode"], "none");
    let quality = json!({"container_image":inspect["Config"]["Image"],"container_exit":0,"host_config":{"NanoCpus":host["NanoCpus"],"Memory":host["Memory"],"MemorySwap":host["MemorySwap"],"PidsLimit":host["PidsLimit"],"CapDrop":host["CapDrop"],"SecurityOpt":host["SecurityOpt"],"NetworkMode":host["NetworkMode"]},"before":read(r.join("remote-results/output/measure/before.json")),"after":read(r.join("remote-results/output/measure/after.json")),"physical_host_exclusivity_established":false});
    save(r.join("target-quality.json"), &quality);
    save(r.join("resource-rows.json"), &json!(resources));
    // Recheck all original source hashes against both the retained tree and production.
    let audit = read(r.join("source-audit.json"));
    let repo = Path::new("/home/ubuntu/src/zk-tools/zopro");
    let edit = &audit["edits"][0];
    let changed = edit["path"].as_str().unwrap();
    let mut manifest = BTreeMap::new();
    for (p, h) in audit["originals"].as_object().unwrap() {
        assert_eq!(&json!(hash(repo.join(p))), h);
        let bytes = fs::read(r.join("source").join(p)).unwrap();
        if p == changed {
            let s = String::from_utf8(bytes.clone()).unwrap();
            let from = edit["after"].as_str().unwrap();
            assert_eq!(s.matches(from).count(), 1);
            let restored = s.replacen(from, edit["before"].as_str().unwrap(), 1);
            assert_eq!(
                &json!(format!("{:x}", Sha256::digest(restored.as_bytes()))),
                h
            );
        } else {
            assert_eq!(&json!(format!("{:x}", Sha256::digest(&bytes))), h);
        }
        manifest.insert(p.clone(), hash(r.join("source").join(p)));
    }
    assert_eq!(manifest.len(), 176);
    save(r.join("candidate-source-manifest.json"), &json!(manifest));
    let release = json!({"decision":"NOT_ADOPTED","reason":"58/66 fixed checks pass; all 66 required","production_changed":false,"175_source_files_unchanged":true,"one_reversible_default_iterator_edit":true,"new_tables_buffers_allocators_pools_unsafe_or_shared_state":false,"all13_RSS_guards_pass":gates.iter().filter(|g|g["kind"]=="RSS").all(|g|g["pass"]==true),"new_concurrent_SDK_cases":0,"new_concurrent_throughput_claim":false,"resource_concurrency_release_qualification_not_claimed":true,"minimum_RAM_or_phone_ARM_execution_claim":false,"candidate_source_manifest_sha256":hash(r.join("candidate-source-manifest.json")),"production_originals_rechecked":176});
    save(r.join("release-review.json"), &release);
    let stage = r.join("publication-source");
    fs::create_dir(&stage).unwrap();
    for f in [
        "design.md",
        "target-protocol.md",
        "prepare.rs",
        "native.rs",
        "review-native.rs",
        "prepare-portable.rs",
        "review-portable.rs",
        "prepare-package.rs",
        "prepare-stage.rs",
        "stage.rs",
        "prepare-cloud.rs",
        "cloud.rs",
        "transfer.rs",
        "sigv4.rs",
        "driver.rs",
        "runner.rs",
        "post.rs",
        "statistics.rs",
        "publish-target.rs",
        "source-audit.json",
        "candidate-source-manifest.json",
        "release-review.json",
        "native-review.json",
        "portable-review.json",
        "local-review.json",
        "remote-review.json",
        "target-analysis.json",
        "resource-rows.json",
        "target-quality.json",
        "cleanup.json",
        "candidate-flags.txt",
        "candidate-plan.json",
        "portable-plan.json",
        "docker-plan.json",
        "preflight-plan.json",
        "final-plan.json",
        "build-pins.json",
        "portable-pins.json",
        "docker-pins.json",
        "preflight-pins.json",
        "final-pins.json",
        "frozen-candidate.json",
        "image-manifest.json",
        "run-id.txt",
        "launch.json",
        "launch-result.json",
        "boot-command.json",
        "boot-parameters.json",
        "boot-result.json",
        "pull-command.json",
        "pull-parameters.json",
        "pull-result.json",
        "measure-command.json",
        "measure-parameters.json",
        "measure-result.json",
        "package-command.json",
        "package-parameters.json",
        "package-result.json",
        "upload-command.json",
        "upload-parameters-redacted.json",
        "upload-result.json",
        "retrieval-complete.json",
        "termination-result.json",
        "termination-observation.json",
        "volume-observation.json",
        "ecr-cleanup.json",
        "ecr-absence.json",
        "bucket-cleanup.json",
        "existing-benchmarks-before-launch.json",
        "existing-benchmarks-after-cleanup.json",
        "network-check.json",
        "publish.stdout",
        "publish.stderr",
    ] {
        copy(&r.join(f), &stage.join(f));
    }
    tree(&r.join("source"), &stage.join("source"));
    tree(&r.join("support"), &stage.join("support"));
    copy(
        &r.join("context/manifest.json"),
        &stage.join("context-manifest.json"),
    );
    copy(&r.join("context/Dockerfile"), &stage.join("Dockerfile"));
    for f in [
        "native-candidate",
        "portable-runs",
        "docker-runs",
        "preflight-runs",
        "final-runs",
    ] {
        tree(&r.join(f), &stage.join(f));
    }
    tree(
        &r.join("local-output/preflight"),
        &stage.join("local-preflight"),
    );
    tree(
        &r.join("remote-results/output/measure"),
        &stage.join("cloud"),
    );
    tree(
        &r.join("transport-verification"),
        &stage.join("transport-verification"),
    );
    for f in ["hardware.txt", "post-host-state.txt", "runner.log"] {
        copy(&r.join("remote-results").join(f), &stage.join(f));
    }
    let mut files = BTreeMap::new();
    inventory(&stage, &stage, &mut files);
    save(stage.join("manifest.json"), &json!(files));
    let archive = a.join("results-sources-public-proofs.tar.gz");
    assert!(Command::new("tar")
        .args([
            "--sort=name",
            "--mtime=2026-11-11 00:00:00Z",
            "--owner=0",
            "--group=0",
            "--numeric-owner",
            "-czf"
        ])
        .arg(&archive)
        .arg("-C")
        .arg(&stage)
        .arg(".")
        .status()
        .unwrap()
        .success());
    let round = r.join("publication-roundtrip");
    fs::create_dir(&round).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&round)
        .status()
        .unwrap()
        .success());
    let mut recovered = BTreeMap::new();
    inventory(&round, &round, &mut recovered);
    recovered.remove("manifest.json");
    assert_eq!(recovered, files);
    assert_eq!(read(round.join("manifest.json")), json!(files));
    for f in [
        "target-protocol.md",
        "source-audit.json",
        "candidate-source-manifest.json",
        "release-review.json",
        "native-review.json",
        "portable-review.json",
        "local-review.json",
        "remote-review.json",
        "target-analysis.json",
        "resource-rows.json",
        "target-quality.json",
        "cleanup.json",
    ] {
        copy(&r.join(f), &a.join(f));
    }
    let publication = json!({"status":"PASS","candidate_qualification_passed":false,"checks_passed":passed,"checks_required":66,"production_changed":false,"target_SDK_requests":25050,"combined_SDK_requests":25094,"target_timed_samples":23880,"new_target_Gnark_exports":390,"combined_preflight_and_target_exports":401,"canonical_verified_exports":50752,"canonical_ledger_sha256":hash(r.join("proof-sha256-after-capture.json")),"cloud_workflow_receipts_checked":command_receipts,"transport_verification_receipts_checked":transported,"independent_producer_ratio_recheck":true,"source_archive_members":files.len(),"source_archive_bytes":fs::metadata(&archive).unwrap().len(),"source_archive_sha256":hash(&archive),"cleanup":cleanup,"full10xgoal_achieved":false});
    save(a.join("publication.json"), &publication);
    save(r.join("publication.json"), &publication);
    let mut text=String::from("# Default G2 scalar-grain qualification on C7a\n\nThe default-build candidate is **not adopted**: **58 of 66 fixed checks pass**, with all 66 required. At 96 workers, 1×2 improves 3.16% paired versus the accepted SDK but is 2.27% slower paired than the earlier experimental build. Production remains unchanged. All fresh exported proofs verify, and all thirteen peak-RSS guards pass.\n\nThis follow-up tests the actual unconditional `with_min_len(128)` change to the existing in-place G2 `phi_split` iterator, without its experimental cfg. The retained candidate has 175 exact original files and one reversibly changed file. Arithmetic, item ordering, scalar/point representations, allocations, forecasts, ABI, Cargo.lock and worker pools are unchanged. The edit restricts Rayon partition granularity; it adds no lookup table, key preparation plan, heap buffer or runtime selector.\n\nREF is the accepted Zen4 SDK `d5e1b2c981fb9bcab2beb69e3b2af5608d298d792c7e3814e87273b04509662e`. PARENT is the earlier qualified experimental build `c88a3528d5feb363732dd2557d1894c93e9161f4e3ec9e9d3c7e2564283bf2fe`. CLEAN is the new default build `96915d56cec6fc3479e155001ac2f2e69acf13895a454a765172bbe6d9bfe22e`. PARENT is an algorithmic control, not a newly rebuilt original iterator. All three use the original untraced accepted SDK driver. The [preceding experiment](../2026-11-11-phi-grain-c7a176/README.md) remains valid for its own binaries and protocol; its result does not automatically qualify this different default artifact.\n\n|Context|Build|Proof ms|Whole-loop CPU ms/request|Maximum lifetime RSS MiB|\n|:---|:---|---:|---:|---:|\n");
    for m in analysis["medians"].as_array().unwrap() {
        text += &format!(
            "|{}|{}|{:.6}|{:.3}|{:.2}|\n",
            m["context"].as_str().unwrap(),
            m["arm"].as_str().unwrap(),
            m["ms"].as_f64().unwrap(),
            m["cpu_ms"].as_f64().unwrap(),
            m["max_rss_mib"].as_f64().unwrap()
        );
    }
    text+="\nLatency is the median of nine process arithmetic means, with 151 timed requests for 1×2 and 31 for other shapes after three primes. Each timer covers fresh assignment, solving, blinding, proving, SDK verification and serialization. Loading, primes, export and external verification are excluded. CPU sums user and system time across threads and includes ordinary loop work between SDK timers. RSS is the maximum process lifetime peak, including loading and primes; it is not a minimum-RAM bound. Process masks and individual worker masks are checked before and after each run. Default SDK stacks and accepted allocator settings are retained.\n\nThe fixed protocol covers nine shapes at the previously accepted best worker counts, plus 1×2 at 16/64/96 and 2×2 at 96. Context order rotates and reverses across nine blocks; arm order also rotates/reverses. Pairing uses the same context and block. Sorted ratio ranks 1/7 (zero based) give nominal 96.09375% marginal coverage under independent exchangeable blocks, without familywise or stationarity guarantees. All 52 latency/CPU nonregression upper bounds must be at most 1.02. All thirteen RSS guards require CLEAN ≤ max(REF, PARENT)×1.05+1 MiB; the primary 96-worker latency upper bound versus REF must be below one. There are no exclusions, extensions, gain floors, threshold changes or subset rescues. Paired ratios and displayed medians use different aggregation.\n\n|Context|Check|Ratio|Lower|Median|Upper|Wins / 9|Pass|\n|:---|:---|:---|---:|---:|---:|---:|:---|\n";
    for g in gates {
        if g["kind"] == "RSS" {
            continue;
        }
        text += &format!(
            "|{}|{}|{}|{:.6}|{:.6}|{:.6}|{}|{}|\n",
            g["context"].as_str().unwrap(),
            g["kind"].as_str().unwrap(),
            g["ratio"].as_str().unwrap(),
            g["lower"].as_f64().unwrap(),
            g["median"].as_f64().unwrap(),
            g["upper"].as_f64().unwrap(),
            g["wins"],
            if g["pass"] == true { "yes" } else { "no" }
        );
    }
    text+="\nSix latency and two CPU checks fail. Most failed intervals straddle parity; those failures do not establish a regression by themselves. The primary CLEAN/PARENT latency interval is wholly above one: [1.004103, 1.034023], median 1.022718. The effective source operation is the same, but these are different compiled artifacts; compiler layout, placement interactions and run variation have not been isolated. The observed discrepancy must not be attributed to a specific cause from this experiment alone. The default build retains most of the high-core CPU saving versus REF: paired CPU ratio 0.881043, or 11.90% less. This still does not improve the best tested 1×2 latency, which is 11.406619 ms at 32 workers for CLEAN.\n\n|Shape|CLEAN workers|CLEAN ms|Peak RSS MiB|Supplied M5 CPU ms|CPU speedup|Supplied M5 Metal ms|Metal speedup|10× CPU target ms|\n|:---|---:|---:|---:|---:|---:|---:|---:|---:|\n";
    for m in analysis["all8"].as_array().unwrap() {
        text += &format!(
            "|{}|{}|{:.6}|{:.2}|{:.0}|{:.3}×|{:.0}|{:.3}×|{:.1}|\n",
            m["shape"].as_str().unwrap(),
            m["workers"],
            m["ms"].as_f64().unwrap(),
            m["max_rss_mib"].as_f64().unwrap(),
            m["M5_CPU_ms"].as_f64().unwrap(),
            m["CPU_speedup"].as_f64().unwrap(),
            m["M5_Metal_ms"].as_f64().unwrap(),
            m["Metal_speedup"].as_f64().unwrap(),
            m["CPU10x_target_ms"].as_f64().unwrap()
        );
    }
    text+="\nThese are descriptive selections among tested worker counts, not a proven global optimum. Merge 54×1 at 64 workers measures CLEAN 123.377169 ms / 2,150.64 MiB, REF 124.312911 ms / 2,195.74 MiB and PARENT 123.169610 ms / 2,130.14 MiB; no supplied M5 reference exists for this shape. All eight CPU 10× targets remain unmet. No fresh Aeglos measurement is made. Its earlier pinned 1×2 result of 7.902802 ms at 96 workers in the [previous all-shape comparison](../2026-11-10-accepted-current-c7a176/README.md) remains historical context, not a new matched comparison; CLEAN has not demonstrated beating it.\n\nThe clean native build passes 127 core, two prover and six cubic tests, coherently rebuilding eight libraries with Rust 1.98.1, znver4, O3, fat LTO, one codegen unit and the accepted manual flags including dense busy reset. Separate generic x86-64/noIFMA/noASM validation passes 102 core and two prover tests; the Zolana target compiles with zero tests enabled. Four independent reader models cover ties, pairing, context isolation and exact binomial coverage. Field source/qualification is inherited. This experiment adds no concurrent SDK workload or throughput claim; because performance qualification fails, no production release qualification is claimed.\n\nThe local functional preflight makes 44 SDK calls and eleven fresh Gnark-verified 164-byte exports across all nine CLEAN shapes plus primary REF/PARENT at four workers. Target preflight plus nine main blocks make 25,050 SDK calls and 390 fresh exports, all externally verified on the server. After size/SHA-bound retrieval, all 390 verify once more locally without increasing the distinct count. The independent reader validates 23,880 timed samples, argv/environment, stream hashes, fixed worker placement, means, bindings and freshness. A separate publication reader recomputes all 66 gates from producer summaries and checks 780 server command receipts and 390 local transport-verification receipts. The canonical verified-export ledger advances **50,351 → 50,362 → 50,752**. Combined local/target work is 25,094 calls and 401 distinct fresh exports. No successful science is replayed for bookkeeping.\n\nOne c7a.24xlarge supplies 96 physical cores without SMT. The network-disabled container has a 96-CPU quota, 30 GiB memory/no swap, PID limit 2,048, dropped capabilities and no-new-privileges. This is an experimental container setting, not an architectural RAM cap. All observed major-fault counts are zero; CPU throttling, memory-pressure/OOM and swap-event counters do not increase. Minor-fault rows are preserved. Physical-host exclusivity and frequency locking are not established. During every SDK preflight/recording only the confirmed live handle is polled; no owned helper/build/hash/analysis/report overlaps capture. All main captures finish before main-export verification.\n\nThe owned VM is terminated, its encrypted delete-on-termination volume and temporary ECR tag are absent, and the private transfer object/bucket and secret URL file are deleted. No live temporary benchmark instance remains in the checked region. The fixed 90-minute termination timer is retained throughout. There are no new phone/ARM/TEE, huge-circuit, memory-pressure, swap or minimum-RAM results.\n\nNext work should distinguish reproducible scalar-grain benefits from artifact-specific effects before another adoption attempt, using retained binaries and source/build evidence first. The failed 66-check qualification is closed; its bounds will not be relaxed or its nine blocks extended. The broader high-core scaling gap also remains, so this partial improvement is not a complete explanation.\n\n[Analysis and all 66 checks](artifacts/target-analysis.json), [resource rows](artifacts/resource-rows.json), [protocol](artifacts/target-protocol.md), [proof/sample review](artifacts/remote-review.json), [native review](artifacts/native-review.json), [generic review](artifacts/portable-review.json), [source audit](artifacts/source-audit.json), [release decision](artifacts/release-review.json), [quality](artifacts/target-quality.json), [cleanup](artifacts/cleanup.json), [publication checks](artifacts/publication.json), [raw results, sources, receipts and public proofs](artifacts/results-sources-public-proofs.tar.gz), [checksums](SHA256SUMS). The archive round-trips exact bytes and hashes. Executables, compiled libraries, private production inputs, credential files and unfiltered container environment are excluded. Reproduction requires the pinned toolchain/dependencies and private inputs.\n\nLocal directory: `/home/ubuntu/src/zopro-perf-work/phi-grain-clean176`; clean SDK: `sdk-candidate-znver4`.\n";
    fs::write(d.join("README.md"), text).unwrap();
    let mut entries = fs::read_dir(&a)
        .unwrap()
        .map(|e| e.unwrap().path())
        .collect::<Vec<_>>();
    entries.sort();
    let mut sums = String::new();
    for p in entries {
        sums += &format!(
            "{}  artifacts/{}\n",
            hash(&p),
            p.file_name().unwrap().to_str().unwrap()
        );
    }
    sums += &format!("{}  README.md\n", hash(d.join("README.md")));
    fs::write(d.join("SHA256SUMS"), sums).unwrap();
    assert!(Command::new("sha256sum")
        .args(["-c", "SHA256SUMS"])
        .current_dir(d)
        .status()
        .unwrap()
        .success());
    println!("{publication}");
}
