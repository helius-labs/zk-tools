use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
const PRIOR: &str =
    "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176/proof-sha256-after-capture.json";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn map(p: &str, local: bool) -> PathBuf {
    let r = Path::new(ROOT);
    if let Some(s) = p.strip_prefix("/output/") {
        return r
            .join(if local {
                "local-output"
            } else {
                "remote-results/output"
            })
            .join(s);
    }
    for (prefix, dir) in [
        ("/cr-basis/", "context/basis"),
        ("/fixtures/", "context/fixtures"),
        ("/usr/local/bin/", "context"),
        ("/cr/", "context"),
    ] {
        if let Some(s) = p.strip_prefix(prefix) {
            return r.join(dir).join(s);
        }
    }
    panic!("unsupported container input {p}")
}
fn expected() -> BTreeMap<String, (String, usize, usize)> {
    let mut m = BTreeMap::new();
    for (shape, w) in [
        ("1x2", 32),
        ("2x2", 32),
        ("4x2", 64),
        ("8x2", 64),
        ("12x2", 64),
        ("16x2", 64),
        ("24x2", 64),
        ("merge-24x1", 64),
        ("merge-54x1", 64),
        ("1x2", 16),
        ("1x2", 64),
        ("1x2", 96),
        ("2x2", 96),
    ] {
        assert!(m
            .insert(
                format!("{shape}-w{w}"),
                (shape.into(), w, if shape == "1x2" { 151 } else { 31 })
            )
            .is_none());
    }
    m
}
include!("statistics.rs");
fn main() {
    let op = std::env::args().nth(1).unwrap();
    if op == "test" {
        statistical_models();
        assert_eq!(expected().len(), 13);
        return;
    }
    let local = op == "local";
    assert!(local || op == "remote");
    let r = Path::new(ROOT);
    let dir = r.join(if local {
        "local-output/preflight"
    } else {
        "remote-results/output/measure"
    });
    let complete = read(dir.join("complete.json"));
    assert_eq!(complete["status"], "complete");
    assert_eq!(
        complete["distinct_gnark_exports"],
        if local { 11 } else { 390 }
    );
    let mut ledger: BTreeSet<String> = serde_json::from_value(if local {
        read(PRIOR)
    } else {
        read(r.join("proof-sha256-after-preflight.json"))
    })
    .unwrap();
    assert_eq!(ledger.len(), if local { 50351 } else { 50362 });
    let before = ledger.clone();
    let pins: BTreeMap<String, String> =
        serde_json::from_value(read(dir.join("pins.json"))).unwrap();
    for (p, h) in &pins {
        assert_eq!(&hash(map(p, local)), h);
    }
    let jobs = read(dir.join("jobs.json"));
    let plan = read(dir.join("plan.json"));
    assert_eq!(
        plan["steps"].as_array().unwrap().len(),
        if local { 22 } else { 780 }
    );
    for s in plan["steps"].as_array().unwrap() {
        let d = dir.join("workflow").join(s["name"].as_str().unwrap());
        let e = read(d.join("exit.json"));
        assert_eq!(e["success"], true);
        assert_eq!(e["returncode"], 0);
        for (f, k) in [
            ("stdout.log", "stdout_sha256"),
            ("stderr.log", "stderr_sha256"),
        ] {
            assert_eq!(hash(d.join(f)), e[k]);
        }
        let command = read(d.join("command.json"));
        assert_eq!(
            &command["argv"].as_array().unwrap()[4..],
            s["argv"].as_array().unwrap()
        );
        assert_eq!(command["environment"], s["environment"]);
    }
    let producer = read(dir.join("rows.json"));
    let definitions = expected();
    let mut latency = BTreeMap::new();
    let mut cpu = BTreeMap::new();
    let mut rss = BTreeMap::<(String, String), f64>::new();
    let mut timed = 0u64;
    let mut resources = vec![];
    let mut seen_jobs = BTreeSet::new();
    for j in jobs.as_array().unwrap() {
        let name = j["name"].as_str().unwrap();
        assert!(seen_jobs.insert(name));
        let proof = map(j["proof_dir"].as_str().unwrap(), local);
        assert_eq!(fs::metadata(proof.join("0.proof")).unwrap().len(), 164);
        let ph = hash(proof.join("0.proof"));
        assert!(ledger.insert(ph.clone()));
        let public = hash(proof.join("0.public"));
        assert_eq!(public, j["case"]["public_sha256"]);
        let verified = fs::read_to_string(
            dir.join("workflow")
                .join(format!("verify-{name}"))
                .join("stdout.log"),
        )
        .unwrap();
        for binding in [
            format!("proof_sha256={ph}"),
            format!("public_sha256={public}"),
            format!(
                "image_sha256={}",
                j["case"]["image_sha256"].as_str().unwrap()
            ),
        ] {
            assert!(verified.contains(&binding));
        }
        let raw = fs::read_to_string(dir.join("workflow").join(name).join("stdout.log")).unwrap();
        let mut total = 0u128;
        let mut n = 0u64;
        for l in raw.lines().filter_map(|l| l.strip_prefix("SAMPLE ")) {
            let v: Value = serde_json::from_str(l).unwrap();
            assert_eq!(v["round"], n);
            let ns = v["ns"]
                .as_u64()
                .unwrap_or_else(|| (v["ms"].as_f64().unwrap() * 1e6).round() as u64);
            assert!(ns > 0);
            total += ns as u128;
            n += 1;
        }
        assert_eq!(n, j["rounds"]);
        timed += n;
        let mean = total as f64 / n as f64;
        let p = producer
            .as_array()
            .unwrap()
            .iter()
            .find(|p| p["job"]["name"] == name)
            .unwrap();
        assert!((p["mean_ns"].as_f64().unwrap() - mean).abs() <= 1e-6);
        let u: Value = serde_json::from_str(
            raw.lines()
                .find_map(|l| l.strip_prefix("SUMMARY "))
                .unwrap(),
        )
        .unwrap();
        assert_eq!(u["rounds"], j["rounds"]);
        assert_eq!(u["priming"], 3);
        assert_eq!(u["workers"], j["workers"]);
        assert_eq!(u["placement_before"], u["placement_after"]);
        let placement = &u["placement_before"];
        assert_eq!(
            placement["tasks"].as_u64().unwrap(),
            j["workers"].as_u64().unwrap() + 1
        );
        assert_eq!(
            placement["worker_rows"].as_array().unwrap().len() as u64,
            j["workers"]
        );
        for (i, w) in placement["worker_rows"]
            .as_array()
            .unwrap()
            .iter()
            .enumerate()
        {
            assert_eq!(w["index"], i);
            assert_eq!(w["allowed"], json!([i]));
        }
        if !local {
            let ctx = j["case"]["name"].as_str().unwrap();
            let (shape, workers, rounds) = &definitions[ctx];
            assert_eq!(j["case"]["shape"], shape.as_str());
            assert_eq!(j["workers"], *workers);
            if j["panel"] == "latency" {
                assert_eq!(n, *rounds as u64);
                let key = (
                    ctx.to_owned(),
                    j["arm"].as_str().unwrap().to_owned(),
                    j["block"].as_u64().unwrap() as usize,
                );
                assert!(key.2 < 9);
                let cpu_ms = (u["user_cpu_ms"].as_f64().unwrap()
                    + u["system_cpu_ms"].as_f64().unwrap())
                    / n as f64;
                let rss_mib = u["whole_process_maxrss_kib"].as_f64().unwrap() / 1024.;
                assert!(latency.insert(key.clone(), mean / 1e6).is_none());
                assert!(cpu.insert(key.clone(), cpu_ms).is_none());
                rss.entry((key.0.clone(), key.1.clone()))
                    .and_modify(|x| *x = x.max(rss_mib))
                    .or_insert(rss_mib);
                resources.push(json!({"context":ctx,"job":name,"shape":shape,"workers":workers,"arm":j["arm"],"block":key.2,"ms":mean/1e6,"cpu_ms":cpu_ms,"rss_mib":rss_mib,"major_faults_per_request":u["major_faults"].as_f64().unwrap()/n as f64,"minor_faults_per_request":u["minor_faults"].as_f64().unwrap()/n as f64}));
            } else {
                assert_eq!(j["panel"], "preflight");
                assert_eq!(n, 1);
            }
            let d = r.join("transport-verification").join(name);
            fs::create_dir_all(&d).unwrap();
            assert!(!d.join("exit.json").exists());
            let argv = vec![
                r.join("context/interval-verify").display().to_string(),
                map(j["case"]["image"].as_str().unwrap(), true)
                    .display()
                    .to_string(),
                j["case"]["image_sha256"].as_str().unwrap().into(),
                proof.join("0.proof").display().to_string(),
                proof.join("0.public").display().to_string(),
                public,
            ];
            let o = Command::new(&argv[0]).args(&argv[1..]).output().unwrap();
            fs::write(d.join("stdout.log"), o.stdout).unwrap();
            fs::write(d.join("stderr.log"), o.stderr).unwrap();
            save(d.join("command.json"), json!({"argv":argv}));
            save(
                d.join("exit.json"),
                json!({"success":o.status.success(),"exit_code":o.status.code(),"stdout_sha256":hash(d.join("stdout.log")),"stderr_sha256":hash(d.join("stderr.log"))}),
            );
            assert!(o.status.success());
        }
    }
    assert_eq!(ledger.len(), if local { 50362 } else { 50752 });
    assert_eq!(
        json!(ledger.difference(&before).collect::<Vec<_>>()),
        complete["new_proof_sha256"]
    );
    assert_eq!(timed, if local { 11 } else { 23880 });
    save(
        r.join(if local {
            "proof-sha256-after-preflight.json"
        } else {
            "proof-sha256-after-capture.json"
        }),
        json!(ledger),
    );
    if !local {
        assert_eq!(latency.len(), 351);
        let mut gates = vec![];
        let mut medians = vec![];
        for (ctx, (shape, w, _)) in &definitions {
            for arm in ["REF", "PARENT", "CLEAN"] {
                medians.push(json!({"context":ctx,"shape":shape,"workers":w,"arm":arm,"ms":median9((0..9).map(|b|latency[&(ctx.clone(),arm.into(),b)]).collect()),"cpu_ms":median9((0..9).map(|b|cpu[&(ctx.clone(),arm.into(),b)]).collect()),"max_rss_mib":rss[&(ctx.clone(),arm.into())]}));
            }
            for arm in ["REF", "PARENT"] {
                for (metric, values) in [("latency", &latency), ("CPU", &cpu)] {
                    let mut g = paired9(values, ctx, "CLEAN", arm);
                    g["kind"] = metric.into();
                    g["pass"] = json!(g["upper"].as_f64().unwrap() <= 1.02);
                    gates.push(g);
                }
            }
            let clean = rss[&(ctx.clone(), "CLEAN".into())];
            let limit = rss[&(ctx.clone(), "REF".into())].max(rss[&(ctx.clone(), "PARENT".into())])
                * 1.05
                + 1.;
            gates.push(json!({"context":ctx,"kind":"RSS","CLEAN_mib":clean,"limit_mib":limit,"pass":clean<=limit}));
        }
        let mut gain = paired9(&latency, "1x2-w96", "CLEAN", "REF");
        gain["kind"] = "primary96_gain".into();
        gain["pass"] = json!(gain["upper"].as_f64().unwrap() < 1.);
        gates.push(gain);
        assert_eq!(gates.len(), 66);
        let mut all_shape = vec![];
        for (shape, cpu_ref, metal_ref) in [
            ("1x2", 37., 24.),
            ("2x2", 59., 30.),
            ("4x2", 109., 48.),
            ("8x2", 189., 74.),
            ("12x2", 284., 101.),
            ("16x2", 335., 124.),
            ("24x2", 528., 176.),
            ("merge-24x1", 507., 175.),
        ] {
            let best = medians
                .iter()
                .filter(|m| m["arm"] == "CLEAN" && m["shape"] == shape)
                .min_by(|a, b| {
                    a["ms"]
                        .as_f64()
                        .unwrap()
                        .total_cmp(&b["ms"].as_f64().unwrap())
                })
                .unwrap();
            let ms = best["ms"].as_f64().unwrap();
            all_shape.push(json!({"shape":shape,"context":best["context"],"workers":best["workers"],"ms":ms,"max_rss_mib":best["max_rss_mib"],"M5_CPU_ms":cpu_ref,"M5_Metal_ms":metal_ref,"CPU_speedup":cpu_ref/ms,"Metal_speedup":metal_ref/ms,"CPU10x_target_ms":cpu_ref/10.,"CPU10x_point_estimate_met":ms<=cpu_ref/10.,"best_count_selection_descriptive":true}));
        }
        save(
            r.join("target-analysis.json"),
            json!({"qualification_passed":gates.iter().all(|g|g["pass"]==true),"gates":gates,"medians":medians,"resource_rows":resources,"all8":all_shape,"production_adoption_requires_final_resource_concurrency_review":true,"goal_completion_not_claimed":true}),
        );
    }
    let result = json!({"status":"PASS","local":local,"new_export_count":jobs.as_array().unwrap().len(),"canonical_verified_exports":if local{50362}else{50752},"timed_samples_checked":timed,"transport_rechecks_add_new_proofs":0,"local_preflight_is_not_speedup_evidence":true});
    save(
        r.join(if local {
            "local-review.json"
        } else {
            "remote-review.json"
        }),
        result.clone(),
    );
    println!("{result}");
}
