use serde_json::json;
use std::{fs, path::Path, process::Command};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
const PARENT: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-c7a176";
fn main() {
    let r = Path::new(ROOT);
    assert!(!r.join("stage.rs").exists());
    let mut s = fs::read_to_string(Path::new(PARENT).join("stage.rs"))
        .unwrap()
        .replace(PARENT, ROOT)
        .replace(
            "/home/ubuntu/src/zopro-perf-work/task-interval-c7a176/proof-sha256-after-capture.json",
            &format!("{PARENT}/proof-sha256-after-capture.json"),
        );
    s = s
        .replace("50351", "50752")
        .replace("50219", "50362")
        .replace("50208", "50351")
        .replace(
            "zopro-phi-grain-c7a:preflight",
            "zopro-phi-grain-clean:preflight",
        )
        .replace("phi-grain-c7a-{}", "phi-clean-c7a-{}")
        .replace("context/cr-control", "context/cr-parent")
        .replace("control_sdk_sha256", "parent_sdk_sha256")
        .replace("candidate_sdk_sha256", "clean_sdk_sha256")
        .replace("\"target_blocks\":21", "\"target_blocks\":9")
        .replace(
            "\"target_SDK_requests\":19428",
            "\"target_SDK_requests\":25050",
        )
        .replace("\"target_exports\":132", "\"target_exports\":390");
    fs::write(r.join("stage.rs"), s).unwrap();
    let deps = "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
    let compiler = "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
    let argv = vec![
        "--edition=2021".to_owned(),
        "-O".into(),
        r.join("stage.rs").display().to_string(),
        "-L".into(),
        format!("dependency={deps}"),
        "--extern".into(),
        format!("serde_json={deps}/libserde_json-cdebb9338c2784ad.rlib"),
        "--extern".into(),
        format!("sha2={deps}/libsha2-16b8f2c03bdf5faa.rlib"),
        "-o".into(),
        r.join("stage").display().to_string(),
    ];
    let o = Command::new(compiler).args(&argv).output().unwrap();
    fs::write(r.join("stage-build.stdout"), o.stdout).unwrap();
    fs::write(r.join("stage-build.stderr"), o.stderr).unwrap();
    fs::write(r.join("stage-build.json"),serde_json::to_vec_pretty(&json!({"compiler":compiler,"argv":argv,"success":o.status.success(),"exit_code":o.status.code()})).unwrap()).unwrap();
    assert!(o.status.success());
    println!("Preparedcleanstage50351->50362->50752,11local/390cloudexports, actualoutputgroup, noSDKcalls");
}
