use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::Read,
    path::{Path, PathBuf},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/phi-grain-clean176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    let mut f = fs::File::open(p).unwrap();
    let mut h = Sha256::new();
    let mut b = [0; 65536];
    loop {
        let n = f.read(&mut b).unwrap();
        if n == 0 {
            break;
        }
        h.update(&b[..n]);
    }
    format!("{:x}", h.finalize())
}
fn pin(p: &mut BTreeMap<String, String>, f: impl AsRef<Path>) {
    let f = f.as_ref();
    p.insert(f.display().to_string(), hash(f));
}
fn once(s: &mut String, a: &str, b: &str) {
    assert_eq!(s.matches(a).count(), 1, "{a}");
    *s = s.replace(a, b);
}
fn setup(){panic!("use setup executable")}fn prepare_use(){panic!("noPGOvariant")}
fn freeze(label: &str) {
    assert!(["control", "generate", "candidate"].contains(&label));
    let flags = std::env::var("RUSTFLAGS").unwrap();
    assert_eq!(
        flags,
        fs::read_to_string(r(format!("{label}-flags.txt"))).unwrap()
    );
    let root = r("frozen").join(label);
    fs::create_dir_all(&root).unwrap();
    let mut all = BTreeMap::<String, BTreeSet<String>>::new();
    let mut pins = BTreeMap::new();
    for l in fs::read_to_string(r(format!(
        "{}/libraries-{label}/stdout.log",
        if label == "candidate" {
            "native-candidate"
        } else {
            "native-control"
        }
    )))
    .unwrap()
    .lines()
    {
        let a: Value = serde_json::from_str(l).unwrap();
        if a["reason"] != "compiler-artifact" {
            continue;
        }
        let n = a["target"]["name"].as_str().unwrap();
        let files = a["filenames"].as_array().unwrap();
        let metas: Vec<_> = files
            .iter()
            .filter_map(Value::as_str)
            .filter(|p| p.ends_with(".rmeta") && p.contains("/deps/"))
            .collect();
        for f in files
            .iter()
            .filter_map(Value::as_str)
            .filter(|p| p.ends_with(".rlib") || p.ends_with(".so"))
        {
            let p = if f.ends_with(".rlib") && !f.contains("/deps/") && metas.len() == 1 {
                Path::new(metas[0]).with_extension("rlib")
            } else {
                PathBuf::from(f)
            };
            let h = hash(&p);
            let ext = p.extension().unwrap().to_str().unwrap();
            let to = root.join(format!("lib{n}-{h}.{ext}"));
            if to.exists() {
                assert_eq!(hash(&to), h)
            } else {
                fs::copy(&p, &to).unwrap();
            }
            pin(&mut pins, &to);
            if ext == "rlib" {
                all.entry(n.into())
                    .or_default()
                    .insert(to.display().to_string());
            }
        }
    }
    let mut lines = String::new();
    let mut libs = BTreeMap::new();
    for n in [
        "zopro_core",
        "zopro_bn254",
        "zopro_prover",
        "zopro_zolana",
        "libc",
        "memmap2",
        "rayon",
        "serde_json",
    ] {
        assert_eq!(all[n].len(), 1);
        let p = all[n].first().unwrap();
        libs.insert(n, p);
        lines.push_str(
            &serde_json::to_string(
                &json!({"reason":"compiler-artifact","target":{"name":n},"filenames":[p]}),
            )
            .unwrap(),
        );
        lines.push('\n');
    }
    let mut fingerprints = vec![];
    for e in fs::read_dir(r(format!(
        "target-{label}/x86_64-unknown-linux-gnu/release/.fingerprint"
    )))
    .unwrap()
    {
        let e = e.unwrap();
        for n in ["zopro-core", "zopro-bn254"] {
            let p = e.path().join(format!("lib-{}.json", n.replace('-', "_")));
            if e.file_name().to_string_lossy().starts_with(n) && p.exists() {
                let f = read(&p);
                assert_eq!(
                    f["rustflags"],
                    json!(flags.split_whitespace().collect::<Vec<_>>())
                );
                if n == "zopro-core" {
                    assert!(f["features"].as_str().unwrap().contains("ifma8"));
                }
                fingerprints.push(json!({"path":p,"receipt":f}));
            }
        }
    }
    assert!(fingerprints.len() >= 2);
    fs::write(r(format!("frozen-{label}-cargo.jsonl")), lines).unwrap();
    save(
        r(format!("frozen-{label}.json")),
        &json!({"rustflags":flags,"libraries":libs,"input_pins":pins,"fingerprints":fingerprints,"proc_macro_shared_objects_frozen":true}),
    );
    println!(
        "Frozen{label}{}rlib/sofiles; nativeflags/features checked",
        pins.len()
    );
}
fn main() {
    let a: Vec<_> = std::env::args().collect();
    match a.get(1).map(String::as_str) {
        Some("setup") => setup(),
        Some("use") => prepare_use(),
        Some("freeze") => freeze(&a[2]),
        Some("link") => link(&a[2]),
        _ => panic!("setup/freeze"),
    }
}

fn link(label:&str){let f=read(r(format!("frozen-{label}.json")));let mut a=vec!["--edition=2021".to_owned(),"-O".into(),"-Clto=fat".into(),"-Ccodegen-units=1".into(),"-Cdebuginfo=1".into(),"-L".into(),format!("dependency={R}/frozen/{label}")];a.extend(fs::read_to_string(r(format!("{label}-flags.txt"))).unwrap().split_whitespace().map(str::to_owned));for(n,p)in f["libraries"].as_object().unwrap(){a.extend(["--extern".into(),format!("{n}={}",p.as_str().unwrap())]);}for(p,h)in f["input_pins"].as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}a.extend([format!("{R}/driver.rs"),"-o".into(),format!("{R}/sdk-{label}-znver4")]);let compiler="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";let o=std::process::Command::new(compiler).args(&a).output().unwrap();fs::write(r(format!("link-{label}.stdout")),&o.stdout).unwrap();fs::write(r(format!("link-{label}.stderr")),&o.stderr).unwrap();save(r(format!("link-{label}.json")),&serde_json::json!({"compiler":compiler,"argv":a,"success":o.status.success(),"exit_code":o.status.code(),"stdout_sha256":hash(r(format!("link-{label}.stdout"))),"stderr_sha256":hash(r(format!("link-{label}.stderr")))}));assert!(o.status.success(),"explicit1.98.1link failed; preserve receipts");println!("LINKED{label} coherent8libs:{}",hash(r(format!("sdk-{label}-znver4"))));}
