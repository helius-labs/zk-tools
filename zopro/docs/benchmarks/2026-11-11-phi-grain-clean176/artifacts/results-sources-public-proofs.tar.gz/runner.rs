use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::Path,
    process::{Command, Stdio},
};
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    assert!(!p.as_ref().exists());
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn state() -> Value {
    let mut m = BTreeMap::new();
    for p in [
        "/proc/loadavg",
        "/proc/swaps",
        "/sys/fs/cgroup/cpu.max",
        "/sys/fs/cgroup/cpu.stat",
        "/sys/fs/cgroup/memory.max",
        "/sys/fs/cgroup/memory.events",
        "/sys/fs/cgroup/memory.swap.max",
        "/sys/fs/cgroup/memory.swap.events",
        "/sys/fs/cgroup/memory.peak",
    ] {
        if let Ok(s) = fs::read_to_string(p) {
            m.insert(p, s);
        }
    }
    json!(m)
}
fn command(name: &str, argv: Vec<String>, env: Value) -> Value {
    json!({"kind":"command","name":name,"argv":argv,"environment":env,"timeout_seconds":900})
}
fn add(
    dir: &Path,
    context: &Value,
    arm: &str,
    rounds: usize,
    panel: &str,
    block: usize,
    env: &Value,
) -> (Value, Value, Value) {
    let w = context["workers"].as_u64().unwrap() as usize;
    let name = format!(
        "{panel}-{}-{arm}-b{block:02}",
        context["name"].as_str().unwrap()
    );
    let proof = dir.join("proofs").join(&name);
    let binary = match arm {
        "REF" => "/usr/local/bin/cr-previous",
        "PARENT" => "/usr/local/bin/cr-parent",
        "CLEAN" => "/usr/local/bin/cr-current",
        _ => panic!("unknown arm"),
    };
    let mut env = env.clone();
    env["RAYON_NUM_THREADS"] = json!(w.to_string());
    let step = command(
        &name,
        vec![
            "/usr/bin/taskset".into(),
            "-c".into(),
            format!("0-{}", w - 1),
            binary.into(),
            context["image"].as_str().unwrap().into(),
            context["request"].as_str().unwrap().into(),
            rounds.to_string(),
            proof.display().to_string(),
        ],
        env,
    );
    let verify = command(
        &format!("verify-{name}"),
        vec![
            "/usr/local/bin/interval-verify".into(),
            context["image"].as_str().unwrap().into(),
            context["image_sha256"].as_str().unwrap().into(),
            proof.join("0.proof").display().to_string(),
            proof.join("0.public").display().to_string(),
            context["public_sha256"].as_str().unwrap().into(),
        ],
        json!({}),
    );
    let job = json!({"name":name,"case":context,"arm":arm,"workers":w,"rounds":rounds,"block":block,"panel":panel,"proof_dir":proof,"binary":binary});
    (job, step, verify)
}
fn receipt(d: &Path) {
    let e = read(d.join("exit.json"));
    assert_eq!(e["success"], true);
    assert_eq!(e["returncode"], 0);
    for (f, k) in [
        ("stdout.log", "stdout_sha256"),
        ("stderr.log", "stderr_sha256"),
    ] {
        assert_eq!(hash(d.join(f)), e[k]);
    }
}
fn main() {
    let phase = std::env::args().nth(1).unwrap();
    assert!(phase == "preflight" || phase == "measure");
    let dir = Path::new("/output").join(&phase);
    fs::create_dir(&dir).unwrap();
    let m = read("/cr/manifest.json");
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(m["container_pins"].clone()).unwrap();
    for (p, h) in &pins {
        assert_eq!(&hash(p), h);
    }
    pins.insert("/cr/manifest.json".into(), hash("/cr/manifest.json"));
    let mut seen: BTreeSet<String> =
        serde_json::from_value(m["prior_proof_sha256"].clone()).unwrap();
    assert_eq!(seen.len(), 50351);
    if phase == "measure" {
        let local = read("/cr/preflight-complete.json");
        assert_eq!(local["status"], "complete");
        assert_eq!(local["distinct_gnark_exports"], 11);
        for h in local["new_proof_sha256"].as_array().unwrap() {
            assert!(seen.insert(h.as_str().unwrap().into()));
        }
        assert_eq!(seen.len(), 50362);
        pins.insert(
            "/cr/preflight-complete.json".into(),
            hash("/cr/preflight-complete.json"),
        );
        let q = fs::read_to_string("/sys/fs/cgroup/cpu.max").unwrap();
        let q = q.split_whitespace().collect::<Vec<_>>();
        assert_eq!(
            q[0].parse::<u64>().unwrap(),
            96 * q[1].parse::<u64>().unwrap()
        );
        assert_eq!(
            fs::read_to_string("/sys/fs/cgroup/memory.max")
                .unwrap()
                .trim(),
            (30u64 << 30).to_string()
        );
        assert_eq!(
            fs::read_to_string("/sys/fs/cgroup/memory.swap.max")
                .unwrap()
                .trim(),
            "0"
        );
    }
    save(dir.join("before.json"), state());
    for (name, args) in [
        ("lscpu.txt", vec![]),
        ("topology.csv", vec!["-p=CPU,CORE,SOCKET,ONLINE"]),
    ] {
        let out = Command::new("lscpu").args(args).output().unwrap();
        assert!(out.status.success());
        fs::write(dir.join(name), out.stdout).unwrap();
    }
    if phase == "measure" {
        let t = fs::read_to_string(dir.join("topology.csv")).unwrap();
        let mut cpus = BTreeSet::new();
        let mut cores = BTreeSet::new();
        for l in t.lines().filter(|l| !l.starts_with('#')) {
            let f = l.split(',').collect::<Vec<_>>();
            assert_eq!(f[3], "Y");
            cpus.insert(f[0].parse::<usize>().unwrap());
            assert!(cores.insert((f[1].to_owned(), f[2].to_owned())));
        }
        assert_eq!(cpus, (0..96).collect());
        assert_eq!(cores.len(), 96);
    }
    let contexts = m["contexts"].as_array().unwrap();
    assert_eq!(contexts.len(), 13);
    let mut env = m["environment"].clone();
    env["ZOPRO_BASIS_KEY_DIR"] = "/cr-basis".into();
    env["ZOPRO_CPU_LAGRANGE_DIR"] = "/output/lagrange-cache".into();
    env["ZOPRO_CPU_DEDUP"] = "1".into();
    let mut jobs = vec![];
    let mut steps = vec![];
    if phase == "preflight" {
        let mut primary = Value::Null;
        for case in m["cases"].as_array().unwrap() {
            let mut c = case.clone();
            c["workers"] = 4.into();
            c["cpu_affinity"] = "0-3".into();
            c["name"] = json!(format!("{}-w4", c["shape"].as_str().unwrap()));
            if c["shape"] == "1x2" {
                primary = c.clone();
            }
            let (j, s, v) = add(&dir, &c, "CLEAN", 1, "preflight", 0, &env);
            jobs.push(j);
            steps.extend([s, v]);
        }
        for arm in ["REF", "PARENT"] {
            let (j, s, v) = add(&dir, &primary, arm, 1, "preflight", 0, &env);
            jobs.push(j);
            steps.extend([s, v]);
        }
        assert_eq!(jobs.len(), 11);
    } else {
        for c in contexts {
            for arm in ["REF", "PARENT", "CLEAN"] {
                let (j, s, v) = add(&dir, c, arm, 1, "preflight", 0, &env);
                jobs.push(j);
                steps.extend([s, v]);
            }
        }
        let mut verifiers = vec![];
        for block in 0..9 {
            let mut order = contexts.clone();
            order.rotate_left(block % 13);
            if block % 2 == 1 {
                order.reverse();
            }
            let mut arms = ["REF", "PARENT", "CLEAN"];
            arms.rotate_left(block % 3);
            if block % 2 == 1 {
                arms.reverse();
            }
            for c in &order {
                for arm in arms {
                    let (j, s, v) = add(
                        &dir,
                        c,
                        arm,
                        c["rounds"].as_u64().unwrap() as usize,
                        "latency",
                        block,
                        &env,
                    );
                    jobs.push(j);
                    steps.push(s);
                    verifiers.push(v);
                }
            }
        }
        steps.extend(verifiers);
        assert_eq!(jobs.len(), 390);
    }
    let requests = jobs
        .iter()
        .map(|j| j["rounds"].as_u64().unwrap() + 3)
        .sum::<u64>();
    assert_eq!(requests, if phase == "preflight" { 44 } else { 25050 });
    save(dir.join("jobs.json"), json!(jobs));
    save(dir.join("pins.json"), json!(pins));
    save(
        dir.join("plan.json"),
        json!({"version":1,"source_pins":dir.join("pins.json"),"steps":steps}),
    );
    let log = fs::File::create(dir.join("workflow.log")).unwrap();
    let status = Command::new("/usr/local/bin/cr-xtask")
        .arg("workflow")
        .arg(dir.join("plan.json"))
        .arg(dir.join("workflow"))
        .stdout(Stdio::from(log.try_clone().unwrap()))
        .stderr(Stdio::from(log))
        .status()
        .unwrap();
    assert!(
        status.success(),
        "preserve partial frozen workflow; do not replay completed science"
    );
    let before = seen.clone();
    let mut inventory = BTreeMap::new();
    let mut rows = vec![];
    for j in &jobs {
        let name = j["name"].as_str().unwrap();
        receipt(&dir.join("workflow").join(name));
        receipt(&dir.join("workflow").join(format!("verify-{name}")));
        let proof = Path::new(j["proof_dir"].as_str().unwrap());
        assert_eq!(fs::metadata(proof.join("0.proof")).unwrap().len(), 164);
        let ph = hash(proof.join("0.proof"));
        assert!(seen.insert(ph.clone()));
        let public = hash(proof.join("0.public"));
        assert_eq!(public, j["case"]["public_sha256"]);
        inventory.insert(proof.join("0.proof").display().to_string(), ph.clone());
        inventory.insert(proof.join("0.public").display().to_string(), public.clone());
        let verified = fs::read_to_string(
            dir.join("workflow")
                .join(format!("verify-{name}"))
                .join("stdout.log"),
        )
        .unwrap();
        for binding in [
            format!("proof_sha256={ph}"),
            format!("public_sha256={public}"),
            format!(
                "image_sha256={}",
                j["case"]["image_sha256"].as_str().unwrap()
            ),
        ] {
            assert!(verified.contains(&binding));
        }
        let text = fs::read_to_string(dir.join("workflow").join(name).join("stdout.log")).unwrap();
        let samples = text
            .lines()
            .filter_map(|l| l.strip_prefix("SAMPLE "))
            .enumerate()
            .map(|(i, l)| {
                let v: Value = serde_json::from_str(l).unwrap();
                assert_eq!(v["round"], i);
                v["ns"]
                    .as_u64()
                    .unwrap_or_else(|| (v["ms"].as_f64().unwrap() * 1e6).round() as u64)
            })
            .collect::<Vec<_>>();
        assert_eq!(samples.len() as u64, j["rounds"].as_u64().unwrap());
        let summary: Value = serde_json::from_str(
            text.lines()
                .find_map(|l| l.strip_prefix("SUMMARY "))
                .unwrap(),
        )
        .unwrap();
        assert_eq!(summary["placement_before"], summary["placement_after"]);
        assert_eq!(summary["rounds"], j["rounds"]);
        assert_eq!(summary["workers"], j["workers"]);
        assert_eq!(summary["priming"], 3);
        rows.push(json!({"job":j,"mean_ns":samples.iter().map(|&n|n as u128).sum::<u128>()as f64/samples.len()as f64,"usage":summary}));
    }
    assert_eq!(seen.len(), if phase == "preflight" { 50362 } else { 50752 });
    for (p, h) in &pins {
        assert_eq!(&hash(p), h);
    }
    save(dir.join("rows.json"), json!(rows));
    save(dir.join("proof-inventory.json"), json!(inventory));
    save(dir.join("after.json"), state());
    save(
        dir.join("complete.json"),
        json!({"status":"complete","sdk_requests":requests,"distinct_gnark_exports":jobs.len(),"proof_ledger":seen.len(),"new_proof_sha256":seen.difference(&before).collect::<Vec<_>>(),"all_exported_proofs_independently_verified":true,"qualification_requires_offline_all66gates":true}),
    );
    println!(
        "COMPLETE cleanDEFAULT{}calls/{}freshGnark/ledger{}",
        requests,
        jobs.len(),
        seen.len()
    );
}
