use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs};
fn main(){
 let r="/home/ubuntu/src/zopro-perf-work/recursive-pair177";
 let old:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zopro-perf-work/global-window-pair-bound176/plan.json").unwrap()).unwrap();
 let mut build=old["steps"][2]["argv"].as_array().unwrap().iter().map(|v|v.as_str().unwrap().to_string()).collect::<Vec<_>>();
 for arg in &mut build {if arg.ends_with("/global-window-pair-bound176/study.rs"){*arg=format!("{r}/model.rs");}else if arg.ends_with("/global-window-pair-bound176/study"){*arg=format!("{r}/model");}}
 build.extend(["--extern".into(),"sha2=/home/ubuntu/src/zopro-perf-work/tool-target/release/deps/libsha2-16b8f2c03bdf5faa.rlib".into()]);
 let mut tests=build.clone();tests.push("--test".into());let out=tests.iter().position(|s|s=="-o").unwrap()+1;tests[out]=format!("{r}/tests");
 let plan=json!({"version":1,"source_pins":format!("{r}/pins.json"),"steps":[
 {"kind":"command","name":"build-tests","argv":tests,"timeout_seconds":300},
 {"kind":"command","name":"tests","argv":[format!("{r}/tests"),"--test-threads=1"],"timeout_seconds":300},
 {"kind":"command","name":"build-model","argv":build,"timeout_seconds":300},
 {"kind":"command","name":"screen","argv":[format!("{r}/model")],"timeout_seconds":1200}]});
 fs::write(format!("{r}/plan.json"),serde_json::to_vec_pretty(&plan).unwrap()).unwrap();
 let mut paths=vec![format!("{r}/model.rs"),format!("{r}/protocol.md"),format!("{r}/plan.json"),format!("{r}/prepare.rs")];
 paths.extend([
 "/home/ubuntu/src/zopro-perf-work/tau9-ring-work176/split.rs",
 "/home/ubuntu/src/zopro-perf-work/tau9-ring-work176/inputs.json",
 "/home/ubuntu/src/zopro-perf-work/global-window-pair-bound176/analysis.json",
 "/home/ubuntu/src/zopro-perf-work/g2-coordinate-leaf-profile177/proof-sha256-after-profile.json",
 "/home/ubuntu/src/zk-tools/zopro/crates/zopro-core/src/msm_affine/g2_phi.rs",
 "/home/ubuntu/src/zk-tools/zopro/crates/zopro-core/src/msm_affine/borrowed_pending.rs",
 "/home/ubuntu/src/zk-tools/zopro/crates/zopro-core/src/msm.rs",
 ].map(str::to_string));
 for s in plan["steps"][2]["argv"].as_array().unwrap(){let a=s.as_str().unwrap();if a.contains("/rustc") {paths.push(a.into());}if let Some((_,p))=a.split_once('='){if p.ends_with(".rlib"){paths.push(p.into());}}}
 let inputs:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zopro-perf-work/tau9-ring-work176/inputs.json").unwrap()).unwrap();for v in inputs.as_object().unwrap().values(){paths.push(v["file"].as_str().unwrap().into());paths.push(v["provenance_receipt"].as_str().unwrap().into());}
 let pins:BTreeMap<_,_>=paths.into_iter().map(|p|{let h=format!("{:x}",Sha256::digest(fs::read(&p).unwrap()));(p,h)}).collect();
 fs::write(format!("{r}/pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();println!("Prepared {} pins and four workflow commands",pins.len());
}
