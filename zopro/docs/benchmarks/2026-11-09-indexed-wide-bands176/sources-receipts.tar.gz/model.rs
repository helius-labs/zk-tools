#![recursion_limit="256"]
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::{BTreeMap, BTreeSet}, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/indexed-wide-bands176";
type Word = [u64; 4];
mod split;
include!("groups.rs");
include!("original-booth.rs");
fn load(path: impl AsRef<Path>) -> Value { serde_json::from_slice(&fs::read(path).unwrap()).unwrap() }
fn digest(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
#[derive(Clone, Copy, Default)]
struct FieldWork { v:u64, f:u64, m:u64, s:u64, fs:u64, inv:u64 }
impl FieldWork {
    fn plus(&mut self,b:Self) { self.v+=b.v; self.f+=b.f; self.m+=b.m; self.s+=b.s; self.fs+=b.fs; self.inv+=b.inv; }
    fn value(self)->Value { json!({"vector_mul":self.v,"vector_fused2":self.f,"scalar_mul":self.m,"scalar_square":self.s,"scalar_fused2":self.fs,"scalar_inverse":self.inv,"vector_IFMA_proxy":100*self.v+150*self.f,"elementary_product_count":8*self.v+16*self.f+self.m+self.s+2*self.fs}) }
}
#[derive(Default)]
struct Batches { hist:BTreeMap<usize,u64> }
impl Batches {
    fn batch(&mut self,n:usize) { *self.hist.entry(n).or_default()+=1; }
    fn pairs(&self)->u64 { self.hist.iter().map(|(&n,&times)|n as u64*times).sum() }
    fn work(&self,tree:bool)->FieldWork { let mut work=FieldWork::default(); for (&n,&times) in &self.hist { let (g,t)=((n/8)as u64,(n%8)as u64); let w=FieldWork { v:(if tree&&n<32 {8}else{7})*g+5, f:5*g, m:1+if tree {7*t}else{8*t}, s:if tree {0}else{2*t}, fs:if tree {5*t}else{4*t}, inv:1 }; work.plus(FieldWork {v:w.v*times,f:w.f*times,m:w.m*times,s:w.s*times,fs:w.fs*times,inv:times}); } work }
    fn value(&self,tree:bool)->Value { json!({"ordinary_pair_histogram":self.hist,"calls":self.hist.values().sum::<u64>(),"generic_pairs":self.pairs(),"full_groups":self.hist.iter().map(|(&n,&t)|(n/8)as u64*t).sum::<u64>(),"scalar_tails":self.hist.iter().map(|(&n,&t)|(n%8)as u64*t).sum::<u64>(),"zero_pair_layers":self.hist.get(&0).copied().unwrap_or(0),"field_work":self.work(tree).value()}) }
}
#[derive(Default)]
struct Projective { add:u64, mixed:u64, doubles:u64, add_calls:u64, mixed_calls:u64, double_calls:u64 }
impl Projective {
    fn join(&mut self,a:bool,b:bool,mixed:bool)->bool { if mixed {self.mixed_calls+=1;self.mixed+=u64::from(a&&b);} else {self.add_calls+=1;self.add+=u64::from(a&&b);} a||b }
    fn double(&mut self,a:bool)->bool {self.double_calls+=1;self.doubles+=u64::from(a);a}
    fn work(&self)->FieldWork { FieldWork {m:10*self.add+8*self.mixed+10*self.doubles,fs:22*self.add+14*self.mixed+4*self.doubles,..Default::default()} }
    fn value(&self)->Value { json!({"projective_add_nonidentity":self.add,"mixed_add_nonidentity":self.mixed,"double_nonidentity":self.doubles,"projective_add_calls":self.add_calls,"mixed_add_calls":self.mixed_calls,"double_calls":self.double_calls,"field_work":self.work().value()}) }
}
#[derive(Default)]
struct Recipe { stream:Batches, tree:Batches, merges:Batches, p:Projective, arrivals:u64, first:u64, overflow:u64, projective_first:u64, projective_mixed:u64, finish_joins:u64, normalizations:u64, normalization_calls:u64, phi_affine:u64, phi_projective:u64, logical_visits:u64, rows:Vec<Value> }
impl Recipe {
    fn tree_groups(&mut self,groups:&mut[Vec<bool>]) { while groups.iter().any(|g|g.len()>1) { let mut pairs=0; for group in groups.iter_mut() {let mut next=Vec::with_capacity(group.len().div_ceil(2));for pair in group.chunks(2) {pairs+=usize::from(pair.len()==2&&pair[0]&&pair[1]);next.push(pair.iter().any(|&x|x));} *group=next;} self.tree.batch(pairs); } }
    fn indexed(&mut self,counts:&[usize])->Vec<bool> { let mut partial_counts=vec![]; for &count in counts {let mut partials=0;for first in (0..count).step_by(1024) {let mut groups=vec![vec![true;(count-first).min(1024)]];self.tree_groups(&mut groups);partials+=1;}partial_counts.push(partials);}let mut result=vec![];for chunk in partial_counts.chunks(256) {let mut groups=chunk.iter().map(|&n|vec![true;n]).collect::<Vec<_>>();self.tree_groups(&mut groups);result.extend(groups.iter().map(|g|g.first().copied().unwrap_or(false)));}result }
    fn merge(&mut self,left:&mut[bool],right:&[bool]) {assert_eq!(left.len(),right.len());for (a,b) in left.chunks_mut(512).zip(right.chunks(512)) {let m=a.iter().zip(b).filter(|(a,b)|**a&&**b).count();if m>0 {self.merges.batch(m);}for (a,&b) in a.iter_mut().zip(b) {*a|=b;}} }
    fn signed_top(&mut self, digits:impl Iterator<Item=i16>,slots:usize)->Vec<bool> {let mut counts=vec![0;2*slots];for d in digits {if d!=0 {counts[d.unsigned_abs()as usize-1+if d<0 {slots}else{0}]+=1;}}let mut p=self.indexed(&counts);let negative=p.split_off(slots);self.merge(&mut p,&negative);p}
    fn weighted(&mut self, input:&[bool])->(bool,bool) {
        let mut partials=vec![];
        for chunk in input.chunks(256) {assert!(chunk.len().is_power_of_two());let mut groups=vec![chunk.to_vec()];while groups[0].len()>1 {let odd=groups[0].iter().step_by(2).copied().collect::<Vec<_>>();let mut pairs=0;for group in &mut groups {let mut next=vec![];for pair in group.chunks(2) {pairs+=usize::from(pair.len()==2&&pair[0]&&pair[1]);next.push(pair.iter().any(|&x|x));}*group=next;}self.tree.batch(pairs);groups.push(odd);}let total=groups[0][0];let mut weighted=total;for group in groups.iter().skip(1).rev() {weighted=self.p.double(weighted);weighted=self.p.join(weighted,group[0],true);}partials.push((weighted,total));}
        let (mut sum,mut offset,mut running)=(false,false,false);for (w,t) in partials.into_iter().rev() {sum=self.p.join(sum,w,false);offset=self.p.join(offset,running,false);running=self.p.join(running,t,true);}for _ in 0..8 {offset=self.p.double(offset);}let result=self.p.join(sum,offset,false);(result,running)
    }
    fn total_work(&self)->FieldWork {let mut w=self.stream.work(false);w.plus(self.tree.work(true));w.plus(self.merges.work(false));w.plus(self.p.work());w.plus(FieldWork {m:2*self.normalizations+2*self.normalization_calls+2*(self.phi_affine+self.phi_projective),s:2*self.normalization_calls,fs:12*self.normalizations,inv:self.normalization_calls,..Default::default()});w}
    fn value(&self)->Value {json!({"stream":self.stream.value(false),"tree":self.tree.value(true),"merges":self.merges.value(false),"projective":self.p.value(),"arrivals":self.arrivals,"first_writes":self.first,"queued_to_projective":self.overflow,"projective_first_writes":self.projective_first,"projective_mixed_updates":self.projective_mixed,"finish_joins":self.finish_joins,"normalization_points":self.normalizations,"normalization_calls":self.normalization_calls,"phi_affine_maps":self.phi_affine,"phi_projective_maps":self.phi_projective,"logical_input_visits":self.logical_visits,"total_field_work":self.total_work().value(),"all_abstract_noncancelling_adds":self.stream.pairs()+self.tree.pairs()+self.merges.pairs()+self.p.add+self.p.mixed,"rows":self.rows})}
}
// Appended to the exact inherited field/tree/weighted helper prefix.
const WIDTH:usize=14;const WINDOWS:usize=10;const HALF:usize=8192;const CELL:usize=256;
fn candidate(digits:&[Vec<i16>])->Value{
 let n=digits.len();let chunk=n.div_ceil(2);let mut r=Recipe::default();let mut diag=vec![];let mut max_leaf_rows=0;let mut max_class_count=0;let mut ordinary_arrivals=0;
 for w in 0..9 {
  let mut counts=vec![0usize;4*HALF];
  for(i,row)in digits.iter().enumerate(){for c in 0..2{let d=row[c*WINDOWS+w];if d==0{continue;}let b=d.unsigned_abs()as usize-1;assert!(b<HALF);let part=i/chunk;assert!(part<2);counts[(c*2+part)*HALF+b]+=1;ordinary_arrivals+=1;}}
  assert!(counts.iter().all(|&n|n<=32768));let mut all=vec![];
  for band in 0..HALF/CELL {
   let cs=(0..4).flat_map(|class|counts[class*HALF+band*CELL..class*HALF+(band+1)*CELL].iter().copied()).collect::<Vec<_>>();
   let rows=cs.iter().sum::<usize>();max_leaf_rows=max_leaf_rows.max(rows);max_class_count=max_class_count.max(*cs.iter().max().unwrap());
   let before=(r.tree.pairs(),r.tree.hist.values().sum::<u64>(),r.merges.pairs());
   let mut groups=cs.iter().map(|&n|vec![true;n]).collect::<Vec<_>>();r.tree_groups(&mut groups);
   let live=groups.iter().map(|g|g.first().copied().unwrap_or(false)).collect::<Vec<_>>();let mut low=live[..CELL].to_vec();r.merge(&mut low,&live[CELL..2*CELL]);let mut high=live[2*CELL..3*CELL].to_vec();r.merge(&mut high,&live[3*CELL..]);r.phi_affine+=high.iter().filter(|&&x|x).count()as u64;r.merge(&mut high,&low);all.extend(high);
   diag.push(json!({"window":w,"band":band,"input_rows":rows,"max_class_count":cs.iter().max(),"live_class_outputs":cs.iter().filter(|&&n|n>0).count(),"tree_pairs":r.tree.pairs()-before.0,"tree_calls":r.tree.hist.values().sum::<u64>()-before.1,"merge_pairs":r.merges.pairs()-before.2}));
  }
  assert_eq!(all.len(),HALF);r.weighted(&all);
 }
 // Original carry reducer; its one magnitude bucket has separate sign classes.
 let mut parts=vec![];
 for(first,part)in digits.chunks(chunk).enumerate(){let mut high=r.signed_top(part.iter().map(|row|row[WINDOWS+9]),1);r.phi_affine+=high.iter().filter(|&&x|x).count()as u64;let low=r.signed_top(part.iter().map(|row|row[9]),1);r.merge(&mut high,&low);assert_eq!(first,parts.len());parts.push(high);}
 let mut top=parts.remove(0);for p in parts{r.merge(&mut top,&p);}r.weighted(&top);
 let mut result=false;for w in(0..WINDOWS).rev(){let active=if w==9{top.iter().any(|&v|v)}else{diag.iter().any(|v|v["window"]==w&&v["live_class_outputs"].as_u64().unwrap()>0)};for _ in 0..WIDTH{result=r.p.double(result);}result=r.p.join(result,active,false);}
 r.arrivals=ordinary_arrivals;r.logical_visits=(2*9*n+4*n)as u64;
 let retained=9*((4*HALF+1)*4+2*n*4);let accepted_coords=2*10*2048*128;
 json!({"recipe":r.value(),"leaf_diagnostics":diag,"ordinary_arrivals":ordinary_arrivals,"max_nonforking_leaf_input_rows":max_leaf_rows,"max_class_input_rows":max_class_count,"ordinary_index_retained_payload_bytes":retained,"ordinary_index_payload_bound_formula":"9*(32769*4+2*n*4)","accepted_ordinary_coordinate_payload_bytes":accepted_coords,"construction_counts_payload_per_window_bytes":4*HALF*2,"construction_positions_payload_per_window_bytes":4*HALF*4,"max_leaf_point_input_payload_bytes":max_leaf_rows*128,"max_leaf_group_offsets_and_counts_payload_bytes":(1025+1024)*8,"four_class_bucket_outputs_payload_bytes":4*CELL*128,"weighted_point_slots_payload_bytes":(2*CELL-1)*128,"ordinary_result_weighted_total_payload_bytes":9*32*(192+128),"resource_bound_complete":false,"native_measurement_selected":false})
}
fn main(){assert!(!Path::new(&format!("{R}/analysis.json")).exists());let previous=load("/home/ubuntu/src/zopro-perf-work/iterative-bands176/analysis.json");let baseline=load("/home/ubuntu/src/zopro-perf-work/iterative-band-cost176/analysis.json");let mut cases=BTreeMap::new();let mut permitted=true;
 for shape in["1x2","2x2"]{let prior=&previous["cases"][shape];let bytes=fs::read(prior["fixture_path"].as_str().unwrap()).unwrap();assert_eq!(digest(&bytes),prior["fixture_sha256"]);let n=u64::from_le_bytes(bytes[8..16].try_into().unwrap())as usize;assert_eq!(bytes.len(),16+160*n);let raw=bytes[16+128*n..].chunks_exact(32).map(|b|std::array::from_fn(|i|u64::from_le_bytes(b[i*8..i*8+8].try_into().unwrap()))).collect::<Vec<Word>>();let g=groups(&raw);let values=g.as_ref().map(|g|&g.0).unwrap_or(&raw);assert_eq!(values.len(),prior["scalar_terms"]);let serial=values.iter().flat_map(|v|v.iter().rev().flat_map(|w|w.to_be_bytes())).collect::<Vec<_>>();assert_eq!(digest(&serial),prior["scalar_values_BE_sha256"]);let digits=values.iter().map(|&v|{let s=split::phi_split(v);let mut out=vec![];for c in 0..2{let magnitude=s[2*c]as u128|((s[2*c+1]&0x7fff_ffff_ffff_ffff)as u128)<<64;let sign=if s[2*c+1]>>63!=0{-1}else{1};let ds=(0..WINDOWS).map(|w|booth_digit(&[magnitude as u64,(magnitude>>64)as u64,0,0],w,WIDTH)*sign).collect::<Vec<_>>();assert_eq!(ds.iter().enumerate().map(|(w,&d)|(d as i128)*(1i128<<(w*WIDTH))).sum::<i128>(),sign as i128*magnitude as i128);out.extend(ds);}out}).collect::<Vec<_>>();let new=candidate(&digits);let old=&baseline["cases"][shape]["original"];assert_eq!(old["normalization_calls"],20);let a=&old["total_field_work"];let b=&new["recipe"]["total_field_work"];let n=|v:&Value,k:&str|v[k].as_u64().unwrap();let pass=n(b,"vector_IFMA_proxy")<n(a,"vector_IFMA_proxy")&&n(b,"elementary_product_count")<n(a,"elementary_product_count")&&n(b,"scalar_inverse")<=n(a,"scalar_inverse")&&new["ordinary_index_retained_payload_bytes"].as_u64().unwrap()<=new["accepted_ordinary_coordinate_payload_bytes"].as_u64().unwrap();permitted&=pass;cases.insert(shape,json!({"raw_input_rows":raw.len(),"scalar_terms":values.len(),"fixture_sha256":prior["fixture_sha256"],"scalar_values_BE_sha256":prior["scalar_values_BE_sha256"],"grouping_selected":g.is_some(),"accepted_baseline_read_not_reexecuted":old,"candidate":new,"necessary_screen_passed":pass}));}
 fs::write(format!("{R}/analysis.json"),serde_json::to_vec_pretty(&json!({"complete":true,"cases":cases,"necessary_screen_passed":permitted,"native_measurement_selected":false,"accepted_Window_normalization_calls":20,"earlier_accepted_covered_ledger_40_boundary_calls_overcounted":true,"new_native_builds":0,"new_proofs":0,"canonical_proofs":40154,"production_changed":false,"adopted":false,"goal_complete":false})).unwrap()).unwrap();println!("indexed-wide count complete necessaryscreen={permitted}; no native timing/proofs");
}

#[cfg(test)]mod indexed_tests{
 use super::*;
 fn plus(a:(i64,i64),b:(i64,i64))->(i64,i64){((a.0+b.0).rem_euclid(1019),(a.1+b.1).rem_euclid(1019))}
 fn scale(a:(i64,i64),n:i64)->(i64,i64){((a.0*n).rem_euclid(1019),(a.1*n).rem_euclid(1019))}
 fn phi(a:(i64,i64))->(i64,i64){((-a.1).rem_euclid(1019),(a.0-a.1).rem_euclid(1019))}
 #[test]fn fused_leaf_weight_and_total_preserve_part_phi_sign_and_offsets(){for n in[0usize,1,7,8,199,200,1024,2048,4099]{let mut expected=(0,0);let mut leaves=vec![vec![(0,0);4*CELL];32];for i in 0..n{let b=(i/2*37+i/10)%HALF;let hi=i/3%3!=0;let negative=i%2==0;let p=if i%11==0{(0,0)}else{((i/2*17%1019)as i64,(i/2*23%1019)as i64)};let raw=if negative{scale(p,-1)}else{p};let v=if hi{phi(raw)}else{raw};expected=plus(expected,scale(v,(b+1)as i64));let part=usize::from(i>=n.div_ceil(2));let class=usize::from(hi)*2+part;let j=class*CELL+b%CELL;leaves[b/CELL][j]=plus(leaves[b/CELL][j],raw);}let pairs=leaves.iter().map(|leaf|{let mut w=(0,0);let mut t=(0,0);for i in 0..CELL{let high=plus(leaf[2*CELL+i],leaf[3*CELL+i]);let low=plus(leaf[i],leaf[CELL+i]);let p=plus(phi(high),low);w=plus(w,scale(p,(i+1)as i64));t=plus(t,p);}(w,t)}).collect::<Vec<_>>();let(mut sum,mut offset,mut running)=((0,0),(0,0),(0,0));for(w,t)in pairs.into_iter().rev(){sum=plus(sum,w);offset=plus(offset,running);running=plus(running,t);}assert_eq!(plus(sum,scale(offset,CELL as i64)),expected);}}
 #[test]fn joint_class_reduction_histogram_matches_ceil_division(){for seed in 0..64usize{let counts=(0..1024).map(|i|((i*37+seed*19)%(1+seed%17)).min(63)).collect::<Vec<_>>();let mut r=Recipe::default();let mut groups=counts.iter().map(|&n|vec![true;n]).collect::<Vec<_>>();r.tree_groups(&mut groups);let mut hist=BTreeMap::new();let mut level=counts.clone();while level.iter().any(|&n|n>1){let pairs=level.iter().map(|n|n/2).sum::<usize>();*hist.entry(pairs).or_insert(0)+=1;level.iter_mut().for_each(|n|*n=n.div_ceil(2));}assert_eq!(hist,r.tree.hist);assert_eq!(r.tree.pairs(),counts.iter().map(|n|n.saturating_sub(1)as u64).sum::<u64>());assert_eq!(groups.iter().map(|g|g.len()).collect::<Vec<_>>(),level);}}
}
