use super::ScalarGroups;
use std::hash::BuildHasher;
type Map<S> = hashbrown::HashMap<[u64;4],u32,S>;
#[inline(always)]
fn lookup<const RAW:bool,S:BuildHasher>(groups:&mut Map<S>, scalar:&[u64;4], values:&mut Vec<[u64;4]>, counts:&mut Vec<usize>)->u32 {
    if RAW {
        // The borrowed and stored keys have identical Hash/Eq implementations.
        // Rehashing on growth therefore computes exactly this same hash.
        let hash=groups.hasher().hash_one(scalar);
        match groups.raw_entry_mut().from_key_hashed_nocheck(hash,scalar) {
            hashbrown::hash_map::RawEntryMut::Occupied(entry)=>*entry.get(),
            hashbrown::hash_map::RawEntryMut::Vacant(entry)=>{
                let index=values.len() as u32;
                values.push(*scalar); counts.push(0);
                entry.insert_hashed_nocheck(hash,*scalar,index);
                index
            }
        }
    } else {
        *groups.entry(*scalar).or_insert_with(||{
            values.push(*scalar); counts.push(0); (values.len()-1) as u32
        })
    }
}
#[inline(never)]
pub(super) fn build<const RAW:bool>(scalars:&[[u64;4]],capacity:usize,percent:usize,reservation:crate::preparation::Reservation)->Option<ScalarGroups>{
    let mut groups=Map::with_capacity_and_hasher(capacity,ahash::RandomState::new());
    let mut values=Vec::new();
    let mut classes=vec![u32::MAX;scalars.len()];
    let mut counts=Vec::new();
    for(scalar,class)in scalars.iter().zip(&mut classes){
        if *scalar==[0;4]{continue;}
        let index=lookup::<RAW,_>(&mut groups,scalar,&mut values,&mut counts);
        *class=index;counts[index as usize]+=1;
    }
    drop(groups);
    if values.len() * 100 > scalars.len() * percent {
        return None;
    }
    if values.is_empty() {
        return Some(ScalarGroups {
            _reservation: reservation,
            len: scalars.len(),
            values,
            order: Vec::new(),
            starts: vec![0],
            counts,
        });
    }
    let mut starts = Vec::with_capacity(counts.len() + 1);
    starts.push(0);
    for &count in &counts {
        starts.push(starts.last().unwrap() + count);
    }
    let mut positions = starts[..counts.len()].to_vec();
    let mut order = vec![0u32; *starts.last().unwrap()];
    for (i, &class) in classes.iter().enumerate() {
        if class != u32::MAX {
            order[positions[class as usize]] = i as u32;
            positions[class as usize] += 1;
        }
    }
    drop(classes);
    drop(positions);
    Some(ScalarGroups {
        _reservation: reservation,
        len: scalars.len(),
        values,
        order,
        starts,
        counts,
    })
}
#[cfg(test)]mod tests{
use super::*;use std::collections::{BTreeMap,BTreeSet};
fn reservation(n:usize,p:usize)->crate::preparation::Reservation{super::super::grouping_cost::reserve(n.max(256),p).unwrap()}
fn check<const RAW:bool>(words:&[[u64;4]],capacity:usize,p:usize){let mut oracle=BTreeMap::<[u64;4],Vec<u32>>::new();let mut first=vec![];for(i,&s)in words.iter().enumerate(){if s==[0;4]{continue;}if !oracle.contains_key(&s){first.push(s);}oracle.entry(s).or_default().push(i as u32);}let actual=build::<RAW>(words,capacity,p,reservation(words.len(),p));if first.len()*100>words.len()*p{assert!(actual.is_none());return;}let g=actual.unwrap();assert_eq!(g.len,words.len());assert_eq!(g.values,first);assert_eq!(g.starts.len(),g.counts.len()+1);assert_eq!(g.starts[0],0);let mut expected_order=vec![];for(i,s)in first.iter().enumerate(){assert_eq!(g.counts[i],oracle[s].len());assert_eq!(g.starts[i],expected_order.len());expected_order.extend_from_slice(&oracle[s]);assert_eq!(g.starts[i+1],expected_order.len());}assert_eq!(g.order,expected_order);assert_eq!(g.order.iter().copied().collect::<BTreeSet<_>>().len(),g.order.len());}
#[test]fn raw_probe_matches_independent_classes_and_stable_order(){let mut cases=0;for n in[0usize,1,17,255,256,1025,2049]{for kind in 0..5{let words=(0..n).map(|i|match kind{0=>[0;4],1=>[(i%17+1)as u64,0,0,0],2=>[i as u64+1,0,0,0],3=>if i%2==0{[0;4]}else{[i as u64+1,0,0,0]},_=>{let v=(i%31+1)as u64;[v,v.wrapping_mul(0x9e3779b97f4a7c15),v.rotate_left(19),v^0xfedcba9876543210]}}).collect::<Vec<_>>();for p in[80,95]{for capacity in[0,17,128]{check::<false>(&words,capacity,p);check::<true>(&words,capacity,p);cases+=2;}}}}assert_eq!(cases,420);println!("RAW_PROBE_CLASS_ORACLES={cases}");}
#[derive(Clone,Default)]struct Collision;impl std::hash::Hasher for Collision{fn write(&mut self,_:&[u8]){}fn finish(&self)->u64{42}}impl BuildHasher for Collision{type Hasher=Self;fn build_hasher(&self)->Self{Self}}
fn collision_check<const RAW:bool,S:BuildHasher>(state:S){let mut map=Map::with_capacity_and_hasher(0,state);let mut values=vec![];let mut counts=vec![];let mut oracle=BTreeMap::new();for i in 0..3072{let k=(i*733)%1025;let scalar=[1,2,3,k];let next=oracle.len()as u32;let expected=*oracle.entry(scalar).or_insert(next);let actual=lookup::<RAW,_>(&mut map,&scalar,&mut values,&mut counts);assert_eq!(actual,expected);assert_eq!(map.get(&scalar),Some(&expected));assert_eq!(map.hasher().hash_one(scalar),map.hasher().hash_one(&scalar));}assert_eq!(map.len(),1025);for(s,index)in oracle{assert_eq!(map.get(&s),Some(&index));assert_eq!(values[index as usize],s);}assert_eq!(counts.len(),1025);}
#[test]fn raw_probe_hash_growth_and_collision_oracle(){collision_check::<false,_>(Collision);collision_check::<true,_>(Collision);for seed in 0..4{let state=ahash::RandomState::with_seeds(seed,seed+1,seed+2,seed+3);collision_check::<false,_>(state.clone());collision_check::<true,_>(state);}}
#[test]fn raw_probe_weighted_and_threaded_oracles(){use crate::msm::BatchInverse;use zopro_bn254::{CurveConfig,Fr,Field,G1Config,G2Config,Projective};fn one<C:CurveConfig>()where C::Base:BatchInverse{let generator=Projective::<C>::generator();let scalars=(0..257).map(|i|if i%3==0{Fr::ZERO}else{Fr::from((i%17+1)as u64).pow(&[11])}).collect::<Vec<_>>();let words=scalars.iter().map(Fr::to_canonical).collect::<Vec<_>>();let points=(0..257).map(|i|generator*Fr::from(i as u64+1)).collect::<Vec<_>>();let bases=Projective::<C>::batch_to_affine(&points);let expected=(generator*scalars.iter().enumerate().fold(Fr::ZERO,|a,(i,&s)|a+s*Fr::from(i as u64+1))).to_affine();for workers in[1usize,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512<<10).build().unwrap();std::thread::scope(|scope|{let mut jobs=vec![];for _ in 0..4{jobs.push(scope.spawn(||pool.install(||{let hb=build::<false>(&words,17,80,reservation(words.len(),80)).unwrap();let raw=build::<true>(&words,17,80,reservation(words.len(),80)).unwrap();assert_eq!(crate::msm_affine::msm_grouped(&bases,&hb).to_affine(),expected);assert_eq!(crate::msm_affine::msm_grouped(&bases,&raw).to_affine(),expected);assert_eq!(crate::msm_affine::msm_raw(&bases,&words).to_affine(),expected);})));}for job in jobs{job.join().unwrap();}});}}one::<G1Config>();one::<G2Config>();}
}
