fn seed(smoke:bool)->BTreeSet<String>{
 assert_eq!(hash(format!("{I}/seed.json")),SEED);let mut s:BTreeSet<String>=serde_json::from_value(read(format!("{I}/seed.json"))).unwrap();assert_eq!(s.len(),55440);
 if !smoke{let p=read(format!("{I}/smoke-complete.json"));assert_eq!(p["status"],"complete");assert_eq!(p["exports"],4);assert_eq!(p["sdk_calls"],16);assert_eq!(p["seed_sha256"],SEED);let delta=p["new_proof_sha256"].as_array().unwrap();assert_eq!(delta.len(),4);for h in delta{assert!(s.insert(h.as_str().unwrap().into()));}assert_eq!(s.len(),55444);assert_eq!(format!("{:x}",Sha256::digest(serde_json::to_vec_pretty(&s).unwrap())),p["canonical_sha256"].as_str().unwrap());}
 s
}
fn backings()->Value{
 use std::os::unix::fs::MetadataExt;let mut ids=BTreeSet::new();let mut out=vec![];let pins=read(format!("{I}/preflight-pins.json"));
 for family in ["zref","zdiag","aref","afresh","adiag"]{let mut expected=None;for i in 0..3{let p=format!("/usr/local/bin/{family}{i}");let m=fs::metadata(&p).unwrap();assert!(ids.insert((m.dev(),m.ino())));let h=hash(&p);assert_eq!(h,pins[&p].as_str().unwrap());if let Some(e)=&expected{assert_eq!(&h,e)}else{expected=Some(h.clone())}out.push(json!({"path":p,"device":m.dev(),"inode":m.ino(),"sha256":h}));}}
 json!(out)
}
fn snapshot(label:&str){save(&format!("{label}.json"),state());save(&format!("backings-{label}.json"),backings());}
fn topology(target:bool){
 let o=Command::new("lscpu").args(["-p=CPU,CORE,SOCKET,ONLINE"]).output().unwrap();assert!(o.status.success());let t=String::from_utf8(o.stdout).unwrap();fs::write(format!("{R}/topology.csv"),&t).unwrap();let o=Command::new("lscpu").output().unwrap();assert!(o.status.success());fs::write(format!("{R}/lscpu.txt"),o.stdout).unwrap();fs::copy("/proc/cpuinfo",format!("{R}/cpuinfo.txt")).unwrap();
 if target{let mut cpus=BTreeSet::new();let mut cores=BTreeSet::new();for l in t.lines().filter(|l|!l.starts_with('#')){let f=l.split(',').collect::<Vec<_>>();assert_eq!(f[3],"Y");cpus.insert(f[0].parse::<usize>().unwrap());assert!(cores.insert((f[1].to_owned(),f[2].to_owned())));}assert_eq!(cpus,(0..96).collect());assert_eq!(cores.len(),96);let cpu=fs::read_to_string("/sys/fs/cgroup/cpu.max").unwrap();let f=cpu.split_whitespace().collect::<Vec<_>>();assert_eq!(f[0].parse::<u64>().unwrap(),96*f[1].parse::<u64>().unwrap());assert_eq!(fs::read_to_string("/sys/fs/cgroup/memory.max").unwrap().trim(),(30u64<<30).to_string());assert_eq!(fs::read_to_string("/sys/fs/cgroup/memory.swap.max").unwrap().trim(),"0");}
}
fn smoke_review(){
 verify_pins();let mut ledger=seed(true);let before=ledger.clone();let jobs=read(format!("{R}/jobs.json"));assert_eq!(jobs.as_array().unwrap().len(),4);for j in jobs.as_array().unwrap(){let v=read(format!("{R}/checks/{}.json",j["name"].as_str().unwrap()));assert_eq!(v["passed"],true);assert!(ledger.insert(v["proof_sha256"].as_str().unwrap().into()));}assert_eq!(ledger.len(),55444);assert_eq!(read(format!("{R}/backings-before.json")),read(format!("{R}/backings-after.json")));save("proof-sha256-after-smoke.json",json!(ledger));save("smoke-complete.json",json!({"status":"complete","exports":4,"sdk_calls":16,"canonical_count":55444,"canonical_sha256":hash(format!("{R}/proof-sha256-after-smoke.json")),"seed_sha256":SEED,"new_proof_sha256":ledger.difference(&before).collect::<Vec<_>>(),"performance_claim":false}));println!("SMOKE COMPLETE4Gnarkexports16SDKcalls; canonical55444");
}
fn counters(v:&Value,p:&str)->BTreeMap<String,u64>{v[p].as_str().unwrap().lines().map(|l|{let f=l.split_whitespace().collect::<Vec<_>>();assert_eq!(f.len(),2);(f[0].into(),f[1].parse().unwrap())}).collect()}
fn extended_review(){
 let basic=read(format!("{R}/review.json"));let mut v=basic.clone();let mut guards=vec![];for g in v["gates"].as_array().unwrap(){let ratios=g["block_ratios"].as_array().unwrap();assert_eq!(ratios.len(),9);for backing in 0..3{let r=(backing..9).step_by(3).map(|i|ratios[i].as_f64().unwrap()).collect::<Vec<_>>();let m=median(&r);guards.push(json!({"mode":g["mode"],"workers":g["workers"],"ratio":g["ratio"],"backing":backing,"block_ratios":r,"median":m,"passed":(0.95..=1.05).contains(&m)}));}}assert_eq!(guards.len(),48);
 let before=read(format!("{R}/before.json"));let after=read(format!("{R}/after.json"));let mut events=vec![];for(p,keys)in [("/sys/fs/cgroup/cpu.stat",vec!["nr_throttled","throttled_usec"]),("/sys/fs/cgroup/memory.events",vec!["high","max","oom","oom_kill","oom_group_kill"]),("/sys/fs/cgroup/memory.swap.events",vec!["high","max","fail"])]{let a=counters(&before,p);let b=counters(&after,p);for k in keys{let x=*a.get(k).unwrap();let y=*b.get(k).unwrap();assert!(y>=x);events.push(json!({"file":p,"counter":k,"delta":y-x,"passed":y==x}));}}
 assert_eq!(read(format!("{R}/backings-before.json")),read(format!("{R}/backings-after.json")));
 v["backing_guards"]=json!(guards);v["environment_guards"]=json!(events);v["all_gates_pass"]=json!(basic["all_gates_pass"]==true&&guards.iter().all(|g|g["passed"]==true)&&events.iter().all(|g|g["passed"]==true));v["target_interpretation_requires_per_context_controls"]=json!(true);save("basic-review.json",basic);fs::write(format!("{R}/review.json"),serde_json::to_vec_pretty(&v).unwrap()).unwrap();println!("TARGET COMPLETE220exports; canonical55664; calibrated={}",v["all_gates_pass"]);
}
fn execute(smoke:bool){
 fs::create_dir(R).unwrap();topology(!smoke);snapshot("before");prepare(smoke);let log=fs::File::create(format!("{R}/workflow.log")).unwrap();let status=Command::new("/usr/local/bin/cr-xtask").args(["workflow",&format!("{R}/plan.json"),&format!("{R}/run")]).stdout(std::process::Stdio::from(log.try_clone().unwrap())).stderr(std::process::Stdio::from(log)).status().unwrap();assert!(status.success(),"workflow failed; preserve partial outputs and do not replay successful SDK calls");println!("COMPLETE {}",if smoke{"smoke"}else{"measure"});
}
fn main(){let a=std::env::args().collect::<Vec<_>>();match a[1].as_str(){
 "smoke"=>execute(true),"measure"=>execute(false),
 "plan"=>{fs::create_dir(R).unwrap();save("backings-dry-plan.json",backings());prepare(false);println!("PLAN ONLY; zero SDK calls");},
 "inspect"=>{let v=validate::inspect(&a[2]);fs::create_dir_all(format!("{R}/checks")).unwrap();save(&format!("checks/{}.json",a[2]),v);},
 "snapshot"=>snapshot(&a[2]),"smoke-review"=>smoke_review(),"review"=>{review();extended_review();},
 _=>panic!("unknown operation")}}
