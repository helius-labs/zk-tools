use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/msm-c7a180";
fn one(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"missing/duplicate: {a}");*s=s.replace(a,b);}
fn main(){
 let mut s=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/msm-local180/local.rs").unwrap();
 s.truncate(s.find("fn main() {").unwrap());
 one(&mut s,"const R: &str = \"/home/ubuntu/src/zopro-perf-work/msm-local180\";","const R: &str = \"/output/msm-c7a180\";");
 one(&mut s,"const I: &str = \"/home/ubuntu/src/zopro-perf-work/msm-full180\";","const I: &str = \"/cr-msm\";");
 one(&mut s,"f40afdcc062125e33e69e523708915956f1aa21bfc25b2dfd2604e81d28e0446","db66bc98a0abbc4c89000e84331cc3eadf7fb6d873c9b2df5ba472cc5cd3df3c");
 s=s.replace("proof-sha256-after-preflight.json","seed.json");
 one(&mut s,"fn prepare() {","fn prepare(smoke: bool) {");
 one(&mut s,"let original = read", "let initial = seed(smoke); assert_eq!(initial.len(), if smoke {55440} else {55444});\n    save(\"mode.json\", json!({\"smoke\":smoke}));\n    let original = read");
 one(&mut s,"j[\"panel\"] = json!(panel);","j[\"panel\"] = json!(panel);\n        let backing=block%3;let binary=format!(\"/usr/local/bin/{}{}\",j[\"family\"].as_str().unwrap(),backing);\n        j[\"backing\"]=json!(backing);j[\"binary\"]=json!(binary);j[\"binary_sha256\"]=json!(hash(&binary));");
 one(&mut s,"step[\"name\"] = json!(name);","step[\"name\"] = json!(name);\n        step[\"argv\"][3]=json!(binary);");
 let a=s.find("    for w in [16, 32] {").unwrap();let b=s.find("    drop(add);").unwrap();
 let old=s[a..b].replace("[16, 32]","[32, 96]");s.replace_range(a..b,&format!("    if smoke {{for(mode,arm)in[(\"zopro\",\"ON\"),(\"sorted\",\"FRESH\"),(\"sorted\",\"ON\"),(\"windowed\",\"ON\")]{{add(4,0,\"preflight\",mode,arm);}}}}else{{\n{old}    }}\n"));
 one(&mut s,"assert_eq!(jobs.len(), 220);","assert_eq!(jobs.len(), if smoke {4}else{220});");
 one(&mut s,"        10780\n    );","        if smoke {16}else{10780}\n    );");
 one(&mut s,"\"review\"],\"timeout_seconds\":120}","if smoke {\"smoke-review\"}else{\"review\"}],\"timeout_seconds\":120}");
 s=s.replace("format!(\"{R}/local\")","\"/usr/local/bin/msm-runner\".to_string()");
 let a=s.find("    for p in [\n        \"/usr/local/bin/msm-runner\"").unwrap();let b=s[a..].find("    save(\"pins.json\"").unwrap()+a;
 s.replace_range(a..b,"    for p in [format!(\"{R}/jobs.json\"),format!(\"{R}/mode.json\"),format!(\"{I}/preflight-pins.json\")] {pins.insert(p.clone(),json!(hash(p)));}\n    if !smoke {pins.insert(format!(\"{I}/smoke-complete.json\"),json!(hash(format!(\"{I}/smoke-complete.json\"))));}\n");
 one(&mut s,"    let seed = read(format!(\"{I}/seed.json\"));\n    let mut ledger: BTreeSet<String> = serde_json::from_value(seed).unwrap();\n    assert_eq!(ledger.len(), 55220);","    let mut ledger = seed(false);\n    assert_eq!(ledger.len(),55444);");
 s=s.replace("assert_eq!(ledger.len(), 55440)","assert_eq!(ledger.len(), 55664)").replace("\"canonical_count\":55440","\"canonical_count\":55664");
 s=s.replace("[16, 32]","[32, 96]").replace("get(mode, 32, arm, b)","get(mode, 96, arm, b)").replace("get(mode, 16, arm, b)","get(mode, 32, arm, b)").replace("median_32_over_16","median_96_over_32");
 one(&mut s,"        \"/proc/self/cgroup\",","        \"/proc/self/cgroup\",\n        \"/sys/fs/cgroup/cpu.max\",\n        \"/sys/fs/cgroup/cpu.stat\",\n        \"/sys/fs/cgroup/memory.max\",\n        \"/sys/fs/cgroup/memory.events\",\n        \"/sys/fs/cgroup/memory.swap.max\",\n        \"/sys/fs/cgroup/memory.swap.events\",\n        \"/sys/fs/cgroup/memory.peak\",");
 s=s.replace("Frozen220 processes10780SDKcalls; canonical55220->55440; no capture yet","Frozen target plan prepared; no capture yet").replace("COMPLETE220 verified exports; canonical55440; interpret individual diagnostic gates","Basic review complete220 verified exports; canonical55664; extended gates follow");
 s.push_str(&fs::read_to_string(format!("{R}/extra.rs")).unwrap());
 fs::write(format!("{R}/runner.rs"),s).unwrap();
 fs::copy("/home/ubuntu/src/zopro-perf-work/msm-local180/validate.rs",Path::new(R).join("validate.rs")).unwrap();
 println!("Generated runner from qualified local reader; explicit smoke,backings,target guards; no SDK build");
}
