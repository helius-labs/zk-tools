impl<C: FpConfig, const MIXED: bool> Ifma8<C, MIXED> {
    /// Normalized limbs permit a borrow decision from unequal top digits.
    /// An equal top digit in any lane keeps the complete original algorithm.
    #[inline(always)]
    fn sub_high_borrow(&self, b: &Self) -> Option<Self> {
        // SAFETY: this module is restricted to AVX-512 IFMA/VL/DQ, and every
        // input digit is normalized. a,b<2p implies 0<=a-b+[a<b]*2p<2p.
        unsafe {
            if _mm512_cmpeq_epi64_mask(self.0[4], b.0[4]) != 0 {
                return None;
            }
            let negative = _mm512_cmplt_epu64_mask(self.0[4], b.0[4]);
            let twice = const { crate::portable::add4(C::P, C::P).0 };
            let modulus = split(twice).map(Self::splat);
            let mask = Self::splat(MASK);
            let mut carry = Self::splat(0);
            let mut out = [Self::splat(0); 5];
            for j in 0..5 {
                let correction = _mm512_maskz_mov_epi64(negative, modulus[j]);
                let value = _mm512_add_epi64(
                    _mm512_sub_epi64(_mm512_add_epi64(self.0[j], correction), b.0[j]),
                    carry,
                );
                out[j] = _mm512_and_si512(value, mask);
                carry = _mm512_srai_epi64::<52>(value);
            }
            debug_assert_eq!(_mm512_cmpneq_epi64_mask(carry, Self::splat(0)), 0);
            Some(Self(out, PhantomData))
        }
    }
    #[cfg(test)]
    #[inline(always)]
    fn sub_original_reference(&self, b: &Self) -> Self {
        unsafe {
            let p = split(crate::portable::add4(C::P, C::P).0).map(Self::splat);
            let mask = Self::splat(MASK);
            let mut t = [Self::splat(0); 5];
            let mut borrow = Self::splat(0);
            for j in 0..5 {
                let v = _mm512_add_epi64(_mm512_sub_epi64(self.0[j], b.0[j]), borrow);
                t[j] = _mm512_and_si512(v, mask);
                borrow = _mm512_srai_epi64::<52>(v);
            }
            let negative = _mm512_cmpneq_epi64_mask(borrow, Self::splat(0));
            for j in 0..5 {
                t[j] = _mm512_add_epi64(t[j], _mm512_maskz_mov_epi64(negative, p[j]));
            }
            for j in 0..4 {
                t[j + 1] = _mm512_add_epi64(t[j + 1], _mm512_srli_epi64::<52>(t[j]));
                t[j] = _mm512_and_si512(t[j], mask);
            }
            t[4] = _mm512_and_si512(t[4], mask);
            Self(t, PhantomData)
        }
    }
}
#[cfg(test)]
mod high_borrow_tests {
    use super::*;
    use crate::{FqConfig, FrConfig};
    use ark_ff::{Field, PrimeField};
    fn words<C: FpConfig, const MIXED: bool>(x: Ifma8<C,MIXED>) -> [[u64;4];8] {
        let t:[[u64;8];5]=x.0.map(|v|unsafe{core::mem::transmute(v)});
        core::array::from_fn(|i|[
            t[0][i]|t[1][i]<<52,
            t[1][i]>>12|t[2][i]<<40,
            t[2][i]>>24|t[3][i]<<28,
            t[3][i]>>36|t[4][i]<<16,
        ])
    }
    fn check_pair<C: FpConfig,A:PrimeField,const MIXED:bool>(a:[[u64;4];8],b:[[u64;4];8]) {
        let av=Ifma8::<C,MIXED>::raw(&a);let bv=Ifma8::<C,MIXED>::raw(&b);
        let reference=av.sub_original_reference(&bv);
        let actual=av.sub(&bv);
        let aa:[[u64;8];5]=actual.0.map(|v|unsafe{core::mem::transmute(v)});
        let bb:[[u64;8];5]=reference.0.map(|v|unsafe{core::mem::transmute(v)});
        assert_eq!(aa,bb);
        let twice=crate::portable::add4(C::P,C::P).0;let raw=words(actual);
        let r_inverse=A::from(2u64).pow([if MIXED{256}else{260}]).inverse().unwrap();
        let host_inverse=A::from(2u64).pow([256]).inverse().unwrap();
        let numeric=|x:[u64;4]|A::from_le_bytes_mod_order(&x.into_iter().flat_map(u64::to_le_bytes).collect::<Vec<_>>());
        let canonical=actual.get();
        for i in 0..8 {
            let expected=if crate::portable::less(a[i],b[i]){crate::portable::sub4(crate::portable::add4(a[i],twice).0,b[i]).0}else{crate::portable::sub4(a[i],b[i]).0};
            assert_eq!(raw[i],expected);
            for digit in &aa {assert!(digit[i]<1u64<<52);}
            assert!(crate::portable::less(raw[i],twice));
            assert!(crate::portable::less(canonical[i].0,C::P));
            assert_eq!(numeric(canonical[i].0)*host_inverse,(numeric(a[i])-numeric(b[i]))*r_inverse);
        }
    }
    fn masks<C:FpConfig,A:PrimeField,const MIXED:bool>() {
        let twice=crate::portable::add4(C::P,C::P).0;let limit=crate::portable::sub4(twice,[1,0,0,0]).0;
        let mut edges=vec![[0;4],[1,0,0,0],crate::portable::sub4(C::P,[1,0,0,0]).0,C::P,crate::portable::add4(C::P,[1,0,0,0]).0,limit];
        for bit in 1..254 {let mut x=[0;4];x[bit/64]=1u64<<(bit%64);for v in[x,crate::portable::sub4(x,[1,0,0,0]).0,crate::portable::add4(x,[1,0,0,0]).0]{if !crate::portable::less(limit,v){edges.push(v);}}}
        for k in 0..edges.len(){for offset in[0,1,3,37,edges.len()/2]{let a=core::array::from_fn(|i|edges[(k+i)%edges.len()]);let b=core::array::from_fn(|i|edges[(k+offset+7*i)%edges.len()]);check_pair::<C,A,MIXED>(a,b);}}
        let top=split(C::P)[4]/4;
        for tie in 0u16..256 {for reverse in[false,true]{let a=core::array::from_fn(|i|[u64::MAX-i as u64,0,1,((top+4*i as u64+2)<<16)|17]);let b=core::array::from_fn(|i|{let high=top+4*i as u64+if tie>>i&1!=0{2}else if(i%2==0)^reverse{1}else{3};[0,u64::MAX,7,(high<<16)|31]});let av=Ifma8::<C,MIXED>::raw(&a);let bv=Ifma8::<C,MIXED>::raw(&b);assert_eq!(av.sub_high_borrow(&bv).is_some(),tie==0);check_pair::<C,A,MIXED>(a,b);}}
    }
    #[test]fn high_borrow_all_tie_masks_and_numeric_boundaries(){masks::<FqConfig,ark_ref::Fq,false>();masks::<FqConfig,ark_ref::Fq,true>();masks::<FrConfig,ark_ref::Fr,false>();masks::<FrConfig,ark_ref::Fr,true>();}
    fn changing<C:FpConfig,A:PrimeField,const MIXED:bool>() {
        let mut seed=0xf026cbd3a17729b1u64;
        for _ in 0..512 {let mut random=||{let mut bytes=[0u8;64];for part in bytes.chunks_exact_mut(8){seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;part.copy_from_slice(&seed.to_le_bytes());}let x=Fp::<C>::from_random_bytes(&bytes).0;if seed&1!=0{crate::portable::add4(x,C::P).0}else{x}};let a=core::array::from_fn(|_|random());let b=core::array::from_fn(|_|random());let f=Ifma8::<C,MIXED>::new(&core::array::from_fn(|i|Fp::<C>::from_u64(i as u64+19)));let mut x=Ifma8::<C,MIXED>::raw(&a);let bv=Ifma8::<C,MIXED>::raw(&b);for _ in 0..8 {check_pair::<C,A,MIXED>(words(x),b);let next=x.sub(&bv).mul(&f);let reference=x.sub_original_reference(&bv).mul(&f);assert_eq!(words(next),words(reference));x=next;}}
    }
    #[test]fn high_borrow_loose_random_chains(){changing::<FqConfig,ark_ref::Fq,false>();changing::<FqConfig,ark_ref::Fq,true>();changing::<FrConfig,ark_ref::Fr,false>();changing::<FrConfig,ark_ref::Fr,true>();}
}
