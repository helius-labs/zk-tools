impl<C: FpConfig, const MIXED: bool> Ifma8<C, MIXED> {
    /// Normalized limbs permit a borrow decision from unequal top digits.
    /// An equal top digit in any lane keeps the complete original algorithm.
    #[inline(always)]
    fn sub_high_borrow(&self, b: &Self) -> Option<Self> {
        // SAFETY: this module is restricted to AVX-512 IFMA/VL/DQ, and every
        // input digit is normalized. a,b<2p implies 0<=a-b+[a<b]*2p<2p.
        unsafe {
            if _mm512_cmpeq_epi64_mask(self.0[4], b.0[4]) != 0 {
                return None;
            }
            let negative = _mm512_cmplt_epu64_mask(self.0[4], b.0[4]);
            let twice = const { crate::portable::add4(C::P, C::P).0 };
            let modulus = split(twice).map(Self::splat);
            let mask = Self::splat(MASK);
            let mut carry = Self::splat(0);
            let mut out = [Self::splat(0); 5];
            for j in 0..5 {
                let correction = _mm512_maskz_mov_epi64(negative, modulus[j]);
                let value = _mm512_add_epi64(
                    _mm512_sub_epi64(_mm512_add_epi64(self.0[j], correction), b.0[j]),
                    carry,
                );
                out[j] = _mm512_and_si512(value, mask);
                carry = _mm512_srai_epi64::<52>(value);
            }
            debug_assert_eq!(_mm512_cmpneq_epi64_mask(carry, Self::splat(0)), 0);
            Some(Self(out, PhantomData))
        }
    }
    {{ORIGINAL_SUB}}
}
