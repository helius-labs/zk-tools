include!("common.rs");
const RC:&str="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
const TOOL:&str="/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
const COMMON:&str="/home/ubuntu/src/zopro-perf-work/compiler199-sdk176/target-OFF/release/deps";
fn unique(dir:&str,prefix:&str)->String {
    let paths=fs::read_dir(dir).unwrap().map(|e|e.unwrap().path()).filter(|p|p.file_name().unwrap().to_str().unwrap().starts_with(prefix)&&p.extension().is_some_and(|x|x=="rlib")).collect::<Vec<_>>();
    assert_eq!(paths.len(),1,"{dir} {prefix}");paths[0].display().to_string()
}
fn step(name:&str,argv:Vec<String>)->Value{json!({"kind":"command","name":name,"argv":argv,"environment":{},"timeout_seconds":600})}
fn main() {
    assert!(!r("build-plan.json").exists());
    let manifest=read("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json");
    for (p,h) in manifest["source_files_sha256"].as_object().unwrap(){assert_eq!(hash(format!("/home/ubuntu/src/zk-tools/zopro/{p}")),h.as_str().unwrap());}
    let qualification=read(format!("{Q}/review.json"));assert_eq!(qualification["passed"],true);
    let frozen="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/frozen/candidate";
    let mut libraries=json!({"REF":{"path":format!("{frozen}/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib")},"OFF":qualification["libraries"]["OFF"],"ON":qualification["libraries"]["ON"]});
    let mut pins=BTreeMap::new();
    for arm in ARMS {let path=libraries[arm]["path"].as_str().unwrap().to_owned();let h=hash(&path);if arm!="REF"{assert_eq!(libraries[arm]["sha256"],h);}libraries[arm]["sha256"]=h.into();pin(&mut pins,path);}
    let shared=[("libc",unique(COMMON,"liblibc-")),("serde_json",unique(COMMON,"libserde_json-"))];
    let mut steps=vec![];
    for arm in ARMS {
        let lib=libraries[arm]["path"].as_str().unwrap();
        let dep=if arm=="REF" {frozen.to_owned()} else {format!("{Q}/target-{arm}/release/deps")};
        let mut argv=vec![RC.into(),"--edition=2021".into(),"-C".into(),"opt-level=3".into(),"-C".into(),"target-cpu=native".into(),"-C".into(),"lto=fat".into(),"-C".into(),"codegen-units=1".into(),"-C".into(),"debuginfo=1".into(),r("driver.rs").display().to_string(),"-o".into(),r(format!("bench-{arm}")).display().to_string(),"-L".into(),format!("dependency={dep}"),"-L".into(),format!("dependency={COMMON}"),"--extern".into(),format!("zopro_bn254={lib}")];
        for (name,path) in &shared {argv.extend(["--extern".into(),format!("{name}={path}")]);}
        steps.push(step(&format!("build-bench-{arm}"),argv));
    }
    let arkdeps=format!("{Q}/target-OFF/release/deps");
    let mut fixture_args=vec![RC.into(),"--edition=2021".into(),"-O".into(),r("fixtures.rs").display().to_string(),"-o".into(),r("fixtures").display().to_string(),"-L".into(),format!("dependency={arkdeps}")];
    for (name,prefix) in [("ark_bn254","libark_bn254-"),("ark_ec","libark_ec-"),("ark_ff","libark_ff-"),("ark_std","libark_std-")] {fixture_args.extend(["--extern".into(),format!("{name}={}",unique(&arkdeps,prefix))]);}
    steps.push(step("build-fixture-generator",fixture_args));
    for name in ["campaign","analyze","review"] {
        let mut argv=vec![RC.into(),"--edition=2021".into(),"-O".into(),r(format!("{name}.rs")).display().to_string(),"-o".into(),r(name).display().to_string(),"-L".into(),format!("dependency={TOOL}")];
        for (lib,file) in [("serde_json","libserde_json-cdebb9338c2784ad.rlib"),("sha2","libsha2-16b8f2c03bdf5faa.rlib"),("rustc_demangle","librustc_demangle-3e2a96f78b3a16e4.rlib")] {argv.extend(["--extern".into(),format!("{lib}={TOOL}/{file}")]);}
        steps.push(step(&format!("build-{name}"),argv));
    }
    steps.push(step("generate-frozen-synthetic-fixtures",vec![r("fixtures").display().to_string(),R.into()]));
    for dir in [COMMON,TOOL,frozen,&arkdeps,&format!("{Q}/target-ON/release/deps")] {
        for e in fs::read_dir(dir).unwrap(){let p=e.unwrap().path();if p.extension().is_some_and(|x|x=="rlib"){pin(&mut pins,p);}}
    }
    for file in ["prepare.rs","prepare","common.rs","design.md","driver.rs","perf.rs","fixtures.rs","campaign.rs","analyze.rs","review.rs","statistics.rs"]{pin(&mut pins,r(file));}
    pin(&mut pins,RC);pin(&mut pins,format!("{Q}/review.json"));
    save(r("libraries.json"),&libraries);pin(&mut pins,r("libraries.json"));
    save(r("build-pins.json"),&json!(pins));save(r("build-plan.json"),&json!({"version":1,"source_pins":r("build-pins.json"),"steps":steps}));
    println!("Frozen 8 build/fixture commands; actual field REF/fresh OFF/ON; complete-call harness and both readers; no clocks");
}
