
/home/ubuntu/src/zopro-perf-work/seed-naf-callers176/bench-OFF:     file format elf64-x86-64


Disassembly of section .text:

0000000000063b70 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup>:
   63b70:	55                   	push   %rbp
   63b71:	41 57                	push   %r15
   63b73:	41 56                	push   %r14
   63b75:	41 55                	push   %r13
   63b77:	41 54                	push   %r12
   63b79:	53                   	push   %rbx
   63b7a:	48 81 ec 18 07 00 00 	sub    $0x718,%rsp
   63b81:	c5 fe 6f 07          	vmovdqu (%rdi),%ymm0
   63b85:	48 89 fb             	mov    %rdi,%rbx
   63b88:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63b8d:	75 28                	jne    63bb7 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x47>
   63b8f:	c5 fe 6f 43 20       	vmovdqu 0x20(%rbx),%ymm0
   63b94:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63b99:	75 1c                	jne    63bb7 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x47>
   63b9b:	c5 fe 6f 43 40       	vmovdqu 0x40(%rbx),%ymm0
   63ba0:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63ba5:	75 10                	jne    63bb7 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x47>
   63ba7:	c5 fe 6f 43 60       	vmovdqu 0x60(%rbx),%ymm0
   63bac:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63bb1:	0f 84 ff 5b 00 00    	je     697b6 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x5c46>
   63bb7:	62 f1 7c 48 10 05 3f 	vmovups -0x534c1(%rip),%zmm0        # 10700 <zmij::STATIC_DATA+0x4600>
   63bbe:	cb fa ff 
   63bc1:	62 f1 7c 48 10 15 f5 	vmovups -0x5350b(%rip),%zmm2        # 106c0 <zmij::STATIC_DATA+0x45c0>
   63bc8:	ca fa ff 
   63bcb:	62 f1 fe 48 6f 0d ab 	vmovdqu64 -0x53555(%rip),%zmm1        # 10680 <zmij::STATIC_DATA+0x4580>
   63bd2:	ca fa ff 
   63bd5:	41 bc 41 00 00 00    	mov    $0x41,%r12d
   63bdb:	4c 8d b4 24 d8 04 00 	lea    0x4d8(%rsp),%r14
   63be2:	00 
   63be3:	4c 8d bc 24 10 04 00 	lea    0x410(%rsp),%r15
   63bea:	00 
   63beb:	49 bd f1 09 69 4a b4 	movabs $0x44e992b44a6909f1,%r13
   63bf2:	92 e9 44 
   63bf5:	62 f1 7c 48 11 84 24 	vmovups %zmm0,0x490(%rsp)
   63bfc:	90 04 00 00 
   63c00:	62 f1 7c 48 11 94 24 	vmovups %zmm2,0x450(%rsp)
   63c07:	50 04 00 00 
   63c0b:	62 f1 fe 48 7f 8c 24 	vmovdqu64 %zmm1,0x410(%rsp)
   63c12:	10 04 00 00 
   63c16:	eb 15                	jmp    63c2d <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0xbd>
   63c18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   63c1f:	00 
   63c20:	49 ff cc             	dec    %r12
   63c23:	49 83 fc 01          	cmp    $0x1,%r12
   63c27:	0f 86 b6 00 00 00    	jbe    63ce3 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x173>
   63c2d:	4c 89 f7             	mov    %r14,%rdi
   63c30:	4c 89 fe             	mov    %r15,%rsi
   63c33:	c5 f8 77             	vzeroupper
   63c36:	e8 55 c8 01 00       	call   80490 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::double>
   63c3b:	62 f1 7c 48 10 84 24 	vmovups 0x4d8(%rsp),%zmm0
   63c42:	d8 04 00 00 
   63c46:	62 f1 fe 48 6f 8c 24 	vmovdqu64 0x518(%rsp),%zmm1
   63c4d:	18 05 00 00 
   63c51:	62 f1 7c 48 10 94 24 	vmovups 0x558(%rsp),%zmm2
   63c58:	58 05 00 00 
   63c5c:	41 8d 44 24 fe       	lea    -0x2(%r12),%eax
   63c61:	0f b6 c0             	movzbl %al,%eax
   63c64:	49 0f a3 c5          	bt     %rax,%r13
   63c68:	62 f1 7c 48 11 94 24 	vmovups %zmm2,0x490(%rsp)
   63c6f:	90 04 00 00 
   63c73:	62 f1 fe 48 7f 8c 24 	vmovdqu64 %zmm1,0x450(%rsp)
   63c7a:	50 04 00 00 
   63c7e:	62 f1 7c 48 11 84 24 	vmovups %zmm0,0x410(%rsp)
   63c85:	10 04 00 00 
   63c89:	73 95                	jae    63c20 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0xb0>
   63c8b:	4c 89 f7             	mov    %r14,%rdi
   63c8e:	4c 89 fe             	mov    %r15,%rsi
   63c91:	48 89 da             	mov    %rbx,%rdx
   63c94:	c5 f8 77             	vzeroupper
   63c97:	e8 04 74 00 00       	call   6b0a0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::add_affine>
   63c9c:	62 f1 7c 48 10 84 24 	vmovups 0x4d8(%rsp),%zmm0
   63ca3:	d8 04 00 00 
   63ca7:	62 f1 fe 48 6f 8c 24 	vmovdqu64 0x518(%rsp),%zmm1
   63cae:	18 05 00 00 
   63cb2:	62 f1 7c 48 10 94 24 	vmovups 0x558(%rsp),%zmm2
   63cb9:	58 05 00 00 
   63cbd:	62 f1 7c 48 11 94 24 	vmovups %zmm2,0x490(%rsp)
   63cc4:	90 04 00 00 
   63cc8:	62 f1 fe 48 7f 8c 24 	vmovdqu64 %zmm1,0x450(%rsp)
   63ccf:	50 04 00 00 
   63cd3:	62 f1 7c 48 11 84 24 	vmovups %zmm0,0x410(%rsp)
   63cda:	10 04 00 00 
   63cde:	e9 3d ff ff ff       	jmp    63c20 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0xb0>
   63ce3:	4c 8d b4 24 98 05 00 	lea    0x598(%rsp),%r14
   63cea:	00 
   63ceb:	4c 8d bc 24 10 04 00 	lea    0x410(%rsp),%r15
   63cf2:	00 
   63cf3:	4c 89 f7             	mov    %r14,%rdi
   63cf6:	4c 89 fe             	mov    %r15,%rsi
   63cf9:	c5 f8 77             	vzeroupper
   63cfc:	e8 bf 5a 00 00       	call   697c0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::psi>
   63d01:	4c 8d a4 24 58 06 00 	lea    0x658(%rsp),%r12
   63d08:	00 
   63d09:	4c 89 f6             	mov    %r14,%rsi
   63d0c:	4c 89 e7             	mov    %r12,%rdi
   63d0f:	e8 ac 5a 00 00       	call   697c0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::psi>
   63d14:	4c 8d ac 24 d8 04 00 	lea    0x4d8(%rsp),%r13
   63d1b:	00 
   63d1c:	4c 89 fe             	mov    %r15,%rsi
   63d1f:	48 89 da             	mov    %rbx,%rdx
   63d22:	4c 89 ef             	mov    %r13,%rdi
   63d25:	e8 76 73 00 00       	call   6b0a0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::add_affine>
   63d2a:	48 8d 9c 24 90 02 00 	lea    0x290(%rsp),%rbx
   63d31:	00 
   63d32:	4c 89 ee             	mov    %r13,%rsi
   63d35:	4c 89 f2             	mov    %r14,%rdx
   63d38:	48 89 df             	mov    %rbx,%rdi
   63d3b:	e8 80 01 01 00       	call   73ec0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::add_projective>
   63d40:	48 8d bc 24 50 03 00 	lea    0x350(%rsp),%rdi
   63d47:	00 
   63d48:	48 89 de             	mov    %rbx,%rsi
   63d4b:	4c 89 e2             	mov    %r12,%rdx
   63d4e:	e8 6d 01 01 00       	call   73ec0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::add_projective>
   63d53:	48 8d 9c 24 d8 04 00 	lea    0x4d8(%rsp),%rbx
   63d5a:	00 
   63d5b:	4c 89 e6             	mov    %r12,%rsi
   63d5e:	48 89 df             	mov    %rbx,%rdi
   63d61:	e8 5a 5a 00 00       	call   697c0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::psi>
   63d66:	48 8d bc 24 90 02 00 	lea    0x290(%rsp),%rdi
   63d6d:	00 
   63d6e:	48 89 de             	mov    %rbx,%rsi
   63d71:	e8 1a c7 01 00       	call   80490 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::double>
   63d76:	c5 fe 6f 84 24 d0 03 	vmovdqu 0x3d0(%rsp),%ymm0
   63d7d:	00 00 
   63d7f:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63d84:	74 21                	je     63da7 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x237>
   63d86:	31 c0                	xor    %eax,%eax
   63d88:	c5 fe 6f 84 24 10 03 	vmovdqu 0x310(%rsp),%ymm0
   63d8f:	00 00 
   63d91:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63d96:	74 30                	je     63dc8 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x258>
   63d98:	31 c9                	xor    %ecx,%ecx
   63d9a:	89 c2                	mov    %eax,%edx
   63d9c:	08 ca                	or     %cl,%dl
   63d9e:	74 3f                	je     63ddf <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x26f>
   63da0:	20 c8                	and    %cl,%al
   63da2:	e9 02 2b 00 00       	jmp    668a9 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2d39>
   63da7:	c5 fe 6f 84 24 f0 03 	vmovdqu 0x3f0(%rsp),%ymm0
   63dae:	00 00 
   63db0:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63db5:	0f 94 c0             	sete   %al
   63db8:	c5 fe 6f 84 24 10 03 	vmovdqu 0x310(%rsp),%ymm0
   63dbf:	00 00 
   63dc1:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63dc6:	75 d0                	jne    63d98 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x228>
   63dc8:	c5 fe 6f 84 24 30 03 	vmovdqu 0x330(%rsp),%ymm0
   63dcf:	00 00 
   63dd1:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63dd6:	0f 94 c1             	sete   %cl
   63dd9:	89 c2                	mov    %eax,%edx
   63ddb:	08 ca                	or     %cl,%dl
   63ddd:	75 c1                	jne    63da0 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x230>
   63ddf:	c5 fc 10 84 24 f0 03 	vmovups 0x3f0(%rsp),%ymm0
   63de6:	00 00 
   63de8:	48 8b 84 24 d0 03 00 	mov    0x3d0(%rsp),%rax
   63def:	00 
   63df0:	48 8b 8c 24 d8 03 00 	mov    0x3d8(%rsp),%rcx
   63df7:	00 
   63df8:	4c 8b 94 24 e0 03 00 	mov    0x3e0(%rsp),%r10
   63dff:	00 
   63e00:	4c 8b 9c 24 e8 03 00 	mov    0x3e8(%rsp),%r11
   63e07:	00 
   63e08:	4c 8d 7c 24 30       	lea    0x30(%rsp),%r15
   63e0d:	49 be 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r14
   63e14:	07 d2 87 
   63e17:	4c 8d 84 24 e0 01 00 	lea    0x1e0(%rsp),%r8
   63e1e:	00 
   63e1f:	4c 8d 8c 24 60 01 00 	lea    0x160(%rsp),%r9
   63e26:	00 
   63e27:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
   63e2e:	00 
   63e2f:	48 89 8c 24 e8 01 00 	mov    %rcx,0x1e8(%rsp)
   63e36:	00 
   63e37:	4c 89 94 24 f0 01 00 	mov    %r10,0x1f0(%rsp)
   63e3e:	00 
   63e3f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   63e44:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
   63e4b:	00 
   63e4c:	4c 89 9c 24 f8 01 00 	mov    %r11,0x1f8(%rsp)
   63e53:	00 
   63e54:	c5 fc 11 84 24 00 01 	vmovups %ymm0,0x100(%rsp)
   63e5b:	00 00 
   63e5d:	c5 fc 11 84 24 60 01 	vmovups %ymm0,0x160(%rsp)
   63e64:	00 00 
   63e66:	c5 fe 6f 05 d2 21 fa 	vmovdqu -0x5de2e(%rip),%ymm0        # 6040 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x5a0>
   63e6d:	ff 
   63e6e:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   63e74:	31 c0                	xor    %eax,%eax
   63e76:	31 f6                	xor    %esi,%esi
   63e78:	31 db                	xor    %ebx,%ebx
   63e7a:	45 31 e4             	xor    %r12d,%r12d
   63e7d:	31 ff                	xor    %edi,%edi
   63e7f:	49 8b 11             	mov    (%r9),%rdx
   63e82:	31 c9                	xor    %ecx,%ecx
   63e84:	c4 42 d3 f6 28       	mulx   (%r8),%rbp,%r13
   63e89:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   63e8f:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   63e95:	c4 42 d3 f6 68 08    	mulx   0x8(%r8),%rbp,%r13
   63e9b:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   63ea1:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   63ea7:	c4 42 d3 f6 68 10    	mulx   0x10(%r8),%rbp,%r13
   63ead:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   63eb3:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   63eb9:	c4 42 d3 f6 68 18    	mulx   0x18(%r8),%rbp,%r13
   63ebf:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   63ec5:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   63ecb:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   63ed1:	48 89 c2             	mov    %rax,%rdx
   63ed4:	49 0f af d6          	imul   %r14,%rdx
   63ed8:	31 c9                	xor    %ecx,%ecx
   63eda:	c4 42 d3 f6 2f       	mulx   (%r15),%rbp,%r13
   63edf:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   63ee5:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   63eeb:	c4 42 d3 f6 6f 08    	mulx   0x8(%r15),%rbp,%r13
   63ef1:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   63ef7:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   63efd:	c4 42 d3 f6 6f 10    	mulx   0x10(%r15),%rbp,%r13
   63f03:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   63f09:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   63f0f:	c4 42 d3 f6 6f 18    	mulx   0x18(%r15),%rbp,%r13
   63f15:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   63f1b:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   63f21:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   63f27:	49 8b 51 08          	mov    0x8(%r9),%rdx
   63f2b:	31 c9                	xor    %ecx,%ecx
   63f2d:	c4 42 d3 f6 28       	mulx   (%r8),%rbp,%r13
   63f32:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   63f38:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   63f3e:	c4 42 d3 f6 68 08    	mulx   0x8(%r8),%rbp,%r13
   63f44:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   63f4a:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   63f50:	c4 42 d3 f6 68 10    	mulx   0x10(%r8),%rbp,%r13
   63f56:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   63f5c:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   63f62:	c4 42 d3 f6 68 18    	mulx   0x18(%r8),%rbp,%r13
   63f68:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   63f6e:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   63f74:	66 48 0f 38 f6 c1    	adcx   %rcx,%rax
   63f7a:	48 89 f2             	mov    %rsi,%rdx
   63f7d:	49 0f af d6          	imul   %r14,%rdx
   63f81:	31 c9                	xor    %ecx,%ecx
   63f83:	c4 42 d3 f6 2f       	mulx   (%r15),%rbp,%r13
   63f88:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   63f8e:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   63f94:	c4 42 d3 f6 6f 08    	mulx   0x8(%r15),%rbp,%r13
   63f9a:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   63fa0:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   63fa6:	c4 42 d3 f6 6f 10    	mulx   0x10(%r15),%rbp,%r13
   63fac:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   63fb2:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   63fb8:	c4 42 d3 f6 6f 18    	mulx   0x18(%r15),%rbp,%r13
   63fbe:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   63fc4:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   63fca:	66 48 0f 38 f6 c1    	adcx   %rcx,%rax
   63fd0:	49 8b 51 10          	mov    0x10(%r9),%rdx
   63fd4:	31 c9                	xor    %ecx,%ecx
   63fd6:	c4 42 d3 f6 28       	mulx   (%r8),%rbp,%r13
   63fdb:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   63fe1:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   63fe7:	c4 42 d3 f6 68 08    	mulx   0x8(%r8),%rbp,%r13
   63fed:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   63ff3:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   63ff9:	c4 42 d3 f6 68 10    	mulx   0x10(%r8),%rbp,%r13
   63fff:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   64005:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   6400b:	c4 42 d3 f6 68 18    	mulx   0x18(%r8),%rbp,%r13
   64011:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64017:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   6401d:	66 48 0f 38 f6 f1    	adcx   %rcx,%rsi
   64023:	48 89 da             	mov    %rbx,%rdx
   64026:	49 0f af d6          	imul   %r14,%rdx
   6402a:	31 c9                	xor    %ecx,%ecx
   6402c:	c4 42 d3 f6 2f       	mulx   (%r15),%rbp,%r13
   64031:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   64037:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   6403d:	c4 42 d3 f6 6f 08    	mulx   0x8(%r15),%rbp,%r13
   64043:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64049:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   6404f:	c4 42 d3 f6 6f 10    	mulx   0x10(%r15),%rbp,%r13
   64055:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6405b:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   64061:	c4 42 d3 f6 6f 18    	mulx   0x18(%r15),%rbp,%r13
   64067:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   6406d:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   64073:	66 48 0f 38 f6 f1    	adcx   %rcx,%rsi
   64079:	49 8b 51 18          	mov    0x18(%r9),%rdx
   6407d:	31 c9                	xor    %ecx,%ecx
   6407f:	c4 42 d3 f6 28       	mulx   (%r8),%rbp,%r13
   64084:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   6408a:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   64090:	c4 42 d3 f6 68 08    	mulx   0x8(%r8),%rbp,%r13
   64096:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6409c:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   640a2:	c4 42 d3 f6 68 10    	mulx   0x10(%r8),%rbp,%r13
   640a8:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   640ae:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   640b4:	c4 42 d3 f6 68 18    	mulx   0x18(%r8),%rbp,%r13
   640ba:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   640c0:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   640c6:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   640cc:	4c 89 e2             	mov    %r12,%rdx
   640cf:	49 0f af d6          	imul   %r14,%rdx
   640d3:	31 c9                	xor    %ecx,%ecx
   640d5:	c4 42 d3 f6 2f       	mulx   (%r15),%rbp,%r13
   640da:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   640e0:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   640e6:	c4 42 d3 f6 6f 08    	mulx   0x8(%r15),%rbp,%r13
   640ec:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   640f2:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   640f8:	c4 42 d3 f6 6f 10    	mulx   0x10(%r15),%rbp,%r13
   640fe:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64104:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   6410a:	c4 42 d3 f6 6f 18    	mulx   0x18(%r15),%rbp,%r13
   64110:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   64116:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   6411c:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   64122:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   64129:	95 7e 68 
   6412c:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   64133:	8c 20 3c 
   64136:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   6413b:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   64140:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   64145:	48 89 34 24          	mov    %rsi,(%rsp)
   64149:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   6414f:	4d 89 df             	mov    %r11,%r15
   64152:	4d 89 d5             	mov    %r10,%r13
   64155:	48 39 d7             	cmp    %rdx,%rdi
   64158:	48 8d 0c 08          	lea    (%rax,%rcx,1),%rcx
   6415c:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   64163:	6a 81 97 
   64166:	c5 fc 10 8c 24 f0 03 	vmovups 0x3f0(%rsp),%ymm1
   6416d:	00 00 
   6416f:	4c 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%r9
   64176:	00 
   64177:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   6417c:	48 83 d9 00          	sbb    $0x0,%rcx
   64180:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
   64187:	00 
   64188:	0f 92 c1             	setb   %cl
   6418b:	48 39 d0             	cmp    %rdx,%rax
   6418e:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   64195:	ba af 47 
   64198:	0f 92 c2             	setb   %dl
   6419b:	48 01 f0             	add    %rsi,%rax
   6419e:	08 ca                	or     %cl,%dl
   641a0:	0f b6 ca             	movzbl %dl,%ecx
   641a3:	4d 89 ce             	mov    %r9,%r14
   641a6:	4d 89 c4             	mov    %r8,%r12
   641a9:	48 29 c8             	sub    %rcx,%rax
   641ac:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
   641b3:	00 
   641b4:	48 b8 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rax
   641bb:	45 50 b8 
   641be:	0f 92 c1             	setb   %cl
   641c1:	48 39 c6             	cmp    %rax,%rsi
   641c4:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   641cb:	b1 9b cf 
   641ce:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   641d5:	00 00 
   641d7:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   641dc:	0f 92 c2             	setb   %dl
   641df:	08 ca                	or     %cl,%dl
   641e1:	0f b6 ca             	movzbl %dl,%ecx
   641e4:	48 8d 14 03          	lea    (%rbx,%rax,1),%rdx
   641e8:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   641ef:	00 
   641f0:	48 29 ca             	sub    %rcx,%rdx
   641f3:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
   641fa:	00 
   641fb:	0f 92 84 24 98 00 00 	setb   0x98(%rsp)
   64202:	00 
   64203:	4c 03 20             	add    (%rax),%r12
   64206:	4c 13 70 08          	adc    0x8(%rax),%r14
   6420a:	4c 13 68 10          	adc    0x10(%rax),%r13
   6420e:	4c 13 78 18          	adc    0x18(%rax),%r15
   64212:	4c 89 e5             	mov    %r12,%rbp
   64215:	4c 89 f3             	mov    %r14,%rbx
   64218:	4c 89 e9             	mov    %r13,%rcx
   6421b:	4c 89 fa             	mov    %r15,%rdx
   6421e:	48 2b 2e             	sub    (%rsi),%rbp
   64221:	48 1b 5e 08          	sbb    0x8(%rsi),%rbx
   64225:	48 1b 4e 10          	sbb    0x10(%rsi),%rcx
   64229:	48 1b 56 18          	sbb    0x18(%rsi),%rdx
   6422d:	4c 0f 43 e5          	cmovae %rbp,%r12
   64231:	4c 0f 43 f3          	cmovae %rbx,%r14
   64235:	4c 0f 43 e9          	cmovae %rcx,%r13
   64239:	4c 0f 43 fa          	cmovae %rdx,%r15
   6423d:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   64243:	48 8d 8c 24 00 01 00 	lea    0x100(%rsp),%rcx
   6424a:	00 
   6424b:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   64250:	4c 2b 01             	sub    (%rcx),%r8
   64253:	4c 1b 49 08          	sbb    0x8(%rcx),%r9
   64257:	4c 1b 51 10          	sbb    0x10(%rcx),%r10
   6425b:	4c 1b 59 18          	sbb    0x18(%rcx),%r11
   6425f:	48 19 ff             	sbb    %rdi,%rdi
   64262:	48 8b 1a             	mov    (%rdx),%rbx
   64265:	48 8b 6a 08          	mov    0x8(%rdx),%rbp
   64269:	48 8b 42 10          	mov    0x10(%rdx),%rax
   6426d:	48 8b 72 18          	mov    0x18(%rdx),%rsi
   64271:	48 21 fb             	and    %rdi,%rbx
   64274:	48 21 fd             	and    %rdi,%rbp
   64277:	48 21 f8             	and    %rdi,%rax
   6427a:	48 21 fe             	and    %rdi,%rsi
   6427d:	49 01 d8             	add    %rbx,%r8
   64280:	49 11 e9             	adc    %rbp,%r9
   64283:	49 11 c2             	adc    %rax,%r10
   64286:	49 11 f3             	adc    %rsi,%r11
   64289:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
   64290:	00 
   64291:	4c 89 b4 24 68 01 00 	mov    %r14,0x168(%rsp)
   64298:	00 
   64299:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
   642a0:	00 
   642a1:	4c 89 84 24 00 01 00 	mov    %r8,0x100(%rsp)
   642a8:	00 
   642a9:	4c 89 8c 24 08 01 00 	mov    %r9,0x108(%rsp)
   642b0:	00 
   642b1:	4c 89 94 24 10 01 00 	mov    %r10,0x110(%rsp)
   642b8:	00 
   642b9:	4c 89 bc 24 78 01 00 	mov    %r15,0x178(%rsp)
   642c0:	00 
   642c1:	4c 89 9c 24 18 01 00 	mov    %r11,0x118(%rsp)
   642c8:	00 
   642c9:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   642cf:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   642d6:	00 
   642d7:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   642dc:	49 bc 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r12
   642e3:	07 d2 87 
   642e6:	45 31 f6             	xor    %r14d,%r14d
   642e9:	31 db                	xor    %ebx,%ebx
   642eb:	45 31 db             	xor    %r11d,%r11d
   642ee:	31 ff                	xor    %edi,%edi
   642f0:	45 31 ff             	xor    %r15d,%r15d
   642f3:	48 8b 11             	mov    (%rcx),%rdx
   642f6:	45 31 d2             	xor    %r10d,%r10d
   642f9:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   642fe:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   64304:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6430a:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   64310:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   64316:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6431c:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   64322:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   64328:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6432e:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   64334:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6433a:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   64340:	66 4d 0f 38 f6 fa    	adcx   %r10,%r15
   64346:	4c 89 f2             	mov    %r14,%rdx
   64349:	49 0f af d4          	imul   %r12,%rdx
   6434d:	45 31 d2             	xor    %r10d,%r10d
   64350:	c4 62 bb f6 0e       	mulx   (%rsi),%r8,%r9
   64355:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6435b:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   64361:	c4 62 bb f6 4e 08    	mulx   0x8(%rsi),%r8,%r9
   64367:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6436d:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   64373:	c4 62 bb f6 4e 10    	mulx   0x10(%rsi),%r8,%r9
   64379:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6437f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   64385:	c4 62 bb f6 4e 18    	mulx   0x18(%rsi),%r8,%r9
   6438b:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   64391:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   64397:	66 4d 0f 38 f6 fa    	adcx   %r10,%r15
   6439d:	48 8b 51 08          	mov    0x8(%rcx),%rdx
   643a1:	45 31 d2             	xor    %r10d,%r10d
   643a4:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   643a9:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   643af:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   643b5:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   643bb:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   643c1:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   643c7:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   643cd:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   643d3:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   643d9:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   643df:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   643e5:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   643eb:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   643f1:	48 89 da             	mov    %rbx,%rdx
   643f4:	49 0f af d4          	imul   %r12,%rdx
   643f8:	45 31 d2             	xor    %r10d,%r10d
   643fb:	c4 62 bb f6 0e       	mulx   (%rsi),%r8,%r9
   64400:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   64406:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6440c:	c4 62 bb f6 4e 08    	mulx   0x8(%rsi),%r8,%r9
   64412:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   64418:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6441e:	c4 62 bb f6 4e 10    	mulx   0x10(%rsi),%r8,%r9
   64424:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6442a:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   64430:	c4 62 bb f6 4e 18    	mulx   0x18(%rsi),%r8,%r9
   64436:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   6443c:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   64442:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   64448:	48 8b 51 10          	mov    0x10(%rcx),%rdx
   6444c:	45 31 d2             	xor    %r10d,%r10d
   6444f:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   64454:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6445a:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   64460:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   64466:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6446c:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   64472:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   64478:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   6447e:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   64484:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   6448a:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   64490:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   64496:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   6449c:	4c 89 da             	mov    %r11,%rdx
   6449f:	49 0f af d4          	imul   %r12,%rdx
   644a3:	45 31 d2             	xor    %r10d,%r10d
   644a6:	c4 62 bb f6 0e       	mulx   (%rsi),%r8,%r9
   644ab:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   644b1:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   644b7:	c4 62 bb f6 4e 08    	mulx   0x8(%rsi),%r8,%r9
   644bd:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   644c3:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   644c9:	c4 62 bb f6 4e 10    	mulx   0x10(%rsi),%r8,%r9
   644cf:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   644d5:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   644db:	c4 62 bb f6 4e 18    	mulx   0x18(%rsi),%r8,%r9
   644e1:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   644e7:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   644ed:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   644f3:	48 8b 51 18          	mov    0x18(%rcx),%rdx
   644f7:	45 31 d2             	xor    %r10d,%r10d
   644fa:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   644ff:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   64505:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   6450b:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   64511:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   64517:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   6451d:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   64523:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   64529:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6452f:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   64535:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6453b:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   64541:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   64547:	48 89 fa             	mov    %rdi,%rdx
   6454a:	49 0f af d4          	imul   %r12,%rdx
   6454e:	45 31 d2             	xor    %r10d,%r10d
   64551:	c4 62 bb f6 0e       	mulx   (%rsi),%r8,%r9
   64556:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6455c:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   64562:	c4 62 bb f6 4e 08    	mulx   0x8(%rsi),%r8,%r9
   64568:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   6456e:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   64574:	c4 62 bb f6 4e 10    	mulx   0x10(%rsi),%r8,%r9
   6457a:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   64580:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   64586:	c4 62 bb f6 4e 18    	mulx   0x18(%rsi),%r8,%r9
   6458c:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   64592:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   64598:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   6459e:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   645a5:	8c 20 3c 
   645a8:	48 b9 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rcx
   645af:	6a 81 97 
   645b2:	4c 89 9c 24 d8 01 00 	mov    %r11,0x1d8(%rsp)
   645b9:	00 
   645ba:	4c 89 bc 24 d8 00 00 	mov    %r15,0xd8(%rsp)
   645c1:	00 
   645c2:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
   645c9:	00 
   645ca:	48 89 9c 24 c8 00 00 	mov    %rbx,0xc8(%rsp)
   645d1:	00 
   645d2:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   645d8:	49 39 c7             	cmp    %rax,%r15
   645db:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   645e2:	95 7e 68 
   645e5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   645ea:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   645f1:	00 
   645f2:	49 8d 04 06          	lea    (%r14,%rax,1),%rax
   645f6:	48 83 d8 00          	sbb    $0x0,%rax
   645fa:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   64601:	00 
   64602:	0f 92 c0             	setb   %al
   64605:	49 39 ce             	cmp    %rcx,%r14
   64608:	0f 92 c1             	setb   %cl
   6460b:	08 c1                	or     %al,%cl
   6460d:	0f b6 c1             	movzbl %cl,%eax
   64610:	48 b9 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rcx
   64617:	ba af 47 
   6461a:	48 01 d9             	add    %rbx,%rcx
   6461d:	48 29 c1             	sub    %rax,%rcx
   64620:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
   64627:	00 
   64628:	48 b9 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rcx
   6462f:	45 50 b8 
   64632:	0f 92 c0             	setb   %al
   64635:	48 39 cb             	cmp    %rcx,%rbx
   64638:	0f 92 c1             	setb   %cl
   6463b:	08 c1                	or     %al,%cl
   6463d:	0f b6 c1             	movzbl %cl,%eax
   64640:	48 b9 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rcx
   64647:	b1 9b cf 
   6464a:	4c 01 d9             	add    %r11,%rcx
   6464d:	48 29 c1             	sub    %rax,%rcx
   64650:	48 b8 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rax
   64657:	4e 64 30 
   6465a:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
   6465f:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   64664:	0f 92 84 24 c0 00 00 	setb   0xc0(%rsp)
   6466b:	00 
   6466c:	48 39 c7             	cmp    %rax,%rdi
   6466f:	0f 92 c0             	setb   %al
   64672:	0a 84 24 98 00 00 00 	or     0x98(%rsp),%al
   64679:	48 b8 b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rax
   64680:	73 df c3 
   64683:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   64687:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   6468e:	00 
   6468f:	48 0f 45 d7          	cmovne %rdi,%rdx
   64693:	48 0f 45 f1          	cmovne %rcx,%rsi
   64697:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   6469e:	00 
   6469f:	48 0f 45 44 24 28    	cmovne 0x28(%rsp),%rax
   646a5:	49 89 d3             	mov    %rdx,%r11
   646a8:	48 0f 45 0c 24       	cmovne (%rsp),%rcx
   646ad:	48 89 b4 24 00 01 00 	mov    %rsi,0x100(%rsp)
   646b4:	00 
   646b5:	48 89 f3             	mov    %rsi,%rbx
   646b8:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   646bf:	00 
   646c0:	49 89 c1             	mov    %rax,%r9
   646c3:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
   646ca:	00 
   646cb:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
   646d2:	00 
   646d3:	48 89 94 24 18 01 00 	mov    %rdx,0x118(%rsp)
   646da:	00 
   646db:	49 89 ca             	mov    %rcx,%r10
   646de:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   646e3:	48 03 18             	add    (%rax),%rbx
   646e6:	4c 13 48 08          	adc    0x8(%rax),%r9
   646ea:	4c 13 50 10          	adc    0x10(%rax),%r10
   646ee:	4c 13 58 18          	adc    0x18(%rax),%r11
   646f2:	48 89 da             	mov    %rbx,%rdx
   646f5:	4c 89 ce             	mov    %r9,%rsi
   646f8:	4c 89 d7             	mov    %r10,%rdi
   646fb:	4d 89 d8             	mov    %r11,%r8
   646fe:	48 2b 11             	sub    (%rcx),%rdx
   64701:	48 1b 71 08          	sbb    0x8(%rcx),%rsi
   64705:	48 1b 79 10          	sbb    0x10(%rcx),%rdi
   64709:	4c 1b 41 18          	sbb    0x18(%rcx),%r8
   6470d:	48 0f 43 da          	cmovae %rdx,%rbx
   64711:	4c 0f 43 ce          	cmovae %rsi,%r9
   64715:	4c 0f 43 d7          	cmovae %rdi,%r10
   64719:	4d 0f 43 d8          	cmovae %r8,%r11
   6471d:	4c 89 8c 24 e8 00 00 	mov    %r9,0xe8(%rsp)
   64724:	00 
   64725:	4c 89 9c 24 b8 00 00 	mov    %r11,0xb8(%rsp)
   6472c:	00 
   6472d:	48 89 9c 24 20 02 00 	mov    %rbx,0x220(%rsp)
   64734:	00 
   64735:	4c 89 94 24 f8 00 00 	mov    %r10,0xf8(%rsp)
   6473c:	00 
   6473d:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   64743:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   64748:	49 ba 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r10
   6474f:	07 d2 87 
   64752:	4c 8d 84 24 e0 01 00 	lea    0x1e0(%rsp),%r8
   64759:	00 
   6475a:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
   64761:	00 
   64762:	c5 fc 10 8c 24 30 03 	vmovups 0x330(%rsp),%ymm1
   64769:	00 00 
   6476b:	48 8b 84 24 10 03 00 	mov    0x310(%rsp),%rax
   64772:	00 
   64773:	4c 8b 8c 24 20 03 00 	mov    0x320(%rsp),%r9
   6477a:	00 
   6477b:	4c 8b 9c 24 28 03 00 	mov    0x328(%rsp),%r11
   64782:	00 
   64783:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   6478a:	00 
   6478b:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
   64792:	00 
   64793:	48 8b 84 24 18 03 00 	mov    0x318(%rsp),%rax
   6479a:	00 
   6479b:	c5 fc 11 8c 24 00 01 	vmovups %ymm1,0x100(%rsp)
   647a2:	00 00 
   647a4:	c5 fc 10 8c 24 30 03 	vmovups 0x330(%rsp),%ymm1
   647ab:	00 00 
   647ad:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
   647b4:	00 
   647b5:	4c 89 8c 24 f0 01 00 	mov    %r9,0x1f0(%rsp)
   647bc:	00 
   647bd:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
   647c4:	00 
   647c5:	4c 89 9c 24 f8 01 00 	mov    %r11,0x1f8(%rsp)
   647cc:	00 
   647cd:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   647d4:	00 00 
   647d6:	31 c0                	xor    %eax,%eax
   647d8:	31 c9                	xor    %ecx,%ecx
   647da:	45 31 ed             	xor    %r13d,%r13d
   647dd:	45 31 f6             	xor    %r14d,%r14d
   647e0:	45 31 e4             	xor    %r12d,%r12d
   647e3:	48 8b 16             	mov    (%rsi),%rdx
   647e6:	31 ff                	xor    %edi,%edi
   647e8:	c4 42 d3 f6 38       	mulx   (%r8),%rbp,%r15
   647ed:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   647f3:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   647f9:	c4 42 d3 f6 78 08    	mulx   0x8(%r8),%rbp,%r15
   647ff:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   64805:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   6480b:	c4 42 d3 f6 78 10    	mulx   0x10(%r8),%rbp,%r15
   64811:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   64817:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   6481d:	c4 42 d3 f6 78 18    	mulx   0x18(%r8),%rbp,%r15
   64823:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64829:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   6482f:	66 4c 0f 38 f6 e7    	adcx   %rdi,%r12
   64835:	48 89 c2             	mov    %rax,%rdx
   64838:	49 0f af d2          	imul   %r10,%rdx
   6483c:	31 ff                	xor    %edi,%edi
   6483e:	c4 62 d3 f6 3b       	mulx   (%rbx),%rbp,%r15
   64843:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64849:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   6484f:	c4 62 d3 f6 7b 08    	mulx   0x8(%rbx),%rbp,%r15
   64855:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   6485b:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   64861:	c4 62 d3 f6 7b 10    	mulx   0x10(%rbx),%rbp,%r15
   64867:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6486d:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   64873:	c4 62 d3 f6 7b 18    	mulx   0x18(%rbx),%rbp,%r15
   64879:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   6487f:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   64885:	66 4c 0f 38 f6 e7    	adcx   %rdi,%r12
   6488b:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   6488f:	31 ff                	xor    %edi,%edi
   64891:	c4 42 d3 f6 38       	mulx   (%r8),%rbp,%r15
   64896:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   6489c:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   648a2:	c4 42 d3 f6 78 08    	mulx   0x8(%r8),%rbp,%r15
   648a8:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   648ae:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   648b4:	c4 42 d3 f6 78 10    	mulx   0x10(%r8),%rbp,%r15
   648ba:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   648c0:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   648c6:	c4 42 d3 f6 78 18    	mulx   0x18(%r8),%rbp,%r15
   648cc:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   648d2:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   648d8:	66 48 0f 38 f6 c7    	adcx   %rdi,%rax
   648de:	48 89 ca             	mov    %rcx,%rdx
   648e1:	49 0f af d2          	imul   %r10,%rdx
   648e5:	31 ff                	xor    %edi,%edi
   648e7:	c4 62 d3 f6 3b       	mulx   (%rbx),%rbp,%r15
   648ec:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   648f2:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   648f8:	c4 62 d3 f6 7b 08    	mulx   0x8(%rbx),%rbp,%r15
   648fe:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   64904:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   6490a:	c4 62 d3 f6 7b 10    	mulx   0x10(%rbx),%rbp,%r15
   64910:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64916:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   6491c:	c4 62 d3 f6 7b 18    	mulx   0x18(%rbx),%rbp,%r15
   64922:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64928:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   6492e:	66 48 0f 38 f6 c7    	adcx   %rdi,%rax
   64934:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   64938:	31 ff                	xor    %edi,%edi
   6493a:	c4 42 d3 f6 38       	mulx   (%r8),%rbp,%r15
   6493f:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   64945:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   6494b:	c4 42 d3 f6 78 08    	mulx   0x8(%r8),%rbp,%r15
   64951:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64957:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   6495d:	c4 42 d3 f6 78 10    	mulx   0x10(%r8),%rbp,%r15
   64963:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64969:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   6496f:	c4 42 d3 f6 78 18    	mulx   0x18(%r8),%rbp,%r15
   64975:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   6497b:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   64981:	66 48 0f 38 f6 cf    	adcx   %rdi,%rcx
   64987:	4c 89 ea             	mov    %r13,%rdx
   6498a:	49 0f af d2          	imul   %r10,%rdx
   6498e:	31 ff                	xor    %edi,%edi
   64990:	c4 62 d3 f6 3b       	mulx   (%rbx),%rbp,%r15
   64995:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6499b:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   649a1:	c4 62 d3 f6 7b 08    	mulx   0x8(%rbx),%rbp,%r15
   649a7:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   649ad:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   649b3:	c4 62 d3 f6 7b 10    	mulx   0x10(%rbx),%rbp,%r15
   649b9:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   649bf:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   649c5:	c4 62 d3 f6 7b 18    	mulx   0x18(%rbx),%rbp,%r15
   649cb:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   649d1:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   649d7:	66 48 0f 38 f6 cf    	adcx   %rdi,%rcx
   649dd:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   649e1:	31 ff                	xor    %edi,%edi
   649e3:	c4 42 d3 f6 38       	mulx   (%r8),%rbp,%r15
   649e8:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   649ee:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   649f4:	c4 42 d3 f6 78 08    	mulx   0x8(%r8),%rbp,%r15
   649fa:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64a00:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   64a06:	c4 42 d3 f6 78 10    	mulx   0x10(%r8),%rbp,%r15
   64a0c:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64a12:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   64a18:	c4 42 d3 f6 78 18    	mulx   0x18(%r8),%rbp,%r15
   64a1e:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   64a24:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   64a2a:	66 4c 0f 38 f6 ef    	adcx   %rdi,%r13
   64a30:	4c 89 f2             	mov    %r14,%rdx
   64a33:	49 0f af d2          	imul   %r10,%rdx
   64a37:	31 ff                	xor    %edi,%edi
   64a39:	c4 62 d3 f6 3b       	mulx   (%rbx),%rbp,%r15
   64a3e:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64a44:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   64a4a:	c4 62 d3 f6 7b 08    	mulx   0x8(%rbx),%rbp,%r15
   64a50:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64a56:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   64a5c:	c4 62 d3 f6 7b 10    	mulx   0x10(%rbx),%rbp,%r15
   64a62:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64a68:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   64a6e:	c4 62 d3 f6 7b 18    	mulx   0x18(%rbx),%rbp,%r15
   64a74:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   64a7a:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   64a80:	66 4c 0f 38 f6 ef    	adcx   %rdi,%r13
   64a86:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   64a8d:	8c 20 3c 
   64a90:	48 89 c7             	mov    %rax,%rdi
   64a93:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   64a9a:	00 
   64a9b:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   64aa2:	95 7e 68 
   64aa5:	48 89 0c 24          	mov    %rcx,(%rsp)
   64aa9:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
   64ab0:	00 
   64ab1:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   64ab6:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   64abc:	4d 89 d8             	mov    %r11,%r8
   64abf:	4d 89 ce             	mov    %r9,%r14
   64ac2:	49 39 d4             	cmp    %rdx,%r12
   64ac5:	48 8d 04 07          	lea    (%rdi,%rax,1),%rax
   64ac9:	c5 fc 10 8c 24 30 03 	vmovups 0x330(%rsp),%ymm1
   64ad0:	00 00 
   64ad2:	48 8b 8c 24 d0 01 00 	mov    0x1d0(%rsp),%rcx
   64ad9:	00 
   64ada:	48 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%rsi
   64ae1:	00 
   64ae2:	4c 8d 64 24 30       	lea    0x30(%rsp),%r12
   64ae7:	48 83 d8 00          	sbb    $0x0,%rax
   64aeb:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   64af0:	48 b8 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rax
   64af7:	6a 81 97 
   64afa:	0f 92 c2             	setb   %dl
   64afd:	48 39 c7             	cmp    %rax,%rdi
   64b00:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   64b07:	ba af 47 
   64b0a:	40 0f 92 c7          	setb   %dil
   64b0e:	40 08 d7             	or     %dl,%dil
   64b11:	48 89 cb             	mov    %rcx,%rbx
   64b14:	49 89 f7             	mov    %rsi,%r15
   64b17:	40 0f b6 d7          	movzbl %dil,%edx
   64b1b:	48 8b 3c 24          	mov    (%rsp),%rdi
   64b1f:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   64b26:	00 00 
   64b28:	48 01 f8             	add    %rdi,%rax
   64b2b:	48 29 d0             	sub    %rdx,%rax
   64b2e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   64b33:	48 b8 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rax
   64b3a:	45 50 b8 
   64b3d:	0f 92 c2             	setb   %dl
   64b40:	48 39 c7             	cmp    %rax,%rdi
   64b43:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   64b4a:	b1 9b cf 
   64b4d:	40 0f 92 c7          	setb   %dil
   64b51:	40 08 d7             	or     %dl,%dil
   64b54:	40 0f b6 d7          	movzbl %dil,%edx
   64b58:	49 8d 7c 05 00       	lea    0x0(%r13,%rax,1),%rdi
   64b5d:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   64b64:	00 
   64b65:	48 29 d7             	sub    %rdx,%rdi
   64b68:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
   64b6f:	00 
   64b70:	0f 92 84 24 f0 00 00 	setb   0xf0(%rsp)
   64b77:	00 
   64b78:	48 03 18             	add    (%rax),%rbx
   64b7b:	4c 13 78 08          	adc    0x8(%rax),%r15
   64b7f:	4c 13 70 10          	adc    0x10(%rax),%r14
   64b83:	4c 13 40 18          	adc    0x18(%rax),%r8
   64b87:	48 89 dd             	mov    %rbx,%rbp
   64b8a:	4d 89 fa             	mov    %r15,%r10
   64b8d:	4c 89 f2             	mov    %r14,%rdx
   64b90:	4c 89 c7             	mov    %r8,%rdi
   64b93:	49 2b 2c 24          	sub    (%r12),%rbp
   64b97:	4d 1b 54 24 08       	sbb    0x8(%r12),%r10
   64b9c:	49 1b 54 24 10       	sbb    0x10(%r12),%rdx
   64ba1:	49 1b 7c 24 18       	sbb    0x18(%r12),%rdi
   64ba6:	48 0f 43 dd          	cmovae %rbp,%rbx
   64baa:	4d 0f 43 fa          	cmovae %r10,%r15
   64bae:	4c 0f 43 f2          	cmovae %rdx,%r14
   64bb2:	4c 0f 43 c7          	cmovae %rdi,%r8
   64bb6:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   64bbc:	48 8d 94 24 00 01 00 	lea    0x100(%rsp),%rdx
   64bc3:	00 
   64bc4:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   64bc9:	48 2b 0a             	sub    (%rdx),%rcx
   64bcc:	48 1b 72 08          	sbb    0x8(%rdx),%rsi
   64bd0:	4c 1b 4a 10          	sbb    0x10(%rdx),%r9
   64bd4:	4c 1b 5a 18          	sbb    0x18(%rdx),%r11
   64bd8:	4d 19 ed             	sbb    %r13,%r13
   64bdb:	4c 8b 17             	mov    (%rdi),%r10
   64bde:	48 8b 6f 08          	mov    0x8(%rdi),%rbp
   64be2:	48 8b 47 10          	mov    0x10(%rdi),%rax
   64be6:	4c 8b 67 18          	mov    0x18(%rdi),%r12
   64bea:	4d 21 ea             	and    %r13,%r10
   64bed:	4c 21 ed             	and    %r13,%rbp
   64bf0:	4c 21 e8             	and    %r13,%rax
   64bf3:	4d 21 ec             	and    %r13,%r12
   64bf6:	4c 01 d1             	add    %r10,%rcx
   64bf9:	48 11 ee             	adc    %rbp,%rsi
   64bfc:	49 11 c1             	adc    %rax,%r9
   64bff:	4d 11 e3             	adc    %r12,%r11
   64c02:	48 89 9c 24 60 01 00 	mov    %rbx,0x160(%rsp)
   64c09:	00 
   64c0a:	4c 89 bc 24 68 01 00 	mov    %r15,0x168(%rsp)
   64c11:	00 
   64c12:	4c 89 b4 24 70 01 00 	mov    %r14,0x170(%rsp)
   64c19:	00 
   64c1a:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
   64c21:	00 
   64c22:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
   64c29:	00 
   64c2a:	4c 89 8c 24 10 01 00 	mov    %r9,0x110(%rsp)
   64c31:	00 
   64c32:	4c 89 84 24 78 01 00 	mov    %r8,0x178(%rsp)
   64c39:	00 
   64c3a:	4c 89 9c 24 18 01 00 	mov    %r11,0x118(%rsp)
   64c41:	00 
   64c42:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   64c48:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   64c4f:	00 
   64c50:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
   64c57:	00 
   64c58:	4c 8d 54 24 30       	lea    0x30(%rsp),%r10
   64c5d:	49 bf 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r15
   64c64:	07 d2 87 
   64c67:	45 31 c0             	xor    %r8d,%r8d
   64c6a:	31 f6                	xor    %esi,%esi
   64c6c:	31 c9                	xor    %ecx,%ecx
   64c6e:	45 31 db             	xor    %r11d,%r11d
   64c71:	45 31 c9             	xor    %r9d,%r9d
   64c74:	48 8b 17             	mov    (%rdi),%rdx
   64c77:	45 31 f6             	xor    %r14d,%r14d
   64c7a:	c4 e2 e3 f6 28       	mulx   (%rax),%rbx,%rbp
   64c7f:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   64c85:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   64c8b:	c4 e2 e3 f6 68 08    	mulx   0x8(%rax),%rbx,%rbp
   64c91:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64c97:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64c9d:	c4 e2 e3 f6 68 10    	mulx   0x10(%rax),%rbx,%rbp
   64ca3:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64ca9:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64caf:	c4 e2 e3 f6 68 18    	mulx   0x18(%rax),%rbx,%rbp
   64cb5:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64cbb:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64cc1:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   64cc7:	4c 89 c2             	mov    %r8,%rdx
   64cca:	49 0f af d7          	imul   %r15,%rdx
   64cce:	45 31 f6             	xor    %r14d,%r14d
   64cd1:	c4 c2 e3 f6 2a       	mulx   (%r10),%rbx,%rbp
   64cd6:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   64cdc:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   64ce2:	c4 c2 e3 f6 6a 08    	mulx   0x8(%r10),%rbx,%rbp
   64ce8:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64cee:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64cf4:	c4 c2 e3 f6 6a 10    	mulx   0x10(%r10),%rbx,%rbp
   64cfa:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64d00:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64d06:	c4 c2 e3 f6 6a 18    	mulx   0x18(%r10),%rbx,%rbp
   64d0c:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64d12:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64d18:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   64d1e:	48 8b 57 08          	mov    0x8(%rdi),%rdx
   64d22:	45 31 f6             	xor    %r14d,%r14d
   64d25:	c4 e2 e3 f6 28       	mulx   (%rax),%rbx,%rbp
   64d2a:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64d30:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64d36:	c4 e2 e3 f6 68 08    	mulx   0x8(%rax),%rbx,%rbp
   64d3c:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64d42:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64d48:	c4 e2 e3 f6 68 10    	mulx   0x10(%rax),%rbx,%rbp
   64d4e:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64d54:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64d5a:	c4 e2 e3 f6 68 18    	mulx   0x18(%rax),%rbx,%rbp
   64d60:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   64d66:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   64d6c:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   64d72:	48 89 f2             	mov    %rsi,%rdx
   64d75:	49 0f af d7          	imul   %r15,%rdx
   64d79:	45 31 f6             	xor    %r14d,%r14d
   64d7c:	c4 c2 e3 f6 2a       	mulx   (%r10),%rbx,%rbp
   64d81:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64d87:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64d8d:	c4 c2 e3 f6 6a 08    	mulx   0x8(%r10),%rbx,%rbp
   64d93:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64d99:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64d9f:	c4 c2 e3 f6 6a 10    	mulx   0x10(%r10),%rbx,%rbp
   64da5:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64dab:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64db1:	c4 c2 e3 f6 6a 18    	mulx   0x18(%r10),%rbx,%rbp
   64db7:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   64dbd:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   64dc3:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   64dc9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
   64dcd:	45 31 f6             	xor    %r14d,%r14d
   64dd0:	c4 e2 e3 f6 28       	mulx   (%rax),%rbx,%rbp
   64dd5:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64ddb:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64de1:	c4 e2 e3 f6 68 08    	mulx   0x8(%rax),%rbx,%rbp
   64de7:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64ded:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64df3:	c4 e2 e3 f6 68 10    	mulx   0x10(%rax),%rbx,%rbp
   64df9:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   64dff:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   64e05:	c4 e2 e3 f6 68 18    	mulx   0x18(%rax),%rbx,%rbp
   64e0b:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   64e11:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   64e17:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   64e1d:	48 89 ca             	mov    %rcx,%rdx
   64e20:	49 0f af d7          	imul   %r15,%rdx
   64e24:	45 31 f6             	xor    %r14d,%r14d
   64e27:	c4 c2 e3 f6 2a       	mulx   (%r10),%rbx,%rbp
   64e2c:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64e32:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64e38:	c4 c2 e3 f6 6a 08    	mulx   0x8(%r10),%rbx,%rbp
   64e3e:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64e44:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64e4a:	c4 c2 e3 f6 6a 10    	mulx   0x10(%r10),%rbx,%rbp
   64e50:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   64e56:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   64e5c:	c4 c2 e3 f6 6a 18    	mulx   0x18(%r10),%rbx,%rbp
   64e62:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   64e68:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   64e6e:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   64e74:	48 8b 57 18          	mov    0x18(%rdi),%rdx
   64e78:	45 31 f6             	xor    %r14d,%r14d
   64e7b:	c4 e2 e3 f6 28       	mulx   (%rax),%rbx,%rbp
   64e80:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64e86:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64e8c:	c4 e2 e3 f6 68 08    	mulx   0x8(%rax),%rbx,%rbp
   64e92:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   64e98:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   64e9e:	c4 e2 e3 f6 68 10    	mulx   0x10(%rax),%rbx,%rbp
   64ea4:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   64eaa:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   64eb0:	c4 e2 e3 f6 68 18    	mulx   0x18(%rax),%rbx,%rbp
   64eb6:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64ebc:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64ec2:	66 49 0f 38 f6 ce    	adcx   %r14,%rcx
   64ec8:	4c 89 da             	mov    %r11,%rdx
   64ecb:	49 0f af d7          	imul   %r15,%rdx
   64ecf:	45 31 f6             	xor    %r14d,%r14d
   64ed2:	c4 c2 e3 f6 2a       	mulx   (%r10),%rbx,%rbp
   64ed7:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64edd:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64ee3:	c4 c2 e3 f6 6a 08    	mulx   0x8(%r10),%rbx,%rbp
   64ee9:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   64eef:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   64ef5:	c4 c2 e3 f6 6a 10    	mulx   0x10(%r10),%rbx,%rbp
   64efb:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   64f01:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   64f07:	c4 c2 e3 f6 6a 18    	mulx   0x18(%r10),%rbx,%rbp
   64f0d:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64f13:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64f19:	66 49 0f 38 f6 ce    	adcx   %r14,%rcx
   64f1f:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   64f26:	8c 20 3c 
   64f29:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   64f30:	6a 81 97 
   64f33:	48 bf 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rdi
   64f3a:	4e 64 30 
   64f3d:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   64f43:	49 39 c1             	cmp    %rax,%r9
   64f46:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   64f4d:	95 7e 68 
   64f50:	4c 8b a4 24 e0 00 00 	mov    0xe0(%rsp),%r12
   64f57:	00 
   64f58:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   64f5d:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
   64f64:	00 
   64f65:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
   64f6a:	49 8d 04 00          	lea    (%r8,%rax,1),%rax
   64f6e:	48 83 d8 00          	sbb    $0x0,%rax
   64f72:	49 89 c6             	mov    %rax,%r14
   64f75:	0f 92 c0             	setb   %al
   64f78:	49 39 d0             	cmp    %rdx,%r8
   64f7b:	0f 92 c2             	setb   %dl
   64f7e:	08 c2                	or     %al,%dl
   64f80:	0f b6 c2             	movzbl %dl,%eax
   64f83:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   64f8a:	ba af 47 
   64f8d:	48 01 f2             	add    %rsi,%rdx
   64f90:	48 29 c2             	sub    %rax,%rdx
   64f93:	49 89 d7             	mov    %rdx,%r15
   64f96:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   64f9d:	45 50 b8 
   64fa0:	0f 92 c0             	setb   %al
   64fa3:	48 39 d6             	cmp    %rdx,%rsi
   64fa6:	0f 92 c2             	setb   %dl
   64fa9:	08 c2                	or     %al,%dl
   64fab:	0f b6 c2             	movzbl %dl,%eax
   64fae:	48 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdx
   64fb5:	b1 9b cf 
   64fb8:	48 01 ca             	add    %rcx,%rdx
   64fbb:	48 29 c2             	sub    %rax,%rdx
   64fbe:	0f 92 c0             	setb   %al
   64fc1:	48 39 f9             	cmp    %rdi,%rcx
   64fc4:	49 89 d5             	mov    %rdx,%r13
   64fc7:	0f 92 c2             	setb   %dl
   64fca:	08 c2                	or     %al,%dl
   64fcc:	49 39 fc             	cmp    %rdi,%r12
   64fcf:	48 bf b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rdi
   64fd6:	73 df c3 
   64fd9:	0f 92 c0             	setb   %al
   64fdc:	0a 84 24 f0 00 00 00 	or     0xf0(%rsp),%al
   64fe3:	49 8d 04 3a          	lea    (%r10,%rdi,1),%rax
   64fe7:	49 0f 45 c2          	cmovne %r10,%rax
   64feb:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
   64ff0:	4c 0f 45 1c 24       	cmovne (%rsp),%r11
   64ff5:	49 0f 45 dc          	cmovne %r12,%rbx
   64ff9:	4c 8d a4 24 60 01 00 	lea    0x160(%rsp),%r12
   65000:	00 
   65001:	4c 0f 45 94 24 a0 00 	cmovne 0xa0(%rsp),%r10
   65008:	00 00 
   6500a:	84 d2                	test   %dl,%dl
   6500c:	49 8d 14 39          	lea    (%r9,%rdi,1),%rdx
   65010:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   65017:	00 
   65018:	49 0f 45 d1          	cmovne %r9,%rdx
   6501c:	4c 0f 45 e9          	cmovne %rcx,%r13
   65020:	4d 0f 45 f0          	cmovne %r8,%r14
   65024:	4c 0f 45 fe          	cmovne %rsi,%r15
   65028:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
   6502f:	00 
   65030:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   65035:	4c 89 34 24          	mov    %r14,(%rsp)
   65039:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   6503e:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
   65045:	00 
   65046:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
   6504d:	00 
   6504e:	49 89 df             	mov    %rbx,%r15
   65051:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   65056:	4d 89 de             	mov    %r11,%r14
   65059:	4c 89 94 24 08 01 00 	mov    %r10,0x108(%rsp)
   65060:	00 
   65061:	4c 89 9c 24 10 01 00 	mov    %r11,0x110(%rsp)
   65068:	00 
   65069:	48 89 9c 24 18 01 00 	mov    %rbx,0x118(%rsp)
   65070:	00 
   65071:	49 03 01             	add    (%r9),%rax
   65074:	4d 13 51 08          	adc    0x8(%r9),%r10
   65078:	4d 13 71 10          	adc    0x10(%r9),%r14
   6507c:	4d 13 79 18          	adc    0x18(%r9),%r15
   65080:	48 89 c2             	mov    %rax,%rdx
   65083:	4c 89 d6             	mov    %r10,%rsi
   65086:	4c 89 f7             	mov    %r14,%rdi
   65089:	4d 89 f8             	mov    %r15,%r8
   6508c:	48 2b 11             	sub    (%rcx),%rdx
   6508f:	48 1b 71 08          	sbb    0x8(%rcx),%rsi
   65093:	48 1b 79 10          	sbb    0x10(%rcx),%rdi
   65097:	4c 1b 41 18          	sbb    0x18(%rcx),%r8
   6509b:	48 0f 43 c2          	cmovae %rdx,%rax
   6509f:	4c 0f 43 d6          	cmovae %rsi,%r10
   650a3:	4c 0f 43 f7          	cmovae %rdi,%r14
   650a7:	4d 0f 43 f8          	cmovae %r8,%r15
   650ab:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
   650b0:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
   650b5:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   650bb:	4c 89 d1             	mov    %r10,%rcx
   650be:	31 d2                	xor    %edx,%edx
   650c0:	31 f6                	xor    %esi,%esi
   650c2:	31 ff                	xor    %edi,%edi
   650c4:	45 31 c0             	xor    %r8d,%r8d
   650c7:	c5 fc 10 8c 24 70 03 	vmovups 0x370(%rsp),%ymm1
   650ce:	00 00 
   650d0:	c5 fc 11 8c 24 20 01 	vmovups %ymm1,0x120(%rsp)
   650d7:	00 00 
   650d9:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   650e0:	00 00 
   650e2:	49 2b 14 24          	sub    (%r12),%rdx
   650e6:	49 1b 74 24 08       	sbb    0x8(%r12),%rsi
   650eb:	49 1b 7c 24 10       	sbb    0x10(%r12),%rdi
   650f0:	4d 1b 44 24 18       	sbb    0x18(%r12),%r8
   650f5:	48 19 ed             	sbb    %rbp,%rbp
   650f8:	4d 8b 4d 00          	mov    0x0(%r13),%r9
   650fc:	4d 8b 55 08          	mov    0x8(%r13),%r10
   65100:	4d 8b 5d 10          	mov    0x10(%r13),%r11
   65104:	49 8b 5d 18          	mov    0x18(%r13),%rbx
   65108:	49 21 e9             	and    %rbp,%r9
   6510b:	49 21 ea             	and    %rbp,%r10
   6510e:	49 21 eb             	and    %rbp,%r11
   65111:	48 21 eb             	and    %rbp,%rbx
   65114:	4c 01 ca             	add    %r9,%rdx
   65117:	4c 11 d6             	adc    %r10,%rsi
   6511a:	4c 11 df             	adc    %r11,%rdi
   6511d:	49 11 d8             	adc    %rbx,%r8
   65120:	49 bb 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r11
   65127:	07 d2 87 
   6512a:	c5 fc 10 8c 24 50 03 	vmovups 0x350(%rsp),%ymm1
   65131:	00 00 
   65133:	4c 8b a4 24 e0 00 00 	mov    0xe0(%rsp),%r12
   6513a:	00 
   6513b:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
   65142:	00 
   65143:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
   65148:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   6514f:	00 00 
   65151:	48 89 94 24 80 01 00 	mov    %rdx,0x180(%rsp)
   65158:	00 
   65159:	48 8b 14 24          	mov    (%rsp),%rdx
   6515d:	48 89 b4 24 88 01 00 	mov    %rsi,0x188(%rsp)
   65164:	00 
   65165:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
   6516c:	00 
   6516d:	4c 89 84 24 98 01 00 	mov    %r8,0x198(%rsp)
   65174:	00 
   65175:	c5 fe 7f 84 24 a0 01 	vmovdqu %ymm0,0x1a0(%rsp)
   6517c:	00 00 
   6517e:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
   65182:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   65187:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   6518c:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
   65191:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
   65196:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   6519b:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   651a0:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
   651a5:	4c 89 7c 24 68       	mov    %r15,0x68(%rsp)
   651aa:	4c 89 5c 24 70       	mov    %r11,0x70(%rsp)
   651af:	c5 f8 11 4c 24 78    	vmovups %xmm1,0x78(%rsp)
   651b5:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   651bc:	00 00 00 00 00 
   651c1:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   651c6:	4c 8d b4 24 60 01 00 	lea    0x160(%rsp),%r14
   651cd:	00 
   651ce:	31 ff                	xor    %edi,%edi
   651d0:	45 31 db             	xor    %r11d,%r11d
   651d3:	31 ed                	xor    %ebp,%ebp
   651d5:	31 f6                	xor    %esi,%esi
   651d7:	31 db                	xor    %ebx,%ebx
   651d9:	48 8b 11             	mov    (%rcx),%rdx
   651dc:	45 31 d2             	xor    %r10d,%r10d
   651df:	c4 42 bb f6 0e       	mulx   (%r14),%r8,%r9
   651e4:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   651ea:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   651f0:	c4 42 bb f6 4e 08    	mulx   0x8(%r14),%r8,%r9
   651f6:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   651fc:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   65202:	c4 42 bb f6 4e 10    	mulx   0x10(%r14),%r8,%r9
   65208:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   6520e:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65214:	c4 42 bb f6 4e 18    	mulx   0x18(%r14),%r8,%r9
   6521a:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65220:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65226:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   6522c:	48 8b 51 20          	mov    0x20(%rcx),%rdx
   65230:	45 31 d2             	xor    %r10d,%r10d
   65233:	c4 42 bb f6 4e 20    	mulx   0x20(%r14),%r8,%r9
   65239:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6523f:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   65245:	c4 42 bb f6 4e 28    	mulx   0x28(%r14),%r8,%r9
   6524b:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   65251:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   65257:	c4 42 bb f6 4e 30    	mulx   0x30(%r14),%r8,%r9
   6525d:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   65263:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65269:	c4 42 bb f6 4e 38    	mulx   0x38(%r14),%r8,%r9
   6526f:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65275:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6527b:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   65281:	48 89 fa             	mov    %rdi,%rdx
   65284:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   65289:	45 31 d2             	xor    %r10d,%r10d
   6528c:	c4 42 bb f6 4e 40    	mulx   0x40(%r14),%r8,%r9
   65292:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65298:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6529e:	c4 42 bb f6 4e 48    	mulx   0x48(%r14),%r8,%r9
   652a4:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   652aa:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   652b0:	c4 42 bb f6 4e 50    	mulx   0x50(%r14),%r8,%r9
   652b6:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   652bc:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   652c2:	c4 42 bb f6 4e 58    	mulx   0x58(%r14),%r8,%r9
   652c8:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   652ce:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   652d4:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   652da:	48 8b 51 08          	mov    0x8(%rcx),%rdx
   652de:	45 31 d2             	xor    %r10d,%r10d
   652e1:	c4 42 bb f6 0e       	mulx   (%r14),%r8,%r9
   652e6:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   652ec:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   652f2:	c4 42 bb f6 4e 08    	mulx   0x8(%r14),%r8,%r9
   652f8:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   652fe:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65304:	c4 42 bb f6 4e 10    	mulx   0x10(%r14),%r8,%r9
   6530a:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65310:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65316:	c4 42 bb f6 4e 18    	mulx   0x18(%r14),%r8,%r9
   6531c:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65322:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65328:	66 49 0f 38 f6 fa    	adcx   %r10,%rdi
   6532e:	48 8b 51 28          	mov    0x28(%rcx),%rdx
   65332:	45 31 d2             	xor    %r10d,%r10d
   65335:	c4 42 bb f6 4e 20    	mulx   0x20(%r14),%r8,%r9
   6533b:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   65341:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   65347:	c4 42 bb f6 4e 28    	mulx   0x28(%r14),%r8,%r9
   6534d:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   65353:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65359:	c4 42 bb f6 4e 30    	mulx   0x30(%r14),%r8,%r9
   6535f:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65365:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6536b:	c4 42 bb f6 4e 38    	mulx   0x38(%r14),%r8,%r9
   65371:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65377:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6537d:	66 49 0f 38 f6 fa    	adcx   %r10,%rdi
   65383:	4c 89 da             	mov    %r11,%rdx
   65386:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   6538b:	45 31 d2             	xor    %r10d,%r10d
   6538e:	c4 42 bb f6 4e 40    	mulx   0x40(%r14),%r8,%r9
   65394:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6539a:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   653a0:	c4 42 bb f6 4e 48    	mulx   0x48(%r14),%r8,%r9
   653a6:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   653ac:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   653b2:	c4 42 bb f6 4e 50    	mulx   0x50(%r14),%r8,%r9
   653b8:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   653be:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   653c4:	c4 42 bb f6 4e 58    	mulx   0x58(%r14),%r8,%r9
   653ca:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   653d0:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   653d6:	66 49 0f 38 f6 fa    	adcx   %r10,%rdi
   653dc:	48 8b 51 10          	mov    0x10(%rcx),%rdx
   653e0:	45 31 d2             	xor    %r10d,%r10d
   653e3:	c4 42 bb f6 0e       	mulx   (%r14),%r8,%r9
   653e8:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   653ee:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   653f4:	c4 42 bb f6 4e 08    	mulx   0x8(%r14),%r8,%r9
   653fa:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65400:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65406:	c4 42 bb f6 4e 10    	mulx   0x10(%r14),%r8,%r9
   6540c:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65412:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65418:	c4 42 bb f6 4e 18    	mulx   0x18(%r14),%r8,%r9
   6541e:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65424:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6542a:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   65430:	48 8b 51 30          	mov    0x30(%rcx),%rdx
   65434:	45 31 d2             	xor    %r10d,%r10d
   65437:	c4 42 bb f6 4e 20    	mulx   0x20(%r14),%r8,%r9
   6543d:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   65443:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65449:	c4 42 bb f6 4e 28    	mulx   0x28(%r14),%r8,%r9
   6544f:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65455:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6545b:	c4 42 bb f6 4e 30    	mulx   0x30(%r14),%r8,%r9
   65461:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65467:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6546d:	c4 42 bb f6 4e 38    	mulx   0x38(%r14),%r8,%r9
   65473:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65479:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6547f:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   65485:	48 89 ea             	mov    %rbp,%rdx
   65488:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   6548d:	45 31 d2             	xor    %r10d,%r10d
   65490:	c4 42 bb f6 4e 40    	mulx   0x40(%r14),%r8,%r9
   65496:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   6549c:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   654a2:	c4 42 bb f6 4e 48    	mulx   0x48(%r14),%r8,%r9
   654a8:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   654ae:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   654b4:	c4 42 bb f6 4e 50    	mulx   0x50(%r14),%r8,%r9
   654ba:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   654c0:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   654c6:	c4 42 bb f6 4e 58    	mulx   0x58(%r14),%r8,%r9
   654cc:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   654d2:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   654d8:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   654de:	48 8b 51 18          	mov    0x18(%rcx),%rdx
   654e2:	45 31 d2             	xor    %r10d,%r10d
   654e5:	c4 42 bb f6 0e       	mulx   (%r14),%r8,%r9
   654ea:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   654f0:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   654f6:	c4 42 bb f6 4e 08    	mulx   0x8(%r14),%r8,%r9
   654fc:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65502:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65508:	c4 42 bb f6 4e 10    	mulx   0x10(%r14),%r8,%r9
   6550e:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65514:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6551a:	c4 42 bb f6 4e 18    	mulx   0x18(%r14),%r8,%r9
   65520:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   65526:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   6552c:	66 49 0f 38 f6 ea    	adcx   %r10,%rbp
   65532:	48 8b 51 38          	mov    0x38(%rcx),%rdx
   65536:	45 31 d2             	xor    %r10d,%r10d
   65539:	c4 42 bb f6 4e 20    	mulx   0x20(%r14),%r8,%r9
   6553f:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65545:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6554b:	c4 42 bb f6 4e 28    	mulx   0x28(%r14),%r8,%r9
   65551:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65557:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6555d:	c4 42 bb f6 4e 30    	mulx   0x30(%r14),%r8,%r9
   65563:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65569:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6556f:	c4 42 bb f6 4e 38    	mulx   0x38(%r14),%r8,%r9
   65575:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6557b:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   65581:	66 49 0f 38 f6 ea    	adcx   %r10,%rbp
   65587:	48 89 f2             	mov    %rsi,%rdx
   6558a:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   6558f:	45 31 d2             	xor    %r10d,%r10d
   65592:	c4 42 bb f6 4e 40    	mulx   0x40(%r14),%r8,%r9
   65598:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   6559e:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   655a4:	c4 42 bb f6 4e 48    	mulx   0x48(%r14),%r8,%r9
   655aa:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   655b0:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   655b6:	c4 42 bb f6 4e 50    	mulx   0x50(%r14),%r8,%r9
   655bc:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   655c2:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   655c8:	c4 42 bb f6 4e 58    	mulx   0x58(%r14),%r8,%r9
   655ce:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   655d4:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   655da:	66 49 0f 38 f6 ea    	adcx   %r10,%rbp
   655e0:	48 b9 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rcx
   655e7:	8c 20 3c 
   655ea:	48 89 fa             	mov    %rdi,%rdx
   655ed:	48 89 bc 24 c8 01 00 	mov    %rdi,0x1c8(%rsp)
   655f4:	00 
   655f5:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
   655fc:	00 
   655fd:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   65602:	48 89 9c 24 d0 01 00 	mov    %rbx,0x1d0(%rsp)
   65609:	00 
   6560a:	4c 89 9c 24 48 02 00 	mov    %r11,0x248(%rsp)
   65611:	00 
   65612:	48 89 ac 24 30 02 00 	mov    %rbp,0x230(%rsp)
   65619:	00 
   6561a:	4c 89 bc 24 98 00 00 	mov    %r15,0x98(%rsp)
   65621:	00 
   65622:	48 89 ee             	mov    %rbp,%rsi
   65625:	48 39 cb             	cmp    %rcx,%rbx
   65628:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   6562f:	95 7e 68 
   65632:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   65637:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
   6563c:	c5 fc 10 94 24 50 03 	vmovups 0x350(%rsp),%ymm2
   65643:	00 00 
   65645:	48 8d 0c 0f          	lea    (%rdi,%rcx,1),%rcx
   65649:	48 bf 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdi
   65650:	6a 81 97 
   65653:	48 83 d9 00          	sbb    $0x0,%rcx
   65657:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
   6565e:	00 
   6565f:	0f 92 c1             	setb   %cl
   65662:	48 39 fa             	cmp    %rdi,%rdx
   65665:	0f 92 c2             	setb   %dl
   65668:	08 ca                	or     %cl,%dl
   6566a:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   6566f:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
   65674:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
   65679:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
   6567e:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   65683:	0f b6 ca             	movzbl %dl,%ecx
   65686:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   6568d:	ba af 47 
   65690:	4d 8d 14 13          	lea    (%r11,%rdx,1),%r10
   65694:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   6569b:	45 50 b8 
   6569e:	49 29 ca             	sub    %rcx,%r10
   656a1:	c5 fc 11 94 24 00 01 	vmovups %ymm2,0x100(%rsp)
   656a8:	00 00 
   656aa:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
   656b1:	00 00 
   656b3:	0f 92 c1             	setb   %cl
   656b6:	49 39 d3             	cmp    %rdx,%r11
   656b9:	0f 92 c2             	setb   %dl
   656bc:	08 ca                	or     %cl,%dl
   656be:	0f b6 ca             	movzbl %dl,%ecx
   656c1:	48 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdx
   656c8:	b1 9b cf 
   656cb:	4c 8d 4c 15 00       	lea    0x0(%rbp,%rdx,1),%r9
   656d0:	48 8d 6c 24 30       	lea    0x30(%rsp),%rbp
   656d5:	49 29 c9             	sub    %rcx,%r9
   656d8:	48 8b 0c 24          	mov    (%rsp),%rcx
   656dc:	0f 92 44 24 17       	setb   0x17(%rsp)
   656e1:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   656e6:	48 b9 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rcx
   656ed:	07 d2 87 
   656f0:	4c 89 44 24 60       	mov    %r8,0x60(%rsp)
   656f5:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
   656fa:	4c 8d 84 24 00 01 00 	lea    0x100(%rsp),%r8
   65701:	00 
   65702:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   65707:	c5 f8 11 4c 24 78    	vmovups %xmm1,0x78(%rsp)
   6570d:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   65714:	00 00 00 00 00 
   65719:	45 31 db             	xor    %r11d,%r11d
   6571c:	31 c0                	xor    %eax,%eax
   6571e:	31 c9                	xor    %ecx,%ecx
   65720:	45 31 ed             	xor    %r13d,%r13d
   65723:	45 31 f6             	xor    %r14d,%r14d
   65726:	48 8b 55 00          	mov    0x0(%rbp),%rdx
   6572a:	45 31 ff             	xor    %r15d,%r15d
   6572d:	c4 c2 9b f6 18       	mulx   (%r8),%r12,%rbx
   65732:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65738:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   6573e:	c4 c2 9b f6 58 08    	mulx   0x8(%r8),%r12,%rbx
   65744:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   6574a:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65750:	c4 c2 9b f6 58 10    	mulx   0x10(%r8),%r12,%rbx
   65756:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   6575c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65762:	c4 c2 9b f6 58 18    	mulx   0x18(%r8),%r12,%rbx
   65768:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   6576e:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65774:	66 4d 0f 38 f6 f7    	adcx   %r15,%r14
   6577a:	48 8b 55 20          	mov    0x20(%rbp),%rdx
   6577e:	45 31 ff             	xor    %r15d,%r15d
   65781:	c4 c2 9b f6 58 20    	mulx   0x20(%r8),%r12,%rbx
   65787:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   6578d:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65793:	c4 c2 9b f6 58 28    	mulx   0x28(%r8),%r12,%rbx
   65799:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   6579f:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   657a5:	c4 c2 9b f6 58 30    	mulx   0x30(%r8),%r12,%rbx
   657ab:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   657b1:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   657b7:	c4 c2 9b f6 58 38    	mulx   0x38(%r8),%r12,%rbx
   657bd:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   657c3:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   657c9:	66 4d 0f 38 f6 f7    	adcx   %r15,%r14
   657cf:	4c 89 da             	mov    %r11,%rdx
   657d2:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   657d7:	45 31 ff             	xor    %r15d,%r15d
   657da:	c4 c2 9b f6 58 40    	mulx   0x40(%r8),%r12,%rbx
   657e0:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   657e6:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   657ec:	c4 c2 9b f6 58 48    	mulx   0x48(%r8),%r12,%rbx
   657f2:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   657f8:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   657fe:	c4 c2 9b f6 58 50    	mulx   0x50(%r8),%r12,%rbx
   65804:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   6580a:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65810:	c4 c2 9b f6 58 58    	mulx   0x58(%r8),%r12,%rbx
   65816:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   6581c:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65822:	66 4d 0f 38 f6 f7    	adcx   %r15,%r14
   65828:	48 8b 55 08          	mov    0x8(%rbp),%rdx
   6582c:	45 31 ff             	xor    %r15d,%r15d
   6582f:	c4 c2 9b f6 18       	mulx   (%r8),%r12,%rbx
   65834:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   6583a:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65840:	c4 c2 9b f6 58 08    	mulx   0x8(%r8),%r12,%rbx
   65846:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   6584c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65852:	c4 c2 9b f6 58 10    	mulx   0x10(%r8),%r12,%rbx
   65858:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   6585e:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65864:	c4 c2 9b f6 58 18    	mulx   0x18(%r8),%r12,%rbx
   6586a:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65870:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65876:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   6587c:	48 8b 55 28          	mov    0x28(%rbp),%rdx
   65880:	45 31 ff             	xor    %r15d,%r15d
   65883:	c4 c2 9b f6 58 20    	mulx   0x20(%r8),%r12,%rbx
   65889:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   6588f:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65895:	c4 c2 9b f6 58 28    	mulx   0x28(%r8),%r12,%rbx
   6589b:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   658a1:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   658a7:	c4 c2 9b f6 58 30    	mulx   0x30(%r8),%r12,%rbx
   658ad:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   658b3:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   658b9:	c4 c2 9b f6 58 38    	mulx   0x38(%r8),%r12,%rbx
   658bf:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   658c5:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   658cb:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   658d1:	48 89 c2             	mov    %rax,%rdx
   658d4:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   658d9:	45 31 ff             	xor    %r15d,%r15d
   658dc:	c4 c2 9b f6 58 40    	mulx   0x40(%r8),%r12,%rbx
   658e2:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   658e8:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   658ee:	c4 c2 9b f6 58 48    	mulx   0x48(%r8),%r12,%rbx
   658f4:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   658fa:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65900:	c4 c2 9b f6 58 50    	mulx   0x50(%r8),%r12,%rbx
   65906:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   6590c:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65912:	c4 c2 9b f6 58 58    	mulx   0x58(%r8),%r12,%rbx
   65918:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   6591e:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65924:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   6592a:	48 8b 55 10          	mov    0x10(%rbp),%rdx
   6592e:	45 31 ff             	xor    %r15d,%r15d
   65931:	c4 c2 9b f6 18       	mulx   (%r8),%r12,%rbx
   65936:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   6593c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65942:	c4 c2 9b f6 58 08    	mulx   0x8(%r8),%r12,%rbx
   65948:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   6594e:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65954:	c4 c2 9b f6 58 10    	mulx   0x10(%r8),%r12,%rbx
   6595a:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65960:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65966:	c4 c2 9b f6 58 18    	mulx   0x18(%r8),%r12,%rbx
   6596c:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65972:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65978:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   6597e:	48 8b 55 30          	mov    0x30(%rbp),%rdx
   65982:	45 31 ff             	xor    %r15d,%r15d
   65985:	c4 c2 9b f6 58 20    	mulx   0x20(%r8),%r12,%rbx
   6598b:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   65991:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65997:	c4 c2 9b f6 58 28    	mulx   0x28(%r8),%r12,%rbx
   6599d:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   659a3:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   659a9:	c4 c2 9b f6 58 30    	mulx   0x30(%r8),%r12,%rbx
   659af:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   659b5:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   659bb:	c4 c2 9b f6 58 38    	mulx   0x38(%r8),%r12,%rbx
   659c1:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   659c7:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   659cd:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   659d3:	48 89 ca             	mov    %rcx,%rdx
   659d6:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   659db:	45 31 ff             	xor    %r15d,%r15d
   659de:	c4 c2 9b f6 58 40    	mulx   0x40(%r8),%r12,%rbx
   659e4:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   659ea:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   659f0:	c4 c2 9b f6 58 48    	mulx   0x48(%r8),%r12,%rbx
   659f6:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   659fc:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65a02:	c4 c2 9b f6 58 50    	mulx   0x50(%r8),%r12,%rbx
   65a08:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65a0e:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65a14:	c4 c2 9b f6 58 58    	mulx   0x58(%r8),%r12,%rbx
   65a1a:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65a20:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65a26:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   65a2c:	48 8b 55 18          	mov    0x18(%rbp),%rdx
   65a30:	45 31 ff             	xor    %r15d,%r15d
   65a33:	c4 c2 9b f6 18       	mulx   (%r8),%r12,%rbx
   65a38:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65a3e:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65a44:	c4 c2 9b f6 58 08    	mulx   0x8(%r8),%r12,%rbx
   65a4a:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65a50:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65a56:	c4 c2 9b f6 58 10    	mulx   0x10(%r8),%r12,%rbx
   65a5c:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65a62:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65a68:	c4 c2 9b f6 58 18    	mulx   0x18(%r8),%r12,%rbx
   65a6e:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65a74:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65a7a:	66 49 0f 38 f6 cf    	adcx   %r15,%rcx
   65a80:	48 8b 55 38          	mov    0x38(%rbp),%rdx
   65a84:	45 31 ff             	xor    %r15d,%r15d
   65a87:	c4 c2 9b f6 58 20    	mulx   0x20(%r8),%r12,%rbx
   65a8d:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65a93:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65a99:	c4 c2 9b f6 58 28    	mulx   0x28(%r8),%r12,%rbx
   65a9f:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65aa5:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65aab:	c4 c2 9b f6 58 30    	mulx   0x30(%r8),%r12,%rbx
   65ab1:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65ab7:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65abd:	c4 c2 9b f6 58 38    	mulx   0x38(%r8),%r12,%rbx
   65ac3:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65ac9:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65acf:	66 49 0f 38 f6 cf    	adcx   %r15,%rcx
   65ad5:	4c 89 ea             	mov    %r13,%rdx
   65ad8:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   65add:	45 31 ff             	xor    %r15d,%r15d
   65ae0:	c4 c2 9b f6 58 40    	mulx   0x40(%r8),%r12,%rbx
   65ae6:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65aec:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65af2:	c4 c2 9b f6 58 48    	mulx   0x48(%r8),%r12,%rbx
   65af8:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65afe:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65b04:	c4 c2 9b f6 58 50    	mulx   0x50(%r8),%r12,%rbx
   65b0a:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65b10:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65b16:	c4 c2 9b f6 58 58    	mulx   0x58(%r8),%r12,%rbx
   65b1c:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65b22:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65b28:	66 49 0f 38 f6 cf    	adcx   %r15,%rcx
   65b2e:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   65b35:	8c 20 3c 
   65b38:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
   65b3f:	00 
   65b40:	48 89 8c 24 38 02 00 	mov    %rcx,0x238(%rsp)
   65b47:	00 
   65b48:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   65b4e:	49 39 d6             	cmp    %rdx,%r14
   65b51:	48 ba 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rdx
   65b58:	95 7e 68 
   65b5b:	c5 fc 10 94 24 b0 02 	vmovups 0x2b0(%rsp),%ymm2
   65b62:	00 00 
   65b64:	49 8d 14 13          	lea    (%r11,%rdx,1),%rdx
   65b68:	48 83 da 00          	sbb    $0x0,%rdx
   65b6c:	41 0f 92 c0          	setb   %r8b
   65b70:	49 39 fb             	cmp    %rdi,%r11
   65b73:	48 bf a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdi
   65b7a:	ba af 47 
   65b7d:	0f 92 c3             	setb   %bl
   65b80:	48 8d 2c 38          	lea    (%rax,%rdi,1),%rbp
   65b84:	48 bf 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdi
   65b8b:	45 50 b8 
   65b8e:	44 08 c3             	or     %r8b,%bl
   65b91:	44 0f b6 c3          	movzbl %bl,%r8d
   65b95:	4c 29 c5             	sub    %r8,%rbp
   65b98:	41 0f 92 c0          	setb   %r8b
   65b9c:	48 39 f8             	cmp    %rdi,%rax
   65b9f:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   65ba6:	b1 9b cf 
   65ba9:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   65bae:	c5 fc 11 94 24 20 01 	vmovups %ymm2,0x120(%rsp)
   65bb5:	00 00 
   65bb7:	c5 fc 10 94 24 b0 02 	vmovups 0x2b0(%rsp),%ymm2
   65bbe:	00 00 
   65bc0:	0f 92 c3             	setb   %bl
   65bc3:	44 08 c3             	or     %r8b,%bl
   65bc6:	4c 8d 04 01          	lea    (%rcx,%rax,1),%r8
   65bca:	48 b8 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rax
   65bd1:	4e 64 30 
   65bd4:	0f b6 db             	movzbl %bl,%ebx
   65bd7:	49 29 d8             	sub    %rbx,%r8
   65bda:	0f 92 c3             	setb   %bl
   65bdd:	48 39 c1             	cmp    %rax,%rcx
   65be0:	48 8b 8c 24 d8 01 00 	mov    0x1d8(%rsp),%rcx
   65be7:	00 
   65be8:	41 0f 92 c7          	setb   %r15b
   65bec:	41 08 df             	or     %bl,%r15b
   65bef:	48 39 c6             	cmp    %rax,%rsi
   65bf2:	48 be b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rsi
   65bf9:	73 df c3 
   65bfc:	0f 92 c3             	setb   %bl
   65bff:	0a 5c 24 17          	or     0x17(%rsp),%bl
   65c03:	c5 fc 11 94 24 60 01 	vmovups %ymm2,0x160(%rsp)
   65c0a:	00 00 
   65c0c:	48 39 c1             	cmp    %rax,%rcx
   65c0f:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
   65c16:	00 
   65c17:	41 0f 92 c4          	setb   %r12b
   65c1b:	44 0a a4 24 c0 00 00 	or     0xc0(%rsp),%r12b
   65c22:	00 
   65c23:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
   65c2a:	00 
   65c2b:	48 0f 45 f9          	cmovne %rcx,%rdi
   65c2f:	4c 8d 2c 30          	lea    (%rax,%rsi,1),%r13
   65c33:	4c 0f 45 a4 24 d0 00 	cmovne 0xd0(%rsp),%r12
   65c3a:	00 00 
   65c3c:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
   65c43:	00 
   65c44:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   65c49:	48 8b bc 24 d0 01 00 	mov    0x1d0(%rsp),%rdi
   65c50:	00 
   65c51:	4c 0f 45 e8          	cmovne %rax,%r13
   65c55:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   65c5c:	00 
   65c5d:	48 0f 45 84 24 c8 00 	cmovne 0xc8(%rsp),%rax
   65c64:	00 00 
   65c66:	84 db                	test   %bl,%bl
   65c68:	48 0f 45 8c 24 c8 01 	cmovne 0x1c8(%rsp),%rcx
   65c6f:	00 00 
   65c71:	4c 0f 45 94 24 48 02 	cmovne 0x248(%rsp),%r10
   65c78:	00 00 
   65c7a:	4c 0f 45 8c 24 30 02 	cmovne 0x230(%rsp),%r9
   65c81:	00 00 
   65c83:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
   65c8a:	00 
   65c8b:	48 8d 1c 37          	lea    (%rdi,%rsi,1),%rbx
   65c8f:	48 0f 45 df          	cmovne %rdi,%rbx
   65c93:	45 84 ff             	test   %r15b,%r15b
   65c96:	49 8d 3c 36          	lea    (%r14,%rsi,1),%rdi
   65c9a:	48 0f 45 ac 24 40 02 	cmovne 0x240(%rsp),%rbp
   65ca1:	00 00 
   65ca3:	4c 0f 45 84 24 38 02 	cmovne 0x238(%rsp),%r8
   65caa:	00 00 
   65cac:	49 0f 45 fe          	cmovne %r14,%rdi
   65cb0:	49 0f 45 d3          	cmovne %r11,%rdx
   65cb4:	48 89 9c 24 50 02 00 	mov    %rbx,0x250(%rsp)
   65cbb:	00 
   65cbc:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
   65cc3:	00 
   65cc4:	4c 89 94 24 60 02 00 	mov    %r10,0x260(%rsp)
   65ccb:	00 
   65ccc:	4c 89 8c 24 68 02 00 	mov    %r9,0x268(%rsp)
   65cd3:	00 
   65cd4:	4c 8d b4 24 60 01 00 	lea    0x160(%rsp),%r14
   65cdb:	00 
   65cdc:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   65ce1:	31 f6                	xor    %esi,%esi
   65ce3:	45 31 ff             	xor    %r15d,%r15d
   65ce6:	48 89 bc 24 70 02 00 	mov    %rdi,0x270(%rsp)
   65ced:	00 
   65cee:	48 89 94 24 78 02 00 	mov    %rdx,0x278(%rsp)
   65cf5:	00 
   65cf6:	31 d2                	xor    %edx,%edx
   65cf8:	31 ff                	xor    %edi,%edi
   65cfa:	48 89 ac 24 80 02 00 	mov    %rbp,0x280(%rsp)
   65d01:	00 
   65d02:	4c 89 84 24 88 02 00 	mov    %r8,0x288(%rsp)
   65d09:	00 
   65d0a:	4d 2b 3e             	sub    (%r14),%r15
   65d0d:	49 1b 76 08          	sbb    0x8(%r14),%rsi
   65d11:	49 1b 7e 10          	sbb    0x10(%r14),%rdi
   65d15:	49 1b 56 18          	sbb    0x18(%r14),%rdx
   65d19:	48 19 db             	sbb    %rbx,%rbx
   65d1c:	4c 8b 01             	mov    (%rcx),%r8
   65d1f:	4c 8b 49 08          	mov    0x8(%rcx),%r9
   65d23:	4c 8b 51 10          	mov    0x10(%rcx),%r10
   65d27:	4c 8b 59 18          	mov    0x18(%rcx),%r11
   65d2b:	49 21 d8             	and    %rbx,%r8
   65d2e:	49 21 d9             	and    %rbx,%r9
   65d31:	49 21 da             	and    %rbx,%r10
   65d34:	49 21 db             	and    %rbx,%r11
   65d37:	4d 01 c7             	add    %r8,%r15
   65d3a:	4c 11 ce             	adc    %r9,%rsi
   65d3d:	4c 11 d7             	adc    %r10,%rdi
   65d40:	4c 11 da             	adc    %r11,%rdx
   65d43:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
   65d48:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
   65d4d:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   65d54:	00 
   65d55:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   65d5a:	c5 fc 10 94 24 90 02 	vmovups 0x290(%rsp),%ymm2
   65d61:	00 00 
   65d63:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   65d68:	48 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%rbp
   65d6f:	00 
   65d70:	4c 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%r14
   65d77:	00 
   65d78:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   65d7d:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   65d84:	00 
   65d85:	c5 fc 11 94 24 60 01 	vmovups %ymm2,0x160(%rsp)
   65d8c:	00 00 
   65d8e:	4c 89 bc 24 80 01 00 	mov    %r15,0x180(%rsp)
   65d95:	00 
   65d96:	4c 8b bc 24 20 02 00 	mov    0x220(%rsp),%r15
   65d9d:	00 
   65d9e:	48 89 b4 24 88 01 00 	mov    %rsi,0x188(%rsp)
   65da5:	00 
   65da6:	48 be 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rsi
   65dad:	07 d2 87 
   65db0:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
   65db7:	00 
   65db8:	48 89 94 24 98 01 00 	mov    %rdx,0x198(%rsp)
   65dbf:	00 
   65dc0:	c5 fe 7f 84 24 a0 01 	vmovdqu %ymm0,0x1a0(%rsp)
   65dc7:	00 00 
   65dc9:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
   65dce:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   65dd3:	48 89 6c 24 60       	mov    %rbp,0x60(%rsp)
   65dd8:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   65ddd:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
   65de2:	c5 f8 11 4c 24 78    	vmovups %xmm1,0x78(%rsp)
   65de8:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   65def:	00 00 00 00 00 
   65df4:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   65dfb:	00 
   65dfc:	45 31 d2             	xor    %r10d,%r10d
   65dff:	45 31 e4             	xor    %r12d,%r12d
   65e02:	31 db                	xor    %ebx,%ebx
   65e04:	31 f6                	xor    %esi,%esi
   65e06:	31 ff                	xor    %edi,%edi
   65e08:	48 8b 11             	mov    (%rcx),%rdx
   65e0b:	45 31 db             	xor    %r11d,%r11d
   65e0e:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   65e13:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   65e19:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   65e1f:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   65e25:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   65e2b:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65e31:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   65e37:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65e3d:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65e43:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   65e49:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65e4f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65e55:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   65e5b:	48 8b 51 20          	mov    0x20(%rcx),%rdx
   65e5f:	45 31 db             	xor    %r11d,%r11d
   65e62:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   65e68:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   65e6e:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   65e74:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   65e7a:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   65e80:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65e86:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   65e8c:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65e92:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65e98:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   65e9e:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65ea4:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65eaa:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   65eb0:	4c 89 d2             	mov    %r10,%rdx
   65eb3:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   65eb8:	45 31 db             	xor    %r11d,%r11d
   65ebb:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   65ec1:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   65ec7:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   65ecd:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   65ed3:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   65ed9:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65edf:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   65ee5:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65eeb:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65ef1:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   65ef7:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65efd:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65f03:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   65f09:	48 8b 51 08          	mov    0x8(%rcx),%rdx
   65f0d:	45 31 db             	xor    %r11d,%r11d
   65f10:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   65f15:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   65f1b:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65f21:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   65f27:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65f2d:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65f33:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   65f39:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65f3f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65f45:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   65f4b:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65f51:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   65f57:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   65f5d:	48 8b 51 28          	mov    0x28(%rcx),%rdx
   65f61:	45 31 db             	xor    %r11d,%r11d
   65f64:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   65f6a:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   65f70:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65f76:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   65f7c:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65f82:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65f88:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   65f8e:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65f94:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65f9a:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   65fa0:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65fa6:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   65fac:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   65fb2:	4c 89 e2             	mov    %r12,%rdx
   65fb5:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   65fba:	45 31 db             	xor    %r11d,%r11d
   65fbd:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   65fc3:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   65fc9:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65fcf:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   65fd5:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65fdb:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65fe1:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   65fe7:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65fed:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65ff3:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   65ff9:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65fff:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   66005:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   6600b:	48 8b 51 10          	mov    0x10(%rcx),%rdx
   6600f:	45 31 db             	xor    %r11d,%r11d
   66012:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   66017:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6601d:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   66023:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   66029:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   6602f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66035:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   6603b:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66041:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   66047:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   6604d:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   66053:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   66059:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   6605f:	48 8b 51 30          	mov    0x30(%rcx),%rdx
   66063:	45 31 db             	xor    %r11d,%r11d
   66066:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   6606c:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66072:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   66078:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   6607e:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   66084:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6608a:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   66090:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66096:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   6609c:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   660a2:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   660a8:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   660ae:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   660b4:	48 89 da             	mov    %rbx,%rdx
   660b7:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   660bc:	45 31 db             	xor    %r11d,%r11d
   660bf:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   660c5:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   660cb:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   660d1:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   660d7:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   660dd:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   660e3:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   660e9:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   660ef:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   660f5:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   660fb:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   66101:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   66107:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   6610d:	48 8b 51 18          	mov    0x18(%rcx),%rdx
   66111:	45 31 db             	xor    %r11d,%r11d
   66114:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   66119:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   6611f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66125:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   6612b:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66131:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   66137:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   6613d:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   66143:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   66149:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   6614f:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   66155:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6615b:	66 49 0f 38 f6 db    	adcx   %r11,%rbx
   66161:	48 8b 51 38          	mov    0x38(%rcx),%rdx
   66165:	45 31 db             	xor    %r11d,%r11d
   66168:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   6616e:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   66174:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6617a:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   66180:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66186:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   6618c:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   66192:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   66198:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   6619e:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   661a4:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   661aa:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   661b0:	66 49 0f 38 f6 db    	adcx   %r11,%rbx
   661b6:	48 89 f2             	mov    %rsi,%rdx
   661b9:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   661be:	45 31 db             	xor    %r11d,%r11d
   661c1:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   661c7:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   661cd:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   661d3:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   661d9:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   661df:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   661e5:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   661eb:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   661f1:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   661f7:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   661fd:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   66203:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66209:	66 49 0f 38 f6 db    	adcx   %r11,%rbx
   6620f:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   66216:	95 7e 68 
   66219:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   66220:	8c 20 3c 
   66223:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   66228:	4c 89 a4 24 c8 00 00 	mov    %r12,0xc8(%rsp)
   6622f:	00 
   66230:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
   66237:	00 
   66238:	48 89 bc 24 d8 00 00 	mov    %rdi,0xd8(%rsp)
   6623f:	00 
   66240:	4c 89 94 24 d0 00 00 	mov    %r10,0xd0(%rsp)
   66247:	00 
   66248:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
   6624f:	00 
   66250:	48 39 d7             	cmp    %rdx,%rdi
   66253:	49 8d 04 02          	lea    (%r10,%rax,1),%rax
   66257:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   6625e:	6a 81 97 
   66261:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
   66268:	00 
   66269:	4c 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%r8
   66270:	00 
   66271:	c5 fc 10 94 24 90 02 	vmovups 0x290(%rsp),%ymm2
   66278:	00 00 
   6627a:	48 83 d8 00          	sbb    $0x0,%rax
   6627e:	0f 92 c1             	setb   %cl
   66281:	49 39 d2             	cmp    %rdx,%r10
   66284:	0f 92 c2             	setb   %dl
   66287:	08 ca                	or     %cl,%dl
   66289:	0f b6 ca             	movzbl %dl,%ecx
   6628c:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   66293:	ba af 47 
   66296:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
   6629b:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
   662a2:	00 
   662a3:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
   662a8:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
   662ad:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
   662b2:	4c 89 44 24 58       	mov    %r8,0x58(%rsp)
   662b7:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   662bc:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   662c1:	4d 8d 0c 14          	lea    (%r12,%rdx,1),%r9
   662c5:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   662cc:	45 50 b8 
   662cf:	49 29 c9             	sub    %rcx,%r9
   662d2:	0f 92 c1             	setb   %cl
   662d5:	49 39 d4             	cmp    %rdx,%r12
   662d8:	c5 fc 11 94 24 00 01 	vmovups %ymm2,0x100(%rsp)
   662df:	00 00 
   662e1:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
   662e8:	00 00 
   662ea:	0f 92 c2             	setb   %dl
   662ed:	08 ca                	or     %cl,%dl
   662ef:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
   662f4:	48 be 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rsi
   662fb:	07 d2 87 
   662fe:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
   66303:	0f b6 ca             	movzbl %dl,%ecx
   66306:	48 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdx
   6630d:	b1 9b cf 
   66310:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
   66315:	c5 f8 11 4c 24 78    	vmovups %xmm1,0x78(%rsp)
   6631b:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   66322:	00 00 00 00 00 
   66327:	4c 8d 24 13          	lea    (%rbx,%rdx,1),%r12
   6632b:	49 29 cc             	sub    %rcx,%r12
   6632e:	48 8d 8c 24 00 01 00 	lea    0x100(%rsp),%rcx
   66335:	00 
   66336:	0f 92 84 24 d8 01 00 	setb   0x1d8(%rsp)
   6633d:	00 
   6633e:	45 31 c0             	xor    %r8d,%r8d
   66341:	45 31 db             	xor    %r11d,%r11d
   66344:	31 f6                	xor    %esi,%esi
   66346:	31 ed                	xor    %ebp,%ebp
   66348:	45 31 f6             	xor    %r14d,%r14d
   6634b:	49 8b 55 00          	mov    0x0(%r13),%rdx
   6634f:	31 db                	xor    %ebx,%ebx
   66351:	c4 62 c3 f6 11       	mulx   (%rcx),%rdi,%r10
   66356:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   6635c:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66362:	c4 62 c3 f6 51 08    	mulx   0x8(%rcx),%rdi,%r10
   66368:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   6636e:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66374:	c4 62 c3 f6 51 10    	mulx   0x10(%rcx),%rdi,%r10
   6637a:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   66380:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66386:	c4 62 c3 f6 51 18    	mulx   0x18(%rcx),%rdi,%r10
   6638c:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   66392:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66398:	66 4c 0f 38 f6 f3    	adcx   %rbx,%r14
   6639e:	49 8b 55 20          	mov    0x20(%r13),%rdx
   663a2:	31 db                	xor    %ebx,%ebx
   663a4:	c4 62 c3 f6 51 20    	mulx   0x20(%rcx),%rdi,%r10
   663aa:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   663b0:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   663b6:	c4 62 c3 f6 51 28    	mulx   0x28(%rcx),%rdi,%r10
   663bc:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   663c2:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   663c8:	c4 62 c3 f6 51 30    	mulx   0x30(%rcx),%rdi,%r10
   663ce:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   663d4:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   663da:	c4 62 c3 f6 51 38    	mulx   0x38(%rcx),%rdi,%r10
   663e0:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   663e6:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   663ec:	66 4c 0f 38 f6 f3    	adcx   %rbx,%r14
   663f2:	4c 89 c2             	mov    %r8,%rdx
   663f5:	49 0f af 55 40       	imul   0x40(%r13),%rdx
   663fa:	31 db                	xor    %ebx,%ebx
   663fc:	c4 62 c3 f6 51 40    	mulx   0x40(%rcx),%rdi,%r10
   66402:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   66408:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   6640e:	c4 62 c3 f6 51 48    	mulx   0x48(%rcx),%rdi,%r10
   66414:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   6641a:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66420:	c4 62 c3 f6 51 50    	mulx   0x50(%rcx),%rdi,%r10
   66426:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   6642c:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66432:	c4 62 c3 f6 51 58    	mulx   0x58(%rcx),%rdi,%r10
   66438:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   6643e:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66444:	66 4c 0f 38 f6 f3    	adcx   %rbx,%r14
   6644a:	49 8b 55 08          	mov    0x8(%r13),%rdx
   6644e:	31 db                	xor    %ebx,%ebx
   66450:	c4 62 c3 f6 11       	mulx   (%rcx),%rdi,%r10
   66455:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   6645b:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66461:	c4 62 c3 f6 51 08    	mulx   0x8(%rcx),%rdi,%r10
   66467:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   6646d:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66473:	c4 62 c3 f6 51 10    	mulx   0x10(%rcx),%rdi,%r10
   66479:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   6647f:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66485:	c4 62 c3 f6 51 18    	mulx   0x18(%rcx),%rdi,%r10
   6648b:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   66491:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66497:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   6649d:	49 8b 55 28          	mov    0x28(%r13),%rdx
   664a1:	31 db                	xor    %ebx,%ebx
   664a3:	c4 62 c3 f6 51 20    	mulx   0x20(%rcx),%rdi,%r10
   664a9:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   664af:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   664b5:	c4 62 c3 f6 51 28    	mulx   0x28(%rcx),%rdi,%r10
   664bb:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   664c1:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   664c7:	c4 62 c3 f6 51 30    	mulx   0x30(%rcx),%rdi,%r10
   664cd:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   664d3:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   664d9:	c4 62 c3 f6 51 38    	mulx   0x38(%rcx),%rdi,%r10
   664df:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   664e5:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   664eb:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   664f1:	4c 89 da             	mov    %r11,%rdx
   664f4:	49 0f af 55 40       	imul   0x40(%r13),%rdx
   664f9:	31 db                	xor    %ebx,%ebx
   664fb:	c4 62 c3 f6 51 40    	mulx   0x40(%rcx),%rdi,%r10
   66501:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   66507:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   6650d:	c4 62 c3 f6 51 48    	mulx   0x48(%rcx),%rdi,%r10
   66513:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   66519:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   6651f:	c4 62 c3 f6 51 50    	mulx   0x50(%rcx),%rdi,%r10
   66525:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   6652b:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66531:	c4 62 c3 f6 51 58    	mulx   0x58(%rcx),%rdi,%r10
   66537:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   6653d:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66543:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   66549:	49 8b 55 10          	mov    0x10(%r13),%rdx
   6654d:	31 db                	xor    %ebx,%ebx
   6654f:	c4 62 c3 f6 11       	mulx   (%rcx),%rdi,%r10
   66554:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   6655a:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66560:	c4 62 c3 f6 51 08    	mulx   0x8(%rcx),%rdi,%r10
   66566:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   6656c:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66572:	c4 62 c3 f6 51 10    	mulx   0x10(%rcx),%rdi,%r10
   66578:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   6657e:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66584:	c4 62 c3 f6 51 18    	mulx   0x18(%rcx),%rdi,%r10
   6658a:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   66590:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66596:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   6659c:	49 8b 55 30          	mov    0x30(%r13),%rdx
   665a0:	31 db                	xor    %ebx,%ebx
   665a2:	c4 62 c3 f6 51 20    	mulx   0x20(%rcx),%rdi,%r10
   665a8:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   665ae:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   665b4:	c4 62 c3 f6 51 28    	mulx   0x28(%rcx),%rdi,%r10
   665ba:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   665c0:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   665c6:	c4 62 c3 f6 51 30    	mulx   0x30(%rcx),%rdi,%r10
   665cc:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   665d2:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   665d8:	c4 62 c3 f6 51 38    	mulx   0x38(%rcx),%rdi,%r10
   665de:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   665e4:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   665ea:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   665f0:	48 89 f2             	mov    %rsi,%rdx
   665f3:	49 0f af 55 40       	imul   0x40(%r13),%rdx
   665f8:	31 db                	xor    %ebx,%ebx
   665fa:	c4 62 c3 f6 51 40    	mulx   0x40(%rcx),%rdi,%r10
   66600:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   66606:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   6660c:	c4 62 c3 f6 51 48    	mulx   0x48(%rcx),%rdi,%r10
   66612:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   66618:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   6661e:	c4 62 c3 f6 51 50    	mulx   0x50(%rcx),%rdi,%r10
   66624:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   6662a:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66630:	c4 62 c3 f6 51 58    	mulx   0x58(%rcx),%rdi,%r10
   66636:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   6663c:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66642:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   66648:	49 8b 55 18          	mov    0x18(%r13),%rdx
   6664c:	31 db                	xor    %ebx,%ebx
   6664e:	c4 62 c3 f6 11       	mulx   (%rcx),%rdi,%r10
   66653:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   66659:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   6665f:	c4 62 c3 f6 51 08    	mulx   0x8(%rcx),%rdi,%r10
   66665:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   6666b:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66671:	c4 62 c3 f6 51 10    	mulx   0x10(%rcx),%rdi,%r10
   66677:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   6667d:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66683:	c4 62 c3 f6 51 18    	mulx   0x18(%rcx),%rdi,%r10
   66689:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   6668f:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66695:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   6669b:	49 8b 55 38          	mov    0x38(%r13),%rdx
   6669f:	31 db                	xor    %ebx,%ebx
   666a1:	c4 62 c3 f6 51 20    	mulx   0x20(%rcx),%rdi,%r10
   666a7:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   666ad:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   666b3:	c4 62 c3 f6 51 28    	mulx   0x28(%rcx),%rdi,%r10
   666b9:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   666bf:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   666c5:	c4 62 c3 f6 51 30    	mulx   0x30(%rcx),%rdi,%r10
   666cb:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   666d1:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   666d7:	c4 62 c3 f6 51 38    	mulx   0x38(%rcx),%rdi,%r10
   666dd:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   666e3:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   666e9:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   666ef:	48 89 ea             	mov    %rbp,%rdx
   666f2:	49 0f af 55 40       	imul   0x40(%r13),%rdx
   666f7:	31 db                	xor    %ebx,%ebx
   666f9:	c4 62 c3 f6 51 40    	mulx   0x40(%rcx),%rdi,%r10
   666ff:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   66705:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   6670b:	c4 62 c3 f6 51 48    	mulx   0x48(%rcx),%rdi,%r10
   66711:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   66717:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   6671d:	c4 62 c3 f6 51 50    	mulx   0x50(%rcx),%rdi,%r10
   66723:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   66729:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   6672f:	c4 62 c3 f6 51 58    	mulx   0x58(%rcx),%rdi,%r10
   66735:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   6673b:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66741:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   66747:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   6674e:	95 7e 68 
   66751:	48 bf 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdi
   66758:	8c 20 3c 
   6675b:	49 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%r10
   66762:	45 50 b8 
   66765:	48 bb 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rbx
   6676c:	4e 64 30 
   6676f:	49 39 fe             	cmp    %rdi,%r14
   66772:	49 8d 0c 08          	lea    (%r8,%rcx,1),%rcx
   66776:	48 bf 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdi
   6677d:	6a 81 97 
   66780:	4c 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%r15
   66787:	00 
   66788:	48 8b ac 24 d8 00 00 	mov    0xd8(%rsp),%rbp
   6678f:	00 
   66790:	c5 fe 6f 8c 24 50 02 	vmovdqu 0x250(%rsp),%ymm1
   66797:	00 00 
   66799:	48 83 d9 00          	sbb    $0x0,%rcx
   6679d:	0f 92 c2             	setb   %dl
   667a0:	49 39 f8             	cmp    %rdi,%r8
   667a3:	40 0f 92 c7          	setb   %dil
   667a7:	40 08 d7             	or     %dl,%dil
   667aa:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   667b1:	ba af 47 
   667b4:	40 0f b6 ff          	movzbl %dil,%edi
   667b8:	4c 01 da             	add    %r11,%rdx
   667bb:	48 29 fa             	sub    %rdi,%rdx
   667be:	40 0f 92 c7          	setb   %dil
   667c2:	4d 39 d3             	cmp    %r10,%r11
   667c5:	41 0f 92 c2          	setb   %r10b
   667c9:	41 08 fa             	or     %dil,%r10b
   667cc:	41 0f b6 fa          	movzbl %r10b,%edi
   667d0:	49 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%r10
   667d7:	b1 9b cf 
   667da:	4e 8d 2c 16          	lea    (%rsi,%r10,1),%r13
   667de:	49 29 fd             	sub    %rdi,%r13
   667e1:	40 0f 92 c7          	setb   %dil
   667e5:	48 39 de             	cmp    %rbx,%rsi
   667e8:	41 0f 92 c2          	setb   %r10b
   667ec:	41 08 fa             	or     %dil,%r10b
   667ef:	49 39 df             	cmp    %rbx,%r15
   667f2:	48 bb b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rbx
   667f9:	73 df c3 
   667fc:	40 0f 92 c7          	setb   %dil
   66800:	40 0a bc 24 d8 01 00 	or     0x1d8(%rsp),%dil
   66807:	00 
   66808:	48 8d 7c 1d 00       	lea    0x0(%rbp,%rbx,1),%rdi
   6680d:	48 0f 45 84 24 d0 00 	cmovne 0xd0(%rsp),%rax
   66814:	00 00 
   66816:	4c 0f 45 8c 24 c8 00 	cmovne 0xc8(%rsp),%r9
   6681d:	00 00 
   6681f:	48 0f 45 fd          	cmovne %rbp,%rdi
   66823:	4d 0f 45 e7          	cmovne %r15,%r12
   66827:	45 84 d2             	test   %r10b,%r10b
   6682a:	4d 8d 14 1e          	lea    (%r14,%rbx,1),%r10
   6682e:	4d 0f 45 d6          	cmovne %r14,%r10
   66832:	49 0f 45 c8          	cmovne %r8,%rcx
   66836:	49 0f 45 d3          	cmovne %r11,%rdx
   6683a:	4c 0f 45 ee          	cmovne %rsi,%r13
   6683e:	48 89 bc 24 e0 01 00 	mov    %rdi,0x1e0(%rsp)
   66845:	00 
   66846:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
   6684d:	00 
   6684e:	4c 89 8c 24 f0 01 00 	mov    %r9,0x1f0(%rsp)
   66855:	00 
   66856:	4c 89 a4 24 f8 01 00 	mov    %r12,0x1f8(%rsp)
   6685d:	00 
   6685e:	4c 89 94 24 00 02 00 	mov    %r10,0x200(%rsp)
   66865:	00 
   66866:	48 89 8c 24 08 02 00 	mov    %rcx,0x208(%rsp)
   6686d:	00 
   6686e:	48 89 94 24 10 02 00 	mov    %rdx,0x210(%rsp)
   66875:	00 
   66876:	4c 89 ac 24 18 02 00 	mov    %r13,0x218(%rsp)
   6687d:	00 
   6687e:	c5 f5 ef 8c 24 e0 01 	vpxor  0x1e0(%rsp),%ymm1,%ymm1
   66885:	00 00 
   66887:	c4 e2 7d 17 c9       	vptest %ymm1,%ymm1
   6688c:	75 19                	jne    668a7 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2d37>
   6688e:	c5 fe 6f 8c 24 70 02 	vmovdqu 0x270(%rsp),%ymm1
   66895:	00 00 
   66897:	c5 f5 ef 8c 24 00 02 	vpxor  0x200(%rsp),%ymm1,%ymm1
   6689e:	00 00 
   668a0:	c4 e2 7d 17 c9       	vptest %ymm1,%ymm1
   668a5:	74 17                	je     668be <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2d4e>
   668a7:	31 c0                	xor    %eax,%eax
   668a9:	48 81 c4 18 07 00 00 	add    $0x718,%rsp
   668b0:	5b                   	pop    %rbx
   668b1:	41 5c                	pop    %r12
   668b3:	41 5d                	pop    %r13
   668b5:	41 5e                	pop    %r14
   668b7:	41 5f                	pop    %r15
   668b9:	5d                   	pop    %rbp
   668ba:	c5 f8 77             	vzeroupper
   668bd:	c3                   	ret
   668be:	c5 fc 10 8c 24 b0 03 	vmovups 0x3b0(%rsp),%ymm1
   668c5:	00 00 
   668c7:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   668cd:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   668d4:	00 
   668d5:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   668da:	31 d2                	xor    %edx,%edx
   668dc:	31 f6                	xor    %esi,%esi
   668de:	31 ff                	xor    %edi,%edi
   668e0:	45 31 c0             	xor    %r8d,%r8d
   668e3:	c5 fc 11 8c 24 20 01 	vmovups %ymm1,0x120(%rsp)
   668ea:	00 00 
   668ec:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   668f3:	00 00 
   668f5:	48 2b 10             	sub    (%rax),%rdx
   668f8:	48 1b 70 08          	sbb    0x8(%rax),%rsi
   668fc:	48 1b 78 10          	sbb    0x10(%rax),%rdi
   66900:	4c 1b 40 18          	sbb    0x18(%rax),%r8
   66904:	48 19 ed             	sbb    %rbp,%rbp
   66907:	4c 8b 09             	mov    (%rcx),%r9
   6690a:	4c 8b 51 08          	mov    0x8(%rcx),%r10
   6690e:	4c 8b 59 10          	mov    0x10(%rcx),%r11
   66912:	48 8b 59 18          	mov    0x18(%rcx),%rbx
   66916:	49 21 e9             	and    %rbp,%r9
   66919:	49 21 ea             	and    %rbp,%r10
   6691c:	49 21 eb             	and    %rbp,%r11
   6691f:	48 21 eb             	and    %rbp,%rbx
   66922:	4c 01 ca             	add    %r9,%rdx
   66925:	4c 11 d6             	adc    %r10,%rsi
   66928:	4c 11 df             	adc    %r11,%rdi
   6692b:	49 11 d8             	adc    %rbx,%r8
   6692e:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
   66935:	00 
   66936:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   6693d:	00 
   6693e:	c5 fe 6f 8c 24 90 03 	vmovdqu 0x390(%rsp),%ymm1
   66945:	00 00 
   66947:	4c 8b bc 24 28 02 00 	mov    0x228(%rsp),%r15
   6694e:	00 
   6694f:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
   66954:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   66959:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
   66960:	00 
   66961:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   66966:	48 8b 04 24          	mov    (%rsp),%rax
   6696a:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
   66971:	00 00 
   66973:	48 89 94 24 80 01 00 	mov    %rdx,0x180(%rsp)
   6697a:	00 
   6697b:	48 89 b4 24 88 01 00 	mov    %rsi,0x188(%rsp)
   66982:	00 
   66983:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
   6698a:	00 
   6698b:	4c 89 84 24 98 01 00 	mov    %r8,0x198(%rsp)
   66992:	00 
   66993:	c5 fe 7f 84 24 a0 01 	vmovdqu %ymm0,0x1a0(%rsp)
   6699a:	00 00 
   6699c:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
   669a0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   669a5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   669aa:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   669af:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   669b4:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   669bb:	00 
   669bc:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   669c1:	48 b8 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rax
   669c8:	07 d2 87 
   669cb:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
   669d0:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
   669d5:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
   669da:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
   669df:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   669e4:	c5 fa 7f 4c 24 78    	vmovdqu %xmm1,0x78(%rsp)
   669ea:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   669f1:	00 00 00 00 00 
   669f6:	45 31 db             	xor    %r11d,%r11d
   669f9:	45 31 f6             	xor    %r14d,%r14d
   669fc:	31 db                	xor    %ebx,%ebx
   669fe:	31 ff                	xor    %edi,%edi
   66a00:	31 c0                	xor    %eax,%eax
   66a02:	48 8b 16             	mov    (%rsi),%rdx
   66a05:	45 31 d2             	xor    %r10d,%r10d
   66a08:	c4 62 bb f6 09       	mulx   (%rcx),%r8,%r9
   66a0d:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66a13:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66a19:	c4 62 bb f6 49 08    	mulx   0x8(%rcx),%r8,%r9
   66a1f:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66a25:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66a2b:	c4 62 bb f6 49 10    	mulx   0x10(%rcx),%r8,%r9
   66a31:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66a37:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66a3d:	c4 62 bb f6 49 18    	mulx   0x18(%rcx),%r8,%r9
   66a43:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66a49:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66a4f:	66 49 0f 38 f6 c2    	adcx   %r10,%rax
   66a55:	48 8b 56 20          	mov    0x20(%rsi),%rdx
   66a59:	45 31 d2             	xor    %r10d,%r10d
   66a5c:	c4 62 bb f6 49 20    	mulx   0x20(%rcx),%r8,%r9
   66a62:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66a68:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66a6e:	c4 62 bb f6 49 28    	mulx   0x28(%rcx),%r8,%r9
   66a74:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66a7a:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66a80:	c4 62 bb f6 49 30    	mulx   0x30(%rcx),%r8,%r9
   66a86:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66a8c:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66a92:	c4 62 bb f6 49 38    	mulx   0x38(%rcx),%r8,%r9
   66a98:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66a9e:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66aa4:	66 49 0f 38 f6 c2    	adcx   %r10,%rax
   66aaa:	4c 89 da             	mov    %r11,%rdx
   66aad:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   66ab2:	45 31 d2             	xor    %r10d,%r10d
   66ab5:	c4 62 bb f6 49 40    	mulx   0x40(%rcx),%r8,%r9
   66abb:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66ac1:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66ac7:	c4 62 bb f6 49 48    	mulx   0x48(%rcx),%r8,%r9
   66acd:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66ad3:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66ad9:	c4 62 bb f6 49 50    	mulx   0x50(%rcx),%r8,%r9
   66adf:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66ae5:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66aeb:	c4 62 bb f6 49 58    	mulx   0x58(%rcx),%r8,%r9
   66af1:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66af7:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66afd:	66 49 0f 38 f6 c2    	adcx   %r10,%rax
   66b03:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   66b07:	45 31 d2             	xor    %r10d,%r10d
   66b0a:	c4 62 bb f6 09       	mulx   (%rcx),%r8,%r9
   66b0f:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66b15:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66b1b:	c4 62 bb f6 49 08    	mulx   0x8(%rcx),%r8,%r9
   66b21:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66b27:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66b2d:	c4 62 bb f6 49 10    	mulx   0x10(%rcx),%r8,%r9
   66b33:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66b39:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66b3f:	c4 62 bb f6 49 18    	mulx   0x18(%rcx),%r8,%r9
   66b45:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66b4b:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66b51:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   66b57:	48 8b 56 28          	mov    0x28(%rsi),%rdx
   66b5b:	45 31 d2             	xor    %r10d,%r10d
   66b5e:	c4 62 bb f6 49 20    	mulx   0x20(%rcx),%r8,%r9
   66b64:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66b6a:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66b70:	c4 62 bb f6 49 28    	mulx   0x28(%rcx),%r8,%r9
   66b76:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66b7c:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66b82:	c4 62 bb f6 49 30    	mulx   0x30(%rcx),%r8,%r9
   66b88:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66b8e:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66b94:	c4 62 bb f6 49 38    	mulx   0x38(%rcx),%r8,%r9
   66b9a:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66ba0:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66ba6:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   66bac:	4c 89 f2             	mov    %r14,%rdx
   66baf:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   66bb4:	45 31 d2             	xor    %r10d,%r10d
   66bb7:	c4 62 bb f6 49 40    	mulx   0x40(%rcx),%r8,%r9
   66bbd:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66bc3:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66bc9:	c4 62 bb f6 49 48    	mulx   0x48(%rcx),%r8,%r9
   66bcf:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66bd5:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66bdb:	c4 62 bb f6 49 50    	mulx   0x50(%rcx),%r8,%r9
   66be1:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66be7:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66bed:	c4 62 bb f6 49 58    	mulx   0x58(%rcx),%r8,%r9
   66bf3:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66bf9:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66bff:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   66c05:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   66c09:	45 31 d2             	xor    %r10d,%r10d
   66c0c:	c4 62 bb f6 09       	mulx   (%rcx),%r8,%r9
   66c11:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66c17:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66c1d:	c4 62 bb f6 49 08    	mulx   0x8(%rcx),%r8,%r9
   66c23:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66c29:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66c2f:	c4 62 bb f6 49 10    	mulx   0x10(%rcx),%r8,%r9
   66c35:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66c3b:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66c41:	c4 62 bb f6 49 18    	mulx   0x18(%rcx),%r8,%r9
   66c47:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66c4d:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66c53:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   66c59:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   66c5d:	45 31 d2             	xor    %r10d,%r10d
   66c60:	c4 62 bb f6 49 20    	mulx   0x20(%rcx),%r8,%r9
   66c66:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66c6c:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66c72:	c4 62 bb f6 49 28    	mulx   0x28(%rcx),%r8,%r9
   66c78:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66c7e:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66c84:	c4 62 bb f6 49 30    	mulx   0x30(%rcx),%r8,%r9
   66c8a:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66c90:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66c96:	c4 62 bb f6 49 38    	mulx   0x38(%rcx),%r8,%r9
   66c9c:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66ca2:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66ca8:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   66cae:	48 89 da             	mov    %rbx,%rdx
   66cb1:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   66cb6:	45 31 d2             	xor    %r10d,%r10d
   66cb9:	c4 62 bb f6 49 40    	mulx   0x40(%rcx),%r8,%r9
   66cbf:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66cc5:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66ccb:	c4 62 bb f6 49 48    	mulx   0x48(%rcx),%r8,%r9
   66cd1:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66cd7:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66cdd:	c4 62 bb f6 49 50    	mulx   0x50(%rcx),%r8,%r9
   66ce3:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66ce9:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66cef:	c4 62 bb f6 49 58    	mulx   0x58(%rcx),%r8,%r9
   66cf5:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66cfb:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66d01:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   66d07:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   66d0b:	45 31 d2             	xor    %r10d,%r10d
   66d0e:	c4 62 bb f6 09       	mulx   (%rcx),%r8,%r9
   66d13:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66d19:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66d1f:	c4 62 bb f6 49 08    	mulx   0x8(%rcx),%r8,%r9
   66d25:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66d2b:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66d31:	c4 62 bb f6 49 10    	mulx   0x10(%rcx),%r8,%r9
   66d37:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66d3d:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66d43:	c4 62 bb f6 49 18    	mulx   0x18(%rcx),%r8,%r9
   66d49:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66d4f:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66d55:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   66d5b:	48 8b 56 38          	mov    0x38(%rsi),%rdx
   66d5f:	45 31 d2             	xor    %r10d,%r10d
   66d62:	c4 62 bb f6 49 20    	mulx   0x20(%rcx),%r8,%r9
   66d68:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66d6e:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66d74:	c4 62 bb f6 49 28    	mulx   0x28(%rcx),%r8,%r9
   66d7a:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66d80:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66d86:	c4 62 bb f6 49 30    	mulx   0x30(%rcx),%r8,%r9
   66d8c:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66d92:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66d98:	c4 62 bb f6 49 38    	mulx   0x38(%rcx),%r8,%r9
   66d9e:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66da4:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66daa:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   66db0:	48 89 fa             	mov    %rdi,%rdx
   66db3:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   66db8:	45 31 d2             	xor    %r10d,%r10d
   66dbb:	c4 62 bb f6 49 40    	mulx   0x40(%rcx),%r8,%r9
   66dc1:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66dc7:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66dcd:	c4 62 bb f6 49 48    	mulx   0x48(%rcx),%r8,%r9
   66dd3:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66dd9:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66ddf:	c4 62 bb f6 49 50    	mulx   0x50(%rcx),%r8,%r9
   66de5:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66deb:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66df1:	c4 62 bb f6 49 58    	mulx   0x58(%rcx),%r8,%r9
   66df7:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66dfd:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66e03:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   66e09:	48 b9 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rcx
   66e10:	8c 20 3c 
   66e13:	49 ba 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%r10
   66e1a:	95 7e 68 
   66e1d:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   66e24:	00 
   66e25:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   66e2c:	6a 81 97 
   66e2f:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   66e34:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
   66e39:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
   66e3e:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   66e43:	48 89 9c 24 c8 01 00 	mov    %rbx,0x1c8(%rsp)
   66e4a:	00 
   66e4b:	4c 89 9c 24 d8 01 00 	mov    %r11,0x1d8(%rsp)
   66e52:	00 
   66e53:	4c 89 b4 24 d0 01 00 	mov    %r14,0x1d0(%rsp)
   66e5a:	00 
   66e5b:	48 39 c8             	cmp    %rcx,%rax
   66e5e:	4b 8d 04 13          	lea    (%r11,%r10,1),%rax
   66e62:	c5 fc 10 94 24 90 03 	vmovups 0x390(%rsp),%ymm2
   66e69:	00 00 
   66e6b:	48 83 d8 00          	sbb    $0x0,%rax
   66e6f:	0f 92 c1             	setb   %cl
   66e72:	49 39 d3             	cmp    %rdx,%r11
   66e75:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
   66e7c:	00 
   66e7d:	0f 92 c2             	setb   %dl
   66e80:	08 ca                	or     %cl,%dl
   66e82:	0f b6 ca             	movzbl %dl,%ecx
   66e85:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   66e8c:	ba af 47 
   66e8f:	49 8d 34 16          	lea    (%r14,%rdx,1),%rsi
   66e93:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   66e9a:	45 50 b8 
   66e9d:	48 29 ce             	sub    %rcx,%rsi
   66ea0:	0f 92 c1             	setb   %cl
   66ea3:	49 39 d6             	cmp    %rdx,%r14
   66ea6:	48 89 b4 24 d0 00 00 	mov    %rsi,0xd0(%rsp)
   66ead:	00 
   66eae:	c5 fc 11 94 24 00 01 	vmovups %ymm2,0x100(%rsp)
   66eb5:	00 00 
   66eb7:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
   66ebe:	00 00 
   66ec0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   66ec5:	0f 92 c2             	setb   %dl
   66ec8:	08 ca                	or     %cl,%dl
   66eca:	0f b6 ca             	movzbl %dl,%ecx
   66ecd:	48 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdx
   66ed4:	b1 9b cf 
   66ed7:	48 8d 04 13          	lea    (%rbx,%rdx,1),%rax
   66edb:	48 29 c8             	sub    %rcx,%rax
   66ede:	48 b9 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rcx
   66ee5:	07 d2 87 
   66ee8:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
   66eef:	00 
   66ef0:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   66ef7:	00 
   66ef8:	41 0f 92 c7          	setb   %r15b
   66efc:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   66f01:	48 8b 04 24          	mov    (%rsp),%rax
   66f05:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   66f0a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   66f0f:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   66f14:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   66f1b:	00 
   66f1c:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   66f21:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   66f26:	c5 fa 7f 4c 24 78    	vmovdqu %xmm1,0x78(%rsp)
   66f2c:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   66f33:	00 00 00 00 00 
   66f38:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   66f3f:	8c 20 3c 
   66f42:	48 8d 8c 24 00 01 00 	lea    0x100(%rsp),%rcx
   66f49:	00 
   66f4a:	45 31 c9             	xor    %r9d,%r9d
   66f4d:	45 31 db             	xor    %r11d,%r11d
   66f50:	45 31 c0             	xor    %r8d,%r8d
   66f53:	31 ff                	xor    %edi,%edi
   66f55:	45 31 ed             	xor    %r13d,%r13d
   66f58:	48 8b 16             	mov    (%rsi),%rdx
   66f5b:	45 31 e4             	xor    %r12d,%r12d
   66f5e:	c4 62 d3 f6 31       	mulx   (%rcx),%rbp,%r14
   66f63:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   66f69:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   66f6f:	c4 62 d3 f6 71 08    	mulx   0x8(%rcx),%rbp,%r14
   66f75:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   66f7b:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   66f81:	c4 62 d3 f6 71 10    	mulx   0x10(%rcx),%rbp,%r14
   66f87:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   66f8d:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   66f93:	c4 62 d3 f6 71 18    	mulx   0x18(%rcx),%rbp,%r14
   66f99:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   66f9f:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   66fa5:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   66fab:	48 8b 56 20          	mov    0x20(%rsi),%rdx
   66faf:	45 31 e4             	xor    %r12d,%r12d
   66fb2:	c4 62 d3 f6 71 20    	mulx   0x20(%rcx),%rbp,%r14
   66fb8:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   66fbe:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   66fc4:	c4 62 d3 f6 71 28    	mulx   0x28(%rcx),%rbp,%r14
   66fca:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   66fd0:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   66fd6:	c4 62 d3 f6 71 30    	mulx   0x30(%rcx),%rbp,%r14
   66fdc:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   66fe2:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   66fe8:	c4 62 d3 f6 71 38    	mulx   0x38(%rcx),%rbp,%r14
   66fee:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   66ff4:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   66ffa:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   67000:	4c 89 ca             	mov    %r9,%rdx
   67003:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   67008:	45 31 e4             	xor    %r12d,%r12d
   6700b:	c4 62 d3 f6 71 40    	mulx   0x40(%rcx),%rbp,%r14
   67011:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   67017:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   6701d:	c4 62 d3 f6 71 48    	mulx   0x48(%rcx),%rbp,%r14
   67023:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   67029:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   6702f:	c4 62 d3 f6 71 50    	mulx   0x50(%rcx),%rbp,%r14
   67035:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   6703b:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   67041:	c4 62 d3 f6 71 58    	mulx   0x58(%rcx),%rbp,%r14
   67047:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6704d:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67053:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   67059:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   6705d:	45 31 e4             	xor    %r12d,%r12d
   67060:	c4 62 d3 f6 31       	mulx   (%rcx),%rbp,%r14
   67065:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   6706b:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   67071:	c4 62 d3 f6 71 08    	mulx   0x8(%rcx),%rbp,%r14
   67077:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   6707d:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   67083:	c4 62 d3 f6 71 10    	mulx   0x10(%rcx),%rbp,%r14
   67089:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6708f:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67095:	c4 62 d3 f6 71 18    	mulx   0x18(%rcx),%rbp,%r14
   6709b:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   670a1:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   670a7:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   670ad:	48 8b 56 28          	mov    0x28(%rsi),%rdx
   670b1:	45 31 e4             	xor    %r12d,%r12d
   670b4:	c4 62 d3 f6 71 20    	mulx   0x20(%rcx),%rbp,%r14
   670ba:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   670c0:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   670c6:	c4 62 d3 f6 71 28    	mulx   0x28(%rcx),%rbp,%r14
   670cc:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   670d2:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   670d8:	c4 62 d3 f6 71 30    	mulx   0x30(%rcx),%rbp,%r14
   670de:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   670e4:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   670ea:	c4 62 d3 f6 71 38    	mulx   0x38(%rcx),%rbp,%r14
   670f0:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   670f6:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   670fc:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   67102:	4c 89 da             	mov    %r11,%rdx
   67105:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   6710a:	45 31 e4             	xor    %r12d,%r12d
   6710d:	c4 62 d3 f6 71 40    	mulx   0x40(%rcx),%rbp,%r14
   67113:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   67119:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   6711f:	c4 62 d3 f6 71 48    	mulx   0x48(%rcx),%rbp,%r14
   67125:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   6712b:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   67131:	c4 62 d3 f6 71 50    	mulx   0x50(%rcx),%rbp,%r14
   67137:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6713d:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67143:	c4 62 d3 f6 71 58    	mulx   0x58(%rcx),%rbp,%r14
   67149:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6714f:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67155:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   6715b:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   6715f:	45 31 e4             	xor    %r12d,%r12d
   67162:	c4 62 d3 f6 31       	mulx   (%rcx),%rbp,%r14
   67167:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   6716d:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   67173:	c4 62 d3 f6 71 08    	mulx   0x8(%rcx),%rbp,%r14
   67179:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6717f:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67185:	c4 62 d3 f6 71 10    	mulx   0x10(%rcx),%rbp,%r14
   6718b:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   67191:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67197:	c4 62 d3 f6 71 18    	mulx   0x18(%rcx),%rbp,%r14
   6719d:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   671a3:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   671a9:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   671af:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   671b3:	45 31 e4             	xor    %r12d,%r12d
   671b6:	c4 62 d3 f6 71 20    	mulx   0x20(%rcx),%rbp,%r14
   671bc:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   671c2:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   671c8:	c4 62 d3 f6 71 28    	mulx   0x28(%rcx),%rbp,%r14
   671ce:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   671d4:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   671da:	c4 62 d3 f6 71 30    	mulx   0x30(%rcx),%rbp,%r14
   671e0:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   671e6:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   671ec:	c4 62 d3 f6 71 38    	mulx   0x38(%rcx),%rbp,%r14
   671f2:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   671f8:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   671fe:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   67204:	4c 89 c2             	mov    %r8,%rdx
   67207:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   6720c:	45 31 e4             	xor    %r12d,%r12d
   6720f:	c4 62 d3 f6 71 40    	mulx   0x40(%rcx),%rbp,%r14
   67215:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   6721b:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   67221:	c4 62 d3 f6 71 48    	mulx   0x48(%rcx),%rbp,%r14
   67227:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6722d:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67233:	c4 62 d3 f6 71 50    	mulx   0x50(%rcx),%rbp,%r14
   67239:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6723f:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67245:	c4 62 d3 f6 71 58    	mulx   0x58(%rcx),%rbp,%r14
   6724b:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   67251:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   67257:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   6725d:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   67261:	45 31 e4             	xor    %r12d,%r12d
   67264:	c4 62 d3 f6 31       	mulx   (%rcx),%rbp,%r14
   67269:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6726f:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67275:	c4 62 d3 f6 71 08    	mulx   0x8(%rcx),%rbp,%r14
   6727b:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   67281:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67287:	c4 62 d3 f6 71 10    	mulx   0x10(%rcx),%rbp,%r14
   6728d:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   67293:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   67299:	c4 62 d3 f6 71 18    	mulx   0x18(%rcx),%rbp,%r14
   6729f:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   672a5:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   672ab:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   672b1:	48 8b 56 38          	mov    0x38(%rsi),%rdx
   672b5:	45 31 e4             	xor    %r12d,%r12d
   672b8:	c4 62 d3 f6 71 20    	mulx   0x20(%rcx),%rbp,%r14
   672be:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   672c4:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   672ca:	c4 62 d3 f6 71 28    	mulx   0x28(%rcx),%rbp,%r14
   672d0:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   672d6:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   672dc:	c4 62 d3 f6 71 30    	mulx   0x30(%rcx),%rbp,%r14
   672e2:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   672e8:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   672ee:	c4 62 d3 f6 71 38    	mulx   0x38(%rcx),%rbp,%r14
   672f4:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   672fa:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   67300:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   67306:	48 89 fa             	mov    %rdi,%rdx
   67309:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   6730e:	45 31 e4             	xor    %r12d,%r12d
   67311:	c4 62 d3 f6 71 40    	mulx   0x40(%rcx),%rbp,%r14
   67317:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6731d:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67323:	c4 62 d3 f6 71 48    	mulx   0x48(%rcx),%rbp,%r14
   67329:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6732f:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67335:	c4 62 d3 f6 71 50    	mulx   0x50(%rcx),%rbp,%r14
   6733b:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   67341:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   67347:	c4 62 d3 f6 71 58    	mulx   0x58(%rcx),%rbp,%r14
   6734d:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   67353:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   67359:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   6735f:	49 39 c5             	cmp    %rax,%r13
   67362:	4b 8d 04 11          	lea    (%r9,%r10,1),%rax
   67366:	48 b9 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rcx
   6736d:	6a 81 97 
   67370:	49 ba 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%r10
   67377:	4e 64 30 
   6737a:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   67380:	48 83 d8 00          	sbb    $0x0,%rax
   67384:	4c 8b a4 24 c8 01 00 	mov    0x1c8(%rsp),%r12
   6738b:	00 
   6738c:	0f 92 c2             	setb   %dl
   6738f:	49 39 c9             	cmp    %rcx,%r9
   67392:	48 b9 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rcx
   67399:	ba af 47 
   6739c:	40 0f 92 c6          	setb   %sil
   673a0:	49 8d 1c 0b          	lea    (%r11,%rcx,1),%rbx
   673a4:	48 b9 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rcx
   673ab:	45 50 b8 
   673ae:	40 08 d6             	or     %dl,%sil
   673b1:	40 0f b6 d6          	movzbl %sil,%edx
   673b5:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
   673bc:	00 
   673bd:	48 29 d3             	sub    %rdx,%rbx
   673c0:	0f 92 c2             	setb   %dl
   673c3:	49 39 cb             	cmp    %rcx,%r11
   673c6:	48 b9 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rcx
   673cd:	b1 9b cf 
   673d0:	40 0f 92 c7          	setb   %dil
   673d4:	49 8d 2c 08          	lea    (%r8,%rcx,1),%rbp
   673d8:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
   673df:	00 
   673e0:	40 08 d7             	or     %dl,%dil
   673e3:	40 0f b6 d7          	movzbl %dil,%edx
   673e7:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
   673ee:	00 
   673ef:	48 29 d5             	sub    %rdx,%rbp
   673f2:	0f 92 c2             	setb   %dl
   673f5:	4d 39 d0             	cmp    %r10,%r8
   673f8:	41 0f 92 c6          	setb   %r14b
   673fc:	41 08 d6             	or     %dl,%r14b
   673ff:	4d 39 d4             	cmp    %r10,%r12
   67402:	0f 92 c2             	setb   %dl
   67405:	44 08 fa             	or     %r15b,%dl
   67408:	49 bf b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%r15
   6740f:	73 df c3 
   67412:	4a 8d 14 39          	lea    (%rcx,%r15,1),%rdx
   67416:	48 0f 45 b4 24 d8 01 	cmovne 0x1d8(%rsp),%rsi
   6741d:	00 00 
   6741f:	48 0f 45 bc 24 d0 01 	cmovne 0x1d0(%rsp),%rdi
   67426:	00 00 
   67428:	48 0f 45 d1          	cmovne %rcx,%rdx
   6742c:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   67433:	00 
   67434:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
   6743b:	00 
   6743c:	4b 8d 54 3d 00       	lea    0x0(%r13,%r15,1),%rdx
   67441:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
   67448:	00 
   67449:	49 0f 45 cc          	cmovne %r12,%rcx
   6744d:	45 84 f6             	test   %r14b,%r14b
   67450:	4c 8d b4 24 00 01 00 	lea    0x100(%rsp),%r14
   67457:	00 
   67458:	49 0f 45 d5          	cmovne %r13,%rdx
   6745c:	49 0f 45 c1          	cmovne %r9,%rax
   67460:	49 0f 45 db          	cmovne %r11,%rbx
   67464:	49 0f 45 e8          	cmovne %r8,%rbp
   67468:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
   6746f:	00 
   67470:	45 31 c9             	xor    %r9d,%r9d
   67473:	45 31 db             	xor    %r11d,%r11d
   67476:	45 31 e4             	xor    %r12d,%r12d
   67479:	45 31 ed             	xor    %r13d,%r13d
   6747c:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
   67483:	00 
   67484:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   6748b:	00 
   6748c:	48 89 04 24          	mov    %rax,(%rsp)
   67490:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
   67497:	00 
   67498:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
   6749f:	00 
   674a0:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   674a5:	48 89 ac 24 18 01 00 	mov    %rbp,0x118(%rsp)
   674ac:	00 
   674ad:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   674b2:	4d 2b 0e             	sub    (%r14),%r9
   674b5:	4d 1b 5e 08          	sbb    0x8(%r14),%r11
   674b9:	4d 1b 66 10          	sbb    0x10(%r14),%r12
   674bd:	4d 1b 6e 18          	sbb    0x18(%r14),%r13
   674c1:	4d 19 ff             	sbb    %r15,%r15
   674c4:	48 8b 10             	mov    (%rax),%rdx
   674c7:	4c 8b 40 08          	mov    0x8(%rax),%r8
   674cb:	4c 8b 50 10          	mov    0x10(%rax),%r10
   674cf:	48 8b 58 18          	mov    0x18(%rax),%rbx
   674d3:	4c 21 fa             	and    %r15,%rdx
   674d6:	4d 21 f8             	and    %r15,%r8
   674d9:	4d 21 fa             	and    %r15,%r10
   674dc:	4c 21 fb             	and    %r15,%rbx
   674df:	49 01 d1             	add    %rdx,%r9
   674e2:	4d 11 c3             	adc    %r8,%r11
   674e5:	4d 11 d4             	adc    %r10,%r12
   674e8:	49 11 dd             	adc    %rbx,%r13
   674eb:	48 89 bc 24 d0 00 00 	mov    %rdi,0xd0(%rsp)
   674f2:	00 
   674f3:	4c 8d 84 24 60 01 00 	lea    0x160(%rsp),%r8
   674fa:	00 
   674fb:	4c 8d 74 24 30       	lea    0x30(%rsp),%r14
   67500:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   67507:	00 
   67508:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   6750f:	00 
   67510:	48 89 b4 24 68 01 00 	mov    %rsi,0x168(%rsp)
   67517:	00 
   67518:	48 89 bc 24 70 01 00 	mov    %rdi,0x170(%rsp)
   6751f:	00 
   67520:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
   67527:	00 
   67528:	48 8d 8c 24 10 03 00 	lea    0x310(%rsp),%rcx
   6752f:	00 
   67530:	4c 89 8c 24 80 01 00 	mov    %r9,0x180(%rsp)
   67537:	00 
   67538:	4c 89 9c 24 88 01 00 	mov    %r11,0x188(%rsp)
   6753f:	00 
   67540:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
   67547:	00 
   67548:	4c 89 ac 24 98 01 00 	mov    %r13,0x198(%rsp)
   6754f:	00 
   67550:	c5 fe 7f 84 24 a0 01 	vmovdqu %ymm0,0x1a0(%rsp)
   67557:	00 00 
   67559:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
   67560:	00 
   67561:	c5 fc 10 51 20       	vmovups 0x20(%rcx),%ymm2
   67566:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   6756c:	c5 fc 10 11          	vmovups (%rcx),%ymm2
   67570:	c5 fc 11 94 24 00 01 	vmovups %ymm2,0x100(%rsp)
   67577:	00 00 
   67579:	c5 fc 10 51 20       	vmovups 0x20(%rcx),%ymm2
   6757e:	48 b9 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rcx
   67585:	07 d2 87 
   67588:	c5 fc 11 94 24 20 01 	vmovups %ymm2,0x120(%rsp)
   6758f:	00 00 
   67591:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
   67598:	00 
   67599:	c5 fa 7f 8c 24 48 01 	vmovdqu %xmm1,0x148(%rsp)
   675a0:	00 00 
   675a2:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
   675a9:	00 00 00 00 00 
   675ae:	31 ff                	xor    %edi,%edi
   675b0:	45 31 e4             	xor    %r12d,%r12d
   675b3:	31 f6                	xor    %esi,%esi
   675b5:	45 31 d2             	xor    %r10d,%r10d
   675b8:	45 31 ed             	xor    %r13d,%r13d
   675bb:	49 8b 11             	mov    (%r9),%rdx
   675be:	45 31 ff             	xor    %r15d,%r15d
   675c1:	c4 c2 a3 f6 18       	mulx   (%r8),%r11,%rbx
   675c6:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   675cc:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   675d2:	c4 c2 a3 f6 58 08    	mulx   0x8(%r8),%r11,%rbx
   675d8:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   675de:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   675e4:	c4 c2 a3 f6 58 10    	mulx   0x10(%r8),%r11,%rbx
   675ea:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   675f0:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   675f6:	c4 c2 a3 f6 58 18    	mulx   0x18(%r8),%r11,%rbx
   675fc:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67602:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67608:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   6760e:	49 8b 51 20          	mov    0x20(%r9),%rdx
   67612:	45 31 ff             	xor    %r15d,%r15d
   67615:	c4 c2 a3 f6 58 20    	mulx   0x20(%r8),%r11,%rbx
   6761b:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   67621:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67627:	c4 c2 a3 f6 58 28    	mulx   0x28(%r8),%r11,%rbx
   6762d:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   67633:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67639:	c4 c2 a3 f6 58 30    	mulx   0x30(%r8),%r11,%rbx
   6763f:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   67645:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   6764b:	c4 c2 a3 f6 58 38    	mulx   0x38(%r8),%r11,%rbx
   67651:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67657:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   6765d:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   67663:	48 89 fa             	mov    %rdi,%rdx
   67666:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   6766b:	45 31 ff             	xor    %r15d,%r15d
   6766e:	c4 c2 a3 f6 58 40    	mulx   0x40(%r8),%r11,%rbx
   67674:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   6767a:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67680:	c4 c2 a3 f6 58 48    	mulx   0x48(%r8),%r11,%rbx
   67686:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   6768c:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67692:	c4 c2 a3 f6 58 50    	mulx   0x50(%r8),%r11,%rbx
   67698:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   6769e:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   676a4:	c4 c2 a3 f6 58 58    	mulx   0x58(%r8),%r11,%rbx
   676aa:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   676b0:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   676b6:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   676bc:	49 8b 51 08          	mov    0x8(%r9),%rdx
   676c0:	45 31 ff             	xor    %r15d,%r15d
   676c3:	c4 c2 a3 f6 18       	mulx   (%r8),%r11,%rbx
   676c8:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   676ce:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   676d4:	c4 c2 a3 f6 58 08    	mulx   0x8(%r8),%r11,%rbx
   676da:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   676e0:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   676e6:	c4 c2 a3 f6 58 10    	mulx   0x10(%r8),%r11,%rbx
   676ec:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   676f2:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   676f8:	c4 c2 a3 f6 58 18    	mulx   0x18(%r8),%r11,%rbx
   676fe:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67704:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   6770a:	66 49 0f 38 f6 ff    	adcx   %r15,%rdi
   67710:	49 8b 51 28          	mov    0x28(%r9),%rdx
   67714:	45 31 ff             	xor    %r15d,%r15d
   67717:	c4 c2 a3 f6 58 20    	mulx   0x20(%r8),%r11,%rbx
   6771d:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   67723:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67729:	c4 c2 a3 f6 58 28    	mulx   0x28(%r8),%r11,%rbx
   6772f:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   67735:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   6773b:	c4 c2 a3 f6 58 30    	mulx   0x30(%r8),%r11,%rbx
   67741:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67747:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   6774d:	c4 c2 a3 f6 58 38    	mulx   0x38(%r8),%r11,%rbx
   67753:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67759:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   6775f:	66 49 0f 38 f6 ff    	adcx   %r15,%rdi
   67765:	4c 89 e2             	mov    %r12,%rdx
   67768:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   6776d:	45 31 ff             	xor    %r15d,%r15d
   67770:	c4 c2 a3 f6 58 40    	mulx   0x40(%r8),%r11,%rbx
   67776:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   6777c:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67782:	c4 c2 a3 f6 58 48    	mulx   0x48(%r8),%r11,%rbx
   67788:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   6778e:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   67794:	c4 c2 a3 f6 58 50    	mulx   0x50(%r8),%r11,%rbx
   6779a:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   677a0:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   677a6:	c4 c2 a3 f6 58 58    	mulx   0x58(%r8),%r11,%rbx
   677ac:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   677b2:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   677b8:	66 49 0f 38 f6 ff    	adcx   %r15,%rdi
   677be:	49 8b 51 10          	mov    0x10(%r9),%rdx
   677c2:	45 31 ff             	xor    %r15d,%r15d
   677c5:	c4 c2 a3 f6 18       	mulx   (%r8),%r11,%rbx
   677ca:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   677d0:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   677d6:	c4 c2 a3 f6 58 08    	mulx   0x8(%r8),%r11,%rbx
   677dc:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   677e2:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   677e8:	c4 c2 a3 f6 58 10    	mulx   0x10(%r8),%r11,%rbx
   677ee:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   677f4:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   677fa:	c4 c2 a3 f6 58 18    	mulx   0x18(%r8),%r11,%rbx
   67800:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   67806:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   6780c:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   67812:	49 8b 51 30          	mov    0x30(%r9),%rdx
   67816:	45 31 ff             	xor    %r15d,%r15d
   67819:	c4 c2 a3 f6 58 20    	mulx   0x20(%r8),%r11,%rbx
   6781f:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   67825:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   6782b:	c4 c2 a3 f6 58 28    	mulx   0x28(%r8),%r11,%rbx
   67831:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67837:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   6783d:	c4 c2 a3 f6 58 30    	mulx   0x30(%r8),%r11,%rbx
   67843:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67849:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   6784f:	c4 c2 a3 f6 58 38    	mulx   0x38(%r8),%r11,%rbx
   67855:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   6785b:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67861:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   67867:	48 89 f2             	mov    %rsi,%rdx
   6786a:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   6786f:	45 31 ff             	xor    %r15d,%r15d
   67872:	c4 c2 a3 f6 58 40    	mulx   0x40(%r8),%r11,%rbx
   67878:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   6787e:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   67884:	c4 c2 a3 f6 58 48    	mulx   0x48(%r8),%r11,%rbx
   6788a:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67890:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67896:	c4 c2 a3 f6 58 50    	mulx   0x50(%r8),%r11,%rbx
   6789c:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   678a2:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   678a8:	c4 c2 a3 f6 58 58    	mulx   0x58(%r8),%r11,%rbx
   678ae:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   678b4:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   678ba:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   678c0:	49 8b 51 18          	mov    0x18(%r9),%rdx
   678c4:	45 31 ff             	xor    %r15d,%r15d
   678c7:	c4 c2 a3 f6 18       	mulx   (%r8),%r11,%rbx
   678cc:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   678d2:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   678d8:	c4 c2 a3 f6 58 08    	mulx   0x8(%r8),%r11,%rbx
   678de:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   678e4:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   678ea:	c4 c2 a3 f6 58 10    	mulx   0x10(%r8),%r11,%rbx
   678f0:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   678f6:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   678fc:	c4 c2 a3 f6 58 18    	mulx   0x18(%r8),%r11,%rbx
   67902:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   67908:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   6790e:	66 49 0f 38 f6 f7    	adcx   %r15,%rsi
   67914:	49 8b 51 38          	mov    0x38(%r9),%rdx
   67918:	45 31 ff             	xor    %r15d,%r15d
   6791b:	c4 c2 a3 f6 58 20    	mulx   0x20(%r8),%r11,%rbx
   67921:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67927:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   6792d:	c4 c2 a3 f6 58 28    	mulx   0x28(%r8),%r11,%rbx
   67933:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67939:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   6793f:	c4 c2 a3 f6 58 30    	mulx   0x30(%r8),%r11,%rbx
   67945:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   6794b:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67951:	c4 c2 a3 f6 58 38    	mulx   0x38(%r8),%r11,%rbx
   67957:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   6795d:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67963:	66 49 0f 38 f6 f7    	adcx   %r15,%rsi
   67969:	4c 89 d2             	mov    %r10,%rdx
   6796c:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   67971:	45 31 ff             	xor    %r15d,%r15d
   67974:	c4 c2 a3 f6 58 40    	mulx   0x40(%r8),%r11,%rbx
   6797a:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67980:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67986:	c4 c2 a3 f6 58 48    	mulx   0x48(%r8),%r11,%rbx
   6798c:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67992:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   67998:	c4 c2 a3 f6 58 50    	mulx   0x50(%r8),%r11,%rbx
   6799e:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   679a4:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   679aa:	c4 c2 a3 f6 58 58    	mulx   0x58(%r8),%r11,%rbx
   679b0:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   679b6:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   679bc:	66 49 0f 38 f6 f7    	adcx   %r15,%rsi
   679c2:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   679c9:	00 
   679ca:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   679d1:	8c 20 3c 
   679d4:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
   679db:	00 
   679dc:	49 89 f9             	mov    %rdi,%r9
   679df:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   679e4:	48 89 b4 24 a0 00 00 	mov    %rsi,0xa0(%rsp)
   679eb:	00 
   679ec:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
   679f1:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
   679f8:	00 
   679f9:	49 39 d5             	cmp    %rdx,%r13
   679fc:	48 ba 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rdx
   67a03:	95 7e 68 
   67a06:	4c 8d 2c 17          	lea    (%rdi,%rdx,1),%r13
   67a0a:	48 bf 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdi
   67a11:	6a 81 97 
   67a14:	49 83 dd 00          	sbb    $0x0,%r13
   67a18:	0f 92 c2             	setb   %dl
   67a1b:	49 39 f9             	cmp    %rdi,%r9
   67a1e:	48 bf a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdi
   67a25:	ba af 47 
   67a28:	41 0f 92 c1          	setb   %r9b
   67a2c:	4d 8d 1c 3c          	lea    (%r12,%rdi,1),%r11
   67a30:	48 bf 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdi
   67a37:	45 50 b8 
   67a3a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   67a41:	00 
   67a42:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   67a49:	00 
   67a4a:	41 08 d1             	or     %dl,%r9b
   67a4d:	41 0f b6 d1          	movzbl %r9b,%edx
   67a51:	49 29 d3             	sub    %rdx,%r11
   67a54:	0f 92 c2             	setb   %dl
   67a57:	49 39 fc             	cmp    %rdi,%r12
   67a5a:	48 bf d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdi
   67a61:	b1 9b cf 
   67a64:	41 0f 92 c1          	setb   %r9b
   67a68:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   67a6f:	00 
   67a70:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
   67a77:	00 
   67a78:	41 08 d1             	or     %dl,%r9b
   67a7b:	41 0f b6 d1          	movzbl %r9b,%edx
   67a7f:	4c 8d 0c 3e          	lea    (%rsi,%rdi,1),%r9
   67a83:	49 29 d1             	sub    %rdx,%r9
   67a86:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   67a8d:	00 
   67a8e:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   67a95:	00 
   67a96:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
   67a9d:	00 
   67a9e:	48 8b 04 24          	mov    (%rsp),%rax
   67aa2:	0f 92 04 24          	setb   (%rsp)
   67aa6:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
   67aad:	00 
   67aae:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   67ab3:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   67aba:	00 
   67abb:	48 8d 84 24 10 03 00 	lea    0x310(%rsp),%rax
   67ac2:	00 
   67ac3:	48 89 ac 24 38 01 00 	mov    %rbp,0x138(%rsp)
   67aca:	00 
   67acb:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
   67ad2:	00 00 
   67ad4:	c5 fc 10 10          	vmovups (%rax),%ymm2
   67ad8:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
   67adf:	00 
   67ae0:	c5 fc 11 54 24 50    	vmovups %ymm2,0x50(%rsp)
   67ae6:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   67aeb:	c5 fa 7f 4c 24 78    	vmovdqu %xmm1,0x78(%rsp)
   67af1:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   67af8:	00 00 00 00 00 
   67afd:	45 31 d2             	xor    %r10d,%r10d
   67b00:	31 ff                	xor    %edi,%edi
   67b02:	45 31 c0             	xor    %r8d,%r8d
   67b05:	45 31 ff             	xor    %r15d,%r15d
   67b08:	31 db                	xor    %ebx,%ebx
   67b0a:	49 8b 16             	mov    (%r14),%rdx
   67b0d:	31 c9                	xor    %ecx,%ecx
   67b0f:	c4 62 d3 f6 20       	mulx   (%rax),%rbp,%r12
   67b14:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67b1a:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67b20:	c4 62 d3 f6 60 08    	mulx   0x8(%rax),%rbp,%r12
   67b26:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67b2c:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67b32:	c4 62 d3 f6 60 10    	mulx   0x10(%rax),%rbp,%r12
   67b38:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67b3e:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67b44:	c4 62 d3 f6 60 18    	mulx   0x18(%rax),%rbp,%r12
   67b4a:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67b50:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67b56:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   67b5c:	49 8b 56 20          	mov    0x20(%r14),%rdx
   67b60:	31 c9                	xor    %ecx,%ecx
   67b62:	c4 62 d3 f6 60 20    	mulx   0x20(%rax),%rbp,%r12
   67b68:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67b6e:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67b74:	c4 62 d3 f6 60 28    	mulx   0x28(%rax),%rbp,%r12
   67b7a:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67b80:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67b86:	c4 62 d3 f6 60 30    	mulx   0x30(%rax),%rbp,%r12
   67b8c:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67b92:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67b98:	c4 62 d3 f6 60 38    	mulx   0x38(%rax),%rbp,%r12
   67b9e:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67ba4:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67baa:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   67bb0:	4c 89 d2             	mov    %r10,%rdx
   67bb3:	49 0f af 56 40       	imul   0x40(%r14),%rdx
   67bb8:	31 c9                	xor    %ecx,%ecx
   67bba:	c4 62 d3 f6 60 40    	mulx   0x40(%rax),%rbp,%r12
   67bc0:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67bc6:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67bcc:	c4 62 d3 f6 60 48    	mulx   0x48(%rax),%rbp,%r12
   67bd2:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67bd8:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67bde:	c4 62 d3 f6 60 50    	mulx   0x50(%rax),%rbp,%r12
   67be4:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67bea:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67bf0:	c4 62 d3 f6 60 58    	mulx   0x58(%rax),%rbp,%r12
   67bf6:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67bfc:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67c02:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   67c08:	49 8b 56 08          	mov    0x8(%r14),%rdx
   67c0c:	31 c9                	xor    %ecx,%ecx
   67c0e:	c4 62 d3 f6 20       	mulx   (%rax),%rbp,%r12
   67c13:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67c19:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67c1f:	c4 62 d3 f6 60 08    	mulx   0x8(%rax),%rbp,%r12
   67c25:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67c2b:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67c31:	c4 62 d3 f6 60 10    	mulx   0x10(%rax),%rbp,%r12
   67c37:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67c3d:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67c43:	c4 62 d3 f6 60 18    	mulx   0x18(%rax),%rbp,%r12
   67c49:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67c4f:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67c55:	66 4c 0f 38 f6 d1    	adcx   %rcx,%r10
   67c5b:	49 8b 56 28          	mov    0x28(%r14),%rdx
   67c5f:	31 c9                	xor    %ecx,%ecx
   67c61:	c4 62 d3 f6 60 20    	mulx   0x20(%rax),%rbp,%r12
   67c67:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67c6d:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67c73:	c4 62 d3 f6 60 28    	mulx   0x28(%rax),%rbp,%r12
   67c79:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67c7f:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67c85:	c4 62 d3 f6 60 30    	mulx   0x30(%rax),%rbp,%r12
   67c8b:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67c91:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67c97:	c4 62 d3 f6 60 38    	mulx   0x38(%rax),%rbp,%r12
   67c9d:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67ca3:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67ca9:	66 4c 0f 38 f6 d1    	adcx   %rcx,%r10
   67caf:	48 89 fa             	mov    %rdi,%rdx
   67cb2:	49 0f af 56 40       	imul   0x40(%r14),%rdx
   67cb7:	31 c9                	xor    %ecx,%ecx
   67cb9:	c4 62 d3 f6 60 40    	mulx   0x40(%rax),%rbp,%r12
   67cbf:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67cc5:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67ccb:	c4 62 d3 f6 60 48    	mulx   0x48(%rax),%rbp,%r12
   67cd1:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67cd7:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67cdd:	c4 62 d3 f6 60 50    	mulx   0x50(%rax),%rbp,%r12
   67ce3:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67ce9:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67cef:	c4 62 d3 f6 60 58    	mulx   0x58(%rax),%rbp,%r12
   67cf5:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67cfb:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67d01:	66 4c 0f 38 f6 d1    	adcx   %rcx,%r10
   67d07:	49 8b 56 10          	mov    0x10(%r14),%rdx
   67d0b:	31 c9                	xor    %ecx,%ecx
   67d0d:	c4 62 d3 f6 20       	mulx   (%rax),%rbp,%r12
   67d12:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67d18:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67d1e:	c4 62 d3 f6 60 08    	mulx   0x8(%rax),%rbp,%r12
   67d24:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67d2a:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67d30:	c4 62 d3 f6 60 10    	mulx   0x10(%rax),%rbp,%r12
   67d36:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67d3c:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67d42:	c4 62 d3 f6 60 18    	mulx   0x18(%rax),%rbp,%r12
   67d48:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67d4e:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67d54:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   67d5a:	49 8b 56 30          	mov    0x30(%r14),%rdx
   67d5e:	31 c9                	xor    %ecx,%ecx
   67d60:	c4 62 d3 f6 60 20    	mulx   0x20(%rax),%rbp,%r12
   67d66:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67d6c:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67d72:	c4 62 d3 f6 60 28    	mulx   0x28(%rax),%rbp,%r12
   67d78:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67d7e:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67d84:	c4 62 d3 f6 60 30    	mulx   0x30(%rax),%rbp,%r12
   67d8a:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67d90:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67d96:	c4 62 d3 f6 60 38    	mulx   0x38(%rax),%rbp,%r12
   67d9c:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67da2:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67da8:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   67dae:	4c 89 c2             	mov    %r8,%rdx
   67db1:	49 0f af 56 40       	imul   0x40(%r14),%rdx
   67db6:	31 c9                	xor    %ecx,%ecx
   67db8:	c4 62 d3 f6 60 40    	mulx   0x40(%rax),%rbp,%r12
   67dbe:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67dc4:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67dca:	c4 62 d3 f6 60 48    	mulx   0x48(%rax),%rbp,%r12
   67dd0:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67dd6:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67ddc:	c4 62 d3 f6 60 50    	mulx   0x50(%rax),%rbp,%r12
   67de2:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67de8:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67dee:	c4 62 d3 f6 60 58    	mulx   0x58(%rax),%rbp,%r12
   67df4:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67dfa:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67e00:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   67e06:	49 8b 56 18          	mov    0x18(%r14),%rdx
   67e0a:	31 c9                	xor    %ecx,%ecx
   67e0c:	c4 62 d3 f6 20       	mulx   (%rax),%rbp,%r12
   67e11:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67e17:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67e1d:	c4 62 d3 f6 60 08    	mulx   0x8(%rax),%rbp,%r12
   67e23:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67e29:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67e2f:	c4 62 d3 f6 60 10    	mulx   0x10(%rax),%rbp,%r12
   67e35:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67e3b:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67e41:	c4 62 d3 f6 60 18    	mulx   0x18(%rax),%rbp,%r12
   67e47:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67e4d:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67e53:	66 4c 0f 38 f6 c1    	adcx   %rcx,%r8
   67e59:	49 8b 56 38          	mov    0x38(%r14),%rdx
   67e5d:	31 c9                	xor    %ecx,%ecx
   67e5f:	c4 62 d3 f6 60 20    	mulx   0x20(%rax),%rbp,%r12
   67e65:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67e6b:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67e71:	c4 62 d3 f6 60 28    	mulx   0x28(%rax),%rbp,%r12
   67e77:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67e7d:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67e83:	c4 62 d3 f6 60 30    	mulx   0x30(%rax),%rbp,%r12
   67e89:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67e8f:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67e95:	c4 62 d3 f6 60 38    	mulx   0x38(%rax),%rbp,%r12
   67e9b:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67ea1:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67ea7:	66 4c 0f 38 f6 c1    	adcx   %rcx,%r8
   67ead:	4c 89 fa             	mov    %r15,%rdx
   67eb0:	49 0f af 56 40       	imul   0x40(%r14),%rdx
   67eb5:	31 c9                	xor    %ecx,%ecx
   67eb7:	c4 62 d3 f6 60 40    	mulx   0x40(%rax),%rbp,%r12
   67ebd:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67ec3:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67ec9:	c4 62 d3 f6 60 48    	mulx   0x48(%rax),%rbp,%r12
   67ecf:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67ed5:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67edb:	c4 62 d3 f6 60 50    	mulx   0x50(%rax),%rbp,%r12
   67ee1:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67ee7:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67eed:	c4 62 d3 f6 60 58    	mulx   0x58(%rax),%rbp,%r12
   67ef3:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67ef9:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67eff:	66 4c 0f 38 f6 c1    	adcx   %rcx,%r8
   67f05:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   67f0c:	8c 20 3c 
   67f0f:	49 bc 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%r12
   67f16:	4e 64 30 
   67f19:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   67f1f:	48 39 c3             	cmp    %rax,%rbx
   67f22:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   67f29:	95 7e 68 
   67f2c:	c5 fc 10 94 24 f0 02 	vmovups 0x2f0(%rsp),%ymm2
   67f33:	00 00 
   67f35:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   67f3c:	00 
   67f3d:	49 8d 34 02          	lea    (%r10,%rax,1),%rsi
   67f41:	48 b8 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rax
   67f48:	6a 81 97 
   67f4b:	48 83 de 00          	sbb    $0x0,%rsi
   67f4f:	0f 92 c2             	setb   %dl
   67f52:	49 39 c2             	cmp    %rax,%r10
   67f55:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   67f5c:	ba af 47 
   67f5f:	40 0f 92 c5          	setb   %bpl
   67f63:	40 08 d5             	or     %dl,%bpl
   67f66:	48 8d 14 07          	lea    (%rdi,%rax,1),%rdx
   67f6a:	48 b8 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rax
   67f71:	45 50 b8 
   67f74:	44 0f b6 f5          	movzbl %bpl,%r14d
   67f78:	4c 29 f2             	sub    %r14,%rdx
   67f7b:	40 0f 92 c5          	setb   %bpl
   67f7f:	48 39 c7             	cmp    %rax,%rdi
   67f82:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   67f89:	b1 9b cf 
   67f8c:	c5 fc 11 94 24 20 01 	vmovups %ymm2,0x120(%rsp)
   67f93:	00 00 
   67f95:	c5 fc 10 94 24 f0 02 	vmovups 0x2f0(%rsp),%ymm2
   67f9c:	00 00 
   67f9e:	41 0f 92 c6          	setb   %r14b
   67fa2:	41 08 ee             	or     %bpl,%r14b
   67fa5:	45 0f b6 fe          	movzbl %r14b,%r15d
   67fa9:	4d 8d 34 00          	lea    (%r8,%rax,1),%r14
   67fad:	48 b8 b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rax
   67fb4:	73 df c3 
   67fb7:	4d 29 fe             	sub    %r15,%r14
   67fba:	40 0f 92 c5          	setb   %bpl
   67fbe:	4d 39 e0             	cmp    %r12,%r8
   67fc1:	41 0f 92 c7          	setb   %r15b
   67fc5:	41 08 ef             	or     %bpl,%r15b
   67fc8:	4c 39 e1             	cmp    %r12,%rcx
   67fcb:	40 0f 92 c5          	setb   %bpl
   67fcf:	40 0a 2c 24          	or     (%rsp),%bpl
   67fd3:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
   67fda:	00 
   67fdb:	c5 fc 11 94 24 60 01 	vmovups %ymm2,0x160(%rsp)
   67fe2:	00 00 
   67fe4:	4c 0f 45 6c 24 28    	cmovne 0x28(%rsp),%r13
   67fea:	4c 0f 45 5c 24 20    	cmovne 0x20(%rsp),%r11
   67ff0:	4c 0f 45 c9          	cmovne %rcx,%r9
   67ff4:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
   67ffb:	00 
   67ffc:	4c 8d 64 05 00       	lea    0x0(%rbp,%rax,1),%r12
   68001:	4c 0f 45 e5          	cmovne %rbp,%r12
   68005:	45 84 ff             	test   %r15b,%r15b
   68008:	4c 8d 3c 03          	lea    (%rbx,%rax,1),%r15
   6800c:	4c 0f 45 fb          	cmovne %rbx,%r15
   68010:	49 0f 45 f2          	cmovne %r10,%rsi
   68014:	48 0f 45 d7          	cmovne %rdi,%rdx
   68018:	4d 0f 45 f0          	cmovne %r8,%r14
   6801c:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
   68023:	00 
   68024:	31 ff                	xor    %edi,%edi
   68026:	45 31 c0             	xor    %r8d,%r8d
   68029:	4c 89 ac 24 e8 01 00 	mov    %r13,0x1e8(%rsp)
   68030:	00 
   68031:	4c 89 9c 24 f0 01 00 	mov    %r11,0x1f0(%rsp)
   68038:	00 
   68039:	4c 89 8c 24 f8 01 00 	mov    %r9,0x1f8(%rsp)
   68040:	00 
   68041:	4c 89 bc 24 00 02 00 	mov    %r15,0x200(%rsp)
   68048:	00 
   68049:	48 89 b4 24 08 02 00 	mov    %rsi,0x208(%rsp)
   68050:	00 
   68051:	48 89 94 24 10 02 00 	mov    %rdx,0x210(%rsp)
   68058:	00 
   68059:	4c 89 b4 24 18 02 00 	mov    %r14,0x218(%rsp)
   68060:	00 
   68061:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   68066:	31 f6                	xor    %esi,%esi
   68068:	45 31 c9             	xor    %r9d,%r9d
   6806b:	48 2b 31             	sub    (%rcx),%rsi
   6806e:	48 1b 79 08          	sbb    0x8(%rcx),%rdi
   68072:	4c 1b 41 10          	sbb    0x10(%rcx),%r8
   68076:	4c 1b 49 18          	sbb    0x18(%rcx),%r9
   6807a:	4d 19 f6             	sbb    %r14,%r14
   6807d:	4c 8b 12             	mov    (%rdx),%r10
   68080:	4c 8b 5a 08          	mov    0x8(%rdx),%r11
   68084:	48 8b 5a 10          	mov    0x10(%rdx),%rbx
   68088:	48 8b 6a 18          	mov    0x18(%rdx),%rbp
   6808c:	4d 21 f2             	and    %r14,%r10
   6808f:	4d 21 f3             	and    %r14,%r11
   68092:	4c 21 f3             	and    %r14,%rbx
   68095:	4c 21 f5             	and    %r14,%rbp
   68098:	4c 01 d6             	add    %r10,%rsi
   6809b:	4c 11 df             	adc    %r11,%rdi
   6809e:	49 11 d8             	adc    %rbx,%r8
   680a1:	49 11 e9             	adc    %rbp,%r9
   680a4:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
   680ab:	00 
   680ac:	c5 fc 10 94 24 d0 02 	vmovups 0x2d0(%rsp),%ymm2
   680b3:	00 00 
   680b5:	48 8b ac 24 20 02 00 	mov    0x220(%rsp),%rbp
   680bc:	00 
   680bd:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
   680c4:	00 
   680c5:	4c 8b a4 24 f8 00 00 	mov    0xf8(%rsp),%r12
   680cc:	00 
   680cd:	4c 8b ac 24 b8 00 00 	mov    0xb8(%rsp),%r13
   680d4:	00 
   680d5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   680da:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   680e1:	00 
   680e2:	c5 fc 11 94 24 60 01 	vmovups %ymm2,0x160(%rsp)
   680e9:	00 00 
   680eb:	48 89 b4 24 80 01 00 	mov    %rsi,0x180(%rsp)
   680f2:	00 
   680f3:	48 89 bc 24 88 01 00 	mov    %rdi,0x188(%rsp)
   680fa:	00 
   680fb:	4c 89 84 24 90 01 00 	mov    %r8,0x190(%rsp)
   68102:	00 
   68103:	4c 89 8c 24 98 01 00 	mov    %r9,0x198(%rsp)
   6810a:	00 
   6810b:	c5 fe 7f 84 24 a0 01 	vmovdqu %ymm0,0x1a0(%rsp)
   68112:	00 00 
   68114:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   68119:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   6811e:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   68125:	00 
   68126:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   6812b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   68130:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   68135:	48 b8 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rax
   6813c:	07 d2 87 
   6813f:	48 89 6c 24 50       	mov    %rbp,0x50(%rsp)
   68144:	4c 89 7c 24 58       	mov    %r15,0x58(%rsp)
   68149:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
   6814e:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
   68153:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   68158:	c5 fa 7f 4c 24 78    	vmovdqu %xmm1,0x78(%rsp)
   6815e:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   68165:	00 00 00 00 00 
   6816a:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   68171:	00 
   68172:	45 31 db             	xor    %r11d,%r11d
   68175:	45 31 f6             	xor    %r14d,%r14d
   68178:	31 db                	xor    %ebx,%ebx
   6817a:	31 ff                	xor    %edi,%edi
   6817c:	31 c9                	xor    %ecx,%ecx
   6817e:	48 8b 16             	mov    (%rsi),%rdx
   68181:	45 31 d2             	xor    %r10d,%r10d
   68184:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   68189:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6818f:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   68195:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   6819b:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   681a1:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   681a7:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   681ad:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   681b3:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   681b9:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   681bf:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   681c5:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   681cb:	66 49 0f 38 f6 ca    	adcx   %r10,%rcx
   681d1:	48 8b 56 20          	mov    0x20(%rsi),%rdx
   681d5:	45 31 d2             	xor    %r10d,%r10d
   681d8:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   681de:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   681e4:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   681ea:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   681f0:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   681f6:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   681fc:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   68202:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   68208:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6820e:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   68214:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6821a:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68220:	66 49 0f 38 f6 ca    	adcx   %r10,%rcx
   68226:	4c 89 da             	mov    %r11,%rdx
   68229:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   6822e:	45 31 d2             	xor    %r10d,%r10d
   68231:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   68237:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6823d:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   68243:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   68249:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6824f:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   68255:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   6825b:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   68261:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68267:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   6826d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68273:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68279:	66 49 0f 38 f6 ca    	adcx   %r10,%rcx
   6827f:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   68283:	45 31 d2             	xor    %r10d,%r10d
   68286:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   6828b:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   68291:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   68297:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   6829d:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   682a3:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   682a9:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   682af:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   682b5:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   682bb:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   682c1:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   682c7:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   682cd:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   682d3:	48 8b 56 28          	mov    0x28(%rsi),%rdx
   682d7:	45 31 d2             	xor    %r10d,%r10d
   682da:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   682e0:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   682e6:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   682ec:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   682f2:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   682f8:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   682fe:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   68304:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6830a:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68310:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   68316:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   6831c:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   68322:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   68328:	4c 89 f2             	mov    %r14,%rdx
   6832b:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   68330:	45 31 d2             	xor    %r10d,%r10d
   68333:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   68339:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6833f:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   68345:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   6834b:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   68351:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68357:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   6835d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68363:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68369:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   6836f:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   68375:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6837b:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   68381:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   68385:	45 31 d2             	xor    %r10d,%r10d
   68388:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   6838d:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   68393:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68399:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   6839f:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   683a5:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   683ab:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   683b1:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   683b7:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   683bd:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   683c3:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   683c9:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   683cf:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   683d5:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   683d9:	45 31 d2             	xor    %r10d,%r10d
   683dc:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   683e2:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   683e8:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   683ee:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   683f4:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   683fa:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68400:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   68406:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   6840c:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   68412:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   68418:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6841e:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   68424:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   6842a:	48 89 da             	mov    %rbx,%rdx
   6842d:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   68432:	45 31 d2             	xor    %r10d,%r10d
   68435:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   6843b:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   68441:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68447:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   6844d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68453:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68459:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   6845f:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   68465:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6846b:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   68471:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   68477:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   6847d:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   68483:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   68487:	45 31 d2             	xor    %r10d,%r10d
   6848a:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   6848f:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68495:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   6849b:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   684a1:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   684a7:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   684ad:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   684b3:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   684b9:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   684bf:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   684c5:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   684cb:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   684d1:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   684d7:	48 8b 56 38          	mov    0x38(%rsi),%rdx
   684db:	45 31 d2             	xor    %r10d,%r10d
   684de:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   684e4:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   684ea:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   684f0:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   684f6:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   684fc:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   68502:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   68508:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6850e:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   68514:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   6851a:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   68520:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   68526:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   6852c:	48 89 fa             	mov    %rdi,%rdx
   6852f:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   68534:	45 31 d2             	xor    %r10d,%r10d
   68537:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   6853d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68543:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68549:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   6854f:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   68555:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6855b:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   68561:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   68567:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   6856d:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   68573:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   68579:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6857f:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   68585:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   6858c:	8c 20 3c 
   6858f:	48 89 0c 24          	mov    %rcx,(%rsp)
   68593:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
   68598:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
   6859d:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   685a2:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
   685a7:	48 89 9c 24 a0 00 00 	mov    %rbx,0xa0(%rsp)
   685ae:	00 
   685af:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
   685b4:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
   685bb:	00 
   685bc:	4c 8d 84 24 00 01 00 	lea    0x100(%rsp),%r8
   685c3:	00 
   685c4:	4c 8d 4c 24 30       	lea    0x30(%rsp),%r9
   685c9:	48 39 c1             	cmp    %rax,%rcx
   685cc:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   685d3:	95 7e 68 
   685d6:	c5 fc 10 94 24 d0 02 	vmovups 0x2d0(%rsp),%ymm2
   685dd:	00 00 
   685df:	49 8d 04 03          	lea    (%r11,%rax,1),%rax
   685e3:	48 83 d8 00          	sbb    $0x0,%rax
   685e7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   685ec:	48 b8 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rax
   685f3:	6a 81 97 
   685f6:	0f 92 c2             	setb   %dl
   685f9:	49 39 c3             	cmp    %rax,%r11
   685fc:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   68603:	ba af 47 
   68606:	40 0f 92 c6          	setb   %sil
   6860a:	40 08 d6             	or     %dl,%sil
   6860d:	40 0f b6 d6          	movzbl %sil,%edx
   68611:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
   68615:	48 b8 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rax
   6861c:	45 50 b8 
   6861f:	48 29 d6             	sub    %rdx,%rsi
   68622:	c5 fc 11 94 24 00 01 	vmovups %ymm2,0x100(%rsp)
   68629:	00 00 
   6862b:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
   68632:	00 00 
   68634:	0f 92 c2             	setb   %dl
   68637:	49 39 c6             	cmp    %rax,%r14
   6863a:	40 0f 92 c7          	setb   %dil
   6863e:	40 08 d7             	or     %dl,%dil
   68641:	40 0f b6 d7          	movzbl %dil,%edx
   68645:	48 bf d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdi
   6864c:	b1 9b cf 
   6864f:	48 8d 0c 3b          	lea    (%rbx,%rdi,1),%rcx
   68653:	48 29 d1             	sub    %rdx,%rcx
   68656:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   6865b:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
   68662:	00 
   68663:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   68668:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   6866f:	00 
   68670:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   68675:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
   6867c:	00 
   6867d:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   68682:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   68687:	0f 92 44 24 08       	setb   0x8(%rsp)
   6868c:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
   68691:	48 b9 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rcx
   68698:	07 d2 87 
   6869b:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   686a0:	c5 fa 7f 4c 24 78    	vmovdqu %xmm1,0x78(%rsp)
   686a6:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   686ad:	00 00 00 00 00 
   686b2:	48 b9 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rcx
   686b9:	8c 20 3c 
   686bc:	45 31 db             	xor    %r11d,%r11d
   686bf:	45 31 ed             	xor    %r13d,%r13d
   686c2:	45 31 e4             	xor    %r12d,%r12d
   686c5:	45 31 d2             	xor    %r10d,%r10d
   686c8:	31 db                	xor    %ebx,%ebx
   686ca:	49 8b 11             	mov    (%r9),%rdx
   686cd:	45 31 ff             	xor    %r15d,%r15d
   686d0:	c4 42 d3 f6 30       	mulx   (%r8),%rbp,%r14
   686d5:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   686db:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   686e1:	c4 42 d3 f6 70 08    	mulx   0x8(%r8),%rbp,%r14
   686e7:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   686ed:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   686f3:	c4 42 d3 f6 70 10    	mulx   0x10(%r8),%rbp,%r14
   686f9:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   686ff:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   68705:	c4 42 d3 f6 70 18    	mulx   0x18(%r8),%rbp,%r14
   6870b:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68711:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68717:	66 49 0f 38 f6 df    	adcx   %r15,%rbx
   6871d:	49 8b 51 20          	mov    0x20(%r9),%rdx
   68721:	45 31 ff             	xor    %r15d,%r15d
   68724:	c4 42 d3 f6 70 20    	mulx   0x20(%r8),%rbp,%r14
   6872a:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68730:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68736:	c4 42 d3 f6 70 28    	mulx   0x28(%r8),%rbp,%r14
   6873c:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68742:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68748:	c4 42 d3 f6 70 30    	mulx   0x30(%r8),%rbp,%r14
   6874e:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   68754:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   6875a:	c4 42 d3 f6 70 38    	mulx   0x38(%r8),%rbp,%r14
   68760:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68766:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   6876c:	66 49 0f 38 f6 df    	adcx   %r15,%rbx
   68772:	4c 89 da             	mov    %r11,%rdx
   68775:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   6877a:	45 31 ff             	xor    %r15d,%r15d
   6877d:	c4 42 d3 f6 70 40    	mulx   0x40(%r8),%rbp,%r14
   68783:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68789:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   6878f:	c4 42 d3 f6 70 48    	mulx   0x48(%r8),%rbp,%r14
   68795:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6879b:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   687a1:	c4 42 d3 f6 70 50    	mulx   0x50(%r8),%rbp,%r14
   687a7:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   687ad:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   687b3:	c4 42 d3 f6 70 58    	mulx   0x58(%r8),%rbp,%r14
   687b9:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   687bf:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   687c5:	66 49 0f 38 f6 df    	adcx   %r15,%rbx
   687cb:	49 8b 51 08          	mov    0x8(%r9),%rdx
   687cf:	45 31 ff             	xor    %r15d,%r15d
   687d2:	c4 42 d3 f6 30       	mulx   (%r8),%rbp,%r14
   687d7:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   687dd:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   687e3:	c4 42 d3 f6 70 08    	mulx   0x8(%r8),%rbp,%r14
   687e9:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   687ef:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   687f5:	c4 42 d3 f6 70 10    	mulx   0x10(%r8),%rbp,%r14
   687fb:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68801:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68807:	c4 42 d3 f6 70 18    	mulx   0x18(%r8),%rbp,%r14
   6880d:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68813:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68819:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   6881f:	49 8b 51 28          	mov    0x28(%r9),%rdx
   68823:	45 31 ff             	xor    %r15d,%r15d
   68826:	c4 42 d3 f6 70 20    	mulx   0x20(%r8),%rbp,%r14
   6882c:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68832:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68838:	c4 42 d3 f6 70 28    	mulx   0x28(%r8),%rbp,%r14
   6883e:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   68844:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   6884a:	c4 42 d3 f6 70 30    	mulx   0x30(%r8),%rbp,%r14
   68850:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68856:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   6885c:	c4 42 d3 f6 70 38    	mulx   0x38(%r8),%rbp,%r14
   68862:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68868:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   6886e:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   68874:	4c 89 ea             	mov    %r13,%rdx
   68877:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   6887c:	45 31 ff             	xor    %r15d,%r15d
   6887f:	c4 42 d3 f6 70 40    	mulx   0x40(%r8),%rbp,%r14
   68885:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6888b:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68891:	c4 42 d3 f6 70 48    	mulx   0x48(%r8),%rbp,%r14
   68897:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   6889d:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   688a3:	c4 42 d3 f6 70 50    	mulx   0x50(%r8),%rbp,%r14
   688a9:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   688af:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   688b5:	c4 42 d3 f6 70 58    	mulx   0x58(%r8),%rbp,%r14
   688bb:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   688c1:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   688c7:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   688cd:	49 8b 51 10          	mov    0x10(%r9),%rdx
   688d1:	45 31 ff             	xor    %r15d,%r15d
   688d4:	c4 42 d3 f6 30       	mulx   (%r8),%rbp,%r14
   688d9:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   688df:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   688e5:	c4 42 d3 f6 70 08    	mulx   0x8(%r8),%rbp,%r14
   688eb:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   688f1:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   688f7:	c4 42 d3 f6 70 10    	mulx   0x10(%r8),%rbp,%r14
   688fd:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68903:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68909:	c4 42 d3 f6 70 18    	mulx   0x18(%r8),%rbp,%r14
   6890f:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68915:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   6891b:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68921:	49 8b 51 30          	mov    0x30(%r9),%rdx
   68925:	45 31 ff             	xor    %r15d,%r15d
   68928:	c4 42 d3 f6 70 20    	mulx   0x20(%r8),%rbp,%r14
   6892e:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   68934:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   6893a:	c4 42 d3 f6 70 28    	mulx   0x28(%r8),%rbp,%r14
   68940:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68946:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   6894c:	c4 42 d3 f6 70 30    	mulx   0x30(%r8),%rbp,%r14
   68952:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68958:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   6895e:	c4 42 d3 f6 70 38    	mulx   0x38(%r8),%rbp,%r14
   68964:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   6896a:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68970:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68976:	4c 89 e2             	mov    %r12,%rdx
   68979:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   6897e:	45 31 ff             	xor    %r15d,%r15d
   68981:	c4 42 d3 f6 70 40    	mulx   0x40(%r8),%rbp,%r14
   68987:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   6898d:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   68993:	c4 42 d3 f6 70 48    	mulx   0x48(%r8),%rbp,%r14
   68999:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   6899f:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   689a5:	c4 42 d3 f6 70 50    	mulx   0x50(%r8),%rbp,%r14
   689ab:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   689b1:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   689b7:	c4 42 d3 f6 70 58    	mulx   0x58(%r8),%rbp,%r14
   689bd:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   689c3:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   689c9:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   689cf:	49 8b 51 18          	mov    0x18(%r9),%rdx
   689d3:	45 31 ff             	xor    %r15d,%r15d
   689d6:	c4 42 d3 f6 30       	mulx   (%r8),%rbp,%r14
   689db:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   689e1:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   689e7:	c4 42 d3 f6 70 08    	mulx   0x8(%r8),%rbp,%r14
   689ed:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   689f3:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   689f9:	c4 42 d3 f6 70 10    	mulx   0x10(%r8),%rbp,%r14
   689ff:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68a05:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68a0b:	c4 42 d3 f6 70 18    	mulx   0x18(%r8),%rbp,%r14
   68a11:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68a17:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68a1d:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   68a23:	49 8b 51 38          	mov    0x38(%r9),%rdx
   68a27:	45 31 ff             	xor    %r15d,%r15d
   68a2a:	c4 42 d3 f6 70 20    	mulx   0x20(%r8),%rbp,%r14
   68a30:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68a36:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68a3c:	c4 42 d3 f6 70 28    	mulx   0x28(%r8),%rbp,%r14
   68a42:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68a48:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68a4e:	c4 42 d3 f6 70 30    	mulx   0x30(%r8),%rbp,%r14
   68a54:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68a5a:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68a60:	c4 42 d3 f6 70 38    	mulx   0x38(%r8),%rbp,%r14
   68a66:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68a6c:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68a72:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   68a78:	4c 89 d2             	mov    %r10,%rdx
   68a7b:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   68a80:	45 31 ff             	xor    %r15d,%r15d
   68a83:	c4 42 d3 f6 70 40    	mulx   0x40(%r8),%rbp,%r14
   68a89:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68a8f:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68a95:	c4 42 d3 f6 70 48    	mulx   0x48(%r8),%rbp,%r14
   68a9b:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68aa1:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68aa7:	c4 42 d3 f6 70 50    	mulx   0x50(%r8),%rbp,%r14
   68aad:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68ab3:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68ab9:	c4 42 d3 f6 70 58    	mulx   0x58(%r8),%rbp,%r14
   68abf:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68ac5:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68acb:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   68ad1:	48 39 cb             	cmp    %rcx,%rbx
   68ad4:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   68adb:	95 7e 68 
   68ade:	c5 fe 7f 44 24 30    	vmovdqu %ymm0,0x30(%rsp)
   68ae4:	4d 8d 3c 0b          	lea    (%r11,%rcx,1),%r15
   68ae8:	48 b9 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rcx
   68aef:	6a 81 97 
   68af2:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
   68af7:	49 83 df 00          	sbb    $0x0,%r15
   68afb:	0f 92 c2             	setb   %dl
   68afe:	49 39 cb             	cmp    %rcx,%r11
   68b01:	48 b9 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rcx
   68b08:	ba af 47 
   68b0b:	41 0f 92 c1          	setb   %r9b
   68b0f:	49 8d 6c 0d 00       	lea    0x0(%r13,%rcx,1),%rbp
   68b14:	48 b9 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rcx
   68b1b:	4e 64 30 
   68b1e:	41 08 d1             	or     %dl,%r9b
   68b21:	41 0f b6 d1          	movzbl %r9b,%edx
   68b25:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
   68b2a:	48 29 d5             	sub    %rdx,%rbp
   68b2d:	0f 92 c2             	setb   %dl
   68b30:	49 39 c5             	cmp    %rax,%r13
   68b33:	48 8b 04 24          	mov    (%rsp),%rax
   68b37:	41 0f 92 c2          	setb   %r10b
   68b3b:	41 08 d2             	or     %dl,%r10b
   68b3e:	41 0f b6 d2          	movzbl %r10b,%edx
   68b42:	4d 8d 14 3c          	lea    (%r12,%rdi,1),%r10
   68b46:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
   68b4d:	00 
   68b4e:	49 29 d2             	sub    %rdx,%r10
   68b51:	0f 92 c2             	setb   %dl
   68b54:	49 39 cc             	cmp    %rcx,%r12
   68b57:	41 0f 92 c6          	setb   %r14b
   68b5b:	41 08 d6             	or     %dl,%r14b
   68b5e:	48 39 cf             	cmp    %rcx,%rdi
   68b61:	48 b9 b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rcx
   68b68:	73 df c3 
   68b6b:	0f 92 c2             	setb   %dl
   68b6e:	0a 54 24 08          	or     0x8(%rsp),%dl
   68b72:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
   68b76:	48 8d 0c 0b          	lea    (%rbx,%rcx,1),%rcx
   68b7a:	4c 0f 45 4c 24 18    	cmovne 0x18(%rsp),%r9
   68b80:	48 0f 45 b4 24 98 00 	cmovne 0x98(%rsp),%rsi
   68b87:	00 00 
   68b89:	48 0f 45 d0          	cmovne %rax,%rdx
   68b8d:	4c 0f 45 c7          	cmovne %rdi,%r8
   68b91:	45 84 f6             	test   %r14b,%r14b
   68b94:	4c 8d b4 24 00 01 00 	lea    0x100(%rsp),%r14
   68b9b:	00 
   68b9c:	48 0f 45 cb          	cmovne %rbx,%rcx
   68ba0:	4d 0f 45 fb          	cmovne %r11,%r15
   68ba4:	49 0f 45 ed          	cmovne %r13,%rbp
   68ba8:	4d 0f 45 d4          	cmovne %r12,%r10
   68bac:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
   68bb3:	00 
   68bb4:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
   68bb9:	48 89 d0             	mov    %rdx,%rax
   68bbc:	31 db                	xor    %ebx,%ebx
   68bbe:	45 31 e4             	xor    %r12d,%r12d
   68bc1:	45 31 ed             	xor    %r13d,%r13d
   68bc4:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
   68bcb:	00 
   68bcc:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
   68bd3:	00 
   68bd4:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
   68bdb:	00 
   68bdc:	48 89 ac 24 10 01 00 	mov    %rbp,0x110(%rsp)
   68be3:	00 
   68be4:	48 89 ac 24 98 00 00 	mov    %rbp,0x98(%rsp)
   68beb:	00 
   68bec:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   68bf1:	4c 89 94 24 18 01 00 	mov    %r10,0x118(%rsp)
   68bf8:	00 
   68bf9:	45 31 ff             	xor    %r15d,%r15d
   68bfc:	48 8d 6c 24 30       	lea    0x30(%rsp),%rbp
   68c01:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
   68c06:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
   68c0b:	4d 2b 3e             	sub    (%r14),%r15
   68c0e:	4d 1b 66 08          	sbb    0x8(%r14),%r12
   68c12:	4d 1b 6e 10          	sbb    0x10(%r14),%r13
   68c16:	49 1b 5e 18          	sbb    0x18(%r14),%rbx
   68c1a:	48 19 ff             	sbb    %rdi,%rdi
   68c1d:	48 8b 55 00          	mov    0x0(%rbp),%rdx
   68c21:	4c 8b 5d 08          	mov    0x8(%rbp),%r11
   68c25:	48 8b 4d 10          	mov    0x10(%rbp),%rcx
   68c29:	48 8b 75 18          	mov    0x18(%rbp),%rsi
   68c2d:	48 21 fa             	and    %rdi,%rdx
   68c30:	49 21 fb             	and    %rdi,%r11
   68c33:	48 21 f9             	and    %rdi,%rcx
   68c36:	48 21 fe             	and    %rdi,%rsi
   68c39:	49 01 d7             	add    %rdx,%r15
   68c3c:	4d 11 dc             	adc    %r11,%r12
   68c3f:	49 11 cd             	adc    %rcx,%r13
   68c42:	48 11 f3             	adc    %rsi,%rbx
   68c45:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   68c4c:	00 
   68c4d:	4c 89 8c 24 68 01 00 	mov    %r9,0x168(%rsp)
   68c54:	00 
   68c55:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
   68c5c:	00 
   68c5d:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   68c64:	00 
   68c65:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   68c6a:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
   68c71:	00 
   68c72:	48 8d 84 24 d0 03 00 	lea    0x3d0(%rsp),%rax
   68c79:	00 
   68c7a:	4c 89 84 24 78 01 00 	mov    %r8,0x178(%rsp)
   68c81:	00 
   68c82:	4c 89 bc 24 80 01 00 	mov    %r15,0x180(%rsp)
   68c89:	00 
   68c8a:	4c 89 a4 24 88 01 00 	mov    %r12,0x188(%rsp)
   68c91:	00 
   68c92:	49 bc 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r12
   68c99:	07 d2 87 
   68c9c:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
   68ca3:	00 
   68ca4:	48 89 9c 24 98 01 00 	mov    %rbx,0x198(%rsp)
   68cab:	00 
   68cac:	c5 fe 7f 84 24 a0 01 	vmovdqu %ymm0,0x1a0(%rsp)
   68cb3:	00 00 
   68cb5:	c5 fc 10 50 20       	vmovups 0x20(%rax),%ymm2
   68cba:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   68cc0:	c5 fc 10 10          	vmovups (%rax),%ymm2
   68cc4:	c5 fc 11 94 24 00 01 	vmovups %ymm2,0x100(%rsp)
   68ccb:	00 00 
   68ccd:	c5 fc 10 50 20       	vmovups 0x20(%rax),%ymm2
   68cd2:	c5 fc 11 94 24 20 01 	vmovups %ymm2,0x120(%rsp)
   68cd9:	00 00 
   68cdb:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
   68ce2:	00 
   68ce3:	c5 fa 7f 8c 24 48 01 	vmovdqu %xmm1,0x148(%rsp)
   68cea:	00 00 
   68cec:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
   68cf3:	00 00 00 00 00 
   68cf8:	31 c0                	xor    %eax,%eax
   68cfa:	45 31 c9             	xor    %r9d,%r9d
   68cfd:	45 31 c0             	xor    %r8d,%r8d
   68d00:	31 ff                	xor    %edi,%edi
   68d02:	45 31 ed             	xor    %r13d,%r13d
   68d05:	48 8b 16             	mov    (%rsi),%rdx
   68d08:	45 31 ff             	xor    %r15d,%r15d
   68d0b:	c4 e2 a3 f6 19       	mulx   (%rcx),%r11,%rbx
   68d10:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   68d16:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   68d1c:	c4 e2 a3 f6 59 08    	mulx   0x8(%rcx),%r11,%rbx
   68d22:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68d28:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68d2e:	c4 e2 a3 f6 59 10    	mulx   0x10(%rcx),%r11,%rbx
   68d34:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68d3a:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68d40:	c4 e2 a3 f6 59 18    	mulx   0x18(%rcx),%r11,%rbx
   68d46:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68d4c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68d52:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68d58:	48 8b 56 20          	mov    0x20(%rsi),%rdx
   68d5c:	45 31 ff             	xor    %r15d,%r15d
   68d5f:	c4 e2 a3 f6 59 20    	mulx   0x20(%rcx),%r11,%rbx
   68d65:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   68d6b:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   68d71:	c4 e2 a3 f6 59 28    	mulx   0x28(%rcx),%r11,%rbx
   68d77:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68d7d:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68d83:	c4 e2 a3 f6 59 30    	mulx   0x30(%rcx),%r11,%rbx
   68d89:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68d8f:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68d95:	c4 e2 a3 f6 59 38    	mulx   0x38(%rcx),%r11,%rbx
   68d9b:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68da1:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68da7:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68dad:	48 89 c2             	mov    %rax,%rdx
   68db0:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   68db5:	45 31 ff             	xor    %r15d,%r15d
   68db8:	c4 e2 a3 f6 59 40    	mulx   0x40(%rcx),%r11,%rbx
   68dbe:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   68dc4:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   68dca:	c4 e2 a3 f6 59 48    	mulx   0x48(%rcx),%r11,%rbx
   68dd0:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68dd6:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68ddc:	c4 e2 a3 f6 59 50    	mulx   0x50(%rcx),%r11,%rbx
   68de2:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68de8:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68dee:	c4 e2 a3 f6 59 58    	mulx   0x58(%rcx),%r11,%rbx
   68df4:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68dfa:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68e00:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68e06:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   68e0a:	45 31 ff             	xor    %r15d,%r15d
   68e0d:	c4 e2 a3 f6 19       	mulx   (%rcx),%r11,%rbx
   68e12:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68e18:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68e1e:	c4 e2 a3 f6 59 08    	mulx   0x8(%rcx),%r11,%rbx
   68e24:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68e2a:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68e30:	c4 e2 a3 f6 59 10    	mulx   0x10(%rcx),%r11,%rbx
   68e36:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68e3c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68e42:	c4 e2 a3 f6 59 18    	mulx   0x18(%rcx),%r11,%rbx
   68e48:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   68e4e:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   68e54:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   68e5a:	48 8b 56 28          	mov    0x28(%rsi),%rdx
   68e5e:	45 31 ff             	xor    %r15d,%r15d
   68e61:	c4 e2 a3 f6 59 20    	mulx   0x20(%rcx),%r11,%rbx
   68e67:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68e6d:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68e73:	c4 e2 a3 f6 59 28    	mulx   0x28(%rcx),%r11,%rbx
   68e79:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68e7f:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68e85:	c4 e2 a3 f6 59 30    	mulx   0x30(%rcx),%r11,%rbx
   68e8b:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68e91:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68e97:	c4 e2 a3 f6 59 38    	mulx   0x38(%rcx),%r11,%rbx
   68e9d:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   68ea3:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   68ea9:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   68eaf:	4c 89 ca             	mov    %r9,%rdx
   68eb2:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   68eb7:	45 31 ff             	xor    %r15d,%r15d
   68eba:	c4 e2 a3 f6 59 40    	mulx   0x40(%rcx),%r11,%rbx
   68ec0:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68ec6:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68ecc:	c4 e2 a3 f6 59 48    	mulx   0x48(%rcx),%r11,%rbx
   68ed2:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68ed8:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68ede:	c4 e2 a3 f6 59 50    	mulx   0x50(%rcx),%r11,%rbx
   68ee4:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68eea:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68ef0:	c4 e2 a3 f6 59 58    	mulx   0x58(%rcx),%r11,%rbx
   68ef6:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   68efc:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   68f02:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   68f08:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   68f0c:	45 31 ff             	xor    %r15d,%r15d
   68f0f:	c4 e2 a3 f6 19       	mulx   (%rcx),%r11,%rbx
   68f14:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68f1a:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68f20:	c4 e2 a3 f6 59 08    	mulx   0x8(%rcx),%r11,%rbx
   68f26:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68f2c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68f32:	c4 e2 a3 f6 59 10    	mulx   0x10(%rcx),%r11,%rbx
   68f38:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   68f3e:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   68f44:	c4 e2 a3 f6 59 18    	mulx   0x18(%rcx),%r11,%rbx
   68f4a:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   68f50:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   68f56:	66 4d 0f 38 f6 cf    	adcx   %r15,%r9
   68f5c:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   68f60:	45 31 ff             	xor    %r15d,%r15d
   68f63:	c4 e2 a3 f6 59 20    	mulx   0x20(%rcx),%r11,%rbx
   68f69:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68f6f:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68f75:	c4 e2 a3 f6 59 28    	mulx   0x28(%rcx),%r11,%rbx
   68f7b:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68f81:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68f87:	c4 e2 a3 f6 59 30    	mulx   0x30(%rcx),%r11,%rbx
   68f8d:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   68f93:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   68f99:	c4 e2 a3 f6 59 38    	mulx   0x38(%rcx),%r11,%rbx
   68f9f:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   68fa5:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   68fab:	66 4d 0f 38 f6 cf    	adcx   %r15,%r9
   68fb1:	4c 89 c2             	mov    %r8,%rdx
   68fb4:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   68fb9:	45 31 ff             	xor    %r15d,%r15d
   68fbc:	c4 e2 a3 f6 59 40    	mulx   0x40(%rcx),%r11,%rbx
   68fc2:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68fc8:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68fce:	c4 e2 a3 f6 59 48    	mulx   0x48(%rcx),%r11,%rbx
   68fd4:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68fda:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68fe0:	c4 e2 a3 f6 59 50    	mulx   0x50(%rcx),%r11,%rbx
   68fe6:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   68fec:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   68ff2:	c4 e2 a3 f6 59 58    	mulx   0x58(%rcx),%r11,%rbx
   68ff8:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   68ffe:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   69004:	66 4d 0f 38 f6 cf    	adcx   %r15,%r9
   6900a:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   6900e:	45 31 ff             	xor    %r15d,%r15d
   69011:	c4 e2 a3 f6 19       	mulx   (%rcx),%r11,%rbx
   69016:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   6901c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   69022:	c4 e2 a3 f6 59 08    	mulx   0x8(%rcx),%r11,%rbx
   69028:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   6902e:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   69034:	c4 e2 a3 f6 59 10    	mulx   0x10(%rcx),%r11,%rbx
   6903a:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   69040:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   69046:	c4 e2 a3 f6 59 18    	mulx   0x18(%rcx),%r11,%rbx
   6904c:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   69052:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   69058:	66 4d 0f 38 f6 c7    	adcx   %r15,%r8
   6905e:	48 8b 56 38          	mov    0x38(%rsi),%rdx
   69062:	45 31 ff             	xor    %r15d,%r15d
   69065:	c4 e2 a3 f6 59 20    	mulx   0x20(%rcx),%r11,%rbx
   6906b:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   69071:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   69077:	c4 e2 a3 f6 59 28    	mulx   0x28(%rcx),%r11,%rbx
   6907d:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   69083:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   69089:	c4 e2 a3 f6 59 30    	mulx   0x30(%rcx),%r11,%rbx
   6908f:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   69095:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   6909b:	c4 e2 a3 f6 59 38    	mulx   0x38(%rcx),%r11,%rbx
   690a1:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   690a7:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   690ad:	66 4d 0f 38 f6 c7    	adcx   %r15,%r8
   690b3:	48 89 fa             	mov    %rdi,%rdx
   690b6:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   690bb:	45 31 ff             	xor    %r15d,%r15d
   690be:	c4 e2 a3 f6 59 40    	mulx   0x40(%rcx),%r11,%rbx
   690c4:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   690ca:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   690d0:	c4 e2 a3 f6 59 48    	mulx   0x48(%rcx),%r11,%rbx
   690d6:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   690dc:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   690e2:	c4 e2 a3 f6 59 50    	mulx   0x50(%rcx),%r11,%rbx
   690e8:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   690ee:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   690f4:	c4 e2 a3 f6 59 58    	mulx   0x58(%rcx),%r11,%rbx
   690fa:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   69100:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   69106:	66 4d 0f 38 f6 c7    	adcx   %r15,%r8
   6910c:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   69113:	8c 20 3c 
   69116:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   6911d:	95 7e 68 
   69120:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
   69127:	00 
   69128:	4c 89 84 24 f8 00 00 	mov    %r8,0xf8(%rsp)
   6912f:	00 
   69130:	4c 89 2c 24          	mov    %r13,(%rsp)
   69134:	4c 89 8c 24 b0 00 00 	mov    %r9,0xb0(%rsp)
   6913b:	00 
   6913c:	49 39 d5             	cmp    %rdx,%r13
   6913f:	4c 8d 1c 08          	lea    (%rax,%rcx,1),%r11
   69143:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   6914a:	6a 81 97 
   6914d:	49 83 db 00          	sbb    $0x0,%r11
   69151:	0f 92 c1             	setb   %cl
   69154:	48 39 d0             	cmp    %rdx,%rax
   69157:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   6915e:	ba af 47 
   69161:	4d 8d 3c 01          	lea    (%r9,%rax,1),%r15
   69165:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   6916c:	b1 9b cf 
   6916f:	0f 92 c2             	setb   %dl
   69172:	49 8d 1c 00          	lea    (%r8,%rax,1),%rbx
   69176:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   6917d:	00 
   6917e:	08 ca                	or     %cl,%dl
   69180:	0f b6 ca             	movzbl %dl,%ecx
   69183:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   6918a:	45 50 b8 
   6918d:	49 29 cf             	sub    %rcx,%r15
   69190:	0f 92 c1             	setb   %cl
   69193:	49 39 d1             	cmp    %rdx,%r9
   69196:	0f 92 c2             	setb   %dl
   69199:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   691a0:	00 
   691a1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   691a6:	08 ca                	or     %cl,%dl
   691a8:	0f b6 ca             	movzbl %dl,%ecx
   691ab:	48 29 cb             	sub    %rcx,%rbx
   691ae:	0f 92 84 24 b8 00 00 	setb   0xb8(%rsp)
   691b5:	00 
   691b6:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   691bd:	00 
   691be:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   691c3:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   691ca:	00 
   691cb:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   691d0:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   691d7:	00 
   691d8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   691dd:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
   691e4:	00 
   691e5:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   691ec:	00 
   691ed:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
   691f4:	00 
   691f5:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
   691fc:	00 
   691fd:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   69204:	00 
   69205:	48 8d 84 24 d0 03 00 	lea    0x3d0(%rsp),%rax
   6920c:	00 
   6920d:	4c 89 94 24 38 01 00 	mov    %r10,0x138(%rsp)
   69214:	00 
   69215:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
   6921c:	00 00 
   6921e:	c5 fc 10 10          	vmovups (%rax),%ymm2
   69222:	48 b8 b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rax
   69229:	73 df c3 
   6922c:	49 8d 4c 05 00       	lea    0x0(%r13,%rax,1),%rcx
   69231:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
   69238:	00 
   69239:	48 8d 8c 24 00 01 00 	lea    0x100(%rsp),%rcx
   69240:	00 
   69241:	c5 fc 11 54 24 50    	vmovups %ymm2,0x50(%rsp)
   69247:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
   6924c:	c5 fa 7f 4c 24 78    	vmovdqu %xmm1,0x78(%rsp)
   69252:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   69259:	00 00 00 00 00 
   6925e:	45 31 c0             	xor    %r8d,%r8d
   69261:	31 ff                	xor    %edi,%edi
   69263:	31 f6                	xor    %esi,%esi
   69265:	45 31 d2             	xor    %r10d,%r10d
   69268:	45 31 c9             	xor    %r9d,%r9d
   6926b:	48 8b 55 00          	mov    0x0(%rbp),%rdx
   6926f:	45 31 f6             	xor    %r14d,%r14d
   69272:	c4 62 9b f6 29       	mulx   (%rcx),%r12,%r13
   69277:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   6927d:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   69283:	c4 62 9b f6 69 08    	mulx   0x8(%rcx),%r12,%r13
   69289:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   6928f:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   69295:	c4 62 9b f6 69 10    	mulx   0x10(%rcx),%r12,%r13
   6929b:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   692a1:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   692a7:	c4 62 9b f6 69 18    	mulx   0x18(%rcx),%r12,%r13
   692ad:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   692b3:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   692b9:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   692bf:	48 8b 55 20          	mov    0x20(%rbp),%rdx
   692c3:	45 31 f6             	xor    %r14d,%r14d
   692c6:	c4 62 9b f6 69 20    	mulx   0x20(%rcx),%r12,%r13
   692cc:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   692d2:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   692d8:	c4 62 9b f6 69 28    	mulx   0x28(%rcx),%r12,%r13
   692de:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   692e4:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   692ea:	c4 62 9b f6 69 30    	mulx   0x30(%rcx),%r12,%r13
   692f0:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   692f6:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   692fc:	c4 62 9b f6 69 38    	mulx   0x38(%rcx),%r12,%r13
   69302:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   69308:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   6930e:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   69314:	4c 89 c2             	mov    %r8,%rdx
   69317:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   6931c:	45 31 f6             	xor    %r14d,%r14d
   6931f:	c4 62 9b f6 69 40    	mulx   0x40(%rcx),%r12,%r13
   69325:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   6932b:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   69331:	c4 62 9b f6 69 48    	mulx   0x48(%rcx),%r12,%r13
   69337:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   6933d:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   69343:	c4 62 9b f6 69 50    	mulx   0x50(%rcx),%r12,%r13
   69349:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   6934f:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69355:	c4 62 9b f6 69 58    	mulx   0x58(%rcx),%r12,%r13
   6935b:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   69361:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69367:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   6936d:	48 8b 55 08          	mov    0x8(%rbp),%rdx
   69371:	45 31 f6             	xor    %r14d,%r14d
   69374:	c4 62 9b f6 29       	mulx   (%rcx),%r12,%r13
   69379:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   6937f:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   69385:	c4 62 9b f6 69 08    	mulx   0x8(%rcx),%r12,%r13
   6938b:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   69391:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69397:	c4 62 9b f6 69 10    	mulx   0x10(%rcx),%r12,%r13
   6939d:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   693a3:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   693a9:	c4 62 9b f6 69 18    	mulx   0x18(%rcx),%r12,%r13
   693af:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   693b5:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   693bb:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   693c1:	48 8b 55 28          	mov    0x28(%rbp),%rdx
   693c5:	45 31 f6             	xor    %r14d,%r14d
   693c8:	c4 62 9b f6 69 20    	mulx   0x20(%rcx),%r12,%r13
   693ce:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   693d4:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   693da:	c4 62 9b f6 69 28    	mulx   0x28(%rcx),%r12,%r13
   693e0:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   693e6:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   693ec:	c4 62 9b f6 69 30    	mulx   0x30(%rcx),%r12,%r13
   693f2:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   693f8:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   693fe:	c4 62 9b f6 69 38    	mulx   0x38(%rcx),%r12,%r13
   69404:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   6940a:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69410:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   69416:	48 89 fa             	mov    %rdi,%rdx
   69419:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   6941e:	45 31 f6             	xor    %r14d,%r14d
   69421:	c4 62 9b f6 69 40    	mulx   0x40(%rcx),%r12,%r13
   69427:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   6942d:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   69433:	c4 62 9b f6 69 48    	mulx   0x48(%rcx),%r12,%r13
   69439:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   6943f:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69445:	c4 62 9b f6 69 50    	mulx   0x50(%rcx),%r12,%r13
   6944b:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   69451:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69457:	c4 62 9b f6 69 58    	mulx   0x58(%rcx),%r12,%r13
   6945d:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   69463:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69469:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   6946f:	48 8b 55 10          	mov    0x10(%rbp),%rdx
   69473:	45 31 f6             	xor    %r14d,%r14d
   69476:	c4 62 9b f6 29       	mulx   (%rcx),%r12,%r13
   6947b:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   69481:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69487:	c4 62 9b f6 69 08    	mulx   0x8(%rcx),%r12,%r13
   6948d:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   69493:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69499:	c4 62 9b f6 69 10    	mulx   0x10(%rcx),%r12,%r13
   6949f:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   694a5:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   694ab:	c4 62 9b f6 69 18    	mulx   0x18(%rcx),%r12,%r13
   694b1:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   694b7:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   694bd:	66 49 0f 38 f6 fe    	adcx   %r14,%rdi
   694c3:	48 8b 55 30          	mov    0x30(%rbp),%rdx
   694c7:	45 31 f6             	xor    %r14d,%r14d
   694ca:	c4 62 9b f6 69 20    	mulx   0x20(%rcx),%r12,%r13
   694d0:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   694d6:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   694dc:	c4 62 9b f6 69 28    	mulx   0x28(%rcx),%r12,%r13
   694e2:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   694e8:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   694ee:	c4 62 9b f6 69 30    	mulx   0x30(%rcx),%r12,%r13
   694f4:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   694fa:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69500:	c4 62 9b f6 69 38    	mulx   0x38(%rcx),%r12,%r13
   69506:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   6950c:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   69512:	66 49 0f 38 f6 fe    	adcx   %r14,%rdi
   69518:	48 89 f2             	mov    %rsi,%rdx
   6951b:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   69520:	45 31 f6             	xor    %r14d,%r14d
   69523:	c4 62 9b f6 69 40    	mulx   0x40(%rcx),%r12,%r13
   69529:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   6952f:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69535:	c4 62 9b f6 69 48    	mulx   0x48(%rcx),%r12,%r13
   6953b:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   69541:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69547:	c4 62 9b f6 69 50    	mulx   0x50(%rcx),%r12,%r13
   6954d:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   69553:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69559:	c4 62 9b f6 69 58    	mulx   0x58(%rcx),%r12,%r13
   6955f:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   69565:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   6956b:	66 49 0f 38 f6 fe    	adcx   %r14,%rdi
   69571:	48 8b 55 18          	mov    0x18(%rbp),%rdx
   69575:	45 31 f6             	xor    %r14d,%r14d
   69578:	c4 62 9b f6 29       	mulx   (%rcx),%r12,%r13
   6957d:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   69583:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69589:	c4 62 9b f6 69 08    	mulx   0x8(%rcx),%r12,%r13
   6958f:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   69595:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   6959b:	c4 62 9b f6 69 10    	mulx   0x10(%rcx),%r12,%r13
   695a1:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   695a7:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   695ad:	c4 62 9b f6 69 18    	mulx   0x18(%rcx),%r12,%r13
   695b3:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   695b9:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   695bf:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   695c5:	48 8b 55 38          	mov    0x38(%rbp),%rdx
   695c9:	45 31 f6             	xor    %r14d,%r14d
   695cc:	c4 62 9b f6 69 20    	mulx   0x20(%rcx),%r12,%r13
   695d2:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   695d8:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   695de:	c4 62 9b f6 69 28    	mulx   0x28(%rcx),%r12,%r13
   695e4:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   695ea:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   695f0:	c4 62 9b f6 69 30    	mulx   0x30(%rcx),%r12,%r13
   695f6:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   695fc:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   69602:	c4 62 9b f6 69 38    	mulx   0x38(%rcx),%r12,%r13
   69608:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   6960e:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   69614:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   6961a:	4c 89 d2             	mov    %r10,%rdx
   6961d:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   69622:	45 31 f6             	xor    %r14d,%r14d
   69625:	c4 62 9b f6 69 40    	mulx   0x40(%rcx),%r12,%r13
   6962b:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   69631:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69637:	c4 62 9b f6 69 48    	mulx   0x48(%rcx),%r12,%r13
   6963d:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   69643:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69649:	c4 62 9b f6 69 50    	mulx   0x50(%rcx),%r12,%r13
   6964f:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   69655:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   6965b:	c4 62 9b f6 69 58    	mulx   0x58(%rcx),%r12,%r13
   69661:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   69667:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   6966d:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   69673:	49 be 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%r14
   6967a:	95 7e 68 
   6967d:	4c 01 c8             	add    %r9,%rax
   69680:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   69687:	8c 20 3c 
   6968a:	49 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%r10
   69691:	6a 81 97 
   69694:	49 bc a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%r12
   6969b:	ba af 47 
   6969e:	49 bd d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%r13
   696a5:	b1 9b cf 
   696a8:	48 bd 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rbp
   696af:	4e 64 30 
   696b2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   696b7:	31 c0                	xor    %eax,%eax
   696b9:	4d 01 c6             	add    %r8,%r14
   696bc:	49 39 d1             	cmp    %rdx,%r9
   696bf:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   696c6:	00 
   696c7:	c5 fe 6f 84 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm0
   696ce:	00 00 
   696d0:	49 83 de 00          	sbb    $0x0,%r14
   696d4:	0f 92 c2             	setb   %dl
   696d7:	4d 39 d0             	cmp    %r10,%r8
   696da:	41 0f 92 c2          	setb   %r10b
   696de:	49 01 fc             	add    %rdi,%r12
   696e1:	41 08 d2             	or     %dl,%r10b
   696e4:	41 0f b6 d2          	movzbl %r10b,%edx
   696e8:	49 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%r10
   696ef:	45 50 b8 
   696f2:	49 29 d4             	sub    %rdx,%r12
   696f5:	0f 92 c2             	setb   %dl
   696f8:	4c 39 d7             	cmp    %r10,%rdi
   696fb:	41 0f 92 c2          	setb   %r10b
   696ff:	49 01 f5             	add    %rsi,%r13
   69702:	41 08 d2             	or     %dl,%r10b
   69705:	41 0f b6 d2          	movzbl %r10b,%edx
   69709:	49 29 d5             	sub    %rdx,%r13
   6970c:	0f 92 c2             	setb   %dl
   6970f:	48 39 ee             	cmp    %rbp,%rsi
   69712:	41 0f 92 c2          	setb   %r10b
   69716:	41 08 d2             	or     %dl,%r10b
   69719:	48 39 e9             	cmp    %rbp,%rcx
   6971c:	48 8b ac 24 a8 00 00 	mov    0xa8(%rsp),%rbp
   69723:	00 
   69724:	0f 92 c2             	setb   %dl
   69727:	0a 94 24 b8 00 00 00 	or     0xb8(%rsp),%dl
   6972e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   69733:	48 0f 45 2c 24       	cmovne (%rsp),%rbp
   69738:	4c 0f 45 9c 24 e8 00 	cmovne 0xe8(%rsp),%r11
   6973f:	00 00 
   69741:	4c 0f 45 bc 24 b0 00 	cmovne 0xb0(%rsp),%r15
   69748:	00 00 
   6974a:	48 0f 45 d9          	cmovne %rcx,%rbx
   6974e:	45 84 d2             	test   %r10b,%r10b
   69751:	49 0f 45 d1          	cmovne %r9,%rdx
   69755:	4d 0f 45 f0          	cmovne %r8,%r14
   69759:	4c 0f 45 e7          	cmovne %rdi,%r12
   6975d:	4c 0f 45 ee          	cmovne %rsi,%r13
   69761:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
   69766:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
   6976b:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
   69770:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
   69775:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   6977a:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
   6977f:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
   69784:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
   69789:	c5 fd ef 44 24 30    	vpxor  0x30(%rsp),%ymm0,%ymm0
   6978f:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   69794:	0f 85 0f d1 ff ff    	jne    668a9 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2d39>
   6979a:	c5 fe 6f 84 24 00 02 	vmovdqu 0x200(%rsp),%ymm0
   697a1:	00 00 
   697a3:	c5 fd ef 44 24 50    	vpxor  0x50(%rsp),%ymm0,%ymm0
   697a9:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   697ae:	0f 94 c0             	sete   %al
   697b1:	e9 f3 d0 ff ff       	jmp    668a9 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2d39>
   697b6:	b0 01                	mov    $0x1,%al
   697b8:	e9 ec d0 ff ff       	jmp    668a9 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2d39>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
