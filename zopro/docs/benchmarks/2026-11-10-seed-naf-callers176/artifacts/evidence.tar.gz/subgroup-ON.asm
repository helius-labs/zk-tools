
/home/ubuntu/src/zopro-perf-work/seed-naf-callers176/bench-ON:     file format elf64-x86-64


Disassembly of section .text:

0000000000063b70 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup>:
   63b70:	55                   	push   %rbp
   63b71:	41 57                	push   %r15
   63b73:	41 56                	push   %r14
   63b75:	41 55                	push   %r13
   63b77:	41 54                	push   %r12
   63b79:	53                   	push   %rbx
   63b7a:	48 81 ec 18 07 00 00 	sub    $0x718,%rsp
   63b81:	c5 fe 6f 07          	vmovdqu (%rdi),%ymm0
   63b85:	48 89 fb             	mov    %rdi,%rbx
   63b88:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63b8d:	0f 95 c1             	setne  %cl
   63b90:	75 28                	jne    63bba <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x4a>
   63b92:	c5 fe 6f 43 20       	vmovdqu 0x20(%rbx),%ymm0
   63b97:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63b9c:	75 1c                	jne    63bba <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x4a>
   63b9e:	c5 fe 6f 43 40       	vmovdqu 0x40(%rbx),%ymm0
   63ba3:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63ba8:	75 10                	jne    63bba <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x4a>
   63baa:	c5 fe 6f 43 60       	vmovdqu 0x60(%rbx),%ymm0
   63baf:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63bb4:	0f 84 d6 5d 00 00    	je     69990 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x5e20>
   63bba:	c5 fc 10 43 40       	vmovups 0x40(%rbx),%ymm0
   63bbf:	c5 fc 10 0d 79 24 fa 	vmovups -0x5db87(%rip),%ymm1        # 6040 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x5a0>
   63bc6:	ff 
   63bc7:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   63bce:	00 
   63bcf:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
   63bd6:	00 
   63bd7:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
   63bde:	00 
   63bdf:	31 c0                	xor    %eax,%eax
   63be1:	31 d2                	xor    %edx,%edx
   63be3:	45 31 d2             	xor    %r10d,%r10d
   63be6:	45 31 db             	xor    %r11d,%r11d
   63be9:	4c 8d 8c 24 d0 04 00 	lea    0x4d0(%rsp),%r9
   63bf0:	00 
   63bf1:	c5 fc 11 84 24 50 02 	vmovups %ymm0,0x250(%rsp)
   63bf8:	00 00 
   63bfa:	c5 fc 11 8c 24 d0 04 	vmovups %ymm1,0x4d0(%rsp)
   63c01:	00 00 
   63c03:	48 2b 06             	sub    (%rsi),%rax
   63c06:	48 1b 56 08          	sbb    0x8(%rsi),%rdx
   63c0a:	4c 1b 56 10          	sbb    0x10(%rsi),%r10
   63c0e:	4c 1b 5e 18          	sbb    0x18(%rsi),%r11
   63c12:	4d 19 ed             	sbb    %r13,%r13
   63c15:	48 8b 2f             	mov    (%rdi),%rbp
   63c18:	4c 8b 77 08          	mov    0x8(%rdi),%r14
   63c1c:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
   63c20:	4c 8b 67 18          	mov    0x18(%rdi),%r12
   63c24:	4c 21 ed             	and    %r13,%rbp
   63c27:	4d 21 ee             	and    %r13,%r14
   63c2a:	4d 21 ef             	and    %r13,%r15
   63c2d:	4d 21 ec             	and    %r13,%r12
   63c30:	48 01 e8             	add    %rbp,%rax
   63c33:	4c 11 f2             	adc    %r14,%rdx
   63c36:	4d 11 fa             	adc    %r15,%r10
   63c39:	4d 11 e3             	adc    %r12,%r11
   63c3c:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
   63c43:	00 
   63c44:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   63c4b:	00 
   63c4c:	c5 fc 11 8c 24 d0 04 	vmovups %ymm1,0x4d0(%rsp)
   63c53:	00 00 
   63c55:	88 8c 24 b8 00 00 00 	mov    %cl,0xb8(%rsp)
   63c5c:	45 31 f6             	xor    %r14d,%r14d
   63c5f:	45 31 ff             	xor    %r15d,%r15d
   63c62:	45 31 e4             	xor    %r12d,%r12d
   63c65:	48 8d 94 24 50 02 00 	lea    0x250(%rsp),%rdx
   63c6c:	00 
   63c6d:	31 c0                	xor    %eax,%eax
   63c6f:	c5 fc 10 43 60       	vmovups 0x60(%rbx),%ymm0
   63c74:	4c 8b 04 24          	mov    (%rsp),%r8
   63c78:	c5 fc 11 84 24 50 02 	vmovups %ymm0,0x250(%rsp)
   63c7f:	00 00 
   63c81:	4c 2b 32             	sub    (%rdx),%r14
   63c84:	4c 1b 7a 08          	sbb    0x8(%rdx),%r15
   63c88:	4c 1b 62 10          	sbb    0x10(%rdx),%r12
   63c8c:	4c 1b 42 18          	sbb    0x18(%rdx),%r8
   63c90:	48 19 ff             	sbb    %rdi,%rdi
   63c93:	49 8b 29             	mov    (%r9),%rbp
   63c96:	4d 8b 69 08          	mov    0x8(%r9),%r13
   63c9a:	49 8b 49 10          	mov    0x10(%r9),%rcx
   63c9e:	49 8b 71 18          	mov    0x18(%r9),%rsi
   63ca2:	48 21 fd             	and    %rdi,%rbp
   63ca5:	49 21 fd             	and    %rdi,%r13
   63ca8:	48 21 f9             	and    %rdi,%rcx
   63cab:	48 21 fe             	and    %rdi,%rsi
   63cae:	49 01 ee             	add    %rbp,%r14
   63cb1:	4d 11 ef             	adc    %r13,%r15
   63cb4:	49 11 cc             	adc    %rcx,%r12
   63cb7:	49 11 f0             	adc    %rsi,%r8
   63cba:	4c 89 04 24          	mov    %r8,(%rsp)
   63cbe:	62 f1 fe 48 6f 03    	vmovdqu64 (%rbx),%zmm0
   63cc4:	0f b6 b4 24 b8 00 00 	movzbl 0xb8(%rsp),%esi
   63ccb:	00 
   63ccc:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
   63cd3:	00 
   63cd4:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
   63cdb:	00 
   63cdc:	48 8b 14 24          	mov    (%rsp),%rdx
   63ce0:	40 88 f0             	mov    %sil,%al
   63ce3:	62 f1 fe 48 7f 84 24 	vmovdqu64 %zmm0,0x250(%rsp)
   63cea:	50 02 00 00 
   63cee:	48 89 8c 24 90 02 00 	mov    %rcx,0x290(%rsp)
   63cf5:	00 
   63cf6:	48 8d 4b 40          	lea    0x40(%rbx),%rcx
   63cfa:	48 89 bc 24 98 02 00 	mov    %rdi,0x298(%rsp)
   63d01:	00 
   63d02:	4c 89 94 24 a0 02 00 	mov    %r10,0x2a0(%rsp)
   63d09:	00 
   63d0a:	4c 89 9c 24 a8 02 00 	mov    %r11,0x2a8(%rsp)
   63d11:	00 
   63d12:	4c 89 b4 24 b0 02 00 	mov    %r14,0x2b0(%rsp)
   63d19:	00 
   63d1a:	4c 89 bc 24 b8 02 00 	mov    %r15,0x2b8(%rsp)
   63d21:	00 
   63d22:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
   63d29:	00 
   63d2a:	48 89 94 24 c8 02 00 	mov    %rdx,0x2c8(%rsp)
   63d31:	00 
   63d32:	85 c0                	test   %eax,%eax
   63d34:	75 2a                	jne    63d60 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x1f0>
   63d36:	c5 fe 6f 43 20       	vmovdqu 0x20(%rbx),%ymm0
   63d3b:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63d40:	75 1e                	jne    63d60 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x1f0>
   63d42:	c5 fe 6f 01          	vmovdqu (%rcx),%ymm0
   63d46:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63d4b:	75 13                	jne    63d60 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x1f0>
   63d4d:	48 8d 43 60          	lea    0x60(%rbx),%rax
   63d51:	c5 fe 6f 00          	vmovdqu (%rax),%ymm0
   63d55:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63d5a:	0f 84 37 5c 00 00    	je     69997 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x5e27>
   63d60:	62 f1 7c 48 10 01    	vmovups (%rcx),%zmm0
   63d66:	62 f1 7c 48 10 13    	vmovups (%rbx),%zmm2
   63d6c:	62 f1 7c 48 10 0d ca 	vmovups -0x53736(%rip),%zmm1        # 10640 <zmij::STATIC_DATA+0x4540>
   63d73:	c8 fa ff 
   63d76:	62 f1 7c 48 11 84 24 	vmovups %zmm0,0x390(%rsp)
   63d7d:	90 03 00 00 
   63d81:	62 f1 7c 48 11 94 24 	vmovups %zmm2,0x350(%rsp)
   63d88:	50 03 00 00 
   63d8c:	62 f1 7c 48 11 8c 24 	vmovups %zmm1,0x3d0(%rsp)
   63d93:	d0 03 00 00 
   63d97:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   63d9d:	4c 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%r14
   63da4:	00 
   63da5:	4c 8d bc 24 50 03 00 	lea    0x350(%rsp),%r15
   63dac:	00 
   63dad:	49 bc 01 0a 89 4a 04 	movabs $0x450a14044a890a01,%r12
   63db4:	14 0a 45 
   63db7:	48 bd 10 00 20 00 50 	movabs $0x20815000200010,%rbp
   63dbe:	81 20 00 
   63dc1:	eb 6d                	jmp    63e30 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2c0>
   63dc3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   63dca:	84 00 00 00 00 00 
   63dd0:	4c 89 f7             	mov    %r14,%rdi
   63dd3:	4c 89 fe             	mov    %r15,%rsi
   63dd6:	48 89 da             	mov    %rbx,%rdx
   63dd9:	c5 f8 77             	vzeroupper
   63ddc:	e8 2f b1 00 00       	call   6ef10 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::add_affine>
   63de1:	62 f1 7c 48 10 84 24 	vmovups 0x4d0(%rsp),%zmm0
   63de8:	d0 04 00 00 
   63dec:	62 f1 7c 48 10 8c 24 	vmovups 0x510(%rsp),%zmm1
   63df3:	10 05 00 00 
   63df7:	62 f1 7c 48 10 94 24 	vmovups 0x550(%rsp),%zmm2
   63dfe:	50 05 00 00 
   63e02:	62 f1 7c 48 11 94 24 	vmovups %zmm2,0x3d0(%rsp)
   63e09:	d0 03 00 00 
   63e0d:	62 f1 7c 48 11 8c 24 	vmovups %zmm1,0x390(%rsp)
   63e14:	90 03 00 00 
   63e18:	62 f1 7c 48 11 84 24 	vmovups %zmm0,0x350(%rsp)
   63e1f:	50 03 00 00 
   63e23:	49 ff cd             	dec    %r13
   63e26:	49 83 fd 01          	cmp    $0x1,%r13
   63e2a:	0f 86 83 00 00 00    	jbe    63eb3 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x343>
   63e30:	4c 89 f7             	mov    %r14,%rdi
   63e33:	4c 89 fe             	mov    %r15,%rsi
   63e36:	c5 f8 77             	vzeroupper
   63e39:	e8 a2 5b 00 00       	call   699e0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::double>
   63e3e:	62 f1 7c 48 10 84 24 	vmovups 0x4d0(%rsp),%zmm0
   63e45:	d0 04 00 00 
   63e49:	62 f1 7c 48 10 8c 24 	vmovups 0x510(%rsp),%zmm1
   63e50:	10 05 00 00 
   63e54:	62 f1 7c 48 10 94 24 	vmovups 0x550(%rsp),%zmm2
   63e5b:	50 05 00 00 
   63e5f:	41 8d 45 fe          	lea    -0x2(%r13),%eax
   63e63:	0f b6 c8             	movzbl %al,%ecx
   63e66:	49 0f a3 cc          	bt     %rcx,%r12
   63e6a:	62 f1 7c 48 11 94 24 	vmovups %zmm2,0x3d0(%rsp)
   63e71:	d0 03 00 00 
   63e75:	62 f1 7c 48 11 8c 24 	vmovups %zmm1,0x390(%rsp)
   63e7c:	90 03 00 00 
   63e80:	62 f1 7c 48 11 84 24 	vmovups %zmm0,0x350(%rsp)
   63e87:	50 03 00 00 
   63e8b:	0f 82 3f ff ff ff    	jb     63dd0 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x260>
   63e91:	b9 01 00 00 00       	mov    $0x1,%ecx
   63e96:	c4 e2 f9 f7 c1       	shlx   %rax,%rcx,%rax
   63e9b:	48 85 e8             	test   %rbp,%rax
   63e9e:	74 83                	je     63e23 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2b3>
   63ea0:	48 8d 94 24 50 02 00 	lea    0x250(%rsp),%rdx
   63ea7:	00 
   63ea8:	4c 89 f7             	mov    %r14,%rdi
   63eab:	4c 89 fe             	mov    %r15,%rsi
   63eae:	e9 26 ff ff ff       	jmp    63dd9 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x269>
   63eb3:	4c 8d b4 24 98 05 00 	lea    0x598(%rsp),%r14
   63eba:	00 
   63ebb:	4c 8d bc 24 50 03 00 	lea    0x350(%rsp),%r15
   63ec2:	00 
   63ec3:	4c 89 f7             	mov    %r14,%rdi
   63ec6:	4c 89 fe             	mov    %r15,%rsi
   63ec9:	c5 f8 77             	vzeroupper
   63ecc:	e8 5f 3e 01 00       	call   77d30 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::psi>
   63ed1:	4c 8d a4 24 58 06 00 	lea    0x658(%rsp),%r12
   63ed8:	00 
   63ed9:	4c 89 f6             	mov    %r14,%rsi
   63edc:	4c 89 e7             	mov    %r12,%rdi
   63edf:	e8 4c 3e 01 00       	call   77d30 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::psi>
   63ee4:	4c 8d ac 24 d0 04 00 	lea    0x4d0(%rsp),%r13
   63eeb:	00 
   63eec:	4c 89 fe             	mov    %r15,%rsi
   63eef:	48 89 da             	mov    %rbx,%rdx
   63ef2:	4c 89 ef             	mov    %r13,%rdi
   63ef5:	e8 16 b0 00 00       	call   6ef10 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::add_affine>
   63efa:	48 8d 9c 24 50 02 00 	lea    0x250(%rsp),%rbx
   63f01:	00 
   63f02:	4c 89 ee             	mov    %r13,%rsi
   63f05:	4c 89 f2             	mov    %r14,%rdx
   63f08:	48 89 df             	mov    %rbx,%rdi
   63f0b:	e8 00 57 01 00       	call   79610 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::add_projective>
   63f10:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
   63f17:	00 
   63f18:	48 89 de             	mov    %rbx,%rsi
   63f1b:	4c 89 e2             	mov    %r12,%rdx
   63f1e:	e8 ed 56 01 00       	call   79610 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::add_projective>
   63f23:	48 8d 9c 24 d0 04 00 	lea    0x4d0(%rsp),%rbx
   63f2a:	00 
   63f2b:	4c 89 e6             	mov    %r12,%rsi
   63f2e:	48 89 df             	mov    %rbx,%rdi
   63f31:	e8 fa 3d 01 00       	call   77d30 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::psi>
   63f36:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   63f3d:	00 
   63f3e:	48 89 de             	mov    %rbx,%rsi
   63f41:	e8 9a 5a 00 00       	call   699e0 <<zopro_bn254::curve::Projective<zopro_bn254::curve::G2Config>>::double>
   63f46:	c5 fe 6f 84 24 90 04 	vmovdqu 0x490(%rsp),%ymm0
   63f4d:	00 00 
   63f4f:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63f54:	74 21                	je     63f77 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x407>
   63f56:	31 c0                	xor    %eax,%eax
   63f58:	c5 fe 6f 84 24 d0 02 	vmovdqu 0x2d0(%rsp),%ymm0
   63f5f:	00 00 
   63f61:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63f66:	74 30                	je     63f98 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x428>
   63f68:	31 c9                	xor    %ecx,%ecx
   63f6a:	89 c2                	mov    %eax,%edx
   63f6c:	08 ca                	or     %cl,%dl
   63f6e:	74 3f                	je     63faf <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x43f>
   63f70:	20 c8                	and    %cl,%al
   63f72:	e9 03 2b 00 00       	jmp    66a7a <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2f0a>
   63f77:	c5 fe 6f 84 24 b0 04 	vmovdqu 0x4b0(%rsp),%ymm0
   63f7e:	00 00 
   63f80:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63f85:	0f 94 c0             	sete   %al
   63f88:	c5 fe 6f 84 24 d0 02 	vmovdqu 0x2d0(%rsp),%ymm0
   63f8f:	00 00 
   63f91:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63f96:	75 d0                	jne    63f68 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x3f8>
   63f98:	c5 fe 6f 84 24 f0 02 	vmovdqu 0x2f0(%rsp),%ymm0
   63f9f:	00 00 
   63fa1:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   63fa6:	0f 94 c1             	sete   %cl
   63fa9:	89 c2                	mov    %eax,%edx
   63fab:	08 ca                	or     %cl,%dl
   63fad:	75 c1                	jne    63f70 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x400>
   63faf:	c5 fc 10 84 24 b0 04 	vmovups 0x4b0(%rsp),%ymm0
   63fb6:	00 00 
   63fb8:	c5 fc 10 15 80 20 fa 	vmovups -0x5df80(%rip),%ymm2        # 6040 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x5a0>
   63fbf:	ff 
   63fc0:	48 8b 84 24 90 04 00 	mov    0x490(%rsp),%rax
   63fc7:	00 
   63fc8:	48 8b 8c 24 98 04 00 	mov    0x498(%rsp),%rcx
   63fcf:	00 
   63fd0:	4c 8b 94 24 a0 04 00 	mov    0x4a0(%rsp),%r10
   63fd7:	00 
   63fd8:	4c 8b 9c 24 a8 04 00 	mov    0x4a8(%rsp),%r11
   63fdf:	00 
   63fe0:	4c 8d 7c 24 30       	lea    0x30(%rsp),%r15
   63fe5:	49 be 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r14
   63fec:	07 d2 87 
   63fef:	4c 8d 84 24 e0 01 00 	lea    0x1e0(%rsp),%r8
   63ff6:	00 
   63ff7:	4c 8d 8c 24 60 01 00 	lea    0x160(%rsp),%r9
   63ffe:	00 
   63fff:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
   64006:	00 
   64007:	48 89 8c 24 e8 01 00 	mov    %rcx,0x1e8(%rsp)
   6400e:	00 
   6400f:	4c 89 94 24 f0 01 00 	mov    %r10,0x1f0(%rsp)
   64016:	00 
   64017:	48 89 04 24          	mov    %rax,(%rsp)
   6401b:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
   64022:	00 
   64023:	4c 89 9c 24 f8 01 00 	mov    %r11,0x1f8(%rsp)
   6402a:	00 
   6402b:	c5 fc 11 84 24 00 01 	vmovups %ymm0,0x100(%rsp)
   64032:	00 00 
   64034:	c5 fc 11 84 24 60 01 	vmovups %ymm0,0x160(%rsp)
   6403b:	00 00 
   6403d:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   64043:	31 c0                	xor    %eax,%eax
   64045:	31 f6                	xor    %esi,%esi
   64047:	31 db                	xor    %ebx,%ebx
   64049:	45 31 e4             	xor    %r12d,%r12d
   6404c:	31 ff                	xor    %edi,%edi
   6404e:	49 8b 11             	mov    (%r9),%rdx
   64051:	31 c9                	xor    %ecx,%ecx
   64053:	c4 42 d3 f6 28       	mulx   (%r8),%rbp,%r13
   64058:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   6405e:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   64064:	c4 42 d3 f6 68 08    	mulx   0x8(%r8),%rbp,%r13
   6406a:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   64070:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   64076:	c4 42 d3 f6 68 10    	mulx   0x10(%r8),%rbp,%r13
   6407c:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   64082:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   64088:	c4 42 d3 f6 68 18    	mulx   0x18(%r8),%rbp,%r13
   6408e:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64094:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   6409a:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   640a0:	48 89 c2             	mov    %rax,%rdx
   640a3:	49 0f af d6          	imul   %r14,%rdx
   640a7:	31 c9                	xor    %ecx,%ecx
   640a9:	c4 42 d3 f6 2f       	mulx   (%r15),%rbp,%r13
   640ae:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   640b4:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   640ba:	c4 42 d3 f6 6f 08    	mulx   0x8(%r15),%rbp,%r13
   640c0:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   640c6:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   640cc:	c4 42 d3 f6 6f 10    	mulx   0x10(%r15),%rbp,%r13
   640d2:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   640d8:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   640de:	c4 42 d3 f6 6f 18    	mulx   0x18(%r15),%rbp,%r13
   640e4:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   640ea:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   640f0:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   640f6:	49 8b 51 08          	mov    0x8(%r9),%rdx
   640fa:	31 c9                	xor    %ecx,%ecx
   640fc:	c4 42 d3 f6 28       	mulx   (%r8),%rbp,%r13
   64101:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   64107:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   6410d:	c4 42 d3 f6 68 08    	mulx   0x8(%r8),%rbp,%r13
   64113:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   64119:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   6411f:	c4 42 d3 f6 68 10    	mulx   0x10(%r8),%rbp,%r13
   64125:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   6412b:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   64131:	c4 42 d3 f6 68 18    	mulx   0x18(%r8),%rbp,%r13
   64137:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6413d:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   64143:	66 48 0f 38 f6 c1    	adcx   %rcx,%rax
   64149:	48 89 f2             	mov    %rsi,%rdx
   6414c:	49 0f af d6          	imul   %r14,%rdx
   64150:	31 c9                	xor    %ecx,%ecx
   64152:	c4 42 d3 f6 2f       	mulx   (%r15),%rbp,%r13
   64157:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   6415d:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   64163:	c4 42 d3 f6 6f 08    	mulx   0x8(%r15),%rbp,%r13
   64169:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   6416f:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   64175:	c4 42 d3 f6 6f 10    	mulx   0x10(%r15),%rbp,%r13
   6417b:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64181:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   64187:	c4 42 d3 f6 6f 18    	mulx   0x18(%r15),%rbp,%r13
   6418d:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   64193:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   64199:	66 48 0f 38 f6 c1    	adcx   %rcx,%rax
   6419f:	49 8b 51 10          	mov    0x10(%r9),%rdx
   641a3:	31 c9                	xor    %ecx,%ecx
   641a5:	c4 42 d3 f6 28       	mulx   (%r8),%rbp,%r13
   641aa:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   641b0:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   641b6:	c4 42 d3 f6 68 08    	mulx   0x8(%r8),%rbp,%r13
   641bc:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   641c2:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   641c8:	c4 42 d3 f6 68 10    	mulx   0x10(%r8),%rbp,%r13
   641ce:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   641d4:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   641da:	c4 42 d3 f6 68 18    	mulx   0x18(%r8),%rbp,%r13
   641e0:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   641e6:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   641ec:	66 48 0f 38 f6 f1    	adcx   %rcx,%rsi
   641f2:	48 89 da             	mov    %rbx,%rdx
   641f5:	49 0f af d6          	imul   %r14,%rdx
   641f9:	31 c9                	xor    %ecx,%ecx
   641fb:	c4 42 d3 f6 2f       	mulx   (%r15),%rbp,%r13
   64200:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   64206:	f3 4d 0f 38 f6 e5    	adox   %r13,%r12
   6420c:	c4 42 d3 f6 6f 08    	mulx   0x8(%r15),%rbp,%r13
   64212:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64218:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   6421e:	c4 42 d3 f6 6f 10    	mulx   0x10(%r15),%rbp,%r13
   64224:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6422a:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   64230:	c4 42 d3 f6 6f 18    	mulx   0x18(%r15),%rbp,%r13
   64236:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   6423c:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   64242:	66 48 0f 38 f6 f1    	adcx   %rcx,%rsi
   64248:	49 8b 51 18          	mov    0x18(%r9),%rdx
   6424c:	31 c9                	xor    %ecx,%ecx
   6424e:	c4 42 d3 f6 28       	mulx   (%r8),%rbp,%r13
   64253:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64259:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   6425f:	c4 42 d3 f6 68 08    	mulx   0x8(%r8),%rbp,%r13
   64265:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6426b:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   64271:	c4 42 d3 f6 68 10    	mulx   0x10(%r8),%rbp,%r13
   64277:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   6427d:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   64283:	c4 42 d3 f6 68 18    	mulx   0x18(%r8),%rbp,%r13
   64289:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   6428f:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   64295:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   6429b:	4c 89 e2             	mov    %r12,%rdx
   6429e:	49 0f af d6          	imul   %r14,%rdx
   642a2:	31 c9                	xor    %ecx,%ecx
   642a4:	c4 42 d3 f6 2f       	mulx   (%r15),%rbp,%r13
   642a9:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   642af:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   642b5:	c4 42 d3 f6 6f 08    	mulx   0x8(%r15),%rbp,%r13
   642bb:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   642c1:	f3 49 0f 38 f6 c5    	adox   %r13,%rax
   642c7:	c4 42 d3 f6 6f 10    	mulx   0x10(%r15),%rbp,%r13
   642cd:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   642d3:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   642d9:	c4 42 d3 f6 6f 18    	mulx   0x18(%r15),%rbp,%r13
   642df:	66 48 0f 38 f6 f5    	adcx   %rbp,%rsi
   642e5:	f3 49 0f 38 f6 dd    	adox   %r13,%rbx
   642eb:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   642f1:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   642f8:	95 7e 68 
   642fb:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   64302:	8c 20 3c 
   64305:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   6430a:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   6430f:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   64314:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
   64319:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   6431f:	4d 89 df             	mov    %r11,%r15
   64322:	4d 89 d5             	mov    %r10,%r13
   64325:	48 39 d7             	cmp    %rdx,%rdi
   64328:	48 8d 0c 08          	lea    (%rax,%rcx,1),%rcx
   6432c:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   64333:	6a 81 97 
   64336:	c5 fc 10 84 24 b0 04 	vmovups 0x4b0(%rsp),%ymm0
   6433d:	00 00 
   6433f:	4c 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%r9
   64346:	00 
   64347:	4c 8b 04 24          	mov    (%rsp),%r8
   6434b:	48 83 d9 00          	sbb    $0x0,%rcx
   6434f:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
   64356:	00 
   64357:	0f 92 c1             	setb   %cl
   6435a:	48 39 d0             	cmp    %rdx,%rax
   6435d:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   64364:	ba af 47 
   64367:	0f 92 c2             	setb   %dl
   6436a:	48 01 f0             	add    %rsi,%rax
   6436d:	08 ca                	or     %cl,%dl
   6436f:	0f b6 ca             	movzbl %dl,%ecx
   64372:	4d 89 ce             	mov    %r9,%r14
   64375:	4d 89 c4             	mov    %r8,%r12
   64378:	48 29 c8             	sub    %rcx,%rax
   6437b:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
   64382:	00 
   64383:	48 b8 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rax
   6438a:	45 50 b8 
   6438d:	0f 92 c1             	setb   %cl
   64390:	48 39 c6             	cmp    %rax,%rsi
   64393:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   6439a:	b1 9b cf 
   6439d:	c5 fc 11 84 24 60 01 	vmovups %ymm0,0x160(%rsp)
   643a4:	00 00 
   643a6:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   643ab:	0f 92 c2             	setb   %dl
   643ae:	08 ca                	or     %cl,%dl
   643b0:	0f b6 ca             	movzbl %dl,%ecx
   643b3:	48 8d 14 03          	lea    (%rbx,%rax,1),%rdx
   643b7:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   643be:	00 
   643bf:	48 29 ca             	sub    %rcx,%rdx
   643c2:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
   643c9:	00 
   643ca:	0f 92 84 24 98 00 00 	setb   0x98(%rsp)
   643d1:	00 
   643d2:	4c 03 20             	add    (%rax),%r12
   643d5:	4c 13 70 08          	adc    0x8(%rax),%r14
   643d9:	4c 13 68 10          	adc    0x10(%rax),%r13
   643dd:	4c 13 78 18          	adc    0x18(%rax),%r15
   643e1:	4c 89 e5             	mov    %r12,%rbp
   643e4:	4c 89 f3             	mov    %r14,%rbx
   643e7:	4c 89 e9             	mov    %r13,%rcx
   643ea:	4c 89 fa             	mov    %r15,%rdx
   643ed:	48 2b 2e             	sub    (%rsi),%rbp
   643f0:	48 1b 5e 08          	sbb    0x8(%rsi),%rbx
   643f4:	48 1b 4e 10          	sbb    0x10(%rsi),%rcx
   643f8:	48 1b 56 18          	sbb    0x18(%rsi),%rdx
   643fc:	4c 0f 43 e5          	cmovae %rbp,%r12
   64400:	4c 0f 43 f3          	cmovae %rbx,%r14
   64404:	4c 0f 43 e9          	cmovae %rcx,%r13
   64408:	4c 0f 43 fa          	cmovae %rdx,%r15
   6440c:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   64412:	48 8d 8c 24 00 01 00 	lea    0x100(%rsp),%rcx
   64419:	00 
   6441a:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   6441f:	4c 2b 01             	sub    (%rcx),%r8
   64422:	4c 1b 49 08          	sbb    0x8(%rcx),%r9
   64426:	4c 1b 51 10          	sbb    0x10(%rcx),%r10
   6442a:	4c 1b 59 18          	sbb    0x18(%rcx),%r11
   6442e:	48 19 ff             	sbb    %rdi,%rdi
   64431:	48 8b 1a             	mov    (%rdx),%rbx
   64434:	48 8b 6a 08          	mov    0x8(%rdx),%rbp
   64438:	48 8b 42 10          	mov    0x10(%rdx),%rax
   6443c:	48 8b 72 18          	mov    0x18(%rdx),%rsi
   64440:	48 21 fb             	and    %rdi,%rbx
   64443:	48 21 fd             	and    %rdi,%rbp
   64446:	48 21 f8             	and    %rdi,%rax
   64449:	48 21 fe             	and    %rdi,%rsi
   6444c:	49 01 d8             	add    %rbx,%r8
   6444f:	49 11 e9             	adc    %rbp,%r9
   64452:	49 11 c2             	adc    %rax,%r10
   64455:	49 11 f3             	adc    %rsi,%r11
   64458:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
   6445f:	00 
   64460:	4c 89 b4 24 68 01 00 	mov    %r14,0x168(%rsp)
   64467:	00 
   64468:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
   6446f:	00 
   64470:	4c 89 84 24 00 01 00 	mov    %r8,0x100(%rsp)
   64477:	00 
   64478:	4c 89 8c 24 08 01 00 	mov    %r9,0x108(%rsp)
   6447f:	00 
   64480:	4c 89 94 24 10 01 00 	mov    %r10,0x110(%rsp)
   64487:	00 
   64488:	4c 89 bc 24 78 01 00 	mov    %r15,0x178(%rsp)
   6448f:	00 
   64490:	4c 89 9c 24 18 01 00 	mov    %r11,0x118(%rsp)
   64497:	00 
   64498:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   6449e:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   644a5:	00 
   644a6:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   644ab:	49 bc 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r12
   644b2:	07 d2 87 
   644b5:	45 31 f6             	xor    %r14d,%r14d
   644b8:	31 db                	xor    %ebx,%ebx
   644ba:	45 31 db             	xor    %r11d,%r11d
   644bd:	31 ff                	xor    %edi,%edi
   644bf:	45 31 ff             	xor    %r15d,%r15d
   644c2:	48 8b 11             	mov    (%rcx),%rdx
   644c5:	45 31 d2             	xor    %r10d,%r10d
   644c8:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   644cd:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   644d3:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   644d9:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   644df:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   644e5:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   644eb:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   644f1:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   644f7:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   644fd:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   64503:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   64509:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   6450f:	66 4d 0f 38 f6 fa    	adcx   %r10,%r15
   64515:	4c 89 f2             	mov    %r14,%rdx
   64518:	49 0f af d4          	imul   %r12,%rdx
   6451c:	45 31 d2             	xor    %r10d,%r10d
   6451f:	c4 62 bb f6 0e       	mulx   (%rsi),%r8,%r9
   64524:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6452a:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   64530:	c4 62 bb f6 4e 08    	mulx   0x8(%rsi),%r8,%r9
   64536:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6453c:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   64542:	c4 62 bb f6 4e 10    	mulx   0x10(%rsi),%r8,%r9
   64548:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6454e:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   64554:	c4 62 bb f6 4e 18    	mulx   0x18(%rsi),%r8,%r9
   6455a:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   64560:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   64566:	66 4d 0f 38 f6 fa    	adcx   %r10,%r15
   6456c:	48 8b 51 08          	mov    0x8(%rcx),%rdx
   64570:	45 31 d2             	xor    %r10d,%r10d
   64573:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   64578:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6457e:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   64584:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   6458a:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   64590:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   64596:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   6459c:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   645a2:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   645a8:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   645ae:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   645b4:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   645ba:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   645c0:	48 89 da             	mov    %rbx,%rdx
   645c3:	49 0f af d4          	imul   %r12,%rdx
   645c7:	45 31 d2             	xor    %r10d,%r10d
   645ca:	c4 62 bb f6 0e       	mulx   (%rsi),%r8,%r9
   645cf:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   645d5:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   645db:	c4 62 bb f6 4e 08    	mulx   0x8(%rsi),%r8,%r9
   645e1:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   645e7:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   645ed:	c4 62 bb f6 4e 10    	mulx   0x10(%rsi),%r8,%r9
   645f3:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   645f9:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   645ff:	c4 62 bb f6 4e 18    	mulx   0x18(%rsi),%r8,%r9
   64605:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   6460b:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   64611:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   64617:	48 8b 51 10          	mov    0x10(%rcx),%rdx
   6461b:	45 31 d2             	xor    %r10d,%r10d
   6461e:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   64623:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   64629:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6462f:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   64635:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6463b:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   64641:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   64647:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   6464d:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   64653:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   64659:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6465f:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   64665:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   6466b:	4c 89 da             	mov    %r11,%rdx
   6466e:	49 0f af d4          	imul   %r12,%rdx
   64672:	45 31 d2             	xor    %r10d,%r10d
   64675:	c4 62 bb f6 0e       	mulx   (%rsi),%r8,%r9
   6467a:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   64680:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   64686:	c4 62 bb f6 4e 08    	mulx   0x8(%rsi),%r8,%r9
   6468c:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   64692:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   64698:	c4 62 bb f6 4e 10    	mulx   0x10(%rsi),%r8,%r9
   6469e:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   646a4:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   646aa:	c4 62 bb f6 4e 18    	mulx   0x18(%rsi),%r8,%r9
   646b0:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   646b6:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   646bc:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   646c2:	48 8b 51 18          	mov    0x18(%rcx),%rdx
   646c6:	45 31 d2             	xor    %r10d,%r10d
   646c9:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   646ce:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   646d4:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   646da:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   646e0:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   646e6:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   646ec:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   646f2:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   646f8:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   646fe:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   64704:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6470a:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   64710:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   64716:	48 89 fa             	mov    %rdi,%rdx
   64719:	49 0f af d4          	imul   %r12,%rdx
   6471d:	45 31 d2             	xor    %r10d,%r10d
   64720:	c4 62 bb f6 0e       	mulx   (%rsi),%r8,%r9
   64725:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6472b:	f3 4d 0f 38 f6 f9    	adox   %r9,%r15
   64731:	c4 62 bb f6 4e 08    	mulx   0x8(%rsi),%r8,%r9
   64737:	66 4d 0f 38 f6 f8    	adcx   %r8,%r15
   6473d:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   64743:	c4 62 bb f6 4e 10    	mulx   0x10(%rsi),%r8,%r9
   64749:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6474f:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   64755:	c4 62 bb f6 4e 18    	mulx   0x18(%rsi),%r8,%r9
   6475b:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   64761:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   64767:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   6476d:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   64774:	8c 20 3c 
   64777:	48 b9 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rcx
   6477e:	6a 81 97 
   64781:	4c 89 9c 24 d8 01 00 	mov    %r11,0x1d8(%rsp)
   64788:	00 
   64789:	4c 89 bc 24 e0 00 00 	mov    %r15,0xe0(%rsp)
   64790:	00 
   64791:	4c 89 b4 24 d8 00 00 	mov    %r14,0xd8(%rsp)
   64798:	00 
   64799:	48 89 9c 24 d0 00 00 	mov    %rbx,0xd0(%rsp)
   647a0:	00 
   647a1:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   647a7:	49 39 c7             	cmp    %rax,%r15
   647aa:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   647b1:	95 7e 68 
   647b4:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   647b9:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
   647c0:	00 
   647c1:	49 8d 04 06          	lea    (%r14,%rax,1),%rax
   647c5:	48 83 d8 00          	sbb    $0x0,%rax
   647c9:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   647d0:	00 
   647d1:	0f 92 c0             	setb   %al
   647d4:	49 39 ce             	cmp    %rcx,%r14
   647d7:	0f 92 c1             	setb   %cl
   647da:	08 c1                	or     %al,%cl
   647dc:	0f b6 c1             	movzbl %cl,%eax
   647df:	48 b9 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rcx
   647e6:	ba af 47 
   647e9:	48 01 d9             	add    %rbx,%rcx
   647ec:	48 29 c1             	sub    %rax,%rcx
   647ef:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   647f6:	00 
   647f7:	48 b9 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rcx
   647fe:	45 50 b8 
   64801:	0f 92 c0             	setb   %al
   64804:	48 39 cb             	cmp    %rcx,%rbx
   64807:	0f 92 c1             	setb   %cl
   6480a:	08 c1                	or     %al,%cl
   6480c:	0f b6 c1             	movzbl %cl,%eax
   6480f:	48 b9 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rcx
   64816:	b1 9b cf 
   64819:	4c 01 d9             	add    %r11,%rcx
   6481c:	48 29 c1             	sub    %rax,%rcx
   6481f:	48 b8 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rax
   64826:	4e 64 30 
   64829:	48 89 0c 24          	mov    %rcx,(%rsp)
   6482d:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   64832:	0f 92 84 24 c8 00 00 	setb   0xc8(%rsp)
   64839:	00 
   6483a:	48 39 c7             	cmp    %rax,%rdi
   6483d:	0f 92 c0             	setb   %al
   64840:	0a 84 24 98 00 00 00 	or     0x98(%rsp),%al
   64847:	48 b8 b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rax
   6484e:	73 df c3 
   64851:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   64855:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   6485c:	00 
   6485d:	48 0f 45 d7          	cmovne %rdi,%rdx
   64861:	48 0f 45 f1          	cmovne %rcx,%rsi
   64865:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   6486c:	00 
   6486d:	48 0f 45 44 24 28    	cmovne 0x28(%rsp),%rax
   64873:	49 89 d3             	mov    %rdx,%r11
   64876:	48 0f 45 4c 24 08    	cmovne 0x8(%rsp),%rcx
   6487c:	48 89 b4 24 00 01 00 	mov    %rsi,0x100(%rsp)
   64883:	00 
   64884:	48 89 f3             	mov    %rsi,%rbx
   64887:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   6488e:	00 
   6488f:	49 89 c1             	mov    %rax,%r9
   64892:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
   64899:	00 
   6489a:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
   648a1:	00 
   648a2:	48 89 94 24 18 01 00 	mov    %rdx,0x118(%rsp)
   648a9:	00 
   648aa:	49 89 ca             	mov    %rcx,%r10
   648ad:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   648b2:	48 03 18             	add    (%rax),%rbx
   648b5:	4c 13 48 08          	adc    0x8(%rax),%r9
   648b9:	4c 13 50 10          	adc    0x10(%rax),%r10
   648bd:	4c 13 58 18          	adc    0x18(%rax),%r11
   648c1:	48 89 da             	mov    %rbx,%rdx
   648c4:	4c 89 ce             	mov    %r9,%rsi
   648c7:	4c 89 d7             	mov    %r10,%rdi
   648ca:	4d 89 d8             	mov    %r11,%r8
   648cd:	48 2b 11             	sub    (%rcx),%rdx
   648d0:	48 1b 71 08          	sbb    0x8(%rcx),%rsi
   648d4:	48 1b 79 10          	sbb    0x10(%rcx),%rdi
   648d8:	4c 1b 41 18          	sbb    0x18(%rcx),%r8
   648dc:	48 0f 43 da          	cmovae %rdx,%rbx
   648e0:	4c 0f 43 ce          	cmovae %rsi,%r9
   648e4:	4c 0f 43 d7          	cmovae %rdi,%r10
   648e8:	4d 0f 43 d8          	cmovae %r8,%r11
   648ec:	4c 89 8c 24 b8 00 00 	mov    %r9,0xb8(%rsp)
   648f3:	00 
   648f4:	4c 89 9c 24 c0 00 00 	mov    %r11,0xc0(%rsp)
   648fb:	00 
   648fc:	48 89 9c 24 20 02 00 	mov    %rbx,0x220(%rsp)
   64903:	00 
   64904:	4c 89 94 24 f8 00 00 	mov    %r10,0xf8(%rsp)
   6490b:	00 
   6490c:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   64912:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   64917:	49 ba 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r10
   6491e:	07 d2 87 
   64921:	4c 8d 84 24 e0 01 00 	lea    0x1e0(%rsp),%r8
   64928:	00 
   64929:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
   64930:	00 
   64931:	c5 fc 10 84 24 f0 02 	vmovups 0x2f0(%rsp),%ymm0
   64938:	00 00 
   6493a:	48 8b 84 24 d0 02 00 	mov    0x2d0(%rsp),%rax
   64941:	00 
   64942:	4c 8b 8c 24 e0 02 00 	mov    0x2e0(%rsp),%r9
   64949:	00 
   6494a:	4c 8b 9c 24 e8 02 00 	mov    0x2e8(%rsp),%r11
   64951:	00 
   64952:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   64959:	00 
   6495a:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
   64961:	00 
   64962:	48 8b 84 24 d8 02 00 	mov    0x2d8(%rsp),%rax
   64969:	00 
   6496a:	c5 fc 11 84 24 00 01 	vmovups %ymm0,0x100(%rsp)
   64971:	00 00 
   64973:	c5 fc 10 84 24 f0 02 	vmovups 0x2f0(%rsp),%ymm0
   6497a:	00 00 
   6497c:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
   64983:	00 
   64984:	4c 89 8c 24 f0 01 00 	mov    %r9,0x1f0(%rsp)
   6498b:	00 
   6498c:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
   64993:	00 
   64994:	4c 89 9c 24 f8 01 00 	mov    %r11,0x1f8(%rsp)
   6499b:	00 
   6499c:	c5 fc 11 84 24 60 01 	vmovups %ymm0,0x160(%rsp)
   649a3:	00 00 
   649a5:	31 c0                	xor    %eax,%eax
   649a7:	31 c9                	xor    %ecx,%ecx
   649a9:	45 31 ed             	xor    %r13d,%r13d
   649ac:	45 31 f6             	xor    %r14d,%r14d
   649af:	45 31 e4             	xor    %r12d,%r12d
   649b2:	48 8b 16             	mov    (%rsi),%rdx
   649b5:	31 ff                	xor    %edi,%edi
   649b7:	c4 42 d3 f6 38       	mulx   (%r8),%rbp,%r15
   649bc:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   649c2:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   649c8:	c4 42 d3 f6 78 08    	mulx   0x8(%r8),%rbp,%r15
   649ce:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   649d4:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   649da:	c4 42 d3 f6 78 10    	mulx   0x10(%r8),%rbp,%r15
   649e0:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   649e6:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   649ec:	c4 42 d3 f6 78 18    	mulx   0x18(%r8),%rbp,%r15
   649f2:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   649f8:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   649fe:	66 4c 0f 38 f6 e7    	adcx   %rdi,%r12
   64a04:	48 89 c2             	mov    %rax,%rdx
   64a07:	49 0f af d2          	imul   %r10,%rdx
   64a0b:	31 ff                	xor    %edi,%edi
   64a0d:	c4 62 d3 f6 3b       	mulx   (%rbx),%rbp,%r15
   64a12:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64a18:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   64a1e:	c4 62 d3 f6 7b 08    	mulx   0x8(%rbx),%rbp,%r15
   64a24:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   64a2a:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   64a30:	c4 62 d3 f6 7b 10    	mulx   0x10(%rbx),%rbp,%r15
   64a36:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   64a3c:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   64a42:	c4 62 d3 f6 7b 18    	mulx   0x18(%rbx),%rbp,%r15
   64a48:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64a4e:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   64a54:	66 4c 0f 38 f6 e7    	adcx   %rdi,%r12
   64a5a:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   64a5e:	31 ff                	xor    %edi,%edi
   64a60:	c4 42 d3 f6 38       	mulx   (%r8),%rbp,%r15
   64a65:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   64a6b:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   64a71:	c4 42 d3 f6 78 08    	mulx   0x8(%r8),%rbp,%r15
   64a77:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   64a7d:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   64a83:	c4 42 d3 f6 78 10    	mulx   0x10(%r8),%rbp,%r15
   64a89:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64a8f:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   64a95:	c4 42 d3 f6 78 18    	mulx   0x18(%r8),%rbp,%r15
   64a9b:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64aa1:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   64aa7:	66 48 0f 38 f6 c7    	adcx   %rdi,%rax
   64aad:	48 89 ca             	mov    %rcx,%rdx
   64ab0:	49 0f af d2          	imul   %r10,%rdx
   64ab4:	31 ff                	xor    %edi,%edi
   64ab6:	c4 62 d3 f6 3b       	mulx   (%rbx),%rbp,%r15
   64abb:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   64ac1:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   64ac7:	c4 62 d3 f6 7b 08    	mulx   0x8(%rbx),%rbp,%r15
   64acd:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   64ad3:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   64ad9:	c4 62 d3 f6 7b 10    	mulx   0x10(%rbx),%rbp,%r15
   64adf:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64ae5:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   64aeb:	c4 62 d3 f6 7b 18    	mulx   0x18(%rbx),%rbp,%r15
   64af1:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64af7:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   64afd:	66 48 0f 38 f6 c7    	adcx   %rdi,%rax
   64b03:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   64b07:	31 ff                	xor    %edi,%edi
   64b09:	c4 42 d3 f6 38       	mulx   (%r8),%rbp,%r15
   64b0e:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   64b14:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   64b1a:	c4 42 d3 f6 78 08    	mulx   0x8(%r8),%rbp,%r15
   64b20:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64b26:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   64b2c:	c4 42 d3 f6 78 10    	mulx   0x10(%r8),%rbp,%r15
   64b32:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64b38:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   64b3e:	c4 42 d3 f6 78 18    	mulx   0x18(%r8),%rbp,%r15
   64b44:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64b4a:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   64b50:	66 48 0f 38 f6 cf    	adcx   %rdi,%rcx
   64b56:	4c 89 ea             	mov    %r13,%rdx
   64b59:	49 0f af d2          	imul   %r10,%rdx
   64b5d:	31 ff                	xor    %edi,%edi
   64b5f:	c4 62 d3 f6 3b       	mulx   (%rbx),%rbp,%r15
   64b64:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   64b6a:	f3 4d 0f 38 f6 f7    	adox   %r15,%r14
   64b70:	c4 62 d3 f6 7b 08    	mulx   0x8(%rbx),%rbp,%r15
   64b76:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64b7c:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   64b82:	c4 62 d3 f6 7b 10    	mulx   0x10(%rbx),%rbp,%r15
   64b88:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64b8e:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   64b94:	c4 62 d3 f6 7b 18    	mulx   0x18(%rbx),%rbp,%r15
   64b9a:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64ba0:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   64ba6:	66 48 0f 38 f6 cf    	adcx   %rdi,%rcx
   64bac:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   64bb0:	31 ff                	xor    %edi,%edi
   64bb2:	c4 42 d3 f6 38       	mulx   (%r8),%rbp,%r15
   64bb7:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64bbd:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   64bc3:	c4 42 d3 f6 78 08    	mulx   0x8(%r8),%rbp,%r15
   64bc9:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64bcf:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   64bd5:	c4 42 d3 f6 78 10    	mulx   0x10(%r8),%rbp,%r15
   64bdb:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64be1:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   64be7:	c4 42 d3 f6 78 18    	mulx   0x18(%r8),%rbp,%r15
   64bed:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   64bf3:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   64bf9:	66 4c 0f 38 f6 ef    	adcx   %rdi,%r13
   64bff:	4c 89 f2             	mov    %r14,%rdx
   64c02:	49 0f af d2          	imul   %r10,%rdx
   64c06:	31 ff                	xor    %edi,%edi
   64c08:	c4 62 d3 f6 3b       	mulx   (%rbx),%rbp,%r15
   64c0d:	66 4c 0f 38 f6 f5    	adcx   %rbp,%r14
   64c13:	f3 4d 0f 38 f6 e7    	adox   %r15,%r12
   64c19:	c4 62 d3 f6 7b 08    	mulx   0x8(%rbx),%rbp,%r15
   64c1f:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   64c25:	f3 49 0f 38 f6 c7    	adox   %r15,%rax
   64c2b:	c4 62 d3 f6 7b 10    	mulx   0x10(%rbx),%rbp,%r15
   64c31:	66 48 0f 38 f6 c5    	adcx   %rbp,%rax
   64c37:	f3 49 0f 38 f6 cf    	adox   %r15,%rcx
   64c3d:	c4 62 d3 f6 7b 18    	mulx   0x18(%rbx),%rbp,%r15
   64c43:	66 48 0f 38 f6 cd    	adcx   %rbp,%rcx
   64c49:	f3 4d 0f 38 f6 ef    	adox   %r15,%r13
   64c4f:	66 4c 0f 38 f6 ef    	adcx   %rdi,%r13
   64c55:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   64c5c:	8c 20 3c 
   64c5f:	48 89 c7             	mov    %rax,%rdi
   64c62:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   64c69:	00 
   64c6a:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   64c71:	95 7e 68 
   64c74:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
   64c79:	4c 89 ac 24 e8 00 00 	mov    %r13,0xe8(%rsp)
   64c80:	00 
   64c81:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   64c86:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   64c8c:	4c 89 db             	mov    %r11,%rbx
   64c8f:	4d 89 cf             	mov    %r9,%r15
   64c92:	49 39 d4             	cmp    %rdx,%r12
   64c95:	48 8d 04 07          	lea    (%rdi,%rax,1),%rax
   64c99:	c5 fc 10 84 24 f0 02 	vmovups 0x2f0(%rsp),%ymm0
   64ca0:	00 00 
   64ca2:	48 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%rsi
   64ca9:	00 
   64caa:	48 8b 8c 24 d0 01 00 	mov    0x1d0(%rsp),%rcx
   64cb1:	00 
   64cb2:	4c 8d 64 24 30       	lea    0x30(%rsp),%r12
   64cb7:	48 83 d8 00          	sbb    $0x0,%rax
   64cbb:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   64cc0:	48 b8 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rax
   64cc7:	6a 81 97 
   64cca:	0f 92 c2             	setb   %dl
   64ccd:	48 39 c7             	cmp    %rax,%rdi
   64cd0:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   64cd7:	ba af 47 
   64cda:	40 0f 92 c7          	setb   %dil
   64cde:	40 08 d7             	or     %dl,%dil
   64ce1:	49 89 f0             	mov    %rsi,%r8
   64ce4:	49 89 ce             	mov    %rcx,%r14
   64ce7:	40 0f b6 d7          	movzbl %dil,%edx
   64ceb:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   64cf0:	c5 fc 11 84 24 60 01 	vmovups %ymm0,0x160(%rsp)
   64cf7:	00 00 
   64cf9:	48 01 f8             	add    %rdi,%rax
   64cfc:	48 29 d0             	sub    %rdx,%rax
   64cff:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   64d04:	48 b8 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rax
   64d0b:	45 50 b8 
   64d0e:	0f 92 c2             	setb   %dl
   64d11:	48 39 c7             	cmp    %rax,%rdi
   64d14:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   64d1b:	b1 9b cf 
   64d1e:	40 0f 92 c7          	setb   %dil
   64d22:	40 08 d7             	or     %dl,%dil
   64d25:	40 0f b6 d7          	movzbl %dil,%edx
   64d29:	49 8d 7c 05 00       	lea    0x0(%r13,%rax,1),%rdi
   64d2e:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   64d35:	00 
   64d36:	48 29 d7             	sub    %rdx,%rdi
   64d39:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
   64d40:	00 
   64d41:	0f 92 84 24 f0 00 00 	setb   0xf0(%rsp)
   64d48:	00 
   64d49:	4c 03 30             	add    (%rax),%r14
   64d4c:	4c 13 40 08          	adc    0x8(%rax),%r8
   64d50:	4c 13 78 10          	adc    0x10(%rax),%r15
   64d54:	48 13 58 18          	adc    0x18(%rax),%rbx
   64d58:	4c 89 f5             	mov    %r14,%rbp
   64d5b:	4d 89 c2             	mov    %r8,%r10
   64d5e:	4c 89 fa             	mov    %r15,%rdx
   64d61:	48 89 df             	mov    %rbx,%rdi
   64d64:	49 2b 2c 24          	sub    (%r12),%rbp
   64d68:	4d 1b 54 24 08       	sbb    0x8(%r12),%r10
   64d6d:	49 1b 54 24 10       	sbb    0x10(%r12),%rdx
   64d72:	49 1b 7c 24 18       	sbb    0x18(%r12),%rdi
   64d77:	4c 0f 43 f5          	cmovae %rbp,%r14
   64d7b:	4d 0f 43 c2          	cmovae %r10,%r8
   64d7f:	4c 0f 43 fa          	cmovae %rdx,%r15
   64d83:	48 0f 43 df          	cmovae %rdi,%rbx
   64d87:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   64d8d:	48 8d 94 24 00 01 00 	lea    0x100(%rsp),%rdx
   64d94:	00 
   64d95:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   64d9a:	48 2b 0a             	sub    (%rdx),%rcx
   64d9d:	48 1b 72 08          	sbb    0x8(%rdx),%rsi
   64da1:	4c 1b 4a 10          	sbb    0x10(%rdx),%r9
   64da5:	4c 1b 5a 18          	sbb    0x18(%rdx),%r11
   64da9:	4d 19 ed             	sbb    %r13,%r13
   64dac:	4c 8b 17             	mov    (%rdi),%r10
   64daf:	48 8b 6f 08          	mov    0x8(%rdi),%rbp
   64db3:	48 8b 47 10          	mov    0x10(%rdi),%rax
   64db7:	4c 8b 67 18          	mov    0x18(%rdi),%r12
   64dbb:	4d 21 ea             	and    %r13,%r10
   64dbe:	4c 21 ed             	and    %r13,%rbp
   64dc1:	4c 21 e8             	and    %r13,%rax
   64dc4:	4d 21 ec             	and    %r13,%r12
   64dc7:	4c 01 d1             	add    %r10,%rcx
   64dca:	48 11 ee             	adc    %rbp,%rsi
   64dcd:	49 11 c1             	adc    %rax,%r9
   64dd0:	4d 11 e3             	adc    %r12,%r11
   64dd3:	4c 89 b4 24 60 01 00 	mov    %r14,0x160(%rsp)
   64dda:	00 
   64ddb:	4c 89 84 24 68 01 00 	mov    %r8,0x168(%rsp)
   64de2:	00 
   64de3:	4c 89 bc 24 70 01 00 	mov    %r15,0x170(%rsp)
   64dea:	00 
   64deb:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
   64df2:	00 
   64df3:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
   64dfa:	00 
   64dfb:	4c 89 8c 24 10 01 00 	mov    %r9,0x110(%rsp)
   64e02:	00 
   64e03:	48 89 9c 24 78 01 00 	mov    %rbx,0x178(%rsp)
   64e0a:	00 
   64e0b:	4c 89 9c 24 18 01 00 	mov    %r11,0x118(%rsp)
   64e12:	00 
   64e13:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   64e19:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   64e20:	00 
   64e21:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
   64e28:	00 
   64e29:	4c 8d 54 24 30       	lea    0x30(%rsp),%r10
   64e2e:	49 bf 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r15
   64e35:	07 d2 87 
   64e38:	45 31 c0             	xor    %r8d,%r8d
   64e3b:	31 f6                	xor    %esi,%esi
   64e3d:	31 c9                	xor    %ecx,%ecx
   64e3f:	45 31 db             	xor    %r11d,%r11d
   64e42:	45 31 c9             	xor    %r9d,%r9d
   64e45:	48 8b 17             	mov    (%rdi),%rdx
   64e48:	45 31 f6             	xor    %r14d,%r14d
   64e4b:	c4 e2 e3 f6 28       	mulx   (%rax),%rbx,%rbp
   64e50:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   64e56:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   64e5c:	c4 e2 e3 f6 68 08    	mulx   0x8(%rax),%rbx,%rbp
   64e62:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64e68:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64e6e:	c4 e2 e3 f6 68 10    	mulx   0x10(%rax),%rbx,%rbp
   64e74:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64e7a:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64e80:	c4 e2 e3 f6 68 18    	mulx   0x18(%rax),%rbx,%rbp
   64e86:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64e8c:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64e92:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   64e98:	4c 89 c2             	mov    %r8,%rdx
   64e9b:	49 0f af d7          	imul   %r15,%rdx
   64e9f:	45 31 f6             	xor    %r14d,%r14d
   64ea2:	c4 c2 e3 f6 2a       	mulx   (%r10),%rbx,%rbp
   64ea7:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   64ead:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   64eb3:	c4 c2 e3 f6 6a 08    	mulx   0x8(%r10),%rbx,%rbp
   64eb9:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64ebf:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64ec5:	c4 c2 e3 f6 6a 10    	mulx   0x10(%r10),%rbx,%rbp
   64ecb:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64ed1:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64ed7:	c4 c2 e3 f6 6a 18    	mulx   0x18(%r10),%rbx,%rbp
   64edd:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64ee3:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64ee9:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   64eef:	48 8b 57 08          	mov    0x8(%rdi),%rdx
   64ef3:	45 31 f6             	xor    %r14d,%r14d
   64ef6:	c4 e2 e3 f6 28       	mulx   (%rax),%rbx,%rbp
   64efb:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64f01:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64f07:	c4 e2 e3 f6 68 08    	mulx   0x8(%rax),%rbx,%rbp
   64f0d:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64f13:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64f19:	c4 e2 e3 f6 68 10    	mulx   0x10(%rax),%rbx,%rbp
   64f1f:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64f25:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64f2b:	c4 e2 e3 f6 68 18    	mulx   0x18(%rax),%rbx,%rbp
   64f31:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   64f37:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   64f3d:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   64f43:	48 89 f2             	mov    %rsi,%rdx
   64f46:	49 0f af d7          	imul   %r15,%rdx
   64f4a:	45 31 f6             	xor    %r14d,%r14d
   64f4d:	c4 c2 e3 f6 2a       	mulx   (%r10),%rbx,%rbp
   64f52:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   64f58:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   64f5e:	c4 c2 e3 f6 6a 08    	mulx   0x8(%r10),%rbx,%rbp
   64f64:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64f6a:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64f70:	c4 c2 e3 f6 6a 10    	mulx   0x10(%r10),%rbx,%rbp
   64f76:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64f7c:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64f82:	c4 c2 e3 f6 6a 18    	mulx   0x18(%r10),%rbx,%rbp
   64f88:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   64f8e:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   64f94:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   64f9a:	48 8b 57 10          	mov    0x10(%rdi),%rdx
   64f9e:	45 31 f6             	xor    %r14d,%r14d
   64fa1:	c4 e2 e3 f6 28       	mulx   (%rax),%rbx,%rbp
   64fa6:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   64fac:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   64fb2:	c4 e2 e3 f6 68 08    	mulx   0x8(%rax),%rbx,%rbp
   64fb8:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   64fbe:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   64fc4:	c4 e2 e3 f6 68 10    	mulx   0x10(%rax),%rbx,%rbp
   64fca:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   64fd0:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   64fd6:	c4 e2 e3 f6 68 18    	mulx   0x18(%rax),%rbx,%rbp
   64fdc:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   64fe2:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   64fe8:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   64fee:	48 89 ca             	mov    %rcx,%rdx
   64ff1:	49 0f af d7          	imul   %r15,%rdx
   64ff5:	45 31 f6             	xor    %r14d,%r14d
   64ff8:	c4 c2 e3 f6 2a       	mulx   (%r10),%rbx,%rbp
   64ffd:	66 48 0f 38 f6 cb    	adcx   %rbx,%rcx
   65003:	f3 4c 0f 38 f6 dd    	adox   %rbp,%r11
   65009:	c4 c2 e3 f6 6a 08    	mulx   0x8(%r10),%rbx,%rbp
   6500f:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   65015:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   6501b:	c4 c2 e3 f6 6a 10    	mulx   0x10(%r10),%rbx,%rbp
   65021:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   65027:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   6502d:	c4 c2 e3 f6 6a 18    	mulx   0x18(%r10),%rbx,%rbp
   65033:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   65039:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   6503f:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   65045:	48 8b 57 18          	mov    0x18(%rdi),%rdx
   65049:	45 31 f6             	xor    %r14d,%r14d
   6504c:	c4 e2 e3 f6 28       	mulx   (%rax),%rbx,%rbp
   65051:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   65057:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   6505d:	c4 e2 e3 f6 68 08    	mulx   0x8(%rax),%rbx,%rbp
   65063:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   65069:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   6506f:	c4 e2 e3 f6 68 10    	mulx   0x10(%rax),%rbx,%rbp
   65075:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   6507b:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   65081:	c4 e2 e3 f6 68 18    	mulx   0x18(%rax),%rbx,%rbp
   65087:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   6508d:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   65093:	66 49 0f 38 f6 ce    	adcx   %r14,%rcx
   65099:	4c 89 da             	mov    %r11,%rdx
   6509c:	49 0f af d7          	imul   %r15,%rdx
   650a0:	45 31 f6             	xor    %r14d,%r14d
   650a3:	c4 c2 e3 f6 2a       	mulx   (%r10),%rbx,%rbp
   650a8:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   650ae:	f3 4c 0f 38 f6 cd    	adox   %rbp,%r9
   650b4:	c4 c2 e3 f6 6a 08    	mulx   0x8(%r10),%rbx,%rbp
   650ba:	66 4c 0f 38 f6 cb    	adcx   %rbx,%r9
   650c0:	f3 4c 0f 38 f6 c5    	adox   %rbp,%r8
   650c6:	c4 c2 e3 f6 6a 10    	mulx   0x10(%r10),%rbx,%rbp
   650cc:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   650d2:	f3 48 0f 38 f6 f5    	adox   %rbp,%rsi
   650d8:	c4 c2 e3 f6 6a 18    	mulx   0x18(%r10),%rbx,%rbp
   650de:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   650e4:	f3 48 0f 38 f6 cd    	adox   %rbp,%rcx
   650ea:	66 49 0f 38 f6 ce    	adcx   %r14,%rcx
   650f0:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   650f7:	8c 20 3c 
   650fa:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   65101:	6a 81 97 
   65104:	48 bf 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rdi
   6510b:	4e 64 30 
   6510e:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   65114:	49 39 c1             	cmp    %rax,%r9
   65117:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   6511e:	95 7e 68 
   65121:	4c 8b a4 24 e8 00 00 	mov    0xe8(%rsp),%r12
   65128:	00 
   65129:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   6512e:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
   65135:	00 
   65136:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
   6513b:	49 8d 04 00          	lea    (%r8,%rax,1),%rax
   6513f:	48 83 d8 00          	sbb    $0x0,%rax
   65143:	49 89 c6             	mov    %rax,%r14
   65146:	0f 92 c0             	setb   %al
   65149:	49 39 d0             	cmp    %rdx,%r8
   6514c:	0f 92 c2             	setb   %dl
   6514f:	08 c2                	or     %al,%dl
   65151:	0f b6 c2             	movzbl %dl,%eax
   65154:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   6515b:	ba af 47 
   6515e:	48 01 f2             	add    %rsi,%rdx
   65161:	48 29 c2             	sub    %rax,%rdx
   65164:	49 89 d7             	mov    %rdx,%r15
   65167:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   6516e:	45 50 b8 
   65171:	0f 92 c0             	setb   %al
   65174:	48 39 d6             	cmp    %rdx,%rsi
   65177:	0f 92 c2             	setb   %dl
   6517a:	08 c2                	or     %al,%dl
   6517c:	0f b6 c2             	movzbl %dl,%eax
   6517f:	48 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdx
   65186:	b1 9b cf 
   65189:	48 01 ca             	add    %rcx,%rdx
   6518c:	48 29 c2             	sub    %rax,%rdx
   6518f:	0f 92 c0             	setb   %al
   65192:	48 39 f9             	cmp    %rdi,%rcx
   65195:	49 89 d5             	mov    %rdx,%r13
   65198:	0f 92 c2             	setb   %dl
   6519b:	08 c2                	or     %al,%dl
   6519d:	49 39 fc             	cmp    %rdi,%r12
   651a0:	48 bf b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rdi
   651a7:	73 df c3 
   651aa:	0f 92 c0             	setb   %al
   651ad:	0a 84 24 f0 00 00 00 	or     0xf0(%rsp),%al
   651b4:	49 8d 04 3a          	lea    (%r10,%rdi,1),%rax
   651b8:	49 0f 45 c2          	cmovne %r10,%rax
   651bc:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
   651c1:	4c 0f 45 5c 24 08    	cmovne 0x8(%rsp),%r11
   651c7:	49 0f 45 dc          	cmovne %r12,%rbx
   651cb:	4c 8d a4 24 60 01 00 	lea    0x160(%rsp),%r12
   651d2:	00 
   651d3:	4c 0f 45 94 24 b0 00 	cmovne 0xb0(%rsp),%r10
   651da:	00 00 
   651dc:	84 d2                	test   %dl,%dl
   651de:	49 8d 14 39          	lea    (%r9,%rdi,1),%rdx
   651e2:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   651e9:	00 
   651ea:	49 0f 45 d1          	cmovne %r9,%rdx
   651ee:	4c 0f 45 e9          	cmovne %rcx,%r13
   651f2:	4d 0f 45 f0          	cmovne %r8,%r14
   651f6:	4c 0f 45 fe          	cmovne %rsi,%r15
   651fa:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
   65201:	00 
   65202:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   65207:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   6520c:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   65211:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
   65218:	00 
   65219:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
   65220:	00 
   65221:	49 89 df             	mov    %rbx,%r15
   65224:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   65229:	4d 89 de             	mov    %r11,%r14
   6522c:	4c 89 94 24 08 01 00 	mov    %r10,0x108(%rsp)
   65233:	00 
   65234:	4c 89 9c 24 10 01 00 	mov    %r11,0x110(%rsp)
   6523b:	00 
   6523c:	48 89 9c 24 18 01 00 	mov    %rbx,0x118(%rsp)
   65243:	00 
   65244:	49 03 01             	add    (%r9),%rax
   65247:	4d 13 51 08          	adc    0x8(%r9),%r10
   6524b:	4d 13 71 10          	adc    0x10(%r9),%r14
   6524f:	4d 13 79 18          	adc    0x18(%r9),%r15
   65253:	48 89 c2             	mov    %rax,%rdx
   65256:	4c 89 d6             	mov    %r10,%rsi
   65259:	4c 89 f7             	mov    %r14,%rdi
   6525c:	4d 89 f8             	mov    %r15,%r8
   6525f:	48 2b 11             	sub    (%rcx),%rdx
   65262:	48 1b 71 08          	sbb    0x8(%rcx),%rsi
   65266:	48 1b 79 10          	sbb    0x10(%rcx),%rdi
   6526a:	4c 1b 41 18          	sbb    0x18(%rcx),%r8
   6526e:	48 0f 43 c2          	cmovae %rdx,%rax
   65272:	4c 0f 43 d6          	cmovae %rsi,%r10
   65276:	4c 0f 43 f7          	cmovae %rdi,%r14
   6527a:	4d 0f 43 f8          	cmovae %r8,%r15
   6527e:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
   65283:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
   65288:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   6528e:	4c 89 d1             	mov    %r10,%rcx
   65291:	31 d2                	xor    %edx,%edx
   65293:	31 f6                	xor    %esi,%esi
   65295:	31 ff                	xor    %edi,%edi
   65297:	45 31 c0             	xor    %r8d,%r8d
   6529a:	c5 fc 10 84 24 30 04 	vmovups 0x430(%rsp),%ymm0
   652a1:	00 00 
   652a3:	c5 fc 11 84 24 20 01 	vmovups %ymm0,0x120(%rsp)
   652aa:	00 00 
   652ac:	c5 fc 11 84 24 60 01 	vmovups %ymm0,0x160(%rsp)
   652b3:	00 00 
   652b5:	49 2b 14 24          	sub    (%r12),%rdx
   652b9:	49 1b 74 24 08       	sbb    0x8(%r12),%rsi
   652be:	49 1b 7c 24 10       	sbb    0x10(%r12),%rdi
   652c3:	4d 1b 44 24 18       	sbb    0x18(%r12),%r8
   652c8:	48 19 ed             	sbb    %rbp,%rbp
   652cb:	4d 8b 4d 00          	mov    0x0(%r13),%r9
   652cf:	4d 8b 55 08          	mov    0x8(%r13),%r10
   652d3:	4d 8b 5d 10          	mov    0x10(%r13),%r11
   652d7:	49 8b 5d 18          	mov    0x18(%r13),%rbx
   652db:	49 21 e9             	and    %rbp,%r9
   652de:	49 21 ea             	and    %rbp,%r10
   652e1:	49 21 eb             	and    %rbp,%r11
   652e4:	48 21 eb             	and    %rbp,%rbx
   652e7:	4c 01 ca             	add    %r9,%rdx
   652ea:	4c 11 d6             	adc    %r10,%rsi
   652ed:	4c 11 df             	adc    %r11,%rdi
   652f0:	49 11 d8             	adc    %rbx,%r8
   652f3:	49 bb 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r11
   652fa:	07 d2 87 
   652fd:	c5 fc 10 84 24 10 04 	vmovups 0x410(%rsp),%ymm0
   65304:	00 00 
   65306:	4c 8b a4 24 e8 00 00 	mov    0xe8(%rsp),%r12
   6530d:	00 
   6530e:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
   65315:	00 
   65316:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
   6531b:	c5 fc 11 84 24 60 01 	vmovups %ymm0,0x160(%rsp)
   65322:	00 00 
   65324:	48 89 94 24 80 01 00 	mov    %rdx,0x180(%rsp)
   6532b:	00 
   6532c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   65331:	48 89 b4 24 88 01 00 	mov    %rsi,0x188(%rsp)
   65338:	00 
   65339:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
   65340:	00 
   65341:	4c 89 84 24 98 01 00 	mov    %r8,0x198(%rsp)
   65348:	00 
   65349:	c5 fc 11 94 24 a0 01 	vmovups %ymm2,0x1a0(%rsp)
   65350:	00 00 
   65352:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   65356:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   6535b:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   65360:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
   65365:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
   6536a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   6536f:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   65374:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
   65379:	4c 89 7c 24 68       	mov    %r15,0x68(%rsp)
   6537e:	4c 89 5c 24 70       	mov    %r11,0x70(%rsp)
   65383:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   65389:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   65390:	00 00 00 00 00 
   65395:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   6539a:	4c 8d b4 24 60 01 00 	lea    0x160(%rsp),%r14
   653a1:	00 
   653a2:	31 ff                	xor    %edi,%edi
   653a4:	45 31 db             	xor    %r11d,%r11d
   653a7:	31 ed                	xor    %ebp,%ebp
   653a9:	31 f6                	xor    %esi,%esi
   653ab:	31 db                	xor    %ebx,%ebx
   653ad:	48 8b 11             	mov    (%rcx),%rdx
   653b0:	45 31 d2             	xor    %r10d,%r10d
   653b3:	c4 42 bb f6 0e       	mulx   (%r14),%r8,%r9
   653b8:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   653be:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   653c4:	c4 42 bb f6 4e 08    	mulx   0x8(%r14),%r8,%r9
   653ca:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   653d0:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   653d6:	c4 42 bb f6 4e 10    	mulx   0x10(%r14),%r8,%r9
   653dc:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   653e2:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   653e8:	c4 42 bb f6 4e 18    	mulx   0x18(%r14),%r8,%r9
   653ee:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   653f4:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   653fa:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   65400:	48 8b 51 20          	mov    0x20(%rcx),%rdx
   65404:	45 31 d2             	xor    %r10d,%r10d
   65407:	c4 42 bb f6 4e 20    	mulx   0x20(%r14),%r8,%r9
   6540d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65413:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   65419:	c4 42 bb f6 4e 28    	mulx   0x28(%r14),%r8,%r9
   6541f:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   65425:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   6542b:	c4 42 bb f6 4e 30    	mulx   0x30(%r14),%r8,%r9
   65431:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   65437:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   6543d:	c4 42 bb f6 4e 38    	mulx   0x38(%r14),%r8,%r9
   65443:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65449:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6544f:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   65455:	48 89 fa             	mov    %rdi,%rdx
   65458:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   6545d:	45 31 d2             	xor    %r10d,%r10d
   65460:	c4 42 bb f6 4e 40    	mulx   0x40(%r14),%r8,%r9
   65466:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6546c:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   65472:	c4 42 bb f6 4e 48    	mulx   0x48(%r14),%r8,%r9
   65478:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6547e:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   65484:	c4 42 bb f6 4e 50    	mulx   0x50(%r14),%r8,%r9
   6548a:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   65490:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65496:	c4 42 bb f6 4e 58    	mulx   0x58(%r14),%r8,%r9
   6549c:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   654a2:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   654a8:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   654ae:	48 8b 51 08          	mov    0x8(%rcx),%rdx
   654b2:	45 31 d2             	xor    %r10d,%r10d
   654b5:	c4 42 bb f6 0e       	mulx   (%r14),%r8,%r9
   654ba:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   654c0:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   654c6:	c4 42 bb f6 4e 08    	mulx   0x8(%r14),%r8,%r9
   654cc:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   654d2:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   654d8:	c4 42 bb f6 4e 10    	mulx   0x10(%r14),%r8,%r9
   654de:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   654e4:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   654ea:	c4 42 bb f6 4e 18    	mulx   0x18(%r14),%r8,%r9
   654f0:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   654f6:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   654fc:	66 49 0f 38 f6 fa    	adcx   %r10,%rdi
   65502:	48 8b 51 28          	mov    0x28(%rcx),%rdx
   65506:	45 31 d2             	xor    %r10d,%r10d
   65509:	c4 42 bb f6 4e 20    	mulx   0x20(%r14),%r8,%r9
   6550f:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   65515:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   6551b:	c4 42 bb f6 4e 28    	mulx   0x28(%r14),%r8,%r9
   65521:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   65527:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   6552d:	c4 42 bb f6 4e 30    	mulx   0x30(%r14),%r8,%r9
   65533:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65539:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6553f:	c4 42 bb f6 4e 38    	mulx   0x38(%r14),%r8,%r9
   65545:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6554b:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65551:	66 49 0f 38 f6 fa    	adcx   %r10,%rdi
   65557:	4c 89 da             	mov    %r11,%rdx
   6555a:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   6555f:	45 31 d2             	xor    %r10d,%r10d
   65562:	c4 42 bb f6 4e 40    	mulx   0x40(%r14),%r8,%r9
   65568:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6556e:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   65574:	c4 42 bb f6 4e 48    	mulx   0x48(%r14),%r8,%r9
   6557a:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   65580:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65586:	c4 42 bb f6 4e 50    	mulx   0x50(%r14),%r8,%r9
   6558c:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65592:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65598:	c4 42 bb f6 4e 58    	mulx   0x58(%r14),%r8,%r9
   6559e:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   655a4:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   655aa:	66 49 0f 38 f6 fa    	adcx   %r10,%rdi
   655b0:	48 8b 51 10          	mov    0x10(%rcx),%rdx
   655b4:	45 31 d2             	xor    %r10d,%r10d
   655b7:	c4 42 bb f6 0e       	mulx   (%r14),%r8,%r9
   655bc:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   655c2:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   655c8:	c4 42 bb f6 4e 08    	mulx   0x8(%r14),%r8,%r9
   655ce:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   655d4:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   655da:	c4 42 bb f6 4e 10    	mulx   0x10(%r14),%r8,%r9
   655e0:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   655e6:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   655ec:	c4 42 bb f6 4e 18    	mulx   0x18(%r14),%r8,%r9
   655f2:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   655f8:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   655fe:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   65604:	48 8b 51 30          	mov    0x30(%rcx),%rdx
   65608:	45 31 d2             	xor    %r10d,%r10d
   6560b:	c4 42 bb f6 4e 20    	mulx   0x20(%r14),%r8,%r9
   65611:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   65617:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   6561d:	c4 42 bb f6 4e 28    	mulx   0x28(%r14),%r8,%r9
   65623:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65629:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6562f:	c4 42 bb f6 4e 30    	mulx   0x30(%r14),%r8,%r9
   65635:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6563b:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65641:	c4 42 bb f6 4e 38    	mulx   0x38(%r14),%r8,%r9
   65647:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6564d:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   65653:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   65659:	48 89 ea             	mov    %rbp,%rdx
   6565c:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   65661:	45 31 d2             	xor    %r10d,%r10d
   65664:	c4 42 bb f6 4e 40    	mulx   0x40(%r14),%r8,%r9
   6566a:	66 49 0f 38 f6 e8    	adcx   %r8,%rbp
   65670:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   65676:	c4 42 bb f6 4e 48    	mulx   0x48(%r14),%r8,%r9
   6567c:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65682:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65688:	c4 42 bb f6 4e 50    	mulx   0x50(%r14),%r8,%r9
   6568e:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65694:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6569a:	c4 42 bb f6 4e 58    	mulx   0x58(%r14),%r8,%r9
   656a0:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   656a6:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   656ac:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   656b2:	48 8b 51 18          	mov    0x18(%rcx),%rdx
   656b6:	45 31 d2             	xor    %r10d,%r10d
   656b9:	c4 42 bb f6 0e       	mulx   (%r14),%r8,%r9
   656be:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   656c4:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   656ca:	c4 42 bb f6 4e 08    	mulx   0x8(%r14),%r8,%r9
   656d0:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   656d6:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   656dc:	c4 42 bb f6 4e 10    	mulx   0x10(%r14),%r8,%r9
   656e2:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   656e8:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   656ee:	c4 42 bb f6 4e 18    	mulx   0x18(%r14),%r8,%r9
   656f4:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   656fa:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   65700:	66 49 0f 38 f6 ea    	adcx   %r10,%rbp
   65706:	48 8b 51 38          	mov    0x38(%rcx),%rdx
   6570a:	45 31 d2             	xor    %r10d,%r10d
   6570d:	c4 42 bb f6 4e 20    	mulx   0x20(%r14),%r8,%r9
   65713:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65719:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6571f:	c4 42 bb f6 4e 28    	mulx   0x28(%r14),%r8,%r9
   65725:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6572b:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   65731:	c4 42 bb f6 4e 30    	mulx   0x30(%r14),%r8,%r9
   65737:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   6573d:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   65743:	c4 42 bb f6 4e 38    	mulx   0x38(%r14),%r8,%r9
   65749:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6574f:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   65755:	66 49 0f 38 f6 ea    	adcx   %r10,%rbp
   6575b:	48 89 f2             	mov    %rsi,%rdx
   6575e:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   65763:	45 31 d2             	xor    %r10d,%r10d
   65766:	c4 42 bb f6 4e 40    	mulx   0x40(%r14),%r8,%r9
   6576c:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   65772:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   65778:	c4 42 bb f6 4e 48    	mulx   0x48(%r14),%r8,%r9
   6577e:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   65784:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6578a:	c4 42 bb f6 4e 50    	mulx   0x50(%r14),%r8,%r9
   65790:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   65796:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6579c:	c4 42 bb f6 4e 58    	mulx   0x58(%r14),%r8,%r9
   657a2:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   657a8:	f3 49 0f 38 f6 e9    	adox   %r9,%rbp
   657ae:	66 49 0f 38 f6 ea    	adcx   %r10,%rbp
   657b4:	48 b9 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rcx
   657bb:	8c 20 3c 
   657be:	48 89 fa             	mov    %rdi,%rdx
   657c1:	48 89 bc 24 c8 01 00 	mov    %rdi,0x1c8(%rsp)
   657c8:	00 
   657c9:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
   657d0:	00 
   657d1:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   657d6:	48 89 9c 24 d0 01 00 	mov    %rbx,0x1d0(%rsp)
   657dd:	00 
   657de:	4c 89 9c 24 48 02 00 	mov    %r11,0x248(%rsp)
   657e5:	00 
   657e6:	48 89 ac 24 30 02 00 	mov    %rbp,0x230(%rsp)
   657ed:	00 
   657ee:	4c 89 bc 24 98 00 00 	mov    %r15,0x98(%rsp)
   657f5:	00 
   657f6:	48 89 ee             	mov    %rbp,%rsi
   657f9:	48 39 cb             	cmp    %rcx,%rbx
   657fc:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   65803:	95 7e 68 
   65806:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   6580b:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
   65810:	c5 fc 10 8c 24 10 04 	vmovups 0x410(%rsp),%ymm1
   65817:	00 00 
   65819:	48 8d 0c 0f          	lea    (%rdi,%rcx,1),%rcx
   6581d:	48 bf 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdi
   65824:	6a 81 97 
   65827:	48 83 d9 00          	sbb    $0x0,%rcx
   6582b:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
   65832:	00 
   65833:	0f 92 c1             	setb   %cl
   65836:	48 39 fa             	cmp    %rdi,%rdx
   65839:	0f 92 c2             	setb   %dl
   6583c:	08 ca                	or     %cl,%dl
   6583e:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   65843:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
   65848:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
   6584d:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
   65852:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   65857:	0f b6 ca             	movzbl %dl,%ecx
   6585a:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   65861:	ba af 47 
   65864:	4d 8d 14 13          	lea    (%r11,%rdx,1),%r10
   65868:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   6586f:	45 50 b8 
   65872:	49 29 ca             	sub    %rcx,%r10
   65875:	c5 fc 11 8c 24 00 01 	vmovups %ymm1,0x100(%rsp)
   6587c:	00 00 
   6587e:	c5 fc 11 94 24 40 01 	vmovups %ymm2,0x140(%rsp)
   65885:	00 00 
   65887:	0f 92 c1             	setb   %cl
   6588a:	49 39 d3             	cmp    %rdx,%r11
   6588d:	0f 92 c2             	setb   %dl
   65890:	08 ca                	or     %cl,%dl
   65892:	0f b6 ca             	movzbl %dl,%ecx
   65895:	48 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdx
   6589c:	b1 9b cf 
   6589f:	4c 8d 4c 15 00       	lea    0x0(%rbp,%rdx,1),%r9
   658a4:	48 8d 6c 24 30       	lea    0x30(%rsp),%rbp
   658a9:	49 29 c9             	sub    %rcx,%r9
   658ac:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   658b1:	0f 92 44 24 17       	setb   0x17(%rsp)
   658b6:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   658bb:	48 b9 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rcx
   658c2:	07 d2 87 
   658c5:	4c 89 44 24 60       	mov    %r8,0x60(%rsp)
   658ca:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
   658cf:	4c 8d 84 24 00 01 00 	lea    0x100(%rsp),%r8
   658d6:	00 
   658d7:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   658dc:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   658e2:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   658e9:	00 00 00 00 00 
   658ee:	45 31 db             	xor    %r11d,%r11d
   658f1:	31 c0                	xor    %eax,%eax
   658f3:	31 c9                	xor    %ecx,%ecx
   658f5:	45 31 ed             	xor    %r13d,%r13d
   658f8:	45 31 f6             	xor    %r14d,%r14d
   658fb:	48 8b 55 00          	mov    0x0(%rbp),%rdx
   658ff:	45 31 ff             	xor    %r15d,%r15d
   65902:	c4 c2 9b f6 18       	mulx   (%r8),%r12,%rbx
   65907:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   6590d:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65913:	c4 c2 9b f6 58 08    	mulx   0x8(%r8),%r12,%rbx
   65919:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   6591f:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65925:	c4 c2 9b f6 58 10    	mulx   0x10(%r8),%r12,%rbx
   6592b:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   65931:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65937:	c4 c2 9b f6 58 18    	mulx   0x18(%r8),%r12,%rbx
   6593d:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65943:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65949:	66 4d 0f 38 f6 f7    	adcx   %r15,%r14
   6594f:	48 8b 55 20          	mov    0x20(%rbp),%rdx
   65953:	45 31 ff             	xor    %r15d,%r15d
   65956:	c4 c2 9b f6 58 20    	mulx   0x20(%r8),%r12,%rbx
   6595c:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65962:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65968:	c4 c2 9b f6 58 28    	mulx   0x28(%r8),%r12,%rbx
   6596e:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65974:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   6597a:	c4 c2 9b f6 58 30    	mulx   0x30(%r8),%r12,%rbx
   65980:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   65986:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   6598c:	c4 c2 9b f6 58 38    	mulx   0x38(%r8),%r12,%rbx
   65992:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65998:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   6599e:	66 4d 0f 38 f6 f7    	adcx   %r15,%r14
   659a4:	4c 89 da             	mov    %r11,%rdx
   659a7:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   659ac:	45 31 ff             	xor    %r15d,%r15d
   659af:	c4 c2 9b f6 58 40    	mulx   0x40(%r8),%r12,%rbx
   659b5:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   659bb:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   659c1:	c4 c2 9b f6 58 48    	mulx   0x48(%r8),%r12,%rbx
   659c7:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   659cd:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   659d3:	c4 c2 9b f6 58 50    	mulx   0x50(%r8),%r12,%rbx
   659d9:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   659df:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   659e5:	c4 c2 9b f6 58 58    	mulx   0x58(%r8),%r12,%rbx
   659eb:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   659f1:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   659f7:	66 4d 0f 38 f6 f7    	adcx   %r15,%r14
   659fd:	48 8b 55 08          	mov    0x8(%rbp),%rdx
   65a01:	45 31 ff             	xor    %r15d,%r15d
   65a04:	c4 c2 9b f6 18       	mulx   (%r8),%r12,%rbx
   65a09:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65a0f:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65a15:	c4 c2 9b f6 58 08    	mulx   0x8(%r8),%r12,%rbx
   65a1b:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   65a21:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65a27:	c4 c2 9b f6 58 10    	mulx   0x10(%r8),%r12,%rbx
   65a2d:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65a33:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65a39:	c4 c2 9b f6 58 18    	mulx   0x18(%r8),%r12,%rbx
   65a3f:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65a45:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65a4b:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   65a51:	48 8b 55 28          	mov    0x28(%rbp),%rdx
   65a55:	45 31 ff             	xor    %r15d,%r15d
   65a58:	c4 c2 9b f6 58 20    	mulx   0x20(%r8),%r12,%rbx
   65a5e:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65a64:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65a6a:	c4 c2 9b f6 58 28    	mulx   0x28(%r8),%r12,%rbx
   65a70:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   65a76:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65a7c:	c4 c2 9b f6 58 30    	mulx   0x30(%r8),%r12,%rbx
   65a82:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65a88:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65a8e:	c4 c2 9b f6 58 38    	mulx   0x38(%r8),%r12,%rbx
   65a94:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65a9a:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65aa0:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   65aa6:	48 89 c2             	mov    %rax,%rdx
   65aa9:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   65aae:	45 31 ff             	xor    %r15d,%r15d
   65ab1:	c4 c2 9b f6 58 40    	mulx   0x40(%r8),%r12,%rbx
   65ab7:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65abd:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65ac3:	c4 c2 9b f6 58 48    	mulx   0x48(%r8),%r12,%rbx
   65ac9:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   65acf:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65ad5:	c4 c2 9b f6 58 50    	mulx   0x50(%r8),%r12,%rbx
   65adb:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65ae1:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65ae7:	c4 c2 9b f6 58 58    	mulx   0x58(%r8),%r12,%rbx
   65aed:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65af3:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65af9:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   65aff:	48 8b 55 10          	mov    0x10(%rbp),%rdx
   65b03:	45 31 ff             	xor    %r15d,%r15d
   65b06:	c4 c2 9b f6 18       	mulx   (%r8),%r12,%rbx
   65b0b:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   65b11:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65b17:	c4 c2 9b f6 58 08    	mulx   0x8(%r8),%r12,%rbx
   65b1d:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65b23:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65b29:	c4 c2 9b f6 58 10    	mulx   0x10(%r8),%r12,%rbx
   65b2f:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65b35:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65b3b:	c4 c2 9b f6 58 18    	mulx   0x18(%r8),%r12,%rbx
   65b41:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65b47:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65b4d:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   65b53:	48 8b 55 30          	mov    0x30(%rbp),%rdx
   65b57:	45 31 ff             	xor    %r15d,%r15d
   65b5a:	c4 c2 9b f6 58 20    	mulx   0x20(%r8),%r12,%rbx
   65b60:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   65b66:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65b6c:	c4 c2 9b f6 58 28    	mulx   0x28(%r8),%r12,%rbx
   65b72:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65b78:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65b7e:	c4 c2 9b f6 58 30    	mulx   0x30(%r8),%r12,%rbx
   65b84:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65b8a:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65b90:	c4 c2 9b f6 58 38    	mulx   0x38(%r8),%r12,%rbx
   65b96:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65b9c:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65ba2:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   65ba8:	48 89 ca             	mov    %rcx,%rdx
   65bab:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   65bb0:	45 31 ff             	xor    %r15d,%r15d
   65bb3:	c4 c2 9b f6 58 40    	mulx   0x40(%r8),%r12,%rbx
   65bb9:	66 49 0f 38 f6 cc    	adcx   %r12,%rcx
   65bbf:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   65bc5:	c4 c2 9b f6 58 48    	mulx   0x48(%r8),%r12,%rbx
   65bcb:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65bd1:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65bd7:	c4 c2 9b f6 58 50    	mulx   0x50(%r8),%r12,%rbx
   65bdd:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65be3:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65be9:	c4 c2 9b f6 58 58    	mulx   0x58(%r8),%r12,%rbx
   65bef:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65bf5:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65bfb:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   65c01:	48 8b 55 18          	mov    0x18(%rbp),%rdx
   65c05:	45 31 ff             	xor    %r15d,%r15d
   65c08:	c4 c2 9b f6 18       	mulx   (%r8),%r12,%rbx
   65c0d:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65c13:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65c19:	c4 c2 9b f6 58 08    	mulx   0x8(%r8),%r12,%rbx
   65c1f:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65c25:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65c2b:	c4 c2 9b f6 58 10    	mulx   0x10(%r8),%r12,%rbx
   65c31:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65c37:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65c3d:	c4 c2 9b f6 58 18    	mulx   0x18(%r8),%r12,%rbx
   65c43:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65c49:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65c4f:	66 49 0f 38 f6 cf    	adcx   %r15,%rcx
   65c55:	48 8b 55 38          	mov    0x38(%rbp),%rdx
   65c59:	45 31 ff             	xor    %r15d,%r15d
   65c5c:	c4 c2 9b f6 58 20    	mulx   0x20(%r8),%r12,%rbx
   65c62:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65c68:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65c6e:	c4 c2 9b f6 58 28    	mulx   0x28(%r8),%r12,%rbx
   65c74:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65c7a:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65c80:	c4 c2 9b f6 58 30    	mulx   0x30(%r8),%r12,%rbx
   65c86:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65c8c:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65c92:	c4 c2 9b f6 58 38    	mulx   0x38(%r8),%r12,%rbx
   65c98:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65c9e:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65ca4:	66 49 0f 38 f6 cf    	adcx   %r15,%rcx
   65caa:	4c 89 ea             	mov    %r13,%rdx
   65cad:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   65cb2:	45 31 ff             	xor    %r15d,%r15d
   65cb5:	c4 c2 9b f6 58 40    	mulx   0x40(%r8),%r12,%rbx
   65cbb:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   65cc1:	f3 4c 0f 38 f6 f3    	adox   %rbx,%r14
   65cc7:	c4 c2 9b f6 58 48    	mulx   0x48(%r8),%r12,%rbx
   65ccd:	66 4d 0f 38 f6 f4    	adcx   %r12,%r14
   65cd3:	f3 4c 0f 38 f6 db    	adox   %rbx,%r11
   65cd9:	c4 c2 9b f6 58 50    	mulx   0x50(%r8),%r12,%rbx
   65cdf:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   65ce5:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   65ceb:	c4 c2 9b f6 58 58    	mulx   0x58(%r8),%r12,%rbx
   65cf1:	66 49 0f 38 f6 c4    	adcx   %r12,%rax
   65cf7:	f3 48 0f 38 f6 cb    	adox   %rbx,%rcx
   65cfd:	66 49 0f 38 f6 cf    	adcx   %r15,%rcx
   65d03:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   65d0a:	8c 20 3c 
   65d0d:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
   65d14:	00 
   65d15:	48 89 8c 24 38 02 00 	mov    %rcx,0x238(%rsp)
   65d1c:	00 
   65d1d:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   65d23:	49 39 d6             	cmp    %rdx,%r14
   65d26:	48 ba 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rdx
   65d2d:	95 7e 68 
   65d30:	c5 fc 10 8c 24 70 02 	vmovups 0x270(%rsp),%ymm1
   65d37:	00 00 
   65d39:	49 8d 14 13          	lea    (%r11,%rdx,1),%rdx
   65d3d:	48 83 da 00          	sbb    $0x0,%rdx
   65d41:	41 0f 92 c0          	setb   %r8b
   65d45:	49 39 fb             	cmp    %rdi,%r11
   65d48:	48 bf a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdi
   65d4f:	ba af 47 
   65d52:	0f 92 c3             	setb   %bl
   65d55:	48 8d 2c 38          	lea    (%rax,%rdi,1),%rbp
   65d59:	48 bf 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdi
   65d60:	45 50 b8 
   65d63:	44 08 c3             	or     %r8b,%bl
   65d66:	44 0f b6 c3          	movzbl %bl,%r8d
   65d6a:	4c 29 c5             	sub    %r8,%rbp
   65d6d:	41 0f 92 c0          	setb   %r8b
   65d71:	48 39 f8             	cmp    %rdi,%rax
   65d74:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   65d7b:	b1 9b cf 
   65d7e:	48 8b 3c 24          	mov    (%rsp),%rdi
   65d82:	c5 fc 11 8c 24 20 01 	vmovups %ymm1,0x120(%rsp)
   65d89:	00 00 
   65d8b:	c5 fc 10 8c 24 70 02 	vmovups 0x270(%rsp),%ymm1
   65d92:	00 00 
   65d94:	0f 92 c3             	setb   %bl
   65d97:	44 08 c3             	or     %r8b,%bl
   65d9a:	4c 8d 04 01          	lea    (%rcx,%rax,1),%r8
   65d9e:	48 b8 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rax
   65da5:	4e 64 30 
   65da8:	0f b6 db             	movzbl %bl,%ebx
   65dab:	49 29 d8             	sub    %rbx,%r8
   65dae:	0f 92 c3             	setb   %bl
   65db1:	48 39 c1             	cmp    %rax,%rcx
   65db4:	48 8b 8c 24 d8 01 00 	mov    0x1d8(%rsp),%rcx
   65dbb:	00 
   65dbc:	41 0f 92 c7          	setb   %r15b
   65dc0:	41 08 df             	or     %bl,%r15b
   65dc3:	48 39 c6             	cmp    %rax,%rsi
   65dc6:	48 be b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rsi
   65dcd:	73 df c3 
   65dd0:	0f 92 c3             	setb   %bl
   65dd3:	0a 5c 24 17          	or     0x17(%rsp),%bl
   65dd7:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   65dde:	00 00 
   65de0:	48 39 c1             	cmp    %rax,%rcx
   65de3:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   65dea:	00 
   65deb:	41 0f 92 c4          	setb   %r12b
   65def:	44 0a a4 24 c8 00 00 	or     0xc8(%rsp),%r12b
   65df6:	00 
   65df7:	4c 8b a4 24 a8 00 00 	mov    0xa8(%rsp),%r12
   65dfe:	00 
   65dff:	48 0f 45 f9          	cmovne %rcx,%rdi
   65e03:	4c 8d 2c 30          	lea    (%rax,%rsi,1),%r13
   65e07:	4c 0f 45 a4 24 d8 00 	cmovne 0xd8(%rsp),%r12
   65e0e:	00 00 
   65e10:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
   65e17:	00 
   65e18:	48 89 3c 24          	mov    %rdi,(%rsp)
   65e1c:	48 8b bc 24 d0 01 00 	mov    0x1d0(%rsp),%rdi
   65e23:	00 
   65e24:	4c 0f 45 e8          	cmovne %rax,%r13
   65e28:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   65e2f:	00 
   65e30:	48 0f 45 84 24 d0 00 	cmovne 0xd0(%rsp),%rax
   65e37:	00 00 
   65e39:	84 db                	test   %bl,%bl
   65e3b:	48 0f 45 8c 24 c8 01 	cmovne 0x1c8(%rsp),%rcx
   65e42:	00 00 
   65e44:	4c 0f 45 94 24 48 02 	cmovne 0x248(%rsp),%r10
   65e4b:	00 00 
   65e4d:	4c 0f 45 8c 24 30 02 	cmovne 0x230(%rsp),%r9
   65e54:	00 00 
   65e56:	4c 89 a4 24 a8 00 00 	mov    %r12,0xa8(%rsp)
   65e5d:	00 
   65e5e:	48 8d 1c 37          	lea    (%rdi,%rsi,1),%rbx
   65e62:	48 0f 45 df          	cmovne %rdi,%rbx
   65e66:	45 84 ff             	test   %r15b,%r15b
   65e69:	49 8d 3c 36          	lea    (%r14,%rsi,1),%rdi
   65e6d:	48 0f 45 ac 24 40 02 	cmovne 0x240(%rsp),%rbp
   65e74:	00 00 
   65e76:	4c 0f 45 84 24 38 02 	cmovne 0x238(%rsp),%r8
   65e7d:	00 00 
   65e7f:	49 0f 45 fe          	cmovne %r14,%rdi
   65e83:	49 0f 45 d3          	cmovne %r11,%rdx
   65e87:	48 89 9c 24 10 03 00 	mov    %rbx,0x310(%rsp)
   65e8e:	00 
   65e8f:	48 89 8c 24 18 03 00 	mov    %rcx,0x318(%rsp)
   65e96:	00 
   65e97:	4c 89 94 24 20 03 00 	mov    %r10,0x320(%rsp)
   65e9e:	00 
   65e9f:	4c 89 8c 24 28 03 00 	mov    %r9,0x328(%rsp)
   65ea6:	00 
   65ea7:	4c 8d b4 24 60 01 00 	lea    0x160(%rsp),%r14
   65eae:	00 
   65eaf:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   65eb4:	31 f6                	xor    %esi,%esi
   65eb6:	45 31 ff             	xor    %r15d,%r15d
   65eb9:	48 89 bc 24 30 03 00 	mov    %rdi,0x330(%rsp)
   65ec0:	00 
   65ec1:	48 89 94 24 38 03 00 	mov    %rdx,0x338(%rsp)
   65ec8:	00 
   65ec9:	31 d2                	xor    %edx,%edx
   65ecb:	31 ff                	xor    %edi,%edi
   65ecd:	48 89 ac 24 40 03 00 	mov    %rbp,0x340(%rsp)
   65ed4:	00 
   65ed5:	4c 89 84 24 48 03 00 	mov    %r8,0x348(%rsp)
   65edc:	00 
   65edd:	4d 2b 3e             	sub    (%r14),%r15
   65ee0:	49 1b 76 08          	sbb    0x8(%r14),%rsi
   65ee4:	49 1b 7e 10          	sbb    0x10(%r14),%rdi
   65ee8:	49 1b 56 18          	sbb    0x18(%r14),%rdx
   65eec:	48 19 db             	sbb    %rbx,%rbx
   65eef:	4c 8b 01             	mov    (%rcx),%r8
   65ef2:	4c 8b 49 08          	mov    0x8(%rcx),%r9
   65ef6:	4c 8b 51 10          	mov    0x10(%rcx),%r10
   65efa:	4c 8b 59 18          	mov    0x18(%rcx),%r11
   65efe:	49 21 d8             	and    %rbx,%r8
   65f01:	49 21 d9             	and    %rbx,%r9
   65f04:	49 21 da             	and    %rbx,%r10
   65f07:	49 21 db             	and    %rbx,%r11
   65f0a:	4d 01 c7             	add    %r8,%r15
   65f0d:	4c 11 ce             	adc    %r9,%rsi
   65f10:	4c 11 d7             	adc    %r10,%rdi
   65f13:	4c 11 da             	adc    %r11,%rdx
   65f16:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
   65f1b:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
   65f20:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   65f27:	00 
   65f28:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   65f2d:	c5 fc 10 8c 24 50 02 	vmovups 0x250(%rsp),%ymm1
   65f34:	00 00 
   65f36:	48 8b 04 24          	mov    (%rsp),%rax
   65f3a:	48 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%rbp
   65f41:	00 
   65f42:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
   65f49:	00 
   65f4a:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   65f4f:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   65f56:	00 
   65f57:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   65f5e:	00 00 
   65f60:	4c 89 bc 24 80 01 00 	mov    %r15,0x180(%rsp)
   65f67:	00 
   65f68:	4c 8b bc 24 20 02 00 	mov    0x220(%rsp),%r15
   65f6f:	00 
   65f70:	48 89 b4 24 88 01 00 	mov    %rsi,0x188(%rsp)
   65f77:	00 
   65f78:	48 be 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rsi
   65f7f:	07 d2 87 
   65f82:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
   65f89:	00 
   65f8a:	48 89 94 24 98 01 00 	mov    %rdx,0x198(%rsp)
   65f91:	00 
   65f92:	c5 fc 11 94 24 a0 01 	vmovups %ymm2,0x1a0(%rsp)
   65f99:	00 00 
   65f9b:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
   65fa0:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   65fa5:	48 89 6c 24 60       	mov    %rbp,0x60(%rsp)
   65faa:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   65faf:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
   65fb4:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   65fba:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   65fc1:	00 00 00 00 00 
   65fc6:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   65fcd:	00 
   65fce:	45 31 d2             	xor    %r10d,%r10d
   65fd1:	45 31 e4             	xor    %r12d,%r12d
   65fd4:	31 db                	xor    %ebx,%ebx
   65fd6:	31 f6                	xor    %esi,%esi
   65fd8:	31 ff                	xor    %edi,%edi
   65fda:	48 8b 11             	mov    (%rcx),%rdx
   65fdd:	45 31 db             	xor    %r11d,%r11d
   65fe0:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   65fe5:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   65feb:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   65ff1:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   65ff7:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   65ffd:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66003:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   66009:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6600f:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   66015:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   6601b:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   66021:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66027:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   6602d:	48 8b 51 20          	mov    0x20(%rcx),%rdx
   66031:	45 31 db             	xor    %r11d,%r11d
   66034:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   6603a:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   66040:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   66046:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   6604c:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   66052:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66058:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   6605e:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66064:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   6606a:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   66070:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   66076:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6607c:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   66082:	4c 89 d2             	mov    %r10,%rdx
   66085:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   6608a:	45 31 db             	xor    %r11d,%r11d
   6608d:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   66093:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   66099:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   6609f:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   660a5:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   660ab:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   660b1:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   660b7:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   660bd:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   660c3:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   660c9:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   660cf:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   660d5:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   660db:	48 8b 51 08          	mov    0x8(%rcx),%rdx
   660df:	45 31 db             	xor    %r11d,%r11d
   660e2:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   660e7:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   660ed:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   660f3:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   660f9:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   660ff:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   66105:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   6610b:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   66111:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66117:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   6611d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66123:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   66129:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   6612f:	48 8b 51 28          	mov    0x28(%rcx),%rdx
   66133:	45 31 db             	xor    %r11d,%r11d
   66136:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   6613c:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   66142:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66148:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   6614e:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66154:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   6615a:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   66160:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   66166:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6616c:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   66172:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66178:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   6617e:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   66184:	4c 89 e2             	mov    %r12,%rdx
   66187:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   6618c:	45 31 db             	xor    %r11d,%r11d
   6618f:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   66195:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   6619b:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   661a1:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   661a7:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   661ad:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   661b3:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   661b9:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   661bf:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   661c5:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   661cb:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   661d1:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   661d7:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   661dd:	48 8b 51 10          	mov    0x10(%rcx),%rdx
   661e1:	45 31 db             	xor    %r11d,%r11d
   661e4:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   661e9:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   661ef:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   661f5:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   661fb:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   66201:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66207:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   6620d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66213:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   66219:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   6621f:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   66225:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   6622b:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   66231:	48 8b 51 30          	mov    0x30(%rcx),%rdx
   66235:	45 31 db             	xor    %r11d,%r11d
   66238:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   6623e:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66244:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   6624a:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   66250:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   66256:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6625c:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   66262:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66268:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   6626e:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   66274:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   6627a:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   66280:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   66286:	48 89 da             	mov    %rbx,%rdx
   66289:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   6628e:	45 31 db             	xor    %r11d,%r11d
   66291:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   66297:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6629d:	f3 49 0f 38 f6 f1    	adox   %r9,%rsi
   662a3:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   662a9:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   662af:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   662b5:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   662bb:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   662c1:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   662c7:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   662cd:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   662d3:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   662d9:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   662df:	48 8b 51 18          	mov    0x18(%rcx),%rdx
   662e3:	45 31 db             	xor    %r11d,%r11d
   662e6:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   662eb:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   662f1:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   662f7:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   662fd:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66303:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   66309:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   6630f:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   66315:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   6631b:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   66321:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   66327:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6632d:	66 49 0f 38 f6 db    	adcx   %r11,%rbx
   66333:	48 8b 51 38          	mov    0x38(%rcx),%rdx
   66337:	45 31 db             	xor    %r11d,%r11d
   6633a:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   66340:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   66346:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   6634c:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   66352:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66358:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   6635e:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   66364:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   6636a:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   66370:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   66376:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   6637c:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66382:	66 49 0f 38 f6 db    	adcx   %r11,%rbx
   66388:	48 89 f2             	mov    %rsi,%rdx
   6638b:	48 0f af 51 40       	imul   0x40(%rcx),%rdx
   66390:	45 31 db             	xor    %r11d,%r11d
   66393:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   66399:	66 49 0f 38 f6 f0    	adcx   %r8,%rsi
   6639f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   663a5:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   663ab:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   663b1:	f3 4d 0f 38 f6 d1    	adox   %r9,%r10
   663b7:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   663bd:	66 4d 0f 38 f6 d0    	adcx   %r8,%r10
   663c3:	f3 4d 0f 38 f6 e1    	adox   %r9,%r12
   663c9:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   663cf:	66 4d 0f 38 f6 e0    	adcx   %r8,%r12
   663d5:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   663db:	66 49 0f 38 f6 db    	adcx   %r11,%rbx
   663e1:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   663e8:	95 7e 68 
   663eb:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   663f2:	8c 20 3c 
   663f5:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   663fa:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
   66401:	00 
   66402:	48 89 9c 24 c8 00 00 	mov    %rbx,0xc8(%rsp)
   66409:	00 
   6640a:	48 89 bc 24 e0 00 00 	mov    %rdi,0xe0(%rsp)
   66411:	00 
   66412:	4c 89 94 24 d8 00 00 	mov    %r10,0xd8(%rsp)
   66419:	00 
   6641a:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
   66421:	00 
   66422:	48 39 d7             	cmp    %rdx,%rdi
   66425:	49 8d 04 02          	lea    (%r10,%rax,1),%rax
   66429:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   66430:	6a 81 97 
   66433:	48 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%rsi
   6643a:	00 
   6643b:	4c 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%r8
   66442:	00 
   66443:	c5 fc 10 8c 24 50 02 	vmovups 0x250(%rsp),%ymm1
   6644a:	00 00 
   6644c:	48 83 d8 00          	sbb    $0x0,%rax
   66450:	0f 92 c1             	setb   %cl
   66453:	49 39 d2             	cmp    %rdx,%r10
   66456:	0f 92 c2             	setb   %dl
   66459:	08 ca                	or     %cl,%dl
   6645b:	0f b6 ca             	movzbl %dl,%ecx
   6645e:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   66465:	ba af 47 
   66468:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
   6646d:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
   66474:	00 
   66475:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
   6647a:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
   6647f:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
   66484:	4c 89 44 24 58       	mov    %r8,0x58(%rsp)
   66489:	4c 8b 04 24          	mov    (%rsp),%r8
   6648d:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   66492:	4d 8d 0c 14          	lea    (%r12,%rdx,1),%r9
   66496:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   6649d:	45 50 b8 
   664a0:	49 29 c9             	sub    %rcx,%r9
   664a3:	0f 92 c1             	setb   %cl
   664a6:	49 39 d4             	cmp    %rdx,%r12
   664a9:	c5 fc 11 8c 24 00 01 	vmovups %ymm1,0x100(%rsp)
   664b0:	00 00 
   664b2:	c5 fc 11 94 24 40 01 	vmovups %ymm2,0x140(%rsp)
   664b9:	00 00 
   664bb:	0f 92 c2             	setb   %dl
   664be:	08 ca                	or     %cl,%dl
   664c0:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
   664c5:	48 be 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rsi
   664cc:	07 d2 87 
   664cf:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
   664d4:	0f b6 ca             	movzbl %dl,%ecx
   664d7:	48 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdx
   664de:	b1 9b cf 
   664e1:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
   664e6:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   664ec:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   664f3:	00 00 00 00 00 
   664f8:	4c 8d 24 13          	lea    (%rbx,%rdx,1),%r12
   664fc:	49 29 cc             	sub    %rcx,%r12
   664ff:	48 8d 8c 24 00 01 00 	lea    0x100(%rsp),%rcx
   66506:	00 
   66507:	0f 92 84 24 d8 01 00 	setb   0x1d8(%rsp)
   6650e:	00 
   6650f:	45 31 c0             	xor    %r8d,%r8d
   66512:	45 31 db             	xor    %r11d,%r11d
   66515:	31 f6                	xor    %esi,%esi
   66517:	31 ed                	xor    %ebp,%ebp
   66519:	45 31 f6             	xor    %r14d,%r14d
   6651c:	49 8b 55 00          	mov    0x0(%r13),%rdx
   66520:	31 db                	xor    %ebx,%ebx
   66522:	c4 62 c3 f6 11       	mulx   (%rcx),%rdi,%r10
   66527:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   6652d:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66533:	c4 62 c3 f6 51 08    	mulx   0x8(%rcx),%rdi,%r10
   66539:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   6653f:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66545:	c4 62 c3 f6 51 10    	mulx   0x10(%rcx),%rdi,%r10
   6654b:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   66551:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66557:	c4 62 c3 f6 51 18    	mulx   0x18(%rcx),%rdi,%r10
   6655d:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   66563:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66569:	66 4c 0f 38 f6 f3    	adcx   %rbx,%r14
   6656f:	49 8b 55 20          	mov    0x20(%r13),%rdx
   66573:	31 db                	xor    %ebx,%ebx
   66575:	c4 62 c3 f6 51 20    	mulx   0x20(%rcx),%rdi,%r10
   6657b:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   66581:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66587:	c4 62 c3 f6 51 28    	mulx   0x28(%rcx),%rdi,%r10
   6658d:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   66593:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66599:	c4 62 c3 f6 51 30    	mulx   0x30(%rcx),%rdi,%r10
   6659f:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   665a5:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   665ab:	c4 62 c3 f6 51 38    	mulx   0x38(%rcx),%rdi,%r10
   665b1:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   665b7:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   665bd:	66 4c 0f 38 f6 f3    	adcx   %rbx,%r14
   665c3:	4c 89 c2             	mov    %r8,%rdx
   665c6:	49 0f af 55 40       	imul   0x40(%r13),%rdx
   665cb:	31 db                	xor    %ebx,%ebx
   665cd:	c4 62 c3 f6 51 40    	mulx   0x40(%rcx),%rdi,%r10
   665d3:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   665d9:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   665df:	c4 62 c3 f6 51 48    	mulx   0x48(%rcx),%rdi,%r10
   665e5:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   665eb:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   665f1:	c4 62 c3 f6 51 50    	mulx   0x50(%rcx),%rdi,%r10
   665f7:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   665fd:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66603:	c4 62 c3 f6 51 58    	mulx   0x58(%rcx),%rdi,%r10
   66609:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   6660f:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66615:	66 4c 0f 38 f6 f3    	adcx   %rbx,%r14
   6661b:	49 8b 55 08          	mov    0x8(%r13),%rdx
   6661f:	31 db                	xor    %ebx,%ebx
   66621:	c4 62 c3 f6 11       	mulx   (%rcx),%rdi,%r10
   66626:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   6662c:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66632:	c4 62 c3 f6 51 08    	mulx   0x8(%rcx),%rdi,%r10
   66638:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   6663e:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66644:	c4 62 c3 f6 51 10    	mulx   0x10(%rcx),%rdi,%r10
   6664a:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   66650:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66656:	c4 62 c3 f6 51 18    	mulx   0x18(%rcx),%rdi,%r10
   6665c:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   66662:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66668:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   6666e:	49 8b 55 28          	mov    0x28(%r13),%rdx
   66672:	31 db                	xor    %ebx,%ebx
   66674:	c4 62 c3 f6 51 20    	mulx   0x20(%rcx),%rdi,%r10
   6667a:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   66680:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66686:	c4 62 c3 f6 51 28    	mulx   0x28(%rcx),%rdi,%r10
   6668c:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   66692:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66698:	c4 62 c3 f6 51 30    	mulx   0x30(%rcx),%rdi,%r10
   6669e:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   666a4:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   666aa:	c4 62 c3 f6 51 38    	mulx   0x38(%rcx),%rdi,%r10
   666b0:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   666b6:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   666bc:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   666c2:	4c 89 da             	mov    %r11,%rdx
   666c5:	49 0f af 55 40       	imul   0x40(%r13),%rdx
   666ca:	31 db                	xor    %ebx,%ebx
   666cc:	c4 62 c3 f6 51 40    	mulx   0x40(%rcx),%rdi,%r10
   666d2:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   666d8:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   666de:	c4 62 c3 f6 51 48    	mulx   0x48(%rcx),%rdi,%r10
   666e4:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   666ea:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   666f0:	c4 62 c3 f6 51 50    	mulx   0x50(%rcx),%rdi,%r10
   666f6:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   666fc:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66702:	c4 62 c3 f6 51 58    	mulx   0x58(%rcx),%rdi,%r10
   66708:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   6670e:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66714:	66 4c 0f 38 f6 c3    	adcx   %rbx,%r8
   6671a:	49 8b 55 10          	mov    0x10(%r13),%rdx
   6671e:	31 db                	xor    %ebx,%ebx
   66720:	c4 62 c3 f6 11       	mulx   (%rcx),%rdi,%r10
   66725:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   6672b:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66731:	c4 62 c3 f6 51 08    	mulx   0x8(%rcx),%rdi,%r10
   66737:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   6673d:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66743:	c4 62 c3 f6 51 10    	mulx   0x10(%rcx),%rdi,%r10
   66749:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   6674f:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66755:	c4 62 c3 f6 51 18    	mulx   0x18(%rcx),%rdi,%r10
   6675b:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   66761:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66767:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   6676d:	49 8b 55 30          	mov    0x30(%r13),%rdx
   66771:	31 db                	xor    %ebx,%ebx
   66773:	c4 62 c3 f6 51 20    	mulx   0x20(%rcx),%rdi,%r10
   66779:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   6677f:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   66785:	c4 62 c3 f6 51 28    	mulx   0x28(%rcx),%rdi,%r10
   6678b:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   66791:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66797:	c4 62 c3 f6 51 30    	mulx   0x30(%rcx),%rdi,%r10
   6679d:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   667a3:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   667a9:	c4 62 c3 f6 51 38    	mulx   0x38(%rcx),%rdi,%r10
   667af:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   667b5:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   667bb:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   667c1:	48 89 f2             	mov    %rsi,%rdx
   667c4:	49 0f af 55 40       	imul   0x40(%r13),%rdx
   667c9:	31 db                	xor    %ebx,%ebx
   667cb:	c4 62 c3 f6 51 40    	mulx   0x40(%rcx),%rdi,%r10
   667d1:	66 48 0f 38 f6 f7    	adcx   %rdi,%rsi
   667d7:	f3 49 0f 38 f6 ea    	adox   %r10,%rbp
   667dd:	c4 62 c3 f6 51 48    	mulx   0x48(%rcx),%rdi,%r10
   667e3:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   667e9:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   667ef:	c4 62 c3 f6 51 50    	mulx   0x50(%rcx),%rdi,%r10
   667f5:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   667fb:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66801:	c4 62 c3 f6 51 58    	mulx   0x58(%rcx),%rdi,%r10
   66807:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   6680d:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66813:	66 4c 0f 38 f6 db    	adcx   %rbx,%r11
   66819:	49 8b 55 18          	mov    0x18(%r13),%rdx
   6681d:	31 db                	xor    %ebx,%ebx
   6681f:	c4 62 c3 f6 11       	mulx   (%rcx),%rdi,%r10
   66824:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   6682a:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66830:	c4 62 c3 f6 51 08    	mulx   0x8(%rcx),%rdi,%r10
   66836:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   6683c:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66842:	c4 62 c3 f6 51 10    	mulx   0x10(%rcx),%rdi,%r10
   66848:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   6684e:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66854:	c4 62 c3 f6 51 18    	mulx   0x18(%rcx),%rdi,%r10
   6685a:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   66860:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66866:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   6686c:	49 8b 55 38          	mov    0x38(%r13),%rdx
   66870:	31 db                	xor    %ebx,%ebx
   66872:	c4 62 c3 f6 51 20    	mulx   0x20(%rcx),%rdi,%r10
   66878:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   6687e:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   66884:	c4 62 c3 f6 51 28    	mulx   0x28(%rcx),%rdi,%r10
   6688a:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   66890:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   66896:	c4 62 c3 f6 51 30    	mulx   0x30(%rcx),%rdi,%r10
   6689c:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   668a2:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   668a8:	c4 62 c3 f6 51 38    	mulx   0x38(%rcx),%rdi,%r10
   668ae:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   668b4:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   668ba:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   668c0:	48 89 ea             	mov    %rbp,%rdx
   668c3:	49 0f af 55 40       	imul   0x40(%r13),%rdx
   668c8:	31 db                	xor    %ebx,%ebx
   668ca:	c4 62 c3 f6 51 40    	mulx   0x40(%rcx),%rdi,%r10
   668d0:	66 48 0f 38 f6 ef    	adcx   %rdi,%rbp
   668d6:	f3 4d 0f 38 f6 f2    	adox   %r10,%r14
   668dc:	c4 62 c3 f6 51 48    	mulx   0x48(%rcx),%rdi,%r10
   668e2:	66 4c 0f 38 f6 f7    	adcx   %rdi,%r14
   668e8:	f3 4d 0f 38 f6 c2    	adox   %r10,%r8
   668ee:	c4 62 c3 f6 51 50    	mulx   0x50(%rcx),%rdi,%r10
   668f4:	66 4c 0f 38 f6 c7    	adcx   %rdi,%r8
   668fa:	f3 4d 0f 38 f6 da    	adox   %r10,%r11
   66900:	c4 62 c3 f6 51 58    	mulx   0x58(%rcx),%rdi,%r10
   66906:	66 4c 0f 38 f6 df    	adcx   %rdi,%r11
   6690c:	f3 49 0f 38 f6 f2    	adox   %r10,%rsi
   66912:	66 48 0f 38 f6 f3    	adcx   %rbx,%rsi
   66918:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   6691f:	95 7e 68 
   66922:	48 bf 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdi
   66929:	8c 20 3c 
   6692c:	49 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%r10
   66933:	45 50 b8 
   66936:	48 bb 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rbx
   6693d:	4e 64 30 
   66940:	49 39 fe             	cmp    %rdi,%r14
   66943:	49 8d 0c 08          	lea    (%r8,%rcx,1),%rcx
   66947:	48 bf 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdi
   6694e:	6a 81 97 
   66951:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
   66958:	00 
   66959:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   66960:	00 
   66961:	c5 fe 6f 84 24 10 03 	vmovdqu 0x310(%rsp),%ymm0
   66968:	00 00 
   6696a:	48 83 d9 00          	sbb    $0x0,%rcx
   6696e:	0f 92 c2             	setb   %dl
   66971:	49 39 f8             	cmp    %rdi,%r8
   66974:	40 0f 92 c7          	setb   %dil
   66978:	40 08 d7             	or     %dl,%dil
   6697b:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   66982:	ba af 47 
   66985:	40 0f b6 ff          	movzbl %dil,%edi
   66989:	4c 01 da             	add    %r11,%rdx
   6698c:	48 29 fa             	sub    %rdi,%rdx
   6698f:	40 0f 92 c7          	setb   %dil
   66993:	4d 39 d3             	cmp    %r10,%r11
   66996:	41 0f 92 c2          	setb   %r10b
   6699a:	41 08 fa             	or     %dil,%r10b
   6699d:	41 0f b6 fa          	movzbl %r10b,%edi
   669a1:	49 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%r10
   669a8:	b1 9b cf 
   669ab:	4e 8d 2c 16          	lea    (%rsi,%r10,1),%r13
   669af:	49 29 fd             	sub    %rdi,%r13
   669b2:	40 0f 92 c7          	setb   %dil
   669b6:	48 39 de             	cmp    %rbx,%rsi
   669b9:	41 0f 92 c2          	setb   %r10b
   669bd:	41 08 fa             	or     %dil,%r10b
   669c0:	49 39 df             	cmp    %rbx,%r15
   669c3:	48 bb b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rbx
   669ca:	73 df c3 
   669cd:	40 0f 92 c7          	setb   %dil
   669d1:	40 0a bc 24 d8 01 00 	or     0x1d8(%rsp),%dil
   669d8:	00 
   669d9:	48 8d 7c 1d 00       	lea    0x0(%rbp,%rbx,1),%rdi
   669de:	48 0f 45 84 24 d8 00 	cmovne 0xd8(%rsp),%rax
   669e5:	00 00 
   669e7:	4c 0f 45 8c 24 d0 00 	cmovne 0xd0(%rsp),%r9
   669ee:	00 00 
   669f0:	48 0f 45 fd          	cmovne %rbp,%rdi
   669f4:	4d 0f 45 e7          	cmovne %r15,%r12
   669f8:	45 84 d2             	test   %r10b,%r10b
   669fb:	4d 8d 14 1e          	lea    (%r14,%rbx,1),%r10
   669ff:	4d 0f 45 d6          	cmovne %r14,%r10
   66a03:	49 0f 45 c8          	cmovne %r8,%rcx
   66a07:	49 0f 45 d3          	cmovne %r11,%rdx
   66a0b:	4c 0f 45 ee          	cmovne %rsi,%r13
   66a0f:	48 89 bc 24 e0 01 00 	mov    %rdi,0x1e0(%rsp)
   66a16:	00 
   66a17:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
   66a1e:	00 
   66a1f:	4c 89 8c 24 f0 01 00 	mov    %r9,0x1f0(%rsp)
   66a26:	00 
   66a27:	4c 89 a4 24 f8 01 00 	mov    %r12,0x1f8(%rsp)
   66a2e:	00 
   66a2f:	4c 89 94 24 00 02 00 	mov    %r10,0x200(%rsp)
   66a36:	00 
   66a37:	48 89 8c 24 08 02 00 	mov    %rcx,0x208(%rsp)
   66a3e:	00 
   66a3f:	48 89 94 24 10 02 00 	mov    %rdx,0x210(%rsp)
   66a46:	00 
   66a47:	4c 89 ac 24 18 02 00 	mov    %r13,0x218(%rsp)
   66a4e:	00 
   66a4f:	c5 fd ef 84 24 e0 01 	vpxor  0x1e0(%rsp),%ymm0,%ymm0
   66a56:	00 00 
   66a58:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   66a5d:	75 19                	jne    66a78 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2f08>
   66a5f:	c5 fe 6f 84 24 30 03 	vmovdqu 0x330(%rsp),%ymm0
   66a66:	00 00 
   66a68:	c5 fd ef 84 24 00 02 	vpxor  0x200(%rsp),%ymm0,%ymm0
   66a6f:	00 00 
   66a71:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   66a76:	74 17                	je     66a8f <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2f1f>
   66a78:	31 c0                	xor    %eax,%eax
   66a7a:	48 81 c4 18 07 00 00 	add    $0x718,%rsp
   66a81:	5b                   	pop    %rbx
   66a82:	41 5c                	pop    %r12
   66a84:	41 5d                	pop    %r13
   66a86:	41 5e                	pop    %r14
   66a88:	41 5f                	pop    %r15
   66a8a:	5d                   	pop    %rbp
   66a8b:	c5 f8 77             	vzeroupper
   66a8e:	c3                   	ret
   66a8f:	c5 fc 10 84 24 70 04 	vmovups 0x470(%rsp),%ymm0
   66a96:	00 00 
   66a98:	c5 fc 10 15 a0 f5 f9 	vmovups -0x60a60(%rip),%ymm2        # 6040 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x5a0>
   66a9f:	ff 
   66aa0:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   66aa7:	00 
   66aa8:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   66aad:	31 d2                	xor    %edx,%edx
   66aaf:	31 f6                	xor    %esi,%esi
   66ab1:	31 ff                	xor    %edi,%edi
   66ab3:	45 31 c0             	xor    %r8d,%r8d
   66ab6:	c5 fc 11 84 24 20 01 	vmovups %ymm0,0x120(%rsp)
   66abd:	00 00 
   66abf:	c5 fc 11 84 24 60 01 	vmovups %ymm0,0x160(%rsp)
   66ac6:	00 00 
   66ac8:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   66ace:	48 2b 10             	sub    (%rax),%rdx
   66ad1:	48 1b 70 08          	sbb    0x8(%rax),%rsi
   66ad5:	48 1b 78 10          	sbb    0x10(%rax),%rdi
   66ad9:	4c 1b 40 18          	sbb    0x18(%rax),%r8
   66add:	48 19 ed             	sbb    %rbp,%rbp
   66ae0:	4c 8b 09             	mov    (%rcx),%r9
   66ae3:	4c 8b 51 08          	mov    0x8(%rcx),%r10
   66ae7:	4c 8b 59 10          	mov    0x10(%rcx),%r11
   66aeb:	48 8b 59 18          	mov    0x18(%rcx),%rbx
   66aef:	49 21 e9             	and    %rbp,%r9
   66af2:	49 21 ea             	and    %rbp,%r10
   66af5:	49 21 eb             	and    %rbp,%r11
   66af8:	48 21 eb             	and    %rbp,%rbx
   66afb:	4c 01 ca             	add    %r9,%rdx
   66afe:	4c 11 d6             	adc    %r10,%rsi
   66b01:	4c 11 df             	adc    %r11,%rdi
   66b04:	49 11 d8             	adc    %rbx,%r8
   66b07:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
   66b0e:	00 
   66b0f:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   66b16:	00 
   66b17:	c5 fc 10 84 24 50 04 	vmovups 0x450(%rsp),%ymm0
   66b1e:	00 00 
   66b20:	4c 8b bc 24 28 02 00 	mov    0x228(%rsp),%r15
   66b27:	00 
   66b28:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
   66b2d:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   66b32:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
   66b39:	00 
   66b3a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   66b3f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   66b44:	c5 fc 11 84 24 60 01 	vmovups %ymm0,0x160(%rsp)
   66b4b:	00 00 
   66b4d:	48 89 94 24 80 01 00 	mov    %rdx,0x180(%rsp)
   66b54:	00 
   66b55:	48 89 b4 24 88 01 00 	mov    %rsi,0x188(%rsp)
   66b5c:	00 
   66b5d:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
   66b64:	00 
   66b65:	4c 89 84 24 98 01 00 	mov    %r8,0x198(%rsp)
   66b6c:	00 
   66b6d:	c5 fc 11 94 24 a0 01 	vmovups %ymm2,0x1a0(%rsp)
   66b74:	00 00 
   66b76:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   66b7a:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   66b7f:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   66b84:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   66b89:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   66b8e:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   66b95:	00 
   66b96:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   66b9b:	48 b8 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rax
   66ba2:	07 d2 87 
   66ba5:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
   66baa:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
   66baf:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
   66bb4:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
   66bb9:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   66bbe:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   66bc4:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   66bcb:	00 00 00 00 00 
   66bd0:	45 31 db             	xor    %r11d,%r11d
   66bd3:	45 31 f6             	xor    %r14d,%r14d
   66bd6:	31 db                	xor    %ebx,%ebx
   66bd8:	31 ff                	xor    %edi,%edi
   66bda:	31 c0                	xor    %eax,%eax
   66bdc:	48 8b 16             	mov    (%rsi),%rdx
   66bdf:	45 31 d2             	xor    %r10d,%r10d
   66be2:	c4 62 bb f6 09       	mulx   (%rcx),%r8,%r9
   66be7:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66bed:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66bf3:	c4 62 bb f6 49 08    	mulx   0x8(%rcx),%r8,%r9
   66bf9:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66bff:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66c05:	c4 62 bb f6 49 10    	mulx   0x10(%rcx),%r8,%r9
   66c0b:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66c11:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66c17:	c4 62 bb f6 49 18    	mulx   0x18(%rcx),%r8,%r9
   66c1d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66c23:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66c29:	66 49 0f 38 f6 c2    	adcx   %r10,%rax
   66c2f:	48 8b 56 20          	mov    0x20(%rsi),%rdx
   66c33:	45 31 d2             	xor    %r10d,%r10d
   66c36:	c4 62 bb f6 49 20    	mulx   0x20(%rcx),%r8,%r9
   66c3c:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66c42:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66c48:	c4 62 bb f6 49 28    	mulx   0x28(%rcx),%r8,%r9
   66c4e:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66c54:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66c5a:	c4 62 bb f6 49 30    	mulx   0x30(%rcx),%r8,%r9
   66c60:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66c66:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66c6c:	c4 62 bb f6 49 38    	mulx   0x38(%rcx),%r8,%r9
   66c72:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66c78:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66c7e:	66 49 0f 38 f6 c2    	adcx   %r10,%rax
   66c84:	4c 89 da             	mov    %r11,%rdx
   66c87:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   66c8c:	45 31 d2             	xor    %r10d,%r10d
   66c8f:	c4 62 bb f6 49 40    	mulx   0x40(%rcx),%r8,%r9
   66c95:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66c9b:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66ca1:	c4 62 bb f6 49 48    	mulx   0x48(%rcx),%r8,%r9
   66ca7:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66cad:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66cb3:	c4 62 bb f6 49 50    	mulx   0x50(%rcx),%r8,%r9
   66cb9:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66cbf:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66cc5:	c4 62 bb f6 49 58    	mulx   0x58(%rcx),%r8,%r9
   66ccb:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66cd1:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66cd7:	66 49 0f 38 f6 c2    	adcx   %r10,%rax
   66cdd:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   66ce1:	45 31 d2             	xor    %r10d,%r10d
   66ce4:	c4 62 bb f6 09       	mulx   (%rcx),%r8,%r9
   66ce9:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66cef:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66cf5:	c4 62 bb f6 49 08    	mulx   0x8(%rcx),%r8,%r9
   66cfb:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66d01:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66d07:	c4 62 bb f6 49 10    	mulx   0x10(%rcx),%r8,%r9
   66d0d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66d13:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66d19:	c4 62 bb f6 49 18    	mulx   0x18(%rcx),%r8,%r9
   66d1f:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66d25:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66d2b:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   66d31:	48 8b 56 28          	mov    0x28(%rsi),%rdx
   66d35:	45 31 d2             	xor    %r10d,%r10d
   66d38:	c4 62 bb f6 49 20    	mulx   0x20(%rcx),%r8,%r9
   66d3e:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66d44:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66d4a:	c4 62 bb f6 49 28    	mulx   0x28(%rcx),%r8,%r9
   66d50:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66d56:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66d5c:	c4 62 bb f6 49 30    	mulx   0x30(%rcx),%r8,%r9
   66d62:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66d68:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66d6e:	c4 62 bb f6 49 38    	mulx   0x38(%rcx),%r8,%r9
   66d74:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66d7a:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66d80:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   66d86:	4c 89 f2             	mov    %r14,%rdx
   66d89:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   66d8e:	45 31 d2             	xor    %r10d,%r10d
   66d91:	c4 62 bb f6 49 40    	mulx   0x40(%rcx),%r8,%r9
   66d97:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66d9d:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66da3:	c4 62 bb f6 49 48    	mulx   0x48(%rcx),%r8,%r9
   66da9:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66daf:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66db5:	c4 62 bb f6 49 50    	mulx   0x50(%rcx),%r8,%r9
   66dbb:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66dc1:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66dc7:	c4 62 bb f6 49 58    	mulx   0x58(%rcx),%r8,%r9
   66dcd:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66dd3:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66dd9:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   66ddf:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   66de3:	45 31 d2             	xor    %r10d,%r10d
   66de6:	c4 62 bb f6 09       	mulx   (%rcx),%r8,%r9
   66deb:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66df1:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66df7:	c4 62 bb f6 49 08    	mulx   0x8(%rcx),%r8,%r9
   66dfd:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66e03:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66e09:	c4 62 bb f6 49 10    	mulx   0x10(%rcx),%r8,%r9
   66e0f:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66e15:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66e1b:	c4 62 bb f6 49 18    	mulx   0x18(%rcx),%r8,%r9
   66e21:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66e27:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66e2d:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   66e33:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   66e37:	45 31 d2             	xor    %r10d,%r10d
   66e3a:	c4 62 bb f6 49 20    	mulx   0x20(%rcx),%r8,%r9
   66e40:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66e46:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66e4c:	c4 62 bb f6 49 28    	mulx   0x28(%rcx),%r8,%r9
   66e52:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66e58:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66e5e:	c4 62 bb f6 49 30    	mulx   0x30(%rcx),%r8,%r9
   66e64:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66e6a:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66e70:	c4 62 bb f6 49 38    	mulx   0x38(%rcx),%r8,%r9
   66e76:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66e7c:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66e82:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   66e88:	48 89 da             	mov    %rbx,%rdx
   66e8b:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   66e90:	45 31 d2             	xor    %r10d,%r10d
   66e93:	c4 62 bb f6 49 40    	mulx   0x40(%rcx),%r8,%r9
   66e99:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   66e9f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   66ea5:	c4 62 bb f6 49 48    	mulx   0x48(%rcx),%r8,%r9
   66eab:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66eb1:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66eb7:	c4 62 bb f6 49 50    	mulx   0x50(%rcx),%r8,%r9
   66ebd:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66ec3:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66ec9:	c4 62 bb f6 49 58    	mulx   0x58(%rcx),%r8,%r9
   66ecf:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66ed5:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66edb:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   66ee1:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   66ee5:	45 31 d2             	xor    %r10d,%r10d
   66ee8:	c4 62 bb f6 09       	mulx   (%rcx),%r8,%r9
   66eed:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66ef3:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66ef9:	c4 62 bb f6 49 08    	mulx   0x8(%rcx),%r8,%r9
   66eff:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66f05:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66f0b:	c4 62 bb f6 49 10    	mulx   0x10(%rcx),%r8,%r9
   66f11:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66f17:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66f1d:	c4 62 bb f6 49 18    	mulx   0x18(%rcx),%r8,%r9
   66f23:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66f29:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66f2f:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   66f35:	48 8b 56 38          	mov    0x38(%rsi),%rdx
   66f39:	45 31 d2             	xor    %r10d,%r10d
   66f3c:	c4 62 bb f6 49 20    	mulx   0x20(%rcx),%r8,%r9
   66f42:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66f48:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66f4e:	c4 62 bb f6 49 28    	mulx   0x28(%rcx),%r8,%r9
   66f54:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66f5a:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66f60:	c4 62 bb f6 49 30    	mulx   0x30(%rcx),%r8,%r9
   66f66:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66f6c:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66f72:	c4 62 bb f6 49 38    	mulx   0x38(%rcx),%r8,%r9
   66f78:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66f7e:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66f84:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   66f8a:	48 89 fa             	mov    %rdi,%rdx
   66f8d:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   66f92:	45 31 d2             	xor    %r10d,%r10d
   66f95:	c4 62 bb f6 49 40    	mulx   0x40(%rcx),%r8,%r9
   66f9b:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   66fa1:	f3 49 0f 38 f6 c1    	adox   %r9,%rax
   66fa7:	c4 62 bb f6 49 48    	mulx   0x48(%rcx),%r8,%r9
   66fad:	66 49 0f 38 f6 c0    	adcx   %r8,%rax
   66fb3:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   66fb9:	c4 62 bb f6 49 50    	mulx   0x50(%rcx),%r8,%r9
   66fbf:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   66fc5:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   66fcb:	c4 62 bb f6 49 58    	mulx   0x58(%rcx),%r8,%r9
   66fd1:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   66fd7:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   66fdd:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   66fe3:	48 b9 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rcx
   66fea:	8c 20 3c 
   66fed:	49 ba 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%r10
   66ff4:	95 7e 68 
   66ff7:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
   66ffe:	00 
   66fff:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   67006:	6a 81 97 
   67009:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   6700e:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
   67013:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
   67018:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   6701d:	48 89 9c 24 c8 01 00 	mov    %rbx,0x1c8(%rsp)
   67024:	00 
   67025:	4c 89 9c 24 d8 01 00 	mov    %r11,0x1d8(%rsp)
   6702c:	00 
   6702d:	4c 89 b4 24 d0 01 00 	mov    %r14,0x1d0(%rsp)
   67034:	00 
   67035:	48 39 c8             	cmp    %rcx,%rax
   67038:	4b 8d 04 13          	lea    (%r11,%r10,1),%rax
   6703c:	c5 fc 10 8c 24 50 04 	vmovups 0x450(%rsp),%ymm1
   67043:	00 00 
   67045:	48 83 d8 00          	sbb    $0x0,%rax
   67049:	0f 92 c1             	setb   %cl
   6704c:	49 39 d3             	cmp    %rdx,%r11
   6704f:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
   67056:	00 
   67057:	0f 92 c2             	setb   %dl
   6705a:	08 ca                	or     %cl,%dl
   6705c:	0f b6 ca             	movzbl %dl,%ecx
   6705f:	48 ba a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdx
   67066:	ba af 47 
   67069:	49 8d 34 16          	lea    (%r14,%rdx,1),%rsi
   6706d:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   67074:	45 50 b8 
   67077:	48 29 ce             	sub    %rcx,%rsi
   6707a:	0f 92 c1             	setb   %cl
   6707d:	49 39 d6             	cmp    %rdx,%r14
   67080:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
   67087:	00 
   67088:	c5 fc 11 8c 24 00 01 	vmovups %ymm1,0x100(%rsp)
   6708f:	00 00 
   67091:	c5 fc 11 94 24 40 01 	vmovups %ymm2,0x140(%rsp)
   67098:	00 00 
   6709a:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   6709f:	0f 92 c2             	setb   %dl
   670a2:	08 ca                	or     %cl,%dl
   670a4:	0f b6 ca             	movzbl %dl,%ecx
   670a7:	48 ba d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdx
   670ae:	b1 9b cf 
   670b1:	48 8d 04 13          	lea    (%rbx,%rdx,1),%rax
   670b5:	48 29 c8             	sub    %rcx,%rax
   670b8:	48 b9 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rcx
   670bf:	07 d2 87 
   670c2:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   670c9:	00 
   670ca:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   670d1:	00 
   670d2:	41 0f 92 c7          	setb   %r15b
   670d6:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   670db:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   670e0:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   670e5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   670ea:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   670ef:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   670f6:	00 
   670f7:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   670fc:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   67101:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   67107:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   6710e:	00 00 00 00 00 
   67113:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   6711a:	8c 20 3c 
   6711d:	48 8d 8c 24 00 01 00 	lea    0x100(%rsp),%rcx
   67124:	00 
   67125:	45 31 c9             	xor    %r9d,%r9d
   67128:	45 31 db             	xor    %r11d,%r11d
   6712b:	45 31 c0             	xor    %r8d,%r8d
   6712e:	31 ff                	xor    %edi,%edi
   67130:	45 31 ed             	xor    %r13d,%r13d
   67133:	48 8b 16             	mov    (%rsi),%rdx
   67136:	45 31 e4             	xor    %r12d,%r12d
   67139:	c4 62 d3 f6 31       	mulx   (%rcx),%rbp,%r14
   6713e:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   67144:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   6714a:	c4 62 d3 f6 71 08    	mulx   0x8(%rcx),%rbp,%r14
   67150:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   67156:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   6715c:	c4 62 d3 f6 71 10    	mulx   0x10(%rcx),%rbp,%r14
   67162:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67168:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   6716e:	c4 62 d3 f6 71 18    	mulx   0x18(%rcx),%rbp,%r14
   67174:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6717a:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67180:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   67186:	48 8b 56 20          	mov    0x20(%rsi),%rdx
   6718a:	45 31 e4             	xor    %r12d,%r12d
   6718d:	c4 62 d3 f6 71 20    	mulx   0x20(%rcx),%rbp,%r14
   67193:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   67199:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   6719f:	c4 62 d3 f6 71 28    	mulx   0x28(%rcx),%rbp,%r14
   671a5:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   671ab:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   671b1:	c4 62 d3 f6 71 30    	mulx   0x30(%rcx),%rbp,%r14
   671b7:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   671bd:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   671c3:	c4 62 d3 f6 71 38    	mulx   0x38(%rcx),%rbp,%r14
   671c9:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   671cf:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   671d5:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   671db:	4c 89 ca             	mov    %r9,%rdx
   671de:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   671e3:	45 31 e4             	xor    %r12d,%r12d
   671e6:	c4 62 d3 f6 71 40    	mulx   0x40(%rcx),%rbp,%r14
   671ec:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   671f2:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   671f8:	c4 62 d3 f6 71 48    	mulx   0x48(%rcx),%rbp,%r14
   671fe:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   67204:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   6720a:	c4 62 d3 f6 71 50    	mulx   0x50(%rcx),%rbp,%r14
   67210:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67216:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   6721c:	c4 62 d3 f6 71 58    	mulx   0x58(%rcx),%rbp,%r14
   67222:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67228:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   6722e:	66 4d 0f 38 f6 ec    	adcx   %r12,%r13
   67234:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   67238:	45 31 e4             	xor    %r12d,%r12d
   6723b:	c4 62 d3 f6 31       	mulx   (%rcx),%rbp,%r14
   67240:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   67246:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   6724c:	c4 62 d3 f6 71 08    	mulx   0x8(%rcx),%rbp,%r14
   67252:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67258:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   6725e:	c4 62 d3 f6 71 10    	mulx   0x10(%rcx),%rbp,%r14
   67264:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6726a:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67270:	c4 62 d3 f6 71 18    	mulx   0x18(%rcx),%rbp,%r14
   67276:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6727c:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67282:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   67288:	48 8b 56 28          	mov    0x28(%rsi),%rdx
   6728c:	45 31 e4             	xor    %r12d,%r12d
   6728f:	c4 62 d3 f6 71 20    	mulx   0x20(%rcx),%rbp,%r14
   67295:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   6729b:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   672a1:	c4 62 d3 f6 71 28    	mulx   0x28(%rcx),%rbp,%r14
   672a7:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   672ad:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   672b3:	c4 62 d3 f6 71 30    	mulx   0x30(%rcx),%rbp,%r14
   672b9:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   672bf:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   672c5:	c4 62 d3 f6 71 38    	mulx   0x38(%rcx),%rbp,%r14
   672cb:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   672d1:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   672d7:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   672dd:	4c 89 da             	mov    %r11,%rdx
   672e0:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   672e5:	45 31 e4             	xor    %r12d,%r12d
   672e8:	c4 62 d3 f6 71 40    	mulx   0x40(%rcx),%rbp,%r14
   672ee:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   672f4:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   672fa:	c4 62 d3 f6 71 48    	mulx   0x48(%rcx),%rbp,%r14
   67300:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67306:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   6730c:	c4 62 d3 f6 71 50    	mulx   0x50(%rcx),%rbp,%r14
   67312:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67318:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   6731e:	c4 62 d3 f6 71 58    	mulx   0x58(%rcx),%rbp,%r14
   67324:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6732a:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67330:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   67336:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   6733a:	45 31 e4             	xor    %r12d,%r12d
   6733d:	c4 62 d3 f6 31       	mulx   (%rcx),%rbp,%r14
   67342:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67348:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   6734e:	c4 62 d3 f6 71 08    	mulx   0x8(%rcx),%rbp,%r14
   67354:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6735a:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67360:	c4 62 d3 f6 71 10    	mulx   0x10(%rcx),%rbp,%r14
   67366:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6736c:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67372:	c4 62 d3 f6 71 18    	mulx   0x18(%rcx),%rbp,%r14
   67378:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   6737e:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   67384:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   6738a:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   6738e:	45 31 e4             	xor    %r12d,%r12d
   67391:	c4 62 d3 f6 71 20    	mulx   0x20(%rcx),%rbp,%r14
   67397:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   6739d:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   673a3:	c4 62 d3 f6 71 28    	mulx   0x28(%rcx),%rbp,%r14
   673a9:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   673af:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   673b5:	c4 62 d3 f6 71 30    	mulx   0x30(%rcx),%rbp,%r14
   673bb:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   673c1:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   673c7:	c4 62 d3 f6 71 38    	mulx   0x38(%rcx),%rbp,%r14
   673cd:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   673d3:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   673d9:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   673df:	4c 89 c2             	mov    %r8,%rdx
   673e2:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   673e7:	45 31 e4             	xor    %r12d,%r12d
   673ea:	c4 62 d3 f6 71 40    	mulx   0x40(%rcx),%rbp,%r14
   673f0:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   673f6:	f3 49 0f 38 f6 fe    	adox   %r14,%rdi
   673fc:	c4 62 d3 f6 71 48    	mulx   0x48(%rcx),%rbp,%r14
   67402:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67408:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   6740e:	c4 62 d3 f6 71 50    	mulx   0x50(%rcx),%rbp,%r14
   67414:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6741a:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67420:	c4 62 d3 f6 71 58    	mulx   0x58(%rcx),%rbp,%r14
   67426:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   6742c:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   67432:	66 4d 0f 38 f6 dc    	adcx   %r12,%r11
   67438:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   6743c:	45 31 e4             	xor    %r12d,%r12d
   6743f:	c4 62 d3 f6 31       	mulx   (%rcx),%rbp,%r14
   67444:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6744a:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   67450:	c4 62 d3 f6 71 08    	mulx   0x8(%rcx),%rbp,%r14
   67456:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6745c:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67462:	c4 62 d3 f6 71 10    	mulx   0x10(%rcx),%rbp,%r14
   67468:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   6746e:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   67474:	c4 62 d3 f6 71 18    	mulx   0x18(%rcx),%rbp,%r14
   6747a:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   67480:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   67486:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   6748c:	48 8b 56 38          	mov    0x38(%rsi),%rdx
   67490:	45 31 e4             	xor    %r12d,%r12d
   67493:	c4 62 d3 f6 71 20    	mulx   0x20(%rcx),%rbp,%r14
   67499:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6749f:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   674a5:	c4 62 d3 f6 71 28    	mulx   0x28(%rcx),%rbp,%r14
   674ab:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   674b1:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   674b7:	c4 62 d3 f6 71 30    	mulx   0x30(%rcx),%rbp,%r14
   674bd:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   674c3:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   674c9:	c4 62 d3 f6 71 38    	mulx   0x38(%rcx),%rbp,%r14
   674cf:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   674d5:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   674db:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   674e1:	48 89 fa             	mov    %rdi,%rdx
   674e4:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   674e9:	45 31 e4             	xor    %r12d,%r12d
   674ec:	c4 62 d3 f6 71 40    	mulx   0x40(%rcx),%rbp,%r14
   674f2:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   674f8:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   674fe:	c4 62 d3 f6 71 48    	mulx   0x48(%rcx),%rbp,%r14
   67504:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6750a:	f3 4d 0f 38 f6 ce    	adox   %r14,%r9
   67510:	c4 62 d3 f6 71 50    	mulx   0x50(%rcx),%rbp,%r14
   67516:	66 4c 0f 38 f6 cd    	adcx   %rbp,%r9
   6751c:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   67522:	c4 62 d3 f6 71 58    	mulx   0x58(%rcx),%rbp,%r14
   67528:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   6752e:	f3 4d 0f 38 f6 c6    	adox   %r14,%r8
   67534:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   6753a:	49 39 c5             	cmp    %rax,%r13
   6753d:	4b 8d 04 11          	lea    (%r9,%r10,1),%rax
   67541:	48 b9 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rcx
   67548:	6a 81 97 
   6754b:	49 ba 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%r10
   67552:	4e 64 30 
   67555:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   6755b:	48 83 d8 00          	sbb    $0x0,%rax
   6755f:	4c 8b a4 24 c8 01 00 	mov    0x1c8(%rsp),%r12
   67566:	00 
   67567:	0f 92 c2             	setb   %dl
   6756a:	49 39 c9             	cmp    %rcx,%r9
   6756d:	48 b9 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rcx
   67574:	ba af 47 
   67577:	40 0f 92 c6          	setb   %sil
   6757b:	49 8d 1c 0b          	lea    (%r11,%rcx,1),%rbx
   6757f:	48 b9 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rcx
   67586:	45 50 b8 
   67589:	40 08 d6             	or     %dl,%sil
   6758c:	40 0f b6 d6          	movzbl %sil,%edx
   67590:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
   67597:	00 
   67598:	48 29 d3             	sub    %rdx,%rbx
   6759b:	0f 92 c2             	setb   %dl
   6759e:	49 39 cb             	cmp    %rcx,%r11
   675a1:	48 b9 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rcx
   675a8:	b1 9b cf 
   675ab:	40 0f 92 c7          	setb   %dil
   675af:	49 8d 2c 08          	lea    (%r8,%rcx,1),%rbp
   675b3:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   675ba:	00 
   675bb:	40 08 d7             	or     %dl,%dil
   675be:	40 0f b6 d7          	movzbl %dil,%edx
   675c2:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
   675c9:	00 
   675ca:	48 29 d5             	sub    %rdx,%rbp
   675cd:	0f 92 c2             	setb   %dl
   675d0:	4d 39 d0             	cmp    %r10,%r8
   675d3:	41 0f 92 c6          	setb   %r14b
   675d7:	41 08 d6             	or     %dl,%r14b
   675da:	4d 39 d4             	cmp    %r10,%r12
   675dd:	0f 92 c2             	setb   %dl
   675e0:	44 08 fa             	or     %r15b,%dl
   675e3:	49 bf b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%r15
   675ea:	73 df c3 
   675ed:	4a 8d 14 39          	lea    (%rcx,%r15,1),%rdx
   675f1:	48 0f 45 b4 24 d8 01 	cmovne 0x1d8(%rsp),%rsi
   675f8:	00 00 
   675fa:	48 0f 45 bc 24 d0 01 	cmovne 0x1d0(%rsp),%rdi
   67601:	00 00 
   67603:	48 0f 45 d1          	cmovne %rcx,%rdx
   67607:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
   6760e:	00 
   6760f:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
   67616:	00 
   67617:	4b 8d 54 3d 00       	lea    0x0(%r13,%r15,1),%rdx
   6761c:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
   67623:	00 
   67624:	49 0f 45 cc          	cmovne %r12,%rcx
   67628:	45 84 f6             	test   %r14b,%r14b
   6762b:	4c 8d b4 24 00 01 00 	lea    0x100(%rsp),%r14
   67632:	00 
   67633:	49 0f 45 d5          	cmovne %r13,%rdx
   67637:	49 0f 45 c1          	cmovne %r9,%rax
   6763b:	49 0f 45 db          	cmovne %r11,%rbx
   6763f:	49 0f 45 e8          	cmovne %r8,%rbp
   67643:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
   6764a:	00 
   6764b:	45 31 c9             	xor    %r9d,%r9d
   6764e:	45 31 db             	xor    %r11d,%r11d
   67651:	45 31 e4             	xor    %r12d,%r12d
   67654:	45 31 ed             	xor    %r13d,%r13d
   67657:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
   6765e:	00 
   6765f:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   67666:	00 
   67667:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   6766c:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
   67673:	00 
   67674:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
   6767b:	00 
   6767c:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   67681:	48 89 ac 24 18 01 00 	mov    %rbp,0x118(%rsp)
   67688:	00 
   67689:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   6768e:	4d 2b 0e             	sub    (%r14),%r9
   67691:	4d 1b 5e 08          	sbb    0x8(%r14),%r11
   67695:	4d 1b 66 10          	sbb    0x10(%r14),%r12
   67699:	4d 1b 6e 18          	sbb    0x18(%r14),%r13
   6769d:	4d 19 ff             	sbb    %r15,%r15
   676a0:	48 8b 10             	mov    (%rax),%rdx
   676a3:	4c 8b 40 08          	mov    0x8(%rax),%r8
   676a7:	4c 8b 50 10          	mov    0x10(%rax),%r10
   676ab:	48 8b 58 18          	mov    0x18(%rax),%rbx
   676af:	4c 21 fa             	and    %r15,%rdx
   676b2:	4d 21 f8             	and    %r15,%r8
   676b5:	4d 21 fa             	and    %r15,%r10
   676b8:	4c 21 fb             	and    %r15,%rbx
   676bb:	49 01 d1             	add    %rdx,%r9
   676be:	4d 11 c3             	adc    %r8,%r11
   676c1:	4d 11 d4             	adc    %r10,%r12
   676c4:	49 11 dd             	adc    %rbx,%r13
   676c7:	48 89 bc 24 d8 00 00 	mov    %rdi,0xd8(%rsp)
   676ce:	00 
   676cf:	4c 8d 84 24 60 01 00 	lea    0x160(%rsp),%r8
   676d6:	00 
   676d7:	4c 8d 74 24 30       	lea    0x30(%rsp),%r14
   676dc:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   676e3:	00 
   676e4:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   676eb:	00 
   676ec:	48 89 b4 24 68 01 00 	mov    %rsi,0x168(%rsp)
   676f3:	00 
   676f4:	48 89 bc 24 70 01 00 	mov    %rdi,0x170(%rsp)
   676fb:	00 
   676fc:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
   67703:	00 
   67704:	48 8d 8c 24 d0 02 00 	lea    0x2d0(%rsp),%rcx
   6770b:	00 
   6770c:	4c 89 8c 24 80 01 00 	mov    %r9,0x180(%rsp)
   67713:	00 
   67714:	4c 89 9c 24 88 01 00 	mov    %r11,0x188(%rsp)
   6771b:	00 
   6771c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
   67723:	00 
   67724:	4c 89 ac 24 98 01 00 	mov    %r13,0x198(%rsp)
   6772b:	00 
   6772c:	c5 fc 11 94 24 a0 01 	vmovups %ymm2,0x1a0(%rsp)
   67733:	00 00 
   67735:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
   6773c:	00 
   6773d:	c5 fc 10 49 20       	vmovups 0x20(%rcx),%ymm1
   67742:	c5 fc 11 4c 24 30    	vmovups %ymm1,0x30(%rsp)
   67748:	c5 fc 10 09          	vmovups (%rcx),%ymm1
   6774c:	c5 fc 11 8c 24 00 01 	vmovups %ymm1,0x100(%rsp)
   67753:	00 00 
   67755:	c5 fc 10 49 20       	vmovups 0x20(%rcx),%ymm1
   6775a:	48 b9 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rcx
   67761:	07 d2 87 
   67764:	c5 fc 11 8c 24 20 01 	vmovups %ymm1,0x120(%rsp)
   6776b:	00 00 
   6776d:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
   67774:	00 
   67775:	c5 f8 11 84 24 48 01 	vmovups %xmm0,0x148(%rsp)
   6777c:	00 00 
   6777e:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
   67785:	00 00 00 00 00 
   6778a:	31 ff                	xor    %edi,%edi
   6778c:	45 31 e4             	xor    %r12d,%r12d
   6778f:	31 f6                	xor    %esi,%esi
   67791:	45 31 d2             	xor    %r10d,%r10d
   67794:	45 31 ed             	xor    %r13d,%r13d
   67797:	49 8b 11             	mov    (%r9),%rdx
   6779a:	45 31 ff             	xor    %r15d,%r15d
   6779d:	c4 c2 a3 f6 18       	mulx   (%r8),%r11,%rbx
   677a2:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   677a8:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   677ae:	c4 c2 a3 f6 58 08    	mulx   0x8(%r8),%r11,%rbx
   677b4:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   677ba:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   677c0:	c4 c2 a3 f6 58 10    	mulx   0x10(%r8),%r11,%rbx
   677c6:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   677cc:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   677d2:	c4 c2 a3 f6 58 18    	mulx   0x18(%r8),%r11,%rbx
   677d8:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   677de:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   677e4:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   677ea:	49 8b 51 20          	mov    0x20(%r9),%rdx
   677ee:	45 31 ff             	xor    %r15d,%r15d
   677f1:	c4 c2 a3 f6 58 20    	mulx   0x20(%r8),%r11,%rbx
   677f7:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   677fd:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67803:	c4 c2 a3 f6 58 28    	mulx   0x28(%r8),%r11,%rbx
   67809:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   6780f:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67815:	c4 c2 a3 f6 58 30    	mulx   0x30(%r8),%r11,%rbx
   6781b:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   67821:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   67827:	c4 c2 a3 f6 58 38    	mulx   0x38(%r8),%r11,%rbx
   6782d:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67833:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67839:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   6783f:	48 89 fa             	mov    %rdi,%rdx
   67842:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   67847:	45 31 ff             	xor    %r15d,%r15d
   6784a:	c4 c2 a3 f6 58 40    	mulx   0x40(%r8),%r11,%rbx
   67850:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   67856:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   6785c:	c4 c2 a3 f6 58 48    	mulx   0x48(%r8),%r11,%rbx
   67862:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   67868:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   6786e:	c4 c2 a3 f6 58 50    	mulx   0x50(%r8),%r11,%rbx
   67874:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   6787a:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   67880:	c4 c2 a3 f6 58 58    	mulx   0x58(%r8),%r11,%rbx
   67886:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   6788c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67892:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   67898:	49 8b 51 08          	mov    0x8(%r9),%rdx
   6789c:	45 31 ff             	xor    %r15d,%r15d
   6789f:	c4 c2 a3 f6 18       	mulx   (%r8),%r11,%rbx
   678a4:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   678aa:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   678b0:	c4 c2 a3 f6 58 08    	mulx   0x8(%r8),%r11,%rbx
   678b6:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   678bc:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   678c2:	c4 c2 a3 f6 58 10    	mulx   0x10(%r8),%r11,%rbx
   678c8:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   678ce:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   678d4:	c4 c2 a3 f6 58 18    	mulx   0x18(%r8),%r11,%rbx
   678da:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   678e0:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   678e6:	66 49 0f 38 f6 ff    	adcx   %r15,%rdi
   678ec:	49 8b 51 28          	mov    0x28(%r9),%rdx
   678f0:	45 31 ff             	xor    %r15d,%r15d
   678f3:	c4 c2 a3 f6 58 20    	mulx   0x20(%r8),%r11,%rbx
   678f9:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   678ff:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67905:	c4 c2 a3 f6 58 28    	mulx   0x28(%r8),%r11,%rbx
   6790b:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   67911:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   67917:	c4 c2 a3 f6 58 30    	mulx   0x30(%r8),%r11,%rbx
   6791d:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67923:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67929:	c4 c2 a3 f6 58 38    	mulx   0x38(%r8),%r11,%rbx
   6792f:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67935:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   6793b:	66 49 0f 38 f6 ff    	adcx   %r15,%rdi
   67941:	4c 89 e2             	mov    %r12,%rdx
   67944:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   67949:	45 31 ff             	xor    %r15d,%r15d
   6794c:	c4 c2 a3 f6 58 40    	mulx   0x40(%r8),%r11,%rbx
   67952:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   67958:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   6795e:	c4 c2 a3 f6 58 48    	mulx   0x48(%r8),%r11,%rbx
   67964:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   6796a:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   67970:	c4 c2 a3 f6 58 50    	mulx   0x50(%r8),%r11,%rbx
   67976:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   6797c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67982:	c4 c2 a3 f6 58 58    	mulx   0x58(%r8),%r11,%rbx
   67988:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   6798e:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   67994:	66 49 0f 38 f6 ff    	adcx   %r15,%rdi
   6799a:	49 8b 51 10          	mov    0x10(%r9),%rdx
   6799e:	45 31 ff             	xor    %r15d,%r15d
   679a1:	c4 c2 a3 f6 18       	mulx   (%r8),%r11,%rbx
   679a6:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   679ac:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   679b2:	c4 c2 a3 f6 58 08    	mulx   0x8(%r8),%r11,%rbx
   679b8:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   679be:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   679c4:	c4 c2 a3 f6 58 10    	mulx   0x10(%r8),%r11,%rbx
   679ca:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   679d0:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   679d6:	c4 c2 a3 f6 58 18    	mulx   0x18(%r8),%r11,%rbx
   679dc:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   679e2:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   679e8:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   679ee:	49 8b 51 30          	mov    0x30(%r9),%rdx
   679f2:	45 31 ff             	xor    %r15d,%r15d
   679f5:	c4 c2 a3 f6 58 20    	mulx   0x20(%r8),%r11,%rbx
   679fb:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   67a01:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   67a07:	c4 c2 a3 f6 58 28    	mulx   0x28(%r8),%r11,%rbx
   67a0d:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67a13:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67a19:	c4 c2 a3 f6 58 30    	mulx   0x30(%r8),%r11,%rbx
   67a1f:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67a25:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   67a2b:	c4 c2 a3 f6 58 38    	mulx   0x38(%r8),%r11,%rbx
   67a31:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   67a37:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67a3d:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   67a43:	48 89 f2             	mov    %rsi,%rdx
   67a46:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   67a4b:	45 31 ff             	xor    %r15d,%r15d
   67a4e:	c4 c2 a3 f6 58 40    	mulx   0x40(%r8),%r11,%rbx
   67a54:	66 49 0f 38 f6 f3    	adcx   %r11,%rsi
   67a5a:	f3 4c 0f 38 f6 d3    	adox   %rbx,%r10
   67a60:	c4 c2 a3 f6 58 48    	mulx   0x48(%r8),%r11,%rbx
   67a66:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67a6c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67a72:	c4 c2 a3 f6 58 50    	mulx   0x50(%r8),%r11,%rbx
   67a78:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67a7e:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   67a84:	c4 c2 a3 f6 58 58    	mulx   0x58(%r8),%r11,%rbx
   67a8a:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   67a90:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67a96:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   67a9c:	49 8b 51 18          	mov    0x18(%r9),%rdx
   67aa0:	45 31 ff             	xor    %r15d,%r15d
   67aa3:	c4 c2 a3 f6 18       	mulx   (%r8),%r11,%rbx
   67aa8:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67aae:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67ab4:	c4 c2 a3 f6 58 08    	mulx   0x8(%r8),%r11,%rbx
   67aba:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67ac0:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   67ac6:	c4 c2 a3 f6 58 10    	mulx   0x10(%r8),%r11,%rbx
   67acc:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   67ad2:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67ad8:	c4 c2 a3 f6 58 18    	mulx   0x18(%r8),%r11,%rbx
   67ade:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   67ae4:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67aea:	66 49 0f 38 f6 f7    	adcx   %r15,%rsi
   67af0:	49 8b 51 38          	mov    0x38(%r9),%rdx
   67af4:	45 31 ff             	xor    %r15d,%r15d
   67af7:	c4 c2 a3 f6 58 20    	mulx   0x20(%r8),%r11,%rbx
   67afd:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67b03:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67b09:	c4 c2 a3 f6 58 28    	mulx   0x28(%r8),%r11,%rbx
   67b0f:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67b15:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   67b1b:	c4 c2 a3 f6 58 30    	mulx   0x30(%r8),%r11,%rbx
   67b21:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   67b27:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67b2d:	c4 c2 a3 f6 58 38    	mulx   0x38(%r8),%r11,%rbx
   67b33:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   67b39:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67b3f:	66 49 0f 38 f6 f7    	adcx   %r15,%rsi
   67b45:	4c 89 d2             	mov    %r10,%rdx
   67b48:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   67b4d:	45 31 ff             	xor    %r15d,%r15d
   67b50:	c4 c2 a3 f6 58 40    	mulx   0x40(%r8),%r11,%rbx
   67b56:	66 4d 0f 38 f6 d3    	adcx   %r11,%r10
   67b5c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   67b62:	c4 c2 a3 f6 58 48    	mulx   0x48(%r8),%r11,%rbx
   67b68:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   67b6e:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   67b74:	c4 c2 a3 f6 58 50    	mulx   0x50(%r8),%r11,%rbx
   67b7a:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   67b80:	f3 4c 0f 38 f6 e3    	adox   %rbx,%r12
   67b86:	c4 c2 a3 f6 58 58    	mulx   0x58(%r8),%r11,%rbx
   67b8c:	66 4d 0f 38 f6 e3    	adcx   %r11,%r12
   67b92:	f3 48 0f 38 f6 f3    	adox   %rbx,%rsi
   67b98:	66 49 0f 38 f6 f7    	adcx   %r15,%rsi
   67b9e:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   67ba5:	00 
   67ba6:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   67bad:	8c 20 3c 
   67bb0:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
   67bb7:	00 
   67bb8:	49 89 f9             	mov    %rdi,%r9
   67bbb:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   67bc0:	48 89 b4 24 b0 00 00 	mov    %rsi,0xb0(%rsp)
   67bc7:	00 
   67bc8:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
   67bcd:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   67bd4:	00 
   67bd5:	49 39 d5             	cmp    %rdx,%r13
   67bd8:	48 ba 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rdx
   67bdf:	95 7e 68 
   67be2:	4c 8d 2c 17          	lea    (%rdi,%rdx,1),%r13
   67be6:	48 bf 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdi
   67bed:	6a 81 97 
   67bf0:	49 83 dd 00          	sbb    $0x0,%r13
   67bf4:	0f 92 c2             	setb   %dl
   67bf7:	49 39 f9             	cmp    %rdi,%r9
   67bfa:	48 bf a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rdi
   67c01:	ba af 47 
   67c04:	41 0f 92 c1          	setb   %r9b
   67c08:	4d 8d 1c 3c          	lea    (%r12,%rdi,1),%r11
   67c0c:	48 bf 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdi
   67c13:	45 50 b8 
   67c16:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   67c1d:	00 
   67c1e:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
   67c25:	00 
   67c26:	41 08 d1             	or     %dl,%r9b
   67c29:	41 0f b6 d1          	movzbl %r9b,%edx
   67c2d:	49 29 d3             	sub    %rdx,%r11
   67c30:	0f 92 c2             	setb   %dl
   67c33:	49 39 fc             	cmp    %rdi,%r12
   67c36:	48 bf d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdi
   67c3d:	b1 9b cf 
   67c40:	41 0f 92 c1          	setb   %r9b
   67c44:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   67c4b:	00 
   67c4c:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   67c53:	00 
   67c54:	41 08 d1             	or     %dl,%r9b
   67c57:	41 0f b6 d1          	movzbl %r9b,%edx
   67c5b:	4c 8d 0c 3e          	lea    (%rsi,%rdi,1),%r9
   67c5f:	49 29 d1             	sub    %rdx,%r9
   67c62:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   67c69:	00 
   67c6a:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
   67c71:	00 
   67c72:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
   67c79:	00 
   67c7a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   67c7f:	0f 92 44 24 08       	setb   0x8(%rsp)
   67c84:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
   67c8b:	00 
   67c8c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   67c91:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   67c98:	00 
   67c99:	48 8d 84 24 d0 02 00 	lea    0x2d0(%rsp),%rax
   67ca0:	00 
   67ca1:	48 89 ac 24 38 01 00 	mov    %rbp,0x138(%rsp)
   67ca8:	00 
   67ca9:	c5 fc 11 94 24 40 01 	vmovups %ymm2,0x140(%rsp)
   67cb0:	00 00 
   67cb2:	c5 fc 10 08          	vmovups (%rax),%ymm1
   67cb6:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
   67cbd:	00 
   67cbe:	c5 fc 11 4c 24 50    	vmovups %ymm1,0x50(%rsp)
   67cc4:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   67cc9:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   67ccf:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   67cd6:	00 00 00 00 00 
   67cdb:	45 31 d2             	xor    %r10d,%r10d
   67cde:	31 ff                	xor    %edi,%edi
   67ce0:	45 31 c0             	xor    %r8d,%r8d
   67ce3:	45 31 ff             	xor    %r15d,%r15d
   67ce6:	31 db                	xor    %ebx,%ebx
   67ce8:	49 8b 16             	mov    (%r14),%rdx
   67ceb:	31 c9                	xor    %ecx,%ecx
   67ced:	c4 62 d3 f6 20       	mulx   (%rax),%rbp,%r12
   67cf2:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67cf8:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67cfe:	c4 62 d3 f6 60 08    	mulx   0x8(%rax),%rbp,%r12
   67d04:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67d0a:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67d10:	c4 62 d3 f6 60 10    	mulx   0x10(%rax),%rbp,%r12
   67d16:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67d1c:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67d22:	c4 62 d3 f6 60 18    	mulx   0x18(%rax),%rbp,%r12
   67d28:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67d2e:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67d34:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   67d3a:	49 8b 56 20          	mov    0x20(%r14),%rdx
   67d3e:	31 c9                	xor    %ecx,%ecx
   67d40:	c4 62 d3 f6 60 20    	mulx   0x20(%rax),%rbp,%r12
   67d46:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67d4c:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67d52:	c4 62 d3 f6 60 28    	mulx   0x28(%rax),%rbp,%r12
   67d58:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67d5e:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67d64:	c4 62 d3 f6 60 30    	mulx   0x30(%rax),%rbp,%r12
   67d6a:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67d70:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67d76:	c4 62 d3 f6 60 38    	mulx   0x38(%rax),%rbp,%r12
   67d7c:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67d82:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67d88:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   67d8e:	4c 89 d2             	mov    %r10,%rdx
   67d91:	49 0f af 56 40       	imul   0x40(%r14),%rdx
   67d96:	31 c9                	xor    %ecx,%ecx
   67d98:	c4 62 d3 f6 60 40    	mulx   0x40(%rax),%rbp,%r12
   67d9e:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67da4:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67daa:	c4 62 d3 f6 60 48    	mulx   0x48(%rax),%rbp,%r12
   67db0:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67db6:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67dbc:	c4 62 d3 f6 60 50    	mulx   0x50(%rax),%rbp,%r12
   67dc2:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67dc8:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67dce:	c4 62 d3 f6 60 58    	mulx   0x58(%rax),%rbp,%r12
   67dd4:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67dda:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67de0:	66 48 0f 38 f6 d9    	adcx   %rcx,%rbx
   67de6:	49 8b 56 08          	mov    0x8(%r14),%rdx
   67dea:	31 c9                	xor    %ecx,%ecx
   67dec:	c4 62 d3 f6 20       	mulx   (%rax),%rbp,%r12
   67df1:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67df7:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67dfd:	c4 62 d3 f6 60 08    	mulx   0x8(%rax),%rbp,%r12
   67e03:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67e09:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67e0f:	c4 62 d3 f6 60 10    	mulx   0x10(%rax),%rbp,%r12
   67e15:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67e1b:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67e21:	c4 62 d3 f6 60 18    	mulx   0x18(%rax),%rbp,%r12
   67e27:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67e2d:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67e33:	66 4c 0f 38 f6 d1    	adcx   %rcx,%r10
   67e39:	49 8b 56 28          	mov    0x28(%r14),%rdx
   67e3d:	31 c9                	xor    %ecx,%ecx
   67e3f:	c4 62 d3 f6 60 20    	mulx   0x20(%rax),%rbp,%r12
   67e45:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67e4b:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67e51:	c4 62 d3 f6 60 28    	mulx   0x28(%rax),%rbp,%r12
   67e57:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67e5d:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67e63:	c4 62 d3 f6 60 30    	mulx   0x30(%rax),%rbp,%r12
   67e69:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67e6f:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67e75:	c4 62 d3 f6 60 38    	mulx   0x38(%rax),%rbp,%r12
   67e7b:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67e81:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67e87:	66 4c 0f 38 f6 d1    	adcx   %rcx,%r10
   67e8d:	48 89 fa             	mov    %rdi,%rdx
   67e90:	49 0f af 56 40       	imul   0x40(%r14),%rdx
   67e95:	31 c9                	xor    %ecx,%ecx
   67e97:	c4 62 d3 f6 60 40    	mulx   0x40(%rax),%rbp,%r12
   67e9d:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   67ea3:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   67ea9:	c4 62 d3 f6 60 48    	mulx   0x48(%rax),%rbp,%r12
   67eaf:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67eb5:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67ebb:	c4 62 d3 f6 60 50    	mulx   0x50(%rax),%rbp,%r12
   67ec1:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67ec7:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67ecd:	c4 62 d3 f6 60 58    	mulx   0x58(%rax),%rbp,%r12
   67ed3:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67ed9:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67edf:	66 4c 0f 38 f6 d1    	adcx   %rcx,%r10
   67ee5:	49 8b 56 10          	mov    0x10(%r14),%rdx
   67ee9:	31 c9                	xor    %ecx,%ecx
   67eeb:	c4 62 d3 f6 20       	mulx   (%rax),%rbp,%r12
   67ef0:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67ef6:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67efc:	c4 62 d3 f6 60 08    	mulx   0x8(%rax),%rbp,%r12
   67f02:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67f08:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67f0e:	c4 62 d3 f6 60 10    	mulx   0x10(%rax),%rbp,%r12
   67f14:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67f1a:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67f20:	c4 62 d3 f6 60 18    	mulx   0x18(%rax),%rbp,%r12
   67f26:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67f2c:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67f32:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   67f38:	49 8b 56 30          	mov    0x30(%r14),%rdx
   67f3c:	31 c9                	xor    %ecx,%ecx
   67f3e:	c4 62 d3 f6 60 20    	mulx   0x20(%rax),%rbp,%r12
   67f44:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67f4a:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67f50:	c4 62 d3 f6 60 28    	mulx   0x28(%rax),%rbp,%r12
   67f56:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67f5c:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67f62:	c4 62 d3 f6 60 30    	mulx   0x30(%rax),%rbp,%r12
   67f68:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67f6e:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67f74:	c4 62 d3 f6 60 38    	mulx   0x38(%rax),%rbp,%r12
   67f7a:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67f80:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67f86:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   67f8c:	4c 89 c2             	mov    %r8,%rdx
   67f8f:	49 0f af 56 40       	imul   0x40(%r14),%rdx
   67f94:	31 c9                	xor    %ecx,%ecx
   67f96:	c4 62 d3 f6 60 40    	mulx   0x40(%rax),%rbp,%r12
   67f9c:	66 4c 0f 38 f6 c5    	adcx   %rbp,%r8
   67fa2:	f3 4d 0f 38 f6 fc    	adox   %r12,%r15
   67fa8:	c4 62 d3 f6 60 48    	mulx   0x48(%rax),%rbp,%r12
   67fae:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67fb4:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67fba:	c4 62 d3 f6 60 50    	mulx   0x50(%rax),%rbp,%r12
   67fc0:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   67fc6:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   67fcc:	c4 62 d3 f6 60 58    	mulx   0x58(%rax),%rbp,%r12
   67fd2:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   67fd8:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   67fde:	66 48 0f 38 f6 f9    	adcx   %rcx,%rdi
   67fe4:	49 8b 56 18          	mov    0x18(%r14),%rdx
   67fe8:	31 c9                	xor    %ecx,%ecx
   67fea:	c4 62 d3 f6 20       	mulx   (%rax),%rbp,%r12
   67fef:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   67ff5:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   67ffb:	c4 62 d3 f6 60 08    	mulx   0x8(%rax),%rbp,%r12
   68001:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68007:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   6800d:	c4 62 d3 f6 60 10    	mulx   0x10(%rax),%rbp,%r12
   68013:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68019:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   6801f:	c4 62 d3 f6 60 18    	mulx   0x18(%rax),%rbp,%r12
   68025:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6802b:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   68031:	66 4c 0f 38 f6 c1    	adcx   %rcx,%r8
   68037:	49 8b 56 38          	mov    0x38(%r14),%rdx
   6803b:	31 c9                	xor    %ecx,%ecx
   6803d:	c4 62 d3 f6 60 20    	mulx   0x20(%rax),%rbp,%r12
   68043:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   68049:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   6804f:	c4 62 d3 f6 60 28    	mulx   0x28(%rax),%rbp,%r12
   68055:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   6805b:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   68061:	c4 62 d3 f6 60 30    	mulx   0x30(%rax),%rbp,%r12
   68067:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   6806d:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   68073:	c4 62 d3 f6 60 38    	mulx   0x38(%rax),%rbp,%r12
   68079:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   6807f:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   68085:	66 4c 0f 38 f6 c1    	adcx   %rcx,%r8
   6808b:	4c 89 fa             	mov    %r15,%rdx
   6808e:	49 0f af 56 40       	imul   0x40(%r14),%rdx
   68093:	31 c9                	xor    %ecx,%ecx
   68095:	c4 62 d3 f6 60 40    	mulx   0x40(%rax),%rbp,%r12
   6809b:	66 4c 0f 38 f6 fd    	adcx   %rbp,%r15
   680a1:	f3 49 0f 38 f6 dc    	adox   %r12,%rbx
   680a7:	c4 62 d3 f6 60 48    	mulx   0x48(%rax),%rbp,%r12
   680ad:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   680b3:	f3 4d 0f 38 f6 d4    	adox   %r12,%r10
   680b9:	c4 62 d3 f6 60 50    	mulx   0x50(%rax),%rbp,%r12
   680bf:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   680c5:	f3 49 0f 38 f6 fc    	adox   %r12,%rdi
   680cb:	c4 62 d3 f6 60 58    	mulx   0x58(%rax),%rbp,%r12
   680d1:	66 48 0f 38 f6 fd    	adcx   %rbp,%rdi
   680d7:	f3 4d 0f 38 f6 c4    	adox   %r12,%r8
   680dd:	66 4c 0f 38 f6 c1    	adcx   %rcx,%r8
   680e3:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   680ea:	8c 20 3c 
   680ed:	49 bc 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%r12
   680f4:	4e 64 30 
   680f7:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   680fd:	48 39 c3             	cmp    %rax,%rbx
   68100:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   68107:	95 7e 68 
   6810a:	c5 fc 10 8c 24 b0 02 	vmovups 0x2b0(%rsp),%ymm1
   68111:	00 00 
   68113:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   6811a:	00 
   6811b:	49 8d 34 02          	lea    (%r10,%rax,1),%rsi
   6811f:	48 b8 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rax
   68126:	6a 81 97 
   68129:	48 83 de 00          	sbb    $0x0,%rsi
   6812d:	0f 92 c2             	setb   %dl
   68130:	49 39 c2             	cmp    %rax,%r10
   68133:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   6813a:	ba af 47 
   6813d:	40 0f 92 c5          	setb   %bpl
   68141:	40 08 d5             	or     %dl,%bpl
   68144:	48 8d 14 07          	lea    (%rdi,%rax,1),%rdx
   68148:	48 b8 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rax
   6814f:	45 50 b8 
   68152:	44 0f b6 f5          	movzbl %bpl,%r14d
   68156:	4c 29 f2             	sub    %r14,%rdx
   68159:	40 0f 92 c5          	setb   %bpl
   6815d:	48 39 c7             	cmp    %rax,%rdi
   68160:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   68167:	b1 9b cf 
   6816a:	c5 fc 11 8c 24 20 01 	vmovups %ymm1,0x120(%rsp)
   68171:	00 00 
   68173:	c5 fc 10 8c 24 b0 02 	vmovups 0x2b0(%rsp),%ymm1
   6817a:	00 00 
   6817c:	41 0f 92 c6          	setb   %r14b
   68180:	41 08 ee             	or     %bpl,%r14b
   68183:	45 0f b6 fe          	movzbl %r14b,%r15d
   68187:	4d 8d 34 00          	lea    (%r8,%rax,1),%r14
   6818b:	48 b8 b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rax
   68192:	73 df c3 
   68195:	4d 29 fe             	sub    %r15,%r14
   68198:	40 0f 92 c5          	setb   %bpl
   6819c:	4d 39 e0             	cmp    %r12,%r8
   6819f:	41 0f 92 c7          	setb   %r15b
   681a3:	41 08 ef             	or     %bpl,%r15b
   681a6:	4c 39 e1             	cmp    %r12,%rcx
   681a9:	40 0f 92 c5          	setb   %bpl
   681ad:	40 0a 6c 24 08       	or     0x8(%rsp),%bpl
   681b2:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
   681b9:	00 
   681ba:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   681c1:	00 00 
   681c3:	4c 0f 45 6c 24 28    	cmovne 0x28(%rsp),%r13
   681c9:	4c 0f 45 5c 24 20    	cmovne 0x20(%rsp),%r11
   681cf:	4c 0f 45 c9          	cmovne %rcx,%r9
   681d3:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
   681da:	00 
   681db:	4c 8d 64 05 00       	lea    0x0(%rbp,%rax,1),%r12
   681e0:	4c 0f 45 e5          	cmovne %rbp,%r12
   681e4:	45 84 ff             	test   %r15b,%r15b
   681e7:	4c 8d 3c 03          	lea    (%rbx,%rax,1),%r15
   681eb:	4c 0f 45 fb          	cmovne %rbx,%r15
   681ef:	49 0f 45 f2          	cmovne %r10,%rsi
   681f3:	48 0f 45 d7          	cmovne %rdi,%rdx
   681f7:	4d 0f 45 f0          	cmovne %r8,%r14
   681fb:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
   68202:	00 
   68203:	31 ff                	xor    %edi,%edi
   68205:	45 31 c0             	xor    %r8d,%r8d
   68208:	4c 89 ac 24 e8 01 00 	mov    %r13,0x1e8(%rsp)
   6820f:	00 
   68210:	4c 89 9c 24 f0 01 00 	mov    %r11,0x1f0(%rsp)
   68217:	00 
   68218:	4c 89 8c 24 f8 01 00 	mov    %r9,0x1f8(%rsp)
   6821f:	00 
   68220:	4c 89 bc 24 00 02 00 	mov    %r15,0x200(%rsp)
   68227:	00 
   68228:	48 89 b4 24 08 02 00 	mov    %rsi,0x208(%rsp)
   6822f:	00 
   68230:	48 89 94 24 10 02 00 	mov    %rdx,0x210(%rsp)
   68237:	00 
   68238:	4c 89 b4 24 18 02 00 	mov    %r14,0x218(%rsp)
   6823f:	00 
   68240:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   68245:	31 f6                	xor    %esi,%esi
   68247:	45 31 c9             	xor    %r9d,%r9d
   6824a:	48 2b 31             	sub    (%rcx),%rsi
   6824d:	48 1b 79 08          	sbb    0x8(%rcx),%rdi
   68251:	4c 1b 41 10          	sbb    0x10(%rcx),%r8
   68255:	4c 1b 49 18          	sbb    0x18(%rcx),%r9
   68259:	4d 19 f6             	sbb    %r14,%r14
   6825c:	4c 8b 12             	mov    (%rdx),%r10
   6825f:	4c 8b 5a 08          	mov    0x8(%rdx),%r11
   68263:	48 8b 5a 10          	mov    0x10(%rdx),%rbx
   68267:	48 8b 6a 18          	mov    0x18(%rdx),%rbp
   6826b:	4d 21 f2             	and    %r14,%r10
   6826e:	4d 21 f3             	and    %r14,%r11
   68271:	4c 21 f3             	and    %r14,%rbx
   68274:	4c 21 f5             	and    %r14,%rbp
   68277:	4c 01 d6             	add    %r10,%rsi
   6827a:	4c 11 df             	adc    %r11,%rdi
   6827d:	49 11 d8             	adc    %rbx,%r8
   68280:	49 11 e9             	adc    %rbp,%r9
   68283:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
   6828a:	00 
   6828b:	c5 fc 10 8c 24 90 02 	vmovups 0x290(%rsp),%ymm1
   68292:	00 00 
   68294:	48 8b ac 24 20 02 00 	mov    0x220(%rsp),%rbp
   6829b:	00 
   6829c:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
   682a3:	00 
   682a4:	4c 8b a4 24 f8 00 00 	mov    0xf8(%rsp),%r12
   682ab:	00 
   682ac:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   682b3:	00 
   682b4:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   682b9:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   682c0:	00 
   682c1:	c5 fc 11 8c 24 60 01 	vmovups %ymm1,0x160(%rsp)
   682c8:	00 00 
   682ca:	48 89 b4 24 80 01 00 	mov    %rsi,0x180(%rsp)
   682d1:	00 
   682d2:	48 89 bc 24 88 01 00 	mov    %rdi,0x188(%rsp)
   682d9:	00 
   682da:	4c 89 84 24 90 01 00 	mov    %r8,0x190(%rsp)
   682e1:	00 
   682e2:	4c 89 8c 24 98 01 00 	mov    %r9,0x198(%rsp)
   682e9:	00 
   682ea:	c5 fc 11 94 24 a0 01 	vmovups %ymm2,0x1a0(%rsp)
   682f1:	00 00 
   682f3:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   682f8:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   682fd:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   68304:	00 
   68305:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   6830a:	48 8b 04 24          	mov    (%rsp),%rax
   6830e:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   68313:	48 b8 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rax
   6831a:	07 d2 87 
   6831d:	48 89 6c 24 50       	mov    %rbp,0x50(%rsp)
   68322:	4c 89 7c 24 58       	mov    %r15,0x58(%rsp)
   68327:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
   6832c:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
   68331:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   68336:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   6833c:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   68343:	00 00 00 00 00 
   68348:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   6834f:	00 
   68350:	45 31 db             	xor    %r11d,%r11d
   68353:	45 31 f6             	xor    %r14d,%r14d
   68356:	31 db                	xor    %ebx,%ebx
   68358:	31 ff                	xor    %edi,%edi
   6835a:	31 c9                	xor    %ecx,%ecx
   6835c:	48 8b 16             	mov    (%rsi),%rdx
   6835f:	45 31 d2             	xor    %r10d,%r10d
   68362:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   68367:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6836d:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   68373:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   68379:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6837f:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   68385:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   6838b:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   68391:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68397:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   6839d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   683a3:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   683a9:	66 49 0f 38 f6 ca    	adcx   %r10,%rcx
   683af:	48 8b 56 20          	mov    0x20(%rsi),%rdx
   683b3:	45 31 d2             	xor    %r10d,%r10d
   683b6:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   683bc:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   683c2:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   683c8:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   683ce:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   683d4:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   683da:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   683e0:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   683e6:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   683ec:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   683f2:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   683f8:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   683fe:	66 49 0f 38 f6 ca    	adcx   %r10,%rcx
   68404:	4c 89 da             	mov    %r11,%rdx
   68407:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   6840c:	45 31 d2             	xor    %r10d,%r10d
   6840f:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   68415:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   6841b:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   68421:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   68427:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6842d:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   68433:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   68439:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6843f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68445:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   6844b:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68451:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68457:	66 49 0f 38 f6 ca    	adcx   %r10,%rcx
   6845d:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   68461:	45 31 d2             	xor    %r10d,%r10d
   68464:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   68469:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6846f:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   68475:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   6847b:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   68481:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68487:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   6848d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68493:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68499:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   6849f:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   684a5:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   684ab:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   684b1:	48 8b 56 28          	mov    0x28(%rsi),%rdx
   684b5:	45 31 d2             	xor    %r10d,%r10d
   684b8:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   684be:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   684c4:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   684ca:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   684d0:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   684d6:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   684dc:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   684e2:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   684e8:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   684ee:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   684f4:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   684fa:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   68500:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   68506:	4c 89 f2             	mov    %r14,%rdx
   68509:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   6850e:	45 31 d2             	xor    %r10d,%r10d
   68511:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   68517:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   6851d:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   68523:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   68529:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6852f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68535:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   6853b:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68541:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68547:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   6854d:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   68553:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   68559:	66 4d 0f 38 f6 da    	adcx   %r10,%r11
   6855f:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   68563:	45 31 d2             	xor    %r10d,%r10d
   68566:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   6856b:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   68571:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68577:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   6857d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68583:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68589:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   6858f:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   68595:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6859b:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   685a1:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   685a7:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   685ad:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   685b3:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   685b7:	45 31 d2             	xor    %r10d,%r10d
   685ba:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   685c0:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   685c6:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   685cc:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   685d2:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   685d8:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   685de:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   685e4:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   685ea:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   685f0:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   685f6:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   685fc:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   68602:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   68608:	48 89 da             	mov    %rbx,%rdx
   6860b:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   68610:	45 31 d2             	xor    %r10d,%r10d
   68613:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   68619:	66 49 0f 38 f6 d8    	adcx   %r8,%rbx
   6861f:	f3 49 0f 38 f6 f9    	adox   %r9,%rdi
   68625:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   6862b:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68631:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68637:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   6863d:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   68643:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   68649:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   6864f:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   68655:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   6865b:	66 4d 0f 38 f6 f2    	adcx   %r10,%r14
   68661:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   68665:	45 31 d2             	xor    %r10d,%r10d
   68668:	c4 62 bb f6 08       	mulx   (%rax),%r8,%r9
   6866d:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68673:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68679:	c4 62 bb f6 48 08    	mulx   0x8(%rax),%r8,%r9
   6867f:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   68685:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   6868b:	c4 62 bb f6 48 10    	mulx   0x10(%rax),%r8,%r9
   68691:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   68697:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   6869d:	c4 62 bb f6 48 18    	mulx   0x18(%rax),%r8,%r9
   686a3:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   686a9:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   686af:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   686b5:	48 8b 56 38          	mov    0x38(%rsi),%rdx
   686b9:	45 31 d2             	xor    %r10d,%r10d
   686bc:	c4 62 bb f6 48 20    	mulx   0x20(%rax),%r8,%r9
   686c2:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   686c8:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   686ce:	c4 62 bb f6 48 28    	mulx   0x28(%rax),%r8,%r9
   686d4:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   686da:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   686e0:	c4 62 bb f6 48 30    	mulx   0x30(%rax),%r8,%r9
   686e6:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   686ec:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   686f2:	c4 62 bb f6 48 38    	mulx   0x38(%rax),%r8,%r9
   686f8:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   686fe:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   68704:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   6870a:	48 89 fa             	mov    %rdi,%rdx
   6870d:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   68712:	45 31 d2             	xor    %r10d,%r10d
   68715:	c4 62 bb f6 48 40    	mulx   0x40(%rax),%r8,%r9
   6871b:	66 49 0f 38 f6 f8    	adcx   %r8,%rdi
   68721:	f3 49 0f 38 f6 c9    	adox   %r9,%rcx
   68727:	c4 62 bb f6 48 48    	mulx   0x48(%rax),%r8,%r9
   6872d:	66 49 0f 38 f6 c8    	adcx   %r8,%rcx
   68733:	f3 4d 0f 38 f6 d9    	adox   %r9,%r11
   68739:	c4 62 bb f6 48 50    	mulx   0x50(%rax),%r8,%r9
   6873f:	66 4d 0f 38 f6 d8    	adcx   %r8,%r11
   68745:	f3 4d 0f 38 f6 f1    	adox   %r9,%r14
   6874b:	c4 62 bb f6 48 58    	mulx   0x58(%rax),%r8,%r9
   68751:	66 4d 0f 38 f6 f0    	adcx   %r8,%r14
   68757:	f3 49 0f 38 f6 d9    	adox   %r9,%rbx
   6875d:	66 49 0f 38 f6 da    	adcx   %r10,%rbx
   68763:	48 b8 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rax
   6876a:	8c 20 3c 
   6876d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
   68772:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
   68777:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
   6877c:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   68781:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
   68786:	48 89 9c 24 b0 00 00 	mov    %rbx,0xb0(%rsp)
   6878d:	00 
   6878e:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
   68793:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
   6879a:	00 
   6879b:	4c 8d 84 24 00 01 00 	lea    0x100(%rsp),%r8
   687a2:	00 
   687a3:	4c 8d 4c 24 30       	lea    0x30(%rsp),%r9
   687a8:	48 39 c1             	cmp    %rax,%rcx
   687ab:	48 b8 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rax
   687b2:	95 7e 68 
   687b5:	c5 fc 10 8c 24 90 02 	vmovups 0x290(%rsp),%ymm1
   687bc:	00 00 
   687be:	49 8d 04 03          	lea    (%r11,%rax,1),%rax
   687c2:	48 83 d8 00          	sbb    $0x0,%rax
   687c6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   687cb:	48 b8 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rax
   687d2:	6a 81 97 
   687d5:	0f 92 c2             	setb   %dl
   687d8:	49 39 c3             	cmp    %rax,%r11
   687db:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   687e2:	ba af 47 
   687e5:	40 0f 92 c6          	setb   %sil
   687e9:	40 08 d6             	or     %dl,%sil
   687ec:	40 0f b6 d6          	movzbl %sil,%edx
   687f0:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
   687f4:	48 b8 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rax
   687fb:	45 50 b8 
   687fe:	48 29 d6             	sub    %rdx,%rsi
   68801:	c5 fc 11 8c 24 00 01 	vmovups %ymm1,0x100(%rsp)
   68808:	00 00 
   6880a:	c5 fc 11 94 24 40 01 	vmovups %ymm2,0x140(%rsp)
   68811:	00 00 
   68813:	0f 92 c2             	setb   %dl
   68816:	49 39 c6             	cmp    %rax,%r14
   68819:	40 0f 92 c7          	setb   %dil
   6881d:	40 08 d7             	or     %dl,%dil
   68820:	40 0f b6 d7          	movzbl %dil,%edx
   68824:	48 bf d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rdi
   6882b:	b1 9b cf 
   6882e:	48 8d 0c 3b          	lea    (%rbx,%rdi,1),%rcx
   68832:	48 29 d1             	sub    %rdx,%rcx
   68835:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   6883a:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
   68841:	00 
   68842:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   68847:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
   6884e:	00 
   6884f:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   68854:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   6885b:	00 
   6885c:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   68861:	48 8b 0c 24          	mov    (%rsp),%rcx
   68865:	0f 92 04 24          	setb   (%rsp)
   68869:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
   6886e:	48 b9 89 63 86 e4 82 	movabs $0x87d20782e4866389,%rcx
   68875:	07 d2 87 
   68878:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   6887d:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   68883:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   6888a:	00 00 00 00 00 
   6888f:	48 b9 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rcx
   68896:	8c 20 3c 
   68899:	45 31 db             	xor    %r11d,%r11d
   6889c:	45 31 ed             	xor    %r13d,%r13d
   6889f:	45 31 e4             	xor    %r12d,%r12d
   688a2:	45 31 d2             	xor    %r10d,%r10d
   688a5:	31 db                	xor    %ebx,%ebx
   688a7:	49 8b 11             	mov    (%r9),%rdx
   688aa:	45 31 ff             	xor    %r15d,%r15d
   688ad:	c4 42 d3 f6 30       	mulx   (%r8),%rbp,%r14
   688b2:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   688b8:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   688be:	c4 42 d3 f6 70 08    	mulx   0x8(%r8),%rbp,%r14
   688c4:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   688ca:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   688d0:	c4 42 d3 f6 70 10    	mulx   0x10(%r8),%rbp,%r14
   688d6:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   688dc:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   688e2:	c4 42 d3 f6 70 18    	mulx   0x18(%r8),%rbp,%r14
   688e8:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   688ee:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   688f4:	66 49 0f 38 f6 df    	adcx   %r15,%rbx
   688fa:	49 8b 51 20          	mov    0x20(%r9),%rdx
   688fe:	45 31 ff             	xor    %r15d,%r15d
   68901:	c4 42 d3 f6 70 20    	mulx   0x20(%r8),%rbp,%r14
   68907:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   6890d:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68913:	c4 42 d3 f6 70 28    	mulx   0x28(%r8),%rbp,%r14
   68919:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   6891f:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68925:	c4 42 d3 f6 70 30    	mulx   0x30(%r8),%rbp,%r14
   6892b:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   68931:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   68937:	c4 42 d3 f6 70 38    	mulx   0x38(%r8),%rbp,%r14
   6893d:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68943:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68949:	66 49 0f 38 f6 df    	adcx   %r15,%rbx
   6894f:	4c 89 da             	mov    %r11,%rdx
   68952:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   68957:	45 31 ff             	xor    %r15d,%r15d
   6895a:	c4 42 d3 f6 70 40    	mulx   0x40(%r8),%rbp,%r14
   68960:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68966:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   6896c:	c4 42 d3 f6 70 48    	mulx   0x48(%r8),%rbp,%r14
   68972:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68978:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   6897e:	c4 42 d3 f6 70 50    	mulx   0x50(%r8),%rbp,%r14
   68984:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   6898a:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   68990:	c4 42 d3 f6 70 58    	mulx   0x58(%r8),%rbp,%r14
   68996:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   6899c:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   689a2:	66 49 0f 38 f6 df    	adcx   %r15,%rbx
   689a8:	49 8b 51 08          	mov    0x8(%r9),%rdx
   689ac:	45 31 ff             	xor    %r15d,%r15d
   689af:	c4 42 d3 f6 30       	mulx   (%r8),%rbp,%r14
   689b4:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   689ba:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   689c0:	c4 42 d3 f6 70 08    	mulx   0x8(%r8),%rbp,%r14
   689c6:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   689cc:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   689d2:	c4 42 d3 f6 70 10    	mulx   0x10(%r8),%rbp,%r14
   689d8:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   689de:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   689e4:	c4 42 d3 f6 70 18    	mulx   0x18(%r8),%rbp,%r14
   689ea:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   689f0:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   689f6:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   689fc:	49 8b 51 28          	mov    0x28(%r9),%rdx
   68a00:	45 31 ff             	xor    %r15d,%r15d
   68a03:	c4 42 d3 f6 70 20    	mulx   0x20(%r8),%rbp,%r14
   68a09:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68a0f:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68a15:	c4 42 d3 f6 70 28    	mulx   0x28(%r8),%rbp,%r14
   68a1b:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   68a21:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   68a27:	c4 42 d3 f6 70 30    	mulx   0x30(%r8),%rbp,%r14
   68a2d:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68a33:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68a39:	c4 42 d3 f6 70 38    	mulx   0x38(%r8),%rbp,%r14
   68a3f:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68a45:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68a4b:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   68a51:	4c 89 ea             	mov    %r13,%rdx
   68a54:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   68a59:	45 31 ff             	xor    %r15d,%r15d
   68a5c:	c4 42 d3 f6 70 40    	mulx   0x40(%r8),%rbp,%r14
   68a62:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68a68:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68a6e:	c4 42 d3 f6 70 48    	mulx   0x48(%r8),%rbp,%r14
   68a74:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   68a7a:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   68a80:	c4 42 d3 f6 70 50    	mulx   0x50(%r8),%rbp,%r14
   68a86:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68a8c:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68a92:	c4 42 d3 f6 70 58    	mulx   0x58(%r8),%rbp,%r14
   68a98:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68a9e:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68aa4:	66 4d 0f 38 f6 df    	adcx   %r15,%r11
   68aaa:	49 8b 51 10          	mov    0x10(%r9),%rdx
   68aae:	45 31 ff             	xor    %r15d,%r15d
   68ab1:	c4 42 d3 f6 30       	mulx   (%r8),%rbp,%r14
   68ab6:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   68abc:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   68ac2:	c4 42 d3 f6 70 08    	mulx   0x8(%r8),%rbp,%r14
   68ac8:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68ace:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68ad4:	c4 42 d3 f6 70 10    	mulx   0x10(%r8),%rbp,%r14
   68ada:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68ae0:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68ae6:	c4 42 d3 f6 70 18    	mulx   0x18(%r8),%rbp,%r14
   68aec:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68af2:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68af8:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68afe:	49 8b 51 30          	mov    0x30(%r9),%rdx
   68b02:	45 31 ff             	xor    %r15d,%r15d
   68b05:	c4 42 d3 f6 70 20    	mulx   0x20(%r8),%rbp,%r14
   68b0b:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   68b11:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   68b17:	c4 42 d3 f6 70 28    	mulx   0x28(%r8),%rbp,%r14
   68b1d:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68b23:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68b29:	c4 42 d3 f6 70 30    	mulx   0x30(%r8),%rbp,%r14
   68b2f:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68b35:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68b3b:	c4 42 d3 f6 70 38    	mulx   0x38(%r8),%rbp,%r14
   68b41:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68b47:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68b4d:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68b53:	4c 89 e2             	mov    %r12,%rdx
   68b56:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   68b5b:	45 31 ff             	xor    %r15d,%r15d
   68b5e:	c4 42 d3 f6 70 40    	mulx   0x40(%r8),%rbp,%r14
   68b64:	66 4c 0f 38 f6 e5    	adcx   %rbp,%r12
   68b6a:	f3 4d 0f 38 f6 d6    	adox   %r14,%r10
   68b70:	c4 42 d3 f6 70 48    	mulx   0x48(%r8),%rbp,%r14
   68b76:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68b7c:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68b82:	c4 42 d3 f6 70 50    	mulx   0x50(%r8),%rbp,%r14
   68b88:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68b8e:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68b94:	c4 42 d3 f6 70 58    	mulx   0x58(%r8),%rbp,%r14
   68b9a:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68ba0:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68ba6:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68bac:	49 8b 51 18          	mov    0x18(%r9),%rdx
   68bb0:	45 31 ff             	xor    %r15d,%r15d
   68bb3:	c4 42 d3 f6 30       	mulx   (%r8),%rbp,%r14
   68bb8:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68bbe:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68bc4:	c4 42 d3 f6 70 08    	mulx   0x8(%r8),%rbp,%r14
   68bca:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68bd0:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68bd6:	c4 42 d3 f6 70 10    	mulx   0x10(%r8),%rbp,%r14
   68bdc:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68be2:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68be8:	c4 42 d3 f6 70 18    	mulx   0x18(%r8),%rbp,%r14
   68bee:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68bf4:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68bfa:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   68c00:	49 8b 51 38          	mov    0x38(%r9),%rdx
   68c04:	45 31 ff             	xor    %r15d,%r15d
   68c07:	c4 42 d3 f6 70 20    	mulx   0x20(%r8),%rbp,%r14
   68c0d:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68c13:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68c19:	c4 42 d3 f6 70 28    	mulx   0x28(%r8),%rbp,%r14
   68c1f:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68c25:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68c2b:	c4 42 d3 f6 70 30    	mulx   0x30(%r8),%rbp,%r14
   68c31:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68c37:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68c3d:	c4 42 d3 f6 70 38    	mulx   0x38(%r8),%rbp,%r14
   68c43:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68c49:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68c4f:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   68c55:	4c 89 d2             	mov    %r10,%rdx
   68c58:	49 0f af 51 40       	imul   0x40(%r9),%rdx
   68c5d:	45 31 ff             	xor    %r15d,%r15d
   68c60:	c4 42 d3 f6 70 40    	mulx   0x40(%r8),%rbp,%r14
   68c66:	66 4c 0f 38 f6 d5    	adcx   %rbp,%r10
   68c6c:	f3 49 0f 38 f6 de    	adox   %r14,%rbx
   68c72:	c4 42 d3 f6 70 48    	mulx   0x48(%r8),%rbp,%r14
   68c78:	66 48 0f 38 f6 dd    	adcx   %rbp,%rbx
   68c7e:	f3 4d 0f 38 f6 de    	adox   %r14,%r11
   68c84:	c4 42 d3 f6 70 50    	mulx   0x50(%r8),%rbp,%r14
   68c8a:	66 4c 0f 38 f6 dd    	adcx   %rbp,%r11
   68c90:	f3 4d 0f 38 f6 ee    	adox   %r14,%r13
   68c96:	c4 42 d3 f6 70 58    	mulx   0x58(%r8),%rbp,%r14
   68c9c:	66 4c 0f 38 f6 ed    	adcx   %rbp,%r13
   68ca2:	f3 4d 0f 38 f6 e6    	adox   %r14,%r12
   68ca8:	66 4d 0f 38 f6 e7    	adcx   %r15,%r12
   68cae:	48 39 cb             	cmp    %rcx,%rbx
   68cb1:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   68cb8:	95 7e 68 
   68cbb:	c5 fc 11 54 24 30    	vmovups %ymm2,0x30(%rsp)
   68cc1:	4d 8d 3c 0b          	lea    (%r11,%rcx,1),%r15
   68cc5:	48 b9 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rcx
   68ccc:	6a 81 97 
   68ccf:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
   68cd4:	49 83 df 00          	sbb    $0x0,%r15
   68cd8:	0f 92 c2             	setb   %dl
   68cdb:	49 39 cb             	cmp    %rcx,%r11
   68cde:	48 b9 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rcx
   68ce5:	ba af 47 
   68ce8:	41 0f 92 c1          	setb   %r9b
   68cec:	49 8d 6c 0d 00       	lea    0x0(%r13,%rcx,1),%rbp
   68cf1:	48 b9 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rcx
   68cf8:	4e 64 30 
   68cfb:	41 08 d1             	or     %dl,%r9b
   68cfe:	41 0f b6 d1          	movzbl %r9b,%edx
   68d02:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
   68d07:	48 29 d5             	sub    %rdx,%rbp
   68d0a:	0f 92 c2             	setb   %dl
   68d0d:	49 39 c5             	cmp    %rax,%r13
   68d10:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   68d15:	41 0f 92 c2          	setb   %r10b
   68d19:	41 08 d2             	or     %dl,%r10b
   68d1c:	41 0f b6 d2          	movzbl %r10b,%edx
   68d20:	4d 8d 14 3c          	lea    (%r12,%rdi,1),%r10
   68d24:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
   68d2b:	00 
   68d2c:	49 29 d2             	sub    %rdx,%r10
   68d2f:	0f 92 c2             	setb   %dl
   68d32:	49 39 cc             	cmp    %rcx,%r12
   68d35:	41 0f 92 c6          	setb   %r14b
   68d39:	41 08 d6             	or     %dl,%r14b
   68d3c:	48 39 cf             	cmp    %rcx,%rdi
   68d3f:	48 b9 b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rcx
   68d46:	73 df c3 
   68d49:	0f 92 c2             	setb   %dl
   68d4c:	0a 14 24             	or     (%rsp),%dl
   68d4f:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
   68d53:	48 8d 0c 0b          	lea    (%rbx,%rcx,1),%rcx
   68d57:	4c 0f 45 4c 24 18    	cmovne 0x18(%rsp),%r9
   68d5d:	48 0f 45 b4 24 98 00 	cmovne 0x98(%rsp),%rsi
   68d64:	00 00 
   68d66:	48 0f 45 d0          	cmovne %rax,%rdx
   68d6a:	4c 0f 45 c7          	cmovne %rdi,%r8
   68d6e:	45 84 f6             	test   %r14b,%r14b
   68d71:	4c 8d b4 24 00 01 00 	lea    0x100(%rsp),%r14
   68d78:	00 
   68d79:	48 0f 45 cb          	cmovne %rbx,%rcx
   68d7d:	4d 0f 45 fb          	cmovne %r11,%r15
   68d81:	49 0f 45 ed          	cmovne %r13,%rbp
   68d85:	4d 0f 45 d4          	cmovne %r12,%r10
   68d89:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
   68d90:	00 
   68d91:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
   68d96:	48 89 d0             	mov    %rdx,%rax
   68d99:	31 db                	xor    %ebx,%ebx
   68d9b:	45 31 e4             	xor    %r12d,%r12d
   68d9e:	45 31 ed             	xor    %r13d,%r13d
   68da1:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
   68da8:	00 
   68da9:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
   68db0:	00 
   68db1:	4c 89 bc 24 a0 00 00 	mov    %r15,0xa0(%rsp)
   68db8:	00 
   68db9:	48 89 ac 24 10 01 00 	mov    %rbp,0x110(%rsp)
   68dc0:	00 
   68dc1:	48 89 ac 24 98 00 00 	mov    %rbp,0x98(%rsp)
   68dc8:	00 
   68dc9:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   68dce:	4c 89 94 24 18 01 00 	mov    %r10,0x118(%rsp)
   68dd5:	00 
   68dd6:	45 31 ff             	xor    %r15d,%r15d
   68dd9:	48 8d 6c 24 30       	lea    0x30(%rsp),%rbp
   68dde:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
   68de3:	48 89 34 24          	mov    %rsi,(%rsp)
   68de7:	49 2b 1e             	sub    (%r14),%rbx
   68dea:	4d 1b 7e 08          	sbb    0x8(%r14),%r15
   68dee:	4d 1b 66 10          	sbb    0x10(%r14),%r12
   68df2:	4d 1b 6e 18          	sbb    0x18(%r14),%r13
   68df6:	48 19 ff             	sbb    %rdi,%rdi
   68df9:	48 8b 55 00          	mov    0x0(%rbp),%rdx
   68dfd:	4c 8b 5d 08          	mov    0x8(%rbp),%r11
   68e01:	48 8b 4d 10          	mov    0x10(%rbp),%rcx
   68e05:	48 8b 75 18          	mov    0x18(%rbp),%rsi
   68e09:	48 21 fa             	and    %rdi,%rdx
   68e0c:	49 21 fb             	and    %rdi,%r11
   68e0f:	48 21 f9             	and    %rdi,%rcx
   68e12:	48 21 fe             	and    %rdi,%rsi
   68e15:	48 01 d3             	add    %rdx,%rbx
   68e18:	4d 11 df             	adc    %r11,%r15
   68e1b:	49 11 cc             	adc    %rcx,%r12
   68e1e:	49 11 f5             	adc    %rsi,%r13
   68e21:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   68e28:	00 
   68e29:	4c 89 8c 24 68 01 00 	mov    %r9,0x168(%rsp)
   68e30:	00 
   68e31:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
   68e38:	00 
   68e39:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   68e40:	00 
   68e41:	48 8b 04 24          	mov    (%rsp),%rax
   68e45:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
   68e4c:	00 
   68e4d:	48 8d 84 24 90 04 00 	lea    0x490(%rsp),%rax
   68e54:	00 
   68e55:	4c 89 84 24 78 01 00 	mov    %r8,0x178(%rsp)
   68e5c:	00 
   68e5d:	48 89 9c 24 80 01 00 	mov    %rbx,0x180(%rsp)
   68e64:	00 
   68e65:	4c 89 bc 24 88 01 00 	mov    %r15,0x188(%rsp)
   68e6c:	00 
   68e6d:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
   68e74:	00 
   68e75:	49 bc 89 63 86 e4 82 	movabs $0x87d20782e4866389,%r12
   68e7c:	07 d2 87 
   68e7f:	4c 89 ac 24 98 01 00 	mov    %r13,0x198(%rsp)
   68e86:	00 
   68e87:	c5 fc 11 94 24 a0 01 	vmovups %ymm2,0x1a0(%rsp)
   68e8e:	00 00 
   68e90:	c5 fc 10 48 20       	vmovups 0x20(%rax),%ymm1
   68e95:	c5 fc 11 4c 24 30    	vmovups %ymm1,0x30(%rsp)
   68e9b:	c5 fc 10 08          	vmovups (%rax),%ymm1
   68e9f:	c5 fc 11 8c 24 00 01 	vmovups %ymm1,0x100(%rsp)
   68ea6:	00 00 
   68ea8:	c5 fc 10 48 20       	vmovups 0x20(%rax),%ymm1
   68ead:	c5 fc 11 8c 24 20 01 	vmovups %ymm1,0x120(%rsp)
   68eb4:	00 00 
   68eb6:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
   68ebd:	00 
   68ebe:	c5 f8 11 84 24 48 01 	vmovups %xmm0,0x148(%rsp)
   68ec5:	00 00 
   68ec7:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
   68ece:	00 00 00 00 00 
   68ed3:	31 c0                	xor    %eax,%eax
   68ed5:	45 31 c9             	xor    %r9d,%r9d
   68ed8:	45 31 c0             	xor    %r8d,%r8d
   68edb:	31 ff                	xor    %edi,%edi
   68edd:	45 31 ed             	xor    %r13d,%r13d
   68ee0:	48 8b 16             	mov    (%rsi),%rdx
   68ee3:	45 31 ff             	xor    %r15d,%r15d
   68ee6:	c4 e2 a3 f6 19       	mulx   (%rcx),%r11,%rbx
   68eeb:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   68ef1:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   68ef7:	c4 e2 a3 f6 59 08    	mulx   0x8(%rcx),%r11,%rbx
   68efd:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68f03:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68f09:	c4 e2 a3 f6 59 10    	mulx   0x10(%rcx),%r11,%rbx
   68f0f:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68f15:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68f1b:	c4 e2 a3 f6 59 18    	mulx   0x18(%rcx),%r11,%rbx
   68f21:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68f27:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68f2d:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68f33:	48 8b 56 20          	mov    0x20(%rsi),%rdx
   68f37:	45 31 ff             	xor    %r15d,%r15d
   68f3a:	c4 e2 a3 f6 59 20    	mulx   0x20(%rcx),%r11,%rbx
   68f40:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   68f46:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   68f4c:	c4 e2 a3 f6 59 28    	mulx   0x28(%rcx),%r11,%rbx
   68f52:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68f58:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68f5e:	c4 e2 a3 f6 59 30    	mulx   0x30(%rcx),%r11,%rbx
   68f64:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68f6a:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68f70:	c4 e2 a3 f6 59 38    	mulx   0x38(%rcx),%r11,%rbx
   68f76:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68f7c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68f82:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68f88:	48 89 c2             	mov    %rax,%rdx
   68f8b:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   68f90:	45 31 ff             	xor    %r15d,%r15d
   68f93:	c4 e2 a3 f6 59 40    	mulx   0x40(%rcx),%r11,%rbx
   68f99:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   68f9f:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   68fa5:	c4 e2 a3 f6 59 48    	mulx   0x48(%rcx),%r11,%rbx
   68fab:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68fb1:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68fb7:	c4 e2 a3 f6 59 50    	mulx   0x50(%rcx),%r11,%rbx
   68fbd:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   68fc3:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   68fc9:	c4 e2 a3 f6 59 58    	mulx   0x58(%rcx),%r11,%rbx
   68fcf:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   68fd5:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   68fdb:	66 4d 0f 38 f6 ef    	adcx   %r15,%r13
   68fe1:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   68fe5:	45 31 ff             	xor    %r15d,%r15d
   68fe8:	c4 e2 a3 f6 19       	mulx   (%rcx),%r11,%rbx
   68fed:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   68ff3:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   68ff9:	c4 e2 a3 f6 59 08    	mulx   0x8(%rcx),%r11,%rbx
   68fff:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   69005:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   6900b:	c4 e2 a3 f6 59 10    	mulx   0x10(%rcx),%r11,%rbx
   69011:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   69017:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   6901d:	c4 e2 a3 f6 59 18    	mulx   0x18(%rcx),%r11,%rbx
   69023:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   69029:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   6902f:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   69035:	48 8b 56 28          	mov    0x28(%rsi),%rdx
   69039:	45 31 ff             	xor    %r15d,%r15d
   6903c:	c4 e2 a3 f6 59 20    	mulx   0x20(%rcx),%r11,%rbx
   69042:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   69048:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   6904e:	c4 e2 a3 f6 59 28    	mulx   0x28(%rcx),%r11,%rbx
   69054:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   6905a:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   69060:	c4 e2 a3 f6 59 30    	mulx   0x30(%rcx),%r11,%rbx
   69066:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   6906c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   69072:	c4 e2 a3 f6 59 38    	mulx   0x38(%rcx),%r11,%rbx
   69078:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   6907e:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   69084:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   6908a:	4c 89 ca             	mov    %r9,%rdx
   6908d:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   69092:	45 31 ff             	xor    %r15d,%r15d
   69095:	c4 e2 a3 f6 59 40    	mulx   0x40(%rcx),%r11,%rbx
   6909b:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   690a1:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   690a7:	c4 e2 a3 f6 59 48    	mulx   0x48(%rcx),%r11,%rbx
   690ad:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   690b3:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   690b9:	c4 e2 a3 f6 59 50    	mulx   0x50(%rcx),%r11,%rbx
   690bf:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   690c5:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   690cb:	c4 e2 a3 f6 59 58    	mulx   0x58(%rcx),%r11,%rbx
   690d1:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   690d7:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   690dd:	66 49 0f 38 f6 c7    	adcx   %r15,%rax
   690e3:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   690e7:	45 31 ff             	xor    %r15d,%r15d
   690ea:	c4 e2 a3 f6 19       	mulx   (%rcx),%r11,%rbx
   690ef:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   690f5:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   690fb:	c4 e2 a3 f6 59 08    	mulx   0x8(%rcx),%r11,%rbx
   69101:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   69107:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   6910d:	c4 e2 a3 f6 59 10    	mulx   0x10(%rcx),%r11,%rbx
   69113:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   69119:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   6911f:	c4 e2 a3 f6 59 18    	mulx   0x18(%rcx),%r11,%rbx
   69125:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   6912b:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   69131:	66 4d 0f 38 f6 cf    	adcx   %r15,%r9
   69137:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   6913b:	45 31 ff             	xor    %r15d,%r15d
   6913e:	c4 e2 a3 f6 59 20    	mulx   0x20(%rcx),%r11,%rbx
   69144:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   6914a:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   69150:	c4 e2 a3 f6 59 28    	mulx   0x28(%rcx),%r11,%rbx
   69156:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   6915c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   69162:	c4 e2 a3 f6 59 30    	mulx   0x30(%rcx),%r11,%rbx
   69168:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   6916e:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   69174:	c4 e2 a3 f6 59 38    	mulx   0x38(%rcx),%r11,%rbx
   6917a:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   69180:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   69186:	66 4d 0f 38 f6 cf    	adcx   %r15,%r9
   6918c:	4c 89 c2             	mov    %r8,%rdx
   6918f:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   69194:	45 31 ff             	xor    %r15d,%r15d
   69197:	c4 e2 a3 f6 59 40    	mulx   0x40(%rcx),%r11,%rbx
   6919d:	66 4d 0f 38 f6 c3    	adcx   %r11,%r8
   691a3:	f3 48 0f 38 f6 fb    	adox   %rbx,%rdi
   691a9:	c4 e2 a3 f6 59 48    	mulx   0x48(%rcx),%r11,%rbx
   691af:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   691b5:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   691bb:	c4 e2 a3 f6 59 50    	mulx   0x50(%rcx),%r11,%rbx
   691c1:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   691c7:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   691cd:	c4 e2 a3 f6 59 58    	mulx   0x58(%rcx),%r11,%rbx
   691d3:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   691d9:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   691df:	66 4d 0f 38 f6 cf    	adcx   %r15,%r9
   691e5:	48 8b 56 18          	mov    0x18(%rsi),%rdx
   691e9:	45 31 ff             	xor    %r15d,%r15d
   691ec:	c4 e2 a3 f6 19       	mulx   (%rcx),%r11,%rbx
   691f1:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   691f7:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   691fd:	c4 e2 a3 f6 59 08    	mulx   0x8(%rcx),%r11,%rbx
   69203:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   69209:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   6920f:	c4 e2 a3 f6 59 10    	mulx   0x10(%rcx),%r11,%rbx
   69215:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   6921b:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   69221:	c4 e2 a3 f6 59 18    	mulx   0x18(%rcx),%r11,%rbx
   69227:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   6922d:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   69233:	66 4d 0f 38 f6 c7    	adcx   %r15,%r8
   69239:	48 8b 56 38          	mov    0x38(%rsi),%rdx
   6923d:	45 31 ff             	xor    %r15d,%r15d
   69240:	c4 e2 a3 f6 59 20    	mulx   0x20(%rcx),%r11,%rbx
   69246:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   6924c:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   69252:	c4 e2 a3 f6 59 28    	mulx   0x28(%rcx),%r11,%rbx
   69258:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   6925e:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   69264:	c4 e2 a3 f6 59 30    	mulx   0x30(%rcx),%r11,%rbx
   6926a:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   69270:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   69276:	c4 e2 a3 f6 59 38    	mulx   0x38(%rcx),%r11,%rbx
   6927c:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   69282:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   69288:	66 4d 0f 38 f6 c7    	adcx   %r15,%r8
   6928e:	48 89 fa             	mov    %rdi,%rdx
   69291:	48 0f af 56 40       	imul   0x40(%rsi),%rdx
   69296:	45 31 ff             	xor    %r15d,%r15d
   69299:	c4 e2 a3 f6 59 40    	mulx   0x40(%rcx),%r11,%rbx
   6929f:	66 49 0f 38 f6 fb    	adcx   %r11,%rdi
   692a5:	f3 4c 0f 38 f6 eb    	adox   %rbx,%r13
   692ab:	c4 e2 a3 f6 59 48    	mulx   0x48(%rcx),%r11,%rbx
   692b1:	66 4d 0f 38 f6 eb    	adcx   %r11,%r13
   692b7:	f3 48 0f 38 f6 c3    	adox   %rbx,%rax
   692bd:	c4 e2 a3 f6 59 50    	mulx   0x50(%rcx),%r11,%rbx
   692c3:	66 49 0f 38 f6 c3    	adcx   %r11,%rax
   692c9:	f3 4c 0f 38 f6 cb    	adox   %rbx,%r9
   692cf:	c4 e2 a3 f6 59 58    	mulx   0x58(%rcx),%r11,%rbx
   692d5:	66 4d 0f 38 f6 cb    	adcx   %r11,%r9
   692db:	f3 4c 0f 38 f6 c3    	adox   %rbx,%r8
   692e1:	66 4d 0f 38 f6 c7    	adcx   %r15,%r8
   692e7:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   692ee:	8c 20 3c 
   692f1:	48 b9 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%rcx
   692f8:	95 7e 68 
   692fb:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   69302:	00 
   69303:	4c 89 84 24 f8 00 00 	mov    %r8,0xf8(%rsp)
   6930a:	00 
   6930b:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
   69310:	4c 89 8c 24 a8 00 00 	mov    %r9,0xa8(%rsp)
   69317:	00 
   69318:	49 39 d5             	cmp    %rdx,%r13
   6931b:	4c 8d 1c 08          	lea    (%rax,%rcx,1),%r11
   6931f:	48 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%rdx
   69326:	6a 81 97 
   69329:	49 83 db 00          	sbb    $0x0,%r11
   6932d:	0f 92 c1             	setb   %cl
   69330:	48 39 d0             	cmp    %rdx,%rax
   69333:	48 b8 a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%rax
   6933a:	ba af 47 
   6933d:	4d 8d 3c 01          	lea    (%r9,%rax,1),%r15
   69341:	48 b8 d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%rax
   69348:	b1 9b cf 
   6934b:	0f 92 c2             	setb   %dl
   6934e:	49 8d 1c 00          	lea    (%r8,%rax,1),%rbx
   69352:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   69359:	00 
   6935a:	08 ca                	or     %cl,%dl
   6935c:	0f b6 ca             	movzbl %dl,%ecx
   6935f:	48 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%rdx
   69366:	45 50 b8 
   69369:	49 29 cf             	sub    %rcx,%r15
   6936c:	0f 92 c1             	setb   %cl
   6936f:	49 39 d1             	cmp    %rdx,%r9
   69372:	0f 92 c2             	setb   %dl
   69375:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   6937c:	00 
   6937d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   69382:	08 ca                	or     %cl,%dl
   69384:	0f b6 ca             	movzbl %dl,%ecx
   69387:	48 29 cb             	sub    %rcx,%rbx
   6938a:	0f 92 84 24 c0 00 00 	setb   0xc0(%rsp)
   69391:	00 
   69392:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   69399:	00 
   6939a:	48 8b 04 24          	mov    (%rsp),%rax
   6939e:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   693a5:	00 
   693a6:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   693ab:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   693b2:	00 
   693b3:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   693b8:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
   693bf:	00 
   693c0:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   693c7:	00 
   693c8:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
   693cf:	00 
   693d0:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
   693d7:	00 
   693d8:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   693df:	00 
   693e0:	48 8d 84 24 90 04 00 	lea    0x490(%rsp),%rax
   693e7:	00 
   693e8:	4c 89 94 24 38 01 00 	mov    %r10,0x138(%rsp)
   693ef:	00 
   693f0:	c5 fc 11 94 24 40 01 	vmovups %ymm2,0x140(%rsp)
   693f7:	00 00 
   693f9:	c5 fc 10 08          	vmovups (%rax),%ymm1
   693fd:	48 b8 b9 02 83 27 e9 	movabs $0xc3df73e9278302b9,%rax
   69404:	73 df c3 
   69407:	49 8d 4c 05 00       	lea    0x0(%r13,%rax,1),%rcx
   6940c:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   69413:	00 
   69414:	48 8d 8c 24 00 01 00 	lea    0x100(%rsp),%rcx
   6941b:	00 
   6941c:	c5 fc 11 4c 24 50    	vmovups %ymm1,0x50(%rsp)
   69422:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
   69427:	c5 f8 11 44 24 78    	vmovups %xmm0,0x78(%rsp)
   6942d:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   69434:	00 00 00 00 00 
   69439:	45 31 c0             	xor    %r8d,%r8d
   6943c:	31 ff                	xor    %edi,%edi
   6943e:	31 f6                	xor    %esi,%esi
   69440:	45 31 d2             	xor    %r10d,%r10d
   69443:	45 31 c9             	xor    %r9d,%r9d
   69446:	48 8b 55 00          	mov    0x0(%rbp),%rdx
   6944a:	45 31 f6             	xor    %r14d,%r14d
   6944d:	c4 62 9b f6 29       	mulx   (%rcx),%r12,%r13
   69452:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   69458:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   6945e:	c4 62 9b f6 69 08    	mulx   0x8(%rcx),%r12,%r13
   69464:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   6946a:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   69470:	c4 62 9b f6 69 10    	mulx   0x10(%rcx),%r12,%r13
   69476:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   6947c:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69482:	c4 62 9b f6 69 18    	mulx   0x18(%rcx),%r12,%r13
   69488:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   6948e:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69494:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   6949a:	48 8b 55 20          	mov    0x20(%rbp),%rdx
   6949e:	45 31 f6             	xor    %r14d,%r14d
   694a1:	c4 62 9b f6 69 20    	mulx   0x20(%rcx),%r12,%r13
   694a7:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   694ad:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   694b3:	c4 62 9b f6 69 28    	mulx   0x28(%rcx),%r12,%r13
   694b9:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   694bf:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   694c5:	c4 62 9b f6 69 30    	mulx   0x30(%rcx),%r12,%r13
   694cb:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   694d1:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   694d7:	c4 62 9b f6 69 38    	mulx   0x38(%rcx),%r12,%r13
   694dd:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   694e3:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   694e9:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   694ef:	4c 89 c2             	mov    %r8,%rdx
   694f2:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   694f7:	45 31 f6             	xor    %r14d,%r14d
   694fa:	c4 62 9b f6 69 40    	mulx   0x40(%rcx),%r12,%r13
   69500:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   69506:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   6950c:	c4 62 9b f6 69 48    	mulx   0x48(%rcx),%r12,%r13
   69512:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   69518:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   6951e:	c4 62 9b f6 69 50    	mulx   0x50(%rcx),%r12,%r13
   69524:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   6952a:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69530:	c4 62 9b f6 69 58    	mulx   0x58(%rcx),%r12,%r13
   69536:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   6953c:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69542:	66 4d 0f 38 f6 ce    	adcx   %r14,%r9
   69548:	48 8b 55 08          	mov    0x8(%rbp),%rdx
   6954c:	45 31 f6             	xor    %r14d,%r14d
   6954f:	c4 62 9b f6 29       	mulx   (%rcx),%r12,%r13
   69554:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   6955a:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   69560:	c4 62 9b f6 69 08    	mulx   0x8(%rcx),%r12,%r13
   69566:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   6956c:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69572:	c4 62 9b f6 69 10    	mulx   0x10(%rcx),%r12,%r13
   69578:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   6957e:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69584:	c4 62 9b f6 69 18    	mulx   0x18(%rcx),%r12,%r13
   6958a:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   69590:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69596:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   6959c:	48 8b 55 28          	mov    0x28(%rbp),%rdx
   695a0:	45 31 f6             	xor    %r14d,%r14d
   695a3:	c4 62 9b f6 69 20    	mulx   0x20(%rcx),%r12,%r13
   695a9:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   695af:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   695b5:	c4 62 9b f6 69 28    	mulx   0x28(%rcx),%r12,%r13
   695bb:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   695c1:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   695c7:	c4 62 9b f6 69 30    	mulx   0x30(%rcx),%r12,%r13
   695cd:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   695d3:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   695d9:	c4 62 9b f6 69 38    	mulx   0x38(%rcx),%r12,%r13
   695df:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   695e5:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   695eb:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   695f1:	48 89 fa             	mov    %rdi,%rdx
   695f4:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   695f9:	45 31 f6             	xor    %r14d,%r14d
   695fc:	c4 62 9b f6 69 40    	mulx   0x40(%rcx),%r12,%r13
   69602:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   69608:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   6960e:	c4 62 9b f6 69 48    	mulx   0x48(%rcx),%r12,%r13
   69614:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   6961a:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69620:	c4 62 9b f6 69 50    	mulx   0x50(%rcx),%r12,%r13
   69626:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   6962c:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69632:	c4 62 9b f6 69 58    	mulx   0x58(%rcx),%r12,%r13
   69638:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   6963e:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69644:	66 4d 0f 38 f6 c6    	adcx   %r14,%r8
   6964a:	48 8b 55 10          	mov    0x10(%rbp),%rdx
   6964e:	45 31 f6             	xor    %r14d,%r14d
   69651:	c4 62 9b f6 29       	mulx   (%rcx),%r12,%r13
   69656:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   6965c:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69662:	c4 62 9b f6 69 08    	mulx   0x8(%rcx),%r12,%r13
   69668:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   6966e:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69674:	c4 62 9b f6 69 10    	mulx   0x10(%rcx),%r12,%r13
   6967a:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   69680:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69686:	c4 62 9b f6 69 18    	mulx   0x18(%rcx),%r12,%r13
   6968c:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   69692:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   69698:	66 49 0f 38 f6 fe    	adcx   %r14,%rdi
   6969e:	48 8b 55 30          	mov    0x30(%rbp),%rdx
   696a2:	45 31 f6             	xor    %r14d,%r14d
   696a5:	c4 62 9b f6 69 20    	mulx   0x20(%rcx),%r12,%r13
   696ab:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   696b1:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   696b7:	c4 62 9b f6 69 28    	mulx   0x28(%rcx),%r12,%r13
   696bd:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   696c3:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   696c9:	c4 62 9b f6 69 30    	mulx   0x30(%rcx),%r12,%r13
   696cf:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   696d5:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   696db:	c4 62 9b f6 69 38    	mulx   0x38(%rcx),%r12,%r13
   696e1:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   696e7:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   696ed:	66 49 0f 38 f6 fe    	adcx   %r14,%rdi
   696f3:	48 89 f2             	mov    %rsi,%rdx
   696f6:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   696fb:	45 31 f6             	xor    %r14d,%r14d
   696fe:	c4 62 9b f6 69 40    	mulx   0x40(%rcx),%r12,%r13
   69704:	66 49 0f 38 f6 f4    	adcx   %r12,%rsi
   6970a:	f3 4d 0f 38 f6 d5    	adox   %r13,%r10
   69710:	c4 62 9b f6 69 48    	mulx   0x48(%rcx),%r12,%r13
   69716:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   6971c:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69722:	c4 62 9b f6 69 50    	mulx   0x50(%rcx),%r12,%r13
   69728:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   6972e:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69734:	c4 62 9b f6 69 58    	mulx   0x58(%rcx),%r12,%r13
   6973a:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   69740:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   69746:	66 49 0f 38 f6 fe    	adcx   %r14,%rdi
   6974c:	48 8b 55 18          	mov    0x18(%rbp),%rdx
   69750:	45 31 f6             	xor    %r14d,%r14d
   69753:	c4 62 9b f6 29       	mulx   (%rcx),%r12,%r13
   69758:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   6975e:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69764:	c4 62 9b f6 69 08    	mulx   0x8(%rcx),%r12,%r13
   6976a:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   69770:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69776:	c4 62 9b f6 69 10    	mulx   0x10(%rcx),%r12,%r13
   6977c:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   69782:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   69788:	c4 62 9b f6 69 18    	mulx   0x18(%rcx),%r12,%r13
   6978e:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   69794:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   6979a:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   697a0:	48 8b 55 38          	mov    0x38(%rbp),%rdx
   697a4:	45 31 f6             	xor    %r14d,%r14d
   697a7:	c4 62 9b f6 69 20    	mulx   0x20(%rcx),%r12,%r13
   697ad:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   697b3:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   697b9:	c4 62 9b f6 69 28    	mulx   0x28(%rcx),%r12,%r13
   697bf:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   697c5:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   697cb:	c4 62 9b f6 69 30    	mulx   0x30(%rcx),%r12,%r13
   697d1:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   697d7:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   697dd:	c4 62 9b f6 69 38    	mulx   0x38(%rcx),%r12,%r13
   697e3:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   697e9:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   697ef:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   697f5:	4c 89 d2             	mov    %r10,%rdx
   697f8:	48 0f af 55 40       	imul   0x40(%rbp),%rdx
   697fd:	45 31 f6             	xor    %r14d,%r14d
   69800:	c4 62 9b f6 69 40    	mulx   0x40(%rcx),%r12,%r13
   69806:	66 4d 0f 38 f6 d4    	adcx   %r12,%r10
   6980c:	f3 4d 0f 38 f6 cd    	adox   %r13,%r9
   69812:	c4 62 9b f6 69 48    	mulx   0x48(%rcx),%r12,%r13
   69818:	66 4d 0f 38 f6 cc    	adcx   %r12,%r9
   6981e:	f3 4d 0f 38 f6 c5    	adox   %r13,%r8
   69824:	c4 62 9b f6 69 50    	mulx   0x50(%rcx),%r12,%r13
   6982a:	66 4d 0f 38 f6 c4    	adcx   %r12,%r8
   69830:	f3 49 0f 38 f6 fd    	adox   %r13,%rdi
   69836:	c4 62 9b f6 69 58    	mulx   0x58(%rcx),%r12,%r13
   6983c:	66 49 0f 38 f6 fc    	adcx   %r12,%rdi
   69842:	f3 49 0f 38 f6 f5    	adox   %r13,%rsi
   69848:	66 49 0f 38 f6 f6    	adcx   %r14,%rsi
   6984e:	49 be 73 35 8e 97 6e 	movabs $0x687e956e978e3573,%r14
   69855:	95 7e 68 
   69858:	4c 01 c8             	add    %r9,%rax
   6985b:	48 ba 47 fd 7c d8 16 	movabs $0x3c208c16d87cfd47,%rdx
   69862:	8c 20 3c 
   69865:	49 ba 8d ca 71 68 91 	movabs $0x97816a916871ca8d,%r10
   6986c:	6a 81 97 
   6986f:	49 bc a3 a7 7e 7e 49 	movabs $0x47afba497e7ea7a3,%r12
   69876:	ba af 47 
   69879:	49 bd d7 5f ce 1e 8d 	movabs $0xcf9bb18d1ece5fd7,%r13
   69880:	b1 9b cf 
   69883:	48 bd 29 a0 31 e1 72 	movabs $0x30644e72e131a029,%rbp
   6988a:	4e 64 30 
   6988d:	48 89 04 24          	mov    %rax,(%rsp)
   69891:	31 c0                	xor    %eax,%eax
   69893:	4d 01 c6             	add    %r8,%r14
   69896:	49 39 d1             	cmp    %rdx,%r9
   69899:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   698a0:	00 
   698a1:	c5 fe 6f 84 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm0
   698a8:	00 00 
   698aa:	49 83 de 00          	sbb    $0x0,%r14
   698ae:	0f 92 c2             	setb   %dl
   698b1:	4d 39 d0             	cmp    %r10,%r8
   698b4:	41 0f 92 c2          	setb   %r10b
   698b8:	49 01 fc             	add    %rdi,%r12
   698bb:	41 08 d2             	or     %dl,%r10b
   698be:	41 0f b6 d2          	movzbl %r10b,%edx
   698c2:	49 ba 5d 58 81 81 b6 	movabs $0xb85045b68181585d,%r10
   698c9:	45 50 b8 
   698cc:	49 29 d4             	sub    %rdx,%r12
   698cf:	0f 92 c2             	setb   %dl
   698d2:	4c 39 d7             	cmp    %r10,%rdi
   698d5:	41 0f 92 c2          	setb   %r10b
   698d9:	49 01 f5             	add    %rsi,%r13
   698dc:	41 08 d2             	or     %dl,%r10b
   698df:	41 0f b6 d2          	movzbl %r10b,%edx
   698e3:	49 29 d5             	sub    %rdx,%r13
   698e6:	0f 92 c2             	setb   %dl
   698e9:	48 39 ee             	cmp    %rbp,%rsi
   698ec:	41 0f 92 c2          	setb   %r10b
   698f0:	41 08 d2             	or     %dl,%r10b
   698f3:	48 39 e9             	cmp    %rbp,%rcx
   698f6:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
   698fd:	00 
   698fe:	0f 92 c2             	setb   %dl
   69901:	0a 94 24 c0 00 00 00 	or     0xc0(%rsp),%dl
   69908:	48 8b 14 24          	mov    (%rsp),%rdx
   6990c:	48 0f 45 6c 24 08    	cmovne 0x8(%rsp),%rbp
   69912:	4c 0f 45 9c 24 b8 00 	cmovne 0xb8(%rsp),%r11
   69919:	00 00 
   6991b:	4c 0f 45 bc 24 a8 00 	cmovne 0xa8(%rsp),%r15
   69922:	00 00 
   69924:	48 0f 45 d9          	cmovne %rcx,%rbx
   69928:	45 84 d2             	test   %r10b,%r10b
   6992b:	49 0f 45 d1          	cmovne %r9,%rdx
   6992f:	4d 0f 45 f0          	cmovne %r8,%r14
   69933:	4c 0f 45 e7          	cmovne %rdi,%r12
   69937:	4c 0f 45 ee          	cmovne %rsi,%r13
   6993b:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
   69940:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
   69945:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
   6994a:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
   6994f:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   69954:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
   69959:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
   6995e:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
   69963:	c5 fd ef 44 24 30    	vpxor  0x30(%rsp),%ymm0,%ymm0
   69969:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   6996e:	0f 85 06 d1 ff ff    	jne    66a7a <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2f0a>
   69974:	c5 fe 6f 84 24 00 02 	vmovdqu 0x200(%rsp),%ymm0
   6997b:	00 00 
   6997d:	c5 fd ef 44 24 50    	vpxor  0x50(%rsp),%ymm0,%ymm0
   69983:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
   69988:	0f 94 c0             	sete   %al
   6998b:	e9 ea d0 ff ff       	jmp    66a7a <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2f0a>
   69990:	b0 01                	mov    $0x1,%al
   69992:	e9 e3 d0 ff ff       	jmp    66a7a <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x2f0a>
   69997:	62 f1 7c 48 10 05 5f 	vmovups -0x592a1(%rip),%zmm0        # 10700 <zmij::STATIC_DATA+0x4600>
   6999e:	6d fa ff 
   699a1:	62 f1 7c 48 10 15 15 	vmovups -0x592eb(%rip),%zmm2        # 106c0 <zmij::STATIC_DATA+0x45c0>
   699a8:	6d fa ff 
   699ab:	62 f1 7c 48 10 0d cb 	vmovups -0x59335(%rip),%zmm1        # 10680 <zmij::STATIC_DATA+0x4580>
   699b2:	6c fa ff 
   699b5:	62 f1 7c 48 11 84 24 	vmovups %zmm0,0x3d0(%rsp)
   699bc:	d0 03 00 00 
   699c0:	62 f1 7c 48 11 94 24 	vmovups %zmm2,0x390(%rsp)
   699c7:	90 03 00 00 
   699cb:	62 f1 7c 48 11 8c 24 	vmovups %zmm1,0x350(%rsp)
   699d2:	50 03 00 00 
   699d6:	e9 bc a3 ff ff       	jmp    63d97 <<zopro_bn254::curve::Affine<zopro_bn254::curve::G2Config>>::is_in_subgroup+0x227>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
