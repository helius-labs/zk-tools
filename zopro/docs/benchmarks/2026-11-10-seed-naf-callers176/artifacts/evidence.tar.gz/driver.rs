//! Fixed-input complete public G2 subgroup-call benchmark. No prover speed claim.
use std::{fs, hint::black_box, sync::{Arc,Barrier}, thread, time::Instant};
use zopro_bn254::{Fq,Fq2,G2Affine};
mod perf;
const POINTS: usize=128;
fn fixtures(path: &str) -> Vec<(G2Affine,bool)> {
    let b=fs::read(path).unwrap(); assert_eq!(b.len(),POINTS*129);
    b.chunks_exact(129).map(|p| {
        assert!(p[128]<2);
        let f=|offset| { let mut limbs=[0;4]; for (i,l) in limbs.iter_mut().enumerate(){*l=u64::from_le_bytes(p[offset+i*8..offset+i*8+8].try_into().unwrap());} Fq::from_montgomery(limbs) };
        let point=G2Affine::new(Fq2::new(f(0),f(32)),Fq2::new(f(64),f(96)));
        assert!(point.is_on_curve()); (point,p[128]!=0)
    }).collect()
}
fn bind(cpu:usize)->(u32,i32) {
    let mut set=unsafe {std::mem::zeroed::<libc::cpu_set_t>()};
    unsafe {libc::CPU_SET(cpu,&mut set); assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&set),&set),0);}
    let mut actual=unsafe {std::mem::zeroed::<libc::cpu_set_t>()};
    assert_eq!(unsafe {libc::sched_getaffinity(0,std::mem::size_of_val(&actual),&mut actual)},0);
    for i in 0..libc::CPU_SETSIZE as usize {assert_eq!(unsafe {libc::CPU_ISSET(i,&actual)},i==cpu);}
    (unsafe {libc::syscall(libc::SYS_gettid)} as u32,unsafe {libc::sched_getcpu()})
}
fn main() {
    let args=std::env::args().collect::<Vec<_>>(); assert_eq!(args.len(),5);
    let workers:usize=args[2].parse().unwrap(); assert!([1,16,32].contains(&workers));
    let rounds:usize=args[3].parse().unwrap(); assert!(rounds>0);
    let calls:usize=args[4].parse().unwrap(); assert!(calls>=POINTS&&calls%POINTS==0);
    let points=Arc::new(fixtures(&args[1]));
    let ready=Arc::new(Barrier::new(workers+1));
    let start=Arc::new(Barrier::new(workers+1));
    let done=Arc::new(Barrier::new(workers+1));
    let check=Arc::new(Barrier::new(workers+1));
    let checked=Arc::new(Barrier::new(workers+1));
    let mut jobs=vec![];
    for worker in 0..workers {
        let (points,ready,start,done,check,checked)=(points.clone(),ready.clone(),start.clone(),done.clone(),check.clone(),checked.clone());
        jobs.push(thread::Builder::new().name(format!("subgroup-{worker}")).stack_size(512*1024).spawn(move|| {
            let cpu=if workers==1 {2} else {worker};
            let (tid,initial_cpu)=bind(cpu);
            let mut outputs=vec![false;calls];
            let mut durations=Vec::with_capacity(rounds);
            // First-touch and allocation precede all clocks.
            for (p,expected) in points.iter() {assert_eq!(p.is_in_subgroup(),*expected);}
            ready.wait();
            for round in 0..rounds+3 {
                let active_calls=if round<3 {calls.min(1024)} else {calls};
                start.wait();
                let began=Instant::now();
                for (i,output) in outputs.iter_mut().take(active_calls).enumerate() {
                    *output=black_box(&points[(i+worker)%POINTS].0).is_in_subgroup();
                }
                black_box(&outputs);
                let ns=began.elapsed().as_nanos() as u64;
                done.wait(); // Every worker clock has ended before checking is released.
                check.wait();
                for (i,actual) in outputs.iter().take(active_calls).enumerate() {assert_eq!(*actual,points[(i+worker)%POINTS].1,"worker={worker} i={i}");}
                if round>=3 {durations.push(ns);}
                checked.wait();
            }
            let (_,final_cpu)=bind(cpu);
            (worker,tid,initial_cpu,final_cpu,durations)
        }).unwrap());
    }
    let mut control=perf::Control::from_env().unwrap();
    ready.wait();
    let usage_before=perf::Usage::now().unwrap();
    let mut waves=Vec::with_capacity(rounds);
    for round in 0..rounds+3 {
        if round>=3 {if let Some(c)=control.as_mut(){c.enable().unwrap();}}
        let began=Instant::now(); start.wait(); done.wait();
        let wave_ns=began.elapsed().as_nanos() as u64;
        if round>=3 {if let Some(c)=control.as_mut(){c.disable().unwrap();} waves.push(wave_ns);}
        check.wait(); checked.wait();
    }
    let usage_after=perf::Usage::now().unwrap();
    let rows=jobs.into_iter().map(|j|j.join().unwrap()).collect::<Vec<_>>();
    for round in 0..rounds {
        let active_ns=rows.iter().map(|r|r.4[round]).max().unwrap();
        println!("SAMPLE {}",serde_json::json!({"round":round,"ns_per_call":active_ns as f64/calls as f64,"max_worker_ns":active_ns,"wave_ns":waves[round]}));
    }
    let workers_rows=rows.iter().map(|r|serde_json::json!({"index":r.0,"tid":r.1,"initial_cpu":r.2,"final_cpu":r.3})).collect::<Vec<_>>();
    let mut summary=usage_after.difference(&usage_before);
    summary["pid"]=std::process::id().into(); summary["workers"]=workers.into(); summary["rounds"]=rounds.into();
    summary["calls_per_worker_per_round"]=calls.into(); summary["priming"]=3.into(); summary["worker_rows"]=workers_rows.into();
    summary["all_boolean_outputs_checked"]=true.into(); summary["fixture_points"]=POINTS.into();
    summary["resource_scope"]="process interval includes priming, barriers and post-clock checking".into();
    println!("SUMMARY {summary}");
}
