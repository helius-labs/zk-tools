//! A second reader recomputes medians and paired ratios from raw output.
//! The already qualified bootstrap implementation is intentionally shared.
include!("common.rs");
mod statistics;
// JSON number parsing can shift an otherwise identical ratio by one ulp.
// This only compares recomputed numbers to their serialized representation;
// it does not change raw medians, bootstrap ranks, intervals or gate thresholds.
fn same_serialized(a:&Value,b:&Value){match(a,b){
    (Value::Number(a),Value::Number(b))=>{let(a,b)=(a.as_f64().unwrap(),b.as_f64().unwrap());assert!((a-b).abs()<=8.*f64::EPSILON*a.abs().max(b.abs()).max(1.));},
    (Value::Array(a),Value::Array(b))=>{assert_eq!(a.len(),b.len());for(a,b)in a.iter().zip(b){same_serialized(a,b);}},
    (Value::Object(a),Value::Object(b))=>{assert_eq!(a.keys().collect::<Vec<_>>(),b.keys().collect::<Vec<_>>());for(k,v)in a{same_serialized(v,&b[k]);}},
    _=>assert_eq!(a,b)
}}
fn main(){
    let report=read(r("analysis.json"));let jobs=read(r("jobs.json"));let plan=read(r("capture-plan.json"));
    assert_eq!(read(r("runs/result.json"))["status"],"complete");
    for s in plan["steps"].as_array().unwrap(){receipt(s);}
    for (p,h) in read(r("capture-pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
    let mut medians=BTreeMap::new();let mut summaries=BTreeMap::new();let mut samples=0;
    for job in jobs.as_array().unwrap(){
        let name=job["name"].as_str().unwrap();let raw=fs::read_to_string(r(format!("runs/{name}/stdout.log"))).unwrap();
        let mut values=vec![];
        for record in raw.lines().filter(|l|l.starts_with("SAMPLE ")){let value:Value=serde_json::from_str(&record[7..]).unwrap();assert_eq!(value["round"].as_u64().unwrap(),values.len() as u64);let v=value["max_worker_ns"].as_u64().unwrap() as f64/job["calls"].as_u64().unwrap() as f64;assert_eq!(v,value["ns_per_call"].as_f64().unwrap());assert!(v>0.&&v.is_finite());values.push(v);}
        assert_eq!(values.len() as u64,job["rounds"].as_u64().unwrap());samples+=values.len();values.sort_unstable_by(|a,b|a.partial_cmp(b).unwrap());let median=values[values.len()/2];
        let row=report["rows"].as_array().unwrap().iter().find(|r|r["name"]==name).unwrap();assert_eq!(row["median_ns"].as_f64().unwrap(),median);
        let sum=raw.lines().filter_map(|l|l.strip_prefix("SUMMARY ")).collect::<Vec<_>>();assert_eq!(sum.len(),1);let s:Value=serde_json::from_str(sum[0]).unwrap();assert_eq!(s["all_boolean_outputs_checked"],true);assert_eq!(s["workers"],job["workers"]);assert_eq!(s,row["summary"]);
        summaries.insert(name.to_owned(),s);medians.insert(name.to_owned(),median);
    }
    for population in ["valid","mixed"]{for workers in [1,16,32]{for (n,d) in [("OFF","REF"),("ON","OFF"),("ON","REF")]{
        let v=|a:&str|(0..15).map(|b|medians[&format!("latency-{population}-w{workers}-{a}-b{b:02}")]).collect::<Vec<_>>();
        let c=statistics::contrast(&v(n),&v(d));same_serialized(&c,&report["contrasts"][format!("{population}-w{workers}-{n}/{d}")]);
    }}}
    let mut diagnostics=0;
    for job in jobs.as_array().unwrap().iter().filter(|j|["stat","cycles"].contains(&j["panel"].as_str().unwrap())){
        diagnostics+=1;let name=job["name"].as_str().unwrap();let d=report["diagnostics"].as_array().unwrap().iter().find(|d|d["name"]==name).unwrap();
        if job["panel"]=="stat"{
            let raw=fs::read_to_string(job["data"].as_str().unwrap()).unwrap();let mut qualified=true;let mut count=0;
            for record in raw.lines().filter(|s|!s.starts_with('#')&&!s.trim().is_empty()){let f=record.split(';').collect::<Vec<_>>();let event=f[2].trim();let value:f64=f[0].trim().parse().unwrap();let runtime:f64=f[3].trim().parse().unwrap();let coverage:f64=f[4].trim().parse().unwrap();assert_eq!(d["events"][event]["count"].as_f64().unwrap(),value);assert!(value.is_finite()&&value>=0.&&runtime.is_finite()&&runtime>0.);qualified&=coverage.is_finite()&&coverage>=99.9;count+=1;}
            assert_eq!(count,4);assert_eq!(d["qualified"],qualified);
        }else{
            let summary=&summaries[name];let pid=summary["pid"].as_u64().unwrap();let tids=summary["worker_rows"].as_array().unwrap().iter().map(|w|(w["tid"].as_u64().unwrap(),w["initial_cpu"].as_u64().unwrap())).collect::<BTreeMap<_,_>>();
            let raw=fs::read_to_string(r(format!("runs/decode-{name}/stdout.log"))).unwrap();let mut count=0;let mut unknown=0;let mut valid=true;
            for line in raw.lines().filter(|l|!l.starts_with('#')&&!l.trim().is_empty()){let f=line.split_ascii_whitespace().collect::<Vec<_>>();let (p,t)=f[0].split_once('/').unwrap();let p=p.parse::<u64>().unwrap();let t=t.parse::<u64>().unwrap();let cpu=f[1].trim_matches(['[',']']).parse::<u64>().unwrap();let period=f[3].parse::<u64>().unwrap();count+=1;unknown+=usize::from(f[5].starts_with("[unknown]"));valid&=p==pid&&period==16000000&&if let Some(expected)=tids.get(&t){cpu==*expected}else{t==pid&&if job["workers"]==1{cpu==2}else{cpu<32}};}
            assert_eq!(d["samples"],count);assert_eq!(d["unknown_samples"],unknown);assert_eq!(d["sample_pid_tid_cpu_period_ok"],valid);
            let loss:Value=read(r(format!("runs/loss-{name}/stdout.log")));assert_eq!(d["zero_lost"],loss["zero_lost"]);
            let meta=fs::read_to_string(r(format!("runs/metadata-{name}/stdout.log"))).unwrap();let mappings=meta.lines().filter(|l|l.contains("PERF_RECORD_MMAP")&&l.contains(job["binary"].as_str().unwrap())).collect::<Vec<_>>();assert!(!mappings.is_empty());for l in mappings{assert_eq!(l.split_once('/').unwrap().0.parse::<u64>().unwrap(),pid);}
        }
    }
    assert_eq!(diagnostics,18);assert_eq!(medians.len(),306);
    let gates=report["gates"].as_array().unwrap();assert_eq!(gates.len(),44);assert_eq!(report["component_selected"],gates.iter().all(|g|g["passed"]==true));
    save(r("review.json"),&json!({"passed":true,"same_agent_separate_raw_reader":true,"shared_qualified_bootstrap":true,"raw_processes":medians.len(),"samples_reconstructed":samples,"contrasts_recomputed":18,"diagnostic_panels":diagnostics,"component_selected":report["component_selected"],"production_changed":false,"new_proof_exports":0,"canonical_unchanged":47437,"original_reader_failed_on_JSON_roundtrip_only":true,"serialization_comparison_tolerance_in_epsilon":8,"performance_data_and_gates_unchanged":true,"original_frozen_reader_preserved":true}));
    println!("separate raw reader PASS:306 processes/18 matched contrasts/18 diagnostic panels; shared bootstrap disclosed; no proof claim");
}
