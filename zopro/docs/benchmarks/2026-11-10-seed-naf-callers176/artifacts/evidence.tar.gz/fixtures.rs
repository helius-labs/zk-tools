//! Generate synthetic complete-subgroup-call fixtures with an independent full-r oracle.
use ark_bn254 as ark;
use ark_ec::{AffineRepr, CurveGroup};
use ark_ff::{UniformRand, Zero};
use ark_std::rand::{rngs::StdRng, SeedableRng};
use std::{fs, path::Path};
const ORDER: [u64;4] = [0x43e1f593f0000001,0x2833e84879b97091,0xb85045b68181585d,0x30644e72e131a029];
fn append(bytes: &mut Vec<u8>, p: ark::G2Affine) -> bool {
    assert!(p.is_on_curve());
    let expected = p.mul_bigint(ORDER).is_zero();
    assert_eq!(expected, p.is_in_correct_subgroup_assuming_on_curve());
    for field in [p.x.c0,p.x.c1,p.y.c0,p.y.c1] {
        let limbs = if p.is_zero() { [0;4] } else { field.0.0 };
        for limb in limbs { bytes.extend(limb.to_le_bytes()); }
    }
    bytes.push(u8::from(expected));
    expected
}
fn main() {
    let out = std::env::args().nth(1).unwrap();
    let out = Path::new(&out);
    let mut rng = StdRng::seed_from_u64(0x671b_f519_34a2_d87e);
    let mut valid = vec![];
    let mut mixed = vec![];
    let mut valid_true=0;
    let mut mixed_true=0;
    for _ in 0..128 { valid_true += usize::from(append(&mut valid,ark::G2Projective::rand(&mut rng).into_affine())); }
    for i in 0..128 {
        let p = match i%8 {
            0 => ark::G2Projective::rand(&mut rng).into_affine(),
            1 => ark::G2Affine::zero(),
            _ => loop {
                if let Some(p) = ark::G2Affine::get_point_from_x_unchecked(ark::Fq2::rand(&mut rng),i%2==0) {
                    if p.mul_bigint(ORDER).is_zero() { continue; }
                    break if i%3==0 { p.mul_bigint(ORDER).into_affine() } else { p };
                }
            }
        };
        mixed_true += usize::from(append(&mut mixed,p));
    }
    assert_eq!(valid_true,128);
    assert_eq!(mixed_true,32);
    for (name,bytes) in [("valid",valid),("mixed",mixed)] {
        assert_eq!(bytes.len(),128*129);
        let p=out.join(format!("{name}.bin"));
        assert!(!p.exists()); fs::write(p,bytes).unwrap();
    }
    println!("128 valid / 128 mixed; mixed true=32 false=96; full-r plus Ark subgroup oracles; synthetic Montgomery fixtures only");
}
