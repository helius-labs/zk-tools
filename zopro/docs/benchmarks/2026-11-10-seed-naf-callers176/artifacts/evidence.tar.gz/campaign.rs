include!("common.rs");
use std::{io::{BufRead,BufReader},process::{Command,Stdio}};
fn step(name:&str,argv:Vec<String>,environment:Value)->Value{json!({"kind":"command","name":name,"argv":argv,"environment":environment,"timeout_seconds":900})}
fn add(steps:&mut Vec<Value>,jobs:&mut Vec<Value>,population:&str,workers:usize,arm:&str,block:usize,panel:&str) {
    let name=format!("{panel}-{population}-w{workers}-{arm}-b{block:02}");
    let affinity=match workers {1=>"2",16=>"0-15",32=>"0-31",_=>panic!()};
    let (rounds,calls)=match panel {"pre"=>(1,128),"latency"|"stat"=>(31,1024),"cycles"=>(1,1048576),_=>panic!()};
    let binary=r(format!("bench-{arm}"));
    let mut argv=vec![];
    let mut data=Value::Null;
    if ["stat","cycles"].contains(&panel) {
        argv.extend(["sudo".into(),"-n".into(),"env".into(),format!("ZOPRO_BENCH_PERF_CTL={}",r("ctl").display()),format!("ZOPRO_BENCH_PERF_ACK={}",r("ack").display()),"perf".into()]);
        if panel=="stat" {
            data=json!(r(format!("stat/{name}.csv")));
            argv.extend(["stat".into(),"--no-big-num".into(),"-x".into(),";".into(),"-e".into(),"{cycles:u,instructions:u,cache-misses:u,branch-misses:u}".into(),"-o".into(),data.as_str().unwrap().into()]);
        } else {
            data=json!(r(format!("perf/{name}.data")));
            argv.extend(["record".into(),"--no-buildid-cache".into(),"--sample-cpu".into(),"--timestamp".into(),"-P".into(),"-e".into(),"cycles:u".into(),"-c".into(),"16000000".into(),"-m".into(),"512".into(),"-o".into(),data.as_str().unwrap().into()]);
        }
        argv.extend(["--delay=-1".into(),format!("--control=fifo:{},{}",r("ctl").display(),r("ack").display()),"--".into()]);
    }
    argv.extend(["taskset".into(),"-c".into(),affinity.into(),binary.display().to_string(),r(format!("{population}.bin")).display().to_string(),workers.to_string(),rounds.to_string(),calls.to_string()]);
    steps.push(step(&name,argv,json!({})));
    jobs.push(json!({"name":name,"population":population,"workers":workers,"arm":arm,"block":block,"panel":panel,"rounds":rounds,"calls":calls,"binary":binary,"data":data}));
}
fn prepare() {
    assert!(!r("capture-plan.json").exists());
    assert_eq!(read(r("build-runs/result.json"))["status"],"complete");
    let mut pins=read(r("build-pins.json")).as_object().unwrap().iter().map(|(k,v)|(k.clone(),v.as_str().unwrap().to_owned())).collect::<BTreeMap<_,_>>();
    for (p,h) in &pins{assert_eq!(hash(p),*h);}
    let mut steps=vec![];let mut jobs=vec![];
    for population in ["valid","mixed"] {for workers in [1,16,32] {for arm in ARMS{add(&mut steps,&mut jobs,population,workers,arm,0,"pre");}}}
    let contexts=[("valid",1),("valid",16),("valid",32),("mixed",1),("mixed",16),("mixed",32)];
    for block in 0..15 {let mut order=(0..6).collect::<Vec<_>>();order.rotate_left(block%6);let mut arms=ARMS;arms.rotate_left(block%3);if block%2==1{order.reverse();arms.reverse();}for i in order{for arm in arms{add(&mut steps,&mut jobs,contexts[i].0,contexts[i].1,arm,block,"latency");}}}
    for dir in ["stat","perf"] {fs::create_dir(r(dir)).unwrap();}
    for fifo in ["ctl","ack"]{assert!(Command::new("mkfifo").args(["-m","600"]).arg(r(fifo)).status().unwrap().success());}
    for panel in ["stat","cycles"] {for (population,workers) in [("valid",1),("valid",32),("mixed",32)]{for arm in ARMS{add(&mut steps,&mut jobs,population,workers,arm,0,panel);}}}
    assert_eq!(jobs.len(),306);
    for j in jobs.iter().filter(|j|j["panel"]=="cycles") {
        let name=j["name"].as_str().unwrap();let data=j["data"].as_str().unwrap();
        steps.push(step(&format!("own-{name}"),vec!["sudo".into(),"-n".into(),"chown".into(),"ubuntu:ubuntu".into(),data.into()],json!({})));
        for (label,args) in [("events",vec!["perf","evlist","-v","-i",data]),("decode",vec!["perf","script","--ns","-i",data,"-F","pid,tid,cpu,time,period,ip,sym"]),("metadata",vec!["perf","script","--header","--show-mmap-events","--show-task-events","--ns","-i",data,"-F","pid,tid,cpu,time,period,ip,sym"])] {
            steps.push(step(&format!("{label}-{name}"),args.into_iter().map(str::to_owned).collect(),json!({})));
        }
        steps.push(step(&format!("loss-{name}"),vec![r("campaign").display().to_string(),"loss".into(),data.into()],json!({})));
    }
    assert_eq!(steps.len(),351);
    save(r("jobs.json"),&json!(jobs));
    for file in ["campaign.rs","campaign","common.rs","analyze.rs","analyze","review.rs","review","statistics.rs","design.md","jobs.json","libraries.json","valid.bin","mixed.bin","bench-REF","bench-OFF","bench-ON","fixtures","driver.rs","perf.rs"] {pin(&mut pins,r(file));}
    for p in ["/usr/bin/perf","/usr/bin/taskset","/usr/bin/sudo","/home/ubuntu/src/zopro-perf-work/tool-target/release/xtask","/home/ubuntu/src/zopro-perf-work/compiler199-sdk176/proof-sha256-after-capture.json"]{pin(&mut pins,p);}
    save(r("capture-pins.json"),&json!(pins));save(r("capture-plan.json"),&json!({"version":1,"source_pins":r("capture-pins.json"),"steps":steps}));
    println!("Frozen 351 serialized commands:18 caller preflights,270 latency,9 PMU,9 profiles,45 offline decode; no old qualification replay/no proof clocks");
}
fn loss(path:&str){assert!(Path::new(path).starts_with(r("perf")));let mut child=Command::new("perf").args(["script","-D","-i",path]).stdout(Stdio::piped()).spawn().unwrap();let mut lost=vec![];let mut lines=0;for line in BufReader::new(child.stdout.take().unwrap()).lines(){let l=line.unwrap();lines+=1;if l.contains("PERF_RECORD_LOST"){lost.push(l);}}assert!(child.wait().unwrap().success());println!("{}",json!({"zero_lost":lost.is_empty(),"lost":lost,"lines":lines}));}
fn main(){match std::env::args().nth(1).as_deref(){Some("prepare")=>prepare(),Some("loss")=>loss(&std::env::args().nth(2).unwrap()),_=>panic!("prepare|loss")}}
