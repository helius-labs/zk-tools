use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{collections::{BTreeMap,BTreeSet},fs,io::Read,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/pairing-half-constant176";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/byte-permute-pack176/pilot";
const LEDGER:&str="/home/ubuntu/src/zopro-perf-work/whole-field-census176/proof-sha256-after.json";
const VERIFY:&str="/home/ubuntu/src/zopro-perf-work/batch-local-steal/gnark/verify";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){assert!(!p.as_ref().exists());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn hash(p:impl AsRef<Path>)->String{let mut h=Sha256::new();let mut f=fs::File::open(p).unwrap();let mut buf=[0;65536];loop{let n=f.read(&mut buf).unwrap();if n==0{break}h.update(&buf[..n]);}format!("{:x}",h.finalize())}
fn step(name:&str,argv:Value,env:Value)->Value{json!({"kind":"command","name":name,"argv":argv,"environment":env,"timeout_seconds":900})}
fn prepare(){
 assert_eq!(read(format!("{R}/native/completed.json")).as_array().unwrap().len(),4);for mode in ["native","portable"]{let log=fs::read_to_string(format!("{R}/native/{mode}-pairing/stdout.log")).unwrap();assert!(log.contains("2 passed; 0 failed"));assert!(log.contains("HALF_CONSTANT points=34 nonidentity=33 lines=2871"));assert!(log.contains("test tests::pairings ... ok"));}
 let analysis=read(format!("{R}/codegen-analysis.json"));assert_eq!(analysis["rows"][0]["inverse_call_rows"].as_array().unwrap().len(),1);assert_eq!(analysis["rows"][1]["inverse_call_rows"].as_array().unwrap().len(),0);
 let link=read(format!("{R}/native/candidate/artifacts.json"));let binary=link["binary"].as_str().unwrap();assert_eq!(hash(binary),link["binary_sha256"].as_str().unwrap());assert_eq!(link["libraries"].as_object().unwrap().len(),8);let command=read(format!("{R}/native/candidate/command.json"));for flag in ["-O","target-cpu=native","lto=fat","codegen-units=1"]{assert!(command["argv"].as_array().unwrap().iter().any(|v|v==flag));}
 let oldjobs=read(format!("{OLD}/preflight-jobs.json"));let oldplan=read(format!("{OLD}/preflight-plan.json"));let mut jobs=vec![];let mut steps=vec![];let mut verifies=vec![];
 for old in oldjobs.as_array().unwrap().iter().filter(|j|j["arm"]=="accepted"){
  let mut job=old.clone();let shape=old["shape"].as_str().unwrap();let name=format!("half-{shape}");let out=format!("{R}/proofs/{name}");let oldstep=oldplan["steps"].as_array().unwrap().iter().find(|s|s["name"]==old["name"]).unwrap();
  steps.push(step(&name,json!(["taskset","-c","0-31",binary,old["image"],old["request"],"1",out]),oldstep["environment"].clone()));
  verifies.push(step(&format!("verify-{name}"),json!([VERIFY,old["image"],old["image_sha256"],format!("{out}/0.proof"),format!("{out}/0.public"),old["public_sha256"]]),json!({})));
  job["original_name"]=old["name"].clone();job["name"]=name.into();job["arm"]="constant-half".into();job["proof"]=format!("{out}/0.proof").into();job["public"]=format!("{out}/0.public").into();jobs.push(job);
 }
 assert_eq!(jobs.len(),9);steps.extend(verifies);
 save(format!("{R}/preflight-jobs.json"),&json!(jobs));
 let protocol=json!({"scope":"all-nine correctness preflight; one observed request after three primes; recorded clock values are diagnostic only, not a matched performance comparison","SDK_requests":36,"fresh_exports":9,"rounds":1,"primes":3,"workers":32,"cpus":"0-31","binary":binary,"binary_sha256":link["binary_sha256"],"canonical_before":LEDGER,"canonical_before_count":31913,"no_proof_speed_or_memory_claim":true,"jobs":jobs});save(format!("{R}/preflight-protocol.json"),&protocol);
 let mut pins:BTreeMap<String,String>=serde_json::from_value(read(format!("{R}/pins.json"))).unwrap();for(p,h)in link["input_pins"].as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pins.insert(p.clone(),h.as_str().unwrap().into());}for p in [LEDGER,VERIFY,binary]{pins.insert(p.into(),hash(p));}
 for j in &jobs{for k in ["image","request"]{let path=j[k].as_str().unwrap();pins.entry(path.into()).or_insert_with(||hash(path));}}
 for name in ["campaign.rs","campaign","preflight-jobs.json","preflight-protocol.json","codegen-analysis.json"]{let p=format!("{R}/{name}");pins.insert(p.clone(),hash(p));}save(format!("{R}/preflight-pins.json"),&json!(pins));save(format!("{R}/preflight-plan.json"),&json!({"version":1,"source_pins":format!("{R}/preflight-pins.json"),"steps":steps}));println!("READY9freshcompleteproofexports/36SDKrequests;not a performance trial");
}
fn analyze(){
 assert_eq!(read(format!("{R}/preflight/completed.json")).as_array().unwrap().len(),18);let mut receipts=0;let plan=read(format!("{R}/preflight-plan.json"));for step in plan["steps"].as_array().unwrap(){let name=step["name"].as_str().unwrap();let root=format!("{R}/preflight/{name}");let exit=read(format!("{root}/exit.json"));assert_eq!(exit["success"],true);assert_eq!(exit["returncode"],0);let command=read(format!("{root}/command.json"));let args=command["argv"].as_array().unwrap();let expected=step["argv"].as_array().unwrap();assert_eq!(&args[args.len()-expected.len()..],expected);for stream in ["stdout","stderr"]{assert_eq!(hash(format!("{root}/{stream}.log")),exit[format!("{stream}_sha256")].as_str().unwrap());}receipts+=1;}
 let mut ledger:BTreeSet<String>=serde_json::from_value(read(LEDGER)).unwrap();assert_eq!(ledger.len(),31913);let mut proofs=vec![];
 for job in read(format!("{R}/preflight-jobs.json")).as_array().unwrap(){let name=job["name"].as_str().unwrap();let proof=job["proof"].as_str().unwrap();let public=job["public"].as_str().unwrap();assert_eq!(fs::metadata(proof).unwrap().len(),164);assert_eq!(fs::metadata(public).unwrap().len(),44);let ph=hash(proof);assert!(ledger.insert(ph.clone()));let public_hash=hash(public);assert_eq!(public_hash,job["public_sha256"].as_str().unwrap());
  let verifier=fs::read_to_string(format!("{R}/preflight/verify-{name}/stdout.log")).unwrap();let line=verifier.lines().find(|l|l.starts_with("VERIFIED ")).unwrap();assert_eq!(verifier.lines().filter(|l|l.starts_with("VERIFIED ")).count(),1);let fields=line.split_whitespace().skip(1).map(|s|s.split_once('=').unwrap()).collect::<BTreeMap<_,_>>();assert_eq!(fields["proof_sha256"],ph);assert_eq!(fields["public_sha256"],public_hash);assert_eq!(fields["image_sha256"],job["image_sha256"].as_str().unwrap());
  let old=fs::read_to_string(format!("{OLD}/preflight-runs/verify-{}/stdout.log",job["original_name"].as_str().unwrap())).unwrap();assert!(old.contains(&format!("vk_sha256={}",fields["vk_sha256"])));
  let stdout=fs::read_to_string(format!("{R}/preflight/{name}/stdout.log")).unwrap();let summary=stdout.lines().filter_map(|s|s.strip_prefix("SUMMARY ")).collect::<Vec<_>>();assert_eq!(summary.len(),1);let s:Value=serde_json::from_str(summary[0]).unwrap();assert_eq!(s["rounds"],1);assert_eq!(s["priming"],3);assert_eq!(s["workers"],32);assert_eq!(stdout.lines().filter(|l|l.starts_with("SAMPLE ")).count(),1);
  proofs.push(json!({"name":name,"shape":job["shape"],"proof_sha256":ph,"public_sha256":public_hash,"image_sha256":fields["image_sha256"],"vk_sha256":fields["vk_sha256"]}));
 }
 assert_eq!(ledger.len(),31922);save(format!("{R}/proof-sha256-after.json"),&json!(ledger));save(format!("{R}/preflight-analysis.json"),&json!({"passed":true,"receipts":receipts,"SDK_requests":36,"fresh_exports":9,"canonical_before":31913,"canonical_after":31922,"proofs":proofs,"no_matched_latency_or_memory_comparison":true}));println!("PASSall9Gnarkfreshbindings;36SDKrequests;ledger31922;no speedclaim");
}
fn main(){match std::env::args().nth(1).as_deref(){Some("prepare")=>prepare(),Some("analyze")=>analyze(),_=>panic!("prepare|analyze")}}
