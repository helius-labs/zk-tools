use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/pairing-half-constant176";
const REPO:&str="/home/ubuntu/src/zk-tools/zopro";
const M:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(p:impl AsRef<Path>,v:&Value){assert!(!p.as_ref().exists());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn main(){
 let manifest=read(M);let files=manifest["source_files_sha256"].as_object().unwrap();assert_eq!(files.len(),176);assert!(!Path::new(&format!("{R}/source")).exists());
 for(name,h)in files{let old=format!("{REPO}/{name}");assert_eq!(hash(&old),h.as_str().unwrap());let out=format!("{R}/source/{name}");fs::create_dir_all(Path::new(&out).parent().unwrap()).unwrap();fs::copy(old,out).unwrap();}
 let path=format!("{R}/source/crates/zopro-bn254/src/pairing.rs");let original=fs::read_to_string(&path).unwrap();
 let before="let two_inv = Fq::from_u64(2).inverse().expect(\"2 is invertible\");";
 let after="let two_inv = const { Fq::from_decimal(\"10944121435919637611123202872628637544348155578648911831344518947322613104292\") };";
 assert_eq!(original.matches(before).count(),1);
 let start=original.find("    pub fn new(q: &G2Affine) -> Self {").unwrap();let mut depth=0;let mut end=None;for (offset,c)in original[start..].char_indices(){if c=='{'{depth+=1;}else if c=='}'{depth-=1;if depth==0{end=Some(start+offset+1);break;}}}
 let reference=original[start..end.unwrap()].replace("pub fn new(q: &G2Affine) -> Self","fn reference(q: &G2Affine) -> G2Prepared").replace("Self {","G2Prepared {");
 let test=format!(r#"
#[cfg(test)]
mod half_constant_tests {{
    use super::*;
    {reference}
    #[test]
    fn prepared_lines_and_halving_match_original() {{
        const HALF: Fq = Fq::from_decimal("10944121435919637611123202872628637544348155578648911831344518947322613104292");
        assert_eq!(HALF * Fq::from_u64(2), Fq::ONE);
        assert_eq!(HALF, Fq::from_u64(2).inverse().unwrap());
        let generator=crate::G2Projective::generator();let mut seed=0x173491aed82c79bfu64;let mut lines=0;
        for i in 0..34 {{
            let point=if i==0 {{G2Affine::IDENTITY}} else if i==1 {{generator.to_affine()}} else {{
                let mut bytes=[0u8;64];for block in bytes.chunks_exact_mut(8){{seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;block.copy_from_slice(&seed.to_le_bytes());}}
                (generator*crate::Fr::from_random_bytes(&bytes)).to_affine()
            }};
            let actual=G2Prepared::new(&point);let old=reference(&point);assert_eq!(actual,old);lines+=actual.lines.len();
        }}
        println!("HALF_CONSTANT points=34 nonidentity=33 lines={{lines}}");
    }}
}}
"#);
 fs::write(&path,format!("{}{test}",original.replacen(before,after,1))).unwrap();
 save(format!("{R}/edits.json"),&json!({"path":"crates/zopro-bn254/src/pairing.rs","before":before,"after":after,"test_suffix":test,"original_sha256":files["crates/zopro-bn254/src/pairing.rs"]}));
 let olddriver="/home/ubuntu/src/zopro-perf-work/byte-permute-pack176/driver.rs";let oldsupport="/home/ubuntu/src/zopro-perf-work/byte-permute-pack176/support/perf.rs";
 fs::create_dir_all(format!("{R}/support")).unwrap();fs::copy(olddriver,format!("{R}/driver.rs")).unwrap();fs::copy(oldsupport,format!("{R}/support/perf.rs")).unwrap();
 let mut pins=BTreeMap::new();for name in files.keys(){let p=format!("{R}/source/{name}");pins.insert(p.clone(),hash(p));}for name in ["prepare.rs","design.md","edits.json","driver.rs","support/perf.rs"]{let p=format!("{R}/{name}");pins.insert(p.clone(),hash(p));}pins.insert(M.to_string(),hash(M));save(format!("{R}/pins.json"),&json!(pins));
 let cargo="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/cargo";
 let native=json!({"PATH":"/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin","RUSTC":"/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc","CARGO_BUILD_JOBS":"16","CARGO_TARGET_DIR":format!("{R}/target-native"),"RUSTFLAGS":manifest["rustflags"]});
 let mut portable=native.clone();portable["CARGO_TARGET_DIR"]=format!("{R}/target-portable").into();portable["RUSTFLAGS"]="-C target-cpu=generic --cfg no_asm --cfg no_ifma".into();
 let test=|name:&str,env:Value|json!({"kind":"command","name":name,"argv":[cargo,"test","--manifest-path",format!("{R}/source/Cargo.toml"),"--locked","--offline","--release","-p","zopro-bn254","--lib","pair","--","--test-threads=1","--nocapture"],"environment":env,"timeout_seconds":900});
 let plan=json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":[
  test("native-pairing",native.clone()),test("portable-pairing",portable),
  {"kind":"command","name":"libraries","argv":[cargo,"build","--manifest-path",format!("{R}/source/Cargo.toml"),"--locked","--offline","--release","-p","zopro-bench","--lib","--message-format=json"],"environment":native,"timeout_seconds":900},
  {"kind":"link-sdk","name":"candidate","artifacts":format!("{R}/native/libraries/stdout.log"),"driver":format!("{R}/driver.rs"),"additional_sources":[format!("{R}/support/perf.rs")],"timeout_seconds":900}
 ]});save(format!("{R}/native-plan.json"),&plan);println!("Prepared176-source snapshot;one const replacement+test suffix;production unchanged");
}
