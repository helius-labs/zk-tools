use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,io::Read,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/pairing-half-constant176";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/primary-instruction-census176";
const SDK:&str="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/native/candidate-sdk";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){assert!(!p.as_ref().exists());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn hash(p:impl AsRef<Path>)->String{let mut h=Sha256::new();let mut f=fs::File::open(p).unwrap();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break;}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn symbol(text:&str)->Value{let rows=text.lines().filter(|l|l.split_whitespace().last().is_some_and(|s|s.contains("G2Prepared")&&s.ends_with("3new"))).collect::<Vec<_>>();assert_eq!(rows.len(),1);let cols=rows[0].split_whitespace().collect::<Vec<_>>();assert_eq!(cols.len(),4);json!({"address":u64::from_str_radix(cols[0],16).unwrap(),"size":u64::from_str_radix(cols[1],16).unwrap(),"symbol":cols[3]})}
fn step(name:&str,argv:Value)->Value{json!({"kind":"command","name":name,"argv":argv,"timeout_seconds":120})}
fn prepare_nm(){
 assert_eq!(hash(SDK),"6d83f1d6fda6f16576cb351b81789e8d26a6177cc0f26f169a3dc98448c0e661");let old=read(format!("{OLD}/nm.command.json"));assert_eq!(old["success"],true);assert_eq!(hash(format!("{OLD}/nm.stdout")),old["stdout_sha256"].as_str().unwrap());
 let link=read(format!("{R}/native/candidate/artifacts.json"));assert_eq!(link["libraries"].as_object().unwrap().len(),8);let binary=link["binary"].as_str().unwrap();assert_eq!(hash(binary),link["binary_sha256"].as_str().unwrap());
 let command=read(format!("{R}/native/candidate/command.json"));for flag in ["-O","target-cpu=native","lto=fat","codegen-units=1"]{assert!(command["argv"].as_array().unwrap().iter().any(|v|v==flag));}
 let mut pins:BTreeMap<String,String>=serde_json::from_value(read(format!("{R}/pins.json"))).unwrap();pins.insert(SDK.into(),hash(SDK));for p in [format!("{OLD}/nm.stdout"),format!("{OLD}/nm.command.json"),format!("{R}/codegen.rs"),format!("{R}/codegen"),format!("{R}/native/candidate/artifacts.json"),format!("{R}/native/candidate/command.json")]{pins.insert(p.clone(),hash(p));}pins.insert(binary.into(),hash(binary));
 save(format!("{R}/nm-pins.json"),&json!(pins));save(format!("{R}/nm-plan.json"),&json!({"version":1,"source_pins":format!("{R}/nm-pins.json"),"steps":[step("candidate-nm",json!(["nm","-S","--size-sort","--defined-only",binary]))]}));
 println!("NewSDKlinkflags/coherent8libschecked;savedacceptednmreused;prepare one candidate listing");
}
fn prepare_decodes(){
 let mut jobs=vec![];let candidate=read(format!("{R}/native/candidate/artifacts.json"));
 for(arm,binary,nm)in [("accepted",SDK.to_owned(),format!("{OLD}/nm.stdout")),("candidate",candidate["binary"].as_str().unwrap().to_owned(),format!("{R}/nm-runs/candidate-nm/stdout.log"))]{let mut s=symbol(&fs::read_to_string(&nm).unwrap());s["arm"]=arm.into();s["binary"]=binary.clone().into();s["binary_sha256"]=hash(&binary).into();s["nm"]=nm.into();jobs.push(s);}
 let mut pins:BTreeMap<String,String>=serde_json::from_value(read(format!("{R}/nm-pins.json"))).unwrap();for p in [format!("{R}/nm-runs/candidate-nm/stdout.log"),format!("{R}/nm-runs/candidate-nm/command.json"),format!("{R}/nm-runs/candidate-nm/exit.json")]{pins.insert(p.clone(),hash(p));}
 save(format!("{R}/codegen-jobs.json"),&json!(jobs));pins.insert(format!("{R}/codegen-jobs.json"),hash(format!("{R}/codegen-jobs.json")));save(format!("{R}/decode-pins.json"),&json!(pins));
 let steps=jobs.iter().map(|j|step(j["arm"].as_str().unwrap(),json!(["objdump","-d","-M","intel",format!("--disassemble={}",j["symbol"].as_str().unwrap()),j["binary"]]))).collect::<Vec<_>>();save(format!("{R}/decode-plan.json"),&json!({"version":1,"source_pins":format!("{R}/decode-pins.json"),"steps":steps}));println!("Prepared exactlytwo previouslyundecoded actualSDKconstructor functions");
}
fn analyze(){
 let jobs=read(format!("{R}/codegen-jobs.json"));let mut rows=vec![];
 for j in jobs.as_array().unwrap(){let arm=j["arm"].as_str().unwrap();let text=fs::read_to_string(format!("{R}/decode-runs/{arm}/stdout.log")).unwrap();let instructions=text.lines().filter(|line|{let s=line.trim_start();let Some((address,rest))=s.split_once(':')else{return false};!address.is_empty()&&address.chars().all(|c|c.is_ascii_hexdigit())&&rest.split_whitespace().next().is_some_and(|b|b.len()==2&&b.chars().all(|c|c.is_ascii_hexdigit()))}).collect::<Vec<_>>();assert!(!instructions.is_empty());
  let call_rows=instructions.iter().filter(|s|s.contains("\tcall ")).copied().collect::<Vec<_>>();let inverse_calls=call_rows.iter().filter(|s|s.contains("inverse")).copied().collect::<Vec<_>>();let gcd_calls=call_rows.iter().filter(|s|s.contains("coefficient_update")||s.contains("zero_run_matrix")||s.contains("6finish")).copied().collect::<Vec<_>>();
  rows.push(json!({"arm":arm,"binary_sha256":j["binary_sha256"],"symbol":j["symbol"],"size_bytes":j["size"],"instruction_rows":instructions.len(),"call_rows":call_rows,"inverse_call_rows":inverse_calls,"named_GCD_helper_call_rows":gcd_calls}));
 }
 let out=json!({"rows":rows,"production_changed":false,"no_latency_or_memory_result":true,"constructor_boundary_only":true,"no_claim_that_call_absence_excludes_inlining":true});save(format!("{R}/codegen-analysis.json"),&out);println!("{}",out);
}
fn capture(dir:&str,argv:Vec<String>)->Value{
 assert!(!Path::new(dir).exists());fs::create_dir_all(dir).unwrap();let output=std::process::Command::new(&argv[0]).args(&argv[1..]).output().unwrap();fs::write(format!("{dir}/stdout.log"),&output.stdout).unwrap();fs::write(format!("{dir}/stderr.log"),&output.stderr).unwrap();
 let exit=json!({"success":output.status.success(),"returncode":output.status.code(),"stdout_sha256":hash(format!("{dir}/stdout.log")),"stderr_sha256":hash(format!("{dir}/stderr.log"))});save(format!("{dir}/command.json"),&json!({"argv":argv}));save(format!("{dir}/exit.json"),&exit);assert!(output.status.success());exit
}
fn complete(){
 prepare_nm();let candidate=read(format!("{R}/native/candidate/artifacts.json"));let binary=candidate["binary"].as_str().unwrap();let mut receipts=vec![];
 receipts.push(capture(&format!("{R}/nm-runs/candidate-nm"),vec!["nm".into(),"-S".into(),"--size-sort".into(),"--defined-only".into(),binary.into()]));prepare_decodes();
 let jobs=read(format!("{R}/codegen-jobs.json"));for j in jobs.as_array().unwrap(){receipts.push(capture(&format!("{R}/decode-runs/{}",j["arm"].as_str().unwrap()),vec!["objdump".into(),"-d".into(),"-M".into(),"intel".into(),format!("--disassemble={}",j["symbol"].as_str().unwrap()),j["binary"].as_str().unwrap().into()]));}
 analyze();save(format!("{R}/codegen-captured.json"),&json!(receipts));
}
fn main(){match std::env::args().nth(1).as_deref(){Some("prepare-nm")=>prepare_nm(),Some("prepare-decodes")=>prepare_decodes(),Some("analyze")=>analyze(),Some("complete")=>complete(),_=>panic!("prepare-nm|prepare-decodes|analyze|complete")}}
