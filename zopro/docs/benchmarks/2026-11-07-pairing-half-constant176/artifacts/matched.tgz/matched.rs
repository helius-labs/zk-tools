use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,io::Read,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/pairing-half-constant176";
const OLD:&str="/home/ubuntu/src/zopro-perf-work/byte-permute-pack176/pilot/primary-pilot";
const CONTROL:&str="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/native/candidate-sdk";
const VERIFY:&str="/home/ubuntu/src/zopro-perf-work/batch-local-steal/gnark/verify";
fn load(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn save(p:impl AsRef<Path>,v:&Value){assert!(!p.as_ref().exists(),"{} exists",p.as_ref().display());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn hash(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break;}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn step(name:&str,argv:Value,env:Value)->Value{json!({"kind":"command","name":name,"argv":argv,"environment":env,"timeout_seconds":900})}
fn main(){
 let base=format!("{R}/matched");assert!(!Path::new(&base).exists());for sub in ["proofs","stat","perf"]{fs::create_dir_all(format!("{base}/{sub}")).unwrap();}
 let review=load(format!("{R}/review.json"));assert_eq!(review["passed"],true);assert_eq!(review["canonical_after"],31922);
 let ledger=load(format!("{R}/proof-sha256-after.json"));assert_eq!(ledger.as_array().unwrap().len(),31922);
 let link=load(format!("{R}/native/candidate/artifacts.json"));let candidate=link["binary"].as_str().unwrap();assert_eq!(hash(candidate),"b23c9c2cf367111126c1047ea57cc4634cc25aef5912db5c6b2c163b4ab38a33");assert_eq!(hash(CONTROL),"6d83f1d6fda6f16576cb351b81789e8d26a6177cc0f26f169a3dc98448c0e661");
 let jobs=load(format!("{R}/preflight-jobs.json"));assert_eq!(jobs.as_array().unwrap().len(),9);let preplan=load(format!("{R}/preflight-plan.json"));
 let mut captures=vec![];let mut verifiers=vec![];let mut entries=vec![];let arms=[("accepted",CONTROL),("candidate",candidate)];
 let make_job=|binding:&Value,name:&str,arm:&str,stage:&str,rounds:usize|{let mut j=binding.clone();j["name"]=name.into();j["arm"]=arm.into();j["stage"]=stage.into();j["rounds"]=rounds.into();j["proof"]=format!("{base}/proofs/{name}/0.proof").into();j["public"]=format!("{base}/proofs/{name}/0.public").into();j};
 let verify=|job:&Value|step(&format!("verify-{}",job["name"].as_str().unwrap()),json!([VERIFY,job["image"],job["image_sha256"],job["proof"],job["public"],job["public_sha256"]]),json!({}));
 for block in 0..15usize{let mut order=(0..9).collect::<Vec<_>>();order.rotate_left(block%9);if block%2==1{order.reverse();}
  for index in order{let binding=&jobs[index];let shape=binding["shape"].as_str().unwrap();let rounds=if shape=="1x2"{151}else{31};let env=preplan["steps"].as_array().unwrap().iter().find(|s|s["name"]==binding["name"]).unwrap()["environment"].clone();let order=if(block+index)%2==0{[0,1]}else{[1,0]};
   for arm_index in order{let(arm,binary)=arms[arm_index];let name=format!("lat-b{block:02}-{shape}-{arm}");let mut job=make_job(binding,&name,arm,"latency",rounds);job["block"]=block.into();job["case_index"]=index.into();captures.push(step(&name,json!(["taskset","-c","0-31",binary,binding["image"],binding["request"],rounds.to_string(),format!("{base}/proofs/{name}")]),env.clone()));verifiers.push(verify(&job));entries.push(job);}
  }
 }
 assert_eq!(captures.len(),270);assert_eq!(verifiers.len(),270);captures.extend(verifiers);
 let old_diag=load(format!("{OLD}/diagnostic-plan.json"));let binding=&jobs[0];assert_eq!(binding["shape"],"1x2");let mut diagnostic=vec![];let mut diag_verify=vec![];let mut offline=vec![];
 let relocate=|text:&str,arm:&str,binary:&str|->String{if text==CONTROL{return binary.into()}if text.contains(OLD){text.replace(OLD,&base).replace("accepted",arm)}else{text.into()}};
 for(kind,rounds)in [("stat",31),("cycles",251)]{let template_name=format!("{kind}-accepted");let template=old_diag["steps"].as_array().unwrap().iter().find(|s|s["name"]==template_name).unwrap();
  for(arm,binary)in arms{let name=format!("{kind}-{arm}");let mut cmd=template.clone();cmd["name"]=name.clone().into();for token in cmd["argv"].as_array_mut().unwrap(){let value=relocate(token.as_str().unwrap(),arm,binary);*token=value.into();}diagnostic.push(cmd);let job=make_job(binding,&name,arm,"diagnostic",rounds);diag_verify.push(verify(&job));entries.push(job);
   if kind=="cycles"{for prefix in ["own","decode","events","metadata","loss"]{let oldname=format!("{prefix}-cycles-accepted");let mut cmd=old_diag["steps"].as_array().unwrap().iter().find(|s|s["name"]==oldname).unwrap().clone();cmd["name"]=format!("{prefix}-{name}").into();for token in cmd["argv"].as_array_mut().unwrap(){*token=relocate(token.as_str().unwrap(),arm,binary).into();}offline.push(cmd);}}
  }
 }
 assert_eq!(diagnostic.len(),4);assert_eq!(diag_verify.len(),4);assert_eq!(offline.len(),10);diagnostic.extend(diag_verify);diagnostic.extend(offline);
 let protocol=json!({"design":format!("{R}/performance-design.md"),"design_sha256":hash(format!("{R}/performance-design.md")),"blocks":15,"arms":[{"name":"accepted","binary":CONTROL,"sha256":hash(CONTROL)},{"name":"candidate","binary":candidate,"sha256":hash(candidate)}],"workers":32,"cpus":"0-31","priming":3,"primary_rounds":151,"other_rounds":31,"cases":jobs.as_array().unwrap().iter().map(|j|j["shape"].clone()).collect::<Vec<_>>(),"case_order":"rotate left block%9, reverse odd blocks","arm_order":"alternate (block+original_case_index)%2","unit":"process arithmetic mean complete SDK request","paired_sorted_indices":[3,7,11],"marginal_coverage":0.96484375,"cleanup_nonregression_upper_ratio":1.03,"all_nine_required":true,"gain_gate_required":false,"no_positive_gain_floor":true,"not_isolated_source_causality":true,"fresh_OFF_control":false,"latency_requests":12780,"latency_exports":270,"latency_commands":540,"diagnostic_requests":576,"diagnostic_exports":4,"diagnostic_commands":18,"canonical_before":format!("{R}/proof-sha256-after.json"),"canonical_before_count":31922,"canonical_after_latency":32192,"canonical_after_diagnostic":32196,"profile_period":16000000,"mmap_pages":512,"no_exclusion_extension_subset_reroll":true,"source_adoption_requires_separate_engineering_decision":true,"goal_active_unmet_original_all8":true});
 save(format!("{base}/protocol.json"),&protocol);save(format!("{base}/jobs.json"),&json!(entries));
 let mut pins:BTreeMap<String,String>=serde_json::from_value(load(format!("{R}/preflight-pins.json"))).unwrap();for path in [format!("{R}/matched.rs"),format!("{R}/matched-helper"),format!("{R}/performance-design.md"),format!("{R}/review.json"),format!("{R}/proof-sha256-after.json"),format!("{base}/protocol.json"),format!("{base}/jobs.json")]{pins.insert(path.clone(),hash(path));}pins.insert(CONTROL.into(),hash(CONTROL));
 let old_pins=load(old_diag["source_pins"].as_str().unwrap());for step in diagnostic.iter(){if step["name"].as_str().unwrap().starts_with("loss-"){let tool=step["argv"][0].as_str().unwrap();assert_eq!(hash(tool),old_pins[tool].as_str().unwrap());pins.insert(tool.into(),hash(tool));let source=format!("{tool}.rs");assert_eq!(hash(&source),old_pins[&source].as_str().unwrap());pins.insert(source.clone(),hash(source));}}
 save(format!("{base}/pins.json"),&json!(pins));for(name,steps)in [("latency",captures),("diagnostic",diagnostic)]{save(format!("{base}/{name}-plan.json"),&json!({"version":1,"source_pins":format!("{base}/pins.json"),"steps":steps}));}
 for fifo in [format!("{base}/ctl"),format!("{base}/ack")]{assert!(!Path::new(&fifo).exists());let output=std::process::Command::new("mkfifo").arg(&fifo).output().unwrap();assert!(output.status.success());}
 println!("READY15blocks/all9/twoarms;540latency+verification/18diagnosticcommands;12780+576SDKrequests;canonical31922->32192->32196;no capture launched");
}
