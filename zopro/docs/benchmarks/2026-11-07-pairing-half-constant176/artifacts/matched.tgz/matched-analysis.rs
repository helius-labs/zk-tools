use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{cell::RefCell, collections::{BTreeMap, BTreeSet}, fs, io::Read, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/pairing-half-constant176/matched";
thread_local! {static INPUTS: RefCell<BTreeMap<String,String>> = RefCell::new(BTreeMap::new());}
fn hash(p: &str) -> String {
    let mut f=fs::File::open(p).unwrap(); let mut h=Sha256::new(); let mut buf=[0;65536];
    loop {let n=f.read(&mut buf).unwrap(); if n==0 {break} h.update(&buf[..n]);}
    let v=format!("{:x}",h.finalize()); INPUTS.with(|m| {let old=m.borrow_mut().insert(p.into(),v.clone()); if let Some(old)=old {assert_eq!(old,v)}}); v
}
fn text(p:&str)->String {hash(p); fs::read_to_string(p).unwrap()}
fn load(p:&str)->Value {serde_json::from_str(&text(p)).unwrap()}
fn save(p:&str,v:&Value) {assert!(!Path::new(p).exists(),"already exists: {p}"); fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn attrs(s:&str)->BTreeMap<String,String> {let lines=s.lines().filter(|l|l.starts_with("VERIFIED ")).collect::<Vec<_>>(); assert_eq!(lines.len(),1); lines[0].split_whitespace().skip(1).map(|s| {let (k,v)=s.split_once('=').unwrap();(k.into(),v.into())}).collect()}
fn triple(mut v:Vec<f64>)->Value {assert_eq!(v.len(),15); let wins=v.iter().filter(|v|**v<1.).count();v.sort_by(f64::total_cmp);json!({"lower":v[3],"median":v[7],"upper":v[11],"wins":wins,"blocks":15})}
fn main() {
    let stage=std::env::args().nth(1).unwrap(); assert_eq!(stage,"latency");
    hash(file!()); hash(std::env::current_exe().unwrap().to_str().unwrap());
    let p=load(&format!("{R}/protocol.json"));assert_eq!(p["blocks"],15);assert_eq!(p["paired_sorted_indices"],json!([3,7,11]));assert_eq!(p["cleanup_nonregression_upper_ratio"],1.03);
    for (path,h) in load(&format!("{R}/pins.json")).as_object().unwrap() {assert_eq!(hash(path),h.as_str().unwrap());}
    let plan=load(&format!("{R}/latency-plan.json"));let steps=plan["steps"].as_array().unwrap();assert_eq!(steps.len(),540);
    let result=load(&format!("{R}/latency-runs/result.json"));assert_eq!(result["status"],"complete");
    let completed=load(&format!("{R}/latency-runs/completed.json"));assert_eq!(completed,json!(steps.iter().map(|s|s["name"].clone()).collect::<Vec<_>>()));assert_eq!(result["steps"],completed);
    for step in steps {
        let name=step["name"].as_str().unwrap();let dir=format!("{R}/latency-runs/{name}"); let cmd=load(&format!("{dir}/command.json"));let argv=cmd["argv"].as_array().unwrap();let expected=step["argv"].as_array().unwrap();assert_eq!(&argv[argv.len()-expected.len()..],expected);
        if let Some(env)=step["environment"].as_object() {for (k,v) in env {assert_eq!(&cmd["environment"][k],v);}}
        let exit=load(&format!("{dir}/exit.json"));assert_eq!(exit["success"],true);assert_eq!(exit["returncode"],0);
        for stream in ["stdout","stderr"] {assert_eq!(hash(&format!("{dir}/{stream}.log")),exit[format!("{stream}_sha256")].as_str().unwrap());}
    }
    let mut ledger:BTreeSet<String>=serde_json::from_value(load(p["canonical_before"].as_str().unwrap())).unwrap();assert_eq!(ledger.len(),31922);
    let jobs=load(&format!("{R}/jobs.json"));let mut rows=vec![];let mut means=BTreeMap::<(String,String,u64),f64>::new();let mut requests=0;
    for job in jobs.as_array().unwrap().iter().filter(|j|j["stage"]=="latency") {
        let name=job["name"].as_str().unwrap();let shape=job["shape"].as_str().unwrap();let arm=job["arm"].as_str().unwrap();let block=job["block"].as_u64().unwrap();assert!(block<15);let rounds=job["rounds"].as_u64().unwrap();assert_eq!(rounds,if shape=="1x2" {151}else{31});
        let raw=text(&format!("{R}/latency-runs/{name}/stdout.log"));let mut samples=vec![];let mut summaries=vec![];
        for line in raw.lines() {if let Some(v)=line.strip_prefix("SAMPLE ") {let v:Value=serde_json::from_str(v).unwrap();assert_eq!(v["round"],samples.len());let ms=v["ms"].as_f64().unwrap();assert!(ms.is_finite()&&ms>0.);samples.push(ms);} if let Some(v)=line.strip_prefix("SUMMARY ") {summaries.push(serde_json::from_str::<Value>(v).unwrap());}}
        assert_eq!(samples.len() as u64,rounds);assert_eq!(summaries.len(),1);let summary=&summaries[0];assert_eq!(summary["rounds"],rounds);assert_eq!(summary["workers"],32);assert_eq!(summary["priming"],3);assert!(summary["whole_process_maxrss_kib"].as_u64().unwrap()>0);
        let proof=job["proof"].as_str().unwrap();let public=job["public"].as_str().unwrap();assert_eq!(fs::metadata(proof).unwrap().len(),164);assert_eq!(fs::metadata(public).unwrap().len(),44);let ph=hash(proof);let pu=hash(public);assert!(ledger.insert(ph.clone()),"nonfresh {name}");assert_eq!(pu,job["public_sha256"].as_str().unwrap());
        let verified=attrs(&text(&format!("{R}/latency-runs/verify-{name}/stdout.log")));assert_eq!(verified["proof_sha256"],ph);assert_eq!(verified["public_sha256"],pu);assert_eq!(verified["image_sha256"],job["image_sha256"].as_str().unwrap());
        let old=attrs(&text(&format!("/home/ubuntu/src/zopro-perf-work/byte-permute-pack176/pilot/preflight-runs/verify-{}/stdout.log",job["original_name"].as_str().unwrap())));assert_eq!(verified["vk_sha256"],old["vk_sha256"]);
        let mean=samples.iter().sum::<f64>()/rounds as f64;assert!(means.insert((shape.into(),arm.into(),block),mean).is_none());requests+=rounds+3;
        rows.push(json!({"job":job,"mean_ms":mean,"summary":summary,"proof_sha256":ph,"public_sha256":pu,"vk_sha256":verified["vk_sha256"]}));
    }
    assert_eq!(rows.len(),270);assert_eq!(requests,12780);assert_eq!(ledger.len(),32192);
    let cases=p["cases"].as_array().unwrap();assert_eq!(cases.len(),9);let mut results=BTreeMap::new();let mut cleanup=true;
    for shape in cases {let shape=shape.as_str().unwrap();let mut arms=BTreeMap::new();for arm in ["accepted","candidate"] {let mut v=(0..15).map(|b|means[&(shape.into(),arm.into(),b)]).collect::<Vec<_>>();v.sort_by(f64::total_cmp);let rss=rows.iter().filter(|r|r["job"]["shape"]==shape&&r["job"]["arm"]==arm).map(|r|r["summary"]["whole_process_maxrss_kib"].as_u64().unwrap()).collect::<Vec<_>>();arms.insert(arm,json!({"median_process_mean_ms":v[7],"min_process_mean_ms":v[0],"max_process_mean_ms":v[14],"whole_process_RSS_min_kib":rss.iter().min().unwrap(),"whole_process_RSS_max_kib":rss.iter().max().unwrap()}));}
        let ratios=(0..15).map(|b|means[&(shape.into(),"candidate".into(),b)]/means[&(shape.into(),"accepted".into(),b)]).collect::<Vec<_>>();let paired=triple(ratios.clone());let nonreg=paired["upper"].as_f64().unwrap()<=1.03;cleanup&=nonreg;results.insert(shape.to_string(),json!({"arms":arms,"candidate_over_accepted":paired,"ratios_by_block":ratios,"cleanup_nonregression_passed":nonreg}));
    }
    let aggregate=(0..15).map(|b| (cases.iter().take(8).map(|s| {let s=s.as_str().unwrap();(means[&(s.into(),"candidate".into(),b)]/means[&(s.into(),"accepted".into(),b)]).ln()}).sum::<f64>()/8.).exp()).collect::<Vec<_>>();
    let output=json!({"passed_data_validation":true,"workflow_receipts":540,"SDK_requests":requests,"fresh_exports":270,"canonical_before":31922,"canonical_after":32192,"cases":results,"original8_equal_log_aggregate_descriptive":triple(aggregate),"cleanup_nonregression_passed":cleanup,"no_speed_gain_gate":true,"not_isolated_constant_causality":true,"goal_original8_achieved":0,"production_changed":false,"rows":rows});
    save(&format!("{R}/proof-sha256-after-latency.json"),&json!(ledger));save(&format!("{R}/latency-analysis.json"),&output);let inputs=INPUTS.with(|m|m.borrow().clone());save(&format!("{R}/latency-analysis-inputs.json"),&json!(inputs));
    println!("PASS540receipts/270freshGnarkbindings/12780SDKrequests;canonical32192;cleanup_nonregression={cleanup}");for (shape,v) in output["cases"].as_object().unwrap() {println!("{shape}: {}",v["candidate_over_accepted"]);}
}
