set pagination off
set confirm off
set print thread-events off
set print frame-arguments none
set print entry-values no
set debuginfod enabled off
set disable-randomization off
set auto-load python-scripts off
unset environment LD_LIBRARY_PATH
catch syscall mmap
condition 1 $rsi == 67112960
commands 1
  silent
  printf "OWNER_MAP bytes=%ld syscall_result=%ld\n", $rsi, $rax
  bt 48
  continue
end
run
