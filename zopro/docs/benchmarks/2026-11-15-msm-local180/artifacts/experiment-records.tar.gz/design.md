# Full-request MSM observer integration

Selected question: why does Aeglos Sorted's MSM scale32→96 on C7a while current
Zopro full requests do not? This step integrates the qualified Aeglos observer
and adds a bounded current-Zopro coarse observer. No optimization or adoption.
Fullall8CPU10x goal and CPU/Metal comparisons remain unchanged,0/8.

Use current accepted177-fileZopro snapshot and exactSDKb646 as REF. NewOFF/ON
share one coherently builtSDK with original accepted Zen4 flags, arithmetic and
scheduler. PrivateRust observer has8 fixed unique slots owned by one canonical
solve invocation: solver,scalarprep,FFT,allqueries,A,KH,G2,output. It is created
after the existing worker-entry hop and explicitly borrowed by the three original
query closures; no global/TLS attribution or per-task traces. Atomic slots with
unique-entry/error checks support overlapping callbacks. Finite stack formatting,
no dynamic recording buffers. Wholequery span contains original branch execution;
callback spans can include helping/waiting, not exclusiveCPU. Unsupported ordinary
routes report an explicit incomplete/unsupported record and cannot be promoted.
Primary1x2 is the diagnostic target; other shapes keep inherited production status.

Aeglos retains msm-stage180's qualified native observer/archive unchanged. Link
its native archive into the retained fullrequestGo harness. Build an unmodified
native archive from recovered original sources and link that with identical
harness as separate freshcontrol. Retain oldeab9 reference binary to check drift.
Same underlyingkey/request/publicbindings,24GiB preparationpolicy,Sorted/Windowed
switch,GOMAXPROCS andnativeworkers aligned. Exact source/build identities required.
FullSDK timings include observer clocks/setup/format/I/O, witnessedassignment,
solving,randomness,proving,internalverification,serialization; exclude load/prime.

Before any SDKcall: freeze inputs,protocol,reader andcanonical55209seed. Initial
functionalpreflight only, primary1x2,4workers,one timedrequest+3primes perarm:
ZREF/OFF/ON and Aold/fresh/OFF/ON for eachSorted/Windowed =11processes44SDKcalls,
11fresh164-byteexports. Fornew observers requirecompleteorderedboundedphase
recordsforeachprime+timedcall; phaseintervalsnestedinroot,passcountsconserved.
Verify every fresh export with existingindependentGnark and fixedpublic/image/VK
bindings,disjoint fromcanonicalledger. Preflight times are NOTperformance evidence.
No build/helper/hash/analysis overlaps liveSDKcapture; poll only the livehandle.
Any failedpreflight stops beforetiming; preserve successfulcallsandexports,repair
only missingwork without replaying successfulpreflights unchanged.

Later freeze a separate fixed32/96C7a matrix with retained/fresh/OFF/ON calibration
and observeroverhead comparisons; no targetmatrix or overheadgate chosen from
preflight timings. NewAeglos nativebuild is not byte-identicaloldreference. Neither
unit/native passes nor source-equivalence prove calibration. AWSauth is checked
onlywhenlaunchprerequisitesready. No newpool,table,keyplan or artificialRAMcap.
