use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::PathBuf};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176";
const RUSTC: &str = "/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
const XTASK: &str = "/home/ubuntu/src/zopro-perf-work/sdk-link-flags176/tool-target/release/xtask";
const DEPS: &str = "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps";
const NUM: &str = "/home/ubuntu/src/zopro-perf-work/word-export176/target-candidate/release/deps";
fn read(p: impl AsRef<std::path::Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn write(p: impl AsRef<std::path::Path>, x: &Value) {
    fs::write(p, serde_json::to_vec_pretty(x).unwrap()).unwrap();
}
fn hash(p: impl AsRef<std::path::Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn validate(p: &str) -> usize {
    let v = read(p);
    for (path, h) in v.as_object().unwrap() {
        assert_eq!(hash(path), h.as_str().unwrap(), "{path}");
    }
    v.as_object().unwrap().len()
}
fn main() {
    let mode = std::env::args().nth(1).unwrap();
    let r = PathBuf::from(ROOT);
    match mode.as_str() {
        "prepare" => {
            let mut pins = BTreeMap::new();
            for path in [r.join("model.rs"),r.join("manage.rs"),r.join("manage"),r.join("design.md"),PathBuf::from(RUSTC),PathBuf::from(XTASK),
   PathBuf::from(format!("{DEPS}/libserde_json-cdebb9338c2784ad.rlib")),PathBuf::from(format!("{DEPS}/libsha2-16b8f2c03bdf5faa.rlib")),
   PathBuf::from(format!("{NUM}/libnum_bigint-c7c8e458843263c8.rlib")),
   PathBuf::from("/home/ubuntu/src/zk-tools/zopro/crates/zopro-bn254/src/lib.rs"),
   PathBuf::from("/home/ubuntu/src/zk-tools/zopro/crates/zopro-bn254/src/fp.rs"),
   PathBuf::from("/home/ubuntu/src/zk-tools/zopro/crates/zopro-bn254/src/ifma8.rs"),
   PathBuf::from("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-23-pairwise-radix51-component/README.md"),
   PathBuf::from("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json")]{
    pins.insert(path.to_str().unwrap().to_owned(),hash(&path));
  }
            write(r.join("build-pins.json"), &json!(pins));
            let argv = vec![
                RUSTC.to_owned(),
                "--edition=2021".into(),
                "-O".into(),
                r.join("model.rs").display().to_string(),
                "-o".into(),
                r.join("model").display().to_string(),
                "-L".into(),
                format!("dependency={DEPS}"),
                "-L".into(),
                format!("dependency={NUM}"),
                "--extern".into(),
                format!("num_bigint={NUM}/libnum_bigint-c7c8e458843263c8.rlib"),
                "--extern".into(),
                format!("serde_json={DEPS}/libserde_json-cdebb9338c2784ad.rlib"),
                "--extern".into(),
                format!("sha2={DEPS}/libsha2-16b8f2c03bdf5faa.rlib"),
            ];
            write(
                r.join("build-plan.json"),
                &json!({"version":1,"source_pins":r.join("build-pins.json"),"environment":{},"steps":[
   {"kind":"command","name":"build-exact-model","argv":argv,"timeout_seconds":120},
   {"kind":"command","name":"prepare-public-fixture","argv":[r.join("model"),"fixture",ROOT],"timeout_seconds":120}]}),
            );
            println!("prepared {} build pins", pins.len());
        }
        "freeze" => {
            validate(&format!("{ROOT}/build-pins.json"));
            assert_eq!(read(r.join("build/result.json"))["status"], "complete");
            let input = read(r.join("inputs.json"));
            let mut counts = Vec::new();
            let mut total = 0;
            for f in input["fields"].as_array().unwrap() {
                let n = f["boundary"].as_array().unwrap().len();
                assert_eq!(f["random"].as_array().unwrap().len(), 4096);
                let reductions = 3 * (n * n + 4096 + 1024);
                total += 2 * reductions;
                counts.push(json!({"field":f["tag"],"boundary_values":n,"boundary_tuples":n*n,"random_tuples":4096,"chain_tuples":1024,"per_radix_reductions":reductions}));
            }
            let protocol = json!({"version":1,"algorithm":"signed differences plus shared diagonal convolution, unchanged radix52 and Montgomery R256/R260",
   "populations":counts,"total_reductions":total,"total_cancellation_rows":5*total,
   "full_limb_convolutions":2*(225+2048),"modes":["ordinary","sum2","difference2 via positive 2p complement"],
   "radices":[256,260],"checks":["signed64 accumulator ranges at each modeled operation","full polynomial equals independent product",
    "exact quotient and divisibility each cancellation row","independent extended Euclid Montgomery quotient","independent modular-power field semantics",
    "ordinary REDC<2p/fused<3p","one subtract2p restores lazy closure","canonical normalization final carry zero","exact IFMA recipe totals"],
   "stage_bounds_strict_B_units":[32,64,1026,1026],"no_clock":true,
   "scope":"mathematical model only; no native ISA, ABI, test-suite, full caller, proof, memory peak or performance qualification",
   "decision":"a pass permits one fixed native implementation and primitive correctness/codegen assessment; any speed claim requires separately frozen matched caller and full-proof trials",
   "no_sweeps":true,"no_rerun_successful_stages":true});
            write(r.join("protocol.json"), &protocol);
            let mut pins = read(r.join("build-pins.json")).as_object().unwrap().clone();
            for file in [
                "model",
                "inputs.json",
                "protocol.json",
                "build-plan.json",
                "build/result.json",
            ] {
                let path = r.join(file);
                pins.insert(path.display().to_string(), json!(hash(&path)));
            }
            write(r.join("run-pins.json"), &json!(pins));
            write(
                r.join("run-plan.json"),
                &json!({"version":1,"source_pins":r.join("run-pins.json"),"environment":{},"steps":[
   {"kind":"command","name":"exact-signed-pair52-model","argv":[r.join("model"),"run",ROOT],"timeout_seconds":600}]}),
            );
            println!(
                "frozen {} run pins; {} reductions / {} exact rows",
                pins.len(),
                total,
                5 * total
            );
        }
        _ => panic!("unknown stage"),
    }
}
