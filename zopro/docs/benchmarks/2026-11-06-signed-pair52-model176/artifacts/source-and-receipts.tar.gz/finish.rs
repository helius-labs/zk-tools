use num_bigint::BigUint;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/signed-pair52-model176";
const REPO: &str = "/home/ubuntu/src/zk-tools";
const DEST: &str = "zopro/docs/benchmarks/2026-11-06-signed-pair52-model176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn write(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let root = PathBuf::from(ROOT);
    let dest = Path::new(REPO).join(DEST);
    assert!(
        !root.join("review.json").exists(),
        "review already complete"
    );
    let pins = read(root.join("run-pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap(), "pin {p}");
    }
    assert_eq!(pins.as_object().unwrap().len(), 19);
    let proto = read(root.join("protocol.json"));
    let result = read(root.join("result.json"));
    let input = read(root.join("inputs.json"));
    assert_eq!(result["status"], "pass");
    assert_eq!(result["input_sha256"], hash(root.join("inputs.json")));
    let mut receipt_count = 0;
    for (dir, plan) in [("build", "build-plan.json"), ("run", "run-plan.json")] {
        let workflow = read(root.join(dir).join("result.json"));
        assert_eq!(workflow["status"], "complete");
        let mut plan = read(root.join(plan));
        for step in plan["steps"].as_array_mut().unwrap() {
            step["environment"] = json!({});
            step["required_tests"] = json!([]);
            step["unfiltered"] = json!(false);
        }
        assert_eq!(plan, read(root.join(dir).join("protocol.json")));
        assert_eq!(
            plan["steps"].as_array().unwrap().len(),
            workflow["steps"].as_array().unwrap().len()
        );
        assert!(!root.join(dir).join("attempt-1.json").exists());
        for step in plan["steps"].as_array().unwrap() {
            let name = step["name"].as_str().unwrap();
            let d = root.join(dir).join(name);
            let exit = read(d.join("exit.json"));
            assert_eq!(exit["success"], true);
            assert_eq!(exit["returncode"], 0);
            assert_eq!(exit["stdout_sha256"], hash(d.join("stdout.log")));
            assert_eq!(exit["stderr_sha256"], hash(d.join("stderr.log")));
            assert_eq!(fs::read(d.join("stderr.log")).unwrap().len(), 0);
            let argv = read(d.join("command.json"))["argv"]
                .as_array()
                .unwrap()
                .clone();
            assert_eq!(argv[0], "timeout");
            assert_eq!(argv[1], "-k");
            assert_eq!(argv[2], "5s");
            assert_eq!(argv[4..], step["argv"].as_array().unwrap()[..]);
            receipt_count += 1;
        }
    }
    assert_eq!(receipt_count, 3);
    let stdout = fs::read_to_string(root.join("run/exact-signed-pair52-model/stdout.log")).unwrap();
    assert_eq!(
        serde_json::from_str::<Value>(stdout.strip_prefix("SIGNED_PAIR52_MODEL ").unwrap().trim())
            .unwrap(),
        result
    );
    let manifest=read(Path::new(REPO).join("zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let mut source_count = 0;
    for (name, h) in manifest["source_files_sha256"].as_object().unwrap() {
        assert_eq!(
            hash(Path::new(REPO).join("zopro").join(name)),
            h.as_str().unwrap(),
            "accepted source {name}"
        );
        source_count += 1;
    }
    assert_eq!(source_count, 176);
    let lib =
        fs::read_to_string(Path::new(REPO).join("zopro/crates/zopro-bn254/src/lib.rs")).unwrap();
    let b = 1u128 << 52;
    assert!(32 * b < 64 * b && 64 * b < 1026 * b && 1026 * b < (1u128 << 63));
    assert!(32 * b + 10 * b + b + 44 < 44 * b);
    assert!(16 * 64 * b + b + 1024 < 1026 * b);
    assert!(1025 * b + 2050 < 1026 * b);
    let mut expected = 0u64;
    let mut range_rows = Vec::new();
    for f in input["fields"].as_array().unwrap() {
        let n = f["boundary"].as_array().unwrap().len();
        assert_eq!(n, 122);
        assert_eq!(f["random"].as_array().unwrap().len(), 4096);
        let pstr = f["p_decimal"].as_str().unwrap();
        assert!(lib.contains(pstr));
        let p = BigUint::parse_bytes(pstr.as_bytes(), 10).unwrap();
        let r = BigUint::from(1u64) << 256usize;
        assert!(&p * BigUint::from(4u64) < r);
        assert!(&p * BigUint::from(3u64) < r);
        let want = 3 * (n * n + 4096 + 1024) as u64;
        expected += 2 * want;
        for bits in [256, 260] {
            let rows: Vec<_> = result["field_results"]
                .as_array()
                .unwrap()
                .iter()
                .filter(|x| x["field"] == f["tag"] && x["radix_bits"] == bits)
                .collect();
            assert_eq!(rows.len(), 1);
            let x = rows[0];
            let c = &x["result"];
            assert_eq!(x["boundary_values"], n);
            assert_eq!(x["boundary_tuples"], n * n);
            assert_eq!(c["checks"], want);
            assert_eq!(c["convolutions"], want);
            assert_eq!(c["cancellation_rows"], 5 * want);
            assert_eq!(c["input_ifma_proxy"], 50 * want);
            assert_eq!(c["reduction_ifma_proxy"], 50 * want);
            assert_eq!(c["two_p_input_occurrences"], 4 * n);
            assert!(c["negative_pair_products"].as_u64().unwrap() > 600000);
            assert!(c["noncanonical_input_occurrences"].as_u64().unwrap() > 30000);
            for (idx, bound) in [32 * b, 64 * b, 1026 * b, 1026 * b].into_iter().enumerate() {
                let max = c["max_abs_by_phase"][idx].as_u64().unwrap() as u128;
                assert!(max < bound);
                assert_eq!(
                    c["phase_bounds_strict"][idx].as_u64().unwrap() as u128,
                    bound
                );
            }
            range_rows.push(json!({"field":f["tag"],"bits":bits,"reductions":want,"max_abs_by_phase":c["max_abs_by_phase"]}));
        }
    }
    assert_eq!(expected, 240048);
    assert_eq!(proto["total_reductions"], expected);
    assert_eq!(result["total_reductions"], expected);
    assert_eq!(result["total_cancellation_rows"], 5 * expected);
    assert_eq!(result["full_limb_convolution"]["convolutions"], 4546);
    assert_eq!(result["full_limb_convolution"]["input_ifma_proxy"], 204570);
    assert_eq!(input["corners"].as_array().unwrap().len(), 15);
    assert_eq!(input["full_random"].as_array().unwrap().len(), 2048);
    let review = json!({"status":"pass","run_pins_verified":19,"unchanged_accepted_source_files":176,"successful_command_receipts":receipt_count,
  "attempts_per_workflow":1,"independent_receipt_and_ledger_reconstruction":true,
  "reviewer_source_sha256":hash(root.join("finish.rs")),"reviewer_binary_sha256":hash(root.join("finish")),
  "total_reductions":expected,"total_rows":expected*5,"full_limb_convolutions":4546,"ranges":range_rows,
  "analytical_bounds":"bounds.md reviewed separately; explicit inequalities hold, observed maxima are not a proof",
  "native_implementation_qualified":false,"proofs_added":0,"timing_claim":false,
        "decision":"select one fixed native primitive implementation and correctness/codegen screen; no adoption",
        "review_repair":"initial helper expected unnormalized protocol; repaired only serde default normalization, no model or build rerun",
        "initial_review_source_sha256":hash(root.join("review-initial/finish.rs")),
        "initial_review_binary_sha256":hash(root.join("review-initial/finish"))});
    write(root.join("review.json"), &review);
    fs::create_dir_all(dest.join("artifacts")).unwrap();
    for (src, name) in [
        ("result.json", "model-result.json"),
        ("review.json", "review.json"),
        ("protocol.json", "protocol.json"),
        ("run-pins.json", "source-pins.json"),
        ("bounds.md", "bounds.md"),
    ] {
        fs::copy(root.join(src), dest.join("artifacts").join(name)).unwrap();
    }
    let mut members = vec![
        "design.md",
        "bounds.md",
        "model.rs",
        "manage.rs",
        "finish.rs",
        "inputs.json",
        "build-plan.json",
        "build-pins.json",
        "run-plan.json",
        "run-pins.json",
        "protocol.json",
        "result.json",
        "review.json",
        "review-initial/finish.rs",
        "review-initial/failure.json",
    ];
    for dir in ["build", "run"] {
        for file in [
            "result.json",
            "protocol.json",
            "source-pins.json",
            "attempt-0.json",
            "completed.json",
            "progress.json",
        ] {
            let s = format!("{dir}/{file}");
            members.push(Box::leak(s.into_boxed_str()));
        }
    }
    for (dir, step) in [
        ("build", "build-exact-model"),
        ("build", "prepare-public-fixture"),
        ("run", "exact-signed-pair52-model"),
    ] {
        for file in [
            "command.json",
            "exit.json",
            "stdout.log",
            "stderr.log",
            "tests.json",
        ] {
            let s = format!("{dir}/{step}/{file}");
            members.push(Box::leak(s.into_boxed_str()));
        }
    }
    let mut member_hashes = BTreeMap::new();
    for name in &members {
        let bytes = fs::read(root.join(name)).unwrap();
        std::str::from_utf8(&bytes).unwrap();
        member_hashes.insert(name.to_string(), format!("{:x}", Sha256::digest(&bytes)));
    }
    write(
        dest.join("artifacts/archive-members.json"),
        &json!(member_hashes),
    );
    let archive = dest.join("artifacts/source-and-receipts.tar.gz");
    assert!(Command::new("tar")
        .arg("-czf")
        .arg(&archive)
        .arg("-C")
        .arg(&root)
        .arg("--")
        .args(&members)
        .status()
        .unwrap()
        .success());
    let listing = Command::new("tar")
        .arg("-tzf")
        .arg(&archive)
        .output()
        .unwrap();
    assert!(listing.status.success());
    let listed: Vec<_> = String::from_utf8(listing.stdout)
        .unwrap()
        .lines()
        .map(str::to_owned)
        .collect();
    assert_eq!(listed, members);
    let extract = root.join("archive-review");
    fs::create_dir(&extract).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&extract)
        .status()
        .unwrap()
        .success());
    for (name, h) in &member_hashes {
        assert_eq!(&hash(extract.join(name)), h);
    }
    let mut report=String::from("# Signed radix-52 arithmetic model\n\nThe fixed signed-difference multiplication recipe passed its exact arithmetic screen. This selects a native primitive implementation and code-generation check; it does not establish a speedup or change production.\n\nThe model checked **240,048 field reductions and 1,200,240 cancellation rows**: Fq and Fr, R256 and R260, ordinary products, fused sums, and differences implemented through the nonnegative `2p-c` complement. Each field/radix had 122 boundary values (14,884 ordered tuples), 4,096 deterministic full-width random tuples, and 1,024 changing-chain tuples, with three operations per tuple. Another 4,546 convolutions covered arbitrary full-width 52-bit limbs. Every modeled cancellation state matched independent integer division, the final Montgomery quotient matched an extended-Euclid reference, and the canonical result matched modular arithmetic using an independently computed radix inverse. No unreduced host field objects were constructed.\n\nThe signed difference identity preserves the existing radix and Montgomery factors. A shared diagonal convolution reduces repeated additions. This differs from the earlier rejected radix-51 pair-sum implementation; that result remains unchanged. The mathematical bounds and limitations are in [bounds.md](artifacts/bounds.md). Signed intermediate coefficients require arithmetic carry shifts in a native implementation. All modeled accumulators satisfied the declared signed-64-bit bounds. Finite checks supplement the bounds and do not qualify native SIMD code.\n\nThe source recipe uses **80 versus 100 IFMAs for an ordinary product**, and **110 versus 150 for a fused product**. It also requires 83/153 difference/diagonal vector or mask operations before common reduction and normalization costs. These are partial source-operation counts, not optimized instruction counts or a latency estimate. Additional arithmetic, coefficient dependencies, register pressure and spills may outweigh the saved IFMAs. No lookup table, key copy or retained execution plan is proposed. Actual native stack and runtime memory remain unmeasured.\n\nThe Rust model build, public-fixture preparation and model execution each succeeded on the first attempt through xtask. A separate receipt/ledger review verified 19 run pins, all three command receipts and unchanged production source identities (176 files). It did not rerun the model. The archive contains the exact public fixtures, source and receipts; no executable, library, key, witness or proof blobs are included.\n\nThe pairwise-product motivation is discussed in the authors' [June 2026 preliminary matrix-arithmetic paper, §3.5](https://www.texmacs.org/joris/amx/amx.html). Its matrix results do not imply a BN254 field or prover speedup. The [previous radix-51 experiment](../2026-10-23-pairwise-radix51-component/README.md) remains closed.\n\n## Accepted full-proof baseline (inherited)\n\nNo new full proof, AWS comparison, Aeglos comparison, RSS peak or minimum-RAM result was produced in this stage. The accepted local 32-worker build remains unchanged. M5 CPU and Metal timings are supplied reference values on different hardware; these ratios do not establish equal hardware efficiency. The goal remains unmet on all eight shapes.\n\n| Shape | Local CPU ms | M5 CPU ms | M5 Metal ms | CPU speedup | vs Metal | 10× CPU limit ms |\n|---|---:|---:|---:|---:|---:|---:|\n");
    let names = [
        "1×2", "2×2", "4×2", "8×2", "12×2", "16×2", "24×2", "merge24",
    ];
    let ms = [
        7.928660, 11.151932, 16.086386, 24.179453, 33.884455, 40.077381, 65.850777, 65.060937,
    ];
    let cpu = [37., 59., 109., 189., 284., 335., 528., 507.];
    let metal = [24., 30., 48., 74., 101., 124., 176., 175.];
    for j in 0..8 {
        report.push_str(&format!(
            "| {} | {:.6} | {:.0} | {:.0} | {:.2}× | {:.2}× | {:.1} |\n",
            names[j],
            ms[j],
            cpu[j],
            metal[j],
            cpu[j] / ms[j],
            metal[j] / ms[j],
            cpu[j] / 10.
        ));
    }
    report.push_str("\nAdditional merge54 regression baseline: 161.883899 ms; no supplied M5 reference. The inherited accepted RSS is 132.75 MiB, not a new peak or a minimum-RAM measurement. Accepted SDK SHA-256: `6d83f1d6fda6f16576cb351b81789e8d26a6177cc0f26f169a3dc98448c0e661`; canonical proof ledger remains 30,846.\n\n## Next stage\n\nImplement this one fixed signed-difference recipe in an isolated field snapshot, preserving the accepted fallback and field representation. Qualify its actual SIMD outputs against independent field arithmetic, then inspect the final optimized primitive for IFMA counts, signed carries and stack traffic. Only a credible native result selects separately frozen matched caller and full-proof measurements. No width/layout/attribute sweep, favorable subset, old experiment rerun or production adoption is selected here.\n\nRaw [model output](artifacts/model-result.json), [protocol](artifacts/protocol.json), [review](artifacts/review.json), [source pins](artifacts/source-pins.json) and [source/receipts archive](artifacts/source-and-receipts.tar.gz) are preserved. The full-limb convolution population checks exact products but does not maintain a separate output digest; its displayed digest is the empty-stream SHA-256.\n");
    report.push_str("\nThe first receipt-review helper stopped because it compared the input plan with xtask's normalized protocol, which inserts default command fields. Only the reviewer was repaired to account for those defaults; the successful model, build and fixture stages were not rerun. The original helper source and observed-failure summary are retained in the archive, with its binary identity in the review.\n");
    fs::write(dest.join("README.md"), report).unwrap();
    let mut checksums = BTreeMap::new();
    for name in [
        "README.md",
        "artifacts/model-result.json",
        "artifacts/review.json",
        "artifacts/protocol.json",
        "artifacts/source-pins.json",
        "artifacts/bounds.md",
        "artifacts/archive-members.json",
        "artifacts/source-and-receipts.tar.gz",
    ] {
        checksums.insert(name, hash(dest.join(name)));
    }
    write(dest.join("checksums.json"), &json!(checksums));
    for (name, h) in &checksums {
        assert_eq!(&hash(dest.join(name)), h);
    }
    write(
        root.join("publication.json"),
        &json!({"status":"pass","files":checksums.len()+1,"utf8_archive_members":members.len(),"roundtrip_hashes":member_hashes.len(),"report":dest.join("README.md"),"archive_sha256":hash(archive)}),
    );
    println!(
        "review/publication PASS: {expected} reductions, {} receipts, {} UTF8 archive members",
        receipt_count,
        members.len()
    );
}
