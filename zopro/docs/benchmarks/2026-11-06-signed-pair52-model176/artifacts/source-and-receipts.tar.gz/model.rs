//! Exact mathematical screen, not a native SIMD implementation or benchmark.
use num_bigint::{BigInt, BigUint};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeSet, fs, path::Path};

const B: i128 = 1i128 << 52;
const MASK: u64 = (1u64 << 52) - 1;
const PRIMES: [&str; 2] = [
    "21888242871839275222246405745257275088696311157297823662689037894645226208583",
    "21888242871839275222246405745257275088548364400416034343698204186575808495617",
];
type Limbs = [u64; 5];

fn u(x: u64) -> BigUint {
    BigUint::from(x)
}
fn i(x: &BigUint) -> BigInt {
    BigInt::from(x.clone())
}
fn hex(x: &BigUint) -> String {
    x.to_str_radix(16)
}
fn parse(s: &str) -> BigUint {
    BigUint::parse_bytes(s.as_bytes(), 16).unwrap()
}
fn hash(b: &[u8]) -> String {
    format!("{:x}", Sha256::digest(b))
}
fn words(x: &BigUint) -> Limbs {
    let mut n = x.clone();
    std::array::from_fn(|_| {
        let z = (&n & u(MASK)).to_u64_digits().first().copied().unwrap_or(0);
        n >>= 52usize;
        z
    })
}
fn value(x: &Limbs) -> BigUint {
    x.iter().rev().fold(u(0), |s, &v| (s << 52usize) + u(v))
}
fn polynomial(x: &[i128]) -> BigInt {
    x.iter()
        .rev()
        .fold(BigInt::from(0), |s, &v| (s << 52usize) + BigInt::from(v))
}
fn rand64(state: &mut u64) -> u64 {
    *state = state.wrapping_add(0x9e3779b97f4a7c15);
    let mut z = *state;
    z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
    z ^ (z >> 31)
}
fn random_big(state: &mut u64) -> BigUint {
    (0..4).fold(u(0), |n, _| (n << 64usize) + u(rand64(state)))
}

pub fn fixture() -> Value {
    let mut fields = Vec::new();
    for (tag, decimal) in ["Fq", "Fr"].into_iter().zip(PRIMES) {
        let p = BigUint::parse_bytes(decimal.as_bytes(), 10).unwrap();
        let two = &p * u(2);
        let mut boundary = BTreeSet::from([
            u(0),
            u(1),
            u(2),
            &p - u(1),
            p.clone(),
            &p + u(1),
            &two - u(2),
            &two - u(1),
            two.clone(),
        ]);
        // Public carry/word/radix boundaries, and their complements around p.
        for bit in [
            1usize, 2, 26, 48, 51, 52, 53, 64, 104, 128, 156, 192, 208, 254, 255, 256,
        ] {
            let x = u(1) << bit;
            for v in [&x - u(1), x.clone(), &x + u(1)] {
                if v <= two {
                    boundary.insert(v.clone());
                }
                if v <= p {
                    boundary.insert(&p - &v);
                    boundary.insert(&p + &v);
                }
            }
        }
        let boundary: Vec<_> = boundary.into_iter().map(|x| hex(&x)).collect();
        let mut state = 0x73ee_7a19_529b_e42du64;
        let random: Vec<Value> = (0..4096)
            .map(|_| {
                let tuple: Vec<String> = (0..4)
                    .map(|_| hex(&(random_big(&mut state) % (&two + u(1)))))
                    .collect();
                json!(tuple)
            })
            .collect();
        fields.push(json!({"tag":tag,"p_decimal":decimal,"boundary":boundary,"random":random}));
    }
    let mut corners = BTreeSet::from([
        [0; 5],
        [MASK; 5],
        [1; 5],
        [MASK, 0, MASK, 0, MASK],
        [0, MASK, 0, MASK, 0],
    ]);
    for j in 0..5 {
        let mut x = [0; 5];
        x[j] = MASK;
        corners.insert(x);
        let mut x = [MASK; 5];
        x[j] = 0;
        corners.insert(x);
    }
    let mut state = 0x107a_52f3_ae98_634du64;
    let full_random: Vec<[[u64; 5]; 4]> = (0..2048)
        .map(|_| std::array::from_fn(|_| std::array::from_fn(|_| rand64(&mut state) & MASK)))
        .collect();
    json!({"version":1,"fields":fields,"corners":corners,"full_random":full_random,
        "radices":[256,260],"chain_steps":1024,"boundary_tuples":"all ordered (a,b); c=boundary[(ia+3)%n], d=boundary[(ib+7)%n]",
        "seed_policy":"fixed SplitMix64, full 256-bit values reduced into the inclusive [0,2p] interval"})
}

#[derive(Default)]
struct Counts {
    checks: u64,
    rows: u64,
    convolution: u64,
    negative_pairs: u64,
    zero_differences: u64,
    noncanonical_inputs: u64,
    endpoint_inputs: u64,
    max_abs: [i128; 4],
    input_ifma: u64,
    reduction_ifma: u64,
    digest: Sha256,
}
impl Counts {
    fn bound(&mut self, v: i128, phase: usize) {
        assert!(
            v >= i64::MIN as i128 && v <= i64::MAX as i128,
            "signed lane overflow: {v}"
        );
        let declared = [32 * B, 64 * B, 1026 * B, 1026 * B][phase];
        assert!(v.abs() < declared, "phase {phase} bound violated: {v}");
        self.max_abs[phase] = self.max_abs[phase].max(v.abs());
    }
    fn absorb(&mut self, n: &BigUint) {
        let b = n.to_bytes_le();
        self.digest.update((b.len() as u64).to_le_bytes());
        self.digest.update(b);
    }
    fn report(&self) -> Value {
        json!({"checks":self.checks,"cancellation_rows":self.rows,"convolutions":self.convolution,
            "negative_pair_products":self.negative_pairs,"zero_difference_pairs":self.zero_differences,
            "noncanonical_input_occurrences":self.noncanonical_inputs,"two_p_input_occurrences":self.endpoint_inputs,
            "max_abs_by_phase":self.max_abs,"phase_bounds_strict":[32*B,64*B,1026*B,1026*B],
            "input_ifma_proxy":self.input_ifma,"reduction_ifma_proxy":self.reduction_ifma,
            "output_digest":format!("{:x}",self.digest.clone().finalize())})
    }
}
fn acc(t: &mut [i128], k: usize, v: i128, c: &mut Counts, phase: usize) {
    t[k] += v;
    c.bound(t[k], phase);
}
fn split_product(a: u64, b: u64) -> (i128, i128) {
    assert!(a <= MASK && b <= MASK);
    let p = a as u128 * b as u128;
    ((p & MASK as u128) as i128, (p >> 52) as i128)
}
// Five diagonal products and ten oriented signed difference products.
fn convolution(products: &[(Limbs, Limbs)], c: &mut Counts) -> [i128; 10] {
    assert!((1..=2).contains(&products.len()));
    let mut lo = [0i128; 5];
    let mut hi = [0i128; 5];
    for (a, b) in products {
        for j in 0..5 {
            let (l, h) = split_product(a[j], b[j]);
            acc(&mut lo, j, l, c, 0);
            acc(&mut hi, j, h, c, 0);
            c.input_ifma += 2;
        }
    }
    let mut e = [0i128; 6];
    e[0] = lo[0];
    e[5] = hi[4];
    for j in 1..5 {
        e[j] = lo[j] + hi[j - 1];
        c.bound(e[j], 0);
    }
    let mut t = [0i128; 10];
    t[0] = e[0];
    for j in 1..5 {
        t[j] = t[j - 1] + e[j];
        c.bound(t[j], 0);
    }
    t[5] = t[4] + e[5];
    c.bound(t[5], 0);
    t[5] -= e[0];
    c.bound(t[5], 0);
    for j in 6..9 {
        t[j] = t[j - 1] - e[j - 5];
        c.bound(t[j], 0);
    }
    t[9] = e[5];
    for (a, b) in products {
        for j in 0..5 {
            for k in j + 1..5 {
                let dx = a[j] as i128 - a[k] as i128;
                let dy = b[k] as i128 - b[j] as i128;
                let x = dx.abs() as u64;
                let y = if dx < 0 { -dy } else { dy };
                assert!(x <= MASK && y.abs() < B);
                c.negative_pairs += (y < 0) as u64;
                c.zero_differences += (x == 0 || y == 0) as u64;
                let (l, h) = split_product(x, (y as u64) & MASK);
                acc(&mut t, j + k, l, c, 0);
                acc(&mut t, j + k + 1, h, c, 0);
                if y < 0 {
                    acc(&mut t, j + k + 1, -(x as i128), c, 0);
                }
                c.input_ifma += 2;
            }
        }
    }
    let expected: BigUint = products.iter().map(|(a, b)| value(a) * value(b)).sum();
    assert_eq!(polynomial(&t), i(&expected), "full signed convolution");
    c.convolution += 1;
    t
}

// Independent extended Euclid. Neither this quotient reference nor modpow
// uses the signed-coefficient reduction recurrence.
fn inverse(a: &BigInt, modulus: &BigInt) -> BigInt {
    let (mut old_r, mut r) = (modulus.clone(), a.clone());
    let (mut old_s, mut s) = (BigInt::from(0), BigInt::from(1));
    while r != BigInt::from(0) {
        let q = &old_r / &r;
        (old_r, r) = (r.clone(), old_r - &q * &r);
        (old_s, s) = (s.clone(), old_s - q * &s);
    }
    assert_eq!(old_r, BigInt::from(1));
    ((old_s % modulus) + modulus) % modulus
}
struct Field {
    p: BigUint,
    two: BigUint,
    limbs: Limbs,
    inv64: u64,
    r: BigUint,
    bits: usize,
    minus_p_inv: BigUint,
    r_inv: BigUint,
}
impl Field {
    fn new(p: BigUint, bits: usize) -> Self {
        let r = u(1) << bits;
        assert!(&p * u(4) < r, "lazy closure requires 4p<R");
        assert!(&p * u(3) < (u(1) << 256usize));
        let limbs = words(&p);
        let mut inv = 1u64;
        for _ in 0..6 {
            inv = inv.wrapping_mul(2u64.wrapping_sub(limbs[0].wrapping_mul(inv)));
        }
        let inv64 = inv.wrapping_neg();
        assert_eq!(limbs[0].wrapping_mul(inv64), u64::MAX);
        let p_inv = inverse(&i(&p), &i(&r)).to_biguint().unwrap();
        let minus_p_inv = (&r - p_inv) % &r;
        let r_inv = (&r % &p).modpow(&(&p - u(2)), &p);
        assert_eq!((&r * &r_inv) % &p, u(1));
        Self {
            two: &p * u(2),
            p,
            limbs,
            inv64,
            r,
            bits,
            minus_p_inv,
            r_inv,
        }
    }
    fn reduce(&self, mut t: [i128; 10], full: &BigUint, fused: bool, c: &mut Counts) -> BigUint {
        for row in 0..5 {
            let bits = if self.bits == 256 && row == 4 {
                48usize
            } else {
                52usize
            };
            let radix = u(1) << bits;
            let before = polynomial(&t[row..]);
            let q = (t[row] as u64).wrapping_mul(self.inv64) & ((1u64 << bits) - 1);
            let exact = &before + i(&(u(q) * &self.p));
            assert_eq!(&exact % i(&radix), BigInt::from(0), "row divisibility");
            c.reduction_ifma += 1; // q via madd52lo (then mask in final48).
            let ceil = (t[row] + ((1i128 << bits) - 1)) >> bits;
            c.bound(t[row] + ((1i128 << bits) - 1), 1);
            let q_shift = if bits == 48 { q << 4 } else { q };
            let (_, q_p0_hi) = split_product(q_shift, self.limbs[0]);
            let carry = ceil + q_p0_hi;
            c.bound(carry, 1);
            c.reduction_ifma += 1;
            for j in 1..5 {
                let (lo, hi) = split_product(q, self.limbs[j]);
                acc(&mut t, row + j, lo, c, 1);
                acc(&mut t, row + j + 1, hi, c, 1);
                c.reduction_ifma += 2;
            }
            t[row] = 0;
            if bits == 48 {
                for v in &mut t[row + 1..] {
                    *v *= 16;
                    c.bound(*v, 2);
                }
                acc(&mut t, row + 1, carry, c, 2);
            } else {
                acc(&mut t, row + 1, carry, c, 1);
            }
            assert_eq!(
                polynomial(&t[row + 1..]),
                exact / i(&radix),
                "exact row quotient"
            );
            c.rows += 1;
        }
        let quotient = (full * &self.minus_p_inv) % &self.r;
        let numerator = full + &quotient * &self.p;
        assert_eq!(&numerator % &self.r, u(0));
        let exact = &numerator / &self.r;
        assert_eq!(
            polynomial(&t[5..]),
            i(&exact),
            "independent Montgomery quotient"
        );
        assert!(
            exact < &self.p * u(if fused { 3 } else { 2 }),
            "REDC output bound"
        );
        for j in 5..9 {
            let carry = t[j] >> 52;
            t[j] &= MASK as i128;
            acc(&mut t, j + 1, carry, c, 3);
        }
        assert!(t[9] >= 0 && t[9] < B, "final carry must be zero");
        let normalized: Limbs = std::array::from_fn(|j| t[5 + j] as u64);
        let raw = value(&normalized);
        assert_eq!(raw, exact);
        let lazy = if raw >= self.two {
            raw - &self.two
        } else {
            raw
        };
        assert!(lazy < self.two);
        let canonical = if lazy >= self.p {
            &lazy - &self.p
        } else {
            lazy.clone()
        };
        assert_eq!(
            canonical,
            (full % &self.p) * &self.r_inv % &self.p,
            "independent field semantic"
        );
        c.absorb(&lazy);
        c.checks += 1;
        lazy
    }
    fn test(&self, a: &BigUint, b: &BigUint, x: &BigUint, y: &BigUint, c: &mut Counts) -> BigUint {
        for n in [a, b, x, y] {
            assert!(n <= &self.two);
            c.noncanonical_inputs += (n >= &self.p) as u64;
            c.endpoint_inputs += (n == &self.two) as u64;
        }
        let before = c.input_ifma;
        let mut last = u(0);
        for mode in 0..3 {
            let complement = &self.two - x;
            let second = if mode == 2 { &complement } else { x };
            let mut products = vec![(words(a), words(b))];
            let mut full = a * b;
            if mode > 0 {
                products.push((words(second), words(y)));
                full += second * y;
            }
            let t = convolution(&products, c);
            let lazy = self.reduce(t, &full, mode > 0, c);
            if mode == 2 {
                let modulus = i(&self.p);
                let signed = i(&(a * b)) - i(&(x * y));
                let signed_mod = ((signed % &modulus) + &modulus) % &modulus;
                assert_eq!(
                    &lazy % &self.p,
                    signed_mod.to_biguint().unwrap() * &self.r_inv % &self.p,
                    "difference complement semantic"
                );
            }
            if mode == 0 {
                last = lazy;
            }
        }
        assert_eq!(c.input_ifma - before, 30 + 60 + 60);
        last
    }
}

fn pins(path: &Path) {
    let x: Value = serde_json::from_slice(&fs::read(path).unwrap()).unwrap();
    for (p, h) in x.as_object().unwrap() {
        assert_eq!(hash(&fs::read(p).unwrap()), h.as_str().unwrap(), "pin {p}");
    }
}
fn run(root: &Path) {
    pins(&root.join("run-pins.json"));
    let input_bytes = fs::read(root.join("inputs.json")).unwrap();
    let input: Value = serde_json::from_slice(&input_bytes).unwrap();
    let corners: Vec<Limbs> = serde_json::from_value(input["corners"].clone()).unwrap();
    assert_eq!(corners.len(), 15);
    let mut convolution_counts = Counts::default();
    for (j, a) in corners.iter().enumerate() {
        for (k, b) in corners.iter().enumerate() {
            convolution(&[(*a, *b)], &mut convolution_counts);
            convolution(
                &[(*a, *b), (corners[(j + 3) % 15], corners[(k + 7) % 15])],
                &mut convolution_counts,
            );
        }
    }
    for row in input["full_random"].as_array().unwrap() {
        let [a, b, x, y]: [Limbs; 4] = serde_json::from_value(row.clone()).unwrap();
        convolution(&[(a, b)], &mut convolution_counts);
        convolution(&[(a, b), (x, y)], &mut convolution_counts);
    }
    assert_eq!(convolution_counts.convolution, 2 * (225 + 2048));
    let mut results = Vec::new();
    let mut total = 0u64;
    for field in input["fields"].as_array().unwrap() {
        for bits in [256, 260] {
            let p =
                BigUint::parse_bytes(field["p_decimal"].as_str().unwrap().as_bytes(), 10).unwrap();
            let f = Field::new(p, bits);
            let boundary: Vec<_> = field["boundary"]
                .as_array()
                .unwrap()
                .iter()
                .map(|v| parse(v.as_str().unwrap()))
                .collect();
            let mut c = Counts::default();
            let n = boundary.len();
            for (j, a) in boundary.iter().enumerate() {
                for (k, b) in boundary.iter().enumerate() {
                    f.test(a, b, &boundary[(j + 3) % n], &boundary[(k + 7) % n], &mut c);
                }
            }
            for row in field["random"].as_array().unwrap() {
                let tuple: Vec<_> = row
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|v| parse(v.as_str().unwrap()))
                    .collect();
                f.test(&tuple[0], &tuple[1], &tuple[2], &tuple[3], &mut c);
            }
            let mut chain = &f.p + u(1);
            let random = field["random"].as_array().unwrap();
            for j in 0..1024 {
                let row = &random[j];
                let tuple: Vec<_> = row
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|v| parse(v.as_str().unwrap()))
                    .collect();
                chain = f.test(&chain, &tuple[1], &tuple[2], &tuple[3], &mut c);
            }
            let tuples = (n * n + 4096 + 1024) as u64;
            assert_eq!(c.checks, tuples * 3);
            assert_eq!(c.rows, c.checks * 5);
            assert_eq!(c.input_ifma, tuples * 150);
            assert_eq!(c.reduction_ifma, tuples * 150);
            assert_eq!(c.convolution, c.checks);
            total += c.checks;
            results.push(json!({"field":field["tag"],"radix_bits":bits,"boundary_values":n,
                "boundary_tuples":n*n,"random_tuples":4096,"chain_tuples":1024,"result":c.report()}));
        }
    }
    pins(&root.join("run-pins.json"));
    let out = json!({"version":1,"status":"pass","kind":"exact signed coefficient model, not native code or timing",
        "input_sha256":hash(&input_bytes),"full_limb_convolution":convolution_counts.report(),"field_results":results,
        "total_reductions":total,"total_cancellation_rows":total*5,
        "proxy":{"ordinary_ifma":80,"fused_ifma":110,"accepted_ordinary_ifma":100,"accepted_fused_ifma":150,
            "ordinary_difference_recipe_ops":83,"fused_difference_recipe_ops":153,
            "excluded":"common normalization/reduction/masks, moves, scheduling, spills, code size; no native latency bound"},
        "scope":"Fq/Fr, R256/R260; ordinary, sum2, complement difference2; inclusive lazy endpoints; no Fp objects"});
    fs::write(
        root.join("result.json"),
        serde_json::to_vec_pretty(&out).unwrap(),
    )
    .unwrap();
    println!(
        "SIGNED_PAIR52_MODEL {}",
        serde_json::to_string(&out).unwrap()
    );
}
fn main() {
    let a: Vec<_> = std::env::args().collect();
    assert_eq!(a.len(), 3);
    let root = Path::new(&a[2]);
    match a[1].as_str() {
        "fixture" => {
            fs::write(
                root.join("inputs.json"),
                serde_json::to_vec_pretty(&fixture()).unwrap(),
            )
            .unwrap();
        }
        "run" => run(root),
        _ => panic!("unknown mode"),
    }
}
