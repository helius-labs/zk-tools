//! Private dispatch by the already grouped effective G2 population.
use super::*;
use std::sync::atomic::{AtomicUsize,Ordering};
static ELIGIBLE:AtomicUsize=AtomicUsize::new(0);
static ENTERED:AtomicUsize=AtomicUsize::new(0);
static DENIED:AtomicUsize=AtomicUsize::new(0);
static ORIGINAL:AtomicUsize=AtomicUsize::new(0);
static GROUPED:AtomicUsize=AtomicUsize::new(0);
static COST:AtomicUsize=AtomicUsize::new(0);
pub(crate) fn snapshot()->[usize;6]{[ELIGIBLE.load(Ordering::Relaxed),ENTERED.load(Ordering::Relaxed),DENIED.load(Ordering::Relaxed),ORIGINAL.load(Ordering::Relaxed),GROUPED.load(Ordering::Relaxed),COST.load(Ordering::Relaxed)]}
pub(super) fn try_grouped(bases:&[G2Affine],groups:&ScalarGroups,allow:bool)->Option<G2Projective>{
 assert_eq!(bases.len(),groups.len);
 if !allow || bases.len()<MAX_QUERY || !(MIN_QUERY..MAX_QUERY).contains(&groups.values.len())
    || !crate::msm::BatchAdd::<G2Config>::default().borrowed_g2_enabled(){return None;}
 let cost=super::super::workspace::postgroup_g2(bases.len(),groups.values.len(),rayon::current_num_threads())?;
 ELIGIBLE.fetch_add(1,Ordering::Relaxed);
 let Some(_reservation)=crate::preparation::Reservation::analysis(Some(cost))else{DENIED.fetch_add(1,Ordering::Relaxed);return None;};
 ENTERED.fetch_add(1,Ordering::Relaxed);ORIGINAL.store(bases.len(),Ordering::Relaxed);GROUPED.store(groups.values.len(),Ordering::Relaxed);COST.store(cost,Ordering::Relaxed);
 let points=crate::msm::group_affine(bases,&groups.order,&groups.starts,&groups.counts);
 let mut words=groups.values.clone();
 Some(super::super::g2_phi::raw_exclusive(&points,&mut words))
}
#[cfg(test)]mod tests{
 use super::*;use zopro_bn254::Fr;
 fn fixture(n:usize,zero:bool)->(Vec<G2Affine>,Vec<[u64;4]>,Fr){
  let coefficients=[0i64,1,-1,2,3,-2,5,1];let table=coefficients.map(|c|{let p=G2Affine::GENERATOR*Fr::from(c.unsigned_abs());(if c<0{-p}else{p}).to_affine()});
  let stride=if zero{16}else{(n/1024).max(1)};let scale=Fr::from(2u64).pow(&[251])+Fr::from(713u64);
  let scalars=(0..n).map(|i|{let g=i/stride;if zero&&g%3==0{Fr::ZERO}else{scale*Fr::from((g+1)as u64)}}).collect::<Vec<_>>();
  let expected=scalars.iter().enumerate().fold(Fr::ZERO,|a,(i,s)|{let c=coefficients[(i*37+i/11)%8];a+*s*if c<0{-Fr::from(c.unsigned_abs())}else{Fr::from(c as u64)}});
  let bases=(0..n).map(|i|table[(i*37+i/11)%8]).collect();(bases,scalars.iter().map(Fr::to_canonical).collect(),expected)
 }
 #[test]fn large_original_small_effective_queries_match_generator_sum(){
  for workers in[1,4]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();for n in[65536,65537,131137]{for zero in[false,true]{let(bases,words,expected)=fixture(n,zero);let original=bases.clone();pool.install(||{let g=super::super::super::scalar_groups(&words).expect("grouping must admit fixed fixture");assert!((1024..65536).contains(&g.values.len()));let old=g.values.clone();let out=try_grouped(&bases,&g,true).unwrap();assert_eq!(out.to_affine(),(G2Affine::GENERATOR*expected).to_affine());assert_eq!(g.values,old);assert_eq!(bases,original);});}}}
 }
 #[test]fn bounds_overflow_and_denial_preserve_grouped_inputs(){
  let cost=super::super::super::workspace::postgroup_g2;
  for(n,u,w)in[(65535,1024,1),(65536,1023,4),(65536,65536,4),(65536,1024,0),(65536,1024,usize::MAX),(u32::MAX as usize,1024,4)]{assert!(cost(n,u,w).is_none());}
  assert!(cost(65536,1024,1).is_some());assert!(cost(1048576,65535,32).unwrap()>cost(65536,1024,1).unwrap());
  let(bases,words,_)=fixture(65536,false);let groups=super::super::super::scalar_groups(&words).unwrap();let values=groups.values.clone();let order=groups.order.clone();assert!(try_grouped(&bases,&groups,false).is_none());assert_eq!(groups.values,values);assert_eq!(groups.order,order);
 }
 #[test]fn immutable_shared_groups_survive_concurrent_readers(){
  let(bases,words,expected)=fixture(65537,false);let g=super::super::super::scalar_groups(&words).unwrap();let old=g.values.clone();let pool=rayon::ThreadPoolBuilder::new().num_threads(4).stack_size(512*1024).build().unwrap();let(out,sum)=pool.install(||rayon::join(||try_grouped(&bases,&g,true).unwrap(),||g.values.iter().fold(Fr::ZERO,|a,w|a+Fr::from_canonical(*w).unwrap())));assert_eq!(out.to_affine(),(G2Affine::GENERATOR*expected).to_affine());assert_eq!(sum,old.iter().fold(Fr::ZERO,|a,w|a+Fr::from_canonical(*w).unwrap()));assert_eq!(g.values,old);
 }
}
