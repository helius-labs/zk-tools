fn interval(values: &[f64]) -> Value {
    assert_eq!(values.len(), 15);
    let mut a = values.to_vec();
    a.sort_by(f64::total_cmp);
    json!({"median":a[7],"low":a[3],"high":a[11],"wins":values.iter().filter(|v|**v<1.).count(),"ratios":values,"conditional_nominal_coverage":0.96484375})
}
fn finish() {
    assert_eq!(read(r("runs/result.json"))["status"], "complete");
    for (p, h) in read(r("pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let jobs = read(r("jobs.json"));
    let mut prior: BTreeSet<String> =
        serde_json::from_value(read(r("prior-proof-sha256.json"))).unwrap();
    assert_eq!(prior.len(), 27353);
    let mut inventory = Vec::new();
    let mut rows = Vec::new();
    let mut counters = BTreeMap::new();
    let mut profiles = BTreeMap::new();
    let mut symbols_all = BTreeMap::new();
    let mut vk = BTreeMap::new();
    for j in jobs.as_array().unwrap() {
        let n = j["name"].as_str().unwrap();
        let c = &j["case"];
        let rounds = j["rounds"].as_u64().unwrap();
        let panel = j["panel"].as_str().unwrap();
        let log = fs::read_to_string(r(format!("runs/{n}/stdout.log"))).unwrap();
        let samples = log
            .lines()
            .filter_map(|l| l.strip_prefix("SAMPLE "))
            .map(|s| serde_json::from_str::<Value>(s).unwrap())
            .collect::<Vec<_>>();
        assert_eq!(samples.len(), rounds as usize);
        for (i, s) in samples.iter().enumerate() {
            assert_eq!(s["round"], i);
            assert!(s["ms"].as_f64().unwrap() > 0.);
        }
        let usage: Value = serde_json::from_str(
            log.lines()
                .find_map(|l| l.strip_prefix("SUMMARY "))
                .unwrap(),
        )
        .unwrap();
        assert_eq!(usage["rounds"], rounds);
        assert_eq!(usage["priming"], 3);
        assert_eq!(usage["workers"], c["workers"]);
        route_check(j,&log);
        rows.push(json!({"name":n,"case":c["name"],"variant":j["variant"],"panel":panel,"block":j["block"],"request_median_ms":median(&samples.iter().map(|s|s["ms"].as_f64().unwrap()).collect::<Vec<_>>()),"CPU_ms_per_request":(usage["user_cpu_ms"].as_f64().unwrap()+usage["system_cpu_ms"].as_f64().unwrap())/rounds as f64,"RSS_MiB":usage["whole_process_maxrss_kib"].as_f64().unwrap()/1024.,"usage":usage}));
        let dir = Path::new(j["directory"].as_str().unwrap());
        let proof = dir.join("0.proof");
        let public = dir.join("0.public");
        let sha = hash(&proof);
        assert_eq!(fs::metadata(&proof).unwrap().len(), 164);
        assert_eq!(hash(&public), c["public_sha256"]);
        let receipt = fs::read_to_string(r(format!("runs/verify-{n}/stdout.log"))).unwrap();
        let lines = receipt
            .lines()
            .filter_map(|l| l.strip_prefix("VERIFIED "))
            .collect::<Vec<_>>();
        assert_eq!(lines.len(), 1);
        let f = lines[0]
            .split_whitespace()
            .map(|s| s.split_once('=').unwrap())
            .collect::<BTreeMap<_, _>>();
        assert_eq!(f["proof_sha256"], sha);
        assert_eq!(f["image_sha256"], c["image_sha256"]);
        assert_eq!(f["public_sha256"], c["public_sha256"]);
        assert_eq!(f["vk_sha256"].len(), 64);
        if let Some(previous) = vk.insert(
            c["shape"].as_str().unwrap().to_string(),
            f["vk_sha256"].to_string(),
        ) {
            assert_eq!(previous, f["vk_sha256"]);
        }
        assert!(prior.insert(sha.clone()));
        inventory.push(json!({"name":n,"proof_sha256":sha,"public_sha256":hash(public),"image_sha256":c["image_sha256"],"verified":true}));
        if panel == "stat" {
            let text = fs::read_to_string(j["data"].as_str().unwrap()).unwrap();
            let events = text
                .lines()
                .filter_map(event_line)
                .collect::<BTreeMap<_, _>>();
            assert_eq!(events.len(), 4);
            let per = events
                .iter()
                .map(|(name, value)| {
                    (
                        name.clone(),
                        value["count"].as_f64().map(|count| count / rounds as f64),
                    )
                })
                .collect::<BTreeMap<_, _>>();
            counters.insert(n.to_owned(),json!({"case":c["name"],"variant":j["variant"],"events":events,"per_request":per,"qualified":events.values().all(|v|v["qualified"]==true)}));
        }
        if panel == "cycles" {
            let attrs = fs::read_to_string(r(format!("runs/events-{n}/stdout.log"))).unwrap();
            for needle in ["cycles:u", "16000000", "CPU", "TIME", "PERIOD"] {
                assert!(attrs.contains(needle));
            }
            assert!(!attrs.contains("freq: 1"));
            let meta = fs::read_to_string(r(format!("runs/metadata-{n}/stdout.log"))).unwrap();
            let binary = j["binary"].as_str().unwrap();
            assert!(meta
                .lines()
                .any(|l| l.contains("PERF_RECORD_MMAP") && l.contains(binary)));
            assert!(meta.contains("PERF_RECORD_FORK"));
            let loss = read(r(format!("runs/loss-{n}/stdout.log")));
            assert_eq!(loss["zero_lost"], true);
            let(expected_pid,allowed_tids)=profile_owners(&meta,binary);
            let mut symbols = BTreeMap::<String, (u64, u64)>::new();
            let mut categories = BTreeMap::<String, u64>::new();
            let mut pids = BTreeSet::new();
            let mut tids = BTreeSet::new();
            let (mut count, mut period, mut selected) = (0u64, 0u64, 0u64);
            for (pid, tid, cpu, weight, symbol) in
                fs::read_to_string(r(format!("runs/decode-{n}/stdout.log")))
                    .unwrap()
                    .lines()
                    .filter_map(sample)
            {
                assert!((cpu as u64) < c["workers"].as_u64().unwrap());
                assert_eq!(pid,expected_pid);assert!(allowed_tids.contains(&tid));
                assert_eq!(weight, 16000000);
                pids.insert(pid);
                tids.insert(tid);
                count += 1;
                period += weight;
                if symbol.contains("msm_affine::g2_horner::postgroup") {
                    selected += weight;
                }
                let v = symbols.entry(symbol.clone()).or_default();
                v.0 += 1;
                v.1 += weight;
                *categories.entry(category(&symbol).into()).or_default() += weight;
            }
            assert_eq!(pids.len(), 1);
            assert!(count > 0);
            let unknown = categories.get("unknown").copied().unwrap_or(0) as f64 / period as f64;
            let category_shares = categories
                .iter()
                .map(|(cat, p)| {
                    (
                        cat.clone(),
                        json!({"period":p,"share":*p as f64/period as f64}),
                    )
                })
                .collect::<BTreeMap<_, _>>();
            let symbol_rows = symbols
                .iter()
                .map(|(s, (count, period))| json!({"symbol":s,"samples":count,"period":period}))
                .collect::<Vec<_>>();
            symbols_all.insert(n.to_string(), json!(symbol_rows));
            profiles.insert(n.to_owned(),json!({"case":c["name"],"variant":j["variant"],"samples":count,"period":period,"PIDs":pids,"TIDs":tids,"categories":category_shares,"postgroup_context_period":selected,"unknown_period_share":unknown,"attribution_qualified":count>=1000&&unknown<=0.05,"zero_lost":true,"absolute_period_coverage_not_validated":true}));
        }
    }
    assert_eq!(prior.len(), 27851);
    save(r("proof-inventory.json"), &json!(inventory));
    save(r("proof-sha256-after.json"), &json!(prior));
    save(r("profile-symbols.json"), &json!(symbols_all));
    save(r("rows.json"), &json!(rows));
    let mut cells = BTreeMap::new();
    let mut pairs = BTreeMap::new();
    let mut failed = Vec::<String>::new();
    for c in read(r("cases.json")).as_array().unwrap() {
        let name = c["name"].as_str().unwrap();
        let mut times = BTreeMap::<&str, Vec<f64>>::new();
        let mut rss = BTreeMap::<&str, f64>::new();
        for v in VS {
            let selected = rows
                .iter()
                .filter(|r| r["panel"] == "latency" && r["case"] == name && r["variant"] == v)
                .collect::<Vec<_>>();
            assert_eq!(selected.len(), 15);
            let mut ordered = Vec::new();
            for b in 0..15 {
                let row = selected.iter().find(|row| row["block"] == b).unwrap();
                ordered.push(row["request_median_ms"].as_f64().unwrap());
            }
            let max = selected
                .iter()
                .map(|r| r["RSS_MiB"].as_f64().unwrap())
                .fold(0f64, f64::max);
            rss.insert(v, max);
            cells.insert(format!("{name}/{v}"),json!({"median_ms":median(&ordered),"CPU_ms":median(&selected.iter().map(|r|r["CPU_ms_per_request"].as_f64().unwrap()).collect::<Vec<_>>()),"max_RSS_MiB":max,"process_medians":ordered,"workers":c["workers"]}));
            times.insert(v, ordered);
        }
        for (num, den) in [("OFF", "accepted"), ("ON", "accepted"), ("ON", "OFF")] {
            let values = times[num]
                .iter()
                .zip(&times[den])
                .map(|(a, b)| a / b)
                .collect::<Vec<_>>();
            let stats = interval(&values);
            let key = format!("{name}/{num}/{den}");
            let pass=if num=="OFF"{stats["low"].as_f64().unwrap()>=1./1.03&&stats["high"].as_f64().unwrap()<=1.03}else{stats["high"].as_f64().unwrap()<=1.03};
            if !pass {
                failed.push(key.clone());
            }
            pairs.insert(key, json!({"statistics":stats,"passed":pass}));
        }
        for v in ["accepted", "OFF"] {
            if rss["ON"] / rss[v] > 1.05 {
                failed.push(format!("{name}/RSS/ON/{v}"));
            }
        }
    }

    let case_data = read(r("cases.json"));
    let original8 = case_data
        .as_array()
        .unwrap()
        .iter()
        .filter(|c| c["workers"] == 32 && !c["reference"].is_null())
        .collect::<Vec<_>>();
    assert_eq!(original8.len(), 8);
    let eligible=original8.iter().copied().filter(|c|["4x2","8x2","12x2","16x2","merge-24x1"].contains(&c["shape"].as_str().unwrap())).collect::<Vec<_>>();assert_eq!(eligible.len(),5);
    let mut aggregates = BTreeMap::new();
    let mut comparisons = BTreeMap::new();
    for control in ["accepted", "OFF"] {
        let values = (0..15)
            .map(|block| {
                (eligible
                    .iter()
                    .map(|c| {
                        pairs[&format!("{}/ON/{control}", c["name"].as_str().unwrap())]
                            ["statistics"]["ratios"][block]
                            .as_f64()
                            .unwrap()
                            .ln()
                    })
                    .sum::<f64>()
                    / 5.)
                    .exp()
            })
            .collect::<Vec<_>>();
        let stats = interval(&values);
        let passed = stats["high"].as_f64().unwrap() < 1. && stats["wins"].as_u64().unwrap() >= 10;
        if !passed {
            failed.push(format!("eligible5/ON/{control}/gain"));
        }
        aggregates.insert(control, json!({"statistics":stats,"passed":passed}));
    }
    for c in &original8 {
        let name = c["name"].as_str().unwrap();
        let mut by_variant = BTreeMap::new();
        for v in VS {
            let ms = cells[&format!("{name}/{v}")]["median_ms"].as_f64().unwrap();
            let cpu = c["reference"]["cpu_ms"].as_f64().unwrap();
            let metal = c["reference"]["metal_ms"].as_f64().unwrap();
            by_variant.insert(
                v,
                json!({"ms":ms,"CPU_speedup":cpu/ms,"Metal_speedup":metal/ms,"CPU10x":ms<=cpu/10.}),
            );
        }
        comparisons.insert(
            name,
            json!({"reference":c["reference"],"variants":by_variant}),
        );
    }
    let diagnostics_qualified = counters.values().all(|v| v["qualified"] == true)
        && profiles
            .values()
            .all(|v| v["attribution_qualified"] == true);
    for (n, v) in &counters {
        if v["qualified"] != true {
            failed.push(format!("diagnostic/{n}/PMU"));
        }
    }
    for (n, v) in &profiles {
        if v["attribution_qualified"] != true {
            failed.push(format!("diagnostic/{n}/profile"));
        }
    }
    save(r("analysis.json"),&json!({"complete":true,"gate_passed":failed.is_empty(),"diagnostics_qualified":diagnostics_qualified,"failed_checks":failed,"adopted":false,"production_changed":false,"goal_achieved":false,"SDK_requests":26562,"new_independent_exports":498,"prior_proof_count":27353,"independent_proof_count":27851,"native_core_tests":128,"native_prover_tests":8,"field_qualification_inherited":true,"portable_not_run":true,"eligible5_aggregates":aggregates,"new_reference_comparisons":comparisons,"cells":cells,"pairs":pairs,"counters":counters,"profiles":profiles,"source_files":177,"originals_exact":172,"reverse176_exact":true,"limitations":["No adoption; final integration/resource/portable qualification still required on success","Flat cycle profiles retain unvalidated absolute-period coverage","No new AWS, mobile, TEE, huge-circuit, pressure or concurrent-throughput result"]}));
    println!("FullSDK15block analysis complete;498newGnarkexports/ledger27851;{}failedchecks",failed.len());
}
