use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{collections::BTreeMap,fs,path::{Path,PathBuf}};
const R:&str="/home/ubuntu/src/zopro-perf-work/postgroup-phi176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";
fn r(p:impl AsRef<Path>)->PathBuf{Path::new(R).join(p)}fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}fn save(p:impl AsRef<Path>,v:&Value){fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}fn pin(m:&mut BTreeMap<String,String>,p:impl AsRef<Path>){m.insert(p.as_ref().display().to_string(),hash(&p));}
fn append(rel:&str,s:&str){let p=r("source").join(rel);let mut t=fs::read_to_string(&p).unwrap();t.push_str("\n// BEGIN PRIVATE POSTGROUP PHI\n");t.push_str(s);fs::write(p,t).unwrap();}
fn main(){assert!(!r("source").exists());let m=read(Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));let mut pins=BTreeMap::new();for(rel,h)in m["source_files_sha256"].as_object().unwrap(){let p=Path::new(Z).join(rel);assert_eq!(hash(&p),h.as_str().unwrap());pin(&mut pins,&p);let to=r("source").join(rel);fs::create_dir_all(to.parent().unwrap()).unwrap();fs::copy(p,to).unwrap();}
 let hook="    #[cfg(zopro_postgroup_phi)]\n    if std::env::var(\"ZOPRO_CPU_POSTGROUP_PHI\").ok().as_deref()==Some(\"1\") {\n        if let Some(out)=postgroup::try_grouped(bases,groups,true){return out;}\n    }\n";
 let rel="crates/zopro-core/src/msm_affine/g2_horner.rs";let p=r("source").join(rel);let mut t=fs::read_to_string(&p).unwrap();let a="    assert_eq!(bases.len(), groups.len);\n";assert_eq!(t.matches(a).count(),1);t=t.replace(a,&format!("{a}{hook}"));fs::write(p,t).unwrap();append(rel,"#[cfg(zopro_postgroup_phi)] pub(super) mod postgroup;\n");
 fs::create_dir_all(r("source/crates/zopro-core/src/msm_affine/g2_horner")).unwrap();fs::copy(r("postgroup.rs"),r("source/crates/zopro-core/src/msm_affine/g2_horner/postgroup.rs")).unwrap();
 append("crates/zopro-core/src/msm_affine/workspace.rs",r#"
#[cfg(zopro_postgroup_phi)]pub(crate) fn postgroup_g2(n:usize,u:usize,workers:usize)->Option<usize>{
 if !(65536..u32::MAX as usize).contains(&n)||!(1024..65536).contains(&u)||u>n||workers==0{return None;}
 let p=hb::<G2Config>(u)?;
 add(add(p.held,vector::<zopro_bn254::G2Affine>(u,false)?)?,mul(p.leaf,workers)?)
}
"#);
 append("crates/zopro-core/src/lib.rs",r#"
#[cfg(zopro_postgroup_phi)]pub fn postgroup_phi_snapshot()->[usize;6]{
 #[cfg(all(feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma),zopro_g2_horner_buckets))]
 {msm_affine::g2_horner::postgroup::snapshot()}
 #[cfg(not(all(feature="ifma8",target_arch="x86_64",target_feature="avx512ifma",target_feature="avx512vl",target_feature="avx512dq",not(no_ifma),zopro_g2_horner_buckets)))]
 {[0;6]}
}
"#);
 // g2_horner is private to msm_affine; expose only the diagnostic bridge there.
 append("crates/zopro-core/src/msm_affine.rs","#[cfg(all(zopro_postgroup_phi,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma),zopro_g2_horner_buckets))] pub(crate) fn postgroup_phi_snapshot()->[usize;6]{g2_horner::postgroup::snapshot()}\n");
 let p=r("source/crates/zopro-core/src/lib.rs");let t=fs::read_to_string(&p).unwrap().replace("msm_affine::g2_horner::postgroup::snapshot()","msm_affine::postgroup_phi_snapshot()");fs::write(p,t).unwrap();
 let mut files=BTreeMap::new();let mut exact=0;for(rel,h)in m["source_files_sha256"].as_object().unwrap(){let p=r("source").join(rel);let bytes=fs::read(&p).unwrap();let original=fs::read(Path::new(Z).join(rel)).unwrap();if hash(&p)==h.as_str().unwrap(){exact+=1;}else{let marker=b"\n// BEGIN PRIVATE POSTGROUP PHI\n";let a=bytes.windows(marker.len()).position(|v|v==marker).unwrap();let mut recovered=String::from_utf8(bytes[..a].to_vec()).unwrap();if rel.ends_with("g2_horner.rs"){assert_eq!(recovered.matches(hook).count(),1);recovered=recovered.replace(hook,"");}assert_eq!(recovered.as_bytes(),original);}files.insert(rel.clone(),json!({"original_sha256":h,"private_sha256":hash(&p)}));pin(&mut pins,p);}
 assert_eq!(exact,172);pin(&mut pins,r("source/crates/zopro-core/src/msm_affine/g2_horner/postgroup.rs"));save(r("source-audit.json"),&json!({"originals":176,"exact":exact,"reversible_parents":4,"new_children":1,"all_originals_recovered":true,"fields_unchanged":true,"hook":hook,"files":files}));
 let flags=m["rustflags"].as_str().unwrap().to_owned()+" --cfg zopro_postgroup_phi";for f in["native-flags.txt","candidate-flags.txt"]{fs::write(r(f),&flags).unwrap();}
 let old="/home/ubuntu/src/zopro-perf-work/g2-wide-top176";let native=fs::read_to_string(Path::new(old).join("native.rs")).unwrap().replace(old,R);fs::write(r("native.rs"),native).unwrap();
 let original=fs::read_to_string(Path::new(Z).join("crates/zopro-bench/examples/cpu-sdk.rs")).unwrap();let a="fn main() -> Result<(), Box<dyn std::error::Error>> {";assert_eq!(original.matches(a).count(),1);let mut driver=original.replace(a,"fn original_main() -> Result<(), Box<dyn std::error::Error>> {");driver.push_str("\nfn main()->Result<(),Box<dyn std::error::Error>>{let result=original_main();println!(\"POSTGROUP_PHI {}\",serde_json::json!({\"counts\":zopro_prover::zopro_core::postgroup_phi_snapshot()}));result}\n");fs::write(r("driver.rs"),driver).unwrap();fs::create_dir_all(r("support")).unwrap();fs::copy(Path::new(Z).join("crates/zopro-bench/examples/support/perf.rs"),r("support/perf.rs")).unwrap();
 save(r("production-pins.json"),&json!(pins));println!("Prepared177private files/172exactoriginals/4recoverableparents;originalSDKbodyretainedwithpost-clockcounterwrapper;fieldsunchanged");}
