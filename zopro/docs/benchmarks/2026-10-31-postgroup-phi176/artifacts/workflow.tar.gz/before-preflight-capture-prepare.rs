fn route_check(j:&Value,log:&str){
 let records=log.lines().filter_map(|l|l.strip_prefix("POSTGROUP_PHI ")).collect::<Vec<_>>();if j["variant"]=="accepted"{assert!(records.is_empty());return;}assert_eq!(records.len(),1);let v:Value=serde_json::from_str(records[0]).unwrap();let c=v["counts"].as_array().unwrap();assert_eq!(c.len(),6);let n=j["rounds"].as_u64().unwrap()+3;
 if j["variant"]=="OFF"||j["case"]["shape"]=="1x2"||j["case"]["shape"]=="2x2"||j["case"]["shape"]=="merge-54x1"{assert!(c.iter().all(|x|x==0));}
 else if ["4x2","8x2","12x2","16x2","merge-24x1"].contains(&j["case"]["shape"].as_str().unwrap()){
  assert_eq!(c[0],n);assert_eq!(c[1],n);assert_eq!(c[2],0);assert!(c[3].as_u64().unwrap()>=65536);assert!((1024..65536).contains(&c[4].as_u64().unwrap()));assert!(c[5].as_u64().unwrap()>0);
 }else{assert_eq!(j["case"]["shape"],"24x2");assert_eq!(c[2],0);assert!(c[0]==0&&c[1]==0||c[0]==n&&c[1]==n);}
}
fn prepare(){
 assert!(!r("plan.json").exists());assert_eq!(read(r("native-fixed/result.json"))["status"],"complete");assert_eq!(read(r("links/result.json"))["status"],"complete");let mut pins:BTreeMap<String,String>=serde_json::from_value(read(r("link-pins.json"))).unwrap();for(p,h)in &pins{assert_eq!(hash(p),*h);}
 let initial=fs::read_to_string(r("native/core/stdout.log")).unwrap();assert!(initial.contains("127 passed; 1 failed"));for(name,count,unfiltered)in[("core-postgroup",1,false),("prover",2,true),("cubic",6,true)]{let p=r(format!("native-fixed/{name}/tests.json"));let t=read(&p);assert_eq!(t["unfiltered"],unfiltered);assert_eq!(t["passed_tests"].as_array().unwrap().len(),count);pin(&mut pins,p);}
 assert_eq!(hash(ACCEPTED),"6d83f1d6fda6f16576cb351b81789e8d26a6177cc0f26f169a3dc98448c0e661");pin(&mut pins,ACCEPTED);
 let linked=read(r("links/sdk/artifacts.json"));let fresh=linked["binary"].as_str().unwrap();assert_eq!(hash(fresh),linked["binary_sha256"]);for(p,h)in linked["input_pins"].as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());pin(&mut pins,p);}pin(&mut pins,fresh);
 let command=read(r("links/sdk/command.json"));for flag in["-O","target-cpu=native","lto=fat","codegen-units=1"]{assert!(command["argv"].as_array().unwrap().iter().any(|v|v==flag));}
 let ids=json!({"accepted":{"binary":ACCEPTED,"sha256":hash(ACCEPTED)},"OFF":{"binary":fresh,"sha256":hash(fresh)},"ON":{"binary":fresh,"sha256":hash(fresh)}});save(r("identities.json"),&ids);
 let prior_path="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default-compat175/proof-sha256-after.json";let prior=read(prior_path);assert_eq!(prior.as_array().unwrap().len(),27353);pin(&mut pins,prior_path);save(r("prior-proof-sha256.json"),&prior);
 let data=read("/home/ubuntu/src/zopro-perf-work/g2-balanced-sdk175/cases.json");let cases=data.as_array().unwrap().clone();assert_eq!(cases.len(),10);save(r("cases.json"),&json!(cases));
 let mut base=read("/home/ubuntu/src/zopro-perf-work/sdk-link-flags176/environment.json");for key in["RUSTFLAGS","CARGO_TARGET_DIR","CARGO_BUILD_JOBS"]{base.as_object_mut().unwrap().remove(key);}for dir in["proofs","stat","perf"]{fs::create_dir_all(r(dir)).unwrap();}for f in["ctl","ack"]{assert!(Command::new("mkfifo").arg(r(f)).status().unwrap().success());}
 let(mut jobs,mut steps)=(vec![],vec![]);for c in &cases{for v in VS{add_job(c,v,0,"preflight",&base,&ids,&mut jobs,&mut steps);steps.push(verify_step(jobs.last().unwrap()));}}
 for b in 0..15{let mut order=(0usize..10).collect::<Vec<_>>();order.rotate_left(b%10);if b%2==1{order.reverse();}let mut variants=VS;variants.rotate_left(b%3);if b%2==1{variants.reverse();}for i in order{for v in variants{add_job(&cases[i],v,b,"latency",&base,&ids,&mut jobs,&mut steps);}}}
 for panel in["stat","cycles"]{for shape in["1x2","4x2","merge-24x1"]{let c=cases.iter().find(|c|c["shape"]==shape&&c["workers"]==32).unwrap();for v in VS{add_job(c,v,0,panel,&base,&ids,&mut jobs,&mut steps);}}}assert_eq!(jobs.len(),498);
 for j in jobs.iter().filter(|j|j["panel"]!="preflight"){steps.push(verify_step(j));}
 for j in jobs.iter().filter(|j|j["panel"]=="cycles"){let name=j["name"].as_str().unwrap();let file=j["data"].as_str().unwrap();steps.push(step(format!("own-{name}"),vec!["sudo".into(),"-n".into(),"chown".into(),"ubuntu:ubuntu".into(),file.into()]));for(kind,argv)in[
 ("decode",vec!["perf","script","--header","--ns","-i",file,"-F","pid,tid,cpu,time,period,ip,sym"].into_iter().map(String::from).collect()),
 ("events",vec!["perf","evlist","-v","-i",file].into_iter().map(String::from).collect()),
 ("loss",vec![r("capture-helper").display().to_string(),"loss".into(),file.into()]),
 ("metadata",vec!["perf","script","--header","--show-mmap-events","--show-task-events","--ns","-i",file,"-F","pid,tid,cpu,time,period,ip,sym"].into_iter().map(String::from).collect())]{steps.push(step(format!("{kind}-{name}"),argv));}}
 assert_eq!(steps.len(),1041);assert_eq!(jobs.iter().map(|j|j["rounds"].as_u64().unwrap()+3).sum::<u64>(),26562);save(r("jobs.json"),&json!(jobs));
 for c in&cases{for key in["image","request"]{pin(&mut pins,c[key].as_str().unwrap());}assert_eq!(hash(c["image"].as_str().unwrap()),c["image_sha256"]);}for e in fs::read_dir("/home/ubuntu/src/zopro-perf-work/sdk-control-copies/lagrange-cache").unwrap(){pin(&mut pins,e.unwrap().path());}
 for p in[VERIFY,X,"/usr/bin/perf"]{pin(&mut pins,p);}for f in["capture.rs","capture-prepare.rs","analysis.rs","sampling.rs","counter.rs","metadata.rs","capture-helper","design.md","postgroup.rs","source-audit.json","identities.json","cases.json","jobs.json","prior-proof-sha256.json","make-capture.rs","make-capture","review.rs","review-helper","publish.rs","publisher","archive-review.rs","archive-review-helper"]{pin(&mut pins,r(f));}save(r("pins.json"),&json!(pins));save(r("plan.json"),&json!({"version":1,"source_pins":r("pins.json"),"steps":steps}));println!("Frozen1041commands/498SDKprocesses/498independentexports/26562SDKrequests;15blocks;eligible5gain/allcontextcalibnonregRSS;noownworkduringcaptures");
}
