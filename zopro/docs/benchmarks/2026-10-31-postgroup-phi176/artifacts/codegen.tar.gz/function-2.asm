
/home/ubuntu/src/zopro-perf-work/postgroup-phi176/links/sdk-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000459ef0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw>:
  459ef0:	push   %rbp
  459ef1:	push   %r15
  459ef3:	push   %r14
  459ef5:	push   %r13
  459ef7:	push   %r12
  459ef9:	push   %rbx
  459efa:	sub    $0x1f8,%rsp
  459f01:	movq   $0xb,0x18(%rsp)
  459f0a:	movq   $0x2,0x40(%rsp)
  459f13:	mov    %rdx,0x48(%rsp)
  459f18:	mov    %r8,0x60(%rsp)
  459f1d:	cmp    %r8,%rdx
  459f20:	jne    459ffe <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x10e>
  459f26:	mov    %fs:0xffffffffffffffc0,%rax
  459f2f:	mov    %rcx,%r12
  459f32:	mov    %rdx,%r15
  459f35:	mov    %rsi,%r13
  459f38:	mov    %rdi,%rbx
  459f3b:	test   %rax,%rax
  459f3e:	je     459f48 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x58>
  459f40:	add    $0x110,%rax
  459f46:	jmp    459f4d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x5d>
  459f48:	call   1049a0 <_RNvNtCs8zaw6vLE3tn_10rayon_core8registry15global_registry>
  459f4d:	mov    (%rax),%rax
  459f50:	mov    0x208(%rax),%rdx
  459f57:	sub    $0x8,%rsp
  459f5b:	lea    0x1f(%rsp),%rax
  459f60:	mov    $0x1,%ecx
  459f65:	mov    %r15,%rdi
  459f68:	xor    %esi,%esi
  459f6a:	mov    %r12,%r8
  459f6d:	mov    %r15,%r9
  459f70:	push   %rax
  459f71:	call   45a3e0 <_RINvNvNtNtCsc3XWelWpAp8_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_5slice15IterMutProducerAyj4_EINtNtB6_8for_each15ForEachConsumerNCNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw0EEB2u_>
  459f76:	add    $0x10,%rsp
  459f7a:	mov    %r15,%rax
  459f7d:	shr    $1,%rax
  459f80:	mov    %r15,%rcx
  459f83:	movq   $0x0,0x20(%rsp)
  459f8c:	movq   $0x8,0x28(%rsp)
  459f95:	movq   $0x0,0x30(%rsp)
  459f9e:	movq   $0xc,0x58(%rsp)
  459fa7:	sub    %rax,%rcx
  459faa:	mov    %rcx,0x50(%rsp)
  459faf:	lea    0x20(%rsp),%rdi
  459fb4:	mov    $0xc,%edx
  459fb9:	mov    $0x8,%ecx
  459fbe:	mov    $0xc0,%r8d
  459fc4:	xor    %esi,%esi
  459fc6:	call   1b66d0 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsHW5vo2gROj_10zopro_core>
  459fcb:	mov    0x20(%rsp),%rbp
  459fd0:	mov    0x30(%rsp),%r14
  459fd5:	mov    %rbp,%rax
  459fd8:	sub    %r14,%rax
  459fdb:	cmp    $0xc,%rax
  459fdf:	jae    45a016 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x126>
  459fe1:	lea    -0x43a641(%rip),%rdi        # 1f9a7 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x55a7>
  459fe8:	lea    0x8b431(%rip),%rdx        # 4e5420 <__frame_dummy_init_array_entry+0x6210>
  459fef:	mov    $0x2f,%esi
  459ff4:	call   f0c40 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
  459ff9:	jmp    45a3a3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x4b3>
  459ffe:	lea    0x8c79b(%rip),%r8        # 4e67a0 <__frame_dummy_init_array_entry+0x7590>
  45a005:	lea    0x48(%rsp),%rdi
  45a00a:	lea    0x60(%rsp),%rsi
  45a00f:	xor    %edx,%edx
  45a011:	call   effc2 <_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedjjEB4_>
  45a016:	mov    0x28(%rsp),%rcx
  45a01b:	lea    0x40(%rsp),%rax
  45a020:	lea    0x50(%rsp),%rsi
  45a025:	lea    0x18(%rsp),%rdx
  45a02a:	movq   $0xc,0x138(%rsp)
  45a036:	mov    %rax,0x60(%rsp)
  45a03b:	mov    %fs:0xffffffffffffffc0,%rax
  45a044:	mov    %rsi,0x68(%rsp)
  45a049:	lea    (%r14,%r14,2),%rsi
  45a04d:	mov    %r13,0x70(%rsp)
  45a052:	mov    %r15,0x78(%rsp)
  45a057:	mov    %r12,0x80(%rsp)
  45a05f:	mov    %r15,0x88(%rsp)
  45a067:	mov    %rdx,0x90(%rsp)
  45a06f:	lea    0x60(%rsp),%rdx
  45a074:	movq   $0x0,0x98(%rsp)
  45a080:	movq   $0xc,0xa0(%rsp)
  45a08c:	mov    %rdx,0x120(%rsp)
  45a094:	shl    $0x6,%rsi
  45a098:	add    %rcx,%rsi
  45a09b:	mov    %rcx,0x8(%rsp)
  45a0a0:	mov    %rsi,0x128(%rsp)
  45a0a8:	movq   $0xc,0x130(%rsp)
  45a0b4:	test   %rax,%rax
  45a0b7:	je     45a0c1 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x1d1>
  45a0b9:	add    $0x110,%rax
  45a0bf:	jmp    45a0c6 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x1d6>
  45a0c1:	call   1049a0 <_RNvNtCs8zaw6vLE3tn_10rayon_core8registry15global_registry>
  45a0c6:	mov    (%rax),%rax
  45a0c9:	mov    0x208(%rax),%rcx
  45a0d0:	lea    0x120(%rsp),%r15
  45a0d8:	xor    %edx,%edx
  45a0da:	lea    0x1e0(%rsp),%rdi
  45a0e2:	mov    $0xc,%esi
  45a0e7:	mov    $0x1,%r8d
  45a0ed:	xor    %r9d,%r9d
  45a0f0:	push   %r15
  45a0f2:	push   $0xc
  45a0f4:	call   45a7b0 <_RINvNvNtNtCsc3XWelWpAp8_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_5range12IterProducerjEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerINtNtCsgHCcee0nhgM_11zopro_bn2545curve10ProjectiveNtB2R_8G2ConfigEENCNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raws_0EEB41_>
  45a0f9:	add    $0x10,%rsp
  45a0fd:	mov    0x1f0(%rsp),%rax
  45a105:	mov    %rax,0x120(%rsp)
  45a10d:	cmp    $0xc,%rax
  45a111:	jne    45a36b <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x47b>
  45a117:	vmovups -0x43acd1(%rip),%zmm0        # 1f450 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x5050>
  45a121:	vmovups -0x43ad1b(%rip),%zmm2        # 1f410 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x5010>
  45a12b:	vmovups -0x43ad65(%rip),%zmm1        # 1f3d0 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x4fd0>
  45a135:	mov    0x18(%rsp),%rax
  45a13a:	shl    $0x6,%r14
  45a13e:	lea    (%r14,%r14,2),%r13
  45a142:	mov    %rax,0x38(%rsp)
  45a147:	vmovups %zmm0,0x1a0(%rsp)
  45a152:	vmovups %zmm2,0x160(%rsp)
  45a15d:	vmovups %zmm1,0x120(%rsp)
  45a168:	test   %rax,%rax
  45a16b:	je     45a24c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x35c>
  45a171:	mov    0x8(%rsp),%rax
  45a176:	lea    0x60(%rsp),%r12
  45a17b:	lea    0x900(%rax,%r13,1),%r15
  45a183:	lea    0x120(%rsp),%r13
  45a18b:	mov    0x38(%rsp),%r14
  45a190:	mov    %r12,%rdi
  45a193:	mov    %r13,%rsi
  45a196:	vzeroupper
  45a199:	call   190cd0 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE6doubleB7_>
  45a19e:	vmovups 0x60(%rsp),%zmm0
  45a1a9:	vmovups 0xa0(%rsp),%zmm1
  45a1b4:	vmovups 0xe0(%rsp),%zmm2
  45a1bf:	dec    %r14
  45a1c2:	vmovups %zmm2,0x1a0(%rsp)
  45a1cd:	vmovups %zmm1,0x160(%rsp)
  45a1d8:	vmovups %zmm0,0x120(%rsp)
  45a1e3:	jne    45a190 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x2a0>
  45a1e5:	add    $0xffffffffffffff40,%r15
  45a1ec:	mov    %r12,%rdi
  45a1ef:	mov    %r13,%rsi
  45a1f2:	mov    %r15,%rdx
  45a1f5:	vzeroupper
  45a1f8:	call   184700 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE14add_projectiveB7_>
  45a1fd:	vmovups 0x60(%rsp),%zmm0
  45a208:	vmovups 0xa0(%rsp),%zmm1
  45a213:	vmovups 0xe0(%rsp),%zmm2
  45a21e:	vmovups %zmm2,0x1a0(%rsp)
  45a229:	vmovups %zmm1,0x160(%rsp)
  45a234:	vmovups %zmm0,0x120(%rsp)
  45a23f:	cmp    %r15,0x8(%rsp)
  45a244:	jne    45a18b <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x29b>
  45a24a:	jmp    45a2c9 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x3d9>
  45a24c:	mov    0x8(%rsp),%rax
  45a251:	lea    0x60(%rsp),%r15
  45a256:	lea    0x120(%rsp),%r12
  45a25e:	lea    0x840(%rax),%r14
  45a265:	lea    (%r14,%r13,1),%rdx
  45a269:	mov    %r15,%rdi
  45a26c:	mov    %r12,%rsi
  45a26f:	vzeroupper
  45a272:	call   184700 <_RNvMs2_NtCsgHCcee0nhgM_11zopro_bn2545curveINtB5_10ProjectiveNtB5_8G2ConfigE14add_projectiveB7_>
  45a277:	vmovups 0x60(%rsp),%zmm0
  45a282:	vmovups 0xa0(%rsp),%zmm1
  45a28d:	vmovups 0xe0(%rsp),%zmm2
  45a298:	add    $0xffffffffffffff40,%r13
  45a29f:	vmovups %zmm2,0x1a0(%rsp)
  45a2aa:	vmovups %zmm1,0x160(%rsp)
  45a2b5:	vmovups %zmm0,0x120(%rsp)
  45a2c0:	cmp    $0xfffffffffffff700,%r13
  45a2c7:	jne    45a265 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x375>
  45a2c9:	vmovups 0x120(%rsp),%zmm0
  45a2d4:	vmovups 0x160(%rsp),%zmm1
  45a2df:	vmovups 0x1a0(%rsp),%zmm2
  45a2ea:	vmovups %zmm2,0x80(%rbx)
  45a2f1:	vmovups %zmm1,0x40(%rbx)
  45a2f8:	vmovups %zmm0,(%rbx)
  45a2fe:	test   %rbp,%rbp
  45a301:	je     45a356 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x466>
  45a303:	cmp    $0x2aa,%rbp
  45a30a:	jbe    45a346 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x456>
  45a30c:	shl    $0x6,%rbp
  45a310:	movabs $0x7ffffffffffffff8,%rcx
  45a31a:	lea    0x0(%rbp,%rbp,2),%rax
  45a31f:	mov    %rax,%rsi
  45a322:	or     $0x1,%rsi
  45a326:	cmp    %rcx,%rsi
  45a329:	ja     45a3a5 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x4b5>
  45a32b:	mov    0x8(%rsp),%rcx
  45a330:	cmpb   $0x1,(%rcx,%rax,1)
  45a334:	jne    45a348 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x458>
  45a336:	mov    0x8(%rsp),%rdi
  45a33b:	vzeroupper
  45a33e:	call   *0x8dbac(%rip)        # 4e7ef0 <munmap@GLIBC_2.2.5>
  45a344:	jmp    45a356 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x466>
  45a346:	jmp    45a348 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x458>
  45a348:	mov    0x8(%rsp),%rdi
  45a34d:	vzeroupper
  45a350:	call   *0x8dba2(%rip)        # 4e7ef8 <free@GLIBC_2.2.5>
  45a356:	add    $0x1f8,%rsp
  45a35d:	pop    %rbx
  45a35e:	pop    %r12
  45a360:	pop    %r13
  45a362:	pop    %r14
  45a364:	pop    %r15
  45a366:	pop    %rbp
  45a367:	vzeroupper
  45a36a:	ret
  45a36b:	lea    0x58(%rsp),%rax
  45a370:	lea    -0x3671b7(%rip),%rcx        # f31c0 <_RNvXsd_NtNtNtCsgxBkk5gSRhY_4core3fmt3num3impyNtB9_7Display3fmt>
  45a377:	mov    %rax,0x60(%rsp)
  45a37c:	mov    %rcx,0x68(%rsp)
  45a381:	mov    %r15,0x70(%rsp)
  45a386:	mov    %rcx,0x78(%rsp)
  45a38b:	lea    -0x443642(%rip),%rdi        # 16d50 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x52d0>
  45a392:	lea    0x89147(%rip),%rdx        # 4e34e0 <__frame_dummy_init_array_entry+0x42d0>
  45a399:	lea    0x60(%rsp),%rsi
  45a39e:	call   eeb70 <_RNvNtCsgxBkk5gSRhY_4core9panicking9panic_fmt>
  45a3a3:	ud2
  45a3a5:	vzeroupper
  45a3a8:	call   1108e0 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>
  45a3ad:	mov    %rax,%rbx
  45a3b0:	mov    0x20(%rsp),%rax
  45a3b5:	test   %rax,%rax
  45a3b8:	je     45a3d1 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw+0x4e1>
  45a3ba:	mov    0x28(%rsp),%rdi
  45a3bf:	shl    $0x6,%rax
  45a3c3:	lea    (%rax,%rax,2),%rsi
  45a3c7:	mov    $0x8,%edx
  45a3cc:	call   e8b60 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
  45a3d1:	mov    %rbx,%rdi
  45a3d4:	call   4de1c0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
