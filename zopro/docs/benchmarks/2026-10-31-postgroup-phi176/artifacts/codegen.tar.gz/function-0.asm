
/home/ubuntu/src/zopro-perf-work/postgroup-phi176/links/sdk-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000460ed0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component>:
  460ed0:	push   %rbp
  460ed1:	push   %r15
  460ed3:	push   %r14
  460ed5:	push   %r13
  460ed7:	push   %r12
  460ed9:	push   %rbx
  460eda:	sub    $0x118,%rsp
  460ee1:	mov    %r9d,0x38(%rsp)
  460ee6:	mov    %rcx,0x30(%rsp)
  460eeb:	mov    %rsi,0x50(%rsp)
  460ef0:	mov    %rdi,0x80(%rsp)
  460ef8:	mov    %rdx,%rbx
  460efb:	mov    $0x8,%edi
  460f00:	mov    $0x1,%edx
  460f05:	mov    %r8,%r14
  460f08:	mov    0x158(%rsp),%rax
  460f10:	mov    0x160(%rsp),%r12
  460f18:	mov    %rax,0x40(%rsp)
  460f1d:	mov    0x150(%rsp),%rax
  460f25:	mov    %rax,0x48(%rsp)
  460f2a:	mov    $0x8,%eax
  460f2f:	shlx   %r12,%rax,%rsi
  460f34:	mov    %rsi,0x8(%rsp)
  460f39:	call   4b9670 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
  460f3e:	test   %rax,%rax
  460f41:	je     461877 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9a7>
  460f47:	cmp    %rbx,%r14
  460f4a:	mov    %rax,%r15
  460f4d:	mov    $0x1,%eax
  460f52:	mov    %r12,0x18(%rsp)
  460f57:	mov    %rbx,0x88(%rsp)
  460f5f:	cmovae %rbx,%r14
  460f63:	shlx   %r12,%rax,%rbp
  460f68:	mov    %r14,0x58(%rsp)
  460f6d:	test   %r14,%r14
  460f70:	je     46112c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x25c>
  460f76:	mov    0x40(%rsp),%r8
  460f7b:	movzbl 0x38(%rsp),%eax
  460f80:	vxorps %xmm0,%xmm0,%xmm0
  460f84:	mov    %r8,%rcx
  460f87:	imul   0x48(%rsp),%rcx
  460f8d:	shl    $0x4,%eax
  460f90:	add    0x30(%rsp),%rax
  460f95:	mov    %r8d,%ebx
  460f98:	lea    -0x1(%r8),%r10d
  460f9c:	lea    -0x1(%rcx),%rdx
  460fa0:	mov    %edx,%edi
  460fa2:	and    $0x3f,%edi
  460fa5:	mov    %rdx,%rsi
  460fa8:	shr    $0x6,%rsi
  460fac:	mov    %rdi,0x10(%rsp)
  460fb1:	lea    -0x40(%r8,%rdi,1),%rdi
  460fb6:	cmp    $0xffffffffffffffbf,%rdi
  460fba:	setb   %dil
  460fbe:	cmp    $0xc0,%rdx
  460fc5:	setb   %r9b
  460fc9:	and    $0x3f,%ebx
  460fcc:	and    $0x3f,%r10d
  460fd0:	and    %dil,%r9b
  460fd3:	mov    $0x1,%edi
  460fd8:	sub    %ecx,%edi
  460fda:	mov    %r9b,0x28(%rsp)
  460fdf:	lea    0x1(%r8),%ecx
  460fe3:	xor    %r8d,%r8d
  460fe6:	and    $0x3f,%edi
  460fe9:	mov    %rdi,0x20(%rsp)
  460fee:	mov    $0xffffffffffffffff,%rdi
  460ff5:	mov    0x58(%rsp),%r9
  460ffa:	shlx   %rcx,%rdi,%r11
  460fff:	mov    0x50(%rsp),%rcx
  461004:	shlx   %rbx,%rdi,%r12
  461009:	mov    %r12,%r13
  46100c:	not    %r11
  46100f:	not    %r13
  461012:	shl    $0x5,%r9
  461016:	jmp    461043 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x173>
  461018:	nopl   0x0(%rax,%rax,1)
  461020:	lea    -0x1(%r14),%rdi
  461024:	cmp    %rbp,%rdi
  461027:	jae    461839 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x969>
  46102d:	incq   -0x8(%r15,%r14,8)
  461032:	add    $0x20,%r8
  461036:	sub    $0xffffffffffffff80,%rcx
  46103a:	cmp    %r8,%r9
  46103d:	je     46112c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x25c>
  461043:	vmovdqu (%rax,%r8,1),%xmm1
  461049:	mov    (%rax,%r8,1),%rdi
  46104d:	cmpq   $0x0,0x48(%rsp)
  461053:	lea    0xa0(%rsp),%r14
  46105b:	vmovdqa %xmm1,0x90(%rsp)
  461064:	vmovaps %xmm0,(%r14)
  461069:	je     4610a0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x1d0>
  46106b:	cmp    $0xff,%rdx
  461072:	ja     4610b0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x1e0>
  461074:	mov    0x10(%rsp),%rdi
  461079:	cmpb   $0x0,0x28(%rsp)
  46107e:	shrx   %rdi,0x90(%rsp,%rsi,8),%r14
  461088:	je     4610b3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x1e3>
  46108a:	mov    0x20(%rsp),%rdi
  46108f:	shlx   %rdi,0x98(%rsp,%rsi,8),%rdi
  461099:	or     %rdi,%r14
  46109c:	jmp    4610b3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x1e3>
  46109e:	xchg   %ax,%ax
  4610a0:	and    %r13,%rdi
  4610a3:	shrx   %r10,%rdi,%r14
  4610a8:	shlx   %rbx,%r14,%r14
  4610ad:	jmp    4610c0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x1f0>
  4610af:	nop
  4610b0:	xor    %r14d,%r14d
  4610b3:	and    %r11,%r14
  4610b6:	lea    0x1(%r14),%rdi
  4610ba:	and    %r12,%r14
  4610bd:	shr    $1,%rdi
  4610c0:	sub    %r14,%rdi
  4610c3:	test   %di,%di
  4610c6:	js     461801 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x931>
  4610cc:	mov    %edi,%r14d
  4610cf:	and    $0x7fff,%r14d
  4610d6:	cmp    %r14,%rbp
  4610d9:	jb     461801 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x931>
  4610df:	test   %di,%di
  4610e2:	je     461032 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x162>
  4610e8:	vmovdqu (%rcx),%ymm1
  4610ec:	vptest %ymm1,%ymm1
  4610f1:	jne    461020 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x150>
  4610f7:	vmovdqu 0x20(%rcx),%ymm1
  4610fc:	vptest %ymm1,%ymm1
  461101:	jne    461020 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x150>
  461107:	vmovdqu 0x40(%rcx),%ymm1
  46110c:	vptest %ymm1,%ymm1
  461111:	jne    461020 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x150>
  461117:	vmovdqu 0x60(%rcx),%ymm1
  46111c:	vptest %ymm1,%ymm1
  461121:	jne    461020 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x150>
  461127:	jmp    461032 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x162>
  46112c:	lea    0x8(,%rbp,8),%r12
  461134:	mov    $0x8,%edi
  461139:	xor    %edx,%edx
  46113b:	mov    %r12,%rsi
  46113e:	vzeroupper
  461141:	call   4b9670 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
  461146:	test   %rax,%rax
  461149:	je     461886 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9b6>
  46114f:	mov    %rbp,0x10(%rsp)
  461154:	mov    %rax,%rbx
  461157:	lea    0x1(%rbp),%rax
  46115b:	mov    $0x1,%r12d
  461161:	lea    0x60(%rsp),%r13
  461166:	movq   $0x0,(%rbx)
  46116d:	mov    0x8(%rsp),%r14
  461172:	mov    %rax,0x60(%rsp)
  461177:	mov    %rbx,0x68(%rsp)
  46117c:	movq   $0x1,0x70(%rsp)
  461185:	jmp    4611a2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x2d2>
  461187:	nopw   0x0(%rax,%rax,1)
  461190:	mov    %rbp,(%rbx,%r12,8)
  461194:	inc    %r12
  461197:	add    $0xfffffffffffffff8,%r14
  46119b:	mov    %r12,0x70(%rsp)
  4611a0:	je     4611c2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x2f2>
  4611a2:	mov    -0x8(%rbx,%r12,8),%rbp
  4611a7:	add    -0x8(%r15,%r12,8),%rbp
  4611ac:	cmp    0x60(%rsp),%r12
  4611b1:	jne    461190 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x2c0>
  4611b3:	mov    %r13,%rdi
  4611b6:	call   f4800 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCsii3nOZuAKF_15crossbeam_utils>
  4611bb:	mov    0x68(%rsp),%rbx
  4611c0:	jmp    461190 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x2c0>
  4611c2:	mov    %r15,%rdi
  4611c5:	call   *0x86d2d(%rip)        # 4e7ef8 <free@GLIBC_2.2.5>
  4611cb:	cmpq   $0x0,-0x8(%rbx,%r12,8)
  4611d1:	je     461252 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x382>
  4611d3:	cmp    %r12,0x10(%rsp)
  4611d8:	ja     461821 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x951>
  4611de:	mov    0x8(%rsp),%r14
  4611e3:	mov    $0x8,%edi
  4611e8:	xor    %edx,%edx
  4611ea:	mov    %r14,%rsi
  4611ed:	call   4b9670 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
  4611f2:	test   %rax,%rax
  4611f5:	je     461895 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9c5>
  4611fb:	mov    %rax,%r15
  4611fe:	movabs $0x7ffffffffffffff9,%rbp
  461208:	mov    %rax,%rdi
  46120b:	mov    %rbx,%rsi
  46120e:	mov    %r14,%rdx
  461211:	call   *0x86cc1(%rip)        # 4e7ed8 <memcpy@GLIBC_2.14>
  461217:	mov    -0x8(%rbx,%r12,8),%r14
  46121c:	lea    0x3(%rbp),%rcx
  461220:	lea    0x0(,%r14,4),%r13
  461228:	mov    %r14,%rax
  46122b:	shr    $0x3e,%rax
  46122f:	setne  %al
  461232:	cmp    %rcx,%r13
  461235:	seta   %cl
  461238:	or     %al,%cl
  46123a:	je     4614fa <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x62a>
  461240:	xor    %ebp,%ebp
  461242:	mov    %rbp,%rdi
  461245:	mov    %r13,%rsi
  461248:	call   edd91 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  46124d:	jmp    4618a2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9d2>
  461252:	mov    0x18(%rsp),%r15
  461257:	mov    $0x80,%eax
  46125c:	mov    $0x8,%edi
  461261:	xor    %edx,%edx
  461263:	shlx   %r15,%rax,%r14
  461268:	mov    %r14,%rsi
  46126b:	call   4b9670 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
  461270:	mov    0x10(%rsp),%r9
  461275:	test   %rax,%rax
  461278:	je     461895 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9c5>
  46127e:	mov    %rax,%rsi
  461281:	test   %r15,%r15
  461284:	je     461462 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x592>
  46128a:	lea    -0x1(%r9),%rdi
  46128e:	lea    0xd0(%rsp),%rcx
  461296:	lea    -0x2(%r9),%r8
  46129a:	mov    %rax,%rsi
  46129d:	mov    %edi,%edx
  46129f:	and    $0x7,%edx
  4612a2:	cmp    $0x6,%r8
  4612a6:	jbe    461420 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x550>
  4612ac:	and    $0xfffffffffffffff8,%rdi
  4612b0:	vxorps %xmm0,%xmm0,%xmm0
  4612b4:	mov    %rax,%rsi
  4612b7:	nopw   0x0(%rax,%rax,1)
  4612c0:	vmovups %zmm0,(%rcx)
  4612c6:	vmovups %zmm0,0x90(%rsp)
  4612d1:	vmovups %zmm0,(%rsi)
  4612d7:	vmovdqu64 0xd0(%rsp),%zmm1
  4612e2:	vmovups %zmm0,(%rcx)
  4612e8:	vmovups %zmm0,0x90(%rsp)
  4612f3:	vmovups 0xd0(%rsp),%zmm2
  4612fe:	vmovups %zmm0,(%rcx)
  461304:	vmovups %zmm0,0x90(%rsp)
  46130f:	vmovups 0xd0(%rsp),%zmm3
  46131a:	vmovups %zmm0,(%rcx)
  461320:	vmovups %zmm0,0x90(%rsp)
  46132b:	vmovdqu64 %zmm1,0x40(%rsi)
  461332:	vmovups %zmm0,0x80(%rsi)
  461339:	vmovups %zmm2,0xc0(%rsi)
  461340:	vmovups 0xd0(%rsp),%zmm2
  46134b:	vmovups %zmm0,(%rcx)
  461351:	vmovups %zmm0,0x90(%rsp)
  46135c:	vmovups %zmm0,0x100(%rsi)
  461363:	vmovups %zmm3,0x140(%rsi)
  46136a:	vmovups 0xd0(%rsp),%zmm3
  461375:	vmovups %zmm0,(%rcx)
  46137b:	vmovups %zmm0,0x90(%rsp)
  461386:	vmovups %zmm0,0x180(%rsi)
  46138d:	vmovups %zmm2,0x1c0(%rsi)
  461394:	vmovups 0xd0(%rsp),%zmm2
  46139f:	vmovups %zmm0,(%rcx)
  4613a5:	vmovups %zmm0,0x90(%rsp)
  4613b0:	vmovups %zmm0,0x200(%rsi)
  4613b7:	vmovups %zmm3,0x240(%rsi)
  4613be:	vmovups 0xd0(%rsp),%zmm3
  4613c9:	vmovups %zmm0,(%rcx)
  4613cf:	vmovups %zmm0,0x280(%rsi)
  4613d6:	vmovups %zmm0,0x90(%rsp)
  4613e1:	vmovups %zmm2,0x2c0(%rsi)
  4613e8:	vmovups 0xd0(%rsp),%zmm2
  4613f3:	vmovups %zmm0,0x300(%rsi)
  4613fa:	vmovups %zmm3,0x340(%rsi)
  461401:	vmovups %zmm0,0x380(%rsi)
  461408:	vmovups %zmm2,0x3c0(%rsi)
  46140f:	add    $0x400,%rsi
  461416:	add    $0xfffffffffffffff8,%rdi
  46141a:	jne    4612c0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x3f0>
  461420:	vxorps %xmm0,%xmm0,%xmm0
  461424:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  461430:	vmovups %zmm0,(%rcx)
  461436:	vmovups %zmm0,(%rsi)
  46143c:	vmovups %zmm0,0x90(%rsp)
  461447:	vmovdqu64 0xd0(%rsp),%zmm1
  461452:	vmovdqu64 %zmm1,0x40(%rsi)
  461459:	sub    $0xffffffffffffff80,%rsi
  46145d:	dec    %rdx
  461460:	jne    461430 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x560>
  461462:	mov    0x80(%rsp),%rcx
  46146a:	vxorps %xmm0,%xmm0,%xmm0
  46146e:	vmovups %zmm0,0x40(%rsi)
  461475:	vmovups %zmm0,(%rsi)
  46147b:	mov    %r9,(%rcx)
  46147e:	mov    %rax,0x8(%rcx)
  461482:	mov    %r9,0x10(%rcx)
  461486:	mov    0x60(%rsp),%rax
  46148b:	test   %rax,%rax
  46148e:	je     4617ec <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x91c>
  461494:	cmp    $0x3fff,%rax
  46149a:	jbe    4614dd <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x60d>
  46149c:	shl    $0x3,%rax
  4614a0:	movabs $0x7ffffffffffffff9,%rcx
  4614aa:	mov    %rax,%rsi
  4614ad:	or     $0x1,%rsi
  4614b1:	cmp    %rcx,%rsi
  4614b4:	jae    461961 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa91>
  4614ba:	cmpb   $0x1,(%rbx,%rax,1)
  4614be:	jne    4614dd <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x60d>
  4614c0:	mov    %rbx,%rdi
  4614c3:	add    $0x118,%rsp
  4614ca:	pop    %rbx
  4614cb:	pop    %r12
  4614cd:	pop    %r13
  4614cf:	pop    %r14
  4614d1:	pop    %r15
  4614d3:	pop    %rbp
  4614d4:	vzeroupper
  4614d7:	jmp    *0x86a13(%rip)        # 4e7ef0 <munmap@GLIBC_2.2.5>
  4614dd:	mov    %rbx,%rdi
  4614e0:	add    $0x118,%rsp
  4614e7:	pop    %rbx
  4614e8:	pop    %r12
  4614ea:	pop    %r13
  4614ec:	pop    %r14
  4614ee:	pop    %r15
  4614f0:	pop    %rbp
  4614f1:	vzeroupper
  4614f4:	jmp    *0x869fe(%rip)        # 4e7ef8 <free@GLIBC_2.2.5>
  4614fa:	test   %r13,%r13
  4614fd:	je     461540 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x670>
  4614ff:	mov    $0x4,%edi
  461504:	mov    $0x1,%edx
  461509:	mov    %r13,%rsi
  46150c:	mov    $0x4,%ebp
  461511:	call   4b9670 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
  461516:	mov    %rax,0x20(%rsp)
  46151b:	test   %rax,%rax
  46151e:	je     461242 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x372>
  461524:	mov    %r14,0x18(%rsp)
  461529:	mov    0x30(%rsp),%rdi
  46152e:	mov    %r14,0x28(%rsp)
  461533:	cmpq   $0x0,0x58(%rsp)
  461539:	jne    461569 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x699>
  46153b:	jmp    461755 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x885>
  461540:	mov    $0x4,%eax
  461545:	mov    %rax,0x20(%rsp)
  46154a:	movq   $0x0,0x18(%rsp)
  461553:	mov    0x30(%rsp),%rdi
  461558:	mov    %r14,0x28(%rsp)
  46155d:	cmpq   $0x0,0x58(%rsp)
  461563:	je     461755 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x885>
  461569:	mov    0x40(%rsp),%r8
  46156e:	movzbl 0x38(%rsp),%eax
  461573:	mov    $0xffffffffffffffff,%r10
  46157a:	vxorps %xmm0,%xmm0,%xmm0
  46157e:	mov    %r8,%rdx
  461581:	imul   0x48(%rsp),%rdx
  461587:	shl    $0x4,%eax
  46158a:	mov    %r8d,%r13d
  46158d:	add    %rax,%rdi
  461590:	mov    %rdi,%rax
  461593:	lea    -0x1(%rdx),%rcx
  461597:	mov    %ecx,%r9d
  46159a:	and    $0x3f,%r9d
  46159e:	mov    %rcx,%rsi
  4615a1:	shr    $0x6,%rsi
  4615a5:	lea    -0x40(%r8,%r9,1),%rdi
  4615aa:	mov    %r9,0x8(%rsp)
  4615af:	cmp    $0xffffffffffffffbf,%rdi
  4615b3:	setb   %dil
  4615b7:	cmp    $0xc0,%rcx
  4615be:	setb   %r9b
  4615c2:	and    $0x3f,%r13d
  4615c6:	and    %dil,%r9b
  4615c9:	mov    $0x1,%edi
  4615ce:	sub    %edx,%edi
  4615d0:	lea    0x1(%r8),%edx
  4615d4:	dec    %r8d
  4615d7:	mov    %r9b,0x30(%rsp)
  4615dc:	xor    %r9d,%r9d
  4615df:	and    $0x3f,%edi
  4615e2:	and    $0x3f,%r8d
  4615e6:	shlx   %rdx,%r10,%r11
  4615eb:	shlx   %r13,%r10,%r10
  4615f0:	mov    %rdi,0x38(%rsp)
  4615f5:	mov    %r8,0x40(%rsp)
  4615fa:	lea    0x8513f(%rip),%r8        # 4e6740 <__frame_dummy_init_array_entry+0x7530>
  461601:	mov    %r10,%rdx
  461604:	not    %r11
  461607:	not    %rdx
  46160a:	mov    %rax,%rdi
  46160d:	mov    %r8,0x78(%rsp)
  461612:	mov    0x50(%rsp),%r8
  461617:	mov    0x20(%rsp),%rbp
  46161c:	jmp    461639 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x769>
  46161e:	xchg   %ax,%ax
  461620:	mov    %rax,%rdi
  461623:	inc    %r9
  461626:	add    $0x20,%rdi
  46162a:	sub    $0xffffffffffffff80,%r8
  46162e:	cmp    %r9,0x58(%rsp)
  461633:	je     461755 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x885>
  461639:	vmovdqu (%rdi),%xmm1
  46163d:	mov    %rdi,%rax
  461640:	mov    (%rdi),%rdi
  461643:	cmpq   $0x0,0x48(%rsp)
  461649:	lea    0xa0(%rsp),%r14
  461651:	vmovdqa %xmm1,0x90(%rsp)
  46165a:	vmovaps %xmm0,(%r14)
  46165f:	je     4616a0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x7d0>
  461661:	cmp    $0xff,%rcx
  461668:	ja     4616c0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x7f0>
  46166a:	mov    0x8(%rsp),%rdi
  46166f:	cmpb   $0x0,0x30(%rsp)
  461674:	shrx   %rdi,0x90(%rsp,%rsi,8),%r14
  46167e:	je     4616c3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x7f3>
  461680:	mov    0x38(%rsp),%rdi
  461685:	shlx   %rdi,0x98(%rsp,%rsi,8),%rdi
  46168f:	or     %rdi,%r14
  461692:	jmp    4616c3 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x7f3>
  461694:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  4616a0:	mov    0x40(%rsp),%r14
  4616a5:	and    %rdx,%rdi
  4616a8:	shrx   %r14,%rdi,%r14
  4616ad:	shlx   %r13,%r14,%r14
  4616b2:	sub    %r14,%rdi
  4616b5:	test   %di,%di
  4616b8:	jne    4616dc <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x80c>
  4616ba:	jmp    461620 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x750>
  4616bf:	nop
  4616c0:	xor    %r14d,%r14d
  4616c3:	and    %r11,%r14
  4616c6:	lea    0x1(%r14),%rdi
  4616ca:	and    %r10,%r14
  4616cd:	shr    $1,%rdi
  4616d0:	sub    %r14,%rdi
  4616d3:	test   %di,%di
  4616d6:	je     461620 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x750>
  4616dc:	vmovdqu (%r8),%ymm1
  4616e1:	vptest %ymm1,%ymm1
  4616e6:	jne    461720 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x850>
  4616e8:	vmovdqu 0x20(%r8),%ymm1
  4616ee:	vptest %ymm1,%ymm1
  4616f3:	jne    461720 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x850>
  4616f5:	vmovdqu 0x40(%r8),%ymm1
  4616fb:	vptest %ymm1,%ymm1
  461700:	jne    461720 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x850>
  461702:	vmovdqu 0x60(%r8),%ymm1
  461708:	vptest %ymm1,%ymm1
  46170d:	je     461620 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x750>
  461713:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  461720:	movswq %di,%r14
  461724:	lea    -0x1(%r14),%rdi
  461728:	cmp    0x10(%rsp),%rdi
  46172d:	jae    46184d <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x97d>
  461733:	mov    -0x8(%r15,%r14,8),%rdi
  461738:	cmp    0x28(%rsp),%rdi
  46173d:	jae    461863 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x993>
  461743:	mov    %r9d,0x0(%rbp,%rdi,4)
  461748:	inc    %rdi
  46174b:	mov    %rdi,-0x8(%r15,%r14,8)
  461750:	jmp    461620 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x750>
  461755:	mov    %r12,(%rsp)
  461759:	mov    %rbx,%r9
  46175c:	mov    0x20(%rsp),%r14
  461761:	mov    0x80(%rsp),%rdi
  461769:	mov    0x50(%rsp),%rsi
  46176e:	mov    0x88(%rsp),%rdx
  461776:	mov    0x28(%rsp),%r8
  46177b:	mov    %r14,%rcx
  46177e:	vzeroupper
  461781:	call   2466d0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm22reduce_indexed_bucketsNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEB4_>
  461786:	mov    0x18(%rsp),%rax
  46178b:	movabs $0x7ffffffffffffff9,%rcx
  461795:	test   %rax,%rax
  461798:	je     4617d5 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x905>
  46179a:	cmp    $0x7fff,%rax
  4617a0:	jbe    4617cc <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x8fc>
  4617a2:	shl    $0x2,%rax
  4617a6:	add    $0x4,%rcx
  4617aa:	mov    %rax,%rsi
  4617ad:	or     $0x1,%rsi
  4617b1:	cmp    %rcx,%rsi
  4617b4:	jae    461961 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa91>
  4617ba:	cmpb   $0x1,(%r14,%rax,1)
  4617bf:	jne    4617cc <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x8fc>
  4617c1:	mov    %r14,%rdi
  4617c4:	call   *0x86726(%rip)        # 4e7ef0 <munmap@GLIBC_2.2.5>
  4617ca:	jmp    4617d5 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x905>
  4617cc:	mov    %r14,%rdi
  4617cf:	call   *0x86723(%rip)        # 4e7ef8 <free@GLIBC_2.2.5>
  4617d5:	mov    %r15,%rdi
  4617d8:	call   *0x8671a(%rip)        # 4e7ef8 <free@GLIBC_2.2.5>
  4617de:	mov    0x60(%rsp),%rax
  4617e3:	test   %rax,%rax
  4617e6:	jne    461494 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x5c4>
  4617ec:	add    $0x118,%rsp
  4617f3:	pop    %rbx
  4617f4:	pop    %r12
  4617f6:	pop    %r13
  4617f8:	pop    %r14
  4617fa:	pop    %r15
  4617fc:	pop    %rbp
  4617fd:	vzeroupper
  461800:	ret
  461801:	lea    -0x441095(%rip),%rdi        # 20773 <_RNvCs2bkUAOhDEmu_4zmij11STATIC_DATA+0x6373>
  461808:	lea    0x84f61(%rip),%rdx        # 4e6770 <__frame_dummy_init_array_entry+0x7560>
  46180f:	mov    $0x2b,%esi
  461814:	vzeroupper
  461817:	call   f0c40 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
  46181c:	jmp    4618a2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9d2>
  461821:	mov    0x10(%rsp),%rsi
  461826:	lea    0x84f2b(%rip),%rcx        # 4e6758 <__frame_dummy_init_array_entry+0x7548>
  46182d:	xor    %edi,%edi
  46182f:	mov    %r12,%rdx
  461832:	call   f0b70 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
  461837:	jmp    4618a2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9d2>
  461839:	lea    0x84f48(%rip),%rdx        # 4e6788 <__frame_dummy_init_array_entry+0x7578>
  461840:	mov    %rbp,%rsi
  461843:	vzeroupper
  461846:	call   efc1b <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
  46184b:	jmp    4618a2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9d2>
  46184d:	mov    0x10(%rsp),%rax
  461852:	lea    0x84ecf(%rip),%rcx        # 4e6728 <__frame_dummy_init_array_entry+0x7518>
  461859:	mov    %rax,0x28(%rsp)
  46185e:	mov    %rcx,0x78(%rsp)
  461863:	mov    0x28(%rsp),%rsi
  461868:	mov    0x78(%rsp),%rdx
  46186d:	vzeroupper
  461870:	call   efc1b <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
  461875:	jmp    4618a2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9d2>
  461877:	mov    0x8(%rsp),%rsi
  46187c:	mov    $0x8,%edi
  461881:	call   edd91 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  461886:	mov    $0x8,%edi
  46188b:	mov    %r12,%rsi
  46188e:	call   edd91 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  461893:	jmp    4618a2 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0x9d2>
  461895:	mov    $0x8,%edi
  46189a:	mov    %r14,%rsi
  46189d:	call   edd91 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  4618a2:	ud2
  4618a4:	cmpq   $0x0,0x18(%rsp)
  4618aa:	mov    %rax,%rbx
  4618ad:	je     461905 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa35>
  4618af:	mov    0x18(%rsp),%rsi
  4618b4:	mov    0x20(%rsp),%rdi
  4618b9:	mov    $0x4,%edx
  4618be:	shl    $0x2,%rsi
  4618c2:	call   e8b60 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
  4618c7:	jmp    461905 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa35>
  4618c9:	mov    0x8(%rsp),%rsi
  4618ce:	mov    $0x8,%edx
  4618d3:	mov    %r15,%rdi
  4618d6:	mov    %rax,%rbx
  4618d9:	call   e8b60 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
  4618de:	jmp    46190e <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa3e>
  4618e0:	mov    %rax,%rbx
  4618e3:	jmp    46190e <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa3e>
  4618e5:	mov    0x8(%rsp),%rsi
  4618ea:	mov    $0x8,%edx
  4618ef:	mov    %r15,%rdi
  4618f2:	mov    %rax,%rbx
  4618f5:	call   e8b60 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
  4618fa:	mov    %rbx,%rdi
  4618fd:	call   4de1c0 <_Unwind_Resume@plt>
  461902:	mov    %rax,%rbx
  461905:	mov    %r15,%rdi
  461908:	call   *0x865ea(%rip)        # 4e7ef8 <free@GLIBC_2.2.5>
  46190e:	mov    0x60(%rsp),%rax
  461913:	test   %rax,%rax
  461916:	je     461959 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa89>
  461918:	mov    0x68(%rsp),%rdi
  46191d:	cmp    $0x3fff,%rax
  461923:	jbe    461953 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa83>
  461925:	shl    $0x3,%rax
  461929:	movabs $0x7ffffffffffffff9,%rcx
  461933:	mov    %rax,%rsi
  461936:	or     $0x1,%rsi
  46193a:	cmp    %rcx,%rsi
  46193d:	jae    461961 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa91>
  46193f:	cmpb   $0x1,(%rdi,%rax,1)
  461943:	jne    461953 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner16hb_top_component+0xa83>
  461945:	call   *0x865a5(%rip)        # 4e7ef0 <munmap@GLIBC_2.2.5>
  46194b:	mov    %rbx,%rdi
  46194e:	call   4de1c0 <_Unwind_Resume@plt>
  461953:	call   *0x8659f(%rip)        # 4e7ef8 <free@GLIBC_2.2.5>
  461959:	mov    %rbx,%rdi
  46195c:	call   4de1c0 <_Unwind_Resume@plt>
  461961:	vzeroupper
  461964:	call   1108e0 <_RNvNtCs9k3SxhrAWiO_3std7process5abort>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
