
/home/ubuntu/src/zopro-perf-work/postgroup-phi176/links/sdk-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000459dd0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner3raw>:
  459dd0:	push   %rbp
  459dd1:	push   %r15
  459dd3:	push   %r14
  459dd5:	push   %r13
  459dd7:	push   %r12
  459dd9:	push   %rbx
  459dda:	push   %rax
  459ddb:	lea    -0x400(%rdx),%rax
  459de2:	mov    %r8,%r14
  459de5:	cmp    $0xfc00,%rax
  459deb:	jae    459e3c <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner3raw+0x6c>
  459ded:	mov    %r14,%rbx
  459df0:	shl    $0x5,%rbx
  459df4:	test   %r14,%r14
  459df7:	je     459e52 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner3raw+0x82>
  459df9:	mov    %rdi,(%rsp)
  459dfd:	mov    $0x8,%edi
  459e02:	mov    %rsi,%rbp
  459e05:	mov    %rdx,%r13
  459e08:	mov    %rcx,%r12
  459e0b:	mov    %rbx,%rsi
  459e0e:	xor    %edx,%edx
  459e10:	call   4b9670 <_RNvMs2_NtNtCsHW5vo2gROj_10zopro_core5alloc5linuxNtB5_9Allocator8allocate>
  459e15:	test   %rax,%rax
  459e18:	je     459ebc <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner3raw+0xec>
  459e1e:	mov    %rax,%r15
  459e21:	mov    %rax,%rdi
  459e24:	mov    %r12,%rsi
  459e27:	mov    %rbx,%rdx
  459e2a:	call   *0x8e0a8(%rip)        # 4e7ed8 <memcpy@GLIBC_2.14>
  459e30:	mov    (%rsp),%rdi
  459e34:	mov    %r13,%rdx
  459e37:	mov    %rbp,%rsi
  459e3a:	jmp    459e58 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner3raw+0x88>
  459e3c:	mov    %r14,%r8
  459e3f:	add    $0x8,%rsp
  459e43:	pop    %rbx
  459e44:	pop    %r12
  459e46:	pop    %r13
  459e48:	pop    %r14
  459e4a:	pop    %r15
  459e4c:	pop    %rbp
  459e4d:	jmp    229b00 <_RINvNtCsHW5vo2gROj_10zopro_core10msm_affine7msm_rawNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEB4_>
  459e52:	mov    $0x8,%r15d
  459e58:	mov    %r15,%rcx
  459e5b:	mov    %r14,%r8
  459e5e:	call   459ef0 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner6hb_raw>
  459e63:	test   %r14,%r14
  459e66:	je     459ead <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner3raw+0xdd>
  459e68:	cmp    $0xfff,%r14
  459e6f:	jbe    459e96 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner3raw+0xc6>
  459e71:	cmpb   $0x1,(%r15,%rbx,1)
  459e76:	jne    459e96 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner3raw+0xc6>
  459e78:	or     $0x1,%rbx
  459e7c:	mov    %r15,%rdi
  459e7f:	mov    %rbx,%rsi
  459e82:	add    $0x8,%rsp
  459e86:	pop    %rbx
  459e87:	pop    %r12
  459e89:	pop    %r13
  459e8b:	pop    %r14
  459e8d:	pop    %r15
  459e8f:	pop    %rbp
  459e90:	jmp    *0x8e05a(%rip)        # 4e7ef0 <munmap@GLIBC_2.2.5>
  459e96:	mov    %r15,%rdi
  459e99:	add    $0x8,%rsp
  459e9d:	pop    %rbx
  459e9e:	pop    %r12
  459ea0:	pop    %r13
  459ea2:	pop    %r14
  459ea4:	pop    %r15
  459ea6:	pop    %rbp
  459ea7:	jmp    *0x8e04b(%rip)        # 4e7ef8 <free@GLIBC_2.2.5>
  459ead:	add    $0x8,%rsp
  459eb1:	pop    %rbx
  459eb2:	pop    %r12
  459eb4:	pop    %r13
  459eb6:	pop    %r14
  459eb8:	pop    %r15
  459eba:	pop    %rbp
  459ebb:	ret
  459ebc:	mov    $0x8,%edi
  459ec1:	mov    %rbx,%rsi
  459ec4:	call   edd91 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  459ec9:	mov    %rax,%r12
  459ecc:	test   %r14,%r14
  459ecf:	je     459ee1 <_RNvNtNtCsHW5vo2gROj_10zopro_core10msm_affine9g2_horner3raw+0x111>
  459ed1:	mov    $0x8,%edx
  459ed6:	mov    %r15,%rdi
  459ed9:	mov    %rbx,%rsi
  459edc:	call   e8b60 <_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc>
  459ee1:	mov    %r12,%rdi
  459ee4:	call   4de1c0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
