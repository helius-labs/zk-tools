//! Lane movement and zero detection only; no new field arithmetic.
use super::*;
impl<C:FpConfig,const MIXED:bool> Ifma8<C,MIXED> {
    /// Padding contributes a multiplicative identity to each lane chain.
    #[inline(always)]
    pub fn tree_active_norm(&self,active:u8)->Self{unsafe{let one=Self::one();Self(core::array::from_fn(|j|_mm512_mask_mov_epi64(one.0[j],active,self.0[j])),PhantomData)}}
    /// Split sixteen contiguous values into eight adjacent-pair sides.
    #[inline(always)]
    pub fn tree_adjacent(a:&Self,b:&Self)->(Self,Self) {
        unsafe {
            let even=_mm512_set_epi64(14,12,10,8,6,4,2,0);
            let odd=_mm512_set_epi64(15,13,11,9,7,5,3,1);
            (Self(core::array::from_fn(|i|_mm512_permutex2var_epi64(a.0[i],even,b.0[i])),PhantomData),
             Self(core::array::from_fn(|i|_mm512_permutex2var_epi64(a.0[i],odd,b.0[i])),PhantomData))
        }
    }
    /// Normalized values strictly below 2p represent zero as 0 or p.
    #[inline(always)]
    pub fn tree_zero_mask(&self)->u8 {
        unsafe {
            let mut zero=0xffu8;let mut modulus=0xffu8;let p=split(C::P);
            for j in 0..5 {
                zero&=_mm512_cmpeq_epi64_mask(self.0[j],Self::splat(0));
                modulus&=_mm512_cmpeq_epi64_mask(self.0[j],Self::splat(p[j]));
            }
            zero|modulus
        }
    }
}
impl<C:FpConfig,const MIXED:bool> PackedIfma8<C,MIXED>{
    #[inline(always)]
    pub fn tree_adjacent_compact(&self,b:&Self)->(Ifma8<C,MIXED>,Ifma8<C,MIXED>){unsafe{
        let even=_mm512_set_epi64(14,12,10,8,6,4,2,0);let odd=_mm512_set_epi64(15,13,11,9,7,5,3,1);
        let x=Self(core::array::from_fn(|i|_mm512_permutex2var_epi64(self.0[i],even,b.0[i])),PhantomData);
        let y=Self(core::array::from_fn(|i|_mm512_permutex2var_epi64(self.0[i],odd,b.0[i])),PhantomData);
        (x.expand(),y.expand())
    }}
    #[inline(always)]
    pub fn tree_copy_lane(&self,src:&Self,from:usize,to:usize)->Self{assert!(from<8&&to<8);unsafe{
        let index=_mm512_set1_epi64(from as i64);let mask=1u8<<to;
        Self(core::array::from_fn(|j|_mm512_mask_mov_epi64(self.0[j],mask,_mm512_permutexvar_epi64(index,src.0[j]))),PhantomData)
    }}
}
#[cfg(test)]mod tests {
use super::*;
fn check<C:FpConfig,const M:bool>() {
    for offset in 0..32u64 {
        let a=core::array::from_fn(|i|Fp::<C>::from(offset+1+i as u64));
        let b=core::array::from_fn(|i|Fp::<C>::from(offset+9+i as u64));
        let(x,y)=Ifma8::<C,M>::tree_adjacent(&Ifma8::new(&a),&Ifma8::new(&b));
        let all=[a,b].concat();assert_eq!(x.get(),core::array::from_fn(|i|all[2*i]));assert_eq!(y.get(),core::array::from_fn(|i|all[2*i+1]));
        let values=core::array::from_fn(|i|if (offset>>i)&1==0{Fp::<C>::ZERO}else{Fp::<C>::from((i+1)as u64)});
        let v=Ifma8::<C,M>::new(&values);assert_eq!(v.tree_zero_mask(),!(offset as u8));assert_eq!(v.sub(&v).tree_zero_mask(),255);
    }
    if M {
        let p=split(C::P);unsafe{
            let raw=Ifma8::<C,M>(core::array::from_fn(|j|_mm512_set_epi64(0,p[j]as i64,0,p[j]as i64,0,p[j]as i64,0,p[j]as i64)),PhantomData);
            assert_eq!(raw.tree_zero_mask(),255);
        }
    }
}
#[test]fn lane_pairing_and_zero_masks_all_fields_radices(){check::<crate::FqConfig,true>();check::<crate::FrConfig,true>();check::<crate::FqConfig,false>();check::<crate::FrConfig,false>();}
fn compact<C:FpConfig,const M:bool>(){
    fn words<C:FpConfig,const M:bool>(x:&Ifma8<C,M>)->[[u64;5];8]{let mut limbs=[[0u64;8];5];unsafe{for j in 0..5{_mm512_storeu_si512(limbs[j].as_mut_ptr().cast(),x.0[j]);}}core::array::from_fn(|i|core::array::from_fn(|j|limbs[j][i]))}
    let p=C::P;let two_p=crate::portable::add4(p,p).0;let pm1=crate::portable::sub4(p,[1,0,0,0]).0;let pp1=crate::portable::add4(p,[1,0,0,0]).0;let max=crate::portable::sub4(two_p,[1,0,0,0]).0;
    let edges=[[0;4],pm1,p,pp1,max,[1,0,0,0],[1u64<<52,0,0,0],[0,0,0,1u64<<48]];
    for offset in 0..16{
        let aa=core::array::from_fn(|i|edges[(offset+i)%8]);let bb=core::array::from_fn(|i|edges[(offset+3*i+1)%8]);
        let a=Ifma8::<C,M>::raw(&aa);let b=Ifma8::<C,M>::raw(&bb);let ap=a.compact();let bp=b.compact();
        let(x,y)=ap.tree_adjacent_compact(&bp);let aw=words(&a);let bw=words(&b);let all=[aw,bw].concat();
        assert_eq!(words(&x),core::array::from_fn(|i|all[i*2]));assert_eq!(words(&y),core::array::from_fn(|i|all[i*2+1]));
        for from in 0..8{for to in 0..8{let mut expected=aw;expected[to]=bw[from];assert_eq!(words(&ap.tree_copy_lane(&bp,from,to).expand()),expected);}}
        let one=words(&Ifma8::<C,M>::one());for mask in 0..=255u8{let want=core::array::from_fn(|i|if mask>>i&1!=0{aw[i]}else{one[i]});assert_eq!(words(&a.tree_active_norm(mask)),want);}
    }
}
#[test]fn compact_pairing_carries_and_all_active_masks_preserve_raw_words(){compact::<crate::FqConfig,true>();compact::<crate::FrConfig,true>();compact::<crate::FqConfig,false>();compact::<crate::FrConfig,false>();}
}

