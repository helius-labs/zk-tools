// Indexed-query integration: one bounded leaf, charged inside the original forecast.
use std::cell::Cell;
use std::sync::OnceLock;
thread_local!{static TRACE:Cell<[[usize;5];2]>=const{Cell::new([[0;5];2])};}
fn enabled()->bool{static ON:OnceLock<bool>=OnceLock::new();*ON.get_or_init(||std::env::var("ZOPRO_CPU_COMPACT_INDEXED_TREE").as_deref()==Ok("1"))}
fn note(curve:usize,n:usize,bytes:usize,entered:bool){TRACE.with(|c|{let mut all=c.get();let a=&mut all[curve];a[0]=a[0].saturating_add(1);let k=if entered{1}else{2};a[k]=a[k].saturating_add(1);a[3]=a[3].max(n);a[4]=a[4].max(bytes);c.set(all);});}
pub(super) fn snapshot()->[[usize;5];2]{let mut total=TRACE.with(Cell::get);for row in rayon::broadcast(|_|TRACE.with(Cell::get)){for c in 0..2{for i in 0..3{total[c][i]=total[c][i].saturating_add(row[c][i]);}for i in 3..5{total[c][i]=total[c][i].max(row[c][i]);}}}total}
fn forecast<C:CurveConfig>(n:usize)->Option<(usize,usize)>where C::Base:PackedBase{
    use crate::msm_affine::workspace::vector as v;
    let tile=2048/(core::mem::size_of::<C::Base>()/32);
    // At least one full SIMD pair group. The maximum is the existing indexed tile.
    if n<16||n>tile{return None;}
    let packed=v::<Point<C::Base>>(n.div_ceil(8),false)?;
    let prefix=v::<[FqBatch;2]>((n/2).div_ceil(8),false)?;
    let tail=v::<usize>(4,false)?;
    // Empty original/group/prefix Vec headers remain in Work; their payloads do not.
    let headers=3usize.checked_mul(core::mem::size_of::<Vec<u8>>())?;
    let requested=packed.checked_add(prefix)?.checked_add(tail)?.checked_add(headers)?;
    let original=super::workspace_grouping::<C>(n,1)?;
    (requested<=original).then_some((requested,original))
}
pub(super) fn try_indexed<C:CurveConfig>(bases:&[Affine<C>],order:&[u32])->Option<Affine<C>>where C::Base:PackedBase{
    if !enabled(){return None;}
    attempt::<C>(bases,order)
}
fn attempt<C:CurveConfig>(bases:&[Affine<C>],order:&[u32])->Option<Affine<C>>where C::Base:PackedBase{
    let (bytes,_)=forecast::<C>(order.len())?;
    let mut work=Work::<C>::default();
    let value=work.packed_by(order.len(),|i|bases[order[i]as usize]);
    note(C::Base::CURVE,order.len(),bytes,value.is_some());
    // Work is dropped before the caller constructs the original fallback.
    value
}
#[cfg(test)]mod integration_tests{
use super::*;
fn check<C:CurveConfig>()where C::Base:PackedBase{
    let tile=2048/(core::mem::size_of::<C::Base>()/32);for n in 16..=tile{let(new,old)=forecast::<C>(n).unwrap();assert!(new<=old);}for n in[0,1,8,9,15,tile+1,usize::MAX]{assert!(forecast::<C>(n).is_none());}
    let g=Projective::<C>::generator();let points=Projective::<C>::batch_to_affine(&(0..tile+1).map(|i|g*Fr::from(i as u64+100003)).collect::<Vec<_>>());let before=points.clone();
    for n in[16,17,31,63,255,256,tile-1,tile]{let order=(0..n).map(|i|((i*37+7)%(tile+1))as u32).collect::<Vec<_>>();let sum=order.iter().fold(Projective::<C>::IDENTITY,|s,&i|s+points[i as usize]).to_affine();assert_eq!(attempt::<C>(&points,&order),Some(sum));let starts=[0,0,n/3,n/3,n];let reduced=super::super::reduce_indexed_buckets::<C>(&points,&order,&starts);assert_eq!(reduced.len(),4);for i in 0..4{let expected=order[starts[i]..starts[i+1]].iter().fold(Projective::<C>::IDENTITY,|s,&j|s+points[j as usize]).to_affine();assert_eq!(reduced[i],expected);}}
    let mut edge=points.clone();for(i,s)in[Fr::from(3),Fr::from(5),Fr::from(11),-Fr::from(19)].into_iter().enumerate(){edge[i]=(g*s).to_affine();}let order=(0..255).map(|i|i as u32).collect::<Vec<_>>();assert!(attempt::<C>(&edge,&order).is_none());let fallback=super::super::reduce_indexed_buckets::<C>(&edge,&order,&[0,255]);assert_eq!(fallback[0],edge[..255].iter().fold(Projective::<C>::IDENTITY,|s,p|s+*p).to_affine());assert_eq!(points,before);
}
#[test]fn indexed_g1_charge_geometry_and_complete_fallback(){check::<G1Config>();}
#[test]fn indexed_g2_charge_geometry_and_complete_fallback(){check::<G2Config>();}
}
