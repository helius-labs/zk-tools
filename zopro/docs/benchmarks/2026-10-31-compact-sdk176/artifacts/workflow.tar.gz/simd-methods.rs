    #[cfg(zopro_packed_tree)]
    #[inline(always)]
    pub(crate) fn tree_adjacent(a:&Self,b:&Self)->(Self,Self){let(x,y)=zopro_bn254::ifma8::Ifma8::tree_adjacent(&a.0,&b.0);(Self(x),Self(y))}
    #[cfg(zopro_packed_tree)]
    #[inline(always)]
    pub(crate) fn tree_zero_mask(&self)->u8{self.0.tree_zero_mask()}
    #[inline(always)]
    pub(crate) fn tree_compact(&self)->zopro_bn254::ifma8::PackedIfma8<FqConfig,true>{self.0.compact()}
    #[inline(always)]
    pub(crate) fn tree_expand(a:&zopro_bn254::ifma8::PackedIfma8<FqConfig,true>)->Self{Self(a.expand())}
    #[inline(always)]
    pub(crate) fn tree_adjacent_compact(a:&zopro_bn254::ifma8::PackedIfma8<FqConfig,true>,b:&zopro_bn254::ifma8::PackedIfma8<FqConfig,true>)->(Self,Self){
        #[cfg(zopro_packed_tree)]{let(x,y)=a.tree_adjacent_compact(b);(Self(x),Self(y))}
        #[cfg(not(zopro_packed_tree))]{let x=a.expand().get();let y=b.expand().get();let all=[x,y].concat();(Self::new(&core::array::from_fn(|i|all[2*i])),Self::new(&core::array::from_fn(|i|all[2*i+1])))}
    }
    #[inline(always)]
    pub(crate) fn tree_copy_compact_lane(dst:&zopro_bn254::ifma8::PackedIfma8<FqConfig,true>,src:&zopro_bn254::ifma8::PackedIfma8<FqConfig,true>,from:usize,to:usize)->zopro_bn254::ifma8::PackedIfma8<FqConfig,true>{
        #[cfg(zopro_packed_tree)]{dst.tree_copy_lane(src,from,to)}
        #[cfg(not(zopro_packed_tree))]{let mut d=dst.expand().get();d[to]=src.expand().get()[from];Self::new(&d).tree_compact()}
    }
    #[cfg(zopro_packed_tree)]
    #[inline(always)]
    pub(crate) fn tree_active_norm(&self,active:u8)->Self{Self(self.0.tree_active_norm(active))}

