use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g2-tree-store176";
const P: &str = "/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let r = Path::new(R);
    assert!(!r.join("build-plan.json").exists());
    let old = read(Path::new(P).join("build-plan.json"));
    let mut steps = vec![];
    for label in ["control", "candidate"] {
        let flags = fs::read_to_string(r.join(if label == "control" {
            "native-flags.txt"
        } else {
            "candidate-flags.txt"
        }))
        .unwrap();
        for name in [
            "candidate-core",
            "libraries-candidate",
            "freeze-candidate",
            "candidate",
        ] {
            let s = old["steps"]
                .as_array()
                .unwrap()
                .iter()
                .find(|s| s["name"] == name)
                .unwrap();
            let mut s: Value = serde_json::from_str(
                &serde_json::to_string(s)
                    .unwrap()
                    .replace(P, R)
                    .replace("candidate", label),
            )
            .unwrap();
            if let Some(env) = s.get_mut("environment") {
                env["RUSTFLAGS"] = json!(flags);
            }
            if name == "candidate" {
                s["driver"] = json!(r.join("driver.rs"));
                s["additional_sources"] = json!([r.join("perf_support.rs")]);
            }
            steps.push(s);
        }
    }
    assert_eq!(steps.len(), 8);
    let audit = read(r.join("source-audit.json"));
    let mut pins = BTreeMap::new();
    for (rel, h) in audit["source_files_sha256"].as_object().unwrap() {
        let file = r.join("source").join(rel);
        assert_eq!(hash(&file), h.as_str().unwrap());
        pins.insert(file.display().to_string(), h.as_str().unwrap().to_string());
    }
    let accepted=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    for (rel, h) in accepted["source_files_sha256"].as_object().unwrap() {
        assert_eq!(hash(Path::new(Z).join(rel)), h.as_str().unwrap());
    }
    for n in [
        "setup.rs",
        "setup",
        "native.rs",
        "native-helper",
        "tree_store.rs",
        "tree_probe.rs",
        "driver.rs",
        "perf_support.rs",
        "prepare-build.rs",
        "prepare-build",
        "source-audit.json",
        "design.md",
        "native-flags.txt",
        "candidate-flags.txt",
    ] {
        let p = r.join(n);
        pins.insert(p.display().to_string(), hash(p));
    }
    let field_receipt="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/native/candidate-field/tests.json";
    let field = read(field_receipt);
    assert_eq!(field["unfiltered"], true);
    assert_eq!(field["passed_tests"].as_array().unwrap().len(), 35);
    pins.insert(field_receipt.into(), hash(field_receipt));
    fs::write(
        r.join("build-pins.json"),
        serde_json::to_vec_pretty(&pins).unwrap(),
    )
    .unwrap();
    fs::write(
        r.join("build-plan.json"),
        serde_json::to_vec_pretty(
            &json!({"version":1,"source_pins":r.join("build-pins.json"),"steps":steps}),
        )
        .unwrap(),
    )
    .unwrap();
    println!("Prepared8OFF/ONnativecore/library/freeze/callerlinks;allfieldsourceexact,35fieldtests inherited;178privatefiles/{}pins",pins.len());
}
