use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::{Path, PathBuf},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g2-tree-store176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn check(values: &[f64], s: &Value) {
    let mut v = values.to_vec();
    v.sort_by(f64::total_cmp);
    for (k, i) in [("median", 7), ("lower", 3), ("upper", 11)] {
        assert!((s[k].as_f64().unwrap() - v[i]).abs() < 1e-8);
    }
    assert_eq!(s["wins"], values.iter().filter(|&&x| x < 1.0).count());
}
fn main() {
    assert!(!r("review.json").exists());
    for file in ["build-pins.json", "caller-pins.json"] {
        for (p, h) in read(r(file)).as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
    }
    let audit = read(r("source-audit.json"));
    let source = audit["source_files_sha256"].as_object().unwrap();
    assert_eq!(source.len(), 178);
    for (rel, h) in source {
        assert_eq!(hash(r("source").join(rel)), h.as_str().unwrap());
    }
    let manifest=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let mut exact = 0;
    let mut changed = vec![];
    for (rel, h) in manifest["source_files_sha256"].as_object().unwrap() {
        assert_eq!(hash(Path::new(Z).join(rel)), h.as_str().unwrap());
        if source[rel] == *h {
            exact += 1;
        } else {
            changed.push(rel);
        }
    }
    assert_eq!(exact, 173);
    assert_eq!(changed.len(), 3);
    assert_eq!(audit["field_files_exact"], 18);
    for label in ["control", "candidate"] {
        let receipt = read(r(format!("native/{label}/artifacts.json")));
        assert_eq!(
            hash(receipt["binary"].as_str().unwrap()),
            receipt["binary_sha256"]
        );
        for (p, h) in receipt["input_pins"].as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
        let tests = read(r(format!("native/{label}-core/tests.json")));
        assert_eq!(tests["unfiltered"], true);
        assert_eq!(
            tests["passed_tests"].as_array().unwrap().len(),
            if label == "control" { 127 } else { 129 }
        );
    }
    let plan = read(r("caller-plan.json"));
    let result = read(r("runs/result.json"));
    assert_eq!(result["status"], "complete");
    let a = read(r("caller-analysis.json"));
    let rows = a["rows"].as_array().unwrap();
    assert_eq!(rows.len(), 180);
    assert_eq!(plan["steps"].as_array().unwrap().len(), 180);
    let mut table = BTreeMap::<(String, String, usize), f64>::new();
    let mut names = BTreeSet::new();
    let (mut calls, mut checked) = (0u64, 0u64);
    for row in rows {
        let job = &row["job"];
        let name = job["name"].as_str().unwrap();
        assert!(names.insert(name));
        assert!(result["steps"].as_array().unwrap().contains(&json!(name)));
        let p = r(format!("runs/{name}/stdout.log"));
        assert_eq!(hash(&p), row["stdout_sha256"]);
        let raw = fs::read_to_string(p).unwrap();
        let mut lines = raw.lines().filter_map(|x| x.strip_prefix("CALLER "));
        let v: Value = serde_json::from_str(lines.next().unwrap()).unwrap();
        assert!(lines.next().is_none());
        assert_eq!(v, row["receipt"]);
        let step = plan["steps"]
            .as_array()
            .unwrap()
            .iter()
            .find(|s| s["name"] == name)
            .unwrap();
        let cmd = read(r(format!("runs/{name}/command.json")));
        assert_eq!(cmd["environment"], step["environment"]);
        assert_eq!(
            &cmd["argv"].as_array().unwrap()[4..],
            step["argv"].as_array().unwrap()
        );
        let workers = v["workers"].as_u64().unwrap();
        let block = job["block"].as_u64().unwrap() as usize;
        assert_eq!(v["points"], job["case"]["points"]);
        assert_eq!(v["workers"], job["case"]["workers"]);
        assert_eq!(v["iterations"], 128);
        assert_eq!(v["priming_per_worker"], 3);
        assert_eq!(v["complete_tree_calls"], workers * 131);
        assert_eq!(v["timed_new_proofs"], 0);
        assert_eq!(v["all_generator_outputs_verified"], true);
        let wave = v["wave_ns"].as_u64().unwrap();
        let ns = wave as f64 / 128.0;
        assert_eq!(ns, v["wave_ns_per_iteration"].as_f64().unwrap());
        assert!(table
            .insert(
                (
                    job["case"]["name"].as_str().unwrap().into(),
                    job["variant"].as_str().unwrap().into(),
                    block
                ),
                ns
            )
            .is_none());
        calls += workers * 131;
        checked += workers * 4;
    }
    let mut primary = vec![1f64; 15];
    let mut context_ok = true;
    for (c, s) in a["cases"].as_object().unwrap() {
        let off = (0..15)
            .map(|b| table[&(c.clone(), "control".into(), b)])
            .collect::<Vec<_>>();
        let on = (0..15)
            .map(|b| table[&(c.clone(), "candidate".into(), b)])
            .collect::<Vec<_>>();
        check(&off, &s["control_ns"]);
        check(&on, &s["candidate_ns"]);
        let ratios = on
            .iter()
            .zip(off.iter())
            .map(|(a, b)| a / b)
            .collect::<Vec<_>>();
        check(&ratios, &s["candidate_over_control"]);
        context_ok &= s["candidate_over_control"]["upper"].as_f64().unwrap() <= 1.03;
        if c.ends_with("-w32") {
            for (b, x) in ratios.iter().enumerate() {
                primary[b] *= x.sqrt();
            }
        }
    }
    check(&primary, &a["primary_equal_log_32"]);
    let gate = context_ok
        && a["primary_equal_log_32"]["upper"].as_f64().unwrap() < 1.0
        && a["primary_equal_log_32"]["wins"].as_u64().unwrap() >= 10;
    assert!(!gate);
    assert_eq!(a["caller_gate_passed"], gate);
    assert_eq!(a["complete_tree_calls"], calls);
    assert_eq!(calls, 385140);
    assert_eq!(checked, 11760);
    let proof=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/proof-sha256-after.json"));
    let out = json!({"passed":true,"source_files":178,"accepted_originals_exact":exact,"changed_parents":changed,"production176_unchanged":true,"field_files_exact":18,"core_tests_OFF_ON":[127,129],"processes":180,"complete_tree_calls":calls,"prime_and_final_checks":checked,"independently_recomputed_gate":gate,"new_proofs":0,"canonical_ledger_file_sha256":hash(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/proof-sha256-after.json")),"ledger_value_kind":if proof.is_object(){"object"}else{"array"},"scope":"Independent raw receipt/command/hash/arithmetic review; no new native test, timing, profile or proof."});
    fs::write(r("review.json"), serde_json::to_vec_pretty(&out).unwrap()).unwrap();
    println!("Independent review PASS;180raw receipts/commands/sixcase+aggregate bounds/production178vs176;gate remains false");
}
