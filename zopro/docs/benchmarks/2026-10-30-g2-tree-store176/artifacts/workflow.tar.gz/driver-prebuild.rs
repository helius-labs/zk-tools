use std::{
    fs,
    sync::{
        atomic::{AtomicU64, Ordering},
        Arc, Barrier,
    },
    time::Instant,
};
use zopro_bn254::{Fr, G2Projective};
#[path = "perf_support.rs"]
mod perf;
#[global_allocator]
static ALLOCATOR: zopro_core::alloc::Allocator = zopro_core::alloc::Allocator;

fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    assert_eq!(args.len(), 4);
    let n = args[1].parse::<usize>().unwrap();
    let workers = args[2].parse::<usize>().unwrap();
    let iterations = args[3].parse::<usize>().unwrap();
    assert!([256, 1024].contains(&n));
    assert!([1, 16, 32].contains(&workers));
    assert!(iterations > 0);
    let mut seed = 0x91f3_7a52_0ce4_668bu64;
    let weights = (0..n)
        .map(|_| {
            let mut bytes = [0; 64];
            for chunk in bytes.chunks_mut(8) {
                seed ^= seed << 13;
                seed ^= seed >> 7;
                seed ^= seed << 17;
                chunk.copy_from_slice(&seed.to_le_bytes());
            }
            Fr::from_random_bytes(&bytes)
        })
        .collect::<Vec<_>>();
    let g = G2Projective::generator();
    let points = Arc::new(G2Projective::batch_to_affine(
        &weights.iter().map(|s| g * *s).collect::<Vec<_>>(),
    ));
    let original = points.clone();
    let expected = (g * weights.iter().fold(Fr::ZERO, |a, b| a + *b)).to_affine();
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(workers)
        .stack_size(1024 * 1024)
        .build()
        .unwrap();
    let ready = Arc::new(Barrier::new(workers + 1));
    let start = Arc::new(Barrier::new(workers + 1));
    let done = Arc::new(Barrier::new(workers + 1));
    let release = Arc::new(Barrier::new(workers + 1));
    let times = Arc::new((0..workers).map(|_| AtomicU64::new(0)).collect::<Vec<_>>());
    let mut control = perf::Control::from_env().unwrap();
    let mut wave_ns = 0;
    let mut usage = serde_json::Value::Null;
    pool.scope(|scope| {
        for worker in 0..workers {
            let points = points.clone();
            let ready = ready.clone();
            let start = start.clone();
            let done = done.clone();
            let release = release.clone();
            let times = times.clone();
            scope.spawn(move |_| {
                let mut fixture = zopro_core::TreeFixture::new(&points, &[n]).unwrap();
                for _ in 0..3 {
                    fixture.run();
                    assert_eq!(fixture.outputs(), vec![expected]);
                }
                ready.wait();
                start.wait();
                let began = Instant::now();
                for _ in 0..iterations {
                    fixture.run();
                    std::hint::black_box(&fixture);
                }
                times[worker].store(began.elapsed().as_nanos() as u64, Ordering::Relaxed);
                done.wait();
                release.wait();
                assert_eq!(fixture.outputs(), vec![expected]);
            });
        }
        ready.wait();
        if let Some(c) = control.as_mut() {
            c.enable().unwrap();
        }
        let before = perf::Usage::now().unwrap();
        let began = Instant::now();
        start.wait();
        done.wait();
        wave_ns = began.elapsed().as_nanos() as u64;
        let after = perf::Usage::now().unwrap();
        if let Some(c) = control.as_mut() {
            c.disable().unwrap();
        }
        usage = after.difference(&before);
        release.wait();
    });
    assert_eq!(&*points, &*original);
    let thread_ns = times
        .iter()
        .map(|x| x.load(Ordering::Relaxed))
        .collect::<Vec<_>>();
    assert!(thread_ns.iter().all(|t| *t > 0));
    let result = serde_json::json!({"points":n,"workers":workers,"iterations":iterations,"priming_per_worker":3,"complete_tree_calls":workers*(iterations+3),"all_generator_outputs_verified":true,"wave_ns":wave_ns,"wave_ns_per_iteration":wave_ns as f64/iterations as f64,"worker_ns":thread_ns,"usage":usage,"input_reset_included":true,"timed_new_proofs":0});
    println!("CALLER {result}");
    if let Some(path) = std::env::var_os("ZOPRO_CALLER_RECEIPT") {
        fs::write(path, serde_json::to_vec_pretty(&result).unwrap()).unwrap();
    }
}
