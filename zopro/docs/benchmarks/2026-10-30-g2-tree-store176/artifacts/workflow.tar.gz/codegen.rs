use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path, process::Command};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g2-tree-store176";
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    let r = Path::new(R);
    assert!(!r.join("codegen.json").exists());
    let result: Value = serde_json::from_slice(&fs::read(r.join("native/result.json")).unwrap()).unwrap();
    assert_eq!(result["status"], "complete");
    let mut variants = BTreeMap::new();
    for label in ["control", "candidate"] {
        let binary = r.join(format!("native/{label}-sdk"));
        let nm = Command::new("nm").args(["-S", "--defined-only"]).arg(&binary).output().unwrap();
        assert!(nm.status.success());
        fs::write(r.join(format!("{label}.nm")), &nm.stdout).unwrap();
        let nm = String::from_utf8(nm.stdout).unwrap();
        let mut functions = vec![];
        for line in nm.lines() {
            let words = line.split_whitespace().collect::<Vec<_>>();
            if words.len() != 4 { continue; }
            let name = format!("{:#}", rustc_demangle::demangle(words[3]));
            let reducer = name.starts_with("zopro_core::msm::reduce_layer::<");
            let caller = name == "<zopro_core::msm::tree_store_probe::TreeFixture>::run";
            if !reducer && !caller { continue; }
            let start = u64::from_str_radix(words[0], 16).unwrap();
            let size = u64::from_str_radix(words[1], 16).unwrap();
            let output = Command::new("objdump").args(["-d", "-w", "--insn-width=16", "-M", "intel"])
                .arg(format!("--start-address={start}"))
                .arg(format!("--stop-address={}", start+size)).arg(&binary).output().unwrap();
            assert!(output.status.success());
            let text = String::from_utf8(output.stdout).unwrap();
            let file = format!("{label}-{}.asm", if reducer {"reduce"} else {"run"});
            fs::write(r.join(&file), &text).unwrap();
            let mut opcodes = BTreeMap::<String, usize>::new();
            let mut rsp_operands = 0;
            let mut instructions = 0;
            for line in text.lines() {
                let fields = line.split('\t').collect::<Vec<_>>();
                if fields.len() < 3 { continue; }
                let instruction = fields.last().unwrap().trim();
                if instruction.is_empty() { continue; }
                let opcode = instruction.split_whitespace().next().unwrap();
                instructions += 1;
                *opcodes.entry(opcode.into()).or_default() += 1;
                if instruction.contains("[rsp") { rsp_operands += 1; }
            }
            functions.push(json!({"name":name,"start":start,"size_bytes":size,"static_instructions":instructions,"static_rsp_operand_instructions":rsp_operands,"opcodes":opcodes,"disassembly":file,"disassembly_sha256":hash(r.join(&file))}));
        }
        assert_eq!(functions.len(), 2, "{label}: actual linked reducer and caller required");
        variants.insert(label, json!({"binary":binary,"binary_sha256":hash(&binary),"functions":functions}));
    }
    let out = json!({"variants":variants,"interpretation":"Static code counts are not dynamic traffic, exclusive costs, or latency. Inputs/arithmetic/tree geometry remain source-bound; inspect actual machine changes before timing."});
    fs::write(r.join("codegen.json"), serde_json::to_vec_pretty(&out).unwrap()).unwrap();
    println!("{}", serde_json::to_string_pretty(&out).unwrap());
}
