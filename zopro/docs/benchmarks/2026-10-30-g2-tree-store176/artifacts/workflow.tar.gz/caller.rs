use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g2-tree-store176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn r(p: impl AsRef<Path>) -> PathBuf {
    Path::new(R).join(p)
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn save(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn pin(pins: &mut BTreeMap<String, String>, p: impl AsRef<Path>) {
    let p = p.as_ref();
    pins.insert(p.display().to_string(), hash(p));
}
fn prepare() {
    assert!(!r("caller-plan.json").exists());
    assert_eq!(read(r("native/result.json"))["status"], "complete");
    assert_eq!(
        read(r("codegen-decision.json"))["warrants_complete_caller_timing"],
        true
    );
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(read(r("build-pins.json"))).unwrap();
    for (p, h) in &pins {
        assert_eq!(hash(p), *h);
    }
    let base = read(r("build-plan.json"))["steps"][0]["environment"].clone();
    let mut env = base.as_object().unwrap().clone();
    env.remove("CARGO_TARGET_DIR");
    env.remove("CARGO_BUILD_JOBS");
    env.remove("RUSTFLAGS");
    let mut identities = BTreeMap::new();
    for (label, count) in [("control", 127), ("candidate", 129)] {
        let t = read(r(format!("native/{label}-core/tests.json")));
        assert_eq!(t["unfiltered"], true);
        assert_eq!(t["passed_tests"].as_array().unwrap().len(), count);
        pin(&mut pins, r(format!("native/{label}-core/tests.json")));
        let artifact = r(format!("native/{label}/artifacts.json"));
        let a = read(&artifact);
        assert_eq!(hash(a["binary"].as_str().unwrap()), a["binary_sha256"]);
        for (p, h) in a["input_pins"].as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
        pin(&mut pins, artifact);
        pin(&mut pins, a["binary"].as_str().unwrap());
        identities.insert(label, a);
        pin(&mut pins, r(format!("frozen-{label}.json")));
    }
    let mut cases = vec![];
    for workers in [1, 16, 32] {
        for points in [256, 1024] {
            cases.push(
                json!({"name":format!("n{points}-w{workers}"),"workers":workers,"points":points}),
            );
        }
    }
    let mut jobs = vec![];
    let mut steps = vec![];
    for block in 0..15 {
        let mut order = (0..6).collect::<Vec<_>>();
        order.rotate_left(block % 6);
        if block % 2 == 1 {
            order.reverse();
        }
        let variants = if block % 2 == 0 {
            ["control", "candidate"]
        } else {
            ["candidate", "control"]
        };
        for i in order {
            let c = &cases[i];
            for label in variants {
                let name = format!("b{block}-{}-{label}", c["name"].as_str().unwrap());
                let workers = c["workers"].as_u64().unwrap();
                let affinity = if workers == 1 {
                    "2".to_string()
                } else {
                    format!("0-{}", workers - 1)
                };
                let argv = json!([
                    "taskset",
                    "-c",
                    affinity,
                    identities[label]["binary"],
                    c["points"].as_u64().unwrap().to_string(),
                    workers.to_string(),
                    "128"
                ]);
                steps.push(json!({"kind":"command","name":name,"argv":argv,"environment":env,"timeout_seconds":180}));
                jobs.push(json!({"name":name,"block":block,"case":c,"variant":label}));
            }
        }
    }
    assert_eq!(steps.len(), 180);
    save(r("caller-jobs.json"), &json!(jobs));
    save(r("caller-identities.json"), &json!(identities));
    let manifest=Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");
    for (rel, h) in read(&manifest)["source_files_sha256"].as_object().unwrap() {
        assert_eq!(hash(Path::new(Z).join(rel)), h.as_str().unwrap());
    }
    pin(&mut pins, manifest);
    for n in [
        "caller.rs",
        "caller",
        "caller-jobs.json",
        "caller-identities.json",
        "codegen.rs",
        "codegen",
        "codegen.json",
        "codegen-decision.json",
        "control.nm",
        "candidate.nm",
        "control-reduce.asm",
        "candidate-reduce.asm",
        "control-run.asm",
        "candidate-run.asm",
    ] {
        pin(&mut pins, r(n));
    }
    save(r("caller-pins.json"), &json!(pins));
    save(
        r("caller-plan.json"),
        &json!({"version":1,"source_pins":r("caller-pins.json"),"steps":steps}),
    );
    println!("Frozen180processes;two sizes;1/16/32workers;15fixedblocks;128complete reductions/worker;no proof timing");
}
fn summary(mut values: Vec<f64>) -> Value {
    assert_eq!(values.len(), 15);
    assert!(values.iter().all(|x| x.is_finite() && *x > 0.0));
    let original = values.clone();
    let wins = values.iter().filter(|&&x| x < 1.0).count();
    values.sort_by(f64::total_cmp);
    json!({"median":values[7],"lower":values[3],"upper":values[11],"wins":wins,"blocks":15,"block_values":original})
}
fn finish() {
    assert!(!r("caller-analysis.json").exists());
    let result = read(r("runs/result.json"));
    assert_eq!(result["status"], "complete");
    assert_eq!(result["steps"].as_array().unwrap().len(), 180);
    let pins = read(r("caller-pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let jobs = read(r("caller-jobs.json"));
    let mut rows = vec![];
    let mut map = BTreeMap::<(String, String, usize), f64>::new();
    let (mut total, mut timed, mut checked) = (0u64, 0u64, 0u64);
    for job in jobs.as_array().unwrap() {
        let name = job["name"].as_str().unwrap();
        let text = fs::read_to_string(r(format!("runs/{name}/stdout.log"))).unwrap();
        let lines = text
            .lines()
            .filter_map(|l| l.strip_prefix("CALLER "))
            .collect::<Vec<_>>();
        assert_eq!(lines.len(), 1);
        let a: Value = serde_json::from_str(lines[0]).unwrap();
        assert_eq!(a["points"], job["case"]["points"]);
        assert_eq!(a["workers"], job["case"]["workers"]);
        assert_eq!(a["iterations"], 128);
        assert_eq!(a["priming_per_worker"], 3);
        assert_eq!(a["input_reset_included"], true);
        assert_eq!(a["all_generator_outputs_verified"], true);
        assert_eq!(a["timed_new_proofs"], 0);
        let workers = a["workers"].as_u64().unwrap();
        assert_eq!(a["complete_tree_calls"], workers * 131);
        assert_eq!(a["worker_ns"].as_array().unwrap().len(), workers as usize);
        let wave = a["wave_ns"].as_u64().unwrap();
        let per = wave as f64 / 128.0;
        assert_eq!(per, a["wave_ns_per_iteration"].as_f64().unwrap());
        assert!(a["worker_ns"]
            .as_array()
            .unwrap()
            .iter()
            .all(|v| v.as_u64().unwrap() > 0 && v.as_u64().unwrap() <= wave));
        let k = (
            job["case"]["name"].as_str().unwrap().into(),
            job["variant"].as_str().unwrap().into(),
            job["block"].as_u64().unwrap() as usize,
        );
        assert!(map.insert(k, per).is_none());
        total += workers * 131;
        timed += workers * 128;
        checked += workers * 4;
        rows.push(json!({"job":job,"receipt":a,"stdout_sha256":hash(r(format!("runs/{name}/stdout.log")))}));
    }
    let mut cases = BTreeMap::new();
    let mut primary = vec![0.0f64; 15];
    let mut contexts_pass = true;
    for workers in [1, 16, 32] {
        for points in [256, 1024] {
            let name = format!("n{points}-w{workers}");
            let off = (0..15)
                .map(|b| map[&(name.clone(), "control".into(), b)])
                .collect::<Vec<_>>();
            let on = (0..15)
                .map(|b| map[&(name.clone(), "candidate".into(), b)])
                .collect::<Vec<_>>();
            let ratios = on.iter().zip(&off).map(|(a, b)| a / b).collect::<Vec<_>>();
            if workers == 32 {
                for (b, x) in ratios.iter().enumerate() {
                    primary[b] += x.ln() / 2.0;
                }
            }
            let ratio = summary(ratios);
            contexts_pass &= ratio["upper"].as_f64().unwrap() <= 1.03;
            cases.insert(name,json!({"control_ns":summary(off),"candidate_ns":summary(on),"candidate_over_control":ratio}));
        }
    }
    let primary = summary(primary.iter().map(|x| x.exp()).collect());
    let passed = primary["upper"].as_f64().unwrap() < 1.0
        && primary["wins"].as_u64().unwrap() >= 10
        && contexts_pass;
    save(
        r("caller-analysis.json"),
        &json!({"cases":cases,"primary_equal_log_32":primary,"all_context_upper_le_1_03":contexts_pass,"caller_gate_passed":passed,"complete_tree_calls":total,"timed_complete_tree_calls":timed,"checked_prime_and_final_bucket_outputs":checked,"intermediate_timed_iterations_individually_checked":false,"processes":180,"new_proofs":0,"paired_interval":"Order statistics4–12/15;96.484375%nominal marginal sign interval;no family-wise claim","rows":rows}),
    );
    println!(
        "Caller gate={passed};{total}completecalls/{checked}prime+finaloraclechecks;no new proofs"
    );
}
fn main() {
    match std::env::args().nth(1).as_deref() {
        Some("prepare") => prepare(),
        Some("finish") => finish(),
        _ => panic!("prepare/finish"),
    }
}
