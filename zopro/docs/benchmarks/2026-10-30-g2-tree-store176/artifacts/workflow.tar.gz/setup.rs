use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g2-tree-store176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn once(s: &mut String, a: &str, b: &str) {
    assert_eq!(s.matches(a).count(), 1, "{a}");
    *s = s.replace(a, b);
}
fn main() {
    let r = Path::new(R);
    let z = Path::new(Z);
    assert!(!r.join("source").exists());
    let manifest=z.join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");
    let m = read(&manifest);
    assert_eq!(m["source_files_sha256"].as_object().unwrap().len(), 176);
    for (p, h) in m["source_files_sha256"].as_object().unwrap() {
        let from = z.join(p);
        assert_eq!(hash(&from), h.as_str().unwrap());
        let to = r.join("source").join(p);
        fs::create_dir_all(to.parent().unwrap()).unwrap();
        fs::copy(from, to).unwrap();
    }
    let guard="all(zopro_tree_direct_store,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma))";
    let probe="all(zopro_tree_store_probe,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma))";
    let simd = "crates/zopro-core/src/simd.rs";
    let mut s = fs::read_to_string(r.join("source").join(simd)).unwrap();
    s.push_str(&format!("\n#[cfg({guard})]\n#[path=\"simd/tree_store.rs\"]\nmod tree_store;\n#[cfg({guard})]\npub(crate) use tree_store::store_fq2;\n"));
    fs::write(r.join("source").join(simd), s).unwrap();
    let to = r.join("source/crates/zopro-core/src/simd/tree_store.rs");
    fs::create_dir_all(to.parent().unwrap()).unwrap();
    fs::copy(r.join("tree_store.rs"), to).unwrap();
    let msm = "crates/zopro-core/src/msm.rs";
    let mut s = fs::read_to_string(r.join("source").join(msm)).unwrap();
    let old="            let (x, y) = (F::<C>::store(&x), F::<C>::store(&y));\n            for i in 0..LANES { points[s.pairs[k + i]] = LimbPoint {x:x[i], y:y[i]}; }";
    let new=format!("            #[cfg({guard})]\n            F::<C>::store_group(points,&s.pairs[k..k+LANES],&x,&y);\n            #[cfg(not({guard}))]\n            {{\n{old}\n            }}");
    once(&mut s, old, &new);
    let anchor = "    fn store(lanes: &Self::Lanes) -> [Self::Limbs; LANES];";
    let insert=format!("{anchor}\n    #[cfg({guard})]\n    #[inline(always)]\n    fn store_group(points:&mut[LimbPoint<Self>],indices:&[usize],x:&Self::Lanes,y:&Self::Lanes){{\n        let (x,y)=(Self::store(x),Self::store(y));\n        for i in 0..LANES{{points[indices[i]]=LimbPoint{{x:x[i],y:y[i]}};}}\n    }}");
    once(&mut s, anchor, &insert);
    let anchor = "impl BatchInverse for Fq2 {";
    let insert=format!("{anchor}\n    #[cfg({guard})]\n    #[inline(always)]\n    fn store_group(points:&mut[LimbPoint<Self>],indices:&[usize],x:&Self::Lanes,y:&Self::Lanes){{\n        let px=core::array::from_fn(|i|core::ptr::addr_of_mut!(points[indices[i]].x));\n        let py=core::array::from_fn(|i|core::ptr::addr_of_mut!(points[indices[i]].y));\n        // SAFETY: every checked index names an existing point field. The SIMD\n        // inputs were captured by value before any output mutation.\n        unsafe{{crate::simd::store_fq2(x,px);crate::simd::store_fq2(y,py);}}\n    }}");
    once(&mut s, anchor, &insert);
    s.push_str(&format!(
        "\n#[cfg({probe})]\n#[path=\"msm/tree_probe.rs\"]\npub mod tree_store_probe;\n"
    ));
    fs::write(r.join("source").join(msm), s).unwrap();
    fs::copy(
        r.join("tree_probe.rs"),
        r.join("source/crates/zopro-core/src/msm/tree_probe.rs"),
    )
    .unwrap();
    let lib = "crates/zopro-core/src/lib.rs";
    let mut s = fs::read_to_string(r.join("source").join(lib)).unwrap();
    s.push_str(&format!(
        "\n#[cfg({probe})]\npub use msm::tree_store_probe::TreeFixture;\n"
    ));
    fs::write(r.join("source").join(lib), s).unwrap();
    let parent = Path::new("/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175");
    let mut native = fs::read_to_string(parent.join("native.rs"))
        .unwrap()
        .replace(parent.to_str().unwrap(), R);
    native = native
        .replace(
            "[\"candidate\", \"portable\"]",
            "[\"candidate\", \"control\"]",
        )
        .replace("\"portable-flags.txt\"", "\"native-flags.txt\"");
    fs::write(r.join("native.rs"), native).unwrap();
    let base = m["rustflags"].as_str().unwrap();
    fs::write(
        r.join("native-flags.txt"),
        format!("{base} --cfg zopro_tree_store_probe"),
    )
    .unwrap();
    fs::write(
        r.join("candidate-flags.txt"),
        format!("{base} --cfg zopro_tree_store_probe --cfg zopro_tree_direct_store"),
    )
    .unwrap();
    let mut source = BTreeMap::new();
    let mut changed = vec![];
    let mut field = 0;
    for (p, h) in m["source_files_sha256"].as_object().unwrap() {
        let f = r.join("source").join(p);
        let after = hash(&f);
        if after != h.as_str().unwrap() {
            changed.push(p.clone());
        } else if p.starts_with("crates/zopro-bn254/") {
            field += 1;
        }
        source.insert(p.clone(), after);
    }
    for p in [
        "crates/zopro-core/src/simd/tree_store.rs",
        "crates/zopro-core/src/msm/tree_probe.rs",
    ] {
        source.insert(p.into(), hash(r.join("source").join(p)));
    }
    assert_eq!(changed.len(), 3);
    assert_eq!(source.len(), 178);
    fs::write(r.join("source-audit.json"),serde_json::to_vec_pretty(&json!({"source_files":178,"accepted_originals_exact":173,"changed_parents":changed,"field_files_exact":field,"field_math_and_generated_sources_unchanged":true,"old_prefix_output_body_retained_verbatim_in_OFF":true,"production_changed":false,"source_files_sha256":source})).unwrap()).unwrap();
    println!("Prepared178privatefiles;173acceptedexact,3parents+2children;allfield/generatedsourceexact;OFFoldoutputbodyverbatim");
}
