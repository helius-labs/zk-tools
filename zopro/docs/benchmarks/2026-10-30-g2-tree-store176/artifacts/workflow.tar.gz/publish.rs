use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    fmt::Write,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/g2-tree-store176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
const NAME: &str = "2026-10-30-g2-tree-store176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn archive(out: &Path, root: &Path, names: &[&str]) {
    let status = Command::new("tar")
        .args([
            "--sort=name",
            "--mtime=@0",
            "--owner=0",
            "--group=0",
            "--numeric-owner",
            "--exclude=*-sdk",
        ])
        .arg("-czf")
        .arg(out)
        .arg("-C")
        .arg(root)
        .args(names)
        .status()
        .unwrap();
    assert!(status.success());
}
fn main() {
    let root = Path::new(R);
    let out = Path::new(Z).join("docs/benchmarks").join(NAME);
    assert!(!out.exists());
    let a = read(root.join("caller-analysis.json"));
    let review = read(root.join("review.json"));
    assert_eq!(review["passed"], true);
    assert_eq!(a["caller_gate_passed"], false);
    let inherited =
        Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts");
    let ledger = read(inherited.join("proof-sha256-after.json"));
    assert_eq!(ledger.as_array().unwrap().len(), 27353);
    fs::create_dir_all(out.join("artifacts")).unwrap();
    for name in [
        "caller-analysis.json",
        "review.json",
        "codegen.json",
        "codegen-decision.json",
        "source-audit.json",
        "design.md",
    ] {
        fs::copy(root.join(name), out.join("artifacts").join(name)).unwrap();
    }
    fs::copy(
        inherited.join("local-rows.json"),
        out.join("artifacts/accepted-local-rows.json"),
    )
    .unwrap();
    let rows = read(inherited.join("local-rows.json"));
    let mut text=String::from("# G2 tree coordinate output stores\n\nThe output-only G2 coordinate-store candidate was **not adopted**. Native correctness passed, but the fixed complete-tree caller comparison failed its performance gate. Production source176 and its accepted proof results are unchanged.\n\nThe candidate keeps field canonicalization, input packing, arithmetic, inversion, pair order, tree geometry and exceptional handling. It combines canonical component words into direct 64-byte Fq2 stores at existing destinations. It adds no production heap allocation, table, key copy or execution plan. The diagnostic caller owns resettable input copies; these are benchmark fixtures, not an architectural change.\n\n## Complete-tree results\n\nEach cell uses 15 separate-process blocks, two variants and 128 complete reductions per worker after three primes. Times below are median wave microseconds per iteration, including identical input reset and worker/barrier tail. These are **tree-caller timings, not proof latency**. The paired ratio median can differ from the ratio of the two marginal medians. Values below one favor the candidate.\n\n| Points | Workers | Control µs | Candidate µs | Paired ratio | Paired interval | Wins |\n|---:|---:|---:|---:|---:|---:|---:|\n");
    for workers in [1, 16, 32] {
        for points in [256, 1024] {
            let s = &a["cases"][format!("n{points}-w{workers}")];
            let q = &s["candidate_over_control"];
            writeln!(
                text,
                "| {points} | {workers} | {:.3} | {:.3} | {:.6} | [{:.6}, {:.6}] | {}/15 |",
                s["control_ns"]["median"].as_f64().unwrap() / 1000.0,
                s["candidate_ns"]["median"].as_f64().unwrap() / 1000.0,
                q["median"].as_f64().unwrap(),
                q["lower"].as_f64().unwrap(),
                q["upper"].as_f64().unwrap(),
                q["wins"]
            )
            .unwrap();
        }
    }
    let p = &a["primary_equal_log_32"];
    writeln!(text,"\nThe predeclared primary equal-log aggregate across both 32-worker sizes was **{:.6} [{:.6}, {:.6}], {}/15 wins**. It fails the required upper bound below one and at least 10 wins. The context upper-bound limit of 1.03 also fails. Threaded results have wide dispersion; the lower aggregate median is not established as a gain. Both single-worker cases were consistently slower. No exclusions, block extensions, geometry sweep, unchanged reroll or full-SDK measurement followed this failure.\n",p["median"].as_f64().unwrap(),p["lower"].as_f64().unwrap(),p["upper"].as_f64().unwrap(),p["wins"]).unwrap();
    text.push_str("Intervals use ranks 4–12 of 15 paired values: nominal marginal 96.484375% sign intervals, without a family-wise guarantee. There is no positive-gain floor. Whole processes were bound to CPU 2, CPUs 0–15 or CPUs 0–31 respectively on this 16-core/32-thread host; individual workers were not pinned. A Rayon pool with the declared worker count executes the reductions, while an external coordinator controls ready/start/done/release barriers.\n\n## Correctness and emitted code\n\nUnfiltered native core suites passed **127 OFF / 129 ON** tests. Two shared tests cover complete generator-sum tree references, tails, exceptional inputs, empty buckets, reset/reuse and 1/4/32-worker pools with 512 KiB stacks. Two candidate-only tests cover scalar field references, lazy/boundary values, permuted destinations and untouched holes. All 18 accepted field source files are byte-identical; the existing 35 native field tests are inherited, not rerun.\n\nThe actual linked reducer emitted direct 64-byte destination stores. Its static size changed from 155,349 to 155,859 bytes; instruction count from 26,650 to 26,601; RSP-operand instructions from 4,778 to 4,889. Prologue stack subtractions total 7,616 versus 7,232 bytes, excluding pushes, alignment and callees. IFMA and scalar `mulx` counts are unchanged. Static counts do not measure executed work, spill traffic or removable latency. The smaller stack frame did not establish a complete-caller gain.\n\nAll 180 processes completed: **385,140 complete tree calls**, including 376,320 timed calls, with 11,760 independently constructed generator-sum checks across primes and final outputs. Intermediate timed iterations are not checked individually. Reference construction, allocation and output checks are outside the clock. No new proof, verifier export or CPU profile was produced; the canonical verified-proof ledger remains **27,353**. The prior instruction census supplied the profiling evidence for this hypothesis; its 5.93% generic G2 reduction sample share was never a promise of removable wall time.\n\nThe private snapshot contains 178 files: 173 accepted originals unchanged, three changed parents and two diagnostic/codec children. The control retains the original output body. The prebuild driver was changed from `scope` to `in_place_scope` before any build or timing so the coordinator does not occupy a worker at its barriers; both prebuild versions and their plans are retained. No successful test or timing run was repeated.\n\n## Accepted proof comparison — inherited, unchanged\n\nThese are the previously accepted local 32-worker SDK measurements, not measurements of this rejected candidate. M5 references are the supplied CPU and Metal timings. Speedups are reference latency divided by accepted local latency. No fresh AWS, Aeglos, phone/ARM/TEE, huge-circuit, concurrent-proof or minimum-RAM measurement is claimed.\n\n| Shape | Zopro ms | Peak RSS MiB | M5 CPU ms | CPU speedup | M5 Metal ms | Metal speedup | 10× CPU target ms |\n|---|---:|---:|---:|---:|---:|---:|---:|\n");
    for (shape, cpu, metal) in [
        ("1x2", 37., 24.),
        ("2x2", 59., 30.),
        ("4x2", 109., 48.),
        ("8x2", 189., 74.),
        ("12x2", 284., 101.),
        ("16x2", 335., 124.),
        ("24x2", 528., 176.),
        ("merge24", 507., 175.),
    ] {
        let key = if shape == "merge24" {
            "merge-24x1-w32".to_string()
        } else {
            format!("{shape}-w32")
        };
        let row = &rows[&key];
        let ms = row["median_ms"]
            .as_f64()
            .unwrap_or_else(|| panic!("missing row {key}"));
        writeln!(
            text,
            "| {shape} | {ms:.6} | {:.2} | {cpu:.0} | {:.3}× | {metal:.0} | {:.3}× | {:.1} |",
            row["max_RSS_MiB"].as_f64().unwrap(),
            cpu / ms,
            metal / ms,
            cpu / 10.
        )
        .unwrap();
    }
    text.push_str("\nThe all-eight 10× CPU objective remains unmet: **0/8** targets achieved. The primary accepted result is 7.928660 ms against a 3.7 ms target. The inherited 54-1 merge result is 161.883899 ms / 1,876.96 MiB peak RSS, without a supplied M5 reference. Latest AWS comparisons predate accepted source176; this study changes none of them.\n\n## Evidence\n\n[Design](artifacts/design.md), [raw rows and analysis](artifacts/caller-analysis.json), [independent review](artifacts/review.json), [linked-code counts](artifacts/codegen.json), [timing decision](artifacts/codegen-decision.json), [source audit](artifacts/source-audit.json), [accepted proof rows](artifacts/accepted-local-rows.json).\n\nArchives retain the [exact private source](artifacts/private-source.tar.gz), [workflow sources and frozen plans](artifacts/workflow.tar.gz), [native command/test/link receipts](artifacts/native-receipts.tar.gz), [all 180 caller receipts](artifacts/caller-receipts.tar.gz) and [linked disassembly](artifacts/codegen.tar.gz). Executables and frozen libraries stay local with recorded hashes. No key image or private witness data is included. [Checksums](SHA256SUMS).\n\nRelated evidence: [accepted integration](../2026-10-30-g2-vector-sign-adoption176/README.md), [instruction census](../2026-10-30-instruction-census176/README.md), [earlier joint G1 point I/O experiment](../2026-10-24-point-io-component/README.md), [G2 staged arithmetic](../2026-10-30-g2-staged175/README.md). This result closes the exact output-only G2 store candidate; it does not establish that all coordinate-layout approaches are ineffective. Further work toward the required large gain needs a distinct mechanism that reduces dominant MSM work.\n");
    fs::write(out.join("README.md"), text).unwrap();
    let mut files = String::new();
    for n in read(root.join("source-audit.json"))["source_files_sha256"]
        .as_object()
        .unwrap()
        .keys()
    {
        writeln!(files, "{n}").unwrap();
    }
    fs::write(root.join("source-files.txt"), files).unwrap();
    let status = Command::new("tar")
        .args([
            "--sort=name",
            "--mtime=@0",
            "--owner=0",
            "--group=0",
            "--numeric-owner",
            "-czf",
        ])
        .arg(out.join("artifacts/private-source.tar.gz"))
        .arg("-C")
        .arg(root.join("source"))
        .arg("-T")
        .arg(root.join("source-files.txt"))
        .status()
        .unwrap();
    assert!(status.success());
    archive(
        &out.join("artifacts/native-receipts.tar.gz"),
        root,
        &["native", "native.log"],
    );
    archive(
        &out.join("artifacts/caller-receipts.tar.gz"),
        root,
        &["runs", "caller-capture.log"],
    );
    archive(
        &out.join("artifacts/codegen.tar.gz"),
        root,
        &[
            "control.nm",
            "candidate.nm",
            "control-reduce.asm",
            "candidate-reduce.asm",
            "control-run.asm",
            "candidate-run.asm",
            "codegen.log",
        ],
    );
    archive(
        &out.join("artifacts/workflow.tar.gz"),
        root,
        &[
            "design.md",
            "setup.rs",
            "setup.log",
            "source-audit.json",
            "native.rs",
            "native-flags.txt",
            "candidate-flags.txt",
            "tree_probe.rs",
            "tree_store.rs",
            "driver.rs",
            "driver-prebuild.rs",
            "perf_support.rs",
            "prepare-build.rs",
            "prepare-build.log",
            "build-pins.json",
            "build-plan.json",
            "build-pins-prebuild.json",
            "build-plan-prebuild.json",
            "codegen.rs",
            "codegen-decision.json",
            "caller.rs",
            "caller-pins.json",
            "caller-plan.json",
            "caller-jobs.json",
            "caller-identities.json",
            "caller-prepare.log",
            "caller-finish.log",
            "review.rs",
            "review.json",
            "review.log",
            "publish.rs",
            "frozen-control.json",
            "frozen-candidate.json",
            "frozen-control-cargo.jsonl",
            "frozen-candidate-cargo.jsonl",
        ],
    );
    let receipt = json!({"published":out,"rejected_candidate":true,"new_proofs":0,"canonical_ledger":27353,"accepted_rows_sha256":hash(out.join("artifacts/accepted-local-rows.json")),"production_source_manifest_sha256":hash(inherited.join("production-source-manifest.json"))});
    fs::write(
        root.join("publication.json"),
        serde_json::to_vec_pretty(&receipt).unwrap(),
    )
    .unwrap();
    println!("Published negative complete-caller study;accepted eight CPU+Metal rows inherited unchanged;0/8target");
}
