
/home/ubuntu/src/zopro-perf-work/g2-tree-store176/native/control-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000000bb5f0 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run>:
   bb5f0:	41 57                                           	push   r15
   bb5f2:	41 56                                           	push   r14
   bb5f4:	41 54                                           	push   r12
   bb5f6:	53                                              	push   rbx
   bb5f7:	50                                              	push   rax
   bb5f8:	48 8b 57 28                                     	mov    rdx,QWORD PTR [rdi+0x28]
   bb5fc:	48 8b 77 10                                     	mov    rsi,QWORD PTR [rdi+0x10]
   bb600:	48 39 f2                                        	cmp    rdx,rsi
   bb603:	0f 85 9c 00 00 00                               	jne    bb6a5 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0xb5>
   bb609:	48 89 fb                                        	mov    rbx,rdi
   bb60c:	48 8b 7f 20                                     	mov    rdi,QWORD PTR [rdi+0x20]
   bb610:	48 8b 73 08                                     	mov    rsi,QWORD PTR [rbx+0x8]
   bb614:	48 c1 e2 07                                     	shl    rdx,0x7
   bb618:	ff 15 c2 3f 00 00                               	call   QWORD PTR [rip+0x3fc2]        # bf5e0 <memcpy@GLIBC_2.14>
   bb61e:	4c 8b 73 58                                     	mov    r14,QWORD PTR [rbx+0x58]
   bb622:	48 8b 73 40                                     	mov    rsi,QWORD PTR [rbx+0x40]
   bb626:	49 39 f6                                        	cmp    r14,rsi
   bb629:	0f 85 88 00 00 00                               	jne    bb6b7 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0xc7>
   bb62f:	4c 8b 7b 50                                     	mov    r15,QWORD PTR [rbx+0x50]
   bb633:	48 8b 73 38                                     	mov    rsi,QWORD PTR [rbx+0x38]
   bb637:	4a 8d 14 f5 00 00 00 00                         	lea    rdx,[r14*8+0x0]
   bb63f:	4c 89 ff                                        	mov    rdi,r15
   bb642:	ff 15 98 3f 00 00                               	call   QWORD PTR [rip+0x3f98]        # bf5e0 <memcpy@GLIBC_2.14>
   bb648:	4c 8d 63 78                                     	lea    r12,[rbx+0x78]
   bb64c:	4a 8d 04 f5 00 00 00 00                         	lea    rax,[r14*8+0x0]
   bb654:	31 c9                                           	xor    ecx,ecx
   bb656:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   bb660:	48 39 c8                                        	cmp    rax,rcx
   bb663:	74 34                                           	je     bb699 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0xa9>
   bb665:	49 83 3c 0f 01                                  	cmp    QWORD PTR [r15+rcx*1],0x1
   bb66a:	48 8d 49 08                                     	lea    rcx,[rcx+0x8]
   bb66e:	76 f0                                           	jbe    bb660 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0x70>
   bb670:	48 8b 7b 20                                     	mov    rdi,QWORD PTR [rbx+0x20]
   bb674:	48 8b 73 28                                     	mov    rsi,QWORD PTR [rbx+0x28]
   bb678:	48 8b 53 68                                     	mov    rdx,QWORD PTR [rbx+0x68]
   bb67c:	48 8b 4b 70                                     	mov    rcx,QWORD PTR [rbx+0x70]
   bb680:	4c 89 24 24                                     	mov    QWORD PTR [rsp],r12
   bb684:	4d 89 f8                                        	mov    r8,r15
   bb687:	4d 89 f1                                        	mov    r9,r14
   bb68a:	e8 31 9f fd ff                                  	call   955c0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm12reduce_layerNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEB4_>
   bb68f:	4c 8b 7b 50                                     	mov    r15,QWORD PTR [rbx+0x50]
   bb693:	4c 8b 73 58                                     	mov    r14,QWORD PTR [rbx+0x58]
   bb697:	eb b3                                           	jmp    bb64c <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0x5c>
   bb699:	48 83 c4 08                                     	add    rsp,0x8
   bb69d:	5b                                              	pop    rbx
   bb69e:	41 5c                                           	pop    r12
   bb6a0:	41 5e                                           	pop    r14
   bb6a2:	41 5f                                           	pop    r15
   bb6a4:	c3                                              	ret
   bb6a5:	48 8d 05 f4 3b 00 00                            	lea    rax,[rip+0x3bf4]        # bf2a0 <__frame_dummy_init_array_entry+0x2470>
   bb6ac:	48 89 d7                                        	mov    rdi,rdx
   bb6af:	48 89 c2                                        	mov    rdx,rax
   bb6b2:	e8 89 df f8 ff                                  	call   49640 <_RNvNvNtCsgxBkk5gSRhY_4core5slice20copy_from_slice_impl17len_mismatch_fail>
   bb6b7:	48 8d 15 fa 3b 00 00                            	lea    rdx,[rip+0x3bfa]        # bf2b8 <__frame_dummy_init_array_entry+0x2488>
   bb6be:	4c 89 f7                                        	mov    rdi,r14
   bb6c1:	e8 7a df f8 ff                                  	call   49640 <_RNvNvNtCsgxBkk5gSRhY_4core5slice20copy_from_slice_impl17len_mismatch_fail>
