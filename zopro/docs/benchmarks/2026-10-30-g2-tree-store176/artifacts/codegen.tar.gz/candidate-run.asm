
/home/ubuntu/src/zopro-perf-work/g2-tree-store176/native/candidate-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000000bb7f0 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run>:
   bb7f0:	41 57                                           	push   r15
   bb7f2:	41 56                                           	push   r14
   bb7f4:	41 54                                           	push   r12
   bb7f6:	53                                              	push   rbx
   bb7f7:	50                                              	push   rax
   bb7f8:	48 8b 57 28                                     	mov    rdx,QWORD PTR [rdi+0x28]
   bb7fc:	48 8b 77 10                                     	mov    rsi,QWORD PTR [rdi+0x10]
   bb800:	48 39 f2                                        	cmp    rdx,rsi
   bb803:	0f 85 9c 00 00 00                               	jne    bb8a5 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0xb5>
   bb809:	48 89 fb                                        	mov    rbx,rdi
   bb80c:	48 8b 7f 20                                     	mov    rdi,QWORD PTR [rdi+0x20]
   bb810:	48 8b 73 08                                     	mov    rsi,QWORD PTR [rbx+0x8]
   bb814:	48 c1 e2 07                                     	shl    rdx,0x7
   bb818:	ff 15 c2 3f 00 00                               	call   QWORD PTR [rip+0x3fc2]        # bf7e0 <memcpy@GLIBC_2.14>
   bb81e:	4c 8b 73 58                                     	mov    r14,QWORD PTR [rbx+0x58]
   bb822:	48 8b 73 40                                     	mov    rsi,QWORD PTR [rbx+0x40]
   bb826:	49 39 f6                                        	cmp    r14,rsi
   bb829:	0f 85 88 00 00 00                               	jne    bb8b7 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0xc7>
   bb82f:	4c 8b 7b 50                                     	mov    r15,QWORD PTR [rbx+0x50]
   bb833:	48 8b 73 38                                     	mov    rsi,QWORD PTR [rbx+0x38]
   bb837:	4a 8d 14 f5 00 00 00 00                         	lea    rdx,[r14*8+0x0]
   bb83f:	4c 89 ff                                        	mov    rdi,r15
   bb842:	ff 15 98 3f 00 00                               	call   QWORD PTR [rip+0x3f98]        # bf7e0 <memcpy@GLIBC_2.14>
   bb848:	4c 8d 63 78                                     	lea    r12,[rbx+0x78]
   bb84c:	4a 8d 04 f5 00 00 00 00                         	lea    rax,[r14*8+0x0]
   bb854:	31 c9                                           	xor    ecx,ecx
   bb856:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nop WORD PTR [rax+rax*1+0x0]
   bb860:	48 39 c8                                        	cmp    rax,rcx
   bb863:	74 34                                           	je     bb899 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0xa9>
   bb865:	49 83 3c 0f 01                                  	cmp    QWORD PTR [r15+rcx*1],0x1
   bb86a:	48 8d 49 08                                     	lea    rcx,[rcx+0x8]
   bb86e:	76 f0                                           	jbe    bb860 <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0x70>
   bb870:	48 8b 7b 20                                     	mov    rdi,QWORD PTR [rbx+0x20]
   bb874:	48 8b 73 28                                     	mov    rsi,QWORD PTR [rbx+0x28]
   bb878:	48 8b 53 68                                     	mov    rdx,QWORD PTR [rbx+0x68]
   bb87c:	48 8b 4b 70                                     	mov    rcx,QWORD PTR [rbx+0x70]
   bb880:	4c 89 24 24                                     	mov    QWORD PTR [rsp],r12
   bb884:	4d 89 f8                                        	mov    r8,r15
   bb887:	4d 89 f1                                        	mov    r9,r14
   bb88a:	e8 31 9d fd ff                                  	call   955c0 <_RINvNtCsHW5vo2gROj_10zopro_core3msm12reduce_layerNtNtCsgHCcee0nhgM_11zopro_bn2545curve8G2ConfigEB4_>
   bb88f:	4c 8b 7b 50                                     	mov    r15,QWORD PTR [rbx+0x50]
   bb893:	4c 8b 73 58                                     	mov    r14,QWORD PTR [rbx+0x58]
   bb897:	eb b3                                           	jmp    bb84c <_RNvMNtNtCsHW5vo2gROj_10zopro_core3msm16tree_store_probeNtB2_11TreeFixture3run+0x5c>
   bb899:	48 83 c4 08                                     	add    rsp,0x8
   bb89d:	5b                                              	pop    rbx
   bb89e:	41 5c                                           	pop    r12
   bb8a0:	41 5e                                           	pop    r14
   bb8a2:	41 5f                                           	pop    r15
   bb8a4:	c3                                              	ret
   bb8a5:	48 8d 05 f4 3b 00 00                            	lea    rax,[rip+0x3bf4]        # bf4a0 <__frame_dummy_init_array_entry+0x2470>
   bb8ac:	48 89 d7                                        	mov    rdi,rdx
   bb8af:	48 89 c2                                        	mov    rdx,rax
   bb8b2:	e8 89 dd f8 ff                                  	call   49640 <_RNvNvNtCsgxBkk5gSRhY_4core5slice20copy_from_slice_impl17len_mismatch_fail>
   bb8b7:	48 8d 15 fa 3b 00 00                            	lea    rdx,[rip+0x3bfa]        # bf4b8 <__frame_dummy_init_array_entry+0x2488>
   bb8be:	4c 89 f7                                        	mov    rdi,r14
   bb8c1:	e8 7a dd f8 ff                                  	call   49640 <_RNvNvNtCsgxBkk5gSRhY_4core5slice20copy_from_slice_impl17len_mismatch_fail>
