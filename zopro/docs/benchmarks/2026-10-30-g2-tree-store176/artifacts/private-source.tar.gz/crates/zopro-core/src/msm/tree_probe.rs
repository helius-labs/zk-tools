//! Diagnostic wrapper around the unchanged complete generic G2 tree.
use super::*;

pub struct TreeFixture {
    original: Vec<LimbPoint<Fq2>>,
    points: Vec<LimbPoint<Fq2>>,
    initial_counts: Vec<usize>,
    counts: Vec<usize>,
    starts: Vec<usize>,
    scratch: Scratch<zopro_bn254::G2Config>,
}

impl TreeFixture {
    pub fn new(points: &[zopro_bn254::G2Affine], counts: &[usize]) -> Result<Self, &'static str> {
        let mut total = 0usize;
        let mut starts = Vec::with_capacity(counts.len());
        for &count in counts {
            starts.push(total);
            total = total.checked_add(count).ok_or("tree count overflow")?;
        }
        if total != points.len() {
            return Err("tree count/point mismatch");
        }
        let original = points
            .iter()
            .copied()
            .map(limbs::<zopro_bn254::G2Config>)
            .collect::<Vec<_>>();
        Ok(Self {
            points: original.clone(),
            original,
            initial_counts: counts.to_vec(),
            counts: counts.to_vec(),
            starts,
            scratch: Scratch::default(),
        })
    }

    /// Reset and reduce every original bucket. Reset cost is charged uniformly.
    #[inline(never)]
    pub fn run(&mut self) {
        self.points.copy_from_slice(&self.original);
        self.counts.copy_from_slice(&self.initial_counts);
        while self.counts.iter().any(|&n| n > 1) {
            reduce_layer::<zopro_bn254::G2Config>(
                &mut self.points,
                &self.starts,
                &mut self.counts,
                &mut self.scratch,
            );
        }
    }

    pub fn outputs(&self) -> Vec<zopro_bn254::G2Affine> {
        self.counts
            .iter()
            .enumerate()
            .map(|(i, &n)| {
                if n == 0 {
                    zopro_bn254::G2Affine::IDENTITY
                } else {
                    affine::<zopro_bn254::G2Config>(self.points[self.starts[i]])
                }
            })
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use zopro_bn254::{Fr, G2Config, G2Projective};

    #[test]
    fn complete_tree_generator_oracles_tails_exceptions_and_reuse() {
        let g = G2Projective::generator();
        let original_weights = (0..1024)
            .map(|i| Fr::from(i * 37 + 1001))
            .collect::<Vec<_>>();
        let geometries = vec![
            vec![],
            vec![0],
            vec![1],
            vec![7],
            vec![8],
            vec![31],
            vec![32],
            vec![33],
            vec![64],
            vec![200],
            vec![352],
            vec![1024],
            vec![0, 1, 7, 64, 0, 33, 200],
        ];
        for style in 0..2 {
            let mut weights = original_weights.clone();
            if style == 1 {
                for chunk in weights.chunks_mut(8) {
                    chunk[0] = Fr::ZERO;
                    chunk[1] = chunk[2];
                    chunk[3] = -chunk[4];
                    chunk[5] = Fr::ZERO;
                }
            }
            let points =
                G2Projective::batch_to_affine(&weights.iter().map(|w| g * *w).collect::<Vec<_>>());
            for counts in &geometries {
                let n = counts.iter().sum::<usize>();
                let mut fixture = TreeFixture::new(&points[..n], counts).unwrap();
                let mut start = 0;
                let expected = counts
                    .iter()
                    .map(|&count| {
                        let weight = weights[start..start + count]
                            .iter()
                            .fold(Fr::ZERO, |a, b| a + *b);
                        start += count;
                        (g * weight).to_affine()
                    })
                    .collect::<Vec<_>>();
                for _ in 0..3 {
                    fixture.run();
                    assert_eq!(
                        fixture.outputs(),
                        expected,
                        "style={style} counts={counts:?}"
                    );
                }
                assert_eq!(
                    points,
                    G2Projective::batch_to_affine(
                        &weights.iter().map(|w| g * *w).collect::<Vec<_>>()
                    )
                );
            }
        }
    }

    #[test]
    fn threaded_small_stack_pools_and_invalid_geometry() {
        let g = Projective::<G2Config>::generator();
        let weights = (1..=128).map(Fr::from).collect::<Vec<_>>();
        let points =
            G2Projective::batch_to_affine(&weights.iter().map(|w| g * *w).collect::<Vec<_>>());
        let expected = (g * weights.iter().fold(Fr::ZERO, |a, b| a + *b)).to_affine();
        assert!(TreeFixture::new(&points, &[127]).is_err());
        assert!(TreeFixture::new(&points, &[usize::MAX, 2]).is_err());
        for workers in [1, 4, 32] {
            let pool = rayon::ThreadPoolBuilder::new()
                .num_threads(workers)
                .stack_size(512 * 1024)
                .build()
                .unwrap();
            pool.install(|| {
                use rayon::prelude::*;
                (0..workers).into_par_iter().for_each(|_| {
                    let mut fixture = TreeFixture::new(&points, &[0, 128, 0]).unwrap();
                    for _ in 0..3 {
                        fixture.run();
                        assert_eq!(
                            fixture.outputs(),
                            vec![
                                zopro_bn254::G2Affine::IDENTITY,
                                expected,
                                zopro_bn254::G2Affine::IDENTITY
                            ]
                        );
                    }
                });
            });
        }
    }
}
