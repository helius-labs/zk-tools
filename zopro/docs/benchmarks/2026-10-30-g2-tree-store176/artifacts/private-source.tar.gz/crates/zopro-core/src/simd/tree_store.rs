//! Native output-only Fq2 coordinate stores. Field canonicalization is unchanged.
use super::{FqBatch, FqLimbs};
use core::arch::x86_64::*;

/// Write the eight canonical complex coordinates to initialized point fields.
///
/// # Safety
/// Each destination must permit writing an entire `[FqLimbs; 2]` (64 bytes).
/// Destinations must not overlap the input lanes. The caller provides distinct
/// point fields; no reference to them is held across these stores.
#[inline(always)]
pub(crate) unsafe fn store_fq2(lanes: &[FqBatch; 2], destinations: [*mut [FqLimbs; 2]; 8]) {
    const {
        assert!(core::mem::size_of::<FqLimbs>() == 32);
        assert!(core::mem::align_of::<FqLimbs>() == 8);
        assert!(core::mem::offset_of!(FqLimbs, 0) == 0);
        assert!(core::mem::size_of::<[FqLimbs; 2]>() == 64);
    }
    // get() is the existing canonical R256 codec. Do not duplicate or weaken
    // its lazy-value reduction contract. LLVM may eliminate these arrays.
    let c0 = lanes[0].get();
    let c1 = lanes[1].get();
    unsafe {
        let a = c0.as_ptr().cast::<__m512i>();
        let b = c1.as_ptr().cast::<__m512i>();
        for i in 0..4 {
            // Each vector contains two consecutive four-word Fq values.
            let a = _mm512_loadu_si512(a.add(i));
            let b = _mm512_loadu_si512(b.add(i));
            _mm512_storeu_si512(
                destinations[2 * i].cast::<__m512i>(),
                _mm512_shuffle_i64x2::<0x44>(a, b),
            );
            _mm512_storeu_si512(
                destinations[2 * i + 1].cast::<__m512i>(),
                _mm512_shuffle_i64x2::<0xee>(a, b),
            );
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use zopro_bn254::Fq;

    fn next(seed: &mut u64) -> Fq {
        let mut bytes = [0; 64];
        for chunk in bytes.chunks_mut(8) {
            *seed ^= *seed << 13;
            *seed ^= *seed >> 7;
            *seed ^= *seed << 17;
            chunk.copy_from_slice(&seed.to_le_bytes());
        }
        Fq::from_random_bytes(&bytes)
    }

    #[test]
    fn canonical_output_and_permuted_holes_match_scalar_fields() {
        let mut seed = 0xb823_19ad_4630_55e1;
        let indices = [6, 1, 17, 4, 11, 0, 9, 15];
        for round in 0..512 {
            let a: [Fq; 8] = core::array::from_fn(|_| next(&mut seed));
            let b: [Fq; 8] = core::array::from_fn(|_| next(&mut seed));
            let (av, bv) = (FqBatch::new(&a), FqBatch::new(&b));
            for mode in 0..4 {
                let (c0, c1) = match mode {
                    0 => (av, bv),
                    1 => (av.add(&bv), av.sub(&bv)),
                    2 => (av.mul(&bv), bv.add(&bv)),
                    _ => (av.sub(&av), bv.sub(&av)),
                };
                let sentinel = FqLimbs::new(Fq::from(1234567));
                let mut actual = [[sentinel; 2]; 19];
                let mut expected = actual;
                for i in 0..8 {
                    let pair = match mode {
                        0 => [a[i], b[i]],
                        1 => [a[i] + b[i], a[i] - b[i]],
                        2 => [a[i] * b[i], b[i] + b[i]],
                        _ => [Fq::ZERO, b[i] - a[i]],
                    };
                    expected[indices[i]] = pair.map(FqLimbs::new);
                }
                let pointers =
                    core::array::from_fn(|i| core::ptr::addr_of_mut!(actual[indices[i]]));
                unsafe { store_fq2(&[c0, c1], pointers) };
                assert!(actual == expected, "round={round} mode={mode}");
            }
        }
    }

    #[test]
    fn zero_one_and_modulus_boundary_outputs() {
        let mut p_minus_one = Fq::MODULUS;
        p_minus_one[0] -= 1;
        let values = [
            Fq::ZERO,
            Fq::ONE,
            -Fq::ONE,
            Fq::from_montgomery([1, 0, 0, 0]),
            Fq::from_montgomery(p_minus_one),
        ];
        for shift in 0..values.len() {
            let a = core::array::from_fn(|i| values[(i + shift) % values.len()]);
            let b = core::array::from_fn(|i| values[(2 * i + shift + 1) % values.len()]);
            let (av, bv) = (FqBatch::new(&a), FqBatch::new(&b));
            let mut output = [[FqLimbs::default(); 2]; 8];
            let pointers = core::array::from_fn(|i| core::ptr::addr_of_mut!(output[i]));
            unsafe { store_fq2(&[av.add(&bv), av.sub(&bv)], pointers) };
            for i in 0..8 {
                assert!(output[i] == [FqLimbs::new(a[i] + b[i]), FqLimbs::new(a[i] - b[i])]);
            }
        }
    }
}
