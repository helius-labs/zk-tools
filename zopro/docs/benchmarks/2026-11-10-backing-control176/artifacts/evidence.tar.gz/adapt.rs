//! Prepare a distinct backing intervention from the qualified layout readers.
use std::{collections::BTreeSet,fs,path::Path,os::unix::fs::{MetadataExt,PermissionsExt}};
use serde_json::{json,Value};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/backing-control176";
const P:&str="/home/ubuntu/src/zopro-perf-work/branch-control-audit176";
const ORIG:&str="/home/ubuntu/src/zopro-perf-work/seed-naf-callers176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn write(name:&str,s:String){let p=format!("{R}/{name}");assert!(!Path::new(&p).exists());fs::write(p,s).unwrap();}
fn replace(s:String,a:&str,b:&str)->String{assert!(s.contains(a),"missing transform: {a}");s.replace(a,b)}
fn main(){
    assert!(!Path::new(&format!("{R}/files.json")).exists());fs::create_dir(format!("{R}/elf")).unwrap();
    let oldpins=read(format!("{ORIG}/capture-pins.json"));let mut files=vec![];let mut inodes=BTreeSet::new();
    for backing in ["shared","copied"]{for arm in ["REF","OFF"]{
        let source=format!("{ORIG}/bench-{arm}");let path=format!("{R}/elf/{backing}-{arm}");let bytes=fs::read(&source).unwrap();let hash=format!("{:x}",Sha256::digest(&bytes));assert_eq!(oldpins[&source],hash);
        let old=fs::metadata(&source).unwrap();
        if backing=="shared"{fs::hard_link(&source,&path).unwrap();}else{fs::write(&path,&bytes).unwrap();fs::set_permissions(&path,fs::Permissions::from_mode(old.mode())).unwrap();}
        let m=fs::metadata(&path).unwrap();assert_eq!(fs::read(&path).unwrap(),bytes);assert_eq!((m.dev(),m.ino())==(old.dev(),old.ino()),backing=="shared");assert!(inodes.insert((m.dev(),m.ino())));
        assert_eq!(path.len(),format!("{R}/elf/shared-REF").len());
        files.push(json!({"cell":format!("{backing}-{arm}"),"path":path,"source":source,"sha256":hash,"dev":m.dev(),"inode":m.ino(),"source_dev":old.dev(),"source_inode":old.ino(),"bytes":bytes.len(),"mode":m.mode(),"same_inode_as_source":backing=="shared"}));
    }}
    fs::write(format!("{R}/files.json"),serde_json::to_vec_pretty(&files).unwrap()).unwrap();
    // Derive the same independent reader logic, with both interventions and
    // exact counter key sets changed prospectively before first preflight.
    let parent=|file:&str|fs::read_to_string(format!("{P}/{file}")).unwrap();
    let transform=|s:String|s.replace(P,R).replace("default","shared").replace("fixed","copied");
    let mut analysis=transform(parent("analysis-main.rs"));
    analysis=replace(analysis,"let copied_mapping_equal=mappings[\"copied-REF\"]==mappings[\"copied-OFF\"];","let copied_mapping_equal=mappings.values().collect::<BTreeSet<_>>().len()==1;");
    analysis=replace(analysis,"\"causal_branch_identified\":false,","\"causal_branch_identified\":false,\"backing_files\":read(r(\"files.json\")),");
    write("analysis-main.rs",analysis);
    let mut review=transform(parent("review.rs"));
    review=replace(review,"latency-{cell}-b","latency-base-{cell}-b");
    review=replace(review,"72processes/five contrasts/eight diagnostic panels","84processes/five contrasts/twenty diagnostic panels");
    review=replace(review,"assert_eq!(events,4);","assert_eq!(events,j[\"events\"].as_array().unwrap().len());");
    review=replace(review,"d[\"events\"][f[2].trim()]","d[\"events\"][event_key(f[2].trim())]");
    review=replace(review,"assert_eq!(diagnostic_count,8);","assert_eq!(diagnostic_count,20);");
    review=replace(review,"\"GNU_objcopy_independent_section_equality_confirmed\":true,","\"GNU_objcopy_independent_section_equality_confirmed\":true,\"four_input_inode_and_hash_bindings_rechecked\":true,");
    review=replace(review,"// GNU objcopy supplies a second section extractor.","for f in read(r(\"files.json\")).as_array().unwrap(){use std::os::unix::fs::MetadataExt;let p=f[\"path\"].as_str().unwrap();let m=fs::metadata(p).unwrap();assert_eq!(m.dev(),f[\"dev\"]);assert_eq!(m.ino(),f[\"inode\"]);assert_eq!(hash(p),f[\"sha256\"]);assert_eq!(hash(f[\"source\"].as_str().unwrap()),f[\"sha256\"]);}\n    // GNU objcopy supplies a second section extractor.");
    write("review.rs",review);
    write("loss.rs",transform(parent("loss.rs")));
    let mut prep=transform(parent("prepare.rs"));
    prep=replace(prep,"use serde_json::{json,Value};", "include!(\"counters.rs\");\nuse serde_json::{json,Value};");
    prep=replace(prep,"let binary=format!(\"{OLD}/bench-{arm}\");","let binary=format!(\"{R}/elf/{cell}\");");
    prep=replace(prep,"let name=format!(\"{panel}-{cell}-b{block:02}\");","let (panel,group)=if panel==\"opcache\"||panel==\"ifill\"||panel==\"itlb\"{(\"stat\",panel)}else{(panel,\"base\")};let name=format!(\"{panel}-{group}-{cell}-b{block:02}\");let events=group_events(group);");
    prep=replace(prep,"\"{cycles:u,instructions:u,cache-misses:u,branch-misses:u}\".into()","format!(\"{{{}}}\",events.join(\",\"))");
    prep=replace(prep,"if layout==\"copied\"{argv.extend([\"setarch\".into(),\"x86_64\".into(),\"-R\".into()]);}","argv.extend([\"setarch\".into(),\"x86_64\".into(),\"-R\".into()]);");
    prep=replace(prep,"\"data\":data}","\"data\":data,\"events\":events.iter().map(|e|event_key(e)).collect::<Vec<_>>(),\"counter_group\":group}");
    prep=replace(prep,"let prefix=prefix.split_once(\"\\nfn main() {\").unwrap().0;","let prefix=prefix.split_once(\"\\nfn main() {\").unwrap().0;let prefix=prefix.replace(\"events.insert(f[2].trim().to_owned()\",\"events.insert(event_key(f[2].trim())\").replace(\"assert_eq!(events.keys().map(String::as_str).collect::<BTreeSet<_>>(),BTreeSet::from([\\\"cycles:u\\\",\\\"instructions:u\\\",\\\"cache-misses:u\\\",\\\"branch-misses:u\\\"]));\",\"assert_eq!(events.keys().cloned().collect::<BTreeSet<_>>(),j[\\\"events\\\"].as_array().unwrap().iter().map(|s|s.as_str().unwrap().to_owned()).collect());\");");
    prep=replace(prep,"fs::write(r(\"common.rs\"),common).unwrap();","fs::write(r(\"common.rs\"),format!(\"{common}\\ninclude!(\\\"counters.rs\\\");\\n\")).unwrap();");
    prep=replace(prep,"\"audit.rs\",\"audit.json\"","\"files.json\",\"counters.rs\",\"probe-review.json\",\"adapt.rs\"");
    prep=replace(prep,"for panel in [\"stat\",\"cycles\"]","for panel in [\"stat\",\"opcache\",\"ifill\",\"itlb\",\"cycles\"]");
    prep=replace(prep,"assert_eq!(jobs.len(),72)","assert_eq!(jobs.len(),84)");
    prep=replace(prep,"assert_eq!(steps.len(),92)","assert_eq!(steps.len(),104)");
    prep=replace(prep,"let cells=[\"shared-REF\",\"shared-OFF\",\"copied-REF\",\"copied-OFF\"];let mut steps", "for f in serde_json::from_slice::<Value>(&fs::read(r(\"files.json\")).unwrap()).unwrap().as_array().unwrap(){let p=f[\"path\"].as_str().unwrap();assert_eq!(hash(p),f[\"sha256\"]);pins.insert(p.to_owned(),hash(p));}\n    let cells=[\"shared-REF\",\"shared-OFF\",\"copied-REF\",\"copied-OFF\"];let mut steps");
    write("prepare.rs",prep);
    println!("Created four equal-length hardlink/copy paths; content and four distinct inode bindings validated; derived readers before preflight");
}
