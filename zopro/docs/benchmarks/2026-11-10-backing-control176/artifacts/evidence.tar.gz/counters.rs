// Linux v6.17 perf amdzen5 definitions; see sources/ and source URLs in design.
// Event 0x18e is deliberately not used.
fn event_key(s: &str) -> String {
    let s=s.trim();
    if let Some(raw)=s.strip_prefix("cpu/") {
        let raw=raw.strip_suffix("/u").unwrap();let mut event=None;let mut mask=0;
        for pair in raw.split(','){let(k,v)=pair.split_once('=').unwrap();let n=u64::from_str_radix(v.trim().trim_start_matches("0x"),16).unwrap();match k.trim(){"event"=>event=Some(n),"umask"=>mask=n,_=>panic!("unexpected PMU field")}}
        format!("cpu/{:#x}:{mask:#x}/u",event.unwrap())
    }else{s.to_owned()}
}
fn group_events(group: &str) -> Vec<String> {
    let extra: [&str;2]=match group {
        "base"=>["cache-misses:u","branch-misses:u"],
        "opcache"=>["cpu/event=0x28f,umask=0x03/u","cpu/event=0x28f,umask=0x04/u"],
        "ifill"=>["cpu/event=0x82,umask=0x00/u","cpu/event=0x83,umask=0x00/u"],
        "itlb"=>["cpu/event=0x84,umask=0x00/u","cpu/event=0x85,umask=0x0f/u"],
        _=>panic!("unknown counter group")
    };
    ["cycles:u","instructions:u",extra[0],extra[1]].map(str::to_owned).to_vec()
}
