//! Check availability and primary event metadata before the backing experiment.
include!("counters.rs");
use std::{collections::BTreeMap,fs,path::Path};
use serde_json::{json,Value};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/backing-control176";
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn save(f:&str,v:&Value){fs::write(format!("{R}/{f}"),serde_json::to_vec_pretty(v).unwrap()).unwrap();}
fn read(f:&str)->Value{serde_json::from_slice(&fs::read(format!("{R}/{f}")).unwrap()).unwrap()}
fn main(){match std::env::args().nth(1).as_deref(){Some("prepare")=>{
    assert!(!Path::new(&format!("{R}/probe-plan.json")).exists());fs::create_dir(format!("{R}/probe-data")).unwrap();
    assert_eq!(fs::read_to_string("/sys/bus/event_source/devices/cpu/format/event").unwrap().trim(),"config:0-7,32-35");
    assert_eq!(fs::read_to_string("/sys/bus/event_source/devices/cpu/format/umask").unwrap().trim(),"config:8-15");
    let cpu=fs::read_to_string("/proc/cpuinfo").unwrap();let values=cpu.split("\n\n").next().unwrap().lines().filter_map(|l|l.split_once(':')).map(|(a,b)|(a.trim(),b.trim())).collect::<BTreeMap<_,_>>();assert_eq!(values["cpu family"],"26");assert_eq!(values["model"],"68");
    let mapping=fs::read_to_string(format!("{R}/sources/mapfile.csv")).unwrap();assert!(mapping.contains("AuthenticAMD-26-[[:xdigit:]]+,v1,amdzen5,core"));
    let mut events=read("sources/inst-cache.json").as_array().unwrap().clone();events.extend(read("sources/branch-prediction.json").as_array().unwrap().iter().cloned());
    let mut selected=vec![];
    for(name,code,mask)in[("ic_cache_fill_l2",0x82,0),("ic_cache_fill_sys",0x83,0),("op_cache_hit_miss.op_cache_hit",0x28f,3),("op_cache_hit_miss.op_cache_miss",0x28f,4),("bp_l1_tlb_miss_l2_tlb_hit",0x84,0),("bp_l1_tlb_miss_l2_tlb_miss.all",0x85,15)]{
        let e=events.iter().find(|e|e["EventName"]==name).unwrap();let number=|s:&str|u64::from_str_radix(s.trim_start_matches("0x"),16).unwrap();assert_eq!(number(e["EventCode"].as_str().unwrap()),code);assert_eq!(e["UMask"].as_str().map(number).unwrap_or(0),mask);
        selected.push(json!({"event_name":name,"event_code":code,"umask":mask,"source":"Linux v6.17 perf amdzen5 event definitions","event_key":event_key(&format!("cpu/event={code:#x},umask={mask:#x}/u"))}));
    }
    save("counter-definitions.json",&json!({"host_family":26,"host_model":68,"host_stepping":values["stepping"],"primary_mapping_version":"linux-v6.17","excluded_event":"0x18e","selected":selected,"sources":["https://github.com/torvalds/linux/blob/v6.17/tools/perf/pmu-events/arch/x86/mapfile.csv","https://github.com/torvalds/linux/blob/v6.17/tools/perf/pmu-events/arch/x86/amdzen5/inst-cache.json","https://github.com/torvalds/linux/blob/v6.17/tools/perf/pmu-events/arch/x86/amdzen5/branch-prediction.json"]}));
    let steps=["base","opcache","ifill","itlb"].map(|group|json!({"kind":"command","name":format!("probe-{group}"),"argv":["sudo","-n","perf","stat","--no-big-num","-x",";","-e",format!("{{{}}}",group_events(group).join(",")),"-o",format!("{R}/probe-data/{group}.csv"),"--","/usr/bin/true"],"environment":{},"timeout_seconds":60}));
    let mut pins=BTreeMap::new();for f in ["probe.rs","probe","counters.rs","counter-definitions.json","sources/mapfile.csv","sources/inst-cache.json","sources/branch-prediction.json"]{let p=format!("{R}/{f}");pins.insert(p.clone(),hash(p));}for p in ["/usr/bin/perf","/usr/bin/sudo","/usr/bin/true"]{pins.insert(p.to_owned(),hash(p));}
    save("probe-pins.json",&json!(pins));save("probe-plan.json",&json!({"version":1,"source_pins":format!("{R}/probe-pins.json"),"steps":steps}));println!("four availability probes frozen; selected raw events verified against family26 upstream metadata; no prover timing");
},Some("review")=>{
    assert_eq!(read("probe-runs/result.json")["status"],"complete");let mut panels=vec![];
    for group in ["base","opcache","ifill","itlb"]{let exit=read(&format!("probe-runs/probe-{group}/exit.json"));assert_eq!(exit["returncode"],0);assert_eq!(exit["success"],true);let text=fs::read_to_string(format!("{R}/probe-data/{group}.csv")).unwrap();let mut observed=BTreeMap::new();
        for l in text.lines().filter(|l|!l.trim().is_empty()&&!l.starts_with('#')){let f=l.split(';').collect::<Vec<_>>();let n=f[0].trim().parse::<f64>().unwrap();let runtime=f[3].trim().parse::<f64>().unwrap();let coverage=f[4].trim().parse::<f64>().unwrap();assert!(n.is_finite()&&n>=0.&&runtime.is_finite()&&runtime>0.&&coverage.is_finite()&&coverage>=99.9);observed.insert(event_key(f[2]),json!({"count":n,"runtime_ns":runtime,"running_percent":coverage}));}
        let mut expected=group_events(group).iter().map(|s|event_key(s)).collect::<Vec<_>>();expected.sort();assert_eq!(expected,observed.keys().cloned().collect::<Vec<_>>());panels.push(json!({"group":group,"events":observed}));
    }
    for(p,h)in read("probe-pins.json").as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
    save("probe-review.json",&json!({"passed":true,"availability_only_not_semantic_or_prover_validation":true,"panels":panels}));println!("four raw/generic event groups available with >=99.9% running; availability only, no prover measurement");
},_=>panic!("prepare|review")}}
