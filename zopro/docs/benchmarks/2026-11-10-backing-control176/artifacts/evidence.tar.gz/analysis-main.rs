fn main(){
    assert_eq!(read(r("runs/result.json"))["status"],"complete");assert!(!r("analysis.json").exists());
    for(p,h)in read(r("pins.json")).as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
    let plan=read(r("plan.json"));for s in plan["steps"].as_array().unwrap(){receipt(s);}
    let jobs=read(r("jobs.json"));let mut rows=vec![];let mut diagnostics=vec![];let mut mappings=BTreeMap::new();
    for j in jobs.as_array().unwrap(){let(m,s)=output(j);let mut row=j.clone();row["median_ns"]=m.into();row["summary"]=s.clone();rows.push(row);
        if ["stat","cycles"].contains(&j["panel"].as_str().unwrap()){diagnostics.push(diagnostic(j,&s));}
        if j["panel"]=="cycles"{let name=j["name"].as_str().unwrap();let meta=fs::read_to_string(r(format!("runs/metadata-{name}/stdout.log"))).unwrap();let starts=meta.lines().filter(|l|l.contains("PERF_RECORD_MMAP")&&l.contains(j["binary"].as_str().unwrap())&&l.contains(": r-xp ")).map(|l|{let tail=l.split_once(": [").unwrap().1;u64::from_str_radix(tail.split_once('(').unwrap().0.trim_start_matches("0x"),16).unwrap()}).collect::<BTreeSet<_>>();assert_eq!(starts.len(),1);mappings.insert(j["cell"].as_str().unwrap().to_owned(),*starts.first().unwrap());}
    }
    let mut series=BTreeMap::new();
    for cell in ["shared-REF","shared-OFF","copied-REF","copied-OFF"]{let values=(0..15).map(|b|rows.iter().find(|j|j["panel"]=="latency"&&j["cell"]==cell&&j["block"]==b).unwrap()["median_ns"].as_f64().unwrap()).collect::<Vec<_>>();series.insert(cell.to_owned(),values);}
    let mut contrasts=BTreeMap::new();
    for(label,n,d)in[("shared-OFF/REF","shared-OFF","shared-REF"),("copied-OFF/REF","copied-OFF","copied-REF"),("REF-copied/shared","copied-REF","shared-REF"),("OFF-copied/shared","copied-OFF","shared-OFF")] {contrasts.insert(label.to_owned(),statistics::contrast(&series[n],&series[d]));}
    let ratios=|layout:&str|(0..15).map(|b|series[&format!("{layout}-OFF")][b]/series[&format!("{layout}-REF")][b]).collect::<Vec<_>>();
    contrasts.insert("interaction-copied/shared-control-ratio".into(),statistics::contrast(&ratios("copied"),&ratios("shared")));
    let copied_mapping_equal=mappings.values().collect::<BTreeSet<_>>().len()==1;
    let qualified=diagnostics.iter().all(|d|d["qualified"]==true)&&copied_mapping_equal;
    save(r("analysis.json"),&json!({"diagnostic_qualified":qualified,"production_changed":false,"new_proof_speedup_measured":false,"rows":rows,"diagnostics":diagnostics,"series":series,"contrasts":contrasts,"profile_executable_mmap_starts":mappings,"copied_profile_mmap_starts_equal":copied_mapping_equal,"causal_branch_identified":false,"backing_files":read(r("files.json")),"canonical_proofs_unchanged":47437}));
    println!("backing diagnostic qualified={qualified}; four cells, five declared contrasts; no arithmetic candidate/adoption");
}
