use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    fmt::Write as _,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/xyzz-fallback176";
const D: &str = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-xyzz-fallback-math176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn walk(p: &Path, out: &mut Vec<PathBuf>) {
    for e in fs::read_dir(p).unwrap() {
        let e = e.unwrap();
        if e.file_type().unwrap().is_dir() {
            walk(&e.path(), out)
        } else if e.file_type().unwrap().is_file() {
            out.push(e.path())
        }
    }
}
fn main() {
    assert!(!Path::new(D).exists());
    let q = read(format!("{R}/review-result.json"));
    assert_eq!(q["passed"], true);
    assert_eq!(q["checks_per_backend"], 38208);
    for (p, h) in read(format!("{R}/pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let decision = json!({"arithmetic_qualified":true,"native_Window_integrated":false,"memory_forecast_integrated":false,"performance_measured":false,"adopted":false,"production_unchanged":true,"mixed_add_static_work_lower":true,"doubling_static_work_higher":true,"one_extra_base_field_per_sparse_point":true,"small_residual_path_not_standalone_twofold_route":true,"next":"Qualified isolated sparse Window integration with charged memory/originalfallback, complete caller oracles/measurements before SDK","new_SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":43730,"goal_active":true,"goal_complete":false,"targets_met":0});
    save(format!("{R}/decision.json"), decision);
    fs::create_dir_all(format!("{D}/artifacts")).unwrap();
    for f in [
        "xyzz.rs",
        "tests.rs",
        "design.md",
        "next.md",
        "review-result.json",
        "decision.json",
    ] {
        fs::copy(format!("{R}/{f}"), format!("{D}/artifacts/{f}")).unwrap();
    }
    let mut report=String::from("# XYZZ sparse fallback: arithmetic qualification\n\n**The new Rust arithmetic passes independent checks with native and generic field libraries. It is not integrated into the prover or timed.** Production and accepted proof latency remain unchanged.\n\nThe proposed use is the sparse projective fallback for collisions and exceptional additions. Ordinary shared-inversion affine batches retain their current implementation. XYZZ stores X,Y,Z²,Z³. The [EFD Sutherland formulas](https://www.hyperelliptic.org/EFD/g1p/auto-shortw-xyzz.html) provide mixed addition and normalization; specializing doubling to the current a=0 curves removes its a-dependent square. The implementation adds no special unit-Z branch, initial-state tag, point table, transformed key, pool or assembly. Prior full-projective-stream and initial-unit experiments stay closed. The earlier triple-affine review mentioned XYZZ versus affine, but did not implement this sparse fallback replacement.\n\n|Base-field work, excluding identity/exception branches|Current Jacobian|XYZZ helper|\n|---|---:|---:|\n|Mixed addition|7M + 4S|8M + 2S|\n|Doubling for a=0|2M + 5S|6M + 3S|\n|Normalization after recovering an inverse|3M + 1S|3M + 1S|\n\nThese are source operation counts, not latency measurements. Scalar Fq square currently dispatches through the same multiplication entry; Fq2 has different relative costs. Mixed addition may benefit, while doubling can cost more. Batch normalization shares one inversion of nonzero Z³ values; it does not require two inverse passes. Identity, equal/opposite points, cancellation and doubling retain complete handling. This targets a small residual path and is not a standalone route to the required twofold primary improvement.\n\n|Logical point payload|Current Jacobian|XYZZ|Increase per sparse point|\n|---|---:|---:|---:|\n|G1|96 bytes|128 bytes|32 bytes|\n|G2|192 bytes|256 bytes|64 bytes|\n\nThe 33.3% increase applies to each sparse accumulator, not the whole proof or key. Future integration must charge every additional capacity and normalization buffer, preserve the original memory-denied/generic fallback, and measure actual peak memory. This stage establishes no process RSS, minimum RAM or pressure result.\n\nFour new focused test functions pass against both the exact original native field1200 and the preexisting generic noASM/noIFMA field library. Each backend executes 38,208 checks across G1/G2: 16,386 pair/raw and 2,718 changing-chain/batch/final-merge checks per curve. The two backends use the same fixtures; eight test executions do not double distinct mathematical coverage.\n\nIndependent Arkworks generator-weight results use full-width scalar coefficients. Nonidentity states also check ZZ³=ZZZ² and X=x·ZZ,Y=y·ZZZ in Arkworks, preventing normalization alone from masking an incorrect projective representation. Cases include identity numerators, variable scales, repeated/opposite points, cancellation, doubling, negation, changing state chains, ordinary-affine final merge and immutable batch conversion at lengths 0/1/7/8/9/31/128/257. This is arithmetic qualification, not a complete Window, MSM, Phi-phase or proof test.\n\nAll four serialized Rust1.98.1/xtask commands succeed first execution: native test build/run and generic build/run. Both consumers use O3, one CGU, debug assertions and overflow checks. The original field libraries and inherited suites are not rebuilt or rerun. A separate Rust reader checks 189 pins, all command/stream receipts, independent fixture-count arithmetic, payload sizes and all 176 production hashes. The unused test-import warning remains without a cleanup rebuild. Setup/review/publication helper invocations are outside those four receipts.\n\nNext is isolated actual sparse-Window integration with checked accounting, original fallback, both Phi phases, complete queue/finalization and real worker/concurrent-caller tests. A subsequent complete caller comparison must include doubling, allocation, merge, normalization, dispatch and memory. An isolated mixed-add timing would not select production code. No optimization is adopted from this stage.\n\nThe following accepted local 32-worker full-proof timings and supplied M5 references are inherited from the latest unchanged SDK campaign. There are no new SDK requests, Gnark exports, performance captures or profiles; the canonical inventory remains 43,730. The full CPU10× goal remains active and unmet, **0/8**.\n\n|Shape|Accepted CPU ms|M5 CPU ms /speedup|M5 Metal ms /speedup|CPU10× target ms|\n|---|---:|---:|---:|---:|\n");
    let comp = read("/home/ubuntu/src/zopro-perf-work/large-class-sdk176/fresh-comparison.json");
    for row in comp["rows"].as_array().unwrap() {
        writeln!(
            report,
            "|{}|{:.6}|{:.1} /{:.3}×|{:.1} /{:.3}×|{:.1}|",
            row["shape"].as_str().unwrap(),
            row["REF_CPU_ms"].as_f64().unwrap(),
            row["M5_CPU_ms"].as_f64().unwrap(),
            row["REF_CPU_speedup"].as_f64().unwrap(),
            row["M5_Metal_ms"].as_f64().unwrap(),
            row["REF_Metal_speedup"].as_f64().unwrap(),
            row["CPU_10x_target_ms"].as_f64().unwrap()
        )
        .unwrap();
    }
    report.push_str("\nAccepted primary peak RSS remains 133.50 MiB; merge54 remains 162.541995 ms without a supplied M5 reference. These cross-machine references are not new Apple measurements. No new AWS/Aeglos, mobile/ARM, huge-circuit, pressure/swap, minimum-RAM or throughput evidence is added.\n\n[Helper](artifacts/xyzz.rs), [independent tests](artifacts/tests.rs), [review](artifacts/review-result.json), [design](artifacts/design.md), [decision](artifacts/decision.json), [continuation](artifacts/next.md), [sources and receipts](sources-receipts.tar.gz), [archive index](artifacts/archive-index.json), [checksums](SHA256SUMS). Private root: /home/ubuntu/src/zopro-perf-work/xyzz-fallback176. Executables/libraries, unchanged source copies, private key/input/witness/proof data and the full ledger remain local.\n");
    fs::write(format!("{D}/README.md"), &report).unwrap();
    let pack = PathBuf::from(format!("{R}/publication-source"));
    fs::create_dir(&pack).unwrap();
    let mut files = vec![];
    for f in [
        "xyzz.rs",
        "tests.rs",
        "prepare.rs",
        "review.rs",
        "publish.rs",
        "design.md",
        "next.md",
        "review-result.json",
        "decision.json",
        "plan.json",
        "pins.json",
    ] {
        files.push(PathBuf::from(format!("{R}/{f}")));
    }
    walk(Path::new(&format!("{R}/runs")), &mut files);
    let mut members = vec![];
    for p in files {
        let rel = p.strip_prefix(R).unwrap();
        let bytes = fs::read(&p).unwrap();
        assert!(std::str::from_utf8(&bytes).is_ok());
        let to = pack.join(rel);
        fs::create_dir_all(to.parent().unwrap()).unwrap();
        fs::write(&to, &bytes).unwrap();
        members.push(json!({"path":rel,"sha256":hash(to),"bytes":bytes.len()}));
    }
    let archive = format!("{D}/sources-receipts.tar.gz");
    assert!(Command::new("tar")
        .args(["-czf", &archive, "-C", pack.to_str().unwrap(), "."])
        .status()
        .unwrap()
        .success());
    let round = format!("{R}/publication-roundtrip");
    fs::create_dir(&round).unwrap();
    assert!(Command::new("tar")
        .args(["-xzf", &archive, "-C", &round, "."])
        .status()
        .unwrap()
        .success());
    for m in &members {
        assert_eq!(
            hash(Path::new(&round).join(m["path"].as_str().unwrap())),
            m["sha256"]
        );
    }
    save(
        format!("{D}/artifacts/archive-index.json"),
        json!({"archive_sha256":hash(&archive),"members":members,"ledger_sha256":q["ledger_sha256"],"excluded":"executables/libraries,full unchanged source,privatekey/input/witness/proof,fullledger"}),
    );
    fs::write(format!("{D}/SHA256SUMS"), "").unwrap();
    let mut links = 0;
    for s in report.split("](").skip(1) {
        let p = s.split(')').next().unwrap();
        if p.starts_with("https://") {
            continue;
        }
        assert!(Path::new(D).join(p).exists(), "{p}");
        links += 1;
    }
    let p = json!({"passed":true,"workflow_commands":4,"test_functions":4,"backend_executions":8,"checks_per_backend":38208,"archive_members":members.len(),"archive_roundtrip":true,"links":links,"production176_unchanged":true,"native_Window_integrated":false,"performance_measured":false,"new_SDK_requests":0,"new_Gnark_exports":0,"canonical_proofs":43730,"adopted":false,"goal_active":true,"goal_complete":false,"targets_met":0});
    save(format!("{R}/publication.json"), p.clone());
    save(format!("{D}/artifacts/publication.json"), p);
    let mut files = vec![];
    walk(Path::new(D), &mut files);
    files.sort();
    let mut sums = String::new();
    for p in files {
        if p.file_name().unwrap() == "SHA256SUMS" {
            continue;
        }
        writeln!(
            sums,
            "{}  {}",
            hash(&p),
            p.strip_prefix(D).unwrap().display()
        )
        .unwrap();
    }
    fs::write(format!("{D}/SHA256SUMS"), &sums).unwrap();
    for line in sums.lines() {
        let (h, p) = line.split_once("  ").unwrap();
        assert_eq!(hash(Path::new(D).join(p)), h);
    }
    println!("XYZZ_PUBLICATION_PASS{}members/{links}links;arithmeticqualified/nocallerorspeedclaim;canonical43730;goalactive0of8",members.len());
}
