fn dispatch(threads:&Value)->Value{
 let mut bykey=BTreeMap::<(u64,u64),[Vec<u64>;4]>::new();for t in threads.as_array().unwrap(){for e in t["events"].as_array().unwrap(){let e=e.as_array().unwrap();let kind=e[1].as_u64().unwrap();if(1..=4).contains(&kind){bykey.entry((e[2].as_u64().unwrap(),e[3].as_u64().unwrap())).or_default()[(kind-1)as usize].push(e[0].as_u64().unwrap());}}}
 let mut nodes=vec![];let mut ambiguous=0;for(key,mut times)in bykey{let count=times[0].len();assert!(count>0);for v in &mut times{assert_eq!(v.len(),count);v.sort_unstable();}let unambiguous=(0..count).all(|i|times[0][i]<=times[1][i]&&times[0][i]<=times[2][i]&&times[2][i]<=times[3][i]&&(i+1==count||times[1][i].max(times[3][i])<=times[0][i+1]));if !unambiguous{ambiguous+=count;continue;}
  for i in 0..count{nodes.push(json!({"key":[key.0,key.1],"generation":i,"publication_before":times[0][i],"publication_after":times[1][i],"start":times[2][i],"end":times[3][i],"dispatch_lower_ns":times[2][i].saturating_sub(times[1][i]),"dispatch_upper_ns":times[2][i]-times[0][i]}));}
 }
 json!({"unambiguous_jobs":nodes.len(),"ambiguous_jobs":ambiguous,"nodes":nodes})
}
fn selftest(){let row=|time,kind|json!([time,kind,11,22,0,0,0,0]);let input=|rows:Vec<Value>|json!([{"events":rows}]);let a=dispatch(&input(vec![row(10,1),row(20,2),row(30,3),row(40,4)]));assert_eq!(a["nodes"][0]["dispatch_lower_ns"],10);assert_eq!(a["nodes"][0]["dispatch_upper_ns"],20);
 let b=dispatch(&input(vec![row(10,1),row(30,2),row(20,3),row(25,4)]));assert_eq!(b["unambiguous_jobs"],1);assert_eq!(b["nodes"][0]["dispatch_lower_ns"],0);assert_eq!(b["nodes"][0]["dispatch_upper_ns"],10);
 let c=dispatch(&input(vec![row(10,1),row(12,2),row(14,3),row(16,4),row(20,1),row(22,2),row(24,3),row(26,4)]));assert_eq!(c["unambiguous_jobs"],2);
 let d=dispatch(&input(vec![row(10,1),row(11,1),row(12,2),row(13,2),row(14,3),row(15,3),row(16,4),row(17,4)]));assert_eq!(d["ambiguous_jobs"],2);assert_eq!(d["unambiguous_jobs"],0);println!("PASS4dispatchinterval/reuse/fastthief/overlapmodels");}
