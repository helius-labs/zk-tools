//! Measure verified SDK requests against an existing CPU key image.
use std::{fs, path::Path, sync::Arc, time::Instant};
#[path = "support/perf.rs"]
mod perf;

#[global_allocator]
static ALLOCATOR: zopro_prover::zopro_core::alloc::Allocator =
    zopro_prover::zopro_core::alloc::Allocator;

#[path="trace-check.rs"]mod trace_check;
fn main()->Result<(),Box<dyn std::error::Error>>{
 use zopro_prover::zopro_core::task_lifecycle as trace;
 let args=std::env::args_os().collect::<Vec<_>>();if args.len()!=5{return Err("driver IMAGE REQUEST ROUNDS PROOF_DIR".into());}let rounds=args[3].to_str().unwrap().parse::<usize>()?;assert!(rounds>0);let enabled=std::env::var("ZOPRO_TASK_TRACE").as_deref()==Ok("1");let placement_before=placement_setup()?;let workers=rayon::current_num_threads();let file=fs::File::open(&args[1])?;let image=unsafe{memmap2::Mmap::map(&file)?};drop(file);let prover=zopro_prover::Prover::load_image(Arc::new(image))?;let mut sdk=zopro_zolana::Prover::new(prover)?;let request=fs::read_to_string(&args[2])?;
 for _ in 0..3{std::hint::black_box(sdk.prove(&request)?);}
 let mut times=Vec::with_capacity(rounds);let mut graphs=Vec::new();let mut last=None;let mut total_events=0usize;let before=perf::Usage::now()?;let wall=Instant::now();
 for round in 0..rounds{
  let capture=if enabled{trace::prepare_current(trace::EXTERNAL,0,8192)?;rayon::broadcast(|c|trace::prepare_current(c.index(),1,8192).unwrap());Some(trace::Session::begin()?)}else{None};
  let root=enabled.then(||trace::phase(1));let start=Instant::now();let proof=sdk.prove(&request)?;let elapsed=start.elapsed().as_nanos()as u64;drop(root);times.push(elapsed);last=Some(proof);
  if let Some(capture)=capture{let done=capture.stop();let mut snapshots=rayon::broadcast(|_|trace::take_current().unwrap());snapshots.push(trace::take_current()?);let checked=trace_check::check(&done,&snapshots,workers);total_events+=checked["events"].as_u64().unwrap()as usize;if [0,15,30].contains(&round){graphs.push(serde_json::json!({"round":round,"begin_ns":done.begin_ns,"end_ns":done.end_ns,"check":checked,"threads":snapshots.iter().map(|s|serde_json::json!({"worker":s.worker,"pool":s.pool,"capacity":s.capacity,"dropped":s.dropped,"late":s.late,"outstanding":s.outstanding,"events":s.events})).collect::<Vec<_>>()}));}drop(done);}
 }
 let loop_wall_ms=wall.elapsed().as_secs_f64()*1000.;let after=perf::Usage::now()?;let placement_after=placement_snapshot("fixed",&placement_before["main_allowed"].as_array().unwrap().iter().map(|n|n.as_u64().unwrap()as usize).collect::<Vec<_>>(),workers)?;assert_eq!(placement_before,placement_after);let dest=Path::new(&args[4]);fs::create_dir_all(dest)?;let proof=last.unwrap();fs::write(dest.join("0.proof"),proof.proof)?;fs::write(dest.join("0.public"),proof.public_inputs)?;fs::write(dest.join("graphs.json"),serde_json::to_vec(&graphs)?)?;
 for(round,ns)in times.into_iter().enumerate(){println!("SAMPLE {}",serde_json::json!({"round":round,"ns":ns,"ms":ns as f64/1e6}));}let mut summary=after.difference(&before);summary["rounds"]=rounds.into();summary["priming"]=3.into();summary["workers"]=workers.into();summary["loop_wall_ms"]=loop_wall_ms.into();summary["placement_before"]=placement_before;summary["placement_after"]=placement_after;println!("SUMMARY {summary}");println!("TASK_TRACE {}",serde_json::json!({"enabled":enabled,"events":total_events,"retained_graphs":graphs.len(),"capacity_per_thread":8192,"all_enabled_requests_validated":true,"setup_and_checking_outside_sdk_timer":true,"whole_loop_usage_includes_observer_setup_and_checking":true}));Ok(())
}

fn placement_setup()->Result<serde_json::Value,Box<dyn std::error::Error>>{
    let mode=std::env::var("ZOPRO_BENCH_WORKER_PLACEMENT")?;
    if mode!="unbound"&&mode!="fixed"{return Err("placement must be unbound or fixed".into());}
    let workers:usize=std::env::var("RAYON_NUM_THREADS")?.parse()?;
    let allowed=placement_affinity()?;
    if workers!=allowed.len(){return Err("one worker per inherited logical CPU is required".into());}
    let start_allowed=allowed.clone();let fixed=mode=="fixed";
    rayon::ThreadPoolBuilder::new().num_threads(workers).start_handler(move|i|{
        if fixed {placement_pin(start_allowed[i]).expect("worker affinity");}
    }).build_global()?;
    placement_snapshot(&mode,&allowed,workers)
}
fn placement_affinity()->Result<Vec<usize>,std::io::Error>{
    let mut set=std::mem::MaybeUninit::<libc::cpu_set_t>::zeroed();
    // SAFETY: getaffinity initializes a cpu_set_t-sized local set on success.
    if unsafe{libc::sched_getaffinity(0,std::mem::size_of::<libc::cpu_set_t>(),set.as_mut_ptr())}!=0{return Err(std::io::Error::last_os_error());}
    let set=unsafe{set.assume_init()};Ok((0..libc::CPU_SETSIZE as usize).filter(|&i|unsafe{libc::CPU_ISSET(i,&set)}).collect())
}
fn placement_pin(cpu:usize)->Result<(),std::io::Error>{
    let mut set=unsafe{std::mem::zeroed::<libc::cpu_set_t>()};
    // SAFETY: cpu came from getaffinity, inside CPU_SETSIZE; target is this thread only.
    unsafe{libc::CPU_ZERO(&mut set);libc::CPU_SET(cpu,&mut set);}
    if unsafe{libc::sched_setaffinity(0,std::mem::size_of::<libc::cpu_set_t>(),&set)}!=0{return Err(std::io::Error::last_os_error());}Ok(())
}
fn placement_snapshot(mode:&str,allowed:&[usize],workers:usize)->Result<serde_json::Value,Box<dyn std::error::Error>>{
    use std::collections::BTreeSet;
    let mut rows=rayon::broadcast(|ctx|{let worker=ctx.index();let tid=unsafe{libc::syscall(libc::SYS_gettid)};let mask=placement_affinity().expect("worker read affinity");assert_eq!(rayon::current_thread_index(),Some(worker));assert_eq!(mask,if mode=="fixed"{vec![allowed[worker]]}else{allowed.to_vec()});serde_json::json!({"index":worker,"tid":tid,"allowed":mask})});
    rows.sort_by_key(|v|v["index"].as_u64().unwrap());assert_eq!(rows.len(),workers);let tids=rows.iter().map(|r|r["tid"].as_u64().unwrap()).collect::<BTreeSet<_>>();assert_eq!(tids.len(),workers);let tasks=std::fs::read_dir("/proc/self/task")?.count();assert_eq!(tasks,workers+1);assert_eq!(placement_affinity()?,allowed);
    Ok(serde_json::json!({"mode":mode,"workers":workers,"main_allowed":allowed,"worker_rows":rows,"tasks":tasks}))
}
