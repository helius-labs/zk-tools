use std::{fs,path::Path};
use serde_json::{Value,json};
use sha2::{Digest,Sha256};
fn main(){
 let r=Path::new("/home/ubuntu/src/zopro-perf-work/task-interval-c7a176");
 assert!(!r.join("preflight-runs").exists());
 let p=r.join("preflight-plan.json");let bytes=fs::read(&p).unwrap();
 let mut v:Value=serde_json::from_slice(&bytes).unwrap();
 let a=v["steps"][0]["argv"].as_array_mut().unwrap();
 assert!(!a.iter().any(|x|x=="--group-add"));
 let pos=a.iter().position(|x|x=="--cap-drop").unwrap();
 a.splice(pos..pos,[json!("--group-add"),json!("1000")]);
 fs::write(r.join("preflight-plan-before-access-fix.json"),bytes).unwrap();
 fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap();
 let p=r.join("preflight-pins.json");let mut pins:Value=serde_json::from_slice(&fs::read(&p).unwrap()).unwrap();
 for f in ["stage.rs","stage","prepare-preflight-access.rs"]{let p=r.join(f);pins[p.display().to_string()]=json!(format!("{:x}",Sha256::digest(fs::read(&p).unwrap())));}
 fs::write(p,serde_json::to_vec_pretty(&pins).unwrap()).unwrap();
 let checkpoint=json!({"status":"container preflight prepared; not started","canonical_ledger":50137,"canonical_path":"/home/ubuntu/src/zopro-perf-work/task-interval-sdk176/proof-sha256-after-capture.json","native_workflow":"complete","docker_workflow":"complete","preflight_access_fix":"supplemental output group 1000, all capabilities still dropped; before any container request","new_AWS_resources":false,"goal":"active/unmet all8 verified 10x CPU"});
 fs::write(r.join("checkpoint.json"),serde_json::to_vec_pretty(&checkpoint).unwrap()).unwrap();
 let h=Path::new("/home/ubuntu/src/zopro-cpu-perf-handoff.md");let old=fs::read_to_string(h).unwrap();
 let top="CURRENT IN PROGRESS: task-interval-c7a176. Read /home/ubuntu/src/zopro-perf-work/task-interval-c7a176/checkpoint.json and design.md FIRST. Zen4 native qualification/build-runs complete, docker-runs complete; local container preflight prepared (preflight-plan.json), not yet run. Supplemental output group1000 fixes cap-drop write access BEFORE any request. Canonical STILL50137 from task-interval-sdk176/proof-sha256-after-capture.json until independently reviewed preflight50148. No new AWS resource/instance/runID yet. Next serialized xtask preflight-runs, only poll live handle during capture; never replay successful proofs for bookkeeping. Goal active/unmet0/8. Existing pushed localqualification6d97b8e remains below.\n\n";
 fs::write(h,format!("{top}{old}")).unwrap();
 println!("Prepared access fix and current checkpoint before any container proof");
}
