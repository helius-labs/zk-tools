// Independent coefficient/range model; no field/native module is imported.
fn add(a:&[i64],b:&[i64])->Vec<i64>{a.iter().zip(b).map(|(a,b)|a+b).collect()}
fn model(n:usize)->(Vec<i64>,usize,usize){
 let groups=n.div_ceil(256);let mut frames=vec![];let mut early=0;
 for g in 0..groups{let length=(n-g*256).min(256);assert!(length.is_power_of_two());let mut s=vec![(0..length).map(|i|{let mut v=vec![0i64;n];v[g*256+i]=1;v}).collect::<Vec<_>>()];
 while s[0].len()>8{let correction=s[0].iter().step_by(2).cloned().collect::<Vec<_>>();for segment in &mut s{*segment=segment.chunks_exact(2).map(|p|add(&p[0],&p[1])).collect();}s.push(correction);early+=1;}assert!(s.len()*s[0].len()<=55);frames.push(s);}
 let mut late=0;while frames.iter().any(|f|f[0].len()>1){for f in &mut frames{let extra=if f[0].len()>1{Some(f[0].iter().step_by(2).cloned().collect::<Vec<_>>())}else{None};for segment in f.iter_mut(){if segment.len()>1{*segment=segment.chunks_exact(2).map(|p|add(&p[0],&p[1])).collect();}}if let Some(extra)=extra{f.push(extra);}assert!(f.len()<=9);}late+=1;}
 let mut result=vec![0i64;n];for(g,f)in frames.iter().enumerate(){let mut w=f[0][0].clone();for correction in f[1..].iter().rev(){w=w.iter().zip(&correction[0]).map(|(a,b)|2*a-b).collect();}for i in 0..n{result[i]+=w[i]+(g*256)as i64*f[0][0][i];}}
 (result,early,late)
}
#[test]fn all_coefficients_and_late_inverse_counts(){for n in[0usize,1,2,4,8,16,32,64,128,256,384,512,640,768,896,1024,2048,4096]{let(w,early,late)=model(n);assert_eq!(w,(1..=n as i64).collect::<Vec<_>>());if n>=512&&n%256==0{assert_eq!(early,n/256*5);assert_eq!(late,3);assert_eq!(early+late,n/256*5+3);}}}
#[test]fn every_saved_tail_is_inside_its_own_slice(){for n in[1usize,2,4,8,16,32,64,128,256]{let l=n.ilog2()as usize;let mut live=n.min(8);let mut segments=1+l.saturating_sub(3);let mut used=live*segments;assert!(used<=55);while live>1{let half=live/2;for i in 0..half{assert!(2*i<used);assert!(used+i<55);assert!(2*i<used+i);}used+=half;segments+=1;live=half;assert!(segments<=9);}assert!(used<=55);}}
