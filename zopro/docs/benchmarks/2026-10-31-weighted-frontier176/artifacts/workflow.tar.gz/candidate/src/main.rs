use std::{alloc::{GlobalAlloc,Layout},sync::{Arc,Mutex,atomic::{AtomicUsize,Ordering::Relaxed}},time::Instant};
use serde_json::json;use sha2::{Digest,Sha256};use rayon::prelude::*;
use zopro_core::{FrontierG1,FrontierG2};use zopro_bn254::{G1Projective,G2Projective};
mod perf;
static LIVE:AtomicUsize=AtomicUsize::new(0);static PEAK:AtomicUsize=AtomicUsize::new(0);static CALLS:AtomicUsize=AtomicUsize::new(0);
struct Allocator;
fn added(n:usize){if cfg!(zopro_track_heap){let live=LIVE.fetch_add(n,Relaxed)+n;PEAK.fetch_max(live,Relaxed);CALLS.fetch_add(1,Relaxed);}}
fn removed(n:usize){if cfg!(zopro_track_heap){LIVE.fetch_sub(n,Relaxed);}}
unsafe impl GlobalAlloc for Allocator {
    unsafe fn alloc(&self,l:Layout)->*mut u8 {let p=unsafe{zopro_core::alloc::Allocator.alloc(l)};if !p.is_null(){added(l.size());}p}
    unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {let p=unsafe{zopro_core::alloc::Allocator.alloc_zeroed(l)};if !p.is_null(){added(l.size());}p}
    unsafe fn dealloc(&self,p:*mut u8,l:Layout){unsafe{zopro_core::alloc::Allocator.dealloc(p,l)};removed(l.size());}
    unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {let out=unsafe{zopro_core::alloc::Allocator.realloc(p,l,n)};if !out.is_null(){removed(l.size());added(n);}out}
}
#[global_allocator]static A:Allocator=Allocator;
enum Fixture{G1(FrontierG1),G2(FrontierG2)}
#[derive(Clone,Copy)]enum Point{G1(G1Projective),G2(G2Projective)}
impl Fixture {
    fn run(&self,k:usize,on:bool)->Point{match self{Self::G1(f)=>Point::G1(f.run(k,on)),Self::G2(f)=>Point::G2(f.run(k,on))}}
    fn check(&self,k:usize,p:Point){match(self,p){(Self::G1(f),Point::G1(p))=>f.check(k,p),(Self::G2(f),Point::G2(p))=>f.check(k,p),_=>panic!("curve mismatch")}}
}
fn affinity(cpu:usize){unsafe{let mut mask:libc::cpu_set_t=std::mem::zeroed();libc::CPU_ZERO(&mut mask);libc::CPU_SET(cpu,&mut mask);assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&mask),&mask),0);}}
fn main(){
    let a=std::env::args().collect::<Vec<_>>();assert_eq!(a.len(),6);
    let g2=match a[1].as_str(){"G1"=>false,"G2"=>true,_=>panic!("curve")};let n=a[2].parse::<usize>().unwrap();
    let workers=a[3].parse::<usize>().unwrap();let rounds=a[4].parse::<usize>().unwrap();let on=match a[5].as_str(){"ON"=>true,"OFF"=>false,_=>panic!("arm")};
    assert!([2048,4096].contains(&n)&&[1,16,32].contains(&workers)&&rounds>0&&rounds%2==0);assert!(!on||cfg!(zopro_joint_weighted));
    let windows=if g2{11}else if n==2048{21}else{20};
    let seen=Arc::new(Mutex::new(vec![]));let copy=seen.clone();
    let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).start_handler(move|i|{let cpu=if workers==1{2}else{i};affinity(cpu);copy.lock().unwrap().push(json!({"worker":i,"cpu":cpu,"tid":unsafe{libc::syscall(libc::SYS_gettid)}}));}).build().unwrap();
    pool.broadcast(|_|());let mut mapping=seen.lock().unwrap().clone();mapping.sort_by_key(|v|v["worker"].as_u64().unwrap());assert_eq!(mapping.len(),workers);
    let fixtures=(0..windows).map(|i|if g2{Fixture::G2(FrontierG2::new(n,19+i as u64))}else{Fixture::G1(FrontierG1::new(n,19+i as u64))}).collect::<Vec<_>>();
    for prime in 0..3 {for k in 0..2 {
        let out=pool.install(||fixtures.par_iter().map(|f|f.run(k,on)).collect::<Vec<_>>());
        for(f,&p)in fixtures.iter().zip(&out){f.check(k,p);}std::hint::black_box(prime);
    }}
    // Allocate result holders before resetting resource high water. Per-wave
    // output allocation/drop remains in both algorithms' measured work.
    let mut last:[Vec<Point>;2]=core::array::from_fn(|_|Vec::new());
    let mut ctl=perf::Control::from_env().unwrap();if let Some(c)=ctl.as_mut(){c.enable().unwrap();}
    let usage0=perf::Usage::now().unwrap();let live0=LIVE.load(Relaxed);PEAK.store(live0,Relaxed);let calls0=CALLS.load(Relaxed);
    let start=Instant::now();for i in 0..rounds {let k=i%2;last[k]=pool.install(||fixtures.par_iter().map(|f|std::hint::black_box(f.run(k,on))).collect());}
    let elapsed=start.elapsed().as_nanos()as u64;let peak=PEAK.load(Relaxed);let live1=LIVE.load(Relaxed);let calls=CALLS.load(Relaxed)-calls0;
    let usage1=perf::Usage::now().unwrap();if let Some(c)=ctl.as_mut(){c.disable().unwrap();}
    let mut h=Sha256::new();for(k,out)in last.iter().enumerate(){assert_eq!(out.len(),windows);for(f,&p)in fixtures.iter().zip(out){f.check(k,p);h.update(match p{Point::G1(p)=>format!("{:?}",p.to_affine()),Point::G2(p)=>format!("{:?}",p.to_affine())});}}
    pool.broadcast(|c|assert_eq!(unsafe{libc::sched_getcpu()},if workers==1{2}else{c.index()}as i32));
    println!("CALLER {}",json!({"curve":a[1],"size":n,"workers":workers,"windows":windows,"rounds":rounds,"arm":a[5],"compiled_joint":cfg!(zopro_joint_weighted),"instrumented_heap":cfg!(zopro_track_heap),"pid":std::process::id(),"worker_rows":mapping,"elapsed_ns":elapsed,"ns_per_wave":elapsed as f64/rounds as f64,"priming_passes":3,"priming_waves_per_pass":2,"complete_generator_oracle":true,"output_sha256":format!("{:x}",h.finalize()),"heap_requested":{"before_bytes":live0,"after_bytes":live1,"peak_bytes":peak,"incremental_peak_bytes":peak.saturating_sub(live0),"allocation_calls":calls},"usage":usage1.difference(&usage0),"new_proofs":0}));
}
