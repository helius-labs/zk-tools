//! Complete weighted windows with joint small-group finishing.
use super::*;
use zopro_bn254::{G1Config,G2Config};
const GROUP:usize=256;
const STRIDE:usize=55;
const LEVELS:usize=9;

// Keep the baseline call boundary explicit and identical in both builds.
#[inline(never)]
fn baseline<C:CurveConfig>(input:&[Affine<C>])->Projective<C>
where C::Base:BatchInverse {weighted_affine(input)}

#[derive(Clone)]
struct Frame {
    starts:[usize;LEVELS], counts:[usize;LEVELS], levels:usize,
    used:usize, pending:usize,
}
impl Default for Frame {
    fn default()->Self {Self{starts:[0;LEVELS],counts:[0;LEVELS],levels:0,used:0,pending:0}}
}

#[cfg(zopro_joint_weighted)]
fn prepare<C:CurveConfig>(
    input:&[Affine<C>], output:&mut[LimbPoint<C::Base>],frame:&mut Frame,
    base:usize,tree:&mut Vec<LimbPoint<C::Base>>,scratch:&mut Scratch<C>,
)where C::Base:BatchInverse {
    let n=input.len();assert!(n.is_power_of_two()&&n<=GROUP);
    tree.resize(2*n-1,LimbPoint::infinity());
    for(out,&p)in tree.iter_mut().zip(input){*out=limbs::<C>(p);}
    let mut starts=[0usize;LEVELS];let mut counts=[0usize;LEVELS];
    counts[0]=n;let mut levels=1;let mut next=n;
    while counts[0]>8 {
        let half=counts[0]/2;
        for i in 0..half {tree[next+i]=tree[2*i];}
        reduce_layer(tree,&starts[..levels],&mut counts[..levels],scratch);
        starts[levels]=next;counts[levels]=half;levels+=1;next+=half;
    }
    let live=counts[0];assert!(levels*live<=STRIDE);
    *frame=Frame::default();frame.levels=levels;frame.used=levels*live;
    for j in 0..levels {
        assert_eq!(counts[j],live);
        output[j*live..(j+1)*live].copy_from_slice(&tree[starts[j]..starts[j]+live]);
        frame.starts[j]=base+j*live;frame.counts[j]=live;
    }
}

#[cfg(zopro_joint_weighted)]
fn joint<C:CurveConfig>(input:&[Affine<C>])->Projective<C>
where C::Base:BatchInverse {
    if input.is_empty(){return Projective::IDENTITY;}
    let groups=input.len().div_ceil(GROUP);
    let mut points=vec![LimbPoint::<C::Base>::infinity();groups*STRIDE];
    let mut frames=vec![Frame::default();groups];
    points.par_chunks_mut(STRIDE).zip(frames.par_iter_mut()).zip(input.par_chunks(GROUP))
        .enumerate().for_each_init(
            ||(Vec::<LimbPoint<C::Base>>::new(),Scratch::<C>::default()),
            |(tree,scratch),(group,((out,frame),chunk))|prepare::<C>(chunk,out,frame,group*STRIDE,tree,scratch),
        );
    let mut scratch=Scratch::<C>::default();
    let mut starts=Vec::with_capacity(groups*LEVELS);
    let mut counts=Vec::with_capacity(groups*LEVELS);
    while frames.iter().any(|f|f.counts[0]>1) {
        starts.clear();counts.clear();
        for(group,f)in frames.iter_mut().enumerate(){
            f.pending=if f.counts[0]>1{f.counts[0]/2}else{0};
            assert!(f.used+f.pending<=STRIDE);
            for i in 0..f.pending {points[group*STRIDE+f.used+i]=points[f.starts[0]+2*i];}
            starts.extend_from_slice(&f.starts[..f.levels]);
            counts.extend_from_slice(&f.counts[..f.levels]);
        }
        reduce_layer(&mut points,&starts,&mut counts,&mut scratch);
        let mut cursor=0;
        for(group,f)in frames.iter_mut().enumerate(){
            f.counts[..f.levels].copy_from_slice(&counts[cursor..cursor+f.levels]);cursor+=f.levels;
            if f.pending>0 {
                assert!(f.levels<LEVELS);f.starts[f.levels]=group*STRIDE+f.used;
                f.counts[f.levels]=f.pending;f.used+=f.pending;f.levels+=1;
            }
        }
        assert_eq!(cursor,counts.len());
    }
    let mut sum=Projective::<C>::IDENTITY;let mut offset=Projective::<C>::IDENTITY;
    let mut running=Projective::<C>::IDENTITY;
    for f in frames.iter().rev(){
        assert!(f.counts[..f.levels].iter().all(|&n|n==1));
        let total=affine::<C>(points[f.starts[0]]);let mut weighted=total.to_projective();
        for start in f.starts[1..f.levels].iter().rev(){weighted=weighted.double();weighted-=affine::<C>(points[*start]);}
        sum+=weighted;offset+=running;running+=total;
    }
    for _ in 0..GROUP.ilog2(){offset=offset.double();}
    sum+offset
}

fn run<C:CurveConfig>(input:&[Affine<C>],on:bool)->Projective<C>
where C::Base:BatchInverse {
    #[cfg(zopro_joint_weighted)]if on{return joint(input);}
    let _=on;baseline(input)
}

struct Random(u64);
impl Random {
    fn fr(&mut self)->Fr {let mut bytes=[0u8;64];for chunk in bytes.chunks_mut(8){
        self.0=self.0.wrapping_add(0x9e3779b97f4a7c15);let mut v=self.0;
        v=(v^(v>>30)).wrapping_mul(0xbf58476d1ce4e5b9);v=(v^(v>>27)).wrapping_mul(0x94d049bb133111eb);v^=v>>31;
        chunk.copy_from_slice(&v.to_le_bytes());}Fr::from_random_bytes(&bytes)}
}
struct Fixture<C:CurveConfig>where C::Base:BatchInverse {
    points:Vec<Affine<C>>,words:Vec<Fr>,n:usize,
}
impl<C:CurveConfig>Fixture<C>where C::Base:BatchInverse {
    fn new(n:usize,seed:u64)->Self {
        let mut random=Random(seed);let start=random.fr();let step=random.fr();
        assert_ne!(step,Fr::ZERO);let g=Projective::<C>::generator();
        let mut p=g*start;let delta=g*step;let mut scalar=start;
        let mut raw=Vec::with_capacity(n+1);let mut words=Vec::with_capacity(n+1);
        for _ in 0..n+1{raw.push(p);words.push(scalar);p+=delta;scalar+=step;}
        Self{points:Projective::<C>::batch_to_affine(&raw),words,n}
    }
    fn run(&self,which:usize,on:bool)->Projective<C>{run(&self.points[which..which+self.n],on)}
    fn check(&self,which:usize,value:Projective<C>) {
        let scalar=self.words[which..which+self.n].iter().enumerate().fold(Fr::ZERO,|s,(i,w)|s+*w*Fr::from(i as u64+1));
        assert_eq!(value.to_affine(),(Projective::<C>::generator()*scalar).to_affine());
    }
}
pub struct FrontierG1(Fixture<G1Config>);pub struct FrontierG2(Fixture<G2Config>);
macro_rules! caller {($name:ident,$point:ty)=>{impl $name{
    pub fn new(n:usize,seed:u64)->Self{Self(Fixture::new(n,seed))}
    pub fn run(&self,which:usize,on:bool)->$point{self.0.run(which,on)}
    pub fn check(&self,which:usize,value:$point){self.0.check(which,value)}
}};}
caller!(FrontierG1,zopro_bn254::G1Projective);caller!(FrontierG2,zopro_bn254::G2Projective);

#[cfg(test)]mod tests {
    use super::*;
    fn check<C:CurveConfig>()where C::Base:BatchInverse {
        let g=Projective::<C>::generator();let mut random=Random(0x66726f6e74696572);
        for n in[0usize,1,2,4,8,16,32,64,128,256,384,512,640,768,896,1024,2048,4096]{
            let scalars=(0..n).map(|_|random.fr()).collect::<Vec<_>>();
            let ordinary=Projective::<C>::batch_to_affine(&scalars.iter().map(|s|g**s).collect::<Vec<_>>());
            for family in 0..5 {
                let mut input=ordinary.clone();let mut weights=scalars.clone();
                if n>=4 {match family {
                    1=>{input[n/2]=Affine::IDENTITY;weights[n/2]=Fr::ZERO;},
                    2=>{input[1]=input[0];weights[1]=weights[0];},
                    3=>{input[1]=-input[0];weights[1]=-weights[0];},
                    4=>{for(i,s)in[3i64,5,11,-19].into_iter().enumerate(){weights[i]=if s<0{-Fr::from((-s)as u64)}else{Fr::from(s as u64)};input[i]=(g*weights[i]).to_affine();}},_=>{}
                }}
                let expected=weights.iter().enumerate().fold(Fr::ZERO,|s,(i,w)|s+*w*Fr::from(i as u64+1));
                let before=input.clone();for on in[false,true]{assert_eq!(run(&input,on).to_affine(),(g*expected).to_affine(),"n{n} family{family} on{on}");assert_eq!(input,before);}
            }
        }
    }
    #[test]fn g1_all_groups_tails_exceptions(){check::<G1Config>();}
    #[test]fn g2_all_groups_tails_exceptions(){check::<G2Config>();}
    #[test]fn nested_pools_small_stacks_and_repeated_waves(){
        use rayon::prelude::*;
        for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();
            let a=(0..4).map(|i|FrontierG1::new(512,19+i)).collect::<Vec<_>>();let b=(0..4).map(|i|FrontierG2::new(512,19+i)).collect::<Vec<_>>();
            pool.install(||for on in[false,true,false,true]{a.par_iter().for_each(|f|for k in 0..2{let p=f.run(k,on);f.check(k,p);});b.par_iter().for_each(|f|for k in 0..2{let p=f.run(k,on);f.check(k,p);});});
        }
    }
}
