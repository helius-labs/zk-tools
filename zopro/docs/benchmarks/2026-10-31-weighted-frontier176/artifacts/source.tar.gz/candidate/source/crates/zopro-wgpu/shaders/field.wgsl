// SPDX-License-Identifier: Apache-2.0
// Portable WGSL adaptation of Aeglos' eight-limb BN254 Montgomery arithmetic.
// Aeglos a4716504d10586d1c87c9a89603bbe5247d5cfd8, cuda/{fp,mont_common}.cuh.
// Copyright (c) 2026 Helius Blockchain Technologies, Inc.
// All Fp values are reduced modulo Fq and use R = 2^256. Storage size: 32 bytes.
struct Fp { limbs: array<u32, 8>, }

const FP_Q: array<u32, 8> = array<u32, 8>(
    0xd87cfd47u, 0x3c208c16u, 0x6871ca8du, 0x97816a91u,
    0x8181585du, 0xb85045b6u, 0xe131a029u, 0x30644e72u,
);
const FP_INV: u32 = 0xe4866389u;

fn fp_zero() -> Fp { return Fp(array<u32, 8>()); }
fn fp_one() -> Fp {
    return Fp(array<u32, 8>(
        0xc58f0d9du, 0xd35d438du, 0xf5c70b3du, 0x0a78eb28u,
        0x7879462cu, 0x666ea36fu, 0x9a07df2fu, 0x0e0a77c1u,
    ));
}
fn fp_equal(a: Fp, b: Fp) -> bool {
    for (var j = 0u; j < 8u; j++) {
        if (a.limbs[j] != b.limbs[j]) { return false; }
    }
    return true;
}
fn fp_is_zero(a: Fp) -> bool {
    var bits = 0u;
    for (var j = 0u; j < 8u; j++) { bits |= a.limbs[j]; }
    return bits == 0u;
}
fn fp_geq_modulus(a: Fp) -> bool {
    for (var j = 8u; j > 0u;) {
        j--;
        if (a.limbs[j] != FP_Q[j]) { return a.limbs[j] > FP_Q[j]; }
    }
    return true;
}
fn fp_adc(a: u32, b: u32, carry: u32) -> vec2<u32> {
    let first = a + b;
    let result = first + carry;
    return vec2<u32>(result, select(0u, 1u, first < a) + select(0u, 1u, result < first));
}
fn fp_sbb(a: u32, b: u32, borrow: u32) -> vec2<u32> {
    let first = a - b;
    let result = first - borrow;
    return vec2<u32>(result, select(0u, 1u, a < b) + select(0u, 1u, first < borrow));
}
fn fp_reduce(a: Fp) -> Fp {
    if (!fp_geq_modulus(a)) { return a; }
    var result = fp_zero();
    var borrow = 0u;
    for (var j = 0u; j < 8u; j++) {
        let word = fp_sbb(a.limbs[j], FP_Q[j], borrow);
        result.limbs[j] = word.x;
        borrow = word.y;
    }
    return result;
}
fn fp_add(a: Fp, b: Fp) -> Fp {
    var result = fp_zero();
    var carry = 0u;
    for (var j = 0u; j < 8u; j++) {
        let word = fp_adc(a.limbs[j], b.limbs[j], carry);
        result.limbs[j] = word.x;
        carry = word.y;
    }
    // a+b < 2q < 2^255, so there is no discarded carry.
    return fp_reduce(result);
}
fn fp_sub(a: Fp, b: Fp) -> Fp {
    var result = fp_zero();
    var borrow = 0u;
    for (var j = 0u; j < 8u; j++) {
        let word = fp_sbb(a.limbs[j], b.limbs[j], borrow);
        result.limbs[j] = word.x;
        borrow = word.y;
    }
    if (borrow != 0u) {
        var carry = 0u;
        for (var j = 0u; j < 8u; j++) {
            let word = fp_adc(result.limbs[j], FP_Q[j], carry);
            result.limbs[j] = word.x;
            carry = word.y;
        }
    }
    return result;
}
fn fp_neg(a: Fp) -> Fp { return fp_sub(fp_zero(), a); }

// Diagnostic helper for the independent wide-product oracle.
// Selected u16 arithmetic does not call it.
// Exact 32x32->64 multiply using four native16-bit products. Each product fits
// u32; middle < 3*2^16; the exact high word fits u32, even for MAX*MAX.
fn fp_wide_mul(a: u32, b: u32) -> vec2<u32> {
    let a0 = a & 0xffffu;
    let a1 = a >> 16u;
    let b0 = b & 0xffffu;
    let b1 = b >> 16u;
    let p0 = a0 * b0;
    let p1 = a0 * b1;
    let p2 = a1 * b0;
    let p3 = a1 * b1;
    let middle = (p0 >> 16u) + (p1 & 0xffffu) + (p2 & 0xffffu);
    return vec2<u32>(
        (p0 & 0xffffu) | (middle << 16u),
        p3 + (p1 >> 16u) + (p2 >> 16u) + (middle >> 16u),
    );
}
// a*b + accumulator + carry <= (B-1)^2+2*(B-1)=B^2-1, B=2^32.
fn fp_mac(accumulator: u32, a: u32, b: u32, carry: u32) -> vec2<u32> {
    let product = fp_wide_mul(a, b);
    let first = product.x + accumulator;
    let result = first + carry;
    let high = product.y + select(0u, 1u, first < product.x) + select(0u, 1u, result < first);
    return vec2<u32>(result, high);
}
// BEGIN COMPACT U16 MONTGOMERY
// Montgomery multiplication in 16-bit halves (B=2^16: (B-1)^2+2*(B-1)=2^32-1,
// so each MAC is exact in u32), one round per half of b in a loop: the
// fully unrolled form was 2 700 lines per multiply, which a phone's
// shader compiler took tens of seconds over or refused to link.
fn fp_mac16(t: u32, a: u32, b: u32, carry: u32) -> vec2<u32> {
    let word = t + a * b + carry;
    return vec2<u32>(word & 0xffffu, word >> 16u);
}
const FP_Q16: array<u32, 16> = array<u32, 16>(0xfd47u, 0xd87cu, 0x8c16u, 0x3c20u, 0xca8du, 0x6871u, 0x6a91u, 0x9781u, 0x585du, 0x8181u, 0x45b6u, 0xb850u, 0xa029u, 0xe131u, 0x4e72u, 0x3064u);
fn fp_mul(a: Fp, b: Fp) -> Fp {
    let a0 = a.limbs[0] & 0xffffu;
    let a1 = a.limbs[0] >> 16u;
    let a2 = a.limbs[1] & 0xffffu;
    let a3 = a.limbs[1] >> 16u;
    let a4 = a.limbs[2] & 0xffffu;
    let a5 = a.limbs[2] >> 16u;
    let a6 = a.limbs[3] & 0xffffu;
    let a7 = a.limbs[3] >> 16u;
    let a8 = a.limbs[4] & 0xffffu;
    let a9 = a.limbs[4] >> 16u;
    let a10 = a.limbs[5] & 0xffffu;
    let a11 = a.limbs[5] >> 16u;
    let a12 = a.limbs[6] & 0xffffu;
    let a13 = a.limbs[6] >> 16u;
    let a14 = a.limbs[7] & 0xffffu;
    let a15 = a.limbs[7] >> 16u;
    var t0 = 0u;
    var t1 = 0u;
    var t2 = 0u;
    var t3 = 0u;
    var t4 = 0u;
    var t5 = 0u;
    var t6 = 0u;
    var t7 = 0u;
    var t8 = 0u;
    var t9 = 0u;
    var t10 = 0u;
    var t11 = 0u;
    var t12 = 0u;
    var t13 = 0u;
    var t14 = 0u;
    var t15 = 0u;
    var carry = 0u;
    for (var j = 0u; j < 16u; j++) {
        let word_j = b.limbs[j >> 1u];
        let bj = select(word_j & 0xffffu, word_j >> 16u, (j & 1u) == 1u);
        carry = 0u;
        { let word = fp_mac16(t0, a0, bj, carry); t0 = word.x; carry = word.y; }
        { let word = fp_mac16(t1, a1, bj, carry); t1 = word.x; carry = word.y; }
        { let word = fp_mac16(t2, a2, bj, carry); t2 = word.x; carry = word.y; }
        { let word = fp_mac16(t3, a3, bj, carry); t3 = word.x; carry = word.y; }
        { let word = fp_mac16(t4, a4, bj, carry); t4 = word.x; carry = word.y; }
        { let word = fp_mac16(t5, a5, bj, carry); t5 = word.x; carry = word.y; }
        { let word = fp_mac16(t6, a6, bj, carry); t6 = word.x; carry = word.y; }
        { let word = fp_mac16(t7, a7, bj, carry); t7 = word.x; carry = word.y; }
        { let word = fp_mac16(t8, a8, bj, carry); t8 = word.x; carry = word.y; }
        { let word = fp_mac16(t9, a9, bj, carry); t9 = word.x; carry = word.y; }
        { let word = fp_mac16(t10, a10, bj, carry); t10 = word.x; carry = word.y; }
        { let word = fp_mac16(t11, a11, bj, carry); t11 = word.x; carry = word.y; }
        { let word = fp_mac16(t12, a12, bj, carry); t12 = word.x; carry = word.y; }
        { let word = fp_mac16(t13, a13, bj, carry); t13 = word.x; carry = word.y; }
        { let word = fp_mac16(t14, a14, bj, carry); t14 = word.x; carry = word.y; }
        { let word = fp_mac16(t15, a15, bj, carry); t15 = word.x; carry = word.y; }
        let upper = carry;
        let m = (t0 * 0x6389u) & 0xffffu;
        { let word = fp_mac16(t0, m, 0xfd47u, 0u); carry = word.y; }
        { let word = fp_mac16(t1, m, 0xd87cu, carry); t0 = word.x; carry = word.y; }
        { let word = fp_mac16(t2, m, 0x8c16u, carry); t1 = word.x; carry = word.y; }
        { let word = fp_mac16(t3, m, 0x3c20u, carry); t2 = word.x; carry = word.y; }
        { let word = fp_mac16(t4, m, 0xca8du, carry); t3 = word.x; carry = word.y; }
        { let word = fp_mac16(t5, m, 0x6871u, carry); t4 = word.x; carry = word.y; }
        { let word = fp_mac16(t6, m, 0x6a91u, carry); t5 = word.x; carry = word.y; }
        { let word = fp_mac16(t7, m, 0x9781u, carry); t6 = word.x; carry = word.y; }
        { let word = fp_mac16(t8, m, 0x585du, carry); t7 = word.x; carry = word.y; }
        { let word = fp_mac16(t9, m, 0x8181u, carry); t8 = word.x; carry = word.y; }
        { let word = fp_mac16(t10, m, 0x45b6u, carry); t9 = word.x; carry = word.y; }
        { let word = fp_mac16(t11, m, 0xb850u, carry); t10 = word.x; carry = word.y; }
        { let word = fp_mac16(t12, m, 0xa029u, carry); t11 = word.x; carry = word.y; }
        { let word = fp_mac16(t13, m, 0xe131u, carry); t12 = word.x; carry = word.y; }
        { let word = fp_mac16(t14, m, 0x4e72u, carry); t13 = word.x; carry = word.y; }
        { let word = fp_mac16(t15, m, 0x3064u, carry); t14 = word.x; carry = word.y; }
        // Round result < a+q < 2q < R256: upper+carry fits in 16 bits.
        t15 = upper + carry;
    }
    return fp_reduce(Fp(array<u32, 8>(t0 | (t1 << 16u), t2 | (t3 << 16u), t4 | (t5 << 16u), t6 | (t7 << 16u), t8 | (t9 << 16u), t10 | (t11 << 16u), t12 | (t13 << 16u), t14 | (t15 << 16u))));
}
// END COMPACT U16 MONTGOMERY
fn fp_square(a: Fp) -> Fp { return fp_mul(a, a); }
