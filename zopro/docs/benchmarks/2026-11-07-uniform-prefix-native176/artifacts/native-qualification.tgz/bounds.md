# General scale cancellation

Interpret every internal raw vector as its ordinary R256 field value. Let q=16 and a★b=ab/q. A normalized raw input is at most2p; ordinary product T<=4p² and fused positive/complemented product T<=8p². Uniform R=qH reduction gives U=(T+kp)/R<p+8p²/R<2p since8p<R. Thus old uniform output ranges compose, and a returned raw vector represents ★ under R256 without conversion. Existing field reductions/digits must retain these contracts; new native wrappers are not yet executed.

For G1 lane-prefix d1..di, set p0=1,pi=pi-1★di=Di/q^i. Store ti=ni★pi-1=ni Di-1/q^i. Ordinary root inversion gives1/pi. Correct it ONCE to vi=q/pi=q^(i+1)/Di. Then ti★vi=ni/di and vi★di=q/pi-1. The result is independent of prefix length and q powers need no table.

For G2, let Ni=norm(dx_i),Ui=dy_i*conj(dx_i). Uniform fused operators produce di=Ni/q and ui=Ui/q. Now pi=N1...Ni/q^(2i),vi=q/pi. The reverse factor fi=pi-1★vi=q²/Ni. Therefore ui★fi=Ui/Ni, the original complex slope, and vi★di=q/pi-1. Final coordinate square/product/subtract remain original ordinary R256 operations, so point encodings never change.

Scalar tails use the ORIGINAL ordinary prefix/numerator/inverse recurrence. Their unknown common prefix scale cancels by itself. Apply q to the remaining inverse only AFTER reversing tails. Correcting before those tails scales their slopes byq; omitting the correction scales full-vector slopes by1/q. Both wrong placements are explicitly checked against complete curve addition.

When no tail exists, all eight lane inverses may receive q through their single scalar product root. For normalized root z choose k=(-z*p^-1) mod16,0<=k<16. z+k*p is divisible by16. If0<=z<=2p, then0<=u=(z+k*p)/16<=17p/16<2p. One subtraction ofp produces canonical u, which represents z/16 in the SAME R256 domain. Its ordinary inverse equals16/z; the original eight-root reverse product tree distributes that scale to every lane. Residue-zero inputs remain zero and are not inverted. This does not replace the existing GCD inverse or require per-root tables. Actual SIMD root export/import and native costs remain unqualified.

These identities hold for every nonzero denominator over both odd BN254 prime fields. The point norm argument concerns the existing Fq2 field, not an arbitrary quadratic ring overFr. Finite BigUint/Arkworks checks support the exact operations and sign/tail/guard implementation; they are not formal proofs of SIMD code, memory or performance. IFMA counts are unchanged; any speed benefit must be established in actual emitted consumers and complete proofs.
