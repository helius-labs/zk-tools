use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix176";
const A:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn text(p: impl AsRef<Path>) -> String {
    fs::read_to_string(p).unwrap()
}
fn span(s: &str, name: &str) -> (usize, usize) {
    let start = s.find(name).unwrap();
    let body = s[start..].find('{').unwrap() + start;
    let mut depth = 0;
    for (i, c) in s.char_indices().skip_while(|(i, _)| *i < body) {
        if c == '{' {
            depth += 1;
        }
        if c == '}' {
            depth -= 1;
            if depth == 0 {
                return (start, i + 1);
            }
        }
    }
    panic!("unclosed {name}")
}
fn fn_text(s: &str, name: &str) -> String {
    let (a, b) = span(s, name);
    s[a..b].into()
}
fn replace(s: &mut String, a: &str, b: &str, n: usize) {
    assert_eq!(s.matches(a).count(), n, "{a}");
    *s = s.replace(a, b);
}
fn receipts(plan: &Path, out: &Path) -> usize {
    let plan = load(plan);
    assert_eq!(load(out.join("result.json"))["status"], "complete");
    for step in plan["steps"].as_array().unwrap() {
        let dir = out.join(step["name"].as_str().unwrap());
        let e = load(dir.join("exit.json"));
        assert_eq!(e["success"], true);
        assert_eq!(e["returncode"], 0);
        let c = load(dir.join("command.json"));
        let args = c["argv"].as_array().unwrap();
        let expected = step["argv"].as_array().unwrap();
        assert_eq!(&args[args.len() - expected.len()..], expected);
        for stream in ["stdout", "stderr"] {
            assert_eq!(
                hash(dir.join(format!("{stream}.log"))),
                e[format!("{stream}_sha256")].as_str().unwrap()
            );
        }
    }
    plan["steps"].as_array().unwrap().len()
}
fn main() {
    let root = Path::new(R);
    let n = root.join("native");
    let accepted = load(A);
    let files = accepted["source_files_sha256"].as_object().unwrap();
    assert_eq!(files.len(), 176);
    for (p, h) in files {
        assert_eq!(
            hash(Path::new("/home/ubuntu/src/zk-tools/zopro").join(p)),
            h.as_str().unwrap()
        );
    }
    let field_pins: BTreeMap<String, String> =
        serde_json::from_value(load(n.join("field-fixed-pins.json"))).unwrap();
    let core_pins: BTreeMap<String, String> =
        serde_json::from_value(load(n.join("core-pins.json"))).unwrap();
    assert_eq!(field_pins.len(), 178);
    assert_eq!(core_pins.len(), 179);
    for (p, h) in field_pins.iter().chain(core_pins.iter()) {
        assert_eq!(&hash(p), h);
    }
    let field = n.join("source-field-fixed");
    let core = n.join("core-source-fixed");
    let mut field_unchanged = 0;
    let mut core_field_equal = 0;
    for (name, h) in files {
        let f = field.join(name);
        if hash(&f) == h.as_str().unwrap() {
            field_unchanged += 1
        } else {
            assert!([
                "crates/zopro-bn254/src/lib.rs",
                "crates/zopro-bn254/src/ifma.rs",
                "crates/zopro-bn254/src/ifma8.rs"
            ]
            .contains(&name.as_str()));
        }
    }
    assert_eq!(field_unchanged, 173);
    for path in field_pins.keys() {
        let relative = Path::new(path).strip_prefix(&field).unwrap();
        if hash(core.join(relative)) == field_pins[path] {
            core_field_equal += 1
        } else {
            assert!([
                "crates/zopro-core/src/msm.rs",
                "crates/zopro-core/src/simd.rs",
                "crates/zopro-core/src/msm/g2_prefix.rs",
                "crates/zopro-core/src/msm/g2_borrowed.rs"
            ]
            .contains(&relative.to_str().unwrap()));
        }
    }
    assert_eq!(core_field_equal, 174);
    let oldtests = text(n.join("source/crates/zopro-bn254/src/uniform_prefix_tests.rs"));
    let mut corrected = oldtests.clone();
    replace(
        &mut corrected,
        "$module:ident,$kind:ident",
        "$module:ident,$field:ident,$kind:ident",
        1,
    );
    replace(
        &mut corrected,
        "crate::$module::$kind",
        "crate::$module::$field",
        4,
    );
    replace(
        &mut corrected,
        "checks!(check4, 4, ifma, __m256i);",
        "checks!(check4, 4, ifma, Ifma, __m256i);",
        1,
    );
    replace(
        &mut corrected,
        "checks!(check8, 8, ifma8, __m512i);",
        "checks!(check8, 8, ifma8, Ifma8, __m512i);",
        1,
    );
    assert_eq!(
        corrected,
        text(field.join("crates/zopro-bn254/src/uniform_prefix_tests.rs"))
    );
    for (p, h) in load(n.join("field-pins.json")).as_object().unwrap() {
        let relative = Path::new(p).strip_prefix(n.join("source")).unwrap();
        if relative != Path::new("crates/zopro-bn254/src/uniform_prefix_tests.rs") {
            assert_eq!(hash(field.join(relative)), h.as_str().unwrap());
        }
    }
    assert!(text(n.join("field-runs/uniform-prefix-field/stderr.log")).contains("error[E0423]"));
    assert!(!n.join("field-runs/result.json").exists());
    assert!(!text(n.join("field-runs/uniform-prefix-field/stdout.log")).contains("running 3 tests"));
    let accepted_ifma = text("/home/ubuntu/src/zk-tools/zopro/crates/zopro-bn254/src/ifma.rs");
    let ifma = text(field.join("crates/zopro-bn254/src/ifma.rs"));
    let (ah, at) = accepted_ifma.split_once("#[cfg(test)]").unwrap();
    let (fh, ft) = ifma.split_once("#[cfg(test)]").unwrap();
    assert!(fh.starts_with(ah));
    assert_eq!(at, ft);
    let additions = &fh[ah.len()..];
    let reused = text(n.join("reused-fused-impl.txt"));
    assert_eq!(additions.matches(&reused).count(), 1);
    let mut original_signed = fn_text(&accepted_ifma, "    pub fn signed_difference_scaled(");
    replace(
        &mut original_signed,
        "signed_difference_scaled(",
        "signed_difference_scaled_div16(",
        1,
    );
    replace(&mut original_signed, "assert!(MIXED);", "", 1);
    replace(&mut original_signed, ".mul(scale)", ".mul_div16(scale)", 1);
    assert_eq!(
        original_signed,
        fn_text(&ifma, "    pub fn signed_difference_scaled_div16(")
    );
    let old_simd = text("/home/ubuntu/src/zk-tools/zopro/crates/zopro-core/src/simd.rs");
    let simd = text(core.join("crates/zopro-core/src/simd.rs"));
    let old_inverse = fn_text(&old_simd, "    pub(crate) fn inverse_nonzero(");
    assert_eq!(
        old_inverse,
        fn_text(&simd, "    pub(crate) fn inverse_nonzero(")
    );
    let expected_inverse=old_inverse.replace("fn inverse_nonzero(","fn inverse_nonzero_scaled16(").replace("let inverse = (products[0] * products[4]).inverse().unwrap();","let inverse = zopro_bn254::uniform_prefix::div16_root(products[0] * products[4]).inverse().unwrap();");
    assert_eq!(
        expected_inverse,
        fn_text(&simd, "    pub(crate) fn inverse_nonzero_scaled16(")
    );
    let cfg="all(zopro_uniform_prefix,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma))";
    let remove_start = simd
        .find(&format!(
            "    #[cfg({cfg})]\n    #[inline(always)]\n    pub(crate) fn mul_div16"
        ))
        .unwrap()
        - 1;
    assert_eq!(simd.as_bytes()[remove_start], b'\n');
    let (_, end) = span(&simd, "    pub(crate) fn inverse_nonzero_scaled16(");
    let restored = format!("{}{}", &simd[..remove_start], &simd[end + 1..]);
    assert_eq!(restored, old_simd);
    let old_msm = text("/home/ubuntu/src/zk-tools/zopro/crates/zopro-core/src/msm.rs");
    let msm = text(core.join("crates/zopro-core/src/msm.rs"));
    let mut g1 = fn_text(&msm, "fn stream_g1_impl<");
    replace(
        &mut g1,
        "prefix_mul(&chains,&denominator)",
        "chains.mul(&denominator)",
        2,
    );
    replace(
        &mut g1,
        "prefix_inverse(&chains,full==batch.len(),s.vector_inverse)",
        "direct_chain_inverse(&chains,full==batch.len(),s.vector_inverse)",
        1,
    );
    replace(
        &mut g1,
        "prefix_tail_inverse(FqBatch::new(&inverse),full)",
        "FqBatch::new(&inverse)",
        1,
    );
    replace(
        &mut g1,
        "prefix_mul(&g.numerator,&inverse)",
        "g.numerator.mul(&inverse)",
        1,
    );
    replace(
        &mut g1,
        "prefix_mul(&inverse,&g.denominator)",
        "inverse.mul(&g.denominator)",
        1,
    );
    assert_eq!(g1, fn_text(&old_msm, "fn stream_g1_impl<"));
    let mut recovery = msm.clone();
    for name in ["fn stream_g1_impl<", "fn scaled_signed_dy<"] {
        let (a, b) = span(&recovery, name);
        recovery.replace_range(a..b, &fn_text(&old_msm, name));
    }
    let suffix="\nmod uniform_prefix;\nuse uniform_prefix::{prefix_mul,prefix_norm,prefix_numerator,prefix_inverse,prefix_tail_inverse};\n";
    assert!(recovery.ends_with(suffix));
    recovery.truncate(recovery.len() - suffix.len());
    assert_eq!(recovery, old_msm);
    for file in ["g2_prefix.rs", "g2_borrowed.rs"] {
        let old =
            text(Path::new("/home/ubuntu/src/zk-tools/zopro/crates/zopro-core/src/msm").join(file));
        let mut new = text(core.join("crates/zopro-core/src/msm").join(file));
        replace(
            &mut new,
            "prefix_norm(&denominator)",
            "Fq2::lanes_norm(&denominator)",
            1,
        );
        replace(
            &mut new,
            "prefix_mul(&chains,&norm)",
            "chains.mul(&norm)",
            1,
        );
        replace(&mut new, "prefix_inverse(", "direct_chain_inverse(", 1);
        replace(
            &mut new,
            "prefix_tail_inverse(FqBatch::new(&inverse),full)",
            "FqBatch::new(&inverse)",
            1,
        );
        replace(
            &mut new,
            "prefix_mul(&s.prefix_records[j][0],&inverse)",
            "s.prefix_records[j][0].mul(&inverse)",
            1,
        );
        replace(
            &mut new,
            "prefix_mul(&inverse,&s.prefix_records[j][1])",
            "inverse.mul(&s.prefix_records[j][1])",
            1,
        );
        replace(
            &mut new,
            "prefix_numerator(",
            "Fq2::lanes_scaled_numerator(",
            1,
        );
        assert_eq!(new, old);
    }
    let helper = text(core.join("crates/zopro-core/src/msm/uniform_prefix.rs"));
    let production = helper.split("#[cfg(all(\n    test,").next().unwrap();
    assert!(!production.contains("Vec"));
    assert!(!production.contains("unsafe"));
    assert!(!production.contains("Box"));
    assert!(helper.contains("all("));
    assert!(!helper.contains("cfg(UP)"));
    let mut commands = 0;
    for (plan, out) in [
        ("generator-plan.json", "generator-runs"),
        ("field-fixed-plan.json", "field-fixed-runs"),
        ("core-plan.json", "core-runs"),
    ] {
        commands += receipts(&n.join(plan), &n.join(out));
    }
    let f = text(n.join("field-fixed-runs/uniform-prefix-field/stdout.log"));
    assert!(f.contains("3 passed; 0 failed; 0 ignored; 0 measured; 35 filtered out"));
    for name in ["core-off", "core-on"] {
        let t = text(n.join(format!("core-runs/{name}/stdout.log")));
        assert!(t.contains("127 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
        for new in [
            "uniform_prefix_g1_signed_tail_inverse_paths",
            "uniform_prefix_borrowed_g2_tail_inverse_paths",
        ] {
            assert!(t.lines().any(|l| l.contains(new) && l.ends_with(" ... ok")));
        }
    }
    let review = json!({"review_passed":true,"accepted_production_files_checked":176,"field_snapshot_files":178,"field_accepted_exact":173,"core_snapshot_files":179,"core_field_snapshot_exact":174,"source_pin_occurrences":357,"successful_command_receipts":commands,"field_tests":3,"new_native_SIMD_outputs":5211*4*12*2,"native_scalar_root_cases":4103*2,"core_OFF_tests":127,"core_ON_tests":127,"original_inverse_tree_preserved":true,"new_inverse_tree_only_scalar_root_changed":true,"new_test_macro_type_repair_only":true,"new_timings":0,"adopted":false,"limits":"Separate source/receipt/count review, not a second native field oracle, curve implementation, formal proof, speed or RAM measurement. Existing core curve oracles share accepted arithmetic; fresh native field tests use Arkworks."});
    let dest = n.join("native-review.json");
    assert!(!dest.exists());
    fs::write(dest, serde_json::to_vec_pretty(&review).unwrap()).unwrap();
    println!("native source/receipt/count review PASS");
}
