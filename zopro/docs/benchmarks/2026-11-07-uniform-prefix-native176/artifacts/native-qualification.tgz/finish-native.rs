use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix176/native";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn check_exit(dir: &Path) {
    let e = load(dir.join("exit.json"));
    assert_eq!(e["success"], true);
    assert_eq!(e["returncode"], 0);
    for s in ["stdout", "stderr"] {
        assert_eq!(
            hash(dir.join(format!("{s}.log"))),
            e[format!("{s}_sha256")].as_str().unwrap()
        );
    }
}
fn main() {
    let r = Path::new(R);
    assert_eq!(load(r.join("native-review.json"))["review_passed"], true);
    let mut pins = 0;
    for name in [
        "field-fixed-pins.json",
        "core-pins.json",
        "sdk-build-pins.json",
    ] {
        for (p, h) in load(r.join(name)).as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
            pins += 1;
        }
    }
    assert_eq!(load(r.join("sdk-build/result.json"))["status"], "complete");
    let plan = load(r.join("sdk-build-plan.json"));
    assert_eq!(plan["steps"].as_array().unwrap().len(), 6);
    for step in plan["steps"].as_array().unwrap() {
        let base = r.join("sdk-build").join(step["name"].as_str().unwrap());
        check_exit(&base);
        let command = load(base.join("command.json"));
        let argv = command["argv"].as_array().unwrap();
        if step["kind"] == "command" {
            let expected = step["argv"].as_array().unwrap();
            assert_eq!(&argv[argv.len() - expected.len()..], expected);
        } else {
            assert!(argv.iter().any(|s| s == "-O"));
            for f in ["target-cpu=native", "lto=fat", "codegen-units=1"] {
                assert!(argv.windows(2).any(|w| w[0] == "-C" && w[1] == f));
            }
        }
    }
    for (name, count) in [("prover-lib-ON", 2), ("prover-cubic-ON", 6)] {
        let out = fs::read_to_string(r.join("sdk-build").join(name).join("stdout.log")).unwrap();
        assert!(out.contains(&format!(
            "{count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
        )));
    }
    for arm in ["OFF", "ON"] {
        let a = load(r.join(format!("sdk-build/{arm}/artifacts.json")));
        assert_eq!(
            hash(a["binary"].as_str().unwrap()),
            a["binary_sha256"].as_str().unwrap()
        );
        assert_eq!(a["libraries"].as_object().unwrap().len(), 8);
        for (p, h) in a["input_pins"].as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
        }
    }
    let mut command_count = 6;
    for stage in ["nm", "decode"] {
        assert_eq!(
            load(r.join(format!("{stage}-runs/result.json")))["status"],
            "complete"
        );
        let p = load(r.join(format!("{stage}-plan.json")));
        for s in p["steps"].as_array().unwrap() {
            let base = r
                .join(format!("{stage}-runs"))
                .join(s["name"].as_str().unwrap());
            check_exit(&base);
            let c = load(base.join("command.json"));
            let actual = c["argv"].as_array().unwrap();
            let expected = s["argv"].as_array().unwrap();
            assert_eq!(&actual[actual.len() - expected.len()..], expected);
            command_count += 1;
        }
    }
    let analysis = load(r.join("codegen-analysis.json"));
    let jobs = load(r.join("codegen-jobs.json"));
    assert_eq!(jobs.as_array().unwrap().len(), 4);
    let mut g1 = false;
    let mut g2 = false;
    for j in jobs.as_array().unwrap() {
        let stream = r.join(format!(
            "decode-runs/{}/stdout.log",
            j["name"].as_str().unwrap()
        ));
        let text = fs::read_to_string(&stream).unwrap();
        let begin = j["address"].as_u64().unwrap();
        let end = begin + j["size_bytes"].as_u64().unwrap();
        let mut ins = vec![];
        for line in text.lines() {
            if let Some((ip, body)) = line.split_once(':') {
                if let Ok(ip) = u64::from_str_radix(ip.trim(), 16) {
                    if (begin..end).contains(&ip) {
                        ins.push(body.trim());
                    }
                }
            }
        }
        let key = format!(
            "{}-{}",
            j["kind"].as_str().unwrap(),
            j["arm"].as_str().unwrap()
        );
        let row = &analysis["rows"][&key];
        assert_eq!(row["instructions"], ins.len());
        assert_eq!(
            row["IFMA_sites"],
            ins.iter().filter(|s| s.starts_with("vpmadd52")).count()
        );
        assert_eq!(
            row["left4_shifts"],
            ins.iter()
                .filter(|s| s.starts_with("vpsllq") && s.ends_with(",0x4"))
                .count()
        );
        assert_eq!(
            row["right48_shifts"],
            ins.iter()
                .filter(|s| s.starts_with("vpsrlq") && s.ends_with(",0x30"))
                .count()
        );
        assert_eq!(
            row["calls"].as_array().unwrap().len(),
            ins.iter().filter(|s| s.starts_with("call ")).count()
        );
        assert_eq!(row["decode_sha256"], hash(&stream));
        assert_eq!(row["binary_sha256"], hash(j["binary"].as_str().unwrap()));
    }
    for kind in ["G1", "G2"] {
        let off = &analysis["rows"][format!("{kind}-OFF")];
        let on = &analysis["rows"][format!("{kind}-ON")];
        let passed = ["instructions", "left4_shifts", "right48_shifts"]
            .into_iter()
            .all(|k| on[k].as_u64().unwrap() < off[k].as_u64().unwrap())
            && on["IFMA_sites"] == off["IFMA_sites"]
            && on["new_wrapper_calls"] == 0;
        if kind == "G1" {
            g1 = passed
        } else {
            g2 = passed
        }
    }
    assert_eq!(analysis["G1_structure_gate_passed"], g1);
    assert_eq!(analysis["G2_structure_gate_passed"], g2);
    assert_eq!(analysis["native_structure_gate_passed"], g1 && g2);
    let result = json!({"review_passed":true,"input_pin_occurrences":pins,"SDK_nm_decode_receipts":command_count,"selected_consumers":4,"G1_structure_gate_passed":g1,"G2_structure_gate_passed":g2,"full_proof_pilot_selected":g1&&g2,"adopted":false,"new_performance_captures":0,"new_full_SDK_Gnark_exports":0,"canonical_proof_ledger_count":31699,"limits":"Separate retained-text receipt/count/gate review. No repeated native tests, model, proof verifier, capture, nm or decoder. Not a second disassembler, native oracle, formal stack bound or latency prediction."});
    let dest = r.join("final-review.json");
    assert!(!dest.exists());
    fs::write(dest, serde_json::to_vec_pretty(&result).unwrap()).unwrap();
    println!(
        "final native/SDK retained-text review PASS; pilot_selected={}",
        g1 && g2
    );
}
