use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix176";
const REPO: &str = "/home/ubuntu/src/zk-tools/zopro";
const MANIFEST:&str="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json";
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn write(p: impl AsRef<Path>, s: impl AsRef<[u8]>) {
    assert!(!p.as_ref().exists(), "{} exists", p.as_ref().display());
    fs::write(p, s).unwrap();
}
fn main() {
    let manifest: Value = serde_json::from_slice(&fs::read(MANIFEST).unwrap()).unwrap();
    let source = Path::new(ROOT).join("native/source");
    assert!(!source.exists());
    fs::create_dir_all(&source).unwrap();
    let files = manifest["source_files_sha256"].as_object().unwrap();
    assert_eq!(files.len(), 176);
    for (name, sha) in files {
        let old = Path::new(REPO).join(name);
        assert_eq!(hash(&old), sha.as_str().unwrap());
        let dest = source.join(name);
        fs::create_dir_all(dest.parent().unwrap()).unwrap();
        fs::copy(old, dest).unwrap();
    }
    let ifma = source.join("crates/zopro-bn254/src/ifma.rs");
    let parent = fs::read_to_string(&ifma).unwrap();
    let old=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/scaled-norm-numerator176/native/source/crates/zopro-bn254/src/ifma.rs").unwrap();
    let start = old
        .find("impl<C: FpConfig> Ifma<C, true> {\n    /// R256 value (self*b+c*d)/16")
        .unwrap();
    let end = old[start..].find("\n#[cfg(test)]").unwrap() + start;
    let reused = &old[start..end];
    let signed_start = parent.find("    /// (sign*by-ay)*scale").unwrap();
    let signed_end = parent[signed_start..].find("\n}\n").unwrap() + signed_start;
    let signed = parent[signed_start..signed_end]
        .replace(
            "signed_difference_scaled(",
            "signed_difference_scaled_div16(",
        )
        .replace("assert!(MIXED);", "")
        .replace(
            "Self(t,PhantomData).mul(scale)",
            "Self(t,PhantomData).mul_div16(scale)",
        )
        .replace("/// (sign*by-ay)*scale,", "/// (sign*by-ay)*scale/16,");
    assert!(signed.contains(".mul_div16(scale)"));
    let new_impl=format!("\n{reused}\nimpl<C:FpConfig> Ifma<C,true> {{\n    /// Logical R256 value self*b/16; normalized inputs <=2p.\n    #[inline(always)]\n    pub fn mul_div16(&self,b:&Self)->Self {{\n        let a=Ifma::<C,false>(self.0,PhantomData);\n        let b=Ifma::<C,false>(b.0,PhantomData);\n        let value=a.mul(&b);Self(value.0,PhantomData)\n    }}\n{signed}\n}}\n");
    let (prefix, tests) = parent.split_once("#[cfg(test)]").unwrap();
    fs::write(&ifma, format!("{prefix}{new_impl}\n#[cfg(test)]{tests}")).unwrap();
    let lib = source.join("crates/zopro-bn254/src/lib.rs");
    let mut text = fs::read_to_string(&lib).unwrap();
    text.push_str("\npub mod uniform_prefix;\n#[cfg(all(test,target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma)))]\nmod uniform_prefix_tests;\n");
    fs::write(lib, text).unwrap();
    write(
        source.join("crates/zopro-bn254/src/uniform_prefix.rs"),
        include_str!("field-child.rs"),
    );
    write(
        source.join("crates/zopro-bn254/src/uniform_prefix_tests.rs"),
        include_str!("field-tests.rs"),
    );
    write(Path::new(ROOT).join("native/reused-fused-impl.txt"), reused);
    let pins: BTreeMap<String, String> = files
        .keys()
        .map(|n| {
            let p = Path::new(REPO).join(n);
            (p.to_str().unwrap().to_owned(), hash(&p))
        })
        .chain(
            [
                MANIFEST,
                concat!(
                    "/home/ubuntu/src/zopro-perf-work/uniform-prefix176/",
                    "native-design.md"
                ),
            ]
            .map(|p| (p.to_owned(), hash(p))),
        )
        .collect();
    write(
        Path::new(ROOT).join("native/accepted-inputs.json"),
        serde_json::to_vec_pretty(&pins).unwrap(),
    );
    write(Path::new(ROOT).join("native/preparation.json"),serde_json::to_vec_pretty(&json!({"accepted_files_checked":176,"source_files_before_generation":178,"reused_fused_impl_sha256":format!("{:x}",Sha256::digest(reused.as_bytes())),"generator_run":false,"native_executed":false,"new_proofs":0,"new_timings":0})).unwrap());
    println!("prepared exact accepted176 + field wrappers/2 children; generator not run");
}
