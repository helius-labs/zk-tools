use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::Path,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix176";
const P: &str = "/home/ubuntu/src/zopro-perf-work/borrowed-bucket-tree176/native/primary-pilot";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn med(v: &[f64]) -> f64 {
    let mut a = v.to_vec();
    assert!(a.iter().all(|x| x.is_finite()));
    a.sort_by(f64::total_cmp);
    a[a.len() / 2]
}
fn close(a: f64, b: f64) {
    assert!((a - b).abs() < 1e-9 * a.abs().max(b.abs()).max(1.));
}
fn main() {
    assert!(!Path::new(&format!("{R}/work-audit.json")).exists());
    let checked = load(format!("{P}/independent-review.json"));
    assert_eq!(checked["review_passed"], true);
    assert_eq!(checked["canonical_ledger_count"], 31699);
    let analysis = load(format!("{P}/latency-analysis.json"));
    let plan = load(format!("{P}/latency-plan.json"));
    let protocol = load(format!("{P}/protocol.json"));
    assert_eq!(protocol["workers"], 32);
    assert_eq!(protocol["rounds"], 151);
    assert_eq!(protocol["blocks"], 15);
    assert_eq!(analysis["rows"].as_array().unwrap().len(), 45);
    let driver = fs::read_to_string(
        "/home/ubuntu/src/zopro-perf-work/borrowed-bucket-tree176/native/driver.rs",
    )
    .unwrap();
    let perf = fs::read_to_string(
        "/home/ubuntu/src/zopro-perf-work/borrowed-bucket-tree176/native/support/perf.rs",
    )
    .unwrap();
    let prime = driver.find("for _ in 0..3").unwrap();
    let before = driver.find("let before = perf::Usage::now()").unwrap();
    let loop_start = driver.find("let loop_started = Instant::now()").unwrap();
    let loop_end = driver.find("let loop_wall_ms =").unwrap();
    let after = driver.find("let after = perf::Usage::now()").unwrap();
    let export = driver.find("if let Some(directory)").unwrap();
    assert!(
        prime < before
            && before < loop_start
            && loop_start < loop_end
            && loop_end < after
            && after < export
    );
    assert!(perf.contains("libc::getrusage(libc::RUSAGE_SELF"));
    let mut contexts = BTreeSet::new();
    let mut rows = vec![];
    let mut by_arm = BTreeMap::<String, Vec<Value>>::new();
    for row in analysis["rows"].as_array().unwrap() {
        let job = &row["job"];
        let arm = job["arm"].as_str().unwrap();
        let block = job["block"].as_u64().unwrap();
        assert!(block < 15);
        assert!(contexts.insert((arm.to_string(), block)));
        let name = job["name"].as_str().unwrap();
        let prefix = format!("{P}/latency-runs/{name}");
        let exit = load(format!("{prefix}/exit.json"));
        assert_eq!(exit["success"], true);
        assert_eq!(exit["returncode"], 0);
        let command = load(format!("{prefix}/command.json"));
        let step = plan["steps"]
            .as_array()
            .unwrap()
            .iter()
            .find(|s| s["name"] == name)
            .unwrap();
        let a = command["argv"].as_array().unwrap();
        let b = step["argv"].as_array().unwrap();
        assert_eq!(&a[a.len() - b.len()..], b);
        for s in ["stdout", "stderr"] {
            assert_eq!(
                hash(format!("{prefix}/{s}.log")),
                exit[format!("{s}_sha256")].as_str().unwrap()
            );
        }
        let raw = fs::read_to_string(format!("{prefix}/stdout.log")).unwrap();
        let summaries = raw
            .lines()
            .filter_map(|s| s.strip_prefix("SUMMARY "))
            .collect::<Vec<_>>();
        assert_eq!(summaries.len(), 1);
        let summary: Value = serde_json::from_str(summaries[0]).unwrap();
        assert_eq!(&summary, &row["summary"]);
        assert_eq!(summary["rounds"], 151);
        assert_eq!(summary["priming"], 3);
        assert_eq!(summary["workers"], 32);
        let samples = raw
            .lines()
            .filter_map(|s| s.strip_prefix("SAMPLE "))
            .map(|s| serde_json::from_str::<Value>(s).unwrap())
            .collect::<Vec<_>>();
        assert_eq!(samples.len(), 151);
        let mut sum = 0.;
        for (i, s) in samples.iter().enumerate() {
            assert_eq!(s["round"], i);
            let ms = s["ms"].as_f64().unwrap();
            assert!(ms > 0. && ms.is_finite());
            close(ms, row["samples_ms"][i].as_f64().unwrap());
            sum += ms;
        }
        close(sum / 151., row["mean_ms"].as_f64().unwrap());
        let wall = summary["loop_wall_ms"].as_f64().unwrap();
        assert!(wall + 0.001 >= sum);
        let user = summary["user_cpu_ms"].as_f64().unwrap();
        let system = summary["system_cpu_ms"].as_f64().unwrap();
        assert!(user > 0. && system >= 0.);
        let cpu = (user + system) / 151.;
        let occupied = (user + system) / wall;
        assert!(occupied > 0. && occupied < 33.);
        let entry = json!({"arm":arm,"block":block,"SDK_mean_ms":sum/151.,"loop_ms_per_request":wall/151.,"user_cpu_ms_per_request":user/151.,"system_cpu_ms_per_request":system/151.,"summed_cpu_ms_per_request":cpu,"average_logical_CPU_occupancy":occupied,"conditional_same_CPU_work_div32_ms":cpu/32.,"conditional_target_CPU_work_fraction":(32.*3.7)/cpu,"minor_faults_per_request":summary["minor_faults"].as_f64().unwrap()/151.,"voluntary_switches_per_request":summary["voluntary_switches"].as_f64().unwrap()/151.,"involuntary_switches_per_request":summary["involuntary_switches"].as_f64().unwrap()/151.,"loop_minus_sum_samples_ms":wall-sum});
        by_arm.entry(arm.into()).or_default().push(entry.clone());
        rows.push(entry);
    }
    let mut arms = BTreeMap::new();
    for (arm, rows) in by_arm {
        assert_eq!(rows.len(), 15);
        let mut summary = serde_json::Map::new();
        for key in [
            "SDK_mean_ms",
            "loop_ms_per_request",
            "user_cpu_ms_per_request",
            "system_cpu_ms_per_request",
            "summed_cpu_ms_per_request",
            "average_logical_CPU_occupancy",
            "conditional_same_CPU_work_div32_ms",
            "conditional_target_CPU_work_fraction",
            "minor_faults_per_request",
            "voluntary_switches_per_request",
            "involuntary_switches_per_request",
            "loop_minus_sum_samples_ms",
        ] {
            summary.insert(
                key.into(),
                json!(med(&rows
                    .iter()
                    .map(|r| r[key].as_f64().unwrap())
                    .collect::<Vec<_>>())),
            );
        }
        arms.insert(arm, Value::Object(summary));
    }
    let result = json!({"review_passed":true,"raw_process_rows":45,"raw_SDK_samples":6795,"source_boundaries_checked":true,"all_rows_retained":true,"arms":arms,"rows":rows,"new_measurements":0,"new_proofs":0,"canonical_ledger_count":31699,"limits":"Conditional CPU-work accounting only, not a physical hardware lower bound, useful-work utilization, measured idle time or a prediction that scheduler changes preserve CPU time. IPC/clocks/SMT/search/spin/runtime and worker-dependent arithmetic can change CPU time. getrusage brackets the loop slightly wider than wall timing; output/primes are excluded."});
    fs::write(
        format!("{R}/work-audit.json"),
        serde_json::to_vec_pretty(&result).unwrap(),
    )
    .unwrap();
    println!("45rawprocesses/6795SDKsamples CPU accounting pass;no recapture");
}
