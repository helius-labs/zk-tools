use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const ROOT: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix176";
const CFG:&str="all(zopro_uniform_prefix,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma))";
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn rep(s: &mut String, a: &str, b: &str, n: usize) {
    assert_eq!(s.matches(a).count(), n, "{a}");
    *s = s.replace(a, b);
}
fn function_span(s: &str, name: &str) -> (usize, usize) {
    let start = s.find(name).unwrap();
    let body = s[start..].find('{').unwrap() + start;
    let mut depth = 0;
    for (i, c) in s.char_indices().skip_while(|(i, _)| *i < body) {
        if c == '{' {
            depth += 1;
        }
        if c == '}' {
            depth -= 1;
            if depth == 0 {
                return (start, i + 1);
            }
        }
    }
    panic!("unclosed {name}");
}
fn main() {
    let root = Path::new(ROOT).join("native");
    let source = root.join("core-source-fixed");
    assert!(!source.exists());
    let result: Value =
        serde_json::from_slice(&fs::read(root.join("field-fixed-runs/result.json")).unwrap())
            .unwrap();
    assert_eq!(result["status"], "complete");
    let field_pins: BTreeMap<String, String> =
        serde_json::from_slice(&fs::read(root.join("field-fixed-pins.json")).unwrap()).unwrap();
    assert_eq!(field_pins.len(), 178);
    for (old, sha) in &field_pins {
        assert_eq!(&hash(old), sha);
        let relative = Path::new(old)
            .strip_prefix(root.join("source-field-fixed"))
            .unwrap();
        let dest = source.join(relative);
        fs::create_dir_all(dest.parent().unwrap()).unwrap();
        fs::copy(old, dest).unwrap();
    }
    let simd = source.join("crates/zopro-core/src/simd.rs");
    let mut text = fs::read_to_string(&simd).unwrap();
    let (start, end) = function_span(&text, "    /// Invert eight nonzero values");
    let original = &text[start..end];
    let inverse=original.replace("pub(crate) fn inverse_nonzero(","pub(crate) fn inverse_nonzero_scaled16(").replace("let inverse = (products[0] * products[4]).inverse().unwrap();","let inverse = zopro_bn254::uniform_prefix::div16_root(products[0] * products[4]).inverse().unwrap();");
    assert!(inverse.contains("div16_root"));
    let mut wrappers = String::from("\n");
    for (name, args, body) in [
        ("mul_div16", "b:&Self", "Self(self.0.mul_div16(&b.0))"),
        (
            "sum2_div16",
            "b:&Self,c:&Self,d:&Self",
            "Self(self.0.sum2_div16(&b.0,&c.0,&d.0))",
        ),
        (
            "difference2_div16",
            "b:&Self,c:&Self,d:&Self",
            "Self(self.0.difference2_div16(&b.0,&c.0,&d.0))",
        ),
        (
            "signed_difference_scaled_div16",
            "ay:&Self,scale:&Self,negative:u8",
            "Self(self.0.signed_difference_scaled_div16(&ay.0,&scale.0,negative))",
        ),
    ] {
        wrappers.push_str(&format!("    #[cfg({CFG})]\n    #[inline(always)]\n    pub(crate) fn {name}(&self,{args})->Self{{{body}}}\n"));
    }
    wrappers.push_str(&format!("    #[cfg({CFG})]\n{inverse}\n"));
    text.insert_str(end, &wrappers);
    fs::write(simd, text).unwrap();
    let msm = source.join("crates/zopro-core/src/msm.rs");
    let mut text = fs::read_to_string(&msm).unwrap();
    let (start, end) = function_span(&text, "fn stream_g1_impl<");
    let mut body = text[start..end].to_owned();
    rep(
        &mut body,
        "chains.mul(&denominator)",
        "prefix_mul(&chains,&denominator)",
        2,
    );
    rep(
        &mut body,
        "direct_chain_inverse(&chains,full==batch.len(),s.vector_inverse)",
        "prefix_inverse(&chains,full==batch.len(),s.vector_inverse)",
        1,
    );
    rep(
        &mut body,
        "FqBatch::new(&inverse)",
        "prefix_tail_inverse(FqBatch::new(&inverse),full)",
        1,
    );
    rep(
        &mut body,
        "g.numerator.mul(&inverse)",
        "prefix_mul(&g.numerator,&inverse)",
        1,
    );
    rep(
        &mut body,
        "inverse.mul(&g.denominator)",
        "prefix_mul(&inverse,&g.denominator)",
        1,
    );
    text.replace_range(start..end, &body);
    let (start, _) = function_span(&text, "fn scaled_signed_dy<");
    let at = text[start..].find('{').unwrap() + start + 1;
    text.insert_str(at,&format!("\n    #[cfg({CFG})] {{\n        if SIGNED {{return by.signed_difference_scaled_div16(ay,chains,negative);}}\n        return prefix_mul(&canonical_sub::<FAST>(by,ay),chains);\n    }}\n"));
    // Isolate the old helper body at compile time, avoiding retained fallback work.
    let (start, end) = function_span(&text, "fn scaled_signed_dy<");
    let helper = &text[start..end];
    let old_start = helper.find("    #[cfg(all(feature=").unwrap() + start;
    text.insert_str(end - 1, "\n    }\n");
    text.insert_str(old_start, &format!("    #[cfg(not({CFG}))] {{\n"));
    text.push_str("\nmod uniform_prefix;\nuse uniform_prefix::{prefix_mul,prefix_norm,prefix_numerator,prefix_inverse,prefix_tail_inverse};\n");
    fs::write(msm, text).unwrap();
    for file in ["g2_prefix.rs", "g2_borrowed.rs"] {
        let path = source.join("crates/zopro-core/src/msm").join(file);
        let mut text = fs::read_to_string(&path).unwrap();
        let (start, end) = function_span(&text, "pub(super) fn apply<");
        let mut body = text[start..end].to_owned();
        rep(
            &mut body,
            "Fq2::lanes_norm(&denominator)",
            "prefix_norm(&denominator)",
            1,
        );
        rep(
            &mut body,
            "chains.mul(&norm)",
            "prefix_mul(&chains,&norm)",
            1,
        );
        rep(&mut body, "direct_chain_inverse(", "prefix_inverse(", 1);
        rep(
            &mut body,
            "FqBatch::new(&inverse)",
            "prefix_tail_inverse(FqBatch::new(&inverse),full)",
            1,
        );
        rep(
            &mut body,
            "s.prefix_records[j][0].mul(&inverse)",
            "prefix_mul(&s.prefix_records[j][0],&inverse)",
            1,
        );
        rep(
            &mut body,
            "inverse.mul(&s.prefix_records[j][1])",
            "prefix_mul(&inverse,&s.prefix_records[j][1])",
            1,
        );
        rep(
            &mut body,
            "Fq2::lanes_scaled_numerator(",
            "prefix_numerator(",
            1,
        );
        text.replace_range(start..end, &body);
        fs::write(path, text).unwrap();
    }
    let module = include_str!("core-child.rs")
        .replace("not(UP)", &format!("not({CFG})"))
        .replace(
            "all(UP, zopro_direct_chain_inverse)",
            &format!("all({CFG},zopro_direct_chain_inverse)"),
        )
        .replace("cfg(UP)", &format!("cfg({CFG})"));
    assert!(!module.contains("UP"));
    fs::write(
        source.join("crates/zopro-core/src/msm/uniform_prefix.rs"),
        module,
    )
    .unwrap();
    let mut pins = BTreeMap::new();
    fn walk(p: &Path, pins: &mut BTreeMap<String, String>) {
        for e in fs::read_dir(p).unwrap() {
            let p = e.unwrap().path();
            if p.is_dir() {
                walk(&p, pins)
            } else {
                pins.insert(p.to_str().unwrap().into(), hash(&p));
            }
        }
    }
    walk(&source, &mut pins);
    assert_eq!(pins.len(), 179);
    fs::write(
        root.join("core-pins.json"),
        serde_json::to_vec_pretty(&pins).unwrap(),
    )
    .unwrap();
    let old: Value = serde_json::from_slice(
        &fs::read(
            "/home/ubuntu/src/zopro-perf-work/scaled-norm-numerator176/native/core-plan.json",
        )
        .unwrap(),
    )
    .unwrap();
    let mut plan = old.clone();
    plan["source_pins"] = json!(root.join("core-pins.json"));
    for step in plan["steps"].as_array_mut().unwrap() {
        for arg in step["argv"].as_array_mut().unwrap() {
            if arg.as_str().unwrap().ends_with("/core-source/Cargo.toml") {
                *arg = json!(source.join("Cargo.toml"));
            }
        }
        let name = step["name"].as_str().unwrap().to_owned();
        step["environment"]["CARGO_TARGET_DIR"] = json!(root.join(format!("{name}-target")));
        let flags = step["environment"]["RUSTFLAGS"]
            .as_str()
            .unwrap()
            .replace("zopro_scaled_norm_numerator", "zopro_uniform_prefix");
        step["environment"]["RUSTFLAGS"] = json!(flags);
    }
    fs::write(
        root.join("core-plan.json"),
        serde_json::to_vec_pretty(&plan).unwrap(),
    )
    .unwrap();
    println!("prepared179files; field bodies inherited exact; core OFF/ON plan frozen");
}
