use ark_bn254::{Fq,Fq2,Fr,G1Config,G2Config};
use ark_ec::{AffineRepr,CurveGroup,short_weierstrass::{Affine,Projective,SWCurveConfig}};
use ark_ff::{BigInteger,Field,PrimeField,Zero};
use num_bigint::BigUint;
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/uniform-prefix176";
fn big(v: u64) -> BigUint {
    BigUint::from(v)
}
fn next(s: &mut u64) -> u64 {
    *s ^= *s << 13;
    *s ^= *s >> 7;
    *s ^= *s << 17;
    *s
}
fn random(s: &mut u64, modulus: &BigUint) -> BigUint {
    let mut b = vec![];
    for _ in 0..4 {
        b.extend_from_slice(&next(s).to_le_bytes());
    }
    BigUint::from_bytes_le(&b) % modulus
}
struct Redc<F: PrimeField> {
    p: BigUint,
    twop: BigUint,
    r: BigUint,
    pinv: BigUint,
    hinv: F,
    sixteenth: F,
}
impl<F: PrimeField> Redc<F> {
    fn new() -> Self {
        let p = BigUint::from_bytes_le(&F::MODULUS.to_bytes_le());
        let r = big(1) << 260;
        let pinv = p.modpow(&((&r >> 1) - big(1)), &r);
        assert_eq!((&p * &pinv) % &r, big(1));
        assert!(&p * big(8) < r);
        let hinv = F::from(2).pow([256u64]).inverse().unwrap();
        Self {
            twop: &p * big(2),
            p,
            r,
            pinv,
            hinv,
            sixteenth: F::from(16).inverse().unwrap(),
        }
    }
    fn field(&self, x: &BigUint) -> F {
        F::from_le_bytes_mod_order(&x.to_bytes_le()) * self.hinv
    }
    fn evaluate(
        &self,
        a: &BigUint,
        b: &BigUint,
        c: &BigUint,
        d: &BigUint,
        negative: bool,
    ) -> BigUint {
        for v in [a, b, c, d] {
            assert!(v <= &self.twop);
        }
        let t = if negative {
            a * b + (&self.twop - c) * d
        } else {
            a * b + c * d
        };
        let rem = (&t * &self.pinv) % &self.r;
        let k = if rem == big(0) { big(0) } else { &self.r - rem };
        let cancelled = &t + &k * &self.p;
        assert_eq!(&cancelled % &self.r, big(0));
        let out = cancelled / &self.r;
        assert!(out < self.twop);
        let want = if negative {
            self.field(a) * self.field(b) - self.field(c) * self.field(d)
        } else {
            self.field(a) * self.field(b) + self.field(c) * self.field(d)
        } * self.sixteenth;
        assert_eq!(self.field(&out), want);
        out
    }
}

fn partial16<F:PrimeField>(ctx:&Redc<F>,z:&BigUint)->BigUint {
    assert!(z<=&ctx.twop);
    let sixteen=big(16);
    let residue=(z*&ctx.pinv)%&sixteen;
    let k=if residue==big(0){big(0)}else{&sixteen-residue};
    let cancelled=z+&k*&ctx.p;
    assert_eq!(&cancelled%&sixteen,big(0));
    let mut out=cancelled/&sixteen;
    assert!(out<ctx.twop);
    if out>=ctx.p{out-=&ctx.p;}
    assert!(out<ctx.p);
    assert_eq!(ctx.field(&out),ctx.field(z)*ctx.sixteenth);
    out
}
fn primitive_model<F:PrimeField>(label:&str)->Value {
    let ctx=Redc::<F>::new();
    let edges=[big(0),big(1),&ctx.p-big(1),ctx.p.clone(),&ctx.p+big(1),&ctx.twop-big(1),ctx.twop.clone()];
    let mut seed=if label=="Fq"{0x731b_d5c8_6a90_f243}else{0xc904_67ea_31db_a805};
    let mut products=0;let mut roots=0;let mut zero_roots=0;
    let mut check=|a:&BigUint,b:&BigUint| {
        let out=ctx.evaluate(a,b,&big(0),&big(0),false);
        assert_eq!(ctx.field(&out),ctx.field(a)*ctx.field(b)*ctx.sixteenth);
        products+=1;out
    };
    for a in &edges{for b in &edges{check(a,b);}}
    for _ in 0..4096{check(&random(&mut seed,&(&ctx.twop+big(1))),&random(&mut seed,&(&ctx.twop+big(1))));}
    let mut boundaries=0;
    for bit in[51usize,52,63,64,104,128,156,192,208,253,254,255] {
        let power=big(1)<<bit;
        for a in[&power-big(1),power.clone(),&power+big(1)] {
            if a<=ctx.twop {check(&a,&random(&mut seed,&(&ctx.twop+big(1))));boundaries+=1;}
        }
    }
    let mut state=random(&mut seed,&ctx.twop);
    for _ in 0..1024{state=check(&state,&random(&mut seed,&ctx.twop));}
    for z in edges.iter().cloned().chain((0..4096).map(|_|random(&mut seed,&(&ctx.twop+big(1))))) {
        let out=partial16(&ctx,&z);
        let value=ctx.field(&z);
        if value.is_zero(){assert!(ctx.field(&out).is_zero());zero_roots+=1;}
        else{assert_eq!(ctx.field(&out).inverse().unwrap(),F::from(16)*value.inverse().unwrap());}
        roots+=1;
    }
    let h=F::from(2).pow([256u64]);
    let mut root_lanes=0;
    for _ in 0..1024 {
        let values:[F;8]=core::array::from_fn(|_|{let v=F::from_le_bytes_mod_order(&random(&mut seed,&ctx.p).to_bytes_le());if v.is_zero(){F::ONE}else{v}});
        let mut prefix=[F::ONE;8];let mut product=F::ONE;
        for i in 0..8{prefix[i]=product;product*=values[i];}
        let encoded=(product*h).into_bigint();
        let raw=BigUint::from_bytes_le(&encoded.to_bytes_le());
        let divided=partial16(&ctx,&raw);
        let mut inverse=ctx.field(&divided).inverse().unwrap();
        for i in(0..8).rev(){let out=inverse*prefix[i];inverse*=values[i];assert_eq!(out*values[i],F::from(16));root_lanes+=1;}
    }
    json!({"field":label,"fresh_product_outputs":products,"inclusive_edges":49,"random_pairs":4096,"power_neighbor_cases":boundaries,"changing_chain_outputs":1024,"partial16_raw_cases":roots,"zero_residue_cases":zero_roots,"distributed_scaled_inverse_lanes":root_lanes,"raw_bounds_passed":true})
}
trait PointField:Field {
    const EXTENSION:bool;
    fn denominator(self)->Fq;
    fn numerator(dy:Self,dx:Self)->Self;
    fn scale_value(self,f:Fq)->Self;
}
impl PointField for Fq {
    const EXTENSION:bool=false;
    fn denominator(self)->Fq{self}
    fn numerator(dy:Self,_:Self)->Self{dy}
    fn scale_value(self,f:Fq)->Self{self*f}
}
impl PointField for Fq2 {
    const EXTENSION:bool=true;
    fn denominator(self)->Fq{self.c0.square()+self.c1.square()}
    fn numerator(dy:Self,dx:Self)->Self{dy*Fq2::new(dx.c0,-dx.c1)}
    fn scale_value(self,f:Fq)->Self{Self::new(self.c0*f,self.c1*f)}
}
fn inverse_lanes(values:[Fq;8])->[Fq;8] {
    let mut pre=[Fq::from(1);8];let mut product=Fq::from(1);
    for i in 0..8{assert!(!values[i].is_zero());pre[i]=product;product*=values[i];}
    let mut inv=product.inverse().unwrap();let mut out=[Fq::from(1);8];
    for i in(0..8).rev(){out[i]=inv*pre[i];inv*=values[i];}
    out
}
struct Entry<P:SWCurveConfig> {a:Affine<P>,b:Affine<P>,pre:Fq,d:Fq,num:P::BaseField,index:usize}
#[derive(Clone,Copy)] enum Bridge{Correct,Missing,BeforeTail}
fn finish<P:SWCurveConfig>(a:Affine<P>,b:Affine<P>,slope:P::BaseField)->Affine<P> {
    let x=slope.square()-a.x-b.x;let y=slope*(a.x-x)-a.y;Affine::new_unchecked(x,y)
}
fn apply<P>(input:&[Affine<P>],batch:&[(usize,Affine<P>)],uniform:bool,bridge:Bridge)->Result<Vec<Affine<P>>,&'static str>
where P:SWCurveConfig<ScalarField=Fr>,P::BaseField:PointField {
    let mut seen=vec![false;input.len()];
    for &(i,b)in batch {
        if i>=input.len(){return Err("bounds");}
        if seen[i]{return Err("duplicate");}seen[i]=true;
        if input[i].is_zero()||b.is_zero(){return Err("identity");}
        if (b.x-input[i].x).is_zero(){return Err("equal-x");}
    }
    let h=if uniform{Fq::from(16).inverse().unwrap()}else{Fq::ONE};
    let correction=if uniform{Fq::from(16)}else{Fq::ONE};
    let full=batch.len()/8*8;let mut chain=[Fq::ONE;8];let mut groups=Vec::<[Entry<P>;8]>::new();
    for k in(0..full).step_by(8) {
        let group=core::array::from_fn(|l|{
            let (index,b)=batch[k+l];let a=input[index];let dx=b.x-a.x;
            let d=dx.denominator()*if P::BaseField::EXTENSION{h}else{Fq::ONE};
            let num=P::BaseField::numerator(b.y-a.y,dx).scale_value(if P::BaseField::EXTENSION{h}else{chain[l]*h});
            let entry=Entry{a,b,pre:chain[l],d,num,index};chain[l]=chain[l]*d*h;entry
        });groups.push(group);
    }
    let mut tails=vec![];
    for k in full..batch.len(){
        let l=k%8;let(index,b)=batch[k];let a=input[index];let dx=b.x-a.x;let d=dx.denominator();
        let num=P::BaseField::numerator(b.y-a.y,dx).scale_value(chain[l]);
        tails.push(Entry{a,b,pre:chain[l],d,num,index});chain[l]*=d;
    }
    let mut inverse=inverse_lanes(chain);
    if matches!(bridge,Bridge::BeforeTail){for v in &mut inverse{*v*=correction;}}
    let mut out=input.to_vec();
    for(offset,e)in tails.iter().enumerate().rev(){
        let l=(full+offset)%8;let slope=e.num.scale_value(inverse[l]);inverse[l]*=e.d;out[e.index]=finish(e.a,e.b,slope);
    }
    if matches!(bridge,Bridge::Correct){for v in &mut inverse{*v*=correction;}}
    for group in groups.iter().rev(){for l in 0..8{
        let e=&group[l];
        let slope=if P::BaseField::EXTENSION{let factor=e.pre*inverse[l]*h;e.num.scale_value(factor*h)}else{e.num.scale_value(inverse[l]*h)};
        inverse[l]=inverse[l]*e.d*h;
        if matches!(bridge,Bridge::Correct)||!uniform{assert_eq!(slope,(e.b.y-e.a.y)*(e.b.x-e.a.x).inverse().unwrap());}
        out[e.index]=finish(e.a,e.b,slope);
    }}
    Ok(out)
}
fn scalar(label:&str)->Fr{Fr::from_le_bytes_mod_order(&Sha256::digest(label.as_bytes()))}
fn points<P:SWCurveConfig<ScalarField=Fr>>(n:usize,label:&str)->Vec<Affine<P>> {
    let g=Affine::<P>::generator();let base=scalar(&format!("uniform-prefix-19c48a5d/{label}/base"));let step=scalar(&format!("uniform-prefix-19c48a5d/{label}/step"));
    let mut p=g.mul_bigint(base.into_bigint());let dp=g.mul_bigint(step.into_bigint());let mut out=Vec::with_capacity(n);
    for _ in 0..n{out.push(p);p+=dp;}Projective::<P>::normalize_batch(&out)
}
fn point_model<P>(label:&str)->Value where P:SWCurveConfig<ScalarField=Fr>,P::BaseField:PointField {
    let mut cases=0;let mut outputs=0;let mut rows=vec![];
    for n in[0usize,1,7,8,9,15,16,31,32,63,64,199,200,201,351,352,353,511]{
        let size=(n+1).next_power_of_two();let initial=points::<P>(size,&format!("{label}/{n}/initial"));let incoming=points::<P>(n,&format!("{label}/{n}/incoming"));
        for sign in 0..3{
            let batch=incoming.iter().enumerate().map(|(i,&p)|((i*53)%size,if sign==1||sign==2&&i%3==0{-p}else{p})).collect::<Vec<_>>();
            let mut state=initial.clone();let mut reference=initial.clone();
            for pass in 0..3{
                for &(i,b)in &batch{reference[i]=(reference[i].into_group()+b).into_affine();}
                let control=apply::<P>(&state,&batch,false,Bridge::Correct).unwrap();
                let candidate=apply::<P>(&state,&batch,true,Bridge::Correct).unwrap();
                assert_eq!(control,reference);assert_eq!(candidate,reference);
                for i in 0..size{if !batch.iter().any(|&(index,_)|index==i){assert_eq!(candidate[i],state[i]);}}
                state=candidate;cases+=1;outputs+=n;
                rows.push(json!({"length":n,"sign":sign,"pass":pass,"outputs":n,"untouched_checked":size-n}));
            }
        }
    }
    let g=Affine::<P>::generator();let two=(g.into_group()+g).into_affine();
    assert_ne!(g.y,two.y);
    let initial=vec![g;9];let batch=(0..9).map(|i|(i,two)).collect::<Vec<_>>();
    let correct=apply::<P>(&initial,&batch,true,Bridge::Correct).unwrap();
    let missing=apply::<P>(&initial,&batch,true,Bridge::Missing).unwrap();
    let early=apply::<P>(&initial,&batch,true,Bridge::BeforeTail).unwrap();
    assert_ne!(&missing[..8],&correct[..8]);assert_eq!(missing[8],correct[8]);
    assert_eq!(&early[..8],&correct[..8]);assert_ne!(early[8],correct[8]);
    let identity=Affine::<P>::zero();
    let guards=[
        (vec![g],vec![(1,two)]),(vec![g],vec![(0,two),(0,two)]),
        (vec![identity],vec![(0,two)]),(vec![g],vec![(0,identity)]),
        (vec![g],vec![(0,g)]),(vec![g],vec![(0,-g)])
    ];
    for(input,batch)in &guards{assert!(apply::<P>(input,batch,true,Bridge::Correct).is_err());}
    json!({"curve":label,"cases":cases,"qualified_point_outputs":outputs,"rows":rows,"guards":guards.len(),"wrong_bridge_fullvector_control":true,"premature_bridge_tail_control":true,"point_codecs_changed":false,"final_coordinate_arithmetic_ordinary":true})
}
fn main(){
    let raw=json!([primitive_model::<Fq>("Fq"),primitive_model::<Fr>("Fr")]);
    let point=json!([point_model::<G1Config>("G1"),point_model::<G2Config>("G2")]);
    let out=json!({"mathematical_qualification_passed":true,"raw":raw,"points":point,"q":16,"bridge_factor_independent_of_prefix_length":true,"no_power_table_or_point_codec":true,"new_proofs":0,"new_timings":0,"canonical_ledger_count":31699,"production_changed":false,"native_qualified":false,"performance_qualified":false,"native_primitive_codegen_screen_selected":true,"limits":"Exact scalar REDC/Arkworks schedule algebra, not new native SIMD execution, proof, measured RAM or speed. Ordinary-product counts unchanged; non-IFMA packing/dependency benefit remains a hypothesis."});
    let p=format!("{R}/analysis.json");assert!(!Path::new(&p).exists());fs::write(p,serde_json::to_vec_pretty(&out).unwrap()).unwrap();println!("uniform G1/G2 prefix and mixed-tail algebra pass;native screen selected,not adopted");
}
