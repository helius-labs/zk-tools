use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::Path,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/uniform-prefix176";
const P: &str = "/home/ubuntu/src/zopro-perf-work/borrowed-bucket-tree176/native/primary-pilot";
fn load(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn close(a: f64, b: f64) {
    assert!((a - b).abs() < 1e-10 * a.abs().max(b.abs()).max(1.));
}
fn med(mut a: Vec<f64>) -> f64 {
    a.sort_by(f64::total_cmp);
    a[a.len() / 2]
}
fn main() {
    assert!(!Path::new(&format!("{R}/review.json")).exists());
    let mut pins = 0;
    for file in ["work-pins.json", "math-fixed-pins.json"] {
        for (p, h) in load(format!("{R}/{file}")).as_object().unwrap() {
            assert_eq!(hash(p), h.as_str().unwrap());
            pins += 1;
        }
    }
    let accepted=load("/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json");
    let source = accepted["source_files_sha256"].as_object().unwrap();
    assert_eq!(source.len(), 176);
    for (p, h) in source {
        assert_eq!(
            hash(format!("/home/ubuntu/src/zk-tools/zopro/{p}")),
            h.as_str().unwrap()
        );
    }
    let old =
        fs::read_to_string("/home/ubuntu/src/zopro-perf-work/scaled-norm-numerator176/model.rs")
            .unwrap();
    let fragment = &old[old.find("fn big(").unwrap()..old.find("fn raw<").unwrap()];
    let initial = fs::read_to_string(format!("{R}/model.rs")).unwrap();
    let fixed = fs::read_to_string(format!("{R}/model-fixed.rs")).unwrap();
    let start = fixed.find("fn big(").unwrap();
    assert_eq!(&fixed[start..start + fragment.len()], fragment);
    let expected=initial.replacen("use ark_bn254::{Fq,Fq2,Fr,G1Config,G2Config};","use ark_bn254::{Fq,Fq2,Fr};\nuse ark_bn254::{g1::Config as G1Config,g2::Config as G2Config};",1);
    assert_eq!(expected, fixed);
    let mut receipts = 0;
    for (plan, dir) in [
        ("work-plan.json", "work-runs"),
        ("math-fixed-plan.json", "math-fixed-runs"),
    ] {
        let plan = load(format!("{R}/{plan}"));
        assert_eq!(load(format!("{R}/{dir}/result.json"))["status"], "complete");
        assert_eq!(plan["steps"].as_array().unwrap().len(), 2);
        for s in plan["steps"].as_array().unwrap() {
            let prefix = format!("{R}/{dir}/{}", s["name"].as_str().unwrap());
            let e = load(format!("{prefix}/exit.json"));
            assert_eq!(e["success"], true);
            assert_eq!(e["returncode"], 0);
            let c = load(format!("{prefix}/command.json"));
            let a = c["argv"].as_array().unwrap();
            let b = s["argv"].as_array().unwrap();
            assert_eq!(&a[a.len() - b.len()..], b);
            for stream in ["stdout", "stderr"] {
                assert_eq!(
                    hash(format!("{prefix}/{stream}.log")),
                    e[format!("{stream}_sha256")].as_str().unwrap()
                );
            }
            receipts += 1;
        }
    }
    let failed = load(format!("{R}/math-runs/build-model/exit.json"));
    assert_eq!(failed["success"], false);
    assert!(!Path::new(&format!("{R}/math-runs/run-model/exit.json")).exists());
    let work = load(format!("{R}/work-audit.json"));
    assert_eq!(work["raw_process_rows"], 45);
    assert_eq!(work["raw_SDK_samples"], 6795);
    let data = load(format!("{P}/latency-analysis.json"));
    let mut recompute = BTreeMap::<String, Vec<(f64, f64)>>::new();
    for r in data["rows"].as_array().unwrap() {
        let arm = r["job"]["arm"].as_str().unwrap();
        let name = r["job"]["name"].as_str().unwrap();
        let raw = fs::read_to_string(format!("{P}/latency-runs/{name}/stdout.log")).unwrap();
        let line = raw
            .lines()
            .find_map(|l| l.strip_prefix("SUMMARY "))
            .unwrap();
        let summary: Value = serde_json::from_str(line).unwrap();
        let cpu =
            summary["user_cpu_ms"].as_f64().unwrap() + summary["system_cpu_ms"].as_f64().unwrap();
        let rounds = summary["rounds"].as_u64().unwrap() as f64;
        let wall = summary["loop_wall_ms"].as_f64().unwrap();
        recompute
            .entry(arm.into())
            .or_default()
            .push((cpu / rounds, cpu / wall));
    }
    for (arm, rows) in recompute {
        assert_eq!(rows.len(), 15);
        let cpu = med(rows.iter().map(|r| r.0).collect());
        let occupied = med(rows.iter().map(|r| r.1).collect());
        close(
            cpu,
            work["arms"][&arm]["summed_cpu_ms_per_request"]
                .as_f64()
                .unwrap(),
        );
        close(
            occupied,
            work["arms"][&arm]["average_logical_CPU_occupancy"]
                .as_f64()
                .unwrap(),
        );
        close(
            cpu / 32.,
            work["arms"][&arm]["conditional_same_CPU_work_div32_ms"]
                .as_f64()
                .unwrap(),
        );
        close(
            118.4 / cpu,
            work["arms"][&arm]["conditional_target_CPU_work_fraction"]
                .as_f64()
                .unwrap(),
        );
    }
    let math = load(format!("{R}/analysis.json"));
    assert_eq!(math["mathematical_qualification_passed"], true);
    assert_eq!(math["q"], 16);
    let mut products = 0;
    let mut rootcases = 0;
    let mut rootlanes = 0;
    for row in math["raw"].as_array().unwrap() {
        assert_eq!(row["fresh_product_outputs"], 5202);
        assert_eq!(row["inclusive_edges"], 49);
        assert_eq!(row["random_pairs"], 4096);
        assert_eq!(row["power_neighbor_cases"], 33);
        assert_eq!(row["changing_chain_outputs"], 1024);
        assert_eq!(row["partial16_raw_cases"], 4103);
        assert_eq!(row["zero_residue_cases"], 3);
        assert_eq!(row["distributed_scaled_inverse_lanes"], 8192);
        products += 5202;
        rootcases += 4103;
        rootlanes += 8192;
    }
    assert_eq!(math["raw"].as_array().unwrap().len(), 2);
    let mut outputs = 0;
    let mut cases = 0;
    let mut guards = 0;
    for row in math["points"].as_array().unwrap() {
        assert_eq!(row["cases"], 162);
        assert_eq!(row["qualified_point_outputs"], 21717);
        assert_eq!(row["guards"], 6);
        assert_eq!(row["wrong_bridge_fullvector_control"], true);
        assert_eq!(row["premature_bridge_tail_control"], true);
        let mut seen = BTreeSet::new();
        let mut sum = 0;
        for r in row["rows"].as_array().unwrap() {
            let n = r["length"].as_u64().unwrap();
            let sign = r["sign"].as_u64().unwrap();
            let pass = r["pass"].as_u64().unwrap();
            assert!(sign < 3 && pass < 3);
            assert!(seen.insert((n, sign, pass)));
            assert_eq!(r["outputs"], n);
            sum += n;
        }
        assert_eq!(seen.len(), 162);
        assert_eq!(sum, 21717);
        outputs += sum;
        cases += 162;
        guards += 6;
    }
    assert_eq!(math["points"].as_array().unwrap().len(), 2);
    // Independent integer-exponent recurrence: multiplication subtracts one q.
    for i in 1i64..=1024 {
        let g1_pre = -(i - 1);
        let g1_num = g1_pre - 1;
        let g1_inv = i + 1;
        assert_eq!(g1_num + g1_inv - 1, 0);
        assert_eq!(g1_inv - 1, i);
        let g2_pre = -2 * (i - 1);
        let g2_inv = 2 * i + 1;
        let factor = g2_pre + g2_inv - 1;
        assert_eq!(factor, 2);
        assert_eq!(-1 + factor - 1, 0);
        assert_eq!(g2_inv - 1 - 1, 2 * (i - 1) + 1);
    }
    let result = json!({"review_passed":true,"input_pin_occurrences":pins,"accepted_source_files_checked":176,"command_receipts":receipts,"old_REDC_fragment_byte_exact":true,"initial_import_only_build_failure_preserved":true,"CPU_accounting_rows_reconstructed":45,"new_raw_product_outputs":products,"partial16_cases":rootcases,"scaled_root_inverse_lanes":rootlanes,"point_cases":cases,"point_outputs":outputs,"guards":guards,"independent_q_exponent_cases":1024,"new_native_calls":0,"new_timings":0,"new_proofs":0,"canonical_ledger_count":31699,"adopted":false,"limits":"Separate receipt/count/exponent/CPU-stat review, not a second BigUint REDC or curve implementation, formal native proof, physical CPU lower bound or speed estimate. Earlier successful models/qualifications/captures were not rerun."});
    fs::write(
        format!("{R}/review.json"),
        serde_json::to_vec_pretty(&result).unwrap(),
    )
    .unwrap();
    println!("uniform prefix review PASS;{receipts}receipts/{cases}pointcases/{outputs}outputs;no newtiming/proof");
}
