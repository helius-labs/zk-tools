# Interval rows for the task recorder

Prior SDK observer is structurally complete but fails its frozen overhead
screen: 32-worker ON/OFF median1.053650, upper1.067126>1.05. Do not loosen that
gate, promote16, or recapture that unchanged representation. Canonical verified
exports now50071. Full CPUAVX singleproof10x ALL8 M5CPU goal remains0/8/unmet;
CPU+Metal comparisons retained. No new AWS or production change at this stage.

Distinct mechanism: reserve ONE per-thread row at operation start and update
its end timestamp in place. Preserve publication BEFORE/AFTER original pushes,
job start/end including join own-job run_inline, FIFO inner/wrapper, external
and broadcast publication, complete victim-search invocations, and phase spans.
No clocks, observations, queue operations or fences are removed. Drop unused
execution-parent pointer metadata; it was not semantic dependency ancestry.

Row = [start_ns,end_ns,kind,job_ptr,execute_fn_ptr,queue,owner], seven u64/56B.
Kinds1publication,3job,5search,7phase. Guard retains slot index, never a TLS
borrow across actual operation. Publication guards are local/non-Send even
though JobRef moves into the original queue. End writes only the reserved
slot; per-thread Vec never grows beyond preallocated limit. JobRef remains
two pointer-sized words. Native original quartet fully reversible; new child
and tests. Same dependency versions as accepted176.

Keep process-exclusive capture/preparation leases, touched buffers before
capture, exact participants, overflow/unprepared/late-phase faults, stop lease,
and valid job/search tails crossing stop (latch may signal before guard drops).
Reject take_current while any interval is open to prevent draining its slot.
Reject incomplete/reversed/crossing intervals, unsupported post-stop work,
missing/duplicate participants and any overflow. No hot shared append lock or
event counter. This is a diagnostic, not a universal RAM cap or new prover pool.

New native tests adapt previous eight real-pool/misuse cases and add explicit
slot closure, zero end before drop, outstanding drain refusal, nesting and
crossing validation. Pools1/4/16/32 requested512KiB; FIFO/scoped/broadcast,
reused keys, callbacks, unwind, disabled, overflow, concurrent preparation.
Upstream unfiltered library/integration tests plus disabled-CFG compile.
Snapshot compatibility does NOT mean old event reader can read intervals:
SDK and independent reader must adapt and qualify before ANY proof preflight.

SDK next stage inherits SAME fixed9blocks/primary16+32/REF+OFF+ON/31requests and
same calibration/overheadbounds as task-lifecycle-sdk176, but new frame protocol
declared separately before clocks. No advantage inferred from source byte
counts; must pass actual verified SDK observer screen before C7a readiness.
No arithmetic, key tables, solver plan, worker pool or production source change.
Commit and push completed qualification; preserve failures and all actual runs.
