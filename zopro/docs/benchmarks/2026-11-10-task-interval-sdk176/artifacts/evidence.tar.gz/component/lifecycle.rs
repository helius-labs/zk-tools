//! Diagnostic interval rows, stored only in preallocated thread-local buffers.
use std::{cell::RefCell,marker::PhantomData,rc::Rc,sync::{OnceLock,atomic::{AtomicBool,AtomicU64,AtomicUsize,Ordering}},time::Instant};
pub type Event=[u64;7];pub type Key=(usize,usize);
pub const PUBLISH:u64=1;pub const JOB:u64=3;pub const SEARCH:u64=5;pub const PHASE:u64=7;
pub const EXTERNAL:usize=usize::MAX;pub const FIFO:usize=usize::MAX-1;pub const BROADCAST:usize=1usize<<(usize::BITS-1);
const CAPTURE:usize=1usize<<(usize::BITS-1);
static LEASE:AtomicUsize=AtomicUsize::new(0);static ACTIVE:AtomicBool=AtomicBool::new(false);static UNPREPARED:AtomicU64=AtomicU64::new(0);static CLOCK:OnceLock<Instant>=OnceLock::new();
#[derive(Debug)]pub(crate) struct Preparation;
impl Preparation{pub(crate) fn acquire()->Result<Self,&'static str>{LEASE.fetch_update(Ordering::AcqRel,Ordering::Relaxed,|n|if n<CAPTURE-1{Some(n+1)}else{None}).map_err(|_|"capture lease held")?;Ok(Self)}}
impl Drop for Preparation{fn drop(&mut self){let n=LEASE.fetch_sub(1,Ordering::Release);assert!(n>0&&n<CAPTURE);}}
#[derive(Default)]struct Buffer{events:Vec<Event>,limit:usize,dropped:u64,worker:usize,pool:usize,depth:usize,late:u64}
thread_local!{static BUFFER:RefCell<Buffer>=RefCell::new(Buffer::default());}
fn now()->u64{CLOCK.get().expect("prepare recorder clock").elapsed().as_nanos().try_into().expect("trace clock overflow")}
pub fn prepare_current(worker:usize,pool:usize,capacity:usize)->Result<(),&'static str>{let _permit=Preparation::acquire()?;if capacity==0{return Err("zero event capacity");}CLOCK.get_or_init(Instant::now);BUFFER.with(|b|{let mut b=b.borrow_mut();if b.depth!=0{return Err("outstanding scope");}let mut events=vec![[0;7];capacity];
 // A stride smaller than a page and a final-byte write force page commitment;
 // calloc/zero-page mappings alone would not establish physical first touch.
 for i in (0..capacity).step_by(64){unsafe{std::ptr::write_volatile(events[i].as_mut_ptr(),0);}}
 unsafe{std::ptr::write_volatile(&mut events[capacity-1][6],0);}
 std::hint::black_box(events.as_slice());events.clear();*b=Buffer{events,limit:capacity,worker,pool,..Buffer::default()};Ok(())})}
#[inline]fn enabled()->bool{ACTIVE.load(Ordering::Relaxed)}
#[derive(Debug)]pub struct Scope{armed:bool,slot:Option<usize>,kind:u64,_local:PhantomData<Rc<()>>}
impl Scope{fn new(kind:u64,key:Key,queue:usize,owner:usize)->Self{let armed=enabled();let slot=if armed{let start=now();BUFFER.with(|b|{let mut b=b.borrow_mut();b.depth+=1;if b.limit==0{UNPREPARED.fetch_add(1,Ordering::Relaxed);return None;}if b.events.len()>=b.limit{b.dropped+=1;return None;}let slot=b.events.len();b.events.push([start,0,kind,key.0 as u64,key.1 as u64,queue as u64,owner as u64]);Some(slot)})}else{None};Self{armed,slot,kind,_local:PhantomData}}}
impl Drop for Scope{fn drop(&mut self){if !self.armed{return;}let end=now();let late=self.kind==PHASE&&!enabled();BUFFER.with(|b|{let mut b=b.borrow_mut();assert!(b.depth>0);if late{b.late+=1;}if let Some(slot)=self.slot{let row=&mut b.events[slot];assert_eq!(row[1],0);assert!(end>=row[0]);row[1]=end;}b.depth-=1;});}}
#[inline]pub(crate) fn publication(key:Key,queue:usize,owner:usize)->Scope{Scope::new(PUBLISH,key,queue,owner)}
#[inline]pub(crate) fn job(key:Key)->Scope{Scope::new(JOB,key,0,0)}
#[inline]pub(crate) fn search()->Scope{Scope::new(SEARCH,(0,0),0,0)}
pub fn phase(id:usize)->Scope{Scope::new(PHASE,(id,0),0,0)}
#[derive(Debug)]pub struct Snapshot{pub worker:usize,pub pool:usize,pub dropped:u64,pub late:u64,pub outstanding:usize,pub capacity:usize,pub events:Vec<Event>}
pub fn take_current()->Result<Snapshot,&'static str>{if ACTIVE.load(Ordering::Acquire){return Err("capture active");}BUFFER.with(|b|{let mut b=b.borrow_mut();if b.limit==0{return Err("thread unprepared");}if b.depth!=0{return Err("outstanding scope");}let out=Snapshot{worker:b.worker,pool:b.pool,dropped:b.dropped,late:b.late,outstanding:b.depth,capacity:b.limit,events:std::mem::take(&mut b.events)};b.limit=0;Ok(out)})}
#[derive(Debug)]pub struct Session{begin:u64,_local:PhantomData<Rc<()>>}
#[derive(Debug)]pub struct Stopped{pub begin_ns:u64,pub end_ns:u64,_local:PhantomData<Rc<()>>}
impl Session{pub fn begin()->Result<Self,&'static str>{if CLOCK.get().is_none(){return Err("recorder not prepared");}if !BUFFER.with(|b|{let b=b.borrow();b.limit>0&&b.events.is_empty()&&b.depth==0&&b.events.capacity()>=b.limit}){return Err("caller buffer not ready");}LEASE.compare_exchange(0,CAPTURE,Ordering::AcqRel,Ordering::Relaxed).map_err(|_|"capture or preparation active")?;UNPREPARED.store(0,Ordering::Relaxed);let begin=now();ACTIVE.store(true,Ordering::Release);Ok(Self{begin,_local:PhantomData})}
 pub fn stop(self)->Stopped{ACTIVE.store(false,Ordering::Release);let out=Stopped{begin_ns:self.begin,end_ns:now(),_local:PhantomData};std::mem::forget(self);out}}
impl Drop for Session{fn drop(&mut self){ACTIVE.store(false,Ordering::Release);LEASE.store(0,Ordering::Release);}}
impl Stopped{pub fn validate(&self,snapshots:&[Snapshot],expected:&[(usize,usize)])->Result<(),&'static str>{let ids=snapshots.iter().map(|s|(s.pool,s.worker)).collect::<std::collections::BTreeSet<_>>();let required=expected.iter().copied().collect::<std::collections::BTreeSet<_>>();if ids.len()!=snapshots.len()||required.len()!=expected.len()||ids!=required{return Err("snapshot participant mismatch");}if UNPREPARED.load(Ordering::Relaxed)!=0{return Err("unprepared participant");}
 for s in snapshots{if s.dropped!=0{return Err("event overflow");}if s.outstanding!=0{return Err("outstanding scope");}if s.late!=0{return Err("scope completed after stop");}let mut last=self.begin_ns;let mut ends=Vec::new();for row in &s.events{let(start,end,kind)=(row[0],row[1],row[2]);if start<last{return Err("event before capture or nonmonotonic");}if end==0||end<start{return Err("incomplete or reversed interval");}if !matches!(kind,PUBLISH|JOB|SEARCH|PHASE){return Err("unknown interval kind");}if start>self.end_ns&&kind!=SEARCH{return Err("unexpected work after stop");}if end>self.end_ns&&!matches!(kind,JOB|SEARCH){return Err("unexpected interval completion after stop");}while ends.last().is_some_and(|&e|e<=start){ends.pop();}if ends.last().is_some_and(|&e|end>e){return Err("crossing interval");}ends.push(end);last=start;}}
 Ok(())}}
impl Drop for Stopped{fn drop(&mut self){LEASE.store(0,Ordering::Release);}}
