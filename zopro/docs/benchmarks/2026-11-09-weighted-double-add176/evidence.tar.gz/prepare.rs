use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,io::Read};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-double-add176";
fn hash(p:&str)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn main(){let out=format!("{R}/native-plan.json");assert!(!Path::new(&out).exists());
 let rustc="/home/ubuntu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/rustc";
 let frozen="/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175/frozen/candidate";
 let ark="/home/ubuntu/src/zopro-perf-work/word-export176/target-candidate/release/deps";
 let field=format!("{frozen}/libzopro_bn254-1200e63547baa41c299a48e3221f1cef85990b0369f17452dc12eb17045f9713.rlib");
 let generic="/home/ubuntu/src/zopro-perf-work/tree-policy-owner176/libzopro_bn254-generic.rlib";
 let rayon=format!("{frozen}/librayon-bf7ab8bf274c84025bc411d349fd1a65105f41c57b184396781dc43ee353a282.rlib");
 let ab=format!("{ark}/libark_bn254-d28868a71f06f5b5.rlib");let ae=format!("{ark}/libark_ec-59ebd5b49f9b3011.rlib");let af=format!("{ark}/libark_ff-3a8e68dc8045d2bd.rlib");
 let native=vec![rustc.into(),"--edition=2021".into(),"--test".into(),format!("{R}/qualification.rs"),"-O".into(),"-C".into(),"target-cpu=native".into(),"-C".into(),"lto=fat".into(),"-C".into(),"codegen-units=1".into(),"-C".into(),"overflow-checks=on".into(),"-C".into(),"debug-assertions=on".into(),"-L".into(),format!("dependency={frozen}"),"-L".into(),format!("dependency={ark}"),"--extern".into(),format!("zopro_bn254={field}"),"--extern".into(),format!("rayon={rayon}"),"--extern".into(),format!("ark_bn254={ab}"),"--extern".into(),format!("ark_ec={ae}"),"--extern".into(),format!("ark_ff={af}"),"-o".into(),format!("{R}/qualification")];
 let guard=vec![rustc.into(),"--edition=2021".into(),"--crate-type=rlib".into(),format!("{R}/kernel.rs"),"--crate-name".into(),"weighted_double_add_generic".into(),"-O".into(),"-C".into(),"target-cpu=generic".into(),"--cfg".into(),"no_ifma".into(),"--cfg".into(),"no_asm".into(),"-L".into(),format!("dependency={frozen}"),"--extern".into(),format!("zopro_bn254={generic}"),"-o".into(),format!("{R}/libweighted_double_add_generic.rlib")];
 let mut pins=serde_json::Map::new();for p in[format!("{R}/design.md"),format!("{R}/kernel.rs"),format!("{R}/qualification.rs"),format!("{R}/prepare.rs"),format!("{R}/prepare"),rustc.into(),field,generic.into(),rayon,ab,ae,af]{pins.insert(p.clone(),json!(hash(&p)));}
 let manifest="/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json";
 let m:Value=serde_json::from_slice(&fs::read(manifest).unwrap()).unwrap();for(rel,h)in m["source_files_sha256"].as_object().unwrap(){let p=format!("/home/ubuntu/src/zk-tools/zopro/{rel}");assert_eq!(hash(&p),h.as_str().unwrap());pins.insert(p,h.clone());}pins.insert(manifest.into(),json!(hash(manifest)));
 let plan=json!({"version":1,"source_pins":format!("{R}/native-pins.json"),"steps":[{"kind":"command","name":"build-independent-native-qualification","argv":native,"timeout_seconds":600},{"kind":"command","name":"native-weighted-fold-oracles","argv":[format!("{R}/qualification"),"--nocapture","--test-threads=1"],"timeout_seconds":600},{"kind":"command","name":"generic-no-ifma-no-asm-guard","argv":guard,"timeout_seconds":300}]});
 fs::write(format!("{R}/native-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();fs::write(out,serde_json::to_vec_pretty(&plan).unwrap()).unwrap();
 println!("Frozen new weighted-double-add qualification: {}pins/3commands; no proofs or performance capture",pins.len());
}
