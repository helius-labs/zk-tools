# Saved G2 scheduling postmortem

Freeze before new analysis. The full SPR-tuned SDK is rejected. This follow-up
uses its nine saved profiles, cached accepted G2 decode and new-candidate G2
decode. No native execution, recording, decoder, proof or old test is replayed.

Question: where does sampled execution inside the signed borrowed G2 consumer
increase, and does the emitted code show a more specific inspection target?
Do not infer exclusive wall time, causality, an exact stall, a critical path,
speedup or an adoptable candidate from flat sample counts.

Keep all nine profiles: accepted/control/candidate at primary16, primary32 and
24x2/32. Map sampled PCs using recorded executable MMAP2 file offsets and ELF
executable LOAD segments; do not assume virtual and file offsets are equal.
Validate function address/size/name against the actual ELF symbol table.
Require every recognized target sample to be inside its function and match
an instruction start before classifying it. Preserve large-shape zero counts.

The accepted disassembly uses AT&T syntax; the new candidate uses Intel syntax.
Classification must account for both, with IFMA classified before memory/vector
categories. Count full static instruction and memory-form populations separately
from sample-weighted populations. Inspect complete fixed 256-byte windows and
top sampled instruction neighborhoods. Neither window addresses nor contiguous
instructions are assumed to be basic blocks or a removable dependency chain.

The accepted-source control has not been decoded in this study. First compare
its complete function bytes with the cached accepted instruction boundaries.
Allow only relative-address tail differences in RIP-relative instructions or
direct branches/calls, keeping all opcode/address-mode bytes. If that full
compatibility check fails, retain the control's function-level sample counts
without assigning instruction semantics. Do not silently treat matching offsets
as matching instructions or exclude a failed context. This is a decoding-class
compatibility check, not a claim of equivalent branch targets or field values.

Inspect the profile increase, not a favorable compiler variant. The parent
global-SPR rejection remains unchanged. Any new Rust implementation requires a
distinct hypothesis and prospective full caller/proof checks. Preserve original
all8 CPU>=10x M5CPU goal and CPU/Metal reporting, accepted source176/SDK6d83,
canonical34439, universal low-RAM requirements and no key-sized extra tables.
