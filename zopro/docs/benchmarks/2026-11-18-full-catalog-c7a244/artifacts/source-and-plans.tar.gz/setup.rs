use std::{collections::BTreeSet,fs,io::Read,path::Path};use serde_json::{json,Value};use sha2::{Digest,Sha256};
const R:&str="/home/ubuntu/src/zopro-perf-work/full-c7a244"; const OLD:&str="/home/ubuntu/src/zopro-perf-work/adopted-c7a239";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn save(p:impl AsRef<Path>,v:Value){assert!(!p.as_ref().exists());fs::write(p,serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
fn main(){let r=Path::new(R);let local=r.join("local");let old=Path::new(OLD).join("bundle");
for d in["bin","config","images","requests","lib"]{fs::create_dir(local.join(d)).unwrap();}
let manifest=read(Path::new(OLD).join("production-manifest.json"));assert_eq!(manifest["source_files_sha256"].as_object().unwrap().len(),188);for(p,h)in manifest["source_files_sha256"].as_object().unwrap(){assert_eq!(hash(Path::new("/home/ubuntu/src/zk-tools/zopro").join(p)),h.as_str().unwrap());}save(r.join("production-manifest.json"),manifest);
let mut cfg=read(old.join("config/config.json"));
let oldcases=cfg["cases"].clone();let lock=read("/home/ubuntu/src/zk-tools/zopro/tools/zolana/zopro-keys.lock");assert_eq!(lock["keys"].as_object().unwrap().len(),41);let mut newcases=serde_json::Map::new();
for(name,k)in lock["keys"].as_object().unwrap(){let id=name.strip_suffix(".key").unwrap();let shape=if let Some(x)=id.strip_prefix("merge_"){format!("merge-{}",x.replace('_',"x"))}else{id.strip_prefix("transfer_confidential_").unwrap().replace('_',"x")};
let key=format!("keys/{name}");assert_eq!(hash(local.join(&key)),k["key_sha256"].as_str().unwrap());
let mut c=if let Some(c)=oldcases.get(&shape){let c=c.clone();for(f,h)in[("image","image_sha256"),("request","request_sha256")]{let rel=c[f].as_str().unwrap();assert_eq!(hash(old.join(rel)),c[h].as_str().unwrap());fs::hard_link(old.join(rel),local.join(rel)).unwrap();}c}else{
let source=r.join("assets").join(format!("{id}.image"));let rel=format!("images/{id}.image");fs::hard_link(&source,local.join(&rel)).unwrap();let req=r.join("generated-requests").join(format!("{shape}.json"));let request=format!("requests/{shape}.json");fs::hard_link(&req,local.join(&request)).unwrap();
json!({"shape":shape,"id":id,"image":rel,"image_sha256":hash(&source),"request":request,"request_sha256":hash(req),"public_sha256":hash(r.join("generated-requests").join(format!("{shape}.public"))),"reference":Value::Null})};
c["aeglos_key"]=json!(key);c["aeglos_key_sha256"]=k["key_sha256"].clone();newcases.insert(shape,c);
}
assert_eq!(newcases.len(),41);cfg["cases"]=json!(newcases);cfg["scope"]=json!("All41 pinned Zopro confidential-transfer/merge shapes; broader mobile families separately inventoried");
for rel in["bin/sdk","bin/aeglos","bin/verify","bin/xtask","lib/libstdc++.so.6"]{fs::copy(old.join(rel),local.join(rel)).unwrap();}
for n in["runner","independent"]{fs::copy(r.join(n),local.join("bin").join(n)).unwrap();}
for n in["sdk","aeglos"]{assert_eq!(hash(local.join("bin").join(n)),cfg[format!("{n}_sha256")].as_str().unwrap());}
let seed=Path::new(OLD).join("host-remote/proof-sha256.json");assert_eq!(hash(&seed),"17f43bcd6b9a2731c5464bfdc62b4fb26948e86b9ea67452269126cc022d0d7b");let ledger:BTreeSet<String>=serde_json::from_value(read(&seed)).unwrap();assert_eq!(ledger.len(),62411);fs::copy(seed,local.join("config/seed.json")).unwrap();cfg["seed_count"]=json!(62411);save(local.join("config/config.json"),cfg);
for n in["protocol.md","runner.rs","independent.rs","setup.rs"]{fs::copy(r.join(n),local.join("config").join(n)).unwrap();}fs::copy(r.join("production-manifest.json"),local.join("config/production-manifest.json")).unwrap();
println!("Prepared all41 current SDK/image/request and pinned Aeglos key bindings; 188 sources unchanged; seed62411.");
}
