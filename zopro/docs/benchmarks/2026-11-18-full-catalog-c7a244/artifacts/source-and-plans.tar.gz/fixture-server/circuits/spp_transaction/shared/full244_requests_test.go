package shared_test
import("bytes";"encoding/json";"fmt";"math/big";"os";"path/filepath";"testing";"testing/cryptotest"
"github.com/consensys/gnark-crypto/ecc";"github.com/consensys/gnark/frontend"
defaultring "zolana/prover/circuits/spp_transaction/default"
. "zolana/prover/circuits/spp_transaction/shared"
"zolana/prover/prover-test/spp/protocol";"zolana/prover/prover-test/spp/spptest";"zolana/prover/prover/common";transfer "zolana/prover/prover/transfer_eddsa_only")
func TestFullCatalog244Requests(t *testing.T){cryptotest.SetGlobalRandom(t,0);out:=os.Getenv("FULL244_REQUESTS");if out==""{t.Fatal("FULL244_REQUESTS required")};if err:=os.MkdirAll(out,0755);err!=nil{t.Fatal(err)}
for _,shape:=range protocol.SupportedShapes{name:=fmt.Sprintf("%dx%d",shape.NInputs,shape.NOutputs);if shape.NOutputs==2{switch shape.NInputs{case 1,2,4,8,12,16,24:continue}}
t.Run(name,func(t *testing.T){a:=buildDefaultRingEddsaOnlyAssignment(t,shape);a.BlindingSeed=big.NewInt(800);rebuildAfterOwnerChange(t,a);refreshDefaultRingPublicInputHash(t,a);c:=asDefaultRingEddsaOnly(a).(*defaultring.DefaultRingEddsaOnlyCircuit);c.Shape=a.Shape;p:=requestParameters(c);data,e:=json.Marshal(p);if e!=nil{t.Fatal(e)};var decoded transfer.TransferParameters;if e=json.Unmarshal(data,&decoded);e!=nil{t.Fatal(e)};if e=decoded.ValidateShape();e!=nil{t.Fatal(e)};w,e:=decoded.CreateWitness();if e!=nil{t.Fatal(e)};full,e:=frontend.NewWitness(w,ecc.BN254.ScalarField());if e!=nil{t.Fatal(e)};pub,e:=full.Public();if e!=nil{t.Fatal(e)};var b bytes.Buffer;if _,e=pub.WriteTo(&b);e!=nil{t.Fatal(e)};for suffix,v:=range map[string][]byte{".json":data,".public":b.Bytes()}{path:=filepath.Join(out,name+suffix);if _,e=os.Stat(path);!os.IsNotExist(e){t.Fatal("output exists",path)};if e=os.WriteFile(path,v,0600);e!=nil{t.Fatal(e)}}})}
}
func requestParameters(c *defaultring.DefaultRingEddsaOnlyCircuit) *transfer.TransferParameters {
	value := spptest.AsBigInt
	values := spptest.ToBigInts
	p := &transfer.TransferParameters{
		NInputs:                      uint32(len(c.Private.Inputs)),
		NOutputs:                     uint32(len(c.Private.Outputs)),
		OutputTreeID:                 value(c.Public.OutputTreeID),
		ExternalDataHash:             value(c.Public.ExternalDataHash),
		PrivateTxHash:                value(c.Public.PrivateTxHash),
		BlindingSeed:                 value(c.Private.BlindingSeed),
		PublicAssets:                 values(c.Public.PublicAssets[:]),
		PublicAmounts:                values(c.Public.PublicAmounts[:]),
		RingProgramID:                big.NewInt(0),
		SignerPkHashes:               values(c.Public.SignerPkHashes),
		InputFlags:                   value(c.Public.InputFlags),
		PublishedOutputOwnerPkHashes: values(c.Public.OutputOwnerPkHashes),
		Cache: transfer.CacheSelectionParams{
			TreeID:        value(c.CachedInputs.TreeID),
			ReadHashChain: value(c.CachedInputs.ReadHashChain),
			ReadHashes:    values(c.CachedInputs.ReadHashes),
			IsCached:      values(c.CachedInputs.IsCached),
			ReadIndex:     values(c.CachedInputs.ReadIndex),
		},
		Variant:         transfer.ConfidentialVariant,
		PublicInputHash: value(c.Public.PublicInputHash),
	}
	for _, slot := range c.Public.TreeSlots {
		p.TreeSlots = append(p.TreeSlots, common.TreeSlotParams{
			ID:            value(slot.ID),
			UtxoRoot:      value(slot.UtxoRoot),
			NullifierRoot: value(slot.NullifierRoot),
		})
	}
	for i, in := range c.Private.Inputs {
		p.Inputs = append(p.Inputs, transfer.InputParams{
			Utxo:                     utxoParams(in.Utxo),
			StatePathElements:        values(in.StatePathElements),
			StatePathIndex:           value(in.StatePathIndex),
			NullifierLowValue:        value(in.NullifierLowValue),
			NullifierNextValue:       value(in.NullifierNextValue),
			NullifierLowPathElements: values(in.NullifierLowPathElements),
			NullifierLowPathIndex:    value(in.NullifierLowPathIndex),
			TreeSlot:                 value(in.TreeSlot),
			Nullifier:                value(c.Public.Nullifiers[i]),
			OwnerPkHash:              value(c.Private.InputOwnerPkHashes[i]),
			NullifierSecret:          value(in.NullifierSecret),
		})
	}
	for i, out := range c.Private.Outputs {
		p.Outputs = append(p.Outputs, transfer.OutputParams{
			Utxo:        utxoParams(out),
			Hash:        value(c.Public.OutputHashes[i]),
			OwnerPkHash: value(c.Public.OutputOwnerPkHashes[i]),
			NullifierPk: value(c.Private.OutputNullifierPks[i]),
		})
	}
	return p
}

func utxoParams(u UtxoCircuitFields) transfer.UtxoParams {
	value := func(v frontend.Variable) *big.Int { return spptest.AsBigInt(v) }
	return transfer.UtxoParams{
		Domain:        value(u.Domain),
		Owner:         value(u.Owner),
		Asset:         value(u.Asset),
		Amount:        value(u.Amount),
		Blinding:      value(u.Blinding),
		DataHash:      value(u.DataHash),
		RingDataHash:  value(u.RingDataHash),
		RingProgramID: value(u.RingProgramID),
	}
}
