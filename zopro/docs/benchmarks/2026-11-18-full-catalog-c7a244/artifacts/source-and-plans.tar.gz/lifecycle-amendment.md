# Full-catalog transport amendment

After all82 local exports verified and before any AWS resource, the full
bundle has7.14GB images plus3.72GB Gnark keys before compression. Replace the
single-PUT uploader with AWS CLI multipart-capable s3 cp, retaining AES256,
private bucket/public-access blocking and hash checks. Cleanup also enumerates
and aborts incomplete multipart uploads in this owned temporary bucket.

Only local cloud-lifecycle source/binary changes. No SDK, runner, reader,
payload, image, request, key, proof, sampling or timing boundary changes.
No successful scientific work repeated. Old cloud source retained separately;
new compilation pinned in multipart-build-plan.json. Archive creation proceeds
unchanged and package-ready hashes the final local lifecycle tool.
