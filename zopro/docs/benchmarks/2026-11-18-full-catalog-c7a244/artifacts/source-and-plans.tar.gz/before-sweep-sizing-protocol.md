# Full pinned Zopro catalog versus retained Aeglos on C7a — experiment244

Scope corrected BEFORE ANY proof/capture/VM: user clarified that nine historical
cases are not the full catalog. Pin tools/zolana/zopro-keys.lock prefix
proving-keys/3a1c88f90f609eb1: all41 shapes,38 confidential transfers and3 merges.
The broader mobile manifest contains130 keys across additional families; this
comparison covers this complete41-key pinned Zopro catalog, with broader manifest
coverage recorded explicitly. Do not call nine cases all supported shapes.

Compare exact current SDK d523 (adopted233 implementation/source188) with retained
Aeglos Sorted eab9/source0290613 on ONE c7a.24xlarge,96physical cores/SMT1.
Every shape/engine at BOTH32/96workers:164contexts. No production change.
Normal-selector SDK and latest upstream Aeglos are outside this binary comparison.

Reuse nine historical image/request/public bindings and recorded Gnark key pins.
Restore32missing pairs from locked CDN .key/.zopro hashes before native parsing.
Convert .zopro through existing frozen raw/Euler tools. Generate valid full
requests/public witnesses for32additional shapes from isolated release-source
fixture helpers. No production checkout changes, key regeneration, new runtime
LUTs, duplicated prover plans or SDK changes.

Freeze runner/separate same-agent reader before local proofs. Local functional
preflight: all41shapes ×2engines at4workers,3primes +1timed request;82fresh exports,
328SDKcalls. All captures precede82Gnark verifiers. Canonical seed62411 at239
host-remote/proof-sha256.json SHA17f43bcd6b9a2731c5464bfdc62b4fb26948e86b9ea67452269126cc022d0d7b.
Successful local ledger62493 seeds a separate remote bundle; local seed immutable.

Remote164preflight contexts then164Gnark verifiers and semantic/separate-reader
gates; nine rotated/reversed matched blocks ×164contexts, each3primes +17timed
calls,1476main captures, all before1476late verifiers. Totals1640remote exports,
30176remoteSDKcalls/25256timed records. Final canonical64133 if allcomplete.
Three independent byte-identical binary backings/engine, block%3, allused.
No exclusions/extensions/timing replays/worker rescue. Retain every failure.
Only poll confirmed handle during ANY SDK capture; no owned CPU cojobs.
All remote exports host-reverified after hash-checked retrieval.

Latency includes solving,fresh randomness,proof construction,serialization and
internal verification; existing Aeglos verified_ms boundary unchanged. Setup/load/
pool/primes outside latency but inside lifetime RSS. Report all164rows,per-shape
paired latency/CPU ratios and maximum lifetimeRSS including preflights;96/32
scaling for bothengines. Supplied historical M5CPU/Metal refs only existing8;
never invent refs for33additional shapes or conflate this sweep with full10xgoal.
Nine-block medians,zero-based ranks1/7 nominal96.09375%marginal coverage under
independentcontinuousblock assumptions; not simultaneous/familywise confidence.
No new adoption veto/minimumgainfloor. No coldstart/throughput/minimumRAM claim.

Same allocator/defaultstacks/fixedaffinity policy as239. One native systemd
30GiB/no-swap service is infrastructure headroom,not proverarchitecturelimit.
Record cgroup/ancestor fields/readerrors. Missing CPU files do not establish
unlimited CPU/no throttling. Preserve uninstrumented latency/CPU/RSS/faults.
No new causal PMU claim.

Before launch require actual devSSO account558215002830,>=110min credentials,
no existing owned benchmark,restricted no-ingress SG,source/package/hashguards.
One idempotent VM/90minterminateTTL,SSM/noSSH,private encrypted transferbucket,
noECR. Remote measure bound3600s; no silent restart on timeout/failure.
Retrieve/hash/hostverify,terminate/check VM/EBS/bucket/objects/secretfiles.
Commit polite factual report locally; NO PUSH without fresh approval.
