fn source_review()->usize{
 let native="all(zopro_packed_tree,zopro_weighted_native,zopro_resource_schedule,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma))";
 let manifest=read(Path::new(Z).join("docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));let mut exact=0;
 for(rel,sha)in manifest["source_files_sha256"].as_object().unwrap(){let original=fs::read(Path::new(Z).join(rel)).unwrap();assert_eq!(hash(Path::new(Z).join(rel)),sha.as_str().unwrap());let bytes=fs::read(r("source").join(rel)).unwrap();if bytes==original{exact+=1;continue;}
 let mut text=String::from_utf8(bytes).unwrap();
 match rel.as_str(){
 "crates/zopro-core/src/msm.rs"=>{
 for part in["    if let Some(value)=C::Base::try_native_weighted::<C>(buckets){return value;}\n".to_owned(),"\n    fn try_native_weighted<C:CurveConfig<Base=Self>>(_input:&[Affine<C>])->Option<Projective<C>>{None}".to_owned()]{assert_eq!(text.matches(&part).count(),1);text=text.replacen(&part,"",1);}
 let part=format!("\n    #[cfg({native})]\n    fn try_native_weighted<C:CurveConfig<Base=Self>>(input:&[Affine<C>])->Option<Projective<C>>{{weighted_tree::try_weighted::<C>(input)}}");assert_eq!(text.matches(&part).count(),2);text=text.replacen(&part,"",2);
 let suffix=format!("\n#[cfg({native})] mod weighted_tree;\n#[cfg({native})]pub(crate) fn compact_weighted_snapshot()->[[usize;7];2]{{weighted_tree::snapshot()}}\n");assert!(text.ends_with(&suffix));text.truncate(text.len()-suffix.len());
 },
 "crates/zopro-core/src/lib.rs"=>{let suffix=format!("\n#[cfg({native})]#[doc(hidden)]pub fn compact_weighted_snapshot()->[[usize;7];2]{{msm::compact_weighted_snapshot()}}\n");assert!(text.ends_with(&suffix));text.truncate(text.len()-suffix.len());},
 "crates/zopro-core/src/simd.rs"=>{let insert=fs::read_to_string(r("simd-methods.rs")).unwrap();assert_eq!(text.matches(&insert).count(),1);text=text.replacen(&insert,"",1);},
 "crates/zopro-bn254/src/ifma8.rs"=>{let suffix="\n#[cfg(zopro_packed_tree)] #[path=\"ifma8_tree.rs\"] mod tree;\n";assert!(text.ends_with(suffix));text.truncate(text.len()-suffix.len());},
 "scripts/ifma8.py"=>{let insert="source += '\\n#[cfg(zopro_packed_tree)] #[path=\"ifma8_tree.rs\"] mod tree;\\n'\n";assert_eq!(text.matches(insert).count(),1);text=text.replacen(insert,"",1);},
 _=>panic!("Unexpected modified original {rel}"),
 }
 assert_eq!(text.as_bytes(),original,"{rel}");
 }
 assert_eq!(exact,171);
 for file in["ifma8_tree.rs","simd-methods.rs"]{assert_eq!(hash(r(file)),hash(Path::new("/home/ubuntu/src/zopro-perf-work/weighted-tree176").join(file)));}
 let kernel=fs::read_to_string(r("weighted_tree.rs")).unwrap();assert_eq!(fs::read_to_string(r("source/crates/zopro-core/src/msm/weighted_tree.rs")).unwrap(),format!("{kernel}\ninclude!(\"integration.rs\");\n"));
 let restored=kernel.replacen("\n    const CURVE:usize;","",1).replacen("\n    const CURVE:usize=0;","",1).replacen("\n    const CURVE:usize=1;","",1);
 assert_eq!(restored,fs::read_to_string("/home/ubuntu/src/zopro-perf-work/weighted-tree176/weighted_tree.rs").unwrap());
 assert_eq!(hash(r("integration.rs")),hash(r("source/crates/zopro-core/src/msm/integration.rs")));
 let driver=fs::read_to_string(r("driver.rs")).unwrap();let suffix="\nfn main()->Result<(),Box<dyn std::error::Error>>{let result=original_main();println!(\"COMPACT_WEIGHTED {}\",serde_json::json!({\"counts\":zopro_prover::zopro_core::compact_weighted_snapshot()}));result}\n";
 assert!(driver.ends_with(suffix));assert_eq!(driver[..driver.len()-suffix.len()].replacen("fn original_main() -> Result<","fn main() -> Result<",1),fs::read_to_string(Path::new(Z).join("crates/zopro-bench/examples/cpu-sdk.rs")).unwrap());
 exact
}
