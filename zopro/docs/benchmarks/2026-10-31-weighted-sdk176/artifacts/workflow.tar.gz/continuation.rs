use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-sdk176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){let old=read(format!("{R}/plan.json"));let steps=old["steps"].as_array().unwrap();assert_eq!(steps.len(),1043);assert_eq!(steps[60]["name"],"preflight-routes");
let mut pins:BTreeMap<String,String>=serde_json::from_value(read(format!("{R}/pins.json"))).unwrap();for(p,h)in &pins{assert_eq!(hash(p),*h);}
for s in &steps[..60]{let n=s["name"].as_str().unwrap();let e=read(format!("{R}/runs/{n}/exit.json"));assert_eq!(e["success"],true);for stream in["stdout","stderr"]{assert_eq!(hash(format!("{R}/runs/{n}/{stream}.log")),e[format!("{stream}_sha256")]);}}
let failed=read(format!("{R}/runs/preflight-routes/exit.json"));assert_eq!(failed["returncode"],101);assert!(!Path::new(R).join("runs/b0-1x2-w32-accepted").exists());
let mut next=vec![json!({"kind":"command","name":"preflight-routes-v2","argv":[format!("{R}/capture-helper-v2"),"preflight-routes"],"timeout_seconds":600})];next.extend_from_slice(&steps[61..]);assert_eq!(next.len(),983);
for f in["prepare-continuation.rs","prepare-continuation","capture-v2.rs","capture-prepare-v2.rs","capture-helper-v2","review-v2.rs","review-helper-v2","continuation.rs","continuation","continuation-note.md","plan.json","pins.json"]{let p=format!("{R}/{f}");pins.insert(p.clone(),hash(p));}
fs::write(format!("{R}/continuation-pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();fs::write(format!("{R}/continuation-plan.json"),serde_json::to_vec_pretty(&json!({"version":1,"source_pins":format!("{R}/continuation-pins.json"),"steps":next})).unwrap()).unwrap();
println!("Prepared983command continuation;60successful preflight/proofcheck receipts retained;onefailed schema checker preserved;no latency/profile/SDKverifier rerun");}
