// Complete weighted-window integration; arithmetic stays in the qualified child.
use std::{cell::Cell,sync::OnceLock};
thread_local!{static TRACE:Cell<[[usize;7];2]>=const{Cell::new([[0;7];2])};}
fn enabled()->bool{static ON:OnceLock<bool>=OnceLock::new();*ON.get_or_init(||std::env::var("ZOPRO_CPU_COMPACT_WEIGHTED").as_deref()==Ok("1"))}
fn record(curve:usize,n:usize,new:usize,old:usize,entered:Option<bool>){TRACE.with(|cell|{let mut rows=cell.get();let r=&mut rows[curve];match entered{Some(ok)=>{r[0]+=1;r[if ok{1}else{2}]+=1;},None=>r[3]+=1;}r[4]=r[4].max(n);r[5]=r[5].max(new);r[6]=r[6].max(old);cell.set(rows);});}
pub(super) fn snapshot()->[[usize;7];2]{let mut out=TRACE.with(Cell::get);for rows in rayon::broadcast(|_|TRACE.with(Cell::get)){for c in 0..2{for i in 0..4{out[c][i]=out[c][i].saturating_add(rows[c][i]);}for i in 4..7{out[c][i]=out[c][i].max(rows[c][i]);}}}out}

fn forecast<C:CurveConfig>(n:usize)->Option<(usize,usize)>where C::Base:PackedBase{
    use crate::msm_affine::workspace::vector as v;
    if !(16..=256).contains(&n)||!n.is_power_of_two(){return None;}
    let segments=n.ilog2()as usize-2;
    let tail=8usize.checked_mul(segments)?.checked_add(7)?;
    let pairs=4usize.checked_mul(segments)?;
    let requested=v::<Point<C::Base>>(3*n/16,false)?
        .checked_add(v::<[FqBatch;2]>(n/16,false)?)?
        .checked_add(v::<LimbPoint<C::Base>>(tail,false)?)?
        .checked_add(v::<Group<C::Base>>(pairs/8,false)?)?
        .checked_add(v::<usize>(pairs,true)?)?
        .checked_add(core::mem::size_of::<Vec<[FqBatch;2]>>())?;
    let original=super::workspace_weighted::<C>(n)?
        .checked_sub(v::<(Projective<C>,Affine<C>)>(1,false)?)?;
    (requested<=original).then_some((requested,original))
}

enum State<C:CurveConfig>where C::Base:PackedBase {
    Empty,Native(Work<C>),Original(Vec<LimbPoint<C::Base>>,Scratch<C>),
}
impl<C:CurveConfig>Default for State<C>where C::Base:PackedBase {fn default()->Self{Self::Native(Work::default())}}
impl<C:CurveConfig>State<C>where C::Base:PackedBase {
    fn group(&mut self,input:&[Affine<C>],budget:(usize,usize))->(Projective<C>,Affine<C>){
        if !matches!(self,Self::Native(_)){*self=Self::Empty;*self=Self::Native(Work::default());}
        let value=match self{Self::Native(w)=>w.native(input),_=>unreachable!()};
        record(C::Base::CURVE,input.len(),budget.0,budget.1,Some(value.is_some()));
        if let Some(value)=value{return value;}
        // Drop the entire native variant, including its tail and Scratch,
        // before any complete-fallback storage/defaults are constructed.
        *self=Self::Empty;*self=Self::Original(Vec::new(),Scratch::default());
        let Self::Original(tree,scratch)=self else{unreachable!()};
        let n=input.len();tree.resize(2*n-1,LimbPoint::infinity());
        for(out,&point)in tree.iter_mut().zip(input){*out=limbs::<C>(point);}
        let weighted=weighted_sum(tree,n,scratch);(weighted,affine::<C>(tree[0]))
    }
    #[cfg(test)]fn requested(&self)->usize{
        let header=core::mem::size_of::<Vec<u8>>();
        match self{Self::Empty=>0,Self::Native(w)=>w.capacity()+6*header,
        Self::Original(tree,s)=>tree.capacity()*core::mem::size_of::<LimbPoint<C::Base>>()
            +s.pairs.capacity()*core::mem::size_of::<usize>()
            +s.groups.capacity()*core::mem::size_of::<Group<C::Base>>()
            +s.prefix_records.capacity()*core::mem::size_of::<[FqBatch;2]>()+4*header}
    }
}

pub(super) fn try_weighted<C:CurveConfig>(input:&[Affine<C>])->Option<Projective<C>>where C::Base:PackedBase{
    if !enabled(){return None;}
    attempt::<C>(input)
}
fn attempt<C:CurveConfig>(input:&[Affine<C>])->Option<Projective<C>>where C::Base:PackedBase{
    let group=input.len().min(256);
    let Some(budget)=forecast::<C>(group)else{record(C::Base::CURVE,group,0,0,None);return None;};
    let tail=input.len()%256;
    if tail!=0&&forecast::<C>(tail).is_none(){record(C::Base::CURVE,tail,0,0,None);return None;}
    let partials:Vec<_>=input.par_chunks(256).map_init(State::<C>::default,|state,chunk|state.group(chunk,budget)).collect();
    let mut sum=Projective::<C>::IDENTITY;
    let mut offset=Projective::<C>::IDENTITY;
    let mut running=Projective::<C>::IDENTITY;
    for(weighted,total)in partials.into_iter().rev(){sum+=weighted;offset+=running;running+=total;}
    for _ in 0..256usize.ilog2(){offset=offset.double();}
    Some(sum+offset)
}

#[cfg(test)]mod integration_tests{
    use super::*;
    fn check<C:CurveConfig>()where C::Base:PackedBase{
        for n in 0..=257{let f=forecast::<C>(n);if let Some((new,old))=f{assert!(new<=old);assert!(n>=16&&n<=256&&n.is_power_of_two());}}
        for n in[0,1,8,15,17,31,63,257,usize::MAX]{assert!(forecast::<C>(n).is_none());}
        let mut rng=crate::testing::Seeded::new(0x7765696768747364);let g=Projective::<C>::generator();
        let weights=(0..1024).map(|_|rng.fr()).collect::<Vec<_>>();
        let points=Projective::<C>::batch_to_affine(&weights.iter().map(|s|g**s).collect::<Vec<_>>());
        for n in[64usize,128,256,512,640,1024]{let expected=weights[..n].iter().enumerate().fold(Fr::ZERO,|s,(i,w)|s+*w*Fr::from(i as u64+1));assert_eq!(attempt::<C>(&points[..n]).unwrap().to_affine(),(g*expected).to_affine());}
        let budget=forecast::<C>(256).unwrap();let mut state=State::<C>::default();
        for n in[64usize,128,256,64,256,128]{
            let expected=points[..n].iter().enumerate().fold(Projective::<C>::IDENTITY,|s,(i,p)|s+*p*Fr::from(i as u64+1)).to_affine();
            assert_eq!(state.group(&points[..n],budget).0.to_affine(),expected);assert!(state.requested()<=budget.1);
        }
        let mut edge=points[..256].to_vec();edge[0]=Affine::IDENTITY;
        let expected=edge.iter().enumerate().fold(Projective::<C>::IDENTITY,|s,(i,p)|s+*p*Fr::from(i as u64+1)).to_affine();
        assert_eq!(state.group(&edge,budget).0.to_affine(),expected);assert!(matches!(state,State::Original(_, _)));assert!(state.requested()<=budget.1);
        // Equal second-level sums force rejection only after a native level.
        let mut late=points[..256].to_vec();for(i,s)in[3i64,5,11,-19].into_iter().enumerate(){late[i]=(g*if s<0{-Fr::from((-s)as u64)}else{Fr::from(s as u64)}).to_affine();}
        let expected=late.iter().enumerate().fold(Projective::<C>::IDENTITY,|s,(i,p)|s+*p*Fr::from(i as u64+1)).to_affine();
        assert_eq!(state.group(&late,budget).0.to_affine(),expected);assert!(matches!(state,State::Original(_, _)));assert!(state.requested()<=budget.1);
        let expected=points[..256].iter().enumerate().fold(Projective::<C>::IDENTITY,|s,(i,p)|s+*p*Fr::from(i as u64+1)).to_affine();
        assert_eq!(state.group(&points[..256],budget).0.to_affine(),expected);assert!(matches!(state,State::Native(_)));assert!(state.requested()<=budget.1);
        assert_eq!(points,Projective::<C>::batch_to_affine(&weights.iter().map(|s|g**s).collect::<Vec<_>>()));
    }
    #[test]fn g1_geometry_full_weighted_and_fallback_release(){check::<G1Config>();}
    #[test]fn g2_geometry_full_weighted_and_fallback_release(){check::<G2Config>();}
}
