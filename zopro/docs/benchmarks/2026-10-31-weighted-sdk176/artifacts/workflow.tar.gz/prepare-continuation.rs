use std::fs;
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-sdk176";
fn one(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1);}
fn resolver()->String{r#"fn r(p: impl AsRef<Path>) -> PathBuf {
    let p=p.as_ref();
    if let Ok(rest)=p.strip_prefix("runs") {
        let first=rest.iter().next().and_then(|s|s.to_str()).unwrap_or("");
        let initial=first.starts_with("preflight-")||first.starts_with("verify-preflight-");
        return Path::new(R).join(if initial{"runs"}else{"runs-continuation"}).join(rest);
    }
    Path::new(R).join(p)
}"#.into()}
fn main(){assert!(!std::path::Path::new(R).join("continuation-plan.json").exists());
 let mut c=fs::read_to_string(format!("{R}/capture.rs")).unwrap();
 one(&mut c,"fn r(p: impl AsRef<Path>) -> PathBuf {\n    Path::new(R).join(p)\n}",&resolver());
 one(&mut c,"include!(\"capture-prepare.rs\");","include!(\"capture-prepare-v2.rs\");");
 fs::write(format!("{R}/capture-v2.rs"),c).unwrap();
 let old=fs::read_to_string(format!("{R}/capture-prepare.rs")).unwrap();let start=old.find("fn prepare(){").unwrap();
 let fixed=fs::read_to_string(format!("{R}/routes.rs")).unwrap()+&old[start..];
 fs::write(format!("{R}/capture-prepare-v2.rs"),fixed).unwrap();
 let mut review=fs::read_to_string(format!("{R}/review.rs")).unwrap();
 one(&mut review,"fn r(p:impl AsRef<Path>)->PathBuf{Path::new(R).join(p)}",&resolver());
 one(&mut review,"for f in[\"build-pins.json\",\"link-pins.json\",\"pins.json\"]","for f in[\"build-pins.json\",\"link-pins.json\",\"pins.json\",\"continuation-pins.json\"]");
 let start=review.find(" let mut commands=0;").unwrap();let end=review.find(" let a=read(r(\"analysis.json\"))").unwrap();
 review.replace_range(start..end,r#" let mut commands=0;
 for(plan,output,limit)in[("build-plan.json","native",usize::MAX),("link-plan.json","links",usize::MAX),("plan.json","runs",61),("continuation-plan.json","runs-continuation",usize::MAX)] {
    let p=read(Path::new(R).join(plan));let steps=p["steps"].as_array().unwrap();
    for(index,s)in steps.iter().take(limit).enumerate(){
        let name=s["name"].as_str().unwrap();let base=Path::new(R).join(output).join(name);
        let failed=plan=="plan.json"&&index==60;
        let exit=read(base.join("exit.json"));assert_eq!(exit["success"],!failed);assert_eq!(exit["returncode"],if failed{101}else{0});
        for stream in["stdout","stderr"]{assert_eq!(hash(base.join(format!("{stream}.log"))),exit[format!("{stream}_sha256")]);}
        let command=read(base.join("command.json"));
        if s["kind"]=="command"{assert_eq!(command["argv"].as_array().unwrap()[4..],s["argv"].as_array().unwrap()[..]);}
        else{assert_eq!(s["kind"],"link-sdk");for flag in["-O","target-cpu=native","lto=fat","codegen-units=1"]{assert!(command["argv"].as_array().unwrap().iter().any(|v|v==flag));}let artifact=read(base.join("artifacts.json"));assert_eq!(hash(artifact["binary"].as_str().unwrap()),artifact["binary_sha256"]);}
        commands+=1;
    }
 }
 assert_eq!(commands,1049);
"#);
 fs::write(format!("{R}/review-v2.rs"),review).unwrap();
 println!("Prepared read-only seven-field checker and split-receipt analysis/review;old source/helper/plan/pins stay immutable");
}
