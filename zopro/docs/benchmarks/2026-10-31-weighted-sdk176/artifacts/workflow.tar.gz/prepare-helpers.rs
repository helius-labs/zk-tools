use std::fs;
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-sdk176";const PREV:&str="/home/ubuntu/src/zopro-perf-work/compact-sdk176";
fn one(s:&mut String,a:&str,b:&str){assert_eq!(s.matches(a).count(),1,"{a}");*s=s.replacen(a,b,1);}
fn main(){for name in["native.rs","build.rs","link.rs","capture.rs","capture-prepare.rs","analysis.rs","sampling.rs","counter.rs","metadata.rs","audit.rs","memory-sdk.rs","review.rs"]{
let mut s=fs::read_to_string(format!("{PREV}/{name}")).unwrap().replace(PREV,R).replace("ZOPRO_CPU_COMPACT_INDEXED_TREE","ZOPRO_CPU_COMPACT_WEIGHTED").replace("COMPACT_INDEXED","COMPACT_WEIGHTED").replace("packed_tree.rs","weighted_tree.rs");
if name=="build.rs"{s=s.replace("131 passed","130 passed").replace("Qualifiedcore131","Qualifiedcore130");}
if name=="capture.rs"{one(&mut s,"                151\n","                if c[\"workers\"]==16 {301} else {151}\n");}
if name=="capture-prepare.rs"{s=s.replace("131 passed","130 passed");one(&mut s,"/home/ubuntu/src/zopro-perf-work/postgroup-phi176/proof-sha256-after.json","/home/ubuntu/src/zopro-perf-work/compact-sdk176/proof-sha256-after.json");s=s.replace("len(),27851","len(),28349");s=s.replace("sum::<u64>(),27912","sum::<u64>(),34662").replace("27912primary","34662primary");}
if name=="analysis.rs"{s=s.replace("prior.len(), 27851","prior.len(), 28349").replace("\"SDK_requests\":27912","\"SDK_requests\":34662").replace("\"total_SDK_requests\":27912+","\"total_SDK_requests\":34662+").replace("\"prior_proof_count\":27851","\"prior_proof_count\":28349").replace("\"independent_proof_count\":28349","\"independent_proof_count\":28847").replace("\"native_core_tests\":131","\"native_core_tests\":130");}
if name=="review.rs"{s=s.replace("131 passed","130 passed").replace("ledger.len(),27851","ledger.len(),28349").replace("\"direct_core_tests\":131","\"direct_core_tests\":130").replace("\"ledger\":28349","\"ledger\":28847").replace("/ledger28349/","/ledger28847/");}
fs::write(format!("{R}/{name}"),s).unwrap();}
println!("Adapted SDK workflows;130core,151primary32/301primary16,34662primaryrequests,prior28349/new498exports");}
