fn route_check(j:&Value,log:&str){
 let rows=log.lines().filter_map(|l|l.strip_prefix("COMPACT_WEIGHTED ")).collect::<Vec<_>>();if j["variant"]=="accepted"{assert!(rows.is_empty());return;}assert_eq!(rows.len(),1);let x:Value=serde_json::from_str(rows[0]).unwrap();let curves=x["counts"].as_array().unwrap();assert_eq!(curves.len(),2);
 for c in curves{let a=c.as_array().unwrap();assert_eq!(a.len(),7);let v=a.iter().map(|x|x.as_u64().unwrap()).collect::<Vec<_>>();if j["variant"]=="OFF"{assert!(v.iter().all(|&n|n==0));}else{assert_eq!(v[0],v[1]+v[2]);if v[0]>0{assert!((64..=256).contains(&v[4]));assert!(v[5]>0&&v[5]<=v[6]);}if v[0]==0&&v[3]==0{assert!(v.iter().all(|&n|n==0));}}}
 if j["variant"]=="ON"&&j["case"]["shape"]=="1x2"{assert!(curves.iter().all(|c|c[1].as_u64().unwrap()>0));}
}
