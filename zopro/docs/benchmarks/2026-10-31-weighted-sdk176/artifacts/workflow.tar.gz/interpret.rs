use serde_json::{json, Value};
use std::{collections::BTreeMap, fs};
const R: &str = "/home/ubuntu/src/zopro-perf-work/weighted-sdk176";
fn read(p: &str) -> Value { serde_json::from_slice(&fs::read(format!("{R}/{p}")).unwrap()).unwrap() }
fn median(mut v: Vec<f64>) -> f64 { v.sort_by(f64::total_cmp); v[v.len()/2] }
fn main() {
    let a=read("analysis.json"); let profiles=read("profile-symbols.json"); let cases=read("cases.json");
    assert_eq!(read("review.json")["passed"],true);
    let mut profile_rows=BTreeMap::new();
    for (name,rows) in profiles.as_object().unwrap() {
        let mut total=0u64; let mut native=0u64; let mut inverses=0u64;
        for row in rows.as_array().unwrap() {
            let n=row["samples"].as_u64().unwrap(); let s=row["symbol"].as_str().unwrap(); total+=n;
            assert_eq!(row["period"].as_u64().unwrap(),n*16_000_000);
            if s.contains("msm::weighted_tree::") {native+=n;}
            if s.contains("zopro_bn254::inverse::inverse") {inverses+=n;}
        }
        assert_eq!(a["profiles"][name]["samples"],total);
        profile_rows.insert(name,json!({"samples":total,"weighted_tree_named_context_samples":native,"weighted_tree_named_context_share":native as f64/total as f64,"general_field_inverse_named_samples":inverses,"general_field_inverse_named_share":inverses as f64/total as f64}));
    }
    let mut usage=BTreeMap::new();
    for c in cases.as_array().unwrap() {
        let name=c["name"].as_str().unwrap(); let mut arms=BTreeMap::new();
        for arm in ["accepted","OFF","ON"] {
            let mut cols:BTreeMap<&str,Vec<f64>>=BTreeMap::new();
            for b in 0..15 {
                let log=fs::read_to_string(format!("{R}/runs-continuation/b{b}-{name}-{arm}/stdout.log")).unwrap();
                let row:Value=serde_json::from_str(log.lines().find_map(|l|l.strip_prefix("SUMMARY ")).unwrap()).unwrap();
                let n=row["rounds"].as_f64().unwrap();
                for k in ["minor_faults","voluntary_switches","involuntary_switches","system_cpu_ms"] {cols.entry(k).or_default().push(row[k].as_f64().unwrap()/n);}
                cols.entry("CPU_ms_divided_by_loop_wall_ms").or_default().push((row["user_cpu_ms"].as_f64().unwrap()+row["system_cpu_ms"].as_f64().unwrap())/row["loop_wall_ms"].as_f64().unwrap());
            }
            arms.insert(arm,cols.into_iter().map(|(k,v)|(k,median(v))).collect::<BTreeMap<_,_>>());
        }
        usage.insert(name,arms);
    }
    let mut ratios=BTreeMap::new();
    for c in ["1x2-w32","4x2-w32","merge-24x1-w32"] {
        let mut r=BTreeMap::new();for e in ["cycles:u","instructions:u","cache-misses:u","branch-misses:u"] {
            r.insert(e,a["counters"][format!("stat-{c}-ON")]["per_request"][e].as_f64().unwrap()/a["counters"][format!("stat-{c}-OFF")]["per_request"][e].as_f64().unwrap());
        }ratios.insert(c,r);
    }
    let v=json!({"passed":true,"profiles":profile_rows,"latency_usage_medians":usage,"descriptive_counter_ON_OFF_ratios":ratios,"profile_matching_rule":"literal msm::weighted_tree:: substring, including symbols naming inlined or enclosing Rayon work; inverse samples separate and may be shared by many callers","usage_intervals":"rusage differences only around timed request loop; process peak counter excluded here","CPU_wall_ratio_is_logical_thread_equivalents_not_physical_utilization":true,"faults_and_switches_are_counts_not_measured_latency_cost_or_causal_attribution":true,"minor_faults_do_not_count_disk_pageins":true,"major_faults_not_exported_by_existing_SDK_driver":true,"no_new_workload_or_verifier_execution":true});
    fs::write(format!("{R}/interpretation.json"),serde_json::to_vec_pretty(&v).unwrap()).unwrap();
    println!("Interpretation PASS: all9profile sample/period sums and450timed rusage summaries reviewed; no workload rerun");
}
