#![allow(dead_code)]
use num_bigint::BigUint;use sha2::{Digest,Sha256};use std::{fs,hint::black_box,time::Instant};use zopro_bn254::{Fp,FpConfig,Fq,FqConfig,Fr,FrConfig};
#[path="/home/ubuntu/src/zopro-perf-work/euclid-pair-sdk176/support/perf.rs"]mod perf;
fn big(w:&[u64])->BigUint{BigUint::from_bytes_le(&w.iter().flat_map(|w|w.to_le_bytes()).collect::<Vec<_>>())}
fn words(x:&BigUint)->[u64;4]{let v=x.to_u64_digits();assert!(v.len()<=4);let mut w=[0;4];w[..v.len()].copy_from_slice(&v);w}
fn rng(s:&mut u64)->u64{*s=s.wrapping_add(0x9e3779b97f4a7c15);let mut z=*s;z=(z^(z>>30)).wrapping_mul(0xbf58476d1ce4e5b9);z=(z^(z>>27)).wrapping_mul(0x94d049bb133111eb);z^(z>>31)}
fn inputs<C:FpConfig>(n:usize)->Vec<Fp<C>>{let p=big(&C::P);let mut values=vec![Fp::ONE,Fp::from_montgomery([1,0,0,0]),Fp::from_montgomery(words(&(&p-1u8)))];let mut seed=0xd9817b5704a3e62c;while values.len()<n{let w:[u64;4]=std::array::from_fn(|_|rng(&mut seed));let x=big(&w)%&p;if x!=BigUint::from(0u8){values.push(Fp::from_montgomery(words(&x)));}}values}
#[no_mangle]#[inline(never)]pub fn complete_fq_inverse(x:&Fq)->Fq{x.inverse().unwrap()}
#[no_mangle]#[inline(never)]pub fn complete_fr_inverse(x:&Fr)->Fr{x.inverse().unwrap()}

fn bench<C:FpConfig>(field:&str,op:fn(&Fp<C>)->Fp<C>,passes:usize){let values=inputs::<C>(4096);for _ in 0..3{for x in &values[..256]{black_box(op(black_box(x)));}}let mut gate=perf::Control::from_env().unwrap().unwrap();gate.enable().unwrap();let before=perf::Usage::now().unwrap();let mut sum=[0u64;4];let mut last=Fp::<C>::ZERO;let now=Instant::now();for _ in 0..passes{for x in &values{let out=black_box(op(black_box(x)));for j in 0..4{sum[j]=sum[j].wrapping_add(out.0[j]);}last=out;}}let elapsed=now.elapsed().as_nanos();let after=perf::Usage::now().unwrap();gate.disable().unwrap();println!("DIAGNOSTIC_INVERSE {}",serde_json::json!({"field":field,"passes":passes,"operations":passes*4096,"elapsed_ns":elapsed.to_string(),"checksum":sum,"last":last.0,"usage":after.difference(&before)}));}
fn main(){let a=std::env::args().collect::<Vec<_>>();let passes=a[2].parse().unwrap();match a[1].as_str(){"Fq"=>bench("Fq",complete_fq_inverse,passes),"Fr"=>bench("Fr",complete_fr_inverse,passes),_=>panic!("field")}}
