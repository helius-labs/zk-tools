# Continue after the weighted double-add SDK experiment

Goal ACTIVE/UNMET 0/8: verified CPU AVX single-proof at least 10x supplied M5
CPU for EACH of ALL8 shapes, reporting CPU and Metal. No token budget.
User authorizes autonomous research without questions, commit AND push each
finished experiment; polite factual reports. No subagents, Python/C/ASM rewrite,
giant lookup tables, expanded per-key plans, new production pool or artificial
architectural RAM cap.

Current root /home/ubuntu/src/zopro-perf-work/weighted-double-sdk176 (R).
Qualification /home/ubuntu/src/zopro-perf-work/weighted-double-current176 (Q).
Report zopro/docs/benchmarks/2026-11-10-weighted-double-sdk176/README.md.
Read checkpoint.json for actual publication commit/remote verification. Do not
assume publication finished before inspecting its actual result.

PROGRESS: recovered an old qualified but UNTImED weighted double-add reducer,
ported to current176 including accepted dense_busy_reset, passed130 native
core tests and13 native/link commands, then measured whole SDK ALL8+54 and
primary1/16/32. Capture50474 terminal0, all1329 commands succeeded once. Frozen
analysis and separate raw reader produced passing reviews. Original analysis
session84082 was no longer live when subsequently polled; authoritative stdout
and JSON artifacts show successful completion. Review session handle was lost
to tool-output truncation, not evidence of failure. No processes remain live.
Never restart captures, successful suites or proof verifications for bookkeeping.

RESULT67/79. Candidate NOT adopted, production unchanged. Primary32 accepted
REF7.843523377483443 ms / OFF7.848310754966888 / ON7.824952185430464.
ON/OFF1.000060870378942 CI[0.993927410540003,1.008862052593396],18/31 wins;
ON/REF1.002458192883059 CI[0.996015370896020,1.011527253659525],20/31 wins.
Neither establishes a gain. ALL8 ON/OFF1.006866664975565
CI[1.003161021263162,1.010860232104253]; ON/REF1.007209542745188
CI[1.002842750466447,1.011659844664659]. Descriptively slower aggregates,
but4x2 OFF/REF calibration fails (upper1.032599>1.03), so controls are not
fully qualified. Do not present this as a clean universal slowdown estimate.
Other failures: solo ON/control nonregression (upper~1.032),4x2 ON/REF,
8x2 ON/both nonregression, four primary gain/win checks and both ALL8 gains.
All22 RSS and18 diagnostic quality gates pass. No blocks excluded or added,
no favorable subset selected. Exact recipe CLOSED; no unchanged recapture.

Primary ON134MiB peak vs REF132.5/OFF134.5; merge54 ON163.150466ms,
1951.351563MiB vs REF163.098343ms,1905.277344MiB. RSS lifetime includes
load/primes, not minimum RAM or stack bound. Zero timed-batch major faults.
Single PMU panels show ~0.5-0.6% fewer instructions/~1-2% fewer cycles against
OFF; this is NOT replicated attribution or confirmed latency gain. All9 profiles
119150samples pass quality; weighted_double symbols sampled only in ON:
61(primary16),67(primary32),73(2x2-32). Counts include inlining/flat namespace
and are not exclusive critical-path or removable time. Do not recapture to
obtain an attractive profile.

Candidate G1 only >=2048buckets/resource-admitted. One511slot tree plus old
scratch reused per outer job; up to8x256 groups sequentially;9 roots/group,
8 batched double-add steps; both weighted and unweighted partials preserved.
6176logical extra bytes/G1leaf charged through existing forecast, not emitted
stack/RSS bound. G2/short/disabled generic original. No large key table/plan.
All3 arithmetic/kernel/test children byte-exact old weighted-double-consumer176;
4msm edits+2suffixes integrated reversibly into CURRENT176. Native130tests,
175 inherited input cases, independent Arkworks weighted+sum oracles, actual53
workers across1/4/16/32/requested512KiB stacks,12 calls sharing8workerpool.
Portable-disabled compile only, no ARM/phone execution.13commands all firstpass.
Current qualification receipts/source audit included in new evidence archive.

Canonical NOW48721 at R/proof-sha256-after-capture.json. This stage642new
unique164byte Gnark exports (33preflight+609capture),44238 SDK requests with
primes;48079->48112->48721 checked bindings/freshness. Seed every subsequent
SDK export from48721, NOT48079/47437/older. Exact SHA in decision/checkpoint.
Capture1329commands=66preflightSDK+Gnark +591latency+18diagnostics+45offline
+609captureGnark. All recording finished before offline analysis. No owned
helpers/build/hash/report overlapped preflight/recording. Both actual readers,
396pins/schedule/gates/input order fixed before first request.114 predetermined
independent whole-ELF backings retained, no post-hoc selection. Preparation:
first adapt.rs compile E0369 &str+String fixed before execution (original saved);
no SDK, protocol or math changed in repair. No successful work repeated.

Accepted production176 source manifest:
zopro/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json
Actual accepted local SDK /home/ubuntu/src/zopro-perf-work/busy-reset-sdk176/sdk-ON
SHA7aff5f602a1e250a6b9b28889bf6278b51ec400af8399c7481c36248a8718d01.
Original field1200 from g2-vector-sign-default175/frozen/candidate remains exact;
new field metadata needs coherent relink of all consumers if changed later.
Native cfgs including dense_busy_reset must all be retained.

AWS latest accepted report2026-11-10-accepted-current-c7a176: 1x2 best Zopro
11.243892ms32workers/122.52MiB vs Aeglos7.902802ms96/479.98MiB;
Aeglos32=11.870012ms.54 bestZ120.757128ms64/2003.02MiB vsA171.908504ms96/
13102.11MiB. No new AWS in current experiment, no Aeglos measurement. Previous
sole c7a i-0a15ad9ae313aa976 terminated/cleanupverified. No new cloud resources.
No mobile/TEE/250/4999/minRAM/swap/pressure/concurrent-throughput claims.

NEXT: choose DISTINCT material reduction in useful prover work after checking
history/source/profile, not syntax/compiler/layout/RAMcap/worker rescue of this
recipe. A lower point-product count alone has now failed to establish full-proof
speed; account for batch boundaries, fanout, roots/inversions and task supply.
Existing profile already identifies G1 streaming, G2 borrowed stream, inversion,
weighted reduction and inlined runtime payload. Do not label epoch samples idle.
Old consumer-work-audit176/fieldcensus/GLV/pointmodel/reduction studies already
exist. Consult previous simd-booth-sdk176/next.md and linked history BEFORE
selecting a new candidate; a generic new profile is not itself a breakthrough.

Prior SIMD Booth fullSDK3679c82b1e rejected73/79, ALLcontrolsqualified:
primaryON7.898484 vsREF7.811658/OFF7.817748; ON/OFF+1.45%,1/31wins.
Other closed: G1GLVKHfullSDKOct29+4.27%; taggedphiNov6extrabetaMproxy+4.96%;
wideGCD62Nov10G1query+5.32%; weightedliveprefixNov9cal/nonregfail; standard
jointchain2017/311+2020/503>10.9xaddbound; BosCosterOct25negative; polarEuler
jointrootpruningNov10noactualpairedsite reduction. Do not rename/retry these.
Revised ePrint2024/038 abstract lastupdated2026-02-09: firstmethod3^d-1table,
24% on tripling curves; secondlarge-d11.34% vs its comparator. Full currentPDF
403; complete revised recurrence NOT read; do not import earlier50% abstract or
transfer paper factor to BN254. No need to retry blocked sameURL endlessly.

Rust1.98.1 explicit, serialized retained xtask. Both readers and meaningful
qualification/protocol/gates frozen BEFORE any SDK preflight. During live
preflight/recording only poll exact returned exec session through terminal;
timeout/truncation is NOT terminal. Finish all recordings before offline
hash/decode/analyze/report/push. All proof verification mandatory, no hot-loop
concurrent analysis. No replay of old successful native/crypto for bookkeeping.
Use Rust/xtask; no new Python. Do not stage hundreds of old untracked reportdirs.
Commit AND push each finished experiment, verify exact remote HEAD, update
checkpoint and /home/ubuntu/src/zopro-cpu-perf-handoff.md. Never mark goal
complete merely because a report/benchmark finished or budget/time is low.
