use serde_json::{json,Value};use sha2::{Digest,Sha256};
use std::{fs,path::{Path,PathBuf},io::{Read,BufRead,BufReader},process::{Command,Stdio},collections::{BTreeMap,BTreeSet}};
const R:&str="/home/ubuntu/src/zopro-perf-work/weighted-double-sdk176";
const Q:&str="/home/ubuntu/src/zopro-perf-work/weighted-double-current176";
const PRIOR:&str="/home/ubuntu/src/zopro-perf-work/simd-booth-sdk176/proof-sha256-after-capture.json";
const REF:&str="/home/ubuntu/src/zopro-perf-work/busy-reset-sdk176/sdk-ON";
const VERIFY:&str="/home/ubuntu/src/zopro-perf-work/batch-local-steal/gnark/verify";
const LEDGER:&str="/home/ubuntu/src/zopro-perf-work/weighted-double-sdk176/proof-sha256-after-preflight.json";
const ARMS:[&str;3]=["REF","OFF","ON"];
fn r(p:impl AsRef<Path>)->PathBuf{Path::new(R).join(p)}
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:impl AsRef<Path>)->String{let mut f=fs::File::open(p).unwrap();let mut h=Sha256::new();let mut b=[0;65536];loop{let n=f.read(&mut b).unwrap();if n==0{break}h.update(&b[..n]);}format!("{:x}",h.finalize())}
fn save(p:impl AsRef<Path>,v:&Value){assert!(!p.as_ref().exists(),"{}",p.as_ref().display());fs::write(p,serde_json::to_vec_pretty(v).unwrap()).unwrap()}
fn step(name:&str,argv:Vec<String>,env:Value)->Value{json!({"kind":"command","name":name,"argv":argv,"environment":env,"timeout_seconds":1800})}
fn blocks(c:&Value)->usize{if c["shape"]=="1x2"&&c["workers"]!=1{31}else{15}}
fn receipt(folder:&str,s:&Value){
 let base=r(format!("{folder}/{}",s["name"].as_str().unwrap()));let exit=read(base.join("exit.json"));assert_eq!(exit["returncode"],0);assert_eq!(exit["success"],true);for stream in["stdout","stderr"]{assert_eq!(hash(base.join(format!("{stream}.log"))),exit[format!("{stream}_sha256")]);}let cmd=read(base.join("command.json"));assert_eq!(&cmd["argv"].as_array().unwrap()[4..],s["argv"].as_array().unwrap());for(k,v)in s["environment"].as_object().into_iter().flatten(){assert_eq!(cmd["environment"][k],*v);}
}
fn check_backings(){
 use std::os::unix::fs::{MetadataExt,PermissionsExt};let copies=read(r("copies.json"));assert_eq!(copies.as_array().unwrap().len(),114);let mut seen=BTreeSet::new();
 for c in copies.as_array().unwrap(){let p=c["path"].as_str().unwrap();let m=fs::metadata(p).unwrap();assert_eq!(hash(p),c["sha256"]);assert_eq!(m.dev(),c["dev"]);assert_eq!(m.ino(),c["ino"]);assert_eq!(m.len(),c["bytes"]);assert_eq!(m.permissions().mode(),c["mode"]);assert_eq!(m.nlink(),1);assert!(seen.insert((m.dev(),m.ino())));let src=c["source"].as_str().unwrap();assert_eq!(hash(src),c["sha256"]);let src=fs::metadata(src).unwrap();assert_ne!((m.dev(),m.ino()),(src.dev(),src.ino()));}
}

include!("source_provenance.rs");
