# Current-source integration of the qualified weighted double-add consumer

Prior goal turn measured/rejected SIMD Booth; canonical48079 remains current.
History finds an implemented, qualified, unmeasured complete G1 weighted reducer
(weighted-double-consumer176) rather than a new untested digit micro-optimization.
Its exact final tail-initialization body/kernel/tests are reused unchanged.
No prior failed timing is reopened. G1 GLV, GCD, weighted-prefix/digit-matrix and
general differential ladder negatives remain closed; a revised2024/038 paper
abstract was readable but its fullPDF inaccessible, no method/speed imported.

Port the recorded4msm edits+2parent suffixes+3children onto the EXACT CURRENT176
source. Both fresh cores retain ALL accepted cfgs including dense busy reset,
which was absent from the old qualified library. The new coherent integration
therefore requires its own current core test build/run, not a replay of the old
standalone arithmetic experiment. Reuse field1200 and independent old tests.
Full native core suite checks interactions; portable-disabled compile only.

Kernel uses the repeated-input2P+Q identity for weighted folds, gathering at most
eight groups of nine roots and reusing ONE511-slot tree/scratch per job. Both
weighted and unweighted outputs feed original offset corrections. G1only,
>=2048buckets with existingresourcepolicy; all other paths original. Extra6176
logical bytes perleaf charged in old forecast; no keyplan/table/pool/heap digit
matrix/artificialRAMcap. Source accounting is not RSS/minRAM/stack proof.

Isolated one-entry parallel timings could misrepresent proof-level task supply:
eight groups are processed per job, while actual proof has sibling windows and
queries. Plan coherent WHOLE-SDK ALL8+54 and primary1/16/32 comparison after this
new integration qualifies, not an isolated-only speed claim. Charge all root
reductions,packing,twoinversions,guards,offsets,allocation/drop and scheduling.
The method may lose; no2× forecast from operation count or old qualification.

Before any SDK preflight freeze bothrawreaders,79gates,actualsource/inputs/order,
automaticprofiles and predetermined backing copies. Reuse last qualified full
SDK protocol with new candidate bindings and48079canonical seed. No timing here.
Every export fresh and independently Gnark verified. WholeSDK resources and
portable/concurrent/admission compatibility needed before adoption. Keep full
CPUAVX>=10×M5CPU ALL8 goal active until each target actually verified, reporting
CPU+Metal. CommitANDpush completed experiments; no questions/subagents/Python.
