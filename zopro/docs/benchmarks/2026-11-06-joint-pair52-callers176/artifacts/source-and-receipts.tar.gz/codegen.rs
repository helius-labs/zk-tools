use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, path::Path, process::Command};
const R: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-callers176";
const N: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-native176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn main() {
    assert_eq!(read(format!("{R}/build/result.json"))["status"], "complete");
    assert!(!Path::new(R).join("codegen.json").exists());
    let mut pins = read(format!("{R}/build-pins.json"))
        .as_object()
        .unwrap()
        .clone();
    for (p, h) in &pins {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let reference = read(format!("{R}/frozen-reference.json"));
    for p in[format!("{R}/codegen.rs"),format!("{R}/codegen"),format!("{R}/source-audit.json"),format!("{R}/frozen-reference.json"),format!("{R}/provenance-note.md"),"/usr/bin/nm".into(),"/usr/bin/objdump".into(),
 "/home/ubuntu/src/zopro-perf-work/tool-target/release/deps/librustc_demangle-3e2a96f78b3a16e4.rlib".into(),"/home/ubuntu/src/zopro-perf-work/word-export176/caller-reference.json".into(),
 "/home/ubuntu/src/zopro-perf-work/high-borrow176/target-control/release/deps/libzopro_bn254-cc6caf9cf6e53c00.rlib".into(),"/home/ubuntu/src/zopro-perf-work/high-borrow176/target-control/release/.fingerprint/zopro-core-ace55e1811755a58/lib-zopro_core.json".into()]{pins.insert(p.clone(),json!(hash(p)));}
    let mut identities = Vec::new();
    for role in ["OFF", "ON"] {
        let core = format!("{R}/libs/{role}/libzopro_core.rlib");
        let binary = format!("{R}/caller-{role}");
        pins.insert(core.clone(), json!(hash(&core)));
        pins.insert(binary.clone(), json!(hash(&binary)));
        let core_command = read(format!("{R}/build/core-{role}/command.json"));
        let args = core_command["argv"].as_array().unwrap();
        assert!(args.contains(&json!(format!(
            "zopro_bn254={N}/field/{role}/libzopro_bn254.rlib"
        ))));
        assert_eq!(
            args.contains(&json!("zopro_joint_pair52_complex")),
            role == "ON"
        );
        let command = read(format!("{R}/build/driver-{role}/command.json"));
        let args = command["argv"].as_array().unwrap();
        assert!(args.contains(&json!(format!("zopro_core={core}"))));
        for f in ["-O", "target-cpu=native", "lto=fat", "codegen-units=1"] {
            assert!(args.contains(&json!(f)));
        }
        assert_eq!(
            args.contains(&json!("zopro_joint_pair52_complex")),
            role == "ON"
        );
        identities.push(json!({"role":role,"binary":binary,"sha256":hash(&binary),"core":core,"core_sha256":hash(&core),"field":format!("{N}/field/{role}/libzopro_bn254.rlib"),"field_sha256":hash(format!("{N}/field/{role}/libzopro_bn254.rlib")),"actual_driver_argv":args}));
    }
    identities.push(json!({"role":"FROZEN","binary":reference["binary"],"sha256":reference["binary_sha256"],"scope":"accepted-source frozen reference, not productionSDK/field1200 binary identity","recorded_field_input_sha256":hash("/home/ubuntu/src/zopro-perf-work/high-borrow176/target-control/release/deps/libzopro_bn254-cc6caf9cf6e53c00.rlib")}));
    fs::write(
        format!("{R}/codegen-pins.json"),
        serde_json::to_vec_pretty(&pins).unwrap(),
    )
    .unwrap();
    fs::create_dir(format!("{R}/disassembly")).unwrap();
    let mut rows = Vec::new();
    for identity in &identities {
        let role = identity["role"].as_str().unwrap();
        let binary = identity["binary"].as_str().unwrap();
        assert_eq!(hash(binary), identity["sha256"]);
        let nm = Command::new("/usr/bin/nm")
            .args(["-S", "--defined-only", binary])
            .output()
            .unwrap();
        assert!(nm.status.success());
        let text = String::from_utf8(nm.stdout).unwrap();
        fs::write(format!("{R}/disassembly/{role}-symbols.txt"), &text).unwrap();
        let symbols: Vec<_> = text
            .lines()
            .filter_map(|l| {
                let f: Vec<_> = l.split_whitespace().collect();
                if f.len() != 4 {
                    return None;
                }
                let start = u64::from_str_radix(f[0], 16).ok()?;
                let size = u64::from_str_radix(f[1], 16).ok()?;
                let name = rustc_demangle::try_demangle(f[3]).ok()?.to_string();
                Some((start, size, f[3].to_owned(), name))
            })
            .collect();
        for (kind, needle) in [
            ("G1", "msm::stream_g1_impl"),
            ("G2", "msm::g2_borrowed::apply"),
            ("inverse", "inverse_nonzero"),
        ] {
            let selected: Vec<_> = symbols
                .iter()
                .filter(|(_, _, _, name)| {
                    name.contains(needle)
                        && if kind == "G1" {
                            name.contains("G1Config") && name.contains('&')
                        } else if kind == "inverse" {
                            name.contains("FqBatch")
                        } else {
                            true
                        }
                })
                .collect();
            assert_eq!(selected.len(), 1, "{role}/{kind} symbol");
            let (start, size, raw, name) = selected[0];
            let argv = vec![
                "-d".to_owned(),
                "-Mintel".into(),
                "--no-show-raw-insn".into(),
                format!("--disassemble={raw}"),
                binary.to_owned(),
            ];
            let decode = Command::new("/usr/bin/objdump")
                .args(&argv)
                .output()
                .unwrap();
            assert!(decode.status.success());
            assert!(decode.stderr.is_empty());
            let decode = String::from_utf8(decode.stdout).unwrap();
            assert!(decode.contains(&format!("<{raw}>:")));
            let file = format!("{R}/disassembly/{role}-{kind}.txt");
            fs::write(&file, &decode).unwrap();
            let inst: Vec<_> = decode
                .lines()
                .filter_map(|l| {
                    let (a, s) = l.trim().split_once(':')?;
                    u64::from_str_radix(a, 16).ok()?;
                    Some(s.trim().to_owned())
                })
                .collect();
            let ifma = inst.iter().filter(|s| s.starts_with("vpmadd52")).count();
            let calls: Vec<_> = inst
                .iter()
                .filter(|s| s.starts_with("call"))
                .cloned()
                .collect();
            let frames: Vec<_> = inst
                .iter()
                .filter(|s| s.starts_with("sub    rsp,") || s.starts_with("sub rsp,"))
                .cloned()
                .collect();
            rows.push(json!({"role":role,"kind":kind,"name":name,"raw_symbol":raw,"start":start,"size_bytes":size,"instruction_rows":inst.len(),"ifma":ifma,"vector_adds":inst.iter().filter(|s|s.starts_with("vpaddq")).count(),"vector_subs":inst.iter().filter(|s|s.starts_with("vpsubq")).count(),"signed_shifts":inst.iter().filter(|s|s.starts_with("vpsraq")).count(),"vector_rsp_rbp_operand_rows":inst.iter().filter(|s|s.starts_with('v')&&(s.contains("[rsp")||s.contains("[rbp"))).count(),"calls":calls,"literal_rsp_subtractions":frames,"decode_argv":argv,"disassembly_sha256":hash(file),"scope":"whole actual complete caller function static rows incl prefixes/tails/coldbranches; not exclusive cycles/spills/lifetime stack"}));
        }
    }
    for (p, h) in &pins {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let out = json!({"status":"pass","pins":pins.len(),"identities":identities,"decodes":rows.len(),"rows":rows,"ordinary_field_rebuilt":false,"new_proofs":0,"clock":false});
    fs::write(
        format!("{R}/codegen.json"),
        serde_json::to_vec_pretty(&out).unwrap(),
    )
    .unwrap();
    println!(
        "inspected9newactualG1/G2/inverseconsumers;{}pins;explicitfield-corecoherence;noclock",
        pins.len()
    );
}
