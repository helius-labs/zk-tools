use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-callers176";
const N: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-native176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
const DEST: &str =
    "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-06-joint-pair52-callers176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn write(p: impl AsRef<Path>, v: &Value) {
    fs::write(p, serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn replace_joint_block(s: &mut String, call: &str, marker: &str, old: &str, semicolon: bool) {
    let site = s.find(call).unwrap();
    let start = s[..site].rfind(marker).unwrap();
    let open = start + s[start..].find('{').unwrap();
    let mut depth = 0;
    let mut end = 0;
    for (offset, c) in s[open..].char_indices() {
        if c == '{' {
            depth += 1;
        } else if c == '}' {
            depth -= 1;
            if depth == 0 {
                end = open + offset + 1;
                break;
            }
        }
    }
    assert!(end > site);
    if semicolon {
        assert_eq!(&s[end..end + 1], ";");
        end += 1;
    }
    s.replace_range(start..end, old);
}
fn main() {
    let r = PathBuf::from(R);
    let d = PathBuf::from(DEST);
    assert!(!r.join("review.json").exists());
    let pins = read(r.join("codegen-pins.json"));
    for (p, h) in pins.as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    assert_eq!(pins.as_object().unwrap().len(), 217);
    let audit = read(r.join("source-audit.json"));
    let native = read(format!("{N}/source-audit.json"));
    let accepted=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let cfg="#[cfg(all(feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma)))]";
    let mut native_exact = 0;
    let mut originals_exact = 0;
    let mut native_recovered = 0;
    let mut original_recovered = 0;
    for (name, h) in audit["hashes"].as_object().unwrap() {
        let path = r.join("source").join(name);
        assert_eq!(hash(&path), h.as_str().unwrap());
        let bytes = fs::read(&path).unwrap();
        if let Some(nh) = native["hashes"].get(name) {
            let parent = fs::read(format!("{N}/source/{name}")).unwrap();
            assert_eq!(
                format!("{:x}", Sha256::digest(&parent)),
                nh.as_str().unwrap()
            );
            if bytes == parent {
                native_exact += 1;
            }
            let mut recovered = bytes.clone();
            if name == "crates/zopro-core/src/msm.rs" {
                let mut s = String::from_utf8(recovered).unwrap();
                let suffix = format!("\n{cfg}\npub mod joint_complex_caller;\n");
                assert!(s.ends_with(&suffix));
                s.truncate(s.len() - suffix.len());
                replace_joint_block(&mut s,"FqBatch::joint_complex::<true>(&dy, &denominator)","        let numerator = {","        let numerator = [\n            dy[0].sum2(&denominator[0], &dy[1], &denominator[1]),\n            dy[1].difference2(&denominator[0], &dy[0], &denominator[1]),\n        ];",true);
                replace_joint_block(&mut s,"FqBatch::joint_complex::<true>(dy, dx)","        let value = {","        let value = [\n            dy[0].sum2(&dx[0], &dy[1], &dx[1]),\n            dy[1].difference2(&dx[0], &dy[0], &dx[1]),\n        ];",true);
                replace_joint_block(&mut s,"FqBatch::joint_complex::<false>(a,b)","            {\n","            [\n                a[0].difference2(&b[0], &a[1], &b[1]),\n                a[0].sum2(&b[1], &a[1], &b[0]),\n            ]",false);
                recovered = s.into_bytes();
            } else if name == "crates/zopro-core/src/lib.rs" {
                let suffix=format!("\n{cfg}\n#[doc(hidden)]pub use msm::joint_complex_caller::{{G1Caller,G2Caller}};\n");
                assert!(recovered.ends_with(suffix.as_bytes()));
                recovered.truncate(recovered.len() - suffix.len());
            } else if name == "crates/zopro-core/src/simd.rs" {
                let s = String::from_utf8(recovered).unwrap();
                let at = s
                    .find("\n#[cfg(all(zopro_joint_pair52_complex,feature=\"ifma8\"")
                    .unwrap();
                recovered = s[..at].as_bytes().to_vec();
            }
            assert_eq!(recovered, parent, "recover native parent {name}");
            native_recovered += 1;
            if let Some(ah) = accepted["source_files_sha256"].get(name) {
                if format!("{:x}", Sha256::digest(&bytes)) == ah.as_str().unwrap() {
                    originals_exact += 1;
                }
                if name == "crates/zopro-bn254/src/ifma8.rs" {
                    let suffix = "\ninclude!(\"joint_pair52.rs\");\n";
                    assert!(recovered.ends_with(suffix.as_bytes()));
                    recovered.truncate(recovered.len() - suffix.len());
                } else if name == "scripts/ifma8.py" {
                    let s = String::from_utf8(recovered).unwrap();
                    let append = "source += '\\ninclude!(\"joint_pair52.rs\");\\n'\n";
                    assert_eq!(s.matches(append).count(), 1);
                    recovered = s.replacen(append, "", 1).into_bytes();
                }
                assert_eq!(
                    format!("{:x}", Sha256::digest(&recovered)),
                    ah.as_str().unwrap(),
                    "recover accepted {name}"
                );
                original_recovered += 1;
            }
        }
    }
    assert_eq!(
        (
            native_exact,
            native_recovered,
            originals_exact,
            original_recovered
        ),
        (175, 178, 171, 176)
    );
    let mut receipts = 0;
    let plan = read(r.join("build-plan.json"));
    let mut members: Vec<String> = [
        "design.md",
        "provenance-note.md",
        "setup.rs",
        "driver.rs",
        "perf.rs",
        "codegen.rs",
        "finish.rs",
        "source-audit.json",
        "frozen-reference.json",
        "build-plan.json",
        "build-pins.json",
        "codegen-pins.json",
        "codegen.json",
        "documentation-initial/design.md",
        "documentation-initial/build-pins.json",
        "documentation-initial/correction.json",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect();
    for step in plan["steps"].as_array().unwrap() {
        let name = step["name"].as_str().unwrap();
        let p = r.join("build").join(name);
        let exit = read(p.join("exit.json"));
        assert_eq!(exit["success"], true);
        assert_eq!(exit["returncode"], 0);
        for stream in ["stdout", "stderr"] {
            assert_eq!(
                exit[format!("{stream}_sha256")],
                hash(p.join(format!("{stream}.log")))
            );
        }
        assert_eq!(
            read(p.join("command.json"))["argv"].as_array().unwrap()[4..],
            step["argv"].as_array().unwrap()[..]
        );
        for file in [
            "command.json",
            "exit.json",
            "stdout.log",
            "stderr.log",
            "tests.json",
        ] {
            members.push(format!("build/{name}/{file}"));
        }
        receipts += 1;
    }
    assert_eq!(receipts, 8);
    assert!(!r.join("build/attempt-1.json").exists());
    let on = fs::read_to_string(r.join("build/core-test-ON/stdout.log")).unwrap();
    let off = fs::read_to_string(r.join("build/core-test-OFF/stdout.log")).unwrap();
    assert!(on.contains("126 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"));
    assert!(off.contains("1 passed; 0 failed; 0 ignored; 0 measured; 125 filtered out"));
    let name="msm::joint_complex_caller::joint_complex_integration::complete_g2_signed_borrowed_tails_and_reuse";
    assert!(on.contains(name));
    assert!(off.contains(name));
    let old_driver =
        fs::read_to_string("/home/ubuntu/src/zopro-perf-work/high-borrow176/control/src/main.rs")
            .unwrap();
    let new_driver = fs::read_to_string(r.join("driver.rs")).unwrap();
    assert_eq!(
        new_driver.replacen("zopro_joint_pair52_complex", "zopro_high_borrow", 1),
        old_driver
    );
    let child =
        fs::read_to_string(r.join("source/crates/zopro-core/src/msm/joint_complex_caller.rs"))
            .unwrap();
    for kind in ["g1", "g2"] {
        assert!(child.contains(
            &fs::read_to_string(format!(
                "/home/ubuntu/src/zopro-perf-work/high-borrow176/{kind}-caller.rs"
            ))
            .unwrap()
        ));
    }
    let codegen = read(r.join("codegen.json"));
    assert_eq!(codegen["decodes"], 9);
    for row in codegen["rows"].as_array().unwrap() {
        let role = row["role"].as_str().unwrap();
        let kind = row["kind"].as_str().unwrap();
        let file = format!("disassembly/{role}-{kind}.txt");
        assert_eq!(row["disassembly_sha256"], hash(r.join(&file)));
        let expected = match kind {
            "G1" => 800,
            "inverse" => 500,
            "G2" => {
                if role == "ON" {
                    1230
                } else {
                    1450
                }
            }
            _ => unreachable!(),
        };
        assert_eq!(row["ifma"], expected);
        members.push(file);
    }
    let review = json!({"status":"pass","pins":217,"successful_commands":8,"attempts":1,"native_parent_files_recovered":178,"exact_native_parent_files":175,"accepted_originals_recovered":176,"exact_accepted_originals":171,"ON_core_tests_passed":126,"OFF_new_integration_test_passed":1,"OFF_unchanged_tests_filtered":125,"integration_lengths":13,"reuse_counts":[1,3,17],"qualified_field_libraries_reused_no_rebuild":true,"explicit_coherent_field_core_links":true,"driver_cfg_rename_only":true,"adapter_bodies_exact":true,"new_actual_decodes":9,"actual_G2_IFMA":{"FROZEN":1450,"OFF":1450,"ON":1230},"G1_IFMA_all":800,"inverse_IFMA_all":500,
 "frozen_control_scope":"accepted-source reference389307, not productionSDK/field1200 binary; see provenance-note and recorded original linkinputs",
 "reviewer_source_sha256":hash(r.join("finish.rs")),"reviewer_binary_sha256":hash(r.join("finish")),"decision":"select prospective actualcallerperformanceprotocol; no clock,adoption,proof or memory qualification","new_proofs":0});
    write(r.join("review.json"), &review);
    members.push("review.json".into());
    for file in [
        "result.json",
        "protocol.json",
        "source-pins.json",
        "attempt-0.json",
        "completed.json",
        "progress.json",
    ] {
        members.push(format!("build/{file}"));
    }
    for file in [
        "crates/zopro-core/src/msm.rs",
        "crates/zopro-core/src/simd.rs",
        "crates/zopro-core/src/lib.rs",
        "crates/zopro-core/src/msm/joint_complex_caller.rs",
    ] {
        members.push(format!("source/{file}"));
    }
    fs::create_dir_all(d.join("artifacts")).unwrap();
    for file in [
        "review.json",
        "codegen.json",
        "codegen-pins.json",
        "source-audit.json",
        "frozen-reference.json",
        "provenance-note.md",
        "design.md",
    ] {
        fs::copy(r.join(file), d.join("artifacts").join(file)).unwrap();
    }
    let mut hashes = BTreeMap::new();
    for file in &members {
        let bytes = fs::read(r.join(file)).unwrap();
        std::str::from_utf8(&bytes).unwrap();
        hashes.insert(file.clone(), format!("{:x}", Sha256::digest(bytes)));
    }
    write(d.join("artifacts/archive-members.json"), &json!(hashes));
    let archive = d.join("artifacts/source-and-receipts.tar.gz");
    assert!(Command::new("tar")
        .arg("-czf")
        .arg(&archive)
        .arg("-C")
        .arg(&r)
        .arg("--")
        .args(&members)
        .status()
        .unwrap()
        .success());
    let listing = Command::new("tar")
        .arg("-tzf")
        .arg(&archive)
        .output()
        .unwrap();
    assert!(listing.status.success());
    assert_eq!(
        String::from_utf8(listing.stdout)
            .unwrap()
            .lines()
            .map(str::to_owned)
            .collect::<Vec<_>>(),
        members
    );
    let extraction = r.join("archive-review");
    fs::create_dir(&extraction).unwrap();
    assert!(Command::new("tar")
        .arg("-xzf")
        .arg(&archive)
        .arg("-C")
        .arg(&extraction)
        .status()
        .unwrap()
        .success());
    for (file, h) in &hashes {
        assert_eq!(&hash(extraction.join(file)), h);
    }
    let mut report=String::from("# Joint complex complete-caller qualification\n\nThe joint signed-pair complex API is integrated into the actual G2 product paths and passes changed-core correctness checks. The final G2 caller has **1,230static IFMA sites versus1,450** in both controls. **No latency benchmark or proof-speed improvement has run.** Additional instructions and stack-addressed operations remain risks for the upcoming complete-caller measurement.\n\n## Integration and tests\n\nThree reversible core changes select the new API for ordinary complex multiplication and both denominator-conjugated numerator paths. Original expressions remain as OFF branches. Norms, scaling, inverses, prefix records, scalar tails, exceptional-point guards, queues and scratch geometry retain their implementations. Ordinary field arithmetic, FrFFT and G1 are unchanged. The [qualified field libraries](../2026-11-06-joint-pair52-native176/README.md) are reused without rebuilding or rerunning their tests. Each fresh core explicitly links its respective qualified OFF/ON field, and each new driver links that core; no old core is attached to a changed field.\n\nThe ON build passes **126unfiltered core tests**, including the new signed borrowed G2 test across13empty/tail/full lengths and1/3/17reuse counts against scalar-generator expectations. OFF runs that one new test, with125unchanged tests filtered. Field/math qualification is inherited, not counted as new. The new test and existing changed-core tests exercise actual integrated code rather than a standalone field proxy.\n\nAll eight build/test/link commands succeed first attempt. Independent review verifies217pins, all receipts, source recovery, flags and coherent libraries. The179-file snapshot has175native-parent files byte-exact and all178native-parent files recoverable;171accepted originals remain exact and all176recover. G1/G2 diagnostic adapter bodies are unchanged, and the driver only renames its compile-time arithmetic flag. No driver clock or profile is executed in this stage.\n\n## Actual final consumers\n\nNine newly decoded G1/G2/inverse functions cover the frozen accepted-source reference and both new executables. Counts describe whole static functions, including prefixes,tails and cold branches; they are not dynamic instructions, exclusive cycles or spill costs.\n\n| Function/build | IFMA sites | Instruction rows | Vector RSP/RBP operand rows | Bytes |\n|---|---:|---:|---:|---:|\n");
    for kind in ["G1", "G2", "inverse"] {
        for role in ["FROZEN", "OFF", "ON"] {
            let row = codegen["rows"]
                .as_array()
                .unwrap()
                .iter()
                .find(|x| x["kind"] == kind && x["role"] == role)
                .unwrap();
            report.push_str(&format!(
                "| {kind}/{role} | {} | {} | {} | {} |\n",
                row["ifma"],
                row["instruction_rows"],
                row["vector_rsp_rbp_operand_rows"],
                row["size_bytes"]
            ));
        }
    }
    report.push_str("\nThe actual G2 static IFMA count falls15.17%, while instruction rows rise8.41% and vector stack-addressed rows rise23.22%. Its literal RSP subtractions change from0xfc0+0x780to0xfc0+0xec0; this excludes alignment,pushes,callees and other frames, so it is not a measured lifetime stack peak or minimum RAM. G1 and inverse retain their counts. No call to a joint-complex field adapter remains in the G2 function; the arithmetic is inlined. These observations justify a matched actual-caller measurement, not adoption.\n\n## Controls and provenance\n\nThe frozen control is accepted-source binary389307b91908fe4822d9b4a788ff507944257f064bd0f11cde317ebd2cf6782b, inherited from the prior reference audit. It is not the production SDK or the original SDK field1200 artifact. The recorded Cargo link input field path currently hashes tob991c821121372aeb0ce07dfd9f7d3b5c839579384dbbcff1a96ea9d00d73d04. The audit's separate new_field_library entry belongs to its word-export candidate, not this frozen binary. [Provenance note](artifacts/provenance-note.md) supersedes earlier private field1200 shorthand for this caller. Exact binary hashes and actual code are checked; paired timing calibration remains required.\n\nBefore any native build, a mistyped illustrative hash in private design text was removed; only that document pin was corrected, with original text/pins retained. Successful setup was not repeated. No native execution failed or was rerun. A setup-helper unused-constant warning did not prompt a rebuild. These preparation notes do not change source, flags or evidence.\n\n## Next measurement and baseline\n\nFreeze a separate actual-caller protocol before any driver clock: G2 sizes200/352and201/353tails, workers1/16/32, frozen+freshOFF+ON, unchangedG1controls, fixed paired blocks, output/capacity/zero-allocation guards and automaticPMU/cycle profiles with verified ownership/samples/loss. No additional favorable primitive-only capture is selected. Only caller gains can select full all-eight plus merge54 SDK, resource/portable and independent Gnark proof qualification before adoption.\n\nProduction source176/SDK6d83 remain unchanged. Accepted local32 1×2 is **7.928660ms**,merge54 **161.883899ms**; inherited132.75MiBRSS is not a new peak or minimum. Canonical proof ledger remains30,846. The inherited [all-eight M5CPU and Metal comparisons](../2026-11-06-signed-pair52-model176/README.md#accepted-full-proof-baseline-inherited) remain current, and the10×CPU goal is unmet for all eight shapes. No new SDK/proof/profile/AWS/Aeglos/huge/mobile/pressure/swap/throughput result exists.\n\n[Codegen](artifacts/codegen.json),[review](artifacts/review.json),[source audit](artifacts/source-audit.json),[pins](artifacts/codegen-pins.json),[control identity](artifacts/frozen-reference.json),[design](artifacts/design.md) and[source/receipts](artifacts/source-and-receipts.tar.gz) are preserved. The public archive contains selectedUTF-8sources/receipts/decodes, with no executable,library,binary fixture,key,witness or proof blobs.\n");
    fs::write(d.join("README.md"), report).unwrap();
    let mut sums = BTreeMap::new();
    for file in [
        "README.md",
        "artifacts/review.json",
        "artifacts/codegen.json",
        "artifacts/codegen-pins.json",
        "artifacts/source-audit.json",
        "artifacts/frozen-reference.json",
        "artifacts/provenance-note.md",
        "artifacts/design.md",
        "artifacts/archive-members.json",
        "artifacts/source-and-receipts.tar.gz",
    ] {
        sums.insert(file, hash(d.join(file)));
    }
    write(d.join("checksums.json"), &json!(sums));
    for (file, h) in &sums {
        assert_eq!(&hash(d.join(file)), h);
    }
    write(
        r.join("publication.json"),
        &json!({"status":"pass","files":11,"utf8_archive_members":members.len(),"roundtrip_members":hashes.len(),"archive_sha256":hash(archive)}),
    );
    println!("caller qualification reviewed/published:217pins/8commands/126ON+1OFFtests/9newdecodes/{}UTF8members",members.len());
}
