use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::Path};
const R: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-callers176";
const N: &str = "/home/ubuntu/src/zopro-perf-work/joint-pair52-native176";
const Z: &str = "/home/ubuntu/src/zk-tools/zopro";
const O: &str = "/home/ubuntu/src/zopro-perf-work/inverse-root-codec176";
const H: &str = "/home/ubuntu/src/zopro-perf-work/high-borrow176";
const B: &str = "/home/ubuntu/src/zopro-perf-work/g2-vector-sign-default175";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(name: &str, v: &Value) {
    fs::write(format!("{R}/{name}"), serde_json::to_vec_pretty(v).unwrap()).unwrap();
}
fn replace(v: &Value) -> Value {
    match v {
        Value::String(s) => json!(s
            .replace(O, R)
            .replace("zopro_inverse_root_product", "zopro_joint_pair52_complex")),
        Value::Array(a) => json!(a.iter().map(replace).collect::<Vec<_>>()),
        Value::Object(o) => json!(o
            .iter()
            .map(|(k, v)| (k.clone(), replace(v)))
            .collect::<BTreeMap<_, _>>()),
        _ => v.clone(),
    }
}
fn field_args(step: &mut Value, role: &str) {
    let a = step["argv"].as_array_mut().unwrap();
    for arg in a {
        let s = arg.as_str().unwrap();
        if s.starts_with("zopro_bn254=") {
            *arg = json!(format!("zopro_bn254={N}/field/{role}/libzopro_bn254.rlib"));
        } else if s == format!("dependency={R}/field") {
            *arg = json!(format!("dependency={N}/field/{role}"));
        }
    }
}
fn main() {
    assert!(!Path::new(R).join("source").exists());
    assert_eq!(read(format!("{N}/review.json"))["status"], "pass");
    let native = read(format!("{N}/source-audit.json"));
    let originals=read(format!("{Z}/docs/benchmarks/2026-10-30-g2-vector-sign-adoption176/artifacts/production-source-manifest.json"));
    let cfg="#[cfg(all(feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma)))]";
    let active = "all(zopro_joint_pair52_complex, feature = \"ifma8\")";
    let numerator="        let numerator = [\n            dy[0].sum2(&denominator[0], &dy[1], &denominator[1]),\n            dy[1].difference2(&denominator[0], &dy[0], &denominator[1]),\n        ];";
    let numerator_after=format!("        let numerator = {{\n            #[cfg({active})]\n            {{ FqBatch::joint_complex::<true>(&dy, &denominator) }}\n            #[cfg(not({active}))]\n            {{ [dy[0].sum2(&denominator[0], &dy[1], &denominator[1]),dy[1].difference2(&denominator[0], &dy[0], &denominator[1])] }}\n        }};");
    let scaled="        let value = [\n            dy[0].sum2(&dx[0], &dy[1], &dx[1]),\n            dy[1].difference2(&dx[0], &dy[0], &dx[1]),\n        ];";
    let scaled_after=format!("        let value = {{\n            #[cfg({active})]\n            {{ FqBatch::joint_complex::<true>(dy, dx) }}\n            #[cfg(not({active}))]\n            {{ [dy[0].sum2(&dx[0], &dy[1], &dx[1]),dy[1].difference2(&dx[0], &dy[0], &dx[1])] }}\n        }};");
    let multiply="            [\n                a[0].difference2(&b[0], &a[1], &b[1]),\n                a[0].sum2(&b[1], &a[1], &b[0]),\n            ]";
    let multiply_after=format!("            {{\n                #[cfg({active})]\n                {{ FqBatch::joint_complex::<false>(a,b) }}\n                #[cfg(not({active}))]\n                {{ [a[0].difference2(&b[0], &a[1], &b[1]),a[0].sum2(&b[1], &a[1], &b[0])] }}\n            }}");
    let edits = [
        (numerator, numerator_after),
        (scaled, scaled_after),
        (multiply, multiply_after),
    ];
    let adapter=format!("\n#[cfg(all(zopro_joint_pair52_complex,feature=\"ifma8\",target_arch=\"x86_64\",target_feature=\"avx512ifma\",target_feature=\"avx512vl\",target_feature=\"avx512dq\",not(no_ifma)))]\nimpl FqBatch {{\n    #[inline(always)]pub(crate) fn joint_complex<const CONJ:bool>(a:&[Self;2],b:&[Self;2])->[Self;2] {{let out=a[0].0.joint_pair52_complex::<CONJ>(&a[1].0,&b[0].0,&b[1].0);[Self(out[0]),Self(out[1])]}}\n}}\n");
    let suffixes=BTreeMap::from([("crates/zopro-core/src/msm.rs".to_owned(),format!("\n{cfg}\npub mod joint_complex_caller;\n")),("crates/zopro-core/src/lib.rs".to_owned(),format!("\n{cfg}\n#[doc(hidden)]pub use msm::joint_complex_caller::{{G1Caller,G2Caller}};\n")),("crates/zopro-core/src/simd.rs".to_owned(),adapter)]);
    let mut pins = BTreeMap::new();
    let mut hashes = BTreeMap::new();
    let mut native_exact = 0;
    let mut accepted_exact = 0;
    for (name, h) in native["hashes"].as_object().unwrap() {
        let p = format!("{N}/source/{name}");
        assert_eq!(hash(&p), h.as_str().unwrap());
        let original = fs::read(&p).unwrap();
        let mut bytes = original.clone();
        if name == "crates/zopro-core/src/msm.rs" {
            let mut s = String::from_utf8(bytes).unwrap();
            for (before, after) in &edits {
                assert_eq!(s.matches(before).count(), 1);
                s = s.replacen(before, after, 1);
            }
            bytes = s.into_bytes();
        }
        if let Some(suffix) = suffixes.get(name) {
            bytes.extend_from_slice(suffix.as_bytes());
        }
        if bytes == original {
            native_exact += 1;
        }
        if originals["source_files_sha256"][name] == format!("{:x}", Sha256::digest(&bytes)) {
            accepted_exact += 1;
        }
        let dest = Path::new(R).join("source").join(name);
        fs::create_dir_all(dest.parent().unwrap()).unwrap();
        fs::write(&dest, &bytes).unwrap();
        let mut recovered = bytes;
        if let Some(suffix) = suffixes.get(name) {
            assert!(recovered.ends_with(suffix.as_bytes()));
            recovered.truncate(recovered.len() - suffix.len());
        }
        if name == "crates/zopro-core/src/msm.rs" {
            let mut s = String::from_utf8(recovered).unwrap();
            for (before, after) in &edits {
                assert_eq!(s.matches(after).count(), 1);
                s = s.replacen(after, before, 1);
            }
            recovered = s.into_bytes();
        }
        assert_eq!(recovered, original);
        hashes.insert(name.clone(), hash(&dest));
        pins.insert(dest.display().to_string(), hash(&dest));
    }
    assert_eq!(native_exact, 175);
    assert_eq!(accepted_exact, 171);
    let g1 = fs::read_to_string(format!("{H}/g1-caller.rs")).unwrap();
    let g2 = fs::read_to_string(format!("{H}/g2-caller.rs")).unwrap();
    assert!(g2.contains("let _=tree;super::g2_borrowed::apply"));
    let integration="\n#[cfg(test)]mod joint_complex_integration {use super::*;\n#[test]fn complete_g2_signed_borrowed_tails_and_reuse(){for n in[0,1,7,8,9,15,16,17,199,200,201,352,353]{let mut f=G2Caller::new(n,31);for rounds in[1,3,17]{f.reset();f.run(rounds,false,true);f.check(rounds);}}}\n}\n";
    let child=format!("use super::*;use zopro_bn254::{{G1Affine,G1Config,G1Projective,G2Affine,G2Config,G2Projective}};\n{g1}\n{g2}\n{integration}");
    let p = format!("{R}/source/crates/zopro-core/src/msm/joint_complex_caller.rs");
    fs::write(&p, &child).unwrap();
    pins.insert(p.clone(), hash(&p));
    hashes.insert(
        "crates/zopro-core/src/msm/joint_complex_caller.rs".into(),
        hash(&p),
    );
    assert_eq!(hashes.len(), 179);
    let driver = fs::read_to_string(format!("{O}/driver.rs")).unwrap();
    assert_eq!(driver.matches("zopro_inverse_root_product").count(), 1);
    fs::write(
        format!("{R}/driver.rs"),
        driver.replacen(
            "zopro_inverse_root_product",
            "zopro_joint_pair52_complex",
            1,
        ),
    )
    .unwrap();
    fs::copy(format!("{O}/perf.rs"), format!("{R}/perf.rs")).unwrap();
    let reference = read("/home/ubuntu/src/zopro-perf-work/word-export176/caller-reference.json");
    assert_eq!(reference["passed"], true);
    let frozen = reference["identity"].clone();
    assert_eq!(
        hash(frozen["binary"].as_str().unwrap()),
        frozen["binary_sha256"]
    );
    save("frozen-reference.json", &frozen);
    let old = replace(&read(format!("{O}/build-plan.json")));
    let oldsteps = old["steps"].as_array().unwrap();
    let mut steps = Vec::new();
    let testname="msm::joint_complex_caller::joint_complex_integration::complete_g2_signed_borrowed_tails_and_reuse";
    for role in ["OFF", "ON"] {
        fs::create_dir_all(format!("{R}/libs/{role}")).unwrap();
        let mut core = oldsteps
            .iter()
            .find(|s| s["name"] == format!("core-{role}"))
            .unwrap()
            .clone();
        field_args(&mut core, role);
        steps.push(core.clone());
        let mut test = core;
        test["name"] = json!(format!("build-core-test-{role}"));
        let a = test["argv"].as_array_mut().unwrap();
        let k = a.iter().position(|x| x == "--crate-type").unwrap();
        a.drain(k..k + 2);
        let k = a.iter().position(|x| x == "-o").unwrap() + 1;
        a[k] = json!(format!("{R}/core-tests-{role}"));
        a.extend([json!("--test"), json!("-C"), json!("lto=fat")]);
        steps.push(test.clone());
        let argv = if role == "ON" {
            vec![
                format!("{R}/core-tests-{role}"),
                "--nocapture".into(),
                "--test-threads=1".into(),
            ]
        } else {
            vec![
                format!("{R}/core-tests-{role}"),
                "--exact".into(),
                testname.into(),
                "--nocapture".into(),
                "--test-threads=1".into(),
            ]
        };
        steps.push(json!({"kind":"command","name":format!("core-test-{role}"),"argv":argv,"environment":test["environment"],"required_tests":[testname],"unfiltered":role=="ON","timeout_seconds":600}));
        let mut driver = oldsteps
            .iter()
            .find(|s| s["name"] == format!("driver-{role}"))
            .unwrap()
            .clone();
        field_args(&mut driver, role);
        steps.push(driver);
    }
    for step in &steps {
        let env = step["environment"].as_object().unwrap();
        assert_eq!(
            env["CARGO_PKG_NAME"],
            if step["name"].as_str().unwrap().starts_with("driver-") {
                env["CARGO_PKG_NAME"].clone()
            } else {
                json!("zopro-core")
            }
        );
        for arg in step["argv"].as_array().unwrap() {
            let arg = arg.as_str().unwrap();
            assert!(!arg.contains("zopro_inverse_root_product"));
            let path = arg
                .split_once('=')
                .filter(|(k, _)| {
                    matches!(
                        *k,
                        "dependency"
                            | "ahash"
                            | "getrandom"
                            | "libc"
                            | "log"
                            | "miniz_oxide"
                            | "rayon"
                            | "sha2"
                            | "wasm_bindgen"
                            | "wasm_bindgen_rayon"
                            | "serde_json"
                            | "zopro_bn254"
                            | "zopro_core"
                    )
                })
                .map(|(_, p)| p)
                .unwrap_or(arg);
            if Path::new(path).is_file() {
                pins.insert(path.to_owned(), hash(path));
            }
        }
    }
    for p in [
        format!("{R}/setup.rs"),
        format!("{R}/setup"),
        format!("{R}/driver.rs"),
        format!("{R}/perf.rs"),
        format!("{R}/design.md"),
        format!("{N}/review.json"),
        format!("{N}/publication.json"),
        format!("{N}/codegen.json"),
        format!("{N}/field/OFF/libzopro_bn254.rlib"),
        format!("{N}/field/ON/libzopro_bn254.rlib"),
        frozen["binary"].as_str().unwrap().into(),
        "/home/ubuntu/src/zopro-perf-work/sdk-link-flags176/tool-target/release/xtask".into(),
    ] {
        pins.insert(p.clone(), hash(p));
    }
    save(
        "source-audit.json",
        &json!({"source_files":179,"native_parent_files":178,"exact_native_parent_files":175,"all_native_parent_files_recovered":178,"exact_accepted_originals":171,"recoverable_accepted_originals":176,"hashes":hashes,"native_field_files_byte_exact":true,"core_complex_sites_changed":3,"new_integration_lengths":13,"reuse_counts":[1,3,17],"driver_only_compiled_flag_renamed":true,"frozen_reference":frozen}),
    );
    save("build-pins.json", &json!(pins));
    save(
        "build-plan.json",
        &json!({"version":1,"source_pins":format!("{R}/build-pins.json"),"environment":{},"steps":steps}),
    );
    println!("prepared179sources/171acceptedexact/178nativeparentrecoverable;8coretestlinkcommands/{}pins;no field rebuild/clock",pins.len());
}
