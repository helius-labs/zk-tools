//! One immutable inverse-policy snapshot per nonempty tree operation.
use super::*;

#[cfg(test)]
static OWNER_READS: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

#[inline]
pub(super) fn factory<C: CurveConfig>(active: bool) -> impl Fn() -> Scratch<C>
where C::Base: BatchInverse {
    let vector_inverse = if active {
        #[cfg(test)] OWNER_READS.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        crate::simd::cpu_option("ZOPRO_CPU_TREE_VECTOR_INVERSE")
    } else { false };
    move || Scratch {
        vector_inverse,
        pairs: Vec::new(),
        groups: Vec::new(),
        prefix_records: Vec::new(),
        denominators: [C::Base::ZERO; LANES],
        products: [Default::default(); LANES],
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use zopro_bn254::{G1Config,G2Config};
    use std::{ffi::OsString,os::unix::ffi::OsStringExt,sync::atomic::Ordering};
    const OPTION:&str="ZOPRO_CPU_TREE_VECTOR_INVERSE";
    struct Restore(Option<OsString>);
    impl Drop for Restore {fn drop(&mut self){unsafe{match &self.0{Some(v)=>std::env::set_var(OPTION,v),None=>std::env::remove_var(OPTION)}}}}
    fn set(value:Option<&std::ffi::OsStr>){unsafe{match value{Some(v)=>std::env::set_var(OPTION,v),None=>std::env::remove_var(OPTION)}}}
    fn coefficients<C:CurveConfig>(n:usize)->(Vec<Affine<C>>,Vec<Fr>){let g=Projective::<C>::generator();let mut weight=Fr::from(123456789u64);let delta=Fr::from(0x9e3779b97f4a7c15u64);let mut points=Vec::new();let mut weights=Vec::new();for i in 0..n{weight=weight.double()+delta;let w=if i%17==0{Fr::ZERO}else if i%13==0{-Fr::ONE}else if i%11==0{Fr::ONE}else{weight};points.push((g*w).to_affine());weights.push(w);}if n>3{points[3]=-points[2];weights[3]=-weights[2];}(points,weights)}
    fn actual_entries<C:CurveConfig>(points:&[Affine<C>],weights:&[Fr])where C::Base:BatchInverse{
        let g=Projective::<C>::generator();let expected=weights.iter().enumerate().fold(Fr::ZERO,|s,(i,w)|s+*w*Fr::from(i as u64+1));assert_eq!(weighted_affine(points).to_affine(),(g*expected).to_affine());
        let cuts=[0,1,8,9,31,32,points.len()];let mut starts=vec![0];let mut order=Vec::new();let mut counts=Vec::new();let mut wanted=Vec::new();for pair in cuts.windows(2){assert!(pair[1]>=pair[0]);let begin=pair[0];let end=pair[1];let mut sum=Fr::ZERO;for i in begin..end{order.push(i as u32);sum+=weights[i];}counts.push(end-begin);starts.push(order.len());wanted.push((g*sum).to_affine());}
        assert_eq!(group_affine(points,&order,&starts,&counts),wanted);assert_eq!(reduce_indexed_buckets(points,&order,&starts),wanted);
    }
    #[test]
    fn option_snapshot_complete_entries_and_shared_workers(){
        let _restore=Restore(std::env::var_os(OPTION));let non_utf8=OsString::from_vec(vec![0xff]);let cases=[None,Some(OsString::from("0")),Some(OsString::from("")),Some(OsString::from("1")),Some(OsString::from("unexpected")),Some(non_utf8)];let mut parsing=0;for case in cases{set(case.as_deref());let before=OWNER_READS.load(Ordering::Relaxed);let make=factory::<G1Config>(true);let expected=Scratch::<G1Config>::default().vector_inverse;assert_eq!(OWNER_READS.load(Ordering::Relaxed),before+1);for _ in 0..7{let s=make();assert_eq!(s.vector_inverse,expected);assert!(s.pairs.is_empty()&&s.groups.is_empty()&&s.prefix_records.is_empty());assert_eq!(s.pairs.capacity()+s.groups.capacity()+s.prefix_records.capacity(),0);assert!(s.denominators.iter().all(|v|*v==Fq::ZERO));}assert_eq!(OWNER_READS.load(Ordering::Relaxed),before+1);parsing+=1;}
        set(Some(std::ffi::OsStr::new("0")));let prior=factory::<G1Config>(true);set(Some(std::ffi::OsStr::new("1")));assert!(!prior().vector_inverse);assert!(factory::<G1Config>(true)().vector_inverse);let before=OWNER_READS.load(Ordering::Relaxed);let _=factory::<G1Config>(false);assert_eq!(OWNER_READS.load(Ordering::Relaxed),before);
        let(p1,w1)=coefficients::<G1Config>(513);let(p2,w2)=coefficients::<G2Config>(64);let mut calls=0;let mut workers_seen=0;for threads in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(threads).stack_size(512*1024).build().unwrap();for inverse in["0","1"]{set(Some(std::ffi::OsStr::new(inverse)));pool.broadcast(|_|{actual_entries(&p1,&w1);actual_entries(&p2,&w2);});calls+=threads*6;}workers_seen+=threads;}
        set(Some(std::ffi::OsStr::new("1")));let pool=rayon::ThreadPoolBuilder::new().num_threads(8).stack_size(512*1024).build().unwrap();std::thread::scope(|scope|{for _ in 0..4{scope.spawn(||{for _ in 0..3{pool.install(||actual_entries(&p1,&w1));}});}});
        let before=OWNER_READS.load(Ordering::Relaxed);assert_eq!(weighted_affine::<G1Config>(&[]),Projective::<G1Config>::IDENTITY);assert!(group_affine::<G1Config>(&[],&[],&[0],&[]).is_empty());assert!(reduce_indexed_buckets::<G1Config>(&[],&[],&[0]).is_empty());assert_eq!(OWNER_READS.load(Ordering::Relaxed),before);
        println!("OWNER_PARSING_CASES={parsing};ACTUAL_WORKERS={workers_seen};G1_G2_COMPLETE_ENTRY_CALLS={calls};CONCURRENT_CALLS=12;EMPTY_OWNERS_NO_READ=true");
    }
}
