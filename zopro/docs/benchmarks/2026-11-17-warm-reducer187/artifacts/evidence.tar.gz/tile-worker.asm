
/home/ubuntu/src/zopro-perf-work/warm-reducer187/target/release/deps/zopro_core-0e91917ca6825209:     file format elf64-x86-64


Disassembly of section .text:

00000000003c13d0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_>:
  3c13d0:	push   %rbp
  3c13d1:	push   %r15
  3c13d3:	push   %r14
  3c13d5:	push   %r13
  3c13d7:	push   %r12
  3c13d9:	push   %rbx
  3c13da:	sub    $0x6b8,%rsp
  3c13e1:	mov    0x6f0(%rsp),%rbx
  3c13e9:	mov    %rdi,0x48(%rsp)
  3c13ee:	shr    $1,%rdi
  3c13f1:	mov    %rdx,0x78(%rsp)
  3c13f6:	mov    %r8,%r12
  3c13f9:	mov    %rcx,0x80(%rsp)
  3c1401:	cmp    %rcx,%rdi
  3c1404:	jae    3c1e7e <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xaae>
  3c140a:	test   %r9,%r9
  3c140d:	je     3c2018 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc48>
  3c1413:	mov    (%rbx),%rcx
  3c1416:	mov    0x8(%rbx),%rdx
  3c141a:	mov    0x10(%rbx),%r13
  3c141e:	mov    0x18(%rbx),%rbp
  3c1422:	mov    %r9,%rax
  3c1425:	shl    $0x5,%rax
  3c1429:	movq   $0x0,0x90(%rsp)
  3c1435:	add    %r12,%rax
  3c1438:	mov    %rax,0xb0(%rsp)
  3c1440:	mov    %rcx,0xb8(%rsp)
  3c1448:	lea    0x3f28f1(%rip),%rcx        # 7b3d40 <__frame_dummy_init_array_entry+0x3938>
  3c144f:	mov    %rdx,0xa0(%rsp)
  3c1457:	mov    %rcx,0x88(%rsp)
  3c145f:	mov    (%r12),%rdi
  3c1463:	test   %rdi,%rdi
  3c1466:	je     3c2018 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc48>
  3c146c:	mov    0x8(%r12),%rsi
  3c1471:	test   %rsi,%rsi
  3c1474:	je     3c1486 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xb6>
  3c1476:	cmp    $0x4,%rsi
  3c147a:	jae    3c148e <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xbe>
  3c147c:	xor    %eax,%eax
  3c147e:	xor    %r14d,%r14d
  3c1481:	jmp    3c165c <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x28c>
  3c1486:	xor    %r14d,%r14d
  3c1489:	jmp    3c1680 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x2b0>
  3c148e:	cmp    $0x20,%rsi
  3c1492:	jae    3c149e <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xce>
  3c1494:	xor    %eax,%eax
  3c1496:	xor    %r14d,%r14d
  3c1499:	jmp    3c15e6 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x216>
  3c149e:	vmovdqa64 -0x37f168(%rip),%zmm9        # 42340 <GCC_except_table0+0x47a4>
  3c14a8:	vmovdqa64 -0x37f132(%rip),%zmm10        # 42380 <GCC_except_table0+0x47e4>
  3c14b2:	mov    %rsi,%rax
  3c14b5:	and    $0xffffffffffffffe0,%rax
  3c14b9:	lea    0x180(%rdi),%rcx
  3c14c0:	vpxor  %xmm0,%xmm0,%xmm0
  3c14c4:	vpxor  %xmm1,%xmm1,%xmm1
  3c14c8:	vpxor  %xmm2,%xmm2,%xmm2
  3c14cc:	vpxor  %xmm3,%xmm3,%xmm3
  3c14d0:	mov    %rax,%rdx
  3c14d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3c14e0:	vmovdqu64 -0x180(%rcx),%zmm4
  3c14e7:	vmovdqu64 -0x140(%rcx),%zmm5
  3c14ee:	vmovdqu64 -0x100(%rcx),%zmm6
  3c14f5:	vmovdqu64 -0xc0(%rcx),%zmm7
  3c14fc:	vmovdqa64 %zmm4,%zmm8
  3c1502:	vpermt2q %zmm5,%zmm9,%zmm8
  3c1508:	vpermt2q %zmm5,%zmm10,%zmm4
  3c150e:	vmovdqa64 %zmm6,%zmm5
  3c1514:	vpermt2q %zmm7,%zmm9,%zmm5
  3c151a:	vpermt2q %zmm7,%zmm10,%zmm6
  3c1520:	vmovdqu64 -0x40(%rcx),%zmm7
  3c1527:	vpsubq %zmm5,%zmm1,%zmm1
  3c152d:	vmovdqu64 -0x80(%rcx),%zmm5
  3c1534:	vpsubq %zmm8,%zmm0,%zmm0
  3c153a:	vpaddq %zmm4,%zmm0,%zmm0
  3c1540:	vpaddq %zmm6,%zmm1,%zmm1
  3c1546:	vmovdqu64 0x40(%rcx),%zmm4
  3c154d:	vmovdqa64 %zmm5,%zmm6
  3c1553:	vpermt2q %zmm7,%zmm9,%zmm6
  3c1559:	vpermt2q %zmm7,%zmm10,%zmm5
  3c155f:	vmovdqu64 (%rcx),%zmm7
  3c1565:	add    $0x200,%rcx
  3c156c:	add    $0xffffffffffffffe0,%rdx
  3c1570:	vpsubq %zmm6,%zmm2,%zmm2
  3c1576:	vpaddq %zmm5,%zmm2,%zmm2
  3c157c:	vmovdqa64 %zmm7,%zmm6
  3c1582:	vpermt2q %zmm4,%zmm9,%zmm6
  3c1588:	vpermt2q %zmm4,%zmm10,%zmm7
  3c158e:	vpsubq %zmm6,%zmm3,%zmm3
  3c1594:	vpaddq %zmm7,%zmm3,%zmm3
  3c159a:	jne    3c14e0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x110>
  3c15a0:	vpaddq %zmm0,%zmm1,%zmm0
  3c15a6:	vpaddq %zmm0,%zmm2,%zmm0
  3c15ac:	vpaddq %zmm0,%zmm3,%zmm0
  3c15b2:	vextracti64x4 $0x1,%zmm0,%ymm1
  3c15b9:	vpaddq %zmm1,%zmm0,%zmm0
  3c15bf:	vextracti128 $0x1,%ymm0,%xmm1
  3c15c5:	vpaddq %xmm1,%xmm0,%xmm0
  3c15c9:	vpshufd $0xee,%xmm0,%xmm1
  3c15ce:	vpaddq %xmm1,%xmm0,%xmm0
  3c15d2:	vmovq  %xmm0,%r14
  3c15d7:	cmp    %rax,%rsi
  3c15da:	je     3c1680 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x2b0>
  3c15e0:	test   $0x1c,%sil
  3c15e4:	je     3c165c <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x28c>
  3c15e6:	mov    %rax,%rcx
  3c15e9:	mov    %rsi,%rax
  3c15ec:	mov    %rcx,%rdx
  3c15ef:	shl    $0x4,%rcx
  3c15f3:	and    $0xfffffffffffffffc,%rax
  3c15f7:	vmovq  %r14,%xmm0
  3c15fc:	sub    %rax,%rdx
  3c15ff:	add    %rdi,%rcx
  3c1602:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3c1610:	vmovdqu (%rcx),%ymm1
  3c1614:	vmovdqu 0x20(%rcx),%ymm2
  3c1619:	add    $0x40,%rcx
  3c161d:	add    $0x4,%rdx
  3c1621:	vpunpcklqdq %ymm2,%ymm1,%ymm3
  3c1625:	vpunpckhqdq %ymm2,%ymm1,%ymm1
  3c1629:	vpermq $0xd8,%ymm3,%ymm3
  3c162f:	vpermq $0xd8,%ymm1,%ymm1
  3c1635:	vpsubq %ymm3,%ymm0,%ymm0
  3c1639:	vpaddq %ymm1,%ymm0,%ymm0
  3c163d:	jne    3c1610 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x240>
  3c163f:	vextracti128 $0x1,%ymm0,%xmm1
  3c1645:	vpaddq %xmm1,%xmm0,%xmm0
  3c1649:	vpshufd $0xee,%xmm0,%xmm1
  3c164e:	vpaddq %xmm1,%xmm0,%xmm0
  3c1652:	vmovq  %xmm0,%r14
  3c1657:	cmp    %rax,%rsi
  3c165a:	je     3c1680 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x2b0>
  3c165c:	mov    %rsi,%rcx
  3c165f:	sub    %rax,%rcx
  3c1662:	shl    $0x4,%rax
  3c1666:	lea    0x8(%rdi,%rax,1),%rax
  3c166b:	nopl   0x0(%rax,%rax,1)
  3c1670:	sub    -0x8(%rax),%r14
  3c1674:	add    (%rax),%r14
  3c1677:	add    $0x10,%rax
  3c167b:	dec    %rcx
  3c167e:	jne    3c1670 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x2a0>
  3c1680:	mov    %r14,%rbx
  3c1683:	shl    $0x7,%rbx
  3c1687:	mov    %r14,%rax
  3c168a:	shr    $0x39,%rax
  3c168e:	movabs $0x7ffffffffffffff8,%rcx
  3c1698:	sete   %al
  3c169b:	cmp    %rcx,%rbx
  3c169e:	setbe  %cl
  3c16a1:	test   %cl,%al
  3c16a3:	je     3c1ea7 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xad7>
  3c16a9:	mov    0x10(%r12),%rax
  3c16ae:	mov    0x18(%r12),%rcx
  3c16b3:	mov    %rdi,0x10(%rsp)
  3c16b8:	mov    %rax,0xc8(%rsp)
  3c16c0:	mov    %rcx,0x70(%rsp)
  3c16c5:	test   %rbx,%rbx
  3c16c8:	je     3c16f7 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x327>
  3c16ca:	mov    %r12,%r15
  3c16cd:	mov    %rbx,%rdi
  3c16d0:	mov    %rsi,%r12
  3c16d3:	vzeroupper
  3c16d6:	call   *0x407bf4(%rip)        # 7c92d0 <malloc@GLIBC_2.2.5>
  3c16dc:	test   %rax,%rax
  3c16df:	je     3c219f <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xdcf>
  3c16e5:	movabs $0x7ffffffffffffff8,%rcx
  3c16ef:	mov    %r12,%rsi
  3c16f2:	mov    %r15,%r12
  3c16f5:	jmp    3c1709 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x339>
  3c16f7:	mov    $0x8,%eax
  3c16fc:	xor    %r14d,%r14d
  3c16ff:	movabs $0x7ffffffffffffff8,%rcx
  3c1709:	lea    0x0(,%rsi,8),%rbx
  3c1711:	mov    %r14,0x50(%rsp)
  3c1716:	mov    %rax,0x58(%rsp)
  3c171b:	mov    %rax,0x68(%rsp)
  3c1720:	mov    %rsi,%rax
  3c1723:	shr    $0x3d,%rax
  3c1727:	movq   $0x0,0x60(%rsp)
  3c1730:	setne  %al
  3c1733:	cmp    %rcx,%rbx
  3c1736:	seta   %cl
  3c1739:	or     %al,%cl
  3c173b:	jne    3c21c8 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xdf8>
  3c1741:	mov    %r12,0xa8(%rsp)
  3c1749:	mov    %rbp,0x98(%rsp)
  3c1751:	test   %rbx,%rbx
  3c1754:	je     3c1a8a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x6ba>
  3c175a:	mov    0x407b6f(%rip),%r15        # 7c92d0 <malloc@GLIBC_2.2.5>
  3c1761:	mov    %rbx,%rdi
  3c1764:	mov    %rsi,%r12
  3c1767:	vzeroupper
  3c176a:	call   *%r15
  3c176d:	lea    0x180(%rsp),%r14
  3c1775:	test   %rax,%rax
  3c1778:	je     3c21bb <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xdeb>
  3c177e:	mov    %r12,0x18(%rsp)
  3c1783:	mov    %r12,%r15
  3c1786:	mov    %rax,0x20(%rsp)
  3c178b:	mov    %rbx,%rdi
  3c178e:	mov    %rax,%r12
  3c1791:	movq   $0x0,0x28(%rsp)
  3c179a:	call   *0x407b30(%rip)        # 7c92d0 <malloc@GLIBC_2.2.5>
  3c17a0:	test   %rax,%rax
  3c17a3:	je     3c21ac <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xddc>
  3c17a9:	mov    0x10(%rsp),%r8
  3c17ae:	mov    %r15,0x30(%rsp)
  3c17b3:	mov    %rax,0x38(%rsp)
  3c17b8:	movq   $0x0,0x40(%rsp)
  3c17c1:	test   %r15,%r15
  3c17c4:	je     3c1acd <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x6fd>
  3c17ca:	shl    $0x4,%r15
  3c17ce:	xor    %r11d,%r11d
  3c17d1:	xor    %r9d,%r9d
  3c17d4:	mov    %r12,%r10
  3c17d7:	add    %r8,%r15
  3c17da:	mov    %r15,0xc0(%rsp)
  3c17e2:	jmp    3c180f <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x43f>
  3c17e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  3c17f0:	lea    0x180(%rsp),%r14
  3c17f8:	add    $0x10,%r8
  3c17fc:	mov    %r9,0x60(%rsp)
  3c1801:	cmp    0xc0(%rsp),%r8
  3c1809:	je     3c1ad0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x700>
  3c180f:	mov    (%r8),%rbp
  3c1812:	mov    0x8(%r8),%r14
  3c1816:	mov    %r8,0x10(%rsp)
  3c181b:	cmp    0x18(%rsp),%r11
  3c1820:	jne    3c1840 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x470>
  3c1822:	lea    0x18(%rsp),%rdi
  3c1827:	mov    %r11,%r15
  3c182a:	mov    %r9,%rbx
  3c182d:	vzeroupper
  3c1830:	call   6d2fd0 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCs9JkjzAOZTiM_15crossbeam_utils>
  3c1835:	mov    0x20(%rsp),%r10
  3c183a:	mov    %rbx,%r9
  3c183d:	mov    %r15,%r11
  3c1840:	mov    %r9,(%r10,%r11,8)
  3c1844:	inc    %r11
  3c1847:	mov    %r9,%r12
  3c184a:	mov    %r10,0xd8(%rsp)
  3c1852:	mov    0x40(%rsp),%r15
  3c1857:	mov    %r11,0xd0(%rsp)
  3c185f:	mov    %r11,0x28(%rsp)
  3c1864:	cmp    0x30(%rsp),%r15
  3c1869:	jne    3c1878 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x4a8>
  3c186b:	lea    0x30(%rsp),%rdi
  3c1870:	vzeroupper
  3c1873:	call   6d2fd0 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCs9JkjzAOZTiM_15crossbeam_utils>
  3c1878:	mov    0x38(%rsp),%rax
  3c187d:	mov    %r14,%rbx
  3c1880:	sub    %rbp,%rbx
  3c1883:	mov    %rbx,(%rax,%r15,8)
  3c1887:	inc    %r15
  3c188a:	mov    %r15,0x40(%rsp)
  3c188f:	cmp    %rbp,%r14
  3c1892:	jb     3c202d <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc5d>
  3c1898:	cmp    0xa0(%rsp),%r14
  3c18a0:	ja     3c202d <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc5d>
  3c18a6:	mov    0x50(%rsp),%rax
  3c18ab:	mov    %r12,%r9
  3c18ae:	sub    %r12,%rax
  3c18b1:	cmp    %rax,%rbx
  3c18b4:	ja     3c1a58 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x688>
  3c18ba:	mov    0x10(%rsp),%r8
  3c18bf:	mov    0xd8(%rsp),%r10
  3c18c7:	mov    0xd0(%rsp),%r11
  3c18cf:	cmp    %rbp,%r14
  3c18d2:	je     3c17f0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x420>
  3c18d8:	mov    0xb8(%rsp),%rax
  3c18e0:	mov    %r9,%rcx
  3c18e3:	shl    $0x7,%rcx
  3c18e7:	add    0x68(%rsp),%rcx
  3c18ec:	lea    0x180(%rsp),%r14
  3c18f4:	xor    %edx,%edx
  3c18f6:	lea    (%rax,%rbp,4),%rax
  3c18fa:	mov    0x98(%rsp),%rbp
  3c1902:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3c1910:	mov    (%rax,%rdx,4),%edi
  3c1913:	cmp    %rdi,%rbp
  3c1916:	jbe    3c2162 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xd92>
  3c191c:	shl    $0x7,%rdi
  3c1920:	vmovups 0x0(%r13,%rdi,1),%zmm0
  3c1928:	vmovups 0x40(%r13,%rdi,1),%zmm1
  3c1930:	vmovups %zmm1,0x260(%rsp)
  3c193b:	vmovups %zmm0,0x220(%rsp)
  3c1946:	vmovdqu 0x0(%r13,%rdi,1),%ymm0
  3c194d:	vptest %ymm0,%ymm0
  3c1952:	jne    3c1990 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x5c0>
  3c1954:	vmovdqu 0x240(%rsp),%ymm0
  3c195d:	vptest %ymm0,%ymm0
  3c1962:	jne    3c1990 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x5c0>
  3c1964:	vmovdqu 0x260(%rsp),%ymm0
  3c196d:	vptest %ymm0,%ymm0
  3c1972:	jne    3c1990 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x5c0>
  3c1974:	vmovdqu 0x280(%rsp),%ymm0
  3c197d:	vptest %ymm0,%ymm0
  3c1982:	je     3c1a2d <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x65d>
  3c1988:	nopl   0x0(%rax,%rax,1)
  3c1990:	add    %r13,%rdi
  3c1993:	lea    0x1c0(%rsp),%rsi
  3c199b:	vmovups 0x20(%rdi),%ymm0
  3c19a0:	vmovups %ymm0,(%r14)
  3c19a5:	vmovups (%rdi),%ymm0
  3c19a9:	vmovups %ymm0,0x160(%rsp)
  3c19b2:	vmovups 0x60(%rdi),%ymm0
  3c19b7:	vmovdqu64 0x160(%rsp),%zmm2
  3c19c2:	vmovups %ymm0,(%rsi)
  3c19c6:	lea    0x120(%rsp),%rsi
  3c19ce:	vmovdqu 0x40(%rdi),%ymm0
  3c19d3:	vmovdqu64 %zmm2,0xe0(%rsp)
  3c19de:	vmovdqu %ymm0,0x1a0(%rsp)
  3c19e7:	vmovups 0x1a0(%rsp),%zmm1
  3c19f2:	vmovups %zmm1,(%rsi)
  3c19f8:	vmovdqu64 0xe0(%rsp),%zmm0
  3c1a03:	vmovdqu64 0x120(%rsp),%zmm1
  3c1a0e:	inc    %rdx
  3c1a11:	vmovdqu64 %zmm1,0x40(%rcx)
  3c1a18:	vmovdqu64 %zmm0,(%rcx)
  3c1a1e:	sub    $0xffffffffffffff80,%rcx
  3c1a22:	cmp    %rdx,%rbx
  3c1a25:	jne    3c1910 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x540>
  3c1a2b:	jmp    3c1a50 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x680>
  3c1a2d:	vpxor  %xmm0,%xmm0,%xmm0
  3c1a31:	vmovdqu64 %zmm0,0x120(%rsp)
  3c1a3c:	vmovdqu64 %zmm0,0xe0(%rsp)
  3c1a47:	jmp    3c19f8 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x628>
  3c1a49:	nopl   0x0(%rax)
  3c1a50:	add    %rdx,%r9
  3c1a53:	jmp    3c17f8 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x428>
  3c1a58:	mov    $0x8,%ecx
  3c1a5d:	mov    $0x80,%r8d
  3c1a63:	lea    0x50(%rsp),%rdi
  3c1a68:	mov    %r9,%rsi
  3c1a6b:	mov    %rbx,%rdx
  3c1a6e:	vzeroupper
  3c1a71:	call   37d850 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9T5c83OD6l3_10zopro_core>
  3c1a76:	mov    0x58(%rsp),%rax
  3c1a7b:	mov    0x60(%rsp),%r9
  3c1a80:	mov    %rax,0x68(%rsp)
  3c1a85:	jmp    3c18ba <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x4ea>
  3c1a8a:	lea    0x180(%rsp),%r14
  3c1a92:	movq   $0x0,0x18(%rsp)
  3c1a9b:	movq   $0x8,0x20(%rsp)
  3c1aa4:	movq   $0x0,0x30(%rsp)
  3c1aad:	movq   $0x8,0x38(%rsp)
  3c1ab6:	xor    %r9d,%r9d
  3c1ab9:	movq   $0x0,0x28(%rsp)
  3c1ac2:	movq   $0x0,0x40(%rsp)
  3c1acb:	jmp    3c1ad0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x700>
  3c1acd:	xor    %r9d,%r9d
  3c1ad0:	mov    $0x1d,%edx
  3c1ad5:	lea    0xe0(%rsp),%rdi
  3c1add:	lea    -0x1a3165(%rip),%rsi        # 21e97f <_RNvNtNtNtCs9T5c83OD6l3_10zopro_core6solver15sparse_poseidon9constants3T13+0x10d5f>
  3c1ae4:	mov    %r9,0x10(%rsp)
  3c1ae9:	vzeroupper
  3c1aec:	call   72cb40 <_RNvNtNtNtCs9k3SxhrAWiO_3std3sys3env4unix6getenv>
  3c1af1:	mov    0xe0(%rsp),%r15
  3c1af9:	mov    0xa8(%rsp),%r12
  3c1b01:	cmp    $0xffffffffffffffff,%r15
  3c1b05:	je     3c1b52 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x782>
  3c1b07:	mov    0xe8(%rsp),%rbx
  3c1b0f:	mov    0xf0(%rsp),%r14
  3c1b17:	lea    0xe0(%rsp),%rdi
  3c1b1f:	mov    %rbx,%rsi
  3c1b22:	mov    %r14,%rdx
  3c1b25:	call   6c9650 <_RNvNtNtCsgxBkk5gSRhY_4core3str8converts9from_utf8>
  3c1b2a:	cmpb   $0x0,0xe0(%rsp)
  3c1b32:	je     3c1b5e <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x78e>
  3c1b34:	mov    $0x1,%bpl
  3c1b37:	test   %r15,%r15
  3c1b3a:	jle    3c1b89 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x7b9>
  3c1b3c:	mov    %rbx,%rdi
  3c1b3f:	mov    0x40779a(%rip),%rbx        # 7c92e0 <free@GLIBC_2.2.5>
  3c1b46:	call   *%rbx
  3c1b48:	lea    0x180(%rsp),%r14
  3c1b50:	jmp    3c1ba1 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x7d1>
  3c1b52:	mov    0x407787(%rip),%rbx        # 7c92e0 <free@GLIBC_2.2.5>
  3c1b59:	mov    $0x1,%bpl
  3c1b5c:	jmp    3c1ba1 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x7d1>
  3c1b5e:	mov    $0x1,%bpl
  3c1b61:	cmp    $0x1,%r14
  3c1b65:	jne    3c1b6e <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x79e>
  3c1b67:	cmpb   $0x30,(%rbx)
  3c1b6a:	setne  %bpl
  3c1b6e:	lea    0x180(%rsp),%r14
  3c1b76:	test   %r15,%r15
  3c1b79:	je     3c1b9a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x7ca>
  3c1b7b:	mov    %rbx,%rdi
  3c1b7e:	mov    0x40775b(%rip),%rbx        # 7c92e0 <free@GLIBC_2.2.5>
  3c1b85:	call   *%rbx
  3c1b87:	jmp    3c1ba1 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x7d1>
  3c1b89:	mov    0x407750(%rip),%rbx        # 7c92e0 <free@GLIBC_2.2.5>
  3c1b90:	lea    0x180(%rsp),%r14
  3c1b98:	jmp    3c1ba1 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x7d1>
  3c1b9a:	mov    0x40773f(%rip),%rbx        # 7c92e0 <free@GLIBC_2.2.5>
  3c1ba1:	lea    0x230(%rsp),%rax
  3c1ba9:	mov    $0x408,%edx
  3c1bae:	lea    0x260(%rsp),%rdi
  3c1bb6:	mov    %bpl,0x668(%rsp)
  3c1bbe:	movq   $0x0,0x220(%rsp)
  3c1bca:	xor    %esi,%esi
  3c1bcc:	add    $0x20,%r12
  3c1bd0:	movq   $0x8,0x228(%rsp)
  3c1bdc:	vpxor  %xmm0,%xmm0,%xmm0
  3c1be0:	vmovdqu %xmm0,(%rax)
  3c1be4:	movq   $0x40,0x240(%rsp)
  3c1bf0:	vmovdqu %xmm0,0x18(%rax)
  3c1bf5:	movq   $0x40,0x258(%rsp)
  3c1c01:	call   *0x407701(%rip)        # 7c9308 <memset@GLIBC_2.2.5>
  3c1c07:	mov    0x98(%rsp),%rbp
  3c1c0f:	mov    0x40(%rsp),%r9
  3c1c14:	mov    0x38(%rsp),%r15
  3c1c19:	xor    %ecx,%ecx
  3c1c1b:	lea    0x0(,%r9,8),%rax
  3c1c23:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3c1c30:	cmp    %rcx,%rax
  3c1c33:	je     3c1c6a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x89a>
  3c1c35:	cmpq   $0x1,(%r15,%rcx,1)
  3c1c3a:	lea    0x8(%rcx),%rcx
  3c1c3e:	jbe    3c1c30 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x860>
  3c1c40:	mov    0x20(%rsp),%rdx
  3c1c45:	mov    0x28(%rsp),%rcx
  3c1c4a:	mov    0x68(%rsp),%rdi
  3c1c4f:	mov    0x10(%rsp),%rsi
  3c1c54:	lea    0x220(%rsp),%rax
  3c1c5c:	mov    %r15,%r8
  3c1c5f:	mov    %rax,(%rsp)
  3c1c63:	call   2b6790 <_RINvNtCs9T5c83OD6l3_10zopro_core3msm12reduce_layerNtNtCs9IkIP5O03Q4_11zopro_bn2545curve8G2ConfigEB4_>
  3c1c68:	jmp    3c1c0f <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x83f>
  3c1c6a:	cmpq   $0x0,0x70(%rsp)
  3c1c70:	je     3c1def <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xa1f>
  3c1c76:	mov    0x58(%rsp),%rax
  3c1c7b:	mov    0x60(%rsp),%rsi
  3c1c80:	mov    0x20(%rsp),%rcx
  3c1c85:	mov    0x28(%rsp),%rdi
  3c1c8a:	shlq   $0x7,0x70(%rsp)
  3c1c90:	xor    %edx,%edx
  3c1c92:	xor    %r8d,%r8d
  3c1c95:	data16 cs nopw 0x0(%rax,%rax,1)
  3c1ca0:	cmp    %r8,%rdi
  3c1ca3:	je     3c218a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xdba>
  3c1ca9:	mov    (%rcx,%r8,8),%r9
  3c1cad:	cmp    %rsi,%r9
  3c1cb0:	jae    3c2176 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xda6>
  3c1cb6:	shl    $0x7,%r9
  3c1cba:	vmovups (%rax,%r9,1),%zmm0
  3c1cc1:	vmovups 0x40(%rax,%r9,1),%zmm1
  3c1cc9:	vmovups %zmm1,0x120(%rsp)
  3c1cd4:	vmovups %zmm0,0xe0(%rsp)
  3c1cdf:	vmovdqu (%rax,%r9,1),%ymm0
  3c1ce5:	vptest %ymm0,%ymm0
  3c1cea:	jne    3c1d20 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x950>
  3c1cec:	vmovdqu 0x100(%rsp),%ymm0
  3c1cf5:	vptest %ymm0,%ymm0
  3c1cfa:	jne    3c1d20 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x950>
  3c1cfc:	vmovdqu 0x120(%rsp),%ymm0
  3c1d05:	vptest %ymm0,%ymm0
  3c1d0a:	jne    3c1d20 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x950>
  3c1d0c:	vmovdqu 0x140(%rsp),%ymm0
  3c1d15:	vptest %ymm0,%ymm0
  3c1d1a:	je     3c1dd3 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xa03>
  3c1d20:	add    %rax,%r9
  3c1d23:	lea    0x690(%rsp),%r10
  3c1d2b:	vmovups 0x20(%r9),%ymm0
  3c1d31:	vmovups %ymm0,(%r10)
  3c1d36:	vmovups (%r9),%ymm0
  3c1d3b:	vmovups %ymm0,0x670(%rsp)
  3c1d44:	vmovups 0x60(%r9),%ymm0
  3c1d4a:	vmovdqu64 0x670(%rsp),%zmm2
  3c1d55:	vmovups %ymm0,(%r14)
  3c1d5a:	vmovdqu 0x40(%r9),%ymm0
  3c1d60:	lea    0x1c0(%rsp),%r9
  3c1d68:	vmovdqu64 %zmm2,0x1a0(%rsp)
  3c1d73:	vmovdqu %ymm0,0x160(%rsp)
  3c1d7c:	vmovups 0x160(%rsp),%zmm1
  3c1d87:	vmovups %zmm1,0x20(%r9)
  3c1d91:	vmovdqu64 0x1a0(%rsp),%zmm0
  3c1d9c:	vmovdqu64 0x1e0(%rsp),%zmm1
  3c1da7:	mov    0xc8(%rsp),%r9
  3c1daf:	inc    %r8
  3c1db2:	add    %rdx,%r9
  3c1db5:	sub    $0xffffffffffffff80,%rdx
  3c1db9:	vmovdqu64 %zmm1,0x40(%r9)
  3c1dc0:	vmovdqu64 %zmm0,(%r9)
  3c1dc6:	cmp    %rdx,0x70(%rsp)
  3c1dcb:	jne    3c1ca0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x8d0>
  3c1dd1:	jmp    3c1def <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xa1f>
  3c1dd3:	vpxor  %xmm0,%xmm0,%xmm0
  3c1dd7:	vmovdqu64 %zmm0,0x1e0(%rsp)
  3c1de2:	vmovdqu64 %zmm0,0x1a0(%rsp)
  3c1ded:	jmp    3c1d91 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x9c1>
  3c1def:	cmpq   $0x0,0x220(%rsp)
  3c1df8:	je     3c1e07 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xa37>
  3c1dfa:	mov    0x228(%rsp),%rdi
  3c1e02:	vzeroupper
  3c1e05:	call   *%rbx
  3c1e07:	cmpq   $0x0,0x238(%rsp)
  3c1e10:	je     3c1e1f <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xa4f>
  3c1e12:	mov    0x240(%rsp),%rdi
  3c1e1a:	vzeroupper
  3c1e1d:	call   *%rbx
  3c1e1f:	cmpq   $0x0,0x250(%rsp)
  3c1e28:	je     3c1e37 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xa67>
  3c1e2a:	mov    0x258(%rsp),%rdi
  3c1e32:	vzeroupper
  3c1e35:	call   *%rbx
  3c1e37:	cmpq   $0x0,0x30(%rsp)
  3c1e3d:	je     3c1e47 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xa77>
  3c1e3f:	mov    %r15,%rdi
  3c1e42:	vzeroupper
  3c1e45:	call   *%rbx
  3c1e47:	cmpq   $0x0,0x18(%rsp)
  3c1e4d:	je     3c1e59 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xa89>
  3c1e4f:	mov    0x20(%rsp),%rdi
  3c1e54:	vzeroupper
  3c1e57:	call   *%rbx
  3c1e59:	cmpq   $0x0,0x50(%rsp)
  3c1e5f:	je     3c1e6b <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xa9b>
  3c1e61:	mov    0x58(%rsp),%rdi
  3c1e66:	vzeroupper
  3c1e69:	call   *%rbx
  3c1e6b:	cmp    0xb0(%rsp),%r12
  3c1e73:	jne    3c145f <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x8f>
  3c1e79:	jmp    3c2018 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc48>
  3c1e7e:	test   %sil,%sil
  3c1e81:	je     3c1e99 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xac9>
  3c1e83:	mov    %fs:0xfffffffffffffff8,%rax
  3c1e8c:	test   %rax,%rax
  3c1e8f:	je     3c1eaf <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xadf>
  3c1e91:	add    $0x110,%rax
  3c1e97:	jmp    3c1ec6 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xaf6>
  3c1e99:	test   %rdx,%rdx
  3c1e9c:	je     3c140a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0x3a>
  3c1ea2:	shr    $1,%rdx
  3c1ea5:	jmp    3c1eda <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xb0a>
  3c1ea7:	vzeroupper
  3c1eaa:	call   6c6da0 <_RNvNtCs6i54tJFfzR_5alloc7raw_vec17capacity_overflow>
  3c1eaf:	mov    %rdi,%r14
  3c1eb2:	mov    %rdx,%r15
  3c1eb5:	mov    %r9,%r13
  3c1eb8:	call   6e85a0 <_RNvNtCsig7U0d24r8A_10rayon_core8registry15global_registry>
  3c1ebd:	mov    %r13,%r9
  3c1ec0:	mov    %r15,%rdx
  3c1ec3:	mov    %r14,%rdi
  3c1ec6:	mov    (%rax),%rax
  3c1ec9:	shr    $1,%rdx
  3c1ecc:	mov    0x208(%rax),%rax
  3c1ed3:	cmp    %rax,%rdx
  3c1ed6:	cmovbe %rax,%rdx
  3c1eda:	sub    %rdi,%r9
  3c1edd:	mov    %rdx,0x78(%rsp)
  3c1ee2:	mov    %rdi,0xe0(%rsp)
  3c1eea:	jb     3c204f <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc7f>
  3c1ef0:	mov    %fs:0xfffffffffffffff8,%rsi
  3c1ef9:	mov    %rdi,%r14
  3c1efc:	shl    $0x5,%r14
  3c1f00:	add    %r12,%r14
  3c1f03:	test   %rsi,%rsi
  3c1f06:	je     3c1f6f <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xb9f>
  3c1f08:	lea    0x48(%rsp),%rax
  3c1f0d:	lea    0xe0(%rsp),%rdx
  3c1f15:	lea    0x78(%rsp),%rcx
  3c1f1a:	mov    %rax,0x220(%rsp)
  3c1f22:	mov    %rdx,0x228(%rsp)
  3c1f2a:	mov    %rcx,0x230(%rsp)
  3c1f32:	mov    %r14,0x238(%rsp)
  3c1f3a:	mov    %r9,0x240(%rsp)
  3c1f42:	mov    %rbx,0x248(%rsp)
  3c1f4a:	mov    %rdx,0x250(%rsp)
  3c1f52:	mov    %rcx,0x258(%rsp)
  3c1f5a:	mov    %r12,0x260(%rsp)
  3c1f62:	mov    %rdi,0x268(%rsp)
  3c1f6a:	jmp    3c2001 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc31>
  3c1f6f:	mov    %r9,%r13
  3c1f72:	mov    %rdi,%r15
  3c1f75:	call   6e85a0 <_RNvNtCsig7U0d24r8A_10rayon_core8registry15global_registry>
  3c1f7a:	mov    (%rax),%rdi
  3c1f7d:	mov    %fs:0xfffffffffffffff8,%rsi
  3c1f86:	test   %rsi,%rsi
  3c1f89:	je     3c2067 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc97>
  3c1f8f:	lea    0x48(%rsp),%rcx
  3c1f94:	mov    %r15,%rax
  3c1f97:	cmp    %rdi,0x110(%rsi)
  3c1f9e:	jne    3c20e7 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xd17>
  3c1fa4:	lea    0xe0(%rsp),%rdi
  3c1fac:	lea    0x78(%rsp),%rdx
  3c1fb1:	mov    %rcx,0x220(%rsp)
  3c1fb9:	mov    %rdi,0x228(%rsp)
  3c1fc1:	mov    %rdx,0x230(%rsp)
  3c1fc9:	mov    %r14,0x238(%rsp)
  3c1fd1:	mov    %r13,0x240(%rsp)
  3c1fd9:	mov    %rbx,0x248(%rsp)
  3c1fe1:	mov    %rdi,0x250(%rsp)
  3c1fe9:	mov    %rdx,0x258(%rsp)
  3c1ff1:	mov    %r12,0x260(%rsp)
  3c1ff9:	mov    %rax,0x268(%rsp)
  3c2001:	lea    0x220(%rsp),%rdi
  3c2009:	xor    %edx,%edx
  3c200b:	mov    %rbx,0x270(%rsp)
  3c2013:	call   3fa7b0 <_RNCINvNtCsig7U0d24r8A_10rayon_core4join12join_contextNCINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB10_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB2J_8G2ConfigEEEINtNtBY_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB3p_E0EE0NCBR_s_0uuE0B4o_>
  3c2018:	add    $0x6b8,%rsp
  3c201f:	pop    %rbx
  3c2020:	pop    %r12
  3c2022:	pop    %r13
  3c2024:	pop    %r14
  3c2026:	pop    %r15
  3c2028:	pop    %rbp
  3c2029:	vzeroupper
  3c202c:	ret
  3c202d:	mov    0xa0(%rsp),%rdx
  3c2035:	lea    0x3f1cec(%rip),%rcx        # 7b3d28 <__frame_dummy_init_array_entry+0x3920>
  3c203c:	mov    %rbp,%rdi
  3c203f:	mov    %r14,%rsi
  3c2042:	vzeroupper
  3c2045:	call   6c9850 <_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail>
  3c204a:	jmp    3c21db <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe0b>
  3c204f:	lea    -0x19f535(%rip),%rdi        # 222b21 <_RNvNvNtNtCskDkOlvfI1Ro_11miniz_oxide7inflate4core12reverse_bits20REVERSED_BITS_LOOKUP+0x1aa5>
  3c2056:	lea    0x3ff143(%rip),%rdx        # 7c11a0 <__frame_dummy_init_array_entry+0x10d98>
  3c205d:	mov    $0x13,%esi
  3c2062:	call   6c7950 <_RNvNtCsgxBkk5gSRhY_4core9panicking9panic_fmt>
  3c2067:	lea    0x48(%rsp),%rax
  3c206c:	lea    0xe0(%rsp),%rdx
  3c2074:	lea    0x78(%rsp),%rcx
  3c2079:	sub    $0xffffffffffffff80,%rdi
  3c207d:	lea    0x220(%rsp),%rsi
  3c2085:	mov    %rax,0x220(%rsp)
  3c208d:	mov    %rdx,0x228(%rsp)
  3c2095:	mov    %rcx,0x230(%rsp)
  3c209d:	mov    %r14,0x238(%rsp)
  3c20a5:	mov    %r13,0x240(%rsp)
  3c20ad:	mov    %rbx,0x248(%rsp)
  3c20b5:	mov    %rdx,0x250(%rsp)
  3c20bd:	mov    %rcx,0x258(%rsp)
  3c20c5:	mov    %r12,0x260(%rsp)
  3c20cd:	mov    %r15,0x268(%rsp)
  3c20d5:	mov    %rbx,0x270(%rsp)
  3c20dd:	call   282bb0 <_RINvMs4_NtCsig7U0d24r8A_10rayon_core8registryNtB6_8Registry14in_worker_coldNCINvNtB8_4join12join_contextNCINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB1P_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB3y_8G2ConfigEEEINtNtB1N_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB4e_E0EE0NCB1G_s_0uuE0TuuEEB5e_>
  3c20e2:	jmp    3c2018 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc48>
  3c20e7:	lea    0xe0(%rsp),%r8
  3c20ef:	lea    0x78(%rsp),%rdx
  3c20f4:	mov    %rcx,0x220(%rsp)
  3c20fc:	sub    $0xffffffffffffff80,%rdi
  3c2100:	mov    %r8,0x228(%rsp)
  3c2108:	mov    %rdx,0x230(%rsp)
  3c2110:	mov    %r14,0x238(%rsp)
  3c2118:	mov    %r13,0x240(%rsp)
  3c2120:	mov    %rbx,0x248(%rsp)
  3c2128:	mov    %r8,0x250(%rsp)
  3c2130:	mov    %rdx,0x258(%rsp)
  3c2138:	lea    0x220(%rsp),%rdx
  3c2140:	mov    %r12,0x260(%rsp)
  3c2148:	mov    %rax,0x268(%rsp)
  3c2150:	mov    %rbx,0x270(%rsp)
  3c2158:	call   29a6d0 <_RINvMs4_NtCsig7U0d24r8A_10rayon_core8registryNtB6_8Registry15in_worker_crossNCINvNtB8_4join12join_contextNCINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB1Q_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB3z_8G2ConfigEEEINtNtB1O_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB4f_E0EE0NCB1H_s_0uuE0TuuEEB5f_>
  3c215d:	jmp    3c2018 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xc48>
  3c2162:	lea    0x3f1d0f(%rip),%rdx        # 7b3e78 <__frame_dummy_init_array_entry+0x3a70>
  3c2169:	mov    %rbp,%rsi
  3c216c:	vzeroupper
  3c216f:	call   6c88eb <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
  3c2174:	jmp    3c21db <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe0b>
  3c2176:	lea    0x3f1bdb(%rip),%rax        # 7b3d58 <__frame_dummy_init_array_entry+0x3950>
  3c217d:	mov    %r9,%rdi
  3c2180:	mov    %rax,0x88(%rsp)
  3c2188:	jmp    3c218d <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xdbd>
  3c218a:	mov    %rdi,%rsi
  3c218d:	mov    0x88(%rsp),%rdx
  3c2195:	vzeroupper
  3c2198:	call   6c88eb <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
  3c219d:	jmp    3c21db <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe0b>
  3c219f:	mov    $0x8,%edi
  3c21a4:	mov    %rbx,%rsi
  3c21a7:	call   6c6c6e <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  3c21ac:	mov    $0x8,%edi
  3c21b1:	mov    %rbx,%rsi
  3c21b4:	call   6c6c6e <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  3c21b9:	jmp    3c21db <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe0b>
  3c21bb:	mov    $0x8,%eax
  3c21c0:	mov    %rax,0x90(%rsp)
  3c21c8:	mov    0x90(%rsp),%rdi
  3c21d0:	mov    %rbx,%rsi
  3c21d3:	vzeroupper
  3c21d6:	call   6c6c6e <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  3c21db:	ud2
  3c21dd:	mov    %rax,%rbx
  3c21e0:	jmp    3c2212 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe42>
  3c21e2:	jmp    3c21e8 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe18>
  3c21e4:	jmp    3c21fc <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe2c>
  3c21e6:	jmp    3c21fc <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe2c>
  3c21e8:	lea    0x220(%rsp),%rdi
  3c21f0:	mov    %rax,%rbx
  3c21f3:	call   3122e0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs9T5c83OD6l3_10zopro_core3msm7ScratchNtNtCs9IkIP5O03Q4_11zopro_bn2545curve8G2ConfigEEBG_>
  3c21f8:	jmp    3c21ff <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe2f>
  3c21fa:	jmp    3c21fc <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe2c>
  3c21fc:	mov    %rax,%rbx
  3c21ff:	cmpq   $0x0,0x30(%rsp)
  3c2205:	je     3c2212 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe42>
  3c2207:	mov    0x38(%rsp),%rdi
  3c220c:	call   *0x4070ce(%rip)        # 7c92e0 <free@GLIBC_2.2.5>
  3c2212:	cmpq   $0x0,0x18(%rsp)
  3c2218:	je     3c222a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe5a>
  3c221a:	mov    0x20(%rsp),%rdi
  3c221f:	call   *0x4070bb(%rip)        # 7c92e0 <free@GLIBC_2.2.5>
  3c2225:	jmp    3c222a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe5a>
  3c2227:	mov    %rax,%rbx
  3c222a:	cmpq   $0x0,0x50(%rsp)
  3c2230:	je     3c223d <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB8_3vec13DrainProducerTRSTjjEQSINtNtCs9IkIP5O03Q4_11zopro_bn2545curve6AffineNtB1Q_8G2ConfigEEEINtNtB6_8for_each15ForEachConsumerNCINvNtNtCs9T5c83OD6l3_10zopro_core3msm13indexed_tiles6reduceB2w_E0EEB3v_+0xe6d>
  3c2232:	mov    0x58(%rsp),%rdi
  3c2237:	call   *0x4070a3(%rip)        # 7c92e0 <free@GLIBC_2.2.5>
  3c223d:	mov    %rbx,%rdi
  3c2240:	call   7af3a0 <_Unwind_Resume@plt>
