
/home/ubuntu/src/zopro-perf-work/warm-reducer187/target/release/deps/zopro_core-0e91917ca6825209:     file format elf64-x86-64


Disassembly of section .text:

00000000003b69e0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_>:
  3b69e0:	push   %rbp
  3b69e1:	push   %r15
  3b69e3:	push   %r14
  3b69e5:	push   %r13
  3b69e7:	push   %r12
  3b69e9:	push   %rbx
  3b69ea:	sub    $0x188,%rsp
  3b69f1:	mov    0x1c0(%rsp),%rbx
  3b69f9:	mov    %rsi,0xd0(%rsp)
  3b6a01:	shr    $1,%rsi
  3b6a04:	mov    %rcx,0xd8(%rsp)
  3b6a0c:	mov    %rdi,%rbp
  3b6a0f:	mov    %r8,0xe0(%rsp)
  3b6a17:	cmp    %r8,%rsi
  3b6a1a:	jae    3b6a62 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x82>
  3b6a1c:	mov    0x10(%r9),%rdi
  3b6a20:	test   %rdi,%rdi
  3b6a23:	je     3b737d <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x99d>
  3b6a29:	mov    0x8(%r9),%r8
  3b6a2d:	mov    0x8(%rbx),%rsi
  3b6a31:	mov    0x10(%rbx),%r14
  3b6a35:	test   %r8,%r8
  3b6a38:	je     3b6a90 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xb0>
  3b6a3a:	mov    (%r9),%rax
  3b6a3d:	mov    0x18(%r9),%r9
  3b6a41:	mov    (%rbx),%r10
  3b6a44:	mov    %r8,%rcx
  3b6a47:	or     %rdi,%rcx
  3b6a4a:	shr    $0x20,%rcx
  3b6a4e:	mov    %rax,0xc0(%rsp)
  3b6a56:	je     3b6a97 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xb7>
  3b6a58:	mov    %r8,%rax
  3b6a5b:	xor    %edx,%edx
  3b6a5d:	div    %rdi
  3b6a60:	jmp    3b6a9e <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xbe>
  3b6a62:	test   %dl,%dl
  3b6a64:	je     3b6a83 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa3>
  3b6a66:	mov    %fs:0xfffffffffffffff8,%rax
  3b6a6f:	test   %rax,%rax
  3b6a72:	je     3b7152 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x772>
  3b6a78:	add    $0x110,%rax
  3b6a7e:	jmp    3b7169 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x789>
  3b6a83:	test   %rcx,%rcx
  3b6a86:	je     3b6a1c <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x3c>
  3b6a88:	shr    $1,%rcx
  3b6a8b:	jmp    3b717d <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x79d>
  3b6a90:	xor    %ecx,%ecx
  3b6a92:	jmp    3b735c <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x97c>
  3b6a97:	mov    %r8d,%eax
  3b6a9a:	xor    %edx,%edx
  3b6a9c:	div    %edi
  3b6a9e:	cmp    $0x1,%rdx
  3b6aa2:	sbb    $0xffffffffffffffff,%rax
  3b6aa6:	xor    %ecx,%ecx
  3b6aa8:	lea    (%rax,%r9,1),%rdx
  3b6aac:	sub    %r9,%rdx
  3b6aaf:	cmovb  %rcx,%rdx
  3b6ab3:	cmp    %rdx,%rax
  3b6ab6:	cmovb  %rax,%rdx
  3b6aba:	mov    %rdx,0x70(%rsp)
  3b6abf:	test   %rdx,%rdx
  3b6ac2:	je     3b735c <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x97c>
  3b6ac8:	mov    0x412819(%rip),%rcx        # 7c92e8 <calloc@GLIBC_2.2.5>
  3b6acf:	xor    %ebx,%ebx
  3b6ad1:	mov    %r8,0x30(%rsp)
  3b6ad6:	mov    %rbp,0xa0(%rsp)
  3b6ade:	mov    %rsi,0x78(%rsp)
  3b6ae3:	mov    %r14,0xa8(%rsp)
  3b6aeb:	mov    %rdi,0x98(%rsp)
  3b6af3:	mov    %r10,0x90(%rsp)
  3b6afb:	mov    (%r10),%rax
  3b6afe:	mov    0x8(%r10),%r12
  3b6b02:	cmp    %r8,%rdi
  3b6b05:	mov    %r8,%r15
  3b6b08:	mov    %rdi,%r14
  3b6b0b:	mov    $0x1,%esi
  3b6b10:	mov    %r9,0x38(%rsp)
  3b6b15:	mov    %r8,0xb8(%rsp)
  3b6b1d:	cmovb  %rdi,%r15
  3b6b21:	mov    $0x8008,%edi
  3b6b26:	mov    (%rax),%rax
  3b6b29:	mov    %rax,0x10(%rsp)
  3b6b2e:	vzeroupper
  3b6b31:	call   *%rcx
  3b6b33:	mov    %rbx,0x8(%rsp)
  3b6b38:	test   %rax,%rax
  3b6b3b:	je     3b745a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa7a>
  3b6b41:	imul   %r14,%rbx
  3b6b45:	mov    %rax,%r13
  3b6b48:	shl    $0x5,%r15
  3b6b4c:	mov    %r15,0x80(%rsp)
  3b6b54:	mov    %rbx,%rax
  3b6b57:	shl    $0x5,%rax
  3b6b5b:	add    0xc0(%rsp),%rax
  3b6b63:	mov    %rbx,0x18(%rsp)
  3b6b68:	mov    %rax,0x88(%rsp)
  3b6b70:	cmp    %rbx,0x30(%rsp)
  3b6b75:	jne    3b6cf0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x310>
  3b6b7b:	mov    0x8(%rsp),%rax
  3b6b80:	inc    %rax
  3b6b83:	mov    %rax,0xb0(%rsp)
  3b6b8b:	mov    $0x10,%eax
  3b6b90:	mov    -0x78(%r13,%rax,8),%rcx
  3b6b95:	add    -0x80(%r13,%rax,8),%rcx
  3b6b9a:	mov    %rcx,-0x78(%r13,%rax,8)
  3b6b9f:	add    -0x70(%r13,%rax,8),%rcx
  3b6ba4:	mov    %rcx,-0x70(%r13,%rax,8)
  3b6ba9:	add    -0x68(%r13,%rax,8),%rcx
  3b6bae:	mov    %rcx,-0x68(%r13,%rax,8)
  3b6bb3:	add    -0x60(%r13,%rax,8),%rcx
  3b6bb8:	mov    %rcx,-0x60(%r13,%rax,8)
  3b6bbd:	add    -0x58(%r13,%rax,8),%rcx
  3b6bc2:	mov    %rcx,-0x58(%r13,%rax,8)
  3b6bc7:	add    -0x50(%r13,%rax,8),%rcx
  3b6bcc:	mov    %rcx,-0x50(%r13,%rax,8)
  3b6bd1:	add    -0x48(%r13,%rax,8),%rcx
  3b6bd6:	mov    %rcx,-0x48(%r13,%rax,8)
  3b6bdb:	add    -0x40(%r13,%rax,8),%rcx
  3b6be0:	mov    %rcx,-0x40(%r13,%rax,8)
  3b6be5:	add    -0x38(%r13,%rax,8),%rcx
  3b6bea:	mov    %rcx,-0x38(%r13,%rax,8)
  3b6bef:	add    -0x30(%r13,%rax,8),%rcx
  3b6bf4:	mov    %rcx,-0x30(%r13,%rax,8)
  3b6bf9:	add    -0x28(%r13,%rax,8),%rcx
  3b6bfe:	mov    %rcx,-0x28(%r13,%rax,8)
  3b6c03:	add    -0x20(%r13,%rax,8),%rcx
  3b6c08:	mov    %rcx,-0x20(%r13,%rax,8)
  3b6c0d:	add    -0x18(%r13,%rax,8),%rcx
  3b6c12:	mov    %rcx,-0x18(%r13,%rax,8)
  3b6c17:	add    -0x10(%r13,%rax,8),%rcx
  3b6c1c:	mov    %rcx,-0x10(%r13,%rax,8)
  3b6c21:	add    -0x8(%r13,%rax,8),%rcx
  3b6c26:	mov    %rcx,-0x8(%r13,%rax,8)
  3b6c2b:	add    %rcx,0x0(%r13,%rax,8)
  3b6c30:	add    $0x10,%rax
  3b6c34:	cmp    $0x1010,%rax
  3b6c3a:	jne    3b6b90 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x1b0>
  3b6c40:	mov    $0x8000,%edi
  3b6c45:	vzeroupper
  3b6c48:	call   *0x412682(%rip)        # 7c92d0 <malloc@GLIBC_2.2.5>
  3b6c4e:	mov    %rax,%rbp
  3b6c51:	test   %rax,%rax
  3b6c54:	mov    0x412695(%rip),%rax        # 7c92f0 <memcpy@GLIBC_2.14>
  3b6c5b:	je     3b746b <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa8b>
  3b6c61:	mov    $0x8000,%edx
  3b6c66:	mov    %rbp,%rdi
  3b6c69:	mov    %r13,%rsi
  3b6c6c:	call   *%rax
  3b6c6e:	mov    0x8000(%r13),%rdx
  3b6c75:	movabs $0x7ffffffffffffffc,%rcx
  3b6c7f:	lea    0x0(,%rdx,4),%rbx
  3b6c87:	mov    %rdx,%rax
  3b6c8a:	shr    $0x3e,%rax
  3b6c8e:	setne  %al
  3b6c91:	cmp    %rcx,%rbx
  3b6c94:	seta   %cl
  3b6c97:	or     %al,%cl
  3b6c99:	jne    3b7143 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x763>
  3b6c9f:	mov    %rdx,(%rsp)
  3b6ca3:	test   %rbx,%rbx
  3b6ca6:	je     3b6e7e <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x49e>
  3b6cac:	mov    $0x1,%esi
  3b6cb1:	mov    %rbx,%rdi
  3b6cb4:	call   *0x41262e(%rip)        # 7c92e8 <calloc@GLIBC_2.2.5>
  3b6cba:	mov    %rax,0x20(%rsp)
  3b6cbf:	test   %rax,%rax
  3b6cc2:	je     3b747c <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa9c>
  3b6cc8:	mov    (%rsp),%rax
  3b6ccc:	mov    %rax,0x28(%rsp)
  3b6cd1:	mov    0x30(%rsp),%rax
  3b6cd6:	mov    0x18(%rsp),%rcx
  3b6cdb:	cmp    %rcx,%rax
  3b6cde:	je     3b6eb0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x4d0>
  3b6ce4:	jmp    3b6f77 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x597>
  3b6ce9:	nopl   0x0(%rax)
  3b6cf0:	mov    0x10(%rsp),%rax
  3b6cf5:	mov    $0xffffffffffffffff,%rcx
  3b6cfc:	xor    %edx,%edx
  3b6cfe:	imul   0x38(%rsp),%rax
  3b6d04:	mov    %rax,(%rsp)
  3b6d08:	jmp    3b6d26 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x346>
  3b6d0a:	nopw   0x0(%rax,%rax,1)
  3b6d10:	mov    0x80(%rsp),%r15
  3b6d18:	add    $0xc,%rcx
  3b6d1c:	cmp    $0x16,%rdx
  3b6d20:	je     3b6b7b <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x19b>
  3b6d26:	mov    %rdx,%r8
  3b6d29:	lea    0x0(,%r8,4),%eax
  3b6d31:	mov    (%rsp),%r14
  3b6d35:	mov    0x88(%rsp),%rbp
  3b6d3d:	mov    %rcx,%r9
  3b6d40:	shr    $0x6,%r9
  3b6d44:	mov    $0x1,%ebx
  3b6d49:	inc    %rdx
  3b6d4c:	lea    -0x1(%rax,%rax,2),%r10d
  3b6d51:	lea    (%rax,%rax,2),%esi
  3b6d54:	and    $0x3f,%r10d
  3b6d58:	cmp    $0x34,%r10d
  3b6d5c:	setae  %al
  3b6d5f:	cmp    $0x11,%r8
  3b6d63:	setb   %r11b
  3b6d67:	sub    %esi,%ebx
  3b6d69:	and    %al,%r11b
  3b6d6c:	and    $0x3d,%ebx
  3b6d6f:	jmp    3b6d8d <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x3ad>
  3b6d71:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3b6d80:	add    $0x20,%rbp
  3b6d84:	inc    %r14
  3b6d87:	add    $0xffffffffffffffe0,%r15
  3b6d8b:	je     3b6d10 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x330>
  3b6d8d:	test   %r8,%r8
  3b6d90:	je     3b6dd0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x3f0>
  3b6d92:	shrx   %r10,0x0(%rbp,%r9,8),%rdi
  3b6d99:	test   %r11b,%r11b
  3b6d9c:	je     3b6da8 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x3c8>
  3b6d9e:	shlx   %rbx,0x8(%rbp,%r9,8),%rax
  3b6da5:	or     %rax,%rdi
  3b6da8:	mov    %edi,%esi
  3b6daa:	and    $0x1fff,%esi
  3b6db0:	inc    %esi
  3b6db2:	shr    $1,%esi
  3b6db4:	and    $0x1000,%edi
  3b6dba:	sub    %rdi,%rsi
  3b6dbd:	je     3b6d80 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x3a0>
  3b6dbf:	jmp    3b6de8 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x408>
  3b6dc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3b6dd0:	mov    0x0(%rbp),%rsi
  3b6dd4:	and    $0xfff,%esi
  3b6dda:	lea    (%rsi,%rsi,1),%edi
  3b6ddd:	and    $0x1000,%edi
  3b6de3:	sub    %rdi,%rsi
  3b6de6:	je     3b6d80 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x3a0>
  3b6de8:	mov    0x18(%r12),%rdi
  3b6ded:	mov    0x10(%r12),%rax
  3b6df2:	imul   %r8,%rdi
  3b6df6:	add    %r14,%rdi
  3b6df9:	cmp    %rax,%rdi
  3b6dfc:	jae    3b73ca <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x9ea>
  3b6e02:	mov    0x8(%r12),%rax
  3b6e07:	shl    $0x7,%rdi
  3b6e0b:	vmovdqu (%rax,%rdi,1),%ymm0
  3b6e10:	vptest %ymm0,%ymm0
  3b6e15:	jne    3b6e50 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x470>
  3b6e17:	add    %rdi,%rax
  3b6e1a:	vmovdqu 0x20(%rax),%ymm0
  3b6e1f:	vptest %ymm0,%ymm0
  3b6e24:	jne    3b6e50 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x470>
  3b6e26:	vmovdqu 0x40(%rax),%ymm0
  3b6e2b:	vptest %ymm0,%ymm0
  3b6e30:	jne    3b6e50 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x470>
  3b6e32:	vmovdqu 0x60(%rax),%ymm0
  3b6e37:	vptest %ymm0,%ymm0
  3b6e3c:	je     3b6d80 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x3a0>
  3b6e42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3b6e50:	mov    %rsi,%rax
  3b6e53:	neg    %rax
  3b6e56:	cmovs  %rsi,%rax
  3b6e5a:	shr    $0x34,%rsi
  3b6e5e:	and    $0x800,%esi
  3b6e64:	add    %rax,%rsi
  3b6e67:	cmp    $0x1000,%rsi
  3b6e6e:	ja     3b73d6 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x9f6>
  3b6e74:	incq   0x0(%r13,%rsi,8)
  3b6e79:	jmp    3b6d80 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x3a0>
  3b6e7e:	mov    $0x4,%eax
  3b6e83:	movq   $0x0,0x28(%rsp)
  3b6e8c:	mov    %rax,0x20(%rsp)
  3b6e91:	mov    0x30(%rsp),%rax
  3b6e96:	mov    0x18(%rsp),%rcx
  3b6e9b:	cmp    %rcx,%rax
  3b6e9e:	jne    3b6f77 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x597>
  3b6ea4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  3b6eb0:	mov    0x28(%rsp),%rax
  3b6eb5:	mov    0x20(%rsp),%rdx
  3b6eba:	mov    (%rsp),%rcx
  3b6ebe:	mov    %rbp,%rdi
  3b6ec1:	mov    %rax,0x40(%rsp)
  3b6ec6:	mov    %rdx,0x48(%rsp)
  3b6ecb:	mov    %rcx,0x50(%rsp)
  3b6ed0:	movq   $0x1001,0x58(%rsp)
  3b6ed9:	mov    %r13,0x60(%rsp)
  3b6ede:	movq   $0x1001,0x68(%rsp)
  3b6ee7:	vzeroupper
  3b6eea:	call   *0x4123f0(%rip)        # 7c92e0 <free@GLIBC_2.2.5>
  3b6ef0:	mov    0x8(%rsp),%rax
  3b6ef5:	mov    0xa8(%rsp),%r14
  3b6efd:	cmp    %r14,%rax
  3b6f00:	je     3b73ad <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x9cd>
  3b6f06:	vmovdqu 0x40(%rsp),%ymm0
  3b6f0c:	vmovups 0x50(%rsp),%ymm1
  3b6f12:	mov    0x38(%rsp),%r9
  3b6f17:	mov    0xb0(%rsp),%rcx
  3b6f1f:	mov    0x78(%rsp),%rsi
  3b6f24:	mov    0x98(%rsp),%rdi
  3b6f2c:	mov    0xb8(%rsp),%r8
  3b6f34:	lea    (%rax,%rax,2),%rax
  3b6f38:	mov    0xa0(%rsp),%rbp
  3b6f40:	mov    0x90(%rsp),%r10
  3b6f48:	shl    $0x4,%rax
  3b6f4c:	sub    %rdi,%r8
  3b6f4f:	inc    %r9
  3b6f52:	mov    %rcx,%rbx
  3b6f55:	vmovups %ymm1,0x10(%rsi,%rax,1)
  3b6f5b:	vmovdqu %ymm0,(%rsi,%rax,1)
  3b6f60:	cmp    0x70(%rsp),%rcx
  3b6f65:	mov    0x41237c(%rip),%rcx        # 7c92e8 <calloc@GLIBC_2.2.5>
  3b6f6c:	jne    3b6afb <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x11b>
  3b6f72:	jmp    3b7357 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x977>
  3b6f77:	mov    0x10(%rsp),%rax
  3b6f7c:	mov    $0xffffffffffffffff,%r8
  3b6f83:	xor    %edx,%edx
  3b6f85:	imul   0x38(%rsp),%rax
  3b6f8b:	mov    %rax,0x10(%rsp)
  3b6f90:	jmp    3b6fbb <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x5db>
  3b6f92:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  3b6fa0:	mov    0x18(%rsp),%r8
  3b6fa5:	mov    0xc8(%rsp),%rdx
  3b6fad:	add    $0xc,%r8
  3b6fb1:	cmp    $0x16,%rdx
  3b6fb5:	je     3b6eb0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x4d0>
  3b6fbb:	lea    0x1(%rdx),%rax
  3b6fbf:	mov    %r8,0x18(%rsp)
  3b6fc4:	shr    $0x6,%r8
  3b6fc8:	mov    $0x1,%r11d
  3b6fce:	mov    0x80(%rsp),%rbx
  3b6fd6:	mov    %rax,0xc8(%rsp)
  3b6fde:	lea    0x0(,%rdx,4),%eax
  3b6fe5:	lea    -0x1(%rax,%rax,2),%r9d
  3b6fea:	lea    (%rax,%rax,2),%ecx
  3b6fed:	and    $0x3f,%r9d
  3b6ff1:	cmp    $0x34,%r9d
  3b6ff5:	setae  %al
  3b6ff8:	cmp    $0x11,%rdx
  3b6ffc:	setb   %r10b
  3b7000:	sub    %ecx,%r11d
  3b7003:	mov    0x10(%rsp),%rcx
  3b7008:	and    %al,%r10b
  3b700b:	mov    0x88(%rsp),%rax
  3b7013:	and    $0x3d,%r11d
  3b7017:	jmp    3b7031 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x651>
  3b7019:	nopl   0x0(%rax)
  3b7020:	add    $0x20,%rax
  3b7024:	inc    %rcx
  3b7027:	add    $0xffffffffffffffe0,%rbx
  3b702b:	je     3b6fa0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x5c0>
  3b7031:	test   %rdx,%rdx
  3b7034:	je     3b7070 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x690>
  3b7036:	shrx   %r9,(%rax,%r8,8),%rsi
  3b703c:	test   %r10b,%r10b
  3b703f:	je     3b704b <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x66b>
  3b7041:	shlx   %r11,0x8(%rax,%r8,8),%rdi
  3b7048:	or     %rdi,%rsi
  3b704b:	mov    %esi,%r14d
  3b704e:	and    $0x1fff,%r14d
  3b7055:	inc    %r14d
  3b7058:	shr    $1,%r14d
  3b705b:	and    $0x1000,%esi
  3b7061:	sub    %rsi,%r14
  3b7064:	je     3b7020 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x640>
  3b7066:	jmp    3b7089 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x6a9>
  3b7068:	nopl   0x0(%rax,%rax,1)
  3b7070:	mov    (%rax),%r14
  3b7073:	and    $0xfff,%r14d
  3b707a:	lea    (%r14,%r14,1),%esi
  3b707e:	and    $0x1000,%esi
  3b7084:	sub    %rsi,%r14
  3b7087:	je     3b7020 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x640>
  3b7089:	mov    0x18(%r12),%r15
  3b708e:	mov    0x10(%r12),%rsi
  3b7093:	mov    %rdx,%rdi
  3b7096:	imul   %r15,%rdi
  3b709a:	add    %rcx,%rdi
  3b709d:	cmp    %rsi,%rdi
  3b70a0:	jae    3b742b <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa4b>
  3b70a6:	mov    0x8(%r12),%rsi
  3b70ab:	shl    $0x7,%rdi
  3b70af:	vmovdqu (%rsi,%rdi,1),%ymm0
  3b70b4:	vptest %ymm0,%ymm0
  3b70b9:	jne    3b70f0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x710>
  3b70bb:	add    %rdi,%rsi
  3b70be:	vmovdqu 0x20(%rsi),%ymm0
  3b70c3:	vptest %ymm0,%ymm0
  3b70c8:	jne    3b70f0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x710>
  3b70ca:	vmovdqu 0x40(%rsi),%ymm0
  3b70cf:	vptest %ymm0,%ymm0
  3b70d4:	jne    3b70f0 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x710>
  3b70d6:	vmovdqu 0x60(%rsi),%ymm0
  3b70db:	vptest %ymm0,%ymm0
  3b70e0:	je     3b7020 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x640>
  3b70e6:	cs nopw 0x0(%rax,%rax,1)
  3b70f0:	mov    %r14,%rsi
  3b70f3:	neg    %rsi
  3b70f6:	cmovs  %r14,%rsi
  3b70fa:	shr    $0x34,%r14
  3b70fe:	and    $0x800,%r14d
  3b7105:	lea    -0x1(%rsi,%r14,1),%rdi
  3b710a:	cmp    $0xfff,%rdi
  3b7111:	ja     3b7444 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa64>
  3b7117:	mov    0x0(%rbp,%rdi,8),%rsi
  3b711c:	cmp    (%rsp),%rsi
  3b7120:	jae    3b7434 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa54>
  3b7126:	mov    0x20(%rsp),%r14
  3b712b:	imul   %edx,%r15d
  3b712f:	add    %ecx,%r15d
  3b7132:	mov    %r15d,(%r14,%rsi,4)
  3b7136:	inc    %rsi
  3b7139:	mov    %rsi,0x0(%rbp,%rdi,8)
  3b713e:	jmp    3b7020 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x640>
  3b7143:	xor    %edi,%edi
  3b7145:	mov    %rbx,%rsi
  3b7148:	call   6c6c6e <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  3b714d:	jmp    3b747a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa9a>
  3b7152:	mov    %rsi,%r14
  3b7155:	mov    %r9,%r12
  3b7158:	mov    %rcx,%r15
  3b715b:	call   6e85a0 <_RNvNtCsig7U0d24r8A_10rayon_core8registry15global_registry>
  3b7160:	mov    %r15,%rcx
  3b7163:	mov    %r12,%r9
  3b7166:	mov    %r14,%rsi
  3b7169:	mov    (%rax),%rax
  3b716c:	shr    $1,%rcx
  3b716f:	mov    0x208(%rax),%rax
  3b7176:	cmp    %rax,%rcx
  3b7179:	cmovbe %rax,%rcx
  3b717d:	mov    0x10(%rbx),%rax
  3b7181:	mov    %rcx,0xd8(%rsp)
  3b7189:	mov    %rsi,0xe8(%rsp)
  3b7191:	sub    %rsi,%rax
  3b7194:	jb     3b7395 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x9b5>
  3b719a:	mov    0x10(%r9),%rcx
  3b719e:	mov    0x8(%r9),%r10
  3b71a2:	mov    (%rbx),%r14
  3b71a5:	mov    (%r9),%rdi
  3b71a8:	mov    0x18(%r9),%rdx
  3b71ac:	mov    0x8(%rbx),%rbx
  3b71b0:	lea    (%rsi,%rsi,2),%r15
  3b71b4:	lea    0xd0(%rsp),%r12
  3b71bc:	lea    0xd8(%rsp),%r13
  3b71c4:	mov    %r12,0xf0(%rsp)
  3b71cc:	lea    0xe8(%rsp),%r12
  3b71d4:	mov    %r12,0xf8(%rsp)
  3b71dc:	mov    %r13,0x100(%rsp)
  3b71e4:	mov    %rcx,%r8
  3b71e7:	imul   %rsi,%r8
  3b71eb:	lea    (%rdx,%rsi,1),%r9
  3b71ef:	cmp    %r8,%r10
  3b71f2:	cmovb  %r10,%r8
  3b71f6:	shl    $0x4,%r15
  3b71fa:	mov    %r8,%r11
  3b71fd:	shl    $0x5,%r11
  3b7201:	sub    %r8,%r10
  3b7204:	add    %rbx,%r15
  3b7207:	add    %rdi,%r11
  3b720a:	mov    %r11,0x108(%rsp)
  3b7212:	mov    %r10,0x110(%rsp)
  3b721a:	mov    %rcx,0x118(%rsp)
  3b7222:	mov    %r9,0x120(%rsp)
  3b722a:	mov    %r14,0x128(%rsp)
  3b7232:	mov    %r15,0x130(%rsp)
  3b723a:	mov    %rax,0x138(%rsp)
  3b7242:	mov    %r12,0x140(%rsp)
  3b724a:	mov    %r13,0x148(%rsp)
  3b7252:	mov    %rdi,0x150(%rsp)
  3b725a:	mov    %r8,0x158(%rsp)
  3b7262:	mov    %rcx,0x160(%rsp)
  3b726a:	mov    %rdx,0x168(%rsp)
  3b7272:	mov    %fs:0xfffffffffffffff8,%rdx
  3b727b:	mov    %r14,0x170(%rsp)
  3b7283:	mov    %rbx,0x178(%rsp)
  3b728b:	mov    %rsi,0x180(%rsp)
  3b7293:	test   %rdx,%rdx
  3b7296:	jne    3b72bf <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x8df>
  3b7298:	call   6e85a0 <_RNvNtCsig7U0d24r8A_10rayon_core8registry15global_registry>
  3b729d:	mov    (%rax),%rsi
  3b72a0:	mov    %fs:0xfffffffffffffff8,%rdx
  3b72a9:	test   %rdx,%rdx
  3b72ac:	je     3b73f5 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa15>
  3b72b2:	cmp    %rsi,0x110(%rdx)
  3b72b9:	jne    3b7410 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa30>
  3b72bf:	lea    0x40(%rsp),%rdi
  3b72c4:	lea    0xf0(%rsp),%rsi
  3b72cc:	xor    %ecx,%ecx
  3b72ce:	call   41ab70 <_RNCINvNtCsig7U0d24r8A_10rayon_core4join12join_contextNCINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtBY_9enumerate17EnumerateProducerINtNtNtB10_5slice6chunks14ChunksProducerAyj4_EEINtNtBY_3map11MapConsumerINtNtNtBY_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB4A_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB5l_5Table14route_parallel0EE0NCBR_s_0INtB3T_13CollectResultB4y_EB6V_E0B5p_>
  3b72d3:	mov    0x50(%rsp),%rcx
  3b72d8:	vmovdqu 0x48(%rsp),%xmm0
  3b72de:	mov    0x40(%rsp),%rax
  3b72e3:	mov    0x58(%rsp),%rbx
  3b72e8:	lea    (%rcx,%rcx,2),%rcx
  3b72ec:	shl    $0x4,%rcx
  3b72f0:	add    %rax,%rcx
  3b72f3:	cmp    %rbx,%rcx
  3b72f6:	je     3b7346 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x966>
  3b72f8:	mov    0x68(%rsp),%r14
  3b72fd:	mov    %rax,0x0(%rbp)
  3b7301:	vmovdqu %xmm0,0x8(%rbp)
  3b7306:	test   %r14,%r14
  3b7309:	je     3b7368 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x988>
  3b730b:	mov    0x411fce(%rip),%r15        # 7c92e0 <free@GLIBC_2.2.5>
  3b7312:	add    $0x20,%rbx
  3b7316:	jmp    3b7329 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x949>
  3b7318:	nopl   0x0(%rax,%rax,1)
  3b7320:	add    $0x30,%rbx
  3b7324:	dec    %r14
  3b7327:	je     3b7368 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x988>
  3b7329:	cmpq   $0x0,-0x20(%rbx)
  3b732e:	je     3b7337 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x957>
  3b7330:	mov    -0x18(%rbx),%rdi
  3b7334:	call   *%r15
  3b7337:	cmpq   $0x0,-0x8(%rbx)
  3b733c:	je     3b7320 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x940>
  3b733e:	mov    (%rbx),%rdi
  3b7341:	call   *%r15
  3b7344:	jmp    3b7320 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x940>
  3b7346:	vpaddq 0x60(%rsp),%xmm0,%xmm0
  3b734c:	mov    %rax,0x0(%rbp)
  3b7350:	vmovdqu %xmm0,0x8(%rbp)
  3b7355:	jmp    3b7368 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x988>
  3b7357:	mov    0x70(%rsp),%rcx
  3b735c:	mov    %rsi,0x0(%rbp)
  3b7360:	mov    %r14,0x8(%rbp)
  3b7364:	mov    %rcx,0x10(%rbp)
  3b7368:	add    $0x188,%rsp
  3b736f:	pop    %rbx
  3b7370:	pop    %r12
  3b7372:	pop    %r13
  3b7374:	pop    %r14
  3b7376:	pop    %r15
  3b7378:	pop    %rbp
  3b7379:	vzeroupper
  3b737c:	ret
  3b737d:	lea    -0x36a1fc(%rip),%rdi        # 4d188 <GCC_except_table0+0xf5ec>
  3b7384:	lea    0x409d7d(%rip),%rdx        # 7c1108 <__frame_dummy_init_array_entry+0x10d00>
  3b738b:	mov    $0x37,%esi
  3b7390:	call   6c7950 <_RNvNtCsgxBkk5gSRhY_4core9panicking9panic_fmt>
  3b7395:	lea    -0x198a5d(%rip),%rdi        # 21e93f <_RNvNtNtNtCs9T5c83OD6l3_10zopro_core6solver15sparse_poseidon9constants3T13+0x10d1f>
  3b739c:	lea    0x409d95(%rip),%rdx        # 7c1138 <__frame_dummy_init_array_entry+0x10d30>
  3b73a3:	mov    $0x1e,%esi
  3b73a8:	call   6c9920 <_RNvNtCsgxBkk5gSRhY_4core9panicking5panic>
  3b73ad:	lea    -0x198a57(%rip),%rdi        # 21e95d <_RNvNtNtNtCs9T5c83OD6l3_10zopro_core6solver15sparse_poseidon9constants3T13+0x10d3d>
  3b73b4:	lea    0x409d95(%rip),%rdx        # 7c1150 <__frame_dummy_init_array_entry+0x10d48>
  3b73bb:	mov    $0x45,%esi
  3b73c0:	call   6c7950 <_RNvNtCsgxBkk5gSRhY_4core9panicking9panic_fmt>
  3b73c5:	jmp    3b747a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa9a>
  3b73ca:	lea    0x3fcfe7(%rip),%rdx        # 7b43b8 <__frame_dummy_init_array_entry+0x3fb0>
  3b73d1:	mov    %rdi,%rsi
  3b73d4:	jmp    3b73e2 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa02>
  3b73d6:	mov    $0x1001,%eax
  3b73db:	lea    0x3fcfee(%rip),%rdx        # 7b43d0 <__frame_dummy_init_array_entry+0x3fc8>
  3b73e2:	mov    %rsi,%rdi
  3b73e5:	mov    %rax,%rsi
  3b73e8:	vzeroupper
  3b73eb:	call   6c88eb <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
  3b73f0:	jmp    3b747a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa9a>
  3b73f5:	sub    $0xffffffffffffff80,%rsi
  3b73f9:	lea    0x40(%rsp),%rdi
  3b73fe:	lea    0xf0(%rsp),%rdx
  3b7406:	call   280450 <_RINvMs4_NtCsig7U0d24r8A_10rayon_core8registryNtB6_8Registry14in_worker_coldNCINvNtB8_4join12join_contextNCINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB1N_9enumerate17EnumerateProducerINtNtNtB1P_5slice6chunks14ChunksProducerAyj4_EEINtNtB1N_3map11MapConsumerINtNtNtB1N_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB5s_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB6d_5Table14route_parallel0EE0NCB1G_s_0INtB4K_13CollectResultB5q_EB7O_E0TB7O_B7O_EEB6h_>
  3b740b:	jmp    3b72d3 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x8f3>
  3b7410:	sub    $0xffffffffffffff80,%rsi
  3b7414:	lea    0x40(%rsp),%rdi
  3b7419:	lea    0xf0(%rsp),%rcx
  3b7421:	call   297a60 <_RINvMs4_NtCsig7U0d24r8A_10rayon_core8registryNtB6_8Registry15in_worker_crossNCINvNtB8_4join12join_contextNCINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB1O_9enumerate17EnumerateProducerINtNtNtB1Q_5slice6chunks14ChunksProducerAyj4_EEINtNtB1O_3map11MapConsumerINtNtNtB1O_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB5t_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB6e_5Table14route_parallel0EE0NCB1H_s_0INtB4L_13CollectResultB5r_EB7P_E0TB7P_B7P_EEB6i_>
  3b7426:	jmp    3b72d3 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x8f3>
  3b742b:	lea    0x3fcf3e(%rip),%rdx        # 7b4370 <__frame_dummy_init_array_entry+0x3f68>
  3b7432:	jmp    3b7450 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa70>
  3b7434:	mov    %rsi,%rdi
  3b7437:	mov    (%rsp),%rsi
  3b743b:	lea    0x3fcf5e(%rip),%rdx        # 7b43a0 <__frame_dummy_init_array_entry+0x3f98>
  3b7442:	jmp    3b7450 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa70>
  3b7444:	mov    $0x1000,%esi
  3b7449:	lea    0x3fcf38(%rip),%rdx        # 7b4388 <__frame_dummy_init_array_entry+0x3f80>
  3b7450:	vzeroupper
  3b7453:	call   6c88eb <_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check>
  3b7458:	jmp    3b747a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa9a>
  3b745a:	mov    $0x8,%edi
  3b745f:	mov    $0x8008,%esi
  3b7464:	call   6c6c6e <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  3b7469:	jmp    3b747a <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xa9a>
  3b746b:	mov    $0x8,%edi
  3b7470:	mov    $0x8000,%esi
  3b7475:	call   6c6c6e <_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error>
  3b747a:	ud2
  3b747c:	mov    $0x4,%edi
  3b7481:	jmp    3b7145 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0x765>
  3b7486:	jmp    3b74b9 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xad9>
  3b7488:	mov    %rax,%rbx
  3b748b:	jmp    3b74d3 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xaf3>
  3b748d:	lea    0x40(%rsp),%rdi
  3b7492:	mov    %rax,%rbx
  3b7495:	call   318800 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs9T5c83OD6l3_10zopro_core3fft7WeightsEBF_>
  3b749a:	mov    %r14,0x8(%rsp)
  3b749f:	jmp    3b74d3 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xaf3>
  3b74a1:	cmpq   $0x0,0x28(%rsp)
  3b74a7:	mov    %rax,%rbx
  3b74aa:	je     3b74c1 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xae1>
  3b74ac:	mov    0x20(%rsp),%rdi
  3b74b1:	call   *0x411e29(%rip)        # 7c92e0 <free@GLIBC_2.2.5>
  3b74b7:	jmp    3b74c1 <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xae1>
  3b74b9:	mov    %rax,%rbx
  3b74bc:	jmp    3b74ca <_RINvNvNtNtCscaDhLUuI3PM_5rayon4iter8plumbing24bridge_producer_consumer6helperINtNtB6_9enumerate17EnumerateProducerINtNtNtB8_5slice6chunks14ChunksProducerAyj4_EEINtNtB6_3map11MapConsumerINtNtNtB6_7collect8consumer15CollectConsumerTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB3H_jEEENCNvMNtNtCs9T5c83OD6l3_10zopro_core10msm_affine14server_shiftedNtB4s_5Table14route_parallel0EEB4w_+0xaea>
  3b74be:	mov    %rax,%rbx
  3b74c1:	mov    %rbp,%rdi
  3b74c4:	call   *0x411e16(%rip)        # 7c92e0 <free@GLIBC_2.2.5>
  3b74ca:	mov    %r13,%rdi
  3b74cd:	call   *0x411e0d(%rip)        # 7c92e0 <free@GLIBC_2.2.5>
  3b74d3:	mov    0x78(%rsp),%rdi
  3b74d8:	mov    0x8(%rsp),%rsi
  3b74dd:	call   3180b0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtNtNtCscaDhLUuI3PM_5rayon4iter7collect8consumer13CollectResultTINtNtCs6i54tJFfzR_5alloc3vec3VecmEIB1H_jEEEECs9T5c83OD6l3_10zopro_core>
  3b74e2:	mov    %rbx,%rdi
  3b74e5:	call   7af3a0 <_Unwind_Resume@plt>
