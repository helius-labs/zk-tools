#[test]#[ignore]fn warm_fifo_profile(){
 let arm=std::env::var("WARM_QUERY_ARM").unwrap();assert!(["current","parallel"].contains(&arm.as_str()));let rounds=251usize;
 let pool=rayon::ThreadPoolBuilder::new().num_threads(32).start_handler(|i|unsafe{let mut set:libc::cpu_set_t=std::mem::zeroed();libc::CPU_ZERO(&mut set);libc::CPU_SET(i,&mut set);assert_eq!(libc::sched_setaffinity(0,std::mem::size_of_val(&set),&set),0);}).build().unwrap();
 let(p,w,expected)=fixture("1x2");let table=if arm=="parallel"{Some(pool.install(||Table::new(&p,usize::MAX).unwrap()))}else{None};
 let run=||pool.install(||{let mut words=w.clone();let result=if let Some(t)=&table{t.apply_mode(&words,true).0}else{super::super::g2_query_exclusive(&p,&mut words)};result.to_affine()});
 let hash=|p:zopro_bn254::G2Affine|{let mut h=Sha256::new();for f in[p.x.c0,p.x.c1,p.y.c0,p.y.c1]{for w in f.to_canonical(){h.update(w.to_le_bytes());}}format!("{:x}",h.finalize())};
 for _ in 0..3{assert_eq!(hash(run()),expected);}let mut results=Vec::with_capacity(rounds);let mut samples=Vec::with_capacity(rounds);let mut control=super::warm_perf::Control::from_env().unwrap();if let Some(c)=control.as_mut(){c.enable().unwrap();}
 let before=super::warm_perf::Usage::now().unwrap();let start=Instant::now();for _ in 0..rounds{let t=Instant::now();results.push(std::hint::black_box(run()));samples.push(t.elapsed().as_nanos()as u64);}let elapsed=start.elapsed().as_nanos()as u64;let after=super::warm_perf::Usage::now().unwrap();if let Some(c)=control.as_mut(){c.disable().unwrap();}
 for p in results{assert_eq!(hash(p),expected);}println!("WARM {}",format!("{{\"arm\":\"{arm}\",\"rounds\":{rounds},\"elapsed_ns\":{elapsed},\"samples_ns\":{samples:?},\"usage\":{}}}",after.difference(&before)));}
