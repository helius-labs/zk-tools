use zopro_bn254::{Affine,CurveConfig,Field,Projective};
pub fn original<C: CurveConfig>(left: &Projective<C>, other: &Affine<C>) -> Projective<C> {
        if other.is_identity() {
            return *left;
        }
        if left.is_identity() {
            return other.to_projective();
        }
        let z1z1 = left.z.square();
        let u2 = other.x * z1z1;
        let s2 = other.y * left.z * z1z1;
        if left.x == u2 {
            return if left.y == s2 { left.double() } else { Projective::IDENTITY };
        }
        let h = u2 - left.x;
        let hh = h.square();
        let i = hh.double().double();
        let j = h * i;
        let r = (s2 - left.y).double();
        let v = left.x * i;
        let x = r.square() - j - v.double();
        let y = r * (v - x) - (left.y * j).double();
        let z = (left.z + h).square() - z1z1 - hh;
        Projective::new(x, y, z)
    }
