use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path,collections::BTreeMap};
const R:&str="/home/ubuntu/src/zopro-perf-work/unit-z-native176";const Z:&str="/home/ubuntu/src/zk-tools/zopro";const P:&str="/home/ubuntu/src/zopro-perf-work/unit-z-mixed176";
fn read(p:impl AsRef<Path>)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}fn hash(p:impl AsRef<Path>)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}fn save(n:&str,v:Value){fs::write(format!("{R}/{n}"),serde_json::to_vec_pretty(&v).unwrap()).unwrap()}
fn main(){
 assert!(!Path::new(&format!("{R}/source")).exists());let manifest=format!("{Z}/docs/benchmarks/2026-11-09-busy-reset-adoption176/artifacts/production-source-manifest.json");let m=read(&manifest);assert_eq!(m["adopted"],true);let originals=m["source_files_sha256"].as_object().unwrap();assert_eq!(originals.len(),176);let mut pins=BTreeMap::new();
 for(rel,h)in originals{let from=format!("{Z}/{rel}");assert_eq!(hash(&from),h.as_str().unwrap());pins.insert(from.clone(),h.clone());let to=format!("{R}/source/{rel}");fs::create_dir_all(Path::new(&to).parent().unwrap()).unwrap();fs::copy(from,to).unwrap();}
 let rel="crates/zopro-bn254/src/curve.rs";let p=format!("{R}/source/{rel}");let original=fs::read_to_string(&p).unwrap();let start=original.find("    pub fn add_affine(&self, other: &Affine<C>) -> Self {").unwrap();let end=start+original[start..].find("\n    pub fn to_affine(").unwrap();let body=&original[start..end];assert!(body.ends_with("    }\n"));let reference=body.replace("    pub fn add_affine(&self, other: &Affine<C>) -> Self {","pub fn original<C: CurveConfig>(left: &Projective<C>, other: &Affine<C>) -> Projective<C> {").replace("self.","left.").replace("*self","*left").replace("Self::","Projective::");fs::write(format!("{R}/reference.rs"),format!("use zopro_bn254::{{Affine,CurveConfig,Field,Projective}};\n{reference}")).unwrap();
 let before="        let z1z1 = self.z.square();\n        let u2 = other.x * z1z1;";
 assert_eq!(original.matches(before).count(),1);
 let inserted=r#"        #[cfg(zopro_unit_z_mixed)]
        if self.z == C::Base::ONE {
            if self.x == other.x {
                return if self.y == other.y { self.double() } else { Self::IDENTITY };
            }
            let h = other.x - self.x;
            let hh = h.square();
            let i = hh.double().double();
            let j = h * i;
            let r = (other.y - self.y).double();
            let v = self.x * i;
            let x = r.square() - j - v.double();
            let y = r * (v - x) - (self.y * j).double();
            return Self::new(x, y, h.double());
        }
"#;
 let after=format!("{inserted}{before}");fs::write(p,original.replace(before,&after)).unwrap();
 save("source-audit.json",json!({"originals":originals,"path":rel,"before":before,"after":after,"inserted":inserted,"original_method":body,"reference_method":reference,"exact_originals":175,"recoverable_originals":1,"new_production_children":0,"production_changed":false,"private_cfg":"zopro_unit_z_mixed","OFF_original_body_literal":true,"original_identity_guards_shared":true,"nonunit_general_body_literal":true}));
 let q=fs::read_to_string(format!("{P}/qualification.rs")).unwrap();
 let q=q.replace("mod kernel;","mod reference;\n#[unsafe(no_mangle)] #[inline(never)] pub fn actual_g1(a:&zopro_bn254::G1Projective,b:&zopro_bn254::G1Affine)->zopro_bn254::G1Projective{a.add_affine(b)}\n#[unsafe(no_mangle)] #[inline(never)] pub fn actual_g2(a:&zopro_bn254::G2Projective,b:&zopro_bn254::G2Affine)->zopro_bn254::G2Projective{a.add_affine(b)}")
 .replace("let original = left.add_affine(&right);","let original = reference::original(&left,&right);")
 .replace("let original = actual.add_affine(&native);","let original = reference::original(&actual,&native);")
 .replace("kernel::add(&actual,&native)","actual.add_affine(&native)")
 .replace("kernel::add(&weird,&id)","weird.add_affine(&id)")
 .replace("kernel::unit_z_mixed_g1","actual_g1").replace("kernel::unit_z_mixed_g2","actual_g2");
 assert!(!q.contains("kernel::"));let q=q.replace("fn exact_and_independent_group_outputs() {","fn exact_and_independent_group_outputs() {\n    assert_eq!((core::mem::size_of::<zopro_bn254::G1Affine>(),core::mem::size_of::<zopro_bn254::G1Projective>(),core::mem::size_of::<zopro_bn254::G2Affine>(),core::mem::size_of::<zopro_bn254::G2Projective>()),(64,96,128,192));");fs::write(format!("{R}/qualification.rs"),q).unwrap();
 let field_template=read("/home/ubuntu/src/zopro-perf-work/inverse-seed-native176/native-plan.json")["steps"][0].clone();let test_template=read(format!("{P}/plan.json"))["steps"][0].clone();let mut steps=Vec::new();
 for arm in["OFF","ON","generic-ON"]{
  let generic=arm=="generic-ON";fs::create_dir_all(format!("{R}/libs/{arm}")).unwrap();let mut field=field_template.clone();for v in field["argv"].as_array_mut().unwrap(){let t=v.as_str().unwrap().replace("/home/ubuntu/src/zopro-perf-work/inverse-seed-native176/source",&format!("{R}/source")).replace("/home/ubuntu/src/zopro-perf-work/inverse-seed-native176/native/on/libzopro_bn254.rlib",&format!("{R}/libs/{arm}/libzopro_bn254.rlib"));*v=json!(if generic{t.replace("target-cpu=native","target-cpu=generic")}else{t});}let a=field["argv"].as_array_mut().unwrap();a.extend([json!("-C"),json!(format!("metadata=unit_z_native176_field_{arm}"))]);if arm!="OFF"{a.extend([json!("--cfg"),json!("zopro_unit_z_mixed")]);}if generic{a.extend([json!("--cfg"),json!("no_asm"),json!("--cfg"),json!("no_ifma")]);}field["name"]=json!(format!("field-{arm}"));steps.push(field);
  let mut test=test_template.clone();for v in test["argv"].as_array_mut().unwrap(){let t=v.as_str().unwrap().replace(&format!("{P}/qualification.rs"),&format!("{R}/qualification.rs")).replace(&format!("{P}/qualification"),&format!("{R}/qualification-{arm}"));*v=json!(if t.starts_with("zopro_bn254="){format!("zopro_bn254={R}/libs/{arm}/libzopro_bn254.rlib")}else if generic{t.replace("target-cpu=native","target-cpu=generic")}else{t});}if generic{let a=test["argv"].as_array_mut().unwrap();let at=a.iter().position(|v|v=="unit_z_native_test").unwrap();a.drain(at-1..at+1);a.extend([json!("--cfg"),json!("no_asm"),json!("--cfg"),json!("no_ifma")]);}test["name"]=json!(format!("consumer-{arm}"));steps.push(test);steps.push(json!({"kind":"command","name":format!("qualify-{arm}"),"argv":[format!("{R}/qualification-{arm}"),"--nocapture","--test-threads=1"],"timeout_seconds":600}));
 }
 for arm in["OFF","ON"]{steps.push(json!({"kind":"command","name":format!("decode-{arm}"),"argv":["objdump","-d","-C",format!("{R}/qualification-{arm}")],"timeout_seconds":120}));}assert_eq!(steps.len(),11);
 for(rel,_)in originals{let p=format!("{R}/source/{rel}");pins.insert(p.clone(),json!(hash(p)));}for f in["design.md","prepare.rs","prepare","reference.rs","qualification.rs","source-audit.json"]{let p=format!("{R}/{f}");pins.insert(p.clone(),json!(hash(p)));}for p in[manifest,format!("{P}/qualification.rs"),format!("{P}/review-result.json"),"/home/ubuntu/src/zopro-perf-work/unit-z-census176/review-result.json".into()]{pins.insert(p.clone(),json!(hash(p)));}for s in &steps{for v in s["argv"].as_array().unwrap(){let t=v.as_str().unwrap();let p=t.split_once('=').map_or(t,|(_,p)|p);if Path::new(p).is_file(){pins.insert(p.into(),json!(hash(p)));}}}
 save("plan.json",json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps}));pins.insert(format!("{R}/plan.json"),json!(hash(format!("{R}/plan.json"))));save("pins.json",json!(pins));println!("Integratedaftersharedidentityguards/1reversiblefile;11commands/nativeOFFON+genericONactualmethodoracles/decode;no clocks/proofs");
}
