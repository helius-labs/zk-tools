
/home/ubuntu/src/zopro-perf-work/beta-fixed176/frozen-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000038950 <_RNvCs3zmp2RFaYZ5_6driver5fixed>:
   38950:	cmp    $0x4,%rsi
   38954:	jb     38980 <_RNvCs3zmp2RFaYZ5_6driver6scalar>
   3895a:	push   %rax
   3895b:	lea    -0x2f1ad(%rip),%rdi        # 97b5 <_RNvNvNtNtCshdGlst1c7nL_10serde_json3ser9Formatter17write_char_escape10HEX_DIGITS+0x3765>
   38962:	lea    0x490ff(%rip),%rdx        # 81a68 <__frame_dummy_init_array_entry+0x8>
   38969:	mov    $0x55,%esi
   3896e:	call   41970 <_RNvNtCsgxBkk5gSRhY_4core9panicking9panic_fmt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
