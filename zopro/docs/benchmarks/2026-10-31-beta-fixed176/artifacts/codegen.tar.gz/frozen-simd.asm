
/home/ubuntu/src/zopro-perf-work/beta-fixed176/frozen-sdk:     file format elf64-x86-64


Disassembly of section .text:

0000000000038250 <_RNvCs3zmp2RFaYZ5_6driver4simd>:
   38250:	movabs $0xfffffffffffffc,%rax
   3825a:	and    %rsi,%rax
   3825d:	je     38936 <_RNvCs3zmp2RFaYZ5_6driver4simd+0x6e6>
   38263:	vmovaps -0x329eb(%rip),%ymm0        # 5880 <GCC_except_table554+0xd0>
   3826b:	vmovdqa64 -0x32735(%rip),%zmm1        # 5b40 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x260>
   38275:	vmovdqa64 -0x326ff(%rip),%zmm2        # 5b80 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x2a0>
   3827f:	vpbroadcastq -0x32869(%rip),%zmm3        # 5a20 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x140>
   38289:	vpbroadcastq -0x3277b(%rip),%zmm4        # 5b18 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x238>
   38293:	vpbroadcastq -0x3279d(%rip),%zmm5        # 5b00 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x220>
   3829d:	vpbroadcastq -0x32857(%rip),%zmm6        # 5a50 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x170>
   382a7:	vpbroadcastq -0x32831(%rip),%zmm7        # 5a80 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1a0>
   382b1:	vpbroadcastq -0x327cb(%rip),%zmm8        # 5af0 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x210>
   382bb:	vpbroadcastq -0x3283d(%rip),%zmm9        # 5a88 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1a8>
   382c5:	vpbroadcastq -0x327f7(%rip),%zmm10        # 5ad8 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1f8>
   382cf:	vbroadcasti32x4 -0x32399(%rip),%zmm11        # 5f40 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x660>
   382d9:	vpbroadcastq -0x328bb(%rip),%zmm12        # 5a28 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x148>
   382e3:	vpbroadcastq -0x3283d(%rip),%zmm13        # 5ab0 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1d0>
   382ed:	vpbroadcastq -0x32837(%rip),%zmm14        # 5ac0 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1e0>
   382f7:	vpbroadcastq -0x32891(%rip),%zmm15        # 5a70 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x190>
   38301:	mov    %rsi,%rdx
   38304:	and    $0xfffffffffffffffc,%rdx
   38308:	movabs $0x30644e72e131,%rcx
   38312:	mov    %rdi,%r8
   38315:	neg    %rdx
   38318:	nopl   0x0(%rax,%rax,1)
   38320:	vmovdqu64 (%r8),%zmm20
   38326:	vmovdqu64 0x80(%r8),%zmm21
   3832d:	vmovdqu64 0x100(%r8),%zmm22
   38334:	vmovdqu64 0x180(%r8),%zmm23
   3833b:	vmovups %ymm0,-0x28(%rsp)
   38341:	mov    %rcx,-0x8(%rsp)
   38346:	vpxord %xmm29,%xmm29,%xmm29
   3834c:	vpxord %xmm28,%xmm28,%xmm28
   38352:	vpxord %xmm30,%xmm30,%xmm30
   38358:	vpxord %xmm31,%xmm31,%xmm31
   3835e:	vpbroadcastq -0x18(%rsp),%zmm18
   38366:	vpbroadcastq -0x10(%rsp),%zmm17
   3836e:	vpbroadcastq -0x20(%rsp),%zmm19
   38376:	vpbroadcastq -0x8(%rsp),%zmm16
   3837e:	vmovups %ymm0,-0x28(%rsp)
   38384:	mov    %rcx,-0x8(%rsp)
   38389:	vpunpcklqdq %zmm21,%zmm20,%zmm26
   3838f:	vpunpckhqdq %zmm21,%zmm20,%zmm20
   38395:	vpunpcklqdq %zmm23,%zmm22,%zmm21
   3839b:	vpunpckhqdq %zmm23,%zmm22,%zmm22
   383a1:	vmovdqa64 %zmm26,%zmm23
   383a7:	vmovdqa64 %zmm20,%zmm27
   383ad:	vpermt2q %zmm21,%zmm1,%zmm23
   383b3:	vpermt2q %zmm22,%zmm1,%zmm27
   383b9:	vpermt2q %zmm21,%zmm2,%zmm26
   383bf:	vpermt2q %zmm22,%zmm2,%zmm20
   383c5:	vpshldq $0x24,%zmm26,%zmm20,%zmm22
   383cc:	vpandq %zmm3,%zmm23,%zmm25
   383d2:	vpshldq $0xc,%zmm23,%zmm27,%zmm21
   383d9:	vpshldq $0x18,%zmm27,%zmm26,%zmm23
   383e0:	vpxord %xmm26,%xmm26,%xmm26
   383e6:	vpxord %xmm27,%xmm27,%xmm27
   383ec:	vpmadd52luq %zmm4,%zmm25,%zmm26
   383f2:	vpmadd52huq %zmm4,%zmm25,%zmm30
   383f8:	vpandq %zmm3,%zmm23,%zmm23
   383fe:	vpandq %zmm3,%zmm22,%zmm22
   38404:	vpandq %zmm3,%zmm21,%zmm24
   3840a:	vpsrlq $0x10,%zmm20,%zmm21
   38411:	vpxord %xmm20,%xmm20,%xmm20
   38417:	vpmadd52huq %zmm4,%zmm23,%zmm29
   3841d:	vpmadd52huq %zmm4,%zmm22,%zmm27
   38423:	vpmadd52huq %zmm4,%zmm24,%zmm28
   38429:	vpmadd52huq %zmm4,%zmm21,%zmm20
   3842f:	vpmadd52luq %zmm5,%zmm26,%zmm31
   38435:	vpmadd52luq %zmm4,%zmm24,%zmm30
   3843b:	vpaddq %zmm3,%zmm26,%zmm26
   38441:	vpsrlq $0x34,%zmm26,%zmm26
   38448:	vpmadd52luq %zmm4,%zmm22,%zmm29
   3844e:	vpmadd52luq %zmm4,%zmm21,%zmm27
   38454:	vpmadd52luq %zmm4,%zmm23,%zmm28
   3845a:	vpmadd52huq %zmm6,%zmm31,%zmm26
   38460:	vpmadd52luq %zmm19,%zmm31,%zmm30
   38466:	vpmadd52huq %zmm16,%zmm31,%zmm20
   3846c:	vpmadd52huq %zmm18,%zmm31,%zmm29
   38472:	vpmadd52huq %zmm17,%zmm31,%zmm27
   38478:	vpmadd52huq %zmm19,%zmm31,%zmm28
   3847e:	vpaddq %zmm26,%zmm30,%zmm30
   38484:	vpmadd52huq %zmm7,%zmm22,%zmm20
   3848a:	vpxord %xmm26,%xmm26,%xmm26
   38490:	vpmadd52huq %zmm7,%zmm21,%zmm26
   38496:	vpmadd52luq %zmm7,%zmm25,%zmm30
   3849c:	vpmadd52luq %zmm17,%zmm31,%zmm29
   384a2:	vpmadd52luq %zmm16,%zmm31,%zmm27
   384a8:	vpmadd52luq %zmm18,%zmm31,%zmm28
   384ae:	vpxord %xmm31,%xmm31,%xmm31
   384b4:	vpmadd52luq %zmm7,%zmm21,%zmm20
   384ba:	vpmadd52luq %zmm5,%zmm30,%zmm31
   384c0:	vpaddq %zmm3,%zmm30,%zmm30
   384c6:	vpmadd52huq %zmm7,%zmm24,%zmm29
   384cc:	vpmadd52huq %zmm7,%zmm23,%zmm27
   384d2:	vpmadd52huq %zmm7,%zmm25,%zmm28
   384d8:	vpsrlq $0x34,%zmm30,%zmm30
   384df:	vpmadd52huq %zmm17,%zmm31,%zmm20
   384e5:	vpmadd52huq %zmm6,%zmm31,%zmm30
   384eb:	vpmadd52huq %zmm16,%zmm31,%zmm26
   384f1:	vpmadd52luq %zmm7,%zmm23,%zmm29
   384f7:	vpmadd52luq %zmm7,%zmm22,%zmm27
   384fd:	vpmadd52luq %zmm7,%zmm24,%zmm28
   38503:	vpmadd52luq %zmm16,%zmm31,%zmm20
   38509:	vpmadd52huq %zmm8,%zmm22,%zmm26
   3850f:	vpmadd52huq %zmm19,%zmm31,%zmm29
   38515:	vpmadd52huq %zmm18,%zmm31,%zmm27
   3851b:	vpmadd52luq %zmm19,%zmm31,%zmm28
   38521:	vpmadd52huq %zmm8,%zmm23,%zmm20
   38527:	vpmadd52luq %zmm8,%zmm21,%zmm26
   3852d:	vpmadd52luq %zmm18,%zmm31,%zmm29
   38533:	vpmadd52luq %zmm17,%zmm31,%zmm27
   38539:	vpaddq %zmm30,%zmm28,%zmm30
   3853f:	vpxord %xmm31,%xmm31,%xmm31
   38545:	vpxord %xmm28,%xmm28,%xmm28
   3854b:	vpmadd52huq %zmm8,%zmm21,%zmm28
   38551:	vpmadd52luq %zmm8,%zmm25,%zmm30
   38557:	vpmadd52luq %zmm8,%zmm22,%zmm20
   3855d:	vpmadd52huq %zmm8,%zmm25,%zmm29
   38563:	vpmadd52huq %zmm8,%zmm24,%zmm27
   38569:	vpmadd52luq %zmm5,%zmm30,%zmm31
   3856f:	vpaddq %zmm3,%zmm30,%zmm30
   38575:	vpsrlq $0x34,%zmm30,%zmm30
   3857c:	vpmadd52luq %zmm8,%zmm24,%zmm29
   38582:	vpmadd52luq %zmm8,%zmm23,%zmm27
   38588:	vpmadd52huq %zmm17,%zmm31,%zmm26
   3858e:	vpmadd52huq %zmm6,%zmm31,%zmm30
   38594:	vpmadd52huq %zmm16,%zmm31,%zmm28
   3859a:	vpmadd52huq %zmm18,%zmm31,%zmm20
   385a0:	vpmadd52huq %zmm19,%zmm31,%zmm27
   385a6:	vpmadd52luq %zmm19,%zmm31,%zmm29
   385ac:	vpmadd52luq %zmm16,%zmm31,%zmm26
   385b2:	vpmadd52huq %zmm9,%zmm22,%zmm28
   385b8:	vpmadd52luq %zmm17,%zmm31,%zmm20
   385be:	vpaddq %zmm30,%zmm29,%zmm30
   385c4:	vpmadd52luq %zmm18,%zmm31,%zmm27
   385ca:	vpxord %xmm31,%xmm31,%xmm31
   385d0:	vpxord %xmm29,%xmm29,%xmm29
   385d6:	vpmadd52huq %zmm9,%zmm21,%zmm29
   385dc:	vpmadd52luq %zmm9,%zmm25,%zmm30
   385e2:	vpmadd52huq %zmm9,%zmm23,%zmm26
   385e8:	vpmadd52luq %zmm9,%zmm21,%zmm28
   385ee:	vpmadd52huq %zmm9,%zmm24,%zmm20
   385f4:	vpmadd52huq %zmm9,%zmm25,%zmm27
   385fa:	vpmadd52luq %zmm5,%zmm30,%zmm31
   38600:	vpmadd52luq %zmm9,%zmm22,%zmm26
   38606:	vpmadd52luq %zmm9,%zmm23,%zmm20
   3860c:	vpaddq %zmm3,%zmm30,%zmm30
   38612:	vpsrlq $0x34,%zmm30,%zmm30
   38619:	vpmadd52luq %zmm9,%zmm24,%zmm27
   3861f:	vpmadd52huq %zmm17,%zmm31,%zmm28
   38625:	vpmadd52huq %zmm18,%zmm31,%zmm26
   3862b:	vpmadd52huq %zmm6,%zmm31,%zmm30
   38631:	vpmadd52huq %zmm16,%zmm31,%zmm29
   38637:	vpmadd52huq %zmm19,%zmm31,%zmm20
   3863d:	vpmadd52luq %zmm19,%zmm31,%zmm27
   38643:	vpmadd52luq %zmm16,%zmm31,%zmm28
   38649:	vpmadd52luq %zmm17,%zmm31,%zmm26
   3864f:	vpmadd52huq %zmm10,%zmm22,%zmm29
   38655:	vpmadd52luq %zmm18,%zmm31,%zmm20
   3865b:	vpaddq %zmm30,%zmm27,%zmm27
   38661:	vpmadd52huq %zmm10,%zmm23,%zmm28
   38667:	vpmadd52luq %zmm10,%zmm25,%zmm27
   3866d:	vpmadd52huq %zmm10,%zmm24,%zmm26
   38673:	vpmadd52luq %zmm10,%zmm21,%zmm29
   38679:	vpmadd52huq %zmm10,%zmm25,%zmm20
   3867f:	vpmadd52luq %zmm10,%zmm22,%zmm28
   38685:	vpxord %xmm22,%xmm22,%xmm22
   3868b:	vpmadd52huq %zmm10,%zmm21,%zmm22
   38691:	vpxord %xmm21,%xmm21,%xmm21
   38697:	vpmadd52luq %zmm5,%zmm27,%zmm21
   3869d:	vpmadd52luq %zmm10,%zmm23,%zmm26
   386a3:	vpmadd52luq %zmm10,%zmm24,%zmm20
   386a9:	vpaddq %zmm12,%zmm27,%zmm24
   386af:	vpsrlq $0x30,%zmm24,%zmm24
   386b6:	vpandq %zmm11,%zmm21,%zmm23
   386bc:	vpsllq $0x4,%zmm21,%zmm21
   386c3:	vpmadd52huq %zmm18,%zmm23,%zmm28
   386c9:	vpmadd52huq %zmm17,%zmm23,%zmm29
   386cf:	vpmadd52huq %zmm19,%zmm23,%zmm26
   386d5:	vpmadd52luq %zmm19,%zmm23,%zmm20
   386db:	vpmadd52huq %zmm16,%zmm23,%zmm22
   386e1:	vpmadd52huq %zmm6,%zmm21,%zmm24
   386e7:	vpmadd52luq %zmm16,%zmm23,%zmm29
   386ed:	vpmadd52luq %zmm17,%zmm23,%zmm28
   386f3:	vpmadd52luq %zmm18,%zmm23,%zmm26
   386f9:	vpsllq $0x4,%zmm20,%zmm16
   38700:	vpsrlq $0x30,%zmm20,%zmm17
   38707:	vpsllq $0x4,%zmm22,%zmm22
   3870e:	vpandq %zmm13,%zmm16,%zmm16
   38714:	vpaddq %zmm24,%zmm16,%zmm16
   3871a:	vpsllq $0x4,%zmm28,%zmm20
   38721:	vpsllq $0x4,%zmm29,%zmm21
   38728:	vpsrlq $0x30,%zmm26,%zmm19
   3872f:	vpsrlq $0x30,%zmm28,%zmm23
   38736:	vpsllq $0x4,%zmm26,%zmm18
   3873d:	vpandq %zmm13,%zmm20,%zmm20
   38743:	vpandq %zmm13,%zmm21,%zmm21
   38749:	vpandq %zmm13,%zmm18,%zmm18
   3874f:	vpaddq %zmm19,%zmm20,%zmm19
   38755:	vpaddq %zmm23,%zmm21,%zmm20
   3875b:	vpsrlq $0x30,%zmm29,%zmm23
   38762:	vpaddq %zmm23,%zmm22,%zmm21
   38768:	vpsrlq $0x34,%zmm16,%zmm23
   3876f:	vpandq %zmm3,%zmm16,%zmm16
   38775:	vpaddq %zmm17,%zmm23,%zmm17
   3877b:	vpaddq %zmm14,%zmm16,%zmm25
   38781:	vpaddq %zmm18,%zmm17,%zmm17
   38787:	vpsraq $0x34,%zmm25,%zmm26
   3878e:	vpsrlq $0x34,%zmm17,%zmm18
   38795:	vpandq %zmm3,%zmm17,%zmm17
   3879b:	vpsubq -0x20(%rsp){1to8},%zmm17,%zmm27
   387a3:	vpaddq %zmm19,%zmm18,%zmm18
   387a9:	vpsrlq $0x34,%zmm18,%zmm19
   387b0:	vpandq %zmm3,%zmm18,%zmm18
   387b6:	vpsubq -0x18(%rsp){1to8},%zmm18,%zmm22
   387be:	vpaddq %zmm20,%zmm19,%zmm19
   387c4:	vpsrlq $0x34,%zmm19,%zmm20
   387cb:	vpandq %zmm3,%zmm19,%zmm19
   387d1:	vpsubq -0x10(%rsp){1to8},%zmm19,%zmm23
   387d9:	vpaddq %zmm21,%zmm20,%zmm20
   387df:	vpsubq -0x8(%rsp){1to8},%zmm20,%zmm24
   387e7:	vpaddq %zmm26,%zmm27,%zmm21
   387ed:	vpsraq $0x34,%zmm21,%zmm26
   387f4:	vpaddq %zmm26,%zmm22,%zmm22
   387fa:	vpsraq $0x34,%zmm22,%zmm26
   38801:	vpaddq %zmm26,%zmm23,%zmm23
   38807:	vpsraq $0x34,%zmm23,%zmm26
   3880e:	vpaddq %zmm26,%zmm24,%zmm24
   38814:	vpcmpltuq %zmm15,%zmm24,%k1
   3881b:	vpandq %zmm3,%zmm21,%zmm17{%k1}
   38821:	vpandq %zmm3,%zmm25,%zmm16{%k1}
   38827:	vpandq %zmm3,%zmm22,%zmm18{%k1}
   3882d:	vpandq %zmm3,%zmm23,%zmm19{%k1}
   38833:	vmovdqa64 %zmm24,%zmm20{%k1}
   38839:	vpsllq $0x10,%zmm20,%zmm20
   38840:	vpsllq $0x34,%zmm17,%zmm21
   38847:	vpsllq $0x28,%zmm18,%zmm24
   3884e:	vpsrlq $0xc,%zmm17,%zmm17
   38855:	vpsrlq $0x18,%zmm18,%zmm18
   3885c:	vporq  %zmm16,%zmm21,%zmm16
   38862:	vpsllq $0x1c,%zmm19,%zmm21
   38869:	vpsrlq $0x24,%zmm19,%zmm19
   38870:	vporq  %zmm17,%zmm24,%zmm17
   38876:	vporq  %zmm19,%zmm20,%zmm19
   3887c:	vporq  %zmm18,%zmm21,%zmm18
   38882:	vpunpcklqdq %zmm17,%zmm16,%zmm20
   38888:	vpunpckhqdq %zmm17,%zmm16,%zmm16
   3888e:	vpunpcklqdq %zmm19,%zmm18,%zmm17
   38894:	vpunpckhqdq %zmm19,%zmm18,%zmm18
   3889a:	vextracti64x4 $0x1,%zmm20,%ymm22
   388a1:	vinserti32x4 $0x1,%xmm17,%ymm20,%ymm19
   388a8:	vinserti32x4 $0x1,%xmm18,%ymm16,%ymm21
   388af:	vshufi64x2 $0x3,%ymm17,%ymm20,%ymm23
   388b6:	vextracti64x4 $0x1,%zmm17,%ymm17
   388bd:	vmovdqu64 %ymm19,(%r8)
   388c3:	vmovdqu64 %ymm21,0x20(%r8)
   388ca:	vshufi64x2 $0x3,%ymm18,%ymm16,%ymm21
   388d1:	vextracti64x4 $0x1,%zmm16,%ymm16
   388d8:	vextracti64x4 $0x1,%zmm18,%ymm18
   388df:	vinserti32x4 $0x1,%xmm17,%ymm22,%ymm20
   388e6:	vshufi64x2 $0x3,%ymm17,%ymm22,%ymm17
   388ed:	vmovdqu64 %ymm23,0x80(%r8)
   388f4:	vmovdqu64 %ymm21,0xa0(%r8)
   388fb:	vinserti32x4 $0x1,%xmm18,%ymm16,%ymm21
   38902:	vshufi64x2 $0x3,%ymm18,%ymm16,%ymm16
   38909:	vmovdqu64 %ymm20,0x100(%r8)
   38910:	vmovdqu64 %ymm21,0x120(%r8)
   38917:	vmovdqu64 %ymm17,0x180(%r8)
   3891e:	vmovdqu64 %ymm16,0x1a0(%r8)
   38925:	add    $0x200,%r8
   3892c:	add    $0x4,%rdx
   38930:	jne    38320 <_RNvCs3zmp2RFaYZ5_6driver4simd+0xd0>
   38936:	shl    $0x7,%rax
   3893a:	and    $0x3,%esi
   3893d:	add    %rax,%rdi
   38940:	vzeroupper
   38943:	jmp    38980 <_RNvCs3zmp2RFaYZ5_6driver6scalar>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
