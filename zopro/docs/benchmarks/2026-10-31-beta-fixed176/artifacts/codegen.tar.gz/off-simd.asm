
/home/ubuntu/src/zopro-perf-work/beta-fixed176/fresh-sdk:     file format elf64-x86-64


Disassembly of section .text:

00000000000382a0 <_RNvCs3zmp2RFaYZ5_6driver4simd>:
   382a0:	movabs $0xfffffffffffffc,%rax
   382aa:	and    %rsi,%rax
   382ad:	je     38986 <_RNvCs3zmp2RFaYZ5_6driver4simd+0x6e6>
   382b3:	vmovaps -0x32a7b(%rip),%ymm0        # 5840 <GCC_except_table554+0xa8>
   382bb:	vmovdqa64 -0x32785(%rip),%zmm1        # 5b40 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x2a0>
   382c5:	vmovdqa64 -0x3274f(%rip),%zmm2        # 5b80 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x2e0>
   382cf:	vpbroadcastq -0x328f9(%rip),%zmm3        # 59e0 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x140>
   382d9:	vpbroadcastq -0x327c3(%rip),%zmm4        # 5b20 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x280>
   382e3:	vpbroadcastq -0x327ed(%rip),%zmm5        # 5b00 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x260>
   382ed:	vpbroadcastq -0x328d7(%rip),%zmm6        # 5a20 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x180>
   382f7:	vpbroadcastq -0x328a1(%rip),%zmm7        # 5a60 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1c0>
   38301:	vpbroadcastq -0x3281b(%rip),%zmm8        # 5af0 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x250>
   3830b:	vpbroadcastq -0x328ad(%rip),%zmm9        # 5a68 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1c8>
   38315:	vpbroadcastq -0x3284f(%rip),%zmm10        # 5ad0 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x230>
   3831f:	vbroadcasti32x4 -0x32369(%rip),%zmm11        # 5fc0 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x720>
   38329:	vpbroadcastq -0x3294b(%rip),%zmm12        # 59e8 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x148>
   38333:	vpbroadcastq -0x328a5(%rip),%zmm13        # 5a98 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1f8>
   3833d:	vpbroadcastq -0x3288f(%rip),%zmm14        # 5ab8 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x218>
   38347:	vpbroadcastq -0x32901(%rip),%zmm15        # 5a50 <_RNvNvXs3_NtNtCshdGlst1c7nL_10serde_json5value5indexNtB9_5ValueINtNtNtCsgxBkk5gSRhY_4core3ops5index5IndexpE5index4NULL+0x1b0>
   38351:	mov    %rsi,%rdx
   38354:	and    $0xfffffffffffffffc,%rdx
   38358:	movabs $0x30644e72e131,%rcx
   38362:	mov    %rdi,%r8
   38365:	neg    %rdx
   38368:	nopl   0x0(%rax,%rax,1)
   38370:	vmovdqu64 (%r8),%zmm20
   38376:	vmovdqu64 0x80(%r8),%zmm21
   3837d:	vmovdqu64 0x100(%r8),%zmm22
   38384:	vmovdqu64 0x180(%r8),%zmm23
   3838b:	vmovups %ymm0,-0x28(%rsp)
   38391:	mov    %rcx,-0x8(%rsp)
   38396:	vpxord %xmm29,%xmm29,%xmm29
   3839c:	vpxord %xmm28,%xmm28,%xmm28
   383a2:	vpxord %xmm30,%xmm30,%xmm30
   383a8:	vpxord %xmm31,%xmm31,%xmm31
   383ae:	vpbroadcastq -0x18(%rsp),%zmm18
   383b6:	vpbroadcastq -0x10(%rsp),%zmm17
   383be:	vpbroadcastq -0x20(%rsp),%zmm19
   383c6:	vpbroadcastq -0x8(%rsp),%zmm16
   383ce:	vmovups %ymm0,-0x28(%rsp)
   383d4:	mov    %rcx,-0x8(%rsp)
   383d9:	vpunpcklqdq %zmm21,%zmm20,%zmm26
   383df:	vpunpckhqdq %zmm21,%zmm20,%zmm20
   383e5:	vpunpcklqdq %zmm23,%zmm22,%zmm21
   383eb:	vpunpckhqdq %zmm23,%zmm22,%zmm22
   383f1:	vmovdqa64 %zmm26,%zmm23
   383f7:	vmovdqa64 %zmm20,%zmm27
   383fd:	vpermt2q %zmm21,%zmm1,%zmm23
   38403:	vpermt2q %zmm22,%zmm1,%zmm27
   38409:	vpermt2q %zmm21,%zmm2,%zmm26
   3840f:	vpermt2q %zmm22,%zmm2,%zmm20
   38415:	vpshldq $0x24,%zmm26,%zmm20,%zmm22
   3841c:	vpandq %zmm3,%zmm23,%zmm25
   38422:	vpshldq $0xc,%zmm23,%zmm27,%zmm21
   38429:	vpshldq $0x18,%zmm27,%zmm26,%zmm23
   38430:	vpxord %xmm26,%xmm26,%xmm26
   38436:	vpxord %xmm27,%xmm27,%xmm27
   3843c:	vpmadd52luq %zmm4,%zmm25,%zmm26
   38442:	vpmadd52huq %zmm4,%zmm25,%zmm30
   38448:	vpandq %zmm3,%zmm23,%zmm23
   3844e:	vpandq %zmm3,%zmm22,%zmm22
   38454:	vpandq %zmm3,%zmm21,%zmm24
   3845a:	vpsrlq $0x10,%zmm20,%zmm21
   38461:	vpxord %xmm20,%xmm20,%xmm20
   38467:	vpmadd52huq %zmm4,%zmm23,%zmm29
   3846d:	vpmadd52huq %zmm4,%zmm22,%zmm27
   38473:	vpmadd52huq %zmm4,%zmm24,%zmm28
   38479:	vpmadd52huq %zmm4,%zmm21,%zmm20
   3847f:	vpmadd52luq %zmm5,%zmm26,%zmm31
   38485:	vpmadd52luq %zmm4,%zmm24,%zmm30
   3848b:	vpaddq %zmm3,%zmm26,%zmm26
   38491:	vpsrlq $0x34,%zmm26,%zmm26
   38498:	vpmadd52luq %zmm4,%zmm22,%zmm29
   3849e:	vpmadd52luq %zmm4,%zmm21,%zmm27
   384a4:	vpmadd52luq %zmm4,%zmm23,%zmm28
   384aa:	vpmadd52huq %zmm6,%zmm31,%zmm26
   384b0:	vpmadd52luq %zmm19,%zmm31,%zmm30
   384b6:	vpmadd52huq %zmm16,%zmm31,%zmm20
   384bc:	vpmadd52huq %zmm18,%zmm31,%zmm29
   384c2:	vpmadd52huq %zmm17,%zmm31,%zmm27
   384c8:	vpmadd52huq %zmm19,%zmm31,%zmm28
   384ce:	vpaddq %zmm26,%zmm30,%zmm30
   384d4:	vpmadd52huq %zmm7,%zmm22,%zmm20
   384da:	vpxord %xmm26,%xmm26,%xmm26
   384e0:	vpmadd52huq %zmm7,%zmm21,%zmm26
   384e6:	vpmadd52luq %zmm7,%zmm25,%zmm30
   384ec:	vpmadd52luq %zmm17,%zmm31,%zmm29
   384f2:	vpmadd52luq %zmm16,%zmm31,%zmm27
   384f8:	vpmadd52luq %zmm18,%zmm31,%zmm28
   384fe:	vpxord %xmm31,%xmm31,%xmm31
   38504:	vpmadd52luq %zmm7,%zmm21,%zmm20
   3850a:	vpmadd52luq %zmm5,%zmm30,%zmm31
   38510:	vpaddq %zmm3,%zmm30,%zmm30
   38516:	vpmadd52huq %zmm7,%zmm24,%zmm29
   3851c:	vpmadd52huq %zmm7,%zmm23,%zmm27
   38522:	vpmadd52huq %zmm7,%zmm25,%zmm28
   38528:	vpsrlq $0x34,%zmm30,%zmm30
   3852f:	vpmadd52huq %zmm17,%zmm31,%zmm20
   38535:	vpmadd52huq %zmm6,%zmm31,%zmm30
   3853b:	vpmadd52huq %zmm16,%zmm31,%zmm26
   38541:	vpmadd52luq %zmm7,%zmm23,%zmm29
   38547:	vpmadd52luq %zmm7,%zmm22,%zmm27
   3854d:	vpmadd52luq %zmm7,%zmm24,%zmm28
   38553:	vpmadd52luq %zmm16,%zmm31,%zmm20
   38559:	vpmadd52huq %zmm8,%zmm22,%zmm26
   3855f:	vpmadd52huq %zmm19,%zmm31,%zmm29
   38565:	vpmadd52huq %zmm18,%zmm31,%zmm27
   3856b:	vpmadd52luq %zmm19,%zmm31,%zmm28
   38571:	vpmadd52huq %zmm8,%zmm23,%zmm20
   38577:	vpmadd52luq %zmm8,%zmm21,%zmm26
   3857d:	vpmadd52luq %zmm18,%zmm31,%zmm29
   38583:	vpmadd52luq %zmm17,%zmm31,%zmm27
   38589:	vpaddq %zmm30,%zmm28,%zmm30
   3858f:	vpxord %xmm31,%xmm31,%xmm31
   38595:	vpxord %xmm28,%xmm28,%xmm28
   3859b:	vpmadd52huq %zmm8,%zmm21,%zmm28
   385a1:	vpmadd52luq %zmm8,%zmm25,%zmm30
   385a7:	vpmadd52luq %zmm8,%zmm22,%zmm20
   385ad:	vpmadd52huq %zmm8,%zmm25,%zmm29
   385b3:	vpmadd52huq %zmm8,%zmm24,%zmm27
   385b9:	vpmadd52luq %zmm5,%zmm30,%zmm31
   385bf:	vpaddq %zmm3,%zmm30,%zmm30
   385c5:	vpsrlq $0x34,%zmm30,%zmm30
   385cc:	vpmadd52luq %zmm8,%zmm24,%zmm29
   385d2:	vpmadd52luq %zmm8,%zmm23,%zmm27
   385d8:	vpmadd52huq %zmm17,%zmm31,%zmm26
   385de:	vpmadd52huq %zmm6,%zmm31,%zmm30
   385e4:	vpmadd52huq %zmm16,%zmm31,%zmm28
   385ea:	vpmadd52huq %zmm18,%zmm31,%zmm20
   385f0:	vpmadd52huq %zmm19,%zmm31,%zmm27
   385f6:	vpmadd52luq %zmm19,%zmm31,%zmm29
   385fc:	vpmadd52luq %zmm16,%zmm31,%zmm26
   38602:	vpmadd52huq %zmm9,%zmm22,%zmm28
   38608:	vpmadd52luq %zmm17,%zmm31,%zmm20
   3860e:	vpaddq %zmm30,%zmm29,%zmm30
   38614:	vpmadd52luq %zmm18,%zmm31,%zmm27
   3861a:	vpxord %xmm31,%xmm31,%xmm31
   38620:	vpxord %xmm29,%xmm29,%xmm29
   38626:	vpmadd52huq %zmm9,%zmm21,%zmm29
   3862c:	vpmadd52luq %zmm9,%zmm25,%zmm30
   38632:	vpmadd52huq %zmm9,%zmm23,%zmm26
   38638:	vpmadd52luq %zmm9,%zmm21,%zmm28
   3863e:	vpmadd52huq %zmm9,%zmm24,%zmm20
   38644:	vpmadd52huq %zmm9,%zmm25,%zmm27
   3864a:	vpmadd52luq %zmm5,%zmm30,%zmm31
   38650:	vpmadd52luq %zmm9,%zmm22,%zmm26
   38656:	vpmadd52luq %zmm9,%zmm23,%zmm20
   3865c:	vpaddq %zmm3,%zmm30,%zmm30
   38662:	vpsrlq $0x34,%zmm30,%zmm30
   38669:	vpmadd52luq %zmm9,%zmm24,%zmm27
   3866f:	vpmadd52huq %zmm17,%zmm31,%zmm28
   38675:	vpmadd52huq %zmm18,%zmm31,%zmm26
   3867b:	vpmadd52huq %zmm6,%zmm31,%zmm30
   38681:	vpmadd52huq %zmm16,%zmm31,%zmm29
   38687:	vpmadd52huq %zmm19,%zmm31,%zmm20
   3868d:	vpmadd52luq %zmm19,%zmm31,%zmm27
   38693:	vpmadd52luq %zmm16,%zmm31,%zmm28
   38699:	vpmadd52luq %zmm17,%zmm31,%zmm26
   3869f:	vpmadd52huq %zmm10,%zmm22,%zmm29
   386a5:	vpmadd52luq %zmm18,%zmm31,%zmm20
   386ab:	vpaddq %zmm30,%zmm27,%zmm27
   386b1:	vpmadd52huq %zmm10,%zmm23,%zmm28
   386b7:	vpmadd52luq %zmm10,%zmm25,%zmm27
   386bd:	vpmadd52huq %zmm10,%zmm24,%zmm26
   386c3:	vpmadd52luq %zmm10,%zmm21,%zmm29
   386c9:	vpmadd52huq %zmm10,%zmm25,%zmm20
   386cf:	vpmadd52luq %zmm10,%zmm22,%zmm28
   386d5:	vpxord %xmm22,%xmm22,%xmm22
   386db:	vpmadd52huq %zmm10,%zmm21,%zmm22
   386e1:	vpxord %xmm21,%xmm21,%xmm21
   386e7:	vpmadd52luq %zmm5,%zmm27,%zmm21
   386ed:	vpmadd52luq %zmm10,%zmm23,%zmm26
   386f3:	vpmadd52luq %zmm10,%zmm24,%zmm20
   386f9:	vpaddq %zmm12,%zmm27,%zmm24
   386ff:	vpsrlq $0x30,%zmm24,%zmm24
   38706:	vpandq %zmm11,%zmm21,%zmm23
   3870c:	vpsllq $0x4,%zmm21,%zmm21
   38713:	vpmadd52huq %zmm18,%zmm23,%zmm28
   38719:	vpmadd52huq %zmm17,%zmm23,%zmm29
   3871f:	vpmadd52huq %zmm19,%zmm23,%zmm26
   38725:	vpmadd52luq %zmm19,%zmm23,%zmm20
   3872b:	vpmadd52huq %zmm16,%zmm23,%zmm22
   38731:	vpmadd52huq %zmm6,%zmm21,%zmm24
   38737:	vpmadd52luq %zmm16,%zmm23,%zmm29
   3873d:	vpmadd52luq %zmm17,%zmm23,%zmm28
   38743:	vpmadd52luq %zmm18,%zmm23,%zmm26
   38749:	vpsllq $0x4,%zmm20,%zmm16
   38750:	vpsrlq $0x30,%zmm20,%zmm17
   38757:	vpsllq $0x4,%zmm22,%zmm22
   3875e:	vpandq %zmm13,%zmm16,%zmm16
   38764:	vpaddq %zmm24,%zmm16,%zmm16
   3876a:	vpsllq $0x4,%zmm28,%zmm20
   38771:	vpsllq $0x4,%zmm29,%zmm21
   38778:	vpsrlq $0x30,%zmm26,%zmm19
   3877f:	vpsrlq $0x30,%zmm28,%zmm23
   38786:	vpsllq $0x4,%zmm26,%zmm18
   3878d:	vpandq %zmm13,%zmm20,%zmm20
   38793:	vpandq %zmm13,%zmm21,%zmm21
   38799:	vpandq %zmm13,%zmm18,%zmm18
   3879f:	vpaddq %zmm19,%zmm20,%zmm19
   387a5:	vpaddq %zmm23,%zmm21,%zmm20
   387ab:	vpsrlq $0x30,%zmm29,%zmm23
   387b2:	vpaddq %zmm23,%zmm22,%zmm21
   387b8:	vpsrlq $0x34,%zmm16,%zmm23
   387bf:	vpandq %zmm3,%zmm16,%zmm16
   387c5:	vpaddq %zmm17,%zmm23,%zmm17
   387cb:	vpaddq %zmm14,%zmm16,%zmm25
   387d1:	vpaddq %zmm18,%zmm17,%zmm17
   387d7:	vpsraq $0x34,%zmm25,%zmm26
   387de:	vpsrlq $0x34,%zmm17,%zmm18
   387e5:	vpandq %zmm3,%zmm17,%zmm17
   387eb:	vpsubq -0x20(%rsp){1to8},%zmm17,%zmm27
   387f3:	vpaddq %zmm19,%zmm18,%zmm18
   387f9:	vpsrlq $0x34,%zmm18,%zmm19
   38800:	vpandq %zmm3,%zmm18,%zmm18
   38806:	vpsubq -0x18(%rsp){1to8},%zmm18,%zmm22
   3880e:	vpaddq %zmm20,%zmm19,%zmm19
   38814:	vpsrlq $0x34,%zmm19,%zmm20
   3881b:	vpandq %zmm3,%zmm19,%zmm19
   38821:	vpsubq -0x10(%rsp){1to8},%zmm19,%zmm23
   38829:	vpaddq %zmm21,%zmm20,%zmm20
   3882f:	vpsubq -0x8(%rsp){1to8},%zmm20,%zmm24
   38837:	vpaddq %zmm26,%zmm27,%zmm21
   3883d:	vpsraq $0x34,%zmm21,%zmm26
   38844:	vpaddq %zmm26,%zmm22,%zmm22
   3884a:	vpsraq $0x34,%zmm22,%zmm26
   38851:	vpaddq %zmm26,%zmm23,%zmm23
   38857:	vpsraq $0x34,%zmm23,%zmm26
   3885e:	vpaddq %zmm26,%zmm24,%zmm24
   38864:	vpcmpltuq %zmm15,%zmm24,%k1
   3886b:	vpandq %zmm3,%zmm21,%zmm17{%k1}
   38871:	vpandq %zmm3,%zmm25,%zmm16{%k1}
   38877:	vpandq %zmm3,%zmm22,%zmm18{%k1}
   3887d:	vpandq %zmm3,%zmm23,%zmm19{%k1}
   38883:	vmovdqa64 %zmm24,%zmm20{%k1}
   38889:	vpsllq $0x10,%zmm20,%zmm20
   38890:	vpsllq $0x34,%zmm17,%zmm21
   38897:	vpsllq $0x28,%zmm18,%zmm24
   3889e:	vpsrlq $0xc,%zmm17,%zmm17
   388a5:	vpsrlq $0x18,%zmm18,%zmm18
   388ac:	vporq  %zmm16,%zmm21,%zmm16
   388b2:	vpsllq $0x1c,%zmm19,%zmm21
   388b9:	vpsrlq $0x24,%zmm19,%zmm19
   388c0:	vporq  %zmm17,%zmm24,%zmm17
   388c6:	vporq  %zmm19,%zmm20,%zmm19
   388cc:	vporq  %zmm18,%zmm21,%zmm18
   388d2:	vpunpcklqdq %zmm17,%zmm16,%zmm20
   388d8:	vpunpckhqdq %zmm17,%zmm16,%zmm16
   388de:	vpunpcklqdq %zmm19,%zmm18,%zmm17
   388e4:	vpunpckhqdq %zmm19,%zmm18,%zmm18
   388ea:	vextracti64x4 $0x1,%zmm20,%ymm22
   388f1:	vinserti32x4 $0x1,%xmm17,%ymm20,%ymm19
   388f8:	vinserti32x4 $0x1,%xmm18,%ymm16,%ymm21
   388ff:	vshufi64x2 $0x3,%ymm17,%ymm20,%ymm23
   38906:	vextracti64x4 $0x1,%zmm17,%ymm17
   3890d:	vmovdqu64 %ymm19,(%r8)
   38913:	vmovdqu64 %ymm21,0x20(%r8)
   3891a:	vshufi64x2 $0x3,%ymm18,%ymm16,%ymm21
   38921:	vextracti64x4 $0x1,%zmm16,%ymm16
   38928:	vextracti64x4 $0x1,%zmm18,%ymm18
   3892f:	vinserti32x4 $0x1,%xmm17,%ymm22,%ymm20
   38936:	vshufi64x2 $0x3,%ymm17,%ymm22,%ymm17
   3893d:	vmovdqu64 %ymm23,0x80(%r8)
   38944:	vmovdqu64 %ymm21,0xa0(%r8)
   3894b:	vinserti32x4 $0x1,%xmm18,%ymm16,%ymm21
   38952:	vshufi64x2 $0x3,%ymm18,%ymm16,%ymm16
   38959:	vmovdqu64 %ymm20,0x100(%r8)
   38960:	vmovdqu64 %ymm21,0x120(%r8)
   38967:	vmovdqu64 %ymm17,0x180(%r8)
   3896e:	vmovdqu64 %ymm16,0x1a0(%r8)
   38975:	add    $0x200,%r8
   3897c:	add    $0x4,%rdx
   38980:	jne    38370 <_RNvCs3zmp2RFaYZ5_6driver4simd+0xd0>
   38986:	shl    $0x7,%rax
   3898a:	and    $0x3,%esi
   3898d:	add    %rax,%rdi
   38990:	vzeroupper
   38993:	jmp    392f0 <_RNvCs3zmp2RFaYZ5_6driver6scalar>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
