//! Private native G2 binary-ring candidate; original field and point kernels.
use super::{batch_size,BatchAdd,BETA,G2Affine,G2Config,G2Projective,Window};
use rayon::prelude::*;
#[path="joint_ring_constants.rs"]mod constants;
const R:usize=2731;const SLOTS:usize=3*R;const WINDOWS:usize=19;
type Codes=[i16;WINDOWS];
#[inline]
fn encode(words:[u64;4])->Codes{
    let s=super::super::g2_phi::phi_split(words);
    let mut pair=[0i128;2];for c in 0..2{let magnitude=s[2*c]as u128|((s[2*c+1]&0x7fff_ffff_ffff_ffff)as u128)<<64;pair[c]=magnitude as i128;if s[2*c+1]>>63!=0{pair[c]=-pair[c];}}
    let out=std::array::from_fn(|_|{let a=pair[0]&127;let b=pair[1]&127;let(code,da,db)=constants::MAP[(a+128*b)as usize];pair[0]=(pair[0]>>7)+((a-da as i128)>>7);pair[1]=(pair[1]>>7)+((b-db as i128)>>7);code});
    assert_eq!(pair,[0,0]);out
}
impl<'a> Window<'a> {
    // Same fixed schedule as the qualified structural model. No scratch or
    // Window field is added; every round strictly shrinks the bounded queue.
    fn ring_complete(&mut self) {
        self.execute();
        while !self.queue.is_empty() {
            let before = self.queue.len();
            for i in (0..before).rev() {
                let (encoded, p) = self.queue[i];
                if !self.busy((encoded & 0x7fffffff) as usize) {
                    self.queue.swap_remove(i);
                    self.add(encoded, p);
                }
            }
            debug_assert!(self.queue.len() < before);
            debug_assert!(self.batch.len() <= 199);
            self.execute();
        }
    }
    fn ring_feed(&mut self, bases: &'a [G2Affine], codes: &[Codes], w: usize, size: usize, unit: usize) {
        for (p, s) in bases.iter().zip(codes) {
            let d = s[w];
            if d == 0 { continue; }
            let index = d.unsigned_abs() as usize - 1;
            if index / R != unit { continue; }
            if p.is_identity() { continue; }
            let b = index % R;
            let encoded = b as u32 | if d < 0 { 1 << 31 } else { 0 };
            if self.busy(b) {
                self.queue.push((encoded, p));
                if self.queue.len() == size - 1 { self.ring_complete(); }
                continue;
            }
            self.add(encoded, p);
            if self.batch.len() == size { self.execute(); self.take_from_queue(); }
        }
        self.ring_complete();
    }
}
fn ordinary(bases: &[G2Affine], codes: &[Codes], w: usize) -> Vec<G2Affine> {
    let size = batch_size(12).max(32);
    debug_assert_eq!(size, 200);
    let mut state = Window::new(R, size, BatchAdd::<G2Config>::default());
    for unit in (0..3).rev() {
        state.ring_feed(bases, codes, w, size, unit);
        debug_assert!(state.batch.is_empty() && state.queue.is_empty());
        if unit != 0 {
            for p in &mut state.affine { if !p.is_identity() { p.x = p.x.mul_by_fp(&BETA); } }
            for p in &mut state.projective { p.x = p.x.mul_by_fp(&BETA); }
        }
    }
    state.finish()
}

fn top(bases:&[G2Affine],codes:&[Codes])->Vec<G2Affine>{
    let mut counts=vec![0usize;2*SLOTS];for(p,s)in bases.iter().zip(codes){let d=s[WINDOWS-1];if d!=0&&!p.is_identity(){counts[d.unsigned_abs()as usize-1+if d<0{SLOTS}else{0}]+=1;}}
    let mut starts=Vec::with_capacity(2*SLOTS+1);starts.push(0);for n in counts{starts.push(starts.last().unwrap()+n);}
    let mut positions=starts[..2*SLOTS].to_vec();let mut order=vec![0u32;*starts.last().unwrap()];
    for(i,(p,s))in bases.iter().zip(codes).enumerate(){let d=s[WINDOWS-1];if d!=0&&!p.is_identity(){let b=d.unsigned_abs()as usize-1+if d<0{SLOTS}else{0};order[positions[b]]=i as u32;positions[b]+=1;}}
    if order.is_empty(){return vec![G2Affine::IDENTITY;SLOTS];}
    let mut reduced=crate::msm::reduce_indexed_buckets(bases,&order,&starts);let negative=reduced.split_off(SLOTS).into_iter().map(|p|-p).collect::<Vec<_>>();
    super::super::merge_buckets(&mut reduced,&negative);reduced
}
fn phi(p:G2Projective)->G2Projective{G2Projective::new(p.x.mul_by_fp(&BETA),p.y,p.z)}
fn weighted(planes:&mut[G2Affine])->G2Projective{
    if planes.len()==SLOTS {
    assert_eq!(planes.len(),SLOTS);let beta2=BETA*BETA;
    for p in &mut planes[R..2*R]{if !p.is_identity(){p.x=p.x.mul_by_fp(&BETA);}}
    for p in &mut planes[2*R..]{if !p.is_identity(){p.x=p.x.mul_by_fp(&beta2);}}
    let(first,others)=planes.split_at_mut(R);super::super::merge_buckets(first,&others[..R]);super::super::merge_buckets(first,&others[R..]);
    } else { assert_eq!(planes.len(),R); }
    let first=&planes[..R];
    let sums=(0..2).into_par_iter().map(|axis|{
        let(order,starts,counts)=if axis==0{(&constants::ORDER_0[..],&constants::STARTS_0[..],&constants::COUNTS_0[..])}else{(&constants::ORDER_1[..],&constants::STARTS_1[..],&constants::COUNTS_1[..])};
        let buckets=crate::msm::group_affine_impl(|i|{let p=first[(i&0x7fff_ffff)as usize];if i>>31!=0{-p}else{p}},order,starts,counts);
        crate::msm::weighted_affine(&buckets)
    }).collect::<Vec<_>>();sums[0]+phi(sums[1])
}
fn admitted(bases:&[G2Affine],words:&[[u64;4]],peak:Option<usize>)->Option<(G2Projective,usize)>{
    if bases.len()!=words.len()||!(1024..65536).contains(&bases.len()){return None;}
    if !BatchAdd::<G2Config>::default().borrowed_g2_enabled(){return None;}
    let peak=peak?;let _owner=crate::preparation::Reservation::analysis(Some(peak))?;
    let codes=words.par_iter().map(|&w|encode(w)).collect::<Vec<_>>();let part=bases.len().div_ceil(2);
    let sums=(0..WINDOWS).into_par_iter().map(|w|{let mut parts=(0..2).into_par_iter().map(|p|{let first=(p*part).min(bases.len());let last=(first+part).min(bases.len());if w==WINDOWS-1{top(&bases[first..last],&codes[first..last])}else{ordinary(&bases[first..last],&codes[first..last],w)}}).collect::<Vec<_>>();let mut out=parts.swap_remove(0);for p in parts{super::super::merge_buckets(&mut out,&p);}weighted(&mut out)}).collect::<Vec<_>>();
    let mut out=G2Projective::IDENTITY;for &sum in sums.iter().rev(){for _ in 0..7{out=out.double();}out+=sum;}Some((out,peak))
}
pub(super)fn try_query(bases:&[G2Affine],words:&[[u64;4]])->Option<(G2Projective,usize)>{admitted(bases,words,super::super::workspace::complete_ring_peak(bases.len(),rayon::current_num_threads()))}
#[cfg(test)]mod tests{
    use super::*;use zopro_bn254::Fr;
    fn scalar(v:i128)->Fr{let m=v.unsigned_abs();let s=Fr::from_canonical([m as u64,(m>>64)as u64,0,0]).unwrap();if v<0{-s}else{s}}
    fn random(s:&mut u64)->Fr{let mut b=[0;32];for c in b.chunks_exact_mut(8){*s^=*s<<13;*s^=*s>>7;*s^=*s<<17;c.copy_from_slice(&s.to_le_bytes());}Fr::from_le_bytes_mod_order(&b)}
    fn value(d:i16)->(i128,i128){if d==0{return(0,0);}let n=d.unsigned_abs()as usize-1;let(a,b)=constants::REPS[n%R];let(mut a,mut b)=(a as i128,b as i128);for _ in 0..n/R{(a,b)=(-b,a-b);}if d<0{(-a,-b)}else{(a,b)}}
    #[test]fn generated_map_and_native_codecs(){for (r,&(code,a,b))in constants::MAP.iter().enumerate(){assert_eq!(value(code),(a as i128,b as i128));assert_eq!((a as i128).rem_euclid(128)+128*(b as i128).rem_euclid(128),r as i128);}let lambda=Fr::from_decimal("4407920970296243842393367215006156084916469457145843978461");let mut seed=0xc7a24a176;let mut inputs=vec![Fr::ZERO,Fr::ONE,-Fr::ONE,lambda,-lambda];for bit in 0..254{let x=Fr::from(2u64).pow(&[bit]);inputs.extend([x-Fr::ONE,x,x+Fr::ONE]);}inputs.extend((0..10000).map(|_|random(&mut seed)));for x in inputs{let ds=encode(x.to_canonical());let pair=ds.iter().rev().fold((0i128,0i128),|(a,b),&d|{let(x,y)=value(d);(a.checked_mul(128).unwrap().checked_add(x).unwrap(),b.checked_mul(128).unwrap().checked_add(y).unwrap())});assert_eq!(scalar(pair.0)+lambda*scalar(pair.1),x);}}
    #[test]fn weighted_planes_match_independent_generator_coefficients(){let g=G2Projective::generator();let lambda=Fr::from_decimal("4407920970296243842393367215006156084916469457145843978461");let coeffs=(0..SLOTS).map(|i|match i%7{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,_=>Fr::from((i+17)as u64)}).collect::<Vec<_>>();let mut planes=G2Projective::batch_to_affine(&coeffs.iter().map(|s|g**s).collect::<Vec<_>>());let expected=coeffs.iter().enumerate().fold(Fr::ZERO,|sum,(i,c)|{let(a,b)=constants::REPS[i%R];sum+*c*(scalar(a as i128)+lambda*scalar(b as i128))*lambda.pow(&[(i/R)as u64])});assert_eq!(weighted(&mut planes).to_affine(),(g*expected).to_affine());}
    #[test]fn full_queries_preserve_borrowed_inputs_and_match_generator(){let g=G2Projective::generator();let mut seed=0x1291a44ac94b176;for n in[1024usize,2051]{let coefficients=(0..n).map(|i|match i%9{0=>Fr::ZERO,1..=3=>Fr::ONE,4=>-Fr::ONE,_=>Fr::from((i+1234567)as u64)}).collect::<Vec<_>>();let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|s|g**s).collect::<Vec<_>>());let scalars=(0..n).map(|i|match i%11{0=>Fr::ZERO,1=>Fr::ONE,2=>-Fr::ONE,3=>Fr::from(2u64),4=>-Fr::from(2u64),_=>random(&mut seed)}).collect::<Vec<_>>();let expected=(g*scalars.iter().zip(&coefficients).fold(Fr::ZERO,|a,(s,c)|a+*s**c)).to_affine();let words=scalars.iter().map(|s|s.to_canonical()).collect::<Vec<_>>();let saved_bases=bases.clone();let saved_words=words.clone();for workers in[1,4,16,32]{let pool=rayon::ThreadPoolBuilder::new().num_threads(workers).stack_size(512*1024).build().unwrap();let(out,_)=pool.install(||try_query(&bases,&words).expect("native optional workspace admitted"));assert_eq!(out.to_affine(),expected);assert_eq!(bases,saved_bases);assert_eq!(words,saved_words);}}}
    #[test]fn denied_admission_and_cost_overflow_preserve_fallback_inputs(){let bases=vec![G2Affine::GENERATOR;1024];let words=vec![[1,0,0,0];1024];assert!(admitted(&bases,&words,None).is_none());assert!(admitted(&bases,&words[..1023],Some(1)).is_none());assert_eq!(words,vec![[1,0,0,0];1024]);assert_eq!(bases,vec![G2Affine::GENERATOR;1024]);assert!(super::super::super::workspace::complete_ring_peak(usize::MAX,32).is_none());}
}
#[cfg(test)]mod completion_curve_tests {
    use super::*;
    use zopro_bn254::Fr;
    #[test]
    fn unit_phases_complete_real_curve_exceptions_and_overflow() {
        let g=G2Projective::generator();
        let lambda=Fr::from_decimal("4407920970296243842393367215006156084916469457145843978461");
        for bins in [1usize,8,2731] {
            let n=1231;
            let coefficients=(0..n).map(|i|match i%11 {0=>Fr::ZERO,1..=3=>Fr::ONE,4..=6=>-Fr::ONE,_=>Fr::from((i+19)as u64)}).collect::<Vec<_>>();
            let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|s|g**s).collect::<Vec<_>>());
            let mut expected=vec![Fr::ZERO;R];
            let codes=(0..n).map(|i| {
                let unit=(i/37)%3;let b=(i*37+i/7)%bins;let negative=i%3==0;
                if i%17!=0{expected[b]+=coefficients[i]*lambda.pow(&[unit as u64])*if negative{-Fr::ONE}else{Fr::ONE};}
                let mut s=[0i16;WINDOWS];if i%17!=0{s[0]=((unit*R+b+1)as i16)*if negative{-1}else{1};}s
            }).collect::<Vec<_>>();
            let saved_bases=bases.clone();let saved_codes=codes.clone();let out=ordinary(&bases,&codes,0);
            for (i,p) in out.iter().enumerate(){assert_eq!(*p,(g*expected[i]).to_affine(),"bins={bins} bucket={i}");}
            assert_eq!(bases,saved_bases);assert_eq!(codes,saved_codes);
        }
    }
    #[test]
    fn long_generic_collisions_use_affine_completion_without_spill_storage() {
        let g=G2Projective::generator();
        let coefficients=(0..1000).map(|i|Fr::from((i+1)as u64)).collect::<Vec<_>>();
        let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|s|g**s).collect::<Vec<_>>());
        let codes=vec![[1i16;WINDOWS];bases.len()];
        let mut state=Window::new(R,200,BatchAdd::<G2Config>::default());
        state.ring_feed(&bases,&codes,0,200,0);
        assert!(state.queue.is_empty()&&state.batch.is_empty());
        assert!(state.projective.is_empty()&&state.projective_buckets.is_empty());
        assert_eq!(state.affine[0],(g*coefficients.iter().copied().sum::<Fr>()).to_affine());
        assert!(state.batch.capacity()==200&&state.queue.capacity()==200);
    }
}
