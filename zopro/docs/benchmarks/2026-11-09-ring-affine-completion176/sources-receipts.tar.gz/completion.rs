// Suffix to the exact inherited census helper prefix, used by model and tests.
#[derive(Default)]
struct Completion { drains:u64, overflow:u64, boundary:u64, rounds:u64, checks:u64, max_rounds:u64, max_queue:usize, max_batch:usize }
struct CompleteWindow { w:Window, c:Completion }
impl std::ops::Deref for CompleteWindow { type Target=Window;fn deref(&self)->&Window{&self.w} }
impl CompleteWindow {
 fn new(n:usize)->Self { Self{w:Window::new(n),c:Completion::default()} }
 fn complete(&mut self,boundary:bool) {
  self.c.drains+=1;if boundary{self.c.boundary+=1}else{self.c.overflow+=1}
  self.w.execute();let mut rounds=0;
  while !self.w.queue.is_empty() {
   let before=self.w.queue.len();
   for i in (0..before).rev() {
    self.c.checks+=1;let b=self.w.queue[i];
    if !self.w.busy[b] { self.w.queue.swap_remove(i);self.w.add(b); }
   }
   assert!(self.w.queue.len()<before);assert!(self.w.batch.len()<=199);
   self.c.max_batch=self.c.max_batch.max(self.w.batch.len());
   self.w.execute();rounds+=1;
  }
  assert!(rounds<=199);self.c.rounds+=rounds;self.c.max_rounds=self.c.max_rounds.max(rounds);
 }
 fn feed(&mut self,digits:impl Iterator<Item=i16>) {
  for d in digits {if d==0{continue;}self.w.s.arrivals+=1;let b=d.unsigned_abs()as usize-1;
   if self.w.busy[b] { self.w.queue.push(b);self.c.max_queue=self.c.max_queue.max(self.w.queue.len());if self.w.queue.len()==199{self.complete(false);}continue; }
   self.w.add(b);self.c.max_batch=self.c.max_batch.max(self.w.batch.len());
   if self.w.batch.len()==200{self.w.execute();self.w.take();}
  }
  self.complete(true);assert!(self.w.batch.is_empty()&&self.w.queue.is_empty());
 }
 fn finish(self)->(Vec<bool>,Stream){self.w.finish()}
}

#[cfg(test)]mod completion_tests {
 use super::*;
 // Different numeric payload implementation: pending operands and deferred
 // operands are separate; source model only tracks occupancy. Sum in Z1019.
 fn payload(bins:usize,events:&[(usize,i64)]) {
  let mut expected=vec![0i64;bins];for &(b,p)in events{expected[b]=(expected[b]+p).rem_euclid(1019);}
  let mut a=vec![0i64;bins];let mut busy=vec![false;bins];let mut batch=vec![];let mut q=vec![];
  fn execute(a:&mut[i64],busy:&mut[bool],batch:&mut Vec<(usize,i64)>){let mut seen=std::collections::BTreeSet::new();for(b,p)in batch.drain(..){assert!(seen.insert(b));a[b]=(a[b]+p).rem_euclid(1019);busy[b]=false;}}
  fn drain(a:&mut[i64],busy:&mut[bool],batch:&mut Vec<(usize,i64)>,q:&mut Vec<(usize,i64)>){execute(a,busy,batch);let mut rounds=0;while !q.is_empty(){let n=q.len();for i in(0..n).rev(){let(b,p)=q[i];if !busy[b]{q.swap_remove(i);busy[b]=true;batch.push((b,p));}}assert!(q.len()<n);assert!(batch.len()<=199);execute(a,busy,batch);rounds+=1;assert!(rounds<=199);}}
  for &(b,p)in events{if busy[b]{q.push((b,p));assert!(q.len()<=199);if q.len()==199{drain(&mut a,&mut busy,&mut batch,&mut q);}}else{busy[b]=true;batch.push((b,p));if batch.len()==200{execute(&mut a,&mut busy,&mut batch);while let Some(&(b,p))=q.last(){if busy[b]{break;}q.pop();busy[b]=true;batch.push((b,p));}}}}
  drain(&mut a,&mut busy,&mut batch,&mut q);assert_eq!(a,expected);assert!(busy.iter().all(|&b|!b));
 }
 #[test]fn bounded_completion_preserves_signed_payload_and_cancellation(){for bins in[1,2,7,8,199,200,201,2731]{for n in[0,1,7,8,198,199,200,201,399,400,401,4099]{for mode in 0..3{let events=(0..n).map(|i|{let b=match mode{0=>0,1=>i%bins,_=>(i*37+i/3)%bins};let p=if i%11==0{0}else{((i/2*71+3)%1019)as i64*if i%2==0{1}else{-1}};(b,p)}).collect::<Vec<_>>();payload(bins,&events);}}}}
 #[test]fn complete_model_conserves_additions_and_bounds(){for bins in[1usize,2,7,8,199,200,201,2731]{for n in[0,1,7,8,198,199,200,201,399,400,401,4099]{for mode in 0..3{let mut w=CompleteWindow::new(bins);for phase in 0..3{w.feed((0..n).map(|i|if (i+phase)%11==0{0}else{let b=match mode{0=>0,1=>i%bins,_=>(i*37+i/3)%bins};((b+1)as i16)*if i%2==0{1}else{-1}}));}assert!(w.c.max_queue<=199);assert!(w.c.max_batch<=200);assert!(w.c.max_rounds<=199);let(live,s)=w.finish();assert_eq!(s.stats.generic,s.arrivals-live.iter().filter(|&&b|b).count()as u64);assert_eq!(s.stats.lanes*8+s.stats.tails,s.stats.generic);assert_eq!(s.queued_to_projective+s.projective_first+s.projective_mixed+s.finish_joins+s.normalize,0);}}}}
}
