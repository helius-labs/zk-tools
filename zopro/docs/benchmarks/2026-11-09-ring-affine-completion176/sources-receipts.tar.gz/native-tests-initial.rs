#[cfg(test)]mod completion_curve_tests {
    use super::*;
    use zopro_bn254::Fr;
    #[test]
    fn unit_phases_complete_real_curve_exceptions_and_overflow() {
        let g=G2Projective::generator();
        let lambda=Fr::from_decimal("4407920970296243842393367215006156084916469457145843978461");
        for bins in [1usize,8,2731] {
            let n=1231;
            let coefficients=(0..n).map(|i|match i%11 {0=>Fr::ZERO,1..=3=>Fr::ONE,4..=6=>-Fr::ONE,_=>Fr::from((i+19)as u64)}).collect::<Vec<_>>();
            let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|s|g**s).collect::<Vec<_>>());
            let mut expected=vec![Fr::ZERO;R];
            let codes=(0..n).map(|i| {
                let unit=(i/37)%3;let b=(i*37+i/7)%bins;let negative=i%3==0;
                if i%17!=0{expected[b]+=coefficients[i]*lambda.pow(&[unit as u64])*if negative{-Fr::ONE}else{Fr::ONE};}
                let mut s=[0i16;WINDOWS];if i%17!=0{s[0]=((unit*R+b+1)as i16)*if negative{-1}else{1};}s
            }).collect::<Vec<_>>();
            let saved_bases=bases.clone();let saved_codes=codes.clone();let out=ordinary(&bases,&codes,0);
            for (i,p) in out.iter().enumerate(){assert_eq!(*p,(g*expected[i]).to_affine(),"bins={bins} bucket={i}");}
            assert_eq!(bases,saved_bases);assert_eq!(codes,saved_codes);
        }
    }
    #[test]
    fn long_generic_collisions_use_affine_completion_without_spill_storage() {
        let g=G2Projective::generator();
        let coefficients=(0..1000).map(|i|Fr::from((i+1)as u64)).collect::<Vec<_>>();
        let bases=G2Projective::batch_to_affine(&coefficients.iter().map(|s|g**s).collect::<Vec<_>>());
        let codes=vec![[1i16;WINDOWS];bases.len()];
        let mut state=Window::new(R,200,BatchAdd::<G2Config>::default());
        state.ring_feed(&bases,&codes,0,200,0);
        assert!(state.queue.is_empty()&&state.batch.is_empty());
        assert!(state.projective.is_empty()&&state.projective_buckets.is_empty());
        assert_eq!(state.affine[0],(g*coefficients.iter().copied().sum::<Fr>()).to_affine());
        assert!(state.batch.capacity()==200&&state.queue.capacity()==200);
    }
}
