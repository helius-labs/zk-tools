#![recursion_limit="256"]
use serde_json::{json,Value};use sha2::{Digest,Sha256};use std::{fs,path::Path};
const R:&str="/home/ubuntu/src/zopro-perf-work/ring-affine-completion176";
const P:&str="/home/ubuntu/src/zopro-perf-work/ring-unit-phases176";
fn read(p:&str)->Value{serde_json::from_slice(&fs::read(p).unwrap()).unwrap()}
fn hash(p:&str)->String{format!("{:x}",Sha256::digest(fs::read(p).unwrap()))}
fn main(){assert!(!Path::new(&format!("{R}/model.rs")).exists());
 let old=fs::read_to_string("/home/ubuntu/src/zopro-perf-work/g2-joint-ring-census176/census.rs").unwrap();let prefix=old.split("\nfn run(").next().unwrap();
 let mut suffix=fs::read_to_string(format!("{P}/phase-model.rs")).unwrap().replace(P,R);
 for(a,b)in[
  ("let mut streams=vec![];let mut tree", "let mut completion=vec![];let mut streams=vec![];let mut tree"),
  ("let mut win=Window::new(REPS);", "let mut win=CompleteWindow::new(REPS);"),
  ("let(p,s)=win.finish();parts.push(p);streams.push(s);", "completion.push(json!({\"window\":w,\"part\":first/part,\"drains\":win.c.drains,\"overflows\":win.c.overflow,\"boundaries\":win.c.boundary,\"rounds\":win.c.rounds,\"queue_checks\":win.c.checks,\"max_rounds\":win.c.max_rounds,\"max_queue\":win.c.max_queue,\"max_batch\":win.c.max_batch,\"batch_histogram\":win.w.s.stats.hist}));let(p,s)=win.finish();parts.push(p);streams.push(s);"),
  ("let permitted=u(&candidate,\"vector_IFMA_proxy\")<", "assert_eq!(u(&stream,\"queued_points_to_projective\"),0);let permitted=u(&candidate,\"stream_projective_mixed_plus_finish\")==0&&u(&candidate,\"stream_normalization_points\")==0&&u(&candidate,\"vector_IFMA_proxy\")<"),
  ("json!({\"rows\":n,\"candidate_stream\":stream", "json!({\"rows\":n,\"completion_diagnostics\":completion,\"candidate_stream\":stream"),
  ("phasecensuscomplete:","completequeuecensus:")
 ]{assert_eq!(suffix.matches(a).count(),1,"{a}");suffix=suffix.replace(a,b);}
 let complete=fs::read_to_string(format!("{R}/completion.rs")).unwrap();fs::write(format!("{R}/phase-model.rs"),&suffix).unwrap();fs::write(format!("{R}/model.rs"),format!("#![recursion_limit=\"256\"]\n{prefix}\n{complete}\n{suffix}")).unwrap();
 let mut pins=read(&format!("{P}/pins-fixed.json"));for(p,h)in pins.as_object().unwrap(){assert_eq!(hash(p),h.as_str().unwrap());}
 for p in[format!("{P}/analysis.json"),format!("{P}/review.json"),format!("{P}/phase-model.rs")]{pins[&p]=json!(hash(&p));}
 let parentplan=read(&format!("{P}/plan-fixed.json"));let mut steps=parentplan["steps"].as_array().unwrap().clone();for s in &mut steps{s["argv"]=json!(s["argv"].as_array().unwrap().iter().map(|v|v.as_str().unwrap().replace(P,R)).collect::<Vec<_>>());}
 steps[0]["name"]=json!("build-completion-tests");steps[1]["name"]=json!("qualify-completion-bounds-and-payload");steps[1]["argv"]=json!([format!("{R}/model-tests"),"completion_tests::","--nocapture","--test-threads=1"]);steps[1]["required_tests"]=json!(["completion_tests::bounded_completion_preserves_signed_payload_and_cancellation","completion_tests::complete_model_conserves_additions_and_bounds"]);steps[2]["name"]=json!("build-completion-census");steps[3]["name"]=json!("count-complete-unit-phases");
 let audit=json!({"exact_inherited_helper_prefix_sha256":format!("{:x}",Sha256::digest(prefix.as_bytes())),"parent_phase_suffix_sha256":hash(&format!("{P}/phase-model.rs")),"new_complete_window_inherited_helpers":true,"old_baselines_read_not_executed":true,"two_new_completion_tests":true,"inherited_tests_filtered":5,"new_proofs":0,"production_changed":false,"goal_complete":false});fs::write(format!("{R}/source-audit.json"),serde_json::to_vec_pretty(&audit).unwrap()).unwrap();
 for tail in["design.md","completion.rs","prepare.rs","model.rs","phase-model.rs","source-audit.json"]{let p=format!("{R}/{tail}");pins[&p]=json!(hash(&p));}
 for s in &steps{for v in s["argv"].as_array().unwrap(){let p=v.as_str().unwrap().split_once('=').map_or(v.as_str().unwrap(),|(_,p)|p);if Path::new(p).is_file(){pins[p]=json!(hash(p));}}}
 fs::write(format!("{R}/pins.json"),serde_json::to_vec_pretty(&pins).unwrap()).unwrap();fs::write(format!("{R}/plan.json"),serde_json::to_vec_pretty(&json!({"version":1,"source_pins":format!("{R}/pins.json"),"steps":steps})).unwrap()).unwrap();println!("prepared4steps/2newtests/{}pins; no capture",pins.as_object().unwrap().len());
}
