impl<'a> Window<'a> {
    // Same fixed schedule as the qualified structural model. No scratch or
    // Window field is added; every round strictly shrinks the bounded queue.
    fn ring_complete(&mut self) {
        self.execute();
        while !self.queue.is_empty() {
            let before = self.queue.len();
            for i in (0..before).rev() {
                let (encoded, p) = self.queue[i];
                if !self.busy((encoded & 0x7fffffff) as usize) {
                    self.queue.swap_remove(i);
                    self.add(encoded, p);
                }
            }
            debug_assert!(self.queue.len() < before);
            debug_assert!(self.batch.len() <= 199);
            self.execute();
        }
    }
    fn ring_feed(&mut self, bases: &'a [G2Affine], codes: &[Codes], w: usize, size: usize, unit: usize) {
        for (p, s) in bases.iter().zip(codes) {
            let d = s[w];
            if d == 0 { continue; }
            let index = d.unsigned_abs() as usize - 1;
            if index / R != unit { continue; }
            if p.is_identity() { continue; }
            let b = index % R;
            let encoded = b as u32 | if d < 0 { 1 << 31 } else { 0 };
            if self.busy(b) {
                self.queue.push((encoded, p));
                if self.queue.len() == size - 1 { self.ring_complete(); }
                continue;
            }
            self.add(encoded, p);
            if self.batch.len() == size { self.execute(); self.take_from_queue(); }
        }
        self.ring_complete();
    }
}
fn ordinary(bases: &[G2Affine], codes: &[Codes], w: usize) -> Vec<G2Affine> {
    let size = batch_size(12).max(32);
    debug_assert_eq!(size, 200);
    let mut state = Window::new(R, size, BatchAdd::<G2Config>::default());
    for unit in (0..3).rev() {
        state.ring_feed(bases, codes, w, size, unit);
        debug_assert!(state.batch.is_empty() && state.queue.is_empty());
        if unit != 0 {
            for p in &mut state.affine { if !p.is_identity() { p.x = p.x.mul_by_fp(&BETA); } }
            for p in &mut state.projective { p.x = p.x.mul_by_fp(&BETA); }
        }
    }
    state.finish()
}
