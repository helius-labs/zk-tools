// This suffix follows the exact inherited recoder/Stats/Window helper prefix.
const ROOT:&str="/home/ubuntu/src/zopro-perf-work/ring-affine-completion176";
const REPS:usize=2731;

fn work(stream:&Value,tree:&Value,top:&Value)->Value {
    let u=|v:&Value,k:&str|v[k].as_u64().unwrap();
    let blocks=u(stream,"full_8lane_groups")+u(tree,"full_8lane_groups")+u(top,"full_8lane_groups");
    let calls=u(stream,"affine_batches")+u(tree,"batch_or_tree_layer_calls")+u(top,"batch_or_tree_layer_calls");
    let tree_groups=u(tree,"full_8lane_groups")+u(top,"full_8lane_groups");
    let layers=u(tree,"batch_or_tree_layer_calls")+u(top,"batch_or_tree_layer_calls");
    // Below32 ordinary pairs the original record path adds one V per group.
    let extra=|v:&Value|v["ordinary_pair_count_histogram"].as_object().unwrap().iter()
        .filter_map(|(m,c)|{let m=m.parse::<u64>().unwrap();(m<32).then_some((m/8)*c.as_u64().unwrap())}).sum::<u64>();
    let v=7*blocks+5*calls+extra(tree)+extra(top);
    let fused=5*blocks;
    let stream_tails=u(stream,"scalar_tail_pairs");let tree_tails=u(tree,"scalar_tail_pairs")+u(top,"scalar_tail_pairs");
    json!({"V":v,"F":fused,"vector_IFMA_proxy":100*v+150*fused,"inverse_calls":calls,
        "stream_scalar_tail_pairs":stream_tails,"tree_scalar_tail_pairs":tree_tails,
        "scalar_M":8*stream_tails+7*tree_tails+calls,"scalar_S":2*stream_tails,"scalar_fused2":4*stream_tails+5*tree_tails,
        "generic_affine_pairs":u(stream,"affine_pairs")+u(tree,"generic_affine_pairs")+u(top,"generic_affine_pairs"),
        "tree_groups":tree_groups,"tree_layers":layers,
        "stream_projective_mixed_plus_finish":u(stream,"projective_mixed_additions")+u(stream,"finish_projective_affine_joins"),
        "stream_normalization_points":u(stream,"normalization_points"),
        "not_complete_CPU_cost":true})
}

fn phase_counts(ring:&[[i16;19]],reps:&[[i128;2]],old:&Value)->Value {
    let n=ring.len();let part=n.div_ceil(2);assert_eq!(reps.len(),REPS);
    let mut completion=vec![];let mut streams=vec![];let mut tree=Stats::default();let mut top=Stats::default();
    let mut affine_maps=0usize;let mut projective_maps=0usize;let mut top_maps=0usize;
    for w in 0..19 {
        let mut parts=vec![];
        for first in(0..n).step_by(part){let last=(first+part).min(n);
            if w==18 { parts.push(signed_top(ring[first..last].iter().map(|d|d[w]),3*REPS,&mut top)); }
            else {
                let mut win=CompleteWindow::new(REPS);
                for unit in(0..3).rev(){
                    win.feed(ring[first..last].iter().filter_map(|s|{
                        let d=s[w];if d==0{return None;}let index=d.unsigned_abs()as usize-1;
                        if index/REPS!=unit{return None;}
                        let v=(index%REPS+1)as i16;Some(if d<0{-v}else{v})
                    }));
                    if unit!=0 {affine_maps+=win.alive.iter().filter(|&&b|b).count();projective_maps+=win.projective.iter().filter(|&&n|n>0).count();}
                }
                completion.push(json!({"window":w,"part":first/part,"drains":win.c.drains,"overflows":win.c.overflow,"boundaries":win.c.boundary,"rounds":win.c.rounds,"queue_checks":win.c.checks,"max_rounds":win.c.max_rounds,"max_queue":win.c.max_queue,"max_batch":win.c.max_batch,"batch_histogram":win.w.s.stats.hist}));let(p,s)=win.finish();parts.push(p);streams.push(s);
            }
        }
        let mut p=parts.remove(0);for other in parts{tree.merge(&mut p,&other);}
        let merged=if w==18 {
            top_maps+=p[REPS..].iter().filter(|&&b|b).count();let mut out=p[..REPS].to_vec();
            tree.merge(&mut out,&p[REPS..2*REPS]);tree.merge(&mut out,&p[2*REPS..]);out
        }else{p};
        assert_eq!(merged.len(),REPS);
        for axis in 0..2{let mut counts=vec![0usize;128];for(i,rep)in reps.iter().enumerate(){if merged[i]&&rep[axis]!=0{counts[rep[axis].unsigned_abs()as usize-1]+=1;}}let sums=tree.grouped(&counts);tree.weighted(&sums);}
        tree.projective_add_calls+=1;
    }
    // The leading algorithm is unchanged, including every ordinary pair,
    // tail and histogram. Check its recomposed candidate counts against the
    // saved parent observation; no parent model/test invocation is repeated.
    assert_eq!(top.value(),old["ring_indexed_top"]);
    let stream=stream_value(&streams);let tree=tree.value();let top=top.value();
    let candidate=work(&stream,&tree,&top);
    let accepted=work(&old["original_stream"],&old["original_merges_and_weighted"],&old["original_indexed_top"]);
    let parent=work(&old["ring_stream"],&old["ring_merges_axes_and_weighted"],&old["ring_indexed_top"]);
    let u=|v:&Value,k:&str|v[k].as_u64().unwrap();
    // Every noncancelling mathematical addition is either affine or an
    // exceptional-projective spill/finish. Changing phases cannot erase it.
    assert_eq!(u(&candidate,"generic_affine_pairs")+u(&candidate,"stream_projective_mixed_plus_finish"),u(&parent,"generic_affine_pairs")+u(&parent,"stream_projective_mixed_plus_finish"));
    assert_eq!(u(&stream,"queued_points_to_projective"),0);let permitted=u(&candidate,"stream_projective_mixed_plus_finish")==0&&u(&candidate,"stream_normalization_points")==0&&u(&candidate,"vector_IFMA_proxy")<u(&accepted,"vector_IFMA_proxy")&&u(&candidate,"inverse_calls")<=u(&accepted,"inverse_calls");
    json!({"rows":n,"completion_diagnostics":completion,"candidate_stream":stream,"candidate_merges_axes_weighted":tree,"unchanged_top":top,
        "accepted_work":accepted,"old_ring_work":parent,"candidate_work":candidate,
        "candidate_ordinary_affine_phi_maps":affine_maps,"candidate_ordinary_projective_phi_maps":projective_maps,
        "unchanged_top_affine_phi_maps":top_maps,"candidate_unit_map_Fq_products":2*(affine_maps+projective_maps+top_maps),
        "old_ring_unit_map_Fq_products":2*old["ring_affine_unit_phi_maps"].as_u64().unwrap(),
        "accepted_unit_map_Fq_products":2*old["original_phi_affine_and_projective_maps"].as_u64().unwrap(),
        "axis_result_phi_maps_each_recipe":19,"Horner_double_calls_unchanged":133,
        "old_ordinary_code_row_tests":18*n,"candidate_ordinary_code_row_tests":3*18*n,
        "point_identity_coordinate_tests_before_unit_filter":false,
        "ordinary_bucket_slots_old_per_part":3*REPS,"ordinary_bucket_slots_candidate_per_part":REPS,
        "all_part_window_affine_coordinate_payload_old_bytes":2*19*3*REPS*128,
        "all_part_window_affine_coordinate_payload_candidate_bytes":2*(18*REPS+3*REPS)*128,
        "native_resource_correctness_investigation_permitted":permitted,
        "native_measurement_selected":false,"generic_noncancelling_model_only":true})
}

fn main(){assert!(!std::path::Path::new(&format!("{ROOT}/analysis.json")).exists());
    let inputs:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zopro-perf-work/g2-joint-ring-screen176/inputs.json").unwrap()).unwrap();
    let prior:Value=serde_json::from_slice(&fs::read("/home/ubuntu/src/zopro-perf-work/g2-joint-ring-census176/analysis.json").unwrap()).unwrap();let mut cases=vec![];
    for(name,input)in inputs.as_object().unwrap(){let b=fs::read(input["file"].as_str().unwrap()).unwrap();assert_eq!(&b[..8],b"B2SCAN01");let n=u64::from_le_bytes(b[8..16].try_into().unwrap())as usize;assert_eq!(b.len(),16+160*n);
        let words=b[16+128*n..].chunks_exact(32).map(|b|std::array::from_fn(|j|u64::from_le_bytes(b[j*8..j*8+8].try_into().unwrap()))).collect::<Vec<_>>();
        let(_,mut ring,reps)=recipe::codes(&words);for i in 0..n{if b[16+128*i..16+128*(i+1)].iter().all(|&b|b==0){ring[i]=[0;19];}}
        let old=&prior["cases"].as_array().unwrap().iter().find(|v|v["case"]==name.as_str()).unwrap()["counts"];
        cases.push(json!({"case":name,"counts":phase_counts(&ring,&reps,old)}));
    }
    let passed=cases.iter().all(|v|v["counts"]["native_resource_correctness_investigation_permitted"]==true);
    fs::write(format!("{ROOT}/analysis.json"),serde_json::to_vec_pretty(&json!({"passed_data_validation":true,"necessary_screen_passed":passed,"cases":cases,"old_baseline_counts_read_not_reexecuted":true,"native_measurement_selected":false,"new_proofs":0,"canonical_proofs":40154,"production_changed":false,"adopted":false,"goal_complete":false})).unwrap()).unwrap();println!("completequeuecensus: necessaryscreen={passed}, zero newproof/timing/native measurement");
}

#[cfg(test)]mod phase_tests {
    fn phi((a,b):(i64,i64))->(i64,i64){((-b).rem_euclid(1019),(a-b).rem_euclid(1019))}
    fn add((a,b):(i64,i64),(c,d):(i64,i64))->(i64,i64){((a+c).rem_euclid(1019),(b+d).rem_euclid(1019))}
    fn check(events:&[(usize,usize,bool,(i64,i64))],bins:usize){
        let mut expected=vec![(0,0);bins];for &(bucket,unit,negative,p)in events{let mut p=p;for _ in 0..unit{p=phi(p);}if negative{p=(-p.0,-p.1);}expected[bucket]=add(expected[bucket],p);}
        let mut state=vec![(0,0);bins];let mut seen=vec![0u8;events.len()];for unit in(0..3).rev(){for(i,&(bucket,u,negative,p))in events.iter().enumerate(){if u!=unit{continue;}seen[i]+=1;state[bucket]=add(state[bucket],if negative{(-p.0,-p.1)}else{p});}if unit!=0{state.iter_mut().for_each(|p|*p=phi(*p));}}
        assert_eq!(state,expected);assert!(seen.iter().all(|&n|n==1));
        // A separate third-order endomorphism identity check includes zero
        // and inverse pairs; native curve exception dispatch is not tested.
        for p in state{assert_eq!(phi(phi(phi(p))),p);assert_eq!(add(add(p,phi(p)),phi(phi(p))),(0,0));}
    }
    #[test]fn phase_horner_signs_cancellations_and_unit_masks(){
        for mask in 0..64usize{let events=(0..6).filter(|i|mask>>i&1!=0).map(|i|(i%2,i/2,i%2!=0,((i*43+1)as i64,(i*19+7)as i64))).collect::<Vec<_>>();check(&events,2);}
        for bins in[1,7,127,2731]{for n in[0,1,7,8,199,200,201,1024,4099]{let events=(0..n).map(|i|(i*37%bins,i%3,i%5==0,if i%11==0{(0,0)}else{((i/2*17%1019)as i64,(i/2*43%1019)as i64)})).collect::<Vec<_>>();check(&events,bins);}}
    }
    #[test]fn retained_bucket_payload_geometry(){assert_eq!(2*19*3*2731*128,39_850_752);assert_eq!(2*(18*2731+3*2731)*128,14_681_856);assert_eq!(3*2731/2731,3);}
}
