#[cfg(zopro_g2_ring_completion)]
pub(super) fn complete_ring_peak(n: usize, workers: usize) -> Option<usize> {
    // Parent outputs can all survive suspension, irrespective of worker count.
    let mut p = shape::<G2Config>(2731, 18, 2, batch_size(12).max(32))?;
    let leading = shape::<G2Config>(8193, 1, 2, batch_size(12).max(32))?;
    p.held = add(p.held, leading.held)?;
    let top = top::<G2Config>(n.div_ceil(2), 15)?;
    p.held = add(p.held, mul(top.held, 2)?)?;
    p.held = add(p.held, vector::<[i16; 19]>(n, false)?)?;
    let axes = add(mul(vector::<Affine<G2Config>>(128, false)?, 2)?, vector::<Projective<G2Config>>(2, false)?)?;
    p.held = add(p.held, mul(axes, 19)?)?;
    let axis_leaf = crate::msm::workspace_grouping::<G2Config>(2 * 2731, 1)?;
    p.leaf = p.leaf.max(leading.leaf).max(top.leaf).max(axis_leaf);
    p.held = add(p.held, 65536 + 5462 + 2 * 2731 * 4 + 2 * (129 + 128) * core::mem::size_of::<usize>())?;
    add(p.held, mul(p.leaf, workers.max(1))?)
}

#[cfg(all(test,zopro_g2_ring_completion))]
mod complete_ring_resource_tests {
    use super::*;
    #[test]
    fn all_parent_ownership_and_checked_overflow() {
        for n in [1024usize,2051,30089,52274,65535] {
            let mut last=0;
            for workers in [1usize,4,16,32] {
                let peak=complete_ring_peak(n,workers).unwrap();
                let coordinate_payload=2*(18*2731+8193)*128;
                assert!(peak>coordinate_payload+38*n);
                assert!(peak>=last);last=peak;
                println!("RESOURCE complete-ring n={n} workers={workers} checked_requested_capacity_bytes={peak}");
            }
        }
        assert_eq!(complete_ring_peak(30089,0),complete_ring_peak(30089,1));
        assert!(complete_ring_peak(usize::MAX,32).is_none());
        assert!(complete_ring_peak(1024,usize::MAX).is_none());
        // The fixed parents alone exceed worker-count-proportional charging.
        assert!(shape::<G2Config>(2731,18,2,200).unwrap().held>2*18*2731*128);
    }
}
