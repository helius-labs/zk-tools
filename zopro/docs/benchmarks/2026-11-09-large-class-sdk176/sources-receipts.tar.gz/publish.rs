use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    fmt::Write as _,
    fs,
    path::{Path, PathBuf},
    process::Command,
};
const R: &str = "/home/ubuntu/src/zopro-perf-work/large-class-sdk176";
const D: &str = "/home/ubuntu/src/zk-tools/zopro/docs/benchmarks/2026-11-09-large-class-sdk176";
fn read(p: impl AsRef<Path>) -> Value {
    serde_json::from_slice(&fs::read(p).unwrap()).unwrap()
}
fn hash(p: impl AsRef<Path>) -> String {
    format!("{:x}", Sha256::digest(fs::read(p).unwrap()))
}
fn save(p: impl AsRef<Path>, v: Value) {
    fs::write(p, serde_json::to_vec_pretty(&v).unwrap()).unwrap()
}
fn walk(p: &Path, out: &mut Vec<PathBuf>) {
    for e in fs::read_dir(p).unwrap() {
        let e = e.unwrap();
        if e.file_type().unwrap().is_dir() {
            walk(&e.path(), out)
        } else if e.file_type().unwrap().is_file() {
            out.push(e.path())
        }
    }
}
fn f(v: &Value) -> f64 {
    v.as_f64().unwrap()
}
fn main() {
    assert!(!Path::new(D).exists());
    let a = read(format!("{R}/analysis.json"));
    let q = read(format!("{R}/review-result.json"));
    let diag = read(format!("{R}/diagnostic-summary.json"));
    let comp = read(format!("{R}/fresh-comparison.json"));
    assert_eq!(q["passed"], true);
    assert_eq!(a["gate_passed"], false);
    assert_eq!(
        a["failed_checks"],
        json!(["ALL8/ON/OFF/gain", "ALL8/ON/REF/gain"])
    );
    assert_eq!(q["canonical_count"], 43730);
    for (p, h) in read(format!("{R}/capture-pins.json")).as_object().unwrap() {
        assert_eq!(hash(p), h.as_str().unwrap());
    }
    let mut receipt_count = 0;
    for (plan, dir) in [
        ("sdk-build-plan.json", "sdk-build-run"),
        ("helper-plan.json", "helper-run"),
        ("preflight-plan.json", "preflight-run"),
        ("capture-plan.json", "runs"),
    ] {
        let p = read(format!("{R}/{plan}"));
        assert_eq!(read(format!("{R}/{dir}/result.json"))["status"], "complete");
        for s in p["steps"].as_array().unwrap() {
            let d = format!("{R}/{dir}/{}", s["name"].as_str().unwrap());
            let e = read(format!("{d}/exit.json"));
            assert_eq!(e["success"], true);
            assert_eq!(e["returncode"], 0);
            let c = read(format!("{d}/command.json"));
            assert_eq!(
                &c["argv"].as_array().unwrap()[4..],
                s["argv"].as_array().unwrap()
            );
            for st in ["stdout", "stderr"] {
                assert_eq!(hash(format!("{d}/{st}.log")), e[format!("{st}_sha256")]);
            }
            receipt_count += 1;
        }
    }
    assert_eq!(receipt_count, 1379);
    fs::create_dir_all(format!("{D}/artifacts")).unwrap();
    for file in [
        "analysis.json",
        "review-result.json",
        "fresh-comparison.json",
        "diagnostic-summary.json",
        "decision.json",
        "source-audit.json",
        "link-review.json",
        "identities.json",
        "prospective-review.json",
        "protocol.md",
        "design.md",
        "next.md",
        "preparation-note.md",
        "preflight-review.json",
        "proof-inventory.json",
    ] {
        fs::copy(format!("{R}/{file}"), format!("{D}/artifacts/{file}")).unwrap();
    }
    let mut report=String::from("# Oversized scalar-class splitting: complete-proof comparison\n\n**The candidate is slower overall and is not adopted.** Across all eight shapes, ON/OFF is **1.003144 [1.001097, 1.005262]** and ON/accepted REF is **1.003705 [1.001757, 1.005717]**: increases of 0.314% and 0.371%. Both required aggregate improvement checks fail. All other 85 declared checks pass, including every control calibration, nonregression tolerance, RSS and diagnostic-quality check. Production remains unchanged.\n\nThe [native-qualified implementation](../2026-11-09-large-class-native176/README.md) splits scalar classes larger than the existing 2,048-point G1 / 1,024-point G2 tile into independent unchanged affine trees, then combines partial roots in the original 256-class output organization. Short classes keep their original inputs. Checked optional admission covers all new metadata/partials and first-pass scratch; denial retains the original reducer. There is no retained key table, expanded point representation, new pool, changed digit geometry or artificial architectural memory cap. Extra tasks, partial roots and a second reduction pass remain costs.\n\nExact qualified OFF/ON cores are reused without rebuilding. Six downstream commands link coherent prover/zolana/SDK artifacts with original field1200, adopted bitmap reset and the unchanged fixed-placement driver, native/O3/fat-LTO/one-CGU. REF is the exact accepted SDK. All 176 production-source hashes recover; 175 private originals are exact, one parent is reversible and two children are new. Explicit LARGE_CLASS_TILES=1 is set in every arm; only ON compiles the reducer. Native correctness/generic checks are inherited, not rerun.\n\nThe protocol and four compiled readers were frozen before any preflight. The experiment prospectively uses all-eight aggregate gains rather than primary-only gain checks because retained primary grouping declines. Primary remains subject to both nonregression/RSS checks and control calibration, and participates in the all-eight aggregate. This changes the experiment's selection test, not the full goal: final success still requires verified CPU10× on every supplied shape. No observation informed this rule.\n\nAll-eight plus merge54 at 32 workers, with primary/merge54 at one and 16 workers, pass 26 functional processes and 26 independent Gnark checks before timing. The 104 functional requests establish correctness only. The timing matrix has 11 conditions: all-eight plus merge54 at32, plus primary solo/16. Primary16/32 use 31 blocks of151 requests; other conditions use15 blocks of31, except solo11. Arm and case order rotate and reverse. Each request solves, proves with fresh randomness, verifies internally and serializes; loading, pool creation, three primes and final export are outside timing. Worker affinity is CPU2 solo,0–15 at16,0–31 at32, with before/after worker index/TID/CPU and N+1-task bindings.\n\nTimes below are medians of process means. Ratios pair blocks and need not equal quotients of displayed medians. Bounds are the frozen20,000-resample paired bootstrap95% intervals; aggregate bounds resample shapes independently with equal log weight. They have no simultaneous familywise guarantee. All observations remain.\n\n|Case|REF ms|OFF ms|ON ms|ON/OFF [95% bounds]; wins|ON/REF [95% bounds]; wins|\n|---|---:|---:|---:|---|---|\n");
    let cases = read(format!("{R}/measure-cases.json"));
    for c in cases.as_array().unwrap() {
        let n = c["name"].as_str().unwrap();
        let p = &a["pairs"][format!("{n}/ON/OFF")];
        let r = &a["pairs"][format!("{n}/ON/REF")];
        let blocks = if c["shape"] == "1x2" && c["workers"] != 1 {
            31
        } else {
            15
        };
        writeln!(report,"|{n}|{:.6}|{:.6}|{:.6}|{:.6} [{:.6}, {:.6}]; {}/{blocks}|{:.6} [{:.6}, {:.6}]; {}/{blocks}|",f(&a["cells"][format!("{n}/REF")]["median_ms"]),f(&a["cells"][format!("{n}/OFF")]["median_ms"]),f(&a["cells"][format!("{n}/ON")]["median_ms"]),f(&p["paired_geomean"]),f(&p["bootstrap95"][0]),f(&p["bootstrap95"][1]),p["wins"],f(&r["paired_geomean"]),f(&r["bootstrap95"][0]),f(&r["bootstrap95"][1]),r["wins"]).unwrap();
    }
    report.push_str("\nPrimary32 is essentially unchanged against fresh OFF, while its ON/REF estimate is 0.299% slower. The solo ON/OFF gain of0.400% is retained, but its ON/REF interval crosses parity. No candidate-namespace samples occur in the primary profiles; the retained grouping population and source dispatch explain why primary can be a negative control. These observations do not attribute the solo difference to class-splitting arithmetic.\n\nThe all-eight slowdown intervals are wholly above parity. The4×2 ON/OFF estimate is0.881% slower, and merge54 is1.118% slower. Passing the3% nonregression tolerance does not assert equality or improvement. Only the two all-eight gain checks fail; no control-calibration failure explains this result. Close this fixed implementation without a size/worker/curve/layout sweep or favorable-subset promotion.\n\n|Case|REF /OFF /ON maximum RSS MiB|REF /OFF /ON median CPU ms per proof|\n|---|---:|---:|\n");
    for c in cases.as_array().unwrap() {
        let n = c["name"].as_str().unwrap();
        writeln!(
            report,
            "|{n}|{:.2} /{:.2} /{:.2}|{:.3} /{:.3} /{:.3}|",
            f(&a["cells"][format!("{n}/REF")]["max_RSS_MiB"]),
            f(&a["cells"][format!("{n}/OFF")]["max_RSS_MiB"]),
            f(&a["cells"][format!("{n}/ON")]["max_RSS_MiB"]),
            f(&a["cells"][format!("{n}/REF")]["median_CPU_ms"]),
            f(&a["cells"][format!("{n}/OFF")]["median_CPU_ms"]),
            f(&a["cells"][format!("{n}/ON")]["median_CPU_ms"])
        )
        .unwrap();
    }
    report.push_str("\nRSS includes key loading, primes and allocator retention. It is not incremental workspace, minimum RAM or pressure qualification. All22 declared ON/control RSS guards pass. The existing admission/fallback checks do not replace a complete proof under memory pressure.\n\nAll591 latency processes finish before15 warm four-event PMU panels and15 separate fixed16M cycles:u profiles. Diagnostics cover primary16/32 and2×2/4×2/24×2 at32. No owned build/helper/hash/decode/analysis/report/push overlaps recording, including preflight. All621 recording processes finish before75 offline decode/ownership/event/loss commands and621 Gnark checks.\n\n|Diagnostic case|ON/OFF instructions|ON/OFF cycles|ON/OFF cache misses|ON/OFF branch misses|ON candidate-namespace samples|\n|---|---:|---:|---:|---:|---:|\n");
    for row in diag["rows"].as_array().unwrap() {
        let ratios = &row["ON_control_PMU_ratios"]["OFF"];
        writeln!(
            report,
            "|{}|{:.6}|{:.6}|{:.6}|{:.6}|{}|",
            row["case"].as_str().unwrap(),
            f(&ratios["instructions:u"]),
            f(&ratios["cycles:u"]),
            f(&ratios["cache-misses:u"]),
            f(&ratios["branch-misses:u"]),
            row["arms"]["ON"]["flat_symbol_bins"]["large_class_tiles"]
                .as_u64()
                .unwrap_or(0)
        )
        .unwrap();
    }
    writeln!(report,"\nAll15 PMU panels satisfy the99.9% running gate. All15 profiles qualify: **{} samples**, minimum{}, maximum unknown share{:.3}%, zero LOST, with actual binary/PID/TID/CPU and fixed-period bindings. Candidate-specific samples at2×2/4×2/24×2 establish sampled execution there; absence in primary is not proof of no execution. The separate4×2 PMU panel shows fewer cycles despite slower repeated latency, while instructions rise slightly. These single descriptive panels and flat symbol bins do not isolate the critical path, a cache level, exact inverse counts, memory bandwidth or a unique cause.",diag["profile_samples"],diag["min_profile_samples"],100.*f(&diag["max_unknown_share"])).unwrap();
    report.push_str("\nThe87-check gate requires11 OFF/REF calibration intervals within factor1.03,22 ON/control nonregression upper bounds≤1.03,22 ON/control peak-RSS ratios≤1.05, both all-eight gain upper bounds<1, and30 diagnostic-quality checks. Source, receipt, placement, input, public, proof and freshness bindings are additionally mandatory. No gain floor, excluded block, extension, changed threshold or reroll is used.\n\nThe frozen separate reader reconstructs591 raw process means, every paired/aggregate ratio, all87 decisions and621 fresh main exports. It shares the inherited statistical/PMU/profile parsers, not native arithmetic. Across preflight and main, **45,938 internally verified SDK requests and647 distinct independently Gnark-verified final exports** advance the canonical inventory43,083→43,109→43,730. These are fixed input fixtures with fresh randomized proofs, not45,938distinct witnesses.\n\nAll1,379 workflow commands complete successfully once: six downstream builds, four helper builds,52preflight and1,317main commands. An initial standalone linker-review preparation failed because its local audit copy was missing; supplying the exact already-qualified audit fixes that dependency. No scientific code, protocol, successful build, test or measurement is replayed. Setup, link/analysis/read/publication helper invocations are outside the workflow-command count.\n\nThe full CPU10× goal remains active and unmet, **0/8**. The following fresh accepted-build comparison uses supplied M5 CPU/Metal references on different hardware; they were not remeasured. Cross-machine ratios do not establish equal hardware efficiency.\n\n|Shape|Accepted CPU ms|Candidate CPU ms|M5 CPU ms /accepted speedup|M5 Metal ms /accepted speedup|CPU10× target ms|\n|---|---:|---:|---:|---:|---:|\n");
    for row in comp["rows"].as_array().unwrap() {
        writeln!(
            report,
            "|{}|{:.6}|{:.6}|{:.1} /{:.3}×|{:.1} /{:.3}×|{:.1}|",
            row["shape"].as_str().unwrap(),
            f(&row["REF_CPU_ms"]),
            f(&row["candidate_CPU_ms"]),
            f(&row["M5_CPU_ms"]),
            f(&row["REF_CPU_speedup"]),
            f(&row["M5_Metal_ms"]),
            f(&row["REF_Metal_speedup"]),
            f(&row["CPU_10x_target_ms"])
        )
        .unwrap();
    }
    report.push_str("\nAccepted primary peak RSS is133.50MiB in this campaign; merge54 is162.541995ms without a supplied M5 reference. The previous7.803404ms primary observation belongs to the same accepted artifact; no slower replacement was adopted. There is no new AWS/Aeglos, mobile/ARM, huge-circuit, pressure/swap, minimum-RAM or concurrent-proof throughput result. Next research should remove useful bulk arithmetic or dependencies; changing large-class task organization alone did not improve complete proofs.\n\n[Full analysis](artifacts/analysis.json), [independent review](artifacts/review-result.json), [CPU/Metal comparisons](artifacts/fresh-comparison.json), [CPU diagnostics](artifacts/diagnostic-summary.json), [decision](artifacts/decision.json), [protocol](artifacts/protocol.md), [prospective review](artifacts/prospective-review.json), [source recovery](artifacts/source-audit.json), [coherent links](artifacts/link-review.json), [preflight](artifacts/preflight-review.json), [main export inventory](artifacts/proof-inventory.json), [preparation note](artifacts/preparation-note.md), [continuation](artifacts/next.md), [sources and receipts](sources-receipts.tar.gz), [archive index](artifacts/archive-index.json), [checksums](SHA256SUMS).\n");
    fs::write(format!("{D}/README.md"), &report).unwrap();
    let pack = PathBuf::from(format!("{R}/publication-source"));
    fs::create_dir(&pack).unwrap();
    let mut files = vec![];
    for file in [
        "prepare-sdk.rs",
        "linker-review.rs",
        "adapt.rs",
        "source_provenance.rs",
        "preflight.rs",
        "campaign.rs",
        "sdk-analysis.rs",
        "review.rs",
        "prospective.rs",
        "statistics.rs",
        "sampling.rs",
        "metadata.rs",
        "counter.rs",
        "summarize.rs",
        "publish.rs",
        "preflight-checkpoint.rs",
        "design.md",
        "protocol.md",
        "next.md",
        "preparation-note.md",
        "analysis.json",
        "rows.json",
        "profile-symbols.json",
        "review-result.json",
        "fresh-comparison.json",
        "diagnostic-summary.json",
        "decision.json",
        "source-audit.json",
        "link-review.json",
        "identities.json",
        "prospective-review.json",
        "preflight-review.json",
        "proof-inventory.json",
        "preflight-jobs.json",
        "jobs.json",
        "cases.json",
        "measure-cases.json",
        "environment.json",
        "sdk-build-plan.json",
        "sdk-build-pins.json",
        "build-pins.json",
        "helper-plan.json",
        "helper-pins.json",
        "preflight-plan.json",
        "preflight-pins.json",
        "capture-plan.json",
        "capture-pins.json",
    ] {
        files.push(PathBuf::from(format!("{R}/{file}")));
    }
    for dir in ["sdk-build-run", "helper-run", "preflight-run", "runs"] {
        walk(Path::new(&format!("{R}/{dir}")), &mut files);
    }
    files.sort();
    let mut members = vec![];
    for p in files {
        let rel = p.strip_prefix(R).unwrap();
        let bytes = fs::read(&p).unwrap();
        assert!(std::str::from_utf8(&bytes).is_ok());
        let to = pack.join(rel);
        fs::create_dir_all(to.parent().unwrap()).unwrap();
        fs::write(&to, &bytes).unwrap();
        members.push(json!({"path":rel,"bytes":bytes.len(),"sha256":hash(to)}));
    }
    let archive = format!("{D}/sources-receipts.tar.gz");
    assert!(Command::new("tar")
        .args(["-czf", &archive, "-C", pack.to_str().unwrap(), "."])
        .status()
        .unwrap()
        .success());
    let round = format!("{R}/publication-roundtrip");
    fs::create_dir(&round).unwrap();
    assert!(Command::new("tar")
        .args(["-xzf", &archive, "-C", &round, "."])
        .status()
        .unwrap()
        .success());
    for m in &members {
        assert_eq!(
            hash(Path::new(&round).join(m["path"].as_str().unwrap())),
            m["sha256"]
        );
    }
    save(
        format!("{D}/artifacts/archive-index.json"),
        json!({"archive_sha256":hash(&archive),"members":members,"canonical_proofs":43730,"ledger_sha256":hash(format!("{R}/proof-sha256-after-capture.json")),"excluded":["raw perf binaries","compiled libraries/executables","unchanged complete source","keys/images/requests/points/scalars/witnesses/proof/public payloads","full historical proof ledger","full nm decodes (hashes in link/native identities)"]}),
    );
    fs::write(format!("{D}/SHA256SUMS"), "").unwrap();
    let mut links = 0;
    for s in report.split("](").skip(1) {
        let p = s.split(')').next().unwrap();
        assert!(Path::new(D).join(p).exists(), "{p}");
        links += 1;
    }
    let publication = json!({"passed":true,"archive_members":members.len(),"archive_roundtrip":true,"links":links,"workflow_commands":1379,"latency_processes":591,"main_recording_processes":621,"profile_samples":625414,"new_stage_SDK_requests":45938,"new_stage_Gnark_exports":647,"canonical_proofs":43730,"gate_passed":false,"failed_checks":a["failed_checks"],"production_unchanged":true,"adopted":false,"goal_active":true,"goal_complete":false,"targets_met":0});
    save(format!("{R}/publication.json"), publication.clone());
    save(format!("{D}/artifacts/publication.json"), publication);
    let mut files = vec![];
    walk(Path::new(D), &mut files);
    files.sort();
    let mut sums = String::new();
    for p in files {
        if p.file_name().unwrap() == "SHA256SUMS" {
            continue;
        }
        writeln!(
            sums,
            "{}  {}",
            hash(&p),
            p.strip_prefix(D).unwrap().display()
        )
        .unwrap();
    }
    fs::write(format!("{D}/SHA256SUMS"), &sums).unwrap();
    for line in sums.lines() {
        let (h, p) = line.split_once("  ").unwrap();
        assert_eq!(hash(Path::new(D).join(p)), h);
    }
    println!("LARGE_CLASS_SDK_PUBLICATION_PASS{}members/{links}links/1379commands;2of87fail;647freshGnarkexports;canonical43730;goalactive0of8",members.len());
}
